// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// N yi ibiti o wa ni `[mid-left, mid+right)` bii pe eroja ni `mid` di eroja akọkọ.Ni ibamu, yiyi ibiti awọn eroja `left` wa si apa osi tabi awọn eroja `right` si apa ọtun.
///
/// # Safety
///
/// Awọn pàtó ibiti o gbọdọ jẹ wulo fun kika ati kikọ.
///
/// # Algorithm
///
/// Ti lo alugoridimu 1 fun awọn iye kekere ti `left + right` tabi fun `T` nla.
/// A gbe awọn eroja lọ si awọn ipo ipari wọn lẹẹkọọkan bẹrẹ ni `mid - left` ati lilọsiwaju nipasẹ awọn igbesẹ `right` modulo `left + right`, bii pe igba diẹ nikan ni o nilo.
/// Nigbamii, a de pada si `mid - left`.
/// Sibẹsibẹ, ti `gcd(left + right, right)` ko ba jẹ 1, awọn igbesẹ ti o loke ju awọn eroja lọ.
/// Fun apere:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// O da, nọmba ti foju lori awọn eroja laarin awọn eroja ti o pari jẹ dogba nigbagbogbo, nitorinaa a le ṣe aiṣedeede ipo ibẹrẹ wa ati ṣe awọn iyipo diẹ sii (apapọ nọmba awọn iyipo ni `gcd(left + right, right)` value).
///
/// Ipari ipari ni pe gbogbo awọn eroja ti pari ni ẹẹkan ati ni ẹẹkan.
///
/// Ti lo alugoridimu 2 ti `left + right` ba tobi ṣugbọn `min(left, right)` jẹ kekere to lati fi ipele ti ifipamọ akopọ kan.
/// Awọn ẹda `min(left, right)` ti wa ni dakọ si ibi ipamọ, `memmove` ti lo si awọn miiran, ati pe awọn ti o wa lori ifipamọ ni a gbe pada sinu iho ni apa idakeji ibiti wọn ti bẹrẹ.
///
/// Awọn alugoridimu ti o le jẹ vectorized ṣe aṣeyọri loke ti ẹẹkan `left + right` di nla to.
/// Alugoridimu 1 le jẹ vectorized nipasẹ gige ati ṣiṣe ọpọlọpọ awọn iyipo ni ẹẹkan, ṣugbọn awọn iyipo diẹ lo wa ni apapọ titi `left + right` fi tobi, ati pe ọran ti o buru ju ti ẹyọkan kan wa nigbagbogbo.
/// Kàkà bẹẹ, alugoridimu 3 lilo tun swapping ti `min(left, right)` eroja titi a kere N yi isoro ti wa ni osi.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// nigbati `left < right` awọn swapping ṣẹlẹ lati osi dipo.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. awọn ni isalẹ aligoridimu le kuna ti o ba ti awọn wọnyi igba ti wa ni ko ẹnikeji
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Alugoridimu 1 Microbenchmarks fihan pe awọn apapọ išẹ fun ID lásìkò ni o dara gbogbo awọn ọna titi nipa `left + right == 32`, ṣugbọn awọn buru irú iṣẹ opin si ani ni ayika 16.
            // 24 a ti yàn bi arin ilẹ.
            // Ti iwọn ti `T` tobi ju 4 'usize`s, algorithm yii tun dara ju awọn alugoridimu miiran lọ.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ibere ti akọkọ yika
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` O le rii ṣaaju ọwọ nipa ṣiṣe iṣiro `gcd(left + right, right)`, ṣugbọn o yara lati ṣe lupu kan eyiti o ṣe iṣiro gcd bi ipa ẹgbẹ, lẹhinna ṣe iyoku chunk
            //
            //
            let mut gcd = right;
            // awọn aṣepari fi han pe o yara lati yi awọn akoko ara ilu pada ni gbogbo ọna nipasẹ dipo kika igba diẹ lẹẹkan, didakọ sẹhin, ati lẹhinna kikọ igba diẹ ni ipari pupọ.
            // Eyi ṣee ṣe nitori otitọ pe sisiparọ tabi rirọpo awọn akoko aye lo adirẹsi iranti nikan ni lupu dipo iwulo lati ṣakoso meji.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // dipo jijẹ `i` ati lẹhinna ṣayẹwo ti o ba wa ni ita awọn aala, a ṣayẹwo ti `i` yoo lọ si ita awọn aala lori alekun ti n bọ.
                // Eyi ṣe idilọwọ eyikeyi ipari ti awọn itọka tabi `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // opin akọkọ yika
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ipo yii gbọdọ wa nibi ti o ba jẹ `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // pari chunk pẹlu awọn iyipo diẹ sii
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` kii ṣe iru iwọn odo, nitorinaa o dara lati pin nipasẹ iwọn rẹ.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Alugoridimu 2 Awọn `[T; 0]` nibi ni lati rii daju yi ti ni bojumu deedee fun T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Alugoridimu 3 Ọna miiran wa ti swapping eyiti o ni wiwa ni ibiti swap ti o kẹhin ti algorithm yii yoo jẹ, ati swapping ni lilo chunk ti o kẹhin dipo yiyi awọn ege ti o wa nitosi bi algorithm yii n ṣe, ṣugbọn ọna yii tun yarayara.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Alugoridimu 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}