//! Awọn iṣẹ lori ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Awọn iṣayẹwo ti gbogbo awọn baiti ninu bibẹ pẹlẹbẹ yii wa laarin ibiti ASCII wa.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Awọn iṣayẹwo pe awọn ege meji jẹ ibaamu-aibikita ọran-ASCII.
    ///
    /// Kanna bi `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ṣugbọn laisi ipin ati didaakọ awọn igba aye.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Iyipada nkan bibẹ pẹlẹpẹlẹ si ipo ASCII ti o ga julọ ni ipo.
    ///
    /// Awọn lẹta ASCII 'a' si 'z' ti wa ni ya aworan si 'A' si 'Z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati da iye tuntun ti oke pada laisi iyipada eyi ti o wa, lo [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Iyipada nkan bibẹ pẹlẹpẹlẹ si ipo ASCII kekere ti o jẹ deede ni ipo.
    ///
    /// Awọn lẹta ASCII 'A' si 'Z' ti wa ni ya aworan si 'a' si 'z', ṣugbọn awọn lẹta ti kii ṣe ASCII ko yipada.
    ///
    /// Lati pada iye kekere ti kekere pada lai ṣe atunṣe eyi ti o wa, lo [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Pada `true` ti eyikeyi baiti ninu ọrọ `v` jẹ nonascii (>=128).
/// Snarfed lati `../str/mod.rs`, eyiti o ṣe nkan ti o jọra fun afọwọsi utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Ise ASCII igbeyewo ti yoo lo usize-ni-a-akoko mosi dipo ti baiti-ni-a-akoko mosi (nigbati o ti ṣee).
///
/// Alugoridimu ti a lo nibi rọrun pupọ.Ti o ba ti `s` ni kuru ju, a kan ṣayẹwo kọọkan baiti ati ki o ṣee ṣe pẹlu o.Tabi ki:
///
/// - Ka ọrọ akọkọ pẹlu fifuye aiṣedeede.
/// - Satunṣe ijuboluwole, ka awọn ọrọ atẹle si opin pẹlu awọn ẹru ti o baamu.
/// - Ka `usize` ti o kẹhin lati `s` pẹlu fifuye aiṣedeede.
///
/// Ti o ba ti eyikeyi ninu awọn èyà fun nkankan fun eyi ti `contains_nonascii` (above) pada otitọ, ki o si a mọ idahun si jẹ eke.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ti a ko ba ni ere ohunkohun lati imuse-ni-akoko kan, ṣubu pada si ọna iwọn.
    //
    // A tun ṣe eyi fun awọn ayaworan ile nibiti `size_of::<usize>()` ko ṣe deede tito lẹtọ fun `usize`, nitori pe o jẹ ọran edge ajeji.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Nigbagbogbo a ka ọrọ akọkọ ti a ko ṣe deede, eyiti o tumọ si `align_offset` jẹ
    // 0, a fẹ ka iye kanna lẹẹkansii fun kika ti o baamu.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // Aabo: A jẹrisi `len < USIZE_SIZE` loke.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // A ṣayẹwo eyi loke, ni itumo lakaye.
    // Akiyesi pe `offset_to_aligned` jẹ boya `align_offset` tabi `USIZE_SIZE`, awọn mejeeji ti wa ni ṣayẹwo ni gbangba loke.
    //
    debug_assert!(offset_to_aligned <= len);

    // AABO: word_ptr ni lilo deede ptr ti a lo lati ka
    // aarin chunk ti bibẹ.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` jẹ itọka baiti ti `word_ptr`, ti a lo fun awọn sọwedowo opin lupu.
    let mut byte_pos = offset_to_aligned;

    // Ṣayẹwo Paranoia nipa tito lẹtọ, nitori a fẹrẹ ṣe ọpọlọpọ awọn ẹrù aiṣedeede.
    // Ni iṣe eyi o yẹ ki o jẹ aiṣedeede dena kokoro ni `align_offset` botilẹjẹpe.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Ka awọn ọrọ ti o tẹle titi di ọrọ ti o baamu to kẹhin, laisi ọrọ ti o baamu to kẹhin funrararẹ lati ṣee ṣe ni ayẹwo iru nigbamii, lati rii daju pe iru nigbagbogbo jẹ ọkan `usize` julọ julọ lati ṣe afikun branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Ṣayẹwo mimọ-mimọ pe kika naa wa ni aala
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Ati pe awọn imọran wa nipa idaduro `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // Aabo: A mo `word_ptr` ti wa ni daradara deedee (nitori ti
        // `Align_offset`), ati awa mọ pe awa ni to baiti laarin `word_ptr` ati opin
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // Aabo: A mọ pe `byte_pos <= len - USIZE_SIZE`, eyiti o tumọ si iyẹn
        // lẹhin `add` yii, `word_ptr` yoo wa ni julọ ọkan-ti o ti kọja-opin.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Ṣayẹwo mimọ-mimọ lati rii daju pe `usize` kan ṣoṣo lo wa gaan gaan.
    // Eyi yẹ ki o jẹ iṣeduro nipasẹ ipo lupu wa.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // Aabo: Eyi gbarale `len >= USIZE_SIZE`, eyiti a ṣayẹwo ni ibẹrẹ.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}