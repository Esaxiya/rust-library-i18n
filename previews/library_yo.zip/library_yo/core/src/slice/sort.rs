//! Yiyan nkan ege
//!
//! Eleyi module ni a ayokuro alugoridimu da lori Orson Peters 'Àpẹẹrẹ-bori quicksort, atejade ni: <https://github.com/orlp/pdqsort>
//!
//!
//! Yiyapa riru jẹ ibaramu pẹlu libcore nitori ko ṣe ipin iranti, laisi iru imuṣe iyatọ iduroṣinṣin wa.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Nigbati o ba silẹ, awọn ẹda lati `src` sinu `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // Aabo: Eyi jẹ kilasi oluranlọwọ.
        //          Jọwọ tọka si lilo rẹ fun atunṣe.
        //          Èyíinì ni, ọkan gbọdọ jẹ daju pe `src` ati `dst` ko ni lqkan bi beere nipa `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Yipada eroja akọkọ si apa ọtun titi ti o yoo fi pade nkan ti o tobi tabi dogba.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // Aabo: Awọn lewu mosi ni isalẹ je titọka lai a férémù ayẹwo (`get_unchecked` ati `get_unchecked_mut`)
    // ati didakọ iranti (`ptr::copy_nonoverlapping`).
    //
    // a.Atọka:
    //  1. A ṣayẹwo iwọn ti orun si>=2.
    //  2. Gbogbo awọn titọka ti a yoo se ni nigbagbogbo laarin {0 <= index < len} ni julọ.
    //
    // b.Didaakọ iranti
    //  1. A n gba awọn itọka si awọn itọkasi eyiti o jẹ ẹri lati wulo.
    //  2. Wọn ko le ṣapọ nitori a gba awọn itọka si awọn atọka iyatọ ti ege.
    //     Paapaa, `i` ati `i-1`.
    //  3. Ti o ba ti bibẹ ti wa ni daradara deedee, awọn eroja ti wa ni daradara deedee.
    //     Ojuse olupe ni lati rii daju pe ege naa baamu daradara.
    //
    // Wo awọn alaye ni isalẹ fun alaye siwaju sii.
    unsafe {
        // Ti awọn eroja meji akọkọ ko ba ni aṣẹ ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Ka ano akọkọ sinu oniyipada ipin-akopọ kan.
            // Ti iṣẹ lafiwe atẹle kan panics, `hole` yoo lọ silẹ ati kọ akọọkọ nkan pada laifọwọyi sinu ege.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Gbe ano i`-th ni ibi kan si apa osi, nitorinaa yi iho si apa ọtun.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ti lọ silẹ ati nitorinaa awọn ẹda `tmp` sinu iho ti o ku ni `v`.
        }
    }
}

/// Yipada nkan ti o kẹhin si apa osi titi yoo fi pade alabapade ti o kere tabi dọgba.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // Aabo: Awọn lewu mosi ni isalẹ je titọka lai a férémù ayẹwo (`get_unchecked` ati `get_unchecked_mut`)
    // ati didakọ iranti (`ptr::copy_nonoverlapping`).
    //
    // a.Atọka:
    //  1. A ṣayẹwo iwọn ti orun si>=2.
    //  2. Gbogbo titọka ti a yoo ṣe jẹ nigbagbogbo laarin `0 <= index < len-1` ni pupọ julọ.
    //
    // b.Didaakọ iranti
    //  1. A n gba awọn itọka si awọn itọkasi eyiti o jẹ ẹri lati wulo.
    //  2. Wọn ko le ṣapọ nitori a gba awọn itọka si awọn atọka iyatọ ti ege.
    //     Paapaa, `i` ati `i+1`.
    //  3. Ti o ba ti bibẹ ti wa ni daradara deedee, awọn eroja ti wa ni daradara deedee.
    //     Ojuse olupe ni lati rii daju pe ege naa baamu daradara.
    //
    // Wo awọn alaye ni isalẹ fun alaye siwaju sii.
    unsafe {
        // Ti awọn eroja meji ti o kẹhin ba jade-ti aṣẹ ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Ka ano ti o kẹhin sinu oniyipada ipin-akopọ kan.
            // Ti iṣẹ lafiwe atẹle kan panics, `hole` yoo lọ silẹ ati kọ akọọkọ nkan pada laifọwọyi sinu ege.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Gbe ano i`-th ni ibi kan si apa ọtun, nitorinaa yi iho si apa osi.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ti lọ silẹ ati nitorinaa awọn ẹda `tmp` sinu iho ti o ku ni `v`.
        }
    }
}

/// Apakan ṣe ipin ege nipasẹ yiyi ọpọlọpọ awọn eroja ti ko ni aṣẹ pada ni ayika.
///
/// Pada `true` ti o ba ti ge nkan na ni ipari.Iṣẹ yi ni *ìwọ*(*n*) buru-nla.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Nọmba ti o pọ julọ ti awọn orisii ita-aṣẹ ti yoo sunmọ ni yoo yipada.
    const MAX_STEPS: usize = 5;
    // Ti bibẹrẹ ba kuru ju eyi lọ, maṣe yi awọn eroja kankan pada.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // Aabo: A ti sọ tẹlẹ ṣayẹwo yiyewo pẹlu owun pẹlu `i < len`.
        // Gbogbo titọka atẹle wa nikan ni ibiti o wa ni `0 <= index < len`
        unsafe {
            // Wa bata atẹle ti awọn eroja jade-ti-aṣẹ ni isunmọ.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Njẹ a ti pari?
        if i == len {
            return true;
        }

        // Maṣe yi awọn eroja pada lori awọn ọna kukuru, ti o ni idiyele iṣẹ.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Siparọ awọn eroja ti a rii.Eyi fi wọn sinu aṣẹ ti o tọ.
        v.swap(i - 1, i);

        // Yi lọ yi bọ awọn kere ano si apa osi.
        shift_tail(&mut v[..i], is_less);
        // Yipada eroja nla si apa ọtun.
        shift_head(&mut v[i..], is_less);
    }

    // Ko ṣakoso lati to awọn ege ni nọmba to lopin ti awọn igbesẹ.
    false
}

/// Awọn iru nkan kan nipa lilo iru ifibọ, eyiti o jẹ *O*(*n*^ 2) ọran ti o buru julọ.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Ona `v` lilo heapsort, eyi ti onigbọwọ *ìwọ*(*n*\*log(* n*)) buru-nla.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Okiti alakomeji yii bọwọ fun ailopin `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Awọn ọmọde ti `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Yan ọmọ ti o tobi julọ.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Duro ti alailera ba mu ni `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Swap `node` pẹlu ọmọ ti o tobi julọ, gbe igbesẹ kan si isalẹ, ki o tẹsiwaju sisọ.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Kọ awọn òkiti ni PCM akoko.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Ṣe agbejade awọn eroja ti o pọ julọ lati okiti.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Awọn ipin `v` sinu awọn eroja ti o kere ju `pivot`, tẹle pẹlu awọn eroja ti o tobi ju tabi dogba si `pivot`.
///
///
/// Pada nọmba awọn eroja ti o kere ju `pivot`.
///
/// Ti ipin ti wa ni ošišẹ ti Àkọsílẹ-nipasẹ-Àkọsílẹ ni lati le gbe awọn iye owo ti branching mosi.
/// A gbekalẹ imọran yii ninu iwe [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Nọmba awọn eroja ninu bulọọki aṣoju kan.
    const BLOCK: usize = 128;

    // Awọn ipin alugoridimu ntun awọn wọnyi awọn igbesẹ ti titi Ipari:
    //
    // 1. Wa kakiri a Àkọsílẹ lati apa osi lati da eroja tobi ju tabi dogba si awọn agbesoke.
    // 2. Wa kakiri bulọọki kan lati apa ọtun lati ṣe idanimọ awọn eroja ti o kere ju agbesoke.
    // 3. Ṣe paṣipaarọ awọn eroja ti a damọ laarin apa osi ati apa ọtun.
    //
    // A tọju awọn oniyipada atẹle fun bulọọki awọn eroja:
    //
    // 1. `block` - Nọmba awọn eroja ninu bulọọki naa.
    // 2. `start` - Bẹrẹ ijuboluwole sinu titobi `offsets`.
    // 3. `end` - Opin ijuboluwole sinu orun `offsets`.
    // 4. awọn aiṣedede, Awọn atọka ti awọn eroja ti ko ni aṣẹ laarin apo.

    // Àkọsílẹ lọwọlọwọ lori apa osi (lati `l` si `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Àkọsílẹ lọwọlọwọ lori apa ọtun (lati `r.sub(block_r)` to `r`).
    // Aabo: Awọn iwe fun .add() pataki mẹnuba pe `vec.as_ptr().add(vec.len())` jẹ ailewu nigbagbogbo '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Nigba ti a ba gba VLAs, gbiyanju ṣiṣẹda kan orun ti ipari `min(v.len(), 2 * ÀWỌN) `kuku
    // ju awọn ipilẹ titobi titobi meji ti ipari `BLOCK`.VLAs le jẹ kaṣe-daradara diẹ sii.

    // Pada nọmba awọn eroja laarin awọn atọka `l` (inclusive) ati `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // A ti ṣe pẹlu pipin-nipasẹ-bulọọki ipin nigbati `l` ati `r` sunmọ sunmọ.
        // Lẹhinna a ṣe diẹ iṣẹ iṣẹ alemo lati le pin awọn eroja to ku laarin.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Nọmba ti awọn eroja ti o ku (ṣi kii ṣe akawe si agbesoke).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Ṣatunṣe awọn iwọn bulọọki ki apa osi ati apa otun maṣe ṣe agbekọja, ṣugbọn jẹ ki o baamu ni pipe lati bo gbogbo aafo ti o ku.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Wa kakiri awọn eroja `block_l` lati apa osi.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // Aabo: Awọn iṣẹ ailaabo ni isalẹ pẹlu lilo ti `offset`.
                //         Gẹgẹbi awọn ipo ti iṣẹ naa nilo, a ni itẹlọrun wọn nitori:
                //         1. `offsets_l` ti wa ni ipin-akopọ, ati bayi ṣe akiyesi nkan ti a pin sọtọ.
                //         2. Iṣẹ `is_less` pada `bool` kan pada.
                //            Simẹnti a `bool` yoo ko bò `isize`.
                //         3. A ti ṣe onigbọwọ pe `block_l` yoo jẹ `<= BLOCK`.
                //            Pẹlupẹlu, `end_l` ni ipilẹṣẹ ni ibẹrẹ si ijuboluwole ti `offsets_` eyiti o kede lori akopọ naa.
                //            Nitorinaa, a mọ pe paapaa ninu ọran ti o buru julọ (gbogbo awọn epe ti `is_less` pada asan) a yoo wa ni pupọ julọ 1 baiti kọja opin.
                //        Išišẹ miiran ti ko ni aabo nihin ni gbigbasilẹ `elem`.
                //        Sibẹsibẹ, `elem` ni ibẹrẹ ibẹrẹ ijuboluwo si nkan ti o wulo nigbagbogbo.
                unsafe {
                    // Ifiwejuwe ti eka.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Wa kakiri awọn eroja `block_r` lati apa ọtun.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // Aabo: Awọn iṣẹ ailaabo ni isalẹ pẹlu lilo ti `offset`.
                //         Gẹgẹbi awọn ipo ti iṣẹ naa nilo, a ni itẹlọrun wọn nitori:
                //         1. `offsets_r` ti wa ni ipin-akopọ, ati bayi ṣe akiyesi nkan ti a pin sọtọ.
                //         2. Iṣẹ `is_less` pada `bool` kan pada.
                //            Simẹnti a `bool` yoo ko bò `isize`.
                //         3. A ti ṣe onigbọwọ pe `block_r` yoo jẹ `<= BLOCK`.
                //            Pẹlupẹlu, `end_r` ni ipilẹṣẹ ni ibẹrẹ si ijuboluwole ti `offsets_` eyiti o kede lori akopọ naa.
                //            Nitorinaa, a mọ pe paapaa ninu ọran ti o buru julọ (gbogbo awọn ẹbẹ ti `is_less` pada otitọ) a yoo wa ni pupọ julọ 1 baiti kọja opin.
                //        Išišẹ miiran ti ko ni aabo nihin ni gbigbasilẹ `elem`.
                //        Sibẹsibẹ, `elem` ni ibẹrẹ `1 *sizeof(T)` kọja opin ati pe a dinku nipasẹ `1* sizeof(T)` ṣaaju ki o to wọle si.
                //        Pẹlupẹlu, `block_r` ni idaniloju lati kere ju `BLOCK` ati `elem` yoo nitorina julọ tọka si ibẹrẹ nkan naa.
                unsafe {
                    // Ifiwejuwe ti eka.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Nọmba awọn eroja ti ko ni aṣẹ lati yipada laarin apa osi ati apa ọtun.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Dipo ti swapping ọkan bata ni akoko, ti o jẹ siwaju sii daradara lati ṣe a salayipo permutation.
            // Eyi kii ṣe deede muna si iyipada, ṣugbọn ṣe agbejade irufẹ kan nipa lilo awọn iṣẹ iranti diẹ.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Gbogbo awọn eroja ti ko ni aṣẹ ni bulọọki apa osi ni gbigbe.Gbe si bulọọki atẹle.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Gbogbo jade-ti-ibere eroja ni ọtun Àkọsílẹ ni won gbe.Gbe si bulọọki ti tẹlẹ.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Gbogbo ohun ti o ku ni bayi o wa ni julọ bulọọki kan (boya apa osi tabi ọtun) pẹlu awọn eroja ti ko ni aṣẹ ti o nilo lati gbe.
    // Iru awọn eroja ti o ku le ni irọrun yipada si opin laarin apo wọn.
    //

    if start_l < end_l {
        // Àkọsílẹ osi wa.
        // Gbe awọn eroja ti o ku kuro ninu aṣẹ si apa ọtun apa ọtun.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Awọn ọtun Àkọsílẹ si maa wa.
        // Gbe awọn eroja ti o ku kuro ninu aṣẹ si apa osi osi.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Ko si nkan miiran lati ṣe, a ti pari.
        width(v.as_mut_ptr(), l)
    }
}

/// Awọn ipin `v` sinu awọn eroja ti o kere ju `v[pivot]`, tẹle pẹlu awọn eroja ti o tobi ju tabi dogba si `v[pivot]`.
///
///
/// Pada kan tuple ti:
///
/// 1. Nọmba awọn eroja ti o kere ju `v[pivot]`.
/// 2. Otitọ ti o ba ti pin `v` tẹlẹ.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Gbe agbesoke ni ibẹrẹ bibẹrẹ.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Ka agbesoke sinu oniyipada ipin-akopọ fun ṣiṣe.
        // Ti o ba jẹ iṣiwe ifiwera atẹle panics, agbesoke yoo wa ni kikọ laifọwọyi sinu ege.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Wa bata akọkọ ti awọn eroja ti ko ni aṣẹ.
        let mut l = 0;
        let mut r = v.len();

        // Aabo: Ailewu ti o wa ni isalẹ pẹlu titọka ila kan.
        // Fun akọkọ: A ti ṣe tẹlẹ awọn igboro ti n ṣayẹwo nibi pẹlu `l < r`.
        // Fun ekeji: A ni akọkọ `l == 0` ati `r == v.len()` ati pe a ṣayẹwo `l < r` ni gbogbo iṣẹ ṣiṣe itọka.
        //                     Lati ibi a mọ pe `r` gbọdọ jẹ o kere `r == l` eyiti o fihan pe o wulo lati akọkọ.
        unsafe {
            // Wa eroja akọkọ ti o tobi ju tabi dọgba si ori-irin.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Wa nkan ti o kẹhin ti o kere ju eyiti o jẹ agbesoke.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` lọ kuro ni aaye ati kọ nkan pataki (eyiti o jẹ oniyipada ipin-akopọ) pada si bibẹ nibiti o ti wa ni akọkọ.
        // Igbese yii jẹ pataki ni idaniloju aabo!
        //
    };

    // Gbe awọn agbesoke laarin awọn meji ti ipin.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Awọn ipin `v` sinu awọn eroja to dogba si `v[pivot]` atẹle pẹlu awọn eroja ti o tobi ju `v[pivot]`.
///
/// Pada nọmba awọn eroja to dogba si ori.
/// O gba pe `v` ko ni awọn eroja ti o kere ju agbesoke lọ.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Gbe agbesoke ni ibẹrẹ bibẹrẹ.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Ka agbesoke sinu oniyipada ipin-akopọ fun ṣiṣe.
    // Ti o ba jẹ iṣiwe ifiwera atẹle panics, agbesoke yoo wa ni kikọ laifọwọyi sinu ege.
    // AABO: Atọka nibi wulo nitori o gba lati itọka si bibẹ pẹlẹbẹ kan.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Bayi ipin nkan naa.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // Aabo: Ailewu ti o wa ni isalẹ pẹlu titọka ila kan.
        // Fun akọkọ: A ti ṣe tẹlẹ awọn igboro ti n ṣayẹwo nibi pẹlu `l < r`.
        // Fun ekeji: A ni akọkọ `l == 0` ati `r == v.len()` ati pe a ṣayẹwo `l < r` ni gbogbo iṣẹ ṣiṣe itọka.
        //                     Lati ibi a mọ pe `r` gbọdọ jẹ o kere `r == l` eyiti o fihan pe o wulo lati akọkọ.
        unsafe {
            // Ri awọn akọkọ ano ti o tobi ju ni agbesoke.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Wa ano ti o kẹhin ti o dọgba si ori.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Njẹ a ti pari?
            if l >= r {
                break;
            }

            // Siparọ bata ti a rii ti awọn eroja ti ko ni aṣẹ.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // A ri awọn eroja `l` ti o dọgba si agbesoke.Ṣafikun 1 si akọọlẹ fun agbesoke funrararẹ.
    l + 1

    // `_pivot_guard` lọ kuro ni aaye ati kọ nkan pataki (eyiti o jẹ oniyipada ipin-akopọ) pada si bibẹ nibiti o ti wa ni akọkọ.
    // Igbese yii jẹ pataki ni idaniloju aabo!
}

/// Tuka diẹ ninu awọn eroja ni ayika ni igbiyanju lati fọ awọn ilana ti o le fa awọn ipin ti ko ni aiṣedeede ni iyara iyara.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Olupilẹṣẹ nọmba Pseudorandom lati iwe "Xorshift RNGs" nipasẹ George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ya ID nọmba ìfiwọn yi nọmba.
        // Nọmba naa baamu si `usize` nitori `len` ko tobi ju `isize::MAX` lọ.
        let modulus = len.next_power_of_two();

        // Diẹ ninu awọn oludije pataki yoo wa nitosi nitosi itọka yii.Jẹ ki a sọtọ wọn.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Ina kan ID nọmba modulo `len`.
            // Sibẹsibẹ, lati yago fun awọn iṣẹ iye owo a kọkọ mu o modulo agbara ti meji, ati lẹhinna dinku nipasẹ `len` titi yoo fi baamu ni ibiti `[0, len - 1]` wa.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ti wa ni ẹri lati wa ni kere ju `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Yiyan agbesoke ni `v` o si da itọka ati `true` pada ti o ba jẹ pe o ṣeeṣe ki o ti ge nkan na tẹlẹ.
///
/// Awọn eroja ni `v` le ṣe atunṣe ni ilana naa.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kere ipari lati yan awọn agbedemeji-ti-medians ọna.
    // Awọn ege kuru ju lilo ọna agbedemeji-ti-mẹta ti o rọrun.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Nọmba ti o pọ julọ ti awọn swaps ti o le ṣe ni iṣẹ yii.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Awọn atọka mẹta nitosi eyi ti a yoo yan agbesoke.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Ka iye nọmba awọn swaps lapapọ ti a fẹrẹ ṣe lakoko tito lẹsẹẹsẹ awọn atọka.
    let mut swaps = 0;

    if len >= 8 {
        // Awọn atọka Swaps ki `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Awọn atọka Swaps ki `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Wa agbedemeji ti `v[a - 1], v[a], v[a + 1]` ati tọju itọka si `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Wa awọn agbedemeji ni awọn adugbo ti `a`, `b`, ati `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Wa agbedemeji laarin `a`, `b`, ati `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Nọmba ti o pọ julọ ti awọn swaps ti ṣe.
        // Awọn ayidayida ni nkan ti n sọkalẹ tabi okeene ti n sọkalẹ, nitorinaa yiyipada yoo jasi ṣe iranlọwọ lati to lẹsẹsẹ ni yiyara.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Ona `v` recursively.
///
/// Ti ege naa ba ni aṣaaju ninu ipilẹṣẹ atilẹba, o ti ṣalaye bi `pred`.
///
/// `limit` ni nọmba awọn ipin ti ko ni idiwọn laaye ṣaaju yi pada si `heapsort`.
/// Ti o ba jẹ odo, iṣẹ yii yoo yipada lẹsẹkẹsẹ.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Awọn ege ti o to gigun yii ni lẹsẹsẹ nipa lilo iru ifibọ.
    const MAX_INSERTION: usize = 20;

    // Otitọ ti o ba ti awọn ti o kẹhin ipin ti a ni idi iwontunwonsi.
    let mut was_balanced = true;
    // Otitọ ti ipin ti o kẹhin ko ṣe dapọ awọn eroja (ipin naa ti pin tẹlẹ).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Gan kuru ege to lẹsẹsẹ lilo sii too.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ti o ba ṣe ọpọlọpọ awọn yiyan pataki pataki, daada pada si akọọlẹ ni ibere lati ṣe onigbọwọ `O(n * log(n))` ti o buru julọ.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ti ipin ipin ti o kẹhin ko ba ni iwọntunwọnsi, gbiyanju awọn ilana fifọ ni gige nipasẹ fifọ diẹ ninu awọn eroja ni ayika.
        // Ni ireti a yoo yan agbesoke to dara julọ ni akoko yii.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Yan agbesoke kan ki o gbiyanju gboju boya o ti to iru ege naa tẹlẹ.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ti ipin ti o kẹhin ba jẹ iwontunwonsi to dara ati pe ko da awọn eroja pọ, ati pe ti o ba jẹ pe asayan pataki ti ṣe asọtẹlẹ ege naa le ti to tẹlẹ.
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Gbiyanju idanimọ ọpọlọpọ awọn eroja ti ko ni aṣẹ ati yi wọn pada lati ṣatunṣe awọn ipo.
            // Ti nkan naa ba pari ni tito lẹsẹsẹ patapata, a ti pari.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ti agbesoke ti o yan ba dọgba pẹlu aṣaaju, lẹhinna o jẹ nkan ti o kere julọ ninu gige.
        // Ipin awọn bibẹ sinu eroja dogba si ati awọn eroja ti o tobi ju ni agbesoke.
        // Ọran yii nigbagbogbo lu nigbati ege naa ni ọpọlọpọ awọn eroja ẹda.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Tẹsiwaju sisọ awọn eroja ti o tobi ju agbesoke.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Ipin ipin.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Pin ege si `left`, `pivot`, ati `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Ṣe igbasilẹ sinu ẹgbẹ kuru ju lati dinku nọmba lapapọ ti awọn ipe atunkọ ati jẹ aaye akopọ kekere.
        // Lẹhinna tẹsiwaju pẹlu ẹgbẹ to gun (eyi jẹ iru si ipadasẹhin iru).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Awọn iru `v` nipa lilo iyara iyara apẹrẹ-ṣẹgun, eyiti o jẹ *O*(*n*\*log(* n*)) buru-nla.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tito lẹsẹsẹ ko ni ihuwasi ti o ni itumọ lori awọn iru iwọn odo.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Ṣe idinwo nọmba ti awọn ipin ti ko ni idawọn si `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Fun awọn ege ti o to gigun yii o ṣee ṣe yiyara lati sọtọ wọn ni irọrun.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Yan agbesoke
        let (pivot, _) = choose_pivot(v, is_less);

        // Ti agbesoke ti o yan ba dọgba pẹlu aṣaaju, lẹhinna o jẹ nkan ti o kere julọ ninu gige.
        // Ipin awọn bibẹ sinu eroja dogba si ati awọn eroja ti o tobi ju ni agbesoke.
        // Ọran yii nigbagbogbo lu nigbati ege naa ni ọpọlọpọ awọn eroja ẹda.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ti a ba ti kọja itọka wa, lẹhinna a dara.
                if mid > index {
                    return;
                }

                // Bibẹẹkọ, tẹsiwaju awọn eroja iyatọ ti o tobi ju agbesoke.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Pin ege si `left`, `pivot`, ati `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ti aarin==itọka, lẹhinna a ti pari, nitori partition() ṣe idaniloju pe gbogbo awọn eroja lẹhin aarin tobi ju tabi dogba si aarin.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Tito lẹsẹsẹ ko ni ihuwasi ti o ni itumọ lori awọn iru iwọn odo.Ma se nkankan.
    } else if index == v.len() - 1 {
        // Wa nkan ti o pọ julọ ki o gbe si ipo ti o kẹhin ti orun naa.
        // A ni ominira lati lo `unwrap()` nibi nitori a mọ pe v ko gbọdọ ṣofo.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Wa eroja min ki o si fi sii ni ipo akọkọ ti orun.
        // A ni ominira lati lo `unwrap()` nibi nitori a mọ pe v ko gbọdọ ṣofo.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}