//! Macros lo nipasẹ awọn olutọtọ ti ege.

// Inline is_empty ati len ṣe iyatọ iṣẹ ṣiṣe nla
macro_rules! is_empty {
    // Ọna ti a ṣe koodu gigun ti aṣetunṣe ZST, eyi n ṣiṣẹ mejeeji fun ZST ati ti kii ṣe ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Lati yọ diẹ ninu awọn sọwedowo aala (wo `position`), a ṣe iṣiro ipari ni ọna ti airotẹlẹ kan.
// (Idanwo nipa `codegen/bibẹ-ipo-igboro-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // nigbami a ma lo wa laarin bulọọki ti ko ni aabo

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ yii lo `unchecked_sub` nitori a dale lori wiwun lati soju gigun ti awọn olutọpa ege ege ZST gigun.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // A mọ pe `start <= end`, nitorinaa o le ṣe dara julọ ju `offset_from`, eyiti o nilo lati ṣe ni iforukọsilẹ.
            // Nipa ṣiṣeto awọn asia ti o yẹ nihin a le sọ fun LLVM eyi, eyiti o ṣe iranlọwọ lati yọ awọn sọwedowo aala kuro.
            // Aabo: Nipa iru ailopin, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Nipasẹ sọ fun LLVM pe awọn itọka naa yato si nipasẹ ọpọ gangan ti iwọn iru, o le ṣe iṣapeye `len() == 0` si isalẹ si `start == end` dipo `(end - start) < size`.
            //
            // Aabo: Nipa iru ailopin, awọn itọka ti wa ni deede nitorina awọn
            //         aaye laarin wọn gbọdọ jẹ ọpọ ti iwọn pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Itumọ pinpin ti awọn olutọtọ `Iter` ati `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Pada ano akọkọ ati ki o gbe ibẹrẹ aṣetunṣe siwaju 1.
        // Imudarasi ilọsiwaju dara si akawe si iṣẹ ti a ṣe ilana.
        // Olutọju ko gbọdọ ṣofo.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Pada ano ti o kẹhin ati gbe opin aṣetunṣe sẹhin nipasẹ 1.
        // Imudarasi ilọsiwaju dara si akawe si iṣẹ ti a ṣe ilana.
        // Olutọju ko gbọdọ ṣofo.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Fọ aṣetunṣe naa nigbati T jẹ ZST, nipa gbigbe opin aṣetọju sẹhin nipasẹ `n`.
        // `n` ko gbọdọ kọja `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Iṣẹ oluranlọwọ fun ṣiṣẹda kan ege lati aṣetunṣe.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // Aabo: a ṣẹda aṣetunṣe lati ori pẹlẹbẹ kan pẹlu ijuboluwole
                // `self.ptr` ati ipari `len!(self)`.
                // Eyi ṣe onigbọwọ pe gbogbo awọn ibeere ṣaaju fun `from_raw_parts` ti ṣẹ.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Iṣẹ oluranlọwọ fun gbigbe ibẹrẹ ti aṣetunṣe siwaju nipasẹ awọn eroja `offset`, dapada ibẹrẹ atijọ.
            //
            // Ailewu nitori aiṣedeede ko gbọdọ kọja `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // Aabo: olupe naa ṣe onigbọwọ pe `offset` ko kọja `self.len()`,
                    // nitorinaa ijuboluwo tuntun yii wa ninu `self` ati nitorinaa ṣe onigbọwọ lati jẹ asan.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Iṣẹ oluranlọwọ fun gbigbe opin aṣetọju sẹhin nipasẹ awọn eroja `offset`, n pada opin tuntun pada.
            //
            // Ailewu nitori aiṣedeede ko gbọdọ kọja `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // Aabo: olupe naa ṣe onigbọwọ pe `offset` ko kọja `self.len()`,
                    // eyiti o jẹ onigbọwọ lati ma bori `isize` kan.
                    // Pẹlupẹlu, ijuboluwole ti o wa ni awọn aala ti `slice`, eyiti o mu awọn ibeere miiran ṣẹ fun `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // le ṣe imuse pẹlu awọn ege, ṣugbọn eyi yago fun awọn sọwedowo awọn aala

                // Aabo: Awọn ipe `assume` wa ni ailewu lati ibẹrẹ ijuboluwole bibẹrẹ
                // gbọdọ jẹ ti kii-asan, ati awọn ege lori awọn ti kii ṣe ZST gbọdọ tun ni itọka ipari ti kii ṣe asan.
                // Ipe si `next_unchecked!` jẹ ailewu niwon a ṣayẹwo ti aṣetunṣe ba ṣofo akọkọ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Alasọye yii ti ṣofo bayi.
                    if mem::size_of::<T>() == 0 {
                        // A ni lati ṣe ni ọna yii bi `ptr` ko ṣe le jẹ 0, ṣugbọn `end` le jẹ (nitori wiwun).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // Aabo: opin ko le je 0 ti o ba ti T ni ko ZST nitori ptr ni ko 0 ati opin>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // Aabo: A wa ni awọn aala.`post_inc_start` ṣe ohun ti o tọ paapaa fun awọn ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // A fagile imuse aiyipada, eyiti o lo `try_fold`, nitori imuse ti o rọrun yii n ṣẹda LLVM IR ti o kere si o yara yara lati ṣajọ.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // A fagile imuse aiyipada, eyiti o lo `try_fold`, nitori imuse ti o rọrun yii n ṣẹda LLVM IR ti o kere si o yara yara lati ṣajọ.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // A fagile imuse aiyipada, eyiti o lo `try_fold`, nitori imuse ti o rọrun yii n ṣẹda LLVM IR ti o kere si o yara yara lati ṣajọ.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // A fagile imuse aiyipada, eyiti o lo `try_fold`, nitori imuse ti o rọrun yii n ṣẹda LLVM IR ti o kere si o yara yara lati ṣajọ.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // A fagile imuse aiyipada, eyiti o lo `try_fold`, nitori imuse ti o rọrun yii n ṣẹda LLVM IR ti o kere si o yara yara lati ṣajọ.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // A fagile imuse aiyipada, eyiti o lo `try_fold`, nitori imuse ti o rọrun yii n ṣẹda LLVM IR ti o kere si o yara yara lati ṣajọ.
            // Paapaa, `assume` yago fun ayẹwo igboro.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // Ailewu: A ṣe idaniloju wa lati wa ni awọn aala nipasẹ ailopin lupu:
                        // nigbati `i >= n`, `self.next()` pada `None` ati awọn lupu fi opin si.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // A fagile imuse aiyipada, eyiti o lo `try_fold`, nitori imuse ti o rọrun yii n ṣẹda LLVM IR ti o kere si o yara yara lati ṣajọ.
            // Paapaa, `assume` yago fun ayẹwo igboro.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // Aabo: `i` gbọdọ jẹ kekere ju `n` nitori o bẹrẹ ni `n`
                        // ati pe o dinku nikan.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // Aabo: olupe naa gbọdọ ṣe onigbọwọ pe `i` wa ni awọn aala ti
                // bibẹ pẹlẹbẹ, nitorinaa `i` ko le bori `isize` kan, ati pe awọn itọkasi ti o pada wa ni idaniloju lati tọka si apakan nkan kan ati nitorinaa ṣe ẹri lati wulo.
                //
                // Tun ṣe akiyesi pe olupe naa tun ṣe onigbọwọ pe a ko pe wa pẹlu itọka kanna lẹẹkansii, ati pe ko si awọn ọna miiran ti yoo wọle si iwe-iṣẹ yii ti a pe, nitorinaa o wulo fun itọkasi ti o pada lati jẹ iyipada ni ọran ti
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // le ṣe imuse pẹlu awọn ege, ṣugbọn eyi yago fun awọn sọwedowo awọn aala

                // Aabo: Awọn ipe `assume` wa ni ailewu nitori pe ibẹrẹ nkan bibẹrẹ kan gbọdọ jẹ asan,
                // ati awọn ege lori awọn ti kii ṣe ZST gbọdọ tun ni ijuboluwo ti kii ṣe asan.
                // Ipe si `next_back_unchecked!` jẹ ailewu niwon a ṣayẹwo ti aṣetunṣe ba ṣofo akọkọ.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Alasọye yii ti ṣofo bayi.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // Aabo: A wa ni igboro.`pre_dec_end` ṣe ohun ti o tọ paapaa fun awọn ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}