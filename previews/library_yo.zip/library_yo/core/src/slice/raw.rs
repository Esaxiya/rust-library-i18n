//! Free iṣẹ lati ṣẹda `&[T]` ati `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Fọọmu apẹrẹ lati ijuboluwole ati gigun kan.
///
/// Ariyanjiyan `len` ni nọmba awọn eroja **, kii ṣe nọmba awọn baiti.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `data` gbọdọ jẹ [valid] fun awọn kika fun `len * mem::size_of::<T>()` ọpọlọpọ awọn baiti, ati pe o gbọdọ ṣe deede ni deede.Eyi tumọ si ni pataki:
///
///     * Gbogbo ibiti iranti ti bibẹ pẹlẹbẹ yii gbọdọ wa ninu ohun ti a fi sọtọ kan!
///       Awọn ege ko le gun kọja ọpọlọpọ awọn nkan ti a pin.Wo [below](#incorrect-usage) fun apẹẹrẹ ni aṣiṣe ti ko mu eyi sinu akọọlẹ.
///     * `data` gbọdọ jẹ ti kii ṣe asan ati ni deede paapaa fun awọn ege gigun-odo.
///     Idi kan fun eyi ni pe awọn iṣapeye ifilelẹ enum le gbarale awọn itọkasi (pẹlu awọn ege ti gigun eyikeyi) ni tito lẹtọ ati aiṣe-asan lati ṣe iyatọ wọn si data miiran.
///     Ti o le gba a ijuboluwole ti o jẹ nkan elo bi `data` fun odo-ipari ege lilo [`NonNull::dangling()`].
///
/// * `data` gbọdọ tọka si itẹlera `len` itẹlera awọn iye ti ipilẹṣẹ ti iru `T`.
///
/// * Iranti ti a tọka nipasẹ nkan ti o pada ko gbọdọ jẹ iyipada fun iye igbesi aye `'a`, ayafi inu `UnsafeCell` kan.
///
/// * Iwọn lapapọ `len * mem::size_of::<T>()` ti gige naa ko gbọdọ tobi ju `isize::MAX`.
///   Wo iwe aabo ti [`pointer::offset`].
///
/// # Caveat
///
/// Igbesi aye fun nkan ti o pada ti wa ni ipilẹ lati lilo rẹ.
/// Lati yago fun ilokulo airotẹlẹ, o daba lati di igbesi aye rẹ si eyikeyi igbesi aye orisun ti o ni aabo ni o tọ, gẹgẹ bi nipasẹ pipese iṣẹ oluranlọwọ kan mu igbesi aye iye iye alejo kan fun bibẹrẹ, tabi nipasẹ alaye asọye.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // farahan ege kan fun eroja kan
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Lilo aito
///
/// Iṣẹ `join_slices` atẹle ni **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Ifọrọhan ti o wa loke rii daju pe `fst` ati `snd` jẹ ṣiṣọkan, ṣugbọn wọn le tun wa ninu _different allocated objects_, ninu eyiti idi ṣiṣẹda ege yii jẹ ihuwasi ti a ko ṣalaye.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` ati `b` jẹ awọn ohun ti a pin sọtọ ...
///     let a = 42;
///     let b = 27;
///     // ... eyi ti o le tibe wa ni gbe jade contiguously ni iranti: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Ṣe iṣẹ kanna bi [`from_raw_parts`], ayafi ti o ba da nkan gige kan pada.
///
/// # Safety
///
/// Ihuwasi ti wa ni aisọye ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ru:
///
/// * `data` gbọdọ jẹ [valid] fun awọn mejeeji Say ati ki o Levin fun `len * mem::size_of::<T>()` ọpọlọpọ awọn baiti, ati awọn ti o gbọdọ wa ni daradara deedee.Eyi tumọ si ni pataki:
///
///     * Gbogbo ibiti iranti ti bibẹ pẹlẹbẹ yii gbọdọ wa ninu ohun ti a fi sọtọ kan!
///       Awọn ege ko le gun kọja ọpọlọpọ awọn nkan ti a pin.
///     * `data` gbọdọ jẹ ti kii ṣe asan ati ni deede paapaa fun awọn ege gigun-odo.
///     Idi kan fun eyi ni pe awọn iṣapeye ifilelẹ enum le gbarale awọn itọkasi (pẹlu awọn ege ti gigun eyikeyi) ni tito lẹtọ ati aiṣe-asan lati ṣe iyatọ wọn si data miiran.
///
///     Ti o le gba a ijuboluwole ti o jẹ nkan elo bi `data` fun odo-ipari ege lilo [`NonNull::dangling()`].
///
/// * `data` gbọdọ tọka si itẹlera `len` itẹlera awọn iye ti ipilẹṣẹ ti iru `T`.
///
/// * Iranti ti a tọka nipasẹ nkan ti o pada ko gbọdọ wọle nipasẹ ijuboluwo miiran (kii ṣe lati inu iye ipadabọ) fun iye igbesi aye `'a`.
///   Mejeeji ka ati kọ awọn wiwọle jẹ eewọ.
///
/// * Iwọn lapapọ `len * mem::size_of::<T>()` ti gige naa ko gbọdọ tobi ju `isize::MAX`.
///   Wo iwe aabo ti [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // Aabo: olupe gbọdọ gbe adehun aabo lọwọ fun `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Awọn iyipada itọkasi tọka si T ni ege ti ipari 1 (laisi didakọ).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Awọn iyipada itọkasi tọka si T ni ege ti ipari 1 (laisi didakọ).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}