//! Ọlẹ iye ati ọkan-akoko initialization ti miiran data.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// A cell eyi ti le wa kọ si ni ẹẹkan.
///
/// Ko `RefCell`, a `OnceCell` nikan pese pín `&T` jo si awọn oniwe-iye.
/// Kii `Cell`, `OnceCell` ko nilo didakọ tabi rirọpo iye lati wọle si.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Onidan: kọ si ni ẹẹkan.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Ṣẹda titun kan sofo cell.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// N ni awọn tọka si amuye iye.
    ///
    /// Pada `None` ti o ba ti cell ti ṣofo.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // Aabo: Safe nitori `inner` ká ko baramu
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// N ni awọn mutable tọka si amuye iye.
    ///
    /// Pada `None` ti o ba ti cell ti ṣofo.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // Aabo: Safe nitori ti a ni oto wiwọle
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Kn awọn akoonu ti ti alagbeka to `value`.
    ///
    /// # Errors
    ///
    /// Yi ọna ti pada `Ok(())` ti o ba ti cell wà sofo ati `Err(value)` ti o ba ti o kún.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // Aabo: Ailewu nitori a ko le ni yiya awọn yiya iyipada ti o pọ
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // Aabo: Eleyi jẹ nikan ni ibi ibi ti a ṣeto awọn Iho, ko si meya
        // nitori reentrancy/concurrency ni o wa ṣee ṣe, ati awọn ti a ti sọ ẹnikeji pe Iho jẹ Lọwọlọwọ `None`, ki yi Kọ ntẹnumọ awọn `inner` ká ko baramu.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Gba awọn akoonu ti sẹẹli naa, bẹrẹ pẹlu `f` ti sẹẹli naa ṣofo.
    ///
    /// # Panics
    ///
    /// Ti o ba ti `f` panics, awọn panic ti wa ni ikede si awọn olupe, ati awọn cell si maa uninitialized.
    ///
    ///
    /// O ti wa ni ohun ašiše to reentrantly initialize awọn sẹẹli lati `f`.N bẹ àbábọrẹ ni a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Gba awọn akoonu ti sẹẹli naa, bẹrẹ pẹlu `f` ti sẹẹli naa ṣofo.
    /// Ti sẹẹli naa ṣofo ati pe `f` kuna, aṣiṣe kan ti pada.
    ///
    /// # Panics
    ///
    /// Ti o ba ti `f` panics, awọn panic ti wa ni ikede si awọn olupe, ati awọn cell si maa uninitialized.
    ///
    ///
    /// O ti wa ni ohun ašiše to reentrantly initialize awọn sẹẹli lati `f`.N bẹ àbábọrẹ ni a panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Akọsilẹ ti *diẹ ninu awọn* iwa ti reentrant initialization le ja si UB (wo `reentrant_init` igbeyewo).
        // Mo gbagbo pe o kan yọ yi `assert`, nigba ti fifi `set/get` ni yio jẹ ohun, sugbon o dabi dara lati panic, dipo ju to silently lo ohun atijọ iye.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Agbara awọn alagbeka, pada awọn ti a we iye.
    ///
    /// Pada `None` ti o ba ti cell wà sofo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Nitori `into_inner` gba `self` nipasẹ iye, oluṣakopọ iṣiro n jẹri pe ko ṣe ya lọwọlọwọ.
        // Ki o jẹ ailewu lati gbe jade `Option<T>`.
        self.inner.into_inner()
    }

    /// Gba awọn iye jade ti yi `OnceCell`, gbigbe ti o pada si ohun uninitialized ipinle.
    ///
    /// Ni o ni ko si ipa ati ki o pada `None` ti o ba ti `OnceCell` ko ti initialized.
    ///
    /// Abo wa ni ẹri nipa nilo a mutable itọkasi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// A iye eyi ti o ti initialized lori akọkọ wiwọle.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   setan initializing
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Ṣẹda iye ọlẹ tuntun pẹlu iṣẹ ibẹrẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Fi agbara mu awọn imọ ti yi Ọlẹ iye ati ki o pada a tọka si awọn esi.
    ///
    ///
    /// Eleyi jẹ deede si `Deref` impl, sugbon o jẹ o fojuhan.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Ṣẹda titun kan Ọlẹ iye lilo `Default` bi awọn initializing iṣẹ.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}