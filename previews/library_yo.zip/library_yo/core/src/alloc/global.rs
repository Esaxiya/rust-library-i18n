use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Olupin iranti kan ti o le forukọsilẹ bi aiyipada ile-ikawe boṣewa nipasẹ ẹya `#[global_allocator]`.
///
/// Diẹ ninu awọn ọna naa nilo pe ki a fi ipin iranti kan *silẹ lọwọlọwọ* nipasẹ olupilẹṣẹ.Eyi tumọ si pe:
///
/// * adirẹsi ti o bẹrẹ fun bulọọki iranti naa ni a ti da pada tẹlẹ nipasẹ ipe ti tẹlẹ si ọna ipin gẹgẹ bi `alloc`, ati
///
/// * iranti Àkọsílẹ ti ko ti paradà deallocated, ibi ti amorindun ti wa ni deallocated boya nipa a kọja si a deallocation ọna bi `dealloc` tabi nipa a kọja si a reallocation ọna ti padà a ti kii-asan ijuboluwole.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// The `GlobalAlloc` trait jẹ ẹya `unsafe` trait fun nọmba kan ti idi, ati implementors gbọdọ rii daju pe won fojusi si awọn wọnyi siwe:
///
/// * O ni aisọye ihuwasi ti o ba ti agbaye allocators unwind.Idinamọ yii le ṣee gbe ni future, ṣugbọn lọwọlọwọ panic lati eyikeyi awọn iṣẹ wọnyi le ja si ailewu ailewu.
///
/// * `Layout` awọn ibeere ati awọn iṣiro ni apapọ gbọdọ jẹ deede.Awọn olupe ti trait yii ni a gba laaye lati gbekele awọn iwe adehun ti a ṣalaye lori ọna kọọkan, ati pe awọn oluṣe gbọdọ rii daju pe iru awọn adehun bẹẹ jẹ otitọ.
///
/// * O le ko gbekele lori Allocations kosi ṣẹlẹ, paapa ti o ba nibẹ ni o wa fojuhan akojo Allocations ninu awọn orisun.
/// Awọn optimizer le ri ajeku Allocations ti o le boya imukuro o šee igbọkanle tabi gbe si awọn akopọ ati bayi ko okòwò wọn allocator.
/// Awọn optimizer le siwaju ro pe ipin ti wa ni jẹỌrọỌlọrun tí, ki koodu ti o lo lati ba kuna nitori allocator ikuna le bayi lojiji iṣẹ nitori awọn optimizer sise ni ayika ti o nilo fun ohun ipin.
/// Die concretely, awọn wọnyi koodu apẹẹrẹ ni unsound, laifi ti boya rẹ aṣa allocator gba kika bi ọpọlọpọ awọn Allocations ti sele.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Akọsilẹ ti awọn optimizations darukọ loke ni o wa ko ni nikan ti o dara ju ti o le wa ni gbẹyin.O le ni gbogbo ko gbekele lori okiti Allocations ṣẹlẹ ti o ba ti won le wa ni kuro lai iyipada eto ihuwasi.
///   Boya Allocations ṣẹlẹ tabi ko ni ko ara ti awọn eto ihuwasi, paapa ti o ba ti o le ṣee wa-ri nipasẹ ohun allocator ti awọn orin Allocations nipa titẹ sita tabi bibẹkọ ti nini ẹgbẹ ipa.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Ṣe iranti iranti bi a ti ṣalaye nipasẹ `layout` ti a fun.
    ///
    /// Pada a ijuboluwole to rinle-soto iranti, tabi asan lati fihan ipin ikuna.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii ko ni aabo nitori ihuwasi ti ko ṣalaye le ja si ti olupe naa ko rii daju pe `layout` ni iwọn ti kii-odo.
    ///
    /// (Itẹsiwaju subtraits le pese siwaju sii kan pato igboro lori ihuwasi, fun apẹẹrẹ, ẹri a Sentinel adirẹsi tabi a asan ijuboluwole ni esi to a odo-iwọn ipin ìbéèrè.)
    ///
    /// Apakan ti a ti sọtọ ti iranti le tabi ko le ṣe ipilẹṣẹ.
    ///
    /// # Errors
    ///
    /// Pada si ijuboluwo asan kan tọka pe boya iranti ti rẹ tabi `layout` ko pade iwọn olupilẹṣẹ yii tabi awọn idiwọ titọ.
    ///
    /// Awọn iwuri ni iwuri lati pada asan lori imukuro iranti kuku ju iṣẹyun, ṣugbọn eyi kii ṣe ibeere ti o muna.
    /// (Ni pataki: o jẹ *ofin* lati ṣe imuse trait yii ni oke ile-ikawe ipin abinibi ti o jẹ abẹrẹ lori imukuro iranti.)
    ///
    /// Ibara edun okan lati abort iṣiro ni esi si ohun ipin aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Ṣe ipin ipin ti iranti ni itọka `ptr` ti a fun pẹlu `layout` ti a fun.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii ko ni aabo nitori ihuwasi ti a ko ṣalaye le ja si ti olupe naa ko rii daju gbogbo nkan wọnyi:
    ///
    ///
    /// * `ptr` gbọdọ tọka bulọọki iranti ti a pin lọwọlọwọ nipasẹ ipin yii,
    ///
    /// * `layout` gbọdọ jẹ ipilẹ kanna ti a lo lati pin ipin yẹn ti iranti.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Huwa bi `alloc`, sugbon o tun idaniloju wipe awọn awọn akoonu ti wa ni ṣeto si odo ṣaaju ki o to ni pada.
    ///
    /// # Safety
    ///
    /// Iṣẹ yi ni lewu fun awọn ti kanna idi ti `alloc` ni.
    /// Sibẹsibẹ ipinfunni ti iranti ti o ni idaniloju jẹ ipilẹṣẹ.
    ///
    /// # Errors
    ///
    /// Pada a asan ijuboluwole tọkasi wipe boya iranti jẹ re tabi `layout` ko ni pade allocator ká iwọn tabi titete inira, o kan bi ni `alloc`.
    ///
    /// Ibara edun okan lati abort iṣiro ni esi si ohun ipin aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // Aabo: aabo guide fun `alloc` gbọdọ wa ni ọwọ si nipa awọn olupe ti.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // Aabo: bi ipin tele, ekun lati `ptr`
            // ti iwọn `size` jẹ ẹri lati wulo fun kikọ.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Isunki tabi dagba ohun amorindun ti iranti si `new_size` ti a fun.
    /// A ṣe apejuwe bulọọki nipasẹ itọka `ptr` ti a fun ati `layout`.
    ///
    /// Ti eyi ba pada ijuboluwo ti kii ṣe asan, lẹhinna nini ti ohun amorindun iranti ti a tọka nipasẹ `ptr` ti gbe si olupilẹṣẹ yii.
    /// Iranti naa le tabi ko ti ni ipin, ati pe o yẹ ki a ṣe akiyesi aiṣekuṣe (ayafi ti o dajudaju o ti gbe pada si olupe naa lẹẹkansi nipasẹ iye ipadabọ ti ọna yii).
    /// Awọn titun iranti Àkọsílẹ ti wa ni soto pẹlu `layout`, ṣugbọn pẹlu awọn `size` imudojuiwọn to `new_size`.
    /// Ifilelẹ tuntun yii yẹ ki o lo nigbati o ba n pin ipin iranti tuntun pẹlu `dealloc`.
    /// Ibiti o `0..min(layout.size(), new_size) 'ti awọn titun iranti Àkọsílẹ ti wa ni ẹri lati ni kanna iye bi awọn atilẹba Àkọsílẹ.
    ///
    /// Ti ọna yii ba pada di asan, lẹhinna nini ti ohun amorindun iranti ko ti gbe si olupilẹṣẹ yii, ati pe awọn akoonu ti bulọọki iranti ko yipada.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii ko ni aabo nitori ihuwasi ti a ko ṣalaye le ja si ti olupe naa ko rii daju gbogbo nkan wọnyi:
    ///
    /// * `ptr` gbọdọ wa ni Lọwọlọwọ soto nipasẹ yi allocator,
    ///
    /// * `layout` - gbọdọ jẹ ipilẹ kanna ti a lo lati pin ipin iranti naa,
    ///
    /// * `new_size` gbọdọ tobi ju odo lọ.
    ///
    /// * `new_size`, nigba ti yika soke si sunmọ ọpọ of `layout.align()`, kò sì gbọdọ kún (ie, awọn ti yika iye gbọdọ jẹ kere ju `usize::MAX`).
    ///
    /// (Itẹsiwaju subtraits le pese siwaju sii kan pato igboro lori ihuwasi, fun apẹẹrẹ, ẹri a Sentinel adirẹsi tabi a asan ijuboluwole ni esi to a odo-iwọn ipin ìbéèrè.)
    ///
    /// # Errors
    ///
    /// Padà asan ti o ba ti titun akọkọ ko ni pade awọn iwọn ati ki o titete inira ti awọn allocator, tabi ti o ba reallocation bibẹkọ ti kuna.
    ///
    /// Imuṣẹ ti wa ni iwuri lati pada asan lori iranti exhaustion kuku ju panicking tabi aborting, ṣugbọn yi ni ko kan ti o muna ibeere.
    /// (Ni pataki: o jẹ *ofin* lati ṣe imuse trait yii ni oke ile-ikawe ipin abinibi ti o jẹ abẹrẹ lori imukuro iranti.)
    ///
    /// Ibara edun okan lati abort iṣiro ni esi to a reallocation aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // Aabo: olupe gbọdọ rii daju pe `new_size` ko bori.
        // `layout.align()` wa lati `Layout` ati nitorinaa o jẹ ẹri lati wulo.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // Aabo: olupe gbọdọ rii daju pe `new_layout` tobi ju odo lọ.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // Aabo: bulọọki ti a ti sọ tẹlẹ tẹlẹ ko le ṣe agbekọja bulọki ti a pin sẹhin.
            // Adehun aabo fun `dealloc` gbọdọ jẹ atilẹyin nipasẹ olupe naa.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}