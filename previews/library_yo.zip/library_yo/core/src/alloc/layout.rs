use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Nigba ti yi iṣẹ ti lo ni ibi kan ati awọn oniwe-imuse le wa ni inlined, ti tẹlẹ igbiyanju lati ṣe bẹ ṣe rustc losokepupo:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Ifilelẹ ti ohun amorindun ti iranti.
///
/// Apeere ti `Layout` ṣe apejuwe ipilẹ pataki ti iranti.
/// O ba kọ a `Layout` soke bi ohun input lati fi fun ẹya allocator.
///
/// Gbogbo awọn ipilẹ ni iwọn ti o ni nkan ati titọ agbara-ti-meji.
///
/// (Note ti ipalemo ni o wa *ko* beere lati ni ti kii-odo iwọn, ani tilẹ `GlobalAlloc` nbeere wipe gbogbo iranti ibeere jẹ ti kii-odo ni iwọn.
/// A olupe gbọdọ boya rii daju wipe ipo bi yi ti wa ni pade, lilo kan pato allocators pẹlu looser awọn ibeere, tabi lo awọn diẹ aláìbìkítà `Allocator` ni wiwo.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // iwọn ti ohun amorindun ti a beere fun iranti, wọn ni awọn baiti.
    size_: usize,

    // titete ti iranti ti a beere fun iranti, wọn ni awọn baiti.
    // a rii daju pe eyi nigbagbogbo jẹ agbara-ti-meji, nitori pe API bii `posix_memalign` nilo rẹ ati pe o jẹ idiwọ ti o tọ lati fa le awọn akọle Ikọle.
    //
    //
    // (Sibẹsibẹ, a ko ni analogously nilo `deede>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Oro a `Layout` lati kan fun `size` ati `align`, tabi padà `LayoutError` ti o ba ti eyikeyi ninu awọn wọnyi ipo ti wa ni ko pade:
    ///
    /// * `align` ko gbodo je odo,
    ///
    /// * `align` gbọdọ jẹ agbara ti meji,
    ///
    /// * `size`, nigbati o ba yika to ọpọ ti o sunmọ ti `align`, ko gbọdọ bori (ie, iye iyipo gbọdọ jẹ kere tabi dọgba si `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (agbara-ti-meji tumọ si mö!=0.)

        // Iwọn ti a yika ni:
        //   size_rounded_up=(iwọn + mö, 1)&! (mö, 1);
        //
        // A mọ lati oke ti mö!=0.
        // Ti fifi kun (mö, 1) ko kunju, lẹhinna ikojọpọ yoo dara.
        //
        // Ni ilodisi,&-iṣowo pẹlu! (Mö, 1) yoo yọkuro awọn kekere-aṣẹ-kekere nikan.
        // Nitorinaa ti iṣanju ba waye pẹlu apao,&&-mask ko le ge iyokuro to lati fagile iṣan omi yẹn.
        //
        //
        // Loke ni imọran pe yiyewo fun ṣiṣan apao jẹ pataki ati pe o to.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // Aabo: awọn ipo fun `from_size_align_unchecked` ti wa
        // ṣayẹwo loke.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Ṣẹda ipilẹ kan, yiju gbogbo awọn sọwedowo.
    ///
    /// # Safety
    ///
    /// Iṣẹ yii jẹ ailewu bi ko ṣe jẹrisi awọn ipilẹṣẹ lati [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // Aabo: olupe gbọdọ rii daju pe `align` tobi ju odo lọ.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Iwọn to kere julọ ninu awọn baiti fun iwe-iranti ti ipilẹ yii.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Iṣeto baiti to kere julọ fun bulọọki iranti ti iṣeto yii.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Ṣe `Layout` kan ti o yẹ fun didimu iye ti iru `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // Aabo: tito lẹtọ jẹ iṣeduro nipasẹ Rust lati jẹ agbara ti meji ati
        // iwọn + mö konbo jẹ onigbọwọ lati baamu ni aaye adirẹsi wa.
        // Gẹgẹbi abajade lo akọle ti a ko ṣayẹwo nibi lati yago fun fifi sii koodu ti panics ti ko ba ṣe iṣapeye daradara to.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Fun wa akọkọ apejuwe a gba ti o le ṣee lo lati allocate Fifẹyinti be fun `T` (eyi ti o le wa ni a trait tabi awọn miiran unsized Iru bi a bibẹ).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // Aabo: wo ọgbọn ọgbọn ni `new` fun idi ti eyi fi nlo iyatọ ti ko ni aabo
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Fun wa akọkọ apejuwe a gba ti o le ṣee lo lati allocate Fifẹyinti be fun `T` (eyi ti o le wa ni a trait tabi awọn miiran unsized Iru bi a bibẹ).
    ///
    /// # Safety
    ///
    /// Iṣẹ yii jẹ ailewu nikan lati pe ti awọn ipo wọnyi ba mu:
    ///
    /// - Ti o ba ti `T` ni `Sized`, iṣẹ yi jẹ nigbagbogbo ailewu lati pe.
    /// - Ti iru ti ko ni iwọn ti `T` jẹ:
    ///     - [slice] kan, lẹhinna ipari iru iru nkan gbodo jẹ odidi odidi, ati iwọn ti *gbogbo iye*(ipari iru iruju + prefix titobi iwọn) gbọdọ baamu ni `isize`.
    ///     - a [trait object], ki o si awọn vtable apa ti awọn ijuboluwole gbọdọ ntoka si kan wulo vtable fun awọn iru `T` ti ipasẹ nipa ohun unsizing coersion, ati awọn iwọn ti awọn *gbogbo iye*(ìmúdàgba iru ipari + statically won ìpele) gbọdọ dada ni `isize`.
    ///
    ///     - (unstable) [extern type] kan, lẹhinna iṣẹ yii jẹ ailewu nigbagbogbo lati pe, ṣugbọn le panic tabi bibẹẹkọ pada iye ti ko tọ, bi a ko ṣe mọ iru iru ita.
    ///     Eyi jẹ ihuwasi kanna bi [`Layout::for_value`] lori itọkasi si iru iru ita.
    ///     - bibẹkọ ti, o ti wa ni conservatively ko ba gba laaye lati pe iṣẹ yi.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // Aabo: a kọja pẹlu awọn ohun ti o nilo fun awọn iṣẹ wọnyi si olupe naa
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // Aabo: wo ọgbọn ọgbọn ni `new` fun idi ti eyi fi nlo iyatọ ti ko ni aabo
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Ṣẹda a `NonNull` o ti wa ni purpili, sugbon daradara-deedee fun yi Layout.
    ///
    /// Akiyesi pe iye ijuboluwole le ṣe aṣoju aṣoju to tọ, eyiti o tumọ si pe eyi ko gbọdọ ṣee lo bi iye sentinel "not yet initialized".
    /// Awọn oriṣi ti o fi ipinlẹ lainidi gbọdọ tọpinpin ipilẹṣẹ nipasẹ awọn ọna miiran.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // Aabo: ṣe deede wa ni ẹri lati jẹ ti kii-odo
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Ṣẹda a akọkọ apejuwe awọn gba awọn ti o le si mu a iye ti kanna akọkọ bi `self`, sugbon ti o tun ti wa ni deedee to titete `align` (won ni awọn baiti).
    ///
    ///
    /// Ti `self` ba pade titete tito tẹlẹ, lẹhinna pada `self`.
    ///
    /// Akiyesi pe ọna yii ko ṣafikun eyikeyi fifẹ si iwọn apapọ, laibikita boya ipilẹ ti o pada ni tito lẹsẹsẹ miiran.
    /// Ni awọn ọrọ miiran, ti `K` ba ni iwọn 16, `K.align_to(32)` yoo *tun* ni iwọn 16.
    ///
    /// Pada aṣiṣe kan ti apapo `self.size()` ati `align` ti a fun ba ṣẹ awọn ipo ti a ṣe akojọ ni [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Pada iye fifẹ ti a gbọdọ fi sii lẹhin `self` lati rii daju pe adirẹsi atẹle naa yoo ni itẹlọrun `align` (wọnwọn ni awọn baiti).
    ///
    /// fun apẹẹrẹ, ti `self.size()` ba jẹ 9, lẹhinna `self.padding_needed_for(4)` pada 3, nitori iyẹn ni nọmba to kere julọ ti awọn baiti ti fifẹ ti a nilo lati gba adirẹsi adarọ-4 kan (ni ero pe bulọki iranti to baamu bẹrẹ ni adirẹsi adarọ-4 kan).
    ///
    ///
    /// Iye ipadabọ ti iṣẹ yii ko ni itumọ ti `align` kii ṣe agbara-ti-meji.
    ///
    /// Akiyesi pe iwulo iye ti o pada nilo `align` lati kere tabi dogba si titete ti adirẹsi ibẹrẹ fun gbogbo bulọọki ti a ti sọtọ ti iranti.Ọna kan lati ni itẹlọrun idiwọ yii ni lati rii daju `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Iye ti a yika ni:
        //   len_rounded_up=(len + mö, 1)&! (ṣe deede, 1);
        // ati lẹhinna a pada iyatọ fifẹ: `len_rounded_up - len`.
        //
        // A lo apọjuwọn isiro jakejado:
        //
        // 1. mö wa ni onigbọwọ lati wa ni> 0, nitorinaa ṣe deede, 1 wulo nigbagbogbo.
        //
        // 2.
        // `len + align - 1` le ṣan nipasẹ pupọ julọ `align - 1`, nitorinaa&-mask pẹlu `!(align - 1)` yoo rii daju pe ninu ọran ṣiṣanju, `len_rounded_up` yoo funrararẹ jẹ 0.
        //
        //    Nitorinaa paadi ti o pada, nigbati o ba ṣafikun si `len`, n ṣe ikore 0, eyiti o jẹ itẹlọrun ni itẹlọrun titete `align`.
        //
        // (Nitoribẹẹ, awọn igbiyanju lati fi ipinfunni awọn ohun amorindun silẹ eyiti iwọn wọn ati fifẹ fifo ni ọna ti o wa loke yẹ ki o fa ki ipin naa fun ni aṣiṣe lọnakọna.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Ṣẹda ipilẹṣẹ kan nipa yiyi iwọn ti ipilẹṣẹ yii pọ si ọpọ ti titete titọ.
    ///
    ///
    /// Eyi jẹ deede lati ṣafikun abajade ti `padding_needed_for` si iwọn lọwọlọwọ ti ifilelẹ.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Eyi ko le ṣan.Idiyele lati ko baramu ti Layout:
        // > `size`, Nigbati o ba yika to ọpọ ti o sunmọ ti `align`,
        // > ko gbọdọ ṣan omi (ie, iye iyipo gbọdọ jẹ kere ju
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Ṣẹda ipilẹ ti o n ṣalaye igbasilẹ fun awọn iṣẹlẹ `n` ti `self`, pẹlu iye ti o yẹ fun fifẹ laarin ọkọọkan lati rii daju pe apeere kọọkan ni a fun ni iwọn ti o beere ati titete.
    /// Lori aṣeyọri, pada `(k, offs)` nibi ti `k` jẹ ipilẹ ti ọna-ọna ati `offs` ni aaye laarin ibẹrẹ ti eroja kọọkan ninu ọna-ọna.
    ///
    /// Lori apọnju iṣiro, pada `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Eyi ko le ṣan.Idiyele lati ko baramu ti Layout:
        // > `size`, Nigbati o ba yika to ọpọ ti o sunmọ ti `align`,
        // > ko gbọdọ ṣan omi (ie, iye iyipo gbọdọ jẹ kere ju
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // Aabo: self.align ti wa ni tẹlẹ mo lati wa ni wulo ati alloc_size ti
        // fifẹ tẹlẹ.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Ṣẹda ipilẹ ti o n ṣalaye igbasilẹ fun `self` ti o tẹle pẹlu `next`, pẹlu eyikeyi fifẹ pataki lati rii daju pe `next` yoo wa ni deede to dara, ṣugbọn *ko si fifẹ wiwa atẹle*.
    ///
    /// Lati baamu ipilẹṣẹ aṣoju C C `repr(C)`, o yẹ ki o pe `pad_to_align` lẹhin ti o faagun iṣeto pẹlu gbogbo awọn aaye.
    /// (Ko si ọna lati baamu aiyipada aṣoju aṣoju Rust akọkọ `repr(Rust)`, as it is unspecified.)
    ///
    /// Akiyesi pe titete ti ipilẹṣẹ abajade yoo jẹ o pọju ti awọn ti `self` ati `next`, lati rii daju titete awọn ẹya mejeeji.
    ///
    /// Awọn ipadabọ `Ok((k, offset))`, nibiti `k` jẹ ipilẹ ti igbasilẹ ti a ṣe pọ ati `offset` jẹ ipo ibatan, ni awọn baiti, ti ibẹrẹ ti `next` ti a fi sii laarin igbasilẹ igbasilẹ (ni imọran pe igbasilẹ naa funrararẹ bẹrẹ ni aiṣedeede 0).
    ///
    ///
    /// Lori apọnju iṣiro, pada `LayoutError`.
    ///
    /// # Examples
    ///
    /// Lati ṣe iṣiro ifilelẹ ti eto `#[repr(C)]` kan ati awọn aiṣedede ti awọn aaye lati awọn ipilẹ awọn aaye rẹ:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ranti lati pari pẹlu `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // idanwo pe o n ṣiṣẹ
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Ṣẹda ifilelẹ ti o ṣe apejuwe igbasilẹ fun awọn iṣẹlẹ `n` ti `self`, laisi fifẹ laarin apẹẹrẹ kọọkan.
    ///
    /// Akiyesi pe, laisi `repeat`, `repeat_packed` ko ṣe onigbọwọ pe awọn iṣẹlẹ ti a tun ṣe ti `self` yoo wa ni deedee, paapaa ti apeere ti a fun ni `self` ba deede.
    /// Ni awọn ọrọ miiran, ti a ba lo ipilẹ ti o pada nipasẹ `repeat_packed` lati pin ipin kan, ko ṣe idaniloju pe gbogbo awọn eroja inu ila naa yoo wa ni deede.
    ///
    /// Lori apọnju iṣiro, pada `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Ṣẹda apẹrẹ ti o ṣe apejuwe igbasilẹ fun `self` atẹle nipa `next` laisi afikun fifẹ laarin awọn meji.
    /// Niwọn igba ti a ko fi sii fifẹ, titete ti `next` ko ṣe pataki, ati pe ko ṣafikun *rara* sinu apẹrẹ abajade.
    ///
    ///
    /// Lori apọnju iṣiro, pada `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Ṣẹda apẹrẹ ti o ṣe apejuwe igbasilẹ fun `[T; n]` kan.
    ///
    /// Lori apọnju iṣiro, pada `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Awọn aye ti a fun si `Layout::from_size_align` tabi ọmọle `Layout` miiran ko ni itẹlọrun awọn idiwọ akọsilẹ rẹ.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (a nilo eyi fun iwadii isalẹ ti aṣiṣe trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}