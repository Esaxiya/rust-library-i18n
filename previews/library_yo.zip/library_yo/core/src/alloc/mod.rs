//! Awọn ipin ipin iranti

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Aṣiṣe `AllocError` tọka ikuna ipin ti o le jẹ nitori irẹwẹsi orisun tabi si nkan ti ko tọ nigbati o ba n dapọ awọn ariyanjiyan titẹsi ti a fun pẹlu ipin yii.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (a nilo eyi fun iwadii isalẹ ti aṣiṣe trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Imuse ti `Allocator` le pin, dagba, dinku, ati pin ipin awọn bulọọki lainidii ti data ti a ṣalaye nipasẹ [`Layout`][].
///
/// `Allocator` ti ṣe apẹrẹ lati ṣe imuse lori awọn ZST, awọn itọkasi, tabi awọn itọka ọlọgbọn nitori nini ipin kan bii `MyAlloc([u8; N])` ko le gbe, laisi mimu awọn itọka si iranti ti a pin.
///
/// Kii [`GlobalAlloc`][], awọn ipin titobi odo jẹ laaye ni `Allocator`.
/// Ti o ba ti ohun amuye allocator ko ni atilẹyin yi (bi jemalloc) tabi pada a asan ijuboluwole (bi `libc::malloc`), eyi gbọdọ ni ao dalejo ni nipasẹ awọn imuse.
///
/// ### Lọwọlọwọ soto iranti
///
/// Diẹ ninu awọn ọna naa nilo pe ki a fi ipin iranti kan *silẹ lọwọlọwọ* nipasẹ olupilẹṣẹ.Eyi tumọ si pe:
///
/// * adirẹsi ti o bẹrẹ fun bulọọki iranti yẹn ni iṣaaju pada nipasẹ [`allocate`], [`grow`], tabi [`shrink`], ati
///
/// * bulọọki iranti ko ti pin ni atẹle, nibiti awọn bulọọki boya pin ni taara nipasẹ gbigbe si [`deallocate`] tabi yipada nipasẹ gbigbe si [`grow`] tabi [`shrink`] ti o pada `Ok`.
///
/// Ti o ba ti `grow` tabi `shrink` ti pada `Err`, awọn kọja ijuboluwole si maa wa wulo.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Memory ibamu
///
/// Diẹ ninu awọn ti awọn ọna beere pe a akọkọ *fit* a iranti Àkọsílẹ.
/// Ohun ti o tumo si fun a akọkọ to "fit" a iranti Àkọsílẹ ọna (tabi equivalently, fun iranti Àkọsílẹ to "fit" a akọkọ) ni wipe awọn wọnyi ipo gbọdọ mu:
///
/// * Awọn Àkọsílẹ gbọdọ wa ni soto pẹlu kanna rege bi [`layout.align()`], ati
///
/// * [`layout.size()`] ti a pese gbọdọ ṣubu ni ibiti o wa ni `min ..= max`, nibiti:
///   - `min` ni awọn iwọn ti awọn ifilelẹ julọ laipe lo lati allocate awọn Àkọsílẹ, ati
///   - `max` jẹ iwọn gangan tuntun ti a pada lati [`allocate`], [`grow`], tabi [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Awọn ohun amorindun ti a pada lati ọdọ oluṣeto gbọdọ tọka si iranti ti o wulo ati idaduro iduroṣinṣin wọn titi apeere ati gbogbo awọn ere ibeji rẹ yoo lọ silẹ,
///
/// * cloning tabi gbigbe oluṣeto ko gbọdọ sọ awọn bulọọki iranti di asan lati ọdọ olupilẹṣẹ yii.Olupilẹṣẹ cloned kan gbọdọ huwa bi olupilẹṣẹ kanna, ati
///
/// * eyikeyi ijuboluwole si iranti Àkọsílẹ ti o jẹ [*currently allocated*] le wa ni koja si eyikeyi miiran ọna ti awọn allocator.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Igbiyanju lati allocate kan Àkọsílẹ ti iranti.
    ///
    /// Lori aṣeyọri, pada ipade [`NonNull<[u8]>`][NonNull] kan iwọn ati awọn iṣeduro isọdọkan ti `layout`.
    ///
    /// Àkọsílẹ ti a da pada le ni iwọn ti o tobi ju ti a sọ nipa `layout.size()`, ati pe o le tabi ko le jẹ ki awọn akoonu rẹ ti bẹrẹ.
    ///
    /// # Errors
    ///
    /// Pada `Err` tọkasi wipe boya iranti jẹ re tabi `layout` ko ni pade allocator ká iwọn tabi titete inira.
    ///
    /// A ṣe iwuri fun awọn imuṣẹ lati pada `Err` lori irẹwẹsi iranti kuku ju ijaya tabi iṣẹyun, ṣugbọn eyi kii ṣe ibeere ti o muna.
    /// (Ni pataki: o jẹ *ofin* lati ṣe imuse trait yii ni oke ile-ikawe ipin abinibi ti o jẹ abẹrẹ lori imukuro iranti.)
    ///
    /// Ibara edun okan lati abort iṣiro ni esi si ohun ipin aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Iwa bi `allocate`, ṣugbọn tun ṣe idaniloju pe iranti ti o pada jẹ ipilẹṣẹ odo.
    ///
    /// # Errors
    ///
    /// Pada `Err` tọkasi wipe boya iranti jẹ re tabi `layout` ko ni pade allocator ká iwọn tabi titete inira.
    ///
    /// A ṣe iwuri fun awọn imuṣẹ lati pada `Err` lori irẹwẹsi iranti kuku ju ijaya tabi iṣẹyun, ṣugbọn eyi kii ṣe ibeere ti o muna.
    /// (Ni pataki: o jẹ *ofin* lati ṣe imuse trait yii ni oke ile-ikawe ipin abinibi ti o jẹ abẹrẹ lori imukuro iranti.)
    ///
    /// Ibara edun okan lati abort iṣiro ni esi si ohun ipin aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // Aabo: `alloc` pada iwe-iranti iranti to wulo
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Ṣiṣẹ awọn iranti tọka nipasẹ `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` gbọdọ tọka bulọọki ti iranti [*currently allocated*] nipasẹ olupilẹṣẹ yii, ati
    /// * `layout` gbọdọ [*fit*] ti o Àkọsílẹ ti iranti.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Igbiyanju lati fa iranti Àkọsílẹ.
    ///
    /// Pada [`NonNull<[u8]>`][NonNull] tuntun kan ti o ni ijuboluwole ati iwọn gangan ti iranti ti a pin.Atọka naa jẹ o dara fun dani data ti a ṣàpèjúwe nipasẹ `new_layout`.
    /// Lati ṣe eyi, oluṣeto le fa ipin ti a tọka si nipasẹ `ptr` lati ba ipele akọkọ naa mu.
    ///
    /// Ti o ba ti yi pada `Ok`, ki o si nini ti awọn iranti Àkọsílẹ rannileti nipa `ptr` ti a ti gbe lọ si yi allocator.
    /// Iranti naa le tabi ko ti ni ominira, ati pe o yẹ ki a ṣe akiyesi ailagbara ayafi ti o ba ti gbe pada si olupe naa lẹẹkansi nipasẹ iye ipadabọ ti ọna yii.
    ///
    /// Ti o ba ti yi ọna pada `Err`, ki o si nini ti awọn iranti Àkọsílẹ ti ko ti gbe si yi allocator, ati awọn awọn akoonu ti ti iranti Àkọsílẹ ti wa ni unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` gbọdọ tọka bulọọki iranti [*currently allocated*] nipasẹ olupilẹṣẹ yii.
    /// * `old_layout` gbọdọ [*fit*] ti o Àkọsílẹ ti iranti (The `new_layout` ariyanjiyan nilo ko bamu o.).
    /// * `new_layout.size()` gbọdọ tobi ju tabi dogba si `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Pada `Err` ti ipilẹṣẹ tuntun ko ba pade iwọn oluṣeto ati awọn ihamọ titọ ti olupilẹṣẹ, tabi ti idagbasoke bibẹkọ ti kuna.
    ///
    /// A ṣe iwuri fun awọn imuṣẹ lati pada `Err` lori irẹwẹsi iranti kuku ju ijaya tabi iṣẹyun, ṣugbọn eyi kii ṣe ibeere ti o muna.
    /// (Ni pataki: o jẹ *ofin* lati ṣe imuse trait yii ni oke ile-ikawe ipin abinibi ti o jẹ abẹrẹ lori imukuro iranti.)
    ///
    /// Ibara edun okan lati abort iṣiro ni esi si ohun ipin aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // Aabo: nitori `new_layout.size()` gbọdọ jẹ tobi ju tabi dogba si
        // `old_layout.size()`, ipin atijọ ati tuntun ti iranti jẹ wulo fun awọn kika ati kikọ fun awọn baiti `old_layout.size()`.
        // Pẹlupẹlu, nitori ipin atijọ ko tii pin ni ipin, ko le ṣe atunṣe `new_ptr`.
        // Nitorinaa, ipe si `copy_nonoverlapping` jẹ ailewu.
        // Adehun aabo fun `dealloc` gbọdọ jẹ atilẹyin nipasẹ olupe naa.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ihuwasi bii `grow`, ṣugbọn tun ṣe idaniloju pe awọn akoonu titun ti ṣeto si odo ṣaaju ki o to pada.
    ///
    /// Iranti Àkọsílẹ yoo ni awọn wọnyi ni awọn akoonu ti kan lẹhin aseyori ipe to
    /// `grow_zeroed`:
    ///   * Awọn baiti `0..old_layout.size()` ti wa ni ipamọ lati ipin akọkọ.
    ///   * Awọn baiti `old_layout.size()..old_size` yoo jẹ ki o wa ni fipamọ tabi ti ko niro, ti o da lori imuse ipin.
    ///   `old_size` n tọka si iwọn ti ohun amorindun iranti ṣaaju si ipe `grow_zeroed`, eyiti o le tobi ju iwọn ti a ti kọkọ beere nigbati o ti pin.
    ///   * Bytes `old_size..new_size` ti wa ni zeroed.`new_size` ntokasi si awọn iwọn ti awọn iranti Àkọsílẹ pada nipa awọn `grow_zeroed` ipe.
    ///
    /// # Safety
    ///
    /// * `ptr` gbọdọ tọka bulọọki iranti [*currently allocated*] nipasẹ olupilẹṣẹ yii.
    /// * `old_layout` gbọdọ [*fit*] ti o Àkọsílẹ ti iranti (The `new_layout` ariyanjiyan nilo ko bamu o.).
    /// * `new_layout.size()` gbọdọ tobi ju tabi dogba si `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Pada `Err` ti ipilẹṣẹ tuntun ko ba pade iwọn oluṣeto ati awọn ihamọ titọ ti olupilẹṣẹ, tabi ti idagbasoke bibẹkọ ti kuna.
    ///
    /// A ṣe iwuri fun awọn imuṣẹ lati pada `Err` lori irẹwẹsi iranti kuku ju ijaya tabi iṣẹyun, ṣugbọn eyi kii ṣe ibeere ti o muna.
    /// (Ni pataki: o jẹ *ofin* lati ṣe imuse trait yii ni oke ile-ikawe ipin abinibi ti o jẹ abẹrẹ lori imukuro iranti.)
    ///
    /// Ibara edun okan lati abort iṣiro ni esi si ohun ipin aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // Aabo: nitori `new_layout.size()` gbọdọ jẹ tobi ju tabi dogba si
        // `old_layout.size()`, ipin atijọ ati tuntun ti iranti jẹ wulo fun awọn kika ati kikọ fun awọn baiti `old_layout.size()`.
        // Pẹlupẹlu, nitori ipin atijọ ko tii pin ni ipin, ko le ṣe atunṣe `new_ptr`.
        // Nitorinaa, ipe si `copy_nonoverlapping` jẹ ailewu.
        // Adehun aabo fun `dealloc` gbọdọ jẹ atilẹyin nipasẹ olupe naa.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Awọn igbiyanju lati dinku apo iranti.
    ///
    /// Pada [`NonNull<[u8]>`][NonNull] tuntun kan ti o ni ijuboluwole ati iwọn gangan ti iranti ti a pin.Atọka naa jẹ o dara fun dani data ti a ṣàpèjúwe nipasẹ `new_layout`.
    /// Lati ṣe eyi, oluṣeto le dinku ipin ti a tọka si nipasẹ `ptr` lati ba ipele akọkọ naa mu.
    ///
    /// Ti o ba ti yi pada `Ok`, ki o si nini ti awọn iranti Àkọsílẹ rannileti nipa `ptr` ti a ti gbe lọ si yi allocator.
    /// Iranti naa le tabi ko ti ni ominira, ati pe o yẹ ki a ṣe akiyesi ailagbara ayafi ti o ba ti gbe pada si olupe naa lẹẹkansi nipasẹ iye ipadabọ ti ọna yii.
    ///
    /// Ti o ba ti yi ọna pada `Err`, ki o si nini ti awọn iranti Àkọsílẹ ti ko ti gbe si yi allocator, ati awọn awọn akoonu ti ti iranti Àkọsílẹ ti wa ni unaltered.
    ///
    /// # Safety
    ///
    /// * `ptr` gbọdọ tọka bulọọki iranti [*currently allocated*] nipasẹ olupilẹṣẹ yii.
    /// * `old_layout` gbọdọ [*fit*] ti o Àkọsílẹ ti iranti (The `new_layout` ariyanjiyan nilo ko bamu o.).
    /// * `new_layout.size()` gbọdọ jẹ kere ju tabi dogba si `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Pada `Err` ti o ba ti titun akọkọ ko ni pade awọn allocator ká iwọn ati ki o titete inira ti awọn allocator, tabi ti o ba sunki bibẹkọ ti kuna.
    ///
    /// A ṣe iwuri fun awọn imuṣẹ lati pada `Err` lori irẹwẹsi iranti kuku ju ijaya tabi iṣẹyun, ṣugbọn eyi kii ṣe ibeere ti o muna.
    /// (Ni pataki: o jẹ *ofin* lati ṣe imuse trait yii ni oke ile-ikawe ipin abinibi ti o jẹ abẹrẹ lori imukuro iranti.)
    ///
    /// Ibara edun okan lati abort iṣiro ni esi si ohun ipin aṣiṣe ti wa ni iwuri lati pe awọn [`handle_alloc_error`] iṣẹ, dipo ju taara invoking `panic!` tabi iru.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // Aabo: nitori `new_layout.size()` gbọdọ jẹ kekere ju tabi dogba si
        // `old_layout.size()`, ipin atijọ ati tuntun ti iranti jẹ wulo fun awọn kika ati kikọ fun awọn baiti `new_layout.size()`.
        // Pẹlupẹlu, nitori ipin atijọ ko tii pin ni ipin, ko le ṣe atunṣe `new_ptr`.
        // Nitorinaa, ipe si `copy_nonoverlapping` jẹ ailewu.
        // Adehun aabo fun `dealloc` gbọdọ jẹ atilẹyin nipasẹ olupe naa.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ṣẹda ohun ti nmu badọgba "by reference" fun apẹẹrẹ ti `Allocator`.
    ///
    /// Awọn pada ti nmu badọgba tun alailewu `Allocator` ati ki o yoo nìkan yá yi.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // Aabo: aabo guide gbọdọ wa ni ọwọ si nipa awọn olupe
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Aabo: aabo guide gbọdọ wa ni ọwọ si nipa awọn olupe
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Aabo: aabo guide gbọdọ wa ni ọwọ si nipa awọn olupe
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Aabo: aabo guide gbọdọ wa ni ọwọ si nipa awọn olupe
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}