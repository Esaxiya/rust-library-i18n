//! Iṣẹ-ṣiṣe fun paṣẹ ati lafiwe.
//!
//! Atokun yii ni awọn irinṣẹ pupọ fun paṣẹ ati afiwe awọn iye.Ni soki:
//!
//! * [`Eq`] ati [`PartialEq`] jẹ traits ti o fun ọ laaye lati ṣalaye lapapọ ati isọdọkan apakan laarin awọn iye, lẹsẹsẹ.
//! Ṣiṣe wọn apọju awọn oṣiṣẹ `==` ati `!=`.
//! * [`Ord`] ati [`PartialOrd`] jẹ traits ti o gba ọ laaye lati ṣalaye lapapọ ati aṣẹ ti apakan laarin awọn iye, lẹsẹsẹ.
//!
//! Ṣiṣe wọn apọju awọn `<`, `<=`, `>`, ati awọn oniṣẹ `>=`.
//! * [`Ordering`] jẹ enum ti a pada nipasẹ awọn iṣẹ akọkọ ti [`Ord`] ati [`PartialOrd`], ati ṣe apejuwe aṣẹ kan.
//! * [`Reverse`] jẹ ipilẹ ti o fun laaye laaye lati yiyi aṣẹ pada ni irọrun.
//! * [`max`] ati [`min`] ni o wa awọn iṣẹ ti Kọ pipa ti [`Ord`] ati ki o gba o lati ri awọn ti o pọju tabi kere ti meji iye.
//!
//! Fun awọn alaye diẹ sii, wo awọn iwe aṣẹ oniwun ti ohun kọọkan ninu atokọ.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait fun Equality afiwera eyi ti o wa [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Eleyi trait laaye fun apa kan Equality, fun orisi ti ko ni kan ni kikun ṣe deede relation.
/// Fun apẹẹrẹ, ni lilefoofo ojuami awọn nọmba `NaN != NaN`, ki lilefoofo ojuami orisi se `PartialEq` sugbon ko [`trait@Eq`].
///
/// Formally, awọn Equality gbọdọ jẹ (fun gbogbo `a`, `b`, `c` ti Iru `A`, `B`, `C`):
///
/// - **to dogba**: ti o ba `A: PartialEq<B>` ati `B: PartialEq<A>`, ki o si **`a==b` tumo si`b==a`**;ati
///
/// - **Transitive**: ti o ba `A: PartialEq<B>` ati `B: PartialEq<C>` ati `A:
///   ApakanEq<C>', Ki o si **`a==b` ati `b == c` tumo si`a==c`**.
///
/// Akiyesi pe awọn igbewọle `B: PartialEq<A>` (symmetric) ati `A: PartialEq<C>` (transitive) ko fi agbara mu lati wa tẹlẹ, ṣugbọn awọn ibeere wọnyi lo nigbakugba ti wọn ba wa tẹlẹ.
///
/// ## Derivable
///
/// trait yii le ṣee lo pẹlu `#[derive]`.Nigba ti `derive`d on structs, meji instances wa ni dogba ti o ba ti gbogbo awọn aaye ni o wa dogba, ati ki o ko dogba o ba ti eyikeyi oko ni o wa ko dogba.Nigbati `ba gba lori awọn enum, iyatọ kọọkan jẹ dọgba si ara rẹ ati pe ko dọgba pẹlu awọn iyatọ miiran.
///
/// ## Bawo ni mo ti se `PartialEq`?
///
/// `PartialEq` nikan nbeere [`eq`] ọna lati muse;[`ne`] ti ṣalaye ni awọn ofin rẹ nipasẹ aiyipada.Eyikeyi Afowoyi imuse ti [`ne`]*gbọdọ* fi owo fun awọn ofin ti [`eq`] ni kan ti o muna onidakeji ti [`ne`];iyẹn, `!(a == b)` ti o ba jẹ pe nikan `a != b`.
///
/// Imuṣẹ ti `PartialEq`, [`PartialOrd`], ati [`Ord`]*gbọdọ* gba pẹlu kọọkan miiran.O rorun lati lairotẹlẹ ṣe wọn koo nipa awon idalekun ti diẹ ninu awọn ti traits ati ọwọ imulo miran.
///
/// Apeere apẹẹrẹ fun agbegbe kan ninu eyiti a ka awọn iwe meji ni iwe kanna ti wọn ba baamu ISBN, paapaa ti awọn ọna kika yatọ:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Bawo ni MO ṣe le ṣe afiwe awọn oriṣi oriṣi meji?
///
/// Iru ti o le fiwera pẹlu rẹ ni iṣakoso nipasẹ paramita iru `PartialEq`.
/// Fun apẹẹrẹ, jẹ ki ká tweak wa tẹlẹ koodu a bit:
///
/// ```
/// // Awọn ohun elo itọsẹ<BookFormat>==<BookFormat>afiwera
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Ṣiṣe<Book>==<BookFormat>awọn afiwera
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Ṣiṣe<BookFormat>==<Book>afiwera
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Nipa yiyipada `impl PartialEq for Book` si `impl PartialEq<BookFormat> for Book`, a gba `BookFormat` lati fiwera pẹlu`Book`s.
///
/// A lafiwe bi awọn ọkan loke, eyi ti kọ diẹ ninu awọn aaye ti awọn struct, le jẹ lewu.O le awọn iṣọrọ ja si ohun unintended ṣẹ ti awọn ibeere fun a apa kan ṣe deede relation.
/// Fun apẹẹrẹ, ti a ba pa imuse ti `PartialEq<Book>` ti o wa loke fun `BookFormat` sii ti a fi kun imuse ti `PartialEq<Book>` fun `Book` (boya nipasẹ `#[derive]` tabi nipasẹ imuse itọnisọna ni apẹẹrẹ akọkọ) lẹhinna abajade yoo ṣẹ transitivity:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Awọn ọna yii ṣe idanwo fun awọn iye `self` ati `other` lati dọgba, ati pe o lo nipasẹ `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Yi ọna ti igbeyewo fun `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Gba macro ṣiṣẹda impl kan ti trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait fun awọn afiwe afijọgba eyiti o jẹ [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Yi ọna, ti ni afikun si `a == b` ati `a != b` jije ti o muna inverses, awọn Equality gbọdọ jẹ (fun gbogbo `a`, `b` ati `c`):
///
/// - reflexive: `a == a`;
/// - isedogba: `a == b` tumọ si `b == a`;ati
/// - transitive: `a == b` ati `b == c` tumọ si `a == c`.
///
/// A ko le ṣayẹwo ohun-ini yii nipasẹ akopọ, nitorinaa `Eq` tumọ si [`PartialEq`], ko si ni awọn ọna afikun.
///
/// ## Derivable
///
/// trait yii le ṣee lo pẹlu `#[derive]`.
/// Nigba ti `derive`d, nitori `Eq` ni o ni ko si afikun awọn ọna, o ti wa ni nikan siso ni alakojo wipe yi jẹ ẹya ṣe deede relation kuku ju a apa kan ṣe deede relation.
///
/// Akiyesi pe ilana `derive` nilo gbogbo awọn aaye ni `Eq`, eyiti ko fẹ nigbagbogbo.
///
/// ## Bawo ni MO ṣe le ṣe `Eq`?
///
/// Ti o ba ti o ko ba le lo awọn `derive` nwon.Mirza, pato pe rẹ iru ọlọnà `Eq`, eyi ti o ni o ni ko ọna:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ọna yii ni a lo nikan nipasẹ#[fifun ni] lati fi idi rẹ mulẹ pe gbogbo paati iru kan n ṣe imuse#[fifun ni] funrararẹ, awọn amayederun ti n wọle lọwọlọwọ tumọ si ṣe idaniloju yii laisi lilo ọna kan lori trait yii jẹ eyiti ko ṣeeṣe.
    //
    //
    // Eyi ko yẹ ki o ṣe imuse nipasẹ ọwọ.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Gba macro ṣiṣẹda impl kan ti trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: yi struct ti lo daada nipa#[nianfani] to
// ṣe idaniloju pe gbogbo paati ti iru awọn imuse kan Eq.
//
// Eleyi struct yẹ ki o ko han ninu olumulo koodu.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` jẹ abajade ti lafiwe laarin awọn iye meji.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Bibere kan nibiti iye ti akawe kan kere ju omiiran lọ.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Bibere nibiti iye ti a fiwewe dọgba si omiiran.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// An bere fun ibi ti a akawe iye ni ti o tobi ju miiran.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Pada `true` ti o ba ti bere fun ni awọn `Equal` iyatọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Pada `true` ti aṣẹ ko ba jẹ iyatọ `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Pada `true` ti o ba ti bere fun ni awọn `Less` iyatọ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Pada `true` ti aṣẹ ba jẹ iyatọ `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Pada `true` ti aṣẹ ba jẹ boya iyatọ `Less` tabi `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Pada `true` ti aṣẹ ba jẹ boya iyatọ `Greater` tabi `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Yiyipada `Ordering` pada.
    ///
    /// * `Less` di `Greater`.
    /// * `Greater` di `Less`.
    /// * `Equal` di `Equal`.
    ///
    /// # Examples
    ///
    /// Ipilẹ ihuwasi:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Ọna yii le ṣee lo lati yiyipada afiwe kan:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // to awọn orun lati titobi julọ si kere.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Awọn ẹwọn bibere meji.
    ///
    /// Padà `self` nigba ti o ni ko `Equal`.Bibẹkọ ti pada `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Awọn ẹwọn bibere pẹlu iṣẹ ti a fifun.
    ///
    /// Padà `self` nigba ti o ni ko `Equal`.
    /// Bibẹkọ ti pe `f` ati da abajade pada.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Ẹkọ oluranlọwọ fun tito aṣẹ yiyipada.
///
/// Eleyi struct ni a oluranlọwọ to ṣee lo pẹlu awọn iṣẹ bi [`Vec::sort_by_key`] ati ki o le wa ni lo lati ẹnjinia ibere apa kan a bọtini.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait fun awọn oriṣi ti o dagba [total order](https://en.wikipedia.org/wiki/Total_order) kan.
///
/// Ibere jẹ aṣẹ lapapọ ti o ba jẹ (fun gbogbo `a`, `b` ati `c`):
///
/// - lapapọ ati aibaramu: deede ọkan ninu `a < b`, `a == b` tabi `a > b` jẹ otitọ;ati
/// - transitive, `a < b` ati `b < c` tumọ si `a < c`.Kanna gbọdọ mu fun `==` ati `>` mejeeji.
///
/// ## Derivable
///
/// trait yii le ṣee lo pẹlu `#[derive]`.
/// Nigbati `ba gba lori awọn iwulo, yoo ṣe agbekalẹ aṣẹ [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) kan ti o da lori aṣẹ ikede lati oke de isalẹ ti awọn ọmọ ẹgbẹ iṣeto.
///
/// Nigbati `ba gba lori awọn enum, awọn iyatọ ni aṣẹ nipasẹ aṣẹ iyasoto ti oke-de-isalẹ.
///
/// ## Ifiwera iwe iroyin
///
/// Lexicographical lafiwe jẹ ẹya isẹ pẹlu awọn wọnyi-ini:
///  - Ọkọọkan meji ti wa ni akawe ano nipa ano.
///  - Ẹya aiṣedeede akọkọ ṣalaye iru itẹlera ti o kere ju lilu lilẹ ti tabi tobi ju ekeji lọ.
///  - Ti o ba ti ọkan ọkọọkan jẹ a ìpele ti awọn miran, awọn kikuru ọkọọkan jẹ lexicographically kere ju awọn miiran.
///  - Ti itẹlera meji ba ni awọn eroja ti o jẹ deede ti wọn si ni gigun kanna, lẹhinna awọn atẹlera naa jẹ dogba iwe-ọrọ.
///  - Ọkọọkan ofo jẹ lexicographically kere si ọkọọkan eyikeyi ti ko ṣofo.
///  - Awọn ọna ṣiṣe ofo meji jẹ dogba ikan-dogba.
///
/// ## Bawo ni MO ṣe le ṣe `Ord`?
///
/// `Ord` nbeere wipe awọn iru tun jẹ [`PartialOrd`] ati [`Eq`] (eyi ti nbeere [`PartialEq`]).
///
/// Ki o si o gbọdọ setumo ohun imuse fun [`cmp`].O le rii pe o wulo lati lo [`cmp`] lori awọn aaye iru rẹ.
///
/// Imuṣẹ ti [`PartialEq`], [`PartialOrd`], ati `Ord`*gbọdọ* gba pẹlu kọọkan miiran.
/// Iyẹn ni, `a.cmp(b) == Ordering::Equal` ti o ba jẹ pe nikan ti `a == b` ati `Some(a.cmp(b)) == a.partial_cmp(b)` fun gbogbo `a` ati `b`.
/// O rọrun lati jẹ ki wọn lairotẹlẹ jẹ ki wọn ko gba nipa gbigba diẹ ninu awọn ti traits ati pẹlu imuse ọwọ pẹlu awọn miiran.
///
/// Eyi ni àpẹẹrẹ ibi ti o fẹ lati to awọn eniyan nipa iga nikan, disregarding `id` ati `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Ọna yii pada [`Ordering`] kan laarin `self` ati `other`.
    ///
    /// Nipa Adehun, `self.cmp(&other)` pada awọn bere tuntun tó awọn ikosile `self <operator> other` ti o ba ti otitọ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Safiwe ati ki o pada awọn ti o pọju ti awọn meji iye.
    ///
    /// Pada ariyanjiyan keji ti ifiwera ba pinnu wọn lati dọgba.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Ṣe afiwe ati dapada iye ti awọn iye meji.
    ///
    /// Pada akọkọ ariyanjiyan ti o ba ti lafiwe ipinnu wọn lati wa ni dogba.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Ni ihamọ iye kan si aarin igba kan.
    ///
    /// Pada `max` ti `self` ba tobi ju `max`, ati `min` ti `self` ba kere si `min`.
    /// Bibẹkọ ti yi pada `self`.
    ///
    /// # Panics
    ///
    /// Panics ti o ba ti `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Gba macro ṣiṣẹda impl kan ti trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait fun iye ti o le wa akawe fun a too-ibere.
///
/// Awọn lafiwe gbọdọ ni itẹlọrun, fun gbogbo `a`, `b` ati `c`:
///
/// - asymmetry: ti o ba `a < b` ki o si `!(a > b)`, bi daradara bi `a > b` gégè `!(a < b)`;ati
/// - transitivity: `a < b` ati `b < c` tumo si `a < c`.Kanna gbọdọ mu fun `==` ati `>`.
///
/// Akọsilẹ wipe awon ibeere tunmọ si wipe awọn trait ara gbọdọ wa ni muse symmetrically ati transitively: ti o ba `T: PartialOrd<U>` ati `U: PartialOrd<V>` ki o si `U: PartialOrd<T>` ati `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Eleyi trait le ṣee lo pẹlu `#[derive]`.Nigbati `ba gba lori awọn ikọsẹ, yoo ṣe agbekalẹ aṣẹ-aṣẹ lexicographic kan ti o da lori aṣẹ ikede lati-de-isalẹ ti awọn ọmọ ẹgbẹ iṣeto.
/// Nigbati `ba gba lori awọn enum, awọn iyatọ ni aṣẹ nipasẹ aṣẹ iyasoto ti oke-de-isalẹ.
///
/// ## Bawo ni MO ṣe le ṣe `PartialOrd`?
///
/// `PartialOrd` nikan nilo imuse ti ọna [`partial_cmp`], pẹlu awọn miiran ti ipilẹṣẹ lati awọn imuse aiyipada.
///
/// Sibẹsibẹ o ṣee ṣe lati ṣe imuse awọn miiran lọtọ fun awọn iru eyiti ko ni aṣẹ lapapọ.
/// Fun apẹẹrẹ, fun awọn nọmba ojuami lilefoofo, `NaN < 0 == false` ati `NaN >= 0 == false` (cf.
/// IEEE 754-2008 apakan 5.11).
///
/// `PartialOrd` nilo iru rẹ lati jẹ [`PartialEq`].
///
/// Imuṣẹ ti [`PartialEq`], `PartialOrd`, ati [`Ord`]*gbọdọ* gba pẹlu kọọkan miiran.
/// O rọrun lati jẹ ki wọn lairotẹlẹ jẹ ki wọn ko gba nipa gbigba diẹ ninu awọn ti traits ati pẹlu imuse ọwọ pẹlu awọn miiran.
///
/// Ti iru rẹ ba jẹ [`Ord`], o le ṣe [`partial_cmp`] nipa lilo [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// O tun le rii pe o wulo lati lo [`partial_cmp`] lori awọn aaye iru rẹ.
/// Eyi ni àpẹẹrẹ ti `Person` orisi ti o ni a lilefoofo-ojuami `height` aaye ti o jẹ nikan ni aaye lati lo fun ayokuro:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Yi ọna ti pada ohun bere laarin `self` ati `other` iye ti o ba ti ọkan wa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Nigbati afiwe ko ṣee ṣe:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Yi ọna ti igbeyewo kere ju (fun `self` ati `other`) ati ti lo nipasẹ awọn `<` onišẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Yi ọna ti igbeyewo kere ju tabi dogba si (fun `self` ati `other`) ati ti lo nipasẹ awọn `<=` onišẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Ọna yii ṣe idanwo tobi ju (fun `self` ati `other`) ati pe o lo nipasẹ oniṣẹ `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Yi ọna ti igbeyewo tobi ju tabi dogba si (fun `self` ati `other`) ati ti lo nipasẹ awọn `>=` onišẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Gba macro ṣiṣẹda impl kan ti trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Ṣe afiwe ati dapada iye ti awọn iye meji.
///
/// Pada akọkọ ariyanjiyan ti o ba ti lafiwe ipinnu wọn lati wa ni dogba.
///
/// Fipa nlo ohun inagijẹ to [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Pada iye ti o kere julọ fun awọn iye meji pẹlu ọwọ si iṣẹ afiwe ti a ṣalaye.
///
/// Pada akọkọ ariyanjiyan ti o ba ti lafiwe ipinnu wọn lati wa ni dogba.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Pada ano ti o fun ni iye ti o kere julọ lati iṣẹ ti a ṣalaye.
///
/// Pada akọkọ ariyanjiyan ti o ba ti lafiwe ipinnu wọn lati wa ni dogba.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Safiwe ati ki o pada awọn ti o pọju ti awọn meji iye.
///
/// Pada ariyanjiyan keji ti ifiwera ba pinnu wọn lati dọgba.
///
/// Ti abẹnu nlo inagijẹ si [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Pada iwọn ti awọn iye meji pọ pẹlu ọwọ si iṣẹ akawe ti a ṣalaye.
///
/// Pada ariyanjiyan keji ti ifiwera ba pinnu wọn lati dọgba.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Padà ni ano ti yoo fun awọn ti o pọju iye lati pàtó kan iṣẹ.
///
/// Pada ariyanjiyan keji ti ifiwera ba pinnu wọn lati dọgba.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Imuse ti PartialEq, Hi Kiu, PartialOrd ati OLUWA si fun atijo orisi
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // Ibere nibi jẹ pataki lati ṣe ina apejọ ti o dara julọ diẹ sii.
                    // Wo <https://github.com/rust-lang/rust/issues/63758> fun diẹ info.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // Simẹnti to i8 ká ati ni jijere awọn iyato si ohun ibere gbogbo diẹ ti aipe ijọ.
            //
            // Wo <https://github.com/rust-lang/rust/issues/66780> fun diẹ info.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // Aabo: bool bi i8 pada 0 tabi 1, ki awọn iyato ko le wa ni ohunkohun miiran
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &ifẹnule

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}