//! Eleyi jẹ ohun ti abẹnu module lo nipasẹ awọn ifmt!isise.Awọn wọnyi ni ẹya ti wa ni emitted to aimi imole to precompile kika gbolohun niwaju ti akoko.
//!
//! Awọn wọnyi ni itumo wa ni iru si wọn `ct` equivalents, sugbon yato ni wipe awọn wọnyi le wa ni statically soto si ti wa ni die-die iṣapeye fun awọn asiko isise
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Awọn atunto ti o le ṣee beere bi apakan ti itọsọna kika kan.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Itọkasi pe awọn akoonu yẹ ki o wa ni apa osi.
    Left,
    /// Itọkasi wipe awọn akoonu ti yẹ ki o wa ọtun-deedee.
    Right,
    /// Itọkasi pe awọn akoonu yẹ ki o wa ni aarin.
    Center,
    /// Ko si titete ti a beere.
    Unknown,
}

/// Lo nipa [width](https://doc.rust-lang.org/std/fmt/#width) ati [precision](https://doc.rust-lang.org/std/fmt/#precision) specifiers.
#[derive(Copy, Clone)]
pub enum Count {
    /// Pàtó kan pẹlu kan gegebi nọmba, tọjú awọn iye
    Is(usize),
    /// Pàtó kan nipa lilo `$` ati `*` syntaxes, tọjú awọn Ìwé sinu `args`
    Param(usize),
    /// Lai so ni pato
    Implied,
}