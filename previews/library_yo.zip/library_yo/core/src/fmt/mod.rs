//! Igbesi fun piparẹ ati ki o sita awọn gbolohun ọrọ.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// Owun to le alignments pada nipa `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Itọkasi pe awọn akoonu yẹ ki o wa ni apa osi.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Itọkasi wipe awọn akoonu ti yẹ ki o wa ọtun-deedee.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// Itọkasi pe awọn akoonu yẹ ki o wa ni aarin.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// Awọn iru pada nipa formatter ọna.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// Awọn aṣiṣe iru eyi ti o ti pada lati ba npa akoonu rẹ a ifiranṣẹ sinu kan san.
///
/// Yi iru ko ni atilẹyin gbigbe ti ohun aṣiṣe miiran ju ti ohun aṣiṣe lodo wa.
/// Eyikeyi afikun alaye gbọdọ wa ni idayatọ to wa ni zqwq nipasẹ diẹ ninu awọn miiran ọna.
///
/// Ohun pataki ohun lati ranti ni wipe ni iru `fmt::Error` ko yẹ ki o wa ni dapo pelu [`std::io::Error`] tabi [`std::error::Error`], eyi ti o le tun ni ni dopin.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// A trait fun kikọ tabi akoonu sinu Unicode-gba buffers tabi ṣiṣan.
///
/// Eleyi trait nikan gbà UTF-8-ti yipada data ati ki o jẹ ko [flushable].
/// Ti o ba ti o ba nikan fẹ lati gba Unicode ati awọn ti o se ko nilo flushing, o yẹ ki se yi trait;
/// bibẹkọ ti o yẹ ki o ṣe [`std::io::Write`].
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// Kọ nkan gige kan sinu onkọwe yii, pada boya kikọ naa ṣaṣeyọri.
    ///
    /// Yi ọna ti le nikan se aseyori ti o ba ti gbogbo okun bibẹ ti a ti ni ifijišẹ kọ, ati yi ọna ti yoo ko pada titi gbogbo data ti a ti kọ tabi ti ẹya ašiše waye.
    ///
    ///
    /// # Errors
    ///
    /// Iṣẹ yi yoo pada ohun apeere ti [`Error`] on aṣiṣe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// Levin a [`char`] sinu yi onkqwe, pada boya awọn Kọ tele.
    ///
    /// [`char`] kan ṣoṣo le ti yipada bi baiti ti o ju ọkan lọ.
    /// Yi ọna ti le nikan se aseyori ti o ba ti gbogbo baiti ọkọọkan ti a ti ni ifijišẹ kọ, ati yi ọna ti yoo ko pada titi gbogbo data ti a ti kọ tabi ti ẹya ašiše waye.
    ///
    ///
    /// # Errors
    ///
    /// Iṣẹ yi yoo pada ohun apeere ti [`Error`] on aṣiṣe.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// Lẹ pọ fun lilo ti awọn [`write!`] Makiro pẹlu implementors ti yi trait.
    ///
    /// Ọna yii ko yẹ ki a pe ni ọwọ, ṣugbọn kuku nipasẹ macro [`write!`] funrararẹ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// Iṣeto ni fun kika.
///
/// A `Formatter` duro orisirisi awọn aṣayan jẹmọ si npa akoonu rẹ.
/// Awọn olumulo ko kọ `Formatter`s taara;a mutable tọka si ọkan ti wa ni kọja si awọn `fmt` ọna ti gbogbo npa akoonu traits, bi [`Debug`] ati [`Display`].
///
///
/// Lati se nlo pẹlu a `Formatter`, o yoo pe orisirisi ọna lati yi awọn orisirisi awọn aṣayan jẹmọ si npa akoonu rẹ.
/// Fun apeere, jọwọ wo awọn iwe ti awọn ọna telẹ on `Formatter` ni isalẹ.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// Ariyanjiyan jẹ ẹya pataki iṣapeye sile loo ba npa akoonu rẹ iṣẹ, deede to `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result`.

extern "C" {
    type Opaque;
}

/// Eleyi struct duro awọn jeneriki "argument" eyi ti o ti ya nipasẹ awọn Xprintf ebi ti awọn iṣẹ.O ni iṣẹ kan to ọna kika fun iye.
/// Ni akoko sakojo o ti rii daju pe iṣẹ ati iye ni awọn oriṣi to pe, ati lẹhinna eto yii ni a lo lati ṣe ifọkanbalẹ awọn ariyanjiyan si oriṣi kan.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// Eyi ṣe onigbọwọ iye iduroṣinṣin kan fun itọka iṣẹ ti o ni nkan ṣe pẹlu indices/counts ninu awọn amayederun kika.
//
// Akiyesi pe iṣẹ kan ti a ṣalaye bi eleyi ko ni jẹ deede bi awọn iṣẹ ṣe tag nigbagbogbo unnamed_addr pẹlu fifalẹ lọwọlọwọ si LLVM IR, nitorinaa adirẹsi wọn ko ṣe pataki si LLVM ati pe bii iru as_usize simẹnti le ti jẹ aṣiṣe.
//
// Ni asa, a ko pe as_usize on ti kii-usize ti o ni awọn data (bi ọrọ kan ti aimi iran ti awọn akoonu rẹ ariyanjiyan), ki ni yi jo ohun afikun ayẹwo.
//
// A nipataki fẹ lati rii daju wipe awọn iṣẹ ijuboluwole ni `USIZE_MARKER` ni o ni ohun adirẹsi ti o baamu *nikan* to awọn iṣẹ ti tun gba `&usize` bi wọn akọkọ ariyanjiyan.
// Awọn read_volatile nibi idaniloju wipe a le kuro lailewu setan jade a usize lati kọja itọkasi ati awọn ti o yi adirẹsi ko ojuami ni a ti kii-usize gba iṣẹ.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // Aabo: ptr jẹ itọkasi kan
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // Aabo: `mem::transmute(x)` jẹ ailewu nitori
        //     1. `&'b T` tọju igbesi aye ti o bẹrẹ pẹlu `'b` (lati ma ni igbesi aye ti ko ni opin)
        //     2.
        //     `&'b T` ati `&'b Opaque` ni kanna iranti akọkọ (nigbati `T` ni `Sized`, bi o ti jẹ nibi) `mem::transmute(f)` jẹ ailewu niwon `fn(&T, &mut Formatter<'_>) -> Result` ati `fn(&Opaque, &mut Formatter<'_>) -> Result` ni kanna Abi (bi gun bi `T` ni `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // Aabo: Awọn `formatter` oko ti wa ni nikan ṣeto si USIZE_MARKER ti o ba ti
            // iye jẹ a usize, ki yi jẹ ailewu
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// awọn asia ti o wa ni ọna kika v1 ti format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// Nigba lilo format_args! () Macro, iṣẹ yii ni a lo lati ṣe agbekalẹ eto ariyanjiyan.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// Iṣẹ yi ti lo lati tokasi nonstandard npa akoonu sile.
    /// Ọna `pieces` gbọdọ jẹ o kere ju bi `fmt` lati ṣe agbekalẹ eto Awọn ariyanjiyan.
    /// Pẹlupẹlu, eyikeyi `Count` laarin `fmt` ti o jẹ `CountIsParam` tabi `CountIsNextParam` ni lati tọka si ariyanjiyan ti a ṣẹda pẹlu `argumentusize`.
    ///
    /// Sibẹsibẹ, aise lati ṣe bẹ ko fa unsafety, sugbon yoo foju invalid.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// Siro awọn ipari ti awọn akoonu ọrọ.
    ///
    /// Eleyi ni a ti pinnu lati wa ni lo fun eto ni ibẹrẹ `String` agbara nigba lilo `format!`.
    /// Note: yi ni bẹni isalẹ tabi oke dè.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // Ti okun ọna kika ba bẹrẹ pẹlu ariyanjiyan, maṣe ṣaju ohunkohun, ayafi ti ipari awọn ege jẹ pataki.
            //
            //
            0
        } else {
            // Nibẹ ni o wa diẹ ninu awọn ariyanjiyan, ki eyikeyi afikun titari yoo reallocate awọn okun.
            //
            // Lati yago fun iyẹn, a jẹ "pre-doubling" agbara nibi.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// Ẹya yii n ṣe aṣoju ẹya ti a ti kọ tẹlẹ lailewu ti okun kika ati awọn ariyanjiyan rẹ.
/// Eyi ko le ṣe ipilẹṣẹ ni asiko asiko nitori ko le ṣe lailewu, nitorinaa a ko fun awọn akọle ati awọn aaye naa jẹ ikọkọ lati yago fun iyipada.
///
///
/// The [`format_args!`] Makiro yoo lailewu ṣẹda ohun apeere ti yi be.
/// Awọn Makiro validates awọn kika okun ni sakojo-akoko ki lilo ti awọn [`write()`] ati [`format()`] awọn iṣẹ le wa ni kuro lailewu ṣe.
///
/// O le lo awọn `Arguments<'a>` ti [`format_args!`] pada ni `Debug` ati `Display` àrà bi ri ni isalẹ.
/// Apẹẹrẹ tun fihan pe ọna kika `Debug` ati `Display` si ohun kanna: okun kika kika interpolated ni `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // Kika okun ona lati tẹ sita.
    pieces: &'a [&'static str],

    // Placeholder lẹkunrẹrẹ, tabi `None` ti o ba ti gbogbo awọn alaye lẹkunrẹrẹ wa ni aiyipada (bi ni "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // Ìmúdàgba ariyanjiyan fun interpolation, lati wa ni interleaved pẹlu okun ege.
    // (Gbogbo ariyanjiyan ti wa ni bere nipa a okun nkan.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// Gba awọn akoonu okun, ti o ba ni ko si ariyanjiyan lati wa ni akoonu.
    ///
    /// Eyi le ṣee lo lati yago fun awọn ipin ninu ọran ti ko ṣe pataki julọ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` yẹ ki o ọna kika awọn ti o wu ni a komputa-ti nkọju si, ṣatunṣe o tọ.
///
/// Gbogbo soro, o yẹ kan `derive` a `Debug` imuse.
///
/// Nigba ti lo pẹlu awọn maili kika specifier `#?`, awọn o wu ti wa ni lẹwa-tejede.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// trait yii le ṣee lo pẹlu `#[derive]` ti gbogbo awọn aaye ba ṣe `Debug`.
/// Nigbati `ba gba fun awọn iwulo, yoo lo orukọ ti `struct`, lẹhinna `{`, lẹhinna atokọ ti o yapa koma ti orukọ aaye kọọkan ati iye `Debug`, lẹhinna `}`.
/// Fun `enum`s, yoo lo orukọ iyatọ ati pe, ti o ba wulo, `(`, lẹhinna awọn iye `Debug` ti awọn aaye naa, lẹhinna `)`.
///
/// # Stability
///
/// Ti ari `Debug` ọna kika wa ni ko idurosinsin, ati ki o le yi pẹlu future Rust awọn ẹya.
/// Ni afikun, awọn imuṣẹ `Debug` ti awọn oriṣi ti a pese nipasẹ ile-ikawe boṣewa (`libstd`, `libcore`, `liballoc`, ati bẹbẹ lọ) ko jẹ iduroṣinṣin, ati pe o tun le yipada pẹlu awọn ẹya future Rust.
///
///
/// # Examples
///
/// Awon idalekun ti ohun imuse:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Ṣiṣe ọwọ pẹlu ọwọ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// Nibẹ ni o wa nọmba kan ti oluranlọwọ ọna lori [`Formatter`] struct lati ran o pẹlu Afowoyi imuṣẹ, gẹgẹ bi awọn [`debug_struct`].
///
/// `Debug` imuṣẹ lilo boya `derive` tabi awọn yokokoro Akole API on [`Formatter`] support lẹwa-sita nipa lilo awọn maili Flag: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// Pretty-titẹ sita pẹlu `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// Kika iye lilo awọn fun formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// Modulu lọtọ lati tun gbe makiro `Debug` wọle lati prelude laisi trait `Debug`.
pub(crate) mod macros {
    /// Nianfani Makiro ti o npese ohun impl ti awọn trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// Kika trait fun ọna kika ofo, `{}`.
///
/// `Display` jọra si [`Debug`], ṣugbọn `Display` jẹ fun iṣelọpọ ti nkọju si olumulo, ati nitorinaa ko le ni ariwo.
///
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Imulo `Display` on a Iru:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// Kika iye lilo awọn fun formatter.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// The `Octal` trait yẹ kika awọn oniwe-wu bi a nọmba ninu base-8.
///
/// Fun atijo wole odidi (`i8` to `i128`, ati `isize`), odi iye ti wa ni akoonu bi awọn meji ká iranlowo oniduro.
///
///
/// Awọn maili flag, `#`, afikun kan `0o` ni iwaju ti o wu.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Ipilẹ lilo pẹlu `i32`:
///
/// ```
/// let x = 42; // 42 jẹ '52' ni octal
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// Imulo `Octal` on a Iru:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // ṣe aṣoju si imuse i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// Kika iye lilo awọn fun formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// The `Binary` trait yẹ kika awọn oniwe-wu bi a nọmba ninu alakomeji.
///
/// Fun atijo wole odidi ([`i8`] to [`i128`], ati [`isize`]), odi iye ti wa ni akoonu bi awọn meji ká iranlowo oniduro.
///
///
/// Awọn maili flag, `#`, afikun kan `0b` ni iwaju ti o wu.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Ipilẹ lilo pẹlu [`i32`]:
///
/// ```
/// let x = 42; // 42 jẹ '101010' ni alakomeji
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// Imulo `Binary` on a Iru:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // ṣe aṣoju si imuse i32
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// Kika iye lilo awọn fun formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait yẹ ki o ṣe agbejade iṣelọpọ rẹ bi nọmba ninu hexadecimal, pẹlu `a` nipasẹ `f` ninu ọrọ kekere.
///
/// Fun atijo wole odidi (`i8` to `i128`, ati `isize`), odi iye ti wa ni akoonu bi awọn meji ká iranlowo oniduro.
///
///
/// Flag miiran, `#`, ṣe afikun `0x` ni iwaju iṣẹjade.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Ipilẹ lilo pẹlu `i32`:
///
/// ```
/// let x = 42; // 42 jẹ '2a' ni hex
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// Imulo `LowerHex` on a Iru:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // ṣe aṣoju si imuse i32
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// Kika iye lilo awọn fun formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait yẹ ki o ṣe agbejade iṣelọpọ rẹ bi nọmba ninu hexadecimal, pẹlu `A` nipasẹ `F` ninu ọrọ oke.
///
/// Fun atijo wole odidi (`i8` to `i128`, ati `isize`), odi iye ti wa ni akoonu bi awọn meji ká iranlowo oniduro.
///
///
/// Flag miiran, `#`, ṣe afikun `0x` ni iwaju iṣẹjade.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Ipilẹ lilo pẹlu `i32`:
///
/// ```
/// let x = 42; // 42 jẹ '2A' ni hex
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// Ṣiṣe `UpperHex` lori oriṣi kan:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // ṣe aṣoju si imuse i32
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// Kika iye lilo awọn fun formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// The `Pointer` trait yẹ kika awọn oniwe-wu bi a iranti ipo.
/// Yi ti ni commonly gbekalẹ bi hexadecimal.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Lilo ipilẹ pẹlu `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // eyi n ṣe nkan bi '0x7f06092ac6d0'
/// ```
///
/// Imulo `Pointer` on a Iru:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // lilo `as` to lọkan padà to a `*const T`, eyi ti alailewu ijuboluwole, eyi ti a le lo
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// Kika iye lilo awọn fun formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// The `LowerExp` trait yẹ kika awọn oniwe-wu ni ijinle sayensi amiakosile pẹlu kan kekere-nla `e`.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Ipilẹ lilo pẹlu `f64`:
///
/// ```
/// let x = 42.0; // 42.0 ni '4.2e1' ni ijinle sayensi amiakosile
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// Ṣiṣe `LowerExp` lori oriṣi kan:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // Egypt to f64 ká imuse
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// Kika iye lilo awọn fun formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// The `UpperExp` trait yẹ kika awọn oniwe-wu ni ijinle sayensi amiakosile pẹlu ohun oke-nla `E`.
///
/// Fun alaye siwaju sii lori formatters, wo [the module-level documentation][module].
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// Ipilẹ lilo pẹlu `f64`:
///
/// ```
/// let x = 42.0; // 42.0 jẹ '4.2E1' ni akọsilẹ imọ-jinlẹ
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// Ṣiṣe `UpperExp` lori oriṣi kan:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // Egypt to f64 ká imuse
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// Kika iye lilo awọn fun formatter.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// The `write` iṣẹ gba ohun o wu san, ati awọn ẹya `Arguments` struct ti o le wa precompiled pẹlu awọn `format_args!` Makiro.
///
///
/// Awọn ariyanjiyan yoo wa ni akoonu ni ibamu si awọn pàtó kan kika okun sinu wu san pese.
///
/// # Examples
///
/// Ipilẹ lilo:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// Jọwọ se akiyesi pe lilo [`write!`] le jẹ preferable.Apẹẹrẹ:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // A le lo awọn aye kika kika aiyipada fun gbogbo awọn ariyanjiyan.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // Gbogbo alaye ni ariyanjiyan ti o baamu eyiti o ṣaju nipasẹ nkan okun.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // Aabo: arg ati args.args wa lati Awọn ariyanjiyan kanna,
                // eyi ti o ṣe onigbọwọ awọn atọka o wa nigbagbogbo laarin igboro.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // Nibẹ le je nikan kan trailing okun nkan kù.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // Aabo: arg ati args wa lati Awọn ariyanjiyan kanna,
    // eyi ti o ṣe onigbọwọ awọn atọka o wa nigbagbogbo laarin igboro.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // Jade awọn ti o tọ ariyanjiyan
    debug_assert!(arg.position < args.len());
    // Aabo: arg ati args wa lati Awọn ariyanjiyan kanna,
    // eyi ti o ṣe onigbọwọ awọn oniwe-Ìwé jẹ nigbagbogbo laarin igboro.
    let value = unsafe { args.get_unchecked(arg.position) };

    // Lẹhinna ṣe diẹ titẹ
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // Aabo: CNT ati args wá lati kanna ariyanjiyan,
            // eyi ti o ṣe onigbọwọ yi Ìwé jẹ nigbagbogbo laarin igboro.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// We lẹhin opin nkankan.Pada nipa `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// Kọ yi post òwú.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // A fẹ lati yi eyi
            buf: wrap(self.buf),

            // Ati tọju awọn wọnyi
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // Awọn ọna Oluranlọwọ ti a lo fun fifẹ ati sisọ awọn ariyanjiyan kika ti gbogbo kika traits le lo.
    //

    /// Ṣe fifẹ ti o pe fun odidi odidi eyiti o ti jade tẹlẹ sinu str kan.
    /// Awọn str yẹ *ko* ni awọn ami fun awọn odidi, ti yoo wa ni fi kun nipa ọna yi.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, boya odidi atilẹba jẹ boya o jẹ odi tabi odo.
    /// * ìpele, ti o ba ti '#' ti ohun kikọ silẹ (Alternate) ti pese, yi ni ìpele lati fi ni iwaju ti awọn nọmba.
    ///
    /// * buf, awọn baiti orun ti awọn nọmba ti a ti akoonu sinu
    ///
    /// Iṣẹ yii yoo ṣe deede fun awọn asia ti a pese gẹgẹbi iwọn to kere julọ.
    /// O yoo ko gba konge sinu iroyin.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // A nilo lati yọ "-" lati awọn nọmba wu.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // Levin awọn ami ti o ba wa, ati ki o si awọn ìpele ti o ba ti o ti beere
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // Aaye `width` jẹ diẹ sii ti paramita `min-width` ni aaye yii.
        match self.width {
            // Ti ko ba si awọn ibeere gigun to kere ju lẹhinna a le kọ awọn baiti kan.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Ṣayẹwo ti o ba ti a ba lori awọn kere iwọn, ti o ba ki o si a tun le kan kọ awọn baiti.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // Awọn ami ati ìpele lọ niwaju awọn òwú ti o ba ti yó ohun kikọ silẹ ni odo
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // Bibẹkọkọ, ami ati ìpele naa n lọ lẹhin fifẹ
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Iṣẹ yi gba a okun bibẹ ati ipele ti o si awọn ti abẹnu saarin lẹhin a to awọn ti o yẹ akoonu rẹ asia pato.
    /// Awọn awọn asia mọ fun jeneriki awọn gbolohun ọrọ ni o wa:
    ///
    /// * iwọn, awọn kere iwọn ti ohun ti emit
    /// * fill/align - ohun to emit ati ibi ti lati emit ti o ba ti ni okun pese aini lati wa ni fifẹ
    /// * konge, ipari ti o pọ julọ lati jade, okun ti wa ni gige ti o ba gun ju gigun yii lọ
    ///
    /// Ni pataki iṣẹ yii kọ awọn ipilẹ `flag`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // Rii daju nibẹ ni a yara ona soke iwaju
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // The `precision` aaye le ti wa ni tumo bi a `max-width` fun awọn okun ni akoonu.
        //
        let s = if let Some(max) = self.precision {
            // Ti okun wa ba gun ju pe o jẹ deede, lẹhinna a gbọdọ ni idinku.
            // Sibẹsibẹ miiran awọn asia bi `fill`, `width` ati `align` gbodo sise bi nigbagbogbo.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM nibi ko le fi mule pe `..i` kì yio panic `&s[..i]`, ṣugbọn awa mọ pe o le ko panic.
                // Lo `get` + `unwrap_or` lati yago fun `unsafe` ki o si bibẹkọ ti ko ba emit eyikeyi panic-jẹmọ awọn koodu nibi.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // Aaye `width` jẹ diẹ sii ti paramita `min-width` ni aaye yii.
        match self.width {
            // Ti o ba ti a ba labẹ awọn ti o pọju gigun, ati nibẹ ni ko si kere ipari awọn ibeere, ki o si a le o kan emit awọn okun
            //
            None => self.buf.write_str(s),
            // Ti o ba ti a ba labẹ awọn ti o pọju iwọn, ṣayẹwo ti o ba ti a ba lori awọn kere iwọn, ti o ba ki o bi rorun bi o kan emitting awọn okun.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // Ti o ba ti a ba labẹ awọn mejeeji ni o pọju ati awọn kere iwọn, ki o si kún soke awọn kere iwọn pẹlu awọn pàtó kan okun + diẹ ninu awọn titete.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// Kọ ami-fifẹ-tẹlẹ ki o pada si fifẹ ifiweranṣẹ ti a ko kọ.
    /// Awọn olupe ni iduro fun idaniloju pe a ti kọ padding ifiweranṣẹ lẹhin nkan ti o wa ni fifẹ.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// Gba awọn ẹya ti a ṣe pa akoonu ati lilo fifẹ naa.
    /// Ṣebi pe olupe ti sọ tẹlẹ awọn ẹya pẹlu iṣedede ti o nilo, ki `self.precision` le foju.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // fun fifẹ odo ti o mọ-ami, a mu ami naa wa akọkọ ki a huwa bi ẹni pe a ko ni ami kankan lati ibẹrẹ.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // a ami nigbagbogbo lọ akọkọ
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // yọ awọn ami lati awọn akoonu awọn ẹya ara
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // ti o ku awọn ẹya lọ nipasẹ awọn arinrin òwú ilana.
            let len = formatted.len();
            let ret = if width <= len {
                // ko si òwú
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // yi ni wọpọ nla ati awọn ti a ya a abuja
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // Aabo: Eyi ni a lo fun `flt2dec::Part::Num` ati `flt2dec::Part::Copy`.
            // O ni ailewu lati lo fun `flt2dec::Part::Num` niwon gbogbo shaha `c` ni laarin `b'0'` ati `b'9'`, eyi ti o tumo `s` jẹ wulo UTF-8.
            // O ni tun jasi ailewu ni asa lati lo fun `flt2dec::Part::Copy(buf)` niwon `buf` yẹ ki o wa itele ti ASCII, sugbon o ni ṣee ṣe fun ẹnikan lati ṣe ni a buburu iye fun `buf` sinu `flt2dec::to_shortest_str` niwon o jẹ kan àkọsílẹ iṣẹ.
            //
            // FIXME: Mo boya yi le ja si ni UB.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 zeroes
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// Kọ diẹ ninu data si ifipamọ ipilẹ ti o wa laarin ọna kika yii.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // Eleyi jẹ deede si:
    ///         // Kọ! (formatter, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// Kọ diẹ ninu alaye ti a ṣe kika sinu apẹẹrẹ yii.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// Awọn asia fun piparẹ
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// Ti ohun kikọ silẹ lo bi 'fill' nigbakugba ti o wa ni titete.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // Ti a ṣeto titete si apa ọtun pẹlu ">".
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// Flag ti o nfihan iru irisi titete ti a beere.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Iwọn odidi odidi ti a yan ni pàtó pe ṣiṣe yẹ ki o jẹ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // Ti a ba ti gba a iwọn, a lo o
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // Tabi ki a ṣe ohun pataki
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// Optionally pàtó kan konge fun nomba omiran.
    /// Tabi, ni o pọju iwọn fun okun omiran.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // Ti a ba ti gba a konge, a lo o.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // Bibẹkọ ti a aiyipada si 2.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// Pinnu ti o ba ti ṣalaye Flag `+`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// Awọn ipinnu ti o ba ti ṣalaye Flag `-`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // Ṣe o fẹ ami iyokuro kan?Ni ọkan!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// Awọn ipinnu ti o ba ti ṣalaye Flag `#`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// Awọn ipinnu ti o ba ti ṣalaye Flag `0`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // A foju awọn formatter ká aṣayan.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: Pinnu iru API ti gbogbo eniyan ti a fẹ fun awọn asia meji wọnyi.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// Ṣẹda akọle [`DebugStruct`] ti a ṣe apẹrẹ lati ṣe iranlọwọ pẹlu ẹda ti awọn imuṣẹ [`fmt::Debug`] fun awọn idiwọn.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// Ṣẹda a `DebugTuple` Akole še lati ran pẹlu ẹda ti `fmt::Debug` imuṣẹ fun tuple structs.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// Ṣẹda a `DebugList` Akole še lati ran pẹlu ẹda ti `fmt::Debug` imuṣẹ fun akojọ-bi ẹya.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// Ṣẹda a `DebugSet` Akole še lati ran pẹlu ẹda ti `fmt::Debug` imuṣẹ fun ṣeto-bi ẹya.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// Ni yi eka sii apẹẹrẹ, a lo [`format_args!`] ati `.debug_set()` lati kọ akojọ kan ti baramu apá:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// Ṣẹda a `DebugMap` Akole še lati ran pẹlu ẹda ti `fmt::Debug` imuṣẹ fun map-bi ẹya.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// Awọn imuse ti kika kika traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // Ti o ba ti shaha aini escaping, danu backlog ki jina ati ki o Kọ, miran Rekọja
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // Flag miiran ti ni itọju tẹlẹ nipasẹ LowerHex bi pataki-o tọka boya lati ṣaju pẹlu 0x.
        // A lo o lati sise jade boya tabi ko si odo fa, ati ki o nitõtọ ṣeto ti o si gba awọn ìpele.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// Imuse ti Display/Debug fun awọn oriṣiriṣi oriṣi oriṣi

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell ti ya adaṣe mutably nitorina a ko le wo iye rẹ nibi.
                // Fi kan placeholder dipo.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// Ti o ba ṣe yẹ igbeyewo lati wa ni nibi, wo dipo ni core/tests/fmt.rs faili, o ni a Pupo rọrun ju ṣiṣẹda gbogbo awọn ti awọn rt::Piece ẹya nibi.
//
// Nibẹ ni o wa tun igbeyewo ninu awọn alloc crate, fun awon ti o nilo Allocations.