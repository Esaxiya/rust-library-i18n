use crate::iter::FromIterator;

/// Collapses gbogbo kuro awọn ohun lati ẹya iterator sinu ọkan.
///
/// Eleyi jẹ diẹ wulo nigba ti ni idapo pelu ti o ga-ipele abstractions, bi gba to a `Result<(), E>` ibi ti o ti nikan bikita nipa aṣiṣe:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}