//! Ṣe alaye asọye ohun-ini ti `IntoIter` fun awọn ipilẹ.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Atunṣe [array] iye-iye.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Yi ni orun ti a ti wa iterating lori.
    ///
    /// Awọn ohun elo pẹlu atọka `i` nibiti `alive.start <= i < alive.end` ko ti ni ikore sibẹsibẹ ati pe o jẹ awọn titẹ sii orun to wulo.
    /// Awọn eroja pẹlu awọn atọka `i < alive.start` tabi `i >= alive.end` ti ni ikore tẹlẹ ati pe ko gbọdọ wọle si mọ!Awon okú eroja le paapaa wa ni a patapata uninitialized ipinle!
    ///
    ///
    /// Nitorinaa awọn alailera ni:
    /// - `data[alive]` wa laaye (ie ni awọn eroja to wulo)
    /// - `data[..alive.start]` ati `data[alive.end..]` kú (ie awọn eroja won tẹlẹ ka ati ko gbodo wa ni ọwọ mọ!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Awọn eroja inu `data` ti ko ti ni ikore sibẹsibẹ.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Ṣẹda aṣetunṣe tuntun lori `array` ti a fun.
    ///
    /// *Akiyesi*: ọna yii le jẹ ibajẹ ni future, lẹhin [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Awọn iru ti `value` ni a `i32` nibi, dipo ti `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // Aabo: Awọn transmute nibi ni kosi ailewu.Awọn docs ti `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` jẹ ẹri lati ni iwọn kanna ati titete
        // > bi `T`.
        //
        // Awọn docs paapaa ṣe afihan transmute kan lati oriṣi `MaybeUninit<T>` si oriṣi ti `T`.
        //
        //
        // Pẹlu iyẹn, ipilẹṣẹ yii ni itẹlọrun awọn alailera.

        // FIXME(LukasKalbertodt): kosi lo `mem::transmute` nibi, ni kete ti o ba ṣiṣẹ pẹlu awọn Jiini apọju:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Titi di igba naa, a le lo `mem::transmute_copy` lati ṣẹda ẹda bitwise bii oriṣi oriṣiriṣi, lẹhinna gbagbe `array` ki o ma fi silẹ.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Pada ohun aileyipada bibẹ pẹlẹbẹ ti gbogbo awọn eroja ti ko ti a yielded sibẹsibẹ.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // Aabo: A mọ pe gbogbo awọn eroja laarin `alive` ti wa ni ipilẹṣẹ daradara.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Pada nkan ti o le yipada ti gbogbo awọn eroja ti ko ti ni ikore sibẹsibẹ.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // Aabo: A mọ pe gbogbo awọn eroja laarin `alive` ti wa ni ipilẹṣẹ daradara.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Gba atọka atẹle lati iwaju.
        //
        // Alekun `alive.start` nipasẹ 1 ṣetọju ailopin nipa `alive`.
        // Sibẹsibẹ, nitori lati yi ayipada, fun igba diẹ, awọn láàyè ibi ni ko `data[alive]` mọ, ṣugbọn `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Ka ano lati orun.
            // Aabo: `idx` jẹ itọka si agbegbe "alive" atijọ ti
            // orun.Kika eroja yii tumọ si pe a ka `data[idx]` si okú bayi (ie maṣe fi ọwọ kan).
            // Bii `idx` ti jẹ ibẹrẹ ti agbegbe laaye, agbegbe laaye ti wa ni `data[alive]` bayi, tun pada sipo gbogbo awọn alailera.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Gba awọn tókàn Ìwé lati pada.
        //
        // Idinku `alive.end` nipasẹ 1 ṣetọju ailopin nipa `alive`.
        // Sibẹsibẹ, nitori iyipada yii, fun igba diẹ, agbegbe laaye ko ni `data[alive]` mọ, ṣugbọn `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Ka ano lati orun.
            // Aabo: `idx` jẹ itọka si agbegbe "alive" atijọ ti
            // orun.Kika eroja yii tumọ si pe a ka `data[idx]` si okú bayi (ie maṣe fi ọwọ kan).
            // Bii `idx` ti jẹ opin ti agbegbe laaye, agbegbe laaye ti wa ni `data[alive]` bayi, tun pada sipo gbogbo awọn alailera.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // Aabo: Eleyi jẹ ailewu: `as_mut_slice` pada gangan ni iha-bibẹ
        // ti eroja ti ko ti a ti gbe jade sibẹsibẹ ati awọn ti o wa lati wa ni silẹ.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Yoo ko ṣan silẹ nitori ailopin `laaye. Bẹrẹ <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Olutọju nitootọ ṣe ijabọ ipari ti o tọ.
// Nọmba awọn eroja "alive" (ti yoo tun jẹ ikore) ni ipari ti ibiti `alive` wa.
// Iwọn yii dinku ni ipari ni boya `next` tabi `next_back`.
// 1 nigbagbogbo dinku nipasẹ awọn ọna wọnyẹn, ṣugbọn ti o ba pada `Some(_)` nikan.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Akiyesi, a ko nilo gaan lati ba iru iwọn laaye laaye kanna, nitorinaa a le ṣe ẹda oniye sinu aiṣedeede 0 laibikita ibiti `self` wa.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Oniye gbogbo awọn eroja laaye.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Kọ ẹda oniye kan sinu ọna tuntun, lẹhinna ṣe imudojuiwọn ibiti o wa laaye.
            // Ti o ba jẹ cloning panics, a yoo ju awọn ohun ti tẹlẹ silẹ daradara.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ṣe atẹjade awọn eroja nikan ti a ko fun ni agbara sibẹsibẹ: a ko le wọle si awọn eroja ti a fun ni mọ.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}