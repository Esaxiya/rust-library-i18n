//! The `Clone` trait fun orisi ti ko le wa ni 'implicitly dakọ'.
//!
//! Ni Rust, diẹ ninu awọn oriṣi ti o rọrun jẹ "implicitly copyable" ati nigbati o ba fi wọn si tabi kọja wọn bi awọn ariyanjiyan, olugba yoo gba ẹda kan, ti o fi iye atilẹba silẹ ni aye.
//! Awon orisi ko beere ipin lati da ki o si ma ko ni finalizers (ie, won ko ba ko ni ini apoti tabi se [`Drop`]), ki awọn alakojo ka wọn poku ati ailewu lati da.
//!
//! Fun awọn ẹda miiran awọn ẹda gbọdọ ṣee ṣe ni kedere, nipasẹ apejọ ti n ṣe imuse [`Clone`] trait ati pipe ọna [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Apẹẹrẹ lilo ipilẹ:
//!
//! ```
//! let s = String::new(); // Okun iru ọlọnà Clone
//! let copy = s.clone(); // nitorina a le ṣe ẹda oniye rẹ
//! ```
//!
//! Lati awọn iṣọrọ se awọn Clone trait, o tun le lo `#[derive(Clone)]`.Apẹẹrẹ:
//!
//! ```
//! #[derive(Clone)] // a fi awọn Clone trait to Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ati nisisiyi a le ṣe ẹda oniye rẹ!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait ti o wọpọ fun agbara lati ṣe ẹda ẹda kan ni gbangba.
///
/// Yato si lati [`Copy`] ni wipe [`Copy`] ni ifisinu ki o si lalailopinpin ilamẹjọ, nigba ti `Clone` jẹ nigbagbogbo o fojuhan ati ki o le tabi ko le jẹ gbowolori.
/// Lati le mu awọn abuda wọnyi ṣẹ, Rust ko gba ọ laaye lati tun pada [`Copy`], ṣugbọn o le ṣe atunṣe `Clone` ki o ṣe koodu lainidii.
///
/// Niwon `Clone` jẹ diẹ gbogboogbo ju [`Copy`], o le laifọwọyi ṣe ohunkohun [`Copy`] jẹ `Clone` bi daradara.
///
/// ## Derivable
///
/// trait yii le ṣee lo pẹlu `#[derive]` ti gbogbo awọn aaye ba jẹ `Clone`.Imuse `derive`d ti awọn ipe [`Clone`] [`clone`] lori aaye kọọkan.
///
/// [`clone`]: Clone::clone
///
/// Fun kan jeneriki struct, `#[derive]` alailewu `Clone` conditionally nipa fifi dè `Clone` on jeneriki sile.
///
/// ```
/// // `derive` ọlọnà oniye fun Reading<T>nigbati T jẹ Oniye.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Bawo ni MO ṣe le ṣe `Clone`?
///
/// Orisi ti o wa ni [`Copy`] yẹ ki o ni a bintin imuse ti `Clone`.Ni ilọsiwaju diẹ sii:
/// ti `T: Copy`, `x: T`, ati `y: &T`, lẹhinna `let x = y.clone();` jẹ deede si `let x = *y;`.
/// Awọn imuṣẹ afọwọṣe yẹ ki o ṣọra lati gbe opagun yii ga;sibẹsibẹ, lewu koodu ko gbọdọ gbekele lori o lati rii daju iranti ailewu.
///
/// Apẹẹrẹ jẹ ilana jeneriki ti o ni itọka iṣẹ kan.Ni ọran yii, imuse ti `Clone` ko le ṣe `derive`d, ṣugbọn o le ṣe imuse bi:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## afikun implementors
///
/// Ni afikun si [implementors listed below][impls], awọn oriṣi atẹle tun ṣe `Clone`:
///
/// * Iṣẹ kan orisi (ie, awọn pato orisi telẹ fun kọọkan iṣẹ)
/// * Awọn oriṣi ijuboluwole iṣẹ (fun apẹẹrẹ, `fn() -> i32`)
/// * Orun oniru, fun gbogbo awọn titobi, ti o ba awọn ohun kan iru tun alailewu `Clone` (eg, `[i32; 123456]`)
/// * Awọn oriṣi Tuple, ti paati kọọkan ba tun ṣe `Clone` (fun apẹẹrẹ, `()`, `(i32, bool)`)
/// * Awọn iru pipade, ti wọn ko ba gba iye kankan lati ayika tabi ti gbogbo awọn iye ti o gba iru ba n ṣe `Clone` funrara wọn.
///   Akiyesi pe awọn oniyipada ti o gba nipasẹ itọkasi itọkasi nigbagbogbo n ṣe `Clone` (paapaa ti akọwe naa ko ba ṣe), lakoko ti awọn oniye ti o gba nipasẹ itọkasi iyipada ko ṣe imuse `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Pada a daakọ ti awọn iye.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str alailewu oniye
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Ṣe iṣẹ adaṣe lati `source`.
    ///
    /// `a.clone_from(&b)` jẹ deede si `a = b.clone()` ni iṣẹ-ṣiṣe, ṣugbọn o le bori lati tun lo awọn orisun ti `a` lati yago fun awọn ipin ti ko ni dandan.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Gba macro ṣiṣẹda impl kan ti trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): wọnyi structs ti wa ni lilo daada nipa#[nianfani] to sọ pé gbogbo ẹyaapakankan fun a iru ọlọnà Clone tabi daakọ.
//
//
// Awọn ilana wọnyi ko gbọdọ han ninu koodu olumulo.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Awọn imuse ti `Clone` fun awọn oriṣi atijo.
///
/// Imuṣẹ ti ko le sapejuwe ninu Rust ti wa ni muse ni `traits::SelectionContext::copy_clone_conditions()` ni `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Awọn itọkasi pinpin le jẹ ti ẹda oniye, ṣugbọn awọn itọkasi iyipada *ko le*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Awọn itọkasi pinpin le jẹ ti ẹda oniye, ṣugbọn awọn itọkasi iyipada *ko le*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}