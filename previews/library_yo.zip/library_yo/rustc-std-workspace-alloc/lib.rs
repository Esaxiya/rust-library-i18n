#![feature(no_core)]
#![no_core]

// Wo rustc-std-workspace-mojuto fun idi yi crate wa ni ti nilo.

// Lorukọ crate lati yago fun ori gbarawọn pẹlu awọn alloc module ni liballoc.
extern crate alloc as foo;

pub use foo::*;