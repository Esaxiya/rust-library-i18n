use core::marker::PhantomData;
use core::ptr::NonNull;

/// 当您知道某个重新引用及其所有后代 (即从该派生而来的所有指针和引用) 在某个时候不再使用时，对某个唯一引用的重新引用进行建模。
///
///
/// 借位检查器通常为您处理这种借位堆积，但是完成这种堆积的某些控制流程对于编译器而言太复杂了。
/// `DormantMutRef` 允许您检查自己是否借用，同时仍然表示其堆叠性质，并且封装执行此操作所需的原始指针代码而没有未定义的行为。
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// 捕获唯一的借入，然后立即重新借入。
    /// 对于编译器，新引用的生存期与原始引用的生存期相同，但是您 promise 可以将其使用更短的时间。
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // 安全: 我们通过 `_marker` 在整个 'a 处保留借入，并且我们公开
        // 仅此参考，因此它是唯一的。
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// 恢复为最初捕获的唯一借项。
    ///
    /// # Safety
    ///
    /// 重新借用必须已经结束，即，不再可以使用 `new` 返回的引用以及从该引用派生的所有指针和引用。
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // 安全: 我们自己的安全条件暗示此参考文献再次是唯一的。
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;