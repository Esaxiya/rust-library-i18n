//! 为 Miri 展开 panics。
use alloc::boxed::Box;
use core::any::Any;

// Miri 引擎通过展开为我们传播的有效负载类型。
// 必须为指针大小。
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// 由 Miri 提供的外部函数开始展开。
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // 我们传递给 `miri_start_panic` 的有效负载将恰好是我们在下面的 `cleanup` 中获得的参数。
    // 因此，我们只需将其装箱一次，即可得到指针大小的东西。
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // 恢复基础 `Box`。
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}