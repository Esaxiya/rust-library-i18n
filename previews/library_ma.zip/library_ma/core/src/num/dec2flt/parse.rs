//! 验证并分解以下形式的十进制字符串:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! 换句话说，是标准的浮点语法，但有两个例外: 无符号，并且不对 "inf" 和 "NaN" 进行任何处理。这些由驱动程序功能 (super::dec2flt) 处理。
//!
//! 尽管识别有效输入相对容易，但该模块还必须拒绝无数无效变量，从不拒绝 panic，并执行其他模块不依赖于 panic 的大量检查 (或溢出)。
//!
//! 更糟的是，所有这些都在输入上一次完成。
//! 因此，修改任何内容时都要小心，并仔细检查其他模块。
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// 十进制字符串的有趣部分。
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// 十进制指数，保证少于 18 个十进制数字。
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// 检查输入字符串是否为有效的浮点数，如果是，则在其中找到整数部分，小数部分和指数。
/// 不处理标志。
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e' 之前没有数字
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // 在该点之前或之后，我们至少需要一位数字。
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // 小数部分后的尾随垃圾
            }
        }
        _ => Invalid, // 第一个数字字符串后的结尾垃圾
    }
}

/// 分割十进制数字，直到第一个非数字字符。
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// 指数提取和错误检查。
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // 指数后的尾随垃圾
    }
    if number.is_empty() {
        return Invalid; // 空指数
    }
    // 在这一点上，我们当然有一个有效的数字字符串。放入 `i64` 可能太长了，但如果太大，则输入肯定为零或无穷大。
    // 由于十进制数字中的每个零仅将指数调整 +/-1，因此在 exp=10 ^ 18 时，输入必须为 17 exabyte (!) 零，才能几乎接近于有限值。
    //
    // 这不是我们需要迎合的用例。
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}