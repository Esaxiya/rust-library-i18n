//! 本文中的各种算法。

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fp 中的有效位数
const P: u32 = 64;

// 我们仅存储 *all* 指数的最佳近似值，因此可以省略变量 "h" 和相关条件。
// 这将性能换成几千字节的空间。

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// 在大多数体系结构中，浮点运算具有显式的位大小，因此，计算精度取决于每个运算。
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// 在 x86 上，如果 SSE/SSE2 扩展不可用，则将 x87 FPU 用于浮动操作。
// x87 FPU 默认情况下以 80 位精度运行，这意味着运算将舍入到 80 位，从而在最终将值表示为时将发生双舍入
//
// 32/64 位浮点值。为了克服这个问题，可以设置 FPU 控制字，以便以所需的精度执行计算。
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// 一种用于保留 FPU 控制字的原始值的结构，以便在删除该结构时可以将其恢复。
    ///
    ///
    /// x87 FPU 是一个 16 位寄存器，其字段如下:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// IA-32 体系结构软件开发人员手册 (第 1 卷) 中提供了所有字段的文档。
    ///
    /// 与以下代码相关的唯一字段是 PC，Precision Control。
    /// 该字段确定 FPU 执行的操作的精度。
    /// 可以设置为:
    ///  - 0b00，单精度，即 32 位
    ///  - 0b10，双精度，即 64 位
    ///  - 0b11，双精度扩展精度，即 80 位 (默认状态) 0b01 值是保留的，不应使用。
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // 安全: `fldcw` 指令已通过审核，可以正常工作。
        // 任何 `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: 我们正在使用 ATT 语法来支持 LLVM 8 和 LLVM 9。
                options(att_syntax, nostack),
            )
        }
    }

    /// 将 FPU 的 precision 字段设置为 `T` 并返回 `FPUControlWord`。
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // 计算适用于 `T` 的 Precision Control 字段的值。
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 位
            8 => 0x0200, // 64 位
            _ => 0x0300, // 默认为 80 位
        };

        // 获得控制字的原始值，以便在以后删除 `FPUControlWord` 结构时将其还原。安全性: `fnstcw` 指令已通过审核，可以与任何 `u16` 一起正常使用
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: 我们正在使用 ATT 语法来支持 LLVM 8 和 LLVM 9。
                options(att_syntax, nostack),
            )
        }

        // 将控制字设置为所需的精度。
        // 这可以通过掩盖旧的精度 (位 8 和 9，0x300) 并将其替换为上面计算的精度标志来实现。
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Bellerophon 使用机器大小的整数和浮点数的快速路径。
///
/// 它被提取到一个单独的函数中，以便可以在构造 bignum 之前尝试使用它。
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) 〜15.95。
    // 我们将精确值与末尾的 MAX_SIG 进行比较，这只是一个快速，廉价的拒绝方法 (并且使其余代码免于担心下溢的麻烦)。
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // 快速路径至关重要地取决于将算术四舍五入到正确的位数，而无需任何中间舍入。
    // 在 x86 (不带 SSE 或 SSE2) 上，这需要更改 x87 FPU 栈的精度，以便直接将其舍入为 64/32 位。
    // `set_precision` 功能负责在需要通过更改全局状态 (例如 x87 FPU 的控制字) 进行设置的体系结构上设置精度。
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // e <0 的情况不能折叠到另一个 branch 中。
    // 负幂会导致二进制中重复的小数部分四舍五入，这会在最终结果中引起实际的 (有时是相当大的! ) 错误。
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// 算法 Bellerophon 是通过非平凡数值分析证明的平凡代码。
///
/// 它将 `f` 四舍五入为有效位数为 64 位的浮点数，并将其乘以 `10^e` 的最佳近似值 (以相同的浮点格式)。通常这足以获得正确的结果。
/// 但是，当结果接近两个相邻 (ordinary) 浮点数之间的一半时，乘以两个近似值会产生复合舍入误差，这意味着结果可能会偏离几位。
/// 发生这种情况时，迭代算法 R 会解决问题。
///
/// 通过本文中的数值分析，可以使手工波浪 "close to halfway" 变得精确。
/// 用克林格的话来说:
///
/// > 以最低有效位为单位表示的斜率是错误的包含范围
/// > 在对 f * 10 ^ e 进行近似的浮点计算过程中累积。(斜率是
/// > 不是真正误差的界限，而是将近似值 z 与
/// > 使用 p 个有效位数的最佳近似值。)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // abs(e) <log5(2^N) 的情况在 fast_path() 中
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // 舍入到 n 位时，斜率是否足够大以产生影响?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// 一种改进 `f * 10^e` 浮点近似的迭代算法。
///
/// 每次迭代都会在最后一个位置获得一个单位，如果 `z0` 稍微偏离，则收敛当然会花费非常长的时间。
/// 幸运的是，当用作 Bellerophon 的后备时，起始近似值最多可以有一个 ULP。
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // 找到正整数 `x`，`y`，使 `x / y` 恰好是 `(f *10^e) / (m* 2^k)`。
        // 这不仅避免了处理 `e` 和 `k` 的符号，而且还消除了 `10^e` 和 `2^k` 的两个共同之处，以使数字更小。
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // 这样做有点尴尬，因为我们的 bignum 不支持负数，因此我们使用绝对值 + 符号信息。
        // 与 m_digits 的乘法不会溢出。
        // 如果 `x` 或 `y` 足够大，我们需要担心溢出，那么它们也足够大，以至于 `make_ratio` 将分数减少了 2 ^ 64 或更多。
        //
        //
        let (d2, d_negative) = if x >= y {
            // 不再需要 x，保存 clone()。
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // 仍然需要 y，进行复制。
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// 给定 `x = f` 和 `y = m`，其中 `f` 照常表示输入的十进制数字，而 `m` 是浮点近似值的有效数字，使比率 `x / y` 等于 `(f *10^e) / (m* 2^k)`，可能会减少两者的幂。
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e，y=m* 2 ^ k，不同之处在于我们将分数减小了 2 的幂。
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k)，y=m 这不会溢出，因为它需要正 `e` 和负 `k`，这仅在值非常接近 1 时才会发生，这意味着 `e` 和 `k` 会比较小。
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f，y=m *10^abs(e)* 2 ^ k 这也不会溢出，请参见上文。
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k)，y=m* 10^abs(e)，再次减小了两个的幂。
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// 从概念上讲，算法 M 是将小数转换为浮点数的最简单方法。
///
/// 我们形成一个等于 `f * 10^e` 的比率，然后将其乘以 2，直到给出有效的有效浮点数为止。
/// 二进制指数 `k` 是分子或分母乘以 2 的次数，即 `f *10^e` 始终等于 `(u / v)* 2^k`。
/// 当我们发现有效位数时，我们只需要检查除法的其余部分就可以进行舍入，这将在下面的辅助函数中完成。
///
///
/// 即使使用 `quick_start()` 中描述的优化方法，该算法也非常慢。
/// 但是，它是最适合于上溢，下溢和次正规结果的算法。
/// 当 Bellerophon 和 Algorithm R 不堪重负时，此实现将接手。
/// 检测下溢和上溢很容易: 该比率仍然不是有效范围，但已达到 minimum/maximum 指数。
/// 在溢出的情况下，我们只是返回无穷大。
///
/// 处理下溢和次常态异常比较棘手。
/// 一个大问题是，如果使用最小指数，则该比率可能仍然太大而无法实现。
/// 有关详细信息，请参见 underflow()。
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME 可能的优化: 泛化 big_to_fp，以便我们可以在这里执行 fp_to_float(big_to_fp(u)) 的等效功能，而无需进行双取整。
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // 我们必须在最小指数处停止，如果我们等到 `k < T::MIN_EXP_INT`，那么我们将相差 2 倍。
            // 不幸的是，这意味着我们必须对具有最小指数的正态数进行特殊处理。
            // FIXME 找到了一个更优雅的公式，但是运行 `tiny-pow10` 测试以确保它实际上是正确的!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// 通过检查位长跳过大多数算法 M 迭代。
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // 位长是以 2 为底的对数的估计值，并且 log(u / v) = log(u)，log(v)。
    // 估计最多偏移 1，但始终被低估，因此 log(u) 和 log(v) 上的错误具有相同的符号并被抵消 (如果两者都很大)。
    // 因此，log(u / v) 的错误最多也为 1。
    // 目标比率是 u/v 在有效范围内的比率。因此，我们的终止条件是 log2(u / v) 为有效位，plus/minus 为 1。
    // FIXME 查看第二位可以改善估计并避免更多划分。
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // 下溢或低于正常水平。留给主要功能。
            break;
        }
        if *k == T::MAX_EXP_INT {
            // 溢出。留给主要功能。
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // 比率不是最小指数的有效范围，因此我们需要舍入多余的位并相应地调整指数。
    // 现在，实际价值如下所示:
    //
    //        l
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q 截断 (由 rem 代表)
    //
    // 因此，当舍入位为! = 0.5 ULP 时，它们将自行决定舍入。
    // 当它们相等且余数不为零时，该值仍需要四舍五入。
    // 只有当四舍五入的位是 1/2 且其余部分为零时，我们才有一半到偶数的情况。
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// 普通的取整到偶数，由于必须除以除法的余数而取整。
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}