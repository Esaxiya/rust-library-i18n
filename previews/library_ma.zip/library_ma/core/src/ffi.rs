#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! 与外部功能接口 (FFI) 绑定相关的实用程序。

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// 当用作 [pointer] 时，等效于 C 的 `void` 类型。
///
/// 本质上，`*const c_void` 等效于 C 的 `const void*`，而 `*mut c_void` 等效于 C 的 `void*`。
/// 也就是说，这与 C 的 `void` 返回类型 (即 Rust 的 `()` 类型) 不同。
///
/// 要在 FFI 中对指向不透明类型的指针进行建模，直到 `extern type` 稳定为止，建议在空字节数组周围使用 newtype 包装器。
///
/// 有关详细信息，请参见 [Nomicon]。
///
/// 如果他们想支持低至 1.1.0 的旧 Rust 编译器，则可以使用 `std::os::raw::c_void`。
/// Rust 1.30.0 之后，此定义将其重新导出。
/// 有关更多信息，请阅读 [RFC 2521]。
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// 注意，为使 LLVM 识别空指针类型并通过扩展功能 (如 malloc())，我们需要在 LLVM 位码中将其表示为 i8 *。
// 此处使用的枚举可确保这一点，并仅通过使用私有变体来防止 "raw" 类型的滥用。
// 我们需要两个变体，因为编译器否则会抱怨 repr 属性，并且我们至少需要一个变体，否则枚举将无人居住，并且至少取消引用此类指针将是 UB。
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// `va_list` 的基本实现。
// 名称为 WIP，现在使用 `VaListImpl`。
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // 在 `'f` 上不变，因此每个 `VaListImpl<'f>` 对象都与其在其中定义的函数的区域相关联
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 `va_list` 的 ABI 实现。
/// 有关更多详细信息，请参见 [AArch64 Procedure Call Standard]。
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC `va_list` 的 ABI 实现。
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 `va_list` 的 ABI 实现。
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// `va_list` 的包装
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// 将 `VaListImpl` 转换为与 C 的 `va_list` 二进制兼容的 `VaList`。
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// 将 `VaListImpl` 转换为与 C 的 `va_list` 二进制兼容的 `VaList`。
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// 必须在公共接口中使用 VaArgSafe trait，但是，不允许在该模块之外使用 trait 本身。
// 允许用户为新类型实现 trait (从而允许在新类型上使用 va_arg 内部函数) 可能会导致未定义的行为。
//
// FIXME(dlrobertson): 为了在公共接口中使用 VaArgSafe trait 并确保不能在其他地方使用它，trait 需要在私有模块中是公共的。
// RFC 2145 实现后，可以考虑对此进行改进。
//
//
//
//
mod sealed_trait {
    /// Trait，允许将允许的类型与 [super::VaListImpl::arg] 一起使用。
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// 前进到下一个 arg。
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // 安全: 调用者必须遵守 `va_arg` 的安全合同。
        unsafe { va_arg(self) }
    }

    /// 在当前位置复制 `va_list`。
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // 安全: 调用者必须遵守 `va_end` 的安全合同。
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // 安全: 我们写入 `MaybeUninit`，因此它已初始化且 `assume_init` 合法
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: 这应该叫 `va_end`，但是没有干净的方法
        // 确保 `drop` 总是内联到其调用程序中，因此 `va_end` 将直接从与相应 `va_copy` 相同的函数中调用。
        // `man va_end` 声明 C 要求这样做，并且 LLVM 基本遵循 C 语义，因此我们需要确保始终从与 `va_copy` 相同的函数调用 `va_end`。
        //
        // 更多细节， see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // 由于 `va_end` 是当前所有 LLVM 目标上的无操作项，因此该操作现在可行。
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// 用 `va_start` 或 `va_copy` 初始化后，销毁参数列表 `ap`。
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// 将 arglist `src` 的当前位置复制到 arglist `dst`。
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// 从 `va_list` `ap` 加载类型为 `T` 的参数，并递增 `ap` 指向的参数。
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}