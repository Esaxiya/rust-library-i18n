use crate::iter::FromIterator;

/// 将所有单元项从一个迭代器折叠为一个。
///
/// 与更高级别的抽象结合使用时，此功能尤其有用，例如收集到仅关心错误的 `Result<(), E>` 上:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}