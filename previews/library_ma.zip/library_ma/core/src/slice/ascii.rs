//! 在 ASCII `[u8]` 上的操作。

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// 检查此片中的所有字节是否都在 ASCII 范围内。
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// 检查两个片是否是 ASCII 大小写不敏感的匹配项。
    ///
    /// 与 `to_ascii_lowercase(a) == to_ascii_lowercase(b)` 相同，但不分配和复制临时文件。
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// 将此切片原位转换为其 ASCII 大写形式。
    ///
    /// ASCII 字母 'a' 到 'z' 映射到 'A' 到 'Z'，但是非 ASCII 字母不变。
    ///
    /// 要返回新的大写值而不修改现有值，请使用 [`to_ascii_uppercase`]。
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// 将此切片原位转换为其 ASCII 小写等效项。
    ///
    /// ASCII 字母 'A' 到 'Z' 映射到 'a' 到 'z'，但是非 ASCII 字母不变。
    ///
    /// 要返回新的小写值而不修改现有值，请使用 [`to_ascii_lowercase`]。
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// 如果单词 `v` 中的任何字节为 nonascii (>=128)，则返回 `true`。
/// 来自 `../str/mod.rs`，它对 utf8 验证执行类似的操作。
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// 优化的 ASCII 测试，将使用每次使用一次的操作，而不是一次使用字节的操作 (如果可能)。
///
/// 我们在这里使用的算法非常简单。如果 `s` 太短，我们只检查每个字节并完成它。除此以外:
///
/// - 阅读未对齐的单词的第一个单词。
/// - 对齐指针，读取后续单词，直到对齐负载结束。
/// - 从 `s` 读取未装载的最后一个 `usize`。
///
/// 如果这些负载中的任何一个产生了 `contains_nonascii` (above) 返回 true 的值，则我们知道答案为 false。
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // 如果我们不能从一次单词的实现中获得任何收益，请回到标量循环。
    //
    // 我们还针对 `size_of::<usize>()` 不足以与 `usize` 对齐的体系结构执行此操作，因为这是一种奇怪的 edge 情况。
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // 我们总是读第一个单词 unaligned，这意味着 `align_offset` 是
    // 0，我们将为对齐的读取再次读取相同的值。
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // 安全: 我们验证上面的 `len < USIZE_SIZE`。
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // 我们在上面对此进行了某种程度的隐式检查。
    // 请注意，`offset_to_aligned` 是 `align_offset` 或 `USIZE_SIZE`，两者均在上面进行了明确检查。
    //
    debug_assert!(offset_to_aligned <= len);

    // 安全: word_ptr 是我们用来读取
    // 切片的中间块。
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` 是 `word_ptr` 的字节索引，用于循环结束检查。
    let mut byte_pos = offset_to_aligned;

    // 偏执狂会检查对齐情况，因为我们将要进行一堆未对齐的负载。
    // 在实践中，除非存在 `align_offset` 中的错误，否则这应该是不可能的。
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // 读取后续单词，直到最后一个对齐的单词 (不包括最后一个对齐的单词本身) 要在以后的尾部检查中进行，以确保尾部始终最多为一个 `usize`，以额外的 branch `byte_pos == len`。
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // 完好无损的检查，以确保读取的范围
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // 并且我们关于 `byte_pos` 的假设成立。
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // 安全: 我们知道 `word_ptr` 正确对齐 (因为
        // `align_offset`)，我们知道 `word_ptr` 和末尾之间有足够的字节
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // 安全: 我们知道 `byte_pos <= len - USIZE_SIZE`，这意味着
        // 在此 `add` 之后，`word_ptr` 最多只能是最后一个。
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // 进行健全性检查，确保仅剩 `usize` 个。
    // 这应该由我们的循环条件来保证。
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // 安全: 这依赖于 `len >= USIZE_SIZE`，我们将在开始时对其进行检查。
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}