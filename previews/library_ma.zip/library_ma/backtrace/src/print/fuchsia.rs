use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr 进行回调，该回调将为已链接到该进程的每个 DSO 接收 dl_phdr_info 指针。
    // dl_iterate_phdr 还可以确保动态链接器从迭代的开始到结束都被锁定。
    // 如果回调返回非零值，则迭代会提前终止。
    // 'data' 将在每次调用时作为第三个参数传递给回调。
    // 'size' 给出 dl_phdr_info 的大小。
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// 我们需要解析构建 ID 和一些基本程序头数据，这意味着我们也需要 ELF 规范中的一些内容。
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// 现在，我们必须一点一点地复制紫红色的当前动态链接器使用的 dl_phdr_info 类型的结构。
// 铬也具有此 ABI 边界以及崩溃垫。
// 最终，我们希望将这些案例移至使用 elf-search，但我们需要在 SDK 中提供它，但尚未完成。
//
// 因此，我们 (和他们) 不得不使用这种方法，而这种方法会导致与紫红色 libc 的紧密耦合。
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // 我们无法知道检查 e_phoff 和 e_phnum 是否有效。
    // libc 应该为我们确保这一点，因此在这里形成切片是安全的。
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr 以目标体系结构的字节序表示一个 64 位的 ELF 程序头。
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr 表示有效的 ELF 程序标头及其内容。
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // 我们无法检查 p_addr 或 p_memsz 是否有效。
    // 紫红色的 libc 首先解析注释，因此，由于位于此处，这些标头必须有效。
    //
    // 注意 Iter 不需要底层数据有效，但是它要求边界有效。
    // 我们相信 libc 确保在这里对我们而言就是这种情况。
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// 构建 ID 的注解类型。
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr 表示目标字节序中的 ELF 注释标头。
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// 注释表示 ELF 注释 (标题 + 内容)。
// 该名称保留为 u8 片，因为它并不总是以 null 终止，并且 rust 使得检查字节是否匹配仍然足够容易。
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter 使您可以安全地遍历笔记段。
// 一旦发生错误或没有更多注释，它将终止。
// 如果您遍历无效数据，它将像未找到任何注释一样起作用。
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // 给定的指针和大小表示可以读取的有效字节范围，这是函数的不变性。
    // 这些字节的内容可以是任何东西，但范围必须是有效的，以确保安全。
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// 假设 'to' 为 2 的幂，align_to 将 'x' 对齐为 `至` 字节对齐。
// 这遵循 C/C ++ ELF 解析代码中的标准模式，其中使用 (x + to，1)＆-to。
// Rust 不允许您否定 usize，所以我用
// 2 的补码转换以重新创建它。
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 会消耗切片中的 num 个字节 (如果存在)，并另外确保最终切片正确对齐。
// 如果请求的字节数太大，或者由于剩余字节数不足而无法在之后重新对齐分片，则将返回 None 且不对分片进行修改。
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// 该函数没有调用者必须坚持的任何实际不变性，除了 'bytes' 应该针对性能 (以及某些体系结构的正确性) 进行对齐之外。
// Elf_Nhdr 字段中的值可能是无意义的，但此函数可确保不会出现这种情况。
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // 只要有足够的空间，这是安全的，并且我们只是在上面的 if 语句中确认了这一点，所以这并不安全。
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // 请注意 sice_of: :<Elf_Nhdr> () 始终 4 字节对齐。
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // 检查我们是否到达终点。
        if self.base.len() == 0 || self.error {
            return None;
        }
        // 我们转换了一个 nhdr，但我们仔细考虑了生成的结构。
        // 我们不信任 namez 或 descsz，也不会根据类型做出不安全的决定。
        //
        // 因此，即使我们清除了完整的垃圾，我们仍然应该是安全的。
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// 指示段是可执行的。
const PERM_X: u32 = 0b00000001;
/// 指示段是可写的。
const PERM_W: u32 = 0b00000010;
/// 指示段是可读的。
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// 表示运行时的 ELF 段。
struct Segment {
    /// 提供此段内容的运行时虚拟地址。
    addr: usize,
    /// 给出此段内容的内存大小。
    size: usize,
    /// 使用 ELF 文件为该段提供模块的虚拟地址。
    mod_rel_addr: usize,
    /// 提供在 ELF 文件中找到的权限。
    /// 但是，这些权限不一定是运行时存在的权限。
    flags: Perm,
}

/// 让一个 DSO 遍历细分。
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// 表示 ELF DSO (动态共享对象)。
/// 此类型引用存储在实际 DSO 中的数据，而不是制作其自己的副本。
struct Dso<'a> {
    /// 即使名称为空，动态链接器也始终为我们提供一个名称。
    /// 对于主可执行文件，此名称将为空。
    /// 对于共享对象，它将是 soname (请参阅 DT_SONAME)。
    name: &'a str,
    /// 在 Fuchsia 上，几乎所有二进制文件都有构建 ID，但这不是严格的要求。
    /// 如果没有 build_id，那么以后就无法将 DSO 信息与真实的 ELF 文件进行匹配，因此我们要求每个 DSO 在此处都具有一个。
    ///
    /// 没有 build_id 的 DSO 将被忽略。
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// 返回此 DSO 中的细分上的迭代器。
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// 这些错误编码了在解析有关每个 DSO 的信息时出现的问题。
///
enum Error {
    /// NameError 表示将 C 样式字符串转换为 rust 字符串时发生错误。
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError 表示我们找不到构建 ID。
    /// 这可能是因为 DSO 没有构建 ID，或者是因为包含构建 ID 的段格式错误。
    ///
    BuildIDError,
}

/// 对于由动态链接器链接到进程的每个 DSO，调用 'dso' 或 'error'。
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter 将具有一种称为 foreach DSO 的 eats 方法。
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr 确保 info.name 指向有效位置。
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// 此功能为 DSO 中包含的所有信息打印倒挂金钟符号器标记。
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}