//! 在 crates.io 上使用 `gimli` crate 支持符号化
//!
//! 这是 Rust 的默认符号实现。

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 静态生命周期是在缺乏对自我引用结构的支持的支持下的谎言。
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // 转换为 `静态寿命`，因为符号仅应借用 `map` 和 `stash`，我们将其保留在下面。
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // 要在 Windows 上加载原生库，请参见 rust-lang/rust#71060 上有关各种策略的一些讨论。
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW 库当前不支持 ASLR (rust-lang/rust#16514)，但是 DLL 仍可以在地址空间中重新定位。
            // 如果该库是在其 "image base" 处加载的，则调试信息中的地址似乎全部都作为该库的 COFF 文件头中的一个字段。
            // 由于这是 debuginfo 似乎列出的内容，因此我们解析符号表并存储地址，就像该库也已在 "image base" 上加载一样。
            //
            // 但是，该库可能未在 "image base" 上加载。
            // (大概在那里可能还有其他内容吗? ) 这是 `bias` 字段起作用的地方，我们需要在这里计算 `bias` 的值。不幸的是，尽管目前尚不清楚如何从已加载的模块中获取此信息。
            // 但是，我们要做的是实际的加载地址 (`modBaseAddr`)。
            //
            // 现在，作为一点补偿，我们映射文件，读取文件头信息，然后放下 mmap。这很浪费，因为我们稍后可能会重新打开 mmap，但这现在应该已经足够好了。
            //
            // 一旦有了 `image_base` (所需的加载位置) 和 `base_addr` (实际的加载位置)，我们就可以填写 `bias` (实际值与期望值之间的差)，然后每个段的指定地址就是 `image_base`，因为这就是文件所说的。
            //
            //
            // 现在看来，与 ELF/MachO 不同，我们可以使用 `modBaseSize` 作为整个大小来处理每个库一个段。
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS 使用 Mach-O 文件格式，并使用 DYLD 特定的 API 加载作为应用程序一部分的原生库的列表。
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // 获取该库的名称，该名称也与加载该库的路径相对应。
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // 加载该库的图像头并将其委托给 `object` 来解析所有加载命令，因此我们可以找出此处涉及的所有段。
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // 遍历这些段，并为找到的段注册已知区域。
            // 另外，记录有关文本段的信息以供以后处理，请参阅下面的注释。
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // 确定该库的 "slide"，这最终是我们用来确定内存对象加载位置的偏差。
            // 但是，这是一个奇怪的计算，是在野外尝试一些尝试并看得出结果的结果。
            //
            // 通常的想法是，`bias` 加上段的 `stated_virtual_memory_address` 将成为该段在实际地址空间中的位置。
            // 但是，我们所依赖的另一件事是，实际地址减去 `bias` 是要在符号表和 debuginfo 中查找的索引。
            //
            // 但是事实证明，对于系统加载的库，这些计算是不正确的。但是，对于原生可执行文件，它似乎是正确的。
            // 从 LLDB 的源代码中提取了一些逻辑，它对从文件偏移量 0 (非零大小) 加载的第一个 `__TEXT` 节有一些特殊的框。
            // 无论出于何种原因，出现这种情况似乎都意味着符号表仅相对于库的 vmaddr 幻灯片。
            // 如果 *不存在*，则符号表是相对于 vmaddr 幻灯片加上段的声明地址的。
            //
            // 为了处理这种情况，如果我们 *找不到* 文件偏移量为零的文本部分，那么我们将增加第一个文本部分的声明地址的偏见，并同时减少所有声明地址的数量。
            //
            // 这样，符号表总是相对于库的偏差量出现。
            // 这似乎对于通过符号表进行符号化具有正确的结果。
            //
            // 老实说，我不确定这是正确的还是还有其他方法可以指示如何做到这一点。
            // 目前，尽管 (?) 看起来已经足够好了，但如果有必要，我们应该可以随时对其进行调整。
            //
            // 有关更多信息，请参见 #318。
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // 其他 Unix (例如
        // Linux) 平台使用 ELF 作为目标文件格式，并且通常实现称为 `dl_iterate_phdr` 的 API 来加载原生库。
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` 应该是一个有效的指针。
        // `vec` 应该是指向 `std::Vec` 的有效指针。
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 本身不支持调试信息，但是构建系统会将调试信息放置在路径 `romfs:/debug_info.elf` 处。
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // 其他所有内容都应使用 ELF，但不知道如何加载原生库。
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// 已加载的所有已知共享库。
    libraries: Vec<Library>,

    /// 映射缓存，其中保留了解析的矮人信息。
    ///
    /// 此列表在整个提升期间具有固定的容量，永远不会增加。
    /// 每对中的 `usize` 元素是 `libraries` 的索引，以上 `usize::max_value()` 表示当前可执行文件。
    ///
    /// `Mapping` 是相应的解析后的矮人信息。
    ///
    /// 请注意，这基本上是一个 LRU 缓存，我们将在这里对地址进行符号化，以进行符号化。
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// 该库的各段已加载到内存中以及它们的加载位置。
    segments: Vec<LibrarySegment>,
    /// 该库的 "bias"，通常是它被加载到内存中的位置。
    /// 将此值添加到每个段的声明地址中，以获取该段加载到的实际虚拟内存地址。
    /// 另外，从实际虚拟内存地址中减去此偏差以将其索引到 debuginfo 和符号表中。
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// 在对象文件中该段的规定地址。
    /// 实际上，这不是加载该段的位置，而是在该地址加上包含库的 `bias` 所在的位置。
    ///
    stated_virtual_memory_address: usize,
    /// 内存中 ths 段的大小。
    len: usize,
}

// 不安全，因为需要从外部进行同步
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // 不安全，因为需要从外部进行同步
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // 一个非常小，非常简单的 LRU 缓存，用于调试信息映射。
        //
        // 命中率应该很高，因为典型的栈不会在许多共享库之间交叉。
        //
        // `addr2line::Context` 结构的创建成本非常高。
        // 预期其成本将由后续的 `locate` 查询摊销，这些查询将利用在构建 `addr2line: : Context`s 时构建的结构来获得良好的加速效果。
        //
        // 如果我们没有此缓存，则摊销将永远不会发生，而象征性回溯将是 ssssllllooooowwww。
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // 首先，测试此 `lib` 是否具有包含 `addr` 的任何段 (处理重定位)。如果此检查通过，那么我们可以继续下面的内容并实际翻译地址。
                //
                // 请注意，我们在这里使用 `wrapping_add` 以避免溢出检查。狂野地看到 SVMA + 偏差计算会溢出。
                // 这似乎有点奇怪，但除了可能忽略这些片段，因为它们可能指向太空之外，我们对此无能为力。
                //
                // 这最初是在 rust-lang/backtrace-rs#329 中出现的。
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // 既然我们知道 `lib` 包含 `addr`，我们就可以用偏差进行偏移以找到规定的虚拟内存地址。
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // 不变式: 此条件完成后没有提前返回
        // 由于错误，此路径的缓存条目位于索引 0。

        if let Some(idx) = idx {
            // 当映射已经在缓存中时，将其移到最前面。
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // 当映射不在高速缓存中时，请创建一个新的映射，将其插入高速缓存的前面，并在必要时逐出最旧的高速缓存条目。
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // 不要泄漏 `'static` 的使用寿命，请确保它仅限于我们自己
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // 将 `sym` 的寿命延长到 `'static`，这是很不幸的，因为我们必须这样做，但是它永远只作为参考，因此无论如何都不应坚持到此。
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // 最后，获取缓存的映射或为此文件创建新的映射，并评估 DWARF 信息以查找该地址的 file/line/name。
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// 我们能够找到该符号的框架信息，并且 `addr2line` 的框架内部具有所有细腻的细节。
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// 找不到调试信息，但是我们在 elf 可执行文件的符号表中找到了它。
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}