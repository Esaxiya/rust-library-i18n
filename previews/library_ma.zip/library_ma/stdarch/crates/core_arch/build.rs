use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // 用来告诉我们的 `#[assert_instr]` 批注，所有 simd 内部函数都可以用来测试其代码生成，因为其中一些是封闭在当前 `#[target_feature]` 中没有任何等效项的额外 `-Ctarget-feature=+unimplemented-simd128` 后面的。
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}