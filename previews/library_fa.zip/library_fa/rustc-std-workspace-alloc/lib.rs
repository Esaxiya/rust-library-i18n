#![feature(no_core)]
#![no_core]

// برای دلیل نیاز به این crate به rustc-std-workspace-core مراجعه کنید.

// نام crate را تغییر دهید تا از ایجاد تضاد با ماژول تخصیص در liballoc جلوگیری شود.
extern crate alloc as foo;

pub use foo::*;