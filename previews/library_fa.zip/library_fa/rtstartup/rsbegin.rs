// rsbegin.o و rsend.o به اصطلاح "compiler runtime startup objects" هستند.
// آنها حاوی کدی هستند که برای شروع صحیح زمان اجرا کامپایلر لازم است.
//
// هنگامی که یک تصویر اجرایی یا dylib پیوند داده می شود ، همه کد کاربر و کتابخانه ها بین این دو پرونده شی "sandwiched" هستند ، بنابراین کد یا داده های rsbegin.o در بخشهای مربوط به تصویر اول می شوند ، در حالی که کد و داده های rsend.o به آخرین موارد تبدیل می شوند.
// از این افکت می توان برای قرار دادن نمادها در ابتدا یا انتهای یک بخش و همچنین قرار دادن هدرها یا پاورقی های مورد نیاز استفاده کرد.
//
// توجه داشته باشید که نقطه ورود واقعی ماژول در شی start راه اندازی زمان اجرا C قرار دارد (که معمولاً `crtX.o` نامیده می شود) ، که پس از آن فراخوانی مقداردهی اولیه سایر اجزای زمان اجرا را فراخوانی می کند (از طریق بخش تصویر ویژه دیگری ثبت شده است).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // ابتدا بخش پشته را از بخش اطلاعات باز کنید
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // فضای خراشیده برای نگهداری کتاب داخلی از بین بردن.
    // این به عنوان `struct object` در GCC $/unwind-dw2-fde.h تعریف می شود.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // اطلاعات معمول registration/deregistration را باز کنید.
    // اسناد libpanic_unwind را ببینید.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // اطلاعات مربوط به راه اندازی ماژول را باز کنید
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ثبت نام در هنگام خاموش کردن
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // ثبت نام معمول init/uninit مخصوص MinGW
    pub mod mingw_init {
        // اشیا start راه اندازی MinGW (crt0.o/dllcrt0.o) در هنگام راه اندازی و خروج سازندگان جهانی را در بخش های .ctors و .dtors فراخوانی می کنند.
        // در مورد DLL ها ، این مورد زمانی انجام می شود که DLL بارگیری و تخلیه می شود.
        //
        // پیوند دهنده بخشها را مرتب می کند ، این اطمینان می دهد که تماسهای ما در انتهای لیست قرار دارد.
        // از آنجا که سازنده ها به ترتیب معکوس اجرا می شوند ، این اطمینان می دهد که تماس های قبلی اولین و آخرین مورد اجرا شده هستند.
        //
        //

        #[link_section = ".ctors.65535"] // بردارها. *: برگشتهای اولیه C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: پاسخهای ختم C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}