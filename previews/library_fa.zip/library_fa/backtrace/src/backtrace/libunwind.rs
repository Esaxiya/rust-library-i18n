//! پشتیبانی از Backtrace با استفاده از API های libunwind/gcc_s/etc.
//!
//! این ماژول شامل توانایی باز کردن پشته با استفاده از API های سبک libunwind است.
//! توجه داشته باشید که مجموعه کاملی از پیاده سازی های API مشابه libunwind وجود دارد و این فقط سعی دارد به جای اینکه انتخابی باشد ، با اکثر آنها همزمان سازگار باشد.
//!
//!
//! API libunwind توسط `_Unwind_Backtrace` تغذیه می شود و در عمل در ایجاد یک backtrace بسیار قابل اعتماد است.
//! کاملاً مشخص نیست که چگونه انجام می شود (اشاره گرهای قاب؟ اطلاعات eh_frame؟ هر دو؟) اما به نظر می رسد که کار می کند!
//!
//! بیشتر پیچیدگی های این ماژول مدیریت تفاوت های مختلف پلتفرم در بین پیاده سازی های libunwind است.
//! در غیر این صورت این اتصال Rust کاملاً ساده به API های libunwind است.
//!
//! این API بازپرداخت پیش فرض برای همه سیستم عامل های غیر ویندوزی در حال حاضر است.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// با استفاده از یک نشانگر libunwind خام ، فقط باید فقط به صورت موضوعی و فقط به صورت ایمن دسترسی داشته باشید ، بنابراین `Sync` است.
// هنگام ارسال به سایر موضوعات از طریق `Clone` ، ما همیشه به نسخه ای روی می آوریم که نشانگرهای داخلی را در خود نگه نمی دارد ، بنابراین باید `Send` نیز باشیم.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // به نظر می رسد که در OSX `_Unwind_FindEnclosingFunction` یک نشانگر را به ... چیزی که مشخص نیست برگرداند.
        // به هر دلیلی قطعاً همیشه عملکرد محصور نیست.
        // برای من کاملاً روشن نیست که در اینجا چه اتفاقی می افتد ، بنابراین فعلاً این موضوع را بد بینید و همیشه IP را برگردانید.
        //
        // توجه داشته باشید که آزمون `skip_inner_frames.rs` به دلیل این بند در OSX حذف شده است و اگر این مشکل برطرف شود ، از لحاظ تئوری تست را می توان بر روی OSX اجرا کرد!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// رابط کتابخانه را بازگردانی کنید
///
/// توجه داشته باشید که کد مرده مجاز است زیرا در اینجا فقط اتصال دهنده ها وجود دارد که iOS از همه آنها استفاده نمی کند اما افزودن تنظیمات خاص ویژه سیستم عامل کد را بیش از حد آلوده می کند
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // فقط توسط ARM EABI استفاده می شود
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // در iOS نسخه پشتیبان گیری _شکاف_بخش نیست
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // از GCC 4.2.0 موجود است ، باید برای اهداف ما خوب باشد
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // این عملکرد نام غلطی است: به جای دریافت Canonical Frame Address (یا همان قاب تماس گیرنده) این فریم SP این فریم را برمی گرداند.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x از مقدار CFA مغرضانه استفاده می کند ، بنابراین ما باید از _Unwind_GetGR استفاده کنیم تا نشانگر پشته (%r15) را به جای تکیه بر _Unwind_GetCFA ثبت کنیم.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // در android و بازوی ، تابع `_Unwind_GetIP` و یک دسته دیگر ماکرو هستند ، بنابراین توابع حاوی گسترش ماکروها را تعریف می کنیم.
    //
    //
    // TODO: اگر می توانید آن را پیدا کنید ، به پرونده هدر پیوند دهید.
    // (من ، fitzgen ، نمی توانم پرونده هدر را پیدا کنم که برخی از این توسعه های کلان در اصل از آن وام گرفته شده اند.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 نشانگر پشته بر روی بازو است.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // این عملکرد در Android یا ARM/Linux نیز وجود ندارد ، بنابراین آن را ممنوع کنید.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}