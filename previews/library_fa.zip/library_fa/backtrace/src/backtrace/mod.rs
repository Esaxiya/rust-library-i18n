use core::ffi::c_void;
use core::fmt;

/// فراخوانی پشته فعلی را بازرسی می کند ، و تمام فریم های فعال را به محفظه تعویض شده برای محاسبه ردیابی پشته منتقل می کند.
///
/// این تابع اسب محرک این کتابخانه در محاسبه ردیابی پشته ها برای یک برنامه است.`cb` بسته شده نمونه هایی از `Frame` است که اطلاعات مربوط به آن فریم تماس روی پشته را نشان می دهد.
/// بسته شدن فریم ها را به صورت بالا به پایین (که اخیراً ابتدا توابع نامیده می شود) ارائه می دهد.
///
/// مقدار بازگشتی بسته شدن نشانه ای از ادامه ادامه روند بازگشت است.مقدار برگشتی `false` بازگشت را خاتمه می دهد و بلافاصله باز می گردد.
///
/// پس از دستیابی `Frame` ، احتمالاً می خواهید با `backtrace::resolve` تماس بگیرید تا `ip` (نشانگر دستورالعمل) یا آدرس نماد را به `Symbol` تبدیل كند كه از طریق آن می توان نام و/یا نام پرونده/شماره خط را یاد گرفت.
///
///
/// توجه داشته باشید که این یک عملکرد نسبتاً سطح پایین است و اگر می خواهید ، مثلاً یک backtrace را بگیرید تا بعداً بررسی شود ، نوع `Backtrace` ممکن است مناسب تر باشد.
///
/// # ویژگی های مورد نیاز
///
/// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
///
/// # Panics
///
/// این عملکرد سعی می کند هرگز panic را انجام ندهد ، اما اگر `cb` panics را ارائه دهد ، برخی از سیستم عامل ها panic دو برابر را مجبور به سقط جنین می کنند.
/// برخی از سیستم عامل ها از کتابخانه C استفاده می کنند که در داخل از بازگشتی استفاده می کند که از طریق آن قابل بازگرداندن نیست ، بنابراین وحشت از `cb` ممکن است منجر به سقط فرآیند شود.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // ادامه بازگشت
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// همان `trace` ، فقط ناامن و همزمان نیست.
///
/// این عملکرد ضمانت همگام سازی ندارد اما وقتی ویژگی `std` این crate در آن کامپایل نشده باشد ، در دسترس است.
/// برای مستندات و مثالهای بیشتر به عملکرد `trace` مراجعه کنید.
///
/// # Panics
///
/// اطلاعات مربوط به `trace` را برای هشدارهای ناشی از وحشت `cb` مشاهده کنید.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait به نمایندگی از یک قاب از backtrace ، عملکرد `trace` این crate را تسلیم می کند.
///
/// بسته شدن تابع ردیابی فریم های بازدهی خواهد داشت و این فریم عملاً ارسال می شود زیرا اجرای اصلی همیشه تا زمان اجرا مشخص نیست.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// نشانگر دستورالعمل فعلی این قاب را برمی گرداند.
    ///
    /// این معمولاً دستورالعمل بعدی است که باید در فریم اجرا شود ، اما همه پیاده سازی ها با دقت 100٪ این را لیست نمی کنند (اما به طور کلی بسیار نزدیک است).
    ///
    ///
    /// توصیه می شود این مقدار را به `backtrace::resolve` منتقل کنید تا آن را به یک نام نماد تبدیل کند.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// نشانگر پشته فعلی این قاب را برمی گرداند.
    ///
    /// در مواردی که یک باطن نتواند نشانگر پشته را برای این فریم بازیابی کند ، یک اشاره گر تهی برگردانده می شود.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// آدرس نماد شروع قاب این تابع را برمی گرداند.
    ///
    /// با این کار می توانید نشانگر دستورالعمل بازگشتی `ip` را به ابتدای عملکرد برگردانید و آن مقدار را برگردانید.
    ///
    /// در برخی موارد ، باطن ها `ip` را از این عملکرد باز می گردانند.
    ///
    /// اگر `backtrace::resolve` در `ip` فوق الذکر خراب شود ، گاهی اوقات می توان از مقدار برگشتی استفاده کرد.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// آدرس پایه ماژولی را که قاب به آن تعلق دارد برمی گرداند.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // برای اطمینان از اینکه Miri نسبت به سیستم عامل میزبان اولویت دارد ، باید این مسئله ابتدا مطرح شود
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // فقط در dbghelp نماد استفاده می شود
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}