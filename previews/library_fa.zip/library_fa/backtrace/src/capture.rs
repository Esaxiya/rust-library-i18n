use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// نمایندگی خرده فروشی متعلق به خود و خودگردان.
///
/// از این ساختار می توان برای گرفتن backtrace در نقاط مختلف یک برنامه استفاده کرد و بعداً برای بررسی آنچه backtrace در آن زمان وجود داشت استفاده شد.
///
///
/// `Backtrace` با استفاده از `Debug` از چاپ بسیار زیبای backtraces پشتیبانی می کند.
///
/// # ویژگی های مورد نیاز
///
/// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // فریم ها در اینجا از بالا به پایین پشته لیست شده اند
    frames: Vec<BacktraceFrame>,
    // شاخصی که به اعتقاد ما شروع واقعی backtrace است و فریم هایی مانند `Backtrace::new` و `backtrace::trace` را حذف می کند.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// نسخه گرفته شده از یک قاب در backtrace.
///
/// این نوع به عنوان یک لیست از `Backtrace::frames` بازگردانده می شود و نشان دهنده یک قاب پشته در backtrace گرفته شده است.
///
/// # ویژگی های مورد نیاز
///
/// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// نسخه گرفته شده از یک نماد در backtrace.
///
/// این نوع به عنوان یک لیست از `BacktraceFrame::symbols` بازگردانده می شود و فراداده یک نماد را در backtrace نشان می دهد.
///
/// # ویژگی های مورد نیاز
///
/// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// با استفاده از این عملکرد ، عملکرد بازگشت را ضبط می کند و نمایشی متعلق به آن را برمی گرداند.
    ///
    /// این عملکرد برای نمایش backtrace به عنوان یک شی در Rust مفید است.این مقدار بازگشتی می تواند از طریق موضوعات ارسال شود و به جای دیگری چاپ شود و هدف از این مقدار کاملاً مستقل بودن از خود است.
    ///
    /// توجه داشته باشید که در برخی از سیستم عامل ها دستیابی به بازگشت کامل و حل آن می تواند بسیار گران باشد.
    /// اگر هزینه برنامه شما بسیار زیاد است ، توصیه می شود از `Backtrace::new_unresolved()` استفاده کنید که از مرحله تفکیک نماد جلوگیری می کند (که معمولاً طولانی ترین زمان طول می کشد) و به تعویق انداختن آن برای تاریخ بعدی امکان پذیر است.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // می خواهید مطمئن شوید که یک فریم برای حذف وجود دارد
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// مشابه `new` با این تفاوت که با این کار هیچ علامتی برطرف نمی شود ، این به سادگی backtrace را به عنوان لیستی از آدرس ها ضبط می کند.
    ///
    /// بعداً می توان تابع `resolve` را فراخوانی کرد تا نمادهای این backtrace را به نام خوانا حل کند.
    /// این عملکرد وجود دارد زیرا فرایند وضوح ممکن است گاهی اوقات زمان قابل توجهی طول بکشد در حالی که هر یک از backtrace فقط به ندرت چاپ می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // هیچ نامی از نمادها وجود ندارد
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // نام نمادها اکنون موجود است
    /// ```
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    ///
    ///
    #[inline(never)] // می خواهید مطمئن شوید که یک فریم برای حذف وجود دارد
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// فریم های مربوط به زمان گرفتن این backtrace را برمی گرداند.
    ///
    /// اولین ورودی این قطعه احتمالاً عملکرد `Backtrace::new` است و آخرین قاب احتمالاً مربوط به نحوه شروع این رشته یا عملکرد اصلی است.
    ///
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// اگر این backtrace از `new_unresolved` ایجاد شده باشد ، این عملکرد تمام آدرس های موجود در backtrace را به نام نمادین آنها حل می کند.
    ///
    ///
    /// اگر این backtrace قبلاً حل شده باشد یا از طریق `new` ایجاد شده باشد ، این عملکرد هیچ کاری نمی کند.
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// همان `Frame::ip` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// همان `Frame::symbol_address` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// همان `Frame::module_base_address` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// لیستی از نمادهایی که این قاب مربوط به آنها است را برمی گرداند.
    ///
    /// به طور معمول در هر فریم تنها یک نماد وجود دارد ، اما گاهی اوقات اگر تعدادی از توابع در یک قاب قرار بگیرند ، چندین نماد بازگردانده می شوند.
    /// اولین نماد ذکر شده "innermost function" است ، در حالی که آخرین نماد بیرونی ترین (آخرین تماس گیرنده) است.
    ///
    /// توجه داشته باشید که اگر این قاب از backtrace حل نشده تهیه شده باشد ، این یک لیست خالی را برمی گرداند.
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// همان `Symbol::name` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// همان `Symbol::addr` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// همان `Symbol::filename` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// همان `Symbol::lineno` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// همان `Symbol::colno` است
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // هنگام چاپ مسیرها سعی می کنیم cwd را در صورت وجود حذف کنیم ، در غیر این صورت ما فقط مسیر را همانطور که هست چاپ می کنیم.
        // توجه داشته باشید که ما این کار را فقط برای قالب کوتاه انجام می دهیم ، زیرا اگر پر باشد احتمالاً می خواهیم همه چیز را چاپ کنیم.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}