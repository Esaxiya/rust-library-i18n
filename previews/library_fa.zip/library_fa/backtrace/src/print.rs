#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// یک قالب ساز برای backtraces.
///
/// این نوع می تواند برای چاپ backtrace استفاده شود بدون در نظر گرفتن اینکه خود backtrace از کجا ناشی می شود.
/// اگر نوع `Backtrace` دارید ، اجرای `Debug` از قبل از این قالب چاپ استفاده می کند.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// سبک های چاپی که می توانیم چاپ کنیم
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// یک backtrace terser را چاپ می کند که در حالت ایده آل فقط شامل اطلاعات مربوطه است
    Short,
    /// backtrace را چاپ می کند که شامل تمام اطلاعات ممکن است
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// `BacktraceFmt` جدید ایجاد کنید که خروجی را برای `fmt` ارائه شده بنویسد.
    ///
    /// آرگومان `format` سبکی را که در آن backtrace چاپ می شود کنترل می کند و از آرگومان `print_path` برای چاپ نمونه های `BytesOrWideString` نام پرونده استفاده می شود.
    /// این نوع به خودی خود چاپ هیچ نامی را انجام نمی دهد ، اما برای این کار به این فراخوان نیاز است.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// مقدمه ای برای backtrace در شرف چاپ چاپ می کند.
    ///
    /// این مورد در برخی از سیستم عامل ها لازم است تا بعداً به طور کامل نمادهای معکوس نشان داده شوند ، وگرنه این فقط اولین روشی است که پس از ایجاد `BacktraceFmt` فراخوانی می کنید.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// یک قاب به خروجی backtrace اضافه می کند.
    ///
    /// این تعهد یک نمونه RAII از `BacktraceFrameFmt` را برمی گرداند که می تواند برای چاپ واقعی یک فریم استفاده شود و در هنگام تخریب ، شمارنده قاب را افزایش می دهد.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// خروجی backtrace را کامل می کند.
    ///
    /// در حال حاضر این گزینه ممنوع است اما برای سازگاری future با قالب های backtrace اضافه می شود.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // در حال حاضر هیچگونه op-op-- شامل این hook برای افزودن future اجازه می دهد.
        Ok(())
    }
}

/// قالب بندی فقط برای یک فریم از backtrace.
///
/// این نوع توسط تابع `BacktraceFmt::frame` ایجاد می شود.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// `BacktraceFrame` را با این قالب فریم چاپ می کند.
    ///
    /// با این کار همه نمونه های `BacktraceSymbol` در `BacktraceFrame` به صورت بازگشتی چاپ می شوند.
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// `BacktraceSymbol` را در داخل `BacktraceFrame` چاپ می کند.
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: این عالی نیست که ما در آخر چیزی چاپ نمی کنیم
            // با نام پرونده های غیر utf8.
            // خوشبختانه تقریباً همه چیز utf8 است بنابراین نباید خیلی بد باشد.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// `Frame` و `Symbol` ردیابی شده خام را چاپ می کند ، معمولاً از طریق بازخورد خام این crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// یک قاب خام به خروجی backtrace اضافه می کند.
    ///
    /// این روش ، برخلاف روش قبلی ، استدلالهای خام را در صورتی که از مکانهای مختلف منبع شده اند ، می گیرد.
    /// توجه داشته باشید که این ممکن است چندین بار برای یک فریم فراخوانی شود.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// یک قاب خام به خروجی backtrace اضافه می کند ، از جمله اطلاعات ستون.
    ///
    /// این روش ، مانند روش قبلی ، استدلال های خام را در صورتی که از مکان های مختلف منبع گرفته شده اند ، می گیرد.
    /// توجه داشته باشید که این ممکن است چندین بار برای یک فریم فراخوانی شود.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia قادر به نمادگذاری در یک فرآیند نیست بنابراین دارای قالب خاصی است که بعداً می تواند برای نماد سازی استفاده شود.
        // آن را به جای چاپ آدرس در قالب خود در اینجا چاپ کنید.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // نیازی به چاپ فریم های "null" نیست ، در واقع این بدان معناست که سیستم backtrace کمی مشتاقانه ردیابی بسیار دور بود.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // برای کاهش اندازه TCB در محوطه Sgx ، ما نمی خواهیم عملکرد وضوح نماد را پیاده سازی کنیم.
        // بلکه می توانیم افست آدرس را در اینجا چاپ کنیم ، که بعداً برای تصحیح عملکرد می تواند نگاشت شود.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // فهرست قاب و همچنین اشاره گر دستورالعمل اختیاری قاب را چاپ کنید.
        // اگر فراتر از نماد اول این قاب هستیم ، فقط فضای سفید مناسب را چاپ می کنیم.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // در مرحله بعدی نام نماد را بنویسید ، اگر اطلاعاتی کامل در صورت بازگشت به عقب داریم ، از قالب بندی جایگزین برای اطلاعات بیشتر استفاده کنید.
        // در اینجا ما نمادهایی را که نامی ندارند نیز مدیریت می کنیم ،
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // و آخر اینکه ، اگر شماره filename/line در دسترس است ، آنها را چاپ کنید.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line با نام نماد روی خطوط چاپ می شوند ، بنابراین فضای خالی مناسبی را چاپ کنید تا خودمان را مرتب کنیم.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // برای چاپ نام پرونده ، به تماس داخلی پاسخ دهید و سپس شماره خط را چاپ کنید.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // در صورت موجود بودن ، شماره ستون را اضافه کنید.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // ما فقط به اولین نماد یک قاب اهمیت می دهیم
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}