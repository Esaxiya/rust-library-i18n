// فقط در Linux در حال حاضر استفاده می شود ، بنابراین کد Dead را در جای دیگر مجاز بگذارید
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// یک تخصیص دهنده عرصه ساده برای بافرهای بایت.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// یک بافر را به اندازه مشخص شده اختصاص می دهد و یک ارجاع قابل تغییر به آن را برمی گرداند.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // ایمنی: این تنها عملکردی است که تاکنون یک mutable را ایجاد می کند
        // اشاره به `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // ایمنی: ما هرگز عناصر را از `self.buffers` حذف نمی کنیم ، بنابراین یک مرجع است
        // داده های داخل هر بافر تا زمانی که `self` زندگی می کند ، زندگی می کنند.
        &mut buffers[i]
    }
}