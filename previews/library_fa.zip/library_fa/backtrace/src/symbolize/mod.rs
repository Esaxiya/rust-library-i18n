use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// آدرس را به یک نماد حل کنید ، نماد را به بسته مشخص شده منتقل کنید.
///
/// این تابع آدرس داده شده را در مناطقی مانند جدول نمادهای محلی ، جدول نمادهای پویا یا اطلاعات اشکال زدایی DWARF جستجو می کند تا نمادهایی را برای عملکرد پیدا کند.
///
///
/// اگر رزولوشن انجام نشود ممکن است بسته نشود ، و همچنین در مورد توابع خط دار ممکن است بیش از یک بار فراخوانی شود.
///
/// نمادهای بازده نشان دهنده اجرا در `addr` مشخص شده است ، و جفت های file/line را برای آن آدرس برمی گرداند (در صورت موجود بودن).
///
/// توجه داشته باشید که اگر `Frame` دارید ، توصیه می شود از تابع `resolve_frame` به جای این مورد استفاده کنید.
///
/// # ویژگی های مورد نیاز
///
/// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
///
/// # Panics
///
/// این عملکرد سعی می کند هرگز panic را انجام ندهد ، اما اگر `cb` panics را ارائه دهد ، برخی از سیستم عامل ها panic دو برابر را مجبور به سقط جنین می کنند.
/// برخی از سیستم عامل ها از کتابخانه C استفاده می کنند که در داخل از بازگشتی استفاده می کند که از طریق آن قابل بازگرداندن نیست ، بنابراین وحشت از `cb` ممکن است منجر به سقط فرآیند شود.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // فقط به فریم بالایی نگاه کنید
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// یک قاب ضبط شده قبلی را به یک نماد حل کنید ، نماد را به بسته مشخص شده منتقل کنید.
///
/// این functin عملکرد مشابه `resolve` را انجام می دهد با این تفاوت که به جای آدرس `Frame` را به عنوان آرگومان در نظر می گیرد.
/// این می تواند به برخی از پیاده سازی های بستر معکوس امکان ارائه اطلاعات دقیق تر نماد یا اطلاعات مربوط به فریم های درون خطی را بدهد.
///
/// توصیه می شود اگر می توانید از این استفاده کنید.
///
/// # ویژگی های مورد نیاز
///
/// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
///
/// # Panics
///
/// این عملکرد سعی می کند هرگز panic را انجام ندهد ، اما اگر `cb` panics را ارائه دهد ، برخی از سیستم عامل ها panic دو برابر را مجبور به سقط جنین می کنند.
/// برخی از سیستم عامل ها از کتابخانه C استفاده می کنند که در داخل از بازگشتی استفاده می کند که از طریق آن قابل بازگرداندن نیست ، بنابراین وحشت از `cb` ممکن است منجر به سقط فرآیند شود.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // فقط به فریم بالایی نگاه کنید
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// مقادیر IP از فریم های پشته معمولاً (always?) دستورالعمل *پس از* فراخوانی است که ردیابی پشته واقعی است.
// نمادگذاری روی این باعث می شود که اگر عدد filename/line نزدیک به پایان کار باشد ، یک جلو باشد و شاید باطل شود.
//
// به نظر می رسد که این اساساً همیشه در همه سیستم عامل ها وجود دارد ، بنابراین ما همیشه یک ip را حل می کنیم تا آن را به دستورالعمل تماس قبلی حل کنیم به جای اینکه دستورالعمل به آن برگردانده شود.
//
//
// در حالت ایده آل ما این کار را نمی کنیم.
// در حالت ایده آل ، ما از تماس گیرنده های `resolve` API در اینجا می خواهیم که به صورت دستی -1 را انجام دهند و حساب کنند که آنها اطلاعات مکان را برای دستورالعمل *قبلی* نه فعلی می خواهند.
// در حالت ایده آل ، اگر واقعاً آدرس دستورالعمل بعدی یا جریان فعلی باشیم ، `Frame` را نیز نشان خواهیم داد.
//
// در حال حاضر اگرچه این یک نگرانی بسیار جالب است ، بنابراین ما فقط در داخل همیشه یکی را کم می کنیم.
// مصرف کنندگان باید به کار خود ادامه دهند و نتایج بسیار خوبی کسب کنند ، بنابراین باید به اندازه کافی خوب باشیم.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// همان `resolve` ، فقط ناامن و همزمان نیست.
///
/// این عملکرد ضمانت همگام سازی ندارد اما وقتی ویژگی `std` این crate در آن کامپایل نشده باشد ، در دسترس است.
/// برای مستندات و مثالهای بیشتر به عملکرد `resolve` مراجعه کنید.
///
/// # Panics
///
/// اطلاعات مربوط به `resolve` را برای هشدارهای ناشی از وحشت `cb` مشاهده کنید.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// همان `resolve_frame` ، فقط ناامن و همزمان نیست.
///
/// این عملکرد ضمانت همگام سازی ندارد اما وقتی ویژگی `std` این crate در آن کامپایل نشده باشد ، در دسترس است.
/// برای مستندات و مثالهای بیشتر به عملکرد `resolve_frame` مراجعه کنید.
///
/// # Panics
///
/// اطلاعات مربوط به `resolve_frame` را برای هشدارهای ناشی از وحشت `cb` مشاهده کنید.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait که وضوح نماد را در یک پرونده نشان می دهد.
///
/// این trait به عنوان یک شی trait در بسته شدن داده شده به عملکرد `backtrace::resolve` ارائه می شود ، و عملاً فرستاده می شود زیرا مشخص نیست کدام پشتوانه پشت آن است.
///
///
/// یک نماد می تواند اطلاعات متنی در مورد یک تابع ، به عنوان مثال نام ، نام پرونده ، شماره خط ، آدرس دقیق و غیره را ارائه دهد.
/// همه اطلاعات همیشه در یک نماد در دسترس نیستند ، بنابراین همه روش ها `Option` را برمی گردانند.
///
///
pub struct Symbol {
    // TODO: این محدوده مادام العمر باید در نهایت تا `Symbol` ادامه یابد ،
    // اما این در حال حاضر یک تغییر مهم است.
    // در حال حاضر این مورد ایمن است زیرا `Symbol` فقط با مرجع ارائه می شود و نمی تواند کلون شود.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// نام این عملکرد را برمی گرداند.
    ///
    /// از ساختار برگشتی می توان برای پرس و جو از خصوصیات مختلف در مورد نام نماد استفاده کرد:
    ///
    ///
    /// * اجرای `Display` نماد تغییر شکل یافته را چاپ می کند.
    /// * مقدار `str` خام نماد قابل دسترسی است (اگر utf-8 معتبر باشد).
    /// * بایت های خام نام نماد قابل دسترسی هستند.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// آدرس شروع این عملکرد را برمی گرداند.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// نام پرونده خام را به عنوان برش برمی گرداند.
    /// این امر عمدتا برای محیط های `no_std` مفید است.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// شماره ستون را برای محلی که این نماد در حال حاضر اجرا می کند برمی گرداند.
    ///
    /// فقط gimli در حال حاضر مقداری را در اینجا ارائه می دهد و حتی در این صورت فقط اگر `filename` `Some` را بازگرداند ، بنابراین در نتیجه مورد هشدارهای مشابه قرار می گیرد.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// شماره خط را برای محلی که این نماد در حال حاضر اجرا می کند برمی گرداند.
    ///
    /// این مقدار بازگشتی اگر `filename` `Some` را بازگرداند معمولاً `Some` است و در نتیجه مورد هشدارهای مشابه قرار می گیرد.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// نام پرونده را در جایی که این عملکرد تعریف شده است برمی گرداند.
    ///
    /// این در حال حاضر فقط در صورت استفاده از libbacktrace یا gimli در دسترس است (به عنوان مثال
    /// unix سیستم عامل های دیگر) و هنگامی که یک باینری با debuginfo کامپایل می شود.
    /// اگر هیچ یک از این شرایط برآورده نشود ، احتمالاً `None` برمی گردد.
    ///
    /// # ویژگی های مورد نیاز
    ///
    /// این عملکرد نیاز به ویژگی `std` `backtrace` crate دارد و ویژگی `std` به طور پیش فرض فعال است.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // اگر تجزیه نماد منگوله شده به دلیل شکست خوردن Rust ، ممکن است یک نماد C++ تجزیه شده باشد.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // حتماً این اندازه صفر را نگه دارید تا ویژگی `cpp_demangle` در هنگام غیرفعال شدن هیچ هزینه ای نداشته باشد.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// یک لفافه در اطراف یک نام نماد برای دستیابی ارگونومیک به نام تغییر شکل ، بایت خام ، رشته خام و غیره
///
// برای غیر فعال بودن ویژگی `cpp_demangle` ، کد مرده مجاز است.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// یک نام نماد جدید از بایت های اصلی خام ایجاد می کند.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// اگر نماد utf-8 معتبر باشد ، نام نماد (mangled) خام را به عنوان `str` برمی گرداند.
    ///
    /// اگر نسخه demangled را می خواهید از پیاده سازی `Display` استفاده کنید.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// نام نماد خام را به عنوان لیستی از بایت برمی گرداند
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // اگر نماد تغییر شکل داده شده در واقع معتبر نیست ، این ممکن است چاپ شود ، بنابراین با عدم انتشار خطا به بیرون ، این خطا را با نرمی کنترل کنید.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// سعی در بازیابی حافظه پنهان شده برای نشان دادن آدرس ها.
///
/// این روش تلاش می کند تا ساختارهای داده جهانی را که در غیر این صورت در سطح جهانی یا در رشته ذخیره شده اند و به طور معمول اطلاعات تجزیه شده DWARF یا موارد مشابه را نشان می دهد ، آزاد کند.
///
///
/// # Caveats
///
/// در حالی که این عملکرد همیشه در دسترس است ، اما در اکثر پیاده سازی ها هیچ کاری انجام نمی دهد.
/// کتابخانه هایی مانند dbghelp یا libbacktrace امکان تخصیص وضعیت و مدیریت حافظه اختصاص داده شده را ندارند.
/// در حال حاضر ویژگی `gimli-symbolize` این crate تنها ویژگی است که این عملکرد در آن تاثیری دارد.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}