//! استراتژی نماد سازی با استفاده از کد تجزیه DWARF در libbacktrace.
//!
//! کتابخانه libbacktrace C ، به طور معمول با gcc توزیع می شود ، نه تنها از ایجاد backtrace (که در واقع ما از آن استفاده نمی کنیم) پشتیبانی می کند بلکه از نماد backtrace و مدیریت اطلاعات اشکال زدایی کوتوله در مورد مواردی مانند قاب های خط خورده و موارد دیگر پشتیبانی نمی کند.
//!
//!
//! این به دلیل نگرانی های مختلف در اینجا نسبتاً پیچیده است ، اما ایده اصلی این است:
//!
//! * ابتدا `backtrace_syminfo` را صدا می کنیم.اگر می توانیم این اطلاعات را از جدول نمادهای پویا دریافت می کنیم.
//! * بعد ما `backtrace_pcinfo` را صدا می کنیم.در صورت موجود بودن جداول ، اشکال زدایی تجزیه می شود و به ما امکان می دهد اطلاعات مربوط به فریم های داخلی ، نام پرونده ها ، شماره های خط و غیره را بازیابی کنیم.
//!
//! ترفندهای زیادی در مورد جابجایی میزهای کوتوله به libbacktrace وجود دارد ، اما امیدوارم این پایان دنیا نباشد و هنگام خواندن مقاله به اندازه کافی واضح باشد.
//!
//! این استراتژی نماد پیش فرض برای سیستم عامل های غیر MSVC و غیر OSX است.در libstd این استراتژی پیش فرض برای OSX است.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // در صورت امکان نام `function` را که از debuginfo می آید و مثلاً برای فریم های درون خطی دقیق تر باشد ترجیح دهید.
                // اگر این مورد وجود ندارد ، به نام جدول نماد مشخص شده در `symname` بازگردید.
                //
                // توجه داشته باشید که گاهی اوقات `function` می تواند تا حدودی دقت کمتری داشته باشد ، به عنوان مثال در لیست `try<i32,closure>` جایگزین `std::panicking::try::do_call` ذکر شده است.
                //
                // واقعاً دلیل آن مشخص نیست ، اما به طور کلی نام `function` دقیق تر به نظر می رسد.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // فعلا کاری نکن
}

/// نوع نشانگر `data` به `syminfo_cb` منتقل می شود
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // هنگامی که این تماس از `backtrace_syminfo` فراخوانی می شود هنگامی که ما شروع به حل و فصل می کنیم ، بیشتر با `backtrace_pcinfo` تماس می گیریم.
    // عملکرد `backtrace_pcinfo` با اطلاعات اشکال زدایی روبرو می شود و سعی در انجام کارهایی مانند بازیابی اطلاعات file/line و همچنین فریم های خط دار دارد.
    // توجه داشته باشید که اگر اطلاعات رفع اشکال وجود نداشته باشد ، `backtrace_pcinfo` می تواند شکست بخورد یا کار زیادی انجام ندهد ، بنابراین اگر چنین اتفاقی بیفتد ، ما با حداقل یک نماد از `syminfo_cb` تماس خواهیم گرفت.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// نوع نشانگر `data` به `pcinfo_cb` منتقل می شود
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API از ایجاد دولت پشتیبانی می کند ، اما از تخریب دولت پشتیبانی نمی کند.
// من شخصاً منظورم این است که یک دولت برای ایجاد و سپس برای همیشه زندگی است.
//
// من دوست دارم یک کنترل کننده at_exit() ثبت کنم که این حالت را پاک می کند ، اما libbacktrace هیچ راهی برای انجام آن فراهم نمی کند.
//
// با استفاده از این محدودیت ها ، این تابع حالت استاتیک cached دارد که اولین بار درخواست آن محاسبه می شود.
//
// به یاد داشته باشید که بازگشت به عقب همه به صورت سریال (یک قفل جهانی) اتفاق می افتد.
//
// توجه داشته باشید که عدم همگام سازی در اینجا به دلیل همگام سازی خارجی `resolve` است.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // از قابلیت های threadsafe libbacktrace استفاده نکنید زیرا ما همیشه آن را به صورت هماهنگ صدا می کنیم.
        //
        0,
        error_cb,
        ptr::null_mut(), // بدون داده اضافی
    );

    return STATE;

    // توجه داشته باشید که برای اینکه libbacktrace به هیچ وجه کار نکند ، نیاز به یافتن اطلاعات اشکال زدایی DWARF برای موارد قابل اجرا دارد.این کار را معمولاً از طریق تعدادی مکانیزم انجام می دهد ، از جمله:
    //
    // * /proc/self/exe در سیستم عامل های پشتیبانی شده
    // * نام پرونده هنگام ایجاد حالت صریحاً به آن منتقل می شود
    //
    // کتابخانه libbacktrace یک مشت بزرگ از کد C است.این به طور طبیعی به معنای آسیب پذیری ایمنی حافظه است ، به ویژه هنگام کار با اشکال زدایی اشکال زدایی.
    // Libstd از نظر تاریخی با موارد زیادی روبرو بوده است.
    //
    // اگر از /proc/self/exe استفاده شود ، می توانیم به طور معمول این موارد را نادیده بگیریم ، زیرا فرض می کنیم libbacktrace "mostly correct" است و در غیر این صورت کارهای عجیب و غریب با اطلاعات اشکال زدایی کوتوله "attempted to be correct" انجام نمی دهد.
    //
    //
    // اگر یک نام پرونده را وارد کنیم ، در برخی از سیستم عامل ها (مانند BSD) این امکان وجود دارد که یک بازیگر مخرب باعث قرار گرفتن پرونده دلخواه در آن مکان شود.
    // این بدان معناست که اگر به libbacktrace در مورد یک نام فایل بگوییم ، ممکن است از یک پرونده دلخواه استفاده کند ، احتمالاً باعث ایجاد خطای شخصی می شود.
    // اگر ما به libbacktrace چیزی نگوییم ، آنگاه در سیستم عامل هایی که مسیرهایی مانند /proc/self/exe را پشتیبانی نمی کنند ، کاری از پیش نخواهد برد!
    //
    // با توجه به همه مواردی که ما سعی می کنیم تا جایی که ممکن است * یک نام پرونده را منتقل نکنیم ، اما باید در سیستم عامل هایی که به هیچ وجه از /proc/self/exe پشتیبانی نمی کنند استفاده کنیم.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // توجه داشته باشید که در حالت ایده آل ما از `std::env::current_exe` استفاده می کنیم ، اما نمی توانیم در اینجا به `std` نیاز داشته باشیم.
            //
            // از `_NSGetExecutablePath` برای بارگذاری مسیر اجرایی فعلی در یک منطقه ایستا استفاده کنید (که اگر خیلی کوچک است فقط انصراف دهید).
            //
            //
            // توجه داشته باشید که ما به طور جدی به libbacktrace در اینجا اعتماد داریم تا در اجرای اجرایی فاسد از بین نرویم ، اما مطمئناً اینگونه است ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows دارای یک حالت باز کردن پرونده ها است که پس از باز شدن نمی توان آن را حذف کرد.
            // این به طور کلی همان چیزی است که ما در اینجا می خواهیم زیرا ما می خواهیم اطمینان حاصل کنیم که اجرایی شدن ما از زیر ما تغییر نمی کند پس از آنکه آن را به libbacktrace تحویل دادیم ، امیدواریم که توانایی انتقال داده های دلخواه به libbacktrace (که ممکن است بدرفتاری انجام شود) را کاهش دهیم.
            //
            //
            // با توجه به اینکه ما در اینجا سعی می کنیم کمی رقص برقرار کنیم تا بتوانیم به نوعی قفل تصویر خود را بدست آوریم:
            //
            // * یک فرایند برای پردازش فعلی دریافت کنید ، نام پرونده آن را بارگیری کنید.
            // * پرونده ای را با پرچم های مناسب به آن نام پرونده باز کنید.
            // * نام فایل فرآیند فعلی را بارگیری کنید و مطمئن شوید که همان است
            //
            // اگر این همه تصویب شود ، ما در تئوری پرونده پرونده خود را باز کرده ایم و تضمین می کنیم تغییری نخواهد کرد.FWIW یک دسته از اینها به صورت تاریخی از libstd کپی شده است ، بنابراین این بهترین تفسیر من از آنچه اتفاق می افتد است.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // این در حافظه ایستا زندگی می کند تا بتوانیم آن را برگردانیم ..
                static mut BUF: [i8; N] = [0; N];
                // ... و این روی پشته زندگی می کند چون موقتی است
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // `handle` را عمداً در اینجا نشت کنید زیرا باز بودن آن باید قفل ما را در این نام پرونده حفظ کند.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // ما می خواهیم قطعه ای را که خنثی می شود برگردانیم ، بنابراین اگر همه چیز پر شده باشد و برابر با کل طول باشد ، آن را با شکست برابر کنیم.
                //
                //
                // در غیر این صورت هنگام بازگشت موفقیت اطمینان حاصل کنید که بایت صفر در برش موجود باشد.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // خطاهای backtrace در حال حاضر زیر فرش جارو می شوند
    let state = init_state();
    if state.is_null() {
        return;
    }

    // با `backtrace_syminfo` API تماس بگیرید (که (از خواندن کد) باید دقیقاً یک بار با `syminfo_cb` تماس بگیرد)(یا احتمالاً با خطا خراب شود).
    // سپس ما در `syminfo_cb` بیشتر کار می کنیم.
    //
    // توجه داشته باشید که ما این کار را انجام می دهیم زیرا `syminfo` با استفاده از جدول نمادها ، حتی در صورت عدم وجود اطلاعات اشکال زدایی در باینری ، نام نمادها را پیدا می کند.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}