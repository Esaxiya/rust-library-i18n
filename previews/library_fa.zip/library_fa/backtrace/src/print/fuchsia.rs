use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr بازخوانی دریافت می کند که برای هر DSO که به فرآیند مرتبط شده است ، یک نشانگر dl_phdr_info دریافت می کند.
    // dl_iterate_phdr همچنین قفل شدن پیوند دهنده پویا از ابتدا تا انتهای تکرار را تضمین می کند.
    // در صورت بازگشت مقدار غیر صفر ، تکرار زودهنگام خاتمه می یابد.
    // 'data' به عنوان سومین آرگومان برای پاسخ به تماس در هر تماس منتقل می شود.
    // 'size' اندازه dl_phdr_info را می دهد.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ما باید شناسه ساخت و برخی از داده های اصلی عنوان برنامه را تجزیه کنیم ، این بدان معناست که ما همچنین به اطلاعات کمی از مشخصات ELF نیز نیاز داریم.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// اکنون ما باید بیت به بیت ، ساختار نوع dl_phdr_info را که توسط لینک دهنده دینامیکی فعلی fuchsia استفاده می شود ، تکرار کنیم.
// Chromium همچنین دارای این مرز ABI و همچنین crashpad است.
// در نهایت ما می خواهیم این موارد را به استفاده از elf-search منتقل کنیم اما لازم است که این موارد را در SDK ارائه دهیم و این هنوز انجام نشده است.
//
// بنابراین ما (و آنها) مجبور به استفاده از این روش هستیم که یک اتصال فشرده با fuchsia libc ایجاد می کند.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // ما هیچ راهی برای دانستن معتبر بودن e_phoff و e_phnum نداریم.
    // libc باید این را برای ما تضمین کند ، بنابراین تشکیل یک قطعه در اینجا امن است.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr نشان دهنده یک سرآیند برنامه 64 بیتی ELF در پایان معماری هدف است.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr یک عنوان برنامه معتبر ELF و محتوای آن را نشان می دهد.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // ما هیچ راهی برای بررسی معتبر بودن p_addr یا p_memsz نداریم.
    // Fuchsia libc ابتدا یادداشت ها را تجزیه می کند ، اما بنابراین به موجب وجود این سرصفحه ها باید معتبر باشند.
    //
    // NoteIter نیازی به معتبر بودن داده های اساسی ندارد اما به معتبر بودن مرزها نیاز دارد.
    // ما اطمینان داریم که libc اطمینان حاصل کرده است که این مورد در اینجا وجود دارد.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// نوع یادداشت برای شناسه های ساخت.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr نشانگر یک سرصفحه یادداشت ELF در انتهای هدف است.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// یادداشت نشان یک یادداشت ELF (سرصفحه + مطالب) است.
// این نام به عنوان یک برش u8 باقی مانده است زیرا همیشه خنثی نمی شود و rust به راحتی می تواند بررسی کند که بایت ها به هر حال مطابقت دارند.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter به شما امکان می دهد با خیال راحت در یک بخش یادداشت تکرار کنید.
// به محض بروز خطا یا دیگر یادداشتها خاتمه می یابد.
// اگر بیش از داده های نامعتبر تکرار کنید ، عملکرد آن به گونه ای خواهد بود که گویی هیچ یادداشتی پیدا نشده است.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // این عملکرد بی تغییر است که نشانگر و اندازه داده شده نشان دهنده یک دامنه معتبر بایت است که همه آنها را می توان خواند.
    // محتوای این بایت ها می تواند هر چیزی باشد اما برای ایمن بودن این محدوده باید معتبر باشد.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to ترازوی 'x' به ترازوی بایت را فرض می کند 'to' قدرت 2 است.
// این از الگوی استانداردی در کد تجزیه C/C ++ ELF استفاده می کند که در آن از (x + به ، 1) و -to استفاده می شود.
// Rust به شما اجازه نمی دهد استفاده ما را نفی کنید بنابراین من استفاده می کنم
// تبدیل مکمل 2 برای بازآفرینی آن.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 تعداد بایت از قطعه را مصرف می کند (در صورت وجود) و علاوه بر این از برش صحیح قطعه نهایی اطمینان حاصل می کند.
// اگر تعداد بایت های درخواستی خیلی زیاد باشد یا بعداً به دلیل عدم باقی ماندن کافی بایت ها ، قطعه مجدداً قابل تنظیم نباشد ، هیچکدام بر نمی گردد و برش اصلاح نمی شود.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// این عملکرد هیچ تغییری واقعی ندارد که تماس گیرنده باید تأیید کند ، به غیر از اینکه 'bytes' برای عملکرد تراز باشد (و در مورد درستی برخی از معماری ها).
// مقادیر در قسمتهای Elf_Nhdr ممکن است مزخرف باشند اما این عملکرد اطمینان از چنین چیزی ندارد.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // این تا زمانی که فضای کافی وجود داشته باشد ایمن است و ما فقط تأیید کردیم که در عبارت if بالا بنابراین نباید ایمن باشد.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // توجه داشته باشید که sice_of: :<Elf_Nhdr>() همیشه 4 بایت تراز است.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // بررسی کنید آیا به پایان رسیده ایم یا نه.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // ما nhdr را تغییر شکل می دهیم اما ساختار بدست آمده را با دقت در نظر می گیریم.
        // ما به namesz یا descsz اعتماد نداریم و بر اساس نوع آن تصمیم غیر ایمنی نمی گیریم.
        //
        // بنابراین حتی اگر زباله های کامل را بیرون بیاوریم ، باز هم باید ایمن باشیم.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// نشان می دهد که یک قطعه قابل اجرا است.
const PERM_X: u32 = 0b00000001;
/// نشان می دهد که یک بخش قابل نوشتن است.
const PERM_W: u32 = 0b00000010;
/// نشان می دهد که یک بخش قابل خواندن است.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// در زمان اجرا یک بخش ELF را نشان می دهد.
struct Segment {
    /// محتوای این بخش آدرس مجازی زمان اجرا را می دهد.
    addr: usize,
    /// اندازه حافظه مطالب این بخش را می دهد.
    size: usize,
    /// آدرس مجازی این بخش را با پرونده ELF می دهد.
    mod_rel_addr: usize,
    /// مجوزهای موجود در پرونده ELF را می دهد.
    /// این مجوزها لزوماً مجوزهای موجود در زمان اجرا نیستند.
    flags: Perm,
}

/// اجازه می دهد تا یکی از بخشهای DSO تکرار شود.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ELF DSO (شی (پویا به اشتراک گذاشته شده) را نشان می دهد.
/// این نوع داده های ذخیره شده در DSO واقعی را به جای تهیه کپی خود ارجاع می دهد.
struct Dso<'a> {
    /// پیوند دهنده پویا همیشه یک نام به ما می دهد ، حتی اگر نام خالی باشد.
    /// در مورد اجرایی اصلی این نام خالی خواهد بود.
    /// در مورد یک شی مشترک ، این نام خانوادگی خواهد بود (به DT_SONAME مراجعه کنید).
    name: &'a str,
    /// در Fuchsia تقریباً همه باینری ها شناسه ساخت دارند اما این یک مورد سختگیرانه نیست.
    /// هیچ راهی برای مطابقت دادن اطلاعات DSO با یک فایل ELF واقعی وجود ندارد پس از آن اگر build_id وجود ندارد ، بنابراین ما نیاز داریم که هر DSO یکی در اینجا داشته باشد.
    ///
    /// DSO بدون build_id نادیده گرفته می شود.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// یک تکرار کننده را بر روی بخشهای موجود در این DSO برمی گرداند.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// این خطاها مواردی را که هنگام تجزیه و تحلیل اطلاعات مربوط به هر DSO به وجود می آید رمزگذاری می کنند.
///
enum Error {
    /// NameError به این معنی است که هنگام تبدیل رشته C به رشته rust خطایی رخ داده است.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError به این معنی است که ما شناسه ساخت پیدا نکردیم.
    /// این امر می تواند به این دلیل باشد که DSO فاقد شناسه ساخت است یا بدلیل ناقص بودن بخشی که حاوی شناسه ساخت است.
    ///
    BuildIDError,
}

/// برای هر DSO متصل به 'dso' یا 'error' توسط پیوند دهنده پویا.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter که یکی از روشهای خوردن به نام foreach DSO را خواهد داشت.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr اطمینان می دهد که info.name به مکانی معتبر اشاره خواهد کرد.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// این عملکرد علامت گذاری نماد Fuchsia را برای تمام اطلاعات موجود در DSO چاپ می کند.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}