//! ماژولی برای کمک به مدیریت اتصالات dbghelp در Windows
//!
//! Backtraces در Windows (حداقل برای MSVC) تا حد زیادی از طریق `dbghelp.dll` و عملکردهای مختلفی که در آن وجود دارد تأمین می شود.
//! این توابع در حال حاضر *به صورت پویا* بارگذاری می شوند تا اینکه از نظر آماری به `dbghelp.dll` پیوند دهند.
//! این کار در حال حاضر توسط کتابخانه استاندارد انجام می شود (و از نظر تئوری در آنجا لازم است) ، اما تلاشی است برای کمک به کاهش وابستگی DL الکتریکی ساکن به یک کتابخانه ، زیرا بک گراندها معمولاً بسیار اختیاری هستند.
//!
//! همانطور که گفته شد ، `dbghelp.dll` تقریباً همیشه با موفقیت روی Windows بارگیری می شود.
//!
//! توجه داشته باشید که از آنجا که تمام این پشتیبانی را به صورت پویا بارگیری می کنیم ، نمی توانیم از تعاریف خام در `winapi` استفاده کنیم ، بلکه باید نوع نشانگر عملکرد را خودمان تعریف کنیم و از آن استفاده کنیم.
//! ما واقعاً نمی خواهیم درگیر کار تکثیر ویناپی باشیم ، بنابراین ما یک ویژگی Cargo `verify-winapi` داریم که ادعا می کند همه اتصالات با آنهایی که در ویناپی هستند مطابقت دارد و این ویژگی در CI فعال است.
//!
//! سرانجام ، در اینجا توجه خواهید کرد که dll برای `dbghelp.dll` هرگز بارگیری نمی شود و این در حال حاضر عمدی است.
//! فکر این است که می توانیم از آن در حافظه پنهان جهانی استفاده کنیم و از آن در میان تماس های API استفاده کنیم و از loads/unloads گران قیمت جلوگیری کنیم.
//! اگر این مشکلی برای آشکارسازهای نشت یا مواردی از این قبیل باشد ، می توانیم هنگام رسیدن به آنجا از روی پل عبور کنیم.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// در اطراف `SymGetOptions` و `SymSetOptions` کار کنید و در خود winapi وجود نداشته باشد.
// در غیر اینصورت این تنها در مواردی استفاده می شود که ما درمورد Winapi انواع را بررسی کنیم.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // هنوز در ویناپی تعریف نشده است
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // این در winapi تعریف شده است ، اما نادرست است (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // هنوز در ویناپی تعریف نشده است
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// این ماکرو برای تعریف ساختار `Dbghelp` استفاده می شود که شامل کلیه نشانگرهای عملکردی است که ممکن است بارگیری کنیم.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// DLL بارگیری شده برای `dbghelp.dll`
            dll: HMODULE,

            // هر نشانگر عملکرد برای هر عملکردی که ممکن است استفاده کنیم
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // در ابتدا ما DLL را بارگیری نکردیم
            dll: 0 as *mut _,
            // ابتدا همه عملکردها روی صفر تنظیم می شوند تا بگویند که باید به صورت پویا بارگیری شوند.
            //
            $($name: 0,)*
        };

        // typedef راحتی برای هر نوع عملکرد.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// تلاش برای باز کردن `dbghelp.dll`.
            /// در صورت موفقیت یا عدم موفقیت `LoadLibraryW` ، موفقیت را برمی گرداند.
            ///
            /// اگر کتابخانه از قبل بارگیری شده است ، Panics است.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // تابعی برای هر روشی که می خواهیم استفاده کنیم.
            // وقتی فراخوانی شد ، نشانگر عملکرد حافظه پنهان را خوانده یا آن را بارگیری می کند و مقدار بارگذاری شده را برمی گرداند.
            // بارها برای موفقیت ادعا می شوند.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // پروکسی راحتی برای استفاده از قفل های پاکسازی برای ارجاع به توابع dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// تمام پشتیبانی لازم برای دسترسی به توابع `dbghelp` API را از این crate آغاز کنید.
///
///
/// توجه داشته باشید که این عملکرد **ایمن است**، در داخل همگام سازی خاص خود را دارد.
/// همچنین توجه داشته باشید که فراخوانی چند باره ای این عملکرد به صورت بازگشتی بی خطر است.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // اولین کاری که باید انجام دهیم همگام سازی این عملکرد است.این را می توان همزمان از رشته های دیگر یا به صورت بازگشتی در یک موضوع فراخوانی کرد.
        // توجه داشته باشید که پیچیده تر از آن است ، زیرا آنچه ما در اینجا استفاده می کنیم ، `dbghelp` ،*همچنین* در این فرآیند باید با تمام تماس گیرندگان دیگر به `dbghelp` هماهنگ شود.
        //
        // معمولاً در همان فرآیند تماسهای زیادی با `dbghelp` وجود ندارد و احتمالاً با اطمینان می توانیم فرض کنیم که تنها ما هستیم که به آن دسترسی داریم.
        // با این حال ، یک کاربر اصلی دیگر وجود دارد که باید نگران آن باشیم که از قضا خود ماست ، اما در کتابخانه استاندارد است.
        // کتابخانه استاندارد Rust برای پشتیبانی backtrace به این crate بستگی دارد و این crate در crates.io نیز وجود دارد.
        // این بدان معناست که اگر کتابخانه استاندارد در حال چاپ یک backtrace panic است ، ممکن است با این crate که از crates.io می آید رقابت کند و باعث ایجاد چندین قفل شود.
        //
        // برای کمک به حل این مشکل همگام سازی ، ما در اینجا یک ترفند مخصوص ویندوز به کار می بریم (به هر حال ، محدودیت مخصوص ویندوز در مورد همگام سازی است).
        // ما یک *session-local* به نام mutex ایجاد می کنیم تا از این تماس محافظت کنیم.
        // هدف در اینجا این است که کتابخانه استاندارد و این crate مجبور نیستند API های سطح Rust را برای همگام سازی در اینجا به اشتراک بگذارند اما می توانند در پشت صحنه کار کنند تا مطمئن شوند که با یکدیگر همگام سازی می شوند.
        //
        // به این ترتیب وقتی این تابع از طریق کتابخانه استاندارد یا از طریق crates.io فراخوانی می شود ، می توان اطمینان حاصل کرد که همان mutex بدست آمده است.
        //
        // بنابراین همه اینها این است که بگوییم اولین کاری که ما در اینجا انجام می دهیم این است که ما از نظر اتمی یک `HANDLE` ایجاد می کنیم که یک Mutex نامگذاری شده در Windows است.
        // ما مقداری را با سایر رشته های مشترک این تابع هماهنگ می کنیم و اطمینان حاصل می کنیم که فقط یک دسته به عنوان نمونه از این عملکرد ایجاد شده است.
        // توجه داشته باشید که دستگیره هرگز بسته نشود در گلوبال ذخیره شود.
        //
        // پس از اینکه قفل را واقعاً استفاده کردیم ، به سادگی آن را بدست آوردیم و دستگیره `Init` که از دست ما خارج می شود ، مسئول افتادن آن خواهد بود.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // خوب ، پیه!اکنون که همه ما با خیال راحت هماهنگ شده ایم ، بیایید در واقع پردازش همه موارد را شروع کنیم.
        // ابتدا باید اطمینان حاصل کنیم که `dbghelp.dll` در این فرآیند بارگذاری شده است.
        // ما این کار را به صورت پویا انجام می دهیم تا از وابستگی ایستا جلوگیری کنیم.
        // این کار از نظر تاریخی برای کار کردن درمورد پیوندهای عجیب و غریب انجام می شده است و هدف آن این است که باینری ها را کمی قابل حمل تر کند زیرا این فقط یک ابزار رفع اشکال است.
        //
        //
        // پس از باز کردن `dbghelp.dll` ، باید برخی از توابع مقدار دهی اولیه را در آن فراخوانی کنیم ، که در زیر بیشتر توضیح داده شده است
        // هرچند ، ما فقط یکبار این کار را انجام می دهیم ، بنابراین یک بول جهانی داریم که نشان می دهد هنوز کار ما تمام شده است یا خیر.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // از تنظیم پرچم `SYMOPT_DEFERRED_LOADS` اطمینان حاصل کنید ، زیرا طبق اسناد خود MSVC در این مورد: "This is the fastest, most efficient way to use the symbol handler." ، پس اجازه دهید این کار را انجام دهیم!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // در واقع نمادها را با MSVC مقداردهی اولیه کنید.توجه داشته باشید که این ممکن است شکست بخورد ، اما ما آن را نادیده می گیریم.
        // به خودی خود یک تن از هنرهای قبلی وجود ندارد ، اما به نظر می رسد LLVM در اینجا مقدار برگشتی را نادیده می گیرد و اگر یکی از کتابخانه های ضدعفونی کننده در LLVM هشدار ترسناکی را چاپ می کند در صورت عدم موفقیت ، اما اساساً آن را در طولانی مدت نادیده می گیرد.
        //
        //
        // یک موردی که این مورد برای Rust زیاد به چشم می خورد این است که کتابخانه استاندارد و این crate در crates.io هر دو می خواهند برای `SymInitializeW` رقابت کنند.
        // کتابخانه استاندارد از نظر تاریخی بیشتر اوقات تمایل به پاک سازی داشت ، اما اکنون که از این crate استفاده می کند ، به این معنی است که کسی ابتدا به مقداردهی اولیه می رسد و دیگری آن مقدار اولیه را می گیرد.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}