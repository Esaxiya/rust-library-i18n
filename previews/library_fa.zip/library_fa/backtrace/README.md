# backtrace-rs

[Documentation](https://docs.rs/backtrace)

کتابخانه ای برای به دست آوردن عودت معکوس در زمان اجرا برای Rust.
این کتابخانه قصد دارد با ارائه یک رابط برنامه نویسی برای کار ، پشتیبانی از کتابخانه استاندارد را افزایش دهد ، اما همچنین به راحتی از چاپ عقب مانده فعلی مانند libstd's panics پشتیبانی می کند.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

برای به سادگی گرفتن یک backtrace و به تعویق انداختن کار با آن تا زمانی دیگر ، می توانید از نوع سطح بالای `Backtrace` استفاده کنید.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

اگر می خواهید دسترسی خام بیشتری به قابلیت ردیابی واقعی داشته باشید ، می توانید مستقیماً از توابع `trace` و `resolve` استفاده کنید.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // این نشانگر دستورالعمل را به یک نام نماد حل کنید
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ادامه رفتن به کادر بعدی
    });
}
```

# License

این پروژه تحت هر یک مجوز دارد

 * مجوز Apache ، نسخه 2.0 ، ([LICENSE-APACHE](LICENSE-APACHE) یا http://www.apache.org/licenses/LICENSE-2.0)
 * مجوز MIT ([LICENSE-MIT](LICENSE-MIT) یا http://opensource.org/licenses/MIT)

به انتخاب شما

### Contribution

تا زمانی که صریحاً خلاف آن را بیان نکنید ، هرگونه سهمی که از طرف شما برای درج در backtrace-rs ارائه شده است ، همانطور که در مجوز Apache-2.0 تعریف شده است ، بدون هیچ گونه شرایط و ضوابط دیگری دارای مجوز دوگانه خواهد بود.







