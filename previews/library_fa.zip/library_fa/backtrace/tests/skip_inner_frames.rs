use backtrace::Backtrace;

// این آزمون فقط در سیستم عامل هایی است که عملکرد `symbol_address` فعال برای فریم هایی دارند که آدرس شروع یک نماد را گزارش می دهند.
// در نتیجه فقط در چند سیستم عامل فعال می شود.
//
const ENABLED: bool = cfg!(all(
    // Windows واقعاً آزمایش نشده است و OSX واقعاً یافتن یک قاب محصور را پشتیبانی نمی کند ، بنابراین این کار را غیرفعال کنید
    //
    target_os = "linux",
    // با استفاده از ARM ، یافتن عملکرد محصور کننده به سادگی بازگشت ip به خودی خود است.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}