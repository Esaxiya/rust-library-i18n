use backtrace::Frame;
use std::thread;

// منطق تدوین مشروط را در انتهای src/symbolize/mod.rs منعکس می کند
static NOOP: bool = false;
static DBGHELP: bool = !NOOP
    && cfg!(all(
        windows,
        target_env = "msvc",
        not(target_vendor = "uwp")
    ));
static LIBBACKTRACE: bool = !NOOP
    && !DBGHELP
    && cfg!(all(
        feature = "libbacktrace",
        any(
            unix,
            all(windows, not(target_vendor = "uwp"), target_env = "gnu")
        ),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ));
static GIMLI_SYMBOLIZE: bool = !NOOP
    && !DBGHELP
    && !LIBBACKTRACE
    && cfg!(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ));
static MIRI_SYMBOLIZE: bool = cfg!(miri);

#[test]
// FIXME: نباید این تست را در i686-msvc نادیده بگیرید ، مطمئن نیستید که چرا با شکست روبرو می شود
#[cfg_attr(all(target_arch = "x86", target_env = "msvc"), ignore)]
#[rustfmt::skip] // ما در اینجا به شماره خط اهمیت می دهیم
fn smoke_test_frames() {
    frame_1(line!());
    #[inline(never)] fn frame_1(start_line: u32) { frame_2(start_line) }
    #[inline(never)] fn frame_2(start_line: u32) { frame_3(start_line) }
    #[inline(never)] fn frame_3(start_line: u32) { frame_4(start_line) }
    #[inline(never)] fn frame_4(start_line: u32) {
        let mut v = Vec::new();
        backtrace::trace(|cx| {
            v.push(cx.clone());
            true
        });

        // سیستم عامل های مختلف عجیب و غریب های مختلفی در مورد عقبگردهای خود دارند.
        // برای پیدا کردن یک نقطه شروع خوب ، بیایید در قاب ها جستجو کنیم
        //
        let target = frame_4 as usize;
        let offset = v
            .iter()
            .map(|frame| frame.symbol_address() as usize)
            .enumerate()
            .filter_map(|(i, sym)| {
                if sym >= target {
                    Some((sym, i))
                } else {
                    None
                }
            })
            .min()
            .unwrap()
            .1;
        let mut frames = v[offset..].iter();

        assert_frame(
            frames.next().unwrap(),
            frame_4 as usize,
            "frame_4",
            "tests/smoke.rs",
            start_line + 6,
            9,
        );
        assert_frame(
            frames.next().unwrap(),
            frame_3 as usize,
            "frame_3",
            "tests/smoke.rs",
            start_line + 3,
            52,
        );
        assert_frame(
            frames.next().unwrap(),
            frame_2 as usize,
            "frame_2",
            "tests/smoke.rs",
            start_line + 2,
            52,
        );
        assert_frame(
            frames.next().unwrap(),
            frame_1 as usize,
            "frame_1",
            "tests/smoke.rs",
            start_line + 1,
            52,
        );
        assert_frame(
            frames.next().unwrap(),
            smoke_test_frames as usize,
            "smoke_test_frames",
            "",
            0,
            0,
        );
    }

    fn assert_frame(
        frame: &Frame,
        actual_fn_pointer: usize,
        expected_name: &str,
        expected_file: &str,
        expected_line: u32,
        expected_col: u32,
    ) {
        backtrace::resolve_frame(frame, |sym| {
            print!("symbol  ip:{:?} address:{:?} ", frame.ip(), frame.symbol_address());
            if let Some(name) = sym.name() {
                print!("name:{} ", name);
            }
            if let Some(file) = sym.filename() {
                print!("file:{} ", file.display());
            }
            if let Some(lineno) = sym.lineno() {
                print!("lineno:{} ", lineno);
            }
            if let Some(colno) = sym.colno() {
                print!("colno:{} ", colno);
            }
            println!();
        });

        let ip = frame.ip() as usize;
        let sym = frame.symbol_address() as usize;
        assert!(ip >= sym);
        assert!(
            sym >= actual_fn_pointer,
            "{:?} < {:?} ({} {}:{}:{})",
            sym as *const usize,
            actual_fn_pointer as *const usize,
            expected_name,
            expected_file,
            expected_line,
            expected_col,
        );

        // windows dbghelp در بسیاری از گزارشات خود اکنون *کاملاً* لیبرال (و اشتباه) است ...
        //
        //
        // این ادعا همچنین می تواند برای ساخت نسخه ها با شکست مواجه شود ، بنابراین از آنجا صرف نظر کنید
        if cfg!(debug_assertions) {
            assert!(sym - actual_fn_pointer < 1024);
        }

        let mut resolved = 0;
        let can_resolve = LIBBACKTRACE || GIMLI_SYMBOLIZE || MIRI_SYMBOLIZE;
        let can_resolve_cols = GIMLI_SYMBOLIZE || MIRI_SYMBOLIZE;

        let mut name = None;
        let mut addr = None;
        let mut col  = None;
        let mut line = None;
        let mut file = None;
        backtrace::resolve_frame(frame, |sym| {
            resolved += 1;
            name = sym.name().map(|v| v.to_string());
            addr = sym.addr();
            col  = sym.colno();
            line = sym.lineno();
            file = sym.filename().map(|v| v.to_path_buf());
        });

        // dbghelp همیشه نمادها را حل نمی کند
        match resolved {
            0 => return assert!(!can_resolve),
            _ => {}
        }

        if can_resolve {
            let name = name.expect("didn't find a name");

            // در حالت انتشار حالت نام ها عجیب هستند زیرا توابع می توانند با `mergefunc` ادغام شوند ، بنابراین این را فقط در حالت اشکال زدایی مطرح کنید
            //
            if cfg!(debug_assertions) {
                assert!(
                    name.contains(expected_name),
                    "didn't find `{}` in `{}`",
                    expected_name,
                    name
                );
            }
        }

        if can_resolve {
            addr.expect("didn't find a symbol");
        }

        if cfg!(debug_assertions) {
            let line = line.expect("didn't find a line number");
            let file = file.expect("didn't find a line number");
            if !expected_file.is_empty() {
                assert!(
                    file.ends_with(expected_file),
                    "{:?} didn't end with {:?}",
                    file,
                    expected_file
                );
            }
            if expected_line != 0 {
                assert!(
                    line == expected_line,
                    "bad line number on frame for `{}`: {} != {}",
                    expected_name,
                    line,
                    expected_line
                );
            }
            if can_resolve_cols {
                let col = col.expect("didn't find a column number");
                if expected_col != 0 {
                    assert!(
                        col == expected_col,
                        "bad column number on frame for `{}`: {} != {}",
                        expected_name,
                        col,
                        expected_col
                    );
                }
            }
        }
    }
}

#[test]
fn many_threads() {
    let threads = (0..16)
        .map(|_| {
            thread::spawn(|| {
                for _ in 0..16 {
                    backtrace::trace(|frame| {
                        backtrace::resolve(frame.ip(), |symbol| {
                            let _s = symbol.name().map(|s| s.to_string());
                        });
                        true
                    });
                }
            })
        })
        .collect::<Vec<_>>();

    for t in threads {
        t.join().unwrap()
    }
}

#[test]
#[cfg(feature = "rustc-serialize")]
fn is_rustc_serialize() {
    extern crate rustc_serialize;

    fn is_encode<T: rustc_serialize::Encodable>() {}
    fn is_decode<T: rustc_serialize::Decodable>() {}

    is_encode::<backtrace::Backtrace>();
    is_decode::<backtrace::Backtrace>();
}

#[test]
#[cfg(feature = "serde")]
fn is_serde() {
    extern crate serde;

    fn is_serialize<T: serde::ser::Serialize>() {}
    fn is_deserialize<T: serde::de::DeserializeOwned>() {}

    is_serialize::<backtrace::Backtrace>();
    is_deserialize::<backtrace::Backtrace>();
}

#[test]
fn sp_smoke_test() {
    let mut refs = vec![];
    recursive_stack_references(&mut refs);
    return;

    #[inline(never)]
    fn recursive_stack_references(refs: &mut Vec<usize>) {
        assert!(refs.len() < 5);

        let x = refs.len();
        refs.push(&x as *const _ as usize);

        if refs.len() < 5 {
            recursive_stack_references(refs);
            eprintln!("exiting: {}", x);
            return;
        }

        backtrace::trace(make_trace_closure(refs));
        eprintln!("exiting: {}", x);
    }

    // NB: توابع `make_*` زیر به جای اینکه از خط خارج شوند ، خارج می شوند
    // نتایج خود را به عنوان بسته شدن خطی در سایت های تماس خود تعریف کنید ، به طوری که بسته شدن نتیجه "recursive_stack_references" در نام منگوله شده خود نداشته باشد.
    //
    //

    fn make_trace_closure<'a>(
        refs: &'a mut Vec<usize>,
    ) -> impl FnMut(&backtrace::Frame) -> bool + 'a {
        let mut child_sp = None;
        let mut child_ref = None;
        move |frame| {
            eprintln!("\n=== frame ===================================");

            let mut is_recursive_stack_references = false;
            backtrace::resolve(frame.ip(), |sym| {
                is_recursive_stack_references |= (LIBBACKTRACE || GIMLI_SYMBOLIZE)
                    && sym
                        .name()
                        .and_then(|name| name.as_str())
                        .map_or(false, |name| {
                            eprintln!("name = {}", name);
                            name.contains("recursive_stack_references")
                        })
            });

            let sp = frame.sp() as usize;
            eprintln!("sp  = {:p}", sp as *const u8);
            if sp == 0 {
                // اگر SP خنثی است ، بنابراین ما برای دستیابی به SP روی این هدف عملی نداریم.
                // فقط به راه رفتن روی پشته ادامه دهید ، اما ادعاهای ما را در مورد نشانگرهای روی پشته و مقادیر SP انجام ندهید.
                //
                //
                return true;
            }

            // پشته رشد می کند.
            if let Some(child_sp) = child_sp {
                assert!(child_sp <= sp);
            }

            if is_recursive_stack_references {
                let r = refs.pop().unwrap();
                eprintln!("ref = {:p}", r as *const u8);
                if sp != 0 {
                    assert!(r > sp);
                    if let Some(child_ref) = child_ref {
                        assert!(sp >= child_ref);
                    }
                }
                child_ref = Some(r);
            }

            child_sp = Some(sp);
            true
        }
    }
}