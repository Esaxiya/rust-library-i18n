//! پیاده سازی panics با پشتیبانی libgcc/libunwind (به نوعی).
//!
//! برای پس زمینه مربوط به موارد استثنایی و باز کردن پشته لطفا به "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) و اسناد مرتبط با آن مراجعه کنید.
//! اینها همچنین خواندنیهای خوبی هستند:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## خلاصه ای کوتاه
//!
//! مدیریت استثناها در دو مرحله اتفاق می افتد: یک مرحله جستجو و یک مرحله تمیز کردن.
//!
//! در هر دو مرحله ، با استفاده از اطلاعات موجود در قاب پشته ، بخشهایی از ماژولهای فرآیند فعلی را باز می کند (بخش "module" در اینجا به یک ماژول سیستم عامل ، یعنی یک کتابخانه اجرایی یا یک کتابخانه پویا اشاره دارد).
//!
//!
//! برای هر قاب پشته ، "personality routine" مرتبط را فراخوانی می کند ، آدرس آن نیز در بخش اطلاعات باز کردن ذخیره می شود.
//!
//! در مرحله جستجو ، کار یک روال شخصیتی این است که شی object استثنایی که پرتاب می شود را بررسی کند و تصمیم بگیرد که آیا باید در آن قاب پشته گرفتار شود.پس از شناسایی قاب کنترل کننده ، مرحله پاکسازی آغاز می شود.
//!
//! در مرحله پاکسازی ، حلقه بازگرداندن هر روال شخصیتی دوباره انجام می شود.
//! این بار تصمیم می گیرد کد کد پاکیزگی (در صورت وجود) برای قاب پشته فعلی باید اجرا شود.در این صورت ، کنترل به یک branch مخصوص در بدنه عملکرد ، "landing pad" منتقل می شود که مخرب ها را فراخوانی می کند ، حافظه را آزاد می کند و غیره.
//! در انتهای بالشتک فرود ، کنترل دوباره به رزومه های غیرمجاز و بازکننده منتقل می شود.
//!
//! هنگامی که پشته تا سطح قاب کنترل کننده باز شد ، باز کردن حالت متوقف می شود و آخرین شخصیت معمول کنترل را به بلوک گیرنده منتقل می کند.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// شناسه کلاس استثنائی Rust.
// این امر توسط روال های شخصیتی برای تعیین اینکه آیا استثنا توسط زمان کار خود آنها ایجاد شده است ، استفاده می شود.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-فروشنده ، زبان
    0x4d4f5a_00_52555354
}

// شناسه های ثبت نام از LLVM's TargetLowering::getExceptionPointerRegister() و TargetLowering::getExceptionSelectorRegister() برای هر معماری برداشته شدند ، سپس از طریق جداول تعریف ثبت (به طور معمول به شماره های ثبت DWARF نگاشت می شوند)<arch>RegisterInfo.td ، "DwarfRegNum" را جستجو کنید).
//
// به http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register نیز مراجعه کنید.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX ، EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX ، RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0 ، X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3 ، X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// کد زیر براساس روال شخصیت C و C++ GCC است.برای مرجع ، مراجعه کنید به:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM روال شخصیت EHABI.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS به جای آن از روال پیش فرض استفاده می کند زیرا از خاموش کردن SjLj استفاده می کند.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // عکسهای برگشتی در ARM شخصیت فرد را با وضعیت معمول صدا می کنند==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // در این موارد ، ما می خواهیم به باز کردن پشته ادامه دهیم ، در غیر این صورت همه کارهای بازگشتی ما به __ اعتماد_پایان پایان می یابد
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // DWARF لغو فرض می کند که _شکل_پیچ کردن_کونتکست مواردی مانند عملکرد و نشانگرهای LSDA را در خود نگه می دارد ، اما ARM EHABI آنها را در شی exception استثنا قرار می دهد.
            // برای حفظ امضاهای عملکردهایی مانند _Unwind_GetLanguageSpecificData() ، که فقط نشانگر زمینه را می گیرند ، روال های شخصیت GCC با استفاده از موقعیت مکانی که برای ARM "scratch register" (r12) اختصاص داده شده است ، یک نشانگر را به استثنای_موضوع در متن ذخیره می کند.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... یک رویکرد اصولی تر ارائه کامل تعریف ARM's_Anwind_Context در صحافی libunwind ماست و با دور زدن توابع سازگاری DWARF ، داده های مورد نیاز را مستقیماً از آنجا واکشی می کنیم.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI برای بروزرسانی مقدار SP در حافظه پنهان شی of استثنا به روال شخصیتی نیاز دارد.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // در ARM EHABI ، روال شخصیتی وظیفه دارد که در واقع قبل از بازگشت یک قاب پشته را باز کند (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // در libgcc تعریف شده است
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // روال شخصیتی پیش فرض ، که مستقیماً در بیشتر اهداف و به طور غیر مستقیم در Windows x86_64 از طریق SEH استفاده می شود.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // در اهداف x86_64 MinGW ، سازوکار باز کردن آن SEH است ، با این وجود داده های کنترل کننده باز (با نام مستعار LSDA) از رمزگذاری سازگار با GCC استفاده می کنند.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // روال شخصیت در بیشتر اهداف ما.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // آدرس برگشت 1 بایت از دستورالعمل تماس گرفته شده است که می تواند در محدوده IP بعدی در جدول محدوده LSDA باشد.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// قاب ثبت اطلاعات را باز کنید
//
// تصویر هر ماژول شامل یک بخش اطلاعاتی برای باز کردن قاب (معمولاً ".eh_frame") است.هنگامی که یک ماژول loaded/unloaded در حال پردازش است ، باید از مکان قرارگیری این بخش در حافظه مطلع شود.روش های دستیابی به آن از نظر سیستم عامل متفاوت است.
// در بعضی از موارد (به عنوان مثال ، Linux) ، حالت لغو کننده می تواند به تنهایی بخشهای اطلاعات را باز کند (با شمارش پویا ماژول های بارگیری شده فعلی از طریق dl_iterate_phdr() API and finding their ".eh_frame" sections) ؛ برخی دیگر ، مانند Windows ، به ماژول ها احتیاج دارند تا به طور فعال بخش های اطلاعات ناخواسته خود را از طریق API بازپرداخت ثبت کنند.
//
//
// این ماژول دو علامت را مشخص می کند که برای ثبت اطلاعات ما در زمان اجرا GCC از rsbegin.rs به آنها ارجاع داده می شود و آنها فراخوانی می شوند.
// اجرای خاموش کردن پشته (در حال حاضر) به libgcc_eh موکول شده است ، با این وجود Rust crates از این نقاط ورودی خاص Rust استفاده می کند تا از درگیری احتمالی با هر زمان اجرای GCC جلوگیری کند.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}