//! Windows SEH
//!
//! در Windows (در حال حاضر فقط در MSVC) ، مکانیزم پیش فرض کنترل استثنا Structured Exception Handling (SEH) است.
//! این از نظر استثنائات مبتنی بر کوتوله (مثلاً سایر پلتفرم های unix که از آن استفاده می کنند) از نظر داخلی کامپایلر کاملاً متفاوت است ، بنابراین LLVM باید پشتیبانی اضافی زیادی از SEH داشته باشد.
//!
//! به طور خلاصه ، آنچه در اینجا اتفاق می افتد:
//!
//! 1. عملکرد `panic` عملکرد استاندارد Windows `_CxxThrowException` را فراخوانی می کند تا ++ C را ایجاد کند-مانند یک استثنا ، فرآیند باز کردن را آغاز می کند.
//! 2.
//! تمام صفحه های فرود تولید شده توسط کامپایلر از عملکرد شخصیت `__CxxFrameHandler3` ، یک تابع در CRT استفاده می کنند و کد باز کردن آن در Windows ، از این عملکرد شخصیتی برای اجرای همه کد های پاکسازی روی پشته استفاده می کند.
//!
//! 3. تمام تماس های تولید شده توسط کامپایلر به `invoke` دارای یک پد فرود است که به عنوان دستورالعمل `cleanuppad` LLVM تنظیم شده است ، که نشان دهنده شروع روال پاکسازی است.
//! شخصیت (در مرحله 2 ، تعریف شده در CRT) وظیفه اجرای روال های پاکسازی را بر عهده دارد.
//! 4. در نهایت کد "catch" در `try` ذاتی (تولید شده توسط کامپایلر) اجرا می شود و نشان می دهد که کنترل باید به Rust برگردد.
//! این کار از طریق دستورالعمل `catchswitch` به علاوه `catchpad` با اصطلاحات LLVM IR انجام می شود و در نهایت با دستورالعمل `catchret` کنترل عادی به برنامه برمی گردد.
//!
//! برخی از تفاوت های خاص از مدیریت استثنای مبتنی بر gcc عبارتند از:
//!
//! * Rust هیچ عملکرد شخصیتی سفارشی ندارد ، در عوض *همیشه*`__CxxFrameHandler3` است.علاوه بر این ، هیچ فیلتر اضافی انجام نمی شود ، بنابراین در نهایت می توانیم هر استثنای C++ را که اتفاقاً شبیه نوعی است که پرتاب می کنیم ، بگیریم.
//! توجه داشته باشید که به هر حال انداختن یک استثنا به Rust یک رفتار تعریف نشده است ، بنابراین این باید خوب باشد.
//! * ما برخی از داده ها را برای انتقال در مرزهای پیچشی ، به ویژه `Box<dyn Any + Send>` در اختیار داریم.مانند استثنائات کوتوله ، این دو نشانگر به عنوان یک محموله در استثنا ذخیره می شوند.
//! با این حال ، در MSVC نیازی به تخصیص پشته اضافی نیست زیرا پشته تماس در هنگام اجرای توابع فیلتر حفظ می شود.
//! این بدان معنی است که اشاره گرها مستقیماً به `_CxxThrowException` منتقل می شوند و سپس در عملکرد فیلتر بازیابی می شوند تا در قاب پشته `try` ذاتی نوشته شوند.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // این باید یک گزینه باشد زیرا ما با استفاده از مرجع استثنا را می گیریم و تخریب کننده آن با زمان اجرا C++ اجرا می شود.
    // وقتی جعبه را از استثنا خارج می کنیم ، باید استثنا را در حالت معتبر بگذاریم تا تخریب کننده آن بدون انداختن دو برابر جعبه کار کند.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ابتدا مجموعه ای از تعاریف نوع.در اینجا چند مورد عجیب و غریب مخصوص پلتفرم وجود دارد و موارد زیادی فقط با بی ادبی از LLVM کپی شده اند.هدف از همه اینها پیاده سازی عملکرد `panic` زیر از طریق تماس با `_CxxThrowException` است.
//
// این تابع دو آرگومان می گیرد.اولین اشاره گر داده ای است که ما در حال انتقال آن هستیم ، که در این مورد شی Z trait ما است.یافتن آن بسیار آسان است!مورد بعدی اما پیچیده تر است.
// این یک اشاره گر برای ساختار `_ThrowInfo` است ، و به طور کلی فقط هدف آن توصیف استثنایی است که پرتاب می شود.
//
// در حال حاضر تعریف این نوع [1] کمی مودار است و عجیب اصلی (و تفاوت مقاله آنلاین) این است که در 32 بیتی اشاره گرها اشاره گر هستند اما در 64 بیت اشاره گرها به عنوان جابجایی 32 بیتی از نماد `__ImageBase`.
//
// ماکرو `ptr_t` و `ptr!` در ماژول های زیر برای بیان این مورد استفاده می شود.
//
// پیچ و خم تعاریف نوع همچنین آنچه LLVM را برای این نوع عملکرد ساطع می کند از نزدیک دنبال می شود.به عنوان مثال ، اگر این کد C++ را بر روی MSVC کامپایل کرده و LLVM IR را منتشر می کنید:
//
//      #include <stdint.h>
//
//      ساختار rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2]؛}؛
//
//      بی اعتبار foo() { rust_panic a = {0, 1} ؛
//          انداختن یک؛}
//
// این اساساً همان چیزی است که ما سعی در تقلید از آن داریم.بیشتر مقادیر ثابت زیر فقط از LLVM کپی شده است ،
//
// در هر صورت ، همه این ساختارها به روشی مشابه ساخته شده اند و فقط برای ما تا حدودی پر حرف است.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// توجه داشته باشید که ما عمداً قوانین دستکاری نام را نادیده می گیریم: ما نمی خواهیم C++ بتواند Rust panics را به سادگی با اعلام `struct rust_panic` بگیرد.
//
//
// هنگام اصلاح ، مطمئن شوید که رشته نوع name دقیقاً با رشته ای که در `compiler/rustc_codegen_llvm/src/intrinsic.rs` استفاده شده مطابقت داشته باشد.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // بایت پیشرو `\x01` در اینجا یک سیگنال جادویی برای LLVM است تا * اعمال هیچ مانع دیگری مانند پیشوند با کاراکتر `_` نشود.
    //
    //
    // این علامت جدول قابل استفاده توسط `std::type_info` C++ است.
    // اشیا of از نوع `std::type_info` ، توصیف کننده های نوع ، یک اشاره گر برای این جدول دارند.
    // توصیف کننده های نوع توسط ساختارهای C++ EH که در بالا تعریف شده است و ما در زیر ساخت می کنیم.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// این توصیف کننده نوع فقط هنگام انداختن یک استثنا استفاده می شود.
// قسمت گرفتن توسط try intrinsic اداره می شود که TypeDescriptor خود را تولید می کند.
//
// این خوب است زیرا زمان اجرای MSVC به جای برابری اشاره گر ، از مقایسه رشته ای برای نام نوع برای مطابقت با TypeDescriptors استفاده می کند.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// اگر کد C++ تصمیم بگیرد این استثنا را گرفته و بدون انتشار آن را رها کند ، از تخریب کننده استفاده می شود.
// قسمت catch try intrinsic اولین کلمه از شی exception استثنا را 0 قرار می دهد تا توسط تخریب کننده کنار گذاشته شود.
//
// توجه داشته باشید که x86 Windows به جای قرارداد برقراری تماس پیش فرض "C" ، از قرارداد فراخوانی "thiscall" برای توابع عضو C++ استفاده می کند.
//
// تابعception_copy در اینجا کمی خاص است: با زمان اجرا MSVC تحت یک بلاک try/catch فراخوانی می شود و panic که ما در اینجا ایجاد می کنیم به عنوان نتیجه کپی استثنا استفاده می شود.
//
// این در زمان اجرا C++ برای پشتیبانی از گرفتن موارد استثنایی با std::exception_ptr استفاده می شود ، زیرا ما نمی توانیم آن را پشتیبانی کنیم زیرا Box<dyn Any>قابل شبیه سازی نیست
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException کاملاً روی این قاب پشته اجرا می شود ، بنابراین نیازی به انتقال `data` به پشته نیست.
    // ما فقط یک نشانگر پشته را به این عملکرد منتقل می کنیم.
    //
    // در اینجا ManualDrop مورد نیاز است زیرا ما نمی خواهیم هنگام باز کردن حالت استثنا حذف شود.
    // در عوض ، با استثنای_صفحه_که مدت زمان اجرای ++ C فراخوانی می شود ، آن را حذف می کند.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // این ... ممکن است تعجب آور به نظر برسد ، و قابل توجیه نیز.در MSVC 32 بیتی ، نشانگرهای بین این ساختار نشانگرها هستند.
    // با این حال ، در MSVC 64 بیتی ، نشانگرهای بین ساختارها به عنوان جابجایی 32 بیتی `__ImageBase` بیان می شوند.
    //
    // در نتیجه ، در MSVC 32 بیتی می توانیم همه این نشانگرها را در ``static`` در بالا اعلام کنیم.
    // در MSVC 64 بیتی ، باید تفریق اشاره گرها را در استاتیک بیان کنیم ، که Rust در حال حاضر اجازه نمی دهد ، بنابراین در واقع نمی توانیم چنین کاری را انجام دهیم.
    //
    // بهترین چیز بعدی ، پر کردن این ساختارها در زمان اجرا است (به هر حال وحشت از قبل "slow path" است).
    // بنابراین در اینجا ما همه این زمینه های اشاره گر را به عنوان عدد صحیح 32 بیتی تفسیر می کنیم و سپس مقدار مربوطه را در آن ذخیره می کنیم (از نظر اتمی ، زیرا ممکن است panics همزمان اتفاق بیفتد).
    //
    // از نظر فنی ، زمان اجرا احتمالاً یک خواندن غیر اتمی از این زمینه ها را انجام می دهد ، اما در تئوری آنها هرگز مقدار *اشتباه* را نمی خوانند ، بنابراین نباید خیلی بد باشد ...
    //
    // در هر صورت ، ما اساساً باید چنین کارهایی را انجام دهیم تا زمانی که بتوانیم عملیات بیشتری را در استاتیک بیان کنیم (و شاید هرگز نتوانیم چنین کاری کنیم).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // محموله NULL در اینجا بدان معنی است که ما از (...) گرفتن __ اعتماد_اجرا به اینجا رسیده ایم.
    // این اتفاق می افتد زمانی که یک استثنا خارجی غیر Rust گرفتار شود.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// وجود این مورد توسط کامپایلر وجود دارد (به عنوان مثال ، این یک مورد زبان است) ، اما در واقع هرگز توسط کامپایلر فراخوانی نمی شود زیرا __C_specific_handler یا _except_handler3 عملکرد شخصیتی است که همیشه استفاده می شود.
//
// از این رو این فقط یک مقاله خرد خرد است.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}