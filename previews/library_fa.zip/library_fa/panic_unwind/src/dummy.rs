//! باز کردن برای هدف *wasm32*.
//!
//! در حال حاضر ما از این پشتیبانی نمی کنیم ، بنابراین این فقط مقاله های خرد است.

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    intrinsics::abort()
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    intrinsics::abort()
}