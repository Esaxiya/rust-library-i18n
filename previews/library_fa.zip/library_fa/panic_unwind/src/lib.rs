//! پیاده سازی panics از طریق باز کردن پشته
//!
//! این crate پیاده سازی panics در Rust با استفاده از مکانیزم باز کردن پشته "most native" از بستری است که برای آن کامپایل شده است.
//! این اساساً در سه سطل طبقه بندی می شود:
//!
//! 1. اهداف MSVC از SEH در پرونده `seh.rs` استفاده می کنند.
//! 2. Emscripten از استثناهای C++ در پرونده `emcc.rs` استفاده می کند.
//! 3. همه اهداف دیگر از libunwind/libgcc در پرونده `gcc.rs` استفاده می کنند.
//!
//! اسناد بیشتر در مورد هر پیاده سازی را می توان در ماژول مربوطه یافت.
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` با میری استفاده نشده است ، بنابراین هشدارها را خاموش کنید.
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // اشیا start راه اندازی Rust به این نمادها بستگی دارد ، بنابراین آنها را عمومی کنید.
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // اهدافی که از باز کردن پشتیبانی نمی کنند.
        // - arch=wasm32
        // - os=هیچ (اهداف "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // از زمان اجرا Miri استفاده کنید.
        // ما همچنان باید زمان عادی را در بالا بارگیری کنیم ، زیرا rustc انتظار دارد که برخی از موارد زبان از آنجا تعریف شوند.
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // از زمان واقعی استفاده کنید.
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler in libstd وقتی یک شی panic خارج از `catch_unwind` ریخته شود فراخوانی می شود.
    ///
    fn __rust_drop_panic() -> !;

    /// Handler in libstd هنگام گرفتن یک استثنا foreign خارجی تماس می گیرد.
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// نقطه ورود برای ایجاد یک استثنا ، فقط به پیاده سازی خاص سیستم عامل اعطا می شود.
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}