//! در حال باز کردن پیچ panics برای Miri.
use alloc::boxed::Box;
use core::any::Any;

// نوع محموله ای که موتور میری از طریق باز کردن برای ما پخش می کند.
// باید اندازه اشاره گر باشد.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// عملکرد خارجی ارائه شده توسط میری برای شروع باز کردن کار.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // محموله ای که به `miri_start_panic` منتقل می کنیم دقیقاً بحثی خواهد بود که در `cleanup` در زیر می گیریم.
    // بنابراین ما فقط یک بار آن را جعبه می کنیم تا چیزی به اندازه اشاره گر بدست آوریم.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // `Box` زمینه ای را بازیابی کنید.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}