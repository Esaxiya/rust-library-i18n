# `rustc-std-workspace-core` crate

این crate یک crate براق و خالی است که به سادگی به `libcore` بستگی دارد و تمام محتوای آن را دوباره صادر می کند.
crate محور قدرت بخشیدن به کتابخانه استاندارد برای وابستگی به crates از crates.io است

Crates در crates.io که کتابخانه استاندارد بستگی به نیاز به `rustc-std-workspace-core` crate از crates.io دارد که خالی است.

ما از `[patch]` استفاده می کنیم تا آن را به این crate در این مخزن نادیده بگیریم.
در نتیجه ، crates روی crates.io وابستگی edge را به `libcore` ترسیم می کند ، نسخه تعریف شده در این مخزن.
این باید تمام لبه های وابستگی را ترسیم کند تا اطمینان حاصل شود Cargo با موفقیت crates را می سازد!

توجه داشته باشید که crates روی crates.io برای کار صحیح همه چیز به این crate با نام `core` بستگی دارد.برای این کار آنها می توانند از موارد زیر استفاده کنند:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

با استفاده از کلید `package` ، crate به `core` تغییر نام می یابد ، به این معنی که به نظر می رسد

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

وقتی Cargo به کامپایلر فراخوانی می کند ، دستورالعمل ضمنی `extern crate core` تزریق شده توسط کامپایلر را برآورده می کند.




