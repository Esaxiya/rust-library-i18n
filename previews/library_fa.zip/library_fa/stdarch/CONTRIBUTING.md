# کمک به stdarch

`stdarch` crate تمایل بیشتری به پذیرش مشارکت دارد!ابتدا احتمالاً می خواهید مخزن را بررسی کنید و مطمئن شوید که آزمایشات برای شما انجام می شود:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

جایی که `<your-target-arch>` سه برابر هدف است همانطور که `rustup` استفاده می کند ، مثلاً `x86_x64-unknown-linux-gnu` (بدون هیچ گونه `nightly-` قبلی یا مشابه آن).
همچنین به یاد داشته باشید که این مخزن به کانال شبانه Rust نیاز دارد!
در واقع آزمایشات فوق برای اینكه 0rust شبانه باشد به طور پیش فرض در سیستم شما وجود دارد ، تا تنظیم شود كه از `rustup default nightly` (و `rustup default stable` برای برگرداندن) استفاده شود.

اگر هر یک از مراحل بالا کار نکرد ، [please let us know][new]!

در مرحله بعدی می توانید [find an issue][issues] را برای کمک به ما ، ما چند مورد را با برچسب های [`help wanted`][help] و [`impl-period`][impl] انتخاب کرده ایم که به ویژه می توانند از کمک استفاده کنند. 
شما ممکن است بیشتر به [#40][vendor] علاقه مند باشید ، تمام ذاتی فروشندگان را در x86 پیاده سازی کنید.این موضوع چندین نشانگر خوب در مورد محل شروع به دست آورده است!

اگر سوالات کلی دارید ، [join us on gitter][gitter] را آزاد کنید و از خود بپرسید!در صورت تمایل می توانیدBurntSushi یاalexcrichton را با س pالات پینگ کنید.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# نحوه نوشتن مثالهایی برای ذاتیان stdarch

چند ویژگی وجود دارد که باید برای ذاتی ارائه شده به درستی کار کند و مثال فقط هنگامی که این ویژگی توسط CPU پشتیبانی می شود باید توسط `cargo test --doc` اجرا شود.

در نتیجه ، `fn main` پیش فرض که توسط `rustdoc` تولید می شود کار نمی کند (در بیشتر موارد).
استفاده از موارد زیر را به عنوان راهنما در نظر بگیرید تا اطمینان حاصل کنید که مثال شما مطابق انتظار عمل می کند.

```rust
/// # // برای اطمینان از تنها مثال به cfg_target_feature نیاز داریم
/// # // هنگامی که پردازنده از این ویژگی پشتیبانی می کند توسط `cargo test --doc` اجرا می شود
/// # #![feature(cfg_target_feature)]
/// # // برای عملکرد ذاتی به target_feature نیاز داریم
/// # #![feature(target_feature)]
/// #
/// # // rustdoc به طور پیش فرض از `extern crate stdarch` استفاده می کند ، اما ما به آن نیاز داریم
/// # // `#[macro_use]`
/// # # [استفاده_ماکرو] extern crate stdarch؛
/// #
/// # // عملکرد اصلی واقعی
/// # fn main() {
/// #     // فقط در صورت پشتیبانی از `<target feature>` این کار را انجام دهید
/// #     اگر cfg_feature_enabled! ("<target feature>"){
/// #         // یک عملکرد `worker` ایجاد کنید که فقط در صورت ویژگی هدف اجرا شود
/// #         // پشتیبانی می شود و اطمینان حاصل کنید که `target_feature` برای کارگر شما فعال است
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         ناامن fn worker() {
/// // مثال خود را اینجا بنویسید.ویژگیهای ذاتی خاص در اینجا کار خواهند کرد!برو وحشی!
///
/// #         }
///
/// #         { worker(); } ناامن
/// #     }
/// # }
```

اگر برخی از نحوهای بالا آشنا به نظر نرسند ، بخش [Documentation as tests] از [Rust Book] نحو `rustdoc` را به خوبی توصیف می کند.
مثل همیشه ، با [join us on gitter][gitter] احساس راحتی کنید و از ما بپرسید که آیا به دام گیر افتاده اید ، و از شما برای کمک به بهبود اسناد `stdarch` متشکریم!

# دستورالعمل های تست جایگزین

به طور کلی توصیه می شود که برای اجرای تست ها از `ci/run.sh` استفاده کنید.
اما این ممکن است برای شما مفید نباشد ، به عنوان مثال اگر از Windows استفاده می کنید.

در این صورت می توانید برای آزمایش تولید کد ، به اجرای `cargo +nightly test` و `cargo +nightly test --release -p core_arch` بازگردید.
توجه داشته باشید که برای این کار باید ابزار ابزار شبانه نصب شود و `rustc` از هدف سه گانه و پردازنده آن مطلع شود.
به طور خاص شما باید متغیر محیط `TARGET` را همانند `ci/run.sh` تنظیم کنید.
علاوه بر این شما باید `RUSTCFLAGS` (نیاز به `C`) را برای نشان دادن ویژگی های هدف تنظیم کنید ، به عنوان مثال `RUSTCFLAGS="-C -target-features=+avx2"`.
همچنین اگر "just" در مقابل پردازنده فعلی خود توسعه می دهید می توانید `-C -target-cpu=native` را تنظیم کنید.

هشدار داده شود که هنگام استفاده از این دستورالعمل های جایگزین ، [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] ، به عنوان مثال
آزمونهای تولید دستورالعمل ممکن است شکست بخورند زیرا جداکننده آنها را به گونه دیگری نامگذاری کرده است ، به عنوان مثال
ممکن است به جای دستورالعمل های `aesenc` `vaesenc` تولید کند ، با وجود اینکه رفتار یکسانی دارند.
همچنین این دستورالعمل ها آزمون های کمتری را نسبت به آنچه که معمولاً انجام می شود ، اجرا می کنند ، بنابراین تعجب نکنید که وقتی در آخر درخواست خود را انجام می دهید ، ممکن است خطاهایی برای آزمونهایی که در اینجا ذکر نشده اند ، نشان داده شود.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






