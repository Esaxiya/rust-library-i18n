`core::arch` - ذاتی خاص معماری کتابخانه اصلی Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

ماژول `core::arch` ذاتی وابسته به معماری را اجرا می کند (به عنوان مثال SIMD).

# Usage 

`core::arch` به عنوان بخشی از `libcore` در دسترس است و توسط `libstd` دوباره صادر می شود.استفاده از آن را از طریق `core::arch` یا `std::arch` ترجیح دهید تا از طریق این crate.
ویژگی های ناپایدار اغلب در Rust شبانه از طریق `feature(stdsimd)` در دسترس هستند.

استفاده از `core::arch` از طریق این crate به Rust شبانه احتیاج دارد و می تواند اغلب شکسته شود (و می شود).تنها مواردی که باید استفاده از آن را از طریق این crate در نظر بگیرید عبارتند از:

* اگر لازم است `core::arch` را خودتان دوباره کامپایل کنید ، مثلاً ویژگی های خاص خاصی را فعال کنید که برای `libcore`/`libstd` فعال نیستند.
Note: اگر می خواهید آن را برای یک هدف غیر استاندارد دوباره کامپایل کنید ، لطفاً به جای استفاده از این crate ، استفاده از `xargo` و کامپایل `libcore`/`libstd` را به صورت مناسب ترجیح دهید.
  
* با استفاده از برخی ویژگی ها که حتی در پشت ویژگی های ناپایدار Rust ممکن است در دسترس نباشند.ما سعی می کنیم این موارد را به حداقل برسانیم.
اگر نیاز به استفاده از برخی از این ویژگی ها دارید ، لطفاً مسئله ای را باز کنید تا بتوانیم آنها را در Rust شبانه نشان دهیم و شما بتوانید از آنجا استفاده کنید.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` در درجه اول تحت شرایط مجوز MIT و Apache License (نسخه 2.0) توزیع می شود ، و بخشهایی از آن تحت مجوزهای مختلف مانند BSD قرار دارند.

برای جزئیات به LICENSE-APACHE و LICENSE-MIT مراجعه کنید.

# Contribution

مگر اینکه صریحاً خلاف آن را بیان کنید ، هرگونه سهمی که از طرف شما برای درج در `core_arch` ارائه شده باشد ، همانطور که در مجوز Apache-2.0 تعریف شده است ، بدون هیچ گونه شرایط و ضوابط اضافی دارای مجوز دوگانه خواهد بود.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












