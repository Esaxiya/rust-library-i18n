use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // مورد استفاده قرار می گیرد تا حاشیه نویسی `#[assert_instr]` ما بگویید که همه ذاتی SIMD در دسترس هستند برای تست کدنویسی خود ، از آنجا که برخی از آنها پشت `-Ctarget-feature=+unimplemented-simd128` اضافی که در حال حاضر هیچ معادل آن در `#[target_feature]` ندارد ، قرار دارند.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}