//! پیاده سازی Rust panics از طریق لغو فرآیند
//!
//! این crate وقتی با پیاده سازی مقایسه می شود ، بسیار ساده تر است!همینطور که گفته شد ، کاملاً چند منظوره نیست ، اما اینجا ادامه دارد!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" محموله و لرزش به سقط مربوطه در سیستم عامل مورد نظر.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // با std::sys::abort_internal تماس بگیرید
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // در Windows ، از سازوکار __ fastfail مخصوص پردازنده استفاده کنید.در Windows 8 و بالاتر ، این کار بلافاصله بدون اجرای برنامه های کنترل استثنا در روند کار ، خاتمه می یابد.
            // در نسخه های قبلی Windows ، این توالی دستورالعمل به عنوان نقض دسترسی تلقی می شود ، روند کار را خاتمه می دهد اما بدون لزوماً از همه کنترل کننده های استثنا عبور می کند.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: این همان پیاده سازی `abort_internal` در libstd است
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// این ... کمی عجیب است.tl ؛ دکتر ؛این است که برای پیوند دادن به این مورد نیاز است ، توضیحات طولانی تر در زیر است.
//
// در حال حاضر باینری های libcore/libstd که ما ارسال می کنیم همه با `-C panic=unwind` وارد شده اند.این کار برای اطمینان از سازگاری حداکثر باینری ها با بیشترین موقعیت ها انجام می شود.
// با این حال ، کامپایلر برای تمام توابع کامپایل شده با `-C panic=unwind` به "personality function" نیاز دارد.این عملکرد شخصیتی به سختی با نماد `rust_eh_personality` کدگذاری می شود و توسط مورد `eh_personality` تعریف می شود.
//
// So...
// چرا فقط آن مورد lang را اینجا تعریف نکنید؟سؤال خوبی بود!روشی که زمان اجرای panic به آن متصل می شود در واقع کمی ظریف است از این جهت که در فروشگاه crate کامپایلر "sort of" است ، اما در صورتی که دیگری واقعاً به هم متصل نباشد واقعاً به هم پیوند می خورد.
//
// در پایان به این معنی است که هم این crate و هم panic_unwind crate می توانند در فروشگاه crate کامپایلر ظاهر شوند و اگر هر دو مورد `eh_personality` را تعریف کنند ، خطایی رخ می دهد.
//
// برای رسیدگی به این مورد ، کامپایلر فقط به `eh_personality` نیاز دارد اگر زمان اجرا panic که به آن متصل می شود ، زمان باز کردن است و در غیر این صورت لازم نیست تعریف شود (به درستی).
// در این حالت ، این کتابخانه فقط این نماد را تعریف می کند ، بنابراین حداقل جایی شخصیت دارد.
//
// اساساً این نماد فقط برای سیم کشی تا باینری libcore/libstd تعریف شده است ، اما هرگز نباید آن را صدا زد زیرا ما اصلاً در یک زمان خنک کننده پیوند نمی دهیم.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // در x86_64-pc-windows-gnu ما از عملکرد شخصیتی خود استفاده می کنیم که هنگام انتقال همه فریم های خود ، `ExceptionContinueSearch` را باید بازگرداند.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // مشابه موارد فوق ، این مربوط به مورد زبان `eh_catch_typeinfo` است که در حال حاضر فقط در Emscripten استفاده می شود.
    //
    // از آنجا که panics استثناهایی ایجاد نمی کند و استثناهای خارجی در حال حاضر با -C panic=سقط UB است (اگرچه ممکن است این مورد تغییر کند) ، هر گونه تماس گرفتن_پرونده هرگز از این نوع اطلاعات استفاده نمی کند.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // این دو توسط اشیا start راه اندازی ما در i686-pc-windows-gnu فراخوانی می شوند ، اما نیازی به انجام هیچ کاری نیستند زیرا بدن ها nops هستند.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}