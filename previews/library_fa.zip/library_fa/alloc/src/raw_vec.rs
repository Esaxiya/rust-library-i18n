#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// محتوای حافظه جدید اولیه نیست.
    Uninitialized,
    /// حافظه جدید تضمین می شود که صفر می شود.
    Zeroed,
}

/// یک ابزار سطح پایین برای تخصیص ارگونومیک ، تخصیص مجدد و اختصاص مکان بافر حافظه روی پشته بدون اینکه نگران همه موارد گوشه ای باشید.
///
/// این نوع برای ساخت ساختارهای داده خود مانند Vec و VecDeque بسیار عالی است.
/// به خصوص:
///
/// * `Unique::dangling()` را در انواع اندازه صفر تولید می کند.
/// * `Unique::dangling()` را در تخصیص هایی با طول صفر تولید می کند.
/// * از آزاد کردن `Unique::dangling()` جلوگیری می کند.
/// * همه سرریزها را در محاسبات ظرفیت می گیرد (آنها را به "capacity overflow" panics ارتقا می دهد).
/// * محافظت در برابر سیستم های 32 بیتی که بیش از isize::MAX بایت اختصاص می دهند.
/// * در برابر سرریز شدن طول شما محافظت نکنید.
/// * برای تخصیص خطای `handle_alloc_error` تماس می گیرد.
/// * دارای `ptr::Unique` است و بنابراین همه مزایای مربوط به آن را به کاربر می بخشد.
/// * از مازاد برگشتی از تخصیص دهنده برای استفاده از بیشترین ظرفیت موجود استفاده می کند.
///
/// این نوع به هیچ وجه حافظه ای را که مدیریت می کند بازرسی نمی کند.وقتی رها شد *حافظه خود را* آزاد می کند ، اما * سعی نمی کند محتوای آن را رها کند.
/// مسئولیت رسیدگی به موارد واقعی *ذخیره شده* در داخل `RawVec` به عهده کاربر `RawVec` است.
///
/// توجه داشته باشید که مقدار اضافی انواع صفر همیشه بی نهایت است ، بنابراین `capacity()` همیشه `usize::MAX` را برمی گرداند.
/// این بدان معناست که شما باید هنگام چرخاندن گرد این نوع با `Box<[T]>` مراقب باشید ، زیرا `capacity()` طول نخواهد داد.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): این وجود دارد زیرا `#[unstable]` `const fn نیازی به مطابقت با `min_const_fn` ندارد و بنابراین نمی توان آنها را در` min_const_fn` فراخوانی کرد.
    ///
    /// اگر `RawVec<T>::new` یا وابستگی ها را تغییر دادید ، لطفاً توجه داشته باشید که چیزی را که واقعاً ناقض `min_const_fn` باشد معرفی نکنید.
    ///
    /// NOTE: ما می توانیم از این هک و بررسی مطابقت با برخی از ویژگی های `#[rustc_force_min_const_fn]` که نیاز به انطباق با `min_const_fn` دارد جلوگیری کنیم اما لزوماً اجازه نمی دهد که آن را در `stable(...) const fn` بخوانید/کد کاربر که `foo` را در صورت وجود `#[rustc_const_unstable(feature = "foo", issue = "01234")]` امکان پذیر نمی کند.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// بدون تخصیص ، بزرگترین `RawVec` ممکن (روی پشته سیستم) را ایجاد می کند.
    /// اگر اندازه `T` مثبت باشد ، این یک `RawVec` با ظرفیت `0` می سازد.
    /// اگر `T` اندازه آن صفر باشد ، `RawVec` با ظرفیت `usize::MAX` تولید می کند.
    /// برای اجرای تخصیص تأخیر مفید است.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// `RawVec` (بر روی سیستم سیستم) دقیقاً با ظرفیت و هم ترازی مورد نیاز `[T; capacity]` ایجاد می کند.
    /// این برابر است با فراخوانی `RawVec::new` وقتی `capacity` `0` باشد یا `T` صفر اندازه باشد.
    /// توجه داشته باشید که اگر `T` اندازه آن صفر باشد ، به این معنی است که * `RawVec` با ظرفیت درخواستی دریافت نمی کنید.
    ///
    /// # Panics
    ///
    /// Panics اگر ظرفیت درخواستی بیش از `isize::MAX` بایت باشد.
    ///
    /// # Aborts
    ///
    /// در OOM سقط می شود.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// مانند `with_capacity` اما تضمین می کند بافر صفر است.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// `RawVec` را از یک نشانگر و ظرفیت بازسازی می کند.
    ///
    /// # Safety
    ///
    /// `ptr` باید (با پشته سیستم) و با `capacity` داده شده اختصاص یابد.
    /// `capacity` برای انواع اندازه نمی تواند بیش از `isize::MAX` باشد.(فقط نگرانی سیستم های 32 بیتی است).
    /// ZST vectors ممکن است ظرفیتی تا `usize::MAX` داشته باشد.
    /// اگر `ptr` و `capacity` از `RawVec` تهیه شده باشد ، این امر تضمین شده است.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs کوچک لال هستند.پرش به:
    // - اگر اندازه عنصر 1 باشد ، 8 است ، زیرا هر یک از تخصیص دهندگان پشته درخواستی کمتر از 8 بایت را به حداقل 8 بایت تبدیل می کنند.
    //
    // - 4 اگر عناصر در اندازه متوسط باشند (1 کیلوبایت=).
    // - در غیر این صورت ، برای جلوگیری از هدر رفتن فضای زیاد برای Vec های خیلی کوتاه.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// مانند `new` ، اما از انتخاب تخصیص دهنده برای `RawVec` بازگشتی پارامتر شده است.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` به معنای "unallocated" است.انواع اندازه صفر نادیده گرفته می شوند.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// مانند `with_capacity` ، اما از انتخاب تخصیص دهنده برای `RawVec` بازگشتی پارامتر شده است.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// مانند `with_capacity_zeroed` ، اما از انتخاب تخصیص دهنده برای `RawVec` بازگشتی پارامتر شده است.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` را به `RawVec<T>` تبدیل می کند.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// کل بافر را با `len` مشخص شده به `Box<[MaybeUninit<T>]>` تبدیل می کند.
    ///
    /// توجه داشته باشید که با این کار هرگونه تغییر `cap` که ممکن است انجام شود به درستی بازسازی می شود.(برای جزئیات به شرح نوع آن مراجعه کنید.)
    ///
    /// # Safety
    ///
    /// * `len` باید بیشتر یا مساوی ظرفیت اخیراً درخواست شده باشد یا
    /// * `len` باید کمتر یا برابر با `self.capacity()` باشد.
    ///
    /// توجه داشته باشید که ظرفیت درخواستی و `self.capacity()` ممکن است متفاوت باشد ، زیرا یک تخصیص دهنده می تواند یک بلوک حافظه بزرگتر از آنچه را که درخواست شده است ، تنظیم و بازگرداند.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // عقل را نیمی از نیاز ایمنی را بررسی کنید (ما نمی توانیم نیمه دیگر را بررسی کنیم).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // ما در اینجا از `unwrap_or_else` اجتناب می کنیم زیرا مقدار LLVM IR تولید شده را نفخ می کند.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// `RawVec` را از یک نشانگر ، ظرفیت و تخصیص دهنده بازسازی می کند.
    ///
    /// # Safety
    ///
    /// `ptr` باید (از طریق اختصاص دهنده `alloc` داده شده) و با `capacity` داده شده اختصاص یابد.
    /// `capacity` برای انواع اندازه نمی تواند بیش از `isize::MAX` باشد.
    /// (فقط نگرانی در مورد سیستم های 32 بیتی است).
    /// ZST vectors ممکن است ظرفیتی تا `usize::MAX` داشته باشد.
    /// اگر `ptr` و `capacity` از `RawVec` ایجاد شده از طریق `alloc` تهیه شده باشد ، این امر تضمین شده است.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// برای شروع تخصیص ، یک نشانگر خام دریافت می کند.
    /// توجه داشته باشید که این `Unique::dangling()` است اگر `capacity == 0` یا `T` اندازه آن صفر باشد.
    /// در مورد اول باید مراقب باشید.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// ظرفیت تخصیص را بدست می آورد.
    ///
    /// اگر `T` اندازه صفر داشته باشد ، این همیشه `usize::MAX` خواهد بود.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// یک مرجع مشترک را به تخصیص دهنده پشتیبان این `RawVec` برمی گرداند.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // ما یک حافظه اختصاصی داریم ، بنابراین می توانیم از چک های زمان اجرا عبور کنیم تا طرح فعلی خود را بدست آوریم.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// اطمینان حاصل می کند که بافر حداقل فضای کافی برای نگهداری عناصر `len + additional` را دارد.
    /// اگر در حال حاضر ظرفیت کافی نداشته باشد ، فضای کافی به علاوه فضای شل راحت را برای بدست آوردن رفتار *O*(1) اختصاص می دهید.
    ///
    /// این رفتار را در صورت عدم نیاز به panic محدود می کند.
    ///
    /// اگر `len` از `self.capacity()` بیشتر شود ، ممکن است در واقع تخصیص فضای درخواست شده انجام نشود.
    /// این واقعاً ناامن نیست ، اما کد ناامن *شما* که می نویسید و به رفتار این عملکرد متکی است ممکن است شکسته شود.
    ///
    /// این برای اجرای یک عمل فشار فشرده مانند `extend` ایده آل است.
    ///
    /// # Panics
    ///
    /// اگر ظرفیت جدید بیش از `isize::MAX` بایت باشد ، Panics.
    ///
    /// # Aborts
    ///
    /// در OOM سقط می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // اگر لن از `isize::MAX` فراتر رود ، ذخیره سقط می شد یا وحشت می کرد ، بنابراین انجام این کار در حال حاضر امن است.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// همان `reserve` است ، اما به جای ترساندن یا سقط جنین ، خطاها را برمی گرداند.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// اطمینان حاصل می کند که بافر حداقل فضای کافی برای نگهداری عناصر `len + additional` را دارد.
    /// اگر قبلاً این کار را انجام ندهید ، حداقل میزان ممکن حافظه لازم را تخصیص می دهید.
    /// به طور کلی این دقیقاً مقدار حافظه لازم خواهد بود ، اما در اصل تخصیص دهنده در بازگرداندن بیش از آنچه که ما خواسته ایم آزاد است.
    ///
    ///
    /// اگر `len` از `self.capacity()` بیشتر شود ، ممکن است در واقع تخصیص فضای درخواست شده انجام نشود.
    /// این واقعاً ناامن نیست ، اما کد ناامن *شما* که می نویسید و به رفتار این عملکرد متکی است ممکن است شکسته شود.
    ///
    /// # Panics
    ///
    /// اگر ظرفیت جدید بیش از `isize::MAX` بایت باشد ، Panics.
    ///
    /// # Aborts
    ///
    /// در OOM سقط می شود.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// همان `reserve_exact` است ، اما به جای ترساندن یا سقط جنین ، خطاها را برمی گرداند.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// تخصیص را به مقدار مشخص شده کاهش می دهد.
    /// اگر مقدار داده شده 0 باشد ، در واقع به طور کامل جابجا می شود.
    ///
    /// # Panics
    ///
    /// Panics اگر مقدار داده شده *بزرگتر* از ظرفیت فعلی باشد.
    ///
    /// # Aborts
    ///
    /// در OOM سقط می شود.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// در صورت نیاز به رشد بافر ، برای برآوردن ظرفیت اضافی مورد نیاز ، برمی گردد.
    /// عمدتا برای ایجاد خط تلفنی ذخیره بدون استفاده از `grow` امکان پذیر است.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // این روش معمولاً چندین بار نمونه سازی می شود.بنابراین ما می خواهیم تا آنجا که ممکن است کوچک باشد ، تا زمان کامپایل را بهبود بخشد.
    // اما همچنین می خواهیم تا حد امکان محتوای آن از نظر آماری قابل محاسبه باشد تا کد تولید شده سریعتر اجرا شود.
    // بنابراین ، این روش با دقت نوشته شده است به گونه ای که تمام کدهایی که به `T` بستگی دارند ، در آن قرار دارند ، در حالی که بیشترین کدی که به `T` وابسته نیست ، در توابع غیر عمومی نسبت به `T` است.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // این با زمینه های تماس تضمین می شود.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // از آنجا که ما `elem_size` ظرفیت `usize::MAX` را برمی گردانیم
            // 0 ، رسیدن به اینجا لزوماً به معنای پر بودن `RawVec` است.
            return Err(CapacityOverflow);
        }

        // متأسفانه ، واقعاً هیچ کاری نمی توانیم در مورد این بررسی ها انجام دهیم.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // این رشد نمایی را تضمین می کند.
        // دو برابر شدن نمی تواند سرریز کند زیرا `cap <= isize::MAX` و نوع `cap` `usize` است.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` بیش از `T` غیر عمومی است.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // محدودیت های موجود در این روش تقریباً مشابه محدودیت های `grow_amortized` است ، اما این روش معمولاً با دفعات کمتری نمونه برداری می شود ، بنابراین از اهمیت کمتری برخوردار است.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // از آنجا که ما ظرفیت `usize::MAX` را هنگامی که اندازه نوع باشد باز می گردانیم
            // 0 ، رسیدن به اینجا لزوماً به معنای پر بودن `RawVec` است.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` بیش از `T` غیر عمومی است.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// این عملکرد خارج از `RawVec` است تا زمان کامپایل را به حداقل برساند.برای جزئیات بیشتر به توضیحات بالا `RawVec::grow_amortized` مراجعه کنید.
// (پارامتر `A` قابل توجه نیست ، زیرا تعداد انواع مختلف `A` در عمل بسیار کمتر از تعداد `T` است.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // برای به حداقل رساندن اندازه `RawVec::grow_*` ، خطا را در اینجا بررسی کنید.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // تخصیص دهنده برابری تراز را بررسی می کند
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// حافظه متعلق به `RawVec`*را آزاد می کند بدون اینکه* سعی در حذف محتوای آن داشته باشد.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// عملکرد مرکزی برای مدیریت خطاهای ذخیره.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// ما باید موارد زیر را تضمین کنیم:
// * ما هرگز اشیای اندازه بایت `> isize::MAX` را اختصاص نمی دهیم.
// * ما `usize::MAX` را سرریز نمی کنیم و در واقع مقدار کمی تخصیص می دهیم.
//
// در 64 بیتی ما فقط باید سرریز را بررسی کنیم زیرا مطمئناً تلاش برای تخصیص بایت `> isize::MAX` ناموفق خواهد بود.
// در صورت استفاده از پلتفرمی که می تواند از همه 4 گیگابایت در فضای کاربر استفاده کند ، به عنوان مثال ، PAE یا x32 ، باید در این سیستم 32 بیتی و 16 بیتی محافظ اضافی اضافه کنیم.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// یکی از عملکردهای اصلی که مسئول گزارش سرریز ظرفیت است.
// این اطمینان می دهد که تولید کد مربوط به این panics کم است زیرا فقط یک مکان وجود دارد که panics است و نه یک دسته در سراسر ماژول.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}