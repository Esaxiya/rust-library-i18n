//! # کتابخانه تخصیص و مجموعه هسته Rust
//!
//! این کتابخانه نشانگرها و مجموعه های هوشمندی را برای مدیریت مقادیر تخصیص یافته به انبار فراهم می کند.
//!
//! این کتابخانه ، مانند libcore ، معمولاً نیازی به استفاده مستقیم ندارد ، زیرا محتوای آن در [`std` crate](../std/index.html) دوباره صادر می شود.
//! Crates که از ویژگی `#![no_std]` استفاده می کند به طور معمول به `std` بستگی نخواهد داشت ، بنابراین در عوض از این crate استفاده می کنند.
//!
//! ## مقادیر جعبه ای
//!
//! نوع [`Box`] از نوع اشاره گر هوشمند است.فقط یک مالک [`Box`] می تواند وجود داشته باشد و مالک می تواند تصمیم بگیرد که محتوای موجود در انبوه را جهش دهد.
//!
//! این نوع می تواند به صورت کارآمد در میان رشته ها ارسال شود زیرا اندازه مقدار `Box` همان اندازه یک اشاره گر است.
//! ساختارهای داده درخت مانند اغلب با جعبه ساخته می شوند زیرا هر گره اغلب فقط یک مالک دارد ، والدین.
//!
//! ## اشاره گرها با شمارش مرجع
//!
//! نوع [`Rc`] یک نوع اشاره گر غیرمخاطره با اشاره به تعداد است که برای اشتراک حافظه در یک موضوع در نظر گرفته شده است.
//! یک نشانگر [`Rc`] نوعی `T` را بسته بندی می کند و فقط اجازه دسترسی به `&T` ، یک مرجع مشترک را می دهد.
//!
//! این نوع هنگامی مفید است که تغییر پذیری وراثتی (مانند استفاده از [`Box`]) برای یک برنامه بسیار محدود کننده باشد و اغلب با انواع [`Cell`] یا [`RefCell`] جفت می شود تا جهش ایجاد شود.
//!
//!
//! ## اشاره گرهای شمارش شده از نظر اتمی
//!
//! نوع [`Arc`] معادل threadsafe نوع [`Rc`] است.این عملکردهای مشابه [`Rc`] را فراهم می کند ، با این تفاوت که مستلزم اشتراک گذاری نوع موجود `T` است.
//! علاوه بر این ، [`Arc<T>`][`Arc`] خود قابل ارسال است در حالی که [`Rc<T>`][`Rc`] اینگونه نیست.
//!
//! این نوع امکان دسترسی مشترک به داده های موجود را فراهم می کند و اغلب با بدوی های همگام سازی مانند mutexes جفت می شود تا جهش منابع مشترک امکان پذیر شود.
//!
//! ## Collections
//!
//! پیاده سازی متداول ترین ساختارهای داده های عمومی در این کتابخانه تعریف شده است.آنها از طریق [standard collections library](../std/collections/index.html) دوباره صادر می شوند.
//!
//! ## رابط های انبوه
//!
//! ماژول [`alloc`](alloc/index.html) رابط سطح پایین را با اختصاص دهنده جهانی پیش فرض تعریف می کند.با API تخصیص دهنده libc سازگار نیست.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// از نظر فنی ، این یک اشکال در rustdoc است: rustdoc می بیند که مستندات مربوط به بلوک های `#[lang = slice_alloc]` مربوط به `&[T]` است ، که همچنین دارای اسنادی با استفاده از این ویژگی در `core` است ، و از عدم فعال بودن درگاه ویژگی عصبانی می شود.
// در حالت ایده آل ، برای درگاه ویژگی اسناد سایر crates بررسی نمی شود ، اما از آنجا که این فقط برای موارد زبان ظاهر می شود ، به نظر نمی رسد ارزش اصلاح داشته باشد.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// آزمایش این کتابخانه مجاز است

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// ماژول با ماکروهای داخلی که توسط سایر ماژول ها استفاده می شود (لازم است قبل از ماژول های دیگر موجود باشد).
#[macro_use]
mod macros;

// انبوهی برای استراتژی های تخصیص سطح پایین ارائه شده است

pub mod alloc;

// انواع ابتدایی با استفاده از پشته های بالا

// برای جلوگیری از کپی کردن موارد زبان هنگام ساخت در cfg آزمون ، باید حالت را به طور مشروط از `boxed.rs` تعریف کنید.همچنین باید کد را برای داشتن اعلامیه های `use boxed::Box;` مجاز بگذارید.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}