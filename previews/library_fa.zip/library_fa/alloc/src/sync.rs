#![stable(feature = "rust1", since = "1.0.0")]

//! اشاره گرهای شمارش مرجع بدون موضوع
//!
//! برای جزئیات بیشتر به اسناد [`Arc<T>`][Arc] مراجعه کنید.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// محدودیتی نرم در میزان مراجعاتی که ممکن است به `Arc` انجام شود.
///
/// با گذشتن از این حد ، برنامه شما (هرچند لزوماً) در منابع _exactly_ `MAX_REFCOUNT + 1` سقط نمی شود.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer از حصارهای حافظه پشتیبانی نمی کند.
// برای جلوگیری از گزارش های مثبت نادرست در اجرای Arc/Weak ، به جای آن از بارهای اتمی برای هماهنگی استفاده کنید.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// یک نشانگر شمارش مرجع بدون موضوع.'Arc' مخفف کلمه "Atomically Reference Counted" است.
///
/// نوع `Arc<T>` مالکیت مشترک مقداری از نوع `T` را که در پشته اختصاص یافته فراهم می کند.فراخوانی [`clone`][clone] در `Arc` یک نمونه `Arc` جدید ایجاد می کند ، که به همان تخصیص در کپه منبع `Arc` اشاره دارد ، در حالی که تعداد مرجع را افزایش می دهد.
/// وقتی آخرین نشانگر `Arc` به یک تخصیص داده شده از بین می رود ، مقدار ذخیره شده در آن تخصیص (که اغلب به آن "inner value" گفته می شود) نیز کاهش می یابد.
///
/// منابع مشترک در Rust به طور پیش فرض جهش را مجاز نمی داند و `Arc` نیز از این قاعده مستثنی نیست: به طور کلی نمی توانید به چیزی که درون `Arc` است ، یک مرجع قابل تغییر بدست آورید.اگر نیاز به جهش از طریق `Arc` دارید ، از [`Mutex`][mutex] ، [`RwLock`][rwlock] یا یکی از انواع [`Atomic`][atomic] استفاده کنید.
///
/// ## ایمنی موضوع
///
/// برخلاف [`Rc<T>`] ، `Arc<T>` برای شمارش مرجع خود از عملیات اتمی استفاده می کند.این بدان معنی است که از نظر نخ ایمن است.عیب آن این است که عملیات اتمی گران تر از دسترسی به حافظه معمولی است.اگر تخصیصات شمارش شده توسط مرجع را بین رشته ها به اشتراک نمی گذارید ، استفاده از [`Rc<T>`] را برای سربار پایین تر در نظر بگیرید.
/// [`Rc<T>`] یک پیش فرض ایمن است ، زیرا کامپایلر هر تلاشی را برای ارسال [`Rc<T>`] بین رشته ها انجام می دهد.
/// با این حال ، یک کتابخانه ممکن است `Arc<T>` را انتخاب کند تا انعطاف پذیری بیشتری به مصرف کنندگان کتابخانه بدهد.
///
/// `Arc<T>` [`Send`] و [`Sync`] را تا زمانی که `T` [`Send`] و [`Sync`] را پیاده سازی کند ، پیاده سازی می کند.
/// چرا نمی توانید `T` بدون نخ را در `Arc<T>` قرار دهید تا از نظر نخ ایمن شود؟این ممکن است در ابتدا کمی ضد شهودی باشد: بالاخره ، آیا موضوع موضوع `Arc<T>` ایمنی ندارد؟نکته اصلی این است: `Arc<T>` داشتن مالکیت چندگانه بر داده های مشابه را از طریق موضوع امن می کند ، اما ایمنی رشته را به داده های خود اضافه نمی کند.
///
/// `Arc <` [RefCell را در نظر بگیرید<T>"]"> ".
/// [`RefCell<T>`] [`Sync`] نیست و اگر `Arc<T>` همیشه [`Send`] بود ، "Arc <" ["RefCell<T>"]"> نیز هست.
/// اما پس از آن ما یک مشکل خواهیم داشت:
/// [`RefCell<T>`] نخ ایمن نیستاین با استفاده از عملیات غیر اتمی ، میزان وام را ثبت می کند.
///
/// در پایان ، این بدان معنی است که شما ممکن است نیاز به جفت کردن `Arc<T>` با نوعی از نوع [`std::sync`] ، معمولاً [`Mutex<T>`][mutex] داشته باشید.
///
/// ## چرخه های شکستن با `Weak`
///
/// از روش [`downgrade`][downgrade] می توان برای ایجاد یک اشاره گر [`Weak`] غیر مالک استفاده کرد.یک نشانگر [`Weak`] می تواند ["upgrade"][ارتقا] d به `Arc` باشد ، اما اگر مقدار ذخیره شده در تخصیص قبلاً کاهش یافته باشد ، این [`None`] را برمی گرداند.
/// به عبارت دیگر ، اشاره گرهای `Weak` مقدار داخل تخصیص را زنده نگه نمی دارند.با این حال ، آنها * تخصیص (فروشگاه پشتیبان ارزش) را زنده نگه می دارند.
///
/// چرخه ای بین اشاره گرهای `Arc` هرگز از جای خود جدا نخواهد شد.
/// به همین دلیل ، [`Weak`] برای شکستن چرخه ها استفاده می شود.به عنوان مثال ، یک درخت می تواند نشانگرهای `Arc` قوی از گره های والدین به سمت کودکان داشته باشد ، و نشانگرهای [`Weak`] از کودکان به والدین خود برگردانده شوند.
///
/// # منابع شبیه سازی
///
/// ایجاد یک مرجع جدید از یک اشاره گر شمارش شده مرجع موجود با استفاده از `Clone` trait پیاده سازی شده برای [`Arc<T>`][Arc] و [`Weak<T>`][Weak] انجام می شود.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // دو نحو زیر برابر است.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a ، b ، و foo همه کمان هایی هستند که به همان مکان حافظه اشاره می کنند
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` به طور خودکار مراجعه به `T` (از طریق [`Deref`][deref] trait) انجام می شود ، بنابراین می توانید روش های "T" را در مقداری از نوع `Arc<T>` فراخوانی کنید.برای جلوگیری از درگیری نام با روش های "T" ، روش های `Arc<T>` خود توابع مرتبط هستند که با استفاده از [fully qualified syntax] نامیده می شوند:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `قوس<T>"پیاده سازی traits مانند `Clone` همچنین ممکن است با استفاده از نحو کاملاً واجد شرایط فراخوانی شود.
/// بعضی از افراد ترجیح می دهند از نحو کاملاً واجد شرایط استفاده کنند ، در حالی که دیگران ترجیح می دهند از نحو فراخوانی روش استفاده کنند.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // نحو فراخوانی روش
/// let arc2 = arc.clone();
/// // نحو کاملاً واجد شرایط
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] به `T` مراجعه مجدد خودکار نمی کند ، زیرا ممکن است مقدار داخلی قبلاً کاهش یافته باشد.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// به اشتراک گذاری داده های تغییرناپذیر بین موضوعات:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// توجه داشته باشید که ما ** این تست ها را در اینجا اجرا نمی کنیم.
// سازندگان windows اگر رشته ای از رشته اصلی زنده مانده و در همان زمان از آن خارج شود (بن بست) بسیار ناراضی می شوند ، بنابراین ما فقط با عدم اجرای این تست ها کاملاً از این امر جلوگیری می کنیم.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// اشتراک [`AtomicUsize`] قابل تغییر:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// برای نمونه های بیشتر شمارش مرجع به طور کلی به [`rc` documentation][rc_examples] مراجعه کنید.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` نسخه ای از [`Arc`] است که اشاره ای غیر اختصاصی به تخصیص مدیریت شده دارد.
/// این تخصیص با تماس [`upgrade`] در نشانگر `Weak` قابل دسترسی است ، که یک ["Option" ""<"["Arc"] را برمی گرداند<T>> "
///
/// از آنجا که یک مرجع `Weak` به عنوان مالکیت به حساب نمی آید ، از کاهش مقدار ذخیره شده در تخصیص جلوگیری نخواهد کرد و `Weak` خود تضمینی در مورد ارزش موجود نیست.
///
/// بنابراین ممکن است [`None`] را هنگامی که ["ارتقا" دهید d بازگرداند.
/// با این حال توجه داشته باشید که یک مرجع `Weak` * از اختصاص محل اختصاص خود (فروشگاه پشتیبان) جلوگیری می کند.
///
/// یک اشاره گر `Weak` برای داشتن اشاره ای موقتی به تخصیص مدیریت شده توسط [`Arc`] بدون جلوگیری از افت مقدار داخلی آن مفید است.
/// این همچنین برای جلوگیری از مراجعات دایره ای بین اشاره گرهای [`Arc`] استفاده می شود ، زیرا منابع مالکیت متقابل هرگز اجازه نمی دهد که [`Arc`] کنار گذاشته شود.
/// به عنوان مثال ، یک درخت می تواند نشانگرهای [`Arc`] قوی از گره های والدین گرفته تا فرزندان داشته باشد ، و اشاره گرهای `Weak` از کودکان به والدین خود بازگردند.
///
/// روش معمول برای بدست آوردن اشاره گر `Weak` تماس با [`Arc::downgrade`] است.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // این `NonNull` است که امکان بهینه سازی اندازه این نوع در enum ها را می دهد ، اما لزوماً یک اشاره گر معتبر نیست.
    //
    // `Weak::new` این را روی `usize::MAX` تنظیم می کند تا نیازی به اختصاص فضای روی پشته نباشد.
    // این مقداری نیست که یک اشاره گر واقعی داشته باشد زیرا RcBox حداقل 2 تراز دارد.
    // این فقط در صورت `T: Sized` امکان پذیر است.`T` بدون اندازه آویزان نیست.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// این از repr(C) به future در برابر تغییر شکل مجدد درست است ، که در غیر این صورت [into|from]_raw() امن از انواع داخلی قابل تغییر اختلال ایجاد می کند.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // مقدار usize::MAX به عنوان یک نگهبان برای موقت "locking" توانایی به روز رسانی اشاره گرهای ضعیف یا تنزل درجه قوی را دارد.این برای جلوگیری از مسابقات در `make_mut` و `get_mut` استفاده می شود.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// `Arc<T>` جدیدی را می سازد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // شمارش ضعیف را به عنوان 1 شروع کنید که نشانگر ضعیفی است که توسط تمام نشانگرهای قوی (kinda) نگه داشته می شود ، برای اطلاعات بیشتر به std/rc.rs مراجعه کنید
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// `Arc<T>` جدید را با استفاده از مراجعه ضعیف به خود می سازد.
    /// تلاش برای به روزرسانی مرجع ضعیف قبل از بازگشت این عملکرد منجر به مقدار `None` می شود.
    /// با این حال ، مرجع ضعیف ممکن است آزادانه کلون شود و برای استفاده در زمان بعدی ذخیره شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // داخلی را در حالت "uninitialized" با یک مرجع ضعیف بسازید.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // مهم است که ما از مالکیت نشانگر ضعیف دست نکشیم ، در غیر این صورت ممکن است حافظه با بازگشت `data_fn` آزاد شود.
        // اگر واقعاً می خواستیم مالکیت خود را به تصویب برسانیم ، می توانستیم یک نشانگر ضعیف اضافی برای خود ایجاد کنیم ، اما این امر منجر به بروزرسانی های اضافی برای تعداد مرجع ضعیف می شود که در غیر این صورت دیگر لازم نیست.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // اکنون می توانیم مقدار درونی را به درستی مقدماتی کرده و مرجع ضعیف خود را به یک مرجع قوی تبدیل کنیم.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // نوشتن فوق در قسمت داده باید برای هر موضوعی که شمارش قوی غیر صفر را مشاهده می کند قابل مشاهده باشد.
            // بنابراین برای همگام سازی با `compare_exchange_weak` در `Weak::upgrade` حداقل به سفارش "Release" نیاز داریم.
            //
            // "Acquire" سفارش لازم نیست
            // هنگام بررسی رفتارهای احتمالی `data_fn` ، فقط باید ببینیم که با مراجعه به `Weak` غیرقابل ارتقا چه کاری می تواند انجام دهد:
            //
            // - این می تواند * `Weak` را کلون کند و تعداد مرجع ضعیف را افزایش دهد.
            // - این می تواند آن کلون ها را رها کند و تعداد مرجع ضعیف را کاهش دهد (اما هرگز به صفر برسد)
            //
            // این عوارض به هیچ وجه بر ما تأثیر نمی گذارد و هیچ عارضه جانبی دیگری فقط با کد ایمن امکان پذیر نیست.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // مراجع قوی باید بصورت جمعی دارای یک مرجع ضعیف مشترک باشند ، بنابراین تخریب کننده را برای مرجع ضعیف قدیمی ما اجرا نکنید.
        //
        mem::forget(weak);
        strong
    }

    /// `Arc` جدید با محتوای غیر اولیه ساخته می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Arc` جدید با محتوای غیر اولیه ساخته می شود ، با حافظه پر شده با بایت `0`.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Pin<Arc<T>>` جدیدی را می سازد.
    /// اگر `T` `Unpin` را پیاده سازی نکند ، `data` در حافظه پین می شود و نمی تواند جابجا شود.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// `Arc<T>` جدید را می سازد ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // شمارش ضعیف را به عنوان 1 شروع کنید که نشانگر ضعیفی است که توسط تمام نشانگرهای قوی (kinda) نگه داشته می شود ، برای اطلاعات بیشتر به std/rc.rs مراجعه کنید
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// `Arc` جدید با محتوای غیر اولیه ساخته می شود ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `Arc` جدید با محتوای غیر اولیه ساخته می شود ، حافظه با `0` بایت پر می شود ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// اگر `Arc` دقیقاً یک مرجع قوی داشته باشد مقدار داخلی را برمی گرداند.
    ///
    /// در غیر این صورت ، یک [`Err`] با همان `Arc` که به آنجا منتقل شده است بازگردانده می شود.
    ///
    ///
    /// این موفقیت حتی اگر منابع ضعیف برجسته وجود داشته باشد ، موفقیت آمیز خواهد بود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // برای تمیز کردن مرجع ضعیف قوی-ضعیف ، یک اشاره گر ضعیف درست کنید
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// یک قطعه جدید با شمارش مرجع اتمی با محتوای غیر اولیه ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// یک قطعه جدید با شمارش مرجع اتمی با محتوای غیر اولیه ساخته می شود ، با حافظه پر شده با بایت `0`.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// به `Arc<T>` تبدیل می شود.
    ///
    /// # Safety
    ///
    /// همانطور که با [`MaybeUninit::assume_init`] ، تضمین اینکه ارزش داخلی واقعاً در حالت اولیه قرار دارد ، به عهده تماس گیرنده است.
    ///
    /// وقتی این محتوا هنوز کاملاً اولیه نشده است ، فراخوانی آن باعث رفتار فوری تعریف نشده می شود.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// به `Arc<[T]>` تبدیل می شود.
    ///
    /// # Safety
    ///
    /// همانطور که با [`MaybeUninit::assume_init`] ، تضمین اینکه ارزش داخلی واقعاً در حالت اولیه قرار دارد ، به عهده تماس گیرنده است.
    ///
    /// وقتی این محتوا هنوز کاملاً اولیه نشده است ، فراخوانی آن باعث رفتار فوری تعریف نشده می شود.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// `Arc` را مصرف می کند ، نشانگر بسته بندی شده را برمی گرداند.
    ///
    /// برای جلوگیری از نشت حافظه ، اشاره گر باید با استفاده از [`Arc::from_raw`] به `Arc` تبدیل شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// یک نشانگر خام برای داده ها فراهم می کند.
    ///
    /// شمارش به هیچ وجه تحت تأثیر قرار نمی گیرد و `Arc` مصرف نمی شود.
    /// نشانگر تا زمانی معتبر است که تعداد زیادی در `Arc` وجود داشته باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // ایمنی: این نمی تواند از طریق Deref::deref یا RcBoxPtr::inner عبور کند زیرا
        // این برای حفظ منشأ raw/mut لازم است به عنوان مثال
        // `get_mut` پس از بازیابی Rc از طریق `from_raw` می تواند از طریق نشانگر بنویسد.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// `Arc<T>` را از یک نشانگر خام می سازد.
    ///
    /// نشانگر خام باید قبلاً با فراخوانی به [`Arc<U>::into_raw`][into_raw] برگردانده شده باشد که `U` باید همان اندازه و ترازوی `T` باشد.
    /// این اگر `U` `T` باشد به طور پیش پا افتاده درست است.
    /// توجه داشته باشید که اگر `U` `T` نباشد اما اندازه و ترازوی یکسانی داشته باشد ، این اساساً مانند انتقال منابع از انواع مختلف است.
    /// برای کسب اطلاعات بیشتر در مورد محدودیت هایی که در این مورد اعمال می شود ، به [`mem::transmute`][transmute] مراجعه کنید.
    ///
    /// کاربر `from_raw` باید مطمئن شود که مقدار مشخصی از `T` فقط یک بار کاهش می یابد.
    ///
    /// این عملکرد ایمن نیست زیرا استفاده نادرست ممکن است منجر به عدم امنیت حافظه شود ، حتی اگر `Arc<T>` برگشتی هرگز دسترسی پیدا نکند.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // برای جلوگیری از نشت ، دوباره به `Arc` تبدیل کنید.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // تماس های بیشتر با `Arc::from_raw(x_ptr)` حافظه ایمن نیست.
    /// }
    ///
    /// // وقتی `x` از محدوده فوق خارج شد ، حافظه آزاد شد ، بنابراین `x_ptr` اکنون آویزان است!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // برای پیدا کردن ArcInner اصلی ، افست را معکوس کنید.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// یک نشانگر [`Weak`] جدید برای این تخصیص ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // این Relaxed مشکلی ندارد زیرا ما در CAS زیر مقدار را بررسی می کنیم.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // بررسی کنید که آیا شمارنده ضعیف در حال حاضر "locked" است.اگر چنین است ، چرخش کنید.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: این کد در حال حاضر امکان سرریز را نادیده می گیرد
            // به usize::MAX ؛به طور کلی Rc و Arc برای مقابله با سرریز باید تنظیم شوند.
            //

            // برخلاف Clone() ، ما برای همگام سازی با نوشتارهایی که از `is_unique` می آیند ، ما باید این یک خواندن اکتسابی باشد ، به طوری که وقایع قبل از آن نوشتن قبل از خواندن اتفاق می افتد.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // اطمینان حاصل کنید که ما یک ضعیف آویز ایجاد نمی کنیم
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// تعداد نشانگرهای [`Weak`] را برای این تخصیص دریافت می کند.
    ///
    /// # Safety
    ///
    /// این روش به خودی خود ایمن است ، اما استفاده صحیح از آن نیاز به مراقبت بیشتر دارد.
    /// موضوع دیگر می تواند تعداد ضعیف را در هر زمان تغییر دهد ، از جمله به طور بالقوه بین فراخوانی این روش و عمل به نتیجه.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // این ادعا قطعی است زیرا ما `Arc` یا `Weak` را بین رشته ها به اشتراک نگذاشته ایم.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // اگر شمارش ضعیف در حال حاضر قفل شده باشد ، مقدار شمارش قبل از گرفتن قفل 0 بود.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// تعداد نشانگرهای قوی (`Arc`) را برای این تخصیص بدست می آورد.
    ///
    /// # Safety
    ///
    /// این روش به خودی خود ایمن است ، اما استفاده صحیح از آن نیاز به مراقبت بیشتر دارد.
    /// موضوع دیگر می تواند شمارش قوی را در هر زمان تغییر دهد ، از جمله به طور بالقوه بین فراخوانی این روش و عمل به نتیجه.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // این ادعا قطعی است زیرا ما `Arc` را بین رشته ها به اشتراک نگذاشته ایم.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// تعداد مرجع قوی `Arc<T>` مربوط به نشانگر ارائه شده را یکی افزایش می دهد.
    ///
    /// # Safety
    ///
    /// اشاره گر باید از طریق `Arc::into_raw` بدست آمده باشد و نمونه `Arc` مرتبط باید معتبر باشد (یعنی
    /// برای مدت زمان استفاده از این روش ، شمارش قوی باید حداقل 1 باشد).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // این ادعا قطعی است زیرا ما `Arc` را بین رشته ها به اشتراک نگذاشته ایم.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Arc را حفظ کنید ، اما با بسته شدن در ManualDrop ، حساب مجدد را لمس نکنید
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // اکنون تخفیف را افزایش دهید ، اما تخفیف جدید را نیز رها نکنید
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// تعداد مرجع قوی `Arc<T>` مربوط به نشانگر ارائه شده را یکی کاهش می دهد.
    ///
    /// # Safety
    ///
    /// اشاره گر باید از طریق `Arc::into_raw` بدست آمده باشد و نمونه `Arc` مرتبط باید معتبر باشد (یعنی
    /// هنگام استناد به این روش ، شمارش قوی باید حداقل 1 باشد).
    /// این روش می تواند برای آزاد کردن `Arc` نهایی و حافظه پشتیبان مورد استفاده قرار گیرد ، اما **پس از انتشار `Arc` نهایی ، نباید** فراخوانی شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // این ادعاها قطعی هستند زیرا ما `Arc` را بین رشته ها به اشتراک نگذاشته ایم.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // این عدم ایمنی درست است زیرا در حالی که این قوس زنده است ، ما معتبر بودن نشانگر داخلی هستیم.
        // علاوه بر این ، ما می دانیم که ساختار `ArcInner` خود `Sync` است زیرا داده های داخلی نیز `Sync` است ، بنابراین ما می توانیم یک اشاره گر تغییرناپذیر برای این مطالب وام دهیم.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // بخشی بدون خط `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // در این زمان داده ها را از بین ببرید ، حتی اگر ممکن است تخصیص جعبه را آزاد نکنیم (هنوز هم ممکن است نشانگرهای ضعیفی در اطراف وجود داشته باشد).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // رفرنسینگ ضعیف را به طور جمعی در اختیار همه مراجع قوی قرار دهید
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` را برمی گرداند اگر دو `Arc` s به تخصیص یکسانی اشاره کنند (در یک مسیر شبیه به [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// `ArcInner<T>` را با فضای کافی برای یک مقدار داخلی که احتمالاً بدون اندازه باشد در جایی که مقدار آن طرح ارائه شده اختصاص می دهد.
    ///
    /// عملکرد `mem_to_arcinner` با نشانگر داده فراخوانی می شود و باید یک نشانگر (بالقوه چربی) را برای `ArcInner<T>` برگرداند.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // طرح را با استفاده از طرح مقدار داده شده محاسبه کنید.
        // پیش از این ، طرح بندی روی عبارت `&*(ptr as* const ArcInner<T>)` محاسبه می شد ، اما این یک مرجع ناهماهنگ ایجاد کرد (نگاه کنید به #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `ArcInner<T>` را با فضای کافی برای مقادیر داخلی احتمالاً بدون اندازه اختصاص می دهد در جایی که مقدار آن طرح ارائه شده است ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند.
    ///
    ///
    /// عملکرد `mem_to_arcinner` با نشانگر داده فراخوانی می شود و باید یک نشانگر (بالقوه چربی) را برای `ArcInner<T>` برگرداند.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // طرح را با استفاده از طرح مقدار داده شده محاسبه کنید.
        // پیش از این ، طرح بندی روی عبارت `&*(ptr as* const ArcInner<T>)` محاسبه می شد ، اما این یک مرجع ناهماهنگ ایجاد کرد (نگاه کنید به #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ArcInner را آغاز کنید
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// `ArcInner<T>` را با فضای کافی برای یک مقدار درونی بدون اندازه اختصاص می دهد.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // با استفاده از مقدار داده شده برای `ArcInner<T>` تخصیص دهید.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // مقدار را به عنوان بایت کپی کنید
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // تخصیص را بدون انداختن محتوای آن آزاد کنید
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// `ArcInner<[T]>` را با طول داده شده اختصاص می دهد.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// عناصر را از برش در Arc </[T\]> تازه تخصیص داده شده کپی کنید
    ///
    /// ناامن است زیرا تماس گیرنده یا باید مالکیت مالکیت را کسب کند یا `T: Copy` را ملزم کند.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// `Arc<[T]>` را از تکرار کننده ای که اندازه مشخصی دارد می سازد.
    ///
    /// اگر اندازه اشتباه باشد ، رفتار تعریف نشده است.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // هنگام شبیه سازی عناصر T از محافظ Panic محافظت می کند.
        // در صورت وجود panic ، عناصری که در ArcInner جدید نوشته شده اند رها می شوند و سپس حافظه آزاد می شود.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // اشاره گر به عنصر اول
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // همه چیز روشن است.محافظ را فراموش کنید تا ArcInner جدید آزاد نشود.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// تخصصی trait که برای `From<&[T]>` استفاده می شود.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// یک کلون از اشاره گر `Arc` ایجاد می کند.
    ///
    /// این یک اشاره گر دیگر به همان تخصیص ایجاد می کند ، و تعداد مرجع قوی را افزایش می دهد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // استفاده از یک مرتب سازی آرام در اینجا اشکالی ندارد ، زیرا دانش در مورد مرجع اصلی از حذف اشتباه موضوعات توسط سایر موضوعات جلوگیری می کند.
        //
        // همانطور که در [Boost documentation][1] توضیح داده شده است ، افزایش شمارنده مرجع همیشه با Memory_order_relaxed می تواند انجام شود: ارجاعات جدید به یک شی فقط از یک مرجع موجود تشکیل می شود و انتقال یک مرجع موجود از یک موضوع به موضوع دیگر باید از قبل هماهنگی لازم را داشته باشد.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // با این حال ما باید در برابر تخفیف های عظیم در صورت کسی که "قوس" را فراموش و فراموش می کند ، محافظت کنیم.
        // اگر این کار را نکنیم ، شمارش می تواند سرریز شود و کاربران پس از استفاده رایگان از آن استفاده می کنند.
        // ما از نظر نژادی با `isize::MAX` اشباع می شویم با این فرض که هیچ رشته ~2 میلیاردی وجود ندارد که تعداد مرجع را به یک باره افزایش دهد.
        //
        // این branch هرگز در هیچ برنامه واقع گرایانه ای مورد استفاده قرار نمی گیرد.
        //
        // ما سقط می کنیم زیرا چنین برنامه ای به طرز باورنکردنی رو به زوال است و اهمیتی برای حمایت از آن نداریم.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// به `Arc` داده شده اشاره قابل تغییر می کند.
    ///
    /// اگر نشانگرهای `Arc` یا [`Weak`] دیگری به همان تخصیص وجود داشته باشد ، `make_mut` تخصیص جدیدی ایجاد می کند و برای اطمینان از مالکیت منحصر به فرد ، [`clone`][clone] را به مقدار داخلی فراخوانی می کند.
    /// این نیز به عنوان کلون نوشتن است.
    ///
    /// توجه داشته باشید که این با رفتار [`Rc::make_mut`] متفاوت است که هر نشانگر `Weak` باقی مانده را جدا می کند.
    ///
    /// همچنین به [`get_mut`][get_mut] مراجعه کنید ، که به جای شبیه سازی شکست می خورد.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // هیچ چیزی شبیه سازی نمی شود
    /// let mut other_data = Arc::clone(&data); // داده های داخلی کلون نخواهد شد
    /// *Arc::make_mut(&mut data) += 1;         // داده های داخلی را کلون می کند
    /// *Arc::make_mut(&mut data) += 1;         // هیچ چیزی شبیه سازی نمی شود
    /// *Arc::make_mut(&mut other_data) *= 2;   // هیچ چیزی شبیه سازی نمی شود
    ///
    /// // اکنون `data` و `other_data` به تخصیص های مختلف اشاره دارند.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // توجه داشته باشید که ما هم یک مرجع قوی داریم و هم یک مرجع ضعیف.
        // بنابراین ، آزاد کردن مرجع قوی ما فقط باعث جدا شدن حافظه نخواهد شد.
        //
        // برای اطمینان از اینکه هرگونه نوشتن در `weak` قبل از نوشتن نسخه (یعنی کاهش) در `strong` رخ می دهد ، از Acquire استفاده کنید.
        // از آنجایی که ما تعداد ضعیفی داریم ، هیچ شانسی برای جابجایی ArcInner وجود ندارد.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // یک اشاره گر قوی دیگر وجود دارد ، بنابراین ما باید شبیه سازی کنیم.
            // از قبل حافظه را اختصاص دهید تا مستقیماً مقدار شبیه سازی شده را بنویسید.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // در موارد فوق ، آرامش کافی است زیرا این اساساً یک بهینه سازی است: ما همیشه در حال رها شدن از نشانگرهای ضعیف هستیم.
            // بدترین حالت ، ما در نهایت بدون نیاز به یک Arc جدید اختصاص دادیم.
            //

            // ما آخرین مرجع قوی را حذف کردیم ، اما رفرهای ضعیف اضافی باقی مانده است.
            // ما محتویات را به یک Arc جدید منتقل می کنیم ، و سایر موارد ضعیف را باطل می کنیم.
            //

            // توجه داشته باشید که امکان خواندن `weak` برای usize::MAX (به عنوان مثال قفل شده) امکان پذیر نیست ، زیرا شمارش ضعیف فقط توسط یک نخ با یک مرجع قوی قفل می شود.
            //
            //

            // اشاره گر ضعیف ضمنی خود را تحقق بخشید ، تا بتواند ArcInner را در صورت لزوم تمیز کند.
            //
            let _weak = Weak { ptr: this.ptr };

            // فقط می تواند داده ها را بدزدد ، تنها چیزی که ضعیف است باقی مانده است
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ما تنها مرجع هر دو نوع بودیم.شمارش مجدد قوی را پشت سر بگذارید.
            //
            this.inner().strong.store(1, Release);
        }

        // همانند `get_mut()` ، عدم ایمنی مناسب است زیرا مرجع ما برای شروع منحصر به فرد بود ، یا با شبیه سازی محتوا یکی شد.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// اگر هیچ نشانگر `Arc` یا [`Weak`] دیگری به همان تخصیص نداشته باشد ، یک مرجع قابل تغییر را به `Arc` داده شده برمی گرداند.
    ///
    ///
    /// در غیر این صورت [`None`] را برمی گرداند ، زیرا تغییر در یک مقدار مشترک ایمن نیست.
    ///
    /// همچنین به [`make_mut`][make_mut] مراجعه کنید ، که در صورت وجود اشاره گرهای دیگر مقدار داخلی [`clone`][clone] خواهد بود.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // این عدم ایمنی درست است زیرا ما تضمین می کنیم که نشانگر برگشته *تنها* اشاره گر است که هرگز به T برگردانده خواهد شد.
            // تعداد مرجع ما در این مرحله تضمین شده است 1 ، و ما خود Arc را به `mut` نیاز داریم ، بنابراین ما تنها مرجع ممکن را به داده های داخلی برمی گردانیم.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// بدون هیچ گونه بررسی ، مرجع قابل تغییر را به `Arc` داده شده برمی گرداند.
    ///
    /// به [`get_mut`] نیز مراجعه کنید که بی خطر است و بررسی های مناسب را انجام می دهد.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// برای سایر وام های `Arc` یا [`Weak`] به همان تخصیص نباید در مدت زمان وام برگشتی مراجعه شود.
    ///
    /// در صورت عدم وجود چنین اشاره گرهایی ، به عنوان مثال بلافاصله بعد از `Arc::new` ، این امر بی اهمیت است.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ما مراقب هستیم که *نه* مرجعی را که زمینه های "count" را پوشش می دهد ایجاد کنیم ، زیرا این نام مستعار با دسترسی همزمان به تعداد مرجع است (به عنوان مثال
        // توسط `Weak`)
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// تعیین کنید که آیا این مرجع منحصر به فرد (از جمله Refs ضعیف) به داده های اساسی است.
    ///
    ///
    /// توجه داشته باشید که این نیاز به قفل کردن شمارش ضعیف دارد.
    fn is_unique(&mut self) -> bool {
        // اگر به نظر می رسد تنها نگهدارنده ضعیف نشانگر است ، تعداد ضعیف نشانگر را قفل کنید.
        //
        // برچسب کسب در اینجا قبل از کاهش تعداد `weak` (از طریق `Weak::drop` ، که از انتشار استفاده می کند) رابطه اتفاقی قبل از هرگونه نوشتن با `strong` (به ویژه در `Weak::upgrade`) را تضمین می کند.
        // اگر هرگز از ضعف به روزرسانی شده به پایین استفاده نکنید ، CAS در اینجا خراب می شود بنابراین ما برای همگام سازی اهمیتی نمی دهیم.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // این باید `Acquire` باشد تا با کاهش شمارنده `strong` در `drop` هماهنگ شود-تنها دسترسی که در صورت قطع هرگونه مرجع انجام می شود ، اما آخرین دسترسی.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // نوشتن نسخه در اینجا با خواندن در `downgrade` هماهنگ می شود و به طور موثر از وقوع خواندن فوق `strong` پس از نوشتن جلوگیری می کند.
            //
            //
            self.inner().weak.store(1, Release); // قفل را رها کنید
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` را رها می کند.
    ///
    /// این باعث کاهش تعداد مرجع شدید می شود.
    /// اگر تعداد مرجع قوی به صفر برسد ، تنها منابع دیگر (در صورت وجود) [`Weak`] هستند ، بنابراین مقدار داخلی `drop` است.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // چیزی چاپ نمی کند
    /// drop(foo2);   // چاپ "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // از آنجا که `fetch_sub` از قبل اتمی است ، نیازی به همگام سازی با سایر رشته ها نیست ، مگر اینکه بخواهیم جسم را حذف کنیم.
        // این منطق مشابه در `fetch_sub` زیر به تعداد `weak` اعمال می شود.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // این حصار برای جلوگیری از مرتب سازی مجدد استفاده از داده ها و حذف داده ها مورد نیاز است.
        // از آنجا که با `Release` مشخص شده است ، کاهش تعداد مرجع با این حصار `Acquire` هماهنگ می شود.
        // این به این معنی است که استفاده از داده ها قبل از کاهش تعداد مرجع ، که قبل از این حصار اتفاق می افتد ، قبل از حذف داده ها اتفاق می افتد.
        //
        // همانطور که در [Boost documentation][1] توضیح داده شده است ،
        //
        // > اجرای هرگونه دسترسی احتمالی به شی در یک مورد مهم است
        // > موضوع (از طریق یک مرجع موجود) به *قبل از* حذف اتفاق می افتد
        // > شی در یک موضوع متفاوت است.این توسط "release" حاصل می شود
        // > عملیات پس از انداختن مرجع (دسترسی به جسم)
        // > از طریق این مرجع باید قبلاً اتفاق افتاده باشد) ، و
        // > "acquire" قبل از حذف شی.
        //
        // به طور خاص ، اگرچه محتویات یک Arc معمولاً تغییرناپذیر است ، وجود نوشتن داخلی برای چیزی مانند Mutex امکان پذیر است<T>.
        // از آنجا که Mutex هنگام حذف به دست نمی آید ، نمی توانیم به منطق همگام سازی آن اعتماد کنیم تا نوشتن در موضوع A را برای یک تخریب کننده در موضوع B قابل مشاهده کند.
        //
        //
        // همچنین توجه داشته باشید که حصار اکتساب در اینجا احتمالاً می تواند با یک بار اکتساب جایگزین شود ، که می تواند عملکرد را در شرایط کاملاً ادعایی بهبود بخشد.به [2] مراجعه کنید.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// تلاش برای پایین آوردن `Arc<dyn Any + Send + Sync>` به یک نوع بتن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// بدون اختصاص حافظه ، `Weak<T>` جدیدی را می سازد.
    /// تماس با [`upgrade`] در مقدار برگشتی همیشه [`None`] را نشان می دهد.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// نوع یاور را برای دسترسی به تعداد مرجع بدون ایجاد هیچ گونه ادعا در مورد قسمت داده ، تایپ کنید.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// یک اشاره گر خام را به شی `T` نشان داده شده توسط این `Weak<T>` برمی گرداند.
    ///
    /// اشاره گر فقط در صورت وجود چند منبع قوی معتبر است.
    /// در غیر اینصورت ممکن است نشانگر آویزان ، غیر تراز شده یا حتی [`null`] باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // هر دو به یک شی اشاره می کنند
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // نیرومند در اینجا آن را زنده نگه می دارد ، بنابراین ما هنوز می توانیم به جسم دسترسی داشته باشیم
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // اما دیگر نه
    /// // ما می توانیم weak.as_ptr() را انجام دهیم ، اما دسترسی به نشانگر منجر به رفتار تعریف نشده می شود.
    /// // assert_eq! ("سلام" ، ناامن {&*weak.as_ptr() })؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // اگر نشانگر آویزان باشد ، نگهبان را مستقیماً برمی گردانیم.
            // این نمی تواند یک آدرس بار مجاز باشد ، زیرا بار حمل و نقل حداقل به همان اندازه ArcInner (usize) تراز شده است.
            ptr as *const T
        } else {
            // ایمنی: اگر is_dangling نادرست است ، نشانگر قابل استناد است.
            // ممکن است بار در این مرحله کاهش یابد و ما باید منشأ خود را حفظ کنیم ، بنابراین از دستکاری اشاره گر خام استفاده کنید.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` را مصرف می کند و آن را به یک نشانگر خام تبدیل می کند.
    ///
    /// این نشانگر ضعیف را به یک نشانگر خام تبدیل می کند ، در حالی که همچنان مالکیت یک مرجع ضعیف را حفظ می کند (تعداد ضعیف با این عمل اصلاح نمی شود).
    /// با [`from_raw`] می توان آن را به `Weak<T>` تبدیل کرد.
    ///
    /// همان محدودیت های دستیابی به هدف نشانگر همانند [`as_ptr`] است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// یک اشاره گر خام که قبلاً توسط [`into_raw`] ایجاد شده بود را به `Weak<T>` تبدیل می کند.
    ///
    /// این می تواند برای بدست آوردن یک مرجع قوی با اطمینان (با تماس گرفتن با [`upgrade`] بعدا) یا برای جدا کردن تعداد ضعیف با انداختن `Weak<T>` استفاده شود.
    ///
    /// مالکیت یک مرجع ضعیف را به خود اختصاص می دهد (به استثنای اشاره گرهای ایجاد شده توسط [`new`] ، زیرا اینها هیچ چیز ندارند ؛ روش هنوز هم روی آنها کار می کند).
    ///
    /// # Safety
    ///
    /// این نشانگر باید از [`into_raw`] سرچشمه گرفته باشد و هنوز هم باید مرجع ضعیف احتمالی خود را داشته باشد.
    ///
    /// مجاز است شمارش قوی در زمان فراخوانی این 0 باشد.
    /// با این وجود ، این مالکیت یک مرجع ضعیف است که در حال حاضر به عنوان یک نشانگر خام نشان داده شده است (تعداد ضعیف با این عمل اصلاح نمی شود) و بنابراین باید با تماس قبلی با [`into_raw`] جفت شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // آخرین شمارش ضعیف را تقلیل دهید.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // برای چگونگی استخراج نشانگر ورودی به Weak::as_ptr مراجعه کنید.

        let ptr = if is_dangling(ptr as *mut T) {
            // این یک ضعف آویز است.
            ptr as *mut ArcInner<T>
        } else {
            // در غیر این صورت ، ما تضمین می کنیم که نشانگر از یک ضعیف ضعیف ظاهر شده است.
            // ایمنی: تماس با data_offset بی خطر است ، زیرا ptr به T واقعی (به طور بالقوه افتاده) اشاره می کند.
            let offset = unsafe { data_offset(ptr) };
            // بنابراین ، جبران را معکوس می کنیم تا کل RcBox بدست آوریم.
            // ایمنی: این نشانگر از یک ضعف گرفته شده است ، بنابراین این جابجایی ایمن است.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ایمنی: ما اکنون نشانگر ضعیف اصلی را بازیابی کردیم ، بنابراین می توانیم ضعف را ایجاد کنیم.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// تلاش برای ارتقا نشانگر `Weak` به [`Arc`] ، در صورت موفقیت افت ارزش داخلی را به تأخیر می اندازد.
    ///
    ///
    /// اگر مقدار داخلی از آن به بعد کاهش یافته باشد ، [`None`] را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // تمام نشانگرهای قوی را از بین ببرید.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // ما از حلقه CAS برای افزایش شمارش قوی به جای fetch_add استفاده می کنیم زیرا این عملکرد هرگز نباید تعداد مرجع را از صفر به یک برساند.
        //
        //
        let inner = self.inner()?;

        // بار آرام ، زیرا هر نوشتاری از 0 که می توانیم مشاهده کنیم ، این فیلد در یک حالت دائمی صفر خارج می شود (بنابراین خواندن "stale" از 0 خوب است) ، و هر مقدار دیگری از طریق CAS زیر تأیید می شود.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // نظرات `Arc::clone` را برای چرایی این کار (برای `mem::forget`) مشاهده کنید.
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed برای پرونده شکست خوب است زیرا ما هیچ انتظاری در مورد وضعیت جدید نداریم.
            // دستیابی به پرونده موفقیت برای همگام سازی با `Arc::new_cyclic` ضروری است ، وقتی مقدار داخلی می تواند پس از ایجاد منابع `Weak` مقدار دهی اولیه شود.
            // در این صورت ، ما انتظار داریم مقدار کاملاً اولیه را مشاهده کنیم.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null در بالا بررسی شد
                Err(old) => n = old,
            }
        }
    }

    /// تعداد نشانگرهای قوی (`Arc`) را نشان می دهد که به این تخصیص اشاره دارند.
    ///
    /// اگر `self` با استفاده از [`Weak::new`] ایجاد شده باشد ، این 0 را برمی گرداند.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// تقریب تعداد نشانگرهای `Weak` را نشان می دهد که به این تخصیص اشاره دارند.
    ///
    /// اگر `self` با استفاده از [`Weak::new`] ایجاد شده باشد ، یا اگر هیچ نشانگر قوی باقی نمانده باشد ، این 0 را برمی گرداند.
    ///
    /// # Accuracy
    ///
    /// با توجه به جزئیات پیاده سازی ، هنگامی که رشته های دیگر هر Arc ، یا `Weak` را که به همان تخصیص نشان می دهد ، دستکاری می کنند ، می تواند مقدار 1 را در هر جهت از بین ببرد.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // از آنجا که مشاهده کردیم حداقل یک اشاره گر قوی پس از خواندن شمارش ضعیف وجود دارد ، می دانیم که مرجع ضعیف ضمنی (در صورت زنده بودن هرگونه ارجاع قوی) هنوز در هنگام مشاهده تعداد ضعیف وجود دارد و بنابراین می توانیم با خیال راحت آن را کم کنیم.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// `None` را هنگامی که نشانگر آویزان است و `ArcInner` اختصاصی وجود ندارد برمی گرداند (یعنی وقتی این `Weak` توسط `Weak::new` ایجاد شده است).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ما مراقب هستیم که *یک* مرجع را که قسمت "data" را پوشش می دهد ایجاد نکنیم ، زیرا این فیلد ممکن است همزمان جهش ایجاد کند (به عنوان مثال ، اگر آخرین `Arc` رها شود ، قسمت داده در محل حذف می شود).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// اگر دو Weak `s به تخصیص یکسانی اشاره کنند (مشابه [`ptr::eq`]) ، یا اگر هر دو به تخصیص اشاره نکنند ، `true` را برمی گرداند (زیرا با `Weak::new()`) ایجاد شده اند).
    ///
    ///
    /// # Notes
    ///
    /// از آنجا که این نشانگرها را با هم مقایسه می کند ، به این معنی است که `Weak::new()` برابر یکدیگر خواهند بود ، حتی اگر به هیچ تخصیص اشاره نکنند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// مقایسه `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// یک کلون از نشانگر `Weak` ایجاد می کند که به همان تخصیص اشاره دارد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // برای اینکه چرا این کار آرام است ، در Arc::clone() نظرات را ببینید.
        // این می تواند از fetch_add استفاده کند (قفل را نادیده بگیرید) زیرا تعداد ضعیف فقط در جایی قفل می شود که * نشانگر ضعیف دیگری وجود ندارد.
        //
        // (بنابراین در این صورت نمی توانیم این کد را اجرا کنیم).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // نظرات Arc::clone() را برای چرایی این کار (برای mem::forget) مشاهده کنید.
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// بدون اختصاص حافظه ، `Weak<T>` جدیدی را می سازد.
    /// تماس با [`upgrade`] در مقدار برگشتی همیشه [`None`] را نشان می دهد.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// نشانگر `Weak` را رها می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // چیزی چاپ نمی کند
    /// drop(foo);        // چاپ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // اگر متوجه شویم که ما آخرین اشاره گر ضعیف هستیم ، وقت آن است که داده ها را به طور کامل جدا کنیم.بحث در Arc::drop() در مورد ترتیب حافظه را ببینید
        //
        // در اینجا لازم نیست که حالت قفل شده بررسی شود ، زیرا شمارش ضعیف تنها در صورت قفل شدن دقیقاً یک ref ضعیف قابل قفل است ، به این معنی که قطره فقط پس از آن می تواند روی آن ref ضعیف باقی مانده اجرا شود ، که فقط پس از آزاد شدن قفل می تواند رخ دهد.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ما این تخصص را در اینجا انجام می دهیم و نه به عنوان یک بهینه سازی کلی تر در `&T` ، زیرا در غیر این صورت هزینه ای را برای تمام بررسی های برابری در refs ها اضافه می کند.
/// ما فرض می کنیم که `Arc` s برای ذخیره مقادیر زیادی استفاده می شود ، که کند کلون می شوند ، اما همچنین برای بررسی برابری نیز سنگین هستند و باعث می شوند این هزینه راحت تر پرداخت شود.
///
/// همچنین دارای دو کلون `Arc` ، که به همان مقدار نشان می دهند ، بیشتر از دو کلون&T است.
///
/// ما فقط زمانی می توانیم این کار را انجام دهیم که `T: Eq` به عنوان `PartialEq` ممکن است به عمد بازتابنده باشد.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// برابری برای دو `Arc` s.
    ///
    /// دو `Arc` برابر است اگر مقادیر درونی آنها برابر باشد ، حتی اگر در تخصیص متفاوت ذخیره شوند.
    ///
    /// اگر `T` `Eq` را نیز پیاده سازی کند (نشان دهنده بازتاب پذیری برابری است) ، دو عدد Arc که به یک تخصیص یکسان اشاره دارند ، همیشه برابر هستند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// نابرابری برای دو `Arc` s.
    ///
    /// دو `Arc` اگر ارزش های درونی آنها نابرابر باشد ، نابرابر هستند.
    ///
    /// اگر `T` `Eq` را نیز پیاده سازی کند (نشان دهنده بازتاب پذیری برابری است) ، هر دو Arc که به یک مقدار نشان می دهند هرگز نابرابر هستند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// مقایسه جزئی برای دو `Arc` s.
    ///
    /// این دو با فراخوانی مقادیر درونی `partial_cmp()` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// مقایسه کمتر از دو Arc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `<` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// مقایسه "کمتر از یا برابر" برای دو `Arc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `<=` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// مقایسه بزرگتر از دو Arc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `>` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// مقایسه "بزرگتر یا مساوی" برای دو "Arc` s.
    ///
    /// این دو با فراخوانی مقادیر درونی `>=` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// مقایسه دو `Arc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `cmp()` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `Arc<T>` جدید با مقدار `Default` برای `T` ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// یک برش شمارش شده توسط مرجع را اختصاص دهید و آن را با شبیه سازی موارد "v" پر کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// یک `str` با تعداد مراجعه به حساب اختصاص دهید و `v` را در آن کپی کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// یک `str` با تعداد مراجعه به حساب اختصاص دهید و `v` را در آن کپی کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// یک شی box جعبه ای را به یک تخصیص جدید و با شمارش مرجع منتقل کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// یک برش با شمارش مرجع اختصاص دهید و موارد "v" را به داخل آن منتقل کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // اجازه دهید Vec حافظه خود را آزاد کند ، اما محتوای آن را از بین نبرد
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// هر عنصر را در `Iterator` می گیرد و آن را در `Arc<[T]>` جمع می کند.
    ///
    /// # ویژگی های عملکرد
    ///
    /// ## مورد کلی
    ///
    /// در حالت کلی ، جمع آوری در `Arc<[T]>` با جمع آوری ابتدا در `Vec<T>` انجام می شود.یعنی هنگام نوشتن موارد زیر:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// این رفتار مانند این است که گویی ما نوشتیم:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // اولین مجموعه از تخصیص ها در اینجا اتفاق می افتد.
    ///     .into(); // تخصیص دوم برای `Arc<[T]>` در اینجا اتفاق می افتد.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// این تعداد به تعداد لازم برای ساخت `Vec<T>` اختصاص می یابد و سپس یک بار برای تبدیل `Vec<T>` به `Arc<[T]>` اختصاص می یابد.
    ///
    ///
    /// ## تکرارکنندگان با طول مشخص
    ///
    /// هنگامی که `Iterator` شما `TrustedLen` را پیاده سازی می کند و اندازه آن دقیق است ، یک تخصیص واحد برای `Arc<[T]>` انجام می شود.مثلا:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // فقط یک تخصیص در اینجا اتفاق می افتد.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// تخصص trait برای جمع آوری در `Arc<[T]>` استفاده می شود.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // این مورد برای یک تکرار کننده `TrustedLen` است.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ایمنی: ما باید اطمینان حاصل کنیم که تکرار کننده دارای طول دقیق و ما است.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // به اجرای عادی برگردید.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// با استفاده از `ArcInner` میزان بار را در پشت نشانگر جبران کنید.
///
/// # Safety
///
/// نشانگر باید به یک نمونه قبلی معتبر T اشاره کند (و دارای فراداده معتبری برای آن باشد) ، اما T مجاز به حذف است.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // مقدار بدون اندازه را با انتهای ArcInner تراز کنید.
    // از آنجا که RcBox repr(C) است ، همیشه آخرین قسمت حافظه خواهد بود.
    // ایمنی: از آنجا که تنها انواع بدون اندازه ممکن است برش ها ، اشیا Z trait باشد ،
    // و انواع خارجی ، در حال حاضر نیاز ایمنی ورودی برای تأمین نیازهای align_of_val_raw کافی است.این جزئیات پیاده سازی زبان است که ممکن است خارج از std به آن اعتماد نشود.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}