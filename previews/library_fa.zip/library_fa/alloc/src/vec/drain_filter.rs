use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// تکرار کننده ای که برای تعیین اینکه آیا باید یک عنصر حذف شود ، از یک بسته استفاده می کند.
///
/// این ساختار توسط [`Vec::drain_filter`] ایجاد شده است.
/// برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// نمایه موردی که با تماس بعدی با `next` بازرسی می شود.
    pub(super) idx: usize,
    /// تعداد مواردی که تاکنون (removed) تخلیه شده است.
    pub(super) del: usize,
    /// طول اصلی `vec` قبل از تخلیه.
    pub(super) old_len: usize,
    /// محمول تست فیلتر.
    pub(super) pred: F,
    /// پرچمی که نشانگر panic باشد در محمول آزمایش فیلتر رخ داده است.
    /// این به عنوان یک نکته در اجرای قطره استفاده می شود تا از مصرف باقی مانده `DrainFilter` جلوگیری کند.
    /// هر مورد پردازش نشده در `vec` تغییر جهت خواهد داد ، اما هیچ مورد دیگری توسط محمول فیلتر حذف یا آزمایش نمی شود.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// مرجعی را به تخصیص دهنده اصلی برمی گرداند.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // بعد از فراخوانی * محمول ، شاخص را به روز کنید.
                // اگر شاخص از قبل به روز شود و محمول panics ، عنصر موجود در این شاخص به بیرون درز می کند.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // این وضعیت کاملاً بهم ریخته ای است و در واقع کار صحیحی وجود ندارد.
                        // ما نمی خواهیم تلاش برای اجرای `pred` را ادامه دهیم ، بنابراین ما فقط عناصر پردازش نشده را به عقب برمی گردانیم و به vec می گوییم که آنها هنوز هم وجود دارند.
                        //
                        // برای جلوگیری از افت مضاعف آخرین مورد تخلیه شده با موفقیت قبل از panic در محمول ، تغییر جهت لازم است.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // اگر ماده اولیه هنوز وحشت نکرده است ، سعی کنید عناصر باقی مانده را مصرف کنید.
        // ما عناصر باقیمانده را عوض خواهیم کرد ، چه در حال حاضر وحشت کرده ایم و چه در مصرف panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}