use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// یک تخصص دیگر trait برای Vec::from_iter برای اولویت بندی دستی تخصص های همپوشان ضروری است و برای جزئیات به [`SpecFromIter`](super::SpecFromIter) مراجعه کنید.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // تکرار اول را باز کنید ، زیرا vector در هر موردی که تکرار خالی نباشد ، در این تکرار گسترش می یابد ، اما در extend_desugared() قرار نیست در چند تکرار حلقه بعدی ، vector پر شود.
        //
        // بنابراین ما پیش بینی branch بهتری دریافت می کنیم.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // باید spec_extend() را به وی اختصاص دهد زیرا extend() خود به Vecs خالی به spec_from اختصاص می دهد
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // باید spec_extend() را به وی اختصاص دهد زیرا extend() خود به Vecs خالی به spec_from اختصاص می دهد
        //
        vector.spec_extend(iterator);
        vector
    }
}