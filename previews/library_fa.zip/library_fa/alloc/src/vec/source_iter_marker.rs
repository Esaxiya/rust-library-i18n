use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// نشانگر تخصصی برای جمع آوری خط لوله تکرار کننده به Vec هنگام استفاده مجدد از تخصیص منبع ، یعنی
/// اجرای خط لوله در محل.
///
/// منبع SourceIter trait برای دسترسی به تخصیصی که قرار است دوباره استفاده شود ، لازم است.
/// اما معتبر بودن تخصص کافی نیست.
/// مرزهای اضافی مربوط به مفهوم را مشاهده کنید.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-SourceIter/InPlaceIterable traits داخلی فقط توسط زنجیره های آداپتور اجرا می شود <Adapter<Adapter<IntoIter>>> (همه متعلق به core/std است).
// حدود اضافی مربوط به پیاده سازی آداپتور (فراتر از `impl<I: Trait> Trait for Adapter<I>`) فقط به سایر traits بستگی دارد که قبلاً به عنوان تخصص traits (کپی ، TrustedRandomAccess ، FusedIterator) مشخص شده اند.
//
// I.e. نشانگر به طول عمر انواع ارائه شده توسط کاربر بستگی ندارد.Modulo سوراخ کپی ، که چندین تخصص دیگر از قبل به آن بستگی دارند.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // الزامات اضافی که از طریق trait bounds قابل بیان نیستند.ما در عوض به ساخت و ساز اعتماد می کنیم:
        // الف) هیچ ZST وجود ندارد زیرا هیچ تخصیصی برای استفاده مجدد و حساب اشاره گر وجود ندارد panic ب) مطابقت اندازه مطابق با الزام قرارداد Alloc ج) ترازها مطابق با الزام قرارداد Alloc مطابقت دارند
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // بازگشت به پیاده سازی های عمومی تر
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // از آنجا استفاده کنید
        // - برای برخی از آداپتورهای تکرارکننده بهتر است
        // - برخلاف بیشتر روشهای تکرار داخلی ، فقط &mut به خودی خود نیاز دارد
        // - به ما اجازه می دهد تا اشاره گر نوشتن را از داخل قسمتهای داخلی آن رد کنیم و در پایان آن را بازگردانیم
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // تکرار موفقیت آمیز است ، سر خود را رها نکنید
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // بررسی کنید که آیا قرارداد SourceIter با تأیید تأیید شده است یا خیر: اگر آنها نبودند ، ما حتی نمی توانیم به این مرحله برسیم
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // قرارداد InPlaceIterable را بررسی کنید.این فقط در صورتی امکان پذیر است که تکرار کننده به طور کلی نشانگر منبع را پیش ببرد.
        // اگر از دسترسی بدون علامت از طریق TrustedRandomAccess استفاده کند ، نشانگر منبع در موقعیت اولیه خود باقی می ماند و ما نمی توانیم از آن به عنوان مرجع استفاده کنیم
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // اگر مقدار panics از محدوده خارج شود ، مقادیر باقی مانده را در انتهای منبع رها کنید اما از افت تخصیص جلوگیری کنید ، ما همچنین عناصر جمع شده را به dst_buf نشت می کنیم
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // قرارداد InPlaceIterable دقیقاً در اینجا تأیید نمی شود زیرا try_fold اشاره ای اختصاصی به اشاره گر مبدا دارد تنها کاری که ما می توانیم انجام دهیم این است که بررسی کنیم آیا هنوز در محدوده است
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}