// هنگام خارج شدن از محدوده مقدار `SetLenOnDrop` ، طول vec را تنظیم کنید.
//
// ایده این است: قسمت طول در SetLenOnDrop یک متغیر محلی است که بهینه ساز مشاهده می کند با هیچ فروشگاهی از طریق اشاره گر داده Vec نام مستعار ندارد.
// این یک راه حل برای تجزیه و تحلیل مستعار شماره #32155 است
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}