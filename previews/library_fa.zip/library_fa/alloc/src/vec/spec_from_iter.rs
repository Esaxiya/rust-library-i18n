use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// تخصصی trait که برای Vec::from_iter استفاده می شود
///
/// ## نمودار نمایندگی:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // یک مورد متداول ، انتقال vector به تابعی است که بلافاصله دوباره در vector جمع می شود.
        // اگر IntoIter اصلاً پیشرفته نباشد ، می توانیم این اتصال را کوتاه کنیم.
        // وقتی پیشرفته شد ، می توانیم دوباره از حافظه استفاده کرده و داده ها را به جلو منتقل کنیم.
        // اما این کار را فقط درصورتی انجام می دهیم که Vec حاصل از ظرفیت بی استفاده بیشتر از ایجاد ظرفیت از طریق اجرای عمومی FromIterator نداشته باشد.
        //
        // این محدودیت کاملاً ضروری نیست زیرا رفتار تخصیص Vec به عمد مشخص نشده است.
        // اما این یک انتخاب محافظه کارانه است.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // باید spec_extend() را به وی اختصاص دهد زیرا extend() خود به Vecs خالی به spec_from اختصاص می دهد
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// این از `iterator.as_slice().to_vec()` استفاده می کند زیرا spec_extend باید مراحل بیشتری را برای استدلال در مورد ظرفیت نهایی + طول انجام دهد و بنابراین کارهای بیشتری انجام دهد.
// `to_vec()` مستقیماً مقدار صحیح را تخصیص داده و دقیقاً آن را پر می کند.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): با cfg(test) روش ذاتی `[T]::to_vec` ، که برای این تعریف روش لازم است ، در دسترس نیست.
    // در عوض از عملکرد `slice::to_vec` استفاده کنید که فقط با cfg(test) NB در دسترس است برای اطلاعات بیشتر به ماژول slice::hack در slice.rs مراجعه کنید
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}