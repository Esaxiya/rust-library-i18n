use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // نوشتن یک آزمایش ادغام بین تخصیص دهنده های شخص ثالث و `RawVec` کمی مشکل است زیرا `RawVec` API روش های تخصیص پذیری را آشکار نمی کند ، بنابراین ما نمی توانیم بررسی کنیم چه اتفاقی می افتد در صورت اتمام تخصیص دهنده (فراتر از تشخیص panic).
    //
    //
    // در عوض ، این فقط بررسی می کند که روش های `RawVec` هنگام ذخیره سازی فضای ذخیره سازی ، از طریق Allocator API حداقل عبور می کنند.
    //
    //
    //
    //
    //

    // یک تخصیص دهنده گنگ که قبل از شروع تلاش برای تخصیص ، مقدار مشخصی سوخت مصرف می کند.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (باعث ایجاد مجدد محل می شود ، بنابراین از 50 + 150=200 واحد سوخت استفاده می شود)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ابتدا `reserve` مانند `reserve_exact` تخصیص می یابد.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 بیش از دو برابر 7 است ، بنابراین `reserve` باید مانند `reserve_exact` کار کند.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 کمتر از نیمی از 12 است ، بنابراین `reserve` باید رشد نمایی کند.
        // در زمان نوشتن این آزمون ضریب رشد 2 است ، بنابراین ظرفیت جدید 24 است ، با این حال ، فاکتور رشد 1.5 نیز مناسب است.
        //
        // از این رو `>= 18` در ادعا.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}