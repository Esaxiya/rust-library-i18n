//! نوع اشاره گر برای تخصیص پشته.
//!
//! [`Box<T>`], به طور معمول که به عنوان 'box' شناخته می شود ، ساده ترین شکل تخصیص پشته را در Rust فراهم می کند.جعبه ها مالکیت این تخصیص را فراهم می کنند و هنگامی که از محدوده خارج می شوند ، محتوای آنها را رها می کنند.جعبه ها همچنین اطمینان می دهند که هرگز بیش از بایت `isize::MAX` اختصاص نمی دهند.
//!
//! # Examples
//!
//! با ایجاد [`Box`] مقداری را از پشته به پشته انتقال دهید:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! با [dereferencing] مقداری را از [`Box`] به پشته انتقال دهید:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! ایجاد یک ساختار داده بازگشتی:
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! این "Cons" (1 ، Cons(2, Nil))`.
//!
//! ساختارهای بازگشتی باید جعبه بندی شوند ، زیرا اگر تعریف `Cons` به این شکل باشد:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! این کار نمی کنداین بدان دلیل است که اندازه `List` به تعداد عناصر موجود در لیست بستگی دارد و بنابراین نمی دانیم چه مقدار حافظه برای `Cons` اختصاص دهیم.با معرفی [`Box<T>`] ، که اندازه مشخصی دارد ، می دانیم که `Cons` چه اندازه باید بزرگ باشد.
//!
//! # طرح حافظه
//!
//! برای مقادیر غیر صفر ، [`Box`] از تخصیص دهنده [`Global`] برای تخصیص خود استفاده می کند.با توجه به اینکه [`Layout`] استفاده شده با تخصیص دهنده برای نوع صحیح است ، تبدیل هر دو روش بین [`Box`] و اشاره گر خام اختصاص داده شده با تخصیص دهنده [`Global`] معتبر است.
//!
//! به طور دقیق تر ، یک `value:*mut T` که با اختصاص دهنده [`Global`] با `Layout::for_value(&* value)` اختصاص داده شده است ، ممکن است با استفاده از [`Box::<T>::from_raw(value)`] به جعبه تبدیل شود.
//! برعکس ، ممكن است حافظه پشتیبان `value:*mut T` به دست آمده از [`Box::<T>::into_raw`] با استفاده از تخصیص دهنده [`Global`] با [`Layout::for_value(&* value)`] تخصیص یابد.
//!
//! برای مقادیر با اندازه صفر ، نشانگر `Box` هنوز برای خواندن و نوشتن باید [valid] باشد و به اندازه کافی تراز باشد.
//! به طور خاص ، قرار دادن هر عدد صحیح غیر صفر تراز شده به معنای واقعی کلمه به یک نشانگر خام ، یک اشاره گر معتبر تولید می کند ، اما یک اشاره گر که به حافظه قبلی اختصاص داده می شود و از زمان آزاد شدن معتبر نیست ، معتبر نیست.
//! در صورت عدم استفاده از `Box::new` ، روش پیشنهادی برای ساخت Box به ZST استفاده از [`ptr::NonNull::dangling`] است.
//!
//! تا زمانی که `T: Sized` وجود داشته باشد ، `Box<T>` تضمین می شود که به عنوان یک نشانگر منفرد نشان داده می شود و همچنین با اشاره گرهای C (یعنی نوع C `T*`) سازگار با ABI است.
//! این بدان معنی است که اگر توابع خارجی "C" Rust دارید که از C فراخوانی می شوند ، می توانید آن توابع Rust را با استفاده از انواع `Box<T>` تعریف کنید و از `T*` به عنوان نوع مربوطه در سمت C استفاده کنید.
//! به عنوان مثال ، این هدر C را در نظر بگیرید که توابع ایجاد و از بین بردن نوعی از ارزش `Foo` را اعلام می کند:
//!
//! ```c
//! /* سربرگ C */
//!
//! /* مالکیت را به تماس گیرنده برمی گرداند */
//! struct Foo* foo_new(void);
//!
//! /* مالکیت را از تماس گیرنده می گیرد ؛no-op وقتی با NULL فراخوانی می شود */
//! void foo_delete(struct Foo*);
//! ```
//!
//! این دو عملکرد ممکن است به صورت زیر در Rust پیاده سازی شوند.در اینجا ، نوع `struct Foo*` از C به `Box<Foo>` ترجمه شده است ، که محدودیت های مالکیت را ضبط می کند.
//! همچنین توجه داشته باشید که استدلال بی اعتبار `foo_delete` در Rust به عنوان `Option<Box<Foo>>` نشان داده می شود ، زیرا `Box<Foo>` نمی تواند صفر باشد.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! حتی اگر `Box<T>` نمایش و C ABI یکسانی با اشاره گر C داشته باشد ، این بدان معنا نیست که شما می توانید `T*` دلخواه را به `Box<T>` تبدیل کرده و انتظار داشته باشید که همه کارها انجام شود.
//! `Box<T>` مقادیر همیشه به صورت کاملاً یکدست و نشانگرهای غیر تهی قرار می گیرندعلاوه بر این ، تخریب کننده `Box<T>` تلاش خواهد کرد تا مقدار را با تخصیص دهنده جهانی آزاد کند.به طور کلی ، بهترین روش این است که فقط از `Box<T>` برای اشاره گرهایی که از تخصیص دهنده جهانی نشأت گرفته اند استفاده کنید.
//!
//! **مهم است.** حداقل در حال حاضر ، از استفاده از انواع `Box<T>` برای توابعی که در C تعریف شده اما از Rust استفاده می شود ، خودداری کنید.در این موارد ، باید مستقیماً انواع C را تا حد امکان آینه کنید.
//! استفاده از انواع مانند `Box<T>` که تعریف C فقط استفاده از `T*` است می تواند منجر به رفتار تعریف نشده شود ، همانطور که در [rust-lang/unsafe-code-guidelines#198][ucg#198] شرح داده شده است.
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// نوع اشاره گر برای تخصیص پشته.
///
/// برای اطلاعات بیشتر به [module-level documentation](../../std/boxed/index.html) مراجعه کنید.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// حافظه را روی پشته تخصیص داده و سپس `x` را درون آن قرار می دهد.
    ///
    /// اگر `T` به اندازه صفر باشد این در واقع تخصیص نمی یابد.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// یک جعبه جدید با محتوای غیر اولیه ساخته می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// `Box` جدید با محتوای غیر اولیه ساخته می شود ، با حافظه پر شده با بایت `0`.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// `Pin<Box<T>>` جدیدی را می سازد.
    /// اگر `T` `Unpin` را پیاده سازی نکند ، `x` در حافظه پین می شود و نمی تواند جابجا شود.
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// حافظه را روی پشته اختصاص می دهد و سپس `x` را درون آن قرار می دهد و در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند
    ///
    ///
    /// اگر `T` به اندازه صفر باشد این در واقع تخصیص نمی یابد.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// یک جعبه جدید با محتویات غیر اولیه در پشته ایجاد می کند ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// `Box` جدید با محتوای غیر اولیه ساخته می شود ، حافظه با `0` بایت روی پشته پر می شود
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// حافظه را در تخصیص داده شده اختصاص می دهد و سپس `x` را در آن قرار می دهد.
    ///
    /// اگر `T` به اندازه صفر باشد این در واقع تخصیص نمی یابد.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// حافظه را در تخصیص داده شده اختصاص می دهد و سپس `x` را در آن قرار می دهد ، در صورت عدم موفقیت در تخصیص ، خطایی برمی گرداند
    ///
    ///
    /// اگر `T` به اندازه صفر باشد این در واقع تخصیص نمی یابد.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// یک جعبه جدید با محتویات غیر اولیه در تخصیص دهنده ساخته شده ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: مطابقت را به unwrap_or_else ترجیح دهید زیرا بسته شدن گاهی غیرقابل خط نیست.
        // این باعث می شود اندازه کد بزرگتر شود.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// جعبه جدیدی را با محتویات غیر اولیه در تخصیص دهنده ایجاد می کند ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// `Box` جدید با محتویات غیر اولیه ساخته می شود ، در این حافظه با بایت `0` در تخصیص دهنده ارائه شده پر می شود.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: مطابقت را به unwrap_or_else ترجیح دهید زیرا بسته شدن گاهی غیرقابل خط نیست.
        // این باعث می شود اندازه کد بزرگتر شود.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// `Box` جدید با محتوای غیر اولیه ساخته می شود ، با حافظه ای که با `0` بایت در تخصیص دهنده پر شده پر می شود ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند ،
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// `Pin<Box<T, A>>` جدیدی را می سازد.
    /// اگر `T` `Unpin` را پیاده سازی نکند ، `x` در حافظه پین می شود و نمی تواند جابجا شود.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// `Box<T>` را به `Box<[T]>` تبدیل می کند
    ///
    /// این تبدیل به پشته اختصاص نمی یابد و در محل اتفاق می افتد.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// `Box` را مصرف می کند ، مقدار بسته بندی شده را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// یک برش جعبه ای جدید با محتوای غیر اولیه ساخته می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// یک قطعه جعبه دار جدید با محتوای غیر اولیه ساخته می شود ، با حافظه که با بایت `0` پر می شود.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// یک برش جعبه ای جدید با محتوای غیر اولیه در تخصیص دهنده ساخته شده ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// یک برش جعبه دار جدید با محتویات غیر اولیه در تخصیص دهنده ارائه شده ، با حافظه پر شده با بایت `0` ، می سازد.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// به `Box<T, A>` تبدیل می شود.
    ///
    /// # Safety
    ///
    /// همانطور که با [`MaybeUninit::assume_init`] ، تضمین اینکه این مقدار واقعاً در حالت اولیه قرار دارد ، به عهده تماس گیرنده است.
    ///
    /// وقتی این محتوا هنوز کاملاً اولیه نشده است ، فراخوانی آن باعث رفتار فوری تعریف نشده می شود.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// به `Box<[T], A>` تبدیل می شود.
    ///
    /// # Safety
    ///
    /// همانطور که با [`MaybeUninit::assume_init`] ، تضمین اینکه مقادیر واقعاً در حالت اولیه قرار دارند ، به عهده تماس گیرنده است.
    ///
    /// وقتی این محتوا هنوز کاملاً اولیه نشده است ، فراخوانی آن باعث رفتار فوری تعریف نشده می شود.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// جعبه ای را از یک اشاره گر خام می سازد.
    ///
    /// پس از فراخوانی این عملکرد ، نشانگر خام متعلق به `Box` حاصل می شود.
    /// به طور خاص ، تخریب کننده `Box` با تخریب کننده `T` تماس گرفته و حافظه اختصاص یافته را آزاد می کند.
    /// برای ایمن بودن این حافظه باید مطابق با [memory layout] استفاده شده توسط `Box` اختصاص داده شود.
    ///
    ///
    /// # Safety
    ///
    /// این عملکرد ایمن نیست زیرا استفاده نادرست ممکن است منجر به مشکلات حافظه شود.
    /// به عنوان مثال ، اگر عملکرد در دو نشانگر خام دو بار فراخوانی شود ، ممکن است یک علامت دوتایی ایجاد شود.
    ///
    /// شرایط ایمنی در بخش [memory layout] شرح داده شده است.
    ///
    /// # Examples
    ///
    /// `Box` را که قبلاً با استفاده از [`Box::into_raw`] به نشانگر خام تبدیل شده بود ، دوباره بسازید:
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// با استفاده از تخصیص دهنده جهانی `Box` را از ابتدا به صورت دستی ایجاد کنید:
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // به طور کلی .write برای جلوگیری از تلاش برای تخریب محتوای قبلی (uninitialized) `ptr` لازم است ، اگرچه برای این مثال ساده `*ptr = 5` نیز جواب می داد.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// یک جعبه از یک نشانگر خام در تخصیص داده شده ساخته می شود.
    ///
    /// پس از فراخوانی این عملکرد ، نشانگر خام متعلق به `Box` حاصل می شود.
    /// به طور خاص ، تخریب کننده `Box` با تخریب کننده `T` تماس گرفته و حافظه اختصاص یافته را آزاد می کند.
    /// برای ایمن بودن این حافظه باید مطابق با [memory layout] استفاده شده توسط `Box` اختصاص داده شود.
    ///
    ///
    /// # Safety
    ///
    /// این عملکرد ایمن نیست زیرا استفاده نادرست ممکن است منجر به مشکلات حافظه شود.
    /// به عنوان مثال ، اگر عملکرد در دو نشانگر خام دو بار فراخوانی شود ، ممکن است یک علامت دوتایی ایجاد شود.
    ///
    /// # Examples
    ///
    /// `Box` را که قبلاً با استفاده از [`Box::into_raw_with_allocator`] به نشانگر خام تبدیل شده بود ، دوباره بسازید:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// با استفاده از تخصیص دهنده سیستم `Box` را از ابتدا به صورت دستی ایجاد کنید:
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // به طور کلی .write برای جلوگیری از تلاش برای تخریب محتوای قبلی (uninitialized) `ptr` لازم است ، اگرچه برای این مثال ساده `*ptr = 5` نیز جواب می داد.
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// `Box` را مصرف می کند ، یک اشاره گر خام بسته بندی شده را برمی گرداند.
    ///
    /// اشاره گر به درستی تراز شده و غیر تهی است.
    ///
    /// پس از فراخوانی این عملکرد ، تماس گیرنده مسئول حافظه قبلی است که توسط `Box` اداره می شود.
    /// به ویژه ، تماس گیرنده باید `T` را به درستی از بین ببرد و با در نظر گرفتن [memory layout] استفاده شده توسط `Box` ، حافظه را آزاد کند.
    /// آسانترین راه برای انجام این کار تبدیل نشانگر خام به `Box` با عملکرد [`Box::from_raw`] است که به تخریب کننده `Box` اجازه می دهد پاکسازی را انجام دهد.
    ///
    ///
    /// Note: این یک تابع مرتبط است ، به این معنی که شما باید آن را به جای `b.into_raw()` به عنوان `Box::into_raw(b)` فراخوانی کنید.
    /// این امر به این دلیل است که هیچ تضادی با روشی در مورد نوع داخلی آن وجود ندارد.
    ///
    /// # Examples
    /// تبدیل نشانگر خام به `Box` با [`Box::from_raw`] برای پاکسازی خودکار:
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// پاکسازی دستی با صراحت تخریب کننده و جدا کردن حافظه:
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// `Box` را مصرف می کند ، یک نشانگر خام پیچیده و تخصیص دهنده را برمی گرداند.
    ///
    /// اشاره گر به درستی تراز شده و غیر تهی است.
    ///
    /// پس از فراخوانی این عملکرد ، تماس گیرنده مسئول حافظه قبلی است که توسط `Box` اداره می شود.
    /// به ویژه ، تماس گیرنده باید `T` را به درستی از بین ببرد و با در نظر گرفتن [memory layout] استفاده شده توسط `Box` ، حافظه را آزاد کند.
    /// آسانترین راه برای انجام این کار تبدیل نشانگر خام به `Box` با عملکرد [`Box::from_raw_in`] است که به تخریب کننده `Box` اجازه می دهد پاکسازی را انجام دهد.
    ///
    ///
    /// Note: این یک تابع مرتبط است ، به این معنی که شما باید آن را به جای `b.into_raw_with_allocator()` به عنوان `Box::into_raw_with_allocator(b)` فراخوانی کنید.
    /// این امر به این دلیل است که هیچ تضادی با روشی در مورد نوع داخلی آن وجود ندارد.
    ///
    /// # Examples
    /// تبدیل نشانگر خام به `Box` با [`Box::from_raw_in`] برای پاکسازی خودکار:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// پاکسازی دستی با صراحت تخریب کننده و جدا کردن حافظه:
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // Box توسط Stacked Borrows به عنوان "unique pointer" شناخته شده است ، اما در داخل آن یک نشانگر خام برای سیستم نوع است.
        // تبدیل مستقیم آن به یک اشاره گر خام به عنوان "releasing" نشانگر منحصر به فرد شناخته نمی شود که دسترسی های خام نامعلوم را مجاز می داند ، بنابراین همه روش های نشانگر خام باید از `Box::leak` عبور کنند.
        //
        // تبدیل *that* به نشانگر خام به درستی رفتار می کند.
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// مرجعی را به تخصیص دهنده اصلی برمی گرداند.
    ///
    /// Note: این یک تابع مرتبط است ، به این معنی که شما باید آن را به جای `b.allocator()` به عنوان `Box::allocator(&b)` فراخوانی کنید.
    /// این امر به این دلیل است که هیچ تضادی با روشی در مورد نوع داخلی آن وجود ندارد.
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// `Box` را مصرف و نشت می کند ، و یک مرجع قابل تغییر می دهد ، `&'a mut T`.
    /// توجه داشته باشید که نوع `T` باید بیش از `'a` طول عمر انتخاب شده داشته باشد.
    /// اگر نوع فقط ارجاعات استاتیک یا اصلاً ندارد ، ممکن است این `'static` انتخاب شود.
    ///
    /// این عملکرد عمدتا برای داده هایی مفید است که تا پایان عمر برنامه زندگی می کنند.
    /// انداختن مرجع برگشتی باعث نشت حافظه می شود.
    /// اگر این قابل قبول نیست ، مرجع ابتدا باید با عملکرد [`Box::from_raw`] تولید `Box` بسته بندی شود.
    ///
    /// سپس می توان این `Box` را رها کرد که به درستی `T` را از بین می برد و حافظه اختصاص یافته را آزاد می کند.
    ///
    /// Note: این یک تابع مرتبط است ، به این معنی که شما باید آن را به جای `b.leak()` به عنوان `Box::leak(b)` فراخوانی کنید.
    /// این امر به این دلیل است که هیچ تضادی با روشی در مورد نوع داخلی آن وجود ندارد.
    ///
    /// # Examples
    ///
    /// استفاده ساده:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// داده های بدون اندازه:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// `Box<T>` را به `Pin<Box<T>>` تبدیل می کند
    ///
    /// این تبدیل به پشته اختصاص نمی یابد و در محل اتفاق می افتد.
    ///
    /// این نیز از طریق [`From`] در دسترس است.
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // امکان جابجایی یا جایگزینی قسمت داخلی `Pin<Box<T>>` در هنگام `T: !Unpin` وجود ندارد ، بنابراین می توان مستقیماً بدون نیاز به هیچگونه نیاز اضافی ، آن را سنجاق کرد.
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: کاری انجام نده ، در حال حاضر drop توسط کامپایلر انجام می شود.
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// `Box<T>` با مقدار `Default` برای T ایجاد می کند.
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// یک جعبه جدید با `clone()` از محتوای این جعبه برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // ارزش همان است
    /// assert_eq!(x, y);
    ///
    /// // اما آنها اشیای منحصر به فردی هستند
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // از قبل حافظه را اختصاص دهید تا مستقیماً مقدار شبیه سازی شده را بنویسید.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// بدون ایجاد تخصیص جدید ، محتوای `منبع` را در `self` کپی می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // ارزش همان است
    /// assert_eq!(x, y);
    ///
    /// // و هیچ تخصیصی رخ نداد
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // این یک کپی از داده ها را ایجاد می کند
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// نوع عمومی `T` را به `Box<T>` تبدیل می کند
    ///
    /// تبدیل به پشته اختصاص یافته و `t` را از پشته به داخل آن منتقل می کند.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// `Box<T>` را به `Pin<Box<T>>` تبدیل می کند
    ///
    /// این تبدیل به پشته اختصاص نمی یابد و در محل اتفاق می افتد.
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// `&[T]` را به `Box<[T]>` تبدیل می کند
    ///
    /// این تبدیل به پشته اختصاص یافته و نسخه ای از `slice` را اجرا می کند.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // &[u8] ایجاد کنید که برای ایجاد جعبه <[u8]> استفاده خواهد شد
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// `&str` را به `Box<str>` تبدیل می کند
    ///
    /// این تبدیل به پشته اختصاص یافته و نسخه ای از `s` را اجرا می کند.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// `Box<str>` را به `Box<[u8]>` تبدیل می کند
    /// این تبدیل به پشته اختصاص نمی یابد و در محل اتفاق می افتد.
    ///
    /// # Examples
    ///
    /// ```rust
    /// // یک جعبه ایجاد کنید<str>که برای ایجاد جعبه <[u8]> استفاده خواهد شد
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // &[u8] ایجاد کنید که برای ایجاد جعبه <[u8]> استفاده خواهد شد
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// `[T; N]` را به `Box<[T]>` تبدیل می کند
    /// این تبدیل آرایه را به حافظه تازه تخصیص یافته به heap منتقل می کند.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// تلاش برای پایین آوردن جعبه به یک نوع بتن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// تلاش برای پایین آوردن جعبه به یک نوع بتن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// تلاش برای پایین آوردن جعبه به یک نوع بتن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // استخراج Uniq داخلی به طور مستقیم از جعبه امکان پذیر نیست ، در عوض ما آن را به یک * ساختار می دهیم که نام مستعار Unique است
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// تخصصی برای `I` سایز که از` I به جای پیش فرض از اجرای `last()` استفاده می کند.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}