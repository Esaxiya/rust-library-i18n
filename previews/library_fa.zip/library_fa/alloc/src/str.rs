//! برش های رشته یونیکد.
//!
//! *[See also the `str` primitive type](str).*
//!
//! نوع `&str` یکی از دو نوع رشته اصلی است و نوع دیگر `String` است.
//! برخلاف نسخه `String` ، محتوای آن وام گرفته شده است.
//!
//! # کاربرد اساسی
//!
//! اعلامیه رشته ای اصلی از نوع `&str`:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! در اینجا ما یک رشته را تحت اللفظی اعلام کرده ایم که به آن برش رشته نیز گفته می شود.
//! اصطلاحات رشته ای دارای طول عمر ثابت هستند ، به این معنی که رشته `hello_world` برای مدت زمان کل برنامه تضمین شده است.
//!
//! ما می توانیم به صراحت طول عمر `hello_world` را نیز مشخص کنیم:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// بسیاری از موارد استفاده شده در این ماژول فقط در پیکربندی آزمون استفاده می شود.
// پاک کردن هشدارهای استفاده نشده از واردات نسبت به رفع آنها تمیزتر است.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` در `Concat<str>` در اینجا معنی دار نیست.
/// این پارامتر نوع trait فقط برای فعال کردن یک impl دیگر وجود دارد.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // حلقه هایی با اندازه های سخت کدگذاری شده بسیار سریعتر اجرا می شوند ، موارد با طول جدا کننده کوچک را تخصصی می کنند
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // بازگشت خودسرانه به اندازه غیر صفر
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// پیوستن بهینه شده بهینه شده که برای هر دو Vec کار می کند<T>(T: کپی) و vec داخلی String در حال حاضر (2018-05-13) اشکالی با استنباط نوع و تخصص وجود دارد (به شماره #36262 مراجعه کنید) به همین دلیل SliceConcat<T>برای T: Copy و SliceConcat تخصصی نیست<str>تنها کاربر این عملکرد است.
// برای زمانی که ثابت است در جای خود باقی مانده است.
//
// محدوده های String-join S: Borrow است<str>و برای Vec-join Borrow <[T]> [T] و str هر دو impl AsRef <[T]> برای برخی از T
// => s.borrow().as_ref() و ما همیشه برش داریم
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // اولین برش تنها موردی است که قبل از آن جدا کننده وجود ندارد
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // در صورت سرریز شدن محاسبه `len` ، طول کل Vec متصل را دقیقاً محاسبه کنید ، ما panic خواهیم کرد به هر حال حافظه ما تمام شده است و بقیه عملکردها به کل Vec از قبل اختصاص یافته برای ایمنی نیاز دارند
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // یک بافر غیر اولیه تهیه کنید
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // جداکننده کپی و برشهای بدون چک مرز ایجاد حلقه هایی با جبران سخت کدگذاری شده برای جداکننده های کوچک امکان بهبود عظیم (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // یک اجرای عجیب وام ممکن است برش های مختلفی را برای محاسبه طول و نسخه واقعی برگرداند.
        //
        // اطمینان حاصل کنید که بایت های غیر اولیه را در معرض تماس گیرنده قرار نمی دهیم.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// روش هایی برای برش های رشته ای.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// بدون کپی یا تخصیص ، `Box<str>` را به `Box<[u8]>` تبدیل می کند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// همه تطابق های یک الگو را با یک رشته دیگر جایگزین می کند.
    ///
    /// `replace` [`String`] جدید ایجاد می کند و داده های موجود در این رشته را در آن کپی می کند.
    /// در حالی که این کار را انجام می دهد ، سعی می کند مطابقت یک الگو را پیدا کند.
    /// اگر موردی پیدا کند ، آنها را با برش رشته جایگزین می کند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// هنگامی که الگو مطابقت ندارد:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// N منطبق اول یک الگو را با یک رشته دیگر جایگزین می کند.
    ///
    /// `replacen` [`String`] جدید ایجاد می کند و داده های موجود در این رشته را در آن کپی می کند.
    /// در حالی که این کار را انجام می دهد ، سعی می کند مطابقت یک الگو را پیدا کند.
    /// اگر موردی پیدا کند ، حداکثر `count` بار آنها را با قطعه رشته جایگزین می کند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// هنگامی که الگو مطابقت ندارد:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // به امید کاهش زمان های تخصیص مجدد
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// معادل کوچک این قطعه رشته ای را به عنوان [`String`] جدید برمی گرداند.
    ///
    /// 'Lowercase' با توجه به شرایط Unicode Derived Core Property `Lowercase` تعریف شده است.
    ///
    /// از آنجا که برخی از نویسه ها می توانند هنگام تغییر حالت کوچک ، به چندین کاراکتر گسترش یابند ، این عملکرد به جای تغییر پارامتر در محل ، [`String`] را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// یک مثال روی حیله و تزویر ، با سیگما:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // اما در پایان کلمه ، ς است ، نه σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// زبانهای بدون حروف تغییر نمی کنند:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ به σ نقشه برداری می کند ، به جز در انتهای کلمه ای که به ς ترسیم می شود.
                // این تنها نقشه (contextual) مشروط اما مستقل از زبان در `SpecialCasing.txt` است ، بنابراین به جای اینکه دارای مکانیزم عمومی "condition" باشد ، آن را کد سخت کنید.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // برای تعریف `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// معادل بزرگ این قطعه رشته ای را به عنوان [`String`] جدید برمی گرداند.
    ///
    /// 'Uppercase' با توجه به شرایط Unicode Derived Core Property `Uppercase` تعریف شده است.
    ///
    /// از آنجا که برخی از نویسه ها می توانند هنگام تغییر حالت کوچک ، به چندین کاراکتر گسترش یابند ، این عملکرد به جای تغییر پارامتر در محل ، [`String`] را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// متن های بدون حروف تغییر نمی کند:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// یک شخصیت می تواند چند برابر شود:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// بدون کپی یا تخصیص ، [`Box<str>`] را به [`String`] تبدیل می کند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// با تکرار یک رشته `n` یک [`String`] جدید ایجاد می کند.
    ///
    /// # Panics
    ///
    /// در صورت سرریز ظرفیت ، این عملکرد panic خواهد بود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// یک panic هنگام سرریز:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// یک کپی از این رشته را برمی گرداند جایی که هر کاراکتر به معادل بزرگ ASCII خود نگاشته می شود.
    ///
    ///
    /// حروف ASCII 'a' تا 'z' با 'A' تا 'Z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بزرگنمایی مقدار در محل ، از [`make_ascii_uppercase`] استفاده کنید.
    ///
    /// برای نویسه های بزرگ ASCII علاوه بر نویسه های غیر ASCII ، از [`to_uppercase`] استفاده کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 ثابت را حفظ می کند.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// یک کپی از این رشته را برمی گرداند جایی که هر کاراکتر به معادل کوچک ASCII خود نگاشته می شود.
    ///
    ///
    /// حروف ASCII 'A' تا 'Z' با 'a' تا 'z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای کوچک کردن مقدار درجا ، از [`make_ascii_lowercase`] استفاده کنید.
    ///
    /// برای کوچک بودن حروف ASCII علاوه بر نویسه های غیر ASCII ، از [`to_lowercase`] استفاده کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 ثابت را حفظ می کند.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// بدون بررسی اینکه رشته حاوی UTF-8 معتبر است ، یک بایت جعبه ای بایت را به یک رشته رشته جعبه ای تبدیل می کند.
///
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}