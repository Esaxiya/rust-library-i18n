#![stable(feature = "wake_trait", since = "1.51.0")]
//! انواع و Traits برای کار با وظایف ناهمزمان.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// اجرای بیدار کردن یک کار بر روی یک مجری.
///
/// از این trait می توان برای ایجاد [`Waker`] استفاده کرد.
/// یک مجری می تواند پیاده سازی این trait را تعریف کند و از آن برای ساختن Waker برای انتقال به وظایفی که بر روی آن اجرا کننده استفاده می کنند استفاده کند.
///
/// این trait یک جایگزین ارگونومیک و ایمن در برابر حافظه برای ساخت [`RawWaker`] است.
/// این برنامه از طراحی معمول مجری پشتیبانی می کند که در آن داده های استفاده شده برای بیدار کردن یک کار در [`Arc`] ذخیره می شود.
/// برخی از مجریان (به ویژه سیستم های تعبیه شده) نمی توانند از این API استفاده کنند ، به همین دلیل [`RawWaker`] به عنوان گزینه دیگری برای آن سیستم ها وجود دارد.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// یک تابع اساسی `block_on` که یک future را گرفته و تا پایان آن را روی رشته فعلی اجرا می کند.
///
/// **Note:** این مثال صحت را برای سادگی معامله می کند.
/// به منظور جلوگیری از بن بست ، پیاده سازی های درجه تولید همچنین باید تماس های میانی با `thread::unpark` و همچنین فراخوانی های تو در تو را کنترل کنند.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// بیداری که هنگام فراخوانی نخ فعلی را بیدار می کند.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// یک future را برای تکمیل موضوع فعلی اجرا کنید.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future را سنجاق کنید تا بتوان از آن نظر سنجی کرد.
///     let mut fut = Box::pin(fut);
///
///     // یک زمینه جدید ایجاد کنید تا به future منتقل شود.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // future را تا انتها اجرا کنید.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// این کار را بیدار کنید.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// این کار را بدون مصرف واشر از خواب بیدار کنید.
    ///
    /// اگر یک مجری از روش ارزان تری برای بیدار شدن بدون مصرف بیدار پشتیبانی می کند ، باید این روش را نادیده بگیرد.
    /// به طور پیش فرض ، [`Arc`] را کلون می کند و روی کلون [`wake`] را فراخوانی می کند.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // ایمنی: این ایمن است زیرا raw_waker با خیال راحت ساخته می شود
        // RawWaker از Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: این تابع خصوصی برای ساخت RawWaker به جای استفاده می شود
// برای اطمینان از اینکه ایمنی `From<Arc<W>> for Waker` به اعزام صحیح trait بستگی ندارد ، این را در `From<Arc<W>> for RawWaker` impl قرار دهید ، در عوض هر دو ضابطه مستقیماً و صریح این عملکرد را فراخوانی می کنند.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // شمارش مرجع قوس را برای شبیه سازی آن افزایش دهید.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // با ارزش بیدار شوید ، Arc را به عملکرد Wake::wake منتقل کنید
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // بیدار با مرجع ، واشر را در ManualDrop بپیچید تا از انداختن آن جلوگیری شود
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // تعداد مرجع Arc را کاهش دهید
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}