//! اشاره گرهای شمارش مرجع تک رشته ای.'Rc' مخفف کلمه "مرجع" است
//! Counted'.
//!
//! نوع [`Rc<T>`][`Rc`] مالکیت مشترک مقداری از نوع `T` را که در پشته اختصاص یافته است ، فراهم می کند.
//! فراخوانی [`clone`][clone] در [`Rc`] نشانگر جدیدی به همان تخصیص در پشته تولید می کند.
//! وقتی آخرین نشانگر [`Rc`] به یک تخصیص داده شده از بین می رود ، مقدار ذخیره شده در آن تخصیص (که اغلب به آن "inner value" گفته می شود) نیز کاهش می یابد.
//!
//! منابع مشترک در Rust به طور پیش فرض جهش را مجاز نمی دانند و [`Rc`] نیز از این قاعده مستثنی نیست: به طور کلی نمی توانید به چیزی که درون [`Rc`] است ، یک مرجع قابل تغییر بدست آورید.
//! اگر به تغییر پذیری نیاز دارید ، [`Cell`] یا [`RefCell`] را داخل [`Rc`] قرار دهید.به [an example of mutability inside an `Rc`][mutability] مراجعه کنید.
//!
//! [`Rc`] از شمارش مرجع غیر اتمی استفاده می کند.
//! این بدان معنی است که سربار بسیار کم است ، اما [`Rc`] نمی تواند بین رشته ها ارسال شود و در نتیجه [`Rc`] [`Send`][send] را پیاده سازی نمی کند.
//! در نتیجه ، کامپایلر Rust *در زمان کامپایل* بررسی می کند که [Rc] ها را بین رشته ها ارسال نمی کنید.
//! اگر به شمارش مرجع اتمی چند رشته ای نیاز دارید ، از [`sync::Arc`][arc] استفاده کنید.
//!
//! از روش [`downgrade`][downgrade] می توان برای ایجاد یک اشاره گر [`Weak`] غیر مالک استفاده کرد.
//! یک نشانگر [`Weak`] می تواند ["upgrade"][ارتقا] d به [`Rc`] باشد ، اما اگر مقدار ذخیره شده در تخصیص قبلاً کاهش یافته باشد ، این [`None`] را برمی گرداند.
//! به عبارت دیگر ، اشاره گرهای `Weak` مقدار داخل تخصیص را زنده نگه نمی دارند.با این حال ، آنها * تخصیص (فروشگاه پشتیبان ارزش داخلی) را زنده نگه می دارند.
//!
//! چرخه ای بین اشاره گرهای [`Rc`] هرگز از جای خود جدا نخواهد شد.
//! به همین دلیل ، [`Weak`] برای شکستن چرخه ها استفاده می شود.
//! به عنوان مثال ، یک درخت می تواند نشانگرهای [`Rc`] قوی از گره های والدین گرفته تا فرزندان داشته باشد ، و اشاره گرهای [`Weak`] از کودکان به والدین خود بازگردند.
//!
//! `Rc<T>` به طور خودکار مراجعه به `T` (از طریق [`Deref`] trait) انجام می شود ، بنابراین می توانید روش های "T" را در مقدار نوع [`Rc<T>`][`Rc`] فراخوانی کنید.
//! برای جلوگیری از درگیری نام با روش های "T" ، روش های [`Rc<T>`][`Rc`] خود توابع مرتبط هستند که با استفاده از [fully qualified syntax] نامیده می شوند:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>"پیاده سازی traits مانند `Clone` همچنین ممکن است با استفاده از نحو کاملاً واجد شرایط فراخوانی شود.
//! بعضی از افراد ترجیح می دهند از نحو کاملاً واجد شرایط استفاده کنند ، در حالی که دیگران ترجیح می دهند از نحو فراخوانی روش استفاده کنند.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // نحو فراخوانی روش
//! let rc2 = rc.clone();
//! // نحو کاملاً واجد شرایط
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] به `T` مراجعه مجدد خودکار نمی کند ، زیرا ممکن است مقدار داخلی قبلاً کاهش یافته باشد.
//!
//! # منابع شبیه سازی
//!
//! ایجاد مرجع جدید به همان تخصیص به عنوان اشاره گر شمارش شده مرجع موجود ، با استفاده از `Clone` trait پیاده سازی شده برای [`Rc<T>`][`Rc`] و [`Weak<T>`][`Weak`] انجام می شود.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // دو نحو زیر برابر است.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a و b هر دو به همان مکان حافظه foo اشاره می کنند.
//! ```
//!
//! نحو `Rc::clone(&from)` اصطلاحی ترین اصطلاح است زیرا معنی کد را با صراحت بیشتری بیان می کند.
//! در مثال بالا ، این نحو به راحتی می تواند درک کند که این کد به جای کپی کردن کل محتوای foo ، یک مرجع جدید ایجاد می کند.
//!
//! # Examples
//!
//! یک سناریو را در نظر بگیرید که در آن مجموعه ای از `Gadget` متعلق به `Owner` معین است.
//! ما می خواهیم `Gadget` خود را به `Owner` خود نشان دهیم.ما نمی توانیم این کار را با مالکیت منحصر به فرد انجام دهیم ، زیرا ممکن است بیش از یک ابزار به همان `Owner` تعلق داشته باشد.
//! [`Rc`] به ما اجازه می دهد تا `Owner` را بین چندین "Gadget" به اشتراک بگذاریم و از `Owner` تا زمانی که هر `Gadget` در آن قرار داشته باشد ، اختصاص یابد.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... زمینه های دیگر
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... زمینه های دیگر
//! }
//!
//! fn main() {
//!     // `Owner` را با تعداد مرجع ایجاد کنید.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `Gadget` متعلق به `gadget_owner` ایجاد کنید.
//!     // شبیه سازی `Rc<Owner>` به ما یک اشاره گر جدید برای همان تخصیص `Owner` می دهد و تعداد مرجع را در این روند افزایش می دهد.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // متغیر محلی `gadget_owner` ما را دور بیندازید.
//!     drop(gadget_owner);
//!
//!     // علی رغم انداختن `gadget_owner` ، ما همچنان قادر به چاپ نام `Owner` از `Gadget` هستیم.
//!     // این به این دلیل است که ما فقط یک `Rc<Owner>` را رها کرده ایم ، نه `Owner` را که به آن اشاره می کند.
//!     // تا زمانی که `Rc<Owner>` دیگری به همان تخصیص `Owner` اشاره داشته باشد ، به صورت زنده باقی خواهد ماند.
//!     // طرح زمینه `gadget1.owner.name` کار می کند زیرا `Rc<Owner>` به طور خودکار از `Owner` خارج می شود.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // در پایان تابع ، `gadget1` و `gadget2` از بین می روند و با آنها آخرین مراجع شمارش شده به `Owner` ما هستند.
//!     // گجت من هم اکنون نابود می شود.
//!     //
//! }
//! ```
//!
//! اگر نیازهای ما تغییر کند ، و همچنین باید بتوانیم از `Owner` به `Gadget` عبور کنیم ، با مشکل روبرو خواهیم شد.
//! یک اشاره گر [`Rc`] از `Owner` به `Gadget` یک چرخه را معرفی می کند.
//! این بدان معنی است که تعداد مرجع آنها هرگز به 0 نمی رسد و تخصیص هرگز از بین نخواهد رفت:
//! نشت حافظهبرای دور زدن این موضوع می توانیم از اشاره گرهای [`Weak`] استفاده کنیم.
//!
//! Rust در واقع تولید این حلقه را تا حدودی دشوار می کند.برای اینکه در نهایت با دو مقدار روبرو شویم ، یکی از آنها باید قابل تغییر باشد.
//! این کار دشوار است زیرا [`Rc`] فقط با ارجاع مشترک به مقدار بسته بندی شده ، ایمنی حافظه را اعمال می کند و این اجازه جهش مستقیم را نمی دهد.
//! ما باید بخشی از مقداری را که می خواهیم جهش پیدا کنیم در [`RefCell`] قرار دهیم ، که *تغییر پذیری داخلی* را فراهم می کند: روشی برای دستیابی به تغییر پذیری از طریق یک مرجع مشترک.
//! [`RefCell`] قوانین وام Rust را در زمان اجرا اعمال می کند.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... زمینه های دیگر
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... زمینه های دیگر
//! }
//!
//! fn main() {
//!     // `Owner` را با تعداد مرجع ایجاد کنید.
//!     // توجه داشته باشید که vector `Owner` از`Gadget` را در داخل `RefCell` قرار داده ایم تا بتوانیم از طریق یک مرجع مشترک آن را جهش دهیم.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // همانند قبل `Gadget` متعلق به `gadget_owner` را ایجاد کنید.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // `Gadget` را به `Owner` خود اضافه کنید.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` وام پویا در اینجا به پایان می رسد.
//!     }
//!
//!     // تکرار کردن `Gadget` ما ، چاپ جزئیات آنها.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` `Weak<Gadget>` است.
//!         // از آنجا که اشاره گرهای `Weak` نمی توانند تخصیص را تضمین کنند ، ما باید با `upgrade` تماس بگیریم که `Option<Rc<Gadget>>` را برمی گرداند.
//!         //
//!         //
//!         // در این حالت می دانیم که تخصیص هنوز وجود دارد ، بنابراین ما به سادگی `unwrap` `Option` را `unwrap` می کنیم.
//!         // در یک برنامه پیچیده تر ، برای نتیجه `None` ممکن است نیاز به مدیریت خطاهای برازنده داشته باشید.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // در پایان عملکرد ، `gadget_owner` ، `gadget1` و `gadget2` از بین می روند.
//!     // اکنون هیچ اشاره گر قوی (`Rc`) برای این ابزارها وجود ندارد ، بنابراین آنها نابود می شوند.
//!     // این تعداد مراجعه به Gadget Man را صفر می کند ، بنابراین او نیز نابود می شود.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// این از repr(C) به future در برابر تغییر شکل مجدد درست است ، که در غیر این صورت [into|from]_raw() امن از انواع داخلی قابل تغییر اختلال ایجاد می کند.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// یک نشانگر شمارش مرجع تک رشته ای.'Rc' مخفف کلمه "مرجع" است
/// Counted'.
///
/// برای جزئیات بیشتر به [module-level documentation](./index.html) مراجعه کنید.
///
/// روش های ذاتی `Rc` همه توابع مرتبط هستند ، به این معنی که شما باید آنها را مانند [`Rc::get_mut(&mut value)`][get_mut] بجای `value.get_mut()` فراخوانی کنید.
/// با این کار از درگیری با روش های نوع داخلی `T` جلوگیری می شود.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // این عدم ایمنی درست است زیرا در حالی که این Rc زنده است ، ما معتبر بودن نشانگر داخلی هستیم.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// `Rc<T>` جدیدی را می سازد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // یک اشاره گر ضعیف ضمنی وجود دارد که متعلق به همه نشانگرهای قوی است ، و این اطمینان می دهد که تخریب کننده ضعیف هرگز تخصیص را آزاد نمی کند در حالی که تخریب کننده قوی کار می کند ، حتی اگر نشانگر ضعیف در داخل نشانگر قوی ذخیره شود.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// `Rc<T>` جدید را با استفاده از مراجعه ضعیف به خود می سازد.
    /// تلاش برای به روزرسانی مرجع ضعیف قبل از بازگشت این عملکرد منجر به مقدار `None` می شود.
    ///
    /// با این حال ، مرجع ضعیف ممکن است آزادانه کلون شود و برای استفاده در زمان بعدی ذخیره شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... زمینه های بیشتر
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // داخلی را در حالت "uninitialized" با یک مرجع ضعیف بسازید.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // مهم است که ما از مالکیت نشانگر ضعیف دست نکشیم ، در غیر این صورت ممکن است حافظه با بازگشت `data_fn` آزاد شود.
        // اگر واقعاً می خواستیم مالکیت خود را به تصویب برسانیم ، می توانستیم یک نشانگر ضعیف اضافی برای خود ایجاد کنیم ، اما این امر منجر به بروزرسانی های اضافی برای تعداد مرجع ضعیف می شود که در غیر این صورت دیگر لازم نیست.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // مراجع قوی باید بصورت جمعی دارای یک مرجع ضعیف مشترک باشند ، بنابراین تخریب کننده را برای مرجع ضعیف قدیمی ما اجرا نکنید.
        //
        mem::forget(weak);
        strong
    }

    /// `Rc` جدید با محتوای غیر اولیه ساخته می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Rc` جدید با محتوای غیر اولیه ساخته می شود ، با حافظه پر شده با بایت `0`.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// `Rc<T>` جدیدی را می سازد و در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // یک اشاره گر ضعیف ضمنی وجود دارد که متعلق به همه نشانگرهای قوی است ، و این اطمینان می دهد که تخریب کننده ضعیف هرگز تخصیص را آزاد نمی کند در حالی که تخریب کننده قوی کار می کند ، حتی اگر نشانگر ضعیف در داخل نشانگر قوی ذخیره شود.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// `Rc` جدید با محتوای غیر اولیه ساخته می شود ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// `Rc` جدید با محتوای غیر اولیه ساخته می شود ، حافظه با `0` بایت پر می شود ، در صورت عدم تخصیص ، خطایی را برمی گرداند
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Pin<Rc<T>>` جدیدی را می سازد.
    /// اگر `T` `Unpin` را پیاده سازی نکند ، `value` در حافظه پین می شود و نمی تواند جابجا شود.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// اگر `Rc` دقیقاً یک مرجع قوی داشته باشد مقدار داخلی را برمی گرداند.
    ///
    /// در غیر این صورت ، یک [`Err`] با همان `Rc` که به آنجا منتقل شده است بازگردانده می شود.
    ///
    ///
    /// این موفقیت حتی اگر منابع ضعیف برجسته وجود داشته باشد ، موفقیت آمیز خواهد بود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // شی موجود را کپی کنید

                // به نقاط ضعف نشان دهید که با کاهش تعداد زیاد نمی توان آنها را ارتقا داد و سپس اشاره گر ضمنی "strong weak" را بردارید در حالی که فقط با ساخت یک ضعف جعلی ، منطق افت را مدیریت می کنید.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// یک قطعه جدید با شمارش مرجع با محتوای غیر اولیه ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// یک قطعه جدید با شمارش مرجع با محتوای غیر اولیه ساخته می شود ، با حافظه پر شده با بایت `0`.
    ///
    ///
    /// برای نمونه استفاده صحیح و نادرست از این روش به [`MaybeUninit::zeroed`][zeroed] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// به `Rc<T>` تبدیل می شود.
    ///
    /// # Safety
    ///
    /// همانطور که با [`MaybeUninit::assume_init`] ، تضمین اینکه ارزش داخلی واقعاً در حالت اولیه قرار دارد ، به عهده تماس گیرنده است.
    ///
    /// وقتی این محتوا هنوز کاملاً اولیه نشده است ، فراخوانی آن باعث رفتار فوری تعریف نشده می شود.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// به `Rc<[T]>` تبدیل می شود.
    ///
    /// # Safety
    ///
    /// همانطور که با [`MaybeUninit::assume_init`] ، تضمین اینکه ارزش داخلی واقعاً در حالت اولیه قرار دارد ، به عهده تماس گیرنده است.
    ///
    /// وقتی این محتوا هنوز کاملاً اولیه نشده است ، فراخوانی آن باعث رفتار فوری تعریف نشده می شود.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // مقداردهی اولیه به تعویق افتاد:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `Rc` را مصرف می کند ، نشانگر بسته بندی شده را برمی گرداند.
    ///
    /// برای جلوگیری از نشت حافظه ، اشاره گر باید با استفاده از [`Rc::from_raw`][from_raw] به `Rc` تبدیل شود.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// یک نشانگر خام برای داده ها فراهم می کند.
    ///
    /// شمارش به هیچ وجه تحت تأثیر قرار نمی گیرد و `Rc` مصرف نمی شود.
    /// اشاره گر برای زمانی معتبر است که تعداد زیادی در `Rc` وجود داشته باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // ایمنی: این نمی تواند از طریق Deref::deref یا Rc::inner عبور کند زیرا
        // این برای حفظ منشأ raw/mut لازم است به عنوان مثال
        // `get_mut` پس از بازیابی Rc از طریق `from_raw` می تواند از طریق نشانگر بنویسد.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// `Rc<T>` را از یک نشانگر خام می سازد.
    ///
    /// نشانگر خام باید قبلاً با فراخوانی به [`Rc<U>::into_raw`][into_raw] برگردانده شده باشد که `U` باید همان اندازه و ترازوی `T` باشد.
    /// این اگر `U` `T` باشد به طور پیش پا افتاده درست است.
    /// توجه داشته باشید که اگر `U` `T` نباشد اما اندازه و ترازوی یکسانی داشته باشد ، این اساساً مانند انتقال منابع از انواع مختلف است.
    /// برای کسب اطلاعات بیشتر در مورد محدودیت هایی که در این مورد اعمال می شود ، به [`mem::transmute`][transmute] مراجعه کنید.
    ///
    /// کاربر `from_raw` باید مطمئن شود که مقدار مشخصی از `T` فقط یک بار کاهش می یابد.
    ///
    /// این عملکرد ایمن نیست زیرا استفاده نادرست ممکن است منجر به عدم امنیت حافظه شود ، حتی اگر `Rc<T>` برگشتی هرگز دسترسی پیدا نکند.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // برای جلوگیری از نشت ، دوباره به `Rc` تبدیل کنید.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // تماس های بیشتر با `Rc::from_raw(x_ptr)` حافظه ایمن نیست.
    /// }
    ///
    /// // وقتی `x` از محدوده فوق خارج شد ، حافظه آزاد شد ، بنابراین `x_ptr` اکنون آویزان است!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // برای یافتن RcBox اصلی ، افست را معکوس کنید.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// یک نشانگر [`Weak`] جدید برای این تخصیص ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // اطمینان حاصل کنید که ما یک ضعیف آویز ایجاد نمی کنیم
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// تعداد نشانگرهای [`Weak`] را برای این تخصیص دریافت می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// تعداد نشانگرهای قوی (`Rc`) را برای این تخصیص بدست می آورد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// اگر هیچ نشانگر `Rc` یا [`Weak`] دیگری به این تخصیص نداشته باشد ، `true` را برمی گرداند.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// اگر هیچ نشانگر `Rc` یا [`Weak`] دیگری به همان تخصیص نداشته باشد ، یک مرجع قابل تغییر را به `Rc` داده شده برمی گرداند.
    ///
    ///
    /// در غیر این صورت [`None`] را برمی گرداند ، زیرا تغییر در یک مقدار مشترک ایمن نیست.
    ///
    /// همچنین به [`make_mut`][make_mut] مراجعه کنید ، که در صورت وجود اشاره گرهای دیگر مقدار داخلی [`clone`][clone] خواهد بود.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// بدون هیچ گونه بررسی ، مرجع قابل تغییر را به `Rc` داده شده برمی گرداند.
    ///
    /// به [`get_mut`] نیز مراجعه کنید که بی خطر است و بررسی های مناسب را انجام می دهد.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// برای سایر وام های `Rc` یا [`Weak`] به همان تخصیص نباید در مدت زمان وام برگشتی مراجعه شود.
    ///
    /// در صورت عدم وجود چنین اشاره گرهایی ، به عنوان مثال بلافاصله بعد از `Rc::new` ، این امر بی اهمیت است.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // ما مراقب هستیم که *نه* مرجعی را که زمینه های "count" را پوشش می دهد ایجاد کنیم ، زیرا این امر با دسترسی به تعداد مرجع مغایرت دارد (به عنوان مثال
        // توسط `Weak`)
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` را برمی گرداند اگر هر دو Rc به تخصیص یکسانی اشاره داشته باشند (در یک مسیر شبیه به [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// یک اشاره قابل تغییر به `Rc` داده شده می کند.
    ///
    /// اگر اشاره گرهای `Rc` دیگری به همان تخصیص وجود داشته باشد ، `make_mut` برای اطمینان از مالکیت منحصر به فرد ، مقدار داخلی [`clone`] را برای تخصیص جدید [`clone`] می کند.
    /// این نیز به عنوان کلون نوشتن است.
    ///
    /// اگر هیچ نشانگر `Rc` دیگری برای این تخصیص وجود نداشته باشد ، نشانگرهای [`Weak`] برای این تخصیص جدا می شوند.
    ///
    /// همچنین به [`get_mut`] مراجعه کنید ، که به جای شبیه سازی شکست می خورد.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // هیچ چیزی شبیه سازی نمی شود
    /// let mut other_data = Rc::clone(&data);    // داده های داخلی کلون نخواهد شد
    /// *Rc::make_mut(&mut data) += 1;        // داده های داخلی را کلون می کند
    /// *Rc::make_mut(&mut data) += 1;        // هیچ چیزی شبیه سازی نمی شود
    /// *Rc::make_mut(&mut other_data) *= 2;  // هیچ چیزی شبیه سازی نمی شود
    ///
    /// // اکنون `data` و `other_data` به تخصیص های مختلف اشاره دارند.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] نشانگرها جدا خواهند شد:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // باید داده ها را شبیه سازی کند ، Rc های دیگری نیز وجود دارد.
            // از قبل حافظه را اختصاص دهید تا مستقیماً مقدار شبیه سازی شده را بنویسید.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // فقط می تواند داده ها را بدزدد ، تنها چیزی که ضعیف است باقی مانده است
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // حذف ضمنی ضعیف ضعف (نیازی به ساخت ضعف جعلی در اینجا نیست-ما می دانیم سایر نقاط ضعف می توانند برای ما تمیز کنند)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // این عدم ایمنی درست است زیرا ما تضمین می کنیم که نشانگر برگشته *تنها* اشاره گر است که هرگز به T برگردانده خواهد شد.
        // تعداد مرجع ما در این مرحله تضمین شده است 1 ، و ما خود `Rc<T>` را `mut` می خواهیم ، بنابراین ما تنها مرجع احتمالی مربوط به تخصیص را برمی گردانیم.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// تلاش برای پایین آوردن `Rc<dyn Any>` به یک نوع بتن.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// `RcBox<T>` را با فضای کافی برای یک مقدار داخلی که احتمالاً بدون اندازه باشد در جایی که مقدار آن طرح ارائه شده اختصاص می دهد.
    ///
    /// عملکرد `mem_to_rcbox` با نشانگر داده فراخوانی می شود و باید یک نشانگر (بالقوه چربی) را برای `RcBox<T>` برگرداند.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // طرح را با استفاده از طرح مقدار داده شده محاسبه کنید.
        // پیش از این ، طرح بندی روی عبارت `&*(ptr as* const RcBox<T>)` محاسبه می شد ، اما این یک مرجع ناهماهنگ ایجاد کرد (نگاه کنید به #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// `RcBox<T>` را با فضای کافی برای مقادیر داخلی احتمالاً بدون اندازه اختصاص می دهد در جایی که مقدار آن طرح ارائه شده است ، در صورت عدم موفقیت در تخصیص ، خطایی را برمی گرداند.
    ///
    ///
    /// عملکرد `mem_to_rcbox` با نشانگر داده فراخوانی می شود و باید یک نشانگر (بالقوه چربی) را برای `RcBox<T>` برگرداند.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // طرح را با استفاده از طرح مقدار داده شده محاسبه کنید.
        // پیش از این ، طرح بندی روی عبارت `&*(ptr as* const RcBox<T>)` محاسبه می شد ، اما این یک مرجع ناهماهنگ ایجاد کرد (نگاه کنید به #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // برای طرح اختصاص دهید.
        let ptr = allocate(layout)?;

        // RcBox را شروع کنید
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// `RcBox<T>` را با فضای کافی برای یک مقدار درونی بدون اندازه اختصاص می دهد
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // با استفاده از مقدار داده شده برای `RcBox<T>` تخصیص دهید.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // مقدار را به عنوان بایت کپی کنید
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // تخصیص را بدون انداختن محتوای آن آزاد کنید
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// `RcBox<[T]>` را با طول داده شده اختصاص می دهد.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// عناصر را از قطعه در Rc <\[T\]> تازه تخصیص داده شده کپی کنید
    ///
    /// ناامن است زیرا تماس گیرنده یا باید مالکیت مالکیت را کسب کند یا `T: Copy` را ملزم کند
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// `Rc<[T]>` را از تکرار کننده ای که اندازه مشخصی دارد می سازد.
    ///
    /// اگر اندازه اشتباه باشد ، رفتار تعریف نشده است.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // هنگام شبیه سازی عناصر T از محافظ Panic محافظت می کند.
        // در صورت وجود panic ، عناصری که در RcBox جدید نوشته شده اند رها می شوند و سپس حافظه آزاد می شود.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // اشاره گر به عنصر اول
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // همه چیز روشن است.محافظ را فراموش کنید تا RcBox جدید آزاد نشود.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// تخصصی trait که برای `From<&[T]>` استفاده می شود.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` را رها می کند.
    ///
    /// این باعث کاهش تعداد مرجع شدید می شود.
    /// اگر تعداد مرجع قوی به صفر برسد ، تنها منابع دیگر (در صورت وجود) [`Weak`] هستند ، بنابراین مقدار داخلی `drop` است.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // چیزی چاپ نمی کند
    /// drop(foo2);   // چاپ "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // از بین بردن شی موجود
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // نشانگر ضمنی "strong weak" را حذف کنید اکنون که محتویات را نابود کرده ایم.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// یک کلون از اشاره گر `Rc` ایجاد می کند.
    ///
    /// این یک اشاره گر دیگر به همان تخصیص ایجاد می کند ، و تعداد مرجع قوی را افزایش می دهد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `Rc<T>` جدید با مقدار `Default` برای `T` ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// هک اجازه تخصص در `Eq` حتی اگر `Eq` روشی دارد.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// ما این تخصص را در اینجا انجام می دهیم و نه به عنوان یک بهینه سازی کلی تر در `&T` ، زیرا در غیر این صورت هزینه ای را برای تمام بررسی های برابری در refs ها اضافه می کند.
/// ما فرض می کنیم که `Rc` برای ذخیره مقادیر زیادی استفاده می شود که کند کلون می شوند ، اما برای بررسی برابری نیز سنگین هستند و باعث می شود این هزینه راحت تر پرداخت شود.
///
/// همچنین دارای دو کلون `Rc` ، که به همان مقدار نشان می دهند ، بیشتر از دو کلون&T است.
///
/// ما فقط زمانی می توانیم این کار را انجام دهیم که `T: Eq` به عنوان `PartialEq` ممکن است به عمد بازتابنده باشد.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// برابری برای دو `Rc`.
    ///
    /// اگر دو مقدار Rc برابر باشند ، اگر مقادیر داخلی آنها برابر باشد ، حتی اگر در تخصیص متفاوت ذخیره شوند.
    ///
    /// اگر `T` `Eq` را نیز پیاده سازی کند (منعکس کننده انعکاس پذیری برابری) ، دو عدد Rc که به تخصیص یکسان اشاره می کنند ، همیشه برابر هستند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// نابرابری برای دو `Rc`.
    ///
    /// اگر دو ارزش Rc نابرابر باشد ، اگر ارزش های درونی آنها نابرابر باشد.
    ///
    /// اگر `T` `Eq` را نیز پیاده سازی کند (نشان دهنده بازتاب پذیری برابری است) ، هر دو Rc که به یک تخصیص یکسان اشاره می کنند هرگز نابرابر هستند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// مقایسه جزئی برای دو `Rc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `partial_cmp()` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// مقایسه کمتر از دو `Rc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `<` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// مقایسه "کمتر یا مساوی" برای دو "Rc".
    ///
    /// این دو با فراخوانی مقادیر درونی `<=` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// مقایسه بزرگتر از دو `Rc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `>` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// مقایسه "بزرگتر یا مساوی" برای دو "Rc".
    ///
    /// این دو با فراخوانی مقادیر درونی `>=` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// مقایسه دو `Rc`.
    ///
    /// این دو با فراخوانی مقادیر درونی `cmp()` مقایسه می شوند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// یک برش شمارش شده توسط مرجع را اختصاص دهید و آن را با شبیه سازی موارد "v" پر کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// یک برش رشته ای را که به تعداد قابل شمارش است ، اختصاص دهید و `v` را در آن کپی کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// یک برش رشته ای را که به تعداد قابل شمارش است ، اختصاص دهید و `v` را در آن کپی کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// یک شی box جعبه ای را به یک تخصیص جدید ، با شمارش مرجع منتقل کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// یک برش با شمارش مرجع اختصاص دهید و موارد "v" را به داخل آن منتقل کنید.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // اجازه دهید Vec حافظه خود را آزاد کند ، اما محتوای آن را از بین نبرد
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// هر عنصر را در `Iterator` می گیرد و آن را در `Rc<[T]>` جمع می کند.
    ///
    /// # ویژگی های عملکرد
    ///
    /// ## مورد کلی
    ///
    /// در حالت کلی ، جمع آوری در `Rc<[T]>` با جمع آوری ابتدا در `Vec<T>` انجام می شود.یعنی هنگام نوشتن موارد زیر:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// این رفتار مانند این است که گویی ما نوشتیم:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // اولین مجموعه از تخصیص ها در اینجا اتفاق می افتد.
    ///     .into(); // تخصیص دوم برای `Rc<[T]>` در اینجا اتفاق می افتد.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// این تعداد به تعداد لازم برای ساخت `Vec<T>` اختصاص می یابد و سپس یک بار برای تبدیل `Vec<T>` به `Rc<[T]>` اختصاص می یابد.
    ///
    ///
    /// ## تکرارکنندگان با طول مشخص
    ///
    /// هنگامی که `Iterator` شما `TrustedLen` را پیاده سازی می کند و اندازه آن دقیق است ، یک تخصیص واحد برای `Rc<[T]>` انجام می شود.مثلا:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // فقط یک تخصیص در اینجا اتفاق می افتد.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// تخصص trait برای جمع آوری در `Rc<[T]>` استفاده می شود.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // این مورد برای یک تکرار کننده `TrustedLen` است.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // ایمنی: ما باید اطمینان حاصل کنیم که تکرار کننده دارای طول دقیق و ما است.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // به اجرای عادی برگردید.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` نسخه ای از [`Rc`] است که اشاره ای غیر اختصاصی به تخصیص مدیریت شده دارد.با تماس با [`upgrade`] بر روی نشانگر `Weak` ، که ["Option"] "<" ["Rc"] را برمی گرداند به این تخصیص دسترسی پیدا می کند.<T>> "
///
/// از آنجا که یک مرجع `Weak` به عنوان مالکیت به حساب نمی آید ، از کاهش مقدار ذخیره شده در تخصیص جلوگیری نخواهد کرد و `Weak` خود تضمینی در مورد ارزش موجود نیست.
/// بنابراین ممکن است [`None`] را هنگامی که ["ارتقا" دهید d بازگرداند.
/// با این حال توجه داشته باشید که یک مرجع `Weak` * از اختصاص محل اختصاص خود (فروشگاه پشتیبان) جلوگیری می کند.
///
/// یک اشاره گر `Weak` برای داشتن اشاره ای موقتی به تخصیص مدیریت شده توسط [`Rc`] بدون جلوگیری از افت مقدار داخلی آن مفید است.
/// این همچنین برای جلوگیری از مراجعات دایره ای بین اشاره گرهای [`Rc`] استفاده می شود ، زیرا منابع مالکیت متقابل هرگز اجازه نمی دهد که [`Rc`] کنار گذاشته شود.
/// به عنوان مثال ، یک درخت می تواند نشانگرهای [`Rc`] قوی از گره های والدین گرفته تا فرزندان ، و اشاره گرهای `Weak` از کودکان به والدین خود داشته باشد.
///
/// روش معمول برای بدست آوردن اشاره گر `Weak` تماس با [`Rc::downgrade`] است.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // این `NonNull` است که امکان بهینه سازی اندازه این نوع در enum ها را می دهد ، اما لزوماً یک اشاره گر معتبر نیست.
    //
    // `Weak::new` این را روی `usize::MAX` تنظیم می کند تا نیازی به اختصاص فضای روی پشته نباشد.
    // این مقداری نیست که یک اشاره گر واقعی داشته باشد زیرا RcBox حداقل 2 تراز دارد.
    // این فقط در صورت `T: Sized` امکان پذیر است.`T` بدون اندازه آویزان نیست.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// بدون اختصاص حافظه ، `Weak<T>` جدیدی را می سازد.
    /// تماس با [`upgrade`] در مقدار برگشتی همیشه [`None`] را نشان می دهد.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// نوع یاور را برای دسترسی به تعداد مرجع بدون ایجاد هیچ گونه ادعا در مورد قسمت داده ، تایپ کنید.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// یک اشاره گر خام را به شی `T` نشان داده شده توسط این `Weak<T>` برمی گرداند.
    ///
    /// اشاره گر فقط در صورت وجود چند منبع قوی معتبر است.
    /// در غیر اینصورت ممکن است نشانگر آویزان ، غیر تراز شده یا حتی [`null`] باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // هر دو به یک شی اشاره می کنند
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // نیرومند در اینجا آن را زنده نگه می دارد ، بنابراین ما هنوز می توانیم به جسم دسترسی داشته باشیم
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // اما دیگر نه
    /// // ما می توانیم weak.as_ptr() را انجام دهیم ، اما دسترسی به نشانگر منجر به رفتار تعریف نشده می شود.
    /// // assert_eq! ("سلام" ، ناامن {&*weak.as_ptr() })؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // اگر نشانگر آویزان باشد ، نگهبان را مستقیماً برمی گردانیم.
            // این نمی تواند یک آدرس بار مجاز باشد ، زیرا بار حمل و نقل حداقل به اندازه RcBox (usize) تراز شده است.
            ptr as *const T
        } else {
            // ایمنی: اگر is_dangling نادرست است ، نشانگر قابل استناد است.
            // ممکن است بار در این مرحله کاهش یابد و ما باید منشأ خود را حفظ کنیم ، بنابراین از دستکاری اشاره گر خام استفاده کنید.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` را مصرف می کند و آن را به یک نشانگر خام تبدیل می کند.
    ///
    /// این نشانگر ضعیف را به یک نشانگر خام تبدیل می کند ، در حالی که همچنان مالکیت یک مرجع ضعیف را حفظ می کند (تعداد ضعیف با این عمل اصلاح نمی شود).
    /// با [`from_raw`] می توان آن را به `Weak<T>` تبدیل کرد.
    ///
    /// همان محدودیت های دستیابی به هدف نشانگر همانند [`as_ptr`] است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// یک اشاره گر خام که قبلاً توسط [`into_raw`] ایجاد شده بود را به `Weak<T>` تبدیل می کند.
    ///
    /// این می تواند برای بدست آوردن یک مرجع قوی با اطمینان (با تماس گرفتن با [`upgrade`] بعدا) یا برای جدا کردن تعداد ضعیف با انداختن `Weak<T>` استفاده شود.
    ///
    /// مالکیت یک مرجع ضعیف را به خود اختصاص می دهد (به استثنای اشاره گرهای ایجاد شده توسط [`new`] ، زیرا اینها هیچ چیز ندارند ؛ روش هنوز هم روی آنها کار می کند).
    ///
    /// # Safety
    ///
    /// این نشانگر باید از [`into_raw`] سرچشمه گرفته باشد و هنوز هم باید مرجع ضعیف احتمالی خود را داشته باشد.
    ///
    /// مجاز است شمارش قوی در زمان فراخوانی این 0 باشد.
    /// با این وجود ، این مالکیت یک مرجع ضعیف است که در حال حاضر به عنوان یک نشانگر خام نشان داده شده است (تعداد ضعیف با این عمل اصلاح نمی شود) و بنابراین باید با تماس قبلی با [`into_raw`] جفت شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // آخرین شمارش ضعیف را تقلیل دهید.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // برای چگونگی استخراج نشانگر ورودی به Weak::as_ptr مراجعه کنید.

        let ptr = if is_dangling(ptr as *mut T) {
            // این یک ضعف آویز است.
            ptr as *mut RcBox<T>
        } else {
            // در غیر این صورت ، ما تضمین می کنیم که نشانگر از یک ضعیف ضعیف ظاهر شده است.
            // ایمنی: تماس با data_offset بی خطر است ، زیرا ptr به T واقعی (به طور بالقوه افتاده) اشاره می کند.
            let offset = unsafe { data_offset(ptr) };
            // بنابراین ، جبران را معکوس می کنیم تا کل RcBox بدست آوریم.
            // ایمنی: این نشانگر از یک ضعف گرفته شده است ، بنابراین این جابجایی ایمن است.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // ایمنی: ما اکنون نشانگر ضعیف اصلی را بازیابی کردیم ، بنابراین می توانیم ضعف را ایجاد کنیم.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// تلاش برای ارتقا نشانگر `Weak` به [`Rc`] ، در صورت موفقیت افت ارزش داخلی را به تأخیر می اندازد.
    ///
    ///
    /// اگر مقدار داخلی از آن به بعد کاهش یافته باشد ، [`None`] را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // تمام نشانگرهای قوی را از بین ببرید.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// تعداد نشانگرهای قوی (`Rc`) را نشان می دهد که به این تخصیص اشاره دارند.
    ///
    /// اگر `self` با استفاده از [`Weak::new`] ایجاد شده باشد ، این 0 را برمی گرداند.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// تعداد نشانگرهای `Weak` را نشان می دهد که به این تخصیص اشاره دارند.
    ///
    /// اگر هیچ اشاره گر قوی باقی نماند ، این صفر را برمی گرداند.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ضمنی ضعیف ضعیف را کم کنید
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// `None` را هنگامی که نشانگر آویزان است و `RcBox` اختصاصی وجود ندارد برمی گرداند (یعنی وقتی این `Weak` توسط `Weak::new` ایجاد شده است).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ما مراقب هستیم که *یک* مرجع را که قسمت "data" را پوشش می دهد ایجاد نکنیم ، زیرا این فیلد ممکن است همزمان جهش ایجاد کند (به عنوان مثال ، اگر آخرین `Rc` رها شود ، قسمت داده در محل حذف می شود).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// اگر دو Weak `s به تخصیص یکسانی اشاره کنند (مشابه [`ptr::eq`]) ، یا اگر هر دو به تخصیص اشاره نکنند ، `true` را برمی گرداند (زیرا با `Weak::new()`) ایجاد شده اند).
    ///
    ///
    /// # Notes
    ///
    /// از آنجا که این نشانگرها را با هم مقایسه می کند ، به این معنی است که `Weak::new()` برابر یکدیگر خواهند بود ، حتی اگر به هیچ تخصیص اشاره نکنند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// مقایسه `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// نشانگر `Weak` را رها می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // چیزی چاپ نمی کند
    /// drop(foo);        // چاپ "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // شمارش ضعیف از 1 شروع می شود و فقط در صورت ناپدید شدن تمام نشانگرهای قوی به صفر می رسد.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// یک کلون از نشانگر `Weak` ایجاد می کند که به همان تخصیص اشاره دارد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// `Weak<T>` جدیدی را می سازد و حافظه را برای `T` بدون مقداردهی اولیه اختصاص می دهد.
    /// تماس با [`upgrade`] در مقدار برگشتی همیشه [`None`] را نشان می دهد.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: ما اینجا را بررسی کردیم تا اضافه کنیم تا با خیال راحت با mem::forget برخورد کنیم.به خصوص
// اگر mem::forget Rc (یا ضعف) داشته باشید ، شمارش مجدد می تواند سرریز شود و سپس می توانید تخصیص را آزاد کنید در حالی که Rc (یا ضعف) برجسته وجود دارد.
//
// ما سقط می کنیم زیرا این یک سناریوی منحط است که به آنچه اتفاق می افتد اهمیتی نمی دهیم-هیچ برنامه واقعی هرگز نباید چنین تجربه ای داشته باشد.
//
// این باید سربار ناچیزی داشته باشد زیرا شما به لطف مالکیت و حرکت معنایی نیازی به شبیه سازی این موارد در Rust ندارید.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // ما می خواهیم به جای کاهش مقدار ، از سرریز کردن سقط کنیم.
        // وقتی این فراخوانی شود ، تعداد مرجع هرگز صفر نخواهد بود.
        // با این وجود ، ما یک سقط را در اینجا وارد می کنیم تا به LLVM در بهینه سازی فراموش شده اشاره کنیم.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // ما می خواهیم به جای کاهش مقدار ، از سرریز کردن سقط کنیم.
        // وقتی این فراخوانی شود ، تعداد مرجع هرگز صفر نخواهد بود.
        // با این وجود ، ما یک سقط را در اینجا وارد می کنیم تا به LLVM در بهینه سازی فراموش شده اشاره کنیم.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// با استفاده از `RcBox` میزان بار را در پشت نشانگر جبران کنید.
///
/// # Safety
///
/// نشانگر باید به یک نمونه قبلی معتبر T اشاره کند (و دارای فراداده معتبری برای آن باشد) ، اما T مجاز به حذف است.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // مقدار بدون اندازه را با انتهای RcBox تراز کنید.
    // از آنجا که RcBox repr(C) است ، همیشه آخرین قسمت حافظه خواهد بود.
    // ایمنی: از آنجا که تنها انواع بدون اندازه ممکن است برش ها ، اشیا Z trait باشد ،
    // و انواع خارجی ، در حال حاضر نیاز ایمنی ورودی برای تأمین نیازهای align_of_val_raw کافی است.این جزئیات پیاده سازی زبان است که ممکن است خارج از std به آن اعتماد نشود.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}