//! اختصاص Prelude
//!
//! هدف از این ماژول کاهش واردات اقلام متداول `alloc` crate با افزودن واردات glob به بالای ماژول ها است:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;