//! نمای پویا به دنباله ای مجاور ، `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! برش ها نمایی از یک بلوک حافظه است که به عنوان یک نشانگر و طول نشان داده می شود.
//!
//! ```
//! // برش یک Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // وادار کردن یک آرایه به یک قطعه
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! برش ها قابل تغییر هستند یا به اشتراک گذاشته می شوند.
//! نوع برش مشترک `&[T]` است ، در حالی که نوع برش قابل تغییر `&mut [T]` است ، جایی که `T` نشان دهنده نوع عنصر است.
//! به عنوان مثال ، می توانید بلوکی از حافظه را تغییر دهید که یک قطعه قابل تغییر به آن اشاره می کند:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! در اینجا برخی از مواردی که این ماژول شامل آن است:
//!
//! ## Structs
//!
//! چندین چوب است که برای برش مفید است ، مانند [`Iter`] ، که تکرار روی یک قطعه را نشان می دهد.
//!
//! ## پیاده سازی های Trait
//!
//! چندین اجرای traits مشترک برای برش ها وجود دارد.برخی از نمونه ها عبارتند از:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] ، برای برش هایی که نوع عناصر آنها [`Eq`] یا [`Ord`] است.
//! * [`Hash`] - برای برش هایی که نوع عنصر آنها [`Hash`] است.
//!
//! ## Iteration
//!
//! برش ها `IntoIterator` را پیاده سازی می کنند.تکرار کننده به عناصر برش ارجاع می دهد.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! برش قابل تغییر ارجاعات قابل تغییر به عناصر را ایجاد می کند:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! این تکرار کننده به عناصر قطعه ارجاعات قابل تغییر می دهد ، بنابراین در حالی که نوع عنصر برش `i32` است ، نوع عنصر تکرار کننده `&mut i32` است.
//!
//!
//! * [`.iter`] و [`.iter_mut`] روشهای واضحی برای بازگرداندن تکرارکننده های پیش فرض هستند.
//! * روش های دیگری که تکرار کننده ها را برمی گرداند [`.split`] ، [`.splitn`] ، [`.chunks`] ، [`.windows`] و بیشتر هستند.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// بسیاری از موارد استفاده شده در این ماژول فقط در پیکربندی آزمون استفاده می شود.
// پاک کردن هشدارهای استفاده نشده از واردات نسبت به رفع آنها تمیزتر است.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// روشهای اصلی گسترش برش
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) برای اجرای ماکرو `vec!` در طول آزمایش NB مورد نیاز است ، برای جزئیات بیشتر به ماژول `hack` در این فایل مراجعه کنید.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) برای اجرای `Vec::clone` در طول آزمایش NB مورد نیاز است ، برای جزئیات بیشتر به ماژول `hack` در این فایل مراجعه کنید.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): با cfg(test) `impl [T]` در دسترس نیست ، این سه عملکرد در واقع روشهایی هستند که در `impl [T]` وجود دارد اما در `core::slice::SliceExt` نیست ، ما باید این توابع را برای آزمون `test_permutations` تهیه کنیم
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // ما نباید ویژگی inline را به این مورد اضافه کنیم زیرا این مورد بیشتر در ماکرو `vec!` استفاده می شود و باعث رگرسیون کامل می شود.
    // برای بحث و نتایج کامل به #71204 مراجعه کنید.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // موارد در حلقه زیر مشخص شده اند
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) لازم است LLVM چک کردن مرزها را انجام دهد و دارای کدژن بهتری نسبت به zip است.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec حداقل به این طول اختصاص داده شده و مقداردهی اولیه شده است.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // با ظرفیت `s` در بالا تخصیص داده شده و در ptr::copy_to_non_overlapping زیر به `s.len()` مقداردهی اولیه می شود.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// برش را مرتب می کند.
    ///
    /// این نوع پایدار است (به عنوان مثال ، ترتیب مجدد عناصر مساوی نیست) و *O*(*n*\*log(* n*)) در بدترین حالت).
    ///
    /// در صورت کاربرد ، مرتب سازی ناپایدار ترجیح داده می شود زیرا به طور کلی سریعتر از مرتب سازی پایدار است و حافظه کمکی را اختصاص نمی دهد.
    /// به [`sort_unstable`](slice::sort_unstable) مراجعه کنید.
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی یک نوع ادغام تطبیقی و تکراری است که از [timsort](https://en.wikipedia.org/wiki/Timsort) الهام گرفته شده است.
    /// در مواردی که قطعه تقریباً مرتب شده یا از دو یا چند توالی مرتب شده که یکی پس از دیگری به هم متصل شده اند ، بسیار سریع طراحی شده است.
    ///
    ///
    /// همچنین ، ذخیره سازی موقتی را به نصف اندازه `self` اختصاص می دهد ، اما به جای برش های کوتاه ، از یک نوع درج غیر اختصاصی استفاده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// قطعه را با عملکرد مقایسه کننده مرتب می کند.
    ///
    /// این نوع پایدار است (به عنوان مثال ، ترتیب مجدد عناصر مساوی نیست) و *O*(*n*\*log(* n*)) در بدترین حالت).
    ///
    /// تابع مقایسه کننده باید ترتیب کاملی برای عناصر موجود در برش تعریف کند.اگر ترتیب کامل نباشد ، ترتیب عناصر مشخص نیست.
    /// یک سفارش در صورت وجود یک سفارش کل است (برای همه `a` ، `b` و `c`):
    ///
    /// * کل و ضد متقارن: دقیقاً یکی از `a < b` ، `a == b` یا `a > b` درست است و
    /// * گذرا ، `a < b` و `b < c` حاوی `a < c` است.برای هر دو `==` و `>` باید همین مورد وجود داشته باشد.
    ///
    /// به عنوان مثال ، در حالی که [`f64`] [`Ord`] را به دلیل `NaN != NaN` پیاده سازی نمی کند ، وقتی می دانیم این تکه حاوی `NaN` نیست ، ما می توانیم از `partial_cmp` به عنوان عملکرد مرتب سازی خود استفاده کنیم.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// در صورت کاربرد ، مرتب سازی ناپایدار ترجیح داده می شود زیرا به طور کلی سریعتر از مرتب سازی پایدار است و حافظه کمکی را اختصاص نمی دهد.
    /// به [`sort_unstable_by`](slice::sort_unstable_by) مراجعه کنید.
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی یک نوع ادغام تطبیقی و تکراری است که از [timsort](https://en.wikipedia.org/wiki/Timsort) الهام گرفته شده است.
    /// در مواردی که قطعه تقریباً مرتب شده یا از دو یا چند توالی مرتب شده که یکی پس از دیگری به هم متصل شده اند ، بسیار سریع طراحی شده است.
    ///
    /// همچنین ، ذخیره سازی موقتی را به نصف اندازه `self` اختصاص می دهد ، اما به جای برش های کوتاه ، از یک نوع درج غیر اختصاصی استفاده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // مرتب سازی معکوس
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// برش را با یک عملکرد استخراج کلیدی مرتب می کند.
    ///
    /// این مرتب سازی پایدار است (به عنوان مثال ، ترتیب مجدد عناصر مساوی نیست) و *O*(*m*\* * n *\* log(*n*)) در بدترین حالت ، جایی که عملکرد کلید *O* است (*m*).
    ///
    /// برای عملکردهای کلیدی گران قیمت (به عنوان مثال
    /// توابع که دسترسی ساده به ملک یا عملیات اساسی نیستند) ، [`sort_by_cached_key`](slice::sort_by_cached_key) احتمالاً سریعتر است ، زیرا کلیدهای عنصر را دوباره محاسبه نمی کند.
    ///
    ///
    /// در صورت کاربرد ، مرتب سازی ناپایدار ترجیح داده می شود زیرا به طور کلی سریعتر از مرتب سازی پایدار است و حافظه کمکی را اختصاص نمی دهد.
    /// به [`sort_unstable_by_key`](slice::sort_unstable_by_key) مراجعه کنید.
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی یک نوع ادغام تطبیقی و تکراری است که از [timsort](https://en.wikipedia.org/wiki/Timsort) الهام گرفته شده است.
    /// در مواردی که قطعه تقریباً مرتب شده یا از دو یا چند توالی مرتب شده که یکی پس از دیگری به هم متصل شده اند ، بسیار سریع طراحی شده است.
    ///
    /// همچنین ، ذخیره سازی موقتی را به نصف اندازه `self` اختصاص می دهد ، اما به جای برش های کوتاه ، از یک نوع درج غیر اختصاصی استفاده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// برش را با یک عملکرد استخراج کلیدی مرتب می کند.
    ///
    /// هنگام مرتب سازی ، تابع کلید برای هر عنصر فقط یک بار فراخوانی می شود.
    ///
    /// این مرتب سازی پایدار است (به عنوان مثال ، ترتیب مجدد عناصر مساوی نیست) و *O*(*m*\* * n *+* n *\* log(*n*)) در بدترین حالت ، جایی که عملکرد کلید *O* است (*m*) .
    ///
    /// برای توابع کلیدی ساده (به عنوان مثال ، توابعی که دسترسی به ویژگی ها یا عملیات اساسی هستند) ، [`sort_by_key`](slice::sort_by_key) سریعتر است.
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی مبتنی بر [pattern-defeating quicksort][pdqsort] توسط اورسون پیترز ساخته شده است که ترکیبی از میانگین متوسط سریع مسابقه quicksort تصادفی و سریعترین حالت heapsort است ، در حالی که برشهای با الگوهای خاص به زمان خطی می رسد.
    /// از برخی تصادفی سازی ها برای جلوگیری از موارد منحط استفاده می کند ، اما با یک seed ثابت همیشه رفتار تعیین کننده ای را ارائه می دهد.
    ///
    /// در بدترین حالت ، الگوریتم ذخیره سازی موقتی را به طول قطعه `Vec<(K, usize)>` اختصاص می دهد.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // کمک کلان برای نمایه سازی vector ما با کوچکترین نوع ممکن ، برای کاهش تخصیص.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // عناصر `indices` منحصر به فرد هستند ، زیرا نمایه می شوند ، بنابراین هر نوع با توجه به قطعه اصلی پایدار خواهد بود.
                // ما در اینجا از `sort_unstable` استفاده می کنیم زیرا به تخصیص حافظه کمتری نیاز دارد.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` را در `Vec` جدید کپی می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // در اینجا ، `s` و `x` می توانند به طور مستقل اصلاح شوند.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// `self` را با یک تخصیص دهنده در `Vec` جدید کپی می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // در اینجا ، `s` و `x` می توانند به طور مستقل اصلاح شوند.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // توجه ، برای جزئیات بیشتر به ماژول `hack` در این پرونده مراجعه کنید.
        hack::to_vec(self, alloc)
    }

    /// `self` را بدون کلون یا تخصیص به vector تبدیل می کند.
    ///
    /// vector حاصل می تواند از طریق `Vec دوباره به یک جعبه تبدیل شود<T>روش `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` دیگر قابل استفاده نیست زیرا به `x` تبدیل شده است.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // توجه ، برای جزئیات بیشتر به ماژول `hack` در این پرونده مراجعه کنید.
        hack::into_vec(self)
    }

    /// با تکرار یک برش `n` یک vector ایجاد می کند.
    ///
    /// # Panics
    ///
    /// در صورت سرریز ظرفیت ، این عملکرد panic خواهد بود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// یک panic هنگام سرریز:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // اگر `n` بزرگتر از صفر باشد ، می تواند به صورت `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` تقسیم شود.
        // `2^expn` عددی است که با بیت '1' سمت چپ `n` نشان داده می شود و `rem` قسمت باقیمانده `n` است.
        //
        //

        // استفاده از `Vec` برای دسترسی به `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` تکرار با دو برابر کردن XNUMX بار expn انجام می شود.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // اگر `m > 0` ، بیت های باقیمانده تا سمت چپ '1' وجود دارد.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ظرفیت `self.len() * n` دارد.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n ، 2 ^ expn`) تکرار با کپی کردن تکرارهای `rem` از `buf` خود انجام می شود.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // این از `2^expn > rem` با هم تداخل ندارد.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` برابر است با `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// یک قطعه `T` را به یک ارزش `Self::Output` یکسان می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// یک قطعه `T` را به یک مقدار `Self::Output` یکنواخت می کند و یک جدا کننده داده شده بین هر یک قرار می دهد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// یک قطعه `T` را به یک مقدار `Self::Output` یکنواخت می کند و یک جدا کننده داده شده بین هر یک قرار می دهد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// یک vector را که حاوی یک کپی از این برش است ، برمی گرداند که هر بایت در آن با معادل بزرگ ASCII خود نگاشت می شود.
    ///
    ///
    /// حروف ASCII 'a' تا 'z' با 'A' تا 'Z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بزرگنمایی مقدار در محل ، از [`make_ascii_uppercase`] استفاده کنید.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// یک vector حاوی یک کپی از این برش را برمی گرداند که هر بایت در آن با معادل کوچک ASCII خود نگاشت می شود.
    ///
    ///
    /// حروف ASCII 'A' تا 'Z' با 'a' تا 'z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای کوچک کردن مقدار درجا ، از [`make_ascii_lowercase`] استفاده کنید.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// پسوند traits برای برشها بر روی انواع خاصی از داده ها
////////////////////////////////////////////////////////////////////////////////

/// Helper trait for [`[T]: : concat`](برش::concat).
///
/// Note: از پارامترهای نوع `Item` در این trait استفاده نشده است ، اما اجازه می دهد تا impls عمومی تر باشد.
/// بدون آن ، این خطا را دریافت می کنیم:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// این به این دلیل است که می تواند انواع `V` با چندین implicate `Borrow<[_]>` وجود داشته باشد ، به طوری که انواع مختلف `T` اعمال می شود:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// نوع حاصل پس از الحاق
    type Output;

    /// اجرای ["[T]: : concat"](قطعه::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Helper trait برای ["[T]: : join"](برش::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// نوع حاصل پس از الحاق
    type Output;

    /// اجرای ["[T]: : join"](برش::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// پیاده سازی های استاندارد trait برای برش ها
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // هر چیزی را در هدف رها کنید که جایگزین نخواهد شد
        target.truncate(self.len());

        // target.len <= self.len به دلیل جزییات بالا ، بنابراین برشهای اینجا همیشه در محدوده هستند.
        //
        let (init, tail) = self.split_at(target.len());

        // از مقادیر موجود allocations/resources دوباره استفاده کنید.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` را در ترتیب `v[1..]` از قبل مرتب شده قرار می دهد تا کل `v[..]` مرتب شود.
///
/// این زیر روال انتگرال از نوع درج است.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // سه روش برای پیاده سازی در اینجا وجود دارد:
            //
            // 1. عناصر مجاور را تا جایی که عنصر اول به مقصد نهایی برسد ، عوض کنید.
            //    با این حال ، به این ترتیب ما داده ها را بیش از آنچه لازم است کپی می کنیم.
            //    اگر عناصر سازه های بزرگی باشند (کپی کردن آنها پرهزینه است) ، این روش کند است.
            //
            // 2. تکرار کنید تا مکان مناسب برای اولین عنصر پیدا شود.
            // سپس عناصر جانشین آن را جابجا کنید تا جایی برای آن باز شود و در آخر آن را در سوراخ باقی مانده قرار دهید.
            // این روش خوبی است.
            //
            // 3. اولین عنصر را در یک متغیر موقتی کپی کنید.تکرار کنید تا مکان مناسب برای آن پیدا شود.
            // همانطور که پیش می رویم ، هر عنصر پیموده شده را در شکاف قبل از آن کپی کنید.
            // در آخر ، داده ها را از متغیر موقت در سوراخ باقیمانده کپی کنید.
            // این روش بسیار خوب است.
            // معیارها عملکرد کمی بهتر از روش 2 را نشان می دهند.
            //
            // همه روش ها محک زده شدند ، و 3 بهترین نتایج را نشان داد.بنابراین ما یکی را انتخاب کردیم.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // حالت متوسط فرآیند درج شده همیشه توسط `hole` ردیابی می شود ، که دو هدف دارد:
            // 1. از یکپارچگی `v` در برابر panics در `is_less` محافظت می کند.
            // 2. در آخر سوراخ باقیمانده `v` را پر می کند.
            //
            // Panic ایمنی:
            //
            // اگر `is_less` panics در هر مرحله از فرآیند ، `hole` رها می شود و سوراخ `v` را با `tmp` پر می کند ، بنابراین اطمینان حاصل می کند که `v` هر شی را که در ابتدا نگه داشته بود دقیقاً یک بار نگه دارد.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` رها می شود و بنابراین `tmp` را در سوراخ باقیمانده `v` کپی می کند.
        }
    }

    // وقتی رها شد ، از `src` به `dest` کپی می شود.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// `v[..mid]` و `v[mid..]` را با کاهش `v[..mid]` و `v[mid..]` با استفاده از `buf` به عنوان ذخیره سازی موقت ادغام می کند و نتیجه را در `v[..]` ذخیره می کند.
///
/// # Safety
///
/// دو برش نباید خالی باشند و `mid` باید در مرز باشد.
/// بافر `buf` باید به اندازه کافی بلند باشد تا بتواند یک نسخه از برش کوتاه تر را در خود جای دهد.
/// همچنین ، `T` نباید از نوع صفر باشد.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // فرآیند ادغام ابتدا نسخه کوتاهتر را در `buf` کپی می کند.
    // سپس اجرای تازه کپی شده و مدت طولانی تر به جلو (یا عقب) را ترسیم می کند ، عناصر مصرف نشده بعدی آنها را مقایسه می کند و یکی کمتر (یا بیشتر) را در `v` کپی می کند.
    //
    // به محض اینکه اجرای کوتاه تر به طور کامل مصرف شد ، فرایند انجام می شود.اگر ابتدا طولانی تر مصرف شود ، باید هرچه از کوتاهتر باقی مانده را در سوراخ باقیمانده `v` کپی کنید.
    //
    // حالت متوسط فرآیند همیشه توسط `hole` ردیابی می شود ، که دو هدف را دنبال می کند:
    // 1. از یکپارچگی `v` در برابر panics در `is_less` محافظت می کند.
    // 2. اگر ابتدا طولانی تر مصرف شود ، سوراخ باقیمانده `v` را پر می کند.
    //
    // Panic ایمنی:
    //
    // اگر `is_less` panics در هر مرحله از فرآیند ، `hole` سقوط کرده و سوراخ `v` را با محدوده مصرف نشده `buf` پر می کند ، بنابراین اطمینان حاصل می کند که `v` هر شی را که در ابتدا نگه داشته بود دقیقاً یک بار نگه دارد.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // اجرای چپ کوتاه تر است.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // در ابتدا ، این اشاره گرها به شروع آرایه های خود اشاره می کنند.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // طرف کمتری را مصرف کنید.
            // در صورت برابر بودن ، برای حفظ ثبات ، حرکت چپ را ترجیح دهید.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // اجرای مناسب کوتاه تر است.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // در ابتدا ، این اشاره گرها از انتهای آرایه های خود عبور می کنند.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // طرف بزرگتر را مصرف کنید.
            // در صورت برابر بودن ، دویدن مناسب را برای حفظ ثبات ترجیح می دهید.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // سرانجام ، `hole` سقوط می کند.
    // اگر مدت کوتاه تر به طور کامل مصرف نشود ، هر آنچه از آن باقی بماند اکنون در سوراخ `v` کپی می شود.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // وقتی رها شد ، دامنه `start..end` را در `dest..` کپی کنید.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` از نوع صفر نیست ، بنابراین تقسیم بر اندازه آن اشکالی ندارد.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// این مرتب سازی ادغام برخی از ایده ها (اما نه همه) را از TimSort وام می گیرد ، که به تفصیل [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) شرح داده شده است.
///
///
/// الگوریتم دنباله های دقیقاً نزولی و غیر نزولی را مشخص می کند که به آنها اجرای طبیعی می گویند.مجموعه ای از اجرای های معلق وجود دارد که هنوز ادغام نشده اند.
/// هر اجرای تازه پیدا شده بر روی پشته رانده می شود و سپس برخی از جفت های اجرای مجاور ادغام می شوند تا این دو نامطبوع راضی شوند:
///
/// 1. برای هر `i` در `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. برای هر `i` در `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// ثابت ها اطمینان حاصل می کنند که کل زمان اجرا *O*(*n*\*log(* n*)) در بدترین حالت است).
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // برشهای تا این طول با استفاده از مرتب سازی درج مرتب می شوند.
    const MAX_INSERTION: usize = 20;
    // دواهای بسیار کوتاه با استفاده از مرتب سازی درج ، گسترش می یابند تا حداقل این عناصر را در بر بگیرد.
    const MIN_RUN: usize = 10;

    // مرتب سازی بر روی انواع اندازه صفر رفتار معنی داری ندارد.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // آرایه های کوتاه برای جلوگیری از تخصیص در محل از طریق مرتب سازی درج مرتب می شوند.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // یک بافر اختصاص دهید تا به عنوان حافظه خراش استفاده شود.ما طول 0 را نگه می داریم ، بنابراین می توانیم نسخه های کم عمق `v` را در آن نگه داریم بدون اینکه در صورت استفاده از نسخه های `is_less` panics ، دکترها را روی نسخه های آزمایشی اجرا کنیم.
    //
    // هنگام ادغام دو اجرای مرتب شده ، این بافر یک نسخه از اجرای کوتاه تر را نگه می دارد که طول آن حداکثر `len / 2` خواهد بود.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // به منظور شناسایی اجرای طبیعی در `v` ، آن را به عقب رد می کنیم.
    // این ممکن است یک تصمیم عجیب به نظر برسد ، اما این واقعیت را در نظر بگیرید که ادغام ها بیشتر در جهت مخالف (forwards) انجام می شود.
    // طبق معیارها ، ادغام به جلو کمی سریعتر از ادغام به عقب است.
    // برای نتیجه گیری ، شناسایی اجرا با عبور از عقب عملکرد را بهبود می بخشد.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // اجرای طبیعی بعدی را پیدا کنید و اگر کاملاً نزولی است آن را معکوس کنید.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // اگر خیلی کوتاه است ، عناصر دیگری را وارد برنامه کنید.
        // مرتب سازی درج سریعتر از مرتب سازی در ترتیب کوتاه است ، بنابراین این امر عملکرد را به طور قابل توجهی بهبود می بخشد.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // این حرکت را روی پشته فشار دهید.
        runs.push(Run { start, len: end - start });
        end = start;

        // برای جلب رضایت افراد ناخوشایند ، چند جفت از محل های مجاور را با هم ادغام کنید.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // سرانجام ، دقیقاً یک اجرا باید در پشته باقی بماند.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // پشته اجرا را بررسی می کند و جفت بعدی اجرای را برای ادغام شناسایی می کند.
    // به طور خاص ، اگر `Some(r)` بازگردانده شود ، این بدان معناست که `runs[r]` و `runs[r + 1]` باید در مرحله بعدی ادغام شوند.
    // اگر در عوض الگوریتم باید به ساخت یک اجرای جدید ادامه دهد ، `None` بازگردانده می شود.
    //
    // همانطور که در اینجا توضیح داده شده است ، TimSort به دلیل اجرای اشکالات خود بدنام است.
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // اصل داستان این است: ما باید تغییرات را در چهار اجرای بالای پشته اعمال کنیم.
    // اجرای آنها فقط در سه مورد برتر کافی نیست تا اطمینان حاصل شود که افراد ناموزون همچنان *برای همه* موارد اجرا شده در پشته نگه دارند.
    //
    // این عملکرد چهار مورد برتر را به درستی بررسی می کند.
    // بعلاوه ، اگر اجرای برتر از شاخص 0 شروع شود ، برای تکمیل مرتب سازی ، همیشه تا زمان ریخته شدن پشته ، یک عملیات ادغام را می طلبد.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}