//! لیستی با پیوند مضاعف با گره های متعلق به خود.
//!
//! `LinkedList` امکان هل دادن و ظاهر شدن عناصر را در هر زمان و در زمان ثابت فراهم می کند.
//!
//! NOTE: تقریباً همیشه استفاده از [`Vec`] یا [`VecDeque`] بهتر است زیرا کانتینرهای مبتنی بر آرایه معمولاً سریع تر ، حافظه کارآمدتری دارند و از حافظه نهان پردازنده بهتر استفاده می کنند.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// لیستی با پیوند مضاعف با گره های متعلق به خود.
///
/// `LinkedList` امکان هل دادن و ظاهر شدن عناصر را در هر زمان و در زمان ثابت فراهم می کند.
///
/// NOTE: تقریباً همیشه استفاده از `Vec` یا `VecDeque` بهتر است زیرا کانتینرهای مبتنی بر آرایه معمولاً سریع تر ، حافظه کارآمدتری دارند و از حافظه نهان پردازنده بهتر استفاده می کنند.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// یک تکرار کننده روی عناصر `LinkedList`.
///
/// این `struct` توسط [`LinkedList::iter()`] ایجاد شده است.
/// برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) حذف به نفع `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// یک تکرار کننده قابل تغییر بر روی عناصر `LinkedList`.
///
/// این `struct` توسط [`LinkedList::iter_mut()`] ایجاد شده است.
/// برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // ما در اینجا * به طور انحصاری کل لیست را در اختیار نداریم ، منابع مربوط به `element` گره توسط تکرار کننده ارائه شده است!بنابراین هنگام استفاده از این مراقب باشید؛روشهایی که فراخوانی می شوند باید بدانند که می تواند اشاره گرهای نامشخصی به `element` وجود داشته باشد.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// تکرارکننده مالک بیش از عناصر `LinkedList`.
///
/// این `struct` با روش [`into_iter`] روی [`LinkedList`] ایجاد شده است (تهیه شده توسط `IntoIterator` trait).
/// برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// روشهای خصوصی
impl<T> LinkedList<T> {
    /// گره داده شده را به جلوی لیست اضافه می کند.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // این روش مراقبت می کند تا منابع قابل تغییر در کل گره ها ایجاد نشود ، تا اعتبار اشاره گرهای مستعار به `element` حفظ شود.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // عدم ایجاد منابع جدید قابل تغییر (unique!) با همپوشانی `element`.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// گره موجود در جلوی لیست را برداشته و برمی گرداند.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // این روش مراقبت می کند تا منابع قابل تغییر در کل گره ها ایجاد نشود ، تا اعتبار اشاره گرهای مستعار به `element` حفظ شود.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // عدم ایجاد منابع جدید قابل تغییر (unique!) با همپوشانی `element`.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// گره داده شده را به پشت لیست اضافه می کند.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // این روش مراقبت می کند تا منابع قابل تغییر در کل گره ها ایجاد نشود ، تا اعتبار اشاره گرهای مستعار به `element` حفظ شود.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // عدم ایجاد منابع جدید قابل تغییر (unique!) با همپوشانی `element`.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// گره موجود در پشت لیست را برداشته و برمی گرداند.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // این روش مراقبت می کند تا منابع قابل تغییر در کل گره ها ایجاد نشود ، تا اعتبار اشاره گرهای مستعار به `element` حفظ شود.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // عدم ایجاد منابع جدید قابل تغییر (unique!) با همپوشانی `element`.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// گره مشخص شده را از لیست فعلی لغو پیوند می کند.
    ///
    /// هشدار: این بررسی نمی کند که گره ارائه شده به لیست فعلی تعلق داشته باشد.
    ///
    /// این روش برای حفظ اعتبار اشاره گرهای نام مستعار ، مراقبت می کند تا منابع قابل تغییر در `element` ایجاد نشود.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // این یکی از ما است ، ما می توانیم &mut ایجاد کنیم.

        // عدم ایجاد منابع جدید قابل تغییر (unique!) با همپوشانی `element`.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // این گره گره سر است
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // این گره گره دم است
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// یک سری از گره ها را بین دو گره موجود اتصال می دهد.
    ///
    /// هشدار: این بررسی نمی کند که گره ارائه شده به دو لیست موجود تعلق داشته باشد.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // این روش مراقبت می کند تا چندین منبع قابل تغییر به طور همزمان به کل گره ها ایجاد نشود ، تا اعتبار اشاره گرهای مستعار به `element` حفظ شود.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// همه گره ها را از لیست پیوندی به عنوان مجموعه ای از گره ها جدا می کند.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // گره split گره جدید سر قسمت دوم است
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // سر ptr قسمت دوم را برطرف کنید
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // گره تقسیم گره دم جدید قسمت اول است و صاحب سر قسمت دوم است.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // ptr دم قسمت اول را برطرف کنید
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// `LinkedList<T>` خالی ایجاد می کند.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// `LinkedList` خالی ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// همه عناصر را از `other` به انتهای لیست منتقل می کند.
    ///
    /// با این کار همه گره ها از `other` دوباره استفاده شده و آنها را به `self` منتقل می کنید.
    /// پس از این عمل ، `other` خالی می شود.
    ///
    /// این عملیات باید در *O*(1) زمان و *O*(1) حافظه محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` در اینجا اشکالی ندارد زیرا ما به طور کامل به هر دو لیست دسترسی داریم.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// همه عناصر را از `other` به ابتدای لیست منتقل می کند.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` در اینجا اشکالی ندارد زیرا ما به طور کامل به هر دو لیست دسترسی داریم.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// تکرار کننده رو به جلو ارائه می دهد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// یک تکرار کننده پیش رو با منابع قابل تغییر فراهم می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// مکان نما را در عنصر جلو ارائه می دهد.
    ///
    /// در صورت خالی بودن فهرست ، مکان نما به غیر عنصر "ghost" اشاره می کند.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// مکان نما را با عملکرد ویرایش در عنصر جلو فراهم می کند.
    ///
    /// در صورت خالی بودن فهرست ، مکان نما به غیر عنصر "ghost" اشاره می کند.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// مکان نما را در عنصر پشتی ارائه می دهد.
    ///
    /// در صورت خالی بودن فهرست ، مکان نما به غیر عنصر "ghost" اشاره می کند.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// مکان نما را با عملکرد ویرایش در عنصر پشتی فراهم می کند.
    ///
    /// در صورت خالی بودن فهرست ، مکان نما به غیر عنصر "ghost" اشاره می کند.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// اگر `LinkedList` خالی باشد `true` را برمی گرداند.
    ///
    /// این عملیات باید در زمان *O*(1) محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// طول `LinkedList` را برمی گرداند.
    ///
    /// این عملیات باید در زمان *O*(1) محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// همه عناصر را از `LinkedList` حذف می کند.
    ///
    /// این عملیات باید در زمان *O*(*n*) محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// اگر `LinkedList` دارای عنصری برابر با مقدار داده شده باشد ، `true` را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// در صورت خالی بودن لیست ، به عنصر جلو یا `None` اشاره می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// در صورت خالی بودن لیست ، ارجاع قابل تغییر به عنصر جلو یا `None` را ارائه می دهد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// در صورت خالی بودن لیست ، ارجاعی به عنصر پشتی یا `None` ارائه می دهد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// در صورت خالی بودن لیست ، یک ارجاع قابل تغییر به عنصر پشتی یا `None` ارائه می دهد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// یک عنصر را ابتدا در لیست اضافه می کند.
    ///
    /// این عملیات باید در زمان *O*(1) محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// عنصر اول را حذف کرده و در صورت خالی بودن لیست ، `None` را برمی گرداند.
    ///
    ///
    /// این عملیات باید در زمان *O*(1) محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// یک عنصر را به پشت لیست اضافه می کند.
    ///
    /// این عملیات باید در زمان *O*(1) محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// آخرین عنصر را از لیست حذف کرده و در صورت خالی بودن `None` را برمی گرداند.
    ///
    ///
    /// این عملیات باید در زمان *O*(1) محاسبه شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// لیست را در فهرست داده شده به دو قسمت تقسیم می کند.
    /// همه چیز را بعد از فهرست داده شده برمی گرداند ، از جمله شاخص.
    ///
    /// این عملیات باید در زمان *O*(*n*) محاسبه شود.
    ///
    /// # Panics
    ///
    /// Panics اگر `at > len` باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // در زیر ، بسته به اینکه کدام یک سریعتر باشد ، به سمت گره "i-1" تکرار می شویم.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // به جای پرش با استفاده از .skip() (که ساختار جدیدی ایجاد می کند) ، ما دستی دستی را رد می کنیم تا بدون اینکه به جزئیات اجرای Skip بستگی داشته باشیم ، می توانیم به قسمت head دسترسی پیدا کنیم.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // بهتر است از آخر شروع کنید
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// عنصر موجود در شاخص داده شده را برداشته و برمی گرداند.
    ///
    /// این عملیات باید در زمان *O*(*n*) محاسبه شود.
    ///
    /// # Panics
    /// Panics اگر در>=len باشد
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // در زیر ، ما از ابتدا یا انتها به گره موجود در شاخص داده شده می پردازیم ، بسته به اینکه کدام یک سریعتر باشد.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// یک تکرار کننده ایجاد می کند که برای تعیین اینکه آیا باید یک عنصر حذف شود ، از یک بسته استفاده می کند.
    ///
    /// اگر بسته شدن درست برگردد ، عنصر حذف شده و بازده می شود.
    /// اگر بسته شدن نادرست برگردد ، عنصر در لیست باقی می ماند و توسط تکرار کننده تحویل داده نمی شود.
    ///
    /// توجه داشته باشید که `drain_filter` به شما امکان می دهد هر عنصری را در بسته شدن فیلتر تغییر دهید ، صرف نظر از اینکه آن را انتخاب یا نگه دارید یا حذف کنید.
    ///
    ///
    /// # Examples
    ///
    /// تقسیم لیست به زوج و شانس ، استفاده مجدد از لیست اصلی:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // از پرداخت وام خودداری کنید.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // همان حلقه ای را که در زیر انجام می دهیم ادامه دهید.این تنها زمانی اجرا می شود که یک مخرب وحشت کرده باشد.
                // اگر یکی دیگر از panics سقط شود.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // برای به دست آوردن یک عمر بی بند و بار نیاز دارید
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // برای به دست آوردن یک عمر بی بند و بار نیاز دارید
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // برای به دست آوردن یک عمر بی بند و بار نیاز دارید
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // برای به دست آوردن یک عمر بی بند و بار نیاز دارید
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// نشانگر بالای `LinkedList`.
///
/// `Cursor` مانند یک تکرار کننده است ، با این تفاوت که می تواند آزادانه به دنبال رفت و برگشت باشد.
///
/// مکان نماها همیشه بین دو عنصر در لیست قرار می گیرند و به روشی منطقی دایره ای فهرست می شوند.
/// برای مطابقت با این موضوع ، یک عنصر "ghost" وجود ندارد که `None` را بین سر و دم لیست تولید می کند.
///
///
/// هنگام ایجاد ، مکان نما ها از جلوی لیست شروع می شوند ، یا اگر لیست غیر خالی باشد "ghost" نیست.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// نشانگر بالای `LinkedList` با عملکرد ویرایش.
///
/// `Cursor` مانند یک تکرار کننده است ، با این تفاوت که می تواند آزادانه به جستجوی عقب و جلو بپردازد و در هنگام تکرار می تواند لیست را با خیال راحت تغییر دهد.
/// دلیل این امر این است که طول عمر منابع تولیدشده به جای فقط لیست اصلی ، به طول عمر خود گره خورده است.
/// این بدان معناست که مکان نما ها نمی توانند چندین عنصر را همزمان داشته باشند.
///
/// مکان نماها همیشه بین دو عنصر در لیست قرار می گیرند و به روشی منطقی دایره ای فهرست می شوند.
/// برای مطابقت با این موضوع ، یک عنصر "ghost" وجود ندارد که `None` را بین سر و دم لیست تولید می کند.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// شاخص موقعیت مکان نما را در `LinkedList` برمی گرداند.
    ///
    /// اگر مکان نما در حال حاضر نشانگر غیر عنصر "ghost" باشد ، این `None` را برمی گرداند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// مکان نما را به عنصر بعدی `LinkedList` منتقل می کند.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، این امر آن را به اولین عنصر `LinkedList` منتقل می کند.
    /// اگر به آخرین عنصر `LinkedList` اشاره دارد ، این امر آن را به سمت غیر عنصر "ghost" منتقل می کند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ما هیچ عنصر فعلی نداریم.مکان نما در موقعیت شروع نشسته بود عنصر بعدی باید سر لیست باشد
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ما یک عنصر قبلی داشتیم ، بنابراین بیایید به مورد بعدی آن برویم
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// مکان نما را به عنصر قبلی `LinkedList` منتقل می کند.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، این امر آن را به آخرین عنصر `LinkedList` منتقل می کند.
    /// اگر به اولین عنصر `LinkedList` اشاره دارد ، این امر آن را به سمت غیر عنصر "ghost" منتقل می کند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // جریان نداردما در ابتدای لیست هستیم.عملکرد هیچ کدام و پرش به پایان.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // یک پیشرو داشته باشیدآن را ارائه دهید و به عنصر قبلی بروید.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// مرجعی را به عنصری که مکان نما در حال حاضر به آن اشاره دارد برمی گرداند.
    ///
    /// اگر مکان نما در حال حاضر نشانگر غیر عنصر "ghost" باشد ، این `None` را برمی گرداند.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// مرجعی را به عنصر بعدی برمی گرداند.
    ///
    /// اگر مکان نما به غیر عنصر "ghost" اشاره دارد ، این اولین عنصر `LinkedList` را برمی گرداند.
    /// اگر به آخرین عنصر `LinkedList` اشاره دارد ، این `None` را برمی گرداند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// مرجعی را به عنصر قبلی برمی گرداند.
    ///
    /// اگر نشانگر به غیر عنصر "ghost" اشاره دارد ، این آخرین عنصر `LinkedList` را برمی گرداند.
    /// اگر به اولین عنصر `LinkedList` اشاره دارد ، این `None` را برمی گرداند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// شاخص موقعیت مکان نما را در `LinkedList` برمی گرداند.
    ///
    /// اگر مکان نما در حال حاضر نشانگر غیر عنصر "ghost" باشد ، این `None` را برمی گرداند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// مکان نما را به عنصر بعدی `LinkedList` منتقل می کند.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، این امر آن را به اولین عنصر `LinkedList` منتقل می کند.
    /// اگر به آخرین عنصر `LinkedList` اشاره دارد ، این امر آن را به سمت غیر عنصر "ghost" منتقل می کند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ما هیچ عنصر فعلی نداریم.مکان نما در موقعیت شروع نشسته بود عنصر بعدی باید سر لیست باشد
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ما یک عنصر قبلی داشتیم ، بنابراین بیایید به مورد بعدی آن برویم
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// مکان نما را به عنصر قبلی `LinkedList` منتقل می کند.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، این امر آن را به آخرین عنصر `LinkedList` منتقل می کند.
    /// اگر به اولین عنصر `LinkedList` اشاره دارد ، این امر آن را به سمت غیر عنصر "ghost" منتقل می کند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // جریان نداردما در ابتدای لیست هستیم.عملکرد هیچ کدام و پرش به پایان.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // یک پیشرو داشته باشیدآن را ارائه دهید و به عنصر قبلی بروید.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// مرجعی را به عنصری که مکان نما در حال حاضر به آن اشاره دارد برمی گرداند.
    ///
    /// اگر مکان نما در حال حاضر نشانگر غیر عنصر "ghost" باشد ، این `None` را برمی گرداند.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// مرجعی را به عنصر بعدی برمی گرداند.
    ///
    /// اگر مکان نما به غیر عنصر "ghost" اشاره دارد ، این اولین عنصر `LinkedList` را برمی گرداند.
    /// اگر به آخرین عنصر `LinkedList` اشاره دارد ، این `None` را برمی گرداند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// مرجعی را به عنصر قبلی برمی گرداند.
    ///
    /// اگر نشانگر به غیر عنصر "ghost" اشاره دارد ، این آخرین عنصر `LinkedList` را برمی گرداند.
    /// اگر به اولین عنصر `LinkedList` اشاره دارد ، این `None` را برمی گرداند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// نشانگر فقط خواندنی را نشان می دهد که به عنصر فعلی اشاره دارد.
    ///
    /// طول عمر `Cursor` برگشت یافته به `CursorMut` محدود است ، به این معنی که نمی تواند `CursorMut` را بیش از حد زنده نگه دارد و `CursorMut` برای عمر `Cursor` مسدود است.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// اکنون عملیات ویرایش لیست را لیست کنید

impl<'a, T> CursorMut<'a, T> {
    /// عنصر جدیدی را پس از عنصر فعلی در `LinkedList` وارد می کند.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، عنصر جدید در قسمت جلوی `LinkedList` قرار می گیرد.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // شاخص غیر عنصر "ghost" تغییر کرده است.
                self.index = self.list.len;
            }
        }
    }

    /// عنصر جدیدی را قبل از عنصر فعلی در `LinkedList` وارد می کند.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، عنصر جدید در انتهای `LinkedList` قرار می گیرد.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// عنصر فعلی را از `LinkedList` حذف می کند.
    ///
    /// عنصری که برداشته شد بازگردانده می شود و مکان نما برای نشان دادن عنصر بعدی در `LinkedList` منتقل می شود.
    ///
    ///
    /// اگر مکان نما در حال حاضر به سمت غیر عنصر "ghost" باشد ، هیچ عنصری برداشته نمی شود و `None` بازگردانده می شود.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// بدون جدا کردن گره لیست ، عنصر فعلی را از `LinkedList` حذف می کند.
    ///
    /// گره ای که برداشته شد به عنوان `LinkedList` جدید برگردانده می شود که فقط شامل این گره است.
    /// مکان نما به سمت عنصر بعدی در `LinkedList` فعلی حرکت می کند.
    ///
    /// اگر مکان نما در حال حاضر به سمت غیر عنصر "ghost" باشد ، هیچ عنصری برداشته نمی شود و `None` بازگردانده می شود.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// عناصر `LinkedList` داده شده را بعد از عنصر فعلی قرار می دهد.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، عناصر جدید در ابتدای `LinkedList` قرار می گیرند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // شاخص غیر عنصر "ghost" تغییر کرده است.
                self.index = self.list.len;
            }
        }
    }

    /// عناصر `LinkedList` داده شده را قبل از عنصر فعلی قرار می دهد.
    ///
    /// اگر مکان نما به سمت غیر عنصر "ghost" باشد ، عناصر جدید در انتهای `LinkedList` قرار می گیرند.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// لیست را بعد از عنصر فعلی به دو قسمت تقسیم می کند.
    /// با این کار لیست جدیدی متشکل از همه چیز بعد از مکان نما به شما باز می گردد ، در لیست اصلی همه موارد قبلی را حفظ می کند.
    ///
    ///
    /// اگر نشانگر به سمت غیر عنصر "ghost" باشد ، تمام محتوای `LinkedList` منتقل می شود.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // شاخص غیر عنصر "ghost" به 0 تغییر کرده است.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// لیست را قبل از عنصر فعلی به دو قسمت تقسیم می کند.
    /// با این کار لیست جدیدی متشکل از همه موارد قبل از مکان نما برمی گردد ، در لیست اصلی همه چیز بعد از آن حفظ می شود.
    ///
    ///
    /// اگر نشانگر به سمت غیر عنصر "ghost" باشد ، تمام محتوای `LinkedList` منتقل می شود.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// تکرار کننده ای که با تماس با `drain_filter` در LinkedList تولید شده است.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` با نام مستعار منابع `element` مشکلی نیست.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// لیست را به یک تکرار کننده که عناصر را از نظر مقدار بازده می دهد ، مصرف می کند.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// اطمینان حاصل کنید که `LinkedList` و تکرارکننده های فقط خواندنی آن از نظر پارامترها از نوع متغیر هستند.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}