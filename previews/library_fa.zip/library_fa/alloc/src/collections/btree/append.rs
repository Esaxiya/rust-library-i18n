use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// تمام جفت های مقدار-کلید را از اتحادیه دو تکرار صعودی ضمیمه می کند و یک متغیر `length` را در طول مسیر افزایش می دهد.مورد دوم باعث می شود که هنگام تماس با یک هیدرولیک قطره ، نشت از تماس گیرنده راحت تر باشد.
    ///
    /// اگر هر دو تکرار کننده کلید یکسانی تولید کنند ، این روش جفت را از تکرار کننده سمت چپ رها می کند و جفت را از تکرار کننده سمت راست اضافه می کند.
    ///
    /// اگر می خواهید درخت به ترتیب دقیقاً صعودی ، مانند `BTreeMap` ، به پایان برسد ، هر دو تکرار کننده باید کلیدهایی را به ترتیب دقیق صعودی تولید کنند ، کلیدهای بزرگتر از همه کلیدهای درخت ، از جمله کلیدهای موجود در درخت هنگام ورود.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // ما آماده می شویم که `left` و `right` را به یک ترتیب مرتب شده در زمان خطی ادغام کنیم.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // در همین حال ، ما یک درخت از توالی مرتب شده در زمان خطی می سازیم.
        self.bulk_push(iter, length)
    }

    /// تمام جفت های مقدار کلید را به انتهای درخت هل می دهد و یک متغیر `length` را در طول مسیر افزایش می دهد.
    /// مورد دوم باعث می شود که هنگام تماس با هراس مکرر ، نشتی از تماس گیرنده جلوگیری کند.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // تمام جفتهای مقدار-کلید را تکرار کرده و آنها را در سطح مناسب به گره ها فشار دهید.
        for (key, value) in iter {
            // سعی کنید جفت مقدار کلید را به گره برگ فعلی فشار دهید.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // جایی باقی نمانده ، بالا بروید و آنجا را فشار دهید.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // گره ای با فاصله باقی مانده پیدا کنید ، اینجا را فشار دهید.
                                open_node = parent;
                                break;
                            } else {
                                // دوباره بالا برو
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // ما در بالا هستیم ، یک گره ریشه جدید ایجاد کرده و به آنجا فشار می دهیم.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // فشار جفت مقدار کلید و زیر شاخه سمت راست جدید.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // دوباره به پایین ترین برگ برگردید.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // هر بار تکرار را افزایش دهید تا مطمئن شوید نقشه حتی اگر باعث پیشرفت وحشت زده شود ، عناصر پیوست شده را کاهش می دهد.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// تکرار کننده ای برای ادغام دو توالی مرتب شده در یک
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// اگر دو کلید برابر باشد ، جفت مقدار-کلید را از منبع درست برمی گرداند.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}