// این تلاشی برای پیاده سازی به دنبال ایده آل است
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// از آنجا که Rust در واقع انواع وابسته و بازگشت چند شکلی ندارد ، ما با بسیاری از عدم ایمنی ها کنار می آییم.
//

// هدف اصلی این ماژول جلوگیری از پیچیدگی ها با درمان درخت به عنوان یک ظرف عمومی (اگر به شکل عجیب و غریب شکل گرفته باشد) و جلوگیری از معامله با بیشتر موارد بی مصرف B-Tree است.
//
// به همین ترتیب ، این ماژول اهمیتی ندارد که ورودی ها مرتب شده باشند ، کدام گره ها می توانند کمبود شوند ، یا حتی معنی کمبود آنها چیست.با این حال ، ما به چند تغییر ناپذیر اعتماد می کنیم:
//
// - درختان باید دارای depth/height یکنواخت باشند.این بدان معنی است که هر مسیر از یک گره مشخص به یک برگ منتهی می شود ، دقیقاً طول یکسانی دارد.
// - گره ای به طول `n` دارای کلیدهای `n` ، مقادیر `n` و لبه های `n + 1` است.
//   این بدان معنی است که حتی یک گره خالی نیز حداقل دارای یک edge است.
//   برای گره برگ ، "having an edge" فقط بدان معنی است که می توانیم موقعیتی را در گره شناسایی کنیم ، زیرا لبه های برگ خالی هستند و نیازی به نمایش داده ندارند.
// در یک گره داخلی ، edge هم موقعیت را مشخص می کند و هم شامل یک اشاره گر برای گره کودک است.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// بازنمایی اصلی گره های برگ و بخشی از نمایش گره های داخلی.
struct LeafNode<K, V> {
    /// ما می خواهیم در `K` و `V` همبسته باشیم.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// این گره در آرایه `edges` گره اصلی قرار می گیرد.
    /// `*node.parent.edges[node.parent_idx]` باید همان `node` باشد.
    /// این تضمین می شود که تنها درصورت غیر خالی بودن `parent` مقداردهی اولیه شود.
    parent_idx: MaybeUninit<u16>,

    /// تعداد کلیدها و مقادیر ذخیره شده در این گره.
    len: u16,

    /// آرایه ها داده های واقعی گره را ذخیره می کنند.
    /// فقط اولین عناصر `len` هر آرایه مقدماتی و معتبر هستند.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// `LeafNode` جدید را در محل شروع می کند.
    unsafe fn init(this: *mut Self) {
        // به عنوان یک سیاست کلی ، در صورت امکان ، زمینه ها را غیر اولیه می گذاریم ، زیرا باید در Valgrind کمی سریعتر و ردیابی آن آسان تر باشد.
        //
        unsafe {
            // parent_idx ، کلیدها و vals همه شاید یونی نیت باشند
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// `LeafNode` جدید جعبه ای ایجاد می کند.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// بازنمایی گره های داخلیهمانند «LeafNode`s» ، این موارد باید پشت «BoxedNode`s» مخفی شوند تا از افتادن کلیدها و مقادیر غیر اولیه جلوگیری شود.
/// هر اشاره گر به `InternalNode` می تواند مستقیماً به یک نشانگر به قسمت `LeafNode` زیرین گره منتقل شود ، به کد اجازه می دهد تا بر روی گره های برگ و داخلی عمل کند بدون اینکه حتی بررسی کند که نشانگر به کدام دو نشان می دهد.
///
/// این ویژگی با استفاده از `repr(C)` فعال می شود.
///
#[repr(C)]
// gdb_providers.py از این نوع نام برای درون نگری استفاده می کند.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// اشاره گرها به فرزندان این گره.
    /// `len + 1` از این موارد اولیه و معتبر در نظر گرفته می شوند ، با این تفاوت که نزدیک به انتها ، در حالی که درخت از طریق نوع وام `Dying` نگه داشته می شود ، برخی از این نشانگرها آویزان هستند.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// `InternalNode` جدید جعبه ای ایجاد می کند.
    ///
    /// # Safety
    /// یک تغییر ناپذیر از گره های داخلی این است که آنها حداقل یک edge اولیه و معتبر دارند.
    /// این عملکرد چنین edge را تنظیم نمی کند.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // ما فقط باید داده ها را اولیه کنیم.لبه ها MaybeUninit هستند.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// یک اشاره گر مدیریت شده و غیر تهی به یک گره.این یا اشاره گر متعلق به `LeafNode<K, V>` است یا نشانگر متعلق به `InternalNode<K, V>`.
///
/// با این حال ، `BoxedNode` هیچ اطلاعاتی در مورد اینکه واقعاً کدام یک از دو نوع گره را شامل می شود ، ندارد و تا حدی به دلیل این کمبود اطلاعات ، نوع جداگانه ای نیست و مخرب نیست.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// گره ریشه یک درخت متعلق به.
///
/// توجه داشته باشید که این تخریب کننده ندارد و باید به صورت دستی تمیز شود.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// یک درخت متعلق به جدید را بازمی گرداند ، با گره اصلی خود که در ابتدا خالی است.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` نباید صفر باشد.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// به طور متغیر گره ریشه متعلق به خود را قرض می گیرد.
    /// برخلاف `reborrow_mut` ، این ایمن است زیرا از مقدار بازگشتی نمی توان برای از بین بردن ریشه استفاده کرد و سایر مراجع به درخت وجود ندارد.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// اندکی متغیر گره ریشه متعلق به خود را قرض می گیرد.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// برگشت ناپذیر به مرجعی منتقل می شود که امکان عبور و مرور را فراهم می کند و روش های مخربی را ارائه می دهد و موارد دیگر.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// یک گره داخلی جدید با یک edge نشانگر به گره قبلی قبلی اضافه می کند ، آن گره جدید را گره ریشه می کنید و آن را برگردانید.
    /// این ارتفاع را 1 افزایش می دهد و در مقابل `pop_internal_level` است.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, با این تفاوت که ما فقط فراموش کردیم که اکنون داخلی هستیم:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// گره داخلی ریشه را با استفاده از اولین فرزند خود به عنوان گره ریشه جدید از بین می برد.
    /// از آنجا که فقط درصورتی که گره ریشه فقط یک فرزند داشته باشد فراخوانی می شود ، هیچ پاک سازی روی هیچ یک از کلیدها ، مقادیر و سایر کودکان انجام نمی شود.
    ///
    /// این ارتفاع را 1 کاهش می دهد و در مقابل `push_internal_level` است.
    ///
    /// نیاز به دسترسی انحصاری به شی `Root` دارد اما نه به گره ریشه.
    /// این دسته ها یا ارجاعات دیگر به گره ریشه را بی اعتبار نمی کند.
    ///
    /// Panics اگر سطح داخلی وجود نداشته باشد ، یعنی اگر گره ریشه یک برگ باشد.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // ایمنی: ما ادعا کردیم که داخلی هستیم.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // ایمنی: ما `self` را به طور انحصاری وام گرفتیم و نوع وام آن منحصر به فرد است.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // ایمنی: اولین edge همیشه مقداردهی اولیه می شود.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` همیشه در `K` و `V` با هم تغییر می کند ، حتی وقتی `BorrowType` `Mut` باشد.
// این از نظر فنی اشتباه است ، اما به دلیل استفاده داخلی از `NodeRef` نمی تواند منجر به عدم امنیت شود زیرا ما نسبت به `K` و `V` کاملاً عمومی هستیم.
//
// با این حال ، هر زمان که یک نوع عمومی `NodeRef` را می پیچد ، مطمئن شوید که از واریانس صحیح برخوردار است.
//
/// ارجاع به یک گره.
///
/// این نوع دارای تعدادی پارامتر است که نحوه عملکرد آن را کنترل می کند:
/// - `BorrowType`: نوعی ساختگی که نوع وام را توصیف می کند و یک عمر را به همراه دارد.
///    - وقتی این `Immut<'a>` باشد ، `NodeRef` تقریباً مانند `&'a Node` عمل می کند.
///    - هنگامی که این `ValMut<'a>` باشد ، `NodeRef` با توجه به کلیدها و ساختار درخت تقریباً مانند `&'a Node` عمل می کند ، اما همچنین اجازه می دهد تا بسیاری از ارجاعات قابل تغییر به مقادیر موجود در درخت با هم زندگی کنند.
///    - هنگامی که این `Mut<'a>` باشد ، `NodeRef` تقریباً مانند `&'a mut Node` عمل می کند ، اگرچه روش های درج به یک اشاره گر قابل تغییر برای یک مقدار امکان همزیستی را می دهند.
///    - وقتی این `Owned` باشد ، `NodeRef` تقریباً مانند `Box<Node>` عمل می کند ، اما تخریب کننده ندارد و باید به صورت دستی تمیز شود.
///    - هنگامی که این `Dying` باشد ، `NodeRef` هنوز تقریباً مانند `Box<Node>` عمل می کند ، اما روش هایی برای از بین بردن ذره ذره درخت دارد و روش های معمولی ، اگرچه برای تماس غیر ایمن مشخص نیستند ، اما اگر اشتباه نامیده شود می توانند UB را فراخوانی کنند.
///
///   از آنجا که هر `NodeRef` امکان گشتن در میان درخت را فراهم می کند ، `BorrowType` به طور م toثر برای کل درخت اعمال می شود ، نه فقط برای خود گره.
/// - `K` و `V`: اینها انواع کلیدها و مقادیر ذخیره شده در گره ها هستند.
/// - `Type`: این می تواند `Leaf` ، `Internal` یا `LeafOrInternal` باشد.
/// وقتی این `Leaf` باشد ، `NodeRef` به گره برگ اشاره می کند ، وقتی `Internal` است `NodeRef` به گره داخلی اشاره می کند و وقتی `LeafOrInternal` باشد `NodeRef` می تواند به هر یک از گره ها اشاره کند.
///   `Type` در صورت استفاده در خارج از `NodeRef` ، `NodeType` نامگذاری می شود.
///
/// `BorrowType` و `NodeType` برای بهره برداری از ایمنی نوع ساکن ، روشهایی را که ما پیاده سازی می کنیم محدود می کنند.در نحوه اعمال چنین محدودیت هایی محدودیت هایی وجود دارد:
/// - برای هر پارامتر نوع ، ما فقط می توانیم یک روش را به صورت عمومی یا برای یک نوع خاص تعریف کنیم.
/// به عنوان مثال ، ما نمی توانیم روشی مانند `into_kv` را به طور عام برای همه `BorrowType` یا یکبار برای همه انواع که مادام العمر دارند تعریف کنیم ، زیرا می خواهیم منابع `&'a` را برگرداند.
///   بنابراین ، ما آن را فقط برای کم قدرت ترین نوع `Immut<'a>` تعریف می کنیم.
/// - ما نمی توانیم از گفته های `Mut<'a>` به `Immut<'a>` اجبار ضمنی بگیریم.
///   بنابراین ، ما باید صریحاً `reborrow` را با `NodeRef` قدرتمندتر فراخوانی کنیم تا به روشی مانند `into_kv` برسیم.
///
/// همه روش های `NodeRef` که نوعی مرجع را برمی گرداند ، یا:
/// - `self` را از نظر ارزش در نظر بگیرید و طول عمر انجام شده توسط `BorrowType` را بازگردانید.
///   گاهی اوقات ، برای فراخوانی چنین روشی ، باید با `reborrow_mut` تماس بگیریم.
/// - `self` را به عنوان مرجع در نظر بگیرید ، و (implicitly) به جای طول عمر `BorrowType` ، عمر آن مرجع را برمی گرداند.
/// به این ترتیب ، وام گیرنده تضمین می کند که `NodeRef` تا زمانی که از مرجع برگشتی استفاده شود ، قرض گرفته می شود.
///   روشهای پشتیبانی از insert با برگرداندن یک اشاره گر خام ، یعنی یک مرجع بدون هیچ عمر ، این قاعده را خم می کنند.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// تعداد سطوحی که گره و سطح برگها از هم جدا هستند ، یک ثابت گره است که به طور کامل توسط `Type` قابل توصیف نیست و گره خود آن را ذخیره نمی کند.
    /// ما فقط باید ارتفاع گره ریشه را ذخیره کرده و هر گره دیگر را از آن استخراج کنیم.
    /// اگر `Type` `Leaf` باشد صفر و اگر `Type` `Internal` باشد صفر باشد.
    ///
    ///
    height: usize,
    /// اشاره گر به برگ یا گره داخلی.
    /// تعریف `InternalNode` معتبر بودن نشانگر را به هر دو صورت تضمین می کند.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// یک مرجع گره را که به عنوان `NodeRef::parent` بسته بندی شده است ، باز کنید.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// داده های یک گره داخلی را نشان می دهد.
    ///
    /// ptr خام را برمی گرداند تا از اعتبار سنجی سایر مراجع به این گره جلوگیری کند.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // ایمنی: نوع گره ساکن `Internal` است.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// دسترسی انحصاری به داده های یک گره داخلی را قطع می کند.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// طول گره را پیدا می کند.این تعداد کلید یا مقدار است.
    /// تعداد لبه ها `len() + 1` است.
    /// توجه داشته باشید که ، علیرغم ایمن بودن ، فراخوانی این عملکرد می تواند منجر به بی اعتبار شدن منابع قابل تغییر شود که کد ناامن ایجاد کرده است.
    ///
    pub fn len(&self) -> usize {
        // نکته اساسی ، ما در اینجا فقط به قسمت `len` دسترسی پیدا می کنیم.
        // اگر BorrowType marker::ValMut باشد ، ممکن است ارجاعات قابل تغییر قابل توجهی به مقادیری وجود داشته باشد که نباید آنها را بی اعتبار کنیم.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// تعداد سطوحی را که گره و برگها از هم جدا هستند برمی گرداند.
    /// ارتفاع صفر یعنی گره خودش یک برگ است.
    /// اگر درختان را با ریشه در بالا تصویر کنید ، عدد نشان می دهد که گره در کدام ارتفاع ظاهر می شود.
    /// اگر درختان را با برگهای بالا تصویر کنید ، این عدد نشان می دهد که درخت تا چه حد بالای گره گسترش یافته است.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// به طور موقت اشاره دیگری تغییرناپذیر به همان گره انجام می دهد.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// قسمت برگ هر برگ یا گره داخلی را نشان می دهد.
    ///
    /// ptr خام را برمی گرداند تا از اعتبار سنجی سایر مراجع به این گره جلوگیری کند.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // گره باید حداقل برای قسمت LeafNode معتبر باشد.
        // این یک مرجع در نوع NodeRef نیست زیرا ما نمی دانیم که باید منحصر به فرد باشد یا مشترک.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// والد گره فعلی را پیدا می کند.
    /// اگر گره فعلی واقعاً دارای یک والد باشد ، `Ok(handle)` را برمی گرداند ، جایی که `handle` به edge والدین اشاره می کند که به گره فعلی اشاره دارد.
    ///
    /// اگر گره فعلی هیچ والدی نداشته باشد ، `Err(self)` را برمی گرداند ، `NodeRef` اصلی را پس می دهد.
    ///
    /// نام متد فرض می کند شما درختان را با گره ریشه در بالا تصویر می کنید.
    ///
    /// `edge.descend().ascend().unwrap()` و `node.ascend().unwrap().descend()` هر دو ، پس از موفقیت ، نباید کاری انجام دهند.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ما باید از نشانگرهای خام برای گره ها استفاده کنیم زیرا ، اگر BorrowType marker::ValMut باشد ، ممکن است منابع قابل تغییر قابل تغییر به مقادیری وجود داشته باشد که نباید آنها را بی اعتبار کنیم.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// توجه داشته باشید که `self` نباید خالی باشد.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// توجه داشته باشید که `self` نباید خالی باشد.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// قسمت برگ هر برگ یا گره داخلی را در یک درخت تغییرناپذیر نشان می دهد.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // ایمنی: هیچ ارجاع متغیری به این درخت وام گرفته شده به عنوان `Immut` وجود ندارد.
        unsafe { &*ptr }
    }

    /// نمایش کلیدهای ذخیره شده در گره را نمایش می دهد.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// مشابه `ascend` ، به گره اصلی گره ارجاع داده می شود ، اما گره فعلی را نیز در فرآیند جابجا می کند.
    /// این ایمن نیست زیرا گره فعلی با وجود جدا شدن از محل ، همچنان قابل دسترسی است.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// اطلاعات ایمنی را که این گره `Leaf` است به طور ناامن به کامپایلر ادعا می کند.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// اطلاعات ایمنی را که این گره `Internal` است به طور ناامن به کامپایلر ادعا می کند.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// به طور موقت اشاره دیگری متغیر به همان گره خارج می کند.مراقب باشید ، زیرا این روش بسیار خطرناک است ، مضاعف زیرا ممکن است بلافاصله خطرناک به نظر نرسد.
    ///
    /// از آنجا که اشاره گرهای قابل تغییر می توانند در هرجای اطراف درخت پرسه بزنند ، از نشانگر برگردانده شده می توان به راحتی آویزان ، خارج از محدوده یا بی اعتبار نشانگر اصلی استفاده کرد.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) در نظر بگیرید که یک نوع پارامتر دیگر به `NodeRef` اضافه کنید که استفاده از روشهای ناوبری را در اشاره گرهای مجدداً محدود می کند و از این عدم ایمنی جلوگیری می کند.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// دسترسی انحصاری به قسمت برگ هر برگ یا گره داخلی را قطع می کند.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // ایمنی: ما به کل گره دسترسی انحصاری داریم.
        unsafe { &mut *ptr }
    }

    /// دسترسی انحصاری به قسمت برگ هر برگ یا گره داخلی را ارائه می دهد.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // ایمنی: ما به کل گره دسترسی انحصاری داریم.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// دسترسی منحصر به فرد به عنصری از محل ذخیره کلید.
    ///
    /// # Safety
    /// `index` در مرزهای 0.. ظرفیت است
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // ایمنی: تماس گیرنده قادر به فراخوانی روشهای دیگر نیست
        // تا زمانی که مرجع قطعه کلیدی حذف نشود ، زیرا ما در طول مدت وام دسترسی منحصر به فرد داریم.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// دسترسی انحصاری به یک عنصر یا قطعه از منطقه ذخیره مقدار گره را مهار می کند.
    ///
    /// # Safety
    /// `index` در مرزهای 0.. ظرفیت است
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // ایمنی: تماس گیرنده قادر به فراخوانی روشهای دیگر نیست
        // تا زمانی که مرجع قطعه ارزش کاهش یابد ، زیرا ما در طول مدت وام دسترسی منحصر به فرد داریم.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// دسترسی منحصر به فرد به یک عنصر یا برش از محل ذخیره گره برای محتویات edge.
    ///
    /// # Safety
    /// `index` در مرزهای 0.. ظرفیت + 1 است
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // ایمنی: تماس گیرنده قادر به فراخوانی روشهای دیگر نیست
        // تا زمانی که مرجع قطعه edge حذف نشود ، زیرا در طول مدت وام دسترسی منحصر به فردی داریم.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - گره بیش از `idx` عناصر اولیه دارد.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // ما فقط به یک عنصر مورد علاقه خود اشاره می کنیم تا با ارجاع برجسته به سایر عناصر ، به ویژه مواردی که در تکرارهای قبلی به تماس گیرنده برگردانده شده اند ، از الگویی کردن جلوگیری کنیم.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // ما به دلیل مسئله Rust #74679 باید نشانگرهای آرایه بدون اندازه را مجبور کنیم.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// دسترسی منحصر به فرد به طول گره.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// پیوند گره را به edge والد خود تنظیم می کند ، بدون اینکه سایر مراجع به گره معتبر باشد.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// پیوند ریشه به edge والدین خود را پاک می کند.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// یک جفت مقدار-کلید به انتهای گره اضافه می کند.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// هر موردی که توسط `range` برگردانده شود ، یک شاخص معتبر edge برای گره است.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// یک جفت مقدار کلید و یک edge برای رفتن به سمت راست آن جفت ، به انتهای گره اضافه می کند.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// بررسی می کند گره گره `Internal` است یا گره `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// اشاره به یک جفت مقدار-کلید خاص یا edge درون گره.
/// پارامتر `Node` باید `NodeRef` باشد ، در حالی که `Type` می تواند `KV` باشد (نشانگر یک دسته در یک جفت مقدار کلید) یا `Edge` (نشان دهنده یک دسته در edge).
///
/// توجه داشته باشید که حتی گره های `Leaf` نیز می توانند دسته های `Edge` داشته باشند.
/// اینها به جای نشانگر یک گره کودک ، فضاهایی را نشان می دهند که نشانگرهای کودک بین جفت-مقدار کلید قرار می گیرند.
/// به عنوان مثال ، در یک گره با طول 2 ، 3 مکان ممکن برای edge وجود دارد ، یکی در سمت چپ گره ، یکی بین دو جفت و دیگری در سمت راست گره.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// ما به کلیات کامل `#[derive(Clone)]` نیازی نداریم ، زیرا تنها زمانی که `Node` قابل ایجاد "Clone" باشد زمانی است که یک مرجع تغییرناپذیر باشد و بنابراین `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// گره حاوی edge یا جفت مقدار کلید را که این دسته به آن نشان می دهد بازیابی می کند.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// موقعیت این دسته را در گره برمی گرداند.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// یک دسته جدید برای یک جفت مقدار-کلید در `node` ایجاد می کند.
    /// ناامن است زیرا تماس گیرنده باید اطمینان حاصل کند که `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// می تواند یک پیاده سازی عمومی از PartialEq باشد ، اما فقط در این ماژول استفاده می شود.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// به طور موقت دستگیره غیر قابل تغییر دیگری را در همان مکان خارج می کند.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // ما نمی توانیم از Handle::new_kv یا Handle::new_edge استفاده کنیم زیرا نوع خود را نمی دانیم
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// به طور ناامن اطلاعات ثابت را به گرد آورنده ادعا می کند که گره دسته `Leaf` است.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// به طور موقت دسته دیگری را که در آن مکان قابل تغییر است خارج می کند.
    /// مراقب باشید ، زیرا این روش بسیار خطرناک است ، مضاعف زیرا ممکن است بلافاصله خطرناک به نظر نرسد.
    ///
    ///
    /// برای جزئیات ، به `NodeRef::reborrow_mut` مراجعه کنید.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // ما نمی توانیم از Handle::new_kv یا Handle::new_edge استفاده کنیم زیرا نوع خود را نمی دانیم
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// یک دسته جدید برای edge در `node` ایجاد می کند.
    /// ناامن است زیرا تماس گیرنده باید اطمینان حاصل کند که `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// با توجه به یک شاخص edge که می خواهیم آن را در گره ای پر از ظرفیت قرار دهیم ، یک شاخص KV معقول از یک نقطه تقسیم شده و محل درج را محاسبه می کند.
///
/// هدف از نقطه تقسیم این است که کلید و مقدار آن در یک گره اصلی خاتمه یابد.
/// کلیدها ، مقادیر و لبه های سمت چپ نقطه تقسیم شده به فرزند چپ تبدیل می شوند.
/// کلیدها ، مقادیر و لبه ها در سمت راست نقطه تقسیم شده فرزند مناسب هستند.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // شماره Rust #74834 سعی در توضیح این قوانین متقارن دارد.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// یک جفت کلید-کلید جدید بین جفت-مقدار کلید در سمت راست و چپ این edge قرار می دهد.
    /// این روش فرض می کند که فضای کافی برای گره خوردن جفت جدید در گره وجود دارد.
    ///
    /// نشانگر برگشتی به مقدار درج شده اشاره می کند.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// یک جفت کلید-کلید جدید بین جفت-مقدار کلید در سمت راست و چپ این edge قرار می دهد.
    /// اگر فضای کافی وجود نداشته باشد ، این روش گره را تقسیم می کند.
    ///
    /// نشانگر برگشتی به مقدار درج شده اشاره می کند.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// نشانگر والد و شاخص را در گره فرزند که این edge به آن پیوند دارد برطرف می کند.
    /// این مفید است هنگامی که ترتیب لبه ها تغییر کرده است ،
    fn correct_parent_link(self) {
        // بدون نامعتبر کردن سایر مراجع به گره ، backpointer ایجاد کنید.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// یک جفت مقدار کلید و یک edge جدید قرار می دهد که در سمت راست آن جفت جدید بین این edge و جفت مقدار کلید در سمت راست این edge قرار می گیرد.
    /// این روش فرض می کند که فضای کافی برای گره خوردن جفت جدید در گره وجود دارد.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// یک جفت مقدار کلید و یک edge جدید قرار می دهد که در سمت راست آن جفت جدید بین این edge و جفت مقدار کلید در سمت راست این edge قرار می گیرد.
    /// اگر فضای کافی وجود نداشته باشد ، این روش گره را تقسیم می کند.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// یک جفت کلید-کلید جدید بین جفت-مقدار کلید در سمت راست و چپ این edge قرار می دهد.
    /// این روش اگر فضای کافی نداشته باشد گره را تقسیم می کند و سعی می کند تا قسمت تقسیم شده را به صورت بازگشتی در گره اصلی وارد کنید ، تا زمانی که به ریشه برسید.
    ///
    ///
    /// اگر نتیجه برگشتی `Fit` باشد ، گره دسته آن می تواند گره این edge یا اجداد باشد.
    /// اگر نتیجه بازگشتی `Split` باشد ، قسمت `left` گره ریشه خواهد بود.
    /// نشانگر برگشتی به مقدار درج شده اشاره می کند.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// گره اشاره شده توسط این edge را پیدا می کند.
    ///
    /// نام متد فرض می کند شما درختان را با گره ریشه در بالا تصویر می کنید.
    ///
    /// `edge.descend().ascend().unwrap()` و `node.ascend().unwrap().descend()` هر دو ، پس از موفقیت ، نباید کاری انجام دهند.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ما باید از نشانگرهای خام برای گره ها استفاده کنیم زیرا ، اگر BorrowType marker::ValMut باشد ، ممکن است منابع قابل تغییر قابل تغییر به مقادیری وجود داشته باشد که نباید آنها را بی اعتبار کنیم.
        // برای دسترسی به قسمت ارتفاع هیچ نگرانی وجود ندارد زیرا این مقدار کپی می شود.
        // مراقب باشید که ، به محض مراجعه از نشانگر گره ، ما به یک آرایه لبه ها با یک مرجع دسترسی پیدا می کنیم (Rust Issue #73987) و سایر مراجع به آرایه یا داخل آن را باطل می کنیم ، اگر وجود داشته باشد.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // ما نمی توانیم متدهای جداگانه کلید و مقدار را فراخوانی کنیم ، زیرا فراخوانی مورد دوم مرجع برگشت داده شده توسط مورد اول را بی اعتبار می کند.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// کلید و مقداری را که دسته KV به آن اشاره دارد جایگزین کنید.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// با مراقبت از داده های برگ ، به پیاده سازی `split` برای `NodeType` خاص کمک می کند.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// گره زیرین را به سه قسمت تقسیم می کند:
    ///
    /// - گره کوتاه می شود تا فقط شامل جفت های مقدار کلید در سمت چپ این دسته باشد.
    /// - کلید و مقدار اشاره شده توسط این دسته استخراج می شود.
    /// - همه جفت های مقدار کلید در سمت راست این دسته در یک گره تازه تخصیص یافته قرار می گیرند.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// جفت مقدار کلید را که توسط این دسته نشان داده شده است حذف می کند و آن را به همراه edge که جفت مقدار کلید در آن فرو ریخته است برمی گرداند.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// گره زیرین را به سه قسمت تقسیم می کند:
    ///
    /// - گره کوتاه می شود تا فقط حاوی لبه ها و جفت مقدار کلید در سمت چپ این دسته باشد.
    /// - کلید و مقدار اشاره شده توسط این دسته استخراج می شود.
    /// - تمام لبه ها و جفت های مقدار کلید در سمت راست این دسته در یک گره تازه تخصیص یافته قرار می گیرند.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// یک جلسه برای ارزیابی و انجام یک عملیات متعادل سازی در اطراف یک جفت داخلی مقدار-کلید را نشان می دهد.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// یک زمینه متعادل کننده شامل گره در کودکی را انتخاب می کند ، بنابراین بین KV بلافاصله به سمت چپ یا راست در گره اصلی قرار دارد.
    /// در صورت عدم وجود والدین ، `Err` را برمی گرداند.
    /// اگر والدین خالی باشد ، Panics.
    ///
    /// سمت چپ را ترجیح می دهد تا اگر گره داده شده به نوعی کمبود داشته باشد ، بهینه باشد ، به این معنی که در اینجا فقط عناصر کمتری نسبت به خواهر برادر چپ خود و در صورت وجود از خواهر و برادر راست خود ، کمتر است.
    /// در این حالت ، ادغام با خواهر و برادر چپ سریعتر است ، زیرا ما فقط باید عناصر N گره را حرکت دهیم ، به جای اینکه آنها را به سمت راست منتقل کنیم و بیش از N عناصر جلو را حرکت دهیم.
    /// سرقت از خواهر و برادر چپ نیز معمولاً سریعتر است ، زیرا ما فقط به جای اینکه حداقل N از عناصر خواهر و برادر را به سمت چپ تغییر دهیم ، فقط باید عناصر N گره را به سمت راست تغییر دهیم.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// اینکه آیا ادغام امکان پذیر است ، یعنی اینکه آیا فضای کافی در یک گره برای ترکیب KV مرکزی با هر دو گره کودک مجاور وجود دارد.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ادغام را انجام می دهد و به شما اجازه می دهد که بسته شدن کالا تصمیم بگیرد چه چیزی را برگرداند.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // ایمنی: ارتفاع گره های ادغام شده یک زیر ارتفاع است
                // از گره این edge ، بنابراین بالای صفر ، بنابراین داخلی هستند.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// جفت مقدار کلید والدین و هر دو گره فرزند مجاور را در گره فرزند سمت چپ ادغام کرده و گره اصلی کوچک شده را برمی گرداند.
    ///
    ///
    /// Panics مگر اینکه ما `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// جفت مقدار کلید والدین و هر دو گره فرزند مجاور را در گره فرزند چپ ادغام کرده و آن گره فرزند را برمی گرداند.
    ///
    ///
    /// Panics مگر اینکه ما `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// جفت کلید-کلید والدین و هر دو گره فرزند مجاور را در گره فرزند چپ ادغام کرده و دسته edge را در آن گره فرزند که فرزند پیگیری شده edge به پایان رسید ، برمی گرداند ،
    ///
    ///
    /// Panics مگر اینکه ما `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// در حالی که جفت کلید-کلید والد را به فرزند راست می رانید ، یک جفت مقدار-کلید را از فرزند چپ حذف کرده و آن را در ذخیره کلید-کلید والدین قرار می دهد.
    ///
    /// یک دستگیره را به edge در کودک مناسب بازمی گرداند ، مطابق با جایی که edge اصلی مشخص شده توسط `track_right_edge_idx` به پایان رسید.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// در حالی که جفت کلید-کلید والد را به فرزند چپ فشار می دهید ، یک جفت مقدار-کلید را از فرزند راست حذف کرده و در حافظه-کلید-اصلی والدین قرار می دهد.
    ///
    /// یک دسته را در کودک سمت چپ مشخص شده توسط `track_left_edge_idx` به edge برمی گرداند ، که حرکت نکرد.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// این کار سرقت مشابه `steal_left` را انجام می دهد اما همزمان چندین عنصر را می دزدد.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // اطمینان حاصل کنید که ممکن است با خیال راحت سرقت کنیم.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // داده های برگ را جابجا کنید.
            {
                // در کودک مناسب فضای لازم برای عناصر دزدیده شده را فراهم کنید.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // عناصر را از کودک چپ به سمت راست منتقل کنید.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // جفت سرقت ترین چپ را به والدین منتقل کنید.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // جفت ارزش کلیدی والدین را به فرزند مناسب منتقل کنید.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // جا برای لبه های دزدیده شده بگذارید.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // لبه ها را بدزدید.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// کلون متقارن `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // اطمینان حاصل کنید که ممکن است با خیال راحت سرقت کنیم.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // داده های برگ را جابجا کنید.
            {
                // جفت درست ترین سرقت شده را به والدین منتقل کنید.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // جفت مقدار کلید والدین را به فرزند چپ منتقل کنید.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // عناصر را از کودک راست به سمت چپ منتقل کنید.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // جای خالی عناصر دزدیده شده را پر کنید.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // لبه ها را بدزدید.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // شکاف را در جایی که لبه های دزدیده شده وجود دارد پر کنید.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// هرگونه اطلاعات استاتیک را که ادعا می کند این گره یک گره `Leaf` است ، از بین می برد.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// هرگونه اطلاعات استاتیک را که ادعا می کند این گره یک گره `Internal` است ، از بین می برد.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// بررسی می کند گره اصلی گره `Internal` است یا گره `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// پسوند را بعد از `self` از یک گره به گره دیگر منتقل کنید.`right` باید خالی باشد.
    /// اولین edge `right` بدون تغییر باقی مانده است.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// نتیجه درج ، هنگامی که یک گره نیاز به گسترش بیش از ظرفیت خود دارد.
pub struct SplitResult<'a, K, V, NodeType> {
    // گره تغییر یافته در درخت موجود با عناصر و لبه هایی که متعلق به سمت چپ `kv` است.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // مقداری از کلید و مقدار تقسیم می شود تا در جای دیگری قرار گیرد.
    pub kv: (K, V),
    // گره متعلق به خود ، غیر متصل ، جدید با عناصر و لبه هایی که به سمت راست `kv` تعلق دارند.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // اینکه آیا ارجاعات گره از این نوع وام اجازه عبور از گره های دیگر درخت را می دهد.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // پیمایش نیازی نیست ، این امر با استفاده از نتیجه `borrow_mut` اتفاق می افتد.
        // با غیرفعال کردن پیمایش و فقط ایجاد ارجاعات جدید به ریشه ها ، می دانیم که هر مرجع از نوع `Owned` به یک گره ریشه است.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// مقداری را در برشی از عناصر مقداردهی شده و به دنبال آن یک عنصر غیر اولیه وارد می کند.
///
/// # Safety
/// این قطعه بیش از عناصر `idx` دارد.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// مقداری از عناصر اولیه سازی شده را برداشته و برمی گرداند ، و یک عنصر غیر اولیه عقب مانده را پشت سر می گذارد.
///
///
/// # Safety
/// این قطعه بیش از عناصر `idx` دارد.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// عناصر را در موقعیتهای قطعه `distance` به سمت چپ تغییر می دهد.
///
/// # Safety
/// این برش حداقل دارای عناصر `distance` است.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// عناصر را در موقعیتهای برش `distance` به سمت راست تغییر می دهد.
///
/// # Safety
/// این برش حداقل دارای عناصر `distance` است.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// همه مقادیر را از یک قطعه از عناصر اولیه به یک قطعه از عناصر غیر اولیه منتقل می کند و `src` را به عنوان همه غیر اولیه پشت سر می گذارد.
///
/// مانند `dst.copy_from_slice(src)` کار می کند اما `T` به `Copy` نیازی ندارد.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;