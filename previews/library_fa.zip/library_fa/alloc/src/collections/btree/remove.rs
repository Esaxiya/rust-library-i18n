use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// یک جفت مقدار-کلید را از درخت حذف می کند ، و آن جفت را برگرداند ، و همچنین برگ edge مربوط به آن جفت سابق را برمی گرداند.
    /// ممکن است این یک گره ریشه داخلی خالی کند ، که تماس گیرنده باید آن را از روی نقشه درخت نگه دارد.
    /// تماس گیرنده همچنین باید طول نقشه را کاهش دهد.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // ما باید نوع کودک را به طور موقت فراموش کنیم ، زیرا هیچ نوع گره مشخصی برای والدین فوری یک برگ وجود ندارد.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // ایمنی: `new_pos` برگی است که از یک خواهر و برادر شروع کردیم.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // فقط در صورت ادغام ، والدین (در صورت وجود) کوچک شده اند ، اما در غیر این صورت پرش از مرحله زیر در معیارها نتیجه نمی دهد.
            //
            // ایمنی: ما برگ را در جایی که `pos` قرار دارد از بین نمی بریم یا مرتب نمی کنیم
            // با استفاده از والدین خود به صورت بازگشتیدر بدترین حالت ، والدین را از طریق مادربزرگ و مادربزرگ تخریب یا تنظیم مجدد می کنیم ، بنابراین پیوند را به والدین درون برگ تغییر می دهیم.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // یک KV مجاور را از برگ آن جدا کنید و سپس آن را دوباره به جای عنصری که از ما خواسته شده است بردارید.
        //
        // به دلایل ذکر شده در `choose_parent_kv` ، KV مجاور سمت چپ را ترجیح دهید.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // گره داخلی ممکن است به سرقت رفته یا ادغام شده باشد.
        // به سمت راست برگردید تا دریابید که KV به کجا ختم شده است.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}