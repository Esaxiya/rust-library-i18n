use core::intrinsics;
use core::mem;
use core::ptr;

/// این با فراخوانی تابع مربوطه ، مقدار پشت مرجع منحصر به فرد `v` را جایگزین می کند.
///
///
/// اگر یک panic در بسته شدن `change` رخ دهد ، کل روند سقط می شود.
#[allow(dead_code)] // به عنوان تصویر و برای استفاده از future نگه دارید
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// این با فراخوانی تابع مربوطه ، مقدار پشت مرجع منحصر به فرد `v` را جایگزین می کند و نتیجه ای را که در طول مسیر بدست آمده برمی گرداند.
///
///
/// اگر یک panic در بسته شدن `change` رخ دهد ، کل روند سقط می شود.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}