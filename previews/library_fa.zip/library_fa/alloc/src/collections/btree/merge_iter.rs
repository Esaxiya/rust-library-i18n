use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// هسته یک تکرار کننده که خروجی دو تکرار کننده صعودی کاملاً صعودی را ادغام می کند ، به عنوان مثال یک اتحادیه یا یک اختلاف متقارن.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// معیارها سریعتر از بسته بندی هر دو تکرار در Peekable هستند ، احتمالاً به این دلیل که توانایی تحمیل محدودیت FusedIterator را داریم.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// یک هسته جدید برای یک تکرار کننده ایجاد می کند که یک جفت منبع را ادغام می کند.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// جفت بعدی آیتم های ناشی از جفت منابع ادغام شده را برمی گرداند.
    /// اگر هر دو گزینه بازگشتی حاوی مقداری باشند ، آن مقدار برابر است و در هر دو منبع رخ می دهد.
    /// اگر یکی از گزینه های برگشتی یک مقدار داشته باشد ، آن مقدار در منبع دیگر رخ نمی دهد (یا منابع کاملا صعودی نیستند).
    ///
    /// اگر هیچ یک از گزینه های برگشتی مقداری نداشته باشد ، تکرار به پایان رسیده است و تماس های بعدی همان جفت خالی را برمی گردانند.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// یک جفت مرز بالای `size_hint` تکرار کننده نهایی را برمی گرداند.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}