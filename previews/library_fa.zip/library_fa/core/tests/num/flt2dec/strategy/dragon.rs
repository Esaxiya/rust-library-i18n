use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // میری خیلی کند است
fn exact_sanity_test() {
    // این آزمون در حالی اجرا می شود که من فقط می توانم فرض کنیم برخی موارد گوشه ای از عملکرد کتابخانه `exp2` است ، که در هر زمان اجرا C استفاده می شود.
    // در VS 2013 این عملکرد ظاهرا دارای اشکال بود زیرا این آزمون در هنگام اتصال ناموفق بود ، اما با VS 2015 اشکال برطرف می شود زیرا آزمون کاملا خوب انجام می شود.
    //
    // به نظر می رسد این اشکال تفاوت در مقدار بازگشت `exp2(-1057)` باشد ، جایی که در VS 2013 با الگوی بیت 0x2 دو برابر و در VS 2015 0x20000 باز می گرداند.
    //
    //
    // در حال حاضر فقط این تست را کاملاً روی MSVC نادیده بگیرید زیرا به هر حال در جاهای دیگر آزمایش شده است و ما علاقه زیادی به آزمایش اجرای exp2 هر پلتفرم نداریم.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}