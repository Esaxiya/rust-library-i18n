use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // این سطح پایدار نیست ، اما به ارزان بودن `?` در بین آنها کمک می کند ، حتی اگر LLVM فعلاً نتواند همیشه از آن استفاده کند.
    //
    // (متاسفانه نتیجه و گزینه متناقض است ، بنابراین ControlFlow نمی تواند با هر دو مطابقت داشته باشد.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}