#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! برنامه های کاربردی مربوط به اتصالات (FFI) رابط عملکرد خارجی.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// معادل نوع X's `void` است که به عنوان [pointer] استفاده می شود.
///
/// در اصل ، `*const c_void` معادل C's `const void*` و `*mut c_void` معادل C's `void*` است.
/// همانطور که گفته شد ، این * همان نوع بازگشتی C0000 X نیست ، که از نوع `()` Rust است.
///
/// برای مدل سازی اشاره گرها به انواع مات در FFI ، تا زمانی که `extern type` تثبیت شود ، توصیه می شود از یک بسته بندی newtype در اطراف یک آرایه بایت خالی استفاده کنید.
///
/// برای جزئیات بیشتر به [Nomicon] مراجعه کنید.
///
/// اگر بخواهند از کامپایلر Rust قدیمی تا 1.1.0 پشتیبانی کنند می توان از `std::os::raw::c_void` استفاده کرد.
/// پس از Rust 1.30.0 ، با این تعریف دوباره صادر شد.
/// برای اطلاعات بیشتر ، لطفا [RFC 2521] را مطالعه کنید.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// توجه داشته باشید ، برای اینکه LLVM نوع اشاره گر باطل را تشخیص دهد و با توابع پسوند مانند malloc() ، باید آن را به عنوان i8 * در بیت کد LLVM نشان دهیم.
// Enum استفاده شده در اینجا این را تضمین می کند و فقط با داشتن انواع خصوصی از سو mis استفاده از نوع "raw" جلوگیری می کند.
// ما به دو نوع نیاز داریم ، زیرا کامپایلر در غیر اینصورت از ویژگی repr شکایت دارد و ما حداقل به یک نوع نیاز داریم زیرا در غیر این صورت enum خالی از سکنه نخواهد بود و حداقل مراجعه به چنین اشاره گرهایی UB است.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// اجرای اساسی `va_list`.
// نام WIP است ، در حال حاضر از `VaListImpl` استفاده می شود.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // بیش از `'f` است ، بنابراین هر شی `VaListImpl<'f>` به منطقه عملکردی که در آن تعریف شده گره خورده است
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 اجرای ABI یک `va_list`.
/// برای جزئیات بیشتر به [AArch64 Procedure Call Standard] مراجعه کنید.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC اجرای ABI یک `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 اجرای ABI یک `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// یک لفافه برای `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` را به `VaList` تبدیل کنید که با C's `va_list` سازگار باشد.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// `VaListImpl` را به `VaList` تبدیل کنید که با C's `va_list` سازگار باشد.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait باید در رابط های عمومی استفاده شود ، با این حال ، trait خود اجازه استفاده در خارج از این ماژول را ندارد.
// اجازه دادن به کاربران برای پیاده سازی trait برای نوع جدید (در نتیجه امکان استفاده از va_arg ذاتی برای نوع جدید) احتمالاً باعث ایجاد رفتار تعریف نشده ای می شود.
//
// FIXME(dlrobertson): برای استفاده از VaArgSafe trait در یک رابط عمومی اما همچنین اطمینان از عدم استفاده از آن در جای دیگر ، trait باید در یک ماژول خصوصی عمومی باشد.
// پس از اجرای RFC 2145 ، این مورد را بهبود ببخشید.
//
//
//
//
mod sealed_trait {
    /// Trait که اجازه استفاده از انواع مجاز با [super::VaListImpl::arg] را می دهد.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// پیشرفت به استدلال بعدی
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `va_arg` را رعایت کند.
        unsafe { va_arg(self) }
    }

    /// `va_list` را در مکان فعلی کپی می کند.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `va_end` را رعایت کند.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // ایمنی: ما برای `MaybeUninit` نامه می نویسیم ، بنابراین اولیه می شود و `assume_init` قانونی است
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: این باید `va_end` باشد ، اما هیچ راه تمیز وجود ندارد
        // تضمین می کند که `drop` همیشه در تماس گیرنده خود قرار می گیرد ، بنابراین `va_end` مستقیماً از همان عملکرد `va_copy` مربوطه فراخوانی می شود.
        // `man va_end` بیان می کند که C به این نیاز دارد و LLVM اساساً از معناشناسی C پیروی می کند ، بنابراین باید اطمینان حاصل کنیم که `va_end` همیشه از همان عملکرد `va_copy` فراخوانی می شود.
        //
        // برای جزئیات بیشتر ، see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // این در حال حاضر کار می کند ، زیرا `va_end` در همه اهداف فعلی LLVM ممنوع است.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// پس از مقداردهی اولیه با `va_start` یا `va_copy` ، Arg arglist را از بین ببرید.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// مکان فعلی arglist `src` را در arglist `dst` کپی می کند.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// آرگومان از نوع `T` را از `va_list` `ap` بارگیری می کند و آرگومان `ap` را به سمت بالا افزایش می دهد.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}