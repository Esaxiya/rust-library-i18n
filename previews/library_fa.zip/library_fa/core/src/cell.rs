//! ظروف قابل اشتعال قابل اشتراک گذاری.
//!
//! Rust ایمنی حافظه بر اساس این قانون است: با توجه به یک شی `T` ، تنها داشتن یکی از موارد زیر امکان پذیر است:
//!
//! - داشتن چندین منبع تغییر ناپذیر (`&T`) به شی (که به آن **aliasing** نیز گفته می شود).
//! - داشتن یک ارجاع قابل تغییر (`&mut T`) به جسم (که به آن **جهش** نیز گفته می شود).
//!
//! این توسط کامپایلر Rust اعمال می شود.با این حال ، شرایطی وجود دارد که این قانون به اندازه کافی انعطاف پذیر نیست.گاهی اوقات لازم است که چندین اشاره به یک شی داشته باشید و در عین حال جهش ایجاد کنید.
//!
//! کانتینرهای قابل اشتعال قابل اشتراک برای وجود امکان تغییر پذیری به صورت کنترل شده ، حتی در صورت وجود نام مستعار وجود دارد.[`Cell<T>`] و [`RefCell<T>`] امکان انجام این کار را به صورت تک رشته ای دارند.
//! با این حال ، نه `Cell<T>` و نه `RefCell<T>` از نظر نخ ایمن نیستند (آنها [`Sync`] را اجرا نمی کنند).
//! در صورت نیاز به ایجاد نام مستعار و جهش بین چندین رشته ، استفاده از انواع [`Mutex<T>`] ، [`RwLock<T>`] یا [`atomic`] امکان پذیر است.
//!
//! مقادیر انواع `Cell<T>` و `RefCell<T>` ممکن است از طریق منابع مشترک (به عنوان مثال) تغییر شکل دهند
//! نوع معمول `&T`) ، در حالی که اکثر انواع Rust فقط از طریق منابع منحصر به فرد (`&mut T`) قابل جهش است.
//! ما می گوییم که `Cell<T>` و `RefCell<T>` برخلاف انواع معمولی Rust که "تغییر پذیری وراثتی" از خود نشان می دهند ، "تغییر پذیری داخلی" را ایجاد می کنند.
//!
//! انواع سلول ها در دو طعم وجود دارد: `Cell<T>` و `RefCell<T>`.`Cell<T>` با انتقال مقادیر داخل و خارج `Cell<T>` ، تغییر پذیری داخلی را پیاده سازی می کند.
//! برای استفاده از منابع به جای مقادیر ، باید از نوع `RefCell<T>` استفاده کنید ، قبل از جهش قفل نوشتن بدست آورید.`Cell<T>` روش هایی را برای بازیابی و تغییر مقدار داخلی موجود ارائه می دهد:
//!
//!  - برای انواع که [`Copy`] را پیاده سازی می کنند ، روش [`get`](Cell::get) مقدار داخلی فعلی را بازیابی می کند.
//!  - برای نوع هایی که [`Default`] را پیاده سازی می کنند ، روش [`take`](Cell::take) مقدار داخلی فعلی را با [`Default::default()`] جایگزین می کند و مقدار جایگزین شده را برمی گرداند.
//!  - برای همه انواع ، روش [`replace`](Cell::replace) جایگزین مقدار داخلی فعلی شده و مقدار جایگزین شده را برمی گرداند و روش [`into_inner`](Cell::into_inner) `Cell<T>` را مصرف می کند و مقدار داخلی را برمی گرداند.
//!  علاوه بر این ، روش [`set`](Cell::set) جایگزین مقدار داخلی می شود و مقدار جایگزین شده را کاهش می دهد.
//!
//! `RefCell<T>` از عمر Rust برای اجرای "استقراض پویا" استفاده می کند ، فرایندی که به موجب آن فرد می تواند دسترسی موقت ، انحصاری و قابل تغییر به ارزش داخلی را ادعا کند.
//! Borrows برای `RefCell<T>برخلاف انواع مرجع بومی Rust که بطور کامل بصورت استاتیک ردیابی می شوند ، در زمان کامپایل ،"در هنگام اجرا" ردیابی می شوند.
//! از آنجا که وامهای `RefCell<T>` پویا هستند ، بنابراین می توان مقداری را که قبلاً به طور متقابل وام گرفته شده ، وام گرفت.هنگامی که این اتفاق می افتد منجر به موضوع panic می شود.
//!
//! # چه زمان تغییر پذیری داخلی را انتخاب کنید
//!
//! تغییر پذیری ارثی رایج تر ، جایی که فرد باید دسترسی منحصر به فردی برای تغییر مقدار داشته باشد ، یکی از عناصر اصلی زبان است که Rust را قادر می سازد تا به شدت درباره مستعار سازی اشاره گر استدلال کند و از بروز اشکالات خرابی به طور ایستا جلوگیری کند.
//! به همین دلیل ، تغییر پذیری ارثی ترجیح داده می شود و تغییر پذیری داخلی چیزی برای آخرین چاره است.
//! از آنجا که انواع سلولها جهشی را امکان پذیر می سازد که در غیر این صورت مجاز به تغییر نخواهد بود ، مواردی وجود دارد که ممکن است تغییر پذیری داخلی مناسب باشد ، یا حتی *باید* استفاده شود ،
//!
//! * معرفی تغییر پذیری 'inside' از چیزی تغییرناپذیر
//! * جزئیات پیاده سازی روشهای منطقی و غیرقابل تغییر.
//! * با تغییر کارایی [`Clone`].
//!
//! ## معرفی تغییر پذیری 'inside' از چیزی تغییرناپذیر
//!
//! بسیاری از انواع اشاره گرهای هوشمند مشترک ، از جمله [`Rc<T>`] و [`Arc<T>`] ، محفظه هایی را ارائه می دهند که می توانند شبیه سازی شده و بین چندین طرف به اشتراک گذاشته شوند.
//! از آنجا که مقادیر موجود ممکن است با نام مستعار ضرب شوند ، فقط با `&` می توان وام گرفت نه `&mut`.
//! بدون سلول به هیچ وجه امکان تغییر داده در داخل این اشاره گرهای هوشمند وجود ندارد.
//!
//! قرار دادن `RefCell<T>` در داخل انواع نشانگرهای مشترک برای ایجاد مجدد تغییر پذیری بسیار معمول است:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // برای محدود کردن دامنه وام پویا ، یک بلوک جدید ایجاد کنید
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // توجه داشته باشید که اگر اجازه نمی دادیم وام قبلی حافظه پنهان از محدوده خارج شود ، وام بعدی باعث ایجاد یک موضوع پویا panic می شود.
//!     //
//!     // این مهمترین خطر استفاده از `RefCell` است.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! توجه داشته باشید که این مثال از `Rc<T>` استفاده می کند و از `Arc<T>` استفاده نمی کند.`RefCell<T>`s برای سناریوهای تک رشته ای هستند.استفاده از [`RwLock<T>`] یا [`Mutex<T>`] را در صورت نیاز به قابلیت تغییر پذیری مشترک در شرایط چند رشته ای در نظر بگیرید.
//!
//! ## جزئیات پیاده سازی روشهای منطقی و غیرقابل تغییر
//!
//! گاهی اوقات ممکن است مطلوب باشد که در API جهش "under the hood" اتفاق نیفتد.
//! این ممکن است به این دلیل باشد که از نظر منطقی این عملیات تغییرناپذیر است ، اما به عنوان مثال ، caching اجرای را مجبور به انجام جهش می کند.یا به این دلیل که برای اجرای یک روش trait که در ابتدا برای گرفتن `&self` تعریف شده است ، باید از جهش استفاده کنید.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // محاسبه گران قیمت اینجا است
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## با تغییر کارایی `Clone`
//!
//! این به سادگی یک مورد خاص ، اما معمول مورد قبلی است: پنهان کردن تغییر پذیری برای عملیاتی که به نظر می رسد غیر قابل تغییر هستند.
//! انتظار می رود که روش [`clone`](Clone::clone) مقدار منبع را تغییر ندهد و اعلام می شود `&self` است نه `&mut self`.
//! بنابراین ، هر جهشی که در روش `clone` اتفاق می افتد باید از انواع سلول استفاده کند.
//! به عنوان مثال ، [`Rc<T>`] تعداد مرجع خود را در `Cell<T>` حفظ می کند.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// یک مکان حافظه قابل تغییر
///
/// # Examples
///
/// در این مثال می بینید که `Cell<T>` جهش درون ساختار غیرقابل تغییر را امکان پذیر می کند.
/// به عبارت دیگر ، "interior mutability" را امکان پذیر می کند.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // خطا: `my_struct` تغییرناپذیر است
/// // my_struct.regular_field =new_value؛
///
/// // کار می کند: اگرچه `my_struct` تغییرناپذیر است ، `special_field` یک `Cell` است ،
/// // که همیشه قابل جهش است
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// برای اطلاعات بیشتر به [module-level documentation](self) مراجعه کنید.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// `Cell<T>` با مقدار `Default` برای T ایجاد می کند.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// `Cell` جدیدی حاوی مقدار داده شده ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// مقدار موجود را تنظیم می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// مقادیر دو سلول را مبادله می کند.
    /// تفاوت با `std::mem::swap` این است که این عملکرد نیازی به مرجع `&mut` ندارد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // ایمنی: اگر از موضوعات جداگانه فراخوانی شود ، این می تواند خطرناک باشد ، اما `Cell`
        // `!Sync` است بنابراین این اتفاق نمی افتد
        // این همچنین هیچ اشاره گر را بی اعتبار نمی کند ، زیرا `Cell` مطمئن می شود که هیچ چیز دیگری به هر یک از این "سلول ها" اشاره نخواهد کرد.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// مقدار موجود را با `val` جایگزین می کند و مقدار موجود قدیمی را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // ایمنی: اگر از یک موضوع جداگانه فراخوانی شود ، این می تواند باعث ایجاد داده های مسابقه شود ،
        // اما `Cell` `!Sync` است بنابراین این اتفاق نمی افتد.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// مقدار را باز می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// نسخه ای از مقدار موجود را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // ایمنی: اگر از یک موضوع جداگانه فراخوانی شود ، این می تواند باعث ایجاد داده های مسابقه شود ،
        // اما `Cell` `!Sync` است بنابراین این اتفاق نمی افتد.
        unsafe { *self.value.get() }
    }

    /// مقدار موجود را با استفاده از یک تابع به روز می کند و مقدار جدید را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// یک اشاره گر خام را به داده های اساسی در این سلول برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ارجاع قابل تغییر به داده های اساسی را برمی گرداند.
    ///
    /// این تماس `Cell` را به طور متغیر وام می گیرد (در زمان کامپایل) که تضمین می کند تنها مرجع را در اختیار داریم.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// `&Cell<T>` را از `&mut T` برمی گرداند
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // ایمنی: `&mut` دسترسی منحصر به فرد را تضمین می کند.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// مقدار سلول را می گیرد و `Default::default()` را در جای خود می گذارد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// `&[Cell<T>]` را از `&Cell<[T]>` برمی گرداند
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // ایمنی: `Cell<T>` طرح حافظه مشابه `T` دارد.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// یک مکان حافظه قابل تغییر با قوانین وام بررسی شده به صورت پویا
///
/// برای اطلاعات بیشتر به [module-level documentation](self) مراجعه کنید.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// خطایی که توسط [`RefCell::try_borrow`] برگردانده شده است.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// خطایی که توسط [`RefCell::try_borrow_mut`] برگردانده شده است.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// مقادیر مثبت نشان دهنده تعداد `Ref` فعال است.مقادیر منفی نشان دهنده تعداد `RefMut` فعال است.
// RefMut `s متعدد تنها در یک زمان فعال است اگر آنها به اجزای متمایز و غیر همپوشانی `RefCell` (مثلا دامنه های مختلف برش) اشاره داشته باشند.
//
// `Ref` و `RefMut` هر دو اندازه دو کلمه هستند و بنابراین به احتمال زیاد هرگز Ref `Ref` یا`RefMut` کافی برای سرریز کردن نیمی از دامنه `usize` وجود نخواهد داشت.
// بنابراین ، `BorrowFlag` احتمالاً هرگز سرریز یا پر نمی شود.
// با این حال ، این تضمینی نیست ، زیرا یک برنامه آسیب شناسی می تواند mem::forget `Ref` s یا `RefMut` را بارها ایجاد کند.
// بنابراین ، برای جلوگیری از عدم ایمنی ، یا حداقل رفتار صحیح در صورت بروز سرریز یا کم شدن جریان ، باید همه کدها صریحاً از نظر سرریز و کمبود جریان کنترل شود (به عنوان مثال ، نگاه کنید به BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `RefCell` جدیدی حاوی `value` ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// `RefCell` را مصرف می کند ، مقدار بسته بندی شده را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // از آنجا که این تابع مقدار `self` (`RefCell`) را می گیرد ، کامپایلر بصورت ایستایی تأیید می کند که در حال حاضر وام نگرفته است.
        //
        self.value.into_inner()
    }

    /// مقدار بسته بندی شده را با یک مقدار جدید جایگزین می کند ، مقدار قدیمی را برمی گرداند ، بدون اینکه از بین بردن مقدار اولیه یکی از آنها را انجام دهید.
    ///
    ///
    /// این عملکرد مربوط به [`std::mem::replace`](../mem/fn.replace.html) است.
    ///
    /// # Panics
    ///
    /// Panics اگر مقدار فعلاً قرض گرفته شده باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// مقدار بسته بندی شده را با مقدار جدیدی که از `f` محاسبه شده است جایگزین می کند و مقدار قدیمی را برمی گرداند ، بدون اینکه یک مورد را از حالت اولیه خارج کنید.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر مقدار فعلاً قرض گرفته شده باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// مقدار بسته بندی شده `self` را با مقدار بسته بندی شده `other` عوض می کند ، بدون اینکه یک مورد را از حالت اولیه خارج کنید.
    ///
    ///
    /// این عملکرد مربوط به [`std::mem::swap`](../mem/fn.swap.html) است.
    ///
    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// مقدار بسته بندی شده را به طور غیرقابل تغییر وام می گیرد.
    ///
    /// وام تا زمان خروج `Ref` از محدوده ادامه دارد.
    /// چندین وام تغییرناپذیر می تواند به طور همزمان گرفته شود.
    ///
    /// # Panics
    ///
    /// Panics اگر این مقدار در حال حاضر به طور متقابل قرض گرفته شده باشد.
    /// برای نوع غیر وحشت زده ، از [`try_borrow`](#method.try_borrow) استفاده کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// نمونه ای از panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// مقدار بسته بندی شده را به طور غیرقابل تغییر وام می گیرد ، اگر در حال حاضر مقدار به طور متقابل قرض گرفته شده است ، خطایی را برمی گرداند.
    ///
    ///
    /// وام تا زمان خروج `Ref` از محدوده ادامه دارد.
    /// چندین وام تغییرناپذیر می تواند به طور همزمان گرفته شود.
    ///
    /// این نوع بدون وحشت از [`borrow`](#method.borrow) است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // ایمنی: `BorrowRef` اطمینان می دهد که فقط دسترسی تغییرناپذیر وجود دارد
            // به ارزش هنگام وام گرفتن.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// مقدار بسته بندی شده را به طور متغیر وام می گیرد.
    ///
    /// این وام تا زمان خروج `RefMut` یا کل `RefMut` حاصل از آن خارج می شود.
    ///
    /// وقتی این وام فعال است نمی توان مقدار آن را وام گرفت.
    ///
    /// # Panics
    ///
    /// Panics اگر مقدار فعلاً قرض گرفته شده باشد.
    /// برای نوع غیر وحشت زده ، از [`try_borrow_mut`](#method.try_borrow_mut) استفاده کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// نمونه ای از panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// مقدار بسته بندی شده را به طور متغیر وام می گیرد و اگر مقدار فعلاً قرض گرفته شده باشد ، خطایی را برمی گرداند.
    ///
    ///
    /// این وام تا زمان خروج `RefMut` یا کل `RefMut` حاصل از آن خارج می شود.
    /// وقتی این وام فعال است نمی توان مقدار آن را وام گرفت.
    ///
    /// این نوع بدون وحشت [`borrow_mut`](#method.borrow_mut) است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // ایمنی: `BorrowRef` دسترسی منحصر به فرد را تضمین می کند.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// یک اشاره گر خام را به داده های اساسی در این سلول برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ارجاع قابل تغییر به داده های اساسی را برمی گرداند.
    ///
    /// این تماس `RefCell` را به صورت متقابل وام می گیرد (در زمان کامپایل) بنابراین نیازی به چک پویا نیست.
    ///
    /// با این حال محتاط باشید: این روش انتظار دارد `self` قابل تغییر باشد ، که معمولاً در هنگام استفاده از `RefCell` چنین نیست.
    ///
    /// اگر `self` قابل تغییر نیست ، به جای آن نگاهی به روش [`borrow_mut`] بیندازید.
    ///
    /// همچنین ، لطفاً توجه داشته باشید که این روش فقط برای شرایط خاص است و معمولاً همان چیزی نیست که شما می خواهید.
    /// در صورت شک ، به جای آن از [`borrow_mut`] استفاده کنید.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// تأثیر محافظ های درز کرده در حالت وام `RefCell` را خنثی کنید.
    ///
    /// این تماس مشابه [`get_mut`] است اما تخصصی تر است.
    /// `RefCell` را به طور متقابل وام می گیرد تا اطمینان حاصل شود که هیچ وام وجود ندارد و سپس وضعیت پیگیری وام های مشترک را بازنشانی می کند.
    /// اگر برخی از وامهای `Ref` یا `RefMut` به بیرون درز کرده باشد ، این امر مهم است.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// مقدار بسته بندی شده را به طور غیرقابل تغییر وام می گیرد ، اگر در حال حاضر مقدار به طور متقابل قرض گرفته شده است ، خطایی را برمی گرداند.
    ///
    /// # Safety
    ///
    /// برخلاف `RefCell::borrow` ، این روش ایمن نیست زیرا `Ref` را بر نمی گرداند ، بنابراین پرچم وام را دست نخورده باقی می گذارد.
    /// وام گرفتن متقابل `RefCell` در حالی که مرجعی که با این روش برگردانده شده است یک رفتار تعریف نشده است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // ایمنی: بررسی می کنیم که اکنون هیچ کس به طور فعال در حال نوشتن نیست ، اما در حال حاضر است
            // مسئولیت تماس گیرنده این است که اطمینان حاصل کند که هیچ کس تا زمانی که مرجع برگشتی دیگر استفاده نشود ، نمی نویسد.
            // همچنین ، `self.value.get()` به مقداری که متعلق به `self` است اشاره می کند و بنابراین برای عمر `self` معتبر است.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// مقدار بسته بندی شده را می گیرد و `Default::default()` را در جای خود می گذارد.
    ///
    /// # Panics
    ///
    /// Panics اگر مقدار فعلاً قرض گرفته شده باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر این مقدار در حال حاضر به طور متقابل قرض گرفته شده باشد.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// `RefCell<T>` با مقدار `Default` برای T ایجاد می کند.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics اگر مقدار `RefCell` در حال حاضر قرض گرفته شده باشد.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // افزایش وام می تواند منجر به عدم خواندن مقدار شود (<=0) در این موارد:
            // 1. این <0 بود ، یعنی وام های نوشتاری وجود دارد ، بنابراین ما نمی توانیم به دلیل قوانین نام مستعار مرجع Rust ، اجازه خواندن وام را بدهیم
            // 2.
            // isize::MAX (حداکثر میزان خواندن وام) بود و به isize::MIN سرریز کرد (حداکثر میزان وام نوشتن) بنابراین ما نمی توانیم وام خوانده اضافی را مجاز بدانیم زیرا isize نمی تواند نشان دهنده بسیاری از وام های خوانده شده باشد (این فقط در صورتی اتفاق می افتد که شما mem::forget بیش از مقدار ثابت کمی از Ref ، که عمل خوبی نیست)
            //
            //
            //
            //
            None
        } else {
            // افزایش وام می تواند منجر به مقدار خواندن (> 0) در این موارد شود:
            // 1. این=0 بود ، یعنی وام نگرفت ، و ما اولین وام خوانده شده را می گیریم
            // 2. > 0 و <isize::MAX بود ، یعنی
            // وام های خوانده شده وجود دارد ، و isize به اندازه کافی بزرگ است که نشان دهنده داشتن یک وام خوانده شده بیشتر است
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // از آنجا که این Ref وجود دارد ، ما می دانیم که پرچم وام قرض خواندن است.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // از سرریز شدن پیشخوان وام به وام نوشتاری جلوگیری کنید.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// ارجاع قرض گرفته شده به مقداری را در یک جعبه `RefCell` قرار می دهد.
/// یک نوع بسته بندی برای مقداری که از `RefCell<T>` وام گرفته شده است.
///
/// برای اطلاعات بیشتر به [module-level documentation](self) مراجعه کنید.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// `Ref` را کپی می کند.
    ///
    /// `RefCell` قبلاً به طور غیرقابل تغییر قرض گرفته شده است ، بنابراین نمی تواند شکست بخورد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `Ref::clone(...)` استفاده شود.
    /// اجرای `Clone` یا روشی در استفاده گسترده از `r.borrow().clone()` برای شبیه سازی محتویات `RefCell` تداخل می کند.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// برای جزئی از داده های قرض گرفته شده `Ref` جدید ایجاد می کند.
    ///
    /// `RefCell` قبلاً به طور غیرقابل تغییر قرض گرفته شده است ، بنابراین نمی تواند شکست بخورد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `Ref::map(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// برای م00لفه اختیاری داده های قرض شده `Ref` جدید ایجاد می کند.
    /// اگر بسته شدن `None` بازگردد ، محافظ اصلی به عنوان `Err(..)` بازگردانده می شود.
    ///
    /// `RefCell` قبلاً به طور غیرقابل تغییر قرض گرفته شده است ، بنابراین نمی تواند شکست بخورد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `Ref::filter_map(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// برای اجزای مختلف داده های وام گرفته شده `Ref` را به چندین Ref تقسیم می کند.
    ///
    /// `RefCell` قبلاً به طور غیرقابل تغییر قرض گرفته شده است ، بنابراین نمی تواند شکست بخورد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `Ref::map_split(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// تبدیل به مرجع به داده های اساسی.
    ///
    /// `RefCell` زمینه ای هرگز نمی تواند به صورت متقابل وام گرفته شود و همیشه در عوض وام گرفته شده غیر قابل تغییر به نظر می رسد.
    ///
    /// ایده خوبی نیست که بیش از تعداد ثابت منابع فاش شود.
    /// اگر در کل تعداد نشتی کمتری وجود داشته باشد ، می توان `RefCell` را به طور غیرقابل تغییر قرض داد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `Ref::leak(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // با فراموش کردن این Ref ، اطمینان حاصل می کنیم که شمارنده وام در RefCell نمی تواند در طول عمر `'b` به UNUSED برگردد.
        // برای بازنشانی حالت ردیابی مرجع ، به یک مراجعه منحصر به فرد به RefCell وام گرفته شده احتیاج دارید.
        // هیچ مرجع قابل تغییر دیگری از سلول اصلی ایجاد نمی شود.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// `RefMut` جدید را برای جزئی از داده های قرض گرفته شده ، به عنوان مثال ، یک نوع enum ایجاد می کند.
    ///
    /// `RefCell` قبلاً بصورت متقابل قرض گرفته شده است ، بنابراین نمی تواند شکست بخورد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `RefMut::map(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): رفع وام چک
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// برای م00لفه اختیاری داده های قرض شده `RefMut` جدید ایجاد می کند.
    /// اگر بسته شدن `None` بازگردد ، محافظ اصلی به عنوان `Err(..)` بازگردانده می شود.
    ///
    /// `RefCell` قبلاً بصورت متقابل قرض گرفته شده است ، بنابراین نمی تواند شکست بخورد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `RefMut::filter_map(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): رفع وام چک
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SAFETY: تابع برای مدت زمان طولانی به عنوان یک مرجع منحصر به فرد عمل می کند
        // از تماس خود از طریق `orig` استفاده می شود ، و اشاره گر فقط در داخل تماس تابع ارجاع داده می شود و هرگز اجازه نمی دهد تا مرجع منحصر به فرد فرار کند.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // ایمنی: همانند بالا.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// `RefMut` را برای مولفه های مختلف داده های وام گرفته شده به چندین RefMut تقسیم می کند.
    ///
    /// `RefCell` زمینه ای تا زمانی که هر دو RefMut برگردانده شده از محدوده خارج نشود ، به طور متقابل قرض می گیرد.
    ///
    /// `RefCell` قبلاً بصورت متقابل قرض گرفته شده است ، بنابراین نمی تواند شکست بخورد.
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `RefMut::map_split(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// تبدیل به یک منبع قابل تغییر به داده های اساسی.
    ///
    /// `RefCell` زمینه را نمی توان دوباره از آن قرض گرفت و همیشه در عوض وام گرفته شده ظاهر می شود ، و مرجع بازگشتی را تنها به داخل نشان می دهد.
    ///
    ///
    /// این یک عملکرد مرتبط است که باید به عنوان `RefMut::leak(...)` استفاده شود.
    /// روشی با روش هایی با همین نام در محتویات `RefCell` استفاده شده از طریق `Deref` تداخل می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // با فراموش کردن این BorrowRefMut اطمینان حاصل می کنیم که شمارنده وام در RefCell نمی تواند در طول عمر `'b` به UNUSED برگردد.
        // برای بازنشانی حالت ردیابی مرجع ، به یک مراجعه منحصر به فرد به RefCell وام گرفته شده احتیاج دارید.
        // در طول آن هیچ مرجعی دیگر نمی تواند از سلول اصلی ایجاد شود ، و این باعث می شود که وام فعلی تنها مرجع برای تمام عمر باقی مانده باشد.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: برخلاف BorrowRefMut::clone ، جدید برای ایجاد مقدماتی فراخوانی می شود
        // مرجع قابل تغییر ، و بنابراین در حال حاضر نباید هیچ مرجعی وجود داشته باشد.
        // بنابراین ، در حالی که کلون بارگیری قابل تغییر را افزایش می دهد ، در اینجا ما صریحاً اجازه می دهیم از UNUSED به UNUSED برویم ، 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // `BorrowRefMut` را کلون می کند.
    //
    // این فقط درصورتی معتبر است که از هر `BorrowRefMut` برای ردیابی یک اشاره قابل تغییر به یک محدوده مشخص و غیر همپوشانی از شی of اصلی استفاده شود.
    //
    // این در یک impl Clone نیست ، بنابراین کد به صورت ضمنی این را نمی خواند.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // از کمبود پیشخوان وام جلوگیری کنید.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// یک نوع بسته بندی برای یک مقدار وام گرفته شده از `RefCell<T>`.
///
/// برای اطلاعات بیشتر به [module-level documentation](self) مراجعه کنید.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// هسته اولیه برای تغییر پذیری داخلی در Rust.
///
/// اگر یک مرجع `&T` دارید ، معمولاً در Rust کامپایلر بر اساس دانش `&T` به داده های تغییرناپذیر ، بهینه سازی را انجام می دهد.تغییر در آن داده ها ، به عنوان مثال از طریق نام مستعار یا تبدیل `&T` به `&mut T` ، یک رفتار تعریف نشده محسوب می شود.
/// `UnsafeCell<T>` حذف تضمین تغییرناپذیری برای `&T`: یک مرجع مشترک `&UnsafeCell<T>` ممکن است به داده هایی اشاره کند که در حال جهش هستند.به این "interior mutability" گفته می شود.
///
/// همه انواع دیگر که امکان تغییر پذیری داخلی را دارند ، مانند `Cell<T>` و `RefCell<T>` ، برای بسته بندی داده های خود از `UnsafeCell` استفاده می کنند.
///
/// توجه داشته باشید که فقط ضمانت تغییرناپذیری منابع مشترک توسط `UnsafeCell` تحت تأثیر قرار می گیرد.ضمانت منحصر به فرد برای منابع متغیر بی تأثیر است.هیچ راهی قانونی برای به دست آوردن نام مستعار `&mut` وجود ندارد ، حتی با `UnsafeCell<T>`.
///
/// `UnsafeCell` API از نظر فنی بسیار ساده است: [`.get()`] به شما یک نشانگر خام `*mut T` را برای محتوای آن می دهد._you_ به عنوان طراح انتزاع استفاده صحیح از آن اشاره گر خام است.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// قوانین دقیق نام مستعار Rust تا حدودی در جریان است ، اما نکات اصلی بحث برانگیز نیستند:
///
/// - اگر یک مرجع ایمن با طول عمر `'a` ایجاد کنید (یا یک مرجع `&T` یا `&mut T`) که با کد امن قابل دسترسی باشد (به عنوان مثال ، زیرا آن را برگردانده اید) ، بنابراین شما نباید به هیچ وجه به داده ها دسترسی پیدا کنید که با این مرجع باقی مانده در تضاد باشد از `'a`.
/// به عنوان مثال ، این بدان معناست که اگر `*mut T` را از `UnsafeCell<T>` بگیرید و آن را به `&T` بیندازید ، داده های موجود در `T` باید تغییر ناپذیر باقی بمانند (البته هرگونه داده `UnsafeCell` موجود در `T` مدول داشته باشد) تا پایان عمر آن مرجع.
/// به همین ترتیب ، اگر یک مرجع `&mut T` ایجاد کنید که به کد امن منتقل شود ، پس از انقضاires مرجع ، نباید به داده های `UnsafeCell` دسترسی داشته باشید.
///
/// - در همه حال ، باید از مسابقه داده خودداری کنید.اگر چندین رشته به `UnsafeCell` یکسان دسترسی داشته باشد ، در هر نوشتاری باید رابطه مناسب قبل از دسترسی به سایر دسترسی ها وجود داشته باشد (یا از اتم استفاده کنید).
///
/// برای کمک به طراحی مناسب ، سناریوهای زیر برای کد تک رشته ای به صراحت قانونی شناخته می شوند:
///
/// 1. یک مرجع `&T` می تواند به کد امن منتشر شود و در آنجا می تواند با سایر منابع `&T` وجود داشته باشد ، اما با `&mut T` نه
///
/// 2. یک مرجع `&mut T` ممکن است به کد امن منتشر شود در صورتی که `&mut T` و `&T` دیگری با آن وجود نداشته باشند.`&mut T` باید همیشه منحصر به فرد باشد.
///
/// توجه داشته باشید که در حالی که جهش محتوای `&UnsafeCell<T>` (حتی در حالی که سایر منابع `&UnsafeCell<T>` به نام مستعار سلول) درست است (به شرط اینکه موارد غیرمستقیم فوق را به روشی دیگر اجرا کنید) ، داشتن چندین نام مستعار `&mut UnsafeCell<T>` هنوز یک رفتار تعریف نشده است.
/// یعنی ، `UnsafeCell` یک لفافه است که برای تعامل ویژه با _shared_ accesses (_i.e._ ، از طریق یک مرجع `&UnsafeCell<_>` طراحی شده است).هیچ جادویی در هنگام برخورد با _exclusive_ accesses (_e.g._ ، از طریق `&mut UnsafeCell<_>` وجود ندارد): نه سلول و نه مقدار بسته بندی شده برای مدت زمان وام `&mut` نمی توانند مستعار باشند.
///
/// این توسط لوازم جانبی [`.get_mut()`] ، که یک _safe_ getter است و `&mut T` تولید می کند ، به نمایش گذاشته شده است.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// در اینجا مثالی آورده شده است که نشان می دهد چگونه جهش صحیح محتوای `UnsafeCell<_>` با وجود وجود چندین منبع غیرمجاز برای سلول:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // چندین منبع/همزمان/مشترک را به `x` یکسان دریافت کنید.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // ایمنی: در این محدوده هیچ اشاره دیگری به محتوای "x" وجود ندارد ،
///     // بنابراین مال ما منحصر به فرد است.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- قرض بگیرید-+
///     *p1_exclusive += 27; // |
/// } // <---------- نمی تواند فراتر از این نقطه باشد -------------------+
///
/// unsafe {
///     // ایمنی: در این محدوده هیچ کس انتظار ندارد که به محتوای "x" دسترسی منحصر به فرد داشته باشد ،
///     // بنابراین می توانیم همزمان چندین دسترسی مشترک داشته باشیم.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// مثال زیر این واقعیت را نشان می دهد که دسترسی انحصاری به `UnsafeCell<T>` به معنای دسترسی انحصاری به `T` آن است:
///
/// ```rust
/// #![forbid(unsafe_code)] // با دسترسی های انحصاری ،
///                         // `UnsafeCell` یک بسته بندی شفاف و ممنوع است ، بنابراین در اینجا نیازی به `unsafe` نیست.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // یک مرجع منحصر به فرد بررسی شده توسط زمان کامپایل به `x` دریافت کنید.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // با یک مرجع اختصاصی ، می توانیم مطالب را به صورت رایگان جهش دهیم.
/// *p_unique.get_mut() = 0;
/// // یا معادل آن:
/// x = UnsafeCell::new(0);
///
/// // وقتی مالک این مقدار شدیم ، می توانیم مطالب را به صورت رایگان استخراج کنیم.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// نمونه جدیدی از `UnsafeCell` را می سازد که مقدار مشخص شده را بسته بندی می کند.
    ///
    ///
    /// تمام دسترسی به مقدار داخلی از طریق روش ها `unsafe` است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// مقدار را باز می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// یک نشانگر قابل تغییر به مقدار بسته بندی شده می دهد.
    ///
    /// این را می توان از هر نوع به یک اشاره گر فرستاد.
    /// اطمینان حاصل کنید که دسترسی در هنگام ارسال به `&mut T` منحصر به فرد است (بدون منابع فعال ، قابل تغییر یا غیر قابل تغییر) ، و اطمینان حاصل کنید که هنگام ریخته شدن به `&T` هیچ گونه جهش یا نام مستعار قابل تغییر وجود ندارد
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // ما فقط می توانیم به دلیل #[repr(transparent)] نشانگر را از `UnsafeCell<T>` به `T` قرار دهیم.
        // این از وضعیت ویژه libstd سوits استفاده می کند ، هیچ تضمینی برای کد کاربر وجود ندارد که این نسخه در نسخه های future کامپایلر کار کند!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// ارجاع قابل تغییر به داده های اساسی را برمی گرداند.
    ///
    /// این تماس `UnsafeCell` را به طور متغیر وام می گیرد (در زمان کامپایل) که تضمین می کند تنها مرجع را در اختیار داریم.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// یک نشانگر قابل تغییر به مقدار بسته بندی شده می دهد.
    /// تفاوت [`get`] در این است که این تابع یک نشانگر خام را می پذیرد ، که برای جلوگیری از ایجاد منابع موقتی مفید است.
    ///
    /// نتیجه را می توان از هر نوعی به یک اشاره گر ارسال کرد.
    /// اطمینان حاصل کنید که دسترسی در هنگام ارسال به `&mut T` منحصر به فرد است (بدون مراجعه فعال ، قابل تغییر است یا غیر) ، و اطمینان حاصل کنید که هنگام ریخته شدن به `&T` هیچ گونه جهش یا نام مستعار قابل تغییر وجود ندارد.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// مقداردهی اولیه تدریجی `UnsafeCell` به `raw_get` نیاز دارد ، زیرا فراخوانی `get` مستلزم ایجاد ارجاع به داده های غیر اولیه است:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // ما فقط می توانیم به دلیل #[repr(transparent)] نشانگر را از `UnsafeCell<T>` به `T` قرار دهیم.
        // این از وضعیت ویژه libstd سوits استفاده می کند ، هیچ تضمینی برای کد کاربر وجود ندارد که این نسخه در نسخه های future کامپایلر کار کند!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// `UnsafeCell` با مقدار `Default` برای T ایجاد می کند.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}