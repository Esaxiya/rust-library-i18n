#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// نوع متادیتای نشانگر را از هر نوع اشاره دار به شما ارائه می دهد.
///
/// # فراداده نشانگر
///
/// انواع اشاره گر خام و انواع مرجع در Rust را می توان به صورت دو قسمت در نظر گرفت:
/// یک اشاره گر داده که حاوی آدرس حافظه مقدار و برخی از فراداده ها است.
///
/// برای انواع با اندازه ثابت (که `Sized` traits را اجرا می کنند) و همچنین برای انواع `extern` ، نشانگرها "نازک" هستند: فراداده ها اندازه صفر دارند و نوع آنها `()` است.
///
///
/// اشاره گرهای [dynamically-sized types][dst] گفته می شود "گسترده" یا "چاق" هستند ، آنها دارای فراداده ای با اندازه غیر صفر هستند:
///
/// * برای ستادهایی که آخرین فیلد آنها DST است ، فراداده ها فراداده های مربوط به قسمت آخر هستند
/// * برای نوع `str` ، فراداده طول در بایت `usize` است
/// * برای انواع برش هایی مانند `[T]` ، ابرداده در موارد به عنوان `usize` طول است
/// * برای اشیا Z trait مانند `dyn SomeTrait` ، فراداده [`DynMetadata<Self>`][DynMetadata] است (به عنوان مثال `DynMetadata<dyn SomeTrait>`)
///
/// در future ، زبان Rust ممکن است انواع جدیدی را پیدا کند که دارای فراداده نشانگر متفاوت هستند.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// نکته این trait نوع `Metadata` مربوط به آن است که همانطور که در بالا توضیح داده شد `()` یا `usize` یا `DynMetadata<_>` است.
/// به طور خودکار برای هر نوع اجرا می شود.
/// می توان فرض کرد که این کار در یک زمینه عمومی انجام می شود ، حتی بدون محدودیت مربوطه.
///
/// # Usage
///
/// اشاره گرهای خام با استفاده از روش [`to_raw_parts`] می توانند به آدرس داده و م componentsلفه های فراداده تجزیه شوند.
///
/// متناوباً ، داده فراداده به تنهایی با عملکرد [`metadata`] قابل استخراج است.
/// یک مرجع می تواند به [`metadata`] منتقل شود و به طور ضمنی مجبور شود.
///
/// یک نشانگر (possibly-wide) را می توان از آدرس و فراداده خود با [`from_raw_parts`] یا [`from_raw_parts_mut`] دوباره جمع کرد.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// نوع مربوط به فراداده در اشاره گرها و ارجاعات به `Self`.
    #[lang = "metadata_type"]
    // NOTE: trait bounds را در `static_assert_expected_bounds_for_metadata` نگه دارید
    //
    // در `library/core/src/ptr/metadata.rs` همگام با کسانی که در اینجا هستند:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// اشاره گرها برای انواع پیاده سازی کننده نام مستعار trait "نازک" هستند.
///
/// این شامل انواع با اندازه ثابت و انواع `extern` است.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: قبل از اینکه نام مستعار trait در زبان ثابت نشود ، این را تثبیت نکنید؟
pub trait Thin = Pointee<Metadata = ()>;

/// م metلفه فوق داده یک نشانگر را استخراج کنید.
///
/// مقادیر نوع `*mut T` ، `&T` یا `&mut T` را می توان مستقیماً به این عملکرد منتقل کرد زیرا آنها به طور ضمنی به `* const T` وادار می شوند.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ایمنی: دسترسی به مقدار از اتحادیه `PtrRepr` از آنجا که * const T امن است
    // و PtrComponents<T>طرح حافظه یکسانی دارند.
    // فقط std می تواند این ضمانت را ارائه دهد.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// یک نشانگر خام (possibly-wide) از آدرس داده و فراداده ایجاد می کند.
///
/// این عملکرد ایمن است اما اشاره گر برگشتی لزوماً برای استفاده مجدد امن نیست.
/// برای برش ها ، به اسناد [`slice::from_raw_parts`] برای شرایط ایمنی مراجعه کنید.
/// برای اشیا Z trait ، فراداده ها باید از یک نشانگر به همان نوع افزایش یافته زیرین بیایند.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ایمنی: دسترسی به مقدار از اتحادیه `PtrRepr` از آنجا که * const T امن است
    // و PtrComponents<T>طرح حافظه یکسانی دارند.
    // فقط std می تواند این ضمانت را ارائه دهد.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// عملکرد مشابه [`from_raw_parts`] را انجام می دهد ، با این تفاوت که یک نشانگر `*mut` خام برگردانده می شود ، در مقابل یک نشانگر `* const` خام است.
///
///
/// برای جزئیات بیشتر به اسناد [`from_raw_parts`] مراجعه کنید.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ایمنی: دسترسی به مقدار از اتحادیه `PtrRepr` از آنجا که * const T امن است
    // و PtrComponents<T>طرح حافظه یکسانی دارند.
    // فقط std می تواند این ضمانت را ارائه دهد.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// برای جلوگیری از اتصال `T: Copy` ، به راهنمای دستی نیاز است.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// برای جلوگیری از اتصال `T: Clone` ، به راهنمای دستی نیاز است.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// فراداده برای یک نوع شی `Dyn = dyn SomeTrait` trait.
///
/// این یک اشاره گر به یک میز vtable (جدول تماس مجازی) است که تمام اطلاعات لازم را برای دستکاری نوع بتن ذخیره شده در داخل یک شی trait نشان می دهد.
/// این جدول مهم شامل موارد زیر است:
///
/// * اندازه نوع
/// * تراز بندی نوع
/// * اشاره گر XL به نوع `drop_in_place` (ممکن است برای داده ساده و قدیمی ممنوع باشد)
/// * اشاره گرها به تمام روشهای اجرای نوع trait است
///
/// توجه داشته باشید که سه مورد اول ویژه هستند زیرا برای تخصیص ، رها کردن و جدا کردن از هر جسم trait ضروری هستند.
///
/// می توان نام این ساختار را با پارامتری از نوع که یک شی `dyn` trait نیست (به عنوان مثال `DynMetadata<u64>`) نامگذاری کرد اما نمی توان مقدار معنی داری از آن ساختار به دست آورد.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// پیشوند مشترک همه vtables.با استفاده از نشانگرهای تابع برای روشهای trait دنبال می شود.
///
/// جزئیات اجرای خصوصی `DynMetadata::size_of` و غیره
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// اندازه نوع مرتبط با این جدول را برمی گرداند.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ترازبندی نوع مرتبط با این جدول را برمی گرداند.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// اندازه و تراز را با هم به عنوان `Layout` برمی گرداند
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SAFETY: کامپایلر این جدول را برای یک نوع Rust بتن ساطع می کند
        // شناخته شده است که دارای یک طرح بندی معتبر است.منطق همان `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// راهنمای دستی برای جلوگیری از مرزهای `Dyn: $Trait` لازم است.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}