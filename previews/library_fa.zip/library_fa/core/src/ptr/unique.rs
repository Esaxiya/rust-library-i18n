use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// یک لفافه در اطراف `*mut T` غیر پوسته خام که نشان می دهد صاحب این لفاف صاحب مرجع است.
/// برای ایجاد انتزاعاتی مانند `Box<T>` ، `Vec<T>` ، `String` و `HashMap<K, V>` مفید است.
///
/// برخلاف `*mut T` ، `Unique<T>` رفتار "as if" دارد ، این نمونه ای از `T` بود.
/// اگر `T` `Send`/`Sync` باشد `Send`/`Sync` را پیاده سازی می کند.
/// این همچنین حاکی از نوعی نام مستعار مستقل است که نمونه ای از `T` می تواند انتظار داشته باشد:
/// مرجع اشاره گر نباید بدون داشتن یک مسیر منحصر به فرد برای داشتن منحصر به فرد ، اصلاح شود.
///
/// اگر از درست بودن استفاده از `Unique` برای اهداف خود مطمئن نیستید ، استفاده از `NonNull` را که معنای معنایی ضعیف تری دارد ، در نظر بگیرید.
///
///
/// برخلاف `*mut T` ، اشاره گر باید همیشه تهی باشد ، حتی اگر اشاره گر هرگز از آن استفاده نشود.
/// این به این دلیل است که enums ممکن است از این مقدار ممنوع به عنوان یک تمایز استفاده کند-`Option<Unique<T>>` دارای همان اندازه `Unique<T>` است.
/// اگر اشاره گر از آن استفاده نشود ، هنوز آویزان می شود.
///
/// بر خلاف `*mut T` ، `Unique<T>` نسبت به `T` متغیر است.
/// این همیشه باید برای هر نوع که الزامات نام مستعار Unique را حفظ می کند صحیح باشد.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: این مارکر هیچ عواقبی برای واریانس ندارد اما ضروری است
    // تا dropck بفهمد که ما منطقاً `T` داریم.
    //
    // برای جزئیات ، به:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` اگر `T` `Send` باشد ، اشاره گرها `Send` هستند زیرا داده هایی که آنها ارجاع می دهند غیرمنطقی است.
/// توجه داشته باشید که این نام مستعار نامشخص توسط سیستم نوع اعمال نمی شود.انتزاع با استفاده از `Unique` باید آن را اعمال کند.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` اگر `T` `Sync` باشد ، اشاره گرها `Sync` هستند زیرا داده هایی که آنها ارجاع می دهند غیرمنطقی است.
/// توجه داشته باشید که این نام مستعار نامشخص توسط سیستم نوع اعمال نمی شود.انتزاع با استفاده از `Unique` باید آن را اعمال کند.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// `Unique` جدید ایجاد می کند که آویزان است ، اما دارای یک ردیف خوب است.
    ///
    /// این مورد برای مقداردهی اولیه انواع تخصیص داده شده مانند `Vec::new` بسیار مفید است.
    ///
    /// توجه داشته باشید که مقدار نشانگر ممکن است نشانگر معتبری برای `T` باشد ، به این معنی که این نباید به عنوان مقدار نگهبان "not yet initialized" استفاده شود.
    /// انواع مختلفی که با تنبلی تخصیص می یابند باید مقدار اولیه را با روش های دیگر دنبال کنند.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() یک اشاره گر معتبر و غیر صفر را برمی گرداند.
        // بنابراین شرایط تماس با new_unchecked() رعایت می شود.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// `Unique` جدید ایجاد می کند.
    ///
    /// # Safety
    ///
    /// `ptr` باید غیر پوچ باشد.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ایمنی: تماس گیرنده باید بی اعتبار بودن `ptr` را تضمین کند.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// اگر `ptr` غیر صفر باشد `Unique` جدید ایجاد می کند.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ایمنی: نشانگر قبلاً بررسی شده است و پوچ نیست.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// نشانگر اصلی `*mut` را به دست می آورد.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// محتوا را حذف می کند.
    ///
    /// طول عمر حتمی به خود بستگی دارد بنابراین این رفتار "as if" را نشان می دهد در واقع نمونه ای از T است که قرض می گیرد.
    /// در صورت نیاز به طول عمر بیشتر (unbound) ، از `&*my_ptr.as_ptr()` استفاده کنید.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ایمنی: تماس گیرنده باید تضمین کند `self` تمام موارد را برآورده می کند
        // الزامات مرجع
        unsafe { &*self.as_ptr() }
    }

    /// به طور متناوب از محتوا استناد می کنید.
    ///
    /// طول عمر حتمی به خود بستگی دارد بنابراین این رفتار "as if" را نشان می دهد در واقع نمونه ای از T است که قرض می گیرد.
    /// در صورت نیاز به طول عمر بیشتر (unbound) ، از `&mut *my_ptr.as_ptr()` استفاده کنید.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ایمنی: تماس گیرنده باید تضمین کند `self` تمام موارد را برآورده می کند
        // الزامات یک مرجع قابل تغییر
        unsafe { &mut *self.as_ptr() }
    }

    /// به نشانگر نوع دیگری ارسال می شود.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ایمنی: Unique::new_unchecked() منحصر به فرد و نیازهای جدیدی را ایجاد می کند
        // نشانگر داده شده خنثی نیست.
        // از آنجا که ما خود را به عنوان یک نشانگر رد می کنیم ، نمی تواند پوچ باشد.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ایمنی: یک مرجع قابل تغییر نمی تواند صفر باشد
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}