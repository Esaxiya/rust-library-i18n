use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` اما غیر صفر و متغیر است.
///
/// این اغلب موارد صحیحی است که باید هنگام ساختن ساختارهای داده با استفاده از اشاره گرهای خام استفاده شود ، اما در نهایت استفاده از آنها به دلیل خواص اضافی خطرناک تر است.اگر مطمئن نیستید که باید از `NonNull<T>` استفاده کنید ، فقط از `*mut T` استفاده کنید!
///
/// برخلاف `*mut T` ، اشاره گر باید همیشه تهی باشد ، حتی اگر اشاره گر هرگز از آن استفاده نشود.این به این دلیل است که enums ممکن است از این مقدار ممنوع به عنوان یک تمایز استفاده کند-`Option<NonNull<T>>` دارای همان اندازه `* mut T` است.
/// اگر اشاره گر از آن استفاده نشود ، هنوز آویزان می شود.
///
/// بر خلاف `*mut T` ، `NonNull<T>` به عنوان متغیر نسبت به `T` انتخاب شد.این امکان استفاده از `NonNull<T>` را هنگام ساخت انواع متغیر امکان پذیر می کند ، اما در صورت استفاده در نوعی که واقعاً نباید متغیر باشد ، خطر نامناسب بودن را ایجاد می کند.
/// (انتخاب مخالف برای `*mut T` انجام شده است حتی اگر از نظر فنی نامناسب بودن فقط با فراخوانی توابع ناایمن ایجاد شود.)
///
/// کوواریانس برای اکثر انتزاعات ایمن مانند `Box` ، `Rc` ، `Arc` ، `Vec` و `LinkedList` صحیح است.این مورد به این دلیل است که آنها یک API عمومی ارائه می دهند که از قوانین نرم افزاری قابل تغییر XOR مشترک Rust پیروی می کند.
///
/// اگر نوع شما با اطمینان نمی تواند از نوع کوواریانت استفاده کند ، باید اطمینان حاصل کنید که شامل برخی زمینه های اضافی برای عدم تغییر است.اغلب این قسمت از نوع [`PhantomData`] مانند `PhantomData<Cell<T>>` یا `PhantomData<&'a mut T>` خواهد بود.
///
/// توجه داشته باشید که `NonNull<T>` یک نمونه `From` برای `&T` دارد.با این حال ، این واقعیت را تغییر نمی دهد که جهش از طریق (اشاره گر مشتق شده از a) مرجع مشترک یک رفتار تعریف نشده است ، مگر اینکه جهش در داخل [`UnsafeCell<T>`] اتفاق بیفتد.همین امر برای ایجاد یک مرجع قابل تغییر از یک مرجع مشترک نیز صدق می کند.
///
/// هنگام استفاده از این نمونه `From` بدون `UnsafeCell<T>` ، مسئولیت این است که `as_mut` هرگز فراخوانی نشود و `as_ptr` هرگز برای جهش استفاده نشود.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` اشاره گرها `Send` نیستند زیرا داده هایی که آنها ارجاع می دهند ممکن است نام مستعار باشند.
// توجه: این پیام ضروری نیست ، اما باید پیام های خطای بهتری ارائه دهد.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` اشاره گرها `Sync` نیستند زیرا داده هایی که آنها ارجاع می دهند ممکن است نام مستعار باشند.
// توجه: این پیام ضروری نیست ، اما باید پیام های خطای بهتری ارائه دهد.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// `NonNull` جدید ایجاد می کند که آویزان است ، اما دارای یک ردیف خوب است.
    ///
    /// این مورد برای مقداردهی اولیه انواع تخصیص داده شده مانند `Vec::new` بسیار مفید است.
    ///
    /// توجه داشته باشید که مقدار نشانگر ممکن است نشانگر معتبری برای `T` باشد ، به این معنی که این نباید به عنوان مقدار نگهبان "not yet initialized" استفاده شود.
    /// انواع مختلفی که با تنبلی تخصیص می یابند باید مقدار اولیه را با روش های دیگر دنبال کنند.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SAFETY: mem::align_of() یک مقدار غیر صفر را برمی گرداند که سپس ترمیم می شود
        // به یک * mut T.
        // بنابراین ، `ptr` باطل نیست و شرایط تماس با new_unchecked() رعایت می شود.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ارجاعات مشترک به مقدار را برمی گرداند.در مقابل [`as_ref`] ، این نیازی به مقداردهی اولیه ندارد.
    ///
    /// برای همتای قابل تغییر [`as_uninit_mut`] را ببینید.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// هنگام فراخوانی این روش ، باید اطمینان حاصل کنید که همه موارد زیر درست است:
    ///
    /// * نشانگر باید به درستی تراز شود.
    ///
    /// * این باید "dereferencable" به معنای تعریف شده در [the module documentation] باشد.
    ///
    /// * شما باید قوانین نام مستعار Rust را اجرا کنید ، زیرا `'a` طول عمر برگشتی خودسرانه انتخاب شده است و لزوماً منعکس کننده عمر واقعی داده ها نیست.
    ///
    ///   به طور خاص ، برای مدت زمان این عمر ، حافظه ای که اشاره گر به آن اشاره می کند نباید جهش یابد (به جز در داخل `UnsafeCell`).
    ///
    /// این امر حتی در صورت استفاده نکردن از نتیجه این روش نیز صدق می کند!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ایمنی: تماس گیرنده باید تضمین کند `self` تمام موارد را برآورده می کند
        // الزامات مرجع
        unsafe { &*self.cast().as_ptr() }
    }

    /// ارجاعات منحصر به فردی را به مقدار برمی گرداند.در مقابل [`as_mut`] ، این نیازی به مقداردهی اولیه ندارد.
    ///
    /// برای همتای مشترک خود به [`as_uninit_ref`] مراجعه کنید.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// هنگام فراخوانی این روش ، باید اطمینان حاصل کنید که همه موارد زیر درست است:
    ///
    /// * نشانگر باید به درستی تراز شود.
    ///
    /// * این باید "dereferencable" به معنای تعریف شده در [the module documentation] باشد.
    ///
    /// * شما باید قوانین نام مستعار Rust را اجرا کنید ، زیرا `'a` طول عمر برگشتی خودسرانه انتخاب شده است و لزوماً منعکس کننده عمر واقعی داده ها نیست.
    ///
    ///   به طور خاص ، برای مدت زمان این عمر ، حافظه ای که اشاره گر به آن اشاره می کند نباید از طریق هیچ اشاره گر دیگری قابل دسترسی (خواندن یا نوشتن) باشد.
    ///
    /// این امر حتی در صورت استفاده نکردن از نتیجه این روش نیز صدق می کند!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ایمنی: تماس گیرنده باید تضمین کند `self` تمام موارد را برآورده می کند
        // الزامات مرجع
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// `NonNull` جدید ایجاد می کند.
    ///
    /// # Safety
    ///
    /// `ptr` باید غیر پوچ باشد.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ایمنی: تماس گیرنده باید بی اعتبار بودن `ptr` را تضمین کند.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// اگر `ptr` غیر پوچ باشد ، `NonNull` جدید ایجاد می کند.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SAFETY: نشانگر قبلاً علامت زده شده است و تهی نیست
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// عملکرد مشابه [`std::ptr::from_raw_parts`] را انجام می دهد ، با این تفاوت که یک نشانگر `NonNull` برگردانده می شود ، در مقابل یک نشانگر `*const` خام است.
    ///
    ///
    /// برای جزئیات بیشتر به اسناد [`std::ptr::from_raw_parts`] مراجعه کنید.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ایمنی: نتیجه `ptr::from::raw_parts_mut` بی اعتبار است زیرا `data_address` است.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// تجزیه یک اشاره گر (احتمالاً گسترده) به آدرس و م componentsلفه های فراداده است.
    ///
    /// بعداً می توان اشاره گر را با [`NonNull::from_raw_parts`] بازسازی کرد.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// نشانگر اصلی `*mut` را به دست می آورد.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// یک مرجع مشترک را به مقدار برمی گرداند.اگر ممکن است مقدار اولیه نشده باشد ، به جای آن باید از [`as_uninit_ref`] استفاده شود.
    ///
    /// برای همتای قابل تغییر [`as_mut`] را ببینید.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// هنگام فراخوانی این روش ، باید اطمینان حاصل کنید که همه موارد زیر درست است:
    ///
    /// * نشانگر باید به درستی تراز شود.
    ///
    /// * این باید "dereferencable" به معنای تعریف شده در [the module documentation] باشد.
    ///
    /// * نشانگر باید به یک نمونه اولیه `T` اشاره کند.
    ///
    /// * شما باید قوانین نام مستعار Rust را اجرا کنید ، زیرا `'a` طول عمر برگشتی خودسرانه انتخاب شده است و لزوماً منعکس کننده عمر واقعی داده ها نیست.
    ///
    ///   به طور خاص ، برای مدت زمان این عمر ، حافظه ای که اشاره گر به آن اشاره می کند نباید جهش یابد (به جز در داخل `UnsafeCell`).
    ///
    /// این امر حتی در صورت استفاده نکردن از نتیجه این روش نیز صدق می کند!
    /// (بخشی در مورد مقداردهی اولیه هنوز به طور کامل تصمیم گیری نشده است ، اما تا زمانی که این کار انجام شود ، تنها روش ایمن این است که اطمینان حاصل شود که در واقع اولیه می شوند.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ایمنی: تماس گیرنده باید تضمین کند `self` تمام موارد را برآورده می کند
        // الزامات مرجع
        unsafe { &*self.as_ptr() }
    }

    /// یک ارجاع منحصر به فرد به مقدار برمی گرداند.اگر ممکن است مقدار اولیه نشده باشد ، به جای آن باید از [`as_uninit_mut`] استفاده شود.
    ///
    /// برای همتای مشترک خود به [`as_ref`] مراجعه کنید.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// هنگام فراخوانی این روش ، باید اطمینان حاصل کنید که همه موارد زیر درست است:
    ///
    /// * نشانگر باید به درستی تراز شود.
    ///
    /// * این باید "dereferencable" به معنای تعریف شده در [the module documentation] باشد.
    ///
    /// * نشانگر باید به یک نمونه اولیه `T` اشاره کند.
    ///
    /// * شما باید قوانین نام مستعار Rust را اجرا کنید ، زیرا `'a` طول عمر برگشتی خودسرانه انتخاب شده است و لزوماً منعکس کننده عمر واقعی داده ها نیست.
    ///
    ///   به طور خاص ، برای مدت زمان این عمر ، حافظه ای که اشاره گر به آن اشاره می کند نباید از طریق هیچ اشاره گر دیگری قابل دسترسی (خواندن یا نوشتن) باشد.
    ///
    /// این امر حتی در صورت استفاده نکردن از نتیجه این روش نیز صدق می کند!
    /// (بخشی در مورد مقداردهی اولیه هنوز به طور کامل تصمیم گیری نشده است ، اما تا زمانی که این کار انجام شود ، تنها روش ایمن این است که اطمینان حاصل شود که در واقع اولیه می شوند.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ایمنی: تماس گیرنده باید تضمین کند `self` تمام موارد را برآورده می کند
        // الزامات یک مرجع قابل تغییر
        unsafe { &mut *self.as_ptr() }
    }

    /// به نشانگر نوع دیگری ارسال می شود.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SAFETY: `self` یک اشاره گر `NonNull` است که لزوماً پوچ است
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// یک برش خام غیر تهی از یک اشاره گر نازک و طول ایجاد می کند.
    ///
    /// استدلال `len` تعداد **عناصر** است ، نه تعداد بایت ها.
    ///
    /// این عملکرد ایمن است ، اما ارجاع مجدد مقدار بازگشتی ناامن است.
    /// برای نیازهای ایمنی در اسناد [`slice::from_raw_parts`] مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // هنگام شروع با اشاره گر به اولین عنصر ، یک اشاره گر برش ایجاد کنید
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (توجه داشته باشید که این مثال به طور مصنوعی استفاده از این روش را نشان می دهد ، اما `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SAFETY: `data` یک اشاره گر `NonNull` است که لزوماً پوچ است
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// طول یک برش خام غیر پوستی را برمی گرداند.
    ///
    /// مقدار برگشتی تعداد **عناصر** است ، نه تعداد بایت ها.
    ///
    /// این عملکرد ایمن است ، حتی اگر قطعه خام غیر تهی را نمی توان به یک قطعه ارجاع داد زیرا نشانگر آدرس معتبری ندارد.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// یک اشاره گر غیر تهی به بافر برش برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ایمنی: می دانیم `self` غیر پوستی است.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// یک نشانگر خام را به بافر برش برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// یک مرجع مشترک را به بخشی از مقادیر احتمالاً غیر اولیه بازمی گرداند.در مقابل [`as_ref`] ، این نیازی به مقداردهی اولیه ندارد.
    ///
    /// برای همتای قابل تغییر [`as_uninit_slice_mut`] را ببینید.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// هنگام فراخوانی این روش ، باید اطمینان حاصل کنید که همه موارد زیر درست است:
    ///
    /// * نشانگر برای خواندن `ptr.len() * mem::size_of::<T>()` بایت باید [valid] باشد و باید به درستی تراز شود.این به ویژه به معنای:
    ///
    ///     * کل محدوده حافظه این قطعه باید در یک شی allocated اختصاص یافته باشد!
    ///       برش ها هرگز نمی توانند از طریق چندین شی allocated اختصاص یافته امتداد پیدا کنند.
    ///
    ///     * اشاره گر باید برای برش هایی با طول صفر هم تراز باشد.
    ///     یک دلیل برای این امر این است که بهینه سازی های چیدمان enum ممکن است به ترجیح داده ها (از جمله برشهای با هر طول) و هم جهت نبودن آنها برای متمایز کردن از سایر داده ها متکی باشد.
    ///
    ///     با استفاده از [`NonNull::dangling()`] می توانید اشاره گر قابل استفاده به عنوان `data` برای برش های با طول صفر بدست آورید.
    ///
    /// * اندازه کل `ptr.len() * mem::size_of::<T>()` قطعه نباید بزرگتر از `isize::MAX` باشد.
    ///   به اسناد ایمنی [`pointer::offset`] مراجعه کنید.
    ///
    /// * شما باید قوانین نام مستعار Rust را اجرا کنید ، زیرا `'a` طول عمر برگشتی خودسرانه انتخاب شده است و لزوماً منعکس کننده عمر واقعی داده ها نیست.
    ///   به طور خاص ، برای مدت زمان این عمر ، حافظه ای که اشاره گر به آن اشاره می کند نباید جهش یابد (به جز در داخل `UnsafeCell`).
    ///
    /// این امر حتی در صورت استفاده نکردن از نتیجه این روش نیز صدق می کند!
    ///
    /// به [`slice::from_raw_parts`] نیز مراجعه کنید.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `as_uninit_slice` را رعایت کند.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// یک ارجاع منحصر به فرد را به بخشی از مقادیر احتمالاً غیر اولیه بازمی گرداند.در مقابل [`as_mut`] ، این نیازی به مقداردهی اولیه ندارد.
    ///
    /// برای همتای مشترک خود به [`as_uninit_slice`] مراجعه کنید.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// هنگام فراخوانی این روش ، باید اطمینان حاصل کنید که همه موارد زیر درست است:
    ///
    /// * نشانگر برای خواندن و نوشتن برای `ptr.len() * mem::size_of::<T>()` بایت باید [valid] باشد و باید به درستی تراز شود.این به ویژه به معنای:
    ///
    ///     * کل محدوده حافظه این قطعه باید در یک شی allocated اختصاص یافته باشد!
    ///       برش ها هرگز نمی توانند از طریق چندین شی allocated اختصاص یافته امتداد پیدا کنند.
    ///
    ///     * اشاره گر باید برای برش هایی با طول صفر هم تراز باشد.
    ///     یک دلیل برای این امر این است که بهینه سازی های چیدمان enum ممکن است به ترجیح داده ها (از جمله برشهای با هر طول) و هم جهت نبودن آنها برای متمایز کردن از سایر داده ها متکی باشد.
    ///
    ///     با استفاده از [`NonNull::dangling()`] می توانید اشاره گر قابل استفاده به عنوان `data` برای برش های با طول صفر بدست آورید.
    ///
    /// * اندازه کل `ptr.len() * mem::size_of::<T>()` قطعه نباید بزرگتر از `isize::MAX` باشد.
    ///   به اسناد ایمنی [`pointer::offset`] مراجعه کنید.
    ///
    /// * شما باید قوانین نام مستعار Rust را اجرا کنید ، زیرا `'a` طول عمر برگشتی خودسرانه انتخاب شده است و لزوماً منعکس کننده عمر واقعی داده ها نیست.
    ///   به طور خاص ، برای مدت زمان این عمر ، حافظه ای که اشاره گر به آن اشاره می کند نباید از طریق هیچ اشاره گر دیگری قابل دسترسی (خواندن یا نوشتن) باشد.
    ///
    /// این امر حتی در صورت استفاده نکردن از نتیجه این روش نیز صدق می کند!
    ///
    /// به [`slice::from_raw_parts_mut`] نیز مراجعه کنید.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // این امن است زیرا `memory` برای خواندن و نوشتن برای `memory.len()` بایت معتبر است.
    /// // توجه داشته باشید که تماس با `memory.as_mut()` در اینجا مجاز نیست زیرا ممکن است محتوا غیر اولیه باشد.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `as_uninit_slice_mut` را رعایت کند.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// یک نشانگر خام را بدون انجام بررسی مرزها به یک عنصر یا زیرشاخه برمی گرداند.
    ///
    /// فراخوانی این روش با یک شاخص خارج از مرزها یا زمانی که `self` قابل ارجاع نیست ،*[رفتار تعریف نشده]* است حتی اگر از نشانگر حاصل استفاده نشود.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SAFETY: تماس گیرنده اطمینان می دهد `self` قابل استناد نیست و `index` داخل مرز است.
        // در نتیجه ، نشانگر حاصل نمی تواند NULL باشد.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ایمنی: یک نشانگر منحصر به فرد نمی تواند تهی باشد ، بنابراین شرایط برای
        // new_unchecked() محترم هستند
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ایمنی: یک مرجع قابل تغییر نمی تواند صفر باشد.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ایمنی: یک مرجع نمی تواند بی فایده باشد ، بنابراین شرایط برای
        // new_unchecked() محترم هستند
        unsafe { NonNull { pointer: reference as *const T } }
    }
}