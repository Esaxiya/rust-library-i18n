//! traits بدوی و انواع نمایانگر خصوصیات اساسی انواع.
//!
//! انواع Rust را می توان با توجه به خصوصیات ذاتی آنها به روش های مفید مختلف طبقه بندی کرد.
//! این طبقه بندی ها به صورت traits نشان داده می شوند.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// انواع قابل انتقال از مرزهای موضوع.
///
/// این trait هنگامی که کامپایلر مناسب بودن را تشخیص دهد به طور خودکار اجرا می شود.
///
/// نمونه ای از نوع غیر "ارسال" نشانگر شمارش مرجع [`rc::Rc`][`Rc`] است.
/// اگر دو رشته بخواهد [Rc »هایی را که به همان مقدار محاسبه شده مرجع هستند ، شبیه سازی کند ، ممکن است سعی کنند تعداد مرجع را به طور همزمان به روز کنند ، که [undefined behavior][ub] است زیرا [`Rc`] از عملیات اتمی استفاده نمی کند.
///
/// پسر عموی آن [`sync::Arc`][arc] از عملیات اتمی استفاده می کند (که برخی از آنها سربار است) و بنابراین `Send` است.
///
/// برای جزئیات بیشتر به [the Nomicon](../../nomicon/send-and-sync.html) مراجعه کنید.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// انواع با اندازه ثابت که در زمان کامپایل شناخته شده اند.
///
/// تمام پارامترهای نوع دارای یک محدودیت ضمنی از `Sized` هستند.در صورت عدم مناسب بودن ، می توان از نحو ویژه `?Sized` برای از بین بردن این بند استفاده کرد.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // ساختار FooUse(Foo<[i32]>)؛//خطا: اندازه برای [i32] اجرا نمی شود
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// یک استثنا ، نوع ضمنی `Self` از trait است.
/// trait دارای `Sized` ضمنی نیست زیرا این مورد با [جسم trait] سازگار نیست ، جایی که طبق تعریف ، trait نیاز به کار با همه پیاده سازهای ممکن دارد و بنابراین می تواند هر اندازه باشد.
///
///
/// اگرچه Rust به شما امکان می دهد `Sized` را به trait متصل کنید ، بعداً نمی توانید از آن برای تشکیل یک شی trait استفاده کنید:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // اجازه دهید y: &dyn Bar= &Impl؛//خطا: trait `Bar` را نمی توان به صورت جسم در آورد
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // به عنوان مثال برای پیش فرض ، که نیاز به ارزیابی `[T]: !Default` دارد
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// انواعي كه مي توانند از نوع "unsized" به نوع ديناميك باشند.
///
/// به عنوان مثال ، اندازه آرایه `[i8; 2]` `Unsize<[i8]>` و `Unsize<dyn fmt::Debug>` را پیاده سازی می کند.
///
/// تمام پیاده سازی های `Unsize` به طور خودکار توسط کامپایلر ارائه می شود.
///
/// `Unsize` برای:
///
/// - `[T; N]` `Unsize<[T]>` است
/// - `T` `Unsize<dyn Trait>` است وقتی `T: Trait`
/// - `Foo<..., T, ...>` `Unsize<Foo<..., U, ...>>` است اگر:
///   - `T: Unsize<U>`
///   - Foo یک ساختار است
///   - فقط آخرین فیلد `Foo` دارای یک نوع مربوط به `T` است
///   - `T` بخشی از نوع سایر زمینه ها نیست
///   - `Bar<T>: Unsize<Bar<U>>`, اگر آخرین قسمت `Foo` از نوع `Bar<T>` باشد
///
/// `Unsize` همراه با [`ops::CoerceUnsized`] استفاده می شود تا ظروف "user-defined" مانند [`Rc`] حاوی انواع پویا باشد.
/// برای جزئیات بیشتر به [DST coercion RFC][RFC982] و [the nomicon entry on coercion][nomicon-coerce] مراجعه کنید.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait مورد نیاز برای ثابتهایی که در تطابق الگوها استفاده می شود.
///
/// هر نوع `PartialEq` مشتق شده به طور خودکار این trait را اجرا می کند ، * بدون در نظر گرفتن اینکه آیا پارامترهای نوع آن `Eq` را اجرا می کنند.
///
/// اگر یک مورد `const` حاوی نوعی باشد که این trait را اجرا نمی کند ، پس آن نوع یا (1.) `PartialEq` را پیاده سازی نمی کند (این بدان معنی است که ثابت آن روش مقایسه را ارائه نمی دهد ، که تولید کد تصور می کند موجود است) ، یا (2.) آن را پیاده سازی می کند *خودش* نسخه `PartialEq` (که ما تصور می کنیم با مقایسه برابری ساختاری مطابقت ندارد).
///
///
/// در هر دو حالت بالا ، استفاده از چنین ثابتی را در یک تطابق الگو رد می کنیم.
///
/// همچنین به [structural match RFC][RFC1445] و [issue 63438] مراجعه کنید که انگیزه مهاجرت از طراحی مبتنی بر ویژگی را به این trait داده است.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait مورد نیاز برای ثابتهایی که در تطابق الگوها استفاده می شود.
///
/// هر نوع مشتق شده از `Eq` به طور خودکار این trait را پیاده سازی می کند ، * صرف نظر از اینکه پارامترهای نوع آن `Eq` را پیاده سازی می کنند.
///
/// این یک هک برای ایجاد محدودیت در سیستم نوع ماست.
///
/// # Background
///
/// ما می خواهیم انواع سازه های مورد استفاده در تطابق الگو دارای ویژگی `#[derive(PartialEq, Eq)]` باشند.
///
/// در دنیای ایده آل تر ، می توانیم فقط با بررسی اینکه نوع داده شده هم `StructuralPartialEq` trait * و هم `Eq` trait را پیاده سازی می کند ، این نیاز را بررسی کنیم.
/// با این حال ، شما می توانید ADT هایی داشته باشید که *`derive(PartialEq, Eq)`* انجام دهند ، و موردی باشید که می خواهیم کامپایلر آن را بپذیرد ، اما با این وجود نوع ثابت نمی تواند `Eq` را پیاده سازی کند.
///
/// یعنی موردی مانند این:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (مشکلی که در کد بالا وجود دارد این است که `Wrap<fn(&())>` `PartialEq` و `Eq` را پیاده سازی نمی کند ، زیرا "برای <" a> fn(&'a _)` does not implement those traits.)
///
/// بنابراین ، نمی توانیم به بررسی ساده لوحانه `StructuralPartialEq` و `Eq` صرف اعتماد کنیم.
///
/// به عنوان یک هک برای حل این مسئله ، ما از دو traits جداگانه تزریق شده توسط هر یک از دو مشتق (`#[derive(PartialEq)]` و `#[derive(Eq)]`) استفاده می کنیم و بررسی می کنیم که هر دو به عنوان بخشی از بررسی سازگاری ساختاری وجود داشته باشند.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// انواع مختلفی که مقادیر آنها به سادگی با کپی کردن بیت ها قابل کپی است.
///
/// به طور پیش فرض ، صحافی های متغیر دارای "معناشناسی حرکت" هستند.به عبارت دیگر:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` به `y` منتقل شده است ، بنابراین نمی توان از آن استفاده کرد
///
/// // println! ("{: ؟}" ، x)؛//خطا: استفاده از مقدار منتقل شده
/// ```
///
/// با این حال ، اگر یک نوع `Copy` را پیاده سازی کند ، درعوض "کپی معنایی" دارد:
///
/// ```
/// // ما می توانیم یک پیاده سازی `Copy` استخراج کنیم.
/// // `Clone` همچنین لازم است ، زیرا این یک سوپراستار `Copy` است.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` یک کپی از `x` است
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// توجه به این نکته مهم است که در این دو مثال ، تنها تفاوت در این است که آیا شما اجازه دسترسی به `x` را پس از انتصاب دارید.
/// در زیر کاپوت ، یک کپی و یک حرکت می تواند منجر به کپی بیت ها در حافظه شود ، اگرچه این موارد بعضاً بهینه می شوند.
///
/// ## چگونه می توانم `Copy` را پیاده سازی کنم؟
///
/// دو روش برای پیاده سازی `Copy` بر روی نوع شما وجود دارد.ساده ترین استفاده از `derive` است:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// همچنین می توانید `Copy` و `Clone` را به صورت دستی پیاده سازی کنید:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// تفاوت کمی بین این دو وجود دارد: استراتژی `derive` همچنین `Copy` را به پارامترهای نوع محدود می کند ، که همیشه مورد نظر نیست.
///
/// ## چه تفاوتی بین `Copy` و `Clone` وجود دارد؟
///
/// کپی به طور ضمنی اتفاق می افتد ، به عنوان مثال به عنوان بخشی از تکلیف `y = x`.رفتار `Copy` بارگیری نمی شود.این همیشه یک کپی ساده و کمی خردمندانه است.
///
/// شبیه سازی عملی صریح است ، `x.clone()`.اجرای [`Clone`] می تواند هر نوع رفتار خاصی را که برای تکثیر مقادیر به صورت ایمن لازم است ، فراهم کند.
/// به عنوان مثال ، پیاده سازی [`Clone`] برای [`String`] نیاز به کپی رشته بافر اشاره شده در پشته دارد.
/// یک کپی بیتی ساده از مقادیر [`String`] صرفاً نشانگر را کپی می کند و منجر به دو برابر آزاد شدن خط می شود.
/// به همین دلیل ، [`String`] [`Clone`] است اما `Copy` نیست.
///
/// [`Clone`] یک سوپرایه از `Copy` است ، بنابراین هر چیزی که `Copy` است باید [`Clone`] را نیز پیاده سازی کند.
/// اگر نوع `Copy` باشد ، اجرای [`Clone`] فقط به بازگشت `*self` نیاز دارد (به مثال بالا مراجعه کنید).
///
/// ## چه زمانی نوع من می تواند `Copy` باشد؟
///
/// اگر همه اجزای آن `Copy` را اجرا کنند ، یک نوع می تواند `Copy` را پیاده سازی کند.به عنوان مثال ، این ساختار می تواند `Copy` باشد:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// یک ساختار می تواند `Copy` باشد ، و [`i32`] `Copy` است ، بنابراین `Point` واجد شرایط `Copy` است.
/// در مقابل ، در نظر بگیرید
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// ساختار `PointList` نمی تواند `Copy` را پیاده سازی کند ، زیرا [`Vec<T>`] `Copy` نیست.اگر بخواهیم پیاده سازی `Copy` را استخراج کنیم ، با خطا مواجه خواهیم شد:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// منابع مشترک (`&T`) نیز `Copy` هستند ، بنابراین یک نوع می تواند `Copy` باشد ، حتی اگر منابع مشترکی از انواع `T` که *`Copy` نیستند* را در خود جای دهد.
/// ساختار زیر را در نظر بگیرید ، که می تواند `Copy` را پیاده سازی کند ، زیرا فقط یک مرجع مشترک * به نوع غیر "کپی" `PointList` ما از بالا دارد:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## چه زمانی * نمی توان نوع من `Copy` باشد؟
///
/// بعضی از انواع را نمی توان با خیال راحت کپی کرد.به عنوان مثال ، کپی کردن `&mut T` باعث ایجاد یک منبع غیرقابل تغییر می شود.
/// کپی کردن [`String`] مسئولیت مدیریت بافر ["رشته"] را تکرار می کند و منجر به دو برابر رایگان شدن می شود.
///
/// با تعمیم مورد اخیر ، هر نوع پیاده سازی کننده [`Drop`] نمی تواند `Copy` باشد ، زیرا علاوه بر بایت [`size_of::<T>`] خود ، برخی منابع را نیز مدیریت می کند.
///
/// اگر سعی کنید `Copy` را بر روی یک ساختار یا enum حاوی داده های غیر "کپی" پیاده سازی کنید ، با خطای [E0204] مواجه خواهید شد.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## چه زمان *باید* نوع من `Copy` باشد؟
///
/// به طور کلی ، اگر نوع _can_ شما `Copy` را پیاده سازی می کند ، باید چنین باشد.
/// به یاد داشته باشید که اجرای `Copy` بخشی از API عمومی از نوع شما است.
/// اگر این نوع در future غیر "کپی" شود ، برای جلوگیری از شکستن تغییر API ، احتیاط خواهد بود که اکنون اجرای `Copy` را حذف کنید.
///
/// ## مجری های اضافی
///
/// علاوه بر [implementors listed below][impls] ، انواع زیر نیز `Copy` را اجرا می کنند:
///
/// * انواع موارد عملکرد (به عنوان مثال ، انواع متمایز تعریف شده برای هر عملکرد)
/// * انواع نشانگر عملکرد (به عنوان مثال ، `fn() -> i32`)
/// * انواع آرایه ، برای همه اندازه ها ، اگر نوع مورد `Copy` را نیز اجرا کند (به عنوان مثال ، `[i32; 123456]`)
/// * اگر هر م componentلفه `Copy` را نیز پیاده سازی کند انواع مختلفی دارد (به عنوان مثال `()` ، `(i32, bool)`)
/// * اگر هیچ مقداری از محیط گرفته نشود یا اگر همه این مقادیر گرفته شده `Copy` را خود پیاده سازی کند ، انواع بسته شدن آن
///   توجه داشته باشید که متغیرهای گرفته شده توسط مرجع مشترک همیشه `Copy` را اجرا می کنند (حتی اگر مرجع این کار را انجام ندهد) ، در حالی که متغیرهای گرفته شده توسط مرجع قابل تغییر هرگز `Copy` را اجرا نمی کنند.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) این امکان کپی کردن نوعی را فراهم می کند که `Copy` را به دلیل عدم رضایت مادام العمر مادام العمر اجرا نمی کند (کپی کردن `A<'_>` فقط در `A<'static>: Copy` و `A<'_>: Clone`).
// ما این ویژگی را فعلاً در اینجا داریم فقط به این دلیل که تعداد زیادی تخصص موجود در `Copy` در کتابخانه استاندارد وجود دارد و در حال حاضر راهی برای داشتن این رفتار با خیال راحت وجود ندارد.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// تولید ماکرو تولید impl از trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// انواع به اشتراک گذاری منابع بین رشته ها برای آنها امن است.
///
/// این trait هنگامی که کامپایلر مناسب بودن را تشخیص دهد به طور خودکار اجرا می شود.
///
/// تعریف دقیق این است: یک نوع `T` [`Sync`] است اگر و فقط اگر `&T` [`Send`] باشد.
/// به عبارت دیگر ، اگر هنگام عبور از منابع `&T` بین رشته ها ، امکان [undefined behavior][ub] (از جمله داده های داده) وجود نداشته باشد.
///
/// همانطور که انتظار می رود ، انواع ابتدایی مانند [`u8`] و [`f64`] همه [`Sync`] هستند و انواع تجمع ساده حاوی آنها نیز وجود دارد ، مانند تاپل ، ستون و شمارش.
/// نمونه های بیشتری از انواع پایه [`Sync`] شامل انواع "immutable" مانند `&T` و آنهایی که دارای تغییر پذیری ساده ارثی هستند مانند [`Box<T>`][box] ، [`Vec<T>`][vec] و اکثر انواع دیگر مجموعه ها.
///
/// (پارامترهای عمومی باید [`Sync`] باشند تا کانتینر آنها ["همگام سازی" باشد.)
///
/// یک نتیجه تا حدودی تعجب آور این تعریف این است که `&mut T` `Sync` است (اگر `T` `Sync` باشد) حتی اگر به نظر می رسد که ممکن است جهش همزمان نشده ایجاد کند.
/// ترفند این است که یک مرجع قابل تغییر در پشت یک مرجع مشترک (یعنی `& &mut T`) فقط خواندنی می شود ، مثل اینکه `& &T` باشد.
/// از این رو هیچ خطر مسابقه داده وجود ندارد.
///
/// انواع `Sync` آنهایی هستند که دارای "interior mutability" به شکل بدون نخ بدون سر نخ نیستند ، مانند [`Cell`][cell] و [`RefCell`][refcell].
/// این نوع حتی از طریق یک منبع مشترک تغییرناپذیر امکان جهش در محتوای آنها را فراهم می کنند.
/// به عنوان مثال روش `set` در [`Cell<T>`][cell] `&self` را می گیرد ، بنابراین فقط به یک مرجع مشترک [`&Cell<T>`][cell] نیاز دارد.
/// این روش بدون هماهنگی انجام می شود ، بنابراین [`Cell`][cell] نمی تواند `Sync` باشد.
///
/// مثال دیگر از نوع غیر «Sync» اشاره گر شمارش مرجع [`Rc`][rc] است.
/// با توجه به هر مرجع [`&Rc<T>`][rc] ، می توانید [`Rc<T>`][rc] جدید را شبیه سازی کنید ، تعداد مرجع را به روشی غیر اتمی تغییر دهید.
///
/// Rust برای مواردی که نیاز به تغییر پذیری داخلی بدون نخ دارد ، [atomic data types] و همچنین قفل صریح را از طریق [`sync::Mutex`][mutex] و [`sync::RwLock`][rwlock] فراهم می کند.
/// این نوع اطمینان حاصل می کند که هر جهش نمی تواند باعث بروز داده ها شود ، از این رو انواع آن `Sync` است.
/// به همین ترتیب ، [`sync::Arc`][arc] آنالوگ [`Rc`][rc] بدون نخ را فراهم می کند.
///
/// هر نوع دارای قابلیت تغییر پذیری داخلی نیز باید از لفافه [`cell::UnsafeCell`][unsafecell] در اطراف value(s) استفاده کنند که می تواند از طریق یک مرجع مشترک جهش یابد.
/// انجام این کار [undefined behavior][ub] نیست.
/// به عنوان مثال ، ["transmute"][transmute]-ing از `&T` به `&mut T` نامعتبر است.
///
/// برای اطلاعات بیشتر در مورد `Sync` به [the Nomicon][nomicon-send-and-sync] مراجعه کنید.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): یک بار پشتیبانی برای اضافه کردن یادداشت ها در `rustc_on_unimplemented` در نسخه بتا ، و آن را گسترش داده است برای بررسی اینکه آیا بسته شدن در هر نقطه از زنجیره مورد نیاز است ، گسترش آن به عنوان (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// نوع صفر برای علامت گذاری مواردی که "act like" صاحب `T` هستند استفاده می شود.
///
/// افزودن فیلد `PhantomData<T>` به نوع خود ، به کامپایلر می گوید که نوع شما مانند اینکه مقدار `T` را ذخیره می کند ، عمل می کند ، اگرچه واقعاً چنین نیست.
/// این اطلاعات هنگام محاسبه برخی از خصوصیات ایمنی استفاده می شود.
///
/// برای توضیح بیشتر در مورد نحوه استفاده از `PhantomData<T>` ، لطفاً به [the Nomicon](../../nomicon/phantom-data.html) مراجعه کنید.
///
/// # یک یادداشت هولناک
///
/// اگرچه هر دو نام ترسناکی دارند ، اما `PhantomData` و "انواع فانتوم" با هم مرتبط هستند ، اما یکسان نیستند.پارامتر نوع فانتوم به سادگی یک پارامتر نوع است که هرگز استفاده نمی شود.
/// در Rust ، این اغلب باعث شکایت کامپایلر می شود و راه حل این است که استفاده "dummy" را از طریق `PhantomData` اضافه کنید.
///
/// # Examples
///
/// ## پارامترهای طول عمر استفاده نشده
///
/// شاید رایج ترین مورد استفاده برای `PhantomData` ساختاری باشد که دارای پارامتر طول عمر بلااستفاده باشد ، معمولاً به عنوان بخشی از برخی از کد های ناامن.
/// به عنوان مثال ، در اینجا یک ساختار `Slice` وجود دارد که دارای دو نشانگر از نوع `*const T` است ، احتمالاً جایی را به یک آرایه نشان می دهد:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// هدف این است که داده های اساسی فقط برای `'a` مادام العمر معتبر باشند ، بنابراین `Slice` نباید بیش از `'a` زنده بماند.
/// با این حال ، این هدف در کد بیان نشده است ، زیرا هیچ استفاده ای از `'a` در طول زندگی وجود ندارد و بنابراین مشخص نیست که برای چه داده ای اعمال می شود.
/// ما می توانیم این را با گفتن کامپایلر اصلاح کنیم *طوری رفتار کنید که انگار* ساختار `Slice` حاوی `&'a T` مرجع باشد:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// این نیز به نوبه خود به حاشیه نویسی `T: 'a` نیاز دارد ، این نشان می دهد که هرگونه مراجعه به `T` در طول عمر `'a` معتبر است.
///
/// هنگام مقدار دهی اولیه `Slice` به سادگی مقدار `PhantomData` را برای قسمت `phantom` ارائه می دهید:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## پارامترهای نوع استفاده نشده
///
/// گاهی اوقات اتفاق می افتد که شما پارامترهای نوع استفاده نشده ای دارید که نشان می دهد ساختار کدام نوع داده "tied" است ، حتی اگر آن داده در واقع در ساختار موجود نباشد.
/// در اینجا مثالی آورده شده است که این مسئله با [FFI] بوجود می آید.
/// رابط خارجی از دسته های نوع `*mut ()` برای اشاره به مقادیر Rust از انواع مختلف استفاده می کند.
/// ما نوع Rust را با استفاده از یک پارامتر نوع فانتوم روی ساختار `ExternalResource` که یک دسته را بسته بندی می کند ردیابی می کنیم.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## مالکیت و چک سقوط
///
/// افزودن فیلدی از نوع `PhantomData<T>` نشان می دهد که نوع شما دارای داده هایی از نوع `T` است.این به نوبه خود نشان می دهد که وقتی نوع شما رها می شود ، ممکن است یک یا چند نمونه از نوع `T` را رها کند.
/// این امر تاثیری در تجزیه و تحلیل [drop check] کامپایلر Rust دارد.
///
/// اگر ساختار شما در واقع داده *های نوع `T`* را در اختیار شما قرار نمی دهد ، بهتر است از نوع مرجعی مانند `PhantomData<&'a T>` (ideally) یا `PhantomData<*const T>` استفاده کنید (درصورتی که طول عمر اعمال نشود) ، تا مالکیت را نشان ندهد.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// کامپایلر داخلی trait برای نشان دادن انواع تبعیض آمیز استفاده می شود.
///
/// این trait به طور خودکار برای هر نوع اجرا می شود و هیچ تضمینی به [`mem::Discriminant`] نمی دهد.
/// تغییر شکل **بین `DiscriminantKind::Discriminant` و `mem::Discriminant`** یک رفتار تعریف نشده است.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// نوع متمایز کننده ، که باید trait bounds مورد نیاز `mem::Discriminant` را برآورده کند.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// کامپایلر داخلی trait برای تعیین اینکه آیا یک نوع حاوی `UnsafeCell` در داخل است ، استفاده می شود ، اما نه از طریق عدم سوire استفاده.
///
/// به عنوان مثال ، اینكه `static` از آن نوع در حافظه استاتیک فقط خواندنی یا حافظه استاتیک قابل نوشتن قرار گیرد ، تأثیر می گذارد.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// انواع قابل انتقال پس از پین شدن با خیال راحت.
///
/// Rust خود تصوری از انواع غیر منقول ندارد و حرکت ها (مثلاً از طریق واگذاری یا [`mem::replace`]) را همیشه ایمن می داند.
///
/// در عوض از نوع [`Pin`][Pin] برای جلوگیری از حرکت در سیستم نوع استفاده می شود.اشاره گرهای `P<T>` را که در بسته بندی [`Pin<P<T>>`][Pin] بسته بندی شده اند ، نمی توان از آن خارج کرد.
/// برای کسب اطلاعات بیشتر در مورد پین کردن ، به اسناد [`pin` module] مراجعه کنید.
///
/// اجرای `Unpin` trait برای `T` محدودیت های ایجاد نوع را برطرف می کند ، بنابراین اجازه می دهد `T` را با عملکردهایی مانند [`mem::replace`] به خارج از [`Pin<P<T>>`][Pin] منتقل کنید.
///
///
/// `Unpin` هیچ نتیجه ای برای داده های غیر پین شده ندارد.
/// به طور خاص ، [`mem::replace`] با خوشحالی داده های `!Unpin` را جابجا می کند (برای هر `&mut T` ، نه فقط هنگام `T: Unpin` کار می کند).
/// با این حال ، شما نمی توانید از [`mem::replace`] در داده های داخل [`Pin<P<T>>`][Pin] استفاده کنید زیرا نمی توانید `&mut T` مورد نیاز خود را بدست آورید و *این* باعث عملکرد این سیستم می شود.
///
/// بنابراین ، برای مثال ، این کار فقط در انواع پیاده سازی کننده `Unpin` قابل انجام است:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // برای تماس با `mem::replace` به یک مرجع قابل تغییر نیاز داریم.
/// // ما می توانیم با استناد به `Pin::deref_mut` چنین مرجعی را بدست آوریم ، اما این فقط به این دلیل امکان پذیر است که `String` `Unpin` را پیاده سازی می کند.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// این trait تقریباً برای هر نوع به طور خودکار اجرا می شود.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// یک نوع نشانگر که `Unpin` را اجرا نمی کند.
///
/// اگر یک نوع شامل `PhantomPinned` باشد ، به طور پیش فرض `Unpin` را اجرا نمی کند.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// پیاده سازی `Copy` برای انواع بدوی.
///
/// پیاده سازی هایی که در Rust قابل توصیف نیستند ، در `traits::SelectionContext::copy_clone_conditions()` در `rustc_trait_selection` اجرا می شوند.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// منابع مشترک قابل کپی هستند ، اما منابع قابل تغییر *نمی توانند*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}