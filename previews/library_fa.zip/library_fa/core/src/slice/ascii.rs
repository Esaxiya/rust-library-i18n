//! عملیات روی ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// بررسی می کند که آیا همه بایت های این برش در محدوده ASCII هستند.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// بررسی می کند که دو برش مطابق با حساسیت موردی ASCII نیستند.
    ///
    /// همان `to_ascii_lowercase(a) == to_ascii_lowercase(b)` است ، اما بدون اختصاص و کپی کردن افراد معاصر.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// این قطعه را به جای بزرگ معادل ASCII تبدیل می کند.
    ///
    /// حروف ASCII 'a' تا 'z' با 'A' تا 'Z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بازگرداندن مقدار بزرگ بزرگ بدون تغییر مقدار موجود ، از [`to_ascii_uppercase`] استفاده کنید.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// این قطعه را به معادل کوچک حروف ASCII درجا تبدیل می کند.
    ///
    /// حروف ASCII 'A' تا 'Z' با 'a' تا 'z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بازگرداندن مقدار کوچک جدید بدون تغییر مقدار موجود ، از [`to_ascii_lowercase`] استفاده کنید.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `true` را در صورت وجود هر بایت در کلمه `v` غیرحرفه ای برمی گرداند (>=128).
/// Snarfed از `../str/mod.rs` ، که چیزی مشابه برای اعتبار سنجی utf8 انجام می دهد.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// تست ASCII بهینه شده که به جای عملیات بایت در یک زمان (در صورت امکان) از عملیات استفاده همزمان استفاده خواهد کرد.
///
/// الگوریتمی که ما در اینجا استفاده می کنیم بسیار ساده است.اگر `s` خیلی کوتاه است ، ما فقط هر بایت را بررسی می کنیم و کار را با آن انجام می دهیم.در غیر این صورت:
///
/// - اولین بار را با بار ناموزون بخوانید.
/// - نشانگر را تراز کنید ، کلمات بعدی را تا پایان با بارهای تراز شده بخوانید.
/// - آخرین `usize` را از `s` با بار غیر تراز شده بخوانید.
///
/// اگر هر یک از این بارها چیزی تولید کند که `contains_nonascii` (above) برای آن درست باشد ، پس می دانیم که جواب نادرست است.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // اگر از پیاده سازی کلمه در یک زمان چیزی بدست نمی آوریم ، دوباره به یک حلقه اسکالر برگردید.
    //
    // ما همچنین این کار را برای معماری هایی انجام می دهیم که `size_of::<usize>()` تراز کافی برای `usize` نباشد ، زیرا این یک مورد عجیب edge است.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // ما همیشه اولین کلمه را بدون تراز می خوانیم ، به معنی `align_offset` است
    // 0 ، برای خواندن تراز شده دوباره همان مقدار را می خوانیم.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // ایمنی: ما `len < USIZE_SIZE` را در بالا تأیید می کنیم.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // ما این را در بالا ، تا حدودی ضمنی بررسی کردیم.
    // توجه داشته باشید که `offset_to_aligned` یا `align_offset` یا `USIZE_SIZE` است ، هر دو مورد به طور صریح در بالا بررسی می شوند.
    //
    debug_assert!(offset_to_aligned <= len);

    // ایمنی: word_ptr (به طور صحیح تراز شده) استفاده از ptr است که ما برای خواندن آن استفاده می کنیم
    // تکه وسط برش.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` شاخص بایت `word_ptr` است ، که برای بررسی پایان حلقه استفاده می شود.
    let mut byte_pos = offset_to_aligned;

    // پارانویا در مورد تراز بودن بررسی کند ، زیرا ما در حال انجام یک گروه بار غیر مرتب هستیم.
    // هرچند در عمل وجود این اشکال در `align_offset` غیرممکن است.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // کلمات بعدی را تا آخرین کلمه تراز شده بخوانید ، به استثنای آخرین کلمه تراز شده به خودی خود که بعداً در بررسی دم انجام می شود ، اطمینان حاصل کنید که دم همیشه حداکثر یک `usize` برای branch `byte_pos == len` اضافی است.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // عقل سلیمی بررسی کنید که خوانده شده در مرز باشد
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // و این که فرضیات ما درباره `byte_pos` صدق می کند.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // ایمنی: می دانیم `word_ptr` به درستی تراز شده است (به همین دلیل
        // `align_offset`) ، و ما می دانیم که بین `word_ptr` و انتهای بایت به اندازه کافی بایت داریم
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // ایمنی: ما `byte_pos <= len - USIZE_SIZE` را می دانیم ، به این معنی
        // پس از این `add` ، `word_ptr` حداکثر یک پایان خواهد بود.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // عقل سالم برای اطمینان از اینکه فقط یک `usize` باقی مانده است.
    // این باید توسط شرایط حلقه ما تضمین شود.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SAFETY: این به `len >= USIZE_SIZE` متکی است ، که در ابتدا بررسی می کنیم.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}