// ignore-tidy-filelength

//! مدیریت برش و دستکاری.
//!
//! برای جزئیات بیشتر به [`std::slice`] مراجعه کنید.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// اجرای خالص mem0r rust ، برگرفته از rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// این عملکرد فقط عمومی است زیرا راهی دیگر برای واحد تست پورت آزمایشی وجود ندارد.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// تعداد عناصر موجود در برش را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SAFETY: صدای ثابت به این دلیل است که قسمت طول را به عنوان یک مقدار تغییر شکل می دهیم (که باید باشد)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // ایمنی: این ایمن است زیرا `&[T]` و `FatPtr<T>` طرح یکسانی دارند.
            // فقط `std` می تواند این ضمانت را ارائه دهد.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: با ثابت بودن `crate::ptr::metadata(self)` جایگزین آن شوید.
            // از زمان نگارش این ، خطای "Const-stable functions can only call other const-stable functions" ایجاد می شود.
            //

            // ایمنی: دسترسی به مقدار از اتحادیه `PtrRepr` از آنجا که * const T امن است
            // و PtrComponents<T>طرح حافظه یکسانی دارند.
            // فقط std می تواند این ضمانت را ارائه دهد.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// اگر طول برش 0 باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// اولین عنصر قطعه یا `None` را اگر خالی باشد برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// یک اشاره گر قابل تغییر به اولین عنصر قطعه یا `None` در صورت خالی بودن برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// اولین و بقیه عناصر قطعه یا `None` را اگر خالی باشد برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// اولین و بقیه عناصر قطعه یا `None` را اگر خالی باشد برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// آخرین و بقیه عناصر قطعه را باز می گرداند ، یا اگر `None` خالی باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// آخرین و بقیه عناصر قطعه را باز می گرداند ، یا اگر `None` خالی باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// آخرین عنصر قطعه یا `None` را اگر خالی باشد برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// یک نشانگر قابل تغییر به آخرین مورد موجود در قطعه برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// بسته به نوع نمایه ، مرجعی را به یک عنصر یا زیرشاخه برمی گرداند.
    ///
    /// - اگر موقعیتی به شما داده شود ، مرجعی را به عنصر موجود در آن موقعیت یا `None` را خارج از مرزها برمی گرداند.
    ///
    /// - اگر محدوده ای به شما داده شود ، زیرشاخه مربوط به آن دامنه یا `None` را در صورت خارج بودن از محدوده ، برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// بسته به نوع فهرست (به [`get`] مراجعه کنید) یا `None` در صورت خارج بودن محدوده ، یک ارجاع قابل تغییر به یک عنصر یا زیرشاخه برمی گرداند.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// بدون انجام بررسی مرزها ، مرجعی را به یک عنصر یا زیرشاخه برمی گرداند.
    ///
    /// برای یک گزینه ایمن به [`get`] مراجعه کنید.
    ///
    /// # Safety
    ///
    /// فراخوانی این روش با شاخص خارج از مرزها *[رفتار تعریف نشده]* است حتی اگر از مرجع حاصله استفاده نشود.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // ایمنی: تماس گیرنده باید بیشتر موارد ایمنی `get_unchecked` را حفظ کند.
        // این قطعه قابل استناد است زیرا `self` یک مرجع ایمن است.
        // اشاره گر برگشتی ایمن است زیرا ضمانت `SliceIndex` باید این را تضمین کند.
        unsafe { &*index.get_unchecked(self) }
    }

    /// بدون انجام بررسی مرزها ، یک ارجاع قابل تغییر به یک عنصر یا زیرشاخه را برمی گرداند.
    ///
    /// برای یک گزینه ایمن به [`get_mut`] مراجعه کنید.
    ///
    /// # Safety
    ///
    /// فراخوانی این روش با شاخص خارج از مرزها *[رفتار تعریف نشده]* است حتی اگر از مرجع حاصله استفاده نشود.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // ایمنی: تماس گیرنده باید الزامات ایمنی `get_unchecked_mut` را رعایت کند.
        // این قطعه قابل استناد است زیرا `self` یک مرجع ایمن است.
        // اشاره گر برگشتی ایمن است زیرا ضمانت `SliceIndex` باید این را تضمین کند.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// یک نشانگر خام را به بافر برش برمی گرداند.
    ///
    /// تماس گیرنده باید اطمینان حاصل کند که قطعه از اشاره گر این عملکرد باز می ماند ، در غیر این صورت در انتها به زباله اشاره می کند.
    ///
    /// تماس گیرنده همچنین باید اطمینان حاصل کند که حافظه ای که اشاره گر (non-transitively) به آن نشان می دهد ، هرگز با استفاده از این اشاره گر یا هر اشاره گر مشتق شده از آن ، نوشته نمی شود (به جز داخل `UnsafeCell`).
    /// اگر می خواهید محتوای برش را جهش دهید ، از [`as_mut_ptr`] استفاده کنید.
    ///
    /// تغییر ظرفی که توسط این برش ارجاع می شود ممکن است باعث شود که بافر آن دوباره تخصیص یابد ، که همین امر باعث می شود هر اشاره گر به آن نامعتبر باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// یک نشانگر قابل تغییر ناامن را به بافر قطعه برمی گرداند.
    ///
    /// تماس گیرنده باید اطمینان حاصل کند که قطعه از اشاره گر این عملکرد باز می ماند ، در غیر این صورت در انتها به زباله اشاره می کند.
    ///
    /// تغییر ظرفی که توسط این برش ارجاع می شود ممکن است باعث شود که بافر آن دوباره تخصیص یابد ، که همین امر باعث می شود هر اشاره گر به آن نامعتبر باشد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// دو نشانگر خام را که برش داده اند برمی گرداند.
    ///
    /// دامنه برگشتی نیمه باز است ، به این معنی که نشانگر انتهایی *یک گذشته* آخرین عنصر قطعه را نشان می دهد.
    /// به این ترتیب ، یک برش خالی با دو نشانگر مساوی نشان داده می شود و اختلاف بین دو اشاره گر نشان دهنده اندازه برش است.
    ///
    /// برای اخطارهای استفاده از این نشانگرها به [`as_ptr`] مراجعه کنید.اشاره گر انتهایی احتیاط بیشتری لازم دارد ، زیرا به عنصر معتبری در برش اشاره نمی کند.
    ///
    /// این عملکرد برای تعامل با رابط های خارجی که از دو اشاره گر برای اشاره به طیف وسیعی از عناصر در حافظه استفاده می کنند ، مفید است ، همانطور که در C++ معمول است.
    ///
    ///
    /// همچنین می توان بررسی کرد که آیا اشاره گر به یک عنصر به عنصری از این برش اشاره دارد:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // ایمنی: `add` در اینجا ایمن است ، زیرا:
        //
        //   - هر دو اشاره گر بخشی از یک جسم هستند ، زیرا اشاره مستقیم به جسم نیز مهم است.
        //
        //   - اندازه قطعه هرگز از isize::MAX بایت بزرگتر نیست ، همانطور که در اینجا ذکر شده است:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - هیچ درگیری وجود ندارد ، زیرا برشها از انتهای فضای آدرس عبور نمی کنند.
        //
        // به اسناد pointer::add مراجعه کنید.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// دو نشانگر تغییرناپذیر ناامن را که برش داده اند برمی گرداند.
    ///
    /// دامنه برگشتی نیمه باز است ، به این معنی که نشانگر انتهایی *یک گذشته* آخرین عنصر قطعه را نشان می دهد.
    /// به این ترتیب ، یک برش خالی با دو نشانگر مساوی نشان داده می شود و اختلاف بین دو اشاره گر نشان دهنده اندازه برش است.
    ///
    /// برای اخطارهای استفاده از این نشانگرها به [`as_mut_ptr`] مراجعه کنید.
    /// اشاره گر انتهایی احتیاط بیشتری لازم دارد ، زیرا به عنصر معتبری در برش اشاره نمی کند.
    ///
    /// این عملکرد برای تعامل با رابط های خارجی که از دو اشاره گر برای اشاره به طیف وسیعی از عناصر در حافظه استفاده می کنند ، مفید است ، همانطور که در C++ معمول است.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // ایمنی: برای اینکه `add` در اینجا بی خطر است به as_ptr_range() بالا مراجعه کنید.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// تعویض دو عنصر در برش.
    ///
    /// # Arguments
    ///
    /// * a ، شاخص عنصر اول
    /// * ب ، شاخص عنصر دوم
    ///
    /// # Panics
    ///
    /// Panics اگر `a` یا `b` خارج از محدوده باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // نمی توانید از یک vector دو وام قابل تغییر بگیرید ، بنابراین به جای آن از نشانگرهای خام استفاده کنید.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // ایمنی: `pa` و `pb` از منابع قابل تغییر و ایمن ایجاد شده و ارجاع می شوند
        // به عناصر موجود در قطعه و بنابراین معتبر و تراز شده تضمین می شوند.
        // توجه داشته باشید که دسترسی به عناصر پشت `a` و `b` بررسی شده است و در صورت خارج بودن از محدوده panic خواهد بود.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// ترتیب عناصر موجود در برش را در جای خود معکوس می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // برای انواع بسیار کوچک ، همه افراد در مسیر عادی خوانده می شوند عملکرد ضعیفی دارند.
        // با بارگذاری یک تکه بزرگتر و برگرداندن یک ثبت نام ، می توانیم بهتر عمل کنیم ، با توجه به load/store بدون ترازوی کارآمد.
        //

        // در حالت ایده آل ، LLVM این کار را برای ما انجام می دهد ، زیرا بهتر از ما می داند که آیا خواندن های غیرهمسطح کارآمد هستند (به عنوان مثال این تغییر بین نسخه های مختلف ARM است) و اینکه بهترین اندازه تکه چه اندازه است.
        // متأسفانه ، از LLVM 4.0 (2017-05) فقط حلقه را باز می کند ، بنابراین ما باید این کار را خودمان انجام دهیم.
        // (فرضیه: معکوس مشکل است زیرا دو طرف می توانند به طور متفاوت تراز شوند-زمانی که طول فرد عجیب باشد-بنابراین هیچ راهی برای انتشار مقدمه و پس زمینه برای استفاده از SIMD کاملاً تراز وسط وجود ندارد).
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // از llvm.bswap ذاتی برای معکوس کردن u8 ها در یک میزان استفاده استفاده کنید
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // ایمنی: چندین چیز برای بررسی وجود دارد:
                //
                // - توجه داشته باشید که `chunk` به دلیل بررسی cfg در بالا 4 یا 8 است.بنابراین `chunk - 1` مثبت است.
                // - نمایه سازی با شاخص `i` به عنوان ضامن بررسی حلقه خوب است
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - نمایه سازی با شاخص `ln - i - chunk = ln - (i + chunk)` خوب است:
                //   - `i + chunk > 0` پیش پا افتاده است
                //   - بررسی حلقه تضمین می کند:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln` ، بنابراین تفریق کم نمی کند.
                // - تماس های `read_unaligned` و `write_unaligned` خوب هستند:
                //   - `pa` به شاخص `i` كه در آن `i < ln / 2 - (chunk - 1)` (به بالا مراجعه كنید) و `pb` به شاخص `ln - i - chunk` اشاره می كند ، بنابراین هر دو حداقل `chunk` بایت دورتر از انتهای `self` هستند.
                //
                //   - هر حافظه اولیه `usize` معتبر است.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // برای معکوس کردن u16 ها در u32 از rotate-by-16 استفاده کنید
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // ایمنی: u32 بدون تراز را می توان از `i` خواند اگر `i + 1 < ln`
                // (و بدیهی است `i < ln`) ، زیرا هر عنصر 2 بایت است و ما 4 را می خوانیم.
                //
                // `i + chunk - 1 < ln / 2` # در حالی که شرط
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // از آنجا که کمتر از طول تقسیم بر 2 است ، بنابراین باید در مرزها باشد.
                //
                // این بدان معنی است که شرط `0 < i + chunk <= ln` همیشه رعایت می شود ، اطمینان حاصل کنید که از نشانگر `pb` می توانید با خیال راحت استفاده کنید.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // ایمنی: `i` نسبت به نیمی از طول برش پایین تر است
            // دسترسی به `i` و `ln - i - 1` بی خطر است (`i` از 0 شروع می شود و بیشتر از `ln / 2 - 1` نخواهد بود).
            // بنابراین نشانگرهای `pa` و `pb` معتبر و تراز هستند و می توان آنها را از روی آنها خواند و نوشت.
            //
            //
            unsafe {
                // مبادله ناامن برای جلوگیری از بررسی مرزها در مبادله مطمئن.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// یک تکرار کننده را برش می دهد.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// یک تکرار کننده را برمی گرداند که امکان تغییر هر مقدار را فراهم می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// یک تکرار کننده را روی تمام windows `size` مجاور برمی گرداند.
    /// windows همپوشانی دارد.
    /// اگر برش کوتاه تر از `size` باشد ، تکرار کننده هیچ مقداری را بر نمی گرداند.
    ///
    /// # Panics
    ///
    /// Panics اگر `size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// اگر قطعه کوتاهتر از `size` باشد:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// یک تکرار کننده را بیش از عناصر `chunk_size` برش برمی گرداند ، از ابتدای برش شروع می شود.
    ///
    /// تکه ها برش خورده اند و با هم تداخل ندارند.اگر `chunk_size` طول برش را تقسیم نکند ، آخرین قطعه طول `chunk_size` نخواهد داشت.
    ///
    /// به [`chunks_exact`] برای نسخه ای از این تکرار کننده مراجعه کنید که تکه هایی از عناصر دقیقاً `chunk_size` را بازگرداند و [`rchunks`] را برای همان تکرارکننده بازگرداند اما از انتهای قسمت شروع می شود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// یک تکرار کننده را بیش از عناصر `chunk_size` برش برمی گرداند ، از ابتدای برش شروع می شود.
    ///
    /// تکه ها برش های قابل تغییر هستند و همپوشانی ندارند.اگر `chunk_size` طول برش را تقسیم نکند ، آخرین قطعه طول `chunk_size` نخواهد داشت.
    ///
    /// به [`chunks_exact_mut`] برای نسخه ای از این تکرار کننده مراجعه کنید که تکه هایی از عناصر دقیقاً `chunk_size` را بازگرداند و [`rchunks_mut`] را برای همان تکرارکننده بازگرداند اما از انتهای قسمت شروع می شود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// یک تکرار کننده را بیش از عناصر `chunk_size` برش برمی گرداند ، از ابتدای برش شروع می شود.
    ///
    /// تکه ها برش خورده اند و با هم تداخل ندارند.
    /// اگر `chunk_size` طول برش را تقسیم نکند ، آخرین عناصر `chunk_size-1` حذف شده و می توانند از عملکرد `remainder` تکرار کننده بازیابی شوند.
    ///
    ///
    /// با توجه به اینکه هر قطعه دقیقاً دارای عناصر `chunk_size` است ، کامپایلر اغلب می تواند کد بدست آمده را بهتر از [`chunks`] بهینه کند.
    ///
    /// به [`chunks`] برای نسخه ای از این تکرارکننده مراجعه کنید که باقیمانده را نیز به عنوان قطعه کوچکتر و [`rchunks_exact`] را برای همان تکرار کننده باز می گرداند اما از انتهای قسمت شروع می شود.
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// یک تکرار کننده را بیش از عناصر `chunk_size` برش برمی گرداند ، از ابتدای برش شروع می شود.
    ///
    /// تکه ها برش های قابل تغییر هستند و همپوشانی ندارند.
    /// اگر `chunk_size` طول برش را تقسیم نکند ، آخرین عناصر `chunk_size-1` حذف شده و می توانند از عملکرد `into_remainder` تکرار کننده بازیابی شوند.
    ///
    ///
    /// با توجه به اینکه هر قطعه دقیقاً دارای عناصر `chunk_size` است ، کامپایلر اغلب می تواند کد بدست آمده را بهتر از [`chunks_mut`] بهینه کند.
    ///
    /// به [`chunks_mut`] برای نسخه ای از این تکرارکننده مراجعه کنید که باقیمانده را نیز به عنوان قطعه کوچکتر و [`rchunks_exact_mut`] را برای همان تکرار کننده باز می گرداند اما از انتهای قسمت شروع می شود.
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// با فرض اینکه هیچ باقیمانده ای وجود نداشته باشد ، برش را به برشی از آرایه های عنصر `N` تقسیم می کند.
    ///
    ///
    /// # Safety
    ///
    /// این فقط زمانی می تواند نامیده شود
    /// - این برش دقیقاً به تکه های عنصر `N` تقسیم می شود (معروف به `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // ایمنی: تکه های 1 عنصر هرگز باقیمانده ندارند
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // ایمنی: طول برش (6) مضربی از 3 است
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // اینها نامعلوم است:
    /// // اجازه دهید تکه ها: &[[_؛5]]= slice.as_chunks_unchecked()//طول قطعه مضربی از 5 قطعه اجازه نیست:&[[_ _0]]= slice.as_chunks_unchecked()//قطعه هایی با طول صفر هرگز مجاز نیستند
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ایمنی: پیش شرط ما دقیقاً همان چیزی است که برای فراخوانی این مورد لازم است
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ایمنی: ما برشی از عناصر `new_len * N` را درون آن قرار می دهیم
        // یک تکه از `new_len` تعداد زیادی عنصر `N`
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// برش را به یک قطعه از آرایه های عنصر `N` تقسیم می کند ، از ابتدای برش شروع می شود ، و یک قطعه باقیمانده با طول دقیقاً کمتر از `N`.
    ///
    ///
    /// # Panics
    ///
    /// اگر `N` 0 باشد Panics احتمالاً قبل از تثبیت این روش به یک خطای زمان کامپایل تغییر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // ایمنی: ما در حال حاضر برای صفر وحشت زده ایم ، و ساخت آن را تضمین می کند
        // که طول زیرشاخه مضربی از N است.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// برش را به برشی از آرایه های عنصر `N` تقسیم می کند که از انتهای برش شروع می شود و یک قطعه باقیمانده با طول دقیقاً کمتر از `N`.
    ///
    ///
    /// # Panics
    ///
    /// اگر `N` 0 باشد Panics احتمالاً قبل از تثبیت این روش به یک خطای زمان کامپایل تغییر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // ایمنی: ما در حال حاضر برای صفر وحشت زده ایم ، و ساخت آن را تضمین می کند
        // که طول زیرشاخه مضربی از N است.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// یک تکرار کننده را بیش از عناصر `N` برش برمی گرداند ، از ابتدای برش شروع می شود.
    ///
    /// تکه ها منابع آرایه ای هستند و همپوشانی ندارند.
    /// اگر `N` طول برش را تقسیم نکند ، آخرین عناصر `N-1` حذف شده و می توانند از عملکرد `remainder` تکرار کننده بازیابی شوند.
    ///
    ///
    /// این روش معادل عمومی ساخت [`chunks_exact`] است.
    ///
    /// # Panics
    ///
    /// اگر `N` 0 باشد Panics احتمالاً قبل از تثبیت این روش به یک خطای زمان کامپایل تغییر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// با فرض اینکه هیچ باقیمانده ای وجود نداشته باشد ، برش را به برشی از آرایه های عنصر `N` تقسیم می کند.
    ///
    ///
    /// # Safety
    ///
    /// این فقط زمانی می تواند نامیده شود
    /// - این برش دقیقاً به تکه های عنصر `N` تقسیم می شود (معروف به `self.len() % N == 0`)).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // ایمنی: تکه های 1 عنصر هرگز باقیمانده ندارند
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // ایمنی: طول برش (6) مضربی از 3 است
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // اینها نامعلوم است:
    /// // اجازه دهید تکه ها: &[[_؛5]]= slice.as_chunks_unchecked_mut()//طول قطعه مضربی از 5 قطعه اجازه نیست:&[[_؛0]]= slice.as_chunks_unchecked_mut()//قطعه هایی با طول صفر هرگز مجاز نیستند
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // ایمنی: پیش شرط ما دقیقاً همان چیزی است که برای فراخوانی این مورد لازم است
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // ایمنی: ما برشی از عناصر `new_len * N` را درون آن قرار می دهیم
        // یک تکه از `new_len` تعداد زیادی عنصر `N`
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// برش را به یک قطعه از آرایه های عنصر `N` تقسیم می کند ، از ابتدای برش شروع می شود ، و یک قطعه باقیمانده با طول دقیقاً کمتر از `N`.
    ///
    ///
    /// # Panics
    ///
    /// اگر `N` 0 باشد Panics احتمالاً قبل از تثبیت این روش به یک خطای زمان کامپایل تغییر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // ایمنی: ما در حال حاضر برای صفر وحشت زده ایم ، و ساخت آن را تضمین می کند
        // که طول زیرشاخه مضربی از N است.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// برش را به برشی از آرایه های عنصر `N` تقسیم می کند که از انتهای برش شروع می شود و یک قطعه باقیمانده با طول دقیقاً کمتر از `N`.
    ///
    ///
    /// # Panics
    ///
    /// اگر `N` 0 باشد Panics احتمالاً قبل از تثبیت این روش به یک خطای زمان کامپایل تغییر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // ایمنی: ما در حال حاضر برای صفر وحشت زده ایم ، و ساخت آن را تضمین می کند
        // که طول زیرشاخه مضربی از N است.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// یک تکرار کننده را بیش از عناصر `N` برش برمی گرداند ، از ابتدای برش شروع می شود.
    ///
    /// تکه ها منابع آرایه قابل تغییر هستند و همپوشانی ندارند.
    /// اگر `N` طول برش را تقسیم نکند ، آخرین عناصر `N-1` حذف شده و می توانند از عملکرد `into_remainder` تکرار کننده بازیابی شوند.
    ///
    ///
    /// این روش معادل عمومی ساخت [`chunks_exact_mut`] است.
    ///
    /// # Panics
    ///
    /// اگر `N` 0 باشد Panics احتمالاً قبل از تثبیت این روش به یک خطای زمان کامپایل تغییر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// یک تکرار کننده را با هم تداخل windows عناصر `N` برش برمی گرداند ، از ابتدای برش شروع می شود.
    ///
    ///
    /// این معادل عمومی کلی [`windows`] است.
    ///
    /// اگر `N` بزرگتر از اندازه قطعه باشد ، هیچ windows بر نمی گردد.
    ///
    /// # Panics
    ///
    /// Panics اگر `N` 0 باشد.
    /// قبل از تثبیت این روش ، احتمالاً این بررسی به خطای زمان کامپایل تغییر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// یک تکرار کننده را همزمان بر روی عناصر `chunk_size` برش برمی گرداند ، از انتهای برش شروع می شود.
    ///
    /// تکه ها برش خورده اند و با هم تداخل ندارند.اگر `chunk_size` طول برش را تقسیم نکند ، آخرین قطعه طول `chunk_size` نخواهد داشت.
    ///
    /// به [`rchunks_exact`] برای نسخه ای از این تکرارکننده مراجعه کنید که تکه هایی از عناصر دقیقاً `chunk_size` را بازگرداند و [`chunks`] را برای همان تکرار کننده بازگرداند اما از ابتدای قطعه شروع شود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// یک تکرار کننده را همزمان بر روی عناصر `chunk_size` برش برمی گرداند ، از انتهای برش شروع می شود.
    ///
    /// تکه ها برش های قابل تغییر هستند و همپوشانی ندارند.اگر `chunk_size` طول برش را تقسیم نکند ، آخرین قطعه طول `chunk_size` نخواهد داشت.
    ///
    /// به [`rchunks_exact_mut`] برای نسخه ای از این تکرارکننده مراجعه کنید که تکه هایی از عناصر دقیقاً `chunk_size` را بازگرداند و [`chunks_mut`] را برای همان تکرار کننده بازگرداند اما از ابتدای قطعه شروع شود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// یک تکرار کننده را همزمان بر روی عناصر `chunk_size` برش برمی گرداند ، از انتهای برش شروع می شود.
    ///
    /// تکه ها برش خورده اند و با هم تداخل ندارند.
    /// اگر `chunk_size` طول برش را تقسیم نکند ، آخرین عناصر `chunk_size-1` حذف شده و می توانند از عملکرد `remainder` تکرار کننده بازیابی شوند.
    ///
    /// با توجه به اینکه هر قطعه دقیقاً دارای عناصر `chunk_size` است ، کامپایلر اغلب می تواند کد بدست آمده را بهتر از [`chunks`] بهینه کند.
    ///
    /// به [`rchunks`] برای نسخه ای از این تکرارکننده مراجعه کنید که باقیمانده را نیز به عنوان یک قطعه کوچکتر و [`chunks_exact`] را برای همان تکرارکننده باز می گرداند اما از ابتدای قطعه شروع می شود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// یک تکرار کننده را همزمان بر روی عناصر `chunk_size` برش برمی گرداند ، از انتهای برش شروع می شود.
    ///
    /// تکه ها برش های قابل تغییر هستند و همپوشانی ندارند.
    /// اگر `chunk_size` طول برش را تقسیم نکند ، آخرین عناصر `chunk_size-1` حذف شده و می توانند از عملکرد `into_remainder` تکرار کننده بازیابی شوند.
    ///
    /// با توجه به اینکه هر قطعه دقیقاً دارای عناصر `chunk_size` است ، کامپایلر اغلب می تواند کد بدست آمده را بهتر از [`chunks_mut`] بهینه کند.
    ///
    /// به [`rchunks_mut`] برای نسخه ای از این تکرارکننده مراجعه کنید که باقیمانده را نیز به عنوان یک قطعه کوچکتر و [`chunks_exact_mut`] را برای همان تکرارکننده باز می گرداند اما از ابتدای قطعه شروع می شود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `chunk_size` 0 باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// یک تکرار کننده را بر روی برش برمی گرداند و اجراهای غیر همپوشانی عناصر را با استفاده از محمول برای جدا کردن آنها تولید می کند.
    ///
    /// محمول بر روی دو عنصر به دنبال خود فراخوانی می شود ، به این معنی که محمول در `slice[0]` و `slice[1]` سپس در `slice[1]` و `slice[2]` و غیره فراخوانده می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از این روش می توان برای استخراج زیرمجموعه های طبقه بندی شده استفاده کرد:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// یک تکرار کننده را برش می دهد و با استفاده از محمول برای جدا کردن ، اجراهای تغییر پذیر غیر همپوشانی عناصر را تولید می کند.
    ///
    /// محمول بر روی دو عنصر به دنبال خود فراخوانی می شود ، به این معنی که محمول در `slice[0]` و `slice[1]` سپس در `slice[1]` و `slice[2]` و غیره فراخوانده می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از این روش می توان برای استخراج زیرمجموعه های طبقه بندی شده استفاده کرد:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// در یک شاخص یک قطعه را به دو قسمت تقسیم می کند.
    ///
    /// شاخص اول شامل تمام شاخص های `[0, mid)` (به استثنای شاخص `mid` خود) و شاخص دوم شامل تمام شاخص های `[mid, len)` (به استثنای شاخص `len` خود) خواهد بود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `mid > len` باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // ایمنی: `[ptr; mid]` و `[mid; len]` داخل `self` است که
        // نیازهای `from_raw_parts_mut` را برآورده می کند.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// یک برش قابل تغییر را در یک شاخص به دو تقسیم می کند.
    ///
    /// شاخص اول شامل تمام شاخص های `[0, mid)` (به استثنای شاخص `mid` خود) و شاخص دوم شامل تمام شاخص های `[mid, len)` (به استثنای شاخص `len` خود) خواهد بود.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر `mid > len` باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // ایمنی: `[ptr; mid]` و `[mid; len]` داخل `self` است که
        // نیازهای `from_raw_parts_mut` را برآورده می کند.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// بدون بررسی مرزها ، یک برش را در یک شاخص به دو تقسیم می کند.
    ///
    /// شاخص اول شامل تمام شاخص های `[0, mid)` (به استثنای شاخص `mid` خود) و شاخص دوم شامل تمام شاخص های `[mid, len)` (به استثنای شاخص `len` خود) خواهد بود.
    ///
    ///
    /// برای یک گزینه ایمن به [`split_at`] مراجعه کنید.
    ///
    /// # Safety
    ///
    /// فراخوانی این روش با شاخص خارج از مرزها *[رفتار تعریف نشده]* است حتی اگر از مرجع حاصله استفاده نشود.تماس گیرنده باید اطمینان حاصل کند که `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // ایمنی: تماس گیرنده باید `0 <= mid <= self.len()` را بررسی کند
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// بدون بررسی مرزها ، یک برش قابل تغییر را در یک شاخص به دو تقسیم می کند.
    ///
    /// شاخص اول شامل تمام شاخص های `[0, mid)` (به استثنای شاخص `mid` خود) و شاخص دوم شامل تمام شاخص های `[mid, len)` (به استثنای شاخص `len` خود) خواهد بود.
    ///
    ///
    /// برای یک گزینه ایمن به [`split_at_mut`] مراجعه کنید.
    ///
    /// # Safety
    ///
    /// فراخوانی این روش با شاخص خارج از مرزها *[رفتار تعریف نشده]* است حتی اگر از مرجع حاصله استفاده نشود.تماس گیرنده باید اطمینان حاصل کند که `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // ایمنی: تماس گیرنده باید `0 <= mid <= self.len()` را بررسی کند.
        //
        // `[ptr; mid]` و `[mid; len]` با هم همپوشانی ندارند ، بنابراین بازگشت یک مرجع قابل تغییر خوب است.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// یک تکرار کننده را بر روی زیرمجموعه هایی که با عناصر منطبق با `pred` جدا شده اند برمی گرداند.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// اگر اولین عنصر مطابقت داشته باشد ، یک قطعه خالی اولین موردی است که توسط تکرار کننده برگردانده می شود.
    /// به همین ترتیب ، اگر آخرین عنصر موجود در قطعه مطابقت داشته باشد ، یک قطعه خالی آخرین موردی است که توسط تکرار کننده برگردانده می شود:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// اگر دو عنصر همسان مستقیماً در مجاورت یکدیگر باشند ، یک برش خالی بین آنها وجود دارد:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه های قابل تغییر که با عناصر منطبق با `pred` جدا شده اند ، برمی گرداند.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه هایی که با عناصر منطبق با `pred` جدا شده اند برمی گرداند.
    /// عنصر مطابق در انتهای زیرشاخه قبلی به عنوان یک خاتمه دهنده موجود است.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// اگر آخرین عنصر برش مطابقت داشته باشد ، آن عنصر پایان دهنده قطعه قبلی در نظر گرفته می شود.
    ///
    /// این قطعه آخرین موردی است که توسط تکرار کننده برگردانده شده است.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه های قابل تغییر که با عناصر منطبق با `pred` جدا شده اند ، برمی گرداند.
    /// عنصر همسان شده در زیرشاخه قبلی به عنوان یک پایان دهنده موجود است.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه هایی که با عناصر منطبق با `pred` از هم جدا شده اند ، برمی گرداند ، از انتهای قسمت شروع می شود و به عقب کار می کند.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// مانند `split()` ، اگر اولین یا آخرین عنصر مطابقت داشته باشد ، یک قطعه خالی اولین (یا آخرین) موردی است که توسط تکرار کننده برگردانده می شود.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه های قابل تغییر برمی گرداند که با عناصر منطبق با `pred` از هم جدا شده اند و از انتهای قطعه شروع می شوند و به عقب کار می کنند.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه هایی که با عناصر منطبق با `pred` از هم جدا شده اند باز می گرداند ، محدود به بازگشت حداکثر موارد `n`.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// آخرین عنصر برگردانده شده ، در صورت وجود ، حاوی باقی مانده قطعه خواهد بود.
    ///
    /// # Examples
    ///
    /// تقسیم برش را یک بار بر روی اعداد قابل تقسیم بر 3 (به عنوان مثال ، `[10, 40]` ، `[20, 60, 50]`) چاپ کنید:
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه هایی که با عناصر منطبق با `pred` از هم جدا شده اند باز می گرداند ، محدود به بازگشت حداکثر موارد `n`.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// آخرین عنصر برگردانده شده ، در صورت وجود ، حاوی باقی مانده قطعه خواهد بود.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه هایی که با عناصر منطبق با `pred` محدود به بازگشت حداکثر موارد `n` هستند ، برمی گرداند.
    /// این کار از انتهای برش شروع می شود و به عقب عمل می کند.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// آخرین عنصر برگردانده شده ، در صورت وجود ، حاوی باقی مانده قطعه خواهد بود.
    ///
    /// # Examples
    ///
    /// تقسیم برش را یک بار چاپ کنید ، از انتها شروع کنید ، با اعداد قابل تقسیم بر 3 (یعنی `[50]` ، `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// یک تکرار کننده را بر روی زیرمجموعه هایی که با عناصر منطبق با `pred` محدود به بازگشت حداکثر موارد `n` هستند ، برمی گرداند.
    /// این کار از انتهای برش شروع می شود و به عقب عمل می کند.
    /// عنصر مطابق در زیرمجموعه ها وجود ندارد.
    ///
    /// آخرین عنصر برگردانده شده ، در صورت وجود ، حاوی باقی مانده قطعه خواهد بود.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// اگر برش شامل عنصری با مقدار داده شده باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// اگر `&T` ندارید ، اما فقط `&U` دارید مانند `T: Borrow<U>` (مثلاً
    /// `رشته: قرض بگیرید<str>`) ، شما می توانید از `iter().any` استفاده کنید:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // قطعه `String`
    /// assert!(v.iter().any(|e| e == "hello")); // با `&str` جستجو کنید
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// اگر `needle` پیشوند قطعه باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// اگر `needle` یک قطعه خالی است ، همیشه `true` را برمی گرداند:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// اگر `needle` پسوند قطعه باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// اگر `needle` یک قطعه خالی است ، همیشه `true` را برمی گرداند:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// زیرشاخه ای را با پیشوند حذف شده برمی گرداند.
    ///
    /// اگر برش با `prefix` شروع شود ، پس از پیشوند ، پسوند فرعی را که در `Some` بسته بندی شده است ، برمی گرداند.
    /// اگر `prefix` خالی است ، برش اصلی را برمی گردانید.
    ///
    /// اگر قطعه با `prefix` شروع نشود ، `None` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // اگر و زمانی که SlicePattern پیچیده تر شود ، این عملکرد نیاز به بازنویسی دارد.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// یک فرعی را با پسوند حذف شده برمی گرداند.
    ///
    /// اگر برش با `suffix` خاتمه یابد ، زیرشاخه را قبل از پسوند ، در `Some` پیچیده ، برمی گرداند.
    /// اگر `suffix` خالی است ، برش اصلی را برمی گردانید.
    ///
    /// اگر برش به `suffix` ختم نشود ، `None` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // اگر و زمانی که SlicePattern پیچیده تر شود ، این عملکرد نیاز به بازنویسی دارد.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// باینری این قطعه مرتب شده را برای یک عنصر مشخص جستجو می کند.
    ///
    /// اگر مقدار پیدا شود ، [`Result::Ok`] بازگردانده می شود ، حاوی شاخص عنصر تطبیق.
    /// اگر چندین مسابقه وجود داشته باشد ، هر یک از مسابقات می تواند برگردانده شود.
    /// اگر مقدار پیدا نشد ، [`Result::Err`] بازگردانده می شود ، حاوی شاخصی که در آن می توان یک عنصر تطبیق را با حفظ نظم مرتب سازی شده وارد کرد.
    ///
    ///
    /// همچنین به [`binary_search_by`] ، [`binary_search_by_key`] و [`partition_point`] مراجعه کنید.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// مجموعه ای از چهار عنصر را جستجو می کند.
    /// اولین مورد با موقعیتی منحصر به فرد مشخص شده یافت می شود.دوم و سوم یافت نمی شود.چهارم می تواند با هر موقعیتی در `[1, 4]` مطابقت داشته باشد.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// اگر می خواهید با حفظ ترتیب مرتب سازی ، موردی را به vector مرتب شده وارد کنید:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// باینری این قطعه مرتب شده را با یک تطبیق کننده جستجو می کند.
    ///
    /// تابع مقایسه کننده باید یک سفارش سازگار با ترتیب مرتب کردن برش اساسی ایجاد کند ، و یک کد دستوری را که نشان می دهد آرگومان آن `Less` ، `Equal` یا `Greater` هدف مورد نظر است ، بازگرداند.
    ///
    ///
    /// اگر مقدار پیدا شود ، [`Result::Ok`] بازگردانده می شود ، حاوی شاخص عنصر تطبیق.اگر چندین مسابقه وجود داشته باشد ، هر یک از مسابقات می تواند برگردانده شود.
    /// اگر مقدار پیدا نشد ، [`Result::Err`] بازگردانده می شود ، حاوی شاخصی که در آن می توان یک عنصر تطبیق را با حفظ نظم مرتب سازی شده وارد کرد.
    ///
    /// همچنین به [`binary_search`] ، [`binary_search_by_key`] و [`partition_point`] مراجعه کنید.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// مجموعه ای از چهار عنصر را جستجو می کند.اولین مورد با موقعیتی منحصر به فرد مشخص شده یافت می شود.دوم و سوم یافت نمی شود.چهارم می تواند با هر موقعیتی در `[1, 4]` مطابقت داشته باشد.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // ایمنی: تماس توسط افراد زیر تغییر می کند:
            // - `mid >= 0`
            // - `mid < size`: `mid` توسط `[left; right)` محدود شده است.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // دلیل اینکه ما به جای تطبیق از جریان کنترل if/else استفاده می کنیم این است که مطابقت ترتیب کارها را مقایسه می کند که کاملاً حساس است.
            //
            // این x86 asm برای u8 است: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// باینری این قطعه مرتب شده را با یک تابع استخراج کلیدی جستجو می کند.
    ///
    /// فرض می کند که برش توسط کلید مرتب شده است ، به عنوان مثال با [`sort_by_key`] با استفاده از همان عملکرد استخراج کلید.
    ///
    /// اگر مقدار پیدا شود ، [`Result::Ok`] بازگردانده می شود ، حاوی شاخص عنصر تطبیق.
    /// اگر چندین مسابقه وجود داشته باشد ، هر یک از مسابقات می تواند برگردانده شود.
    /// اگر مقدار پیدا نشد ، [`Result::Err`] بازگردانده می شود ، حاوی شاخصی که در آن می توان یک عنصر تطبیق را با حفظ نظم مرتب سازی شده وارد کرد.
    ///
    ///
    /// همچنین به [`binary_search`] ، [`binary_search_by`] و [`partition_point`] مراجعه کنید.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// یک سری از چهار عنصر را در یک تکه از جفت ها مرتب می شود که بر اساس عناصر دوم آنها مرتب شده است.
    /// اولین مورد با موقعیتی منحصر به فرد مشخص شده یافت می شود.دوم و سوم یافت نمی شود.چهارم می تواند با هر موقعیتی در `[1, 4]` مطابقت داشته باشد.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links مجاز است زیرا `slice::sort_by_key` در crate `alloc` است و به همین ترتیب در هنگام ساخت `core` هنوز وجود ندارد.
    //
    // پیوندها به پایین دست crate: #74481.از آنجا که بدویها فقط در libstd (#73423) مستند شده اند ، در عمل هرگز منجر به خرابی پیوندها نمی شود.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// برش را مرتب می کند ، اما ممکن است ترتیب عناصر مساوی را حفظ نکند.
    ///
    /// این نوع ناپایدار است (یعنی ممکن است عناصر مساوی را مجدداً مرتب کنید) ، در محل (یعنی تخصیص نمی یابد) و *O*(*n*\*log(* n*)) در بدترین حالت).
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی مبتنی بر [pattern-defeating quicksort][pdqsort] توسط اورسون پیترز ساخته شده است که ترکیبی از میانگین متوسط سریع مسابقه quicksort تصادفی و سریعترین حالت heapsort است ، در حالی که برشهای با الگوهای خاص به زمان خطی می رسد.
    /// از برخی تصادفی سازی ها برای جلوگیری از موارد منحط استفاده می کند ، اما با یک seed ثابت همیشه رفتار تعیین کننده ای را ارائه می دهد.
    ///
    /// این معمولاً سریعتر از مرتب سازی پایدار است ، مگر در موارد خاص ، به عنوان مثال ، زمانی که برش از چندین توالی مرتب شده بهم پیوسته تشکیل شده باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// برش را با عملکرد مقایسه ای مرتب می کند ، اما ممکن است ترتیب عناصر مساوی را حفظ نکند.
    ///
    /// این نوع ناپایدار است (یعنی ممکن است عناصر مساوی را مجدداً مرتب کنید) ، در محل (یعنی تخصیص نمی یابد) و *O*(*n*\*log(* n*)) در بدترین حالت).
    ///
    /// تابع مقایسه کننده باید ترتیب کاملی برای عناصر موجود در برش تعریف کند.اگر ترتیب کامل نباشد ، ترتیب عناصر مشخص نیست.یک سفارش در صورت وجود یک سفارش کل است (برای همه `a` ، `b` و `c`):
    ///
    /// * کل و ضد متقارن: دقیقاً یکی از `a < b` ، `a == b` یا `a > b` درست است و
    /// * گذرا ، `a < b` و `b < c` حاوی `a < c` است.برای هر دو `==` و `>` باید همین مورد وجود داشته باشد.
    ///
    /// به عنوان مثال ، در حالی که [`f64`] [`Ord`] را به دلیل `NaN != NaN` پیاده سازی نمی کند ، وقتی می دانیم این تکه حاوی `NaN` نیست ، ما می توانیم از `partial_cmp` به عنوان عملکرد مرتب سازی خود استفاده کنیم.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی مبتنی بر [pattern-defeating quicksort][pdqsort] توسط اورسون پیترز ساخته شده است که ترکیبی از میانگین متوسط سریع مسابقه quicksort تصادفی و سریعترین حالت heapsort است ، در حالی که برشهای با الگوهای خاص به زمان خطی می رسد.
    /// از برخی تصادفی سازی ها برای جلوگیری از موارد منحط استفاده می کند ، اما با یک seed ثابت همیشه رفتار تعیین کننده ای را ارائه می دهد.
    ///
    /// این معمولاً سریعتر از مرتب سازی پایدار است ، مگر در موارد خاص ، به عنوان مثال ، زمانی که برش از چندین توالی مرتب شده بهم پیوسته تشکیل شده باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // مرتب سازی معکوس
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// برش را با عملکرد استخراج کلیدی مرتب می کند ، اما ممکن است ترتیب عناصر مساوی را حفظ نکند.
    ///
    /// این مرتب سازی ناپایدار است (یعنی ممکن است عناصر مساوی را دوباره مرتب کنید) ، در محل (یعنی تخصیص نمی یابد) و *O*(m\* * n *\* log(*n*)) در بدترین حالت ، که عملکرد اصلی *O* است (*متر*)
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی مبتنی بر [pattern-defeating quicksort][pdqsort] توسط اورسون پیترز ساخته شده است که ترکیبی از میانگین متوسط سریع مسابقه quicksort تصادفی و سریعترین حالت heapsort است ، در حالی که برشهای با الگوهای خاص به زمان خطی می رسد.
    /// از برخی تصادفی سازی ها برای جلوگیری از موارد منحط استفاده می کند ، اما با یک seed ثابت همیشه رفتار تعیین کننده ای را ارائه می دهد.
    ///
    /// با توجه به استراتژی اصلی تماس ، [`sort_unstable_by_key`](#method.sort_unstable_by_key) در مواردی که عملکرد کلید گران است ، احتمالاً کندتر از [`sort_by_cached_key`](#method.sort_by_cached_key) است.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// برش را دوباره مرتب کنید تا عنصر `index` در آخرین مرتب سازی قرار بگیرد.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// مرتب کردن برش با عملکرد مقایسه ای به گونه ای که عنصر در `index` در آخرین مرتب سازی قرار گیرد.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// مرتب کردن برش با عملکرد استخراج کلیدی به گونه ای که عنصر `index` در آخرین مرتب سازی قرار گیرد.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// برش را دوباره مرتب کنید تا عنصر `index` در آخرین مرتب سازی قرار بگیرد.
    ///
    /// این مرتب سازی خاصیت اضافی دارد که هر مقداری در موقعیت `i < index` کمتر یا برابر با هر مقداری در موقعیت `j > index` خواهد بود.
    /// علاوه بر این ، این مرتب سازی مجدد ناپایدار است (یعنی
    /// هر تعداد از عناصر مساوی ممکن است در موقعیت `index` قرار بگیرند) ، در جای خود (یعنی
    /// اختصاص نمی دهد) ، و *O*(*n*) در بدترین حالت.
    /// این تابع در کتابخانه های دیگر به عنوان "kth element" نیز شناخته می شود.
    /// این سه گانه از مقادیر زیر را برمی گرداند: همه عناصر کمتر از یک در شاخص داده شده ، مقدار در شاخص داده شده و همه عناصر بزرگتر از یک در شاخص داده شده.
    ///
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی براساس بخش انتخاب سریع همان الگوریتم quicksort استفاده شده برای [`sort_unstable`] است.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics هنگام `index >= len()` ، یعنی همیشه روی برشهای خالی panics است.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // میانه را پیدا کنید
    /// v.select_nth_unstable(2);
    ///
    /// // ما فقط تضمین می کنیم که برش بر اساس نحوه مرتب سازی درباره شاخص مشخص شده ، یکی از موارد زیر باشد.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// مرتب کردن برش با عملکرد مقایسه ای به گونه ای که عنصر در `index` در آخرین مرتب سازی قرار گیرد.
    ///
    /// این مرتب سازی خاصیت اضافی دارد که هر مقداری در موقعیت `i < index` با استفاده از عملکرد مقایسه کننده کمتر یا برابر با هر مقداری در موقعیت `j > index` خواهد بود.
    /// بعلاوه ، این مرتب سازی مجدد ناپایدار است (یعنی هر تعداد عنصر مساوی ممکن است در موقعیت `index` قرار گیرد) ، در جای خود (یعنی تخصیص نمی یابد) و *O*(*n*) در بدترین حالت است.
    /// این عملکرد در کتابخانه های دیگر با نام "kth element" نیز شناخته می شود.
    /// این یک سه گانه از مقادیر زیر را برمی گرداند: همه عناصر کمتر از یک در شاخص داده شده ، مقدار در شاخص داده شده و همه عناصر بزرگتر از یک در شاخص داده شده ، با استفاده از تابع مقایسه کننده ارائه شده.
    ///
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی براساس بخش انتخاب سریع همان الگوریتم quicksort استفاده شده برای [`sort_unstable`] است.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics هنگام `index >= len()` ، یعنی همیشه روی برشهای خالی panics است.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // میانه را طوری پیدا کنید که انگار برش ها به ترتیب نزولی مرتب شده اند.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // ما فقط تضمین می کنیم که برش بر اساس نحوه مرتب سازی درباره شاخص مشخص شده ، یکی از موارد زیر باشد.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// مرتب کردن برش با عملکرد استخراج کلیدی به گونه ای که عنصر `index` در آخرین مرتب سازی قرار گیرد.
    ///
    /// این مرتب سازی دارای ویژگی اضافی است که هر مقدار در موقعیت `i < index` با استفاده از عملکرد استخراج کلید ، در مقادیر `j > index` کمتر یا برابر با آن خواهد بود.
    /// بعلاوه ، این مرتب سازی مجدد ناپایدار است (یعنی هر تعداد عنصر مساوی ممکن است در موقعیت `index` قرار گیرد) ، در جای خود (یعنی تخصیص نمی یابد) و *O*(*n*) در بدترین حالت است.
    /// این عملکرد در کتابخانه های دیگر با نام "kth element" نیز شناخته می شود.
    /// این سه گانه از مقادیر زیر را برمی گرداند: همه عناصر کمتر از یک در شاخص داده شده ، مقدار در شاخص داده شده و همه عناصر بزرگتر از یک در شاخص داده شده ، با استفاده از تابع استخراج کلید ارائه شده.
    ///
    ///
    /// # اجرای فعلی
    ///
    /// الگوریتم فعلی براساس بخش انتخاب سریع همان الگوریتم quicksort استفاده شده برای [`sort_unstable`] است.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics هنگام `index >= len()` ، یعنی همیشه روی برشهای خالی panics است.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // میانه را برگردانید مثل اینکه آرایه بر اساس مقدار مطلق مرتب شده باشد.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // ما فقط تضمین می کنیم که برش بر اساس نحوه مرتب سازی درباره شاخص مشخص شده ، یکی از موارد زیر باشد.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// با توجه به اجرای [`PartialEq`] trait ، تمام عناصر تکراری متوالی را به انتهای قطعه منتقل می کند.
    ///
    ///
    /// دو برش برمی گرداند.مورد اول شامل هیچ عنصر تکراری متوالی نیست.
    /// مورد دوم شامل همه موارد تکراری و بدون ترتیب مشخص است.
    ///
    /// اگر برش مرتب شود ، اولین قطعه برگردانده شده فاقد نسخه تکراری است.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// همه عناصر متوالی به جز اول را به انتهای قطعه برطرف می کند که یک رابطه برابری داده شده را برآورده می کند.
    ///
    /// دو برش برمی گرداند.مورد اول شامل هیچ عنصر تکراری متوالی نیست.
    /// مورد دوم شامل همه موارد تکراری و بدون ترتیب مشخص است.
    ///
    /// تابع `same_bucket` به دو عنصر از قطعه منتقل می شود و باید تعیین کند که آیا عناصر برابر هستند.
    /// عناصر به ترتیب مخالف ترتیب خود در قطعه منتقل می شوند ، بنابراین اگر `same_bucket(a, b)` `true` را بازگرداند ، `a` در انتهای قطعه منتقل می شود.
    ///
    ///
    /// اگر برش مرتب شود ، اولین قطعه برگردانده شده فاقد نسخه تکراری است.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // اگرچه ما به `self` اشاره قابل تغییر داریم ، اما نمی توانیم تغییرات * خودسرانه ایجاد کنیم.تماس های `same_bucket` می تواند panic باشد ، بنابراین باید اطمینان حاصل کنیم که قطعه در هر زمان در وضعیت معتبری قرار دارد.
        //
        // روشی که ما از عهده این کار بر می آییم با استفاده از مبادله است.ما تمام عناصر را تکرار می کنیم ، هرچه پیش می رویم مبادله می شویم تا در انتها عناصری که می خواهیم نگه داریم در جلو قرار بگیرند ، و کسانی که می خواهیم آنها را رد کنیم در عقب هستند.
        // سپس می توانیم قطعه را تقسیم کنیم.
        // این عملیات هنوز `O(n)` است.
        //
        // مثال: ما از این حالت شروع می کنیم ، جایی که `r` "بعدی" را نشان می دهد
        // خواندن "و `w` نشان دهنده" next_write "است.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // با مقایسه self[r] در برابر خود [w-1] ، این یک نسخه تکراری نیست ، بنابراین ما self[r] و self[w] را با یکدیگر عوض می کنیم (هیچ تأثیری به عنوان r==w ندارد) و سپس هر دو r و w را افزایش می دهیم ، با این کار:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // با مقایسه self[r] در برابر خود [w-1] ، این مقدار تکراری است ، بنابراین ما `r` را افزایش می دهیم اما همه موارد دیگر را بدون تغییر می گذاریم:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // با مقایسه self[r] در برابر خود [w-1] ، این یک نسخه تکراری نیست ، بنابراین self[r] و self[w] را عوض کنید و r و w را پیش ببرید:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // تکراری نیست ، تکرار کنید:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // کپی ، قطعه advance r. End.تقسیم در w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // ایمنی: شرایط `while` `next_read` و `next_write` را تضمین می کند
        // کمتر از `len` هستند ، بنابراین در داخل `self` هستند.
        // `prev_ptr_write` قبل از `ptr_write` به یک عنصر اشاره می کند ، اما `next_write` از 1 شروع می شود ، بنابراین `prev_ptr_write` هرگز کمتر از 0 نیست و در داخل برش قرار دارد.
        // این شرایط برای مراجعه مجدد به `ptr_read` ، `prev_ptr_write` و `ptr_write` و استفاده از `ptr.add(next_read)` ، `ptr.add(next_write - 1)` و `prev_ptr_write.offset(1)` را برآورده می کند.
        //
        //
        // `next_write` همچنین حداکثر یک بار در هر حلقه افزایش می یابد ، به این معنی که هیچ عنصری در صورت نیاز به مبادله حذف نمی شود.
        //
        // `ptr_read` و `prev_ptr_write` هرگز به همان عنصر اشاره نمی کنند.این برای ایمن بودن `&mut *ptr_read`، `&mut* prev_ptr_write` لازم است.
        // توضیح این است که `next_read >= next_write` همیشه درست است ، بنابراین `next_read > next_write - 1` نیز درست است.
        //
        //
        //
        //
        //
        unsafe {
            // با استفاده از اشاره گرهای خام از بررسی محدودیت ها خودداری کنید.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// همه عناصر متوالی به جز اول را به انتهای قطعه منتقل می کند که به همان کلید حل می شوند.
    ///
    ///
    /// دو برش برمی گرداند.مورد اول شامل هیچ عنصر تکراری متوالی نیست.
    /// مورد دوم شامل همه موارد تکراری و بدون ترتیب مشخص است.
    ///
    /// اگر برش مرتب شود ، اولین قطعه برگردانده شده فاقد نسخه تکراری است.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// برش را در جای خود بچرخانید تا اولین عناصر `mid` برش به انتها منتقل شوند در حالی که آخرین عناصر `self.len() - mid` به جلو منتقل شوند.
    /// پس از فراخوانی `rotate_left` ، عنصری که قبلاً در فهرست `mid` قرار داشت ، به اولین عنصر در قطعه تبدیل خواهد شد.
    ///
    /// # Panics
    ///
    /// اگر `mid` از طول برش بیشتر باشد ، این عملکرد panic خواهد بود.توجه داشته باشید که `mid == self.len()` _not_ panic را انجام می دهد و یک چرخش بدون اپ است.
    ///
    /// # Complexity
    ///
    /// خطی می گیرد (به وقت `self.len()`)).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// چرخاندن زیرشاخه:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // ایمنی: محدوده `[p.add(mid) - mid, p.add(mid) + k)` به صورت پیش پا افتاده است
        // مطابق با `ptr_rotate` برای خواندن و نوشتن معتبر است.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// برش را در جای خود بچرخانید تا اولین عناصر `self.len() - k` برش به انتها منتقل شوند در حالی که آخرین عناصر `k` به جلو منتقل شوند.
    /// پس از فراخوانی `rotate_right` ، عنصری که قبلاً در فهرست `self.len() - k` قرار داشت ، به اولین عنصر در قطعه تبدیل خواهد شد.
    ///
    /// # Panics
    ///
    /// اگر `k` از طول برش بیشتر باشد ، این عملکرد panic خواهد بود.توجه داشته باشید که `k == self.len()` _not_ panic را انجام می دهد و یک چرخش بدون اپ است.
    ///
    /// # Complexity
    ///
    /// خطی می گیرد (به وقت `self.len()`)).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// چرخاندن زیرمجموعه:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // ایمنی: محدوده `[p.add(mid) - mid, p.add(mid) + k)` به صورت پیش پا افتاده است
        // مطابق با `ptr_rotate` برای خواندن و نوشتن معتبر است.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// با شبیه سازی `value` عناصر `self` را پر می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// `self` را با تماس با مكرر تعطیل ، با عناصر برگشتی پر می كند.
    ///
    /// این روش برای ایجاد مقادیر جدید از یک بسته استفاده می کند.اگر ترجیح می دهید [`Clone`] یک مقدار داده شده باشد ، از [`fill`] استفاده کنید.
    /// اگر می خواهید از [`Default`] trait برای تولید مقادیر استفاده کنید ، می توانید [`Default::default`] را به عنوان آرگومان منتقل کنید.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// عناصر را از `src` به `self` کپی می کند.
    ///
    /// طول `src` باید همان `self` باشد.
    ///
    /// اگر `T` `Copy` را پیاده سازی کند ، استفاده از [`copy_from_slice`] عملکرد بیشتری دارد.
    ///
    /// # Panics
    ///
    /// اگر طول دو برش متفاوت باشد ، این عملکرد panic خواهد بود.
    ///
    /// # Examples
    ///
    /// شبیه سازی دو عنصر از یک برش به دیگری:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // از آنجا که طول برش ها باید یکسان باشد ، ما قطعه منبع را از چهار عنصر به دو قطعه برش می دهیم.
    /// // اگر این کار را نکنیم panic خواهد بود.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust اعمال می کند که فقط می تواند یک مرجع قابل تغییر وجود داشته باشد که هیچ ارجاع تغییرناپذیری به داده خاصی در یک دامنه خاص نداشته باشد.
    /// به همین دلیل ، تلاش برای استفاده از `clone_from_slice` در یک برش منجر به خرابی کامپایل می شود:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// برای حل این مسئله ، می توانیم از [`split_at_mut`] برای ایجاد دو زیر برش مجزا از یک برش استفاده کنیم:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// با استفاده از memcpy همه عناصر را از `src` به `self` کپی می کند.
    ///
    /// طول `src` باید همان `self` باشد.
    ///
    /// اگر `T` `Copy` را اجرا نمی کند ، از [`clone_from_slice`] استفاده کنید.
    ///
    /// # Panics
    ///
    /// اگر طول دو برش متفاوت باشد ، این عملکرد panic خواهد بود.
    ///
    /// # Examples
    ///
    /// کپی کردن دو عنصر از یک برش در دیگری:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // از آنجا که طول برش ها باید یکسان باشد ، ما قطعه منبع را از چهار عنصر به دو قطعه برش می دهیم.
    /// // اگر این کار را نکنیم panic خواهد بود.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust اعمال می کند که فقط می تواند یک مرجع قابل تغییر وجود داشته باشد که هیچ ارجاع تغییرناپذیری به داده خاصی در یک دامنه خاص نداشته باشد.
    /// به همین دلیل ، تلاش برای استفاده از `copy_from_slice` در یک برش منجر به خرابی کامپایل می شود:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// برای حل این مسئله ، می توانیم از [`split_at_mut`] برای ایجاد دو زیر برش مجزا از یک برش استفاده کنیم:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // مسیر کد panic برای ایجاد نفخ در محل تماس ، یک عملکرد سرد قرار داده شد.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // ایمنی: `self` برای عناصر `self.len()` طبق تعریف معتبر است و `src` معتبر بود
        // بررسی می شود که طول یکسانی داشته باشد.
        // برش ها نمی توانند همپوشانی داشته باشند زیرا منابع قابل تغییر منحصر به فرد هستند.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// با استفاده از memmove عناصر را از یک قسمت برش به قسمت دیگری از خود کپی می کند.
    ///
    /// `src` محدوده `self` برای کپی از است.
    /// `dest` شاخص شروع دامنه `self` برای کپی کردن است ، که طول آن همان `src` خواهد بود.
    /// این دو دامنه ممکن است با هم همپوشانی داشته باشند.
    /// انتهای دو دامنه باید کمتر یا برابر با `self.len()` باشد.
    ///
    /// # Panics
    ///
    /// اگر یکی از دامنه ها از انتهای برش فراتر رود یا اگر پایان `src` قبل از شروع باشد ، این عملکرد panic خواهد بود.
    ///
    ///
    /// # Examples
    ///
    /// کپی کردن چهار بایت در یک قطعه:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // ایمنی: شرایط `ptr::copy` در بالا بررسی شده است ،
        // همانطور که برای `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// همه عناصر موجود در `self` را با عناصر موجود در `other` جابجا می کند.
    ///
    /// طول `other` باید همان `self` باشد.
    ///
    /// # Panics
    ///
    /// اگر طول دو برش متفاوت باشد ، این عملکرد panic خواهد بود.
    ///
    /// # Example
    ///
    /// مبادله دو عنصر در میان برشها:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust اعمال می کند که فقط می تواند یک اشاره قابل تغییر به یک قطعه خاص از داده در یک دامنه خاص داشته باشد.
    ///
    /// به همین دلیل ، تلاش برای استفاده از `swap_with_slice` در یک برش منجر به خرابی کامپایل می شود:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// برای حل این مسئله ، می توانیم از [`split_at_mut`] برای ایجاد دو زیر برش متمایز قابل تغییر از یک قطعه استفاده کنیم:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // ایمنی: `self` برای عناصر `self.len()` طبق تعریف معتبر است و `src` معتبر بود
        // بررسی می شود که طول یکسانی داشته باشد.
        // برش ها نمی توانند همپوشانی داشته باشند زیرا منابع قابل تغییر منحصر به فرد هستند.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// عملکرد برای محاسبه طول برش میانی و انتهایی برای `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // آنچه می خواهیم در مورد `rest` انجام دهیم این است که بفهمیم چه تعداد از U می توانیم در کمترین تعداد `T` قرار دهیم.
        //
        // و تعداد "T" برای هر "multiple" از این دست نیاز داریم.
        //
        // به عنوان مثال T=u8 U=u16 را در نظر بگیرید.سپس می توانیم 1 U در 2 Ts قرار دهیم.ساده.
        // اکنون ، برای مثال موردی را در نظر بگیرید که size_of: :<T>=16 ، اندازه_::<U>=24.</u>
        // ما می توانیم 2 Us را به جای هر 3 Ts در قطعه `rest` قرار دهیم.
        // کمی پیچیده تر.
        //
        // فرمول محاسبه این است:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // گسترش و ساده سازی:
        //
        // ما=اندازه_: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=اندازه_::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // خوشبختانه از آنجا که همه اینها دائماً ارزیابی می شوند ... عملکرد در اینجا مهم نیست!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // الگوریتم تکرار stein ما هنوز هم باید این `const fn` را بسازیم (و اگر این کار را انجام دهیم به الگوریتم بازگشتی برگردیم) زیرا تکیه بر llvm برای جمع کردن همه اینها خوب است ، این باعث ناراحتی من می شود.
            //
            //

            // ایمنی: `a` و `b` علامت گذاری می شوند که مقادیر غیر صفر باشند.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // تمام فاکتورهای 2 را از b حذف کنید
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // ایمنی: `b` غیر صفر است.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // با داشتن این دانش ، می توانیم پیدا کنیم که چه تعداد U می توانیم جای دهیم!
        let us_len = self.len() / ts * us;
        // و چند عدد T در قسمت انتهایی وجود خواهد داشت!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// قطعه را به قطعه ای از نوع دیگر منتقل کنید و اطمینان حاصل کنید که تراز بودن انواع آن حفظ می شود.
    ///
    /// این روش قطعه را به سه برش مشخص تقسیم می کند: پیشوند ، برش میانی درست از نوع جدید و قطعه پسوند.
    /// این روش ممکن است برش میانی را برای بیشترین طول ممکن برای یک نوع داده شده و برش ورودی ایجاد کند ، اما فقط عملکرد الگوریتم شما باید به آن بستگی داشته باشد ، نه به صحت آن.
    ///
    /// مجاز است که تمام داده های ورودی به عنوان قطعه پیشوند یا پسوند برگردانده شوند.
    ///
    /// هنگامی که عنصر ورودی `T` یا عنصر خروجی `U` اندازه صفر داشته باشند ، این روش هیچ هدفی ندارد و برش اصلی را بدون تقسیم چیزی برمی گرداند.
    ///
    /// # Safety
    ///
    /// این روش اساساً یک `transmute` با توجه به عناصر موجود در قطعه میانی برگشتی است ، بنابراین تمام هشدارهای معمول مربوط به `transmute::<T, U>` در اینجا نیز اعمال می شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // توجه داشته باشید که بیشتر این عملکرد بصورت ثابت ارزیابی می شود ،
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST ها را به طور خاص اداره کنید ، یعنی-به هیچ وجه آنها را اداره نکنید.
            return (self, &[], &[]);
        }

        // ابتدا ، دریابید که در چه مرحله ای بین قطعه اول و دوم تقسیم شده ایم.
        // با ptr.align_offset آسان است.
        let ptr = self.as_ptr();
        // ایمنی: برای توضیحات دقیق درباره ایمنی به روش `align_to_mut` مراجعه کنید.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // ایمنی: اکنون `rest` قطعاً تراز شده است ، بنابراین `from_raw_parts` در زیر خوب است ،
            // از آنجا که تماس گیرنده تضمین می کند که ما می توانیم `T` را به `U` ایمن تبدیل کنیم.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// قطعه را به قطعه ای از نوع دیگر منتقل کنید و اطمینان حاصل کنید که تراز بودن انواع آن حفظ می شود.
    ///
    /// این روش قطعه را به سه برش مشخص تقسیم می کند: پیشوند ، برش میانی درست از نوع جدید و قطعه پسوند.
    /// این روش ممکن است برش میانی را برای بیشترین طول ممکن برای یک نوع داده شده و برش ورودی ایجاد کند ، اما فقط عملکرد الگوریتم شما باید به آن بستگی داشته باشد ، نه به صحت آن.
    ///
    /// مجاز است که تمام داده های ورودی به عنوان قطعه پیشوند یا پسوند برگردانده شوند.
    ///
    /// هنگامی که عنصر ورودی `T` یا عنصر خروجی `U` اندازه صفر داشته باشند ، این روش هیچ هدفی ندارد و برش اصلی را بدون تقسیم چیزی برمی گرداند.
    ///
    /// # Safety
    ///
    /// این روش اساساً یک `transmute` با توجه به عناصر موجود در قطعه میانی برگشتی است ، بنابراین تمام هشدارهای معمول مربوط به `transmute::<T, U>` در اینجا نیز اعمال می شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // توجه داشته باشید که بیشتر این عملکرد بصورت ثابت ارزیابی می شود ،
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST ها را به طور خاص اداره کنید ، یعنی-به هیچ وجه آنها را اداره نکنید.
            return (self, &mut [], &mut []);
        }

        // ابتدا ، دریابید که در چه مرحله ای بین قطعه اول و دوم تقسیم شده ایم.
        // با ptr.align_offset آسان است.
        let ptr = self.as_ptr();
        // ایمنی: در اینجا اطمینان حاصل خواهیم کرد که از نشانگرهای همسو برای U استفاده خواهیم کرد
        // بقیه روشاین کار با عبور دادن یک اشاره گر به&[T] با تراز بندی برای U انجام می شود.
        // `crate::ptr::align_offset` با یک اشاره گر صحیح تراز شده و معتبر `ptr` (از ارجاع به `self` می آید) و با اندازه ای که قدرت دو است (از آنجا که از تراز برای U می آید) فراخوانی می شود ، و این محدودیت های ایمنی آن را برآورده می کند.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // پس از این نمی توانیم دوباره از `rest` استفاده کنیم ، که نام مستعار `mut_ptr` آن را بی اعتبار می کند!ایمنی: به نظرات `align_to` مراجعه کنید.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// بررسی می کند که آیا عناصر این برش مرتب شده اند.
    ///
    /// یعنی برای هر عنصر `a` و عنصر `b` زیر آن ، `a <= b` باید نگه داشته شود.اگر قطعه دقیقاً صفر یا یک عنصر را بازده دهد ، `true` بازگردانده می شود.
    ///
    /// توجه داشته باشید که اگر `Self::Item` فقط `PartialOrd` باشد ، اما `Ord` نباشد ، تعریف فوق بیانگر این است که اگر هر دو مورد متوالی قابل مقایسه نباشند ، این عملکرد `false` را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// بررسی می کند که آیا عناصر این برش با استفاده از عملکرد مقایسه کننده داده شده مرتب شده اند.
    ///
    /// این تابع به جای استفاده از `PartialOrd::partial_cmp` ، از تابع `compare` داده شده برای تعیین ترتیب دو عنصر استفاده می کند.
    /// جدا از آن ، معادل [`is_sorted`] است.برای اطلاعات بیشتر به اسناد آن مراجعه کنید.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// بررسی می کند که آیا عناصر این برش با استفاده از تابع استخراج کلید داده شده مرتب شده اند.
    ///
    /// این تابع به جای مقایسه مستقیم عناصر برش ، کلیدهای عناصر را با تعیین `f` مقایسه می کند.
    /// جدا از آن ، معادل [`is_sorted`] است.برای اطلاعات بیشتر به اسناد آن مراجعه کنید.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// شاخص پارتیشن را با توجه به محمول داده شده برمی گرداند (شاخص عنصر اول پارتیشن دوم).
    ///
    /// فرض می شود که برش طبق محمول داده شده تقسیم شود.
    /// این بدان معناست که تمام عناصری که محمول برای آنها درست برگردانده می شود در ابتدای برش هستند و همه عناصری که محمول برای آنها نادرست باز می گرداند در انتها قرار دارند.
    ///
    /// به عنوان مثال ، [7, 15, 3, 5, 4, 12, 6] یک پارتیشن تحت ماده x=2 است!=0 (همه اعداد فرد در آغاز ، همه حتی در انتها هستند).
    ///
    /// اگر این برش تقسیم نشود ، نتیجه برگشتی مشخص و بی معنی است ، زیرا این روش نوعی جستجوی باینری را انجام می دهد.
    ///
    /// همچنین به [`binary_search`] ، [`binary_search_by`] و [`binary_search_by_key`] مراجعه کنید.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // ایمنی: هنگامی که `left < right` ، `left <= mid < right`.
            // بنابراین `left` همیشه افزایش می یابد و `right` همیشه کاهش می یابد و هر یک از آنها انتخاب می شود.در هر دو مورد `left <= right` راضی است.بنابراین اگر `left < right` در یک مرحله باشد ، `left <= right` در مرحله بعدی راضی است.
            //
            // بنابراین تا زمانی که `left != right` ، `0 <= left < right <= len` راضی است و اگر این مورد `0 <= mid < len` نیز راضی باشد.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: ما باید صریحاً آنها را به همان طول برش دهیم
        // برای آسان تر کردن بهینه ساز از کنترل مرزها.
        // اما از آنجا که نمی توان به آن اعتماد کرد ، ما برای T: Copy نیز تخصص صریح داریم.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// یک برش خالی ایجاد می کند.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// یک برش خالی قابل تغییر ایجاد می کند.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// الگوهای برش خورده ، در حال حاضر فقط توسط `strip_prefix` و `strip_suffix` استفاده می شود.
/// در یک نقطه future ، ما امیدواریم که `core::str::Pattern` (که در زمان نوشتن آن محدود به `str` است) را به برش ها تعمیم دهیم ، و سپس این trait جایگزین یا لغو می شود.
///
pub trait SlicePattern {
    /// نوع عنصر برش در حال تطبیق.
    type Item;

    /// در حال حاضر ، مصرف کنندگان `SlicePattern` به یک قطعه نیاز دارند.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}