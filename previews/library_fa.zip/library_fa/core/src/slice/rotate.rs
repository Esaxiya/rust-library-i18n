// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// دامنه `[mid-left, mid+right)` را به گونه ای می چرخاند که عنصر موجود در `mid` به اولین عنصر تبدیل شود.به طور برابر ، عناصر محدوده `left` را به چپ یا عناصر `right` را به سمت راست می چرخاند.
///
/// # Safety
///
/// دامنه مشخص شده باید برای خواندن و نوشتن معتبر باشد.
///
/// # Algorithm
///
/// الگوریتم 1 برای مقادیر کوچک `left + right` یا برای `T` بزرگ استفاده می شود.
/// این عناصر هر بار از `mid - left` شروع می شوند و با مدول مراحل `right` `left + right` به جلو منتقل می شوند ، به طوری که فقط به یک مورد موقت نیاز است.
/// در نهایت ، ما دوباره به `mid - left` می رسیم.
/// با این حال ، اگر `gcd(left + right, right)` 1 نباشد ، مراحل فوق از عناصر عبور می کنند.
/// مثلا:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// خوشبختانه ، تعداد عناصر پرش شده بین عناصر نهایی همیشه برابر است ، بنابراین ما فقط می توانیم موقعیت شروع خود را جبران کنیم و دورهای بیشتری را انجام دهیم (تعداد کل دورها `gcd(left + right, right)` value) است.
///
/// نتیجه نهایی این است که همه عناصر یک بار و فقط یک بار نهایی می شوند.
///
/// اگر `left + right` بزرگ باشد اما `min(left, right)` آنقدر کوچک باشد که بتواند روی بافر پشته قرار گیرد ، از الگوریتم 2 استفاده می شود.
/// عناصر `min(left, right)` بر روی بافر کپی می شوند ، `memmove` به سایر موارد اعمال می شود و موارد موجود در بافر به داخل سوراخ سمت مخالف محل اصلی خود منتقل می شوند.
///
/// با بزرگتر شدن `left + right` ، الگوریتم های قابل تصویربرداری بهتر از موارد فوق هستند.
/// الگوریتم 1 را می توان با تقسیم و انجام چندین دور همزمان ، برداری کرد ، اما به طور متوسط تعداد دورهای زیادی وجود دارد تا اینکه `left + right` بسیار زیاد شود ، و بدترین حالت یک دور همیشه وجود دارد.
/// در عوض ، الگوریتم 3 از تعویض مکرر عناصر `min(left, right)` استفاده می کند تا زمانی که یک مشکل چرخش کوچکتر باقی بماند.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// در عوض `left < right` تعویض از سمت چپ اتفاق می افتد.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. در صورت عدم بررسی این موارد ، الگوریتم های زیر ممکن است خراب شوند
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // میکرو معیارهای الگوریتم 1 نشان می دهد که عملکرد متوسط برای شیفت های تصادفی تا حدود `left + right == 32` بهتر است ، اما عملکرد بدترین حالت حتی حدود 16 است.
            // 24 به عنوان میانه انتخاب شد.
            // اگر اندازه `T` بزرگتر از 4 کاربر باشد ، این الگوریتم نیز از الگوریتم های دیگر بهتر عمل می کند.
            //
            //
            let x = unsafe { mid.sub(left) };
            // آغاز دور اول
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` با محاسبه `gcd(left + right, right)` می توان آن را قبل از دست یافت ، اما سریعتر می توان یک حلقه را محاسبه کرد که gcd را به عنوان یک اثر جانبی محاسبه کند ، سپس بقیه قسمت را انجام دهد
            //
            //
            let mut gcd = right;
            // معیارها نشان می دهد که به جای خواندن یک مورد موقت ، کپی کردن به عقب ، و سپس نوشتن آن موقتی در انتهای آن ، تعویض معاصر در تمام طول راه سریعتر است.
            // این احتمالاً به این دلیل است که مبادله یا جایگزینی افراد معاصر به جای نیاز به مدیریت دو آدرس ، فقط از یک آدرس حافظه در حلقه استفاده می کنند.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // به جای اینکه `i` را افزایش داده و سپس خارج از مرز را بررسی کنیم ، بررسی می کنیم که `i` با افزایش بعدی از مرز خارج شود یا خیر.
                // این از بسته بندی اشاره گرها یا `usize` جلوگیری می کند.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // پایان دور اول
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // این شرط باید در اینجا باشد اگر `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // تکه را با دورهای بیشتر به پایان برسانید
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` از نوع صفر نیست ، بنابراین تقسیم بر اندازه آن اشکالی ندارد.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // الگوریتم 2 `[T; 0]` در اینجا برای اطمینان از همسویی مناسب با T است
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // الگوریتم 3 یک روش جایگزین برای مبادله وجود دارد که شامل پیدا کردن مکان آخرین تعویض این الگوریتم و مبادله با استفاده از آخرین قطعه به جای مبادله قطعه های مجاور مانند این الگوریتم است ، اما این روش هنوز سریعتر است.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // الگوریتم 3 ، `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}