//! توابع رایگان برای ایجاد `&[T]` و `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// یک برش از یک نشانگر و یک طول ایجاد می کند.
///
/// استدلال `len` تعداد **عناصر** است ، نه تعداد بایت ها.
///
/// # Safety
///
/// در صورت نقض هر یک از شرایط زیر ، رفتار تعریف نشده است:
///
/// * `data` باید [valid] باشد برای خواندن `len * mem::size_of::<T>()` بایت ، و باید به درستی تراز شود.این به ویژه به معنای:
///
///     * کل محدوده حافظه این قطعه باید در یک شی allocated اختصاص یافته باشد!
///       برش ها هرگز نمی توانند از طریق چندین شی allocated اختصاص یافته امتداد پیدا کنند.برای مثال با در نظر نگرفتن اشتباه آن ، به [below](#incorrect-usage) مراجعه کنید.
///     * `data` باید حتی برای برش های طول صفر غیر پوستی و تراز باشد.
///     یک دلیل برای این امر این است که بهینه سازی های چیدمان enum ممکن است به ترجیح داده ها (از جمله برشهای با هر طول) و هم جهت نبودن آنها برای متمایز کردن از سایر داده ها متکی باشد.
///     با استفاده از [`NonNull::dangling()`] می توانید اشاره گر قابل استفاده به عنوان `data` برای برش های با طول صفر بدست آورید.
///
/// * `data` باید به مقادیر `len` به درستی مقداردهی اولیه از نوع `T` اشاره کند.
///
/// * حافظه ارجاع شده توسط قطعه برگشتی نباید در طول عمر `'a` تغییر یابد ، مگر در داخل `UnsafeCell`.
///
/// * اندازه کل `len * mem::size_of::<T>()` قطعه نباید بزرگتر از `isize::MAX` باشد.
///   به اسناد ایمنی [`pointer::offset`] مراجعه کنید.
///
/// # Caveat
///
/// طول عمر قطعه برگشتی از کاربرد آن استنباط می شود.
/// برای جلوگیری از سو mis استفاده تصادفی ، پیشنهاد می شود که طول عمر را به هر کدام از طول عمر منبع ایمن متصل کنید ، از جمله با ارائه یک تابع کمکی که طول یک میزبان را برای طول قطعه طول می کشد ، یا با حاشیه نویسی صریح.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // یک قطعه را برای یک عنصر آشکار کنید
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### استفاده نادرست
///
/// عملکرد `join_slices` زیر **نامعلوم است**
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // ادعای فوق اطمینان حاصل می کند که `fst` و `snd` بهم پیوسته اند ، اما ممکن است در _different allocated objects_ وجود داشته باشد ، در این صورت ایجاد این برش یک رفتار تعریف نشده است.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` و `b` اشیا allocated مختلف تخصیص یافته هستند ...
///     let a = 42;
///     let b = 27;
///     // ... که با این وجود ممکن است به طور پیوسته در حافظه گذاشته شود: |a |ب |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ایمنی: تماس گیرنده باید قرارداد ایمنی `from_raw_parts` را رعایت کند.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// عملکرد مشابه [`from_raw_parts`] را انجام می دهد ، با این تفاوت که یک برش قابل تغییر برمی گرداند.
///
/// # Safety
///
/// در صورت نقض هر یک از شرایط زیر ، رفتار تعریف نشده است:
///
/// * `data` باید [valid] باشد برای خواندن و نوشتن برای `len * mem::size_of::<T>()` بایت زیاد ، و باید به درستی تراز شود.این به ویژه به معنای:
///
///     * کل محدوده حافظه این قطعه باید در یک شی allocated اختصاص یافته باشد!
///       برش ها هرگز نمی توانند از طریق چندین شی allocated اختصاص یافته امتداد پیدا کنند.
///     * `data` باید حتی برای برش های طول صفر غیر پوستی و تراز باشد.
///     یک دلیل برای این امر این است که بهینه سازی های چیدمان enum ممکن است به ترجیح داده ها (از جمله برشهای با هر طول) و هم جهت نبودن آنها برای متمایز کردن از سایر داده ها متکی باشد.
///
///     با استفاده از [`NonNull::dangling()`] می توانید اشاره گر قابل استفاده به عنوان `data` برای برش های با طول صفر بدست آورید.
///
/// * `data` باید به مقادیر `len` به درستی مقداردهی اولیه از نوع `T` اشاره کند.
///
/// * در طول عمر `'a` به حافظه ارجاع شده توسط قطعه برگشتی نباید از طریق هیچ اشاره گر دیگری (از مقدار برگشتی مشتق نشده باشد) دسترسی پیدا کرد.
///   دسترسی به خواندن و نوشتن هر دو ممنوع است.
///
/// * اندازه کل `len * mem::size_of::<T>()` قطعه نباید بزرگتر از `isize::MAX` باشد.
///   به اسناد ایمنی [`pointer::offset`] مراجعه کنید.
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ایمنی: تماس گیرنده باید قرارداد ایمنی `from_raw_parts_mut` را رعایت کند.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// یک مرجع به T را به برشی به طول 1 تبدیل می کند (بدون کپی برداری).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// یک مرجع به T را به برشی به طول 1 تبدیل می کند (بدون کپی برداری).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}