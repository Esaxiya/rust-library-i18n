//! ماکروهایی که توسط تکرار کنندگان برش استفاده می شود.

// خط کشیدن خالی است و len تفاوت زیادی در عملکرد ایجاد می کند
macro_rules! is_empty {
    // نحوه رمزگذاری طول تکرار کننده ZST ، این هم برای ZST و هم برای غیر ZST کار می کند.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// برای خلاص شدن از شر برخی از چک های مرزی (نگاه کنید به `position`) ، ما طول را تا حدودی غیر منتظره محاسبه می کنیم.
// (تست شده توسط `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ما گاهی اوقات در یک بلوک ناامن استفاده می شود

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // این _cannot_ از `unchecked_sub` استفاده می کند زیرا برای نشان دادن طول تکرارهای طولانی قطعه ZST به بسته بندی بستگی داریم.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // ما می دانیم که `start <= end` ، بنابراین می تواند بهتر از `offset_from` ، که نیاز به معامله امضا دارد ، بهتر عمل کند.
            // با تنظیم پرچم های مناسب می توانیم این مورد را به LLVM بگوییم ، که به آن کمک می کند تا چک های مرزی را حذف کند.
            // ایمنی: با توجه به نوع ثابت ، `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // با گفتن اینکه LLVM نشانگرها با یک عدد دقیقاً از اندازه نوع جدا شده اند ، می تواند `len() == 0` را به جای `(end - start) < size` به `start == end` بهینه کند.
            //
            // ایمنی: با توجه به نوع ثابت ، نشانگرها با هم تراز می شوند
            //         فاصله بین آنها باید چندین برابر اندازه جمع باشد
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// تعریف مشترک تکرار کننده های `Iter` و `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // اولین عنصر را برمی گرداند و شروع تکرار کننده را با 1 به جلو منتقل می کند.
        // عملکرد را در مقایسه با عملکرد برجسته بسیار بهبود می بخشد.
        // تکرار کننده نباید خالی باشد.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // آخرین عنصر را برمی گرداند و انتهای تکرار کننده را با 1 به عقب منتقل می کند.
        // عملکرد را در مقایسه با عملکرد برجسته بسیار بهبود می بخشد.
        // تکرار کننده نباید خالی باشد.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // هنگامی که T یک ZST است ، با حرکت انتهای تکرار کننده به عقب توسط `n` ، تکرار کننده را کوچک می کند.
        // `n` نباید بیش از `self.len()` باشد.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // عملکرد Helper برای ایجاد برش از تکرار کننده.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SAFETY: تکرار کننده از یک برش با اشاره گر ایجاد شده است
                // `self.ptr` و طول `len!(self)`.
                // این تضمین می کند که تمام پیش نیازهای `from_raw_parts` برآورده شده است.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // عملکرد Helper برای انتقال شروع تکرار کننده توسط عناصر `offset` به جلو و بازگشت شروع قدیمی.
            //
            // ناامن است زیرا جبران نباید بیش از `self.len()` باشد.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // ایمنی: تماس گیرنده تضمین می کند `offset` بیش از `self.len()` نیست ،
                    // بنابراین این اشاره گر جدید در داخل `self` قرار دارد و بنابراین غیرمعتبر بودن آن تضمین می شود.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // عملکرد Helper برای انتقال انتهای تکرار کننده توسط عناصر `offset` به عقب و بازگشت انتهای جدید.
            //
            // ناامن است زیرا جبران نباید بیش از `self.len()` باشد.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // ایمنی: تماس گیرنده تضمین می کند `offset` بیش از `self.len()` نیست ،
                    // که تضمین می کند `isize` سرریز نمی کند.
                    // همچنین ، نشانگر بدست آمده در حدود `slice` است ، که سایر الزامات `offset` را برآورده می کند.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // می تواند با برش اجرا شود ، اما این امر از بررسی مرزها جلوگیری می کند

                // ایمنی: تماس های `assume` از زمان اشاره گر شروع یک قطعه ایمن هستند
                // باید غیر پوچ باشد و برشهای غیر ZST نیز باید دارای یک اشاره گر انتهایی غیر پوچ باشند.
                // تماس با `next_unchecked!` بی خطر است زیرا ما ابتدا خالی بودن تکرار کننده را بررسی می کنیم.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // این تکرار کننده اکنون خالی است.
                    if mem::size_of::<T>() == 0 {
                        // ما باید این کار را انجام دهیم زیرا `ptr` ممکن است هرگز 0 نباشد ، اما `end` ممکن است باشد (به دلیل بسته بندی).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // ایمنی: اگر T ZST نباشد پایان نمی تواند 0 باشد زیرا ptr 0 نیست و پایان>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // ایمنی: ما در محدوده هستیم.`post_inc_start` حتی برای ZST ها نیز کار درستی انجام می دهد.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // ما پیاده سازی پیش فرض را که از `try_fold` استفاده می کند ، نادیده می گیریم ، زیرا این پیاده سازی ساده IR LLVM کمتری تولید می کند و سریعتر برای کامپایل می شود.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // ما پیاده سازی پیش فرض را که از `try_fold` استفاده می کند ، نادیده می گیریم ، زیرا این پیاده سازی ساده IR LLVM کمتری تولید می کند و سریعتر برای کامپایل می شود.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // ما پیاده سازی پیش فرض را که از `try_fold` استفاده می کند ، نادیده می گیریم ، زیرا این پیاده سازی ساده IR LLVM کمتری تولید می کند و سریعتر برای کامپایل می شود.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // ما پیاده سازی پیش فرض را که از `try_fold` استفاده می کند ، نادیده می گیریم ، زیرا این پیاده سازی ساده IR LLVM کمتری تولید می کند و سریعتر برای کامپایل می شود.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // ما پیاده سازی پیش فرض را که از `try_fold` استفاده می کند ، نادیده می گیریم ، زیرا این پیاده سازی ساده IR LLVM کمتری تولید می کند و سریعتر برای کامپایل می شود.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // ما پیاده سازی پیش فرض را که از `try_fold` استفاده می کند ، نادیده می گیریم ، زیرا این پیاده سازی ساده IR LLVM کمتری تولید می کند و سریعتر برای کامپایل می شود.
            // همچنین ، `assume` از بررسی مرزها جلوگیری می کند.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // ایمنی: ما تضمین می کنیم که در حلقه ثابت هستیم:
                        // وقتی `i >= n` ، `self.next()` `None` را برمی گرداند و حلقه می شکند.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // ما پیاده سازی پیش فرض را که از `try_fold` استفاده می کند ، نادیده می گیریم ، زیرا این پیاده سازی ساده IR LLVM کمتری تولید می کند و سریعتر برای کامپایل می شود.
            // همچنین ، `assume` از بررسی مرزها جلوگیری می کند.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // ایمنی: `i` باید کمتر از `n` باشد زیرا از `n` شروع می شود
                        // و فقط در حال کاهش است.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // ایمنی: تماس گیرنده باید تضمین کند که `i` در حد مجاز است
                // برش اساسی ، بنابراین `i` نمی تواند `isize` را سرریز کند ، و منابع ارجاع شده تضمین می شود که به عنصری از قطعه مراجعه کنند و بنابراین معتبر بودن آن تضمین می شود.
                //
                // همچنین توجه داشته باشید که تماس گیرنده همچنین تضمین می کند که دیگر هرگز با همان شاخص تماس نخواهیم گرفت و هیچ روش دیگری که به این زیرشاخه دسترسی پیدا کند فراخوانی نمی شود ، بنابراین معتبر است که در مورد
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // می تواند با برش اجرا شود ، اما این امر از بررسی مرزها جلوگیری می کند

                // ایمنی: تماس های `assume` بی خطر هستند زیرا نشانگر شروع یک تکه باید خنثی باشد ،
                // و برشهای غیر ZST نیز باید دارای یک اشاره گر انتهایی غیر تهی باشند.
                // تماس با `next_back_unchecked!` بی خطر است زیرا ما ابتدا خالی بودن تکرار کننده را بررسی می کنیم.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // این تکرار کننده اکنون خالی است.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // ایمنی: ما در محدوده هستیم.`pre_dec_end` حتی برای ZST ها نیز کار درستی انجام می دهد.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}