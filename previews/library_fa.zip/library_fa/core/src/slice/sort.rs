//! مرتب سازی برش
//!
//! این ماژول شامل یک الگوریتم مرتب سازی بر اساس الگوی شکست خورنده الگو شکست اورسن پیترز است که در: <https://github.com/orlp/pdqsort>
//!
//!
//! مرتب سازی ناپایدار با libcore سازگار است زیرا بر خلاف اجرای مرتب سازی پایدار ما ، حافظه را تخصیص نمی دهد.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// وقتی رها شد ، از `src` به `dest` کپی می شود.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // ایمنی: این یک کلاس کمکی است.
        //          لطفا برای صحت به کاربرد آن مراجعه کنید.
        //          یعنی باید مطمئن بود که `src` و `dst` مطابق با خواسته های `ptr::copy_nonoverlapping` با هم تداخل ندارند.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// اولین عنصر را به سمت راست تغییر دهید تا زمانی که با یک عنصر بزرگ یا مساوی روبرو شود.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ایمنی: عملیات ناامن زیر شامل نمایه سازی بدون چک محدود (`get_unchecked` و `get_unchecked_mut`) است
    // و حافظه (`ptr::copy_nonoverlapping`) را کپی کنید.
    //
    // آ.نمایه سازی:
    //  1. اندازه آرایه را به>=2 بررسی کردیم.
    //  2. تمام نمایه سازی که انجام خواهیم داد همیشه حداکثر بین {0 <= index < len} است.
    //
    // بکپی کردن حافظه
    //  1. ما در حال به دست آوردن اشاره گرهایی برای منابع معتبر تضمین شده هستیم.
    //  2. آنها نمی توانند همپوشانی داشته باشند زیرا ما نشانگرهای شاخص اختلاف برش را بدست می آوریم.
    //     یعنی `i` و `i-1`.
    //  3. اگر برش به درستی تراز شود ، عناصر به درستی تراز می شوند.
    //     این مسئولیت تماس گیرنده است که مطمئن شود برش به درستی تراز شده است.
    //
    // برای جزئیات بیشتر به نظرات زیر مراجعه کنید.
    unsafe {
        // اگر دو عنصر اول خارج از دستور باشد ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // اولین عنصر را در یک متغیر تخصیص یافته پشته بخوانید.
            // اگر یک عمل مقایسه زیر panics انجام شود ، `hole` رها می شود و به طور خودکار عنصر را در قطعه می نویسد.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // عنصر "i" را یک مکان به سمت چپ حرکت دهید ، بنابراین سوراخ را به سمت راست تغییر دهید.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` رها می شود و بنابراین `tmp` را در سوراخ باقیمانده `v` کپی می کند.
        }
    }
}

/// آخرین عنصر را به سمت چپ تغییر دهید تا اینکه با عنصر کوچکتر یا مساوی روبرو شود.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // ایمنی: عملیات ناامن زیر شامل نمایه سازی بدون چک محدود (`get_unchecked` و `get_unchecked_mut`) است
    // و حافظه (`ptr::copy_nonoverlapping`) را کپی کنید.
    //
    // آ.نمایه سازی:
    //  1. اندازه آرایه را به>=2 بررسی کردیم.
    //  2. تمام نمایه سازی که انجام خواهیم داد همیشه حداکثر بین `0 <= index < len-1` است.
    //
    // بکپی کردن حافظه
    //  1. ما در حال به دست آوردن اشاره گرهایی برای منابع معتبر تضمین شده هستیم.
    //  2. آنها نمی توانند همپوشانی داشته باشند زیرا ما نشانگرهای شاخص اختلاف برش را بدست می آوریم.
    //     یعنی `i` و `i+1`.
    //  3. اگر برش به درستی تراز شود ، عناصر به درستی تراز می شوند.
    //     این مسئولیت تماس گیرنده است که مطمئن شود برش به درستی تراز شده است.
    //
    // برای جزئیات بیشتر به نظرات زیر مراجعه کنید.
    unsafe {
        // اگر دو عنصر آخر از دستور خارج شوند ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // آخرین عنصر را در یک متغیر اختصاص یافته به پشته بخوانید.
            // اگر یک عمل مقایسه زیر panics انجام شود ، `hole` رها می شود و به طور خودکار عنصر را در قطعه می نویسد.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // i "-عنصر را یک مکان به راست حرکت دهید ، بنابراین سوراخ را به سمت چپ تغییر دهید.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` رها می شود و بنابراین `tmp` را در سوراخ باقیمانده `v` کپی می کند.
        }
    }
}

/// با جابجایی چندین عنصر خارج از سفارش به اطراف ، بخشی را مرتب می کند.
///
/// اگر برش در انتها مرتب شود ، `true` را برمی گرداند.این عملکرد بدترین حالت *O*(*n*) است.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // حداکثر تعداد جفتهای خارج از سفارش مجاور که تغییر مکان می دهند.
    const MAX_STEPS: usize = 5;
    // اگر برش کوتاهتر از این است ، هیچ عنصری را جابجا نکنید.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // ایمنی: ما قبلاً صریحاً بررسی `i < len` را انجام دادیم.
        // تمام نمایه سازی های بعدی ما فقط در محدوده `0 <= index < len` است
        unsafe {
            // جفت بعدی عناصر خارج از سفارش مجاور را پیدا کنید.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // آیا کارمان تمام شد؟
        if i == len {
            return true;
        }

        // عناصر را روی آرایه های کوتاه تغییر ندهید ، این هزینه عملکرد دارد.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // جفت عناصر پیدا شده را عوض کنید.این آنها را به ترتیب صحیح قرار می دهد.
        v.swap(i - 1, i);

        // عنصر کوچکتر را به سمت چپ تغییر دهید.
        shift_tail(&mut v[..i], is_less);
        // عنصر بزرگتر را به سمت راست تغییر دهید.
        shift_head(&mut v[i..], is_less);
    }

    // موفق به مرتب سازی برش در تعداد محدود مراحل نشد.
    false
}

/// با استفاده از مرتب سازی درج ، یک قطعه را مرتب می کند که بدترین حالت *O*(*n*^ 2) است.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// `v` را با استفاده از heapsort مرتب سازی می کند که بدترین حالت *O*(*n*\*log(* n*))) را تضمین می کند.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // این پشته باینری به `parent >= child` ثابت احترام می گذارد.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // کودکان `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // فرزند بزرگتر را انتخاب کنید.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // در صورت عدم تغییر `node` ، توقف کنید.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // `node` را با فرزند بزرگ عوض کنید ، یک قدم به سمت پایین حرکت کرده و الک را ادامه دهید.
            v.swap(node, greater);
            node = greater;
        }
    };

    // پشته را در زمان خطی بسازید.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // عناصر حداکثر را از انبوه پاپ کنید.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// `v` را به عناصر کوچکتر از `pivot` تقسیم کرده و عناصر بزرگتر یا مساوی `pivot` را دنبال می کنید.
///
///
/// تعداد عناصر کوچکتر از `pivot` را برمی گرداند.
///
/// پارتیشن بندی به صورت بلوک به بلوک انجام می شود تا هزینه عملیات انشعاب به حداقل برسد.
/// این ایده در مقاله [BlockQuicksort][pdf] ارائه شده است.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // تعداد عناصر در یک بلوک معمولی.
    const BLOCK: usize = 128;

    // الگوریتم پارتیشن بندی مراحل زیر را تا زمان تکمیل تکرار می کند:
    //
    // 1. برای شناسایی عناصر بزرگتر یا مساوی محوری ، یک بلوک را از سمت چپ ردیابی کنید.
    // 2. برای شناسایی عناصر کوچکتر از محور ، یک بلوک را از سمت راست ردیابی کنید.
    // 3. عناصر شناسایی شده را بین سمت چپ و راست مبادله کنید.
    //
    // متغیرهای زیر را برای مجموعه ای از عناصر نگهداری می کنیم:
    //
    // 1. `block` - تعداد عناصر موجود در بلوک.
    // 2. `start` - نشانگر را در آرایه `offsets` شروع کنید.
    // 3. `end` - اشاره گر را به آرایه `offsets` خاتمه دهید.
    // 4. `offsets، شاخص های خارج از سفارش عناصر درون بلوک.

    // بلوک فعلی در سمت چپ (از `l` به `l.add(block_l)`)).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // بلوک فعلی در سمت راست (از `r.sub(block_r)` to `r`).
    // ایمنی: در اسناد .add() به طور خاص ذکر شده است که `vec.as_ptr().add(vec.len())` همیشه ایمن است
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: هنگامی که VLA دریافت می کنیم ، سعی کنید یک آرایه با طول `min(v.len() ، 2 * BLOCK) ایجاد کنید
    // بیش از دو آرایه با اندازه ثابت `BLOCK`.VLA ها ممکن است از حافظه پنهان کارآمدتر باشند.

    // تعداد عناصر بین نشانگرهای `l` (inclusive) و `r` (exclusive) را برمی گرداند.
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // وقتی `l` و `r` به هم نزدیک می شوند کار ما با پارتیشن بندی بلوک به بلوک تمام می شود.
        // سپس برای تقسیم بندی عناصر باقیمانده در این بین ، کارهایی را انجام می دهیم.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // تعداد عناصر باقی مانده (هنوز با محوری مقایسه نمی شود).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // اندازه بلوک ها را طوری تنظیم کنید که بلوک چپ و راست با هم تداخل نداشته باشند ، اما کاملاً تراز شده و کل شکاف باقی مانده را بپوشانید.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // عناصر `block_l` را از سمت چپ ردیابی کنید.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // ایمنی: عملیات ایمنی زیر شامل استفاده از `offset` است.
                //         با توجه به شرایط مورد نیاز تابع ، ما آنها را برآورده می کنیم زیرا:
                //         1. `offsets_l` پشته اختصاص داده شده است ، و بنابراین شی and جداگانه جداگانه ای در نظر گرفته می شود.
                //         2. عملکرد `is_less` یک `bool` را برمی گرداند.
                //            بازیگران `bool` هرگز `isize` را سرریز نخواهند کرد.
                //         3. ما تضمین کرده ایم که `block_l` `<= BLOCK` خواهد بود.
                //            بعلاوه ، `end_l` در ابتدا روی نشانگر آغازین `offsets_` تنظیم شده بود که روی پشته اعلام شده بود.
                //            بنابراین ، ما می دانیم که حتی در بدترین حالت (تمام فراخوانی های `is_less` نادرست است) ما فقط حداکثر 1 بایت خواهیم بود که پایان آن را می گیریم.
                //        یکی دیگر از عملیات های عدم ایمنی در اینجا مراجعه مجدد به `elem` است.
                //        با این حال ، `elem` در ابتدا اشاره گر شروع به قطعه بود که همیشه معتبر است.
                unsafe {
                    // مقایسه بدون شاخه.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // عناصر `block_r` را از سمت راست ردیابی کنید.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // ایمنی: عملیات ایمنی زیر شامل استفاده از `offset` است.
                //         با توجه به شرایط مورد نیاز تابع ، ما آنها را برآورده می کنیم زیرا:
                //         1. `offsets_r` پشته اختصاص داده شده است ، و بنابراین شی and جداگانه جداگانه ای در نظر گرفته می شود.
                //         2. عملکرد `is_less` یک `bool` را برمی گرداند.
                //            بازیگران `bool` هرگز `isize` را سرریز نخواهند کرد.
                //         3. ما تضمین کرده ایم که `block_r` `<= BLOCK` خواهد بود.
                //            بعلاوه ، `end_r` در ابتدا روی نشانگر آغازین `offsets_` تنظیم شده بود که روی پشته اعلام شده بود.
                //            بنابراین ، ما می دانیم که حتی در بدترین حالت (تمام فراخوانی های `is_less` درست است) ما حداکثر 1 بایت خواهیم بود که پایان آن را می گیریم.
                //        یکی دیگر از عملیات های عدم ایمنی در اینجا مراجعه مجدد به `elem` است.
                //        با این حال ، `elem` در ابتدا `1 *sizeof(T)` بود و ما قبل از دسترسی به `1* sizeof(T)` ، آن را کاهش دادیم.
                //        بعلاوه ، گفته شد که `block_r` کمتر از `BLOCK` است و بنابراین `elem` حداکثر به ابتدای قطعه اشاره خواهد کرد.
                unsafe {
                    // مقایسه بدون شاخه.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // تعداد عناصر خارج از سفارش برای تعویض بین سمت چپ و راست.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // به جای جابجایی یک جفت در آن زمان ، انجام یک جایگزینی چرخه ای کارآمدتر است.
            // این کاملاً معادل مبادله نیست ، اما با استفاده از عملیات حافظه کمتر نتیجه مشابهی ایجاد می کند.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // همه عناصر خارج از سفارش در بلوک سمت چپ منتقل شدند.به بلوک بعدی بروید.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // همه عناصر خارج از سفارش در بلوک سمت راست منتقل شدند.به بلوک قبلی بروید.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // بیشترین چیزی که اکنون باقی مانده حداکثر یک بلوک (چپ یا راست) با عناصر خارج از دستور است که باید منتقل شوند.
    // چنین عناصر باقی مانده را می توان به سادگی در انتهای بلوک خود به انتها منتقل کرد.
    //

    if start_l < end_l {
        // بلوک سمت چپ باقی مانده است.
        // عناصر خارج از سفارش آن را به سمت راست راست منتقل کنید.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // بلوک سمت راست باقی مانده است.
        // عناصر خارج از سفارش آن را به سمت چپ منتقل کنید.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // کار دیگری برای انجام دادن نیست ، کار ما تمام شد.
        width(v.as_mut_ptr(), l)
    }
}

/// `v` را به عناصر کوچکتر از `v[pivot]` تقسیم کرده و عناصر بزرگتر یا مساوی `v[pivot]` را دنبال می کنید.
///
///
/// یک قسمت از موارد زیر را برمی گرداند:
///
/// 1. تعداد عناصر کوچکتر از `v[pivot]`.
/// 2. اگر `v` قبلاً پارتیشن بندی شده باشد ، درست است.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // محوری را در ابتدای برش قرار دهید.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // محوری را برای یک کارایی در یک متغیر تخصیص داده شده به پشته بخوانید.
        // اگر یک عمل مقایسه زیر panics انجام شود ، محور به طور خودکار در قطعه نوشته می شود.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // جفت اول عناصر خارج از سفارش را پیدا کنید.
        let mut l = 0;
        let mut r = v.len();

        // ایمنی: عدم ایمنی زیر شامل نمایه سازی یک آرایه است.
        // برای مورد اول: ما در اینجا بررسی Xbox را با `l < r` انجام می دهیم.
        // برای مورد دوم: ما در ابتدا `l == 0` و `r == v.len()` داریم و آن `l < r` را در هر عملیات نمایه سازی بررسی کردیم.
        //                     از اینجا می دانیم که `r` باید حداقل `r == l` باشد که نشان داده شده از مورد اول معتبر است.
        unsafe {
            // اولین عنصر بزرگتر یا برابر آن را پیدا کنید.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // آخرین عنصر کوچکتر از محور را پیدا کنید.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` از محدوده خارج می شود و محوری (که یک متغیر تخصیص داده شده است) را در قطعه ای که در ابتدا بود ، می نویسد.
        // این مرحله برای اطمینان از ایمنی بسیار مهم است!
        //
    };

    // محوری را بین دو پارتیشن قرار دهید.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// پارتیشن های `v` به عناصر برابر با `v[pivot]` و به دنبال آن عناصر بزرگتر از `v[pivot]`.
///
/// تعداد عناصر برابر با محور را برمی گرداند.
/// فرض بر این است که `v` حاوی عناصر کوچکتر از محور نیست.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // محوری را در ابتدای برش قرار دهید.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // محوری را برای یک کارایی در یک متغیر تخصیص داده شده به پشته بخوانید.
    // اگر یک عمل مقایسه زیر panics انجام شود ، محور به طور خودکار در قطعه نوشته می شود.
    // SAFETY: نشانگر در اینجا معتبر است زیرا از ارجاع به یک برش بدست می آید.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // حالا برش را تقسیم کنید.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // ایمنی: عدم ایمنی زیر شامل نمایه سازی یک آرایه است.
        // برای مورد اول: ما در اینجا بررسی Xbox را با `l < r` انجام می دهیم.
        // برای مورد دوم: ما در ابتدا `l == 0` و `r == v.len()` داریم و آن `l < r` را در هر عملیات نمایه سازی بررسی کردیم.
        //                     از اینجا می دانیم که `r` باید حداقل `r == l` باشد که نشان داده شده از مورد اول معتبر است.
        unsafe {
            // اولین عنصر بزرگتر از محور را پیدا کنید.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // آخرین عنصر برابر با محور را پیدا کنید.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // آیا کارمان تمام شد؟
            if l >= r {
                break;
            }

            // جفت پیدا شده از عناصر خارج از سفارش را عوض کنید.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // ما عناصر `l` برابر با محور را پیدا کردیم.1 را برای محاسبه خود محوری اضافه کنید.
    l + 1

    // `_pivot_guard` از محدوده خارج می شود و محوری (که یک متغیر تخصیص داده شده است) را در قطعه ای که در ابتدا بود ، می نویسد.
    // این مرحله برای اطمینان از ایمنی بسیار مهم است!
}

/// برخی از عناصر را به منظور شکستن الگوهایی که ممکن است باعث ایجاد پارتیشن های نامتعادل در نوع جست و جو شوند ، پراکنده می کند.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // مولد اعداد شبه از مقاله "Xorshift RNGs" توسط جورج مارساگلیا.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // این عدد را مدول اعداد تصادفی بگیرید.
        // این عدد در `usize` جای می گیرد زیرا `len` از `isize::MAX` بزرگتر نیست.
        let modulus = len.next_power_of_two();

        // برخی از نامزدهای محوری در نزدیکی این شاخص خواهند بود.بیایید آنها را تصادفی کنیم
        let pos = len / 4 * 2;

        for i in 0..3 {
            // یک عدد تصادفی مدول `len` ایجاد کنید.
            // با این حال ، برای جلوگیری از عملیات پرهزینه ، ابتدا آن را با قدرت دو برابر می کنیم و سپس `len` کاهش می دهیم تا در محدوده `[0, len - 1]` قرار گیرد.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` تضمین شده است که کمتر از `2 * len` باشد.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// محوری را در `v` انتخاب می کند و در صورت مرتب سازی برش ، شاخص و `true` را برمی گرداند.
///
/// عناصر موجود در `v` ممکن است در این فرآیند دوباره مرتب شوند.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // حداقل طول برای انتخاب روش متوسط-متوسط.
    // برش های کوتاه تر از روش ساده میانه از سه استفاده می کنند.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // حداکثر تعداد مبادله ای که می تواند در این عملکرد انجام شود.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // سه شاخص که در نزدیکی آنها قصد داریم یک محور را انتخاب کنیم.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // تعداد کل مبادله هایی را که می خواهیم هنگام مرتب سازی شاخص ها انجام دهیم ، محاسبه می کند.
    let mut swaps = 0;

    if len >= 8 {
        // مبادله شاخص ها به طوری که `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // مبادله شاخص ها به طوری که `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // میانه `v[a - 1], v[a], v[a + 1]` را پیدا می کند و شاخص را در `a` ذخیره می کند.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // در محله های `a` ، `b` و `c` متوسط پیدا کنید.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // متوسط را در میان `a` ، `b` و `c` پیدا کنید.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // حداکثر تعداد مبادله انجام شد.
        // به احتمال زیاد قطعه در حال نزولی یا بیشتر نزولی است ، بنابراین معکوس کردن احتمالاً به مرتب سازی سریعتر آن کمک می کند.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// `v` را به صورت بازگشتی مرتب می کند.
///
/// اگر برش در آرایه اصلی دارای یک سلف باشد ، به عنوان `pred` مشخص شده است.
///
/// `limit` تعداد پارتیشن های نامتعادل مجاز قبل از تغییر به `heapsort` است.
/// در صورت صفر ، این عملکرد بلافاصله به heapsort تغییر حالت می دهد.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // برشهای تا این طول با استفاده از مرتب سازی درج مرتب می شوند.
    const MAX_INSERTION: usize = 20;

    // درست است اگر آخرین پارتیشن بندی متعادل بود.
    let mut was_balanced = true;
    // درست است اگر آخرین پارتیشن بندی عناصر را بهم نزند (برش از قبل پارتیشن بندی شده بود).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // برش های بسیار کوتاه با استفاده از مرتب سازی درج مرتب می شوند.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // اگر بیش از حد انتخاب های محوری بد انجام شده است ، برای تضمین بدترین حالت `O(n * log(n))` ، به سادگی به بخش اصلی برگردید.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // اگر آخرین پارتیشن بندی متعادل نبود ، سعی کنید با زدن برخی عناصر در اطراف ، الگوهای موجود در آن را بشکنید.
        // امیدوارم که این بار محور بهتری را انتخاب کنیم.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // محوری را انتخاب کنید و حدس بزنید که برش از قبل مرتب شده است یا خیر.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // اگر آخرین پارتیشن بندی متعادل بود و عناصر را به هم نمی زد ، و اگر انتخاب محوری پیش بینی کند که قطعه از قبل مرتب شده است ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // سعی کنید چندین عنصر خارج از سفارش را شناسایی کرده و آنها را به موقعیت های صحیح منتقل کنید.
            // اگر قطعه به طور کامل مرتب شود ، کار ما تمام شد.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // اگر محور انتخاب شده برابر با نمونه قبلی باشد ، کوچکترین عنصر موجود در برش است.
        // قطعه را به عناصر برابر و عناصر بزرگتر از محور تقسیم کنید.
        // این حالت معمولاً هنگامی مورد حمله قرار می گیرد که برش شامل بسیاری از عناصر تکراری باشد.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // مرتب سازی عناصر بزرگتر از محور را ادامه دهید.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // قطعه را تقسیم کنید.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // برش را به `left` ، `pivot` و `right` تقسیم کنید.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // فقط به سمت کوتاه تر حرکت کنید تا تعداد کل تماس های بازگشتی را به حداقل برسانید و فضای پشته کمتری را مصرف کنید.
        // سپس فقط با سمت بلندتر ادامه دهید (این شبیه به بازگشت دم است).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// `v` را با استفاده از quicksort شکست دهنده الگو مرتب می کند ، که *O* است (*n*\*log(* n*)) در بدترین حالت.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // مرتب سازی بر روی انواع اندازه صفر رفتار معنی داری ندارد.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // تعداد پارتیشن های نامتعادل را به `floor(log2(len)) + 1` محدود کنید.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // برای برش هایی با این طول ، مرتب سازی بر اساس آنها سریعتر است.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // محوری انتخاب کنید
        let (pivot, _) = choose_pivot(v, is_less);

        // اگر محور انتخاب شده برابر با نمونه قبلی باشد ، کوچکترین عنصر موجود در برش است.
        // قطعه را به عناصر برابر و عناصر بزرگتر از محور تقسیم کنید.
        // این حالت معمولاً هنگامی مورد حمله قرار می گیرد که برش شامل بسیاری از عناصر تکراری باشد.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // اگر شاخص خود را پشت سر گذاشته ایم ، خوب هستیم.
                if mid > index {
                    return;
                }

                // در غیر این صورت ، مرتب سازی عناصر بزرگتر از محور را ادامه دهید.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // برش را به `left` ، `pivot` و `right` تقسیم کنید.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // اگر mid==index باشد ، کار ما تمام شد ، زیرا partition() تضمین کرد که همه عناصر بعد از mid بیشتر یا مساوی mid هستند.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // مرتب سازی بر روی انواع اندازه صفر رفتار معنی داری ندارد.هیچ کاری نکن
    } else if index == v.len() - 1 {
        // عنصر max را پیدا کرده و در آخرین موقعیت آرایه قرار دهید.
        // ما در اینجا آزاد هستیم که از `unwrap()` استفاده کنیم زیرا می دانیم که v نباید خالی باشد.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // عنصر min را پیدا کنید و آن را در اولین موقعیت آرایه قرار دهید.
        // ما در اینجا آزاد هستیم که از `unwrap()` استفاده کنیم زیرا می دانیم که v نباید خالی باشد.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}