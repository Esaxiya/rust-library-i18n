#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // بسته به نسخه تماس گیرنده به `$crate::panic::panic_2015` یا `$crate::panic::panic_2021` گسترش می یابد.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// ادعا می کند که دو عبارت با یکدیگر برابر هستند (با استفاده از [`PartialEq`]).
///
/// در panic ، این ماکرو مقادیر عبارات را با نمایش اشکال زدایی آنها چاپ می کند.
///
///
/// مانند [`assert!`] ، این ماکرو فرم دوم نیز دارد ، در آنجا می توان پیام سفارشی panic را ارائه داد.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // reborrows زیر عمدی است.
                    // بدون آنها ، اسلات پشته برای وام حتی قبل از مقایسه مقادیر اولیه آغاز می شود که منجر به کاهش چشمگیر سرعت می شود.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // reborrows زیر عمدی است.
                    // بدون آنها ، اسلات پشته برای وام حتی قبل از مقایسه مقادیر اولیه آغاز می شود که منجر به کاهش چشمگیر سرعت می شود.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ادعا می کند که دو عبارت با یکدیگر برابر نیستند (با استفاده از [`PartialEq`]).
///
/// در panic ، این ماکرو مقادیر عبارات را با نمایش اشکال زدایی آنها چاپ می کند.
///
///
/// مانند [`assert!`] ، این ماکرو فرم دوم نیز دارد ، در آنجا می توان پیام سفارشی panic را ارائه داد.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // reborrows زیر عمدی است.
                    // بدون آنها ، اسلات پشته برای وام حتی قبل از مقایسه مقادیر اولیه آغاز می شود که منجر به کاهش چشمگیر سرعت می شود.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // reborrows زیر عمدی است.
                    // بدون آنها ، اسلات پشته برای وام حتی قبل از مقایسه مقادیر اولیه آغاز می شود که منجر به کاهش چشمگیر سرعت می شود.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// ادعا می کند که یک عبارت بولی در زمان اجرا `true` است.
///
/// اگر عبارت ارائه شده نتواند هنگام اجرا به `true` ارزیابی شود ، ماکرو [`panic!`] را فراخوانی می کند.
///
/// مانند [`assert!`] ، این ماکرو نسخه دوم نیز دارد که در آن می توان پیام سفارشی panic را ارائه داد.
///
/// # Uses
///
/// برخلاف [`assert!`] ، دستورات `debug_assert!` به صورت پیش فرض فقط در ساختهای غیربهینه فعال می شوند.
/// ساخت بهینه شده دستورات `debug_assert!` را اجرا نمی کند مگر اینکه `-C debug-assertions` به کامپایلر منتقل شود.
/// این باعث می شود `debug_assert!` برای چک هایی که برای تهیه در نسخه بسیار گران هستند ، اما ممکن است در طول توسعه مفید باشد ، مفید است.
/// نتیجه گسترش `debug_assert!` همیشه نوع تیک خورده است.
///
/// یک ادعای بدون کنترل به برنامه ای در حالت ناسازگار امکان ادامه کار می دهد ، که ممکن است عواقب غیر منتظره ای داشته باشد اما تا زمانی که این فقط در کد امن اتفاق نیفتد ، عدم امنیت را ایجاد نمی کند.
///
/// هزینه عملکرد ادعاها ، به طور کلی قابل اندازه گیری نیست.
/// جایگزینی [`assert!`] با `debug_assert!` فقط پس از مشخصات کامل تشویق می شود ، و مهمتر از همه ، فقط در کد امن!
///
/// # Examples
///
/// ```
/// // پیام panic برای این ادعاها مقدار رشته ای عبارت داده شده است.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // یک عملکرد بسیار ساده
/// debug_assert!(some_expensive_computation());
///
/// // با یک پیام سفارشی ادعا کنید
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// ادعا می کند که دو عبارت با یکدیگر برابر هستند.
///
/// در panic ، این ماکرو مقادیر عبارات را با نمایش اشکال زدایی آنها چاپ می کند.
///
/// برخلاف [`assert_eq!`] ، دستورات `debug_assert_eq!` به صورت پیش فرض فقط در ساختهای غیربهینه فعال می شوند.
/// ساخت بهینه شده دستورات `debug_assert_eq!` را اجرا نمی کند مگر اینکه `-C debug-assertions` به کامپایلر منتقل شود.
/// این باعث می شود `debug_assert_eq!` برای چک هایی که برای تهیه در نسخه بسیار گران هستند ، اما ممکن است در طول توسعه مفید باشد ، مفید است.
///
/// نتیجه گسترش `debug_assert_eq!` همیشه نوع تیک خورده است.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// ادعا می کند که دو عبارت با یکدیگر برابر نیستند.
///
/// در panic ، این ماکرو مقادیر عبارات را با نمایش اشکال زدایی آنها چاپ می کند.
///
/// برخلاف [`assert_ne!`] ، دستورات `debug_assert_ne!` به صورت پیش فرض فقط در ساختهای غیربهینه فعال می شوند.
/// ساخت بهینه شده دستورات `debug_assert_ne!` را اجرا نمی کند مگر اینکه `-C debug-assertions` به کامپایلر منتقل شود.
/// این باعث می شود `debug_assert_ne!` برای چک هایی که برای تهیه در نسخه بسیار گران هستند ، اما ممکن است در طول توسعه مفید باشد ، مفید است.
///
/// نتیجه گسترش `debug_assert_ne!` همیشه نوع تیک خورده است.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// اینکه آیا عبارت داده شده با هر یک از الگوهای داده شده مطابقت دارد یا خیر.
///
/// مانند یک عبارت `match` ، الگوی را می توان به صورت اختیاری `if` و یک عبارت محافظ را دنبال کرد که به نامهای محدود شده توسط الگو دسترسی دارد.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// نتیجه را باز کرده یا خطای آن را گسترش می دهد.
///
/// اپراتور `?` به جای `try!` اضافه شد و باید به جای آن استفاده شود.
/// علاوه بر این ، `try` یک کلمه اختصاصی در Rust 2018 است ، بنابراین اگر باید از آن استفاده کنید ، باید از [raw-identifier syntax][ris] استفاده کنید: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` با [`Result`] داده شده مطابقت دارد.در مورد نوع `Ok` ، این عبارت دارای مقدار مقدار بسته بندی شده است.
///
/// در صورت نسخه `Err` ، خطای داخلی را بازیابی می کند.`try!` سپس با استفاده از `From` تبدیل را انجام می دهد.
/// این امکان تبدیل خودکار بین خطاهای تخصصی و خطاهای کلی تر را فراهم می کند.
/// خطای حاصل بلافاصله برگردانده می شود.
///
/// به دلیل بازگشت زود هنگام ، `try!` فقط در توابعی که [`Result`] را برمی گرداند قابل استفاده است.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // روش ارجح برای بازگشت سریع خطاها
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // روش قبلی بازگشت سریع خطاها
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // این معادل است با:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// داده های قالب بندی شده را در یک بافر می نویسد.
///
/// این ماکرو 'writer' ، رشته فرمت و لیستی از آرگومان ها را می پذیرد.
/// آرگومان ها با توجه به رشته قالب مشخص شده قالب بندی می شوند و نتیجه به نویسنده منتقل می شود.
/// نویسنده ممکن است با استفاده از روش `write_fmt` هر مقداری باشد.به طور کلی این از اجرای [`fmt::Write`] یا [`io::Write`] trait ناشی می شود.
/// ماکرو هرچه روش `write_fmt` برگرداند را برمی گرداند.معمولاً [`fmt::Result`] یا [`io::Result`].
///
/// برای اطلاعات بیشتر در مورد نحو رشته قالب به [`std::fmt`] مراجعه کنید.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// یک ماژول می تواند `std::fmt::Write` و `std::io::Write` را وارد کند و با `write!` روی اشیایی که اجرا می کنند تماس بگیرد ، زیرا اشیا به طور معمول هر دو را اجرا نمی کنند.
///
/// با این حال ، ماژول باید traits واجد شرایط را وارد کند تا نام آنها مغایرت نداشته باشد:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // از fmt::Write::write_fmt استفاده می کند
///     write!(&mut v, "s = {:?}", s)?; // از io::Write::write_fmt استفاده می کند
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: از این ماکرو می توان در تنظیمات `no_std` نیز استفاده کرد.
/// در نصب `no_std` شما مسئول جزئیات پیاده سازی اجزا هستید.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// داده های قالب بندی شده را در یک بافر بنویسید و یک خط جدید به آن اضافه شود.
///
/// در همه سیستم عامل ها ، خط جدید شخصیت LINE FEED (`\n`/`U+000A`) به تنهایی است (بدون CARRIAGE RETURN (`\r`/`U+000D`) اضافی).
///
/// برای اطلاعات بیشتر ، به [`write!`] مراجعه کنید.برای اطلاعات در مورد نحو رشته قالب ، به [`std::fmt`] مراجعه کنید.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// یک ماژول می تواند `std::fmt::Write` و `std::io::Write` را وارد کند و با `write!` روی اشیایی که اجرا می کنند تماس بگیرد ، زیرا اشیا به طور معمول هر دو را اجرا نمی کنند.
/// با این حال ، ماژول باید traits واجد شرایط را وارد کند تا نام آنها مغایرت نداشته باشد:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // از fmt::Write::write_fmt استفاده می کند
///     writeln!(&mut v, "s = {:?}", s)?; // از io::Write::write_fmt استفاده می کند
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// کد غیرقابل دسترسی را نشان می دهد.
///
/// این مفید است هر زمان که کامپایلر نتواند غیرقابل دسترسی بودن برخی از کدها را تشخیص دهد.مثلا:
///
/// * بازوها را با شرایط نگهبانی مطابقت دهید.
/// * حلقه هایی که به صورت پویا خاتمه می یابند.
/// * تکرارکنندگانی که به صورت پویا خاتمه می یابند.
///
/// اگر تشخیص نادرست بودن کد ثابت شود ، برنامه بلافاصله با [`panic!`] خاتمه می یابد.
///
/// همتای ناامن این ماکرو عملکرد [`unreachable_unchecked`] است که در صورت دستیابی به کد باعث ایجاد رفتار تعریف نشده می شود.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// این همیشه [`panic!`] خواهد بود.
///
/// # Examples
///
/// بازوهای تطبیقی:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // اگر کامنت گذاشته شود خطای کامپایل را انجام دهید
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // یکی از ضعیف ترین پیاده سازی های x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// با وحشت زدگی با پیام "not implemented" کد انجام نشده را نشان می دهد.
///
/// این اجازه می دهد تا کد شما نوع تایپ را بررسی کند ، که اگر در حال نمونه سازی یا پیاده سازی trait هستید که به چندین روش احتیاج دارد و قصد ندارید از همه آنها استفاده کنید ، مفید است.
///
/// تفاوت بین `unimplemented!` و [`todo!`] این است که در حالی که `todo!` قصد پیاده سازی عملکرد را بعداً دارد و پیام "not yet implemented" است ، `unimplemented!` چنین ادعایی ندارد.
/// پیام آن "not implemented" است.
/// همچنین برخی از IDE ها "todo!" را علامت گذاری می کنند.
///
/// # Panics
///
/// این همیشه [`panic!`] خواهد بود زیرا `unimplemented!` فقط یک مختصر برای `panic!` با یک پیام خاص و ثابت است.
///
/// مانند `panic!` ، این ماکرو فرم دوم را نیز برای نمایش مقادیر سفارشی دارد.
///
/// # Examples
///
/// بگویید ما یک trait `Foo` داریم:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// ما می خواهیم `Foo` را برای 'MyStruct' پیاده سازی کنیم ، اما به دلایلی اجرای عملکرد `bar()` فقط منطقی است.
/// `baz()` و `qux()` همچنان باید در اجرای `Foo` تعریف شوند ، اما ما می توانیم از `unimplemented!` در تعاریف آنها استفاده کنیم تا کد ما کامپایل شود.
///
/// ما در صورت دستیابی به روشهای اجرا نشده هنوز می خواهیم برنامه خود را متوقف کنیم.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // برای `baz` `MyStruct` منطقی نیست ، بنابراین ما در اینجا هیچ منطقی نداریم.
/////
///         // با این کار "thread 'main' panicked at 'not implemented'" نمایش داده می شود.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ما در اینجا منطقی داریم ، می توانیم پیامی را به موارد غیرمجاز اضافه کنیم!برای حذف ما
///         // این نمایش می دهد: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// کد ناتمام را نشان می دهد.
///
/// اگر در حال نمونه سازی هستید و فقط به دنبال تیک زدن کد خود هستید ، این می تواند مفید باشد.
///
/// تفاوت بین [`unimplemented!`] و `todo!` این است که در حالی که `todo!` قصد پیاده سازی عملکرد را بعداً دارد و پیام "not yet implemented" است ، `unimplemented!` چنین ادعایی ندارد.
/// پیام آن "not implemented" است.
/// همچنین برخی از IDE ها "todo!" را علامت گذاری می کنند.
///
/// # Panics
///
/// این همیشه [`panic!`] خواهد بود.
///
/// # Examples
///
/// در اینجا مثالی از برخی از کدهای در دست اجرا آورده شده است.ما یک trait `Foo` داریم:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// ما می خواهیم `Foo` را روی یکی از انواع خود پیاده سازی کنیم ، اما می خواهیم ابتدا فقط روی `bar()` کار کنیم.برای اینکه کد ما کامپایل شود ، باید `baz()` را پیاده سازی کنیم ، بنابراین می توانیم از `todo!` استفاده کنیم:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // پیاده سازی به اینجا می رود
///     }
///
///     fn baz(&self) {
///         // در حال حاضر نگران اجرای baz() نباشیم
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ما حتی از baz() استفاده نمی کنیم ، بنابراین این خوب است.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// تعاریف ماکرو داخلی
///
/// بیشتر خصوصیات کلان (پایداری ، دید و غیره) از کد منبع در اینجا گرفته شده است ، به استثنای توابع انبساط که ورودی های ماکرو را به خروجی تبدیل می کند ، این توابع توسط کامپایلر ارائه می شوند.
///
///
pub(crate) mod builtin {

    /// باعث می شود که هنگام تلفیق ، پیام با خطای داده شده ترکیب نشود.
    ///
    /// این ماکرو باید زمانی استفاده شود که crate از استراتژی تدوین مشروط برای ارائه پیام های خطای بهتر برای شرایط اشتباه استفاده کند.
    ///
    /// این فرم در سطح کامپایلر [`panic!`] است ، اما در هنگام *کامپایل* به جای *در زمان اجرا* خطایی ایجاد می کند.
    ///
    /// # Examples
    ///
    /// دو نمونه از این قبیل ، محیط های ماکرو و `#[cfg]` است.
    ///
    /// اگر مقادیر نامعتبر از ماکرو گذشت ، خطای کامپایلر بهتری ایجاد کنید.
    /// بدون branch نهایی ، کامپایلر هنوز یک خطا منتشر می کند ، اما در پیام خطا دو مقدار معتبر ذکر نشده است.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// اگر یکی از چندین ویژگی در دسترس نباشد ، خطای کامپایلر را منتشر کنید.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// پارامترهای دیگر ماکروهای قالب بندی رشته را می سازد.
    ///
    /// این ماکرو با در نظر گرفتن یک رشته قالب بندی تحت اللفظی حاوی `{}` برای هر آرگومان اضافی ، عمل می کند.
    /// `format_args!` پارامترهای اضافی را آماده می کند تا اطمینان حاصل کند که خروجی می تواند به عنوان یک رشته تفسیر شود و آرگومان ها را به یک نوع واحد متعارف می کند.
    /// هر مقداری که [`Display`] trait را پیاده سازی می کند می تواند به `format_args!` منتقل شود ، همچنین هر پیاده سازی [`Debug`] می تواند به `{:?}` درون رشته قالب بندی منتقل شود.
    ///
    ///
    /// این ماکرو مقداری از نوع [`fmt::Arguments`] تولید می کند.این مقدار برای انجام تغییر مسیر مفید می تواند به ماکروهای [`std::fmt`] منتقل شود.
    /// تمام ماکروهای قالب بندی دیگر (["قالب!" ، [`write!`] ، [`println!`] و غیره) از طریق این یکی پروکسی می شوند.
    /// `format_args!`, برخلاف ماکروهای مشتق شده از تخصیص انبوه جلوگیری می کند.
    ///
    /// همانطور که در زیر مشاهده می شود می توانید از مقدار [`fmt::Arguments`] که `format_args!` در زمینه های `Debug` و `Display` برمی گرداند استفاده کنید.
    /// این مثال همچنین نشان می دهد که فرمت های `Debug` و `Display` به همان چیز: رشته فرمت درونی در `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// برای اطلاعات بیشتر ، به اسناد موجود در [`std::fmt`] مراجعه کنید.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// همان `format_args` است ، اما در پایان یک خط جدید اضافه می کند.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// یک متغیر محیط را در زمان کامپایل بازرسی می کند.
    ///
    /// این ماکرو به مقدار متغیر محیط نامگذاری شده در زمان کامپایل گسترش می یابد و عبارتی از نوع `&'static str` را به دست می دهد.
    ///
    ///
    /// اگر متغیر محیط تعریف نشده باشد ، خطای تلفیقی منتشر می شود.
    /// برای عدم انتشار خطای کامپایل ، به جای آن از ماکرو [`option_env!`] استفاده کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// می توانید پیام خطا را با عبور دادن یک رشته به عنوان پارامتر دوم شخصی سازی کنید:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// اگر متغیر محیط `documentation` تعریف نشده باشد ، با خطای زیر مواجه خواهید شد:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// به صورت اختیاری یک متغیر محیط را در زمان کامپایل بازرسی می کند.
    ///
    /// اگر متغیر محیط نامگذاری شده در زمان کامپایل وجود داشته باشد ، این حالت به عبارتی از نوع `Option<&'static str>` گسترش می یابد که مقدار آن `Some` مقدار متغیر محیط است.
    /// اگر متغیر محیط وجود نداشته باشد ، این امر تا `None` گسترش می یابد.
    /// برای اطلاعات بیشتر در مورد این نوع به [`Option<T>`][Option] مراجعه کنید.
    ///
    /// صرف نظر از وجود یا عدم وجود متغیر محیط ، هرگز هنگام استفاده از این ماکرو خطای کامپایل ساطع نمی شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// شناسه ها را به یک شناسه متصل می کند.
    ///
    /// این ماکرو هر تعداد شناسه جدا شده با ویرگول را می گیرد و همه آنها را به هم متصل می کند و یک عبارت را می دهد که یک شناسه جدید است.
    /// توجه داشته باشید که بهداشت باعث شده است که این ماکرو نتواند متغیرهای محلی را ضبط کند.
    /// همچنین ، به عنوان یک قاعده کلی ، ماکرو فقط در مورد ، عبارت یا موقعیت بیان مجاز است.
    /// این بدان معناست که اگر شما می توانید از این ماکرو برای مراجعه به متغیرهای موجود ، توابع یا ماژول ها و غیره استفاده کنید ، نمی توانید یک جدید با آن تعریف کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (جدید ، سرگرم کننده ، نام) { }//از این طریق قابل استفاده نیست!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// اصطلاحات واقعی را به یک برش رشته ثابت متصل می کند.
    ///
    /// این ماکرو به هر تعداد از حروف الفبا با کاما جدا می شود ، و عبارتی از نوع `&'static str` را به دست می دهد که نشان دهنده تمام حروف الفبا است که از چپ به راست به هم متصل شده اند.
    ///
    ///
    /// اصطلاحات صحیح و نقطه شناور برای اینکه بهم پیوسته شوند رشته ای هستند.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// به شماره خطی که در آن فراخوانی شده است ، گسترش می یابد.
    ///
    /// با استفاده از [`column!`] و [`file!`] ، این ماکروها اطلاعات اشکال زدایی را در مورد مکان درون منبع برای توسعه دهندگان فراهم می کنند.
    ///
    /// عبارت گسترش یافته از نوع `u32` است و بر پایه 1 است ، بنابراین اولین خط در هر پرونده به 1 ، دوم به 2 و غیره ارزیابی می شود.
    /// این با پیام های خطای کامپایلرهای رایج یا ویراستاران محبوب سازگار است.
    /// خط برگشتی *لزوماً* خط فراخوانی `line!` نیست بلکه اولین فراخوانی ماکرو است که منجر به فراخوانی ماکرو `line!` می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// به شماره ستونی که در آن فراخوانی شده است گسترش می یابد.
    ///
    /// با استفاده از [`line!`] و [`file!`] ، این ماکروها اطلاعات اشکال زدایی را در مورد مکان درون منبع برای توسعه دهندگان فراهم می کنند.
    ///
    /// عبارت گسترش یافته از نوع `u32` است و 1 پایه دارد ، بنابراین اولین ستون در هر سطر به 1 ، دوم به 2 و غیره ارزیابی می شود.
    /// این با پیام های خطای کامپایلرهای رایج یا ویراستاران محبوب سازگار است.
    /// ستون برگشتی * لزوماً خط خود فراخوانی `column!` نیست ، بلکه اولین فراخوانی کلان است که منجر به فراخوانی ماکرو `column!` می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// نام پرونده ای را که در آن فراخوانی شده است گسترش می دهد.
    ///
    /// با استفاده از [`line!`] و [`column!`] ، این ماکروها اطلاعات اشکال زدایی را در مورد مکان درون منبع برای توسعه دهندگان فراهم می کنند.
    ///
    /// عبارت گسترش یافته از نوع `&'static str` است ، و پرونده برگشتی فراخوانی ماکرو `file!` نیست بلکه اولین فراخوانی ماکرو است که منجر به فراخوانی ماکرو `file!` می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// استدلال های خود را رشته ای می کند.
    ///
    /// این ماکرو عبارتی از نوع `&'static str` را ارائه می دهد که رشته ای تمام tokens منتقل شده به ماکرو است.
    /// برای نحو فراخوانی کلان هیچ محدودیتی اعمال نشده است.
    ///
    /// توجه داشته باشید که نتایج توسعه یافته ورودی tokens ممکن است در future تغییر کند.اگر به خروجی تکیه می کنید باید مراقب باشید.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// شامل یک فایل رمزگذاری شده UTF-8 به عنوان یک رشته.
    ///
    /// پرونده نسبت به پرونده فعلی قرار دارد (به طور مشابه نحوه یافتن ماژول ها).
    /// مسیر ارائه شده در زمان کامپایل به روشی مخصوص پلتفرم تفسیر می شود.
    /// بنابراین ، برای مثال ، فراخوانی با مسیر Windows حاوی Backslashes `\` به درستی در Unix کامپایل نمی شود.
    ///
    ///
    /// این ماکرو عبارتی از نوع `&'static str` را ارائه می دهد که محتوای فایل است.
    ///
    /// # Examples
    ///
    /// فرض کنید دو پرونده در همان دایرکتوری با محتوای زیر وجود دارد:
    ///
    /// پرونده 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// پرونده 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// با کامپایل 'main.rs' و اجرای باینری حاصل ، "adiós" چاپ می شود.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// شامل پرونده ای به عنوان ارجاع به یک آرایه بایت است.
    ///
    /// پرونده نسبت به پرونده فعلی قرار دارد (به طور مشابه نحوه یافتن ماژول ها).
    /// مسیر ارائه شده در زمان کامپایل به روشی مخصوص پلتفرم تفسیر می شود.
    /// بنابراین ، برای مثال ، فراخوانی با مسیر Windows حاوی Backslashes `\` به درستی در Unix کامپایل نمی شود.
    ///
    ///
    /// این ماکرو عبارتی از نوع `&'static [u8; N]` را ارائه می دهد که محتوای فایل است.
    ///
    /// # Examples
    ///
    /// فرض کنید دو پرونده در همان دایرکتوری با محتوای زیر وجود دارد:
    ///
    /// پرونده 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// پرونده 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// با کامپایل 'main.rs' و اجرای باینری حاصل ، "adiós" چاپ می شود.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// به رشته ای گسترش می یابد که نشان دهنده مسیر ماژول فعلی است.
    ///
    /// مسیر ماژول فعلی را می توان به عنوان سلسله مراتب ماژول هایی دانست که به crate root منتهی می شوند.
    /// اولین جز component مسیر برگشت شده ، نام crate است که در حال حاضر در حال کامپایل است.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// ترکیب بولی پرچم های پیکربندی را در زمان کامپایل ارزیابی می کند.
    ///
    /// علاوه بر ویژگی `#[cfg]` ، این ماکرو برای ارزیابی بیان بولی پرچم های پیکربندی ارائه شده است.
    /// این به کدهای تکراری کمتر منجر می شود.
    ///
    /// نحو داده شده به این ماکرو همان نحو ویژگی [`cfg`] است.
    ///
    /// `cfg!`, برخلاف `#[cfg]` ، هیچ کدی را حذف نمی کند و فقط درست یا نادرست را ارزیابی می کند.
    /// به عنوان مثال ، تمام بلوک های عبارت if/else باید معتبر باشند وقتی `cfg!` برای شرایط استفاده می شود ، صرف نظر از اینکه `cfg!` چه چیزی را ارزیابی می کند.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// با توجه به زمینه ، پرونده را به عنوان عبارت یا مورد تجزیه می کند.
    ///
    /// پرونده نسبت به پرونده فعلی قرار دارد (به طور مشابه نحوه یافتن ماژول ها).مسیر ارائه شده در زمان کامپایل به روشی مخصوص پلتفرم تفسیر می شود.
    /// بنابراین ، برای مثال ، فراخوانی با مسیر Windows حاوی Backslashes `\` به درستی در Unix کامپایل نمی شود.
    ///
    /// استفاده از این ماکرو اغلب ایده بدی است ، زیرا اگر پرونده به عنوان عبارت تجزیه شود ، قرار است به صورت غیر بهداشتی در کد اطراف قرار گیرد.
    /// در صورت وجود متغیرها یا توابع با نام مشابه در پرونده فعلی ، این می تواند متغیرها یا توابع متفاوت از آنچه فایل انتظار داشت باشد.
    ///
    ///
    /// # Examples
    ///
    /// فرض کنید دو پرونده در همان دایرکتوری با محتوای زیر وجود دارد:
    ///
    /// پرونده 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// پرونده 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// با کامپایل 'main.rs' و اجرای باینری حاصل ، "🙈🙊🙉🙈🙊🙉" چاپ می شود.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ادعا می کند که یک عبارت بولی در زمان اجرا `true` است.
    ///
    /// اگر عبارت ارائه شده نتواند هنگام اجرا به `true` ارزیابی شود ، ماکرو [`panic!`] را فراخوانی می کند.
    ///
    /// # Uses
    ///
    /// ادعاها همیشه در ساخت اشکال زدایی و انتشار بررسی می شوند و نمی توانند غیرفعال شوند.
    /// برای ادعاهایی که به طور پیش فرض در ساخت نسخه فعال نیستند ، به [`debug_assert!`] مراجعه کنید.
    ///
    /// کد ناامن ممکن است به `assert!` متکی باشد تا موارد نامحدود را اجرا کند که در صورت نقض می تواند منجر به عدم ایمنی شود.
    ///
    /// سایر موارد استفاده از `assert!` شامل آزمایش و اجرای موارد نامحدود در کد ایمن است (که نقض آنها نمی تواند منجر به عدم ایمنی شود).
    ///
    ///
    /// # پیام های سفارشی
    ///
    /// این ماکرو فرم دوم دارد که در آن می توان پیام panic سفارشی را با استدلال یا بدون استدلال برای قالب بندی ارائه داد.
    /// برای نحو برای این فرم به [`std::fmt`] مراجعه کنید.
    /// عباراتی که به عنوان آرگومان های قالب استفاده می شوند ، فقط در صورت عدم موفقیت در ادعا ارزیابی می شوند.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // پیام panic برای این ادعاها مقدار رشته ای عبارت داده شده است.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // یک عملکرد بسیار ساده
    ///
    /// assert!(some_computation());
    ///
    /// // با یک پیام سفارشی ادعا کنید
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// مونتاژ خطی
    ///
    /// [unstable book] را برای استفاده بخوانید.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// مونتاژ خطی به سبک LLVM.
    ///
    /// [unstable book] را برای استفاده بخوانید.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// مونتاژ خطی در سطح ماژول.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// چاپ ها tokens را به خروجی استاندارد منتقل می کردند.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// قابلیت ردیابی مورد استفاده برای اشکال زدایی از سایر ماکروها را فعال یا غیرفعال می کند.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ویژگی ماکرو که برای اعمال ماکروهای مشتق استفاده می شود.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ویژگی کلان به یک تابع اعمال می شود تا آن را به یک تست واحد تبدیل کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ویژگی کلان به یک تابع اعمال می شود تا آن را به یک تست معیار تبدیل کند.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// جزئیات پیاده سازی ماکروهای `#[test]` و `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// ویژگی کلان برای ثبت یک شخص به عنوان یک تخصیص دهنده جهانی اعمال می شود.
    ///
    /// به [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) نیز مراجعه کنید.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// موردی را که در آن استفاده شده است اگر مسیر عبور کرده قابل دسترسی باشد ، نگه می دارد و در غیر این صورت آن را حذف می کند.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// تمام ویژگی های `#[cfg]` و `#[cfg_attr]` را در قطعه کد مورد استفاده قرار می دهد.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// جزئیات اجرای ناپایدار کامپایلر `rustc` ، استفاده نکنید.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// جزئیات اجرای ناپایدار کامپایلر `rustc` ، استفاده نکنید.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}