Panics موضوع فعلی.

این اجازه می دهد تا یک برنامه فوراً خاتمه یابد و به تماس گیرنده برنامه بازخورد ارائه دهد.
`panic!` باید هنگامی که برنامه به حالت غیرقابل بازیابی می رسد استفاده شود.

این ماکرو بهترین روش برای اثبات شرایط در کد مثال و آزمون است.
`panic!` از نزدیک با روش `unwrap` هر دو شمارش [`Option`][ounwrap] و [`Result`][runwrap] گره خورده است.
هر دو پیاده سازی هنگامی که روی انواع [`None`] یا [`Err`] تنظیم شده باشند ، `panic!` را فراخوانی می کنند.

هنگام استفاده از `panic!()` می توانید محموله رشته ای را تعیین کنید که با استفاده از نحو [`format!`] ساخته شود.
از این محموله هنگام تزریق panic به نخ فراخوان Rust استفاده می شود و باعث می شود که رشته به طور کامل panic شود.

رفتار `std` hook پیش فرض ، یعنی
کدی که مستقیماً پس از فراخوانی panic اجرا می شود ، چاپ پیام بار به `stderr` همراه با اطلاعات file/line/column تماس `panic!()` است.

با استفاده از [`std::panic::set_hook()`] می توانید panic hook را نادیده بگیرید.
در داخل hook می توان به panic به صورت `&dyn Any + Send` دسترسی پیدا کرد ، که شامل `&str` یا `String` برای تماس های معمولی `panic!()` است.
برای panic با مقدار نوع دیگری ، می توان از [`panic_any`] استفاده کرد.

[`Result`] enum اغلب یک راه حل بهتر برای بازیابی از خطاها نسبت به استفاده از ماکرو `panic!` است.
برای جلوگیری از ادامه استفاده از مقادیر نادرست ، مانند منابع خارجی ، باید از این ماکرو استفاده شود.
اطلاعات دقیق در مورد مدیریت خطا در [book] یافت می شود.

برای ایجاد خطاهای در هنگام تدوین ، به ماکرو [`compile_error!`] نیز مراجعه کنید.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# اجرای فعلی

اگر موضوع اصلی panics باشد ، تمام رشته های شما را خاتمه می دهد و برنامه شما را با کد `101` خاتمه می دهد.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





