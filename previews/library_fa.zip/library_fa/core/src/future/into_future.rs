use crate::future::Future;

/// تبدیل به `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// خروجی که future پس از اتمام تولید می کند.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// ما این را به کدام نوع future تبدیل می کنیم؟
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// future را از یک مقدار ایجاد می کند.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}