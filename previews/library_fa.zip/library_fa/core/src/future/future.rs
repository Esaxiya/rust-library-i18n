#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// یک future یک محاسبه ناهمزمان را نشان می دهد.
///
/// future مقداری است که ممکن است هنوز محاسبه آن تمام نشده باشد.
/// این نوع "asynchronous value" این امکان را برای یک رشته فراهم می کند تا کار مفید را ادامه دهد در حالی که منتظر می ماند تا مقدار آن در دسترس باشد.
///
///
/// # روش `poll`
///
/// روش اصلی future ، `poll` ، * تلاش می کند تا future را به یک مقدار نهایی حل کند.
/// اگر مقدار آماده نباشد ، این روش مسدود نمی شود.
/// در عوض ، برنامه فعلی برنامه ریزی شده است تا زمانی که امکان پیشرفت بیشتر با "نظرسنجی" دوباره وجود دارد ، بیدار شود.
/// `context` که به روش `poll` منتقل شده است می تواند [`Waker`] را ارائه دهد ، که یک دسته برای بیدار کردن کار فعلی است.
///
/// هنگام استفاده از future ، معمولاً با `poll` مستقیم تماس نمی گیرید ، بلکه به جای آن `.await` مقدار است.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// نوع ارزش تولید شده پس از اتمام.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// سعی کنید future را به یک مقدار نهایی برسانید ، اگر مقدار هنوز در دسترس نیست ، کار فعلی را برای بیدار کردن ثبت کنید.
    ///
    /// # مقدار برگشتی
    ///
    /// این تابع باز می گردد:
    ///
    /// - [`Poll::Pending`] اگر future هنوز آماده نیست
    /// - [`Poll::Ready(val)`] در صورت موفقیت آمیز بودن `val` از این future.
    ///
    /// پس از اتمام future ، مشتریان نباید آن را دوباره `poll` کنند.
    ///
    /// وقتی future هنوز آماده نیست ، `poll` `Poll::Pending` را برمی گرداند و یک کلون از [`Waker`] کپی شده از [`Context`] فعلی را ذخیره می کند.
    /// هنگامی که future می تواند پیشرفت کند ، این [`Waker`] بیدار می شود.
    /// به عنوان مثال ، future که منتظر خواندن سوکت است با `.clone()` در [`Waker`] تماس گرفته و آن را ذخیره می کند.
    /// وقتی سیگنالی به جای دیگر می رسد که نشان می دهد سوکت قابل خواندن است ، [`Waker::wake`] فراخوانی می شود و وظیفه سوکت future بیدار می شود.
    /// پس از بیدار شدن یک کار ، باید دوباره `poll` future را امتحان کنید ، که ممکن است یک مقدار نهایی تولید کند یا نکند.
    ///
    /// توجه داشته باشید که در چندین تماس با `poll` ، فقط [`Waker`] از [`Context`] منتقل شده به آخرین تماس باید برای دریافت بیدار شدن برنامه ریزی شود.
    ///
    /// # ویژگی های زمان اجرا
    ///
    /// Futures به تنهایی *بی اثر هستند ؛برای پیشرفت باید "* فعالانه" نظرسنجی شوند ، به این معنی که هر بار که وظیفه فعلی بیدار می شود ، باید در انتظار futures که هنوز هم علاقه مند است ، دوباره "دوباره" جمع آوری کند.
    ///
    /// عملکرد `poll` به طور مکرر در یک حلقه فشرده فراخوانی نمی شود-در عوض ، فقط هنگامی باید فراخوانی شود که future نشان دهد که آماده پیشرفت است (با تماس با `wake()`).
    /// اگر با سیستم های `poll(2)` یا `select(2)` در Unix آشنا هستید ، لازم به ذکر است که futures به طور معمول از مشکلات "all wakeups must poll all events" رنج نمی برد.آنها بیشتر شبیه `epoll(4)` هستند.
    ///
    /// اجرای `poll` باید در تلاش برای بازگشت سریع باشد و نباید مسدود شود.بازگشت سریع مانع از گرفتگی بی مورد نخ ها یا حلقه های رویداد می شود.
    /// اگر زودتر از موعد مشخص شود که ممکن است مکالمه با `poll` مدتی طول بکشد ، کار باید در استخر نخ (یا چیزی شبیه به آن) بارگیری شود تا اطمینان حاصل شود که `poll` می تواند به سرعت برگردد.
    ///
    /// # Panics
    ///
    /// پس از اتمام future (بازگشت `Ready` از `poll`) ، فراخوانی مجدد روش `poll` ممکن است panic باشد ، برای همیشه مسدود شود یا مشکلات دیگری ایجاد کند.`Future` trait هیچگونه الزامی در مورد تأثیرات چنین فراخوانی ندارد.
    /// با این حال ، چون روش `poll` با `unsafe` مشخص نشده است ، قوانین معمول Rust اعمال می شود: تماس ها هرگز نباید باعث رفتار نامشخص (تخریب حافظه ، استفاده نادرست از توابع `unsafe` یا موارد مشابه) شوند ، صرف نظر از وضعیت future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}