#![stable(feature = "futures_api", since = "1.36.0")]

//! مقادیر ناهمگام.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// این نوع مورد نیاز است زیرا:
///
/// الف) ژنراتورها نمی توانند `for<'a, 'b> Generator<&'a mut Context<'b>>` را پیاده سازی کنند ، بنابراین ما باید از یک اشاره گر خام عبور کنیم (نگاه کنید به <https://github.com/rust-lang/rust/issues/68923>).
///
/// ب) اشاره گرهای خام و `NonNull` `Send` یا `Sync` نیستند ، بنابراین باعث ایجاد تک تک future non-Send/Sync نیز می شود و ما این را نمی خواهیم.
///
/// همچنین کاهش HIR `.await` را ساده می کند.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// یک ژنراتور را در future بپیچید.
///
/// این تابع یک `GenFuture` را از زیر برمی گرداند ، اما آن را در `impl Trait` پنهان می کند تا پیام های خطای بهتری (`impl Future` به جای `GenFuture<[closure.....]>`) ارائه دهد.
///
// این `const` است تا بعد از بهبودی از `const async fn` از خطاهای اضافی جلوگیری شود
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // ما به این واقعیت تکیه می کنیم که async/await futures برای ایجاد وام های خود ارجاع در ژنراتور اصلی غیرقابل حرکت هستند.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ایمنی: ایمن زیرا ما !Unpin + !Drop هستیم و این فقط یک پیش بینی میدانی است.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // ژنراتور را از سر بگیرید و `&mut Context` را به یک نشانگر خام `NonNull` تبدیل کنید.
            // پایین آمدن `.await` با اطمینان آن را به `&mut Context` تبدیل می کند.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ایمنی: تماس گیرنده باید تضمین کند که `cx.0` یک اشاره گر معتبر است
    // که تمام الزامات یک مرجع متغیر را برآورده می کند.
    unsafe { &mut *cx.0.as_ptr().cast() }
}