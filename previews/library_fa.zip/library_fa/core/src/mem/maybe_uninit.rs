use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// یک نوع لفافه برای ساخت نمونه های غیر اولیه `T`.
///
/// # مقداردهی اولیه
///
/// کامپایلر به طور کلی فرض می کند که یک متغیر با توجه به نیاز نوع متغیر به درستی مقدار دهی می شود.به عنوان مثال ، یک متغیر از نوع مرجع باید تراز شده و غیر NULL باشد.
/// این یک تغییر ناپذیر است که باید *همیشه*، حتی در کد های ناامن ، از آن پشتیبانی شود.
/// در نتیجه ، مقداردهی اولیه صفر متغیر از نوع مرجع باعث ایجاد [undefined behavior][ub] فوری می شود ، مهم نیست که آیا این مرجع برای دسترسی به حافظه مورد استفاده قرار می گیرد:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // رفتار تعریف نشده!⚠️
/// // کد معادل آن با `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // رفتار تعریف نشده!⚠️
/// ```
///
/// این کامپایلر برای بهینه سازی های مختلف مانند حذف چک های زمان اجرا و بهینه سازی طرح `enum` مورد سو explo استفاده قرار می گیرد.
///
/// به همین ترتیب ، ممكن است حافظه كاملاً غیرساختاری دارای هرگونه محتوا باشد ، در حالی كه `bool` باید همیشه `true` یا `false` باشد.از این رو ، ایجاد یک `bool` غیر ابتدایی یک رفتار تعریف نشده است:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // رفتار تعریف نشده!⚠️
/// // کد معادل آن با `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // رفتار تعریف نشده!⚠️
/// ```
///
/// علاوه بر این ، حافظه غیر اولیه از این جهت خاصیت خاصی دارد که دارای مقدار ثابت نیست ("fixed" به معنای "it won't change without being written to").چندین بار خواندن یک بایت غیر اولیه یکسان می تواند نتایج متفاوتی ایجاد کند.
/// این باعث می شود که داده های غیر اولیه در یک متغیر حتی اگر آن متغیر دارای یک نوع عدد صحیح باشد ، یک رفتار تعریف نشده است: در غیر این صورت می تواند هر الگوی بیتی *ثابت* را نگه دارد:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // رفتار تعریف نشده!⚠️
/// // کد معادل آن با `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // رفتار تعریف نشده!⚠️
/// ```
/// (توجه داشته باشید که قوانین مربوط به اعداد صحیح غیر اولیه هنوز نهایی نشده اند ، اما تا زمان تکمیل آنها توصیه می شود از آنها اجتناب کنید.)
///
/// علاوه بر این ، به یاد داشته باشید که اکثر انواع دارای موارد اضافی فراتر از صرفاً ابتکاری در سطح نوع هستند.
/// به عنوان مثال ، [`Vec<T>`] با مقدار 1 "" مقداردهی اولیه در نظر گرفته می شود (تحت اجرای فعلی ، این یک ضمانت پایدار محسوب نمی شود) زیرا تنها الزامی که کامپایلر در مورد آن می داند این است که نشانگر داده باید غیر تهی باشد.
/// ایجاد چنین `Vec<T>` باعث رفتار *فوری* تعریف نشده نمی شود ، بلکه با اکثر عملیات ایمن (از جمله انداختن آن) باعث یک رفتار تعریف نشده می شود.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` در خدمت فعال کردن کد ناامن برای مقابله با داده های غیر اولیه است.
/// این یک سیگنال به کامپایلر است که نشان می دهد داده ها در اینجا ممکن است * ** ** ** مقدماتی نباشد:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // یک مرجع صریحاً غیر اولیه ایجاد کنید.
/// // کامپایلر می داند که داده های داخل `MaybeUninit<T>` ممکن است نامعتبر باشد ، بنابراین این UB نیست:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // آن را روی یک مقدار معتبر تنظیم کنید.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // داده های اولیه را استخراج کنید-این فقط *پس از* تنظیم اولیه `x` به صورت صحیح مجاز است!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// سپس کامپایلر می داند که هیچگونه پیش فرض یا بهینه سازی نادرستی در مورد این کد انجام ندهد.
///
/// شما می توانید `MaybeUninit<T>` را کمی شبیه `Option<T>` بدانید اما بدون هیچ یک از ردیابی های زمان اجرا و بدون هیچ گونه بررسی ایمنی.
///
/// ## out-pointers
///
/// برای پیاده سازی "out-pointers" می توانید از `MaybeUninit<T>` استفاده کنید: به جای برگرداندن داده از یک تابع ، آن را به برخی از حافظه های (uninitialized) نشانگر منتقل کنید تا نتیجه را در آن قرار دهید.
/// این امر زمانی می تواند مفید باشد که برای تماس گیرنده کنترل نحوه ذخیره سازی حافظه ای که نتیجه در آن ذخیره می شود ، مهم باشد و شما می خواهید از حرکت های غیرضروری جلوگیری کنید.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` مطالب قدیمی را رها نمی کند ، که مهم است.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // اکنون می دانیم که `v` مقداردهی اولیه شده است!این امر همچنین اطمینان حاصل می کند که vector به درستی افتاده است.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## شروع یک آرایه عنصر به عنصر
///
/// `MaybeUninit<T>` می توان برای شروع یک آرایه بزرگ عنصر به عنصر استفاده کرد:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // یک آرایه غیر اولیه `MaybeUninit` ایجاد کنید.
///     // `assume_init` بی خطر است زیرا نوعی که ادعا می کنیم در اینجا مقدار اولیه آن را گرفته ایم یک دسته `MaybeUninit` است که نیازی به مقداردهی اولیه ندارند.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // انداختن `MaybeUninit` هیچ کاری نمی کند.
///     // بنابراین استفاده از تخصیص اشاره گر خام به جای `ptr::write` باعث نمی شود که مقدار غیر اولیه اولیه حذف شود.
/////
///     // همچنین اگر در طول این حلقه panic وجود داشته باشد ، ما نشت حافظه داریم ، اما هیچ مشکلی برای ایمنی حافظه وجود ندارد.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // همه چیز مقدماتی است.
///     // آرایه را به نوع اولیه تبدیل کنید.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// همچنین می توانید با آرایه های نیمه اولیه کار کنید ، که می تواند در ساختار داده های سطح پایین یافت شود.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // یک آرایه غیر اولیه `MaybeUninit` ایجاد کنید.
/// // `assume_init` بی خطر است زیرا نوعی که ادعا می کنیم در اینجا مقدار اولیه آن را گرفته ایم یک دسته `MaybeUninit` است که نیازی به مقداردهی اولیه ندارند.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // تعداد عناصر اختصاص داده شده را بشمارید.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // برای هر مورد در آرایه ، اگر آن را اختصاص دهیم ، آن را رها کنید.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## آغاز ساخت یک ساختار به یک زمینه
///
/// می توانید از `MaybeUninit<T>` و از ماکرو [`std::ptr::addr_of_mut`] برای مقدمه گذاری زمینه ها به قسمت های مختلف استفاده کنید:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // شروع قسمت `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // شروع فیلد `list` اگر در اینجا panic وجود داشته باشد ، `String` در قسمت `name` نشت می کند.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // همه قسمت ها مقداردهی اولیه شده اند ، بنابراین ما برای دریافت Foo اولیه با `assume_init` تماس می گیریم.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` دارای همان اندازه ، تراز و ABI با `T` تضمین شده است:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// اما به یاد داشته باشید که یک نوع *حاوی*`MaybeUninit<T>` لزوماً همان طرح نیست.Rust به طور کلی تضمین نمی کند که فیلدهای `Foo<T>` همان نظم `Foo<U>` را دارند حتی اگر `T` و `U` دارای اندازه و تراز بندی یکسان باشند.
///
/// بعلاوه از آنجا که هر مقدار بیت برای `MaybeUninit<T>` معتبر است ، کامپایلر نمی تواند بهینه سازی های non-zero/niche-filling را اعمال کند ، به طور بالقوه منجر به اندازه بزرگتر می شود:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// اگر `T` از نظر FFI ایمن نیست ، `MaybeUninit<T>` نیز ایمن است.
///
/// در حالی که `MaybeUninit` `#[repr(transparent)]` است (نشان می دهد که همان اندازه ، تراز و ABI را با `T` تضمین می کند) ، این * هیچکدام از موارد قبلی را تغییر نمی دهد.
/// `Option<T>` و `Option<MaybeUninit<T>>` ممکن است هنوز اندازه های متفاوتی داشته باشند ، و انواع حاوی فیلدی از نوع `T` ممکن است متفاوت از آن فیلد `MaybeUninit<T>` باشد (و اندازه).
/// `MaybeUninit` از نوع اتحادیه است و `#[repr(transparent)]` در اتحادیه ها ناپایدار است (نگاه کنید به [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// با گذشت زمان ، تضمین های دقیق `#[repr(transparent)]` در اتحادیه ها ممکن است تکامل یابد و `MaybeUninit` ممکن است `#[repr(transparent)]` باقی بماند یا نماند.
/// همانطور که گفته شد ، `MaybeUninit<T>`*همیشه* تضمین می کند که همان اندازه ، تراز و ABI آن همان `T` باشد.فقط ممکن است نحوه پیاده سازی تضمین `MaybeUninit` تکامل یابد.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// مورد را لنگ کنید تا بتوانیم انواع دیگر را در آن بپیچیم.این برای ژنراتورها مفید است.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // اگر با `T::clone()` تماس نگیریم ، نمی توانیم بفهمیم که آیا برای این کار مقداردهی اولیه داریم یا خیر.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// `MaybeUninit<T>` جدیدی را با مقدار داده شده ایجاد می کند.
    /// با مقدار برگشتی این عملکرد [`assume_init`] امن است.
    ///
    /// توجه داشته باشید که انداختن `MaybeUninit<T>` هرگز با کد افت «T» تماس نخواهد گرفت.
    /// این وظیفه شماست که در صورت اولیه سازی `T` رها شود.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// `MaybeUninit<T>` جدید را در حالت غیر اولیه ایجاد می کند.
    ///
    /// توجه داشته باشید که انداختن `MaybeUninit<T>` هرگز با کد افت «T» تماس نخواهد گرفت.
    /// این وظیفه شماست که در صورت اولیه سازی `T` رها شود.
    ///
    /// برای چند مثال به [type-level documentation][MaybeUninit] مراجعه کنید.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// یک آرایه جدید از موارد `MaybeUninit<T>` ، در حالت غیر اولیه ایجاد کنید.
    ///
    /// Note: در یک نسخه future Rust ، این روش ممکن است غیرضروری باشد ، زیرا نحو واقعی آرایه اجازه [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) را می دهد.
    ///
    /// مثال زیر می تواند از `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` استفاده کند.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// برشی از اطلاعات (احتمالاً کوچکتر) را که در واقع خوانده شده اند برمی گرداند
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ایمنی: `[MaybeUninit<_>; LEN]` غیر اولیه معتبر است.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// `MaybeUninit<T>` جدید را در حالت غیر اولیه ایجاد می کند ، با حافظه پر شده با بایت `0`.این به `T` بستگی دارد که آیا در حال حاضر برای شروع اولیه مناسب است.
    ///
    /// به عنوان مثال ، `MaybeUninit<usize>::zeroed()` مقداردهی اولیه می شود ، اما `MaybeUninit<&'static i32>::zeroed()` به این دلیل نیست که منابع نباید پوچ باشند.
    ///
    /// توجه داشته باشید که انداختن `MaybeUninit<T>` هرگز با کد افت «T» تماس نخواهد گرفت.
    /// این وظیفه شماست که در صورت اولیه سازی `T` رها شود.
    ///
    /// # Example
    ///
    /// استفاده صحیح از این تابع: مقداردهی اولیه یک ساختار با صفر ، جایی که همه زمینه های ساختار می توانند الگوی بیت 0 را به عنوان یک مقدار معتبر نگه دارند.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// * استفاده نادرست از این عملکرد: فراخوانی `x.zeroed().assume_init()` وقتی `0` الگوی بیتی معتبری برای نوع نیست:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // در داخل یک جفت ، ما `NotZero` ایجاد می کنیم که تفکیک معتبری ندارد.
    /// // این یک رفتار تعریف نشده است.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SAFETY: `u.as_mut_ptr()` به حافظه اختصاص یافته اشاره می کند.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// مقدار `MaybeUninit<T>` را تنظیم می کند.
    /// این مقدار بدون انداختن هر مقدار قبلی را جایگزین می کند ، بنابراین مراقب باشید دو بار از آن استفاده نکنید مگر اینکه بخواهید از اجرای تخریب کننده صرف نظر کنید.
    ///
    /// برای راحتی شما ، این امر همچنین اشاره ای قابل تغییر به محتوای `self` (که اکنون با خیال راحت آغاز شده است) را برمی گرداند.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ایمنی: ما فقط این مقدار را مقداردهی اولیه کردیم.
        unsafe { self.assume_init_mut() }
    }

    /// یک نشانگر به مقدار موجود می رساند.
    /// خواندن از این نشانگر یا تبدیل آن به مرجع یک رفتار تعریف نشده است ، مگر اینکه `MaybeUninit<T>` اولیه شود.
    /// نوشتن روی حافظه ای که این اشاره گر (non-transitively) به آن اشاره می کند یک رفتار تعریف نشده است (به جز در داخل `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// استفاده صحیح از این روش:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // یک مرجع در `MaybeUninit<T>` ایجاد کنید.این اشکالی ندارد زیرا ما آن را مقداردهی اولیه کردیم.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// * استفاده نادرست از این روش:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ما یک مرجع به یک vector غیر اولیه ایجاد کرده ایم!این یک رفتار تعریف نشده است.⚠️
    /// ```
    ///
    /// (توجه داشته باشید که قوانین مربوط به ارجاع به داده های غیر اولیه هنوز نهایی نشده اند ، اما بهتر است تا زمان تکمیل آنها از آنها اجتناب کنید.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` و `ManuallyDrop` هر دو `repr(transparent)` هستند بنابراین می توانیم نشانگر را ارسال کنیم.
        self as *const _ as *const T
    }

    /// یک نشانگر قابل تغییر به مقدار موجود می دهد.
    /// خواندن از این نشانگر یا تبدیل آن به مرجع یک رفتار تعریف نشده است ، مگر اینکه `MaybeUninit<T>` اولیه شود.
    ///
    /// # Examples
    ///
    /// استفاده صحیح از این روش:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // یک مرجع در `MaybeUninit<Vec<u32>>` ایجاد کنید.
    /// // این اشکالی ندارد زیرا ما آن را مقداردهی اولیه کردیم.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// * استفاده نادرست از این روش:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ما یک مرجع به یک vector غیر اولیه ایجاد کرده ایم!این یک رفتار تعریف نشده است.⚠️
    /// ```
    ///
    /// (توجه داشته باشید که قوانین مربوط به ارجاع به داده های غیر اولیه هنوز نهایی نشده اند ، اما بهتر است تا زمان تکمیل آنها از آنها اجتناب کنید.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` و `ManuallyDrop` هر دو `repr(transparent)` هستند بنابراین می توانیم نشانگر را ارسال کنیم.
        self as *mut _ as *mut T
    }

    /// مقدار را از ظرف `MaybeUninit<T>` استخراج می کند.این یک روش عالی برای اطمینان از کاهش داده ها است ، زیرا `T` حاصل تحت کنترل معمول افت است.
    ///
    /// # Safety
    ///
    /// تضمین اینکه `MaybeUninit<T>` واقعاً در وضعیت اولیه قرار دارد ، به عهده تماس گیرنده است.وقتی این محتوا هنوز کاملاً اولیه نشده است ، فراخوانی این مسئله باعث رفتار فوری تعریف نشده می شود.
    /// [type-level documentation][inv] شامل اطلاعات بیشتری در مورد این ثابت اولیه است.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// علاوه بر این ، به یاد داشته باشید که اکثر انواع دارای موارد اضافی فراتر از صرفاً ابتکاری در سطح نوع هستند.
    /// به عنوان مثال ، [`Vec<T>`] با مقدار 1 "" مقداردهی اولیه در نظر گرفته می شود (تحت اجرای فعلی ، این یک ضمانت پایدار محسوب نمی شود) زیرا تنها الزامی که کامپایلر در مورد آن می داند این است که نشانگر داده باید غیر تهی باشد.
    ///
    /// ایجاد چنین `Vec<T>` باعث رفتار *فوری* تعریف نشده نمی شود ، بلکه با اکثر عملیات ایمن (از جمله انداختن آن) باعث یک رفتار تعریف نشده می شود.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// استفاده صحیح از این روش:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// * استفاده نادرست از این روش:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` هنوز اولیه نشده بود ، بنابراین این خط آخر باعث رفتارهای تعریف نشده ای شد.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ایمنی: تماس گیرنده باید شروع اولیه `self` را تضمین کند.
        // این همچنین بدان معنی است که `self` باید یک نوع `value` باشد.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// مقدار را از ظرف `MaybeUninit<T>` می خواند.`T` حاصل تحت کنترل معمول افت است.
    ///
    /// در صورت امکان ، استفاده از [`assume_init`] ترجیح داده می شود که از تکرار محتوای `MaybeUninit<T>` جلوگیری می کند.
    ///
    /// # Safety
    ///
    /// تضمین اینکه `MaybeUninit<T>` واقعاً در وضعیت اولیه قرار دارد ، به عهده تماس گیرنده است.فراخوانی این موارد درصورتی که هنوز مطالب به طور کامل اولیه نشده باشند باعث ایجاد رفتار تعریف نشده می شود.
    /// [type-level documentation][inv] شامل اطلاعات بیشتری در مورد این ثابت اولیه است.
    ///
    /// علاوه بر این ، این یک کپی از همان داده ها را در `MaybeUninit<T>` باقی می گذارد.
    /// هنگام استفاده از چندین نسخه از داده ها (با تماس چند باره با `assume_init_read` ، یا ابتدا با `assume_init_read` و سپس [`assume_init`] تماس بگیرید) ، مسئولیت اطمینان از تکرار شدن آن داده ها بر عهده شماست.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// استفاده صحیح از این روش:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` است ، بنابراین ممکن است چندین بار بخوانیم.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // تکثیر مقدار `None` مشکلی نیست ، بنابراین ممکن است چندین بار بخوانیم.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// * استفاده نادرست از این روش:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ما اکنون دو نسخه از همان vector ایجاد کرده ایم که منجر به یک نسخه دو رایگان می شود!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ایمنی: تماس گیرنده باید شروع اولیه `self` را تضمین کند.
        // خواندن از `self.as_ptr()` بی خطر است زیرا `self` باید اولیه شود.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// مقدار موجود را در جای خود رها می کند.
    ///
    /// اگر مالکیت `MaybeUninit` هستید ، می توانید به جای آن از [`assume_init`] استفاده کنید.
    ///
    /// # Safety
    ///
    /// تضمین اینکه `MaybeUninit<T>` واقعاً در وضعیت اولیه قرار دارد ، به عهده تماس گیرنده است.فراخوانی این موارد درصورتی که هنوز مطالب به طور کامل اولیه نشده باشند باعث ایجاد رفتار تعریف نشده می شود.
    ///
    /// علاوه بر این ، تمام موارد اضافی نوع `T` باید راضی باشند ، زیرا اجرای `Drop` `T` (یا اعضای آن) ممکن است به این اتکا کند.
    /// به عنوان مثال ، [`Vec<T>`] با مقدار 1 "" مقداردهی اولیه در نظر گرفته می شود (تحت اجرای فعلی ، این یک ضمانت پایدار محسوب نمی شود) زیرا تنها الزامی که کامپایلر در مورد آن می داند این است که نشانگر داده باید غیر تهی باشد.
    ///
    /// با انداختن چنین `Vec<T>` رفتار نامشخصی ایجاد می شود.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ایمنی: تماس گیرنده باید تضمین کند که `self` مقدار اولیه دارد و
        // همه موارد `T` را برآورده می کند.
        // در این صورت انداختن مقدار در جای خود ایمن است.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// به یک مقدار مشترک ارجاع مشترک می دهد.
    ///
    /// این می تواند زمانی مفید باشد که بخواهیم به `MaybeUninit` دسترسی پیدا کنیم که راه اندازی شده است اما مالکیت `MaybeUninit` را نداریم (جلوگیری از استفاده از `.assume_init()`).)
    ///
    /// # Safety
    ///
    /// تماس با این حالت درصورتی که هنوز محتوای آن کاملاً اولیه نشده باشد باعث ایجاد رفتار تعریف نشده می شود: تضمین این که `MaybeUninit<T>` واقعاً در یک حالت اولیه است ، تماس گیرنده است.
    ///
    ///
    /// # Examples
    ///
    /// ### استفاده صحیح از این روش:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` را مقداردهی اولیه کنید:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // اکنون که مقدار اولیه `MaybeUninit<_>` ما مشخص شده است ، ایجاد یک مرجع مشترک به آن اشکالی ندارد:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ایمنی: `x` مقداردهی اولیه شده است.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *کاربردهای نادرست* این روش:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ما یک مرجع به یک vector غیر اولیه ایجاد کرده ایم!این یک رفتار تعریف نشده است.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `MaybeUninit` را با استفاده از `Cell::set` شروع کنید:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // اشاره به `Cell<bool>` غیر اولیه: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ایمنی: تماس گیرنده باید شروع اولیه `self` را تضمین کند.
        // این همچنین بدان معنی است که `self` باید یک نوع `value` باشد.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// (unique) قابل تغییر را به مقدار موجود می دهد.
    ///
    /// این می تواند زمانی مفید باشد که بخواهیم به `MaybeUninit` دسترسی پیدا کنیم که راه اندازی شده است اما مالکیت `MaybeUninit` را نداریم (جلوگیری از استفاده از `.assume_init()`).)
    ///
    /// # Safety
    ///
    /// تماس با این حالت درصورتی که هنوز محتوای آن کاملاً اولیه نشده باشد باعث ایجاد رفتار تعریف نشده می شود: تضمین این که `MaybeUninit<T>` واقعاً در یک حالت اولیه است ، تماس گیرنده است.
    /// به عنوان مثال ، از `.assume_init_mut()` نمی توان برای مقداردهی اولیه `MaybeUninit` استفاده کرد.
    ///
    /// # Examples
    ///
    /// ### استفاده صحیح از این روش:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// *تمام* بایت بافر ورودی را اولیه می کند.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` را مقداردهی اولیه کنید:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // اکنون می دانیم که `buf` مقداردهی اولیه شده است ، بنابراین می توانیم آن را `.assume_init()` کنیم.
    /// // با این حال ، استفاده از `.assume_init()` ممکن است باعث ایجاد `memcpy` از 2048 بایت شود.
    /// // برای اینکه ادعا کنیم بافر ما بدون کپی برداری مقدماتی شده است ، ما `&mut MaybeUninit<[u8; 2048]>` را به `&mut [u8; 2048]` ارتقا می دهیم:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ایمنی: `buf` مقداردهی اولیه شده است.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // اکنون می توانیم از `buf` به عنوان یک برش معمولی استفاده کنیم:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *کاربردهای نادرست* این روش:
    ///
    /// برای مقداردهی اولیه نمی توانید از `.assume_init_mut()` استفاده کنید:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ما یک ارجاع (mutable) به یک `bool` غیر اولیه ایجاد کرده ایم!
    ///     // این یک رفتار تعریف نشده است.⚠️
    /// }
    /// ```
    ///
    /// به عنوان مثال ، شما نمی توانید [`Read`] را در یک بافر غیر اولیه قرار دهید:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) اشاره به حافظه غیر اولیه!
    ///                             // این یک رفتار تعریف نشده است.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// همچنین نمی توانید از دسترسی مستقیم میدانی برای انجام مقدماتی تدریجی میدان به میدان استفاده کنید:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) اشاره به حافظه غیر اولیه!
    ///                  // این یک رفتار تعریف نشده است.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) اشاره به حافظه غیر اولیه!
    ///                  // این یک رفتار تعریف نشده است.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): ما در حال حاضر به نادرست بودن موارد بالا اعتماد می کنیم ، یعنی ما به داده های غیر اولیه مراجعه می کنیم (به عنوان مثال ، در `libcore/fmt/float.rs`).
    // قبل از تثبیت باید در مورد قوانین تصمیم نهایی بگیریم.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ایمنی: تماس گیرنده باید شروع اولیه `self` را تضمین کند.
        // این همچنین بدان معنی است که `self` باید یک نوع `value` باشد.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// مقادیر را از آرایه ظروف `MaybeUninit` استخراج می کند.
    ///
    /// # Safety
    ///
    /// تضمین اینکه همه عناصر آرایه در وضعیت اولیه قرار دارند ، به عهده تماس گیرنده است.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ایمنی: اکنون با تنظیم اولیه همه عناصر ، ایمن باشید
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * تماس گیرنده شروع اولیه همه عناصر آرایه را تضمین می کند
        // * `MaybeUninit<T>` و T دارای چیدمان یکسان هستند
        // * MaybeUnint افت نمی کند ، بنابراین دو بار آزاد نیست و بنابراین تبدیل امن است
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// با فرض مقداردهی اولیه تمام عناصر ، برشی از آنها دریافت کنید.
    ///
    /// # Safety
    ///
    /// تضمین اینکه عناصر `MaybeUninit<T>` واقعاً در حالت اولیه قرار دارند ، به عهده تماس گیرنده است.
    ///
    /// فراخوانی این موارد درصورتی که هنوز مطالب به طور کامل اولیه نشده باشند باعث ایجاد رفتار تعریف نشده می شود.
    ///
    /// برای جزئیات بیشتر و مثالها به [`assume_init_ref`] مراجعه کنید.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ایمنی: قطعه ریخته گری به `*const [T]` بی خطر است زیرا تماس گیرنده آن را تضمین می کند
        // `slice` مقداردهی اولیه می شود ، و "MaybeUninit" دارای همان طرح `T` است.
        // اشاره گر بدست آمده معتبر است زیرا به حافظه متعلق به `slice` اشاره دارد که مرجع است و بنابراین برای خواندن معتبر است.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// با فرض مقداردهی اولیه تمام عناصر ، یک قطعه قابل تغییر برای آنها بگیرید.
    ///
    /// # Safety
    ///
    /// تضمین اینکه عناصر `MaybeUninit<T>` واقعاً در حالت اولیه قرار دارند ، به عهده تماس گیرنده است.
    ///
    /// فراخوانی این موارد درصورتی که هنوز مطالب به طور کامل اولیه نشده باشند باعث ایجاد رفتار تعریف نشده می شود.
    ///
    /// برای جزئیات بیشتر و مثالها به [`assume_init_mut`] مراجعه کنید.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ایمنی: مشابه یادداشت های ایمنی برای `slice_get_ref` است ، اما ما یک
        // مرجع قابل تغییر که برای نوشتن نیز معتبر است.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// یک نشانگر به اولین عنصر آرایه می رساند.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// یک نشانگر قابل تغییر به اولین عنصر آرایه می دهد.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// عناصر را از `src` به `this` کپی می کند ، و یک مرجع قابل تغییر به محتوای `this` را که اکنون دارای حساسیت است ، برمی گرداند.
    ///
    /// اگر `T` `Copy` را اجرا نمی کند ، از [`write_slice_cloned`] استفاده کنید
    ///
    /// این شبیه [`slice::copy_from_slice`] است.
    ///
    /// # Panics
    ///
    /// اگر طول دو برش متفاوت باشد ، این عملکرد panic خواهد بود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ایمنی: ما تمام عناصر len را در ظرفیت اضافی کپی کردیم
    /// // اولین عناصر src.len() از VC اکنون معتبر هستند.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ایمنی: &[T] و&[MaybeUninit<T>] چیدمان یکسانی دارند
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ایمنی: عناصر معتبر به تازگی در `this` کپی شده اند ، بنابراین آن را بی سیم می کند
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// عناصر را از `src` به `this` کلون می کند ، و مرجعی قابل تغییر به محتوای `this` را که در حال حاضر حساس است ، برمی گرداند.
    /// هر عنصری که قبلاً تزریق شده باشد حذف نخواهد شد.
    ///
    /// اگر `T` `Copy` را پیاده سازی کرد ، از [`write_slice`] استفاده کنید
    ///
    /// این شبیه [`slice::clone_from_slice`] است اما عناصر موجود را رها نمی کند.
    ///
    /// # Panics
    ///
    /// اگر طول دو برش مختلف یا اجرای `Clone` panics وجود داشته باشد ، این عملکرد panic خواهد بود.
    ///
    /// اگر panic وجود داشته باشد ، عناصر شبیه سازی شده از بین می روند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ایمنی: ما تمام عناصر len را به ظرفیت اضافی شبیه سازی کردیم
    /// // اولین عناصر src.len() از VC اکنون معتبر هستند.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // بر خلاف copy_from_slice ، این clone_from_slice را روی قطعه فراخوانی نمی کند ، زیرا `MaybeUninit<T: Clone>` Clone را اجرا نمی کند.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ایمنی: این قطعه خام فقط شامل اشیا initial اولیه است
                // به همین دلیل ، رها کردن آن مجاز است.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: ما باید صریحاً آنها را به همان طول برش دهیم
        // برای پاک کردن مرزها ، و بهینه ساز برای موارد ساده (به عنوان مثال T= u8) حافظه ایجاد می کند.
        //
        let len = this.len();
        let src = &src[..len];

        // محافظ مورد نیاز است b/c panic ممکن است در طی یک کلون اتفاق بیفتد
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ایمنی: عناصر معتبر به تازگی در `this` نوشته شده اند ، بنابراین آن را نهادینه می کند
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}