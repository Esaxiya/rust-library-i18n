//! توابع اساسی برای کار با حافظه.
//!
//! این ماژول شامل توابع برای پرس و جو از اندازه و ترازبندی انواع ، مقداردهی اولیه و دستکاری حافظه است.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// "forgets" را درمورد مقدار **بدون اجرای تخریب کننده** به دست می آورد.
///
/// منابعی که مقدار کنترل می کند ، مانند حافظه heap یا دسته پرونده ، برای همیشه در یک حالت غیرقابل دسترسی ماندگار می شوند.با این وجود تضمین نمی کند که نشانگرهای این حافظه معتبر باقی بمانند.
///
/// * اگر می خواهید حافظه نشت کند ، به [`Box::leak`] مراجعه کنید.
/// * اگر می خواهید یک نشانگر خام برای حافظه بدست آورید ، به [`Box::into_raw`] مراجعه کنید.
/// * اگر می خواهید مقداری را به درستی دفع کنید ، تخریب کننده آن را اجرا کنید ، به [`mem::drop`] مراجعه کنید.
///
/// # Safety
///
/// `forget` به عنوان `unsafe` علامت گذاری نشده است ، زیرا ضمانت های ایمنی Rust تضمینی برای ادامه کار تخریب کنندگان نیست.
/// به عنوان مثال ، یک برنامه می تواند با استفاده از [`Rc`][rc] یک چرخه مرجع ایجاد کند یا برای خروج بدون اجرای تخریب کننده ها با [`process::exit`][exit] تماس بگیرد.
/// بنابراین ، اجازه دادن به `mem::forget` از کد امن اساساً ضمانت های ایمنی Rust را تغییر نمی دهد.
///
/// گفته شد ، نشت منابع مانند حافظه یا اشیا X I/O معمولاً نامطلوب است.
/// این نیاز در برخی موارد استفاده تخصصی از FFI یا کد ناامن وجود دارد ، اما حتی در آن صورت نیز [`ManuallyDrop`] معمولاً ترجیح داده می شود.
///
/// از آنجا که فراموش کردن یک مقدار مجاز است ، هر کد `unsafe` که می نویسید باید این امکان را فراهم کند.نمی توانید مقداری را برگردانید و انتظار داشته باشید که تماس گیرنده لزوما تخریب کننده مقدار را اجرا کند.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// استفاده ایمن متعارف از `mem::forget` برای دور زدن تخریب کننده یک مقدار است که توسط `Drop` trait اجرا شده است.به عنوان مثال ، این یک `File` را فاش می کند ، یعنی
/// فضای گرفته شده توسط متغیر را بازیابی کنید اما هرگز منبع اصلی سیستم را نبندید:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// این زمانی مفید است که مالکیت منبع اساسی قبلاً با انتقال توصیفگر فایل خام به کد C به کدی خارج از Rust منتقل شده باشد.
///
/// # رابطه با `ManuallyDrop`
///
/// در حالی که می توان از `mem::forget` برای انتقال *حافظه* مالکیت نیز استفاده کرد ، انجام این کار مستعد خطا است.
/// [`ManuallyDrop`] باید بجای آن استفاده شودبرای مثال ، این کد را در نظر بگیرید:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // با استفاده از محتویات `v` `String` بسازید
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // `v` نشت کند زیرا حافظه آن اکنون توسط `s` مدیریت می شود
/// mem::forget(v);  // خطا ، v نامعتبر است و نباید به یک تابع منتقل شود
/// assert_eq!(s, "Az");
/// // `s` به طور ضمنی حذف می شود و حافظه آن جدا می شود.
/// ```
///
/// با مثال فوق دو مسئله وجود دارد:
///
/// * اگر کد بیشتری بین ساخت `String` و فراخوانی `mem::forget()` اضافه شود ، panic درون آن باعث آزاد شدن دو برابر می شود زیرا حافظه مشابه توسط `v` و `s` اداره می شود.
/// * پس از تماس با `v.as_mut_ptr()` و انتقال مالکیت داده ها به `s` ، مقدار `v` نامعتبر است.
/// حتی وقتی مقداری فقط به `mem::forget` منتقل می شود (که آن را بازرسی نمی کند) ، بعضی از انواع مقادیر سختگیرانه ای برای مقادیر خود دارند که باعث می شود هنگام آویز کردن یا دیگر مالکیت آنها نامعتبر باشد.
/// استفاده از مقادیر نامعتبر به هر روشی ، از جمله انتقال آنها به آنها یا بازگرداندن آنها از توابع ، به منزله یک رفتار تعریف نشده است و ممکن است مفروضات ارائه شده توسط کامپایلر را بشکند.
///
/// تغییر به `ManuallyDrop` از هر دو مسئله جلوگیری می کند:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // قبل از اینکه `v` را به قطعات خام آن بریزیم ، مطمئن شوید که افت نمی کند!
/////
/// let mut v = ManuallyDrop::new(v);
/// // حالا `v` را جدا کنید.این عملیات نمی تواند panic باشد ، بنابراین نمی تواند نشتی داشته باشد.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // در آخر ، یک `String` بسازید.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` به طور ضمنی حذف می شود و حافظه آن جدا می شود.
/// ```
///
/// `ManuallyDrop` به شدت مانع استفاده از دوبار رایگان می شود زیرا ما تخریب کننده "v" را قبل از هر کار دیگری غیرفعال می کنیم.
/// `mem::forget()` این اجازه را نمی دهد زیرا این استدلال خود را مصرف می کند ، و ما را مجبور می کند فقط پس از استخراج هر چیزی که از `v` نیاز داریم تماس بگیریم.
/// حتی اگر panic بین ساخت `ManuallyDrop` و ساخت رشته وارد شود (که همانطور که نشان داده می شود در کد اتفاق نمی افتد) ، این امر منجر به نشت و دو برابر آزاد شدن می شود.
/// به عبارت دیگر ، `ManuallyDrop` به جای خطا در سمت افتادن (مضاعف) ، در کنار نشت کردن خطا می کند.
///
/// همچنین ، `ManuallyDrop` پس از انتقال مالکیت به `s` مانع از نیاز به "touch" `v` می شود-مرحله آخر تعامل با `v` برای دفع آن بدون اجرای تخریب کننده کاملاً اجتناب می شود.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// مانند [`forget`] ، اما مقادیر بدون اندازه را نیز می پذیرد.
///
/// این عملکرد فقط یک لبه است که با تثبیت شدن ویژگی `unsized_locals` حذف می شود.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// اندازه یک نوع را در بایت برمی گرداند.
///
/// به طور خاص ، این جابجایی بایت بین عناصر پی در پی در یک آرایه با آن نوع مورد از جمله تراز بندی است.
///
/// بنابراین ، برای هر نوع `T` و طول `n` ، `[T; n]` دارای اندازه `n * size_of::<T>()` است.
///
/// به طور کلی ، اندازه یک نوع در میان مجموعه ها پایدار نیست ، اما انواع خاصی مانند ابتدایی هستند.
///
/// جدول زیر اندازه اولیه را نشان می دهد.
///
/// نوع |اندازه_:::<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 کاراکتر |4
///
/// علاوه بر این ، `usize` و `isize` دارای اندازه یکسانی هستند.
///
/// انواع `*const T` ، `&T` ، `Box<T>` ، `Option<&T>` و `Option<Box<T>>` همه دارای اندازه یکسانی هستند.
/// اگر `T` اندازه باشد ، همه آن نوع همان اندازه `usize` دارند.
///
/// تغییرپذیری نشانگر اندازه آن را تغییر نمی دهد.به همین ترتیب ، `&T` و `&mut T` دارای اندازه یکسانی هستند.
/// به همین ترتیب برای `*const T` و `* mut T`.
///
/// # اندازه موارد `#[repr(C)]`
///
/// نمایندگی `C` برای موارد دارای یک طرح مشخص است.
/// با این طرح ، اندازه موارد نیز پایدار است به شرط آنکه همه فیلدها دارای اندازه پایدار باشند.
///
/// ## اندازه سازه ها
///
/// برای `structs` ، اندازه توسط الگوریتم زیر تعیین می شود.
///
/// برای هر فیلد در ساختار به ترتیب سفارش اعلام شده:
///
/// 1. اندازه قسمت را اضافه کنید.
/// 2. اندازه فعلی را به نزدیکترین مضرب [alignment] قسمت بعدی جمع کنید.
///
/// در آخر ، اندازه ساختار را به نزدیکترین مضرب [alignment] آن بچرخانید.
/// تراز بندی ساختار معمولاً بزرگترین ترازبندی در تمام زمینه های آن است.با استفاده از `repr(align(N))` می توان این مورد را تغییر داد.
///
/// برخلاف `C` ، اندازه های اندازه صفر تا یک بایت گرد نمی شوند.
///
/// ## اندازه Enums
///
/// enum هایی که به جز متمایز کننده داده دیگری ندارند ، اندازه آنها با C enums در بستری که برای آن تدوین شده اند برابر است.
///
/// ## اندازه اتحادیه ها
///
/// اندازه اتحادیه به اندازه بزرگترین زمینه آن است.
///
/// برخلاف `C` ، واحدهای اندازه صفر تا اندازه یک بایت گرد نمی شوند.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // برخی از بدوی ها
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // برخی از آرایه ها
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // برابری اندازه نشانگر
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// با استفاده از `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // اندازه قسمت اول 1 است ، بنابراین 1 را به اندازه اضافه کنید.اندازه 1 است.
/// // تراز بندی قسمت دوم 2 است ، بنابراین 1 را برای اندازه پر کردن به اندازه اضافه کنید.اندازه 2 است.
/// // اندازه قسمت دوم 2 است ، بنابراین 2 را به اندازه اضافه کنید.اندازه 4 است.
/// // تراز بندی قسمت سوم 1 است ، بنابراین 0 را برای اندازه پر کردن به اندازه اضافه کنید.اندازه 4 است.
/// // اندازه قسمت سوم 1 است ، بنابراین 1 را به اندازه اضافه کنید.اندازه 5 است.
/// // سرانجام ، ترازبندی ساختار 2 است (زیرا بیشترین هم ترازی در بین زمینه های آن 2 است) ، بنابراین 1 را برای اندازه گذاری به اندازه اضافه کنید.
/// // اندازه 6 است.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // ضربه های تاپل نیز از همین قوانین پیروی می کنند.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // توجه داشته باشید که با مرتب سازی مجدد فیلدها می توانید اندازه را کاهش دهید.
/// // با قرار دادن `third` قبل از `second` می توانیم هر دو بایت padding را حذف کنیم.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // اندازه اتحادیه به اندازه بزرگترین زمینه است.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// اندازه مقدار اشاره شده به بایت را برمی گرداند.
///
/// این معمولاً همان `size_of::<T>()` است.
/// با این حال ، هنگامی که `T` * دارای اندازه ثابت شناخته شده ای نیست ، به عنوان مثال یک قطعه [`[T]`][slice] یا [trait object] ، پس می توان از `size_of_val` برای بدست آوردن اندازه شناخته شده پویا استفاده کرد.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ایمنی: `val` یک مرجع است ، بنابراین یک اشاره گر خام معتبر است
    unsafe { intrinsics::size_of_val(val) }
}

/// اندازه مقدار اشاره شده به بایت را برمی گرداند.
///
/// این معمولاً همان `size_of::<T>()` است.با این حال ، هنگامی که `T` * دارای اندازه ثابت شناخته شده ای نیست ، به عنوان مثال یک برش [`[T]`][slice] یا [trait object] ، پس می توان از `size_of_val_raw` برای بدست آوردن اندازه شناخته شده پویا استفاده کرد.
///
/// # Safety
///
/// تماس با این عملکرد فقط در صورت وجود شرایط زیر ایمن است:
///
/// - اگر `T` `Sized` باشد ، تماس با این عملکرد همیشه بی خطر است.
/// - اگر دنباله `T` بدون اندازه باشد:
///     - یک [slice] ، سپس طول دم برش باید یک عدد صحیح اولیه باشد و اندازه *کل مقدار*(طول دم پویا + پیشوند اندازه ایستا) باید در `isize` قرار گیرد.
///     - یک [trait object] ، سپس قسمت vtable نشانگر باید به یک میز معتبر معتبر که با اجبار یک سایز بدست آمده است ، اشاره کند و اندازه *کل مقدار*(طول دم پویا + پیشوند اندازه ایستا) باید در `isize` قرار گیرد.
///
///     - (unstable) [extern type] ، پس این عملکرد همیشه امن است ، اما ممکن است panic یا در غیر این صورت مقدار اشتباه را بازگرداند ، زیرا طرح نوع خارجی شناخته شده نیست.
///     این همان رفتار [`size_of_val`] در مورد ارجاع به نوعی با دم نوع خارجی است.
///     - در غیر این صورت ، فراخوانی این عملکرد به صورت محافظه کارانه مجاز نیست.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ایمنی: تماس گیرنده باید یک نشانگر خام معتبر ارائه دهد
    unsafe { intrinsics::size_of_val(val) }
}

/// حداقل تراز مورد نیاز [ABI] را برمی گرداند.
///
/// هر ارجاعی به مقداری از نوع `T` باید مضربی از این عدد باشد.
///
/// این ترازی است که برای زمینه های ساختار استفاده می شود.ممکن است کوچکتر از تراز دلخواه باشد.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// حداقل تراز مورد نیاز [ABI] را از نوع مقداری که `val` به آن نشان می دهد برمی گرداند.
///
/// هر ارجاعی به مقداری از نوع `T` باید مضربی از این عدد باشد.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ایمنی: val یک مرجع است ، بنابراین یک اشاره گر خام معتبر است
    unsafe { intrinsics::min_align_of_val(val) }
}

/// حداقل تراز مورد نیاز [ABI] را برمی گرداند.
///
/// هر ارجاعی به مقداری از نوع `T` باید مضربی از این عدد باشد.
///
/// این ترازی است که برای زمینه های ساختار استفاده می شود.ممکن است کوچکتر از تراز دلخواه باشد.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// حداقل تراز مورد نیاز [ABI] را از نوع مقداری که `val` به آن نشان می دهد برمی گرداند.
///
/// هر ارجاعی به مقداری از نوع `T` باید مضربی از این عدد باشد.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ایمنی: val یک مرجع است ، بنابراین یک اشاره گر خام معتبر است
    unsafe { intrinsics::min_align_of_val(val) }
}

/// حداقل تراز مورد نیاز [ABI] را از نوع مقداری که `val` به آن نشان می دهد برمی گرداند.
///
/// هر ارجاعی به مقداری از نوع `T` باید مضربی از این عدد باشد.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// تماس با این عملکرد فقط در صورت وجود شرایط زیر ایمن است:
///
/// - اگر `T` `Sized` باشد ، تماس با این عملکرد همیشه بی خطر است.
/// - اگر دنباله `T` بدون اندازه باشد:
///     - یک [slice] ، سپس طول دم برش باید یک عدد صحیح اولیه باشد و اندازه *کل مقدار*(طول دم پویا + پیشوند اندازه ایستا) باید در `isize` قرار گیرد.
///     - یک [trait object] ، سپس قسمت vtable نشانگر باید به یک میز معتبر معتبر که با اجبار یک سایز بدست آمده است ، اشاره کند و اندازه *کل مقدار*(طول دم پویا + پیشوند اندازه ایستا) باید در `isize` قرار گیرد.
///
///     - (unstable) [extern type] ، پس این عملکرد همیشه امن است ، اما ممکن است panic یا در غیر این صورت مقدار اشتباه را بازگرداند ، زیرا طرح نوع خارجی شناخته شده نیست.
///     این همان رفتار [`align_of_val`] در مورد ارجاع به نوعی با دم نوع خارجی است.
///     - در غیر این صورت ، فراخوانی این عملکرد به صورت محافظه کارانه مجاز نیست.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ایمنی: تماس گیرنده باید یک نشانگر خام معتبر ارائه دهد
    unsafe { intrinsics::min_align_of_val(val) }
}

/// اگر مقادیر از نوع `T` مهم باشد ، `true` را برمی گرداند.
///
/// این صرفاً یک نکته بهینه سازی است و ممکن است محافظه کارانه اجرا شود:
/// این ممکن است `true` را برای انواع که در واقع نیازی به حذف ندارند ، بازگرداند.
/// به همین ترتیب همیشه بازگشت `true` یک اجرای معتبر از این عملکرد است.اما اگر این عملکرد واقعاً `false` را برمی گرداند ، مطمئن باشید که افت `T` هیچ عارضه ای ندارد.
///
/// پیاده سازی های سطح پایین مواردی مانند مجموعه ها ، که باید داده های خود را به صورت دستی رها کنند ، باید از این عملکرد استفاده کنند تا در هنگام تخریب ، از تلاش بی مورد برای رها کردن تمام مطالب آنها جلوگیری شود.
///
/// این ممکن است تفاوتی در ساخت نسخه ایجاد نکند (در صورتی که حلقه ای که هیچ عوارض جانبی ندارد به راحتی شناسایی و از بین می رود) ، اما اغلب یک پیروزی بزرگ برای ساخت اشکال زدایی است.
///
/// توجه داشته باشید که [`drop_in_place`] قبلاً این بررسی را انجام داده است ، بنابراین اگر میزان کار شما می تواند به تعداد کمی از تماس های [`drop_in_place`] کاهش یابد ، استفاده از این مورد ضروری نیست.
/// به طور خاص توجه داشته باشید که شما می توانید یک برش [`drop_in_place`] ایجاد کنید ، و این برای همه مقادیر یک بررسی ضروری است.
///
/// انواع مشابه Vec بنابراین فقط `drop_in_place(&mut self[..])` بدون استفاده صریح از `needs_drop` استفاده می شود.
/// از طرف دیگر ، انواع مختلف [`HashMap`] باید مقادیر را یک به یک کاهش دهند و باید از این API استفاده کنند.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// در اینجا مثالی از نحوه استفاده یک مجموعه از `needs_drop` آورده شده است:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // داده ها را رها کنید
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// مقدار نوع `T` را که توسط الگوی بایت تمام صفر نشان داده شده است برمی گرداند.
///
/// این بدان معنی است که به عنوان مثال ، بایت padding در `(u8, u16)` لزوماً صفر نمی شود.
///
/// هیچ تضمینی وجود ندارد که یک الگوی بایت تمام صفر مقدار معتبری از برخی از انواع `T` را نشان دهد.
/// به عنوان مثال ، الگوی بایت تمام صفر برای انواع مرجع (`&T` ، `&mut T`) و نشانگرهای توابع مقدار معتبری نیست.
/// استفاده از `zeroed` در این نوع باعث فوری [undefined behavior][ub] می شود زیرا [the Rust compiler assumes][inv] که همیشه یک مقدار معتبر در متغیری دارد که آن را مقدار اولیه می داند.
///
///
/// این اثر همان [`MaybeUninit::zeroed().assume_init()`][zeroed] است.
/// بعضی اوقات برای FFI مفید است ، اما به طور کلی باید از آن اجتناب شود.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// استفاده صحیح از این عملکرد: مقداردهی اولیه یک عدد صحیح با صفر.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// * استفاده نادرست از این عملکرد: مقداردهی اولیه مرجع با صفر.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // رفتار تعریف نشده!
/// let _y: fn() = unsafe { mem::zeroed() }; // و دوباره!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SAFETY: تماس گیرنده باید معتبر بودن مقدار صفر برای `T` را تضمین کند.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// با تظاهر به تولید مقداری از نوع `T` ، در حالی که اصلاً کاری انجام نمی دهد ، میزان شروع اولیه حافظه Rust را دور می زند.
///
/// **این عملکرد منسوخ شده است.** به جای آن از [`MaybeUninit<T>`] استفاده کنید.
///
/// دلیل استهلاک این است که اساساً نمی توان از عملکرد به درستی استفاده کرد: همان تأثیری مانند [`MaybeUninit::uninit().assume_init()`][uninit] دارد.
///
/// همانطور که [`assume_init` documentation][assume_init] توضیح می دهد ، مقادیر [the Rust compiler assumes][inv] به درستی مقداردهی اولیه می شوند.
/// در نتیجه ، به عنوان مثال تماس بگیرید
/// `mem::uninitialized::<bool>()` باعث بازگشت فوری تعریف نشده برای بازگشت `bool` می شود که قطعاً `true` یا `false` نیست.
/// از این بدتر ، حافظه واقعاً غیر اولیه مانند آنچه در اینجا برمی گردد از این نظر خاص است که کامپایلر می داند که مقدار ثابتی ندارد.
/// این باعث می شود که داده های غیر اولیه در یک متغیر حتی اگر آن متغیر از نوع عدد صحیح باشد ، یک رفتار تعریف نشده است.
/// (توجه داشته باشید که قوانین مربوط به اعداد صحیح غیر اولیه هنوز نهایی نشده اند ، اما تا زمان تکمیل آنها توصیه می شود از آنها اجتناب کنید.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ایمنی: تماس گیرنده باید معتبر بودن یک مقدار واحد برای `T` را تضمین کند.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// مقادیر را در دو مکان قابل تغییر مبادله کنید ، بدون اینکه یک مورد را از حالت اولیه خارج کنید.
///
/// * اگر می خواهید با مقدار پیش فرض یا ساختگی مبادله کنید ، به [`take`] مراجعه کنید.
/// * اگر می خواهید با مقدار عبور داده شده مبادله کنید ، مقدار قدیمی را بازگردانید ، به [`replace`] مراجعه کنید.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ایمنی: نشانگرهای خام از منابع قابل تغییر و ایمن ایجاد شده اند که رضایت همه موارد را دارند
    // محدودیت های `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// `dest` را با مقدار پیش فرض `T` جایگزین می کند ، مقدار قبلی `dest` را برمی گرداند.
///
/// * اگر می خواهید مقادیر دو متغیر را جایگزین کنید ، به [`swap`] مراجعه کنید.
/// * اگر می خواهید به جای مقدار پیش فرض ، مقدار عبور داده شده را جایگزین کنید ، به [`replace`] مراجعه کنید.
///
/// # Examples
///
/// یک مثال ساده:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` اجازه می دهد تا مالکیت یک قسمت ساختار را با جایگزینی آن با مقدار "empty" در اختیار بگیرید.
/// بدون `take` می توانید با مواردی از این دست روبرو شوید:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// توجه داشته باشید که `T` لزوماً [`Clone`] را پیاده سازی نمی کند ، بنابراین حتی نمی تواند `self.buf` را شبیه سازی و تنظیم مجدد کند.
/// اما `take` می تواند برای جدا کردن مقدار اصلی `self.buf` از `self` مورد استفاده قرار گیرد و اجازه بازگشت داده می شود:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// `src` را به `dest` ارجاع شده منتقل می کند ، مقدار `dest` قبلی را برمی گرداند.
///
/// هیچ یک از دو مقدار کاهش پیدا نمی کند.
///
/// * اگر می خواهید مقادیر دو متغیر را جایگزین کنید ، به [`swap`] مراجعه کنید.
/// * اگر می خواهید با یک مقدار پیش فرض جایگزین کنید ، به [`take`] مراجعه کنید.
///
/// # Examples
///
/// یک مثال ساده:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` با جایگزینی یک مقدار دیگر ، می تواند یک میدان ساختار را مصرف کند.
/// بدون `replace` می توانید با مواردی از این دست روبرو شوید:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// توجه داشته باشید که `T` لزوماً [`Clone`] را پیاده سازی نمی کند ، بنابراین برای جلوگیری از حرکت حتی نمی توان `self.buf[i]` را شبیه سازی کرد.
/// اما `replace` می تواند برای جدا کردن مقدار اصلی آن شاخص از `self` مورد استفاده قرار گیرد و اجازه بازگشت داده شود:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ایمنی: ما از `dest` می خوانیم اما پس از آن مستقیماً `src` را در آن می نویسیم ،
    // به طوری که مقدار قدیمی تکرار نشود.
    // هیچ چیزی افت نمی کند و هیچ چیز در اینجا نمی تواند panic باشد.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// مقداری را از بین می برد.
///
/// این کار را با فراخوانی اجرای استدلال [`Drop`][drop] انجام می دهد.
///
/// این به طور م nothingثر برای انواعي كه `Copy` را اجرا می كنند ، هيچ كاری ندارد
/// integers.
/// چنین مقادیری کپی شده و _then_ به داخل تابع منتقل می شود ، بنابراین مقدار پس از فراخوانی این تابع همچنان ادامه دارد.
///
///
/// این عملکرد جادویی نیست.به معنای واقعی کلمه اینگونه تعریف می شود
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// از آنجا که `_x` به داخل تابع منتقل می شود ، قبل از بازگشت عملکرد به طور خودکار کاهش می یابد.
///
/// [drop]: Drop
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // vector را صریحاً رها کنید
/// ```
///
/// از آنجا که [`RefCell`] قوانین وام را در زمان اجرا اعمال می کند ، `drop` می تواند وام [`RefCell`] را آزاد کند:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // از وام قابل تغییر در این شیار صرف نظر کنید
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// عددهای صحیح و سایر انواع [`Copy`] تحت تأثیر `drop` نیستند.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // یک نسخه از `x` منتقل شده و رها می شود
/// drop(y); // یک نسخه از `y` منتقل شده و رها می شود
///
/// println!("x: {}, y: {}", x, y.0); // هنوز در دسترس است
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// `src` را به عنوان نوع `&U` تفسیر می کند ، و سپس `src` را بدون جابجایی مقدار موجود می خواند.
///
/// این عملکرد با ایمن کردن نشانگر `src` برای بایت [`size_of::<U>`][size_of] با تبدیل `&T` به `&U` و سپس خواندن `&U` ، نا ایمن فرض می کند (با این تفاوت که این کار حتی در زمانی که `&U` الزامات ترازبندی سخت تری نسبت به `&T` ایجاد می کند ، درست است).
/// همچنین به جای اینکه از `src` خارج شود ، به صورت نا ایمن کپی از مقدار موجود را ایجاد می کند.
///
/// اگر `T` و `U` اندازه های مختلف داشته باشند خطای زمان کامپایل نیست ، اما فقط در مواردی که اندازه های `T` و `U` یکسان است این عملکرد را فراخوانی می کند بسیار توصیه می شود.اگر `U` بزرگتر از `T` باشد ، این عملکرد باعث ایجاد [undefined behavior][ub] می شود.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // داده ها را از 'foo_array' کپی کرده و با آنها به عنوان 'Foo' رفتار کنید
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // داده های کپی شده را اصلاح کنید
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // محتوای 'foo_array' نباید تغییر کند
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // اگر U به تراز بیشتری نیاز داشته باشد ، src به طور مناسب تراز نمی شود.
    if align_of::<U>() > align_of::<T>() {
        // ایمنی: `src` مرجعی است که برای خواندن معتبر است.
        // تماس گیرنده باید مطمئن باشد که تغییر شکل واقعی بی خطر است.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ایمنی: `src` مرجعی است که برای خواندن معتبر است.
        // ما فقط بررسی کردیم `src as *const U` به درستی تراز شده باشد.
        // تماس گیرنده باید مطمئن باشد که تغییر شکل واقعی بی خطر است.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// نوع غیرشفاف نشان دهنده تبعیض آمیز یک حساب.
///
/// برای اطلاعات بیشتر به عملکرد [`discriminant`] در این ماژول مراجعه کنید.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. این پیاده سازی های trait بدست نمی آید زیرا ما هیچ محدودیتی برای T نمی خواهیم.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// مقداری را بازمی گرداند که منحصراً نوع enum را در `v` شناسایی می کند.
///
/// اگر `T` یک enum نباشد ، فراخوانی این تابع منجر به رفتار تعریف نشده نمی شود ، اما مقدار برگشتی مشخص نیست.
///
///
/// # Stability
///
/// اگر تعریف enum تغییر کند ، ممکن است وجه تمایز یک نوع enum تغییر کند.
/// متمایز کننده برخی از انواع بین کامپایلرهای با کامپایلر مشابه تغییر نخواهد کرد.
///
/// # Examples
///
/// این را می توان برای مقایسه مقادیر حامل داده استفاده کرد ، در حالی که داده واقعی را نادیده می گیرد:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// تعداد انواع موجود در نوع enum `T` را برمی گرداند.
///
/// اگر `T` یک enum نباشد ، فراخوانی این تابع منجر به رفتار تعریف نشده نمی شود ، اما مقدار برگشتی مشخص نیست.
/// به طور مساوی ، اگر `T` یک enum با تغییرات بیشتر از `usize::MAX` باشد ، مقدار بازگشت مشخص نشده است.
/// انواع غیر مسکونی محاسبه خواهد شد.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}