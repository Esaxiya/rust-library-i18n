use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// یک بسته بندی برای جلوگیری از تماس خودکار کامپایلر با تخریبگر "T".
/// این لفافه 0 هزینه دارد.
///
/// `ManuallyDrop<T>` تحت همان بهینه سازی های طرح `T` است.
/// در نتیجه ،*هیچ تأثیری* بر فرضیاتی که کامپایلر درباره محتوای آن می زند ، ندارد.
/// به عنوان مثال ، مقدار دهی اولیه `ManuallyDrop<&mut T>` با [`mem::zeroed`] یک رفتار تعریف نشده است.
/// اگر شما نیاز به مدیریت داده های غیر اولیه دارید ، به جای آن از [`MaybeUninit<T>`] استفاده کنید.
///
/// توجه داشته باشید که دستیابی به مقدار داخل `ManuallyDrop<T>` بی خطر است.
/// این بدان معنی است که `ManuallyDrop<T>` که محتوای آن رها شده است نباید از طریق یک API امن عمومی در معرض دید قرار گیرد.
/// به همین ترتیب ، `ManuallyDrop::drop` ناامن است.
///
/// # `ManuallyDrop` و سفارش را رها کنید.
///
/// Rust دارای مقادیر [drop order] کاملاً مشخص است.
/// برای اطمینان از اینکه فیلدها یا محلی ها به ترتیب خاصی رها می شوند ، اظهارات را دوباره مرتب کنید تا ترتیب افت ضمنی ، صحیح باشد.
///
/// برای کنترل مرتبه افت می توان از `ManuallyDrop` استفاده کرد ، اما این کار به کد ناامنی نیاز دارد و در صورت باز کردن پیچیدگی به درستی انجام می شود.
///
///
/// به عنوان مثال ، اگر می خواهید مطمئن شوید که یک قسمت خاص بعد از قسمت های دیگر افتاده است ، آن را آخرین قسمت یک ساختار قرار دهید:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` پس از `children` حذف خواهد شد.
///     // Rust تضمین می کند که فیلدها به ترتیب اعلامیه رها می شوند.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// مقداری را بسته بندی کنید که به صورت دستی حذف شود.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // هنوز هم می توانید با خیال راحت مقدار را کار کنید
    /// assert_eq!(*x, "Hello");
    /// // اما `Drop` در اینجا اجرا نمی شود
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// مقدار را از ظرف `ManuallyDrop` استخراج می کند.
    ///
    /// این اجازه می دهد تا مقدار دوباره کاهش یابد.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // این باعث افت `Box` می شود.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// مقدار را از ظرف `ManuallyDrop<T>` خارج می کند.
    ///
    /// این روش در درجه اول برای انتقال مقادیر قطره ای در نظر گرفته شده است.
    /// به جای استفاده از [`ManuallyDrop::drop`] برای انداختن دستی مقدار ، می توانید از این روش برای گرفتن مقدار استفاده کنید و از آن به دلخواه استفاده کنید.
    ///
    /// در صورت امکان ، استفاده از [`into_inner`][`ManuallyDrop::into_inner`] ترجیح داده می شود که از تکرار محتوای `ManuallyDrop<T>` جلوگیری می کند.
    ///
    ///
    /// # Safety
    ///
    /// این عملکرد بدون اینکه مانع از استفاده بیشتر شود ، به صورت معنایی مقدار موجود را خارج کرده و حالت این ظرف را بدون تغییر می گذارد.
    /// این مسئولیت شماست که اطمینان حاصل کنید که از این `ManuallyDrop` دوباره استفاده نمی شود.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ایمنی: ما در حال خواندن از یک مرجع هستیم که تضمین شده است
        // برای خواندن معتبر باشد.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// مقدار موجود را به صورت دستی کاهش می دهد.این دقیقاً معادل فراخوانی [`ptr::drop_in_place`] با اشاره گر به مقدار موجود است.
    /// بدین ترتیب ، مگر اینکه مقدار موجود یک ساختار بسته بندی شده باشد ، تخریب کننده بدون جابجایی مقدار در محل فراخوانی می شود ، بنابراین می توان از آن برای افتادن ایمن داده های [pinned] استفاده کرد.
    ///
    /// اگر مالکیت این مقدار را دارید ، می توانید به جای آن از [`ManuallyDrop::into_inner`] استفاده کنید.
    ///
    /// # Safety
    ///
    /// این تابع تخریب کننده مقدار موجود را اجرا می کند.
    /// غیر از تغییراتی که توسط خود تخریب کننده انجام می شود ، حافظه بدون تغییر باقی می ماند و بنابراین تا آنجا که به کامپایلر مربوط می شود ، یک الگوی بیت وجود دارد که برای نوع `T` معتبر است.
    ///
    ///
    /// با این حال ، این مقدار "zombie" نباید در معرض کد امن قرار گیرد و این عملکرد نباید بیش از یک بار فراخوانی شود.
    /// استفاده از مقداری پس از افتادن آن یا افتادن مقداری به دفعات ، می تواند باعث ایجاد رفتار تعریف نشده (بسته به آنچه `drop` انجام می دهد) شود.
    /// این امر به طور معمول توسط سیستم نوع جلوگیری می شود ، اما کاربران `ManuallyDrop` باید این ضمانت ها را بدون کمک کامپایلر حفظ کنند.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // ایمنی: ما در حال کاهش مقدار اشاره شده توسط یک مرجع قابل تغییر هستیم
        // که برای نوشتن معتبر است.
        // این اطمینان حاصل می کند که `slot` دوباره افتاده نیست.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}