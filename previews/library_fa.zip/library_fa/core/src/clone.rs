//! `Clone` trait برای انواع غیرقانونی "کپی" نیست.
//!
//! در Rust ، برخی از انواع ساده "implicitly copyable" هستند و وقتی آنها را اختصاص دهید یا آنها را به عنوان آرگومان منتقل کنید ، گیرنده یک کپی دریافت می کند و مقدار اصلی را در جای خود باقی می گذارد.
//! این نوع برای کپی کردن نیازی به تخصیص ندارند و نهایی کننده ندارند (یعنی جعبه های اختصاصی ندارند یا [`Drop`] را پیاده سازی نمی کنند) ، بنابراین کامپایلر آنها را ارزان و ایمن برای کپی می داند.
//!
//! برای انواع دیگر ، با استفاده از [`Clone`] trait و فراخوانی روش [`clone`] ، کپی باید به طور واضح ساخته شود.
//!
//! [`clone`]: Clone::clone
//!
//! مثال استفاده اساسی:
//!
//! ```
//! let s = String::new(); // نوع رشته Clone را پیاده سازی می کند
//! let copy = s.clone(); // بنابراین می توانیم آن را شبیه سازی کنیم
//! ```
//!
//! برای اجرای راحت Clone trait می توانید از `#[derive(Clone)]` نیز استفاده کنید.مثال:
//!
//! ```
//! #[derive(Clone)] // Clone trait را به ساختار Morpheus اضافه می کنیم
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // و اکنون می توانیم آن را شبیه سازی کنیم!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait مشترک برای توانایی کپی صریح یک شی.
///
/// تفاوت در [`Copy`] در [`Copy`] ضمنی و بسیار ارزان است ، در حالی که `Clone` همیشه صریح است و ممکن است گران باشد یا نباشد.
/// برای اجرای این ویژگی ها ، Rust به شما اجازه نمی دهد [`Copy`] را دوباره اجرا کنید ، اما شما می توانید `Clone` را دوباره اجرا کنید و کد دلخواه را اجرا کنید.
///
/// از آنجا که `Clone` عمومی تر از [`Copy`] است ، می توانید به صورت خودکار هر [`Copy`] را `Clone` نیز کنید.
///
/// ## Derivable
///
/// اگر همه زمینه ها `Clone` باشد ، می توان از این trait با `#[derive]` استفاده کرد.``استخراج`` اجرای [`Clone`] در هر زمینه [`clone`] را فراخوانی می کند.
///
/// [`clone`]: Clone::clone
///
/// برای یک ساختار عمومی ، `#[derive]` با اضافه کردن `Clone` مقید شده روی پارامترهای عمومی ، `Clone` را به طور مشروط پیاده سازی می کند.
///
/// ```
/// // `derive` Clone را برای خواندن پیاده سازی می کند<T>وقتی T کلون است.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## چگونه می توانم `Clone` را پیاده سازی کنم؟
///
/// انواع [`Copy`] باید از `Clone` پیش پا افتاده باشند.به صورت رسمی تر:
/// اگر `T: Copy` ، `x: T` و `y: &T` باشد ، `let x = y.clone();` معادل `let x = *y;` است.
/// پیاده سازی های دستی باید مراقب این موضوع باشند.با این حال ، کد ناامن برای اطمینان از ایمنی حافظه نباید به آن اعتماد کند.
///
/// به عنوان مثال یک ساختار عمومی است که یک نشانگر عملکرد را در خود نگه می دارد.در این حالت ، پیاده سازی `Clone` نمی تواند مشتق شود ، اما می تواند به صورت زیر اجرا شود:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## مجری های اضافی
///
/// علاوه بر [implementors listed below][impls] ، انواع زیر نیز `Clone` را اجرا می کنند:
///
/// * انواع موارد عملکرد (به عنوان مثال ، انواع متمایز تعریف شده برای هر عملکرد)
/// * انواع نشانگر عملکرد (به عنوان مثال ، `fn() -> i32`)
/// * انواع آرایه ، برای همه اندازه ها ، اگر نوع مورد `Clone` را نیز اجرا کند (به عنوان مثال ، `[i32; 123456]`)
/// * اگر هر م componentلفه `Clone` را نیز پیاده سازی کند انواع مختلفی دارد (به عنوان مثال `()` ، `(i32, bool)`)
/// * اگر هیچ مقداری از محیط گرفته نشود یا اگر همه این مقادیر گرفته شده `Clone` را خود پیاده سازی کند ، انواع بسته شدن آن
///   توجه داشته باشید که متغیرهای گرفته شده توسط مرجع مشترک همیشه `Clone` را اجرا می کنند (حتی اگر مرجع این کار را انجام ندهد) ، در حالی که متغیرهای گرفته شده توسط مرجع قابل تغییر هرگز `Clone` را اجرا نمی کنند.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// یک کپی از مقدار را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str پیاده سازی Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// تکلیف کپی را از `source` انجام می دهد.
    ///
    /// `a.clone_from(&b)` از نظر عملکردی معادل `a = b.clone()` است ، اما می توان برای استفاده مجدد از منابع `a` برای جلوگیری از تخصیص غیر ضروری ، آن را لغو کرد.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// تولید ماکرو تولید impl از trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): این ساختارها فقط توسط#[مشتق] استفاده می شوند تا ادعا كنند كه هر م componentلفه از یك نوع Clone یا Copy را پیاده سازی می كند.
//
//
// این ساختارها هرگز نباید در کد کاربر ظاهر شوند.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// پیاده سازی `Clone` برای انواع بدوی.
///
/// پیاده سازی هایی که در Rust قابل توصیف نیستند ، در `traits::SelectionContext::copy_clone_conditions()` در `rustc_trait_selection` اجرا می شوند.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// منابع مشترک به اشتراک گذاشته می شوند ، اما منابع قابل تغییر *نمی توانند*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// منابع مشترک به اشتراک گذاشته می شوند ، اما منابع قابل تغییر *نمی توانند*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}