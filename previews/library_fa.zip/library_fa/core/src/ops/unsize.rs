use crate::marker::Unsize;

/// Trait که نشان می دهد این یک نشانگر یا یک لفافه برای یکی است ، جایی که می توان اندازه گیری را روی pointee انجام داد.
///
/// برای جزئیات بیشتر به [DST coercion RFC][dst-coerce] و [the nomicon entry on coercion][nomicon-coerce] مراجعه کنید.
///
/// برای انواع اشاره گرهای داخلی ، اشاره گرهای `T` با تبدیل از یک اشاره گر نازک به یک نشانگر چربی ، به نشانگرهای `U` مجبور می شوند.
///
/// برای انواع سفارشی ، اجبار در اینجا با مجبور کردن `Foo<T>` به `Foo<U>` ارائه می شود ، درصورتی که یک `CoerceUnsized<Foo<U>> for Foo<T>` وجود داشته باشد.
/// چنین ضمنی فقط در صورتی می تواند نوشته شود که `Foo<T>` فقط یک قسمت غیر فانتومدایی منفرد داشته باشد که شامل `T` باشد.
/// اگر نوع آن قسمت `Bar<T>` باشد ، باید پیاده سازی `CoerceUnsized<Bar<U>> for Bar<T>` وجود داشته باشد.
/// این اجبار با مجبور کردن قسمت `Bar<T>` به `Bar<U>` و پر کردن بقیه قسمت ها از `Foo<T>` برای ایجاد `Foo<U>` عملی خواهد شد.
/// این به طور م toثر به یک قسمت اشاره گر متصل می شود و آن را وادار می کند.
///
/// به طور کلی ، برای اشاره گرهای هوشمند شما `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` را اجرا خواهید کرد ، با `?Sized` اختیاری که به `T` خود متصل است.
/// برای انواع لفافی که مستقیماً `T` را مانند `Cell<T>` و `RefCell<T>` جاسازی می کنند ، می توانید `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` را مستقیماً پیاده سازی کنید.
///
/// با این کار اجباری از انواع مانند `Cell<Box<T>>` قابل استفاده است.
///
/// [`Unsize`][unsize] برای علامت گذاری انواع استفاده می شود که اگر پشت عقب باشد ، می تواند به DST ها وادار شود.توسط کامپایلر بصورت خودکار اجرا می شود.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * ساختار U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * ساختار U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* ساختار U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// این برای ایمنی جسم استفاده می شود ، برای بررسی اینکه آیا نوع گیرنده یک روش می تواند ارسال شود.
///
/// نمونه ای از اجرای trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}