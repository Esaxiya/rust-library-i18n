/// برای نمایه سازی عملیات (`container[index]`) در زمینه های تغییرناپذیر استفاده می شود.
///
/// `container[index]` در واقع شکر نحوی برای `*container.index(index)` است ، اما فقط زمانی که به عنوان مقدار تغییرناپذیر استفاده شود.
/// در صورت درخواست مقدار قابل تغییر ، به جای آن از [`IndexMut`] استفاده می شود.
/// اگر نوع `value` [`Copy`] را اجرا کند ، این موارد خوب مانند `let value = v[index]` را اجازه می دهد.
///
/// # Examples
///
/// مثال زیر `Index` را بر روی ظرف `NucleotideCount` فقط خواندنی پیاده سازی می کند و با استفاده از نحو فهرست می توان شمارش های فردی را بازیابی کرد.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// نوع برگشتی پس از نمایه سازی.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// عملیات نمایه سازی (`container[index]`) را انجام می دهد.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// برای نمایه سازی عملیات (`container[index]`) در زمینه های قابل تغییر استفاده می شود.
///
/// `container[index]` در واقع شکر نحوی برای `*container.index_mut(index)` است ، اما فقط وقتی به عنوان مقدار قابل تغییر استفاده شود.
/// در صورت درخواست مقدار تغییرناپذیر ، به جای آن از [`Index`] trait استفاده می شود.
/// این اجازه می دهد تا چیزهای خوب مانند `v[index] = value`.
///
/// # Examples
///
/// یک اجرای بسیار ساده از ساختار `Balance` که دارای دو طرف است ، جایی که هر یک از آنها را می توان به صورت متغیر و غیرقابل تغییر نمایه کرد.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // در این حالت ، `balance[Side::Right]` برای `*balance.index(Side::Right)` شکر است ، زیرا ما فقط*`balance[Side::Right]` را می خوانیم ، نه اینکه آن را بنویسیم.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // با این حال ، در این مورد `balance[Side::Left]` برای `*balance.index_mut(Side::Left)` شکر است ، زیرا ما در حال نوشتن `balance[Side::Left]` هستیم.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// عملیات نمایه سازی قابل تغییر (`container[index]`) را انجام می دهد.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}