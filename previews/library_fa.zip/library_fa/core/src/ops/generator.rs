use crate::marker::Unpin;
use crate::pin::Pin;

/// نتیجه از سرگیری مجدد ژنراتور.
///
/// این enum از روش `Generator::resume` بازگردانده می شود و مقادیر بازگشتی احتمالی یک ژنراتور را نشان می دهد.
/// در حال حاضر این مربوط به یک نقطه تعلیق (`Yielded`) یا یک نقطه خاتمه (`Complete`) است.
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// ژنراتور با مقدار معلق است.
    ///
    /// این حالت نشان می دهد که یک ژنراتور به حالت تعلیق درآمده است ، و معمولاً با بیانیه `yield` مطابقت دارد.
    /// مقدار ارائه شده در این نوع با عبارتی که به `yield` منتقل می شود مطابقت دارد و به ژنراتورها اجازه می دهد تا هر بار که تولید می کنند مقداری را ارائه دهند.
    ///
    ///
    Yielded(Y),

    /// ژنراتور با مقدار بازگشتی کامل شد.
    ///
    /// این حالت نشان می دهد که یک تولید کننده با مقدار ارائه شده کار خود را به پایان رسانده است.
    /// هنگامی که یک ژنراتور `Complete` را بازگرداند ، خطای برنامه نویسی در نظر گرفته می شود که دوباره با `resume` تماس بگیرید.
    ///
    Complete(R),
}

/// trait که توسط انواع مولد داخلی ساخته شده است.
///
/// ژنراتورها ، که معمولاً به آنها کوروتین نیز می گویند ، در حال حاضر یک ویژگی آزمایشی زبان در Rust هستند.
/// ژنراتورهای [RFC 2033] اضافه شده در حال حاضر به طور عمده برای ایجاد یک بلوک برای نحو async/await در نظر گرفته شده اند اما احتمالاً به یک تعریف ارگونومی برای تکرارکنندگان و سایر موارد اولیه نیز گسترش می یابد.
///
///
/// نحو و معناشناسی ژنراتورها ناپایدار است و برای تثبیت به RFC بیشتری نیاز دارد.در این زمان ، نحو بسته مانند است:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// اسناد بیشتری از ژنراتورها را می توان در کتاب ناپایدار یافت.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// نوع مقداری که این ژنراتور تولید می کند.
    ///
    /// این نوع مرتبط با عبارت `yield` و مقادیر مجاز است که هر بار تولید یک ژنراتور مجاز به بازگشت است.
    ///
    /// به عنوان مثال یک تکرار کننده به عنوان یک ژنراتور احتمالاً این نوع را `T` دارد ، نوع تکرار شده بیش از حد.
    ///
    type Yield;

    /// نوع مقداری که این ژنراتور برمی گرداند.
    ///
    /// این مربوط به نوعی است که از یک ژنراتور برگردانده می شود یا با عبارت `return` یا به طور ضمنی به عنوان آخرین عبارت تولید کننده به معنای واقعی کلمه.
    /// به عنوان مثال futures از این به عنوان `Result<T, E>` استفاده می کند زیرا نشان دهنده future کامل است.
    ///
    ///
    type Return;

    /// اجرای این ژنراتور را از سر می گیرد.
    ///
    /// این تابع اجرای ژنراتور را از سر می گیرد یا اگر قبلاً آن را اجرا نکرده است ، شروع به اجرا می کند.
    /// این تماس به آخرین نقطه تعلیق ژنراتور بازمی گردد ، و اجرای آن از آخرین `yield` از سر گرفته می شود.
    /// ژنراتور به کار خود ادامه می دهد تا زمانی که یا تسلیم شود یا بازگردد ، در آن زمان این عملکرد باز می گردد.
    ///
    /// # مقدار برگشتی
    ///
    /// `GeneratorState` enum برگشتی از این عملکرد نشان می دهد ژنراتور در هنگام بازگشت چه وضعیتی دارد.
    /// اگر نوع `Yielded` بازگردانده شود ، ژنراتور به نقطه تعلیق رسیده و مقداری از آن خارج شده است.
    /// ژنراتورهای موجود در این حالت در مراحل بعدی برای ازسرگیری در دسترس هستند.
    ///
    /// اگر `Complete` برگردانده شود ، ژنراتور با مقدار ارائه شده کاملاً تمام شده است.از سرگیری مجدد تولید کننده نامعتبر است.
    ///
    /// # Panics
    ///
    /// این تابع ممکن است panic باشد اگر بعد از بازگشت نوع `Complete` قبلاً فراخوانی شود.
    /// در حالی که لغات کلیدی ژنراتور در زبان پس از `Complete` از سرگیری برای panic تضمین شده است ، اما این برای همه پیاده سازی های `Generator` trait تضمین نمی شود.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}