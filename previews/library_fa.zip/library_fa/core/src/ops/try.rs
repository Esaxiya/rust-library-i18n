/// trait برای شخصی سازی رفتار اپراتور `?`.
///
/// نوعی از پیاده سازی `Try` نوعی است که روشی متعارف برای مشاهده آن از نظر دوگانگی success/failure دارد.
/// این trait اجازه می دهد تا هم مقادیر موفقیت یا شکست را از یک نمونه موجود استخراج کنید و هم از یک مقدار موفقیت یا شکست یک نمونه جدید ایجاد کنید.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// نوع این مقدار در صورت موفقیت مشاهده می شود.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// نوع این مقدار در صورت عدم موفقیت مشاهده می شود.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// عملگر "?" را اعمال می کند.بازگشت `Ok(t)` به این معنی است که اجرا باید به طور عادی ادامه یابد و نتیجه `?` مقدار `t` است.
    /// بازگشت `Err(e)` به این معنی است که اجرا باید branch به درون محصور `catch` باشد ، یا از عملکرد برگردد.
    ///
    /// اگر نتیجه `Err(e)` برگردانده شود ، مقدار `e` در نوع بازگشت دامنه محصور "wrapped" خواهد بود (که خود باید `Try` را پیاده سازی کند).
    ///
    /// به طور خاص ، مقدار `X::from_error(From::from(e))` بازگردانده می شود ، جایی که `X` نوع بازگشتی تابع محصور است.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// برای ساخت نتیجه مرکب مقدار خطا را بپیچید.
    /// به عنوان مثال ، `Result::Err(x)` و `Result::from_error(x)` معادل هستند.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// برای ساخت نتیجه مرکب مقدار OK را بپیچید.
    /// به عنوان مثال ، `Result::Ok(x)` و `Result::from_ok(x)` معادل هستند.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}