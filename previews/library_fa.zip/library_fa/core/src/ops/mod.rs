//! اپراتورهای بیش از حد قابل بارگذاری.
//!
//! پیاده سازی این traits به شما امکان می دهد اپراتورهای خاصی را بیش از حد بارگیری کنید.
//!
//! برخی از این traits توسط prelude وارد می شود ، بنابراین در هر برنامه Rust موجود است.فقط اپراتورهایی که توسط traits پشتیبانی می شوند می توانند بیش از حد بارگیری کنند.
//! به عنوان مثال ، عملگر جمع (`+`) می تواند از طریق [`Add`] trait بیش از حد بارگیری شود ، اما از آنجا که اپراتور انتساب (`=`) هیچ پشتیبان trait ندارد ، راهی برای اضافه بار معنایی آن وجود ندارد.
//! علاوه بر این ، این ماژول هیچ مکانیزمی برای ایجاد اپراتورهای جدید ارائه نمی دهد.
//! در صورت نیاز به بارگذاری بدون ویژگی یا اپراتورهای سفارشی ، باید به دنبال افزونه های ماکرو یا کامپایلر باشید تا نحو Rust را گسترش دهید.
//!
//! پیاده سازی های عملگر traits باید در متن مربوطه تعجب آور نباشد ، با در نظر گرفتن معنای معمول آنها و [operator precedence].
//! به عنوان مثال ، هنگام اجرای [`Mul`] ، عملیات باید تا حدودی به ضرب شباهت داشته باشد (و خصوصیات مورد انتظار مانند انجمن را به اشتراک بگذارد).
//!
//! توجه داشته باشید که اتصال کوتاه اپراتورهای `&&` و `||` ، یعنی آنها فقط در صورت کمک به نتیجه ، عملگر دوم خود را ارزیابی می کنند.از آنجا که این رفتار توسط traits قابل اجرا نیست ، `&&` و `||` به عنوان اپراتورهای قابل بارگیری پشتیبانی نمی شوند.
//!
//! بسیاری از عملگرها عملوندهای خود را از نظر مقدار می گیرند.در زمینه های غیر عمومی که شامل انواع داخلی هستند ، این معمولاً مشکلی ایجاد نمی کند.
//! با این حال ، استفاده از این عملگرها در کد عمومی ، در صورت استفاده مجدد از مقادیر ، در مقابل اجازه دادن به اپراتورها برای استفاده از آنها ، نیاز به توجه دارد.یک گزینه استفاده گاه به گاه از [`clone`] است.
//! گزینه دیگر اعتماد به انواع مربوط به ارائه پیاده سازی های اضافی اپراتور برای منابع است.
//! به عنوان مثال ، برای یک نوع `T` تعریف شده توسط کاربر که قرار است علاوه بر آن را پشتیبانی کند ، احتمالاً ایده خوبی است که `T` و `&T` traits [`Add<T>`][`Add`] و [`Add<&T>`][`Add`] را پیاده سازی کنند تا کد عمومی بدون شبیه سازی غیر ضروری نوشته شود.
//!
//!
//! # Examples
//!
//! این مثال یک ساختار `Point` ایجاد می کند که [`Add`] و [`Sub`] را پیاده سازی می کند و سپس جمع و تفریق دو نقطه `را نشان می دهد.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! برای اجرای نمونه ، مستندات مربوط به هر trait را مشاهده کنید.
//!
//! [`Fn`] ، [`FnMut`] و [`FnOnce`] traits توسط انواع قابل اجرا مانند توابع پیاده سازی می شوند.توجه داشته باشید که [`Fn`] `&self` ، [`FnMut`] `&mut self` و [`FnOnce`] `self` می گیرند.
//! اینها با سه نوع روشی که می توان در یک نمونه فراخوانی کرد مطابقت دارد: فراخوانی از طریق مرجع ، فراخوانی توسط قابل تغییر در مرجع ، و از نظر ارزش.
//! متداول ترین کاربرد این traits این است که به عنوان مرزهای عملکردهای سطح بالاتر عمل می کند که توابع یا بسته شدن ها را به عنوان آرگومان می گیرند.
//!
//! با استفاده از [`Fn`] به عنوان یک پارامتر:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! با استفاده از [`FnMut`] به عنوان یک پارامتر:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! با استفاده از [`FnOnce`] به عنوان یک پارامتر:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` متغیرهای گرفته شده خود را مصرف می کند ، بنابراین نمی توان آن را بیش از یک بار اجرا کرد
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // تلاش برای فراخوانی مجدد `func()` خطای `use of moved value` برای `func` ایجاد می شود
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` در این مرحله دیگر نمی توان استناد کرد
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;