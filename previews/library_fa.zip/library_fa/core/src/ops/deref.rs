/// برای عملیات ارجاع مجدد تغییرناپذیر مانند `*v` استفاده می شود.
///
/// `Deref` علاوه بر اینکه برای عملیات ارجاع مجدد صریح با اپراتور (unary) `*` در زمینه های تغییرناپذیر استفاده می شود ، در بسیاری از شرایط توسط کامپایلر به طور ضمنی نیز استفاده می شود.
/// این مکانیزم ['`Deref` coercion'][more] نامیده می شود.
/// در زمینه های قابل تغییر ، از [`DerefMut`] استفاده می شود.
///
/// پیاده سازی `Deref` برای اشاره گرهای هوشمند دسترسی به داده های پشت سر آنها را راحت می کند ، به همین دلیل آنها `Deref` را پیاده سازی می کنند.
/// از طرف دیگر ، قوانین مربوط به `Deref` و [`DerefMut`] به طور خاص برای قرار دادن اشاره گرهای هوشمند طراحی شده اند.
/// به همین دلیل ، ** "Deref" فقط برای اشاره گرهای هوشمند باید اجرا شود تا از سردرگمی جلوگیری شود.
///
/// به دلایل مشابه ،**این trait هرگز نباید خراب شود**.شکست در هنگام مراجعه مجدد هنگامی که به طور ضمنی `Deref` فراخوانی می شود می تواند بسیار گیج کننده باشد.
///
/// # اطلاعات بیشتر در مورد اجبار `Deref`
///
/// اگر `T` `Deref<Target = U>` را پیاده سازی می کند و `x` مقداری از نوع `T` است ، پس:
///
/// * در زمینه های تغییرناپذیر ، `*x` (جایی که `T` نه مرجع است و نه یک اشاره گر خام) معادل `* Deref::deref(&x)` است.
/// * مقادیر نوع `&T` به مقادیر نوع `&U` وادار می شوند
/// * `T` ضمنی همه روش های (immutable) از نوع `U` را پیاده سازی می کند.
///
/// برای جزئیات بیشتر ، به [the chapter in *The Rust Programming Language*][book] و همچنین بخشهای مرجع در [the dereference operator][ref-deref-op] ، [method resolution] و [type coercions] مراجعه کنید.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// یک ساختار با یک قسمت واحد که با استناد به ارجاع مجدد به ساختار قابل دسترسی است.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// نوع حاصل پس از مراجعه مجدد.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// ارزش را حذف می کند.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// برای عملیات مرجع دهی متحرک مانند `*v = 1;` استفاده می شود.
///
/// `DerefMut` علاوه بر اینکه برای عملیات ارجاع مجدد صریح با اپراتور (unary) `*` در زمینه های قابل تغییر استفاده می شود ، در بسیاری از شرایط توسط کامپایلر به طور ضمنی نیز استفاده می شود.
/// این مکانیزم ['`Deref` coercion'][more] نامیده می شود.
/// در زمینه های تغییرناپذیر ، از [`Deref`] استفاده می شود.
///
/// پیاده سازی `DerefMut` برای اشاره گرهای هوشمند باعث تغییر در داده های پشت سر آنها راحت می شود ، به همین دلیل آنها `DerefMut` را پیاده سازی می کنند.
/// از طرف دیگر ، قوانین مربوط به [`Deref`] و `DerefMut` به طور خاص برای قرار دادن اشاره گرهای هوشمند طراحی شده اند.
/// به همین دلیل ، ** `DerefMut` فقط برای اشاره گرهای هوشمند باید اجرا شود تا از سردرگمی جلوگیری شود.
///
/// به دلایل مشابه ،**این trait هرگز نباید خراب شود**.شکست در هنگام مراجعه مجدد هنگامی که به طور ضمنی `DerefMut` فراخوانی می شود می تواند بسیار گیج کننده باشد.
///
/// # اطلاعات بیشتر در مورد اجبار `Deref`
///
/// اگر `T` `DerefMut<Target = U>` را پیاده سازی می کند و `x` مقداری از نوع `T` است ، پس:
///
/// * در زمینه های قابل تغییر ، `*x` (جایی که `T` نه مرجع است و نه یک اشاره گر خام) معادل `* DerefMut::deref_mut(&mut x)` است.
/// * مقادیر نوع `&mut T` به مقادیر نوع `&mut U` وادار می شوند
/// * `T` ضمنی همه روش های (mutable) از نوع `U` را پیاده سازی می کند.
///
/// برای جزئیات بیشتر ، به [the chapter in *The Rust Programming Language*][book] و همچنین بخشهای مرجع در [the dereference operator][ref-deref-op] ، [method resolution] و [type coercions] مراجعه کنید.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// یک ساختار با یک قسمت واحد که با استناد به ارجاع به ساختار قابل اصلاح است.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// به طور متغیر مقدار را استنباط می کنید.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// نشان می دهد که از یک ساختار می توان به عنوان گیرنده روش ، بدون ویژگی `arbitrary_self_types` استفاده کرد.
///
/// این توسط انواع نشانگر stdlib مانند `Box<T>` ، `Rc<T>` ، `&T` و `Pin<P>` پیاده سازی می شود.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}