/// نسخه اپراتور مکالمه که یک گیرنده تغییرناپذیر را می گیرد.
///
/// نمونه های `Fn` را می توان بدون تغییر حالت به طور مکرر فراخوانی کرد.
///
/// *این trait (`Fn`) را نباید با [function pointers] (`fn`) اشتباه گرفت.*
///
/// `Fn` به طور خودکار با بسته شدن هایی که فقط اشاره ای تغییرناپذیر به متغیرهای گرفته شده دارند یا اصلاً چیزی را ضبط نمی کنند ، و همچنین (safe) [function pointers] (با برخی از هشدارها ، برای اطلاعات بیشتر به اسناد آنها مراجعه کنید) اجرا می شود
///
/// علاوه بر این ، برای هر نوع `F` که `Fn` را پیاده سازی می کند ، `&F` نیز `Fn` را پیاده سازی می کند.
///
/// از آنجا که هر دو [`FnMut`] و [`FnOnce`] فوق العاده `Fn` هستند ، هر نمونه `Fn` می تواند به عنوان یک پارامتر که در آن [`FnMut`] یا [`FnOnce`] انتظار می رود ، استفاده شود.
///
/// هنگامی که می خواهید پارامتری از نوع عملکرد مانند را بپذیرید و نیاز به فراخوانی آن به طور مکرر و بدون حالت جهش دارید (به عنوان مثال ، هنگام فراخوانی همزمان) ، از `Fn` به عنوان مقید استفاده کنید.
/// اگر به چنین شرایط سختگیری نیاز ندارید ، از [`FnMut`] یا [`FnOnce`] به عنوان محدودیت استفاده کنید.
///
/// برای اطلاعات بیشتر در مورد این موضوع به [chapter on closures in *The Rust Programming Language*][book] مراجعه کنید.
///
/// همچنین نحو ویژه `Fn` traits قابل توجه است (به عنوان مثال
/// `Fn(usize, bool) -> استفاده کنید ").علاقمندان به جزئیات فنی این امر می توانند به [the relevant section in the *Rustonomicon*][nomicon] مراجعه کنند.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## تماس بسته شدن
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## با استفاده از پارامتر `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // تا regex بتواند به آن `&str: !FnMut` اعتماد کند
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// عملیات تماس را انجام می دهد.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// نسخه اپراتور مکالمه که یک گیرنده قابل تغییر می گیرد.
///
/// نمونه های `FnMut` را می توان به طور مکرر فراخوانی کرد و ممکن است حالت جهش یافته ای داشته باشد.
///
/// `FnMut` به طور خودکار با بسته شدن هایی که به منابع متغیر متغیرهای ضبط شده مراجعه می کنند و همچنین انواع مختلفی که [`Fn`] را اجرا می کنند ، به عنوان مثال ، (safe) [function pointers] (از آنجایی که `FnMut` یک سوپرایه [`Fn`] است) اجرا می شود.
/// علاوه بر این ، برای هر نوع `F` که `FnMut` را پیاده سازی می کند ، `&mut F` نیز `FnMut` را پیاده سازی می کند.
///
/// از آنجایی که [`FnOnce`] یک سوپرایه `FnMut` است ، می توان از هر نمونه `FnMut` در جاهایی که [`FnOnce`] انتظار می رود استفاده کرد و از آنجا که [`Fn`] یک فرعی از `FnMut` است ، می توان از هر نمونه [`Fn`] در جایی که `FnMut` انتظار می رود استفاده کرد.
///
/// هنگامی که می خواهید پارامتری از نوع عملکرد مانند را بپذیرید و باید مرتباً با آن تماس بگیرید ، از `FnMut` به عنوان مقید استفاده کنید ، در حالی که به آن اجازه می دهد حالت جهش داشته باشد.
/// اگر نمی خواهید پارامتر حالت جهش پیدا کند ، از [`Fn`] به عنوان یک bind استفاده کنید.اگر نیازی به تماس مکرر با آن نیست ، از [`FnOnce`] استفاده کنید.
///
/// برای اطلاعات بیشتر در مورد این موضوع به [chapter on closures in *The Rust Programming Language*][book] مراجعه کنید.
///
/// همچنین نحو ویژه `Fn` traits قابل توجه است (به عنوان مثال
/// `Fn(usize, bool) -> استفاده کنید ").علاقمندان به جزئیات فنی این امر می توانند به [the relevant section in the *Rustonomicon*][nomicon] مراجعه کنند.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## فراخوانی بسته شدن متغیر
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## با استفاده از پارامتر `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // تا regex بتواند به آن `&str: !FnMut` اعتماد کند
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// عملیات تماس را انجام می دهد.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// نسخه اپراتور مکالمه که یک گیرنده کم ارزش را می گیرد.
///
/// نمونه های `FnOnce` را می توان فراخوانی کرد ، اما ممکن است چندین بار قابل تماس نباشد.به همین دلیل ، اگر تنها چیزی که در مورد یک نوع شناخته شده است پیاده سازی `FnOnce` است ، فقط یک بار می توان تماس گرفت.
///
/// `FnOnce` به طور خودکار با بسته هایی که ممکن است متغیرهای ضبط شده را مصرف کنند ، و همچنین انواع مختلفی که [`FnMut`] را اجرا می کنند ، به عنوان مثال ، (safe) [function pointers] (از آنجا که `FnOnce` یک سوپرایه [`FnMut`] است) اجرا می شود.
///
///
/// از آنجا که هر دو [`Fn`] و [`FnMut`] زیر مجموعه `FnOnce` هستند ، هر نمونه [`Fn`] یا [`FnMut`] می تواند در جاهایی که `FnOnce` انتظار می رود استفاده شود.
///
/// هنگامی که می خواهید پارامتری از نوع عملکرد مانند را بپذیرید و فقط کافی است یک بار با آن تماس بگیرید ، از `FnOnce` به عنوان مقید استفاده کنید.
/// اگر نیاز به تماس مکرر با پارامتر دارید ، از [`FnMut`] به عنوان محدود استفاده کنید.اگر شما نیز به آن نیاز ندارید تا حالت جهش ایجاد کند ، از [`Fn`] استفاده کنید.
///
/// برای اطلاعات بیشتر در مورد این موضوع به [chapter on closures in *The Rust Programming Language*][book] مراجعه کنید.
///
/// همچنین نحو ویژه `Fn` traits قابل توجه است (به عنوان مثال
/// `Fn(usize, bool) -> استفاده کنید ").علاقمندان به جزئیات فنی این امر می توانند به [the relevant section in the *Rustonomicon*][nomicon] مراجعه کنند.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## با استفاده از پارامتر `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` متغیرهای گرفته شده خود را مصرف می کند ، بنابراین نمی توان آن را بیش از یک بار اجرا کرد.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // تلاش برای فراخوانی مجدد `func()` خطای `use of moved value` برای `func` ایجاد می شود.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` در این مرحله دیگر نمی توان استناد کرد
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // تا regex بتواند به آن `&str: !FnMut` اعتماد کند
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// نوع برگشتی پس از استفاده از اپراتور مکالمه.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// عملیات تماس را انجام می دهد.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}