//! مقدار نقطه شناور را به قسمتهای جداگانه و دامنه خطا رمزگشایی می کند.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// مقدار محدود بدون امضا رمزگشایی شده ، به این ترتیب:
///
/// - مقدار اصلی برابر با `mant * 2^exp` است.
///
/// - هر عددی از `(mant - minus)*2^exp` تا `(mant + plus)* 2^exp` به مقدار اصلی گرد می شود.
/// دامنه فقط زمانی است که `inclusive` `true` باشد.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// مانتیسای مقیاس دار
    pub mant: u64,
    /// دامنه خطای کمتری.
    pub minus: u64,
    /// دامنه خطای بالاتر.
    pub plus: u64,
    /// نماینده مشترک در پایه 2.
    pub exp: i16,
    /// وقتی دامنه خطا فراگیر باشد درست است.
    ///
    /// در IEEE 754 ، این درست است وقتی که مانتیسای اصلی یکنواخت بود.
    pub inclusive: bool,
}

/// رمزگشایی نشده
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// بینهایت ، مثبت یا منفی.
    Infinite,
    /// صفر ، مثبت یا منفی.
    Zero,
    /// اعداد محدود با زمینه های رمزگشایی بیشتر
    Finite(Decoded),
}

/// یک نوع شناور که می تواند "d" رمزگشایی شود.
pub trait DecodableFloat: RawFloat + Copy {
    /// حداقل مقدار نرمال شده مثبت.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// یک علامت (وقتی منفی است درست است) و مقدار `FullDecoded` را از شماره نقطه شناور داده شده برمی گرداند.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // همسایگان: (mant، 2، exp)-(mant، exp)-(mant + 2، exp)
            // Float::integer_decode همیشه نماینده را حفظ می کند ، بنابراین مانتیسا برای عادی ها مقیاس بندی می شود.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // همسایگان: (maxmant ، exp ، 1)-(minnormmant ، exp)-(minnormmant + 1 ، exp)
                // جایی که maxmant=نادرست بودن * 2 ، 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // همسایگان: (mant، 1، exp)-(mant، exp)-(mant + 1، exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}