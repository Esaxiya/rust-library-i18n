//! برآوردگر نماد.

/// `k_0` را مانند `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)` پیدا می کند.
///
/// این برای تقریبی `k = ceil(log_10 (mant * 2^exp))` استفاده می شود.
/// `k` واقعی یا `k_0` یا `k_0+1` است.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits اگر mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) بنابراین این همیشه دست کم می گیرد (یا دقیق است) ، اما نه زیاد.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}