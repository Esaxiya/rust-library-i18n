//! سازگاری Rust با الگوریتم Grisu3 که در "چاپ سریع و دقیق اعداد شناور با اعداد صحیح" شرح داده شده است [^ 1].
//! این از حدود 1 کیلوبایت جدول پیش محاسبه شده استفاده می کند و به نوبه خود برای اکثر ورودی ها بسیار سریع است.
//!
//! [^1]: Florian لویچ2010. چاپ سریع اعداد شناور با سرعت و
//!   با اعداد صحیح دقیق.SIGPLAN نیست45 ، 6 (ژوئن 2010) ، 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// برای توضیحات به نظرات `format_shortest_opt` مراجعه کنید.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-من ؛e=4* من ، 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f ، e ، k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// با توجه به `x > 0` ، `(k, 10^k)` را برمی گرداند مانند `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// کوتاهترین حالت اجرای برای گریسو.
///
/// `None` را برمی گرداند اگر در غیر اینصورت بازنمایی نادرستی داشته باشد.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // ما حداقل به سه بیت دقت اضافی نیاز داریم

    // با مقادیر نرمال شده با نمای مشترک شروع کنید
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // هر `cached = 10^minusk` را پیدا کنید مانند `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // از آنجا که `plus` نرمال است ، این بدان معنی است که `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`.
    // با توجه به انتخاب های `ALPHA` و `GAMMA` ، این `plus * cached` را در `[4, 2^32)` قرار می دهد.
    //
    // بدیهی است که به حداکثر رساندن `GAMMA - ALPHA` مطلوب است ، بنابراین ما به بسیاری از قدرت های ذخیره شده 10 نیاز نداریم ، اما برخی ملاحظات وجود دارد:
    //
    //
    // 1. ما می خواهیم `floor(plus * cached)` را در `u32` نگه داریم زیرا به یک تقسیم هزینه بر نیاز دارد.
    //    (این واقعاً قابل اجتناب نیست ، برای تخمین دقت به باقیمانده نیاز است.)
    // 2.
    // باقیمانده `floor(plus * cached)` به طور مکرر در 10 ضرب می شود و نباید سرریز شود.
    //
    // اولی `64 + GAMMA <= 32` می دهد ، در حالی که دومی `10 * 2^-ALPHA <= 2^64` می دهد.
    // -60 و -32 حداکثر دامنه با این محدودیت است و V8 نیز از آنها استفاده می کند.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // فریم در ثانیهاین حداکثر خطای 1 ulp را نشان می دهد (اثبات شده از قضیه 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-محدوده واقعی منهای
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // بالاتر از `minus` ، `v` و `plus`*تقریب** هستند (خطا <1 ulp).
    // از آنجا که نمی دانیم خطا مثبت یا منفی است ، از دو تقریب با فاصله برابر استفاده می کنیم و حداکثر خطا 2 ulps است.
    //
    // "unsafe region" یک فاصله لیبرال است که در ابتدا ایجاد می کنیم.
    // "safe region" یک فاصله محافظه کارانه است که ما فقط آن را می پذیریم.
    // ما با repr صحیح در منطقه ناامن شروع می کنیم و سعی می کنیم نزدیکترین repr را به `v` پیدا کنیم که در منطقه امن نیز باشد.
    // اگر نتوانیم ، تسلیم می شویم.
    //
    let plus1 = plus.f + 1;
    // بگذارید plus0 = plus.f ، 1؛//فقط برای توضیح اجازه دهید minus0 = minus.f + 1؛//فقط برای توضیح
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // نماینده مشترک

    // `plus1` را به قطعات انتگرال و کسری تقسیم کنید.
    // قطعات انتگرال در u32 جایگزین می شوند ، زیرا قدرت حافظه پنهان `plus < 2^32` را تضمین می کند و `plus.f` نرمال نیز به دلیل دقت بسیار کمتر از `2^64 - 2^4` است.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // بزرگترین `10^max_kappa` را بیش از `plus1` (بنابراین `plus1 < 10^(max_kappa+1)`) محاسبه نکنید.
    // این حد بالای `kappa` زیر است.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // قضیه 6.2: اگر `k` بزرگترین عدد صحیح است
    // `0 <= y mod 10^k <= y - x`,              پس `V = floor(y / 10^k) * 10^k` در `[x, y]` و یکی از کوتاهترین نمایش ها (با حداقل تعداد ارقام قابل توجه) در آن محدوده است.
    //
    //
    // مطابق قضیه 6.2 طول `kappa` بین `(minus1, plus1)` را پیدا کنید.
    // قضیه 6.2 را می توان تصویب کرد تا `x` را حذف کند و در عوض `y mod 10^k < y - x` را الزام کند.
    // (به عنوان مثال ، `x` =32000 ، `y` =32777 ؛ `kappa` =2 از آنجا که "y mod 10 ^ 3=777 <y ، x=777".) الگوریتم برای حذف `y` به مرحله تأیید بعدی متکی است.
    //
    let delta1 = plus1 - minus1;
    // بگذارید delta1int=(delta1>> e) به عنوان مقدار استفاده شود.//فقط برای توضیح
    let delta1frac = delta1 & ((1 << e) - 1);

    // ضمن بررسی صحت در هر مرحله ، قطعات انتگرال را ارائه دهید.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // رقمی که هنوز ارائه نشده است
    loop {
        // ما همیشه حداقل یک رقم برای ارائه داریم ، به عنوان موارد `plus1 >= 10^kappa`:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (نتیجه این است که `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // `remainder` را به `10^kappa` تقسیم کنید.هر دو توسط `2^-e` مقیاس بندی می شوند.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1٪ 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; ما `kappa` صحیح را پیدا کرده ایم.
            let ten_kappa = (ten_kappa as u64) << e; // مقیاس 10 ^ kappa به بیان مشترک بازمی گردد
            return round_and_weed(
                // ایمنی: ما آن حافظه را در ابتدا مقداردهی اولیه کردیم.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // وقتی همه ارقام انتگرال را ارائه دادیم حلقه را بشکنید.
        // تعداد دقیق ارقام `max_kappa + 1` به عنوان `plus1 < 10^(max_kappa+1)` است.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // موارد بازگرداندن
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ضمن بررسی صحت در هر مرحله ، قطعات کسری را ارائه دهید.
    // این بار به ضربهای مکرر اعتماد می کنیم ، زیرا تقسیم دقت را از دست می دهد.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // رقم بعدی باید قابل توجه باشد زیرا ما قبل از شکستن موارد نامحدود آزمایش کرده ایم ، جایی که `m = max_kappa + 1` (#رقم در قسمت انتگرال):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // سرریز نخواهد شد ، `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // `remainder` را به `10^kappa` تقسیم کنید.
        // هر دو توسط `2^e / 10^kappa` مقیاس بندی می شوند ، بنابراین مورد دوم در اینجا ضمنی است.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // تقسیم ضمنی
            return round_and_weed(
                // ایمنی: ما آن حافظه را در ابتدا مقداردهی اولیه کردیم.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // موارد بازگرداندن
        kappa -= 1;
        remainder = r;
    }

    // ما همه ارقام قابل توجه `plus1` را تولید کرده ایم ، اما مطمئن نیستیم که این رقم بهینه است.
    // به عنوان مثال ، اگر `minus1` 3.14153 ... و `plus1` 3.14158 باشد ... ، 5 نمایش کوتاه متفاوت از 3.14154 تا 3.14158 وجود دارد اما ما فقط بزرگترین را داریم.
    // ما باید به طور متوالی رقم آخر را کاهش دهیم و بررسی کنیم که آیا این بهترین رقم است.
    // حداکثر 9 نامزد وجود دارد (از 1 تا 3/9) ، بنابراین این کار بسیار سریع است.(فاز "rounding")
    //
    // عملکرد بررسی می کند که آیا این "optimal" بازپخش واقعاً در محدوده ulp قرار دارد یا خیر ، همچنین ممکن است که به دلیل خطای گرد کردن ، "second-to-optimal" بازده واقعی باشد.
    // در هر صورت این `None` را برمی گرداند.
    // (فاز "weeding")
    //
    // همه استدلال ها در اینجا با مقادیر معمول (اما ضمنی) `k` مقیاس بندی می شوند ، به این ترتیب:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (و همچنین ، `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (و همچنین ، `threshold > plus1v` از افراد قبلی)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // تولید دو تقریب به `v` (در واقع `plus1 - v`) در 1.5 ulps.
        // نمایندگی حاصل باید نزدیکترین نمایش به هر دو باشد.
        //
        // در اینجا `plus1 - v` استفاده می شود زیرا محاسبات مربوط به `plus1` انجام می شود تا از overflow/underflow جلوگیری شود (از این رو نام های به ظاهر مبادله شده).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v ، 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // آخرین رقم را کاهش دهید و در نزدیکترین نمایش به `v + 1 ulp` متوقف شوید.
        let mut plus1w = remainder; // plus1w(n) = plus1 ، w(n)
        {
            let last = buf.last_mut().unwrap();

            // ما با ارقام تقریبی `w(n)` کار می کنیم ، که در ابتدا برابر با `plus1 - plus1 % 10^kappa` است.پس از اجرای بدن حلقه `n` بار ، `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // ما `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` را تنظیم می کنیم (بنابراین `مانده= plus1w(0)`) برای ساده کردن چک ها).
            // توجه داشته باشید که `plus1w(n)` همیشه در حال افزایش است.
            //
            // ما سه شرط داریم که خاتمه دهیم.هرکدام از آنها حلقه را قادر به ادامه کار نمی کنند ، اما پس از آن حداقل یک نمایش معتبر داریم که به هر حال نزدیک ترین حالت به `v + 1 ulp` است.
            // ما آنها را به اختصار به عنوان TC1 تا TC3 نشان خواهیم داد.
            //
            // TC1: `w(n) <= v + 1 ulp` ، یعنی این آخرین نسخه است که می تواند نزدیکترین باشد.
            // این معادل `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up` است.
            // همراه با TC2 (که بررسی می کند آیا `w(n+1)` is valid) ، این مانع از سرریز احتمالی محاسبه `plus1w(n)` می شود).
            //
            // TC2: `w(n+1) < minus1` ، یعنی نسخه بعدی قطعاً به `v` نمی رسد.
            // این معادل `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold` است.
            // سمت چپ می تواند سرریز شود ، اما ما `threshold > plus1v` را می دانیم ، بنابراین اگر TC1 نادرست است ، `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` و ما می توانیم با خیال راحت `threshold - plus1w(n) < 10^kappa` را آزمایش کنیم.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))` ، یعنی نسخه بعدی است
            // به `v + 1 ulp` نزدیکتر از REP فعلی نیست.
            // با توجه به `z(n) = plus1v_up - plus1w(n)` ، این `abs(z(n)) <= abs(z(n+1))` می شود.باز هم با فرض نادرست بودن TC1 ، ما `z(n) > 0` داریم.ما باید دو مورد را در نظر بگیریم:
            //
            // - وقتی `z(n+1) >= 0`: TC3 تبدیل به `z(n) <= z(n+1)` می شود.
            // همانطور که `plus1w(n)` در حال افزایش است ، `z(n)` باید در حال کاهش باشد و این به وضوح نادرست است.
            // - وقتی `z(n+1) < 0`:
            //   - TC3a: پیش شرط `plus1v_up < plus1w(n) + 10^kappa` است.با فرض نادرست بودن TC2 ، `threshold >= plus1w(n) + 10^kappa` بنابراین نمی تواند سرریز شود.
            //   - TC3b: TC3 به `z(n) <= -z(n+1)` تبدیل می شود ، یعنی `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   TC1 نفی شده `plus1v_up > plus1w(n)` می دهد ، بنابراین در صورت ترکیب با TC3a نمی تواند سرریز یا کم شود.
            //
            // در نتیجه ، ما باید `TC1 || TC2 || (TC3a && TC3b)` را متوقف کنیم.زیر برابر با معکوس آن است ، `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // کوتاهترین نسخه نمی تواند با `0` به پایان برسد
                plus1w += ten_kappa;
            }
        }

        // بررسی کنید که آیا این نمایندگی نزدیکترین نمایندگی به `v - 1 ulp` است یا خیر.
        //
        // این به سادگی با شرایط خاتمه `v + 1 ulp` برابر است ، در عوض تمام `plus1v_up` با `plus1v_down` جایگزین می شود.
        // تجزیه و تحلیل سرریز به همان اندازه برگزار می شود.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // اکنون نزدیکترین نمایش به `v` بین `plus1` و `minus1` را داریم.
        // اگرچه این بیش از حد لیبرال است ، بنابراین ما هر `w(n)` را نه بین `plus0` و `minus0` ، یعنی `plus1 - plus1w(n) <= minus0` یا `plus1 - plus1w(n) >= plus0` ، رد می کنیم.
        // ما از حقایق `threshold = plus1 - minus1` و `plus1 - plus0 = minus0 - minus1 = 2 ulp` استفاده می کنیم.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// کوتاهترین حالت اجرای برای گریسو با گزینه Dragon.
///
/// این باید در بیشتر موارد استفاده شود.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // ایمنی: جستجوگر وام آنقدر هوشمند نیست که به ما اجازه دهد از `buf` استفاده کنیم
    // در branch دوم ، بنابراین ما عمر را در اینجا شستشو می دهیم.
    // اما ما فقط `buf` را مجدداً استفاده می کنیم اگر `format_shortest_opt` `None` را بازگرداند بنابراین اشکالی ندارد.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// اجرای دقیق و ثابت حالت گریسو.
///
/// `None` را برمی گرداند اگر در غیر اینصورت بازنمایی نادرستی داشته باشد.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // ما حداقل به سه بیت دقت اضافی نیاز داریم
    assert!(!buf.is_empty());

    // عادی و مقیاس `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // `v` را به قطعات انتگرال و کسری تقسیم کنید.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // `v` قدیمی و `v` جدید (با مقیاس `10^-k`) دارای خطای <1 ulp (قضیه 5.1) هستند.
    // از آنجا که نمی دانیم خطا مثبت یا منفی است ، از دو تقریب با فاصله برابر استفاده می کنیم و حداکثر خطا 2 ulps (همان کوتاه ترین حالت) است.
    //
    //
    // هدف این است که سریهای دقیقاً گرد شده ای را که برای `v - 1 ulp` و `v + 1 ulp` مشترک هستند پیدا کنید ، به طوری که حداکثر اطمینان داشته باشیم.
    // اگر این امکان وجود نداشته باشد ، ما نمی دانیم کدام یک خروجی صحیح `v` است ، بنابراین ما تسلیم می شویم و عقب می افتیم.
    //
    // `err` در اینجا به عنوان `1 ulp * 2^e` تعریف شده است (همان ulp در `vfrac`) ، و هر زمان که `v` مقیاس بندی شود ما آن را مقیاس بندی خواهیم کرد.
    //
    //
    //
    let mut err = 1;

    // بزرگترین `10^max_kappa` را بیش از `v` (بنابراین `v < 10^(max_kappa+1)`) محاسبه نکنید.
    // این حد بالای `kappa` زیر است.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // اگر ما با محدودیت آخرین رقم کار می کنیم ، برای جلوگیری از گرد شدن دو برابر ، باید قبل از ارائه واقعی ، بافر را کوتاه کنیم.
    //
    // توجه داشته باشید که هنگام جمع کردن ، باید بافر را بزرگتر کنیم!
    let len = if exp <= limit {
        // اوه ، ما حتی نمی توانیم *یک* رقم تولید کنیم.
        // این ممکن است زمانی که ، مثلاً ، چیزی شبیه 9.5 به دست ما رسیده و به 10 رسیده است.
        //
        // در اصل ما می توانیم بلافاصله `possibly_round` را با یک بافر خالی فراخوانی کنیم ، اما مقیاس دهی `max_ten_kappa << e` با 10 می تواند منجر به سرریز شود.
        //
        // بنابراین ما در اینجا شلخته هستیم و دامنه خطا را با ضریب 10 افزایش می دهیم.
        // این میزان منفی کاذب را افزایش می دهد ، اما فقط بسیار ،*بسیار* کمی.
        // این فقط زمانی قابل توجه است که مانتیسا از 60 بیت بزرگتر باشد.
        //
        // ایمنی: `len=0` ، بنابراین الزام به مقداردهی اولیه این حافظه بی اهمیت است.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // ارائه اجزای اصلی
    // خطا کاملا کسری است ، بنابراین نیازی به بررسی آن در این قسمت نیست.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // رقمی که هنوز ارائه نشده است
    loop {
        // ما همیشه حداقل یک رقم برای ارائه موارد ناخوشایند داریم:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (نتیجه این است که `remainder = vint % 10^(kappa+1)`)
        //
        //

        // `remainder` را به `10^kappa` تقسیم کنید.هر دو توسط `2^-e` مقیاس بندی می شوند.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // بافر پر است؟پاس گرد را باقیمانده اجرا کنید.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v٪ 10 ^ kappa) * 2 ^ e
            // ایمنی: ما `len` بایت زیادی را مقداردهی اولیه کرده ایم.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // وقتی همه ارقام انتگرال را ارائه دادیم حلقه را بشکنید.
        // تعداد دقیق ارقام `max_kappa + 1` به عنوان `plus1 < 10^(max_kappa+1)` است.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // موارد بازگرداندن
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ارائه قطعات کسری
    //
    // در اصل می توانیم به آخرین رقم موجود ادامه دهیم و صحت را بررسی کنیم.
    // متأسفانه ما در حال کار با عدد صحیح متناهی هستیم ، بنابراین برای تشخیص سرریز نیاز به چند معیار داریم.
    // V8 از `remainder > err` استفاده می کند ، که هنگامی که اولین رقم قابل توجه `i` از `v - 1 ulp` و `v` متفاوت باشد ، نادرست می شود.
    // با این حال این ورودی بیش از حد معتبر را رد می کند.
    //
    // از آنجا که فاز بعدی دارای یک تشخیص صحیح سرریز است ، ما در عوض از معیار دقیق تری استفاده می کنیم:
    // ما ادامه می دهیم تا `err` بیش از `10^kappa / 2` باشد ، بنابراین محدوده بین `v - 1 ulp` و `v + 1 ulp` قطعاً شامل دو یا چند نمایش گرد است.
    //
    // این برای مقایسه با دو مقایسه اول `possibly_round` است.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // ثابت ، که در آن `m = max_kappa + 1` (#رقم در بخش انتگرال):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // سرریز نخواهد شد ، `2^e * 10 < 2^64`
        err *= 10; // سرریز نخواهد شد ، `err * 10 < 2^e * 5 < 2^64`

        // `remainder` را به `10^kappa` تقسیم کنید.
        // هر دو توسط `2^e / 10^kappa` مقیاس بندی می شوند ، بنابراین مورد دوم در اینجا ضمنی است.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // بافر پر است؟پاس گرد را باقیمانده اجرا کنید.
        if i == len {
            // ایمنی: ما `len` بایت زیادی را مقداردهی اولیه کرده ایم.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // موارد بازگرداندن
        remainder = r;
    }

    // محاسبه بیشتر بی فایده است (`possibly_round` قطعاً شکست می خورد) ، بنابراین ما تسلیم می شویم.
    return None;

    // ما تمام ارقام درخواستی `v` را تولید کرده ایم که باید با رقم مربوط به `v - 1 ulp` نیز برابر باشد.
    // اکنون بررسی می کنیم که آیا نمایشی منحصر به فرد توسط `v - 1 ulp` و `v + 1 ulp` به اشتراک گذاشته شده است.این می تواند برای ارقام تولید شده یکسان باشد ، یا برای نسخه گرد شده این رقم ها.
    //
    // اگر محدوده شامل چندین نمایش از همان طول باشد ، نمی توان مطمئن بود و باید `None` را به جای آن بازگرداند.
    //
    // همه استدلال ها در اینجا با مقادیر معمول (اما ضمنی) `k` مقیاس بندی می شوند ، به این ترتیب:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // ایمنی: اولین بایت `len` با `buf` باید مقداردهی اولیه شود.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (برای مرجع ، خط نقطه ای مقدار دقیق نمایش های احتمالی را با تعداد مشخص رقم نشان می دهد.)
        //
        //
        // خطا خیلی بزرگ است که حداقل سه نمایش ممکن بین `v - 1 ulp` و `v + 1 ulp` وجود دارد.
        // ما نمی توانیم تعیین کنیم که کدام یک صحیح است.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // در حقیقت ، 1/2 ulp برای معرفی دو نمایش احتمالی کافی است.
        // (بخاطر داشته باشید که برای `v - 1 ulp` و `v + 1 ulp` به نمایندگی منحصر به فرد نیاز داریم.) چون `ulp < ten_kappa` از اولین بررسی ، این حالت سرریز نخواهد شد.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ کاپا---------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // اگر `v + 1 ulp` به نمای گرد شده نزدیکتر باشد (که قبلاً در `buf` قرار دارد) ، پس می توانیم با خیال راحت برگردیم.
        // توجه داشته باشید که `v - 1 ulp`*می تواند* کمتر از نمایش فعلی باشد ، اما به عنوان `1 ulp < 10^kappa / 2` ، این شرط کافی است:
        // فاصله بین `v - 1 ulp` و نمایش فعلی نمی تواند بیش از `10^kappa / 2` باشد.
        //
        // شرط برابر با `remainder + ulp < 10^kappa / 2` است.
        // از آنجا که این به راحتی می تواند سرریز شود ، ابتدا `remainder < 10^kappa / 2` را بررسی کنید.
        // ما قبلاً تأیید کرده ایم که `ulp < 10^kappa / 2` ، بنابراین تا زمانی که `10^kappa` سرریز نکند ، بررسی دوم خوب است.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // ایمنی: تماس گیرنده ما حافظه را اولیه می کند.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------باقیمانده------> |:
        //   :                          |   :
        //   : <---------10 ^ کاپا--------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // از طرف دیگر ، اگر `v - 1 ulp` به نمای گرد شده نزدیکتر باشد ، باید جمع شده و برگردیم.
        // به همین دلیل نیازی به بررسی `v + 1 ulp` نداریم.
        //
        // شرط برابر با `remainder - ulp >= 10^kappa / 2` است.
        // مجدداً ابتدا `remainder > ulp` را بررسی می کنیم (توجه داشته باشید که این `remainder >= ulp` نیست ، زیرا `10^kappa` هرگز صفر نیست).
        //
        // همچنین توجه داشته باشید که `remainder - ulp <= 10^kappa` ، بنابراین چک دوم سرریز نمی شود.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // ایمنی: تماس گیرنده ما باید آن حافظه را اولیه کرده باشد.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // فقط هنگامی که از ما دقت ثابت درخواست شده است ، یک رقم اضافی اضافه کنید.
                // ما همچنین باید بررسی کنیم که ، اگر بافر اصلی خالی بود ، رقم اضافی فقط هنگام `exp == limit` (مورد edge) می تواند اضافه شود.
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // ایمنی: ما و تماس گیرنده خود حافظه را اولیه کردیم.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // در غیر این صورت ما محکوم به فنا هستیم (یعنی برخی مقادیر بین `v - 1 ulp` و `v + 1 ulp` گرد می شوند و برخی دیگر گرد می شوند) و منصرف می شویم.
        //
        None
    }
}

/// اجرای دقیق و ثابت حالت گریسو با گزینه Dragon.
///
/// این باید در بیشتر موارد استفاده شود.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // ایمنی: جستجوگر وام آنقدر هوشمند نیست که به ما اجازه دهد از `buf` استفاده کنیم
    // در branch دوم ، بنابراین ما عمر را در اینجا شستشو می دهیم.
    // اما ما فقط `buf` را مجدداً استفاده می کنیم اگر `format_exact_opt` `None` را بازگرداند بنابراین اشکالی ندارد.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}