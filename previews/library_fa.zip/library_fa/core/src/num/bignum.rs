//! تعداد دلخواه و دلخواه پیاده سازی (bignum).
//!
//! این کار برای جلوگیری از تخصیص انباشته در هزینه حافظه پشته طراحی شده است.
//! بیشترین استفاده از نوع bignum ، `Big32x40` ، با 32 × 40=1،280 بیت محدود شده و حداکثر 160 بایت حافظه پشته خواهد داشت.
//! این برای دور زدن تمام مقادیر محدود `f64` بیش از اندازه کافی است.
//!
//! در اصل ممکن است چندین نوع bignum برای ورودی های مختلف وجود داشته باشد ، اما برای جلوگیری از نفخ کد این کار را نمی کنیم.
//!
//! هر bignum هنوز برای کاربردهای واقعی ردیابی می شود ، بنابراین معمولاً اهمیتی ندارد.
//!

// این ماژول فقط برای dec2flt و flt2dec است و فقط به دلیل coretests عمومی است.
// در نظر گرفته نشده است که هرگز تثبیت شود.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// عملیات حسابی مورد نیاز bignums.
pub trait FullOps: Sized {
    /// `(carry', v')` را مانند `carry' * 2^W + v' = self + other + carry` برمی گرداند ، جایی که `W` تعداد بیت های `Self` است.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `(carry', v')` را مانند `carry'*2^W + v' = self* other + carry` برمی گرداند ، جایی که `W` تعداد بیت های `Self` است.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(carry', v')` را مانند `carry'*2^W + v' = self* other + other2 + carry` برمی گرداند ، جایی که `W` تعداد بیت های `Self` است.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `(quo, rem)` را مانند `borrow *2^W + self = quo* other + rem` و `0 <= rem < other` برمی گرداند ، جایی که `W` تعداد بیت های `Self` است.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // این نمی تواند سرریز شود.خروجی بین `0` و `2 * 2^nbits - 1` است.
                    // FIXME: آیا LLVM این مورد را به ADC یا موارد مشابه بهینه می کند؟
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // این نمی تواند سرریز شود.
                    // خروجی بین `0` و `2^nbits * (2^nbits - 1)` است.
                    // FIXME: آیا LLVM این مورد را به ADC یا موارد مشابه بهینه می کند؟
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // این نمی تواند سرریز شود.
                    // خروجی بین `0` و `2^nbits * (2^nbits - 1)` است.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // این نمی تواند سرریز شود.خروجی بین `0` و `other * (2^nbits - 1)` است.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // برای فعال کردن این امر به RFC #521 مراجعه کنید.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// جدول قدرت های 5 عددی که به صورت رقمی نمایش داده می شوند.به طور خاص ، بزرگترین مقدار {u8, u16, u32} که قدرت پنج ، به علاوه توان مربوطه است.
/// در `mul_pow5` استفاده می شود.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// عدد صحیح با دقت دلخواه (تا حد معین) تخصیص یافته است.
        ///
        /// این توسط یک آرایه با اندازه ثابت از نوع داده شده ("digit") پشتیبانی می شود.
        /// در حالی که آرایه خیلی بزرگ نیست (به طور معمول حدود صد بایت) ، کپی بی پروا از آن ممکن است منجر به عملکرد شود.
        ///
        /// بنابراین این عمدا `Copy` نیست.
        ///
        /// تمام عملیات موجود برای bignums panic در صورت سرریز.
        /// تماس گیرنده وظیفه استفاده از انواع بزرگ به اندازه کافی بزرگ را دارد.
        pub struct $name {
            /// یک به علاوه جبران حداکثر "digit" در استفاده.
            /// این کاهش نمی یابد ، بنابراین از دستور محاسبه آگاه باشید.
            /// `base[size..]` باید صفر باشد
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` را نشان می دهد که `W` تعداد بیت ها در نوع رقم است.
            base: [$ty; $n],
        }

        impl $name {
            /// از یک رقم bignum می سازد.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// از مقدار `u64` یک bignum می سازد.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// ارقام داخلی را به صورت قطعه `[a, b, c, ...]` برمی گرداند به طوری که مقدار عددی `a + b *2^W + c* 2^(2W) + ...` است که `W` تعداد بیت ها در نوع رقم است.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// بیت "i" را برمی گرداند که بیت 0 کمترین مقدار است.
            /// به عبارت دیگر ، بیت با وزن `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// اگر bignum صفر باشد `true` را برمی گرداند.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// تعداد بیت های لازم برای نمایش این مقدار را برمی گرداند.
            /// توجه داشته باشید که صفر نیاز به 0 بیت در نظر گرفته شده است.
            pub fn bit_length(&self) -> usize {
                // از مهمترین ارقام صفر عبور کنید.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // هیچ رقمی غیر صفر وجود ندارد ، یعنی عدد صفر است.
                    return 0;
                }
                // این را می توان با leading_zeros() و شیفت بیت بهینه کرد ، اما این احتمالاً ارزش دردسر را ندارد.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` را به خودش اضافه می کند و مرجع قابل تغییر خود را برمی گرداند.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` را از خودش کم می کند و مرجع قابل تغییر خود را برمی گرداند.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// خود را در `other` به اندازه یک رقم ضرب می کند و مرجع قابل تغییر خود را برمی گرداند.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// خود را در `2^bits` ضرب می کند و مرجع قابل تغییر خود را برمی گرداند.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // تغییر توسط بیت های `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // تغییر توسط بیت های `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. رقم] صفر است ، نیازی به تغییر نیست
                }

                self.size = sz;
                self
            }

            /// خود را در `5^e` ضرب می کند و مرجع قابل تغییر خود را برمی گرداند.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // دقیقاً n صفر انتهایی در 2 ^ n وجود دارد و تنها اندازه های رقمی مربوطه قدرت های متوالی دو هستند ، بنابراین این شاخص برای جدول مناسب است.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // با بیشترین توان تک رقمی تا زمانی که ممکن است ضرب کنید ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... سپس باقی مانده را تمام کنید.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// خودش را با عددی که توسط `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` توصیف شده ضرب می کند (جایی که `W` تعداد بیت ها در نوع رقم است) و مرجع قابل تغییر خود را برمی گرداند.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // روال داخلیوقتی aa.len() <= bb.len() بهتر کار می کند.
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// خودش را به اندازه `other` به اندازه رقم تقسیم می کند و مرجع تغییر پذیر *و* باقیمانده خود را برمی گرداند.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// خود را با یک bignum دیگر تقسیم کنید ، `q` را با نصاب و `r` را با بقیه جایگزین کنید.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // تقسیم طولانی احمق کند base-2 گرفته شده از
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME از یک پایه بزرگتر ($ty) برای تقسیم طولانی استفاده می کند.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // بیت `i` از q را روی 1 تنظیم کنید.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// نوع رقمی برای `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// این یکی فقط برای آزمایش استفاده می شود.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}