//! تبدیل رشته های اعشاری به IEEE 754 اعداد دودویی شناور.
//!
//! # بیان مسأله
//!
//! یک رشته اعشاری مانند `12.34e56` به ما داده می شود.
//! این رشته از قطعات انتگرال (`12`) ، کسری (`34`) و قطعات (`56`) تشکیل شده است.تمام قطعات اختیاری هستند و هنگام از دست دادن صفر تفسیر می شوند.
//!
//! ما به دنبال شماره نقطه شناور IEEE 754 هستیم که نزدیکترین مقدار دقیق به رشته اعشاری باشد.
//! معروف است که بسیاری از رشته های اعشاری در پایه دو نمایش ختم ندارند ، بنابراین در آخرین مکان (به عبارت دیگر ، و همچنین ممکن) به واحد 0.5 می گردیم.
//! کراوات ، مقادیر اعشاری دقیقاً در نیمه راه بین دو شناور متوالی ، با استراتژی نیمه به تساوی حل می شود ، همچنین به عنوان گردکاری بانکدار شناخته می شود.
//!
//! نیازی به گفتن نیست ، این از نظر پیچیدگی پیاده سازی و هم از نظر چرخه پردازنده انجام شده کاملاً سخت است.
//!
//! # Implementation
//!
//! اول ، ما علائم را نادیده می گیریم.یا بهتر بگوییم ، ما آن را در ابتدای فرآیند تبدیل حذف کرده و در انتها مجدداً اعمال می کنیم.
//! این در همه موارد edge صحیح است زیرا شناورهای IEEE در حدود صفر متقارن هستند ، با نادیده گرفتن یک بیت اول ، به راحتی چرخانده می شود.
//!
//! سپس با تنظیم نماد نقطه اعشاری را حذف می کنیم: از نظر مفهومی ، `12.34e56` به `1234e54` تبدیل می شود ، که ما آن را با یک عدد صحیح مثبت `f = 1234` و یک عدد صحیح `e = 54` توصیف می کنیم.
//! نمایش `(f, e)` تقریباً توسط همه کدهای مرحله تجزیه استفاده می شود.
//!
//! سپس یک زنجیره طولانی از موارد خاص به تدریج کلی تر و گران قیمت را با استفاده از عددهای صحیح به اندازه ماشین و اعداد کوچک و شناور با اندازه ثابت (ابتدا `f32`/`f64` ، سپس یک نوع با 64 بیتی و `Fp`) امتحان می کنیم.
//!
//! وقتی همه اینها شکست می خورد ، ما گلوله را گاز می گیریم و به یک الگوریتم ساده اما بسیار کند متوسل می شویم که شامل محاسبه کامل `f * 10^e` و جستجوی تکراری برای بهترین تقریب است.
//!
//! در درجه اول ، این ماژول و فرزندان آن الگوریتم های توصیف شده در:
//! "How to Read Floating Point Numbers Accurately" توسط ویلیام دی
//! Clinger ، به صورت آنلاین موجود است: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! علاوه بر این ، توابع کمکی بی شماری وجود دارد که در مقاله استفاده می شود اما در Rust (یا حداقل در هسته) موجود نیست.
//! نسخه ما علاوه بر این به دلیل نیاز به کنترل سرریز و کم جریان و تمایل به کنترل اعداد غیر عادی پیچیده است.
//! Bellerophon و Algorithm R در سرریز ، زیر نرمال و کم شدن جریان مشکل دارند.
//! ما محافظه کارانه قبل از ورود ورودی ها به منطقه مهم ، به الگوریتم M (با تغییراتی که در بخش 8 مقاله شرح داده شده است) تغییر می دهیم.
//!
//! جنبه دیگری که نیاز به توجه دارد "RawFloat" trait است که تقریباً همه توابع با آن پارامتر می شوند.ممکن است تصور شود که تجزیه به `f64` کافی است و نتیجه را به `f32` می دهیم.
//! متأسفانه این دنیایی نیست که ما در آن زندگی می کنیم و این هیچ ارتباطی با استفاده از گرد کردن پایه دو یا نیمه تا یکنواخت ندارد.
//!
//! به عنوان مثال دو نوع `d2` و `d4` را نشان دهید كه نشان دهنده نوع اعشاری با دو رقم اعشار و چهار رقم اعشار است و "0.01499" را به عنوان ورودی در نظر بگیرید.بیایید از گرد کردن به نیمه استفاده کنیم.
//! رفتن مستقیم به دو رقم اعشاری `0.01` را نشان می دهد ، اما اگر ابتدا به چهار رقم گرد کنیم ، `0.0150` بدست می آوریم که سپس تا `0.02` گرد می شود.
//! همین اصل در مورد سایر عملیات نیز وجود دارد ، اگر دقت 0.5 ULP را می خواهید ، باید *همه کارها* را با دقت کامل و دور *دقیقاً یک بار انجام دهید ، در پایان*، با در نظر گرفتن همه بیت های کوتاه شده همزمان.
//!
//! FIXME: اگرچه برخی از تکثیر کد ها لازم است ، اما ممکن است قسمت هایی از کد به گونه ای تغییر شکل داده شود که کد کمتری کپی شود.
//! قسمتهای بزرگی از الگوریتمها از نوع شناور برای خروج مستقل نیستند یا فقط نیاز به دسترسی به چند ثابت دارند که می تواند به عنوان پارامتر منتقل شود.
//!
//! # Other
//!
//! تبدیل باید *هرگز* panic باشد.
//! اظهارات و panics صریح در کد وجود دارد ، اما هرگز نباید آنها را تحریک کرد و فقط به عنوان بررسی های عقلانیت داخلی عمل می کنند.هر panics باید یک اشکال محسوب شود.
//!
//! آزمونهای واحدی وجود دارد اما در حصول اطمینان از صحت آنها بسیار ناکافی هستند ، آنها فقط درصد کمی از خطاهای احتمالی را پوشش می دهند.
//! آزمایشات بسیار گسترده تری به عنوان یک اسکریپت Python در دایرکتوری `src/etc/test-float-parse` قرار دارد.
//!
//! یادداشتی در مورد سرریز عدد صحیح: بسیاری از قسمتهای این پرونده با صفت اعشار `e` حساب می کنند.
//! در ابتدا ، نقطه اعشار را به اطراف تغییر می دهیم: قبل از اولین رقم اعشاری ، بعد از آخرین رقم اعشاری و غیره.در صورت بی احتیاطی این امر ممکن است سرریز شود.
//! ما به زیر ماژول تجزیه و تکیه می کنیم تا فقط نمایانگرهای کوچک را به اندازه کافی کوچک تقسیم کنیم ، جایی که "sufficient" به معنای "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" است.
//! نماهای بزرگتر پذیرفته می شوند ، اما ما حساب آنها را انجام نمی دهیم ، آنها بلافاصله به {positive,negative} {zero,infinity} تبدیل می شوند.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// این دو تست خاص خود را دارند.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// یک رشته در پایه 10 را به float تبدیل می کند.
            /// نماد اعشاری اختیاری را می پذیرد.
            ///
            /// این تابع رشته هایی مانند را می پذیرد
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', یا معادل آن ، '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', یا معادل آن '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// فضای خالی و پیشرو نشان دهنده یک خطا است.
            ///
            /// # Grammar
            ///
            /// تمام رشته هایی که به دستور زیر [EBNF] می چسبند ، منجر به بازگشت [`Ok`] می شوند:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # اشکالات شناخته شده
            ///
            /// در بعضی شرایط ، برخی از رشته ها که باید یک float معتبر ایجاد کنند ، خطایی را برمی گردانند.
            /// برای جزئیات بیشتر به [issue #31407] مراجعه کنید.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src ، یک رشته
            ///
            /// # مقدار برگشتی
            ///
            /// `Err(ParseFloatError)` اگر رشته عدد معتبری را نشان نمی داد.
            /// در غیر این صورت ، `Ok(n)` که `n` عدد شناور است که توسط `src` نشان داده می شود.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// خطایی که هنگام تجزیه شناور قابل بازگشت است.
///
/// این خطا به عنوان نوع خطا برای پیاده سازی [`FromStr`] برای [`f32`] و [`f64`] استفاده می شود.
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// یک رشته اعشاری را به علامت و بقیه تقسیم می کند ، بدون اینکه بقیه را بررسی یا تأیید کنید.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // اگر رشته نامعتبر باشد ، ما هرگز از علامت استفاده نمی کنیم ، بنابراین نیازی نیست که در اینجا اعتبار سنجی کنیم.
        _ => (Sign::Positive, s),
    }
}

/// یک رشته اعشاری را به یک عدد نقطه شناور تبدیل می کند.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// اسب اصلی کار برای تبدیل اعشاری به شناور: تمام پیش پردازش ها را ارکستر کنید و بفهمید کدام الگوریتم باید تبدیل واقعی را انجام دهد.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift رقم اعشار
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 به 1280 بیت محدود می شود که در حدود 385 رقم اعشاری ترجمه می شود.
    // اگر از این بالاتر برویم ، خراب می شویم ، بنابراین قبل از نزدیک شدن به خطا از خطا خارج می شویم (ظرف 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // اکنون این نمایشگر قطعاً در 16 بیتی جا می گیرد که در کل الگوریتم های اصلی استفاده می شود.
    let e = e as i16;
    // FIXME این مرزها کاملا محافظه کارانه هستند.
    // تجزیه و تحلیل دقیق تر از حالت های خرابی Bellerophon می تواند استفاده از آن را در موارد بیشتر برای سرعت زیاد فراهم کند.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// همانطور که نوشته شده است ، این بد بهینه سازی می شود (به #27130 مراجعه کنید ، اگرچه به نسخه قدیمی کد اشاره دارد).
// `inline(always)` یک راه حل برای آن است.
// به طور کلی فقط دو سایت تماس وجود دارد و اندازه کد را بدتر نمی کند.

/// درصورت امکان صفرها را بچرخانید ، حتی در مواردی که این نیاز به تغییر توان دارد
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // کوتاه کردن این صفرها تغییری ایجاد نمی کند اما ممکن است مسیر سریع (<15 رقمی) را فعال کند.
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // اعداد فرم 0،0 ... x و x ... 0،0 را ساده کنید و نمایه را متناسب با آن تنظیم کنید.
    // این ممکن است همیشه یک برد نباشد (احتمالاً تعدادی از اعداد را از مسیر سریع خارج می کند) ، اما قسمت های دیگر را به طور قابل توجهی ساده می کند (به طور تقریبی ، تقریب اندازه مقدار).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// یک کلاف بالایی سریع و کثیف در اندازه (log10) از بزرگترین مقداری را که الگوریتم R و الگوریتم M هنگام کار بر روی اعشاری داده شده محاسبه می کنند ، برمی گرداند.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // ما به لطف trivial_cases() و تجزیه کننده ، که شدیدترین ورودی ها را برای ما فیلتر می کنند ، در اینجا نیازی نیست که زیاد نگران سرریز آب باشیم.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // در حالت e>=0 ، هر دو الگوریتم حدود `f * 10^e` را محاسبه می کنند.
        // الگوریتم R با این کار محاسبات پیچیده ای را انجام می دهد اما ما می توانیم این مورد را برای حد بالا نادیده بگیریم زیرا همچنین کسری را از قبل کاهش می دهد ، بنابراین بافر زیادی در آنجا داریم.
        //
        f_len + (e as u64)
    } else {
        // اگر e <0 باشد ، الگوریتم R تقریباً همان کار را انجام می دهد ، اما الگوریتم M متفاوت است:
        // سعی می شود یک عدد k مثبت پیدا کند به طوری که `f << k / 10^e` یک علامت محدوده باشد.
        // این امر منجر به حدود `2^53 *f* 10^e` <`10^17 *f* 10^e` خواهد شد.
        // یک ورودی که باعث این می شود 0.33 ... 33 (375 (3) است.
        f_len + e.unsigned_abs() + 17
    }
}

/// سرریزها و سرریزهای آشکار را حتی بدون مشاهده رقم اعشار تشخیص می دهد.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // صفر وجود داشت اما توسط simplify() سلب شد
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // این تقریبی خام از ceil(log10(the real value)) است.
    // در اینجا نیازی به نگرانی بیش از حد برای سرریز نداریم زیرا طول ورودی بسیار ناچیز است (حداقل در مقایسه با 2 ^ 64) و تجزیه کننده از قبل نمایه هایی را کنترل می کند که مقدار مطلق آنها بیشتر از 10 ^ 18 باشد (که هنوز 10 ^ 19 کوتاه است) 64)
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}