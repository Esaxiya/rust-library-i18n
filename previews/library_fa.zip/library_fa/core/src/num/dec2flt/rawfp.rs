//! بازی کوچک در شناورهای مثبت IEEE 754.اعداد منفی مورد استفاده قرار نمی گیرند و نیازی به استفاده از آنها نیست.
//! اعداد عادی شناور نمایشی متعارف به صورت (frac ، exp) دارند به طوری که مقدار 2 <sup>exp</sup> * است (1 + sum(frac[N-i] / 2<sup>i</sup>)) که N تعداد بیت ها است.
//!
//! عادی های فرعی کمی متفاوت و عجیب هستند ، اما همان اصل اعمال می شود.
//!
//! در اینجا ، ما آنها را به صورت (sig ، k) با f مثبت نشان می دهیم ، به طوری که مقدار f * است
//! 2 <sup>e</sup>علاوه بر اینکه "hidden bit" صریح است ، این تغییر اصطلاحاً تغییر شیفت مانتیسا را تغییر می دهد.
//!
//! به روشی دیگر ، به طور معمول شناورها به صورت (1) نوشته می شوند اما در اینجا با (2) نوشته می شوند:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! ما (1) را **نمای کسری** و (2) را **نمایشی انتگرال** می نامیم.
//!
//! بسیاری از توابع در این ماژول فقط اعداد نرمال را کنترل می کنند.روال های dec2flt با محافظه کاری مسیر آهسته کاملاً صحیح جهانی (الگوریتم M) را برای اعداد بسیار کوچک و بسیار بزرگ طی می کنند.
//! این الگوریتم فقط به next_float() نیاز دارد که از زیر نرمال ها و صفرها استفاده کند.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// trait کمکی برای جلوگیری از تکثیر اساساً همه کد تبدیل برای `f32` و `f64`.
///
/// برای اینکه چرا این کار ضروری است ، نظرات مربوط به ماژول والدین را ببینید.
///
/// آیا باید **هرگز** برای انواع دیگر پیاده سازی شود یا در خارج از ماژول dec2flt مورد استفاده قرار گیرد.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// نوع استفاده شده توسط `to_bits` و `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// یک جابجایی خام به یک عدد صحیح انجام می دهد.
    fn to_bits(self) -> Self::Bits;

    /// یک جابجایی خام از یک عدد صحیح انجام می دهد.
    fn from_bits(v: Self::Bits) -> Self;

    /// دسته ای را که این تعداد در آن قرار دارد برمی گرداند.
    fn classify(self) -> FpCategory;

    /// مانتیسا ، نماد و علامت را به عنوان اعداد صحیح برمی گرداند.
    fn integer_decode(self) -> (u64, i16, i8);

    /// شناور را رمزگشایی می کند.
    fn unpack(self) -> Unpacked;

    /// از یک عدد صحیح کوچک می توان دقیقاً نمایش داد.
    /// Panic اگر عدد صحیح نمایش داده نشود ، کد دیگر موجود در این ماژول اطمینان می دهد که هرگز چنین اتفاقی نمی افتد.
    fn from_int(x: u64) -> Self;

    /// مقدار 10 <sup>e را</sup> از یک جدول از قبل محاسبه شده بدست می آورد.
    /// Panics برای `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// این اسم چه می گوید
    /// آسان تر بودن کد سخت است از دستکاری ذاتی و امیدواری LLVM تا برابر آن.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // یک محافظه کار با ارقام اعشاری ورودی که نمی تواند سرریز یا صفر یا
    /// فرعیاحتمالاً نماینده اعشار حداکثر مقدار طبیعی ، از این رو نامگذاری شده است.
    const MAX_NORMAL_DIGITS: usize;

    /// وقتی مهمترین رقم اعشاری مقداری بیشتر از این داشته باشد ، قطعاً عدد تا بی نهایت دور می شود.
    ///
    const INF_CUTOFF: i64;

    /// وقتی مهمترین رقم اعشاری مقداری کمتر از این داشته باشد ، قطعاً عدد به صفر می رسد.
    ///
    const ZERO_CUTOFF: i64;

    /// تعداد بیت های نمایانگر.
    const EXP_BITS: u8;

    /// تعداد بیت های مشخص شده ،*از جمله* بیت پنهان.
    const SIG_BITS: u8;

    /// تعداد بیت های مشخص شده ،*به استثنای* بیت پنهان.
    const EXPLICIT_SIG_BITS: u8;

    /// حداکثر نماینده قانونی در نمایندگی کسری.
    const MAX_EXP: i16;

    /// حداقل نماینده قانونی در نمایندگی کسری ، به استثنای موارد غیر طبیعی.
    const MIN_EXP: i16;

    /// `MAX_EXP` برای نمایش انتگرال ، به عنوان مثال ، با تغییر اعمال شده است.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` کدگذاری شده (به عنوان مثال ، با تعصب افست)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` برای نمایش انتگرال ، به عنوان مثال ، با تغییر اعمال شده است.
    const MIN_EXP_INT: i16;

    /// حداکثر مقدار نرمال شده و در نمایش انتگرال.
    const MAX_SIG: u64;

    /// حداقل اهمیت عادی و در نمایش انتگرال.
    const MIN_SIG: u64;
}

// بیشتر راه حل های #34344 است.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// مانتیسا ، نماد و علامت را به عنوان اعداد صحیح برمی گرداند.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // تعصب برجسته + تغییر مانتیسا
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe مطمئن نیست که آیا `as` به درستی در همه سیستم عامل ها گرد می شود یا خیر.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// مانتیسا ، نماد و علامت را به عنوان اعداد صحیح برمی گرداند.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // تعصب برجسته + تغییر مانتیسا
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe مطمئن نیست که آیا `as` به درستی در همه سیستم عامل ها گرد می شود یا خیر.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// `Fp` را به نزدیکترین نوع شناور ماشین تبدیل می کند.
/// نتایج غیر طبیعی را کنترل نمی کند.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 بیتی است ، بنابراین xe دارای تغییر شیفت 63 است
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// علامت 64 بیتی و بیت های T::SIG_BITS را با نصف برابر بچرخانید.
/// سرریز نمایی را کنترل نمی کند.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // شیفت مانتیسا را تنظیم کنید
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// معکوس `RawFloat::unpack()` برای اعداد نرمال شده.
/// Panics اگر نشانگر یا نشانگر برای اعداد نرمال معتبر نباشد.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // بیت مخفی را بردارید
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // نماد را برای تعصب نما و تغییر مانتیسا تنظیم کنید
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // بیت علامت را در 0 ("+") بگذارید ، اعداد ما همه مثبت هستند
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// یک امر غیر عادی را بسازید.مانتیسای 0 مجاز است و صفر می سازد.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // نماد رمزگذاری شده 0 است ، بیت علامت 0 است ، بنابراین ما فقط باید بیت ها را دوباره تفسیر کنیم.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// یک bignum را با Fp تقریبی کنید.درون 0.5 ULP با نیمه تا برابر گرد می شود.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // ما قبل از شاخص `start` همه بیت ها را قطع می کنیم ، یعنی به طور م byثر با مقدار `start` به راست حرکت می کنیم ، بنابراین این همان نمایی است که ما به آن نیاز داریم.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // بسته به بیت های کوتاه شده (half-to-even) را دور بزنید.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// بزرگترین عدد شناور را کاملاً کوچکتر از استدلال می یابد.
/// از زیر نرمال ، زیر صفر یا نماد پایین عبور نمی کند.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// کوچکترین عدد شناور را کاملاً بزرگتر از آرگومان پیدا کنید.
// این عملیات اشباع می شود ، یعنی next_float(inf) ==inf.
// برخلاف اکثر کدهای موجود در این ماژول ، این عملکرد صفر ، غیرعادی و بی نهایت را کنترل می کند.
// با این حال ، مانند همه کد های دیگر در اینجا ، با NaN و اعداد منفی سروکار ندارد.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // به نظر می رسد این خیلی خوب است اما درست است.
        // 0.0 به عنوان کلمه صفر رمزگذاری شده است.عادی های فرعی 0x000 متر ... متر هستند که متر mantissa است.
        // به طور خاص ، کوچکترین حالت عادی 0x0 ... 01 و بزرگترین 0x000F ... F است.
        // کمترین عدد طبیعی 0x0010 ... 0 است ، بنابراین این مورد گوشه ای نیز کار می کند.
        // اگر این افزایش از مانتیسا سرریز شود ، بیت حمل همانطور که می خواهیم نمایانگر را افزایش می دهد و بیت های مانتیسا صفر می شوند.
        // به دلیل کنوانسیون بیت پنهان ، این نیز دقیقاً همان چیزی است که ما می خواهیم!
        // سرانجام ، f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}