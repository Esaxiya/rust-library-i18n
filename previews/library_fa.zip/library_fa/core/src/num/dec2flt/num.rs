//! توابع کمکی برای bignums که منطقی نیست که به روش تبدیل شوند.

// FIXME نام این ماژول کمی تأسف آور است ، زیرا ماژول های دیگر نیز `core::num` را وارد می کنند.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// آزمایش کنید که آیا کوتاه کردن همه بیت های کمتر از `ones_place` خطای نسبی کمتر ، برابر یا بزرگتر از 0.5 ULP را ایجاد می کند.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // اگر تمام بیت های باقیمانده صفر باشد ، این= 0.5 ULP است ، در غیر این صورت> 0.5 اگر دیگر بیت وجود ندارد (half_bit==0) ، زیر نیز به درستی برابر می آورد.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// یک رشته ASCII که فقط شامل رقم اعشار است به `u64` تبدیل می کند.
///
/// بررسی کاراکترهای سرریز یا نامعتبر را انجام نمی دهد ، بنابراین اگر تماس گیرنده مراقب نباشد ، نتیجه جعلی است و می تواند panic باشد (اگرچه `unsafe` نخواهد بود).
/// علاوه بر این ، رشته های خالی به عنوان صفر رفتار می شوند.
/// این تابع وجود دارد زیرا
///
/// 1. استفاده از `FromStr` در `&[u8]` به `from_utf8_unchecked` نیاز دارد ، که بد است ، و
/// 2. جمع کردن نتایج `integral.parse()` و `fractional.parse()` پیچیده تر از کل عملکرد است.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// رشته ای از ارقام ASCII را به یک bignum تبدیل می کند.
///
/// مانند `from_str_unchecked` ، این عملکرد برای از بین بردن رقم های غیر رقمی به تجزیه کننده متکی است.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// bignum را به یک عدد صحیح 64 بیتی باز کنید.Panics اگر تعداد آنها خیلی زیاد باشد.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// محدوده ای از بیت ها را استخراج می کند.

/// شاخص 0 کمترین بیت است و دامنه آن به طور معمول نیمه باز است.
/// Panics در صورت درخواست برای استخراج بیت های بیشتر از تناسب در نوع بازگشت.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}