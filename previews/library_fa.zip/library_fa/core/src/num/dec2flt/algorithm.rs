//! الگوریتم های مختلف مقاله.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// تعداد بیت های قابل توجه و در Fp
const P: u32 = 64;

// ما به راحتی بهترین تقریب را برای *همه* نمایانان ذخیره می کنیم ، بنابراین می توان متغیر "h" و شرایط مرتبط را حذف کرد.
// این عملکرد برای یک کیلو بایت فضا را معامله می کند.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// در بیشتر معماری ها ، عملیات نقطه شناور دارای اندازه بیتی مشخص است ، بنابراین دقت محاسبه بر اساس هر عمل تعیین می شود.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// در صورتی که پسوندهای SSE/SSE2 در دسترس نباشند ، در x86 ، x87 FPU برای عملیات شناور استفاده می شود.
// x87 FPU به طور پیش فرض با 80 بیت دقیق کار می کند ، این بدان معناست که عملیات به 80 بیت تبدیل می شود و باعث گرد شدن دو برابر می شود که در نهایت مقادیر نشان داده شوند
//
// 32/64 مقادیر شناور bit.برای غلبه بر این ، می توان کلمه کنترل FPU را تنظیم کرد تا محاسبات با دقت دلخواه انجام شود.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// ساختاری که برای حفظ مقدار اصلی کلمه کنترل FPU استفاده می شود ، بنابراین در هنگام افت ساختار می توان آن را بازیابی کرد.
    ///
    ///
    /// x87 FPU یک ثبت 16 بیتی است که قسمت های آن به شرح زیر است:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// اسناد و مدارک مربوط به همه زمینه ها در کتابچه راهنمای توسعه دهنده نرم افزار IA-32 Architectures (جلد 1) موجود است.
    ///
    /// تنها فیلدی که برای کد زیر مرتبط است ، PC ، کنترل دقیق است.
    /// این قسمت دقت عملیات انجام شده توسط FPU را تعیین می کند.
    /// می توان آن را به صورت زیر تنظیم کرد:
    ///  - 0b00 ، تک دقت یعنی 32 بیت
    ///  - 0b10 ، دقت دو برابر ، یعنی 64 بیت
    ///  - 0b11 ، دقت دو برابر بزرگتر یعنی 80 بیت (حالت پیش فرض) مقدار 0b01 محفوظ است و نباید استفاده شود.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // ایمنی: دستورالعمل `fldcw` بررسی شده است تا بتواند به درستی با آن کار کند
        // هر `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: ما برای پشتیبانی از LLVM 8 و LLVM 9 از نحو ATT استفاده می کنیم.
                options(att_syntax, nostack),
            )
        }
    }

    /// قسمت دقیق FPU را روی `T` تنظیم می کند و `FPUControlWord` را برمی گرداند.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // مقداری را برای قسمت کنترل دقیق که برای `T` مناسب است محاسبه کنید.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 بیت
            8 => 0x0200, // 64 بیت
            _ => 0x0300, // پیش فرض ، 80 بیت
        };

        // مقدار اصلی کلمه کنترل را بدست آورید تا بعداً آن را بازیابی کنید ، وقتی ساختار `FPUControlWord` از بین رفت ایمنی: دستورالعمل `fnstcw` بررسی شده است تا بتواند به درستی با هر `u16` کار کند
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: ما برای پشتیبانی از LLVM 8 و LLVM 9 از نحو ATT استفاده می کنیم.
                options(att_syntax, nostack),
            )
        }

        // کلمه کنترل را به دقت دلخواه تنظیم کنید.
        // این امر با پوشاندن دقت قدیمی (بیت های 8 و 9 ، 0x300) و جایگزینی آن با پرچم دقیق محاسبه شده در بالا ، حاصل می شود.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// مسیر سریع Bellerophon با استفاده از عدد صحیح و شناورهای اندازه ماشین.
///
/// این کار به یک تابع جداگانه استخراج می شود تا قبل از ساخت bignum بتوان آن را امتحان کرد.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // ما مقدار دقیق را با MAX_SIG نزدیک به پایان مقایسه می کنیم ، این فقط یک رد سریع و ارزان است (و همچنین بقیه کد را از نگرانی در مورد کمبود جریان آزاد می کند).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // مسیر سریع بسیار مهم است به محاسبه محاسبه به تعداد صحیح بیت ها و بدون هیچ گردی متوسط.
    // در x86 (بدون SSE یا SSE2) این نیاز به تغییر دقت پشته x87 FPU دارد تا مستقیماً به بیت 64/32 تبدیل شود.
    // عملکرد `set_precision` برای تعیین دقت در معماری هایی که نیاز به تنظیم آن دارند با تغییر وضعیت جهانی (مانند کلمه کنترل x87 FPU) مراقبت می کند.
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // مورد e <0 را نمی توان در branch دیگر قرار داد.
    // قدرت های منفی منجر به تکرار یک بخش کسری در باینری می شوند ، که گرد می شوند ، که باعث ایجاد خطاهای واقعی (و گهگاه کاملاً قابل توجه!) در نتیجه نهایی می شود.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// الگوریتم Bellerophon کد پیش پا افتاده ای است که با تجزیه و تحلیل عددی غیر پیش پا افتاده توجیه می شود.
///
/// "f" را به یک شناور با 64 بیت نشان می دهد و آن را با بهترین تقریب `10^e` (در همان قالب نقطه شناور) ضرب می کند.این اغلب برای گرفتن نتیجه صحیح کافی است.
/// با این حال ، هنگامی که نتیجه نزدیک به نیمه راه بین دو شناور (ordinary) مجاور است ، خطای گرد ترکیب از ضرب دو تقریب به این معنی است که نتیجه ممکن است در چند بیت خاموش باشد.
/// وقتی این اتفاق می افتد ، الگوریتم تکراری R مشکلات را برطرف می کند.
///
/// "close to halfway" موج دار دستی با استفاده از تجزیه و تحلیل عددی در مقاله دقیق ساخته شده است.
/// به قول کلینگر:
///
/// > شیب ، که به واحد کمترین بیت بیان می شود ، محدودیتی برای خطا است
/// > در هنگام محاسبه نقطه شناور از تقریب به f * 10 ^ e جمع شده است.(شیب است
/// > محدودیتی برای خطای واقعی نیست ، اما تفاوت بین تقریب z و
/// > بهترین تقریب ممکن که از بیت های معنی دار استفاده می کند.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // موارد abs(e) <log5(2^N) در fast_path() است
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // آیا شیب آنقدر بزرگ است که بتواند هنگام گرد کردن به n بیت تغییر کند؟
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// یک الگوریتم تکراری که تقریب نقطه شناور `f * 10^e` را بهبود می بخشد.
///
/// هر تکرار در آخرین مکان یک واحد نزدیکتر می شود ، که اگر `z0` حتی خفیف باشد همگرایی بسیار طولانی طول می کشد.
/// خوشبختانه ، هنگامی که به عنوان روش بازگشتی برای Bellerophon استفاده می شود ، تقریب شروع حداکثر با یک ULP خاموش است.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // اعداد صحیح مثبت `x`، `y` را پیدا کنید به طوری که `x / y` دقیقاً `(f *10^e) / (m* 2^k)` باشد.
        // این نه تنها از پرداختن به علائم `e` و `k` جلوگیری می کند ، بلکه قدرت دو مشترک `10^e` و `2^k` را نیز برای کوچکتر کردن اعداد از بین می بریم.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // این کمی ناجور نوشته شده است زیرا bignums ما از اعداد منفی پشتیبانی نمی کند ، بنابراین ما از اطلاعات مطلق + مقدار مطلق استفاده می کنیم.
        // ضرب با m_digits نمی تواند سرریز شود.
        // اگر `x` یا `y` به اندازه کافی بزرگ هستند که باید نگران سرریز شدن آب باشیم ، آن ها نیز به اندازه کافی بزرگ هستند که `make_ratio` کسری را با ضریب 2 ^ 64 یا بیشتر کاهش داده است.
        //
        //
        let (d2, d_negative) = if x >= y {
            // دیگر به x نیازی ندارید ، clone() را ذخیره کنید.
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // هنوز به y نیاز دارید ، کپی کنید.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// با توجه به `x = f` و `y = m` که `f` به طور معمول ارقام اعشاری ورودی را نشان می دهد و `m` اهمیت تقریب نقطه شناور است ، نسبت `x / y` را برابر با `(f *10^e) / (m* 2^k)` کنید ، احتمالاً با دو قدرت مشترک هر دو کاهش می یابد.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e ، y=m* 2 ^ k ، با این تفاوت که کسر را با مقداری قدرت دو کاهش می دهیم.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k)، y=m این نمی تواند سرریز کند زیرا به `e` مثبت و `k` منفی احتیاج دارد که این فقط برای مقادیر بسیار نزدیک به 1 اتفاق می افتد ، به این معنی که `e` و `k` نسبتاً کوچک خواهند بود.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f، y=m *10^abs(e)* 2 ^ k این هم نمی تواند سرریز شود ، به بالا مراجعه کنید.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k) ، y=m* 10^abs(e) ، دوباره با قدرت مشترک دو برابر کاهش می یابد.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// از نظر مفهومی ، الگوریتم M ساده ترین راه برای تبدیل اعشار به شناور است.
///
/// ما نسبتی را تشکیل می دهیم که برابر با `f * 10^e` باشد ، سپس قدرت های دو را پرتاب می کنیم تا وقتی که یک معنی شناور معتبر بدست آورد.
/// نماگر باینری `k` تعداد دفعاتی است که ما عدد یا مخرج را بر دو ضرب می کنیم ، یعنی در هر زمان `f *10^e` برابر با `(u / v)* 2^k` است.
/// هنگامی که ما از اهمیت و اهمیت مطلع شدیم ، فقط باید با بازرسی از باقیمانده تقسیم ، که در توابع کمکی در زیر انجام می شود ، دور بزنیم.
///
///
/// این الگوریتم حتی با بهینه سازی توصیف شده در `quick_start()` بسیار کند است.
/// با این حال ، این ساده ترین الگوریتم برای سازگاری با نتایج سرریز ، کم شدن جریان و غیرعادی است.
/// هنگامی که Bellerophon و Algorithm R بیش از حد تحت فشار قرار می گیرند ، این پیاده سازی انجام می شود.
/// تشخیص کمبود جریان و سرریز آسان است: این نسبت هنوز در محدوده مهم نیست و با این وجود توان minimum/maximum به دست آمده است.
/// در صورت سرریز ، ما به راحتی بی نهایت را برمی گردانیم.
///
/// دست زدن به زیر سطح و زیر نرمال پیچیده تر است.
/// یک مشکل بزرگ این است که ، با حداقل میزان بیان ، نسبت ممکن است برای یک علامت خیلی زیاد باشد.
/// برای جزئیات بیشتر به underflow() مراجعه کنید.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // بهینه سازی احتمالی FIXME: big_to_fp را تعمیم دهید تا بتوانیم معادل fp_to_float(big_to_fp(u)) را در اینجا انجام دهیم ، فقط بدون گرد کردن دو برابر.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // اگر تا `k < T::MIN_EXP_INT` منتظر بمانیم ، باید در کمترین میزان متوقف شویم ، با دو برابر ضعف مواجه خواهیم شد.
            // متأسفانه این بدان معناست که ما باید اعداد عادی را با حداقل برجسته خاص کنیم.
            // FIXME فرمول زیباتر پیدا می کند ، اما برای اطمینان از صحت آن تست `tiny-pow10` را اجرا کنید!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// با بررسی طول بیت از بیشتر تکرارهای الگوریتم M عبور می کند.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // طول بیت برآورد لگاریتم پایه دو و log(u / v) = log(u) ، log(v) است.
    // تخمین حداکثر تا 1 خاموش است ، اما همیشه یک تخمین کم است ، بنابراین خطاهای log(u) و log(v) یک نشانه دارند و لغو می شوند (اگر هر دو بزرگ باشند).
    // بنابراین خطای log(u / v) نیز حداکثر یکی است.
    // نسبت هدف نسبتي است كه u/v در محدوده معني دار باشد.بنابراین شرط خاتمه ما log2(u / v) بیت های مهم و plus/minus است.
    // FIXME نگاهی به بیت دوم می تواند تخمین را بهبود بخشد و از برخی تقسیمات دیگر جلوگیری کند.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // کم جریان یا غیر عادی.آن را به عملکرد اصلی بسپارید.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // سرریز.آن را به عملکرد اصلی بسپارید.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // نسبت دارای اهمیت در محدوده نیست و حداقل توان آن را نشان می دهد ، بنابراین ما باید بیت های اضافی را گرد کرده و توان را بر این اساس تنظیم کنیم.
    // ارزش واقعی اکنون به این شکل است:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q تنه(به نمایندگی از Rem)
    //
    // بنابراین ، وقتی بیت های گرد شده!= 0.5 ULP باشند ، آنها گردی را خودشان تعیین می کنند.
    // هنگامی که برابر باشند و باقیمانده غیر صفر باشد ، مقدار هنوز باید گرد شود.
    // فقط وقتی بیت های گرد شده 1/2 باشند و باقیمانده صفر باشد ، ما یک وضعیت نیم به یک خواهیم داشت.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// گرد به هم معمول ، با توجه به باقی مانده یک تقسیم ، گیج می شود.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}