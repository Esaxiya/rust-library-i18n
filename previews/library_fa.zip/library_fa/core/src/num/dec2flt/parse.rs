//! تأیید و تجزیه یک رشته اعشاری از فرم:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! به عبارت دیگر ، نحو استاندارد شناور ، با دو استثنا: بدون علامت و بدون دست زدن به "inf" و "NaN".اینها توسط عملکرد درایور (super::dec2flt) اداره می شوند.
//!
//! اگرچه شناسایی ورودی های معتبر نسبتاً آسان است ، این ماژول همچنین مجبور است تغییرات بی اعتبار بی شماری را رد کند ، هرگز panic ، و بررسی های بیشماری را انجام دهد که سایر ماژول ها به نوبه خود به panic اعتماد ندارند (یا سرریز می شود).
//!
//! برای بدتر کردن شرایط ، همه آنچه در یک عبور از ورودی اتفاق می افتد.
//! بنابراین ، هنگام تغییر هر چیزی مراقب باشید ، و با ماژول های دیگر دوباره بررسی کنید.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// قسمتهای جالب یک رشته اعشاری.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// ضریب اعشار ، تضمین شده است که کمتر از 18 رقم اعشار دارد.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// بررسی می کند که آیا رشته ورودی یک شماره شناور معتبر است یا خیر و در این صورت ، قسمت انتگرال ، قسمت کسری و نمایان را در آن قرار دهید.
/// علائم را کنترل نمی کند.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // بدون رقم قبل از 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // ما قبل یا بعد از نقطه حداقل به یک رقم نیاز داریم.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // دنباله های ناخواسته بعد از قسمت کسری
            }
        }
        _ => Invalid, // دنباله های ناخواسته پس از رشته اول رقم
    }
}

/// رقم اعشار را تا اولین نویسه غیر رقمی از بین می برد.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// استخراج و بررسی خطا.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ناخواسته دنباله دار پس از برجسته
    }
    if number.is_empty() {
        return Invalid; // نماینده خالی
    }
    // در این مرحله ، مطمئناً یک رشته رقم معتبر داریم.ممکن است قرار دادن `i64` خیلی طولانی باشد ، اما اگر اینقدر عظیم باشد ، ورودی مطمئناً صفر یا بی نهایت است.
    // از آنجایی که هر صفر در رقم اعشار فقط نمایان را با 1/+ تنظیم می کند ، در exp=10 ^ 18 ورودی باید 17 exabyte (!) صفر باشد تا حتی از راه دور به محدود بودن نزدیک شود.
    //
    // این دقیقاً مورد مورد استفاده ما نیست که ما به آن نیاز داشته باشیم.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}