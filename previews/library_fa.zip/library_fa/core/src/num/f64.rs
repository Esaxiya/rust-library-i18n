//! ثابت های مخصوص نوع شناور با دقت دو برابر `f64`.
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! اعداد قابل توجه از نظر ریاضی در زیر ماژول `consts` ارائه شده است.
//!
//! برای ثابتهایی که مستقیماً در این ماژول تعریف شده اند (همانطور که از آنچه در زیر ماژول `consts` تعریف شده اند) ، کد جدید باید در عوض از ثابتهای مرتبط تعریف شده مستقیماً روی نوع `f64` استفاده کند.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// شعاع یا پایه نمایش داخلی `f64`.
/// به جای آن از [`f64::RADIX`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // راه در نظر گرفته شده
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// تعداد ارقام قابل توجه در پایه 2.
/// به جای آن از [`f64::MANTISSA_DIGITS`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // راه در نظر گرفته شده
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// تعداد تقریبی ارقام قابل توجه در پایه 10.
/// به جای آن از [`f64::DIGITS`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // راه در نظر گرفته شده
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] مقدار برای `f64`.
/// به جای آن از [`f64::EPSILON`] استفاده کنید.
///
/// این تفاوت بین `1.0` و عدد بعدی بزرگتر است.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // راه در نظر گرفته شده
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// کوچکترین مقدار محدود `f64`.
/// به جای آن از [`f64::MIN`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // راه در نظر گرفته شده
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// کوچکترین مقدار مثبت طبیعی `f64`.
/// به جای آن از [`f64::MIN_POSITIVE`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // راه در نظر گرفته شده
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// بزرگترین مقدار محدود `f64`.
/// به جای آن از [`f64::MAX`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // راه در نظر گرفته شده
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// یک بزرگتر از حداقل توان طبیعی 2 نمایی.
/// به جای آن از [`f64::MIN_EXP`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // راه در نظر گرفته شده
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// حداکثر توان ممکن 2 نماد.
/// به جای آن از [`f64::MAX_EXP`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // راه در نظر گرفته شده
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// حداقل توان طبیعی 10 نمایی ممکن.
/// به جای آن از [`f64::MIN_10_EXP`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // راه در نظر گرفته شده
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// حداکثر توان ممکن 10 توان
/// به جای آن از [`f64::MAX_10_EXP`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // راه در نظر گرفته شده
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// شماره (NaN) نیست.
/// به جای آن از [`f64::NAN`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // راه در نظر گرفته شده
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// Infinity (∞).
/// به جای آن از [`f64::INFINITY`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // راه در نظر گرفته شده
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// بی نهایت منفی (−∞).
/// به جای آن از [`f64::NEG_INFINITY`] استفاده کنید.
///
/// # Examples
///
/// ```rust
/// // راه منسوخ
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // راه در نظر گرفته شده
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// ثابت های پایه ریاضی.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: با ثبات ریاضی از cmath جایگزین کنید.

    /// Archimedes (π) ثابت
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// ثابت دایره کامل (τ)
    ///
    /// برابر با 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// شماره اولر (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// شعاع یا پایه نمایش داخلی `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// تعداد ارقام قابل توجه در پایه 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// تعداد تقریبی ارقام قابل توجه در پایه 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] مقدار برای `f64`.
    ///
    /// این تفاوت بین `1.0` و عدد بعدی بزرگتر است.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// کوچکترین مقدار محدود `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// کوچکترین مقدار مثبت طبیعی `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// بزرگترین مقدار محدود `f64`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// یک بزرگتر از حداقل توان طبیعی 2 نمایی.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// حداکثر توان ممکن 2 نماد.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// حداقل توان طبیعی 10 نمایی ممکن.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// حداکثر توان ممکن 10 توان
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// شماره (NaN) نیست.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// بی نهایت منفی (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// اگر این مقدار `NaN` باشد `true` را برمی گرداند.
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` به دلیل نگرانی در مورد قابلیت حمل به طور عمومی در libcore در دسترس نیست ، بنابراین این پیاده سازی برای استفاده داخلی است.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// `true` را برمی گرداند اگر این مقدار بی نهایت مثبت یا منفی باشد و در غیر این صورت `false` است.
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// `true` را برمی گرداند اگر این عدد نه بی نهایت باشد و نه `NaN`.
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // نیازی به اداره جداگانه NaN نیست: اگر خود NaN باشد ، مقایسه درست نیست ، دقیقاً همانطور که می خواهیم.
        //
        self.abs_private() < Self::INFINITY
    }

    /// اگر شماره [subnormal] باشد `true` را برمی گرداند.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // مقادیر بین `0` و `min` غیر عادی هستند.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// اگر عدد صفر ، بی نهایت ، [subnormal] یا `NaN` نباشد ، `true` را برمی گرداند.
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // مقادیر بین `0` و `min` غیر عادی هستند.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// دسته نقطه شناور عدد را برمی گرداند.
    /// اگر قرار است فقط یک خاصیت مورد آزمایش قرار گیرد ، معمولاً استفاده از محمول خاص در عوض سریعتر است.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// اگر `self` دارای علامت مثبت باشد ، `true` را برمی گرداند ، از جمله `+0.0` ، `NaN` با بیت علامت مثبت و بی نهایت مثبت.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// اگر `self` علامت منفی داشته باشد ، `true` را برمی گرداند ، از جمله `-0.0` ، `NaN` با بیت علامت منفی و بی نهایت منفی.
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// (inverse) متقابل یک عدد را می گیرد ، `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// رادیان را به درجه تبدیل می کند.
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // تقسیم در اینجا با توجه به مقدار واقعی 180/π به درستی گرد می شود.
        // (این با f32 متفاوت است ، جایی که برای اطمینان از یک نتیجه صحیح گرد باید از یک ثابت استفاده کرد.)
        //
        self * (180.0f64 / consts::PI)
    }

    /// درجات را به رادیان تبدیل می کند.
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// حداکثر دو عدد را برمی گرداند.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// اگر یکی از استدلال ها NaN باشد ، استدلال دیگر برمی گردد.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// حداقل دو عدد را برمی گرداند.
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// اگر یکی از استدلال ها NaN باشد ، استدلال دیگر برمی گردد.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// به سمت صفر می چرخد و به هر نوع عدد صحیح بدوی تبدیل می شود ، با این فرض که مقدار محدود باشد و در آن نوع متناسب باشد.
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// مقدار باید:
    ///
    /// * `NaN` نباش
    /// * بی نهایت نباشد
    /// * پس از برش بخش کسری آن ، در نوع برگشت `Int` نمایندگی داشته باشید
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `FloatToInt::to_int_unchecked` را رعایت کند.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// تغییر شکل خام به `u64`.
    ///
    /// این در حال حاضر در تمام سیستم عامل ها با `transmute::<f64, u64>(self)` یکسان است.
    ///
    /// برای بحث در مورد قابلیت حمل این عملیات به `from_bits` مراجعه کنید (تقریباً هیچ مشکلی وجود ندارد).
    ///
    /// توجه داشته باشید که این عملکرد از ریخته گری `as` متمایز است ، که تلاش می کند مقدار *عددی* و نه مقدار بیتی را حفظ کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() ریخته گری نیست!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // ایمنی: `u64` یک نوع داده ساده و قدیمی است بنابراین ما همیشه می توانیم از آن استفاده کنیم
        unsafe { mem::transmute(self) }
    }

    /// تغییر شکل خام از `u64`.
    ///
    /// این در حال حاضر در تمام سیستم عامل ها با `transmute::<u64, f64>(v)` یکسان است.
    /// معلوم می شود که این به دو دلیل قابل حمل است:
    ///
    /// * شناورها و Ints ها در همه سیستم عامل های پشتیبانی شده پایان یکسانی دارند.
    /// * IEEE-754 به طور دقیق طرح بیت شناورها را مشخص می کند.
    ///
    /// اما یک نکته مهم وجود دارد: قبل از نسخه 2008 IEEE-754 ، نحوه تفسیر بیت سیگنالینگ NaN در واقع مشخص نشده است.
    /// اکثر سیستم عامل ها (به ویژه x86 و ARM) تفسیری را انتخاب کردند که در نهایت در سال 2008 استاندارد شد ، اما برخی دیگر (به ویژه MIPS) این کار را نکردند.
    /// در نتیجه ، همه NaN های سیگنالینگ در MIPS NaN های ساکت در x86 هستند و بالعکس.
    ///
    /// این پیاده سازی به جای تلاش برای حفظ کراس پلتفرم سیگنالینگ ، حفظ دقیق بیت ها است.
    /// این بدان معنی است که هر بار بارگذاری شده در NaN ها حتی اگر نتیجه این روش از طریق دستگاه x86 به دستگاه MIPS از طریق شبکه ارسال شود ، حفظ خواهد شد.
    ///
    ///
    /// اگر نتایج این روش فقط با همان معماری تولید شده دستکاری شود ، دیگر هیچ نگرانی برای قابلیت حمل وجود ندارد.
    ///
    /// اگر ورودی NaN نباشد ، هیچ جای نگرانی برای قابلیت حمل وجود ندارد.
    ///
    /// اگر به اهمیت سیگنالینگ اهمیت نمی دهید (به احتمال زیاد) ، هیچ جای نگرانی برای قابلیت حمل وجود ندارد.
    ///
    /// توجه داشته باشید که این عملکرد از ریخته گری `as` متمایز است ، که تلاش می کند مقدار *عددی* و نه مقدار بیتی را حفظ کند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // ایمنی: `u64` یک نوع داده ساده و قدیمی است بنابراین ما همیشه می توانیم از آن جا به جا شویم
        // به نظر می رسد که مشکلات ایمنی sNaN بیش از حد سرریز شده است!هورا!
        unsafe { mem::transmute(v) }
    }

    /// نمایش حافظه این شماره نقطه شناور را به صورت آرایه بایت به ترتیب بایت big-endian (network) برگردانید.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// نمایش حافظه این شماره نقطه شناور را به صورت آرایه بایت به ترتیب بایت اندین اندک برگردانید.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// نمایش حافظه این شماره نقطه شناور را به صورت آرایه بایت به ترتیب بایت بومی برگردانید.
    ///
    /// همانطور که از پایان پذیری بومی پلت فرم هدف استفاده می شود ، به جای آن ، کد قابل حمل باید از [`to_be_bytes`] یا [`to_le_bytes`] استفاده کند.
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// نمایش حافظه این شماره نقطه شناور را به صورت آرایه بایت به ترتیب بایت بومی برگردانید.
    ///
    ///
    /// [`to_ne_bytes`] هر زمان ممکن باشد باید بر این امر ترجیح داده شود.
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // ایمنی: `f64` یک نوع داده ساده و قدیمی است بنابراین ما همیشه می توانیم از آن استفاده کنیم
        unsafe { &*(self as *const Self as *const _) }
    }

    /// مقدار نمای شناور را از نمایش آن به عنوان آرایه بایت در endian بزرگ ایجاد کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// مقدار نمای شناور را از نمایش آن به عنوان یک آرایه بایت در اندیان کوچک ایجاد کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// یک مقدار نقطه شناور از نمایش آن به عنوان یک آرایه بایت در endian بومی ایجاد کنید.
    ///
    /// همانطور که از پایان پذیری بومی پلتفرم هدف استفاده می شود ، کد قابل حمل به احتمال زیاد می خواهد از [`from_be_bytes`] یا [`from_le_bytes`] استفاده کند ، در صورت جایگزینی.
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// ترتیب بین خود و سایر ارزش ها را برمی گرداند.
    /// بر خلاف مقایسه جزئی استاندارد بین اعداد شناور ، این مقایسه همیشه یک نظم مطابق با گزاره totalOrder ارائه می دهد ، همانطور که در استاندارد نقطه شناور IEEE 754 (ویرایش 2008) تعریف شده است.
    /// مقادیر به ترتیب زیر مرتب می شوند:
    /// - منفی NaN ساکت
    /// - سیگنالینگ منفی NaN
    /// - بی نهایت منفی
    /// - اعداد منفی
    /// - اعداد غیر طبیعی منفی
    /// - صفر منفی
    /// - صفر مثبت
    /// - اعداد مثبت غیر عادی
    /// - اعداد مثبت
    /// - بی نهایت مثبت
    /// - سیگنالینگ مثبت NaN
    /// - مثبت NaN
    ///
    /// توجه داشته باشید که این عملکرد همیشه با پیاده سازی [`PartialOrd`] و [`PartialEq`] `f64` موافق نیست.به طور خاص ، آنها صفر منفی و مثبت را برابر می دانند ، در حالی که `total_cmp` اینگونه نیست.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // در صورت منفی ، بیت ها را بجز علامت بچرخانید تا به یک طرح مشابه به عنوان عدد صحیح مکمل دو دست پیدا کنید
        //
        // چرا این کار می کند؟شناورهای IEEE 754 از سه زمینه تشکیل شده اند:
        // بیت ، نماد و مانتیسا را امضا کنید.مجموعه ای از زمینه های نماد و مانتیسا به طور کلی دارای این ویژگی هستند که ترتیب بیت آنها برابر است با مقدار عددی که در آن مقدار تعریف شده است.
        // مقدار به طور معمول بر روی مقادیر NaN تعریف نمی شود ، اما IEEE 754 totalOrder مقادیر NaN را نیز برای دنبال کردن ترتیب بیت تعریف می کند.این منجر به نظم توضیح داده شده در نظر سند می شود.
        // با این حال ، نمایش مقدار برای اعداد منفی و مثبت یکسان است-فقط بیت علامت متفاوت است.
        // برای مقایسه ساده شناورها به عنوان عدد صحیح امضا شده ، باید بیت های نمایشگر و مانتیسا را در صورت عدد منفی تلنگر کنیم.
        // ما به طور موثر اعداد را به فرم "two's complement" تبدیل می کنیم.
        //
        // برای انجام ورق زدن ، یک ماسک و XOR در برابر آن می سازیم.
        // ما یک ماسک "all-ones except for the sign bit" را بدون مقادیر از مقادیر با علامت منفی محاسبه می کنیم: علامت جابجایی سمت راست ، عدد صحیح را گسترش می دهد ، بنابراین ما ماسک را با بیت های نشانه "fill" می کنیم و سپس به غیر امضا تبدیل می کنیم تا یک بیت صفر دیگر فشار دهیم.
        //
        // در مورد مقادیر مثبت ، ماسک همه صفر است ، بنابراین ممنوع است.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// یک مقدار را به یک بازه خاص محدود کنید مگر اینکه NaN باشد.
    ///
    /// اگر `self` بزرگتر از `max` باشد `max` و اگر `self` کمتر از `min` باشد `min` برمی گرداند.
    /// در غیر این صورت این `self` را برمی گرداند.
    ///
    /// توجه داشته باشید که اگر مقدار اولیه NaN نیز باشد ، این تابع NaN را برمی گرداند.
    ///
    /// # Panics
    ///
    /// Panics اگر `min > max` ، `min` NaN یا `max` NaN باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}