//! انواع خطا برای تبدیل به انواع انتگرال.

use crate::convert::Infallible;
use crate::fmt;

/// وقتی یک نوع نوع انتگرال بررسی نشده از کار افتاد ، نوع خطا برمی گردد.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // به جای اجبار مطابقت داشته باشید تا مطمئن شوید کدی مانند `From<Infallible> for TryFromIntError` در بالا هنگامی که `Infallible` نام مستعار `!` می شود ، ادامه خواهد یافت.
        //
        //
        match never {}
    }
}

/// خطایی که هنگام تجزیه یک عدد صحیح قابل بازگشت است.
///
/// این خطا به عنوان نوع خطا برای توابع `from_str_radix()` در انواع صحیح بدوی ، مانند [`i8::from_str_radix`] استفاده می شود.
///
/// # علل بالقوه
///
/// از جمله دلایل دیگر ، `ParseIntError` می تواند به دلیل وجود فضای خالی یا پیشرو بودن فضای خالی در رشته پرتاب شود ، به عنوان مثال وقتی از ورودی استاندارد بدست می آید.
///
/// استفاده از روش [`str::trim()`] تضمین می کند که قبل از تجزیه فضای خالی وجود ندارد.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum برای ذخیره انواع مختلف خطاها که می تواند باعث تجزیه یک عدد صحیح شود ، ذخیره می شود.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// ارزش تجزیه شده خالی است.
    ///
    /// از دیگر دلایل ، این نوع در هنگام تجزیه یک رشته خالی ساخته خواهد شد.
    Empty,
    /// شامل یک رقم نامعتبر در متن آن است.
    ///
    /// از میان دلایل دیگر ، این نوع در هنگام تجزیه رشته ای که حاوی یک کاراکتر غیر ASCII است ساخته می شود.
    ///
    /// این نوع همچنین زمانی ساخته می شود که `+` یا `-` در یک رشته به صورت خود به خود یا در وسط یک عدد قرار نگیرد.
    ///
    ///
    InvalidDigit,
    /// عدد صحیح برای ذخیره در نوع عدد صحیح خیلی بزرگ است.
    PosOverflow,
    /// عدد صحیح برای ذخیره در نوع عدد صحیح بسیار کوچک است.
    NegOverflow,
    /// ارزش صفر بود
    ///
    /// این نوع هنگامی منتشر می شود که رشته تجزیه مقدار صفر داشته باشد ، که این برای انواع غیر صفر غیرقانونی است.
    ///
    Zero,
}

impl ParseIntError {
    /// علت جزئی تجزیه یک عدد صحیح را صادر می کند.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}