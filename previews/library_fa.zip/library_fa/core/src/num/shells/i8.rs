//! ثابت هایی برای نوع عدد صحیح 8 بیتی امضا شده.
//!
//! *[See also the `i8` primitive type][i8].*
//!
//! کد جدید باید ثابتهای مرتبط را مستقیماً روی نوع اولیه استفاده کند.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i8`"
)]

int_module! { i8 }