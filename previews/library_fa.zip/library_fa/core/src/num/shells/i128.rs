//! ثابت برای نوع عدد صحیح امضا شده 128 بیتی.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! کد جدید باید ثابتهای مرتبط را مستقیماً روی نوع اولیه استفاده کند.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }