//! ثابت برای نوع عدد صحیح بدون بیت 8 بیتی.
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! کد جدید باید ثابتهای مرتبط را مستقیماً روی نوع اولیه استفاده کند.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }