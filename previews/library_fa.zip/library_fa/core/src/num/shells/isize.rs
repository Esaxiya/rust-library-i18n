//! ثابت برای نوع عدد صحیح امضا شده به اندازه اشاره گر.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! کد جدید باید ثابتهای مرتبط را مستقیماً روی نوع اولیه استفاده کند.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }