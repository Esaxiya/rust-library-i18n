#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` به پیاده ساز یک مجری کار اجازه می دهد تا [`Waker`] ایجاد کند که رفتار بیداری سفارشی را فراهم می کند.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// این شامل یک اشاره گر داده و [virtual function pointer table (vtable)][vtable] است که رفتار `RawWaker` را به صورت سفارشی تنظیم می کند.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// یک نشانگر داده ، که می تواند برای ذخیره داده های دلخواه طبق نیاز اجرا کننده مورد استفاده قرار گیرد.
    /// این می تواند به عنوان مثال باشد
    /// یک نشانگر پاک شده نوع به `Arc` که با این کار مرتبط است.
    /// مقدار این قسمت به عنوان اولین پارامتر به کلیه توابع که بخشی از vtable هستند منتقل می شود.
    ///
    data: *const (),
    /// جدول اشاره گر عملکرد مجازی که رفتار این بیدار را سفارشی می کند.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// `RawWaker` جدید را از نشانگر `data` و `vtable` ایجاد می کند.
    ///
    /// از نشانگر `data` می توان برای ذخیره داده های دلخواه طبق نیاز اجرا کننده استفاده کرد.این می تواند به عنوان مثال باشد
    /// یک نشانگر پاک شده نوع به `Arc` که با این کار مرتبط است.
    /// مقدار این نشانگر به عنوان اولین پارامتر به تمام عملکردهایی که بخشی از `vtable` هستند منتقل می شود.
    ///
    /// `vtable` رفتار `Waker` را که از `RawWaker` ایجاد می شود ، سفارشی می کند.
    /// برای هر عمل در `Waker` ، تابع مربوط به `vtable` `RawWaker` زمینه ای فراخوانی می شود.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// جدول اشاره گر عملکرد مجازی (vtable) که رفتار [`RawWaker`] را مشخص می کند.
///
/// اشاره گر منتقل شده به تمام عملکردهای داخل vtable ، اشاره گر `data` از شی X [`RawWaker`] محصور است.
///
/// توابع درون این ساختار فقط در نظر گرفته شده اند تا از نشانگر `data` یک شیX [`RawWaker`] به درستی ساخته شده از داخل پیاده سازی [`RawWaker`] فراخوانی شوند.
/// فراخوانی یکی از توابع موجود با استفاده از هر نشانگر `data` دیگر باعث رفتار نامشخص می شود.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// هنگامی که [`RawWaker`] شبیه سازی شود ، به عنوان مثال وقتی [`Waker`] که [`RawWaker`] در آن ذخیره شده است ، شبیه سازی شود ، این عملکرد فراخوانی می شود.
    ///
    /// اجرای این عملکرد باید تمام منابعی را که برای این نمونه اضافی از [`RawWaker`] و کار مرتبط با آن لازم است حفظ کند.
    /// تماس با `wake` با [`RawWaker`] حاصل باید منجر به بیدار شدن از همان وظیفه ای شود که با [`RawWaker`] اصلی بیدار شده بود.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// این عملکرد وقتی فراخوانی شود که `wake` روی [`Waker`] فراخوانی شود.
    /// باید وظیفه مرتبط با این [`RawWaker`] را بیدار کند.
    ///
    /// اجرای این عملکرد باید اطمینان حاصل کند که منابعی را که با این نمونه از [`RawWaker`] و وظایف مرتبط مرتبط هستند ، آزاد می کند.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// این عملکرد وقتی فراخوانی شود که `wake_by_ref` روی [`Waker`] فراخوانی شود.
    /// باید وظیفه مرتبط با این [`RawWaker`] را بیدار کند.
    ///
    /// این عملکرد مشابه `wake` است ، اما نباید نشانگر داده ارائه شده را مصرف کند.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// این عملکرد با افت [`RawWaker`] فراخوانی می شود.
    ///
    /// اجرای این عملکرد باید اطمینان حاصل کند که منابعی را که با این نمونه از [`RawWaker`] و وظایف مرتبط مرتبط هستند ، آزاد می کند.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// از توابع `clone` ، `wake` ، `wake_by_ref` و `drop` `RawWakerVTable` جدید ایجاد می کند.
    ///
    /// # `clone`
    ///
    /// هنگامی که [`RawWaker`] شبیه سازی شود ، به عنوان مثال وقتی [`Waker`] که [`RawWaker`] در آن ذخیره شده است ، شبیه سازی شود ، این عملکرد فراخوانی می شود.
    ///
    /// اجرای این عملکرد باید تمام منابعی را که برای این نمونه اضافی از [`RawWaker`] و کار مرتبط با آن لازم است حفظ کند.
    /// تماس با `wake` با [`RawWaker`] حاصل باید منجر به بیدار شدن از همان وظیفه ای شود که با [`RawWaker`] اصلی بیدار شده بود.
    ///
    /// # `wake`
    ///
    /// این عملکرد وقتی فراخوانی شود که `wake` روی [`Waker`] فراخوانی شود.
    /// باید وظیفه مرتبط با این [`RawWaker`] را بیدار کند.
    ///
    /// اجرای این عملکرد باید اطمینان حاصل کند که منابعی را که با این نمونه از [`RawWaker`] و وظایف مرتبط مرتبط هستند ، آزاد می کند.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// این عملکرد وقتی فراخوانی شود که `wake_by_ref` روی [`Waker`] فراخوانی شود.
    /// باید وظیفه مرتبط با این [`RawWaker`] را بیدار کند.
    ///
    /// این عملکرد مشابه `wake` است ، اما نباید نشانگر داده ارائه شده را مصرف کند.
    ///
    /// # `drop`
    ///
    /// این عملکرد با افت [`RawWaker`] فراخوانی می شود.
    ///
    /// اجرای این عملکرد باید اطمینان حاصل کند که منابعی را که با این نمونه از [`RawWaker`] و وظایف مرتبط مرتبط هستند ، آزاد می کند.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` یک کار ناهمزمان.
///
/// در حال حاضر ، `Context` فقط برای دسترسی به `&Waker` است که می تواند برای بیدار کردن کار فعلی استفاده شود.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // اطمینان حاصل کنید که ما future در برابر تغییرات واریانس را با مجبور کردن طول عمر به ثابت بودن اطمینان حاصل می کنیم (طول زندگی با استدلال متفاوت است ، در حالی که طول عمر با موقعیت بازگشت متغیر است).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// از `&Waker` یک `Context` جدید ایجاد کنید.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// برای کار فعلی مرجعی را به `Waker` برمی گرداند.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` دسته ای است برای بیدار کردن یک کار با اطلاع دادن به مجری آن که آماده اجرا است.
///
/// این دسته یک نمونه [`RawWaker`] را محصور می کند ، که رفتار بیدار شدن مختص مجری را تعریف می کند.
///
///
/// [`Clone`] ، [`Send`] و [`Sync`] را پیاده سازی می کند.
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// وظیفه مرتبط با این `Waker` را از خواب بیدار کنید.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // تماس بیدار واقعی از طریق فراخوانی عملکرد مجازی به پیاده سازی که توسط مجری تعریف شده است ، منتقل می شود.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // با `drop` تماس نگیرید-وایکر توسط `wake` مصرف می شود.
        crate::mem::forget(self);

        // ایمنی: این ایمن است زیرا `Waker::from_raw` تنها راه است
        // برای مقداردهی اولیه `wake` و `data` کاربر را ملزم می کند که تایید کند قرارداد `RawWaker` تأیید شده است.
        //
        unsafe { (wake)(data) };
    }

    /// بدون مصرف `Waker` ، وظیفه مرتبط با این `Waker` را از خواب بیدار کنید.
    ///
    /// این مشابه `wake` است ، اما در موردی که `Waker` متعلق به آن موجود است ، ممکن است کمی کارآیی کمتری داشته باشد.
    /// این روش باید به تماس `waker.clone().wake()` ترجیح داده شود.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // تماس بیدار واقعی از طریق فراخوانی عملکرد مجازی به پیاده سازی که توسط مجری تعریف شده است ، منتقل می شود.
        //

        // ایمنی: به `wake` مراجعه کنید
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// `true` را برمی گرداند اگر این `Waker` و `Waker` دیگر همان کار را بیدار کرده باشند.
    ///
    /// این عملکرد بر اساس بهترین تلاش انجام می شود ، و حتی ممکن است نادرست برگردد حتی اگر `Waker` همان کار را بیدار کند.
    /// با این حال ، اگر این عملکرد `true` را بازگرداند ، تضمین شده است که `Waker` همان کار را بیدار می کند.
    ///
    /// این تابع در درجه اول برای اهداف بهینه سازی استفاده می شود.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// `Waker` جدیدی از [`RawWaker`] ایجاد می کند.
    ///
    /// اگر قرارداد تعریف شده در مستندات ["RawWaker"] و ["RawWakerVTable"] تأیید نشود ، رفتار `Waker` برگشتی تعریف نشده است.
    ///
    /// بنابراین این روش ناامن است.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // ایمنی: این ایمن است زیرا `Waker::from_raw` تنها راه است
            // برای مقداردهی اولیه `clone` و `data` کاربر را ملزم می کند که تایید کند قرارداد [`RawWaker`] تأیید شده است.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // ایمنی: این ایمن است زیرا `Waker::from_raw` تنها راه است
        // برای مقداردهی اولیه `drop` و `data` کاربر را ملزم می کند که تایید کند قرارداد `RawWaker` تأیید شده است.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}