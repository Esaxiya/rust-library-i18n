//! Traits برای تبدیل بین انواع.
//!
//! traits در این ماژول راهی برای تبدیل از یک نوع به نوع دیگر ارائه می دهد.
//! هر trait هدف متفاوتی دارد:
//!
//! - [`AsRef`] trait را برای تبدیل ارزان به مرجع پیاده سازی کنید
//! - [`AsMut`] trait را برای تبدیل ارزان جهش پذیر به جهش پذیر پیاده سازی کنید
//! - [`From`] trait را برای مصرف تبدیل ارزش به ارزش پیاده سازی کنید
//! - [`Into`] trait را برای مصرف تبدیل مقدار به مقدار به انواع خارج از crate فعلی پیاده سازی کنید
//! - [`TryFrom`] و [`TryInto`] traits مانند [`From`] و [`Into`] رفتار می کنند ، اما در صورت عدم موفقیت در تبدیل باید اجرا شوند.
//!
//! traits در این ماژول اغلب به عنوان trait bounds برای توابع عمومی استفاده می شود ، به طوری که از آرگومان های انواع مختلف پشتیبانی می شود.برای مثال به مستندات هر trait مراجعه کنید.
//!
//! به عنوان نویسنده کتابخانه ، شما همیشه باید پیاده سازی [`From<T>`][`From`] یا [`TryFrom<T>`][`TryFrom`] را به جای [`Into<U>`][`Into`] یا [`TryInto<U>`][`TryInto`] ترجیح دهید ، زیرا [`From`] و [`TryFrom`] انعطاف پذیری بیشتری را ایجاد می کند و به لطف اجرای پتو در کتابخانه استاندارد ، پیاده سازی های معادل [`Into`] یا [`TryInto`] را به صورت رایگان ارائه می دهد.
//! هنگام هدف قرار دادن نسخه قبل از Rust 1.41 ، ممکن است لازم باشد هنگام تبدیل به یک نوع خارج از crate فعلی ، [`Into`] یا [`TryInto`] را مستقیماً پیاده سازی کنید.
//!
//! # پیاده سازی های عمومی
//!
//! - [`AsRef`] و [`AsMut`] خود ارجاع خودکار اگر نوع داخلی یک مرجع است
//! - ["از"] <U>برای T به معنی ["به"] است</u><T><U>برای U`</u>
//! - ["TryFrom"] <U>برای T به معنای ["TryInto"] است</u><T><U>برای U`</u>
//! - [`From`] و [`Into`] بازتابنده هستند ، به این معنی که همه انواع می توانند `into` خودشان و `from` خودشان باشند
//!
//! برای مثالهای استفاده از هر trait دیدن کنید.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// عملکرد هویت.
///
/// ذکر دو نکته در مورد این عملکرد مهم است:
///
/// - این همیشه معادل بسته شدن مانند `|x| x` نیست ، زیرا ممکن است بسته شدن `x` را به نوع دیگری منتقل کند.
///
/// - ورودی `x` منتقل شده به تابع را حرکت می دهد.
///
/// اگرچه ممکن است داشتن تابعی که فقط ورودی را برمی گرداند عجیب به نظر برسد ، اما استفاده های جالبی وجود دارد.
///
///
/// # Examples
///
/// استفاده از `identity` برای انجام هیچ کاری در توالی توابع دیگر جالب ،
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // بیایید وانمود کنیم که اضافه کردن یک عملکرد جالب است.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// استفاده از `identity` به عنوان حالت پایه "do nothing" در شرایط:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // کارهای جالب تری انجام دهید ...
///
/// let _results = do_stuff(42);
/// ```
///
/// با استفاده از `identity` برای حفظ نسخه های `Some` تکرار کننده `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// برای انجام تبدیل ارزان مرجع به مرجع استفاده می شود.
///
/// این trait مشابه [`AsMut`] است که برای تبدیل بین منابع قابل تغییر استفاده می شود.
/// اگر شما نیاز به انجام یک تبدیل پرهزینه دارید ، بهتر است [`From`] را با نوع `&T` پیاده سازی کنید یا یک عملکرد دلخواه بنویسید.
///
/// `AsRef` دارای همان امضای [`Borrow`] است ، اما [`Borrow`] از چند جنبه متفاوت است:
///
/// - بر خلاف `AsRef` ، [`Borrow`] برای هر `T` دارای یک پتو است و می تواند برای پذیرش یک مرجع یا یک مقدار استفاده شود.
/// - [`Borrow`] همچنین مستلزم آن است که [`Hash`] ، [`Eq`] و [`Ord`] برای ارزش وام گرفته شده برابر با ارزش متعلق به خود باشد.
/// به همین دلیل ، اگر می خواهید فقط یک فیلد از یک ساختار وام بگیرید ، می توانید `AsRef` را پیاده سازی کنید ، اما [`Borrow`] را نه.
///
/// **Note: این trait نباید خراب شود **.در صورت عدم موفقیت در تبدیل ، از یک روش اختصاصی استفاده کنید که [`Option<T>`] یا [`Result<T, E>`] را برمی گرداند.
///
/// # پیاده سازی های عمومی
///
/// - `AsRef` اگر نوع داخلی یک مرجع یا یک مرجع قابل تغییر باشد (بعنوان مثال: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// با استفاده از trait bounds ما می توانیم آرگومان های مختلف را بپذیریم به شرطی که بتوانند به نوع مشخص شده `T` تبدیل شوند.
///
/// به عنوان مثال: با ایجاد یک تابع عمومی که `AsRef<str>` را می گیرد ، بیان می کنیم که می خواهیم همه مراجع قابل تبدیل به [`&str`] را به عنوان آرگومان بپذیریم.
/// از آنجا که [`String`] و [`&str`] `AsRef<str>` را پیاده سازی می کنند ، می توانیم هر دو را به عنوان آرگومان ورودی بپذیریم.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// تبدیل را انجام می دهد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// برای انجام یک تبدیل مرجع قابل تغییر از جهش به جهش یافته استفاده می شود.
///
/// این trait مشابه [`AsRef`] است اما برای تبدیل بین منابع قابل تغییر استفاده می شود.
/// اگر شما نیاز به انجام یک تبدیل پرهزینه دارید ، بهتر است [`From`] را با نوع `&mut T` پیاده سازی کنید یا یک عملکرد دلخواه بنویسید.
///
/// **Note: این trait نباید خراب شود **.در صورت عدم موفقیت در تبدیل ، از یک روش اختصاصی استفاده کنید که [`Option<T>`] یا [`Result<T, E>`] را برمی گرداند.
///
/// # پیاده سازی های عمومی
///
/// - `AsMut` اگر نوع داخلی یک مرجع قابل تغییر باشد ، به طور خودکار مراجعه کنید (به عنوان مثال: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// با استفاده از `AsMut` به عنوان trait bound برای یک عملکرد عمومی می توانیم همه منابع قابل تغییر را که می توانند به نوع `&mut T` تبدیل شوند ، بپذیریم.
/// از آنجا که [`Box<T>`] `AsMut<T>` را پیاده سازی می کند ، می توانیم یک تابع `add_one` بنویسیم که تمام آرگومان های قابل تبدیل به `&mut u64` را بگیرد.
/// از آنجا که [`Box<T>`] `AsMut<T>` را پیاده سازی می کند ، `add_one` آرگومان هایی از نوع `&mut Box<u64>` را نیز قبول می کند:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// تبدیل را انجام می دهد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// تبدیل ارزش به ارزش که مقدار ورودی را مصرف می کند.نقطه مقابل [`From`] است.
///
/// باید از اجرای [`Into`] پرهیز کرد و به جای آن [`From`] را پیاده سازی کرد.
/// پیاده سازی [`From`] به لطف اجرای پتو در کتابخانه استاندارد ، به طور خودکار یکی از پیاده سازی های [`Into`] را فراهم می کند.
///
/// هنگام تعیین trait bounds در یک عملکرد عمومی ، استفاده از [`Into`] را به [`From`] ترجیح دهید تا اطمینان حاصل کنید که از انواع که فقط [`Into`] را اجرا می کنند نیز می توان استفاده کرد.
///
/// **Note: این trait نباید خراب شود **.در صورت عدم موفقیت در تبدیل ، از [`TryInto`] استفاده کنید.
///
/// # پیاده سازی های عمومی
///
/// - ["از"] "<T>برای U` به معنی `Into<U> for T` است
/// - [`Into`] بازتابنده است ، به این معنی که `Into<T> for T` پیاده سازی شده است
///
/// # پیاده سازی [`Into`] برای تبدیل به انواع خارجی در نسخه های قدیمی Rust
///
/// قبل از Rust 1.41 ، اگر نوع مقصد بخشی از crate فعلی نبود ، نمی توانید [`From`] را مستقیماً پیاده سازی کنید.
/// به عنوان مثال ، این کد را در نظر بگیرید:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// این در نسخه های قدیمی زبان کامپایل نخواهد شد زیرا قوانین یتیم Rust قبلاً کمی سختگیرانه تر بود.
/// برای دور زدن این مورد ، می توانید [`Into`] را مستقیماً پیاده سازی کنید:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// درک این نکته مهم است که [`Into`] پیاده سازی [`From`] را ارائه نمی دهد (همانطور که [`From`] با [`Into`] انجام می دهد).
/// بنابراین ، همیشه باید سعی کنید [`From`] را پیاده سازی کنید و اگر [`From`] قابل اجرا نیست ، دوباره به [`Into`] بازگردید.
///
/// # Examples
///
/// [`String`] ["Into"] "<" ["Vec"] "<" ["u8"] "" "را پیاده سازی می کند:
///
/// برای بیان اینکه ما می خواهیم یک تابع عمومی همه آرگومان های قابل تبدیل به یک نوع مشخص `T` را بدست آورد ، می توانیم از یک trait bound از "Into" استفاده کنیم<T>``
///
/// به عنوان مثال: تابع `is_hello` تمام آرگومان های قابل تبدیل به ""Vec"]"<"["u8"]"> را می گیرد.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// تبدیل را انجام می دهد.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// برای انجام تبدیل مقدار به مقدار در حالی که مقدار ورودی را مصرف می کنید ، استفاده می شود.متقابل [`Into`] است.
///
/// همیشه باید پیاده سازی `From` را بر [`Into`] ترجیح داد زیرا اجرای `From` به لطف اجرای پتو در کتابخانه استاندارد ، به طور خودکار پیاده سازی [`Into`] را برای فرد فراهم می کند.
///
///
/// [`Into`] را فقط هنگام هدف گرفتن نسخه قبل از Rust 1.41 و تبدیل آن به نوع خارج از crate فعلی ، پیاده سازی کنید.
/// `From` به دلیل قوانین یتیم Rust قادر به انجام این نوع تبدیل ها در نسخه های قبلی نبود.
/// برای جزئیات بیشتر به [`Into`] مراجعه کنید.
///
/// هنگام تعیین trait bounds در یک عملکرد عمومی ، استفاده از [`Into`] را به استفاده از `From` ترجیح دهید.
/// به این ترتیب ، انواع که مستقیماً [`Into`] را اجرا می کنند نیز می توانند به عنوان آرگومان استفاده شوند.
///
/// `From` در هنگام انجام خطا نیز بسیار مفید است.هنگام ساخت تابعی که قادر به شکست باشد ، نوع بازگشت به طور کلی از فرم `Result<T, E>` خواهد بود.
/// `From` trait با اجازه دادن به یک تابع برای بازگرداندن یک نوع خطای منفرد که چندین نوع خطا را در خود جمع می کند ، مدیریت خطا را ساده می کند.برای جزئیات بیشتر به بخش "Examples" و [the book][book] مراجعه کنید.
///
/// **Note: این trait نباید خراب شود **.در صورت عدم موفقیت در تبدیل ، از [`TryFrom`] استفاده کنید.
///
/// # پیاده سازی های عمومی
///
/// - `From<T> for U` حاوی ["Into"] <U>برای T "است</u>
/// - `From` بازتابنده است ، به این معنی که `From<T> for T` پیاده سازی شده است
///
/// # Examples
///
/// [`String`] `From<&str>` را پیاده سازی می کند:
///
/// تبدیل صریح از `&str` به رشته به شرح زیر انجام می شود:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// در حین انجام کار با خطا ، معمولاً استفاده از `From` برای نوع خطای خود مفید است.
/// با تبدیل انواع خطاهای اساسی به نوع خطای سفارشی خود که نوع خطای اساسی را در خود جمع می کند ، می توانیم یک نوع خطای واحد را بدون از دست دادن اطلاعات علت اصلی بازگردانیم.
/// اپراتور '?' با تماس با `Into<CliError>::into` که به طور خودکار هنگام اجرای `From` ارائه می شود ، نوع خطای اساسی را به طور خودکار به نوع خطای سفارشی ما تبدیل می کند.
/// سپس کامپایلر نتیجه گیری می کند که کدام یک از `Into` باید مورد استفاده قرار گیرد.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// تبدیل را انجام می دهد.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// اقدام به تبدیل که `self` مصرف می کند ، ممکن است گران باشد یا نباشد.
///
/// نویسندگان کتابخانه معمولاً نباید این trait را مستقیماً پیاده سازی کنند ، اما باید [`TryFrom`] trait را که انعطاف پذیری بیشتری را ارائه می دهد و اجرای `TryInto` معادل آن را به صورت رایگان فراهم می کند ، به لطف اجرای پتو در کتابخانه استاندارد ، ترجیح می دهند.
/// برای کسب اطلاعات بیشتر در این مورد ، به اسناد مربوط به [`Into`] مراجعه کنید.
///
/// # پیاده سازی `TryInto`
///
/// این همان محدودیت ها و استدلال هایی را دارد که اجرای [`Into`] را نشان می دهد ، برای جزئیات بیشتر به آنجا مراجعه کنید.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// نوع برگشتی در صورت خطای تبدیل.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// تبدیل را انجام می دهد.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// تبدیل ساده و ایمن که در برخی شرایط ممکن است به صورت کنترل شده از کار بیفتد.متقابل [`TryInto`] است.
///
/// این زمانی مفید است که شما یک نوع تبدیل را انجام می دهید که ممکن است به طور پیش پا افتاده ای موفقیت آمیز باشد اما ممکن است نیاز به دست زدن به ویژه نیز داشته باشد.
/// به عنوان مثال ، هیچ راهی برای تبدیل [`i64`] به [`i32`] با استفاده از [`From`] trait وجود ندارد ، زیرا [`i64`] ممکن است حاوی مقداری باشد که [`i32`] نمی تواند نشان دهد و بنابراین تبدیل داده ها را از دست می دهد.
///
/// این کار را می توان با کوتاه کردن [`i64`] به [`i32`] (اساساً دادن مدول مقدار ["i64"] [`i32::MAX`]) یا با بازگرداندن [`i32::MAX`] یا روش دیگری انجام داد.
/// [`From`] trait برای تبدیل های کامل در نظر گرفته شده است ، بنابراین `TryFrom` trait به برنامه نویس اطلاع می دهد که چه زمانی یک نوع تبدیل ممکن است خراب شود و به آنها اجازه می دهد تا نحوه مدیریت آن را تعیین کنند.
///
/// # پیاده سازی های عمومی
///
/// - `TryFrom<T> for U` به معنای ["TryInto"] <U>برای T است</u>
/// - [`try_from`] انعکاسی است ، به این معنی که `TryFrom<T> for T` پیاده سازی شده است و نمی تواند شکست بخورد-نوع `Error` مرتبط برای تماس با `T::try_from()` با مقداری از نوع `T` [`Infallible`] است.
/// وقتی نوع [`!`] تثبیت شود ، [`Infallible`] و [`!`] معادل خواهد بود.
///
/// `TryFrom<T>` به شرح زیر قابل اجرا است:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// همانطور که توضیح داده شد ، [`i32`] "TryFrom <" ["i64"] ">" را اجرا می کند:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // بی صدا `big_number` را کوتاه می کند ، نیاز به شناسایی و دست زدن به برش پس از واقعیت دارد.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // خطایی را برمی گرداند زیرا `big_number` خیلی بزرگ است و نمی تواند در `i32` جای گیرد.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // `Ok(3)` را برمی گرداند.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// نوع برگشتی در صورت خطای تبدیل.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// تبدیل را انجام می دهد.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// مفاهیم عمومی
////////////////////////////////////////////////////////////////////////////////

// به عنوان آسانسور بیش از&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// به عنوان آسانسور بیش از &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): موارد زیر را برای&/&mut با موارد عمومی زیر جایگزین کنید:
// // همانطور که بر فراز Deref آسانسور می شود
// تلنگر کردن <D: ?Sized + Deref<Target: AsRef<U>> ، U:؟ Sized> AsRef <U>برای D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut بیش از &mut را بلند می کند
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): مفهوم فوق را برای &mut جایگزین کنید با مثال کلی زیر:
// // AsMut بر روی DerefMut بلند می شود
// تلنگر کردن <D: ?Sized + Deref<Target: AsMut<U>>، U:؟ Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// از دلالت بر
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// از (و بنابراین به داخل) بازتابنده است
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **یادداشت پایداری:** این ضابطه هنوز وجود ندارد ، اما ما "reserving space" هستیم که آن را در future اضافه کنیم.
/// برای جزئیات بیشتر به [rust-lang/rust#64715][#64715] مراجعه کنید.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): به جای آن یک اصلاح اساسی انجام دهید.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom به معنای TryInto است
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// تبدیل های غیرقابل خط از لحاظ معنایی معادل تبدیل های خطاپذیر با نوع خطای خالی از سکنه هستند.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS بتن
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// نوع خطای بدون خطا
////////////////////////////////////////////////////////////////////////////////

/// نوع خطا برای خطاهایی که هرگز نمی توانند اتفاق بیفتند.
///
/// از آنجا که این enum هیچگونه تغییری ندارد ، بنابراین مقداری از این نوع در واقع هرگز نمی تواند وجود داشته باشد.
/// این می تواند برای API های عمومی که از [`Result`] استفاده می کنند و نوع خطا را پارامتر می کنند ، مفید باشد تا نشان دهد که نتیجه همیشه [`Ok`] است.
///
/// به عنوان مثال ، [`TryFrom`] trait (تبدیل [`Result`] را برمی گرداند) برای انواع مختلفی که اجرای معکوس [`Into`] وجود دارد ، اجرای پتو دارد.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # سازگاری Future
///
/// این enum همان نقش [the `!`“never”type][never] را دارد که در این نسخه از Rust ناپایدار است.
/// وقتی `!` تثبیت شد ، ما قصد داریم `Infallible` را به یک نام مستعار برای آن تبدیل کنیم:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …و در نهایت `Infallible` را منسوخ کنید.
///
/// اما یک مورد وجود دارد که می توان از نحو `!` قبل از تثبیت `!` به عنوان یک نوع تمام عیار استفاده کرد: در موقعیت نوع بازگشتی یک تابع.
/// به طور خاص ، امکان پیاده سازی برای دو نوع نشانگر عملکرد مختلف وجود دارد:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// با enum `Infallible` ، این کد معتبر است.
/// با این وجود وقتی `Infallible` نام مستعار never type می شود ، دو مفهوم با هم تداخل پیدا می کنند و بنابراین با قوانین انسجام trait این زبان لغو می شود.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}