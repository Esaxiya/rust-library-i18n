//! `Default` trait برای انواع مختلفی که ممکن است مقادیر پیش فرض معنی داری داشته باشند.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait برای دادن مقدار پیش فرض مفید به یک نوع.
///
/// گاهی اوقات ، شما می خواهید به نوعی از مقدار پیش فرض بازگردید ، و به خصوص اهمیت دهید که چیست.
/// این اغلب با `ساختار` ارائه می شود که مجموعه ای از گزینه ها را تعریف می کند:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// چگونه می توان مقادیر پیش فرض را تعریف کرد؟می توانید از `Default` استفاده کنید:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// اکنون ، همه مقادیر پیش فرض را دریافت می کنید.Rust `Default` را برای انواع مختلف بدوی پیاده سازی می کند.
///
/// اگر می خواهید یک گزینه خاص را نادیده بگیرید ، اما سایر پیش فرض ها را همچنان حفظ کنید:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// اگر تمام قسمتهای نوع `Default` را اجرا کنند ، این trait با `#[derive]` قابل استفاده است.
/// هنگام `derive`d ، از مقدار پیش فرض برای نوع هر فیلد استفاده می کند.
///
/// ## چگونه می توانم `Default` را پیاده سازی کنم؟
///
/// یک پیاده سازی برای روش `default()` ارائه دهید که مقدار نوع شما را که باید پیش فرض باشد برگرداند:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// "default value" را برای یک نوع برمی گرداند.
    ///
    /// مقادیر پیش فرض اغلب نوعی از ارزش اولیه ، مقدار هویت یا هر چیز دیگری هستند که ممکن است به عنوان پیش فرض منطقی باشد.
    ///
    ///
    /// # Examples
    ///
    /// استفاده از مقادیر پیش فرض داخلی:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// ساخت خود:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// مقدار پیش فرض یک نوع را با توجه به `Default` trait برگردانید.
///
/// نوع بازگشتی از متن استنباط می شود.این معادل `Default::default()` است اما نوع آن کوتاه تر است.
///
/// مثلا:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// تولید ماکرو تولید impl از trait `Default`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }