//! این یک ماژول داخلی است که توسط ifmt استفاده می شود!زمان اجرااین ساختارها قبل از زمان به آرایه های ساکن منتقل می شوند تا رشته های قالب را از قبل ترکیب کنند.
//!
//! این تعاریف مشابه معادل های `ct` آنها هستند ، اما از نظر تفاوت در این که این تعریف ها می توانند به صورت استاتیک تخصیص داده شوند و برای زمان اجرا کمی بهینه شده اند ، متفاوت هستند.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ترازهای احتمالی که می توانند به عنوان بخشی از بخشنامه قالب بندی درخواست شوند.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// نشانگر این است که محتویات باید در راستای چپ قرار بگیرند.
    Left,
    /// نشانگر این است که محتویات باید در راستای راست قرار گیرند.
    Right,
    /// نشانگر این است که محتویات باید تراز وسط قرار بگیرند.
    Center,
    /// هیچ ترازی درخواست نشد.
    Unknown,
}

/// توسط مشخص کننده های [width](https://doc.rust-lang.org/std/fmt/#width) و [precision](https://doc.rust-lang.org/std/fmt/#precision) استفاده می شود.
#[derive(Copy, Clone)]
pub enum Count {
    /// مشخص شده با یک عدد واقعی ، مقدار را ذخیره می کند
    Is(usize),
    /// مشخص شده با استفاده از نحوهای `$` و `*` ، ایندکس را در `args` ذخیره می کند
    Param(usize),
    /// مشخص نشده
    Implied,
}