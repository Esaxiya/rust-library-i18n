//! ابزارهای قالب بندی و چاپ رشته ها.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// ترازهای احتمالی `Formatter::align` برگردانده شده است
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// نشانگر این است که محتویات باید در راستای چپ قرار بگیرند.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// نشانگر این است که محتویات باید در راستای راست قرار گیرند.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// نشانگر این است که محتویات باید تراز وسط قرار بگیرند.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// نوعی که با روش های قالب بندی برگردانده می شود.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// نوع خطایی که از قالب بندی پیام به یک جریان برمی گردد.
///
/// این نوع از انتقال خطایی غیر از اینکه خطایی رخ داده پشتیبانی نمی کند.
/// هرگونه اطلاعات اضافی باید ترتیب داده شود تا از طریق دیگری منتقل شود.
///
/// نکته مهمی که باید به خاطر داشته باشید این است که نوع `fmt::Error` را نباید با [`std::io::Error`] یا [`std::error::Error`] اشتباه گرفت ، که ممکن است دامنه آن را نیز داشته باشید.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// trait برای نوشتن یا قالب بندی در بافرها یا جریان های پذیرنده یونیکد.
///
/// این trait فقط داده های رمزگذاری شده UTF-8 را می پذیرد و [flushable] نیست.
/// اگر فقط می خواهید Unicode را بپذیرید و نیازی به فلاشینگ ندارید ، باید این trait را پیاده سازی کنید.
/// در غیر این صورت شما باید [`std::io::Write`] را پیاده سازی کنید.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// یک تار رشته ای را برای این نویسنده می نویسد ، و آیا موفقیت نوشتن را برمی گرداند.
    ///
    /// این روش تنها در صورتی موفقیت آمیز است که کل برش رشته با موفقیت نوشته شده باشد ، و این روش تا زمان نوشتن تمام داده ها یا بروز خطا باز نخواهد گشت.
    ///
    ///
    /// # Errors
    ///
    /// این تابع نمونه ای از [`Error`] را هنگام خطا برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// [`char`] را برای این نویسنده می نویسد ، و آیا موفقیت نوشتن را برمی گرداند.
    ///
    /// یک [`char`] منفرد ممکن است به عنوان بیش از یک بایت رمزگذاری شود.
    /// این روش تنها در صورتی موفقیت آمیز است که کل توالی بایت با موفقیت نوشته شده باشد و این روش تا زمان نوشتن تمام داده ها یا بروز خطا بر نمی گردد.
    ///
    ///
    /// # Errors
    ///
    /// این تابع نمونه ای از [`Error`] را هنگام خطا برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// چسب برای استفاده از ماکرو [`write!`] با مجریان این trait.
    ///
    /// این روش به طور کلی نباید به صورت دستی فراخوانی شود ، بلکه باید از طریق خود ماکرو [`write!`] انجام شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// پیکربندی برای قالب بندی.
///
/// `Formatter` گزینه های مختلف مربوط به قالب بندی را نشان می دهد.
/// کاربران `Formatter` را مستقیماً نمی سازند.یک ارجاع قابل تغییر به یک به روش `fmt` از تمام قالب های traits مانند [`Debug`] و [`Display`] منتقل می شود.
///
///
/// برای تعامل با `Formatter` ، روش های مختلفی را برای تغییر گزینه های مختلف مربوط به قالب بندی فراخوانی می کنید.
/// برای مثال ، لطفاً به اسناد روشهای تعریف شده در `Formatter` در زیر مراجعه کنید.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// آرگومان اساساً یک تابع قالب بندی تا حدی کاربردی بهینه شده ، معادل `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` است.

extern "C" {
    type Opaque;
}

/// این ساختار بیانگر "argument" عمومی است که توسط خانواده توابع Xprintf گرفته شده است.این شامل یک عملکرد برای قالب بندی مقدار داده شده است.
/// در زمان کامپایل اطمینان حاصل می شود که تابع و مقدار انواع صحیحی دارند و سپس از این ساختار برای متعارف کردن آرگومان ها به یک نوع استفاده می شود.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// این یک مقدار ثابت ثابت را برای نشانگر عملکرد مرتبط با indices/counts در زیرساخت قالب بندی تضمین می کند.
//
// توجه داشته باشید که تابعی که بدین صورت تعریف شود صحیح نخواهد بود زیرا توابع همیشه با نام کاهش یافته_addr با پایین آمدن جریان به LLVM IR برچسب گذاری می شوند ، بنابراین آدرس آنها برای LLVM مهم تلقی نمی شود و به همین دلیل بازیگران as_usize ممکن است اشتباه جمع شوند.
//
// در عمل ، ما هرگز داده های حاوی غیر استفاده را as_usize نمی دانیم (به عنوان یک تولید ثابت از آرگومان های قالب بندی) ، بنابراین این فقط یک بررسی اضافی است.
//
// ما در وهله اول می خواهیم اطمینان حاصل کنیم که نشانگر عملکرد در `USIZE_MARKER` نشانی مربوط به *فقط* مربوط به توابع است که `&usize` را نیز به عنوان اولین آرگومان در نظر می گیرند.
// read_volatile در اینجا تضمین می کند که با خیال راحت می توانیم یک مقدار استفاده را از مرجع عبور داده شده آماده کنیم و این آدرس به عملکرد غیر استفاده استفاده نمی کند.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // ایمنی: ptr یک مرجع است
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // ایمنی: `mem::transmute(x)` بی خطر است زیرا
        //     1. `&'b T` طول عمر خود را با `'b` ایجاد می کند (به طوری که یک عمر نامحدود ندارد)
        //     2.
        //     `&'b T` و `&'b Opaque` طرح حافظه یکسانی دارند (وقتی `T` `Sized` باشد ، همانطور که در اینجا است) `mem::transmute(f)` بی خطر است زیرا `fn(&T, &mut Formatter<'_>) -> Result` و `fn(&Opaque, &mut Formatter<'_>) -> Result` دارای ABI یکسان هستند (تا زمانی که `T` `Sized` باشد)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // SAFETY: قسمت `formatter` فقط در صورت تنظیم بر روی USIZE_MARKER تنظیم شده است
            // ارزش یک مقدار استفاده است ، بنابراین این امن است
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// پرچم های موجود در قالب v1 از format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// هنگام استفاده از ماکرو format_args! () ، این تابع برای تولید ساختار Arguments استفاده می شود.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// این تابع برای تعیین پارامترهای قالب بندی غیراستاندارد استفاده می شود.
    /// آرایه `pieces` باید حداقل به اندازه `fmt` باشد تا یک ساختار Argument معتبر ساخته شود.
    /// همچنین ، هر `Count` درون `fmt` که `CountIsParam` یا `CountIsNextParam` باشد باید به استدلالی که با `argumentusize` ایجاد شده اشاره کند.
    ///
    /// با این حال ، عدم انجام این کار باعث عدم ایمنی نمی شود ، اما بی اعتبار را نادیده می گیرد.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// طول متن قالب بندی شده را تخمین می زند.
    ///
    /// این هدف برای استفاده در تنظیم ظرفیت اولیه `String` هنگام استفاده از `format!` در نظر گرفته شده است.
    /// Note: این نه حد پایین است و نه بالا.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // اگر رشته فرمت با آرگومان شروع می شود ، هیچ چیزی را از قبل اختصاص ندهید ، مگر اینکه طول قطعات قابل توجه باشد.
            //
            //
            0
        } else {
            // چند آرگومان وجود دارد ، بنابراین هر فشار اضافی رشته را دوباره تخصیص می دهد.
            //
            // برای جلوگیری از آن ، ما در اینجا ظرفیت "pre-doubling" هستیم.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// این ساختار یک نسخه از پیش تلفیق شده ایمن یک رشته قالب و آرگومان های آن را نشان می دهد.
/// این کار نمی تواند در زمان اجرا ایجاد شود زیرا با خیال راحت امکان پذیر نیست ، بنابراین هیچ سازنده ای داده نمی شود و فیلدها خصوصی هستند تا از تغییر آن جلوگیری کنند.
///
///
/// ماکرو [`format_args!`] با خیال راحت نمونه ای از این ساختار را ایجاد می کند.
/// ماکرو رشته فرمت را در زمان کامپایل تأیید می کند ، بنابراین استفاده از توابع [`write()`] و [`format()`] می تواند با اطمینان انجام شود.
///
/// همانطور که در زیر مشاهده می شود می توانید از `Arguments<'a>` که [`format_args!`] در زمینه `Debug` و `Display` برمی گرداند استفاده کنید.
/// این مثال همچنین نشان می دهد که فرمت های `Debug` و `Display` به همان چیز: رشته فرمت درونی در `format_args!`.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // قطعه های رشته را برای چاپ فرمت کنید.
    pieces: &'a [&'static str],

    // مشخصات مکان نگهدارنده یا `None` در صورت پیش فرض بودن همه مشخصات (مانند "{}{}").
    fmt: Option<&'a [rt::v1::Argument]>,

    // آرگومان های پویا برای درون یابی ، با قطعات رشته ای ترکیب می شوند.
    // (قبل از هر آرگومان یک رشته وجود دارد.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// اگر رشته ای برای قالب بندی ندارد ، رشته قالب بندی شده را دریافت کنید.
    ///
    /// این می تواند برای جلوگیری از تخصیص در بی اهمیت ترین حالت استفاده شود.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` باید خروجی را در یک زمینه برنامه ریز ، اشکال زدایی قالب بندی کند.
///
/// به طور کلی ، شما فقط باید `derive` `Debug` پیاده سازی.
///
/// هنگامی که با مشخص کننده قالب جایگزین `#?` استفاده می شود ، خروجی بسیار چاپ می شود.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// اگر همه زمینه ها `Debug` را اجرا کنند ، می توان از این trait با `#[derive]` استفاده کرد.
/// وقتی `برای stts استخراج می شود ، از نام `struct` و سپس `{` استفاده می شود ، سپس لیستی جدا شده با کاما از نام هر فیلد و مقدار `Debug` و سپس `}` استفاده می شود.
/// برای `enum` از نام نوع و در صورت استفاده از `(` و سپس مقادیر `Debug` قسمتها و سپس `)` استفاده خواهد شد.
///
/// # Stability
///
/// قالب های `Debug` مشتق شده پایدار نیستند ، و بنابراین ممکن است با نسخه های future Rust تغییر کند.
/// علاوه بر این ، پیاده سازی `Debug` از انواع ارائه شده توسط کتابخانه استاندارد (`libstd` ، `libcore` ، `liballoc` و غیره) پایدار نیست ، و همچنین ممکن است با نسخه های future Rust تغییر کند.
///
///
/// # Examples
///
/// استخراج یک پیاده سازی:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// اجرای دستی:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// تعدادی روش کمکی در ساختار [`Formatter`] وجود دارد که به شما در پیاده سازی دستی ، مانند [`debug_struct`] ، کمک می کند.
///
/// `Debug` پیاده سازی ها با استفاده از `derive` یا API سازنده اشکال زدایی در [`Formatter`] از چاپ بسیار زیبا با استفاده از پرچم جایگزین پشتیبانی می کنند: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// چاپ بسیار زیبا با `#?`:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// ماژول جداگانه برای صادرات مجدد ماکرو `Debug` از prelude بدون trait `Debug`.
pub(crate) mod macros {
    /// تولید ماکرو تولید impl از trait `Debug`.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// trait را برای یک قالب خالی قالب بندی کنید ، `{}`.
///
/// `Display` مشابه [`Debug`] است ، اما `Display` برای خروجی کاربر است و نمی توان آن را استخراج کرد.
///
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// پیاده سازی `Display` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait باید خروجی خود را به صورت یک عدد در base-8 قالب بندی کند.
///
/// برای عددهای صحیح امضا شده ابتدایی (`i8` تا `i128` و `isize`) ، مقادیر منفی به عنوان نمایش مکمل این دو قالب بندی می شوند.
///
///
/// پرچم جایگزین ، `#` ، `0o` را جلوی خروجی اضافه می کند.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// استفاده اساسی با `i32`:
///
/// ```
/// let x = 42; // 42 در هشتم '52' است
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// پیاده سازی `Octal` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // به اجرای i32 تفویض شود
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait باید خروجی خود را به صورت عددی باینری قالب بندی کند.
///
/// برای عددهای صحیح امضا شده ابتدایی ([`i8`] تا [`i128`] و [`isize`]) ، مقادیر منفی به عنوان نمایش مکمل این دو قالب بندی می شوند.
///
///
/// پرچم جایگزین ، `#` ، `0b` را جلوی خروجی اضافه می کند.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// استفاده اساسی با [`i32`]:
///
/// ```
/// let x = 42; // 42 بصورت باینری '101010' است
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// پیاده سازی `Binary` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // به اجرای i32 تفویض شود
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait باید خروجی خود را به صورت یک عدد در هگزادسیمال قالب بندی کند ، با `a` تا `f` با حروف کوچک.
///
/// برای عددهای صحیح امضا شده ابتدایی (`i8` تا `i128` و `isize`) ، مقادیر منفی به عنوان نمایش مکمل این دو قالب بندی می شوند.
///
///
/// پرچم جایگزین ، `#` ، `0x` را جلوی خروجی اضافه می کند.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// استفاده اساسی با `i32`:
///
/// ```
/// let x = 42; // 42 با سحر و جادو '2a' است
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// پیاده سازی `LowerHex` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // به اجرای i32 تفویض شود
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait باید خروجی خود را به صورت یک عدد در هگزادسیمال قالب بندی کند ، با بزرگتر از `A` تا `F`.
///
/// برای عددهای صحیح امضا شده ابتدایی (`i8` تا `i128` و `isize`) ، مقادیر منفی به عنوان نمایش مکمل این دو قالب بندی می شوند.
///
///
/// پرچم جایگزین ، `#` ، `0x` را جلوی خروجی اضافه می کند.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// استفاده اساسی با `i32`:
///
/// ```
/// let x = 42; // 42 با سحر و جادو '2A' است
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// پیاده سازی `UpperHex` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // به اجرای i32 تفویض شود
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait باید خروجی خود را به عنوان یک مکان حافظه قالب بندی کند.
/// این معمولاً به صورت هگزادسیمال ارائه می شود.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// استفاده اساسی با `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // این چیزی شبیه به '0x7f06092ac6d0' تولید می کند
/// ```
///
/// پیاده سازی `Pointer` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // از `as` برای تبدیل به `*const T` استفاده کنید ، که Pointer را پیاده سازی می کند و می توانیم از آن استفاده کنیم
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait باید خروجی خود را در علامت گذاری علمی با یک حرف کوچک `e` قالب بندی کند.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// استفاده اساسی با `f64`:
///
/// ```
/// let x = 42.0; // 42.0 در نشانه گذاری علمی '4.2e1' است
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// پیاده سازی `LowerExp` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // نماینده به اجرای f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait باید خروجی خود را در علامت گذاری علمی با یک حرف بزرگ `E` قالب بندی کند.
///
/// برای اطلاعات بیشتر در مورد قالب بندی ها ، به [the module-level documentation][module] مراجعه کنید.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// استفاده اساسی با `f64`:
///
/// ```
/// let x = 42.0; // 42.0 در نشانه گذاری علمی '4.2E1' است
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// پیاده سازی `UpperExp` بر روی یک نوع:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // نماینده به اجرای f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// مقدار را با استفاده از قالب دهنده داده شده قالب بندی می کند.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// عملکرد `write` جریان خروجی و یک ساختار `Arguments` را می توان با ماکرو `format_args!` از پیش ترکیب کرد.
///
///
/// آرگومان ها با توجه به رشته فرمت مشخص شده در جریان خروجی ارائه شده ، قالب بندی می شوند.
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// لطفا توجه داشته باشید که استفاده از [`write!`] ممکن است ارجح باشد.مثال:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // ما می توانیم از پارامترهای قالب بندی پیش فرض برای همه آرگومان ها استفاده کنیم.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // هر مشخصات دارای یک استدلال مربوطه است که قبل از آن یک قطعه رشته وجود دارد.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // ایمنی: arg و args.args از همان استدلال ها ناشی می شوند ،
                // که تضمین می کند شاخص ها همیشه در محدوده هستند.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // فقط یک قطعه رشته عقب می تواند باقی بماند.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // ایمنی: arg و args از همان استدلال ها ناشی می شوند ،
    // که تضمین می کند شاخص ها همیشه در محدوده هستند.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // استدلال صحیح را استخراج کنید
    debug_assert!(arg.position < args.len());
    // ایمنی: arg و args از همان استدلال ها ناشی می شوند ،
    // که تضمین می کند شاخص آن همیشه در محدوده است.
    let value = unsafe { args.get_unchecked(arg.position) };

    // سپس در واقع مقداری چاپ کنید
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // ایمنی: cnt و args از همان استدلال ها ناشی می شوند ،
            // که تضمین می کند این شاخص همیشه در محدوده است.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// بالشتک پس از پایان چیزی.برگشت توسط `Formatter::padding`.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// این پدینگ را بنویسید.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // ما می خواهیم این را تغییر دهیم
            buf: wrap(self.buf),

            // و اینها را حفظ کنید
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // روش های کمکی که برای پر کردن و پردازش آرگومان های قالب بندی استفاده می شود و همه قالب بندی های traits می توانند از آنها استفاده کنند.
    //

    /// پر کردن صحیح را برای یک عدد صحیح که قبلاً در یک خیابان منتشر شده است ، انجام می دهد.
    /// str نباید * حاوی علامت عدد صحیح باشد که با این روش اضافه می شود.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative است ، خواه عدد صحیح اصلی مثبت باشد یا صفر.
    /// * پیشوند ، اگر کاراکتر '#' (Alternate) ارائه شود ، این پیشوندی است که باید در مقابل شماره قرار دهید.
    ///
    /// * buf ، آرایه بایت که تعداد در آن قالب بندی شده است
    ///
    /// این عملکرد به درستی پرچم های ارائه شده و همچنین حداقل عرض را در بر می گیرد.
    /// این به دقت توجه نخواهد شد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // ما باید "-" را از شماره خروجی حذف کنیم.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // در صورت وجود علامت ، و در صورت درخواست پیشوند را می نویسد
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // قسمت `width` در این مرحله بیشتر یک پارامتر `min-width` است.
        match self.width {
            // در صورت عدم نیاز به حداقل طول ، می توانیم بایت ها را بنویسیم.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // بررسی کنید که آیا از حداقل عرض بیشتر هستیم یا خیر ، در این صورت می توانیم فقط بایت ها را بنویسیم.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // اگر نویسه پر کردن صفر باشد ، علامت و پیش شماره قبل از پر کردن می رود
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // در غیر این صورت ، علامت و پیشوند به دنبال بالشتک می رود
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// این تابع پس از اعمال پرچم های قالب بندی مربوطه مشخص شده ، یک قطعه رشته ای را می گیرد و آن را به بافر داخلی منتقل می کند.
    /// پرچم های شناخته شده برای رشته های عمومی عبارتند از:
    ///
    /// * عرض ، حداقل عرض آنچه باید منتشر شود
    /// * fill/align - اگر رشته ارائه شده باید پر شود ، چه چیزی را منتشر کند و کجا آن را منتشر کند
    /// * رشته ، حداکثر طول برای انتشار ، اگر رشته از این طول بیشتر باشد کوتاه می شود
    ///
    /// قابل توجه این عملکرد پارامترهای `flag` را نادیده می گیرد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // مطمئن شوید که یک مسیر سریع از جلو وجود دارد
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // قسمت `precision` را می توان به عنوان `max-width` برای رشته در حال قالب تفسیر كرد.
        //
        let s = if let Some(max) = self.precision {
            // اگر رشته ما از دقت طولانی تر باشد ، پس باید برش داشته باشیم.
            // با این حال پرچم های دیگری مانند `fill` ، `width` و `align` باید مثل همیشه عمل کنند.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM در اینجا نمی تواند اثبات کند که `..i` panic `&s[..i]` نخواهد بود ، اما می دانیم که نمی تواند panic باشد.
                // برای جلوگیری از `unsafe` از `get` + `unwrap_or` استفاده کنید و در غیر این صورت هیچ کد مربوط به panic را در اینجا منتشر نکنید.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // قسمت `width` در این مرحله بیشتر یک پارامتر `min-width` است.
        match self.width {
            // اگر ما زیر حداکثر طول هستیم و حداقل شرایط لازم برای طول وجود ندارد ، پس می توانیم رشته را منتشر کنیم
            //
            None => self.buf.write_str(s),
            // اگر زیر حداکثر عرض هستیم ، بررسی کنید که آیا از حداقل عرض بیشتر هستیم یا خیر ، به همین سادگی فقط انتشار رشته است.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // اگر هم زیر حداکثر و هم حداقل عرض هستیم ، حداقل رشته را با رشته مشخص شده + چند تراز را پر کنید.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// پیش پر کردن را بنویسید و پس از پر کردن نانوشته را برگردانید.
    /// تماس گیرندگان مسئولیت اطمینان از نوشتن پس از پر کردن را پس از آنچه که پر شده است ، انجام می دهند.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// قطعات قالب بندی شده را می گیرد و روکش را اعمال می کند.
    /// فرض می کند که تماس گیرنده در حال حاضر قطعات را با دقت لازم ارائه داده است ، بنابراین `self.precision` قابل چشم پوشی است.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // برای بالشتک صفر آگاه از علامت ، ابتدا علامت را رندر می کنیم و رفتار می کنیم مثل اینکه از ابتدا هیچ نشانه ای نداریم.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // یک علامت همیشه اول است
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // علامت را از قسمتهای قالب بندی شده بردارید
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // قطعات باقیمانده از روند بالشتک معمولی عبور می کنند.
            let len = formatted.len();
            let ret = if width <= len {
                // بدون بالشتک
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // این مورد معمول است و ما یک میانبر می گیریم
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // SAFETY: این مورد برای `flt2dec::Part::Num` و `flt2dec::Part::Copy` استفاده می شود.
            // استفاده از `flt2dec::Part::Num` بی خطر است زیرا هر `c` بین `b'0'` و `b'9'` است ، به این معنی که `s` UTF-8 معتبر است.
            // همچنین استفاده از آن برای `flt2dec::Part::Copy(buf)` احتمالاً در عمل ایمن است زیرا `buf` باید ASCII ساده باشد ، اما ممکن است کسی مقدار بد `buf` را به `flt2dec::to_shortest_str` بداند زیرا این یک عملکرد عمومی است.
            //
            // FIXME: تعیین کنید که آیا این می تواند منجر به UB شود.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 صفر
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// برخی از داده ها را در بافر اصلی موجود در این قالب نویس می نویسد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // این معادل است با:
    ///         // بنویسید! (قالب ، "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// برخی از اطلاعات قالب بندی شده را در این نمونه می نویسد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// پرچم ها برای قالب بندی
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// کاراکتر به عنوان 'fill' هر زمان که تراز باشد وجود دارد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // تراز را با ">" به راست تنظیم می کنیم.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// پرچم نشان می دهد که چه شکلی از تراز درخواست شده است.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// به صورت اختیاری عرض عدد صحیح مشخص شده است که باید خروجی باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // اگر عرض دریافت کردیم ، از آن استفاده می کنیم
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // در غیر این صورت ما کار خاصی انجام نمی دهیم
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// به صورت اختیاری برای انواع عددی مشخص شده است.
    /// متناوباً ، حداکثر عرض برای انواع رشته ها.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // اگر دقیق دریافت کردیم ، از آن استفاده می کنیم.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // در غیر این صورت 2 را پیش فرض قرار می دهیم.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// تعیین می کند که آیا پرچم `+` مشخص شده است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// تعیین می کند که آیا پرچم `-` مشخص شده است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // علامت منفی می خواهید؟یکی داشته باش!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// تعیین می کند که آیا پرچم `#` مشخص شده است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// تعیین می کند که آیا پرچم `0` مشخص شده است.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // ما گزینه های قالب ساز را نادیده می گیریم.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: تصمیم بگیرید که برای این دو پرچم چه API عمومی می خواهیم.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// سازنده [`DebugStruct`] ایجاد می کند که برای کمک به ایجاد پیاده سازی [`fmt::Debug`] برای ستون ها طراحی شده است.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// سازنده `DebugTuple` ایجاد می کند که برای کمک به ایجاد پیاده سازی های `fmt::Debug` برای تاپ ستت طراحی شده است.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// سازنده `DebugList` ایجاد می کند که برای کمک به ایجاد پیاده سازی های `fmt::Debug` برای ساختارهای لیست مانند طراحی شده است.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// سازنده `DebugSet` ایجاد می کند که برای کمک به ایجاد پیاده سازی های `fmt::Debug` برای ساختارهای مشابه طراحی شده است.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// در این مثال پیچیده تر ، ما از [`format_args!`] و `.debug_set()` برای ساخت لیستی از بازوهای مطابقت استفاده می کنیم:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// سازنده `DebugMap` ایجاد می کند که برای کمک به ایجاد پیاده سازی `fmt::Debug` برای ساختارهای نقشه مانند طراحی شده است.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// پیاده سازی های قالب بندی اصلی traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // اگر کاراکتر احتیاج به فرار دارد ، تاکنون پرونده های عقب مانده را فوراً بنویسید و بنویسید ، دیگر از این کار صرف نظر کنید
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // پرچم جایگزین در حال حاضر توسط LowerHex به عنوان خاص در نظر گرفته می شود-این نشان می دهد که آیا پیشوند با 0x است.
        // ما از آن برای بررسی اینکه آیا به صفر گسترش می یابد یا نه استفاده می کنیم و سپس آن را بدون قید و شرط تنظیم می کنیم تا پیشوند را بدست آوریم.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// پیاده سازی Display/Debug برای انواع مختلف هسته

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell به طور متقابل قرض گرفته شده است بنابراین نمی توانیم در اینجا به ارزش آن نگاه کنیم.
                // به جای آن یک مکان یاب نشان دهید.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// اگر انتظار داشتید که تست ها اینجا باشد ، به جای آن به پرونده core/tests/fmt.rs نگاه کنید ، این کار بسیار آسان تر از ایجاد همه ساختارهای rt::Piece در اینجا است.
//
// همچنین آزمایشاتی در تخصیص crate برای کسانی که نیاز به تخصیص دارند وجود دارد.