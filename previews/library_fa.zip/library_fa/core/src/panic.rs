//! پشتیبانی از Panic در کتابخانه استاندارد.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// یک ساختار ارائه دهنده اطلاعات در مورد panic.
///
/// `PanicInfo` ساختار به یک panic hook تنظیم شده توسط عملکرد [`set_hook`] منتقل می شود.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// محموله مرتبط با panic را برمی گرداند.
    ///
    /// این معمولاً `&'static str` یا [`String`] است ، اما نه همیشه.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// اگر ماکرو `panic!` از `core` crate (نه از `std`) با یک رشته قالب بندی و چند آرگومان اضافی استفاده شده است ، آن پیام را برای استفاده به عنوان مثال با [`fmt::write`] آماده می کند
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// در صورت وجود اطلاعات مربوط به مکانی را که panic از آن منشأ گرفته است برمی گرداند.
    ///
    /// این روش در حال حاضر همیشه [`Some`] را برمی گرداند ، اما این ممکن است در نسخه های future تغییر کند.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: اگر این مورد تغییر کند و گاهی اوقات None بر نمی گردد ،
        // در std::panicking::default_hook و std::panicking::begin_panic_fmt به آن پرونده رسیدگی کنید.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ما نمی توانیم از downcast_ref استفاده کنیم: :<String>() اینجا
        // از آنجا که رشته در libcore موجود نیست!
        // payload یک رشته است که `std::panic!` با چندین استدلال فراخوانی می شود ، اما در این حالت پیام نیز در دسترس است.
        //

        self.location.fmt(formatter)
    }
}

/// یک ساختار حاوی اطلاعات مربوط به مکان panic.
///
/// این ساختار توسط [`PanicInfo::location()`] ایجاد شده است.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// مقایسه برابری و ترتیب در اولویت پرونده ، خط و سپس ستون انجام می شود.
/// فایل ها به عنوان رشته مقایسه می شوند نه `Path` ، که غیر منتظره است.
/// برای بحث بیشتر به اسناد ["محل سکونت: : پرونده"] مراجعه کنید.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// محل تماس گیرنده این عملکرد را برمی گرداند.
    /// اگر تماس گیرنده آن عملکرد حاشیه نویسی کند ، مکان تماس آن برمی گردد و به همین ترتیب روی اولین پشته در یک مجموعه عملکرد غیر ردیابی قرار می گیرید.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] را که در آن فراخوانی می شود برمی گرداند.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// [`Location`] را از درون تعریف این تابع برمی گرداند.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // اجرای همان عملکرد غیرقابل ردیابی در مکانی متفاوت ، نتیجه یکسانی را به ما می دهد
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // اجرای تابع ردیابی شده در یک مکان متفاوت ، مقدار متفاوتی تولید می کند
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// نام فایل مبدا را که panic از آن منشأ گرفته است برمی گرداند.
    ///
    /// # `&str`, نه `&Path`
    ///
    /// نام برگشتی به یک مسیر منبع در سیستم کامپایلر اشاره دارد ، اما نمایندگی این به طور مستقیم به عنوان `&Path` معتبر نیست.
    /// کد کامپایل شده ممکن است در سیستم دیگری با اجرای `Path` متفاوت از سیستم ارائه دهنده محتویات اجرا شود و این کتابخانه در حال حاضر نوع دیگری از "host path" ندارد.
    ///
    /// تعجب آورترین رفتار زمانی اتفاق می افتد که فایل "the same" از طریق چندین مسیر در سیستم ماژول قابل دسترسی باشد (معمولاً با استفاده از ویژگی `#[path = "..."]` یا موارد مشابه) ، که می تواند باعث شود کد های یکسان مقادیر متفاوت از این عملکرد را برگرداند.
    ///
    ///
    /// # Cross-compilation
    ///
    /// هنگامی که سیستم عامل میزبان و سیستم عامل متفاوت هستند ، این مقدار برای عبور به `Path::new` یا سازنده های مشابه مناسب نیست.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// شماره خطی را که panic از آن منشأ گرفته است برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// ستونی را که panic از آن منشأ گرفته است برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// یک trait داخلی که توسط libstd برای انتقال داده از libstd به `panic_unwind` و سایر زمانهای استفاده از panic استفاده می شود.
/// در نظر گرفته نشده است که به زودی تثبیت شود ، از آن استفاده نکنید.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// مالکیت کامل مطالب را در دست بگیرید.
    /// نوع بازگشت در واقع `Box<dyn Any + Send>` است ، اما ما نمی توانیم از `Box` در libcore استفاده کنیم.
    ///
    /// بعد از فراخوانی این روش ، فقط مقداری از مقدار پیش فرض ساختگی در `self` باقی مانده است.
    /// تماس دو بار با این روش یا تماس با `get` پس از فراخوانی این روش ، خطا است.
    ///
    /// این استدلال قرض گرفته شده است زیرا panic Runtime (`__rust_start_panic`) فقط `dyn BoxMeUp` قرض گرفته می شود.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// فقط مطالب را قرض بگیرید.
    fn get(&mut self) -> &(dyn Any + Send);
}