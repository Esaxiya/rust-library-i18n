//! تبدیل کاراکترها

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// `u32` را به `char` تبدیل می کند.
///
/// توجه داشته باشید که همه ["char" ها معتبر ["u32"] ثانیه هستند ، و می توان آنها را با یک انتخاب کرد
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// با این حال ، عکس این درست نیست: همه "u32" های معتبر ["char"] معتبر نیستند.
/// `from_u32()` اگر ورودی برای [`char`] مقدار معتبری نباشد ، `None` را برمی گرداند.
///
/// برای نسخه ناامن این عملکرد که این بررسی ها را نادیده می گیرد ، به [`from_u32_unchecked`] مراجعه کنید.
///
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// بازگشت `None` وقتی ورودی معتبر [`char`] نباشد:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// با نادیده گرفتن اعتبار ، `u32` را به `char` تبدیل می کند.
///
/// توجه داشته باشید که همه ["char" ها معتبر ["u32"] ثانیه هستند ، و می توان آنها را با یک انتخاب کرد
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// با این حال ، عکس این درست نیست: همه "u32" های معتبر ["char"] معتبر نیستند.
/// `from_u32_unchecked()` این را نادیده می گیرد ، و کورکورانه به [`char`] می رود ، احتمالاً یک نامعتبر ایجاد می کند.
///
///
/// # Safety
///
/// این عملکرد ناامن است ، زیرا ممکن است مقادیر `char` نامعتبر را ایجاد کند.
///
/// برای نسخه ایمن این عملکرد ، به عملکرد [`from_u32`] مراجعه کنید.
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ایمنی: تماس گیرنده باید تضمین کند که مقدار `i` معتبر است.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// [`char`] را به [`u32`] تبدیل می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// [`char`] را به [`u64`] تبدیل می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // کاراکتر به مقدار نقطه کد کست می شود ، سپس صفر تا 64 بیت گسترش می یابد.
        // به [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] مراجعه کنید
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// [`char`] را به [`u128`] تبدیل می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // کاراکتر به مقدار نقطه کد کست می شود ، سپس صفر تا 128 بیت گسترش می یابد.
        // به [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics] مراجعه کنید
        c as u128
    }
}

/// یک بایت را در 0x00 نقشه می کند ..=0xFF به `char` که نقطه کد آن دارای همان مقدار است ، در U + 0000 ..=U + 00FF.
///
/// یونیکد به گونه ای طراحی شده است که بایت را با رمزگذاری کاراکتری که IANA با آن ISO-8859-1 می نامد ، رمزگشایی می کند.
/// این رمزگذاری با ASCII سازگار است.
///
/// توجه داشته باشید که این مورد با ISO/IEC 8859-1 معروف است
/// ISO 8859-1 (با یک خط تیره کمتر) ، مقداری مقادیر بایت "blanks" باقی می گذارد که به هیچ کاراکتر اختصاص داده نمی شود.
/// ISO-8859-1 (همان IANA) آنها را به کدهای کنترل C0 و C1 اختصاص می دهد.
///
/// توجه داشته باشید که این نیز با Windows-1252 معروف به * متفاوت است
/// صفحه صفحه 1252 ، که یک superset ISO/IEC 8859-1 است که برخی از نقاط خالی (نه همه!) را به علائم نگارشی و حروف مختلف لاتین اختصاص می دهد.
///
/// برای سردرگمی بیشتر موارد ، [on the Web](https://encoding.spec.whatwg.org/) `ascii` ، `iso-8859-1` و `windows-1252` نام مستعار برای یک مجموعه بزرگ از Windows-1252 است که جاهای خالی باقی مانده را با کدهای کنترل C0 و C1 مربوط پر می کند.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// [`u8`] را به [`char`] تبدیل می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// خطایی که هنگام تجزیه کاراکتر قابل بازگشت است.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // SAFETY: بررسی کنید که این یک مقدار unicode قانونی است
            Ok(unsafe { transmute(i) })
        }
    }
}

/// وقتی خطا از u32 به char تبدیل نشد ، نوع خطا برمی گردد.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// رقمی را در شعاع داده شده به `char` تبدیل می کند.
///
/// 'radix' در اینجا گاهی اوقات 'base' نیز نامیده می شود.
/// شعاع دو نشان می دهد یک عدد باینری ، یک شعبه ده ، دهدهی ، و یک شعاع شانزده ، هگزادسیمال ، برای دادن برخی مقادیر مشترک.
///
/// شعاع خودسرانه پشتیبانی می شود.
///
/// `from_digit()` `None` را برمی گرداند اگر ورودی رقمی در رادیکس داده شده نباشد.
///
/// # Panics
///
/// Panics اگر یک شعاع بزرگتر از 36 به آن داده شود.
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // دهدهی 11 در رقم 16 یک رقمی است
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// بازگشت `None` وقتی ورودی رقمی نیست:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// عبور از یک شعاع بزرگ ، باعث ایجاد panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}