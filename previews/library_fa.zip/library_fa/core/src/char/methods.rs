//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// بالاترین نقطه کد معتبر `char` می تواند داشته باشد.
    ///
    /// `char` [Unicode Scalar Value] است ، به این معنی که [Code Point] است ، اما فقط آنهایی که در محدوده خاصی هستند.
    /// `MAX` بالاترین نقطه کد معتبر است که [Unicode Scalar Value] معتبر است.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () در یونی کد برای نشان دادن یک خطای رمزگشایی استفاده می شود.
    ///
    /// این می تواند به عنوان مثال ، هنگام دادن بایت UTF-8 بد شکل به [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) رخ دهد.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// نسخه [Unicode](http://www.unicode.org/) که قطعات یونیکد روش های `char` و `str` بر اساس آن ساخته شده اند.
    ///
    /// نسخه های جدید Unicode به طور منظم منتشر می شوند و متعاقباً همه روش ها در کتابخانه استاندارد بسته به Unicode به روز می شوند.
    /// بنابراین رفتار برخی از روش های `char` و `str` و مقدار این ثابت با گذشت زمان تغییر می کند.
    /// این * تغییر شکننده محسوب نمی شود.
    ///
    /// طرح شماره گذاری نسخه در [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) توضیح داده شده است.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// یک تکرار کننده در نقاط کدگذاری شده کد UTF-16 در `iter` ایجاد می کند ، و جایگزین های جفت نشده را به عنوان `Err` برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// با جایگزینی نتایج `Err` با کاراکتر جایگزین می توان رسیور زیان دهی را بدست آورد:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// `u32` را به `char` تبدیل می کند.
    ///
    /// توجه داشته باشید که همه `char` معتبر [`u32`] هستند ، و می توان آنها را با یکی بازیابی کرد
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// با این حال ، عکس این درست نیست: همه "u32" معتبر "char" معتبر نیستند.
    /// `from_u32()` اگر ورودی برای `char` مقدار معتبری نباشد ، `None` را برمی گرداند.
    ///
    /// برای نسخه ناامن این عملکرد که این بررسی ها را نادیده می گیرد ، به [`from_u32_unchecked`] مراجعه کنید.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// بازگشت `None` وقتی ورودی معتبر `char` نباشد:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// با نادیده گرفتن اعتبار ، `u32` را به `char` تبدیل می کند.
    ///
    /// توجه داشته باشید که همه `char` معتبر [`u32`] هستند ، و می توان آنها را با یکی بازیابی کرد
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// با این حال ، عکس این درست نیست: همه "u32" معتبر "char" معتبر نیستند.
    /// `from_u32_unchecked()` این را نادیده می گیرد ، و کورکورانه به `char` می رود ، احتمالاً یک نامعتبر ایجاد می کند.
    ///
    ///
    /// # Safety
    ///
    /// این عملکرد ناامن است ، زیرا ممکن است مقادیر `char` نامعتبر را ایجاد کند.
    ///
    /// برای نسخه ایمن این عملکرد ، به عملکرد [`from_u32`] مراجعه کنید.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // ایمنی: قرارداد ایمنی باید توسط تماس گیرنده تأیید شود.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// رقمی را در شعاع داده شده به `char` تبدیل می کند.
    ///
    /// 'radix' در اینجا گاهی اوقات 'base' نیز نامیده می شود.
    /// شعاع دو نشان می دهد یک عدد باینری ، یک شعبه ده ، دهدهی ، و یک شعاع شانزده ، هگزادسیمال ، برای دادن برخی مقادیر مشترک.
    ///
    /// شعاع خودسرانه پشتیبانی می شود.
    ///
    /// `from_digit()` `None` را برمی گرداند اگر ورودی رقمی در رادیکس داده شده نباشد.
    ///
    /// # Panics
    ///
    /// Panics اگر یک شعاع بزرگتر از 36 به آن داده شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // دهدهی 11 در رقم 16 یک رقمی است
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// بازگشت `None` وقتی ورودی رقمی نیست:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// عبور از یک شعاع بزرگ ، باعث ایجاد panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// بررسی می کند که آیا یک `char` یک رقم در رادیکس داده شده است.
    ///
    /// 'radix' در اینجا گاهی اوقات 'base' نیز نامیده می شود.
    /// شعاع دو نشان می دهد یک عدد باینری ، یک شعبه ده ، دهدهی ، و یک شعاع شانزده ، هگزادسیمال ، برای دادن برخی مقادیر مشترک.
    ///
    /// شعاع خودسرانه پشتیبانی می شود.
    ///
    /// در مقایسه با [`is_numeric()`] ، این عملکرد فقط شخصیت های `0-9` ، `a-z` و `A-Z` را تشخیص می دهد.
    ///
    /// 'Digit' فقط به نویسه های زیر تعریف شده است:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// برای درک جامع تر 'digit' ، به [`is_numeric()`] مراجعه کنید.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics اگر یک شعاع بزرگتر از 36 به آن داده شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// عبور از یک شعاع بزرگ ، باعث ایجاد panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// `char` را به یک رقم در رادیکس داده شده تبدیل می کند.
    ///
    /// 'radix' در اینجا گاهی اوقات 'base' نیز نامیده می شود.
    /// شعاع دو نشان می دهد یک عدد باینری ، یک شعبه ده ، دهدهی ، و یک شعاع شانزده ، هگزادسیمال ، برای دادن برخی مقادیر مشترک.
    ///
    /// شعاع خودسرانه پشتیبانی می شود.
    ///
    /// 'Digit' فقط به نویسه های زیر تعریف شده است:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// اگر `char` به یک رقم در رادیکس داده شده اشاره نکند ، `None` را برمی گرداند.
    ///
    /// # Panics
    ///
    /// Panics اگر یک شعاع بزرگتر از 36 به آن داده شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// تصویب یک رقم غیر رقمی منجر به عدم موفقیت می شود:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// عبور از یک شعاع بزرگ ، باعث ایجاد panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // کد برای بهبود سرعت اجرا در مواردی که `radix` ثابت و 10 یا کوچکتر است ، در اینجا تقسیم شده است
        //
        let val = if likely(radix <= 10) {
            // اگر رقم نباشد ، عددی بزرگتر از radix ایجاد می شود.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// تکرار کننده ای را بازمی گرداند که از Unicode هگزادسیمال یک شخصیت به عنوان `char` فرار می کند.
    ///
    /// این کاراکترها را با نحو Rust از فرم `\u{NNNNNN}` که `NNNNNN` یک نمایش هگزادسیمال است ، فرار می کند.
    ///
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // یا-1 تضمین می کند که برای c==0 کد محاسبه می کند که یک رقم باید چاپ شود و (که همان است) از افت (31 ، 32) جلوگیری می کند
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // شاخص مهمترین رقم هگز
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// نسخه گسترده `escape_debug` که به صورت اختیاری اجازه فرار از رمزهای رمز شده Extended Grapheme را می دهد.
    /// این به ما امکان می دهد که کاراکترها مانند علامت های بدون فاصله را در ابتدای یک رشته بهتر قالب بندی کنیم.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// یک تکرار کننده را بازمی گرداند که کد واقعی فرار از کاراکتر را به عنوان `char` ارائه می دهد.
    ///
    /// این کاراکترهای مشابه پیاده سازی `Debug` `str` یا `char` را فراری می دهد.
    ///
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// یک تکرار کننده را بازمی گرداند که کد واقعی فرار از کاراکتر را به عنوان `char` ارائه می دهد.
    ///
    /// پیش فرض با تعصب نسبت به تولید حروف الفبا که به زبانهای مختلف قانونی است از جمله C++ 11 و زبانهای مشابه خانواده C انتخاب می شود.
    /// قوانین دقیق عبارتند از:
    ///
    /// * Tab به عنوان `\t` فرار می کند.
    /// * از بازگشت کالسکه به عنوان `\r` فرار می شود.
    /// * از خوراک خط به عنوان `\n` فرار می شود.
    /// * نقل قول تنها به عنوان `\'` فرار می کند.
    /// * نقل قول دو برابر به عنوان `\"` فرار کرد.
    /// * Backslash به عنوان `\\` فرار می کند.
    /// * از هیچ شخصیتی در محدوده "قابل چاپ ASCII" `0x20` .. `0x7e` فرار نمی شود.
    /// * به همه کاراکترهای دیگر فرار یونی کد هگزادسیمال داده می شود.به [`escape_unicode`] مراجعه کنید.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// تعداد بایتهایی را که اگر `char` در UTF-8 رمزگذاری شود ، نیاز دارد برمی گرداند.
    ///
    /// این تعداد بایت همیشه شامل 1 تا 4 بیت است.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// نوع `&str` تضمین می کند که محتوای آن UTF-8 است ، بنابراین ما می توانیم مدت زمانی را که هر نقطه کد به عنوان `char` در مقابل `&str` نشان داده می شود مقایسه کنیم:
    ///
    ///
    /// ```
    /// // به عنوان شخصیت های برجسته
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // هر دو را می توان به صورت سه بایت نشان داد
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // به عنوان &str ، این دو در UTF-8 رمزگذاری می شوند
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // می توانیم ببینیم که آنها در کل شش بایت می گیرند ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... درست مثل &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// تعداد واحدهای کد 16 بیتی را که این `char` در صورت رمزگذاری در UTF-16 نیاز دارد برمی گرداند.
    ///
    ///
    /// برای توضیح بیشتر در مورد این مفهوم به اسناد مربوط به [`len_utf8()`] مراجعه کنید.
    /// این عملکرد یک آینه است ، اما برای UTF-16 به جای UTF-8 است.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// این کاراکتر را به عنوان UTF-8 در بافر ارائه شده بایت رمزگذاری می کند و سپس زیرشاخه بافر را که حاوی نویسه رمزگذاری شده است برمی گرداند.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر بافر به اندازه کافی بزرگ نباشد.
    /// بافر طول چهار به اندازه کافی بزرگ است که می تواند هر `char` را رمزگذاری کند.
    ///
    /// # Examples
    ///
    /// در هر دو این مثال ها ، 'ß' دو بایت برای رمزگذاری می گیرد.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// بافر خیلی کوچک:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // ایمنی: `char` جایگزین نیست ، بنابراین این UTF-8 معتبر است.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// این کاراکتر را به عنوان UTF-16 در بافر `u16` ارائه شده رمزگذاری می کند و سپس زیرشاخه بافر حاوی نویسه رمزگذاری شده را برمی گرداند.
    ///
    ///
    /// # Panics
    ///
    /// Panics اگر بافر به اندازه کافی بزرگ نباشد.
    /// بافر طول 2 به اندازه کافی بزرگ است که می تواند هر `char` را رمزگذاری کند.
    ///
    /// # Examples
    ///
    /// در هر دو این مثال ها ، '𝕊' دو رمز u16 را برای رمزگذاری می گیرد.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// بافر خیلی کوچک:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// `true` را برمی گرداند اگر این `char` خاصیت `Alphabetic` را داشته باشد.
    ///
    /// `Alphabetic` در فصل 4 (خصوصیات شخصیت) [Unicode Standard] شرح داده شده و در [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] مشخص شده است.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // عشق چیزهای زیادی است اما الفبایی نیست
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// `true` را برمی گرداند اگر این `char` خاصیت `Lowercase` را داشته باشد.
    ///
    /// `Lowercase` در فصل 4 (خصوصیات شخصیت) [Unicode Standard] شرح داده شده و در [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] مشخص شده است.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // متن های مختلف چینی و علائم نگارشی دارای حروف کوچک نیستند ، و به همین ترتیب:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// `true` را برمی گرداند اگر این `char` خاصیت `Uppercase` را داشته باشد.
    ///
    /// `Uppercase` در فصل 4 (خصوصیات شخصیت) [Unicode Standard] شرح داده شده و در [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] مشخص شده است.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // متن های مختلف چینی و علائم نگارشی دارای حروف کوچک نیستند ، و به همین ترتیب:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// `true` را برمی گرداند اگر این `char` خاصیت `White_Space` را داشته باشد.
    ///
    /// `White_Space` در [Unicode Character Database][ucd] [`PropList.txt`] مشخص شده است.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // یک فضای شکستن
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// `true` را برمی گرداند اگر این `char` یا [`is_alphabetic()`] یا [`is_numeric()`] را برآورده کند.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// `true` را برمی گرداند اگر این `char` دسته عمومی کد کنترل را داشته باشد.
    ///
    /// کدهای کنترل (نقاط کد با دسته عمومی `Cc`) در فصل 4 (خصوصیات شخصیت) [Unicode Standard] شرح داده شده و در [Unicode Character Database][ucd] [`UnicodeData.txt`] مشخص شده است.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// // U + 009C ، ترمینال STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// `true` را برمی گرداند اگر این `char` خاصیت `Grapheme_Extend` را داشته باشد.
    ///
    /// `Grapheme_Extend` در [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] شرح داده شده و در [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] مشخص شده است.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// `true` را برمی گرداند اگر این `char` یکی از دسته های کلی اعداد را داشته باشد.
    ///
    /// دسته های کلی اعداد (`Nd` برای رقم اعشاری ، `Nl` برای حروف عددی مانند حرف و `No` برای سایر نویسه های عددی) در [Unicode Character Database][ucd] [`UnicodeData.txt`] مشخص شده اند.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// یک تکرار کننده را برمی گرداند که نگاشت کوچک این `char` را به صورت یک یا چند بازده ارائه می دهد
    /// `char`s.
    ///
    /// اگر این `char` نگاشت کوچک نداشته باشد ، تکرار کننده همان `char` را ارائه می دهد.
    ///
    /// اگر این `char` دارای یک نقشه کوچک به یک باشد که توسط [Unicode Character Database][ucd] [`UnicodeData.txt`] ارائه شده است ، تکرار کننده آن `char` را ارائه می دهد.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// اگر این `char` به ملاحظات خاصی احتیاج داشته باشد (به عنوان مثال چندین کاراکتر) ، تکرار کننده "کاراکتر" های داده شده توسط [`SpecialCasing.txt`] را تولید می کند.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// این عملیات بدون خیاطی نقشه برداری بدون قید و شرط را انجام می دهد.یعنی تبدیل مستقل از زمینه و زبان است.
    ///
    /// در [Unicode Standard] ، فصل 4 (خصوصیات نویسه) به طور کلی در مورد نگاشت مورد و در فصل 3 (Conformance) در مورد الگوریتم پیش فرض برای تبدیل حروف بحث می کند.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // گاهی اوقات نتیجه بیش از یک شخصیت است:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // شخصیت هایی که هم بزرگ و هم کوچک ندارند به خود تبدیل می شوند.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// یک تکرار کننده را برمی گرداند که نگاشت بزرگ این `char` را به صورت یک یا چند بازده ارائه می دهد
    /// `char`s.
    ///
    /// اگر این `char` نگاشت بزرگ نداشته باشد ، تکرار کننده همان `char` را ارائه می دهد.
    ///
    /// اگر این `char` دارای نگاشت بزرگ یک به یک باشد که توسط [Unicode Character Database][ucd] [`UnicodeData.txt`] ارائه شده است ، تکرار کننده آن `char` را بازده می کند.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// اگر این `char` به ملاحظات خاصی احتیاج داشته باشد (به عنوان مثال چندین کاراکتر) ، تکرار کننده "کاراکتر" های داده شده توسط [`SpecialCasing.txt`] را تولید می کند.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// این عملیات بدون خیاطی نقشه برداری بدون قید و شرط را انجام می دهد.یعنی تبدیل مستقل از زمینه و زبان است.
    ///
    /// در [Unicode Standard] ، فصل 4 (خصوصیات نویسه) به طور کلی در مورد نگاشت مورد و در فصل 3 (Conformance) در مورد الگوریتم پیش فرض برای تبدیل حروف بحث می کند.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // گاهی اوقات نتیجه بیش از یک شخصیت است:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // شخصیت هایی که هم بزرگ و هم کوچک ندارند به خود تبدیل می شوند.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # یادداشت در مورد محلی
    ///
    /// در زبان ترکی ، معادل 'i' در لاتین به جای دو فرم ، پنج شکل دارد:
    ///
    /// * 'Dotless': من/ı ، گاهی اوقات نوشته می شود
    /// * 'Dotted': İ/من
    ///
    /// توجه داشته باشید که حروف کوچک 'i' همان لاتین است.از این رو:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// مقدار `upper_i` در اینجا به زبان متن متکی است: اگر در `en-US` هستیم ، باید `"I"` باشد ، اما اگر در `tr_TR` هستیم ، باید `"İ"` باشد.
    /// `to_uppercase()` این را در نظر نمی گیرد ، و به همین ترتیب:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// در سراسر زبانها نگهداری می شود.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// بررسی می کند که آیا مقدار در محدوده ASCII است.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// کپی از مقدار را با معادل بزرگ ASCII خود می سازد.
    ///
    /// حروف ASCII 'a' تا 'z' با 'A' تا 'Z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بزرگنمایی مقدار در محل ، از [`make_ascii_uppercase()`] استفاده کنید.
    ///
    /// برای نویسه های بزرگ ASCII علاوه بر نویسه های غیر ASCII ، از [`to_uppercase()`] استفاده کنید.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// کپی از مقدار را با معادل کوچک آن ASCII می سازد.
    ///
    /// حروف ASCII 'A' تا 'Z' با 'a' تا 'z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای کوچک کردن مقدار درجا ، از [`make_ascii_lowercase()`] استفاده کنید.
    ///
    /// برای کوچک بودن حروف ASCII علاوه بر نویسه های غیر ASCII ، از [`to_lowercase()`] استفاده کنید.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// بررسی می کند که دو مقدار مطابقت غیر کوچک ASCII ندارند.
    ///
    /// معادل `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// این نوع را به صورت معادل بزرگ در ASCII درجا تبدیل می کند.
    ///
    /// حروف ASCII 'a' تا 'z' با 'A' تا 'Z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بازگرداندن مقدار بزرگ بزرگ بدون تغییر مقدار موجود ، از [`to_ascii_uppercase()`] استفاده کنید.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// این نوع را به معادل کوچک حروف ASCII درجا تبدیل می کند.
    ///
    /// حروف ASCII 'A' تا 'Z' با 'a' تا 'z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بازگرداندن مقدار کوچک جدید بدون تغییر مقدار موجود ، از [`to_ascii_lowercase()`] استفاده کنید.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// بررسی می کند که آیا مقدار یک کاراکتر الفبایی ASCII است:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ، یا
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// بررسی می کند که آیا این مقدار یک حرف بزرگ ASCII است یا خیر:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// بررسی می کند که آیا این مقدار یک حرف کوچک ASCII است:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// بررسی می کند که آیا این مقدار یک کاراکتر عددی عددی ASCII است:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ، یا
    /// - U + 0061 'a' ..=U + 007A 'z' ، یا
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// بررسی می کند که آیا مقدار یک رقم اعشاری ASCII است یا خیر:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// بررسی می کند که آیا مقدار یک رقم هگزادسیمال ASCII است:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' ، یا
    /// - U + 0041 'A' ..=U + 0046 'F' ، یا
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// بررسی می کند که آیا این مقدار یک نویسه نگارشی ASCII است:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /` ، یا
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` ، یا
    /// - U + 005B ..=U + 0060 "[\] ^ _" `` ، یا
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// بررسی می کند که آیا مقدار یک کاراکتر گرافیکی ASCII است:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// بررسی می کند که آیا مقدار یک کاراکتر فضای سفید ASCII است یا خیر:
    /// U + 0020 SPACE ، U + 0009 HORIZONTAL TAB ، U + 000A LINE FEED ، U + 000C FORM FEED ، یا U + 000D CARRIAGE RETURN.
    ///
    /// Rust از WhatWG Infra Standard's [definition of ASCII whitespace][infra-aw] استفاده می کند.چندین تعریف دیگر در استفاده گسترده وجود دارد.
    /// به عنوان مثال ، [the POSIX locale][pct] شامل U + 000B VERTICAL TAB و همچنین همه نویسه های فوق است ، اما-از همان مشخصات-[قانون پیش فرض "field splitting" در Bourne shell][bfs]*فقط* SPACE ، HORIZONTAL TAB و LINE FEED به عنوان فضای سفید.
    ///
    ///
    /// اگر در حال نوشتن برنامه ای هستید که یک قالب پرونده موجود را پردازش می کند ، قبل از استفاده از این عملکرد بررسی کنید که تعریف آن قالب از فضای سفید چیست.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// بررسی می کند که آیا مقدار یک کاراکتر کنترل ASCII است:
    /// U + 0000 NUL ..=U + 001F SEPARATOR UNIT ، یا U + 007F DELETE.
    /// توجه داشته باشید که بیشتر کاراکترهای فضای سفید ASCII شخصیت کنترل هستند ، اما SPACE اینگونه نیست.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// مقدار u32 خام را به عنوان UTF-8 در بافر ارائه شده بایت رمزگذاری می کند و سپس زیرشاخه بافر را که حاوی نویسه رمزگذاری شده است برمی گرداند.
///
///
/// بر خلاف `char::encode_utf8` ، این روش همچنین نقاط رمزگذاری را در محدوده جایگزین اداره می کند.
/// (ایجاد `char` در محدوده جایگزین UB است.) نتیجه [generalized UTF-8] معتبر است اما UTF-8 معتبر نیست.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics اگر بافر به اندازه کافی بزرگ نباشد.
/// بافر طول چهار به اندازه کافی بزرگ است که می تواند هر `char` را رمزگذاری کند.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// مقدار u32 خام را به عنوان UTF-16 در بافر `u16` ارائه شده رمزگذاری می کند و سپس زیرشاخه بافر را که حاوی نویسه رمزگذاری شده است برمی گرداند.
///
///
/// برخلاف `char::encode_utf16` ، این روش همچنین نقاط رمز را در محدوده جایگزین اداره می کند.
/// (ایجاد `char` در محدوده جایگزین UB است.)
///
/// # Panics
///
/// Panics اگر بافر به اندازه کافی بزرگ نباشد.
/// بافر طول 2 به اندازه کافی بزرگ است که می تواند هر `char` را رمزگذاری کند.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // ایمنی: هر بازو بررسی می کند که آیا بیت های کافی برای نوشتن وجود دارد
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP از بین می رود
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // هواپیماهای مکمل به جایگزین ها نفوذ می کنند.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}