//! عملکرد برای سفارش و مقایسه.
//!
//! این ماژول شامل ابزارهای مختلفی برای ترتیب و مقایسه مقادیر است.به طور خلاصه:
//!
//! * [`Eq`] و [`PartialEq`] traits هستند که به شما امکان می دهند به ترتیب برابری کامل و جزئی را بین مقادیر تعیین کنید.
//! اجرای آنها عملگرهای `==` و `!=` را بیش از حد بار می آورد.
//! * [`Ord`] و [`PartialOrd`] traits هستند که به شما امکان می دهند ترتیب های کلی و جزئی را به ترتیب بین مقادیر تعریف کنید.
//!
//! اجرای آنها بیش از حد اپراتورهای `<` ، `<=` ، `>` و `>=` را بارگیری می کند.
//! * [`Ordering`] یک محاسبه است که توسط توابع اصلی [`Ord`] و [`PartialOrd`] بازگردانده می شود ، و یک ترتیب را توصیف می کند.
//! * [`Reverse`] یک ساختار است که به شما امکان می دهد یک سفارش را به راحتی معکوس کنید.
//! * [`max`] و [`min`] توابعی هستند که از [`Ord`] ساخته می شوند و به شما امکان می دهند حداکثر یا حداقل دو مقدار را پیدا کنید.
//!
//! برای جزئیات بیشتر ، به اسناد مربوطه مربوط به هر مورد در لیست مراجعه کنید.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait برای مقایسه برابری که [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) است.
///
/// این trait امکان برابری جزئی را برای انواع مختلفی که رابطه معادل کامل ندارند فراهم می کند.
/// به عنوان مثال ، در شماره های شناور `NaN != NaN` ، بنابراین انواع شناور `PartialEq` را اجرا می کنند اما [`trait@Eq`] را اجرا نمی کنند.
///
/// به طور رسمی ، برابری باید باشد (برای همه `a` ، `b` ، `c` از نوع `A` ، `B` ، `C`):
///
/// - **متقارن**: اگر `A: PartialEq<B>` و `B: PartialEq<A>` ، پس **`a==b` دلالت بر`b==a`**؛و
///
/// - **انتقالی**: اگر `A: PartialEq<B>` و `B: PartialEq<C>` و `A:
///   معادل جزئی<C>`، پس **` a==b`و `b == c` دلالت بر`a==c`**.
///
/// توجه داشته باشید که مدل های `B: PartialEq<A>` (symmetric) و `A: PartialEq<C>` (transitive) اجباری نیستند ، اما این الزامات در هر زمان که وجود داشته باشند اعمال می شوند.
///
/// ## Derivable
///
/// این trait با `#[derive]` قابل استفاده است.هنگامی که `بر روی stts استخراج می شود ، دو نمونه برابر است اگر همه زمینه ها برابر باشند ، و اگر هر فیلد برابر نیستند برابر نیستند.وقتی از enums مشتق می شود ، هر نوع برابر با خودش است و با سایر گزینه ها برابر نیست.
///
/// ## چگونه می توانم `PartialEq` را پیاده سازی کنم؟
///
/// `PartialEq` فقط به پیاده سازی روش [`eq`] نیاز دارد.[`ne`] به صورت پیش فرض از نظر آن تعریف می شود.هرگونه اجرای دستی [`ne`] * باید به این قانون احترام بگذارد که [`eq`] کاملاً معکوس [`ne`] است.یعنی `!(a == b)` اگر و فقط اگر `a != b` باشد.
///
/// اجرای `PartialEq` ، [`PartialOrd`] و [`Ord`]*باید* با یکدیگر توافق داشته باشند.آسان است که با استخراج برخی از traits و اجرای دستی برخی دیگر ، آنها را به طور تصادفی مخالف کنید.
///
/// یک مثال پیاده سازی برای دامنه ای که در آن دو کتاب در صورت مطابقت ISBN با یک کتاب در نظر گرفته می شوند ، حتی اگر قالب ها متفاوت باشند:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## چگونه می توانم دو نوع مختلف را مقایسه کنم؟
///
/// نوعی که می توانید با آن مقایسه کنید توسط پارامتر نوع `PartialEq` کنترل می شود.
/// به عنوان مثال ، بیایید کد قبلی خود را کمی تغییر دهیم:
///
/// ```
/// // استخراج پیاده سازی می کند<BookFormat>==<BookFormat>مقایسه
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // پیاده سازی<Book>==<BookFormat>مقایسه
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // پیاده سازی<BookFormat>==<Book>مقایسه
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// با تغییر `impl PartialEq for Book` به `impl PartialEq<BookFormat> for Book` ، اجازه می دهیم `BookFormat` با`Book` مقایسه شود.
///
/// مقایسه ای مانند مقایسه فوق ، که برخی از زمینه های ساختار را نادیده می گیرد ، می تواند خطرناک باشد.به راحتی می تواند منجر به نقض ناخواسته الزامات مربوط به یک رابطه هم ارز جزئی شود.
/// به عنوان مثال ، اگر ما اجرای فوق `PartialEq<Book>` را برای `BookFormat` حفظ کنیم و یک پیاده سازی `PartialEq<Book>` را برای `Book` اضافه کنیم (یا از طریق `#[derive]` یا از طریق پیاده سازی دستی از مثال اول) ، نتیجه این امر انتقال را نقض می کند:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// این روش آزمایش می کند که مقادیر `self` و `other` برابر باشد و توسط `==` استفاده می شود.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// این روش برای `!=` تست می شود.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// تولید ماکرو تولید impl از trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait برای مقایسه برابری که [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) است.
///
/// این بدان معناست که علاوه بر این که `a == b` و `a != b` معکوس دقیق هستند ، برابری باید (برای همه `a` ، `b` و `c`) باشد:
///
/// - reflexive: `a == a`;
/// - متقارن: `a == b` حاوی `b == a` است.و
/// - انتقالی: `a == b` و `b == c` حاوی `a == c` است.
///
/// این ویژگی توسط کامپایلر قابل بررسی نیست و بنابراین `Eq` حاوی [`PartialEq`] است و هیچ روش اضافی ندارد.
///
/// ## Derivable
///
/// این trait با `#[derive]` قابل استفاده است.
/// هنگامی که `مشتق` d می شود ، زیرا `Eq` روش اضافی ندارد ، فقط به کامپایلر اطلاع می دهد که این یک رابطه هم ارز است تا یک رابطه هم ارز جزئی.
///
/// توجه داشته باشید که استراتژی `derive` به تمام قسمتها `Eq` نیاز دارد ، که همیشه مورد نظر نیست.
///
/// ## چگونه می توانم `Eq` را پیاده سازی کنم؟
///
/// اگر نمی توانید از استراتژی `derive` استفاده کنید ، مشخص کنید که نوع شما `Eq` را اجرا کند ، که هیچ روشی ندارد:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // این روش صرفاً توسط#[مشتق] استفاده می شود تا ادعا شود كه هر م componentلفه از یك نوع خود#را استخراج می كند ، زیرساخت مشتق شده فعلی به معنای انجام این ادعا بدون استفاده از روشی در این trait تقریباً غیرممكن است.
    //
    //
    // این امر هرگز نباید با دست اجرا شود.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// تولید ماکرو تولید impl از trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: این ساختار فقط توسط#[مشتق] استفاده می شود
// ادعا کنید که هر جز component از یک نوع Eq را پیاده سازی می کند.
//
// این ساختار هرگز نباید در کد کاربر ظاهر شود.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` نتیجه مقایسه بین دو مقدار است.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// یک سفارش که در آن یک مقدار مقایسه شده کمتر از دیگری است.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// نظمی که در آن یک مقدار مقایسه شده برابر با دیگری است.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// نظمی که در آن مقدار مقایسه شده بیشتر از مقدار دیگر باشد.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// اگر سفارش نوع `Equal` باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// اگر سفارش نوع `Equal` نباشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// اگر سفارش نوع `Less` باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// اگر سفارش نوع `Greater` باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// اگر سفارش از نوع `Less` یا `Equal` باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// اگر سفارش از نوع `Greater` یا `Equal` باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` را معکوس می کند.
    ///
    /// * `Less` `Greater` می شود.
    /// * `Greater` `Less` می شود.
    /// * `Equal` `Equal` می شود.
    ///
    /// # Examples
    ///
    /// رفتار اساسی:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// از این روش می توان برای معکوس کردن مقایسه استفاده کرد:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // آرایه را از بزرگترین به کوچکترین مرتب کنید.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// زنجیر دو سفارش.
    ///
    /// `self` را هنگامی که `Equal` نباشد برمی گرداند.در غیر این صورت `other` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ترتیب را با عملکرد داده شده زنجیره می کند.
    ///
    /// `self` را `Equal` بر نمی گرداند.
    /// در غیر این صورت با `f` تماس گرفته و نتیجه را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// ساختار کمکی برای سفارش معکوس.
///
/// این ساختار کمکی است که در توابع مانند [`Vec::sort_by_key`] استفاده می شود و می تواند برای ترتیب معکوس بخشی از کلید استفاده شود.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait برای انواع تشکیل دهنده [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// یک سفارش در صورت وجود یک سفارش کل است (برای همه `a` ، `b` و `c`):
///
/// - کل و نامتقارن: دقیقاً یکی از `a < b` ، `a == b` یا `a > b` درست است.و
/// - گذرا ، `a < b` و `b < c` حاوی `a < c` است.برای هر دو `==` و `>` باید همین مورد وجود داشته باشد.
///
/// ## Derivable
///
/// این trait با `#[derive]` قابل استفاده است.
/// هنگامی که از stet استخراج می شود ، یک سفارش [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) بر اساس ترتیب اعلان از بالا به پایین اعضای ساختار تولید می کند.
///
/// وقتی از enums مشتق می شود ، انواع با توجه به ترتیب تفکیک پذیری آنها از بالا به پایین مرتب می شوند.
///
/// ## مقایسه فرهنگ لغت
///
/// مقایسه واژگانی عملیاتی با خصوصیات زیر است:
///  - دو دنباله عنصر به عنصر مقایسه می شوند.
///  - اولین عنصر عدم تطابق تعریف می کند که کدام توالی از نظر فرهنگ لغت کمتر یا بیشتر از دیگری است.
///  - اگر یک دنباله پیشوند دیگری باشد ، دنباله کوتاه تر از نظر فرهنگ لغت کمتر از دیگری است.
///  - اگر دو دنباله عناصر معادل داشته و از طول یکسانی برخوردار باشند ، پس توالی ها از نظر فرهنگ لغت برابر هستند.
///  - یک توالی خالی از نظر فرهنگ لغت کمتر از هر سکانس غیر خالی است.
///  - دو دنباله خالی از نظر فرهنگ لغت برابر هستند.
///
/// ## چگونه می توانم `Ord` را پیاده سازی کنم؟
///
/// `Ord` ایجاب می کند که نوع [`PartialOrd`] و [`Eq`] نیز باشد (که به [`PartialEq`] نیاز دارد).
///
/// سپس باید یک پیاده سازی برای [`cmp`] تعریف کنید.ممکن است استفاده از [`cmp`] در قسمتهای نوع خود مفید باشد.
///
/// اجرای [`PartialEq`] ، [`PartialOrd`] و `Ord`*باید* با یکدیگر توافق داشته باشند.
/// یعنی `a.cmp(b) == Ordering::Equal` اگر و فقط اگر `a == b` و `Some(a.cmp(b)) == a.partial_cmp(b)` برای همه `a` و `b` باشد.
/// آسان است که با استخراج برخی از traits و اجرای دستی برخی دیگر ، آنها را به طور تصادفی مخالف کنید.
///
/// در اینجا مثالی آورده شده است که می خواهید افراد را بر اساس قد و بدون توجه به `id` و `name` مرتب کنید:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// این روش [`Ordering`] را بین `self` و `other` برمی گرداند.
    ///
    /// طبق قرارداد ، `self.cmp(&other)` در صورت درست بودن ترتیب مطابق با عبارت `self <operator> other` را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// حداکثر دو مقدار را مقایسه و برمی گرداند.
    ///
    /// اگر مقایسه برابر بودن آنها را مشخص کند ، آرگومان دوم را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// حداقل دو مقدار را مقایسه و برمی گرداند.
    ///
    /// اگر مقایسه برابر بودن آنها را مشخص کند ، اولین استدلال را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// یک مقدار را به یک بازه خاص محدود کنید.
    ///
    /// اگر `self` بزرگتر از `max` باشد `max` و اگر `self` کمتر از `min` باشد `min` برمی گرداند.
    /// در غیر این صورت این `self` را برمی گرداند.
    ///
    /// # Panics
    ///
    /// Panics اگر `min > max` باشد.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// تولید ماکرو تولید impl از trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait برای مقادیر قابل مقایسه برای ترتیب مرتب سازی.
///
/// مقایسه باید برای همه `a` ، `b` و `c` مطابقت داشته باشد:
///
/// - عدم تقارن: اگر `a < b` سپس `!(a > b)` باشد ، و همچنین `a > b` حاوی `!(a < b)` است.و
/// - انتقال پذیری: `a < b` و `b < c` حاوی `a < c` است.برای هر دو `==` و `>` باید همین مورد وجود داشته باشد.
///
/// توجه داشته باشید که این الزامات بدان معناست که trait خود باید به صورت متقارن و انتقالی اجرا شود: اگر `T: PartialOrd<U>` و `U: PartialOrd<V>` پس `U: PartialOrd<T>` و `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// این trait با `#[derive]` قابل استفاده است.هنگامی که از stet استخراج می شود ، یک ترتیب فرهنگ لغوی بر اساس ترتیب اعلان از بالا به پایین اعضای ساختار ایجاد می کند.
/// وقتی از enums مشتق می شود ، انواع با توجه به ترتیب تفکیک پذیری آنها از بالا به پایین مرتب می شوند.
///
/// ## چگونه می توانم `PartialOrd` را پیاده سازی کنم؟
///
/// `PartialOrd` فقط به پیاده سازی روش [`partial_cmp`] نیاز دارد ، بقیه از تولیدات پیش فرض تولید می شوند.
///
/// با این وجود ، امکان پیاده سازی سایر موارد جداگانه برای انواع فاقد ترتیب کلی وجود دارد.
/// به عنوان مثال ، برای اعداد شناور ، `NaN < 0 == false` و `NaN >= 0 == false` (ر.ک.
/// IEEE 754-2008 بخش 5.11).
///
/// `PartialOrd` نیاز دارد که نوع شما [`PartialEq`] باشد.
///
/// اجرای [`PartialEq`] ، `PartialOrd` و [`Ord`]*باید* با یکدیگر توافق داشته باشند.
/// آسان است که با استخراج برخی از traits و اجرای دستی برخی دیگر ، آنها را به طور تصادفی مخالف کنید.
///
/// اگر نوع شما [`Ord`] است ، می توانید با استفاده از [`cmp`] [`partial_cmp`] را پیاده سازی کنید:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// همچنین ممکن است استفاده از [`partial_cmp`] در قسمتهای نوع خود مفید باشد.
/// در اینجا مثالی از انواع `Person` آورده شده است که دارای یک قسمت شناور `height` است که تنها فیلدی است که برای مرتب سازی استفاده می شود:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// این روش در صورت وجود نظمی بین مقادیر `self` و `other` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// وقتی مقایسه غیرممکن است:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// این روش کمتر از (برای `self` و `other`) آزمایش می کند و توسط اپراتور `<` استفاده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// این روش کمتر (یا برای `self` و `other`) آزمایش می کند و توسط اپراتور `<=` استفاده می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// این روش بیشتر از (برای `self` و `other`) آزمایش می شود و توسط اپراتور `>` استفاده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// این روش آزمایش بزرگتر یا مساوی (برای `self` و `other`) است و توسط اپراتور `>=` استفاده می شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// تولید ماکرو تولید impl از trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// حداقل دو مقدار را مقایسه و برمی گرداند.
///
/// اگر مقایسه برابر بودن آنها را مشخص کند ، اولین استدلال را برمی گرداند.
///
/// در داخل از نام مستعار [`Ord::min`] استفاده می کند.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// حداقل دو مقدار را با توجه به تابع مقایسه مشخص شده برمی گرداند.
///
/// اگر مقایسه برابر بودن آنها را مشخص کند ، اولین استدلال را برمی گرداند.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// عنصری را که حداقل مقدار را از تابع مشخص شده می دهد ، برمی گرداند.
///
/// اگر مقایسه برابر بودن آنها را مشخص کند ، اولین استدلال را برمی گرداند.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// حداکثر دو مقدار را مقایسه و برمی گرداند.
///
/// اگر مقایسه برابر بودن آنها را مشخص کند ، آرگومان دوم را برمی گرداند.
///
/// در داخل از نام مستعار [`Ord::max`] استفاده می کند.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// حداکثر دو مقدار را با توجه به تابع مقایسه مشخص شده برمی گرداند.
///
/// اگر مقایسه برابر بودن آنها را مشخص کند ، آرگومان دوم را برمی گرداند.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// عنصری را که حداکثر مقدار را از تابع مشخص شده می دهد ، برمی گرداند.
///
/// اگر مقایسه برابر بودن آنها را مشخص کند ، آرگومان دوم را برمی گرداند.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// پیاده سازی PartialEq ، Eq ، PartialOrd و Ord برای انواع اولیه
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // منظور در اینجا برای تولید مونتاژ بهینه تر مهم است.
                    // برای اطلاعات بیشتر به <https://github.com/rust-lang/rust/issues/63758> مراجعه کنید.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // ریخته گری به i8 و تبدیل تفاوت به ترتیب مونتاژ بهینه تری ایجاد می کند.
            //
            // برای اطلاعات بیشتر به <https://github.com/rust-lang/rust/issues/66780> مراجعه کنید.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // ایمنی: bool همانطور که i8 0 یا 1 برمی گرداند ، بنابراین تفاوت نمی تواند چیز دیگری باشد
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &نشانگرها

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}