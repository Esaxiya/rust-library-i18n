//! پشتیبانی Panic از libcore
//!
//! کتابخانه اصلی نمی تواند رعب و وحشت را تعریف کند ، اما *اعلام* وحشت می کند.
//! این بدان معناست که توابع داخل libcore به panic مجاز هستند ، اما برای مفید بودن crate بالادستی باید وحشت را برای استفاده از libcore تعریف کند.
//! رابط فعلی برای ایجاد وحشت:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! این تعریف امکان ایجاد وحشت با هر پیام عمومی را فراهم می کند ، اما شکست با مقدار `Box<Any>` را مجاز نمی داند.
//! (`PanicInfo` فقط حاوی `&(dyn Any + Send)` است که برای آن یک مقدار ساختگی در "PanicInfo: : internal_constructor" پر می کنیم.) دلیل این امر این است که libcore مجاز به تخصیص نیست.
//!
//!
//! این ماژول شامل چند توابع وحشت زدایی دیگر است ، اما اینها فقط موارد لازم برای کامپایلر هستند.همه panics از طریق این یک عملکرد هدایت می شوند.
//! نماد واقعی از طریق ویژگی `#[panic_handler]` اعلام می شود.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// پیاده سازی اساسی ماکرو `panic!` libcore هنگامی که از قالب بندی استفاده نمی شود.
#[cold]
// برای جلوگیری از نفوذ کد در سایتهای تماس تا آنجا که ممکن است هرگز درون خطی نکنید مگر اینکه panic_immed_abort شود
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // مورد نیاز codegen برای panic در سرریز و سایر ترمیناتورهای `Assert` MIR
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // از Arguments::new_v1 به جای format_args استفاده کنید! ("{}" ، expr) برای کاهش بالقوه اندازه سربار.
    // فرمت_ارگ!ماکرو برای نوشتن expr از Display trait str استفاده می کند ، که Formatter::pad را فراخوانی می کند ، که باید کوتاه کردن و پر کردن رشته را در خود جای دهد (حتی اگر در اینجا هیچ کدام استفاده نمی شود).
    //
    // استفاده از Arguments::new_v1 ممکن است به کامپایلر اجازه دهد Formatter::pad را از باینری خروجی حذف کند و تا چند کیلوبایت صرفه جویی کند.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // مورد نیاز برای ارزیابی panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // مورد نیاز codegen برای panic در دسترسی OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// پیاده سازی اساسی ماکرو `panic!` libcore هنگام استفاده از قالب بندی.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // توجه: این عملکرد هرگز از مرز FFI عبور نمی کند.این یک تماس Rust-to-Rust است که به عملکرد `#[panic_handler]` برطرف می شود.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ایمنی: `panic_impl` در کد امن Rust تعریف شده و بنابراین تماس با آن بی خطر است.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// عملکرد داخلی برای ماکروهای `assert_eq!` و `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}