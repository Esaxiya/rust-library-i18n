//! ذاتی کامپایلر.
//!
//! تعاریف مربوطه در `compiler/rustc_codegen_llvm/src/intrinsic.rs` است.
//! پیاده سازی های مربوطه در `compiler/rustc_mir/src/interpret/intrinsics.rs` هستند
//!
//! # ذاتی ساختنی
//!
//! Note: هر گونه تغییر در ثبات ذاتی ها باید با تیم زبان مورد بحث قرار گیرد.
//! این شامل تغییراتی در ثبات ثبات است.
//!
//! برای اینکه یک ذاتی در زمان کامپایل قابل استفاده باشد ، باید کپی پیاده سازی را از <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> به `compiler/rustc_mir/src/interpret/intrinsics.rs` انجام دهید و `#[rustc_const_unstable(feature = "foo", issue = "01234")]` را به ذات خود اضافه کنید.
//!
//!
//! اگر قرار باشد از ذاتی از `const fn` با ویژگی `rustc_const_stable` استفاده شود ، ویژگی ذاتی نیز باید `rustc_const_stable` باشد.
//! چنین تغییری نباید بدون مشاوره T-lang انجام شود ، زیرا ویژگی را به زبانی تبدیل می کند که بدون پشتیبانی کامپایلر در کد کاربر قابل تکرار نیست.
//!
//! # Volatiles
//!
//! ذاتی فرار ، عملیاتی را در نظر گرفته اند که بر روی حافظه I/O عمل می کنند ، و تضمین می شود که توسط کامپایلر در سایر مواد ذاتی فرار ترتیب مجدد داده نمی شود.به اسناد LLVM در [[volatile]] مراجعه کنید.
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! ذات اتمی با چندین مرتبه ترتیب حافظه ، عملیات اتمی مشترک روی کلمات ماشین را ارائه می دهند.آنها از همان معناشناسی C++ 11 پیروی می کنند.به اسناد LLVM در [[atomics]] مراجعه کنید.
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! تازه کردن سریع سفارش حافظه:
//!
//! * اکتساب ، مانعی برای دستیابی به قفل.خواندن و نوشتن بعدی پس از مانع صورت می گیرد.
//! * رها کردن ، مانعی برای آزاد کردن قفل است.مقدمه خواندن و نوشتن قبل از مانع صورت می گیرد.
//! * عملیات متوالی و متوالی تضمین می شود که به ترتیب اتفاق بیفتد.این حالت استاندارد برای کار با انواع اتمی است و معادل Java's `volatile` است.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// این واردات برای ساده سازی پیوندهای داخل Doc استفاده می شود
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ایمنی: به `ptr::drop_in_place` مراجعه کنید
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // توجه: این ذاتی ها نشانگرهای خام می گیرند زیرا حافظه نام مستعار را جهش می دهند ، که برای `&` یا `&mut` معتبر نیست.
    //

    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان پارامترهای `success` و `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    ///
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان پارامترهای `success` و `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    ///
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `success` و [`Ordering::Acquire`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان پارامترهای `success` و `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    ///
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `success` و [`Ordering::Acquire`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان پارامترهای `success` و `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    ///
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان پارامترهای `success` و `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    ///
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `success` و [`Ordering::Acquire`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان پارامترهای `success` و `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    ///
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `success` و [`Ordering::Acquire`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// اگر مقدار فعلی همان مقدار `old` باشد ، مقداری را ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `success` و [`Ordering::Relaxed`] به عنوان پارامترهای `failure` در انواع [`atomic`] از طریق روش `compare_exchange_weak` در دسترس است.
    /// مثلا، [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// مقدار فعلی نشانگر را بارگیری می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `load` در دسترس است.
    /// مثلا، [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// مقدار فعلی نشانگر را بارگیری می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در انواع [`atomic`] از طریق روش `load` در دسترس است.
    /// مثلا، [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// مقدار فعلی نشانگر را بارگیری می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `load` در دسترس است.
    /// مثلا، [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// مقدار را در محل حافظه مشخص شده ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `store` در دسترس است.
    /// مثلا، [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// مقدار را در محل حافظه مشخص شده ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در انواع [`atomic`] از طریق روش `store` در دسترس است.
    /// مثلا، [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// مقدار را در محل حافظه مشخص شده ذخیره می کند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `store` در دسترس است.
    /// مثلا، [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// مقدار را در محل حافظه مشخص شده ذخیره می کند ، مقدار قدیمی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `swap` در دسترس است.
    /// مثلا، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// مقدار را در محل حافظه مشخص شده ذخیره می کند ، مقدار قدیمی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در انواع [`atomic`] از طریق روش `swap` در دسترس است.
    /// مثلا، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// مقدار را در محل حافظه مشخص شده ذخیره می کند ، مقدار قدیمی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در انواع [`atomic`] از طریق روش `swap` در دسترس است.
    /// مثلا، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// مقدار را در محل حافظه مشخص شده ذخیره می کند ، مقدار قدیمی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در انواع [`atomic`] از طریق روش `swap` در دسترس است.
    /// مثلا، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// مقدار را در محل حافظه مشخص شده ذخیره می کند ، مقدار قدیمی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `swap` در دسترس است.
    /// مثلا، [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// به مقدار فعلی اضافه می کند و مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_add` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// به مقدار فعلی اضافه می کند و مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_add` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// به مقدار فعلی اضافه می کند و مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_add` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// به مقدار فعلی اضافه می کند و مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_add` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// به مقدار فعلی اضافه می کند و مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_add` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// از مقدار فعلی کم کنید و مقدار قبلی را برگردانید.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_sub` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// از مقدار فعلی کم کنید و مقدار قبلی را برگردانید.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_sub` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// از مقدار فعلی کم کنید و مقدار قبلی را برگردانید.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_sub` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// از مقدار فعلی کم کنید و مقدار قبلی را برگردانید.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_sub` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// از مقدار فعلی کم کنید و مقدار قبلی را برگردانید.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_sub` در دسترس است.
    /// مثلا، [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// بیت و با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_and` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_and` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_and` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_and` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_and` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// بیت و با مقدار فعلی و بازگشت مقدار قبلی.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی از طریق `fetch_nand` با عبور از [`Ordering::SeqCst`] به عنوان `order` در نوع [`AtomicBool`] در دسترس است.
    /// مثلا، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی و بازگشت مقدار قبلی.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی از طریق `fetch_nand` با عبور از [`Ordering::Acquire`] به عنوان `order` در نوع [`AtomicBool`] در دسترس است.
    /// مثلا، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی و بازگشت مقدار قبلی.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی از طریق `fetch_nand` با عبور از [`Ordering::Release`] به عنوان `order` در نوع [`AtomicBool`] در دسترس است.
    /// مثلا، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی و بازگشت مقدار قبلی.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی از طریق `fetch_nand` با عبور از [`Ordering::AcqRel`] به عنوان `order` در نوع [`AtomicBool`] در دسترس است.
    /// مثلا، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت و با مقدار فعلی و بازگشت مقدار قبلی.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی از طریق `fetch_nand` با عبور از [`Ordering::Relaxed`] به عنوان `order` در نوع [`AtomicBool`] در دسترس است.
    /// مثلا، [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// بیت یا با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_or` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت یا با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_or` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت یا با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_or` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت یا با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_or` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// بیت یا با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_or` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// xor بیت با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_xor` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor بیت با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_xor` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor بیت با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_xor` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor بیت با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_xor` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// xor بیت با مقدار فعلی ، مقدار قبلی را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با عبور از [`Ordering::Relaxed`] به عنوان `order` در انواع [`atomic`] از طریق روش `fetch_xor` در دسترس است.
    /// مثلا، [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// حداکثر با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::SeqCst`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Acquire`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Release`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::AcqRel`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Relaxed`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// حداقل با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::SeqCst`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Acquire`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Release`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::AcqRel`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه امضا شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Relaxed`] به عنوان `order` در انواع صحیح امضا شده [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// حداقل با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::SeqCst`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Acquire`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Release`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::AcqRel`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] در دسترس است.
    /// مثلا، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداقل با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Relaxed`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_min` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// حداکثر با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::SeqCst`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Acquire`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Release`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::AcqRel`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// حداکثر با مقدار فعلی با استفاده از مقایسه بدون امضا.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی با گذراندن [`Ordering::Relaxed`] به عنوان `order` در انواع صحیح بدون علامت [`atomic`] از طریق روش `fetch_max` در دسترس است.
    /// مثلا، [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` ذاتی اشاره ای به مولد کد است تا در صورت پشتیبانی ، یک دستورالعمل پیش فرض را وارد کند.در غیر این صورت ، این یک ممنوع الکار است.
    /// پیش بارها تاثیری در رفتار برنامه ندارند اما می توانند ویژگی های عملکرد آن را تغییر دهند.
    ///
    /// آرگومان `locality` باید یک عدد صحیح ثابت باشد و یک مکان یاب محلی است که از (0) ، بدون مکان ، تا (3) متغیر است ، و در محلی که حافظه پنهان است بسیار محلی است.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` ذاتی اشاره ای به مولد کد است تا در صورت پشتیبانی ، یک دستورالعمل پیش فرض را وارد کند.در غیر این صورت ، این یک ممنوع الکار است.
    /// پیش بارها تاثیری در رفتار برنامه ندارند اما می توانند ویژگی های عملکرد آن را تغییر دهند.
    ///
    /// آرگومان `locality` باید یک عدد صحیح ثابت باشد و یک مکان یاب محلی است که از (0) ، بدون مکان ، تا (3) متغیر است ، و در محلی که حافظه پنهان است بسیار محلی است.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` ذاتی اشاره ای به مولد کد است تا در صورت پشتیبانی ، یک دستورالعمل پیش فرض را وارد کند.در غیر این صورت ، این یک ممنوع الکار است.
    /// پیش بارها تاثیری در رفتار برنامه ندارند اما می توانند ویژگی های عملکرد آن را تغییر دهند.
    ///
    /// آرگومان `locality` باید یک عدد صحیح ثابت باشد و یک مکان یاب محلی است که از (0) ، بدون مکان ، تا (3) متغیر است ، و در محلی که حافظه پنهان است بسیار محلی است.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` ذاتی اشاره ای به مولد کد است تا در صورت پشتیبانی ، یک دستورالعمل پیش فرض را وارد کند.در غیر این صورت ، این یک ممنوع الکار است.
    /// پیش بارها تاثیری در رفتار برنامه ندارند اما می توانند ویژگی های عملکرد آن را تغییر دهند.
    ///
    /// آرگومان `locality` باید یک عدد صحیح ثابت باشد و یک مکان یاب محلی است که از (0) ، بدون مکان ، تا (3) متغیر است ، و در محلی که حافظه پنهان است بسیار محلی است.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// حصار اتمی.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در [`atomic::fence`] در دسترس است.
    ///
    ///
    pub fn atomic_fence();
    /// حصار اتمی.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در [`atomic::fence`] در دسترس است.
    ///
    ///
    pub fn atomic_fence_acq();
    /// حصار اتمی.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در [`atomic::fence`] در دسترس است.
    ///
    ///
    pub fn atomic_fence_rel();
    /// حصار اتمی.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در [`atomic::fence`] در دسترس است.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// مانع حافظه فقط کامپایلر.
    ///
    /// دسترسی به حافظه هرگز توسط این کامپایلر از طریق این سد مرتب نمی شود ، اما هیچ دستورالعملی برای آن صادر نمی شود.
    /// این برای عملیات روی همان موضوعی که ممکن است از قبل استفاده شود ، مانند هنگام تعامل با کنترل کننده های سیگنال مناسب است.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::SeqCst`] به عنوان `order` در [`atomic::compiler_fence`] در دسترس است.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// مانع حافظه فقط کامپایلر.
    ///
    /// دسترسی به حافظه هرگز توسط این کامپایلر از طریق این سد مرتب نمی شود ، اما هیچ دستورالعملی برای آن صادر نمی شود.
    /// این برای عملیات روی همان موضوعی که ممکن است از قبل استفاده شود ، مانند هنگام تعامل با کنترل کننده های سیگنال مناسب است.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::Acquire`] به عنوان `order` در [`atomic::compiler_fence`] در دسترس است.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// مانع حافظه فقط کامپایلر.
    ///
    /// دسترسی به حافظه هرگز توسط این کامپایلر از طریق این سد مرتب نمی شود ، اما هیچ دستورالعملی برای آن صادر نمی شود.
    /// این برای عملیات روی همان موضوعی که ممکن است از قبل استفاده شود ، مانند هنگام تعامل با کنترل کننده های سیگنال مناسب است.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::Release`] به عنوان `order` در [`atomic::compiler_fence`] در دسترس است.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// مانع حافظه فقط کامپایلر.
    ///
    /// دسترسی به حافظه هرگز توسط این کامپایلر از طریق این سد مرتب نمی شود ، اما هیچ دستورالعملی برای آن صادر نمی شود.
    /// این برای عملیات روی همان موضوعی که ممکن است از قبل استفاده شود ، مانند هنگام تعامل با کنترل کننده های سیگنال مناسب است.
    ///
    /// نسخه تثبیت شده این ذاتی با عبور از [`Ordering::AcqRel`] به عنوان `order` در [`atomic::compiler_fence`] در دسترس است.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// سحر و جادو ذاتی که معنی خود را از ویژگی های متصل به تابع می گیرد.
    ///
    /// به عنوان مثال ، گردش داده از این امر برای تزریق ادعاهای استاتیک استفاده می کند تا `rustc_peek(potentially_uninitialized)` در واقع بررسی کند که آیا جریان داده در واقع محاسبه می کند که در آن نقطه از جریان کنترل به چه صورت اولیه نیست.
    ///
    ///
    /// این ماده ذاتی نباید در خارج از کامپایلر استفاده شود.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// از اجرای فرایند جلوگیری می کند.
    ///
    /// نسخه کاربرپسند و پایدارتر از این عملکرد [`std::process::abort`](../../std/process/fn.abort.html) است.
    ///
    pub fn abort() -> !;

    /// به بهینه ساز اطلاع می دهد که این قسمت از کد قابل دسترسی نیست و بهینه سازی های بعدی را امکان پذیر می کند.
    ///
    /// توجه داشته باشید ، این بسیار متفاوت با ماکرو `unreachable!()` است: برخلاف ماکرو که panics هنگام اجرای آن اجرا می شود ، رسیدن به کدی که با این عملکرد مشخص شده است * یک رفتار تعریف نشده است.
    ///
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked) است.
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// بهینه ساز را مطلع می کند که یک شرط همیشه درست است.
    /// اگر شرایط نادرست باشد ، رفتار تعریف نشده است.
    ///
    /// هیچ کدی برای این ماده ذاتی تولید نمی شود ، اما بهینه ساز سعی می کند آن (و شرایط آن) را بین پاسها حفظ کند ، که ممکن است در بهینه سازی کد اطراف تداخل ایجاد کند و عملکرد را کاهش دهد.
    /// اگر بدون تغییر توسط خود بهینه ساز به صورت خودکار تغییر شود ، یا اگر هیچ بهینه سازی قابل توجهی را فعال نکند ، نباید از آن استفاده شود.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// به کامپایلر اشاره می کند که احتمالاً شرایط branch درست است.
    /// مقدار ارسال شده به آن را برمی گرداند.
    ///
    /// هر کاربرد دیگری غیر از دستورات `if` احتمالاً تاثیری نخواهد داشت.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// به کامپایلر اشاره می کند که احتمالاً شرایط branch نادرست است.
    /// مقدار ارسال شده به آن را برمی گرداند.
    ///
    /// هر کاربرد دیگری غیر از دستورات `if` احتمالاً تاثیری نخواهد داشت.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// یک دامنه breakpoint را برای بازرسی توسط اشکال زدا اجرا می کند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn breakpoint();

    /// اندازه یک نوع در بایت.
    ///
    /// به طور خاص ، این جابجایی بایت بین موارد متوالی از همان نوع ، از جمله padding تراز است.
    ///
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::mem::size_of`](crate::mem::size_of) است.
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// حداقل تراز بودن یک نوع.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::mem::align_of`](crate::mem::align_of) است.
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// تراز دلخواه یک نوع.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// اندازه مقدار ارجاع شده در بایت.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`mem::size_of_val`] است.
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// تراز بندی مورد نیاز مقدار ارجاع شده.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::mem::align_of_val`](crate::mem::align_of_val) است.
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// یک برش رشته استاتیک حاوی نام یک نوع می گیرد.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::any::type_name`](crate::any::type_name) است.
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// شناسه ای دریافت می کند که در سطح جهانی خاص نوع مشخص شده است.
    /// این تابع بدون در نظر گرفتن هر کدام از crate که فراخوانده می شود ، همان مقدار را برای یک نوع برمی گرداند.
    ///
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::any::TypeId::of`](crate::any::TypeId::of) است.
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// محافظ عملکردهای ناامن که در صورت خالی بودن `T` هرگز قابل اجرا نیست:
    /// این از نظر آماری یا panic خواهد بود ، یا کاری انجام نمی دهد.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// محافظی برای عملکردهای غیر ایمن که اگر `T` مقداردهی اولیه را مجاز نباشد ، هرگز قابل اجرا نیست: این از نظر آماری panic است یا کاری نمی کند.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn assert_zero_valid<T>();

    /// محافظ عملکردهای ناامن که اگر `T` دارای الگوهای بیت نامعتبر باشد ، هرگز قابل اجرا نیست: این از نظر آماری یا panic است ، یا هیچ کاری انجام نمی دهد.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn assert_uninit_valid<T>();

    /// به یک `Location` ثابت اشاره می کند که محل فراخوانی آن را نشان می دهد.
    ///
    /// به جای استفاده از [`core::panic::Location::caller`](crate::panic::Location::caller) در نظر بگیرید.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// بدون استفاده از چسب قطره ، مقداری را از محدوده خارج می کند.
    ///
    /// این فقط برای [`mem::forget_unsized`] وجود دارد.`forget` معمولی به جای آن از `ManuallyDrop` استفاده می کند.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// بیت های مقدار یک نوع را به عنوان نوع دیگر تفسیر می کند.
    ///
    /// اندازه هر دو نوع باید یکسان باشد.
    /// نه اصلی و نه نتیجه ممکن است [invalid value](../../nomicon/what-unsafe-does.html) باشد.
    ///
    /// `transmute` از نظر معنایی معادل حرکت ذره ای از یک نوع به نوع دیگر است.بیت ها را از مقدار منبع در مقدار مقصد کپی می کند ، سپس اصل را فراموش می کند.
    /// این دقیقاً مانند `memcpy` C در زیر کاپوت است ، دقیقاً مانند `transmute_copy`.
    ///
    /// از آنجا که `transmute` یک عمل کم ارزش است ، هم ترازی بودن مقادیر * تبدیل شده خود نگران کننده نیست.
    /// همانند سایر عملکردها ، کامپایلر از هم تراز بودن `T` و `U` اطمینان حاصل می کند.
    /// با این حال ، هنگام انتقال مقادیری که *به جای دیگری* اشاره می شوند (مانند اشاره گرها ، منابع ، جعبه ها ...) ، تماس گیرنده باید از هم ترازی مناسب مقادیر اشاره شده به اطمینان حاصل کند.
    ///
    /// `transmute` **فوق العاده** ناامن است.روشهای زیادی برای ایجاد [undefined behavior][ub] با این عملکرد وجود دارد.`transmute` باید آخرین چاره مطلق باشد.
    ///
    /// [nomicon](../../nomicon/transmutes.html) مستندات اضافی دارد.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// چند مورد وجود دارد که `transmute` واقعا برای آنها مفید است.
    ///
    /// تبدیل نشانگر به نشانگر عملکرد.این * برای دستگاههایی که اندازهگرهای عملکرد و نشانگرهای داده دارای اندازه های مختلف هستند قابل حمل نیست.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// تمدید یک عمر ، یا کوتاه کردن یک عمر ثابت.این پیشرفته ، بسیار ناامن Rust است!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// ناامید نشوید: بسیاری از کاربردهای `transmute` را می توان از طریق دیگر به دست آورد.
    /// در زیر برنامه های متداول `transmute` وجود دارد که می تواند با ساختارهای ایمن تری جایگزین شود.
    ///
    /// تبدیل bytes(`&[u8]`) خام به `u32` ، `f64` و غیره:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // به جای آن از `u32::from_ne_bytes` استفاده کنید
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // یا از `u32::from_le_bytes` یا `u32::from_be_bytes` برای تعیین پایان استفاده کنید
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// تبدیل نشانگر به `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // در عوض از بازیگران `as` استفاده کنید
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// تبدیل `*mut T` به `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // به جای آن از reborrow استفاده کنید
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// تبدیل `&mut T` به `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // اکنون ، `as` و reborrowing را کنار هم قرار دهید ، توجه داشته باشید که زنجیرزنی `as` `as` انتقالی نیست
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// تبدیل `&str` به `&[u8]`:
    ///
    /// ```
    /// // این روش خوبی برای این کار نیست.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // می توانید از `str::as_bytes` استفاده کنید
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // یا اگر از کنترل رشته بر روی رشته استفاده می کنید ، فقط از یک رشته بایت استفاده کنید
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// تبدیل `Vec<&T>` به `Vec<Option<&T>>`.
    ///
    /// برای تغییر شکل نوع داخلی محتویات یک ظرف ، باید اطمینان حاصل کنید که هیچ یک از مواد تغییر دهنده ظرف را نقض نکنید.
    /// برای `Vec` ، این بدان معنی است که هم اندازه *و هم تراز* انواع داخلی باید مطابقت داشته باشند.
    /// ظروف دیگر ممکن است به اندازه نوع ، تراز یا حتی `TypeId` تکیه کنند ، در این صورت بدون نقض مواد غیرتغذایی کانتینر ، تغییر شکل به هیچ وجه امکان پذیر نیست.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // vector را شبیه سازی کنید زیرا بعداً از آنها استفاده مجدد خواهیم کرد
    /// let v_clone = v_orig.clone();
    ///
    /// // استفاده از transmute: این به طرح داده های مشخص نشده `Vec` بستگی دارد ، که ایده بدی است و می تواند باعث رفتار نامشخص شود.
    /////
    /// // با این حال ، کپی نیست.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // این روش ایمن پیشنهاد شده است.
    /// // هرچند که کل vector را در یک آرایه جدید کپی می کند.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // این روش بدون کپی و ایمن مناسب "transmuting" a `Vec` ، بدون اتکا به طرح داده است.
    /// // به جای اینکه به معنای واقعی کلمه `transmute` فراخوانی شود ، ما یک بازیگر اشاره گر را انجام می دهیم ، اما از نظر تبدیل نوع داخلی (`&i32`) اصلی به (`Option<&i32>`) جدید ، این موارد دارای هشدارهای یکسان است.
    /////
    /// // علاوه بر اطلاعات ارائه شده در بالا ، با اسناد [`from_raw_parts`] نیز مشورت کنید.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME هنگامی که vec_into_raw_parts تثبیت شد ، این مورد را به روز کنید.
    ///     // اطمینان حاصل کنید که vector اصلی افتاده نیست.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// پیاده سازی `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // روش های مختلفی برای انجام این کار وجود دارد ، و چندین راه با روش (transmute) زیر وجود دارد.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // اول: transmute از نظر نوع ایمن نیست.تمام بررسی این است که T و
    ///         // U از یک اندازه هستند.
    ///         // دوم ، در اینجا ، شما دو منبع قابل تغییر دارید که به همان حافظه اشاره می کنند.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // این از شر مشکلات ایمنی خلاص می شود.`&mut *`* فقط *`&mut T` را از `&mut T` یا `* mut T` به شما می دهد.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // با این حال ، شما هنوز هم دو مرجع قابل تغییر دارید که به همان حافظه اشاره دارند.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // اینگونه است که کتابخانه استاندارد این کار را می کند.
    /// // اگر شما نیاز به انجام چنین کاری دارید ، این بهترین روش است
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // این اکنون دارای سه منبع قابل تغییر است که به یک حافظه اشاره می کنند.`slice` ، rvalue ret.0 و rvalue ret.1.
    ///         // `slice` بعد از `let ptr = ...` هرگز استفاده نمی شود ، بنابراین می توان آن را به عنوان "dead" در نظر گرفت ، بنابراین شما فقط دو برش قابل تغییر واقعی دارید.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: در حالی که این باعث می شود که ساختار ذاتی پایدار باشد ، ما تعدادی کد سفارشی در ساختار fn داریم
    // بررسی هایی که از استفاده آن در `const fn` جلوگیری می کند.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// اگر نوع واقعی داده شده به عنوان `T` نیاز به چسب قطره دارد ، `true` را برمی گرداند.اگر نوع واقعی ارائه شده برای `T` `Copy` را پیاده سازی کند ، `false` را برمی گرداند.
    ///
    ///
    /// اگر نوع واقعی آن نه به چسب قطره ای احتیاج داشته باشد و نه `Copy` را پیاده سازی کند ، مقدار بازگشتی این عملکرد مشخص نیست.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`mem::needs_drop`](crate::mem::needs_drop) است.
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// جبران را از یک نشانگر محاسبه می کند.
    ///
    /// این به عنوان یک ماده ذاتی برای جلوگیری از تبدیل به یک عدد صحیح اجرا می شود ، زیرا این تبدیل اطلاعات مستعار است.
    ///
    /// # Safety
    ///
    /// اشاره گر شروع و نتیجه هر دو باید در مرزها یا یک بایت از انتهای یک شی allocated اختصاص داده شده باشد.
    /// اگر نشانگر خارج از محدوده باشد یا سرریز حسابی رخ دهد ، هرگونه استفاده بیشتر از مقدار برگشتی منجر به یک رفتار تعریف نشده می شود.
    ///
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`pointer::offset`] است.
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// جبران را از یک نشانگر محاسبه می کند ، به طور بالقوه بسته بندی می شود.
    ///
    /// این امر به عنوان یک ماده ذاتی برای جلوگیری از تبدیل به یک عدد صحیح انجام می شود ، زیرا این تبدیل باعث بهینه سازی های خاص می شود.
    ///
    /// # Safety
    ///
    /// بر خلاف `offset` ذاتی ، این ذات محدود نمی کند که نشانگر حاصله به انتهای یک شی allocated اختصاص داده شده به یک بایت یا یک بایت باشد ، و با محاسبات مکمل دو بسته می شود.
    /// مقدار بدست آمده لزوماً معتبر نیست که برای دستیابی واقعی به حافظه استفاده شود.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`pointer::wrapping_offset`] است.
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// برابر با `llvm.memcpy.p0i8.0i8.*` ذاتی مناسب ، با اندازه `count`*`size_of::<T>()` و تراز بندی از
    ///
    /// `min_align_of::<T>()`
    ///
    /// پارامتر فرار روی `true` تنظیم شده است ، بنابراین تا زمانی که اندازه آن برابر با صفر نباشد ، بهینه سازی نخواهد شد.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// برابر با `llvm.memmove.p0i8.0i8.*` ذاتی مناسب ، با اندازه `count* size_of::<T>()` و تراز بندی از
    ///
    /// `min_align_of::<T>()`
    ///
    /// پارامتر فرار روی `true` تنظیم شده است ، بنابراین تا زمانی که اندازه آن برابر با صفر نباشد ، بهینه سازی نخواهد شد.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// برابر با `llvm.memset.p0i8.*` ذاتی مناسب ، با اندازه `count* size_of::<T>()` و تراز `min_align_of::<T>()`.
    ///
    ///
    /// پارامتر فرار روی `true` تنظیم شده است ، بنابراین تا زمانی که اندازه آن برابر با صفر نباشد ، بهینه سازی نخواهد شد.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// بار ناپایداری را از نشانگر `src` انجام می دهد.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::ptr::read_volatile`](crate::ptr::read_volatile) است.
    pub fn volatile_load<T>(src: *const T) -> T;
    /// ذخیره ناپایداری را در اشاره گر `dst` انجام می دهد.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::ptr::write_volatile`](crate::ptr::write_volatile) است.
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// بار ناپایداری را از نشانگر `src` انجام می دهد نیازی به هموار بودن نشانگر نیست.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// ذخیره ناپایداری را در اشاره گر `dst` انجام می دهد.
    /// اشاره گر نیازی به تراز شدن ندارد.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// ریشه مربع `f32` را برمی گرداند
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// ریشه مربع `f64` را برمی گرداند
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// `f32` را به یک عدد صحیح ارتقا می دهد.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// `f64` را به یک عدد صحیح ارتقا می دهد.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// سینوس `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// سینوس `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// کسینوس `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// کسینوس `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// `f32` را به توان `f32` می رساند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// `f64` را به توان `f64` می رساند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// نمایی `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// نمایی `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// 2 را به قدرت `f32` برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// 2 را به قدرت `f64` برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// لگاریتم طبیعی `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// لگاریتم طبیعی `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// لگاریتم پایه 10 `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// لگاریتم پایه 10 `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// لگاریتم پایه 2 `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// لگاریتم پایه 2 `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// `a * b + c` را برای مقادیر `f32` برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// `a * b + c` را برای مقادیر `f64` برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// مقدار مطلق `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// مقدار مطلق `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// حداقل دو مقدار `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// حداقل دو مقدار `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// حداکثر دو مقدار `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// حداکثر دو مقدار `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// علامت را از `y` به `x` برای مقادیر `f32` کپی می کند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// علامت را از `y` به `x` برای مقادیر `f64` کپی می کند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// بزرگترین عدد صحیح کمتر یا مساوی با `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// بزرگترین عدد صحیح کمتر یا مساوی با `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// کوچکترین عدد صحیح بزرگتر یا مساوی `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// کوچکترین عدد صحیح بزرگتر یا مساوی `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// قسمت صحیح `f32` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// قسمت صحیح `f64` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// نزدیکترین عدد صحیح را به `f32` برمی گرداند.
    /// اگر آرگومان یک عدد صحیح نباشد ، ممکن است یک استثنا نادرست در نقطه شناور ایجاد کند.
    pub fn rintf32(x: f32) -> f32;
    /// نزدیکترین عدد صحیح را به `f64` برمی گرداند.
    /// اگر آرگومان یک عدد صحیح نباشد ، ممکن است یک استثنا نادرست در نقطه شناور ایجاد کند.
    pub fn rintf64(x: f64) -> f64;

    /// نزدیکترین عدد صحیح را به `f32` برمی گرداند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn nearbyintf32(x: f32) -> f32;
    /// نزدیکترین عدد صحیح را به `f64` برمی گرداند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn nearbyintf64(x: f64) -> f64;

    /// نزدیکترین عدد صحیح را به `f32` برمی گرداند.موارد نیمه راه را دور از صفر دور می زند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// نزدیکترین عدد صحیح را به `f64` برمی گرداند.موارد نیمه راه را دور از صفر دور می زند.
    ///
    /// نسخه تثبیت شده این ذاتی است
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// علاوه بر شناور که امکان بهینه سازی بر اساس قوانین جبری را فراهم می کند.
    /// ممکن است ورودی ها محدود باشند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// تفریق شناور که امکان بهینه سازی براساس قوانین جبری را فراهم می کند.
    /// ممکن است ورودی ها محدود باشند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// ضرب شناور که امکان بهینه سازی براساس قوانین جبری را فراهم می کند.
    /// ممکن است ورودی ها محدود باشند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// تقسیم شناور که امکان بهینه سازی براساس قوانین جبری را فراهم می کند.
    /// ممکن است ورودی ها محدود باشند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// باقیمانده شناور که امکان بهینه سازی براساس قوانین جبری را فراهم می کند.
    /// ممکن است ورودی ها محدود باشند.
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// با fptoui/fptosi LLVM تبدیل کنید ، که ممکن است برای مقادیر خارج از محدوده undef برگرداند
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// به صورت [`f32::to_int_unchecked`] و [`f64::to_int_unchecked`] تثبیت شده است.
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// تعداد بیت های تنظیم شده در یک نوع صحیح `T` را برمی گرداند
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `count_ones` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// تعداد بیت های بازنشسته (zeroes) را در یک نوع صحیح `T` برمی گرداند.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `leading_zeros` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` با مقدار `0` عرض بیت `T` را برمی گرداند.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// مانند `ctlz` ، اما بسیار ناامن است زیرا `undef` را هنگامی که `x` با ارزش `0` به آن داده می شود ، برمی گرداند.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// تعداد بیت های عقب مانده نشده (zeroes) را در یک نوع صحیح `T` برمی گرداند.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `trailing_zeros` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` با مقدار `0` عرض بیت `T` را برمی گرداند:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// مانند `cttz` ، اما بسیار ناامن است زیرا `undef` را هنگامی که `x` با ارزش `0` به آن داده می شود ، برمی گرداند.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// بایت ها را در نوع صحیح `T` معکوس می کند.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `swap_bytes` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// بیت ها را در نوع صحیح `T` معکوس می کند.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `reverse_bits` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// جمع عدد صحیح را انجام می دهد.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `overflowing_add` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// تفریق عدد صحیح را انجام می دهد
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `overflowing_sub` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// ضرب عدد صحیح را انجام می دهد
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `overflowing_mul` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// یک تقسیم دقیق انجام می دهد ، در نتیجه رفتار نامشخصی که در آن `x % y != 0` یا `y == 0` یا `x == T::MIN && y == -1` انجام می شود
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// یک تقسیم بدون کنترل را انجام می دهد ، در نتیجه رفتار نامشخصی که در آن `y == 0` یا `x == T::MIN && y == -1` انجام می شود
    ///
    ///
    /// بسته بندی ایمن برای این ماده ذاتی از طریق روش `checked_div` در اعداد اولیه در دسترس است.
    /// مثلا،
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// باقی مانده یک تقسیم نشده را برمی گرداند ، و در نتیجه هنگام تعریف `y == 0` یا `x == T::MIN && y == -1` رفتار تعریف نشده ای ایجاد می شود
    ///
    ///
    /// بسته بندی ایمن برای این ماده ذاتی از طریق روش `checked_rem` در اعداد اولیه در دسترس است.
    /// مثلا،
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// یک شیفت چپ کنترل نشده انجام می دهد ، در نتیجه هنگام تعریف `y < 0` یا `y >= N` ، در جایی که N عرض T در بیت است ، رفتار تعریف نشده ای ایجاد می شود.
    ///
    ///
    /// بسته بندی ایمن برای این ماده ذاتی از طریق روش `checked_shl` در اعداد اولیه در دسترس است.
    /// مثلا،
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// یک تغییر راست بدون کنترل انجام می دهد ، در نتیجه هنگام تعریف `y < 0` یا `y >= N` رفتاری تعریف نشده انجام می شود ، جایی که N عرض T در بیت است.
    ///
    ///
    /// بسته بندی ایمن برای این ماده ذاتی از طریق روش `checked_shr` در اعداد اولیه در دسترس است.
    /// مثلا،
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// نتیجه یک جمع بدون علامت را برمی گرداند ، در نتیجه هنگام تعریف `x + y > T::MAX` یا `x + y < T::MIN` رفتار تعریف نشده ای ایجاد می شود.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// نتیجه یک تفریق کنترل نشده را برمی گرداند ، در نتیجه هنگام تعریف `x - y > T::MAX` یا `x - y < T::MIN` رفتار تعریف نشده ای ایجاد می شود.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// نتیجه یک ضرب علامت زده نشده را برمی گرداند ، در نتیجه `x *y > T::MAX` یا `x* y < T::MIN` منجر به یک رفتار تعریف نشده می شود.
    ///
    ///
    /// این ذاتی هیچ نمونه ثابت ندارد.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// چرخش به سمت چپ را انجام می دهد.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `rotate_left` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// چرخش را به درستی انجام می دهد.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `rotate_right` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// (a + b) mod 2 <sup>N را</sup> برمی گرداند ، جایی که N عرض T در بیت است.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `wrapping_add` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// (a، b) mod 2 <sup>N را</sup> برمی گرداند ، جایی که N عرض T در بیت است.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `wrapping_sub` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// (a * b) mod 2 <sup>N را</sup> برمی گرداند ، جایی که N عرض T در بیت است.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `wrapping_mul` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// `a + b` را محاسبه می کند ، در مرزهای عددی اشباع می شود.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `saturating_add` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// `a - b` را محاسبه می کند ، در مرزهای عددی اشباع می شود.
    ///
    /// نسخه های تثبیت شده این ذاتی از طریق روش `saturating_sub` در ابتدای عدد در دسترس است.
    /// مثلا،
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// مقدار متمایز کننده نوع را در 'v' برمی گرداند.
    /// اگر `T` هیچ تمایزی ندارد ، `0` را برمی گرداند.
    ///
    /// نسخه تثبیت شده این نسخه ذاتی [`core::mem::discriminant`](crate::mem::discriminant) است.
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// تعداد انواع نوع Cast `T` را به `usize` برمی گرداند.
    /// اگر `T` هیچ گونه تغییری نداشته باشد ، `0` را برمی گرداند.انواع غیر مسکونی محاسبه خواهد شد.
    ///
    /// نسخه قابل تثبیت این نسخه ذاتی [`mem::variant_count`] است.
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// ساختار "try catch" Rust که نشانگر عملکرد `try_fn` را با اشاره گر داده `data` فراخوانی می کند.
    ///
    /// آرگومان سوم تابعی است که در صورت بروز panic فراخوانی می شود.
    /// این عملکرد نشانگر داده و یک اشاره گر را به شی استثنایی خاص هدف که گرفته شده می برد.
    ///
    /// برای اطلاعات بیشتر به منبع کامپایلر و همچنین پیاده سازی std مراجعه کنید.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// مطابق LLVM فروشگاه `!nontemporal` منتشر می کند (به اسناد آنها مراجعه کنید).
    /// احتمالاً هرگز پایدار نخواهد شد.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// برای جزئیات بیشتر به اسناد `<*const T>::offset_from` مراجعه کنید.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// برای جزئیات بیشتر به اسناد `<*const T>::guaranteed_eq` مراجعه کنید.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// برای جزئیات بیشتر به اسناد `<*const T>::guaranteed_ne` مراجعه کنید.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// در زمان کامپایل تخصیص دهید.نباید در زمان اجرا تماس گرفته شود.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// برخی از توابع در اینجا تعریف می شوند زیرا به طور تصادفی در پایدار در این ماژول در دسترس قرار گرفتند.
// به <https://github.com/rust-lang/rust/issues/15702> مراجعه کنید.
// (`transmute` نیز در این گروه قرار می گیرد ، اما به دلیل بررسی اندازه یکسان `T` و `U` نمی توان آن را بسته بندی کرد.)
//

/// بررسی می کند که `ptr` با توجه به `align_of::<T>()` به درستی همسو باشد.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// `count *size_of::<T>()` بایت را از `src` به `dst` کپی می کند.مبدا و مقصد نباید* همپوشانی داشته باشد.
///
/// برای مناطقی از حافظه که ممکن است با هم تداخل داشته باشند ، به جای آن از [`copy`] استفاده کنید.
///
/// `copy_nonoverlapping` از نظر معنایی معادل C's [`memcpy`] است ، اما با تغییر ترتیب استدلال.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// در صورت نقض هر یک از شرایط زیر ، رفتار تعریف نشده است:
///
/// * `src` برای خواندن بایت `count * size_of::<T>()` باید [valid] باشد.
///
/// * `dst` برای نوشتن بایت `count * size_of::<T>()` باید [valid] باشد.
///
/// * `src` و `dst` باید به درستی تراز شوند.
///
/// * منطقه حافظه از `src` با اندازه `شمارش آغاز می شود *
///   اندازه_: :<T>() "بایت ها *نباید* با منطقه حافظه از `dst` با همان اندازه تداخل داشته باشند.
///
/// مانند [`read`] ، `copy_nonoverlapping` یک نسخه کپی از `T` ایجاد می کند ، صرف نظر از اینکه `T` [`Copy`] است.
/// اگر `T` [`Copy`] نباشد ، از مقادیر * **در ناحیه ای که از `* src` شروع می شود و منطقه با `*dst` می تواند [violate memory safety][read-ownership] استفاده کنید.
///
///
/// توجه داشته باشید که حتی اگر اندازه کپی شده به طور موثر ("count * size_of: :)<T>()") `0` است ، نشانگرها باید NULL نباشند و به درستی تراز شوند.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// [`Vec::append`] را به صورت دستی پیاده سازی کنید:
///
/// ```
/// use std::ptr;
///
/// /// تمام عناصر `src` را به `dst` منتقل می کند ، `src` را خالی می گذارد.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // اطمینان حاصل کنید که `dst` ظرفیت کافی برای نگهداری تمام `src` را دارد.
///     dst.reserve(src_len);
///
///     unsafe {
///         // تماس برای جبران همیشه ایمن است زیرا `Vec` هرگز بیش از `isize::MAX` بایت اختصاص نمی دهد.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // `src` را بدون انداختن محتویات آن کوتاه کنید.
///         // ابتدا این کار را انجام می دهیم تا مشکلی در مورد پایین آمدن panics ایجاد نشود.
///         src.set_len(0);
///
///         // این دو منطقه نمی توانند همپوشانی داشته باشند زیرا مراجع قابل تغییر نام مستعار ندارند و دو vectors مختلف نمی توانند حافظه یکسانی داشته باشند.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // به `dst` اطلاع دهید که اکنون محتویات `src` را در خود نگهداری می کند.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: این بررسی ها را فقط در زمان اجرا انجام دهید
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // وحشت نکنید تا تأثیر کدژن کمتر شود.
        abort();
    }*/

    // ایمنی: قرارداد ایمنی `copy_nonoverlapping` باید باشد
    // توسط تماس گیرنده پشتیبانی می شود.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// `count * size_of::<T>()` بایت را از `src` به `dst` کپی می کند.مبدا و مقصد ممکن است با هم تداخل داشته باشند.
///
/// اگر مبدا و مقصد *هرگز* با هم تداخل نداشته باشند ، می توان به جای آن از [`copy_nonoverlapping`] استفاده کرد.
///
/// `copy` از نظر معنایی معادل C's [`memmove`] است ، اما با تغییر ترتیب استدلال.
/// کپی برداری به گونه ای صورت می گیرد که گویی بایت ها از `src` در آرایه ای موقتی کپی شده اند و سپس از آرایه در `dst` کپی شده اند.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// در صورت نقض هر یک از شرایط زیر ، رفتار تعریف نشده است:
///
/// * `src` برای خواندن بایت `count * size_of::<T>()` باید [valid] باشد.
///
/// * `dst` برای نوشتن بایت `count * size_of::<T>()` باید [valid] باشد.
///
/// * `src` و `dst` باید به درستی تراز شوند.
///
/// مانند [`read`] ، `copy` یک نسخه کپی از `T` ایجاد می کند ، صرف نظر از اینکه `T` [`Copy`] است.
/// اگر `T` [`Copy`] نباشد ، از مقادیر موجود در ناحیه که از `*src` شروع می شود و منطقه از `* dst` می توانید [violate memory safety][read-ownership] استفاده کنید.
///
///
/// توجه داشته باشید که حتی اگر اندازه کپی شده به طور موثر ("count * size_of: :)<T>()") `0` است ، نشانگرها باید NULL نباشند و به درستی تراز شوند.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// به طور کارآمد یک Rust vector را از یک بافر ناایمن ایجاد کنید:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` باید برای نوع آن صحیح و غیر صفر باشد.
/// /// * `ptr` باید برای خواندن عناصر مجاور `elts` از نوع `T` معتبر باشد.
/// /// * پس از فراخوانی این تابع نباید از این عناصر استفاده شود مگر اینکه `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ایمنی: پیش شرط ما مطابقت و اعتبار منبع را تضمین می کند ،
///     // و `Vec::with_capacity` تضمین می کند که فضای قابل استفاده برای نوشتن آنها داریم.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ایمنی: ما آن را با این ظرفیت خیلی زودتر ایجاد کردیم ،
///     // و `copy` قبلی این عناصر را اولیه کرده است.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: این بررسی ها را فقط در زمان اجرا انجام دهید
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // وحشت نکنید تا تأثیر کدژن کمتر شود.
        abort();
    }*/

    // ایمنی: قرارداد ایمنی `copy` باید توسط تماس گیرنده تأیید شود.
    unsafe { copy(src, dst, count) }
}

/// `count * size_of::<T>()` بایت حافظه را از `dst` تا `val` تنظیم می کند.
///
/// `write_bytes` مشابه [`memset`] C است ، اما بایت `count * size_of::<T>()` را روی `val` تنظیم می کند.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// در صورت نقض هر یک از شرایط زیر ، رفتار تعریف نشده است:
///
/// * `dst` برای نوشتن بایت `count * size_of::<T>()` باید [valid] باشد.
///
/// * `dst` باید به درستی تراز شود.
///
/// علاوه بر این ، تماس گیرنده باید اطمینان حاصل کند که نوشتن بایت `count * size_of::<T>()` در منطقه حافظه مشخص شده منجر به یک مقدار معتبر `T` می شود.
/// استفاده از یک منطقه از حافظه تایپ شده به عنوان `T` که حاوی مقدار نامعتبر `T` باشد ، یک رفتار تعریف نشده است.
///
/// توجه داشته باشید که حتی اگر اندازه کپی شده به طور موثر ("count * size_of: :)<T>()") `0` است ، نشانگر باید بدون NULL باشد و به درستی تراز باشد.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// ایجاد یک مقدار نامعتبر:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // با جایگزینی `Box<T>` با اشاره گر صفر ، مقدار قبلی را فاش می کند.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // در این مرحله ، استفاده یا رها کردن `v` منجر به یک رفتار تعریف نشده می شود.
/// // drop(v); // ERROR
///
/// // حتی نشت `v` "uses" آن ، و بنابراین یک رفتار تعریف نشده است.
/// // mem::forget(v); // ERROR
///
/// // در واقع ، `v` با توجه به نوع اولیه طرح بندی نامعتبر است ، بنابراین *هر عمل* لمس آن یک رفتار تعریف نشده است.
/////
/// // بگذارید v2 =v؛//خطا
///
/// unsafe {
///     // بگذارید در عوض یک مقدار معتبر قرار دهیم
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // حالا جعبه خوب است
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ایمنی: قرارداد ایمنی `write_bytes` باید توسط تماس گیرنده تأیید شود.
    unsafe { write_bytes(dst, val, count) }
}