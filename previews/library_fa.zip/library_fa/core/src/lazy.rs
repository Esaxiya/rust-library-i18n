//! مقادیر تنبل و مقداردهی اولیه یکبار مصرف داده های استاتیک.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// سلولی که فقط یکبار می توان روی آن نوشت.
///
/// بر خلاف `RefCell` ، `OnceCell` فقط ارجاعات `&T` مشترک را به مقدار آن ارائه می دهد.
/// برخلاف `Cell` ، `OnceCell` برای دسترسی به آن نیازی به کپی یا جایگزینی مقدار ندارد.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // بی تغییر: حداکثر یک بار به آن نوشته شده است.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// یک سلول خالی جدید ایجاد می کند.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// به مقدار اساسی مراجعه می کند.
    ///
    /// اگر سلول خالی باشد ، `None` را برمی گرداند.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // ایمنی: به دلیل ثابت نبودن `داخلی` ایمن است
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// اشاره قابل تغییر به مقدار اساسی را دریافت می کند.
    ///
    /// اگر سلول خالی باشد ، `None` را برمی گرداند.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // ایمنی: ایمن زیرا دسترسی منحصر به فردی داریم
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// محتویات سلول را به `value` تنظیم می کند.
    ///
    /// # Errors
    ///
    /// اگر سلول خالی باشد `Ok(())` و اگر پر باشد `Err(value)` برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // ایمنی: ایمن زیرا ما نمی توانیم وامهای قابل انعطاف همپوشانی داشته باشیم
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // ایمنی: این تنها مکانی است که ما جایگاه را تعیین می کنیم ، بدون مسابقه
        // با توجه به reentrancy/concurrency امکان پذیر است ، و ما بررسی کردیم که اسلات در حال حاضر `None` است ، بنابراین این نوشتار "داخلی" را ثابت نگه می دارد.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// محتویات سلول را دریافت می کند ، در صورت خالی بودن سلول ، آن را با `f` مقداردهی اولیه می کند.
    ///
    /// # Panics
    ///
    /// اگر `f` panics ، panic به تماس گیرنده منتقل می شود و سلول غیر اولیه باقی می ماند.
    ///
    ///
    /// شروع مجدد سلول از `f` خطایی است.انجام این کار منجر به panic می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// محتویات سلول را دریافت می کند ، در صورت خالی بودن سلول ، آن را با `f` مقداردهی اولیه می کند.
    /// اگر سلول خالی باشد و `f` خراب شود ، خطایی برمی گردد.
    ///
    /// # Panics
    ///
    /// اگر `f` panics ، panic به تماس گیرنده منتقل می شود و سلول غیر اولیه باقی می ماند.
    ///
    ///
    /// شروع مجدد سلول از `f` خطایی است.انجام این کار منجر به panic می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // توجه داشته باشید که *برخی* اشکال مقداردهی مجدد مجدد هزینه ممکن است منجر به UB شود (به آزمایش `reentrant_init` مراجعه کنید).
        // من معتقدم که فقط حذف این `assert` ، در حالی که `set/get` را حفظ می کنید ، کاری صحیح است ، اما به نظر می رسد که panic بهتر از این است که در سکوت از یک مقدار قدیمی استفاده کند.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// سلول را مصرف می کند ، مقدار بسته بندی شده را برمی گرداند.
    ///
    /// اگر سلول خالی باشد ، `None` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // از آنجا که `into_inner` مقدار `self` را بدست می آورد ، کامپایلر به صورت آماری تأیید می کند که در حال حاضر وام نگرفته است.
        // بنابراین انتقال `Option<T>` بی خطر است.
        self.inner.into_inner()
    }

    /// مقدار این `OnceCell` را می گیرد و آن را به حالت غیر اولیه منتقل می کند.
    ///
    /// اگر `OnceCell` مقداردهی اولیه نشده باشد تاثیری ندارد و `None` را برمی گرداند.
    ///
    /// با نیاز به یک مرجع قابل تغییر ، ایمنی تضمین می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// مقداری که در اولین دسترسی مقداردهی اولیه می شود.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   آماده سازی اولیه
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// با عملکرد اولیه داده شده مقدار تنبلی جدیدی ایجاد می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// ارزیابی این مقدار تنبل را مجبور کرده و مرجعی را به نتیجه برمی گرداند.
    ///
    ///
    /// این معادل Xpt X است ، اما صریح است.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// مقدار تنبلی جدیدی را با استفاده از `Default` به عنوان تابع مقداردهی اولیه ایجاد می کند.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}