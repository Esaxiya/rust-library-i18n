//! API های تخصیص حافظه

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// خطای `AllocError` نشان دهنده خرابی در تخصیص است که ممکن است به دلیل فرسودگی منابع یا اشتباه هنگام ترکیب آرگومان های ورودی داده شده با این تخصیص دهنده باشد.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (ما این را برای impl پایین دستی خطای trait نیاز داریم)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// پیاده سازی `Allocator` می تواند تخصیص ، رشد ، کوچک شدن و عدم تخصیص مکانهای دلخواهی از طریق [`Layout`][] را توصیف کند.
///
/// `Allocator` برای پیاده سازی بر روی ZST ها ، منابع یا اشاره گرهای هوشمند طراحی شده است ، زیرا داشتن یک تخصیص دهنده مانند `MyAlloc([u8; N])` بدون به روزرسانی نشانگرها به حافظه اختصاصی ، قابل جابجایی نیست.
///
/// برخلاف [`GlobalAlloc`][] ، تخصیص هایی با اندازه صفر در `Allocator` مجاز هستند.
/// اگر یک تخصیص دهنده اصلی از این پشتیبانی نمی کند (مانند jemalloc) یا یک اشاره گر صفر را بر نمی گرداند (مانند `libc::malloc`) ، این باید پیاده سازی شود.
///
/// ### حافظه اختصاص یافته در حال حاضر
///
/// بعضی از روشها مستلزم این است که یک بلوک حافظه *در حال حاضر* از طریق یک تخصیص دهنده اختصاص یابد.این بدان معنی است که:
///
/// * آدرس شروع آن بلوک حافظه قبلاً توسط [`allocate`] ، [`grow`] یا [`shrink`] بازگردانده شده است
///
/// * بلوک حافظه متعاقباً منتقل نشده است ، جایی که بلوک ها مستقیماً با عبور به [`deallocate`] از محل جدا می شوند یا با انتقال به [`grow`] یا [`shrink`] که `Ok` را برمی گرداند ، تغییر می یابند.
///
/// اگر `grow` یا `shrink` `Err` را برگردانده است ، نشانگر عبور داده معتبر باقی می ماند.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### اتصالات حافظه
///
/// بعضی از روش ها نیاز دارند که یک طرح *متناسب با* بلوک حافظه باشد.
/// منظور از طرح بندی برای "fit" ، بلوک حافظه (یا معادل آن ، برای یک بلوک حافظه به طرح "fit") این است که شرایط زیر باید وجود داشته باشد:
///
/// * بلوک باید با همان ترازوی [`layout.align()`] تخصیص یابد ، و
///
/// * [`layout.size()`] ارائه شده باید در محدوده `min ..= max` قرار گیرد ، جایی که:
///   - `min` اندازه طرح است که اخیراً برای تخصیص بلوک استفاده شده است ، و
///   - `max` آخرین اندازه واقعی است که از [`allocate`] ، [`grow`] یا [`shrink`] برگردانده شده است.
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * بلوک های حافظه برگشتی از یک تخصیص دهنده باید به حافظه معتبر اشاره کرده و اعتبار خود را حفظ کنند تا زمانی که نمونه و تمام کلون های آن کاهش یابد ،
///
/// * شبیه سازی یا جابجایی تخصیص دهنده نباید بلوک های حافظه برگشتی از این تخصیص دهنده را بی اعتبار کند.یک تخصیص دهنده شبیه سازی شده باید مانند همان تخصیص دهنده رفتار کند ، و
///
/// * هر اشاره گر به یک بلوک حافظه که [*currently allocated*] است ممکن است به هر روش دیگری از تخصیص دهنده منتقل شود.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// تلاش برای اختصاص بخشی از حافظه.
    ///
    /// در صورت موفقیت ، یک جلسه [`NonNull<[u8]>`][NonNull] با اندازه و تضمین های هم تراز `layout` برمی گرداند.
    ///
    /// بلوک برگشتی ممکن است اندازه بزرگتری از آنچه توسط `layout.size()` مشخص شده است داشته باشد ، و ممکن است محتوای آن اولیه نباشد.
    ///
    /// # Errors
    ///
    /// بازگشت `Err` نشان می دهد که یا حافظه به اتمام رسیده است یا `layout` با اندازه و یا محدودیت های ترازبندی مطابقت ندارد.
    ///
    /// پیاده سازی ها برای بازگرداندن `Err` در فرسودگی حافظه به جای وحشت زدگی یا سقط جنین توصیه می شود ، اما این یک مورد سختگیرانه نیست.
    /// (به طور خاص: پیاده سازی این trait در بالای یک کتابخانه تخصیص بومی زیربنایی که باعث خستگی حافظه می شود ،*قانونی* است).
    ///
    /// مشتریانی که مایل به لغو محاسبه در پاسخ به خطای تخصیص هستند ، به جای استفاده مستقیم از `panic!` یا موارد مشابه ، با عملکرد [`handle_alloc_error`] فراخوانی می شوند.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// مانند `allocate` رفتار می کند ، اما همچنین تضمین می کند که حافظه برگشتی صفر شروع نمی شود.
    ///
    /// # Errors
    ///
    /// بازگشت `Err` نشان می دهد که یا حافظه به اتمام رسیده است یا `layout` با اندازه و یا محدودیت های ترازبندی مطابقت ندارد.
    ///
    /// پیاده سازی ها برای بازگرداندن `Err` در فرسودگی حافظه به جای وحشت زدگی یا سقط جنین توصیه می شود ، اما این یک مورد سختگیرانه نیست.
    /// (به طور خاص: پیاده سازی این trait در بالای یک کتابخانه تخصیص بومی زیربنایی که باعث خستگی حافظه می شود ،*قانونی* است).
    ///
    /// مشتریانی که مایل به لغو محاسبه در پاسخ به خطای تخصیص هستند ، به جای استفاده مستقیم از `panic!` یا موارد مشابه ، با عملکرد [`handle_alloc_error`] فراخوانی می شوند.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SAFETY: `alloc` یک بلوک حافظه معتبر را برمی گرداند
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// حافظه ارجاع شده توسط `ptr` را از جای خود خارج می کند.
    ///
    /// # Safety
    ///
    /// * `ptr` باید یک بلوک از حافظه [*currently allocated*] را از طریق این تخصیص دهنده نشان دهد ، و
    /// * `layout` باید [*fit*] که بلوک حافظه است.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// تلاش برای گسترش بلوک حافظه.
    ///
    /// [`NonNull<[u8]>`][NonNull] جدید حاوی نشانگر و اندازه واقعی حافظه اختصاص داده شده را برمی گرداند.اشاره گر برای نگهداری داده های توصیف شده توسط `new_layout` مناسب است.
    /// برای تحقق این امر ، تخصیص دهنده می تواند تخصیص ارجاع شده توسط `ptr` را متناسب با طرح جدید گسترش دهد.
    ///
    /// اگر این `Ok` را بازگرداند ، پس مالکیت بلوک حافظه مورد اشاره `ptr` به این تخصیص دهنده منتقل شده است.
    /// ممكن است حافظه آزاد شده باشد یا نشود ، و باید غیر قابل استفاده تلقی شود مگر آنكه از طریق مقدار برگشتی این روش دوباره به تماس گیرنده منتقل شود.
    ///
    /// اگر این روش `Err` را بازگرداند ، پس مالکیت بلوک حافظه به این تخصیص دهنده منتقل نشده است و محتوای بلوک حافظه تغییری نکرده است.
    ///
    /// # Safety
    ///
    /// * `ptr` باید یک بلوک از حافظه [*currently allocated*] را از طریق این تخصیص دهنده نشان دهد.
    /// * `old_layout` باید [*fit*] آن بلوک حافظه باشد (استدلال `new_layout` نیازی به آن ندارد.)
    /// * `new_layout.size()` باید بزرگتر یا برابر با `old_layout.size()` باشد.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` را برمی گرداند اگر طرح جدید مطابق با اندازه و محدودیت های تراز کننده تخصیص دهنده نباشد ، یا اگر رشد در غیر این صورت ناموفق باشد.
    ///
    /// پیاده سازی ها برای بازگرداندن `Err` در فرسودگی حافظه به جای وحشت زدگی یا سقط جنین توصیه می شود ، اما این یک مورد سختگیرانه نیست.
    /// (به طور خاص: پیاده سازی این trait در بالای یک کتابخانه تخصیص بومی زیربنایی که باعث خستگی حافظه می شود ،*قانونی* است).
    ///
    /// مشتریانی که مایل به لغو محاسبه در پاسخ به خطای تخصیص هستند ، به جای استفاده مستقیم از `panic!` یا موارد مشابه ، با عملکرد [`handle_alloc_error`] فراخوانی می شوند.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ایمنی: زیرا `new_layout.size()` باید بزرگتر یا مساوی باشد
        // `old_layout.size()`, تخصیص حافظه قدیمی و جدید برای خواندن و نوشتن برای بایت `old_layout.size()` معتبر است.
        // همچنین ، از آنجا که تخصیص قدیمی هنوز تخصیص نیافته است ، نمی تواند `new_ptr` را همپوشانی کند.
        // بنابراین تماس با `copy_nonoverlapping` بی خطر است.
        // قرارداد ایمنی `dealloc` باید توسط تماس گیرنده تأیید شود.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// مانند `grow` رفتار می کند ، اما همچنین اطمینان حاصل می کند که محتوای جدید قبل از بازگرداندن صفر است.
    ///
    /// بلوک حافظه پس از یک تماس موفق به محتوای زیر خواهد بود
    /// `grow_zeroed`:
    ///   * بایت `0..old_layout.size()` از تخصیص اولیه حفظ شده است.
    ///   * بسته به اجرای تخصیص دهنده ، Bytes `old_layout.size()..old_size` حفظ یا صفر می شود.
    ///   `old_size` به اندازه بلوک حافظه قبل از تماس `grow_zeroed` اشاره دارد ، که ممکن است بزرگتر از اندازه ای باشد که در ابتدا هنگام اختصاص دادن درخواست شد.
    ///   * بایت `old_size..new_size` صفر است.`new_size` به اندازه بلوک حافظه برگشتی توسط تماس `grow_zeroed` گفته می شود.
    ///
    /// # Safety
    ///
    /// * `ptr` باید یک بلوک از حافظه [*currently allocated*] را از طریق این تخصیص دهنده نشان دهد.
    /// * `old_layout` باید [*fit*] آن بلوک حافظه باشد (استدلال `new_layout` نیازی به آن ندارد.)
    /// * `new_layout.size()` باید بزرگتر یا برابر با `old_layout.size()` باشد.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// `Err` را برمی گرداند اگر طرح جدید مطابق با اندازه و محدودیت های تراز کننده تخصیص دهنده نباشد ، یا اگر رشد در غیر این صورت ناموفق باشد.
    ///
    /// پیاده سازی ها برای بازگرداندن `Err` در فرسودگی حافظه به جای وحشت زدگی یا سقط جنین توصیه می شود ، اما این یک مورد سختگیرانه نیست.
    /// (به طور خاص: پیاده سازی این trait در بالای یک کتابخانه تخصیص بومی زیربنایی که باعث خستگی حافظه می شود ،*قانونی* است).
    ///
    /// مشتریانی که مایل به لغو محاسبه در پاسخ به خطای تخصیص هستند ، به جای استفاده مستقیم از `panic!` یا موارد مشابه ، با عملکرد [`handle_alloc_error`] فراخوانی می شوند.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // ایمنی: زیرا `new_layout.size()` باید بزرگتر یا مساوی باشد
        // `old_layout.size()`, تخصیص حافظه قدیمی و جدید برای خواندن و نوشتن برای بایت `old_layout.size()` معتبر است.
        // همچنین ، از آنجا که تخصیص قدیمی هنوز تخصیص نیافته است ، نمی تواند `new_ptr` را همپوشانی کند.
        // بنابراین تماس با `copy_nonoverlapping` بی خطر است.
        // قرارداد ایمنی `dealloc` باید توسط تماس گیرنده تأیید شود.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// تلاش برای کوچک کردن بلوک حافظه.
    ///
    /// [`NonNull<[u8]>`][NonNull] جدید حاوی نشانگر و اندازه واقعی حافظه اختصاص داده شده را برمی گرداند.اشاره گر برای نگهداری داده های توصیف شده توسط `new_layout` مناسب است.
    /// برای تحقق این امر ، تخصیص دهنده می تواند تخصیص ارجاع شده توسط `ptr` را متناسب با طرح جدید کوچک کند.
    ///
    /// اگر این `Ok` را بازگرداند ، پس مالکیت بلوک حافظه مورد اشاره `ptr` به این تخصیص دهنده منتقل شده است.
    /// ممكن است حافظه آزاد شده باشد یا نشود ، و باید غیر قابل استفاده تلقی شود مگر آنكه از طریق مقدار برگشتی این روش دوباره به تماس گیرنده منتقل شود.
    ///
    /// اگر این روش `Err` را بازگرداند ، پس مالکیت بلوک حافظه به این تخصیص دهنده منتقل نشده است و محتوای بلوک حافظه تغییری نکرده است.
    ///
    /// # Safety
    ///
    /// * `ptr` باید یک بلوک از حافظه [*currently allocated*] را از طریق این تخصیص دهنده نشان دهد.
    /// * `old_layout` باید [*fit*] آن بلوک حافظه باشد (استدلال `new_layout` نیازی به آن ندارد.)
    /// * `new_layout.size()` باید کوچکتر یا مساوی با `old_layout.size()` باشد.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// اگر طرح جدید مطابق با اندازه و محدودیتهای تراز کننده تخصیص دهنده نباشد ، یا در صورت عدم موفقیت در کوچک شدن ، `Err` را برمی گرداند.
    ///
    /// پیاده سازی ها برای بازگرداندن `Err` در فرسودگی حافظه به جای وحشت زدگی یا سقط جنین توصیه می شود ، اما این یک مورد سختگیرانه نیست.
    /// (به طور خاص: پیاده سازی این trait در بالای یک کتابخانه تخصیص بومی زیربنایی که باعث خستگی حافظه می شود ،*قانونی* است).
    ///
    /// مشتریانی که مایل به لغو محاسبه در پاسخ به خطای تخصیص هستند ، به جای استفاده مستقیم از `panic!` یا موارد مشابه ، با عملکرد [`handle_alloc_error`] فراخوانی می شوند.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // ایمنی: زیرا `new_layout.size()` باید کمتر یا مساوی باشد
        // `old_layout.size()`, تخصیص حافظه قدیمی و جدید برای خواندن و نوشتن برای بایت `new_layout.size()` معتبر است.
        // همچنین ، از آنجا که تخصیص قدیمی هنوز تخصیص نیافته است ، نمی تواند `new_ptr` را همپوشانی کند.
        // بنابراین تماس با `copy_nonoverlapping` بی خطر است.
        // قرارداد ایمنی `dealloc` باید توسط تماس گیرنده تأیید شود.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// یک آداپتور "by reference" برای این نمونه از `Allocator` ایجاد می کند.
    ///
    /// آداپتور برگشتی نیز `Allocator` را پیاده سازی می کند و به سادگی این مورد را قرض می گیرد.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // ایمنی: قرارداد ایمنی باید توسط تماس گیرنده تأیید شود
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ایمنی: قرارداد ایمنی باید توسط تماس گیرنده تأیید شود
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ایمنی: قرارداد ایمنی باید توسط تماس گیرنده تأیید شود
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // ایمنی: قرارداد ایمنی باید توسط تماس گیرنده تأیید شود
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}