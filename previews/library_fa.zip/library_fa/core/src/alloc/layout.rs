use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// در حالی که این تابع در یک مکان استفاده می شود و می توان اجرای آن را مشخص کرد ، اما تلاش های قبلی برای این کار rustc را کندتر می کند:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// طرح یک بلوک از حافظه.
///
/// نمونه ای از `Layout` طرح خاصی از حافظه را توصیف می کند.
/// شما `Layout` را به عنوان ورودی برای دادن به یک تخصیص دهنده ایجاد می کنید.
///
/// همه چیدمان ها دارای اندازه مرتبط و تراز بندی قدرت دو هستند.
///
/// (توجه داشته باشید که طرح *ها* دارای اندازه غیر صفر نیستند * ، حتی اگر `GlobalAlloc` ایجاب می کند که تمام درخواستهای حافظه غیر صفر باشند.
/// یک تماس گیرنده یا باید اطمینان حاصل کند که شرایطی از این دست را برآورده می کند ، یا از تخصیص دهنده های خاص با نیازهای شلتر استفاده می کند یا از رابط نرم تر `Allocator` استفاده می کند.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // اندازه بلوک حافظه درخواستی ، اندازه گیری شده در بایت.
    size_: usize,

    // تراز بلوک حافظه درخواستی ، اندازه گیری شده در بایت.
    // ما اطمینان می دهیم که این همیشه یک قدرت دو نفره است ، زیرا API مانند `posix_memalign` به آن نیاز دارد و تحمیل آن به سازندگان Layout محدودیت معقولی است.
    //
    //
    // (با این حال ، ما به طور مشابه نیازی به `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) نداریم
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// `Layout` را از `size` و `align` مشخص می سازد یا اگر هر یک از شرایط زیر را برآورده نکنید `LayoutError` را برمی گرداند:
    ///
    /// * `align` نباید صفر باشد ،
    ///
    /// * `align` باید قدرت دو باشد ،
    ///
    /// * `size`, هنگامی که به نزدیکترین مضرب `align` گرد می شود ، نباید سرریز شود (یعنی مقدار گرد شده باید کمتر یا مساوی `usize::MAX` باشد).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (قدرت دو نشان دهنده هم ترازی است!=0.)

        // اندازه گرد شده:
        //   size_rounded_up=(size + align، 1)&! (align، 1)؛
        //
        // ما از بالا می دانیم که تراز کردن!=0.
        // اگر با اضافه کردن (تراز کردن ، 1) سرریز نشود ، گرد کردن درست است.
        //
        // برعکس ، و-ماسک زدن با! (تراز کردن ، 1) فقط بیت های کم سفارش را کم می کند.
        // بنابراین اگر سرریز با مجموع اتفاق بیفتد ،&-mask نمی تواند آنقدر کم کند که آن سرریز را خنثی کند.
        //
        //
        // در بالا نشان می دهد که بررسی برای سرریز جمع ، هم لازم و هم کافی است.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // ایمنی: شرایط `from_size_align_unchecked` وجود داشته است
        // در بالا بررسی شد
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// با دور زدن همه بررسی ها ، یک طرح ایجاد می کند.
    ///
    /// # Safety
    ///
    /// این عملکرد ایمن نیست زیرا پیش شرط های [`Layout::from_size_align`] را تأیید نمی کند.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // ایمنی: تماس گیرنده باید اطمینان حاصل کند که `align` بیشتر از صفر است.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// حداقل اندازه در بایت برای یک بلوک حافظه از این طرح.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// حداقل تراز بایت برای یک بلوک حافظه از این طرح.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// `Layout` مناسب برای نگه داشتن مقداری از نوع `T` را می سازد.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SAFETY: تراز شده توسط Rust تضمین می شود که دارای قدرت دو و
        // اندازه + ترازوی کوچک در فضای آدرس ما تضمین شده است.
        // در نتیجه برای جلوگیری از درج کدی که panics به اندازه کافی بهینه نشده است ، از سازنده علامت گذاری نشده در اینجا استفاده کنید.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// طرح توصیفی از یک رکورد را که می تواند برای اختصاص ساختار پشتیبان برای `T` (که می تواند trait یا نوع دیگر بدون اندازه مانند یک برش باشد) ، تولید می کند.
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ایمنی: به دلیل استفاده از این نوع ناامن در `new` منطق را ببینید
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// طرح توصیفی از یک رکورد را که می تواند برای اختصاص ساختار پشتیبان برای `T` (که می تواند trait یا نوع دیگر بدون اندازه مانند یک برش باشد) ، تولید می کند.
    ///
    /// # Safety
    ///
    /// تماس با این عملکرد فقط در صورت وجود شرایط زیر ایمن است:
    ///
    /// - اگر `T` `Sized` باشد ، تماس با این عملکرد همیشه بی خطر است.
    /// - اگر دنباله `T` بدون اندازه باشد:
    ///     - یک [slice] ، پس طول دم برش باید یک عدد صحیح intialized باشد ، و اندازه *کل مقدار*(طول دم پویا + پیشوند اندازه ایستا) باید در `isize` قرار گیرد.
    ///     - a [trait object] ، سپس قسمت vtable نشانگر باید به یک جدول معتبر برای نوع `T` بدست آمده توسط یک انسداد بدون سایز اشاره کند ، و اندازه *کل مقدار*(طول دم پویا + پیشوند اندازه ایستا) باید در `isize` قرار گیرد.
    ///
    ///     - (unstable) [extern type] ، پس این عملکرد همیشه امن است ، اما ممکن است panic یا در غیر این صورت مقدار اشتباه را بازگرداند ، زیرا طرح نوع خارجی شناخته شده نیست.
    ///     این همان رفتار [`Layout::for_value`] در هنگام مراجعه به دم نوع خارجی است.
    ///     - در غیر این صورت ، فراخوانی این عملکرد به صورت محافظه کارانه مجاز نیست.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // ایمنی: ما پیش نیازهای این توابع را به تماس گیرنده منتقل می کنیم
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // ایمنی: به دلیل استفاده از این نوع ناامن در `new` منطق را ببینید
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `NonNull` ایجاد می کند که آویزان است ، اما برای این چیدمان کاملاً تراز شده است.
    ///
    /// توجه داشته باشید که مقدار نشانگر ممکن است به طور بالقوه نشانگر معتبری باشد ، به این معنی که این نباید به عنوان مقدار نگهبان "not yet initialized" استفاده شود.
    /// انواع مختلفی که با تنبلی تخصیص می یابند باید مقدار اولیه را با روش های دیگر دنبال کنند.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // ایمنی: هم ترازی بودن بدون صفر تضمین شده است
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// یک طرح توصیف از رکورد ایجاد می کند که می تواند مقداری از همان طرح `self` را در خود نگه دارد ، اما همچنین با ترازبندی `align` (با بایت اندازه گیری شده) تراز شده است.
    ///
    ///
    /// اگر `self` از قبل مطابق با تراز مطابق باشد ، `self` را برمی گرداند.
    ///
    /// توجه داشته باشید که این روش ، بدون توجه به اینکه چیدمان متفاوت ، تراز بندی دیگری داشته باشد ، هیچ اندازه ای به اندازه کلی اضافه نمی کند.
    /// به عبارت دیگر ، اگر `K` اندازه 16 داشته باشد ، `K.align_to(32)`*همچنان* دارای اندازه 16 خواهد بود.
    ///
    /// اگر ترکیبی از `self.size()` و `align` داده شده شرایط ذکر شده در [`Layout::from_size_align`] را نقض کند ، خطایی را برمی گرداند.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// مقدار اطمینان را که باید بعد از `self` وارد کنیم برمی گرداند تا اطمینان حاصل شود که آدرس زیر `align` را برآورده می کند (با بایت اندازه گیری می شود).
    ///
    /// به عنوان مثال ، اگر `self.size()` 9 باشد ، `self.padding_needed_for(4)` 3 را برمی گرداند ، زیرا این حداقل تعداد بایت padding مورد نیاز برای دریافت یک آدرس 4 تراز است (با فرض اینکه بلوک حافظه مربوطه از یک آدرس 4 ترازو شروع می شود).
    ///
    ///
    /// اگر `align` قدرت دو نباشد مقدار بازگشتی این تابع معنایی ندارد.
    ///
    /// توجه داشته باشید که ابزار مقدار بازگشتی به `align` نیاز دارد تا کمتر از هم ترازی آدرس شروع برای کل بلوک حافظه اختصاص یافته باشد.یکی از راه های تأمین این محدودیت اطمینان از `align <= self.align()` است.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // مقدار گرد شده:
        //   len_rounded_up=(len + align ، 1)&! (align ، 1)؛
        // و سپس اختلاف بالشتک را برمی گردانیم: `len_rounded_up - len`.
        //
        // ما از حسابهای مدولار در کل استفاده می کنیم:
        //
        // 1. align تضمین می شود> 0 باشد ، بنابراین align ، 1 همیشه معتبر است.
        //
        // 2.
        // `len + align - 1` حداکثر می تواند با `align - 1` سرریز شود ، بنابراین&-mask با `!(align - 1)` اطمینان حاصل خواهد کرد که در صورت سرریز ، `len_rounded_up` خود 0 خواهد بود.
        //
        //    بنابراین بالشتک برگشتی ، وقتی به `len` اضافه شود ، بازدهی 0 دارد ، که به طور پیش فرض ترازبندی `align` را برآورده می کند.
        //
        // (البته ، تلاش برای تخصیص بلوکهایی از حافظه که اندازه و بالشتک آنها به روش بالا سرریز می شود ، باید باعث شود که تخصیص دهنده به هر حال خطایی ایجاد کند.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// با گرد کردن اندازه این طرح تا چند برابر از ترازبندی طرح ، یک طرح ایجاد می کند.
    ///
    ///
    /// این معادل اضافه کردن نتیجه `padding_needed_for` به اندازه فعلی طرح است.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // این نمی تواند سرریز شود.به نقل از نامعتبر طرح بندی:
        // > `size`, هنگامی که به نزدیکترین مضرب `align` گرد شوید ،
        // > نباید سرریز شود (یعنی مقدار گرد شده باید کمتر از باشد
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// برای توصیف رکورد نمونه های `n` `self` ، با مقدار مناسب پر کردن بین هر یک ، یک طرح ایجاد می کند تا اطمینان حاصل شود که به هر نمونه اندازه و تراز مورد نظر داده شده است.
    /// با موفقیت ، `(k, offs)` را برمی گرداند که `k` طرح آرایه است و `offs` فاصله بین شروع هر عنصر در آرایه است.
    ///
    /// در هنگام سرریز حساب ، `LayoutError` را برمی گرداند.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // این نمی تواند سرریز شود.به نقل از نامعتبر طرح بندی:
        // > `size`, هنگامی که به نزدیکترین مضرب `align` گرد شوید ،
        // > نباید سرریز شود (یعنی مقدار گرد شده باید کمتر از باشد
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // ایمنی: self.align از قبل معتبر شناخته شده است و تخصیص_بزرگ نیز معتبر بوده است
        // از قبل پر شده
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// یک طرح ایجاد می کند که شرح رکورد `self` و به دنبال آن `next` را توصیف می کند ، از جمله هرگونه پر کردن لازم برای اطمینان از تراز وسط قرار گرفتن `next` ، اما *بدون بالشتک عقب*.
    ///
    /// به منظور مطابقت با طرح نمایندگی C `repr(C)` ، پس از گسترش طرح با تمام قسمتها ، باید با `pad_to_align` تماس بگیرید.
    /// (هیچ راهی برای مطابقت با طرح نمایشی پیش فرض Rust `repr(Rust)`, as it is unspecified.) وجود ندارد
    ///
    /// توجه داشته باشید که ترازبندی چیدمان حاصل حداکثر `self` و `next` است تا از هم ترازی هر دو قسمت اطمینان حاصل شود.
    ///
    /// `Ok((k, offset))` را برمی گرداند ، جایی که `k` طرح رکورد بهم پیوسته است و `offset` مکان نسبی ، در بایت ، از شروع `next` جاسازی شده در رکورد متصل شده است (با فرض اینکه رکورد خودش از جبران 0 شروع می شود).
    ///
    ///
    /// در هنگام سرریز حساب ، `LayoutError` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// برای محاسبه طرح ساختار `#[repr(C)]` و جابجایی فیلدها از طرح زمینه های آن:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // به یاد داشته باشید که با `pad_to_align` نهایی کنید!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // تست کنید که کار می کند
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// یک طرح ایجاد می کند که شرح پرونده های `n` `self` را توصیف می کند ، بدون اینکه بین هر نمونه پر شود.
    ///
    /// توجه داشته باشید که ، بر خلاف `repeat` ، `repeat_packed` تضمین نمی کند که موارد تکراری `self` به درستی تراز شوند ، حتی اگر یک نمونه داده شده از `self` به درستی تراز شود.
    /// به عبارت دیگر ، اگر از طرح ارسالی `repeat_packed` برای اختصاص آرایه استفاده شود ، تضمین نمی شود که همه عناصر آرایه به درستی تراز شوند.
    ///
    /// در هنگام سرریز حساب ، `LayoutError` را برمی گرداند.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// ایجاد یک طرح توصیف رکورد برای `self` و پس از آن `next` بدون هیچ گونه بالشتک اضافی بین این دو.
    /// از آنجا که هیچ بالشتکی وارد نشده است ، تراز `next` بی ربط است ، و *اصلاً* در طرح حاصل گنجانده نشده است.
    ///
    ///
    /// در هنگام سرریز حساب ، `LayoutError` را برمی گرداند.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// یک طرح توصیف رکورد برای `[T; n]` ایجاد می کند.
    ///
    /// در هنگام سرریز حساب ، `LayoutError` را برمی گرداند.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// پارامترهای داده شده به `Layout::from_size_align` یا برخی دیگر از سازندگان `Layout` محدودیت های مستند آن را برآورده نمی کنند.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (ما این را برای impl پایین دستی خطای trait نیاز داریم)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}