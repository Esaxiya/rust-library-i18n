use crate::iter::FromIterator;

/// همه موارد واحد را از یک تکرارکننده در یک دیگر جمع می کند.
///
/// این مفیدتر است اگر با انتزاعات سطح بالاتر ترکیب شود ، مانند جمع آوری در `Result<(), E>` که فقط به خطاها اهمیت می دهید:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}