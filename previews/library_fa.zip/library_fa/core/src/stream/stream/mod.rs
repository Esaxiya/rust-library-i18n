use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// رابطی برای برخورد با تکرارکننده های ناهمزمان.
///
/// این جریان اصلی trait است.
/// برای اطلاعات بیشتر در مورد مفهوم پخش جریانی ، لطفاً به [module-level documentation] مراجعه کنید.
/// به طور خاص ، ممکن است بخواهید نحوه [implement `Stream`][impl] را بدانید.
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// نوع موارد تولید شده توسط جریان.
    type Item;

    /// تلاش برای بیرون کشیدن مقدار بعدی این جریان ، ثبت کار فعلی برای بیدار شدن از خواب اگر مقدار هنوز در دسترس نیست و بازگشت `None` در صورت اتمام جریان.
    ///
    /// # مقدار برگشتی
    ///
    /// چندین مقدار بازگشتی احتمالی وجود دارد ، هر کدام نشانگر یک جریان متمایز است:
    ///
    /// - `Poll::Pending` به این معنی است که مقدار بعدی این جریان هنوز آماده نیست.با اجرای این کار ، اطمینان حاصل می شود که هنگام آماده شدن مقدار بعدی ، کار فعلی مطلع خواهد شد.
    ///
    /// - `Poll::Ready(Some(val))` بدان معنی است که جریان با موفقیت مقداری `val` تولید کرده است و ممکن است مقادیر بیشتری در تماس های `poll_next` بعدی ایجاد کند.
    ///
    /// - `Poll::Ready(None)` به این معنی است که جریان خاتمه یافته است و `poll_next` نباید دوباره فراخوانی شود.
    ///
    /// # Panics
    ///
    /// پس از اتمام جریان (بازگشت `Ready(None)` from `poll_next`) ، فراخوانی مجدد روش `poll_next` ممکن است panic باشد ، برای همیشه مسدود شود یا مشکلات دیگری ایجاد کند ؛ `Stream` trait هیچ گونه الزامی در مورد تأثیرات چنین فراخوانی ندارد.
    ///
    /// با این حال ، چون روش `poll_next` با `unsafe` مشخص نشده است ، قوانین معمول Rust اعمال می شود: تماس ها هرگز نباید باعث رفتار نامشخص (تخریب حافظه ، استفاده نادرست از توابع `unsafe` یا موارد مشابه) شوند ، صرف نظر از وضعیت جریان.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// مرزهای باقی مانده جریان را برمی گرداند.
    ///
    /// به طور خاص ، `size_hint()` یک تاپل را برمی گرداند جایی که عنصر اول مرز پایین است و عنصر دوم مرز بالایی است.
    ///
    /// نیمه دوم tuple که بازگردانده می شود ، یک ["Option" """" usize "]" "است.
    /// [`None`] در اینجا بدان معنی است که یا کران بالایی مشخص نیست ، یا کران بالایی بزرگتر از [`usize`] است.
    ///
    /// # یادداشت های اجرایی
    ///
    /// اجرایی نمی شود که یک اجرای جریان تعداد اعلام شده عناصر را ارائه دهد.یک جریان حشره دار ممکن است کمتر از محدوده پایین یا بیشتر از حد بالایی عناصر باشد.
    ///
    /// `size_hint()` در درجه اول برای استفاده در بهینه سازی هایی مانند ذخیره سازی فضای برای عناصر جریان در نظر گرفته شده است ، اما نباید به عنوان مثال ، حذف چک های محدودیت در کد ناامن اعتماد کرد.
    /// اجرای نادرست `size_hint()` نباید منجر به نقض ایمنی حافظه شود.
    ///
    /// با این اوصاف ، این پیاده سازی باید برآورد صحیحی را ارائه دهد ، زیرا در غیر این صورت نقض پروتکل trait خواهد بود.
    ///
    /// اجرای پیش فرض ``(0 ،`` ```` ```` ```` `` `) برمی گرداند که برای هر جریانی صحیح است.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}