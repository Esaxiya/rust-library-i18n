//! اجرای SipHash.

#![allow(deprecated)] // انواع موجود در این ماژول منسوخ می شوند

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// اجرای SipHash 1-3.
///
/// این در حال حاضر عملکرد هش پیش فرض است که توسط کتابخانه استاندارد استفاده می شود (به عنوان مثال ، `collections::HashMap` به طور پیش فرض از آن استفاده می کند).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// اجرای SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// اجرای SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash یک عملکرد هش عمومی است: با سرعت خوبی اجرا می شود (قابل رقابت با Spooky و City) و هش کردن _keyed_ قوی را امکان پذیر می کند.
///
/// با این کار می توانید جداول هش خود را از یک RNG قوی مانند [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) کلید بزنید.
///
/// اگرچه الگوریتم SipHash به طور کلی قوی در نظر گرفته می شود ، اما برای اهداف رمزنگاری در نظر گرفته نشده است.
/// به همین ترتیب ، تمام کاربردهای رمزنگاری این پیاده سازی _strongly discouraged_ است.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // چه تعداد بایت پردازش کرده ایم
    state: State,  // دولت هش
    tail: u64,     // بایت پردازش نشده le
    ntail: usize,  // چند بایت در دم معتبر است
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 و v1 ، v3 به صورت جفت در الگوریتم نشان داده می شوند و در پیاده سازی simd از SipHash از vectors از v02 و v13 استفاده می شود.
    //
    // با قرار دادن آنها به ترتیب در ساختار ، کامپایلر می تواند به تنهایی چند بهینه سازی simd را انتخاب کند.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// یک عدد صحیح از نوع مورد نظر را به ترتیب LE از یک جریان بایت بارگیری می کند.
/// از `copy_nonoverlapping` استفاده می کند تا به کامپایلر بتواند کارآمدترین روش را برای بارگذاری آن از یک آدرس احتمالاً بدون تراز ایجاد کند.
///
///
/// ناامن زیرا: نمایه سازی نشده در i..i+size_of(int_ty) بررسی نشده است
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// u64 را با استفاده از حداکثر 7 بایت قطعه بایت بارگیری می کند.
/// به نظر ناهنجار است اما تماس های `copy_nonoverlapping` که رخ می دهد (از طریق `load_int_le!`) همه دارای اندازه های ثابت هستند و از تماس با `memcpy` که برای سرعت مناسب است خودداری می کنند.
///
///
/// ناامن زیرا: در آغاز نمایه سازی علامت گذاری نشده است..استارت + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // شاخص بایت جریان (از LSB) در خروجی u64
    let mut out = 0;
    if i + 3 < len {
        // ایمنی: `i` نمی تواند از `len` بیشتر باشد ، و تماس گیرنده باید تضمین کند
        // که شاخص شروع می شود .. شروع + len در مرز است.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // ایمنی: همانند بالا.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // ایمنی: همانند بالا.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// با دو کلید اولیه تنظیم شده روی 0 ، `SipHasher` جدید ایجاد می کند.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// `SipHasher` ایجاد می کند که از کلیدهای ارائه شده کلید خورده است.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// با دو کلید اولیه تنظیم شده روی 0 ، `SipHasher13` جدید ایجاد می کند.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// `SipHasher13` ایجاد می کند که از کلیدهای ارائه شده کلید خورده است.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: هیچ روش هش عددی صحیح ("write_u *" ، `write_i*`) تعریف نشده است
    // برای این نوع
    // ما می توانیم آنها را اضافه کنیم ، پیاده سازی `short_write` را در librustc_data_structures/sip128.rs کپی کنیم و روش های `write_u *`/`write_i*` را به `SipHasher` ، `SipHasher13` و `DefaultHasher` اضافه کنیم.
    //
    // این باعث می شود سرعت هش کردن عدد صحیح توسط آن هش ها بسیار زیاد شود ، و این در هزینه های اندکی کاهش سرعت کامپایل در برخی از معیارها است.
    // برای جزئیات بیشتر به #69152 مراجعه کنید.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // ایمنی: `cmp::min(length, needed)` بیش از `length` تضمین شده نیست
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // دم بافر اکنون سرخ شده است ، ورودی جدید را پردازش کنید.
        let len = length - needed;
        let left = len & 0x7; // len٪ 8

        let mut i = needed;
        while i < len - left {
            // ایمنی: زیرا `len - left` بزرگترین مضرب از 8 زیر است
            // `len`, و از آنجا که `i` از `needed` شروع می شود که `len` `length - needed` است ، `i + 8` کمتر یا برابر `length` است.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // ایمنی: `i` اکنون `needed + len.div_euclid(8) * 8` است ،
        // بنابراین `i + left` = `needed + len` = `length` ، که طبق تعریف برابر با `msg.len()` است.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// `Hasher<S>` را با دو کلید اولیه تنظیم شده روی 0 ایجاد می کند.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}