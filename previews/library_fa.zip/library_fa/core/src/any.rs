//! این ماژول `Any` trait را اجرا می کند ، که تایپ کردن پویا از هر نوع `'static` را از طریق بازتاب زمان اجرا امکان پذیر می کند.
//!
//! `Any` خود می تواند برای بدست آوردن `TypeId` استفاده شود و در صورت استفاده به عنوان یک شی trait دارای ویژگی های بیشتری است.
//! به عنوان `&dyn Any` (یک شی trait قرض گرفته شده) ، این روش `is` و `downcast_ref` را دارد ، برای آزمایش اینکه آیا مقدار موجود از یک نوع مشخص است یا خیر ، و برای گرفتن مقدار داخلی به عنوان یک نوع.
//! به عنوان `&mut dyn Any` ، روش `downcast_mut` نیز برای بدست آوردن ارجاع قابل تغییر به مقدار داخلی وجود دارد.
//! `Box<dyn Any>` روش `downcast` را اضافه می کند ، که سعی در تبدیل آن به `Box<T>` دارد.
//! برای جزئیات کامل به اسناد [`Box`] مراجعه کنید.
//!
//! توجه داشته باشید که `&dyn Any` محدود به آزمایش این است که آیا مقداری از نوع بتن مشخص است یا خیر ، و نمی توان برای آزمایش اینکه آیا یک نوع trait را پیاده سازی می کند ، استفاده شود.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # اشاره گرهای هوشمند و `dyn Any`
//!
//! رفتاری که باید هنگام استفاده از `Any` به عنوان یک شی trait به خاطر بسپارید ، به ویژه در انواع مختلفی مانند `Box<dyn Any>` یا `Arc<dyn Any>` ، این است که صرف فراخوانی `.type_id()` روی مقدار ، `TypeId`*کانتینر* را تولید می کند ، نه جسم زیرین trait.
//!
//! با تبدیل نشانگر هوشمند به `&dyn Any` ، که `TypeId` جسم را برمی گرداند ، می توان از این امر جلوگیری کرد.
//! مثلا:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // به احتمال زیاد این را می خواهید:
//! let actual_id = (&*boxed).type_id();
//! // ... از این:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! شرایطی را در نظر بگیرید که می خواهیم مقداری را که به یک تابع ارسال شده است از سیستم خارج کنیم.
//! ما از ارزشی که روی آن کار می کنیم می دانیم Debug را پیاده سازی می کند ، اما نوع بتن آن را نمی دانیم.ما می خواهیم برای انواع خاصی درمان ویژه ای داشته باشیم: در این حالت طول مقادیر String را قبل از مقدار آنها چاپ می کنیم.
//! ما نوع بتن مقدار خود را در زمان کامپایل نمی دانیم ، بنابراین باید به جای آن از بازتاب زمان استفاده کنیم.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // عملکرد Logger برای هر نوع پیاده سازی اشکال زدایی.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // سعی کنید مقدار ما را به `String` تبدیل کنید.
//!     // در صورت موفقیت ، می خواهیم طول String` و همچنین مقدار آن را خارج کنیم.
//!     // در غیر این صورت ، نوع دیگری است: فقط آن را بدون تزئین چاپ کنید.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // این تابع می خواهد پارامتر خود را قبل از انجام کار با آن خارج کند.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... کارهای دیگری انجام دهید
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// هر trait
///////////////////////////////////////////////////////////////////////////////

/// یک trait برای شبیه سازی تایپ پویا.
///
/// اکثر انواع `Any` را پیاده سازی می کنند.با این حال ، هر نوع حاوی یک مرجع غیر "استاتیک" نیست.
/// برای جزئیات بیشتر به [module-level documentation][mod] مراجعه کنید.
///
/// [mod]: crate::any
// این trait ناامن نیست ، اگرچه ما به مشخصات عملکرد `type_id` impl آن در کد ناامن (به عنوان مثال `downcast`) اعتماد داریم.به طور معمول ، این یک مشکل است ، اما از آنجا که تنها مفهوم `Any` اجرای پتو است ، هیچ کد دیگری نمی تواند `Any` را پیاده سازی کند.
//
// ما می توانیم به طور قابل قبولی این trait را ناامن کنیم-این امر باعث خرابی نمی شود ، زیرا همه پیاده سازی ها را کنترل می کنیم-اما ما ترجیح می دهیم این کار را انجام ندهیم زیرا این امر واقعاً لازم نیست و ممکن است کاربران را در مورد تمایز روشهای traits ناامن و ناامن گیج کند (به عنوان مثال ، تماس با `type_id` هنوز ایمن است ، اما ما احتمالاً می خواهیم این را در اسناد نشان دهیم).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `TypeId` `self` را دریافت می کند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// روشهای داخلی برای هر شی trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// اطمینان حاصل کنید که می توانید نتیجه پیوستن به یک موضوع را چاپ کرده و از این رو با `unwrap` استفاده کنید.
// اگر اعزام با افزایش کار کند ، در نهایت دیگر نیازی نخواهد بود.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// اگر نوع جعبه ای همان `T` باشد ، `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // `TypeId` را از نوعی که این عملکرد با آن نمونه شده دریافت کنید.
        let t = TypeId::of::<T>();

        // `TypeId` از نوع را در شی Z trait (`self`) دریافت کنید.
        let concrete = self.type_id();

        // هر دو نوع TypeId را در مورد برابری مقایسه کنید.
        t == concrete
    }

    /// اگر از نوع `T` باشد ، یا اگر `None` نباشد ، مقداری ارجاع به مقدار جعبه ای برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // ایمنی: فقط بررسی کرد که آیا به نوع صحیح اشاره کرده ایم یا خیر ، و می توانیم به آن اعتماد کنیم
            // ایمنی حافظه را بررسی می کنند زیرا ما همه را برای همه انواع پیاده سازی کرده ایم.هیچ معنای دیگری نمی تواند وجود داشته باشد زیرا با مفاهیم ما مغایرت دارد.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// اگر از نوع `T` باشد ، یا اگر غیر از آن باشد `None` برخی از ارجاع های قابل تغییر را به مقدار جعبه ای برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // ایمنی: فقط بررسی کرد که آیا به نوع صحیح اشاره کرده ایم یا خیر ، و می توانیم به آن اعتماد کنیم
            // ایمنی حافظه را بررسی می کنند زیرا ما همه را برای همه انواع پیاده سازی کرده ایم.هیچ معنای دیگری نمی تواند وجود داشته باشد زیرا با مفاهیم ما مغایرت دارد.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// به روشی که روی نوع `Any` تعریف شده است ، هدایت می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// به روشی که روی نوع `Any` تعریف شده است ، هدایت می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// به روشی که روی نوع `Any` تعریف شده است ، هدایت می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// به روشی که روی نوع `Any` تعریف شده است ، هدایت می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// به روشی که روی نوع `Any` تعریف شده است ، هدایت می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// به روشی که روی نوع `Any` تعریف شده است ، هدایت می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID و روش های آن
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` یک شناسه جهانی منحصر به فرد برای یک نوع است.
///
/// هر `TypeId` یک شی مات است که اجازه نمی دهد از داخل آن بازدید کنید اما اجازه می دهد عملیات اساسی مانند شبیه سازی ، مقایسه ، چاپ و نمایش انجام شود.
///
///
/// `TypeId` در حال حاضر فقط برای انواع مربوط به `'static` در دسترس است ، اما ممکن است این محدودیت در future برداشته شود.
///
/// در حالی که `TypeId` `Hash` ، `PartialOrd` و `Ord` را پیاده سازی می کند ، لازم به ذکر است که هش و ترتیب در نسخه های Rust متفاوت خواهد بود.
/// مراقب باشید که در کد خود به آنها اعتماد کنید!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// `TypeId` را از نوعی که این عملکرد عمومی با آن نمونه شده است برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// نام یک نوع را به عنوان برش رشته ای برمی گرداند.
///
/// # Note
///
/// این برای استفاده تشخیصی در نظر گرفته شده است.
/// محتوای دقیق و قالب رشته برگشتی مشخص نیست ، به غیر از توصیف بهترین نوع.
/// به عنوان مثال ، از جمله رشته هایی که `type_name::<Option<String>>()` ممکن است برگرداند ، `"Option<String>"` و `"std::option::Option<std::string::String>"` است.
///
///
/// رشته برگشتی نباید یک شناسه منحصر به فرد از یک نوع در نظر گرفته شود زیرا انواع مختلفی ممکن است با همان نام نوع یکپارچه شوند.
/// به همین ترتیب ، هیچ تضمینی وجود ندارد که تمام قسمت های یک نوع در رشته برگشتی ظاهر شوند: به عنوان مثال ، مشخص کننده های طول عمر در حال حاضر شامل نمی شوند.
/// علاوه بر این ، ممکن است خروجی بین نسخه های کامپایلر تغییر کند.
///
/// پیاده سازی فعلی از زیرساخت مشابه تشخیص دهنده کامپایلر و رفع اشکال استفاده می کند ، اما این تضمین نمی شود.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// نام نوع مقدار اشاره شده به عنوان قطعه رشته ای را برمی گرداند.
/// این همان `type_name::<T>()` است ، اما درصورتی که نوع متغیر به راحتی در دسترس نباشد ، می تواند مورد استفاده قرار گیرد.
///
/// # Note
///
/// این برای استفاده تشخیصی در نظر گرفته شده است.محتوای دقیق و قالب رشته مشخص نشده است ، به غیر از توصیف بهترین نوع.
/// به عنوان مثال ، `type_name_of_val::<Option<String>>(None)` می تواند `"Option<String>"` یا `"std::option::Option<std::string::String>"` را بازگرداند ، اما `"foobar"` را باز نمی گرداند.
///
/// علاوه بر این ، ممکن است خروجی بین نسخه های کامپایلر تغییر کند.
///
/// این عملکرد اشیا Z trait را حل نمی کند ، به این معنی که `type_name_of_val(&7u32 as &dyn Debug)` ممکن است `"dyn Debug"` را بازگرداند ، اما `"u32"` را باز نمی گرداند.
///
/// نام نوع نباید یک شناسه منحصر به فرد از یک نوع در نظر گرفته شود.
/// چندین نوع ممکن است از همان نام یکسان استفاده کنند.
///
/// پیاده سازی فعلی از زیرساخت مشابه تشخیص دهنده کامپایلر و رفع اشکال استفاده می کند ، اما این تضمین نمی شود.
///
/// # Examples
///
/// انواع صحیح و float پیش فرض را چاپ می کند.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}