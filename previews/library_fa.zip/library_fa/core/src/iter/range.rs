use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// اشیایی که مفهوم عملیات *جانشین* و *سلف* دارند.
///
/// عملیات *جانشین* به سمت مقادیری حرکت می کند که مقایسه بیشتری داشته باشند.
/// عملیات *سلف* به سمت مقادیری حرکت می کند که مقایسه کمتری دارند.
///
/// # Safety
///
/// این trait `unsafe` است زیرا اجرای آن برای ایمنی پیاده سازی `unsafe trait TrustedLen` باید صحیح باشد ، و در غیر اینصورت می توان با استفاده از کد `unsafe` نتایج صحیح و تعهدات ذکر شده را به نتایج استفاده از این trait اعتماد کرد.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// تعداد مراحل جانشین * لازم برای رسیدن از `start` به `end` را برمی گرداند.
    ///
    /// اگر تعداد مراحل `usize` سرریز شود (یا نامحدود باشد ، یا اگر هرگز به `end` نرسید) `None` را برمی گرداند.
    ///
    ///
    /// # Invariants
    ///
    /// برای هر `a` ، `b` و `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` اگر و فقط اگر `Step::forward_checked(&a, n) == Some(b)` باشد
    /// * `steps_between(&a, &b) == Some(n)` اگر و فقط اگر `Step::backward_checked(&a, n) == Some(a)` باشد
    /// * `steps_between(&a, &b) == Some(n)` فقط اگر `a <= b` باشد
    ///   * نتیجه گیری: `steps_between(&a, &b) == Some(0)` اگر و فقط اگر `a == b` باشد
    ///   * توجه داشته باشید که `a <= b` به معنای _not_ است به `steps_between(&a, &b) != None`.
    ///     این مورد زمانی است که برای رسیدن به `b` بیش از مراحل `usize::MAX` نیاز است
    /// * `steps_between(&a, &b) == None` اگر `a > b` باشد
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// مقداری را که با گرفتن *جانشین*`self` `count` بار به دست می آید ، برمی گرداند.
    ///
    /// اگر این طیف وسیعی از مقادیر پشتیبانی شده توسط `Self` را سرریز می کند ، `None` را برمی گرداند.
    ///
    /// # Invariants
    ///
    /// برای هر `a` ، `n` و `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// برای هر `a` ، `n` و `m` که `n + m` سرریز نمی شود:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// برای هر `a` و `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// مقداری را که با گرفتن *جانشین*`self` `count` بار به دست می آید ، برمی گرداند.
    ///
    /// اگر این طیف وسیعی از مقادیر پشتیبانی شده توسط `Self` را سرریز کند ، این عملکرد به panic ، بسته بندی یا اشباع مجاز است.
    ///
    /// رفتار پیشنهادی این است که panic هنگام فعال کردن ادعای اشکال زدایی و بسته بندی یا اشباع در غیر این صورت.
    ///
    /// کد ناامن نباید به درستی رفتار پس از سرریز متکی باشد.
    ///
    /// # Invariants
    ///
    /// برای هر `a` ، `n` و `m` ، جایی که هیچ سرریز رخ نمی دهد:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// برای هر `a` و `n` ، جایی که هیچ سرریز رخ نمی دهد:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// مقداری را که با گرفتن *جانشین*`self` `count` بار به دست می آید ، برمی گرداند.
    ///
    /// # Safety
    ///
    /// رفتاری تعریف نشده برای این عملیات این است که طیف وسیعی از مقادیر پشتیبانی شده توسط `Self` را سرریز کند.
    /// اگر نمی توانید تضمین کنید که این سرریز نخواهد شد ، به جای آن از `forward` یا `forward_checked` استفاده کنید.
    ///
    /// # Invariants
    ///
    /// برای هر `a`:
    ///
    /// * اگر `b` مانند `b > a` وجود داشته باشد ، تماس با `Step::forward_unchecked(a, 1)` بی خطر است
    /// * در صورت وجود `b`، `n` مانند `steps_between(&a, &b) == Some(n)` ، تماس با `Step::forward_unchecked(a, m)` برای هر `m <= n` بی خطر است.
    ///
    ///
    /// برای هر `a` و `n` ، جایی که هیچ سرریز رخ نمی دهد:
    ///
    /// * `Step::forward_unchecked(a, n)` معادل `Step::forward(a, n)` است
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// مقداری را که با گرفتن *پیشینی*`self` `count` بار به دست می آید ، برمی گرداند.
    ///
    /// اگر این طیف وسیعی از مقادیر پشتیبانی شده توسط `Self` را سرریز می کند ، `None` را برمی گرداند.
    ///
    /// # Invariants
    ///
    /// برای هر `a` ، `n` و `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// برای هر `a` و `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// مقداری را که با گرفتن *پیشینی*`self` `count` بار به دست می آید ، برمی گرداند.
    ///
    /// اگر این طیف وسیعی از مقادیر پشتیبانی شده توسط `Self` را سرریز کند ، این عملکرد به panic ، بسته بندی یا اشباع مجاز است.
    ///
    /// رفتار پیشنهادی این است که panic هنگام فعال کردن ادعای اشکال زدایی و بسته بندی یا اشباع در غیر این صورت.
    ///
    /// کد ناامن نباید به درستی رفتار پس از سرریز متکی باشد.
    ///
    /// # Invariants
    ///
    /// برای هر `a` ، `n` و `m` ، جایی که هیچ سرریز رخ نمی دهد:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// برای هر `a` و `n` ، جایی که هیچ سرریز رخ نمی دهد:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// مقداری را که با گرفتن *پیشینی*`self` `count` بار به دست می آید ، برمی گرداند.
    ///
    /// # Safety
    ///
    /// رفتاری تعریف نشده برای این عملیات این است که طیف وسیعی از مقادیر پشتیبانی شده توسط `Self` را سرریز کند.
    /// اگر نمی توانید تضمین کنید که این سرریز نخواهد شد ، به جای آن از `backward` یا `backward_checked` استفاده کنید.
    ///
    /// # Invariants
    ///
    /// برای هر `a`:
    ///
    /// * اگر `b` مانند `b < a` وجود داشته باشد ، تماس با `Step::backward_unchecked(a, 1)` بی خطر است
    /// * در صورت وجود `b`، `n` مانند `steps_between(&b, &a) == Some(n)` ، تماس با `Step::backward_unchecked(a, m)` برای هر `m <= n` بی خطر است.
    ///
    ///
    /// برای هر `a` و `n` ، جایی که هیچ سرریز رخ نمی دهد:
    ///
    /// * `Step::backward_unchecked(a, n)` معادل `Step::backward(a, n)` است
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// اینها هنوز به صورت ماکرو تولید می شوند زیرا کلمات کلیدی عدد صحیح به انواع مختلف تقسیم می شوند.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // ایمنی: تماس گیرنده باید تضمین کند که `start + n` سرریز نمی شود.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // ایمنی: تماس گیرنده باید تضمین کند که `start - n` سرریز نمی شود.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // در ساخت اشکال زدایی ، panic را هنگام سرریز تحریک کنید.
            // این باید در ساخت نسخه به طور کامل بهینه شود.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // برای اجازه دادن به مثال ، ریاضیات پیچیده ای انجام دهید `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // در ساخت اشکال زدایی ، panic را هنگام سرریز تحریک کنید.
            // این باید در ساخت نسخه به طور کامل بهینه شود.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // برای اجازه دادن به مثال ، ریاضیات پیچیده ای انجام دهید `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // این به $u_narrower <=استفاده کردن متکی است
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // اگر n خارج از محدوده باشد ، `unsigned_start + n` نیز بیش از حد است
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // اگر n خارج از محدوده باشد ، `unsigned_start - n` نیز بیش از حد است
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // این به $i_narrower <=استفاده کردن متکی است
                        //
                        // ریخته گری برای ایزو ، عرض را گسترش می دهد اما علامت را حفظ می کند.
                        // برای محاسبه تفاوتی که ممکن است در محدوده isize نباشد ، از wrapping_sub در فضای isize و cast برای استفاده استفاده کنید.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // بسته بندی مواردی مانند `Step::forward(-120_i8, 200) == Some(80_i8)` را مدیریت می کند ، حتی اگر 200 برای i8 خارج از محدوده باشد.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // اضافات سرریز کرد
                            }
                        }
                        // اگر n خارج از محدوده مثلا باشد
                        // u8, پس از آن بزرگتر از کل دامنه i8 گسترده است بنابراین `any_i8 + n` لزوماً i8 سرریز می کند.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // بسته بندی مواردی مانند `Step::forward(-120_i8, 200) == Some(80_i8)` را مدیریت می کند ، حتی اگر 200 برای i8 خارج از محدوده باشد.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // تفریق سرریز شد
                            }
                        }
                        // اگر n خارج از محدوده مثلا باشد
                        // u8, پس از آن بزرگتر از کل دامنه i8 گسترده است بنابراین `any_i8 - n` لزوماً i8 سرریز می کند.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // اگر تفاوت برای مثال خیلی زیاد باشد
                            // i128 ، همچنین برای استفاده با بیت های کمتر نیز بسیار بزرگ است.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // SAFETY: res یک مقیاس معتبر یونی کد است
            // (زیر 0x110000 و نه در 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // SAFETY: res یک مقیاس معتبر یونی کد است
        // (زیر 0x110000 و نه در 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ایمنی: تماس گیرنده باید تضمین کند که این سرریز نمی شود
        // دامنه مقادیر برای یک کاراکتر.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // ایمنی: تماس گیرنده باید تضمین کند که این سرریز نمی شود
            // دامنه مقادیر برای یک کاراکتر.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // ایمنی: به دلیل قرارداد قبلی ، این تضمین شده است
        // توسط تماس گیرنده یک کاراکتر معتبر باشد.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // ایمنی: تماس گیرنده باید تضمین کند که این سرریز نمی شود
        // دامنه مقادیر برای یک کاراکتر.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // ایمنی: تماس گیرنده باید تضمین کند که این سرریز نمی شود
            // دامنه مقادیر برای یک کاراکتر.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // ایمنی: به دلیل قرارداد قبلی ، این تضمین شده است
        // توسط تماس گیرنده یک کاراکتر معتبر باشد.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // ایمنی: فقط پیش شرط بررسی شده است
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // ایمنی: فقط پیش شرط بررسی شده است
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// این ماکروها مدلهای `ExactSizeIterator` را برای انواع مختلف تولید می کنند.
//
// * `ExactSizeIterator::len` برای بازگرداندن دقیق `usize` لازم است ، بنابراین هیچ محدوده ای نمی تواند بیشتر از `usize::MAX` باشد.
//
// * در مورد انواع صحیح در `Range<_>` این مورد در مورد انواع باریک تر یا گسترده تر از `usize` وجود دارد.
//   در مورد انواع عدد صحیح در `RangeInclusive<_>` ، این مورد در مورد انواع * کاملاً باریک تر از `usize` وجود دارد
//   `(0..=u64::MAX).len()` `u64::MAX + 1` خواهد بود
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // این موارد از نظر استدلال بالا غیرقابل جمع هستند ، اما از بین بردن آنها تغییر مهمی خواهد بود زیرا در Rust 1.0.0 تثبیت شده اند.
    // بنابراین به عنوان مثال
    // `(0..66_000_u32).len()` به عنوان مثال بدون خطا یا هشدار در سیستم عامل های 16 بیتی کامپایل می شود ، اما همچنان نتیجه اشتباه می دهید.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // این موارد از نظر استدلال بالا غیرقابل جمع هستند ، اما از بین بردن آنها تغییر مهمی خواهد بود زیرا در Rust 1.26.0 تثبیت شده اند.
    // بنابراین به عنوان مثال
    // `(0..=u16::MAX).len()` به عنوان مثال بدون خطا یا هشدار در سیستم عامل های 16 بیتی کامپایل می شود ، اما همچنان نتیجه اشتباه می دهید.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // ایمنی: فقط پیش شرط بررسی شده است
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // ایمنی: فقط پیش شرط بررسی شده است
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ایمنی: فقط پیش شرط بررسی شده است
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ایمنی: فقط پیش شرط بررسی شده است
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // ایمنی: فقط پیش شرط بررسی شده است
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // ایمنی: فقط پیش شرط بررسی شده است
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}