use crate::fmt;

/// یک تکرار کننده جدید ایجاد می کند که در آن هر تکرار بسته شدن ارائه شده را `F: FnMut() -> Option<T>` می نامد.
///
/// این اجازه می دهد تا یک تکرارکننده سفارشی با هر رفتاری ایجاد کنید بدون استفاده از نحو صریح تر ، ایجاد یک نوع اختصاصی و پیاده سازی [`Iterator`] trait برای آن.
///
/// توجه داشته باشید که تکرار کننده `FromFn` فرضیاتی در مورد رفتار بسته نمی کند و بنابراین محافظه کارانه [`FusedIterator`] را اجرا نمی کند یا [`Iterator::size_hint()`] را از `(0, None)` پیش فرض خود نادیده می گیرد.
///
///
/// این بسته می تواند از عکسها و محیط آن برای ردیابی وضعیت تکرارها استفاده کند.بسته به نحوه استفاده از تکرار کننده ، این ممکن است نیاز به تعیین کلمه کلیدی [`move`] در بسته شدن داشته باشد.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// بیایید تکرار کننده شمارنده را از [module-level documentation] دوباره پیاده سازی کنیم:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // تعداد ما را افزایش دهید.به همین دلیل است که ما از صفر شروع کردیم.
///     count += 1;
///
///     // بررسی کنید که آیا شمارش را به پایان رسانده ایم یا نه.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// تکرارکننده ای که هر تکرار بسته شدن ارائه شده را `F: FnMut() -> Option<T>` می خواند.
///
/// این `struct` توسط عملکرد [`iter::from_fn()`] ایجاد شده است.
/// برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}