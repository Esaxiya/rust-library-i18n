use crate::iter::{FusedIterator, TrustedLen};

/// یک تکرار کننده ایجاد می کند که یک عنصر را دقیقاً یک بار بازده می کند.
///
/// این معمولاً برای انطباق یک مقدار واحد با [`chain()`] از انواع دیگر تکرار استفاده می شود.
/// شاید شما یک تکرار کننده داشته باشید که تقریباً همه چیز را پوشش می دهد ، اما شما به یک مورد خاص اضافی نیاز دارید.
/// شاید شما تابعی داشته باشید که روی تکرار کننده ها کار کند ، اما فقط باید یک مقدار را پردازش کنید.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::iter;
///
/// // یکی تنها ترین شماره است
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // فقط یک ، این چیزی است که به دست می آوریم
/// assert_eq!(None, one.next());
/// ```
///
/// زنجیر زدن با تکرار کننده دیگر.
/// بیایید بگوییم که ما می خواهیم بیش از هر پرونده از پوشه `.foo` ، بلکه یک فایل پیکربندی را تکرار کنیم ،
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ما باید از یک تکرار کننده DirEntry-s به یک تکرار کننده از PathBufs تبدیل کنیم ، بنابراین ما از نقشه استفاده می کنیم
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // اکنون تکرار کننده ما فقط برای فایل پیکربندی ماست
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // دو تکرار کننده را با هم در یک تکرار بزرگ قرار دهید
/// let files = dirs.chain(config);
///
/// // این به ما تمام پرونده های موجود در .foo و همچنین .foorc را می دهد
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// تکرار کننده ای که دقیقاً یک بار یک عنصر را بازده می کند.
///
/// این `struct` توسط عملکرد [`once()`] ایجاد شده است.برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}