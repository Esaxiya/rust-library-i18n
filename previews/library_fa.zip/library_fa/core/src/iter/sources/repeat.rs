use crate::iter::{FusedIterator, TrustedLen};

/// تکرار کننده جدیدی ایجاد می کند که یک عنصر را به طور بی وقفه تکرار می کند.
///
/// عملکرد `repeat()` یک مقدار را بارها و بارها تکرار می کند.
///
/// تکرارهای بی نهایت مانند `repeat()` اغلب با آداپتورهایی مانند [`Iterator::take()`] مورد استفاده قرار می گیرند تا محدود شوند.
///
/// اگر نوع عنصر تکرار کننده مورد نیاز شما `Clone` را پیاده سازی نمی کند ، یا اگر نمی خواهید عنصر تکرار شده را در حافظه نگه دارید ، می توانید در عوض از عملکرد [`repeat_with()`] استفاده کنید.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::iter;
///
/// // عدد چهار 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // بله ، هنوز چهار
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// با [`Iterator::take()`] محدود می شوید:
///
/// ```
/// use std::iter;
///
/// // که آخرین مثال خیلی چهار برابر بود.بیایید فقط چهار چهار نفر داشته باشیم.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... و اکنون کار ما تمام شده است
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// تکرار کننده ای که یک عنصر را بی وقفه تکرار می کند.
///
/// این `struct` توسط عملکرد [`repeat()`] ایجاد شده است.برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}