use crate::iter::{FusedIterator, TrustedLen};

/// تکرار کننده جدیدی ایجاد می کند که عناصر نوع `A` را با استفاده از بسته بند ارائه شده ، تکرار کننده ، بی وقفه تکرار می کند `F: FnMut() -> A`.
///
/// عملکرد `repeat_with()` بارها و بارها با تکرار کننده تماس می گیرد.
///
/// تکرارهای بی نهایت مانند `repeat_with()` اغلب با آداپتورهایی مانند [`Iterator::take()`] مورد استفاده قرار می گیرند تا محدود شوند.
///
/// اگر نوع عنصر تکرار کننده مورد نیاز شما [`Clone`] را پیاده سازی می کند و نگه داشتن عنصر منبع در حافظه مشکلی نیست ، درعوض باید از عملکرد [`repeat()`] استفاده کنید.
///
///
/// تکرار کننده تولید شده توسط `repeat_with()` [`DoubleEndedIterator`] نیست.
/// اگر برای بازگرداندن [`DoubleEndedIterator`] به `repeat_with()` نیاز دارید ، لطفاً یک مسئله GitHub را باز کنید و در مورد مورد استفاده خود توضیح دهد.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::iter;
///
/// // بیایید فرض کنیم مقداری از نوعی داریم که `Clone` نیست یا هنوز نمی خواهد حافظه داشته باشد زیرا گران است:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // یک ارزش خاص برای همیشه:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// استفاده از جهش و محدود شدن:
///
/// ```rust
/// use std::iter;
///
/// // از صفر تا قدرت سوم دو:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... و اکنون کار ما تمام شده است
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// تکرار کننده ای که عناصر نوع `A` را با استفاده از بسته `F: FnMut() -> A` ارائه شده بی وقفه تکرار می کند.
///
///
/// این `struct` توسط عملکرد [`repeat_with()`] ایجاد شده است.
/// برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}