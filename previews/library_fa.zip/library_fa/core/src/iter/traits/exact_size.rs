/// تکرار کننده ای که طول دقیق خود را می داند.
///
/// بسیاری از [تکرار کنندگان] نمی دانند که چند بار تکرار می شوند ، اما برخی از آنها می دانند.
/// اگر تکرار کننده بداند که چند بار می تواند تکرار کند ، دسترسی به آن اطلاعات می تواند مفید باشد.
/// به عنوان مثال ، اگر می خواهید به عقب برگردید ، یک شروع خوب این است که بدانید پایان آن کجاست.
///
/// هنگام اجرای `ExactSizeIterator` ، باید [`Iterator`] را نیز پیاده سازی کنید.
/// هنگام انجام این کار ، اجرای [`Iterator::size_hint`]*باید* اندازه دقیق تکرار کننده را برگرداند.
///
/// روش [`len`] یک پیش فرض دارد ، بنابراین معمولاً نباید آن را پیاده سازی کنید.
/// با این حال ، شما ممکن است بتوانید اجرای کارآمدتری نسبت به حالت پیش فرض ارائه دهید ، بنابراین غلبه بر آن در این مورد منطقی است.
///
///
/// توجه داشته باشید که این trait یک trait امن است و به همین ترتیب *صحت* و *نمی تواند* تضمین کننده درست بودن برگردانده شده باشد.
/// این بدان معنی است که کد `unsafe` ** نباید به صحت [`Iterator::size_hint`] اعتماد کند.
/// [`TrustedLen`](super::marker::TrustedLen) trait ناپایدار و ناامن این ضمانت اضافی را می دهد.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// // یک محدود محدود دقیقاً می داند که چند بار تکرار می شود
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// در [module-level docs] ، ما [`Iterator`] را اجرا کردیم ، `Counter`.
/// بیایید `ExactSizeIterator` را برای آن نیز پیاده سازی کنیم:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ما می توانیم تعداد تکرارهای باقی مانده را به راحتی محاسبه کنیم.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // و حالا ما می توانیم از آن استفاده کنیم!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// طول دقیق تکرار کننده را برمی گرداند.
    ///
    /// پیاده سازی تضمین می کند که تکرار کننده دقیقاً `len()` برابر مقدار [`Some(T)`] قبل از بازگشت [`None`] بازگرداند.
    ///
    /// این روش یک اجرای پیش فرض دارد ، بنابراین معمولاً نباید مستقیماً آن را اجرا کنید.
    /// با این حال ، اگر می توانید اجرای کارآمدتری ارائه دهید ، می توانید این کار را انجام دهید.
    /// برای مثال به اسناد [trait-level] مراجعه کنید.
    ///
    /// این عملکرد همان تضمین های ایمنی عملکرد [`Iterator::size_hint`] را دارد.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// // یک محدود محدود دقیقاً می داند که چند بار تکرار می شود
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: این ادعا بیش از حد دفاعی است ، اما این امر ثابت را بررسی می کند
        // تضمین شده توسط trait.
        // اگر این trait داخلی rust بود ، می توانستیم از debug_assert استفاده کنیم !؛assert_eq!تمام پیاده سازی های کاربر Rust را نیز بررسی می کند.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// اگر تکرار کننده خالی باشد ، `true` را برمی گرداند.
    ///
    /// این روش با استفاده از [`ExactSizeIterator::len()`] یک پیش فرض دارد ، بنابراین نیازی نیست که خودتان آن را پیاده سازی کنید.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}