// ignore-tidy-filelength این پرونده تقریباً منحصراً از تعریف `Iterator` تشکیل شده است.
// ما نمی توانیم آن را به چندین پرونده تقسیم کنیم.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// رابط کاربری برای برخورد با تکرارکننده ها.
///
/// این تکرار کننده اصلی trait است.
/// برای اطلاعات بیشتر در مورد مفهوم تکرار کننده ها به طور کلی ، لطفاً به [module-level documentation] مراجعه کنید.
/// به طور خاص ، ممکن است بخواهید نحوه [implement `Iterator`][impl] را بدانید.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// نوع عناصر تکرار شونده.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// از تکرار کننده پیش می رود و مقدار بعدی را برمی گرداند.
    ///
    /// [`None`] را پس از اتمام تکرار برمی گرداند.
    /// پیاده سازی های تکرار کننده فردی ممکن است تصمیم بگیرند که تکرار را از سر بگیرند ، بنابراین تماس مجدد با `next()` ممکن است در بعضی از زمان ها دوباره بازگشت [`Some(Item)`] را شروع کند یا نکنه.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // تماس با next() مقدار بعدی را برمی گرداند ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... و بعد هیچکدام که تمام شد
    /// assert_eq!(None, iter.next());
    ///
    /// // تماس های بیشتر ممکن است `None` را بازگرداند یا بازگرداند.در اینجا ، آنها همیشه خواهند شد.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// حدود باقی مانده تکرار کننده را برمی گرداند.
    ///
    /// به طور خاص ، `size_hint()` یک تاپل را برمی گرداند جایی که عنصر اول مرز پایین است و عنصر دوم مرز بالایی است.
    ///
    /// نیمه دوم tuple که بازگردانده می شود ، یک ["Option" """" usize "]" "است.
    /// [`None`] در اینجا بدان معنی است که یا کران بالایی مشخص نیست ، یا کران بالایی بزرگتر از [`usize`] است.
    ///
    /// # یادداشت های اجرایی
    ///
    /// اجرا نمی شود که یک اجرای تکرار کننده تعداد عناصر اعلام شده را ارائه دهد.یک تکرار کننده باگی ممکن است کمتر از محدوده پایین یا بیشتر از قسمت بالایی عناصر باشد.
    ///
    /// `size_hint()` در درجه اول برای استفاده در بهینه سازی هایی مانند ذخیره سازی فضای برای عناصر تکرارکننده مورد استفاده قرار می گیرد ، اما نباید به عنوان مثال ، حذف چک های محدود در کد ناامن اعتماد کرد.
    /// اجرای نادرست `size_hint()` نباید منجر به نقض ایمنی حافظه شود.
    ///
    /// با این اوصاف ، این پیاده سازی باید برآورد صحیحی را ارائه دهد ، زیرا در غیر این صورت نقض پروتکل trait خواهد بود.
    ///
    /// پیاده سازی پیش فرض ``(0 ،`` ```` ```` ```` `` `) برمی گرداند
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// یک مثال پیچیده تر:
    ///
    /// ```
    /// // اعداد زوج از صفر تا ده.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ممکن است از صفر تا ده بار تکرار کنیم.
    /// // دانستن اینکه پنج دقیقاً بدون اجرای filter() امکان پذیر نیست.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // بیایید با chain() پنج عدد دیگر اضافه کنیم
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // اکنون هر دو مرز پنج افزایش یافته است
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// بازگشت `None` برای حد بالا:
    ///
    /// ```
    /// // یک تکرار کننده نامحدود هیچ حد بالایی و حداکثر حد ممکن پایین ندارد
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// تکرار کننده را مصرف می کند ، تعداد تکرارها را می شمارد و برگرداند.
    ///
    /// این روش تا زمانی که [`None`] مشاهده نشود ، [`next`] را به طور مکرر فراخوانی می کند و تعداد دفعات مشاهده [`Some`] را برمی گرداند.
    /// توجه داشته باشید که [`next`] باید حداقل یک بار فراخوانی شود حتی اگر تکرار کننده هیچ عنصری نداشته باشد.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # رفتار سرریز
    ///
    /// این روش هیچ گونه محافظتی در برابر سرریز نمی کند ، بنابراین شمارش عناصر تکرار کننده با بیش از عناصر [`usize::MAX`] یا نتیجه اشتباه ایجاد می کند یا panics.
    ///
    /// اگر ادعای اشکال زدایی فعال باشد ، panic تضمین می شود.
    ///
    /// # Panics
    ///
    /// اگر تکرار کننده بیش از عناصر [`usize::MAX`] داشته باشد ، این عملکرد ممکن است panic باشد.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// تکرار کننده را مصرف می کند ، و آخرین عنصر را برمی گرداند.
    ///
    /// این روش تکرار کننده را ارزیابی می کند تا زمانی که [`None`] برگرداند.
    /// ضمن انجام این کار ، عنصر فعلی را ردیابی می کند.
    /// پس از بازگشت [`None`] ، `last()` آخرین عنصری را که مشاهده کرده است برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// تکرار کننده توسط عناصر `n` پیشرفت می کند.
    ///
    /// این روش با فراخوانی [`next`] تا `n` بار تا رسیدن به [`None`] مشتاقانه عناصر `n` را رد می کند.
    ///
    /// `advance_by(n)` اگر تکرار کننده با عناصر `n` با موفقیت پیشرفت کند ، [`Ok(())`][Ok] را برمی گرداند یا اگر [`None`] با [`Err(k)`][Err] روبرو شود ،[`Ok(())`][Ok] را بازگرداند ، جایی که `k` تعداد عناصری است که تکرار کننده قبل از اتمام عناصر توسط آن پیشرفت می کند (یعنی
    /// طول تکرار کننده).
    /// توجه داشته باشید که `k` همیشه کمتر از `n` است.
    ///
    /// تماس با `advance_by(0)` هیچ عنصری را مصرف نمی کند و همیشه [`Ok(())`][Ok] را برمی گرداند.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // فقط `&4` رد شد
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// `n` عنصر تکرار کننده را برمی گرداند.
    ///
    /// مانند اکثر عملیات نمایه سازی ، شمارش از صفر شروع می شود ، بنابراین `nth(0)` مقدار اول ، `nth(1)` دوم را و غیره برمی گرداند.
    ///
    /// توجه داشته باشید که تمام عناصر قبلی و همچنین عنصر برگشتی از تکرار کننده مصرف می شود.
    /// این بدان معناست که عناصر قبلی کنار گذاشته می شوند و همچنین تماس چندین بار با `nth(0)` با همان تکرار باعث بازگرداندن عناصر مختلف می شود.
    ///
    ///
    /// `nth()` اگر `n` بزرگتر یا برابر با طول تکرار کننده باشد [`None`] را برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// چند بار تماس با `nth()` تکرار کننده را عقب نمی اندازد:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// اگر عناصر `n + 1` کمتر باشد `None` را برمی گردانید:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// تکرار کننده را با شروع در همان نقطه ایجاد می کند ، اما در هر تکرار با مقدار مشخص قدم می گذارد.
    ///
    /// توجه 1: اولین عنصر تکرار کننده ، بدون در نظر گرفتن مرحله انجام شده ، همیشه بازگردانده می شود.
    ///
    /// توجه 2: زمان کشیده شدن عناصر نادیده گرفته شده ثابت نیست.
    /// `StepBy` مانند سکانس `next(), nth(step-1), nth(step-1),…` رفتار می کند ، اما همچنین می تواند مانند سکانس رفتار کند
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// به دلایل عملکردی ، روش استفاده شده ممکن است برای برخی از تکرارکنندگان تغییر کند.
    /// راه دوم تکرار کننده را زودتر پیش می برد و ممکن است موارد بیشتری را مصرف کند.
    ///
    /// `advance_n_and_return_first` معادل این است:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// اگر مرحله داده شده `0` باشد ، روش panic خواهد بود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// دو تکرار را می گیرد و یک ترتیب دهنده جدید به ترتیب ترتیب می دهد.
    ///
    /// `chain()` تکرار کننده جدیدی را برمی گرداند که ابتدا مقادیر مربوط به تکرار کننده اول را تکرار می کند و سپس از تکرار کننده دوم بیش از مقادیر تکرار می کند.
    ///
    /// به عبارت دیگر ، این دو تکرار را به صورت زنجیره ای بهم پیوند می دهد.🔗
    ///
    /// [`once`] معمولاً برای انطباق یک مقدار واحد با زنجیره انواع دیگر تکرار استفاده می شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از آنجا که استدلال برای `chain()` از [`IntoIterator`] استفاده می کند ، ما می توانیم هر چیزی را که می تواند به [`Iterator`] تبدیل شود ، منتقل کنیم ، نه فقط خود [`Iterator`].
    /// به عنوان مثال ، برش های (`&[T]`) [`IntoIterator`] را پیاده سازی می کنند و بنابراین می توان مستقیماً به `chain()` منتقل کرد:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// اگر با Windows API کار می کنید ، ممکن است بخواهید [`OsStr`] را به `Vec<u16>` تبدیل کنید:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// "تکرار" دو تکرار را به یک تکرار کننده واحد جفت تبدیل کنید.
    ///
    /// `zip()` یک تکرار کننده جدید برمی گرداند که بیش از دو تکرار دیگر تکرار می شود ، یک جمع را برمی گرداند که اولین عنصر از تکرار کننده اول می آید و عنصر دوم از تکرار کننده دوم می آید.
    ///
    ///
    /// به عبارت دیگر ، این دو تکرار را با هم فشرده و به یک مورد واحد تبدیل می کند.
    ///
    /// اگر هر تکرار کننده [`None`] را بازگرداند ، [`next`] از تکرار کننده زیپ شده [`None`] را برمی گرداند.
    /// اگر تکرار کننده اول [`None`] را بازگرداند ، `zip` اتصال کوتاه می کند و `next` با تکرار کننده دوم فراخوانی نمی شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از آنجا که استدلال برای `zip()` از [`IntoIterator`] استفاده می کند ، ما می توانیم هر چیزی را که می تواند به [`Iterator`] تبدیل شود ، منتقل کنیم ، نه فقط خود [`Iterator`].
    /// به عنوان مثال ، برش های (`&[T]`) [`IntoIterator`] را پیاده سازی می کنند و بنابراین می توان مستقیماً به `zip()` منتقل کرد:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` اغلب برای زیپ کردن یک تکرار کننده نامحدود به یک متن محدود استفاده می شود.
    /// این کار به این دلیل انجام می شود که تکرار کننده محدود در نهایت [`None`] را باز می گرداند ، و زیپ به پایان می رسد.زیپ کردن با `(0..)` بسیار شبیه [`enumerate`] است:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// تکرار کننده جدیدی ایجاد می کند که کپی `separator` را در بین موارد مجاور تکرار کننده اصلی قرار می دهد.
    ///
    /// در صورتی که `separator` [`Clone`] را اجرا نمی کند یا هر بار نیاز به محاسبه دارد ، از [`intersperse_with`] استفاده کنید.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // اولین عنصر از `a`.
    /// assert_eq!(a.next(), Some(&100)); // جدا کننده
    /// assert_eq!(a.next(), Some(&1));   // عنصر بعدی از `a`.
    /// assert_eq!(a.next(), Some(&100)); // جدا کننده
    /// assert_eq!(a.next(), Some(&2));   // آخرین عنصر از `a`.
    /// assert_eq!(a.next(), None);       // تکرار کننده تمام شد.
    /// ```
    ///
    /// `intersperse` برای پیوستن به موارد تکرار کننده با استفاده از یک عنصر مشترک می تواند بسیار مفید باشد:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// تکرار کننده جدیدی ایجاد می کند که موردی را که توسط `separator` ایجاد شده بین موارد مجاور تکرارکننده اصلی قرار می دهد.
    ///
    /// بسته شدن دقیقاً هر بار که هر مورد بین دو مورد مجاور از تکرار کننده اصلی قرار می گیرد فراخوانی می شود.
    /// به طور خاص ، اگر تکرار کننده اصلی کمتر از دو مورد و بعد از آخرین محصول بازده دهد ، بسته شدن فراخوانی نمی شود.
    ///
    ///
    /// اگر مورد تکرار کننده [`Clone`] را اجرا کند ، ممکن است استفاده از [`intersperse`] راحت تر باشد.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // اولین عنصر از `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // جدا کننده
    /// assert_eq!(it.next(), Some(NotClone(1)));  // عنصر بعدی از `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // جدا کننده
    /// assert_eq!(it.next(), Some(NotClone(2)));  // آخرین عنصر از `v`.
    /// assert_eq!(it.next(), None);               // تکرار کننده تمام شد.
    /// ```
    ///
    /// `intersperse_with` می تواند در شرایطی که جدا کننده نیاز به محاسبه دارد استفاده شود:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // بسته شدن به طور متقابل زمینه تولید خود را برای تولید یک مورد وام می گیرد.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// یک بسته می شود و یک تکرار کننده ایجاد می کند که این بسته شدن را روی هر عنصر فراخوانی می کند.
    ///
    /// `map()` با استفاده از استدلال یک تکرار کننده را به دیگری تبدیل می کند:
    /// چیزی که [`FnMut`] را پیاده سازی می کند.این یک تکرار کننده جدید تولید می کند که این بسته شدن را روی هر عنصر تکرار کننده اصلی فراخوانی می کند.
    ///
    /// اگر در انواع تفکر مهارت دارید ، می توانید به `map()` اینگونه فکر کنید:
    /// اگر یک تکرار کننده دارید که عناصری از نوع `A` را به شما می دهد و یک تکرار کننده از نوع دیگری `B` می خواهید ، می توانید از `map()` استفاده کنید ، با بستن یک بسته که `A` را می گیرد و `B` را برمی گرداند.
    ///
    ///
    /// `map()` از نظر مفهومی شبیه به یک حلقه [`for`] است.با این وجود ، چون `map()` تنبل است ، بهترین استفاده در مواردی است که از قبل با تکرارکنندگان دیگر کار می کنید.
    /// اگر به نوعی حلقه برای عارضه جانبی انجام می دهید ، استفاده از [`for`] نسبت به `map()` اصطلاح بیشتری دارد.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// اگر به نوعی عارضه جانبی انجام می دهید ، [`for`] را به `map()` ترجیح دهید:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // این کار را نکن:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // حتی تنبل هم اجرا نمی شود.Rust در این مورد به شما هشدار می دهد.
    ///
    /// // در عوض ، برای استفاده از:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// بسته شدن هر عنصر تکرار کننده را فراخوانی می کند.
    ///
    /// این معادل استفاده از حلقه [`for`] در تکرار کننده است ، اگرچه `break` و `continue` از طریق بسته شدن امکان پذیر نیست.
    /// استفاده از حلقه `for` معمولاً اصولی تر است ، اما هنگام پردازش موارد در پایان زنجیره های تکرار طولانی تر ، `for_each` خواناتر است.
    ///
    /// در برخی موارد `for_each` ممکن است سریعتر از یک حلقه نیز باشد ، زیرا از تکرار داخلی در آداپتورهایی مانند `Chain` استفاده می کند.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// برای چنین مثال کوچکی ، یک حلقه `for` ممکن است تمیزتر باشد ، اما `for_each` برای حفظ یک سبک کاربردی با تکرارهای طولانی تر ممکن است ترجیح داده شود:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// یک تکرار کننده ایجاد می کند که برای تعیین اینکه آیا باید یک عنصر تولید شود ، از یک بسته استفاده می کند.
    ///
    /// با توجه به یک عنصر ، بسته شدن باید `true` یا `false` را برگرداند.تکرار کننده برگشتی فقط عناصری را که بسته شدن برای آنها درست است ، ارائه می دهد.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از آنجا که بسته شدن `filter()` به یک مرجع احتیاج دارد ، و بسیاری از تکرارکنندگان نسبت به مراجع تکرار می شوند ، این امر منجر به یک وضعیت احتمالاً گیج کننده می شود ، جایی که نوع بسته شدن یک مرجع مضاعف است:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // به دو * ثانیه احتیاج دارید!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// معمولاً استفاده از تخریب در استدلال برای دور کردن یکی از موارد معمول است:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // هر دو و *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// یا هر دو:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // دو &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از این لایه ها
    ///
    /// توجه داشته باشید که `iter.filter(f).next()` معادل `iter.find(f)` است.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// یک تکرار کننده ایجاد می کند که هم فیلتر می کند و هم نقشه می کشد.
    ///
    /// تکرار کننده برگشتی فقط مقدار را باز می کند که بسته شده برای آن `Some(value)` برمی گرداند.
    ///
    /// `filter_map` می توان برای ساخت مختصر زنجیره های [`filter`] و [`map`] استفاده کرد.
    /// مثال زیر نشان می دهد که چگونه می توان `map().filter().map()` را به یک تماس کوتاه با `filter_map` کوتاه کرد.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// در اینجا همان مثال وجود دارد ، اما با [`filter`] و [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// یک تکرار کننده ایجاد می کند که تعداد تکرار فعلی و همچنین مقدار بعدی را می دهد.
    ///
    /// تکرار کننده بازده جفت `(i, val)` را بدست می آورد ، جایی که `i` شاخص فعلی تکرار است و `val` مقداری است که توسط تکرار کننده برگردانده می شود.
    ///
    ///
    /// `enumerate()` شمارش خود را به عنوان [`usize`] حفظ می کند.
    /// اگر می خواهید با یک عدد صحیح با اندازه متفاوت حساب کنید ، عملکرد [`zip`] عملکرد مشابهی را فراهم می کند.
    ///
    /// # رفتار سرریز
    ///
    /// این روش هیچ گونه محافظتی در برابر سرریز نمی کند ، بنابراین برشمردن بیش از عناصر [`usize::MAX`] یا نتیجه اشتباهی ایجاد می کند یا panics.
    /// اگر ادعای اشکال زدایی فعال باشد ، panic تضمین می شود.
    ///
    /// # Panics
    ///
    /// اگر شاخص بازگشتی [`usize`] را سرریز کند ، تکرار کننده برگشتی ممکن است panic باشد.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// یک تکرار کننده ایجاد می کند که می تواند با استفاده از [`peek`] به عنصر بعدی تکرار کننده بدون مصرف آن نگاه کند.
    ///
    /// یک روش [`peek`] به یک تکرار کننده اضافه می کند.برای اطلاعات بیشتر به اسناد آن مراجعه کنید.
    ///
    /// توجه داشته باشید که تکرار اصلی در هنگام فراخوانی [`peek`] هنوز پیشرفته است: برای بازیابی عنصر بعدی ، [`next`] با تکرار کننده اصلی فراخوانی می شود ، از این رو عوارض جانبی (به عنوان مثال
    ///
    /// هر چیزی غیر از واکشی مقدار بعدی) روش [`next`] رخ خواهد داد.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() به ما اجازه می دهد future را ببینیم
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // ما می توانیم peek() چندین بار ، تکرار کننده پیشرفت نمی کند
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // پس از اتمام تکرار کننده ، peek() نیز به همین ترتیب انجام می شود
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// تکرار کننده ای ایجاد می کند که عناصر ["جست و خیز" را بر اساس یک محمول تنظیم می کند.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` بسته شدن را به عنوان یک استدلال می گیرد.این بسته شدن را روی هر عنصر تکرار کننده فراخوانی می کند و عناصر را نادیده می گیرد تا زمانی که `false` برگرداند.
    ///
    /// پس از بازگشت `false` ، کار `skip_while()`'s به پایان رسیده است و بقیه عناصر تولید می شوند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از آنجا که بسته شدن `skip_while()` به یک مرجع احتیاج دارد ، و بسیاری از تکرارکنندگان نسبت به مراجع تکرار می شوند ، این امر منجر به یک وضعیت احتمالاً گیج کننده می شود ، جایی که نوع استدلال بسته شدن یک مرجع دوگانه است:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // به دو * ثانیه احتیاج دارید!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// توقف پس از `false` اولیه:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // در حالی که این نادرست بوده است ، از آنجا که قبلاً یک دروغ دریافت کرده ایم ، skip_while() دیگر استفاده نمی شود
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// یک تکرار کننده ایجاد می کند که عناصر را بر اساس یک محمول بازده می کند.
    ///
    /// `take_while()` بسته شدن را به عنوان یک استدلال می گیرد.این بسته شدن را روی هر عنصر تکرار کننده فراخوانی می کند ، و عناصر را بازده می کند در حالی که `true` را برمی گرداند.
    ///
    /// پس از بازگشت `false` ، کار `take_while()`'s به پایان رسیده است و بقیه عناصر نادیده گرفته می شوند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از آنجا که بسته شدن `take_while()` به یک مرجع احتیاج دارد ، و بسیاری از تکرارکنندگان نسبت به مراجع تکرار می شوند ، این امر منجر به یک وضعیت احتمالاً گیج کننده می شود ، جایی که نوع بسته شدن یک مرجع مضاعف است:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // به دو * ثانیه احتیاج دارید!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// توقف پس از `false` اولیه:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // ما عناصر بیشتری داریم که کمتر از صفر هستند ، اما از آنجا که قبلاً یک false داشتیم ، take_while() دیگر استفاده نمی شود
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// از آنجا که `take_while()` برای دیدن اینکه آیا باید در آن گنجانده شود یا خیر ، باید مقدار مورد نظر را بررسی کند ، با تکرار مصرف کننده مشاهده می شود که مقدار حذف شده است:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` دیگر وجود ندارد ، زیرا برای اینکه ببیند آیا تکرار باید متوقف شود ، مصرف شده است اما مجدداً در تکرار کننده قرار داده نشده است.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// یک تکرار کننده ایجاد می کند که هم عناصر را بر اساس یک محمول و هم نقشه ها بازده می کند.
    ///
    /// `map_while()` بسته شدن را به عنوان یک استدلال می گیرد.
    /// این بسته شدن را روی هر عنصر تکرار کننده فراخوانی می کند و در حالی که [`Some(_)`][`Some`] را برمی گرداند ، عناصر را باز می کند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// در اینجا همان مثال وجود دارد ، اما با [`take_while`] و [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// توقف پس از [`None`] اولیه:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // عناصر بیشتری داریم که می توانند در u32 جای بگیرند (4 ، 5) ، اما `map_while` `None` را برای `-3` بازگرداند (همانطور که `predicate` `None` را برگرداند) و `collect` در اولین `None` متوقف می شود.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// از آنجا که `map_while()` برای دیدن اینکه آیا باید در آن گنجانده شود یا خیر ، باید مقدار مورد نظر را بررسی کند ، با تکرار مصرف کننده مشاهده می شود که مقدار حذف شده است:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` دیگر وجود ندارد ، زیرا برای اینکه ببیند آیا تکرار باید متوقف شود ، مصرف شده است اما مجدداً در تکرار کننده قرار داده نشده است.
    ///
    /// توجه داشته باشید که برخلاف [`take_while`] این تکرار کننده ** فیوجی نیست.
    /// همچنین مشخص نشده است که این تکرار کننده پس از بازگشت [`None`] اول چه چیزی را برمی گرداند.
    /// اگر به تکرار کننده ذوب شده نیاز دارید ، از [`fuse`] استفاده کنید.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// یک تکرار کننده ایجاد می کند که از اولین عناصر `n` رد می شود.
    ///
    /// پس از مصرف آنها ، بقیه عناصر تولید می شوند.
    /// به جای غلبه بر مستقیم این روش ، در عوض روش `nth` را نادیده بگیرید.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// یک تکرار کننده ایجاد می کند که اولین عناصر `n` خود را تولید می کند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` اغلب با یک تکرار کننده نامحدود برای محدود کردن آن استفاده می شود:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// اگر کمتر از عناصر `n` موجود باشد ، `take` خود را به اندازه تکرار کننده اصلی محدود می کند:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// آداپتور تکرارکننده مشابه [`fold`] که حالت داخلی را دارد و یک تکرار کننده جدید تولید می کند.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` دو آرگومان می گیرد: یک مقدار اولیه که حالت داخلی را ایجاد می کند و یک بسته با دو آرگومان ، اولین ارجاع قابل تغییر به حالت داخلی و دیگری عنصر تکرار کننده.
    ///
    /// بسته شدن می تواند به حالت داخلی اختصاص یابد تا وضعیت را بین تکرارها تقسیم کند.
    ///
    /// با تکرار ، بسته شدن به هر عنصر تکرار کننده اعمال می شود و مقدار بازگشتی از بسته شدن ، یک [`Option`] ، توسط تکرار کننده بدست می آید.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // در هر تکرار ، حالت را در عنصر ضرب می کنیم
    ///     *state = *state * x;
    ///
    ///     // سپس ، ما نفی دولت را ارائه خواهیم داد
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// یک تکرار کننده ایجاد می کند که مانند نقشه کار می کند ، اما ساختار تو در تو را مسطح می کند.
    ///
    /// آداپتور [`map`] بسیار مفید است ، اما فقط زمانی که آرگومان بستن مقادیر را تولید می کند.
    /// اگر به جای آن یک تکرار کننده تولید کند ، یک لایه غیرمستقیم وجود دارد.
    /// `flat_map()` این لایه اضافی را به خودی خود حذف می کند.
    ///
    /// شما می توانید `flat_map(f)` را معادل معنایی پینگ ["map" و سپس "flatten" را در `map(f).flatten()` تصور کنید.
    ///
    /// روش دیگر تفکر در مورد `flat_map()`: بسته شدن ["map"] برای هر عنصر یک مورد را برمی گرداند ، و بسته شدن `flat_map()`'s یک تکرار کننده برای هر عنصر را برمی گرداند.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() یک تکرار کننده را برمی گرداند
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// یک تکرار کننده ایجاد می کند که ساختار تو در تو را مسطح می کند.
    ///
    /// این هنگامی مفید است که شما یک تکرار کننده تکرارکننده داشته باشید یا یک تکرارکننده چیزهایی دارید که می توانند به تکرار کننده تبدیل شوند و می خواهید یک سطح بی تفاوتی را از بین ببرید.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// نقشه برداری و سپس مسطح سازی:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() یک تکرار کننده را برمی گرداند
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// همچنین می توانید این مورد را از نظر [`flat_map()`] بازنویسی کنید ، که در این مورد ترجیح داده می شود زیرا هدف را به طور واضح تری بیان می کند:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() یک تکرار کننده را برمی گرداند
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// مسطح کردن فقط یک سطح لانه سازی را در یک بار از بین می برد:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// در اینجا می بینیم که `flatten()` یکنواخت "deep" را انجام نمی دهد.
    /// در عوض ، فقط یک سطح لانه سازی حذف می شود.یعنی اگر شما یک آرایه سه بعدی `flatten()` داشته باشید ، نتیجه آن دو بعدی خواهد بود و یک بعدی نیست.
    /// برای به دست آوردن یک ساختار تک بعدی ، باید `flatten()` را دوباره انجام دهید.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// یک تکرار کننده ایجاد می کند که بعد از [`None`] اول به پایان می رسد.
    ///
    /// پس از بازگشت یک تکرار کننده [`None`] ، تماس های future ممکن است [`Some(T)`] دوباره تولید کند یا نکند.
    /// `fuse()` یک تکرار کننده را تطبیق می دهد ، اطمینان حاصل شود که پس از [`None`] داده می شود ، همیشه [`None`] را برای همیشه باز می گرداند.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// // تکرارکننده ای که بین بعضی و هیچکدام متناوب است
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // اگر حتی ، Some(i32) باشد ، دیگر هیچ
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // می توانیم تکرار کننده خود را ببینیم که به عقب و جلو می رود
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // با این حال ، هنگامی که ما آن را فیوز می کنیم ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // همیشه پس از اولین بار `None` باز می گردد.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// با انتقال هر مقدار با هر عنصر تکرار کننده ، کاری انجام می دهد.
    ///
    /// هنگام استفاده از تکرار کننده ها ، اغلب چندین مورد را با هم زنجیر می کنید.
    /// هنگام کار بر روی چنین کدی ، ممکن است بخواهید آنچه در قسمتهای مختلف خط لوله اتفاق می افتد را بررسی کنید.برای انجام این کار ، یک تماس با `inspect()` وارد کنید.
    ///
    /// معمولاً استفاده از `inspect()` به عنوان ابزاری برای رفع اشکال بیشتر از وجود کد نهایی است ، اما ممکن است برنامه ها در شرایط خاصی که لازم است قبل از ریختن خطاها وارد سیستم شوند ، آن را مفید می دانند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // این توالی تکرار پیچیده است.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // بیایید برخی تماس های inspect() را اضافه کنیم تا بررسی کنیم چه اتفاقی می افتد
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// این چاپ خواهد شد:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// خطاهای ورود به سیستم قبل از دور انداختن آنها:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// این چاپ خواهد شد:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// به جای مصرف کردن ، یک تکرار کننده را مهار می کند.
    ///
    /// این کار برای استفاده از آداپتورهای تکرارکننده در حالی که هنوز مالکیت تکرار کننده اصلی را حفظ کرده اید مفید است.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // اگر دوباره بخواهیم از iter استفاده کنیم ، کار نمی کند.
    /// // خط زیر خطا می دهد: استفاده از مقدار منتقل شده: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // بیایید دوباره امتحان کنیم
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // در عوض ، ما .by_ref() را اضافه می کنیم
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // اکنون این کاملا خوب است:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// یک تکرار کننده را به یک مجموعه تبدیل می کند.
    ///
    /// `collect()` می تواند هر چیزی را که قابل نجات است ، بگیرد و آن را به یک مجموعه مرتبط تبدیل کند.
    /// این یکی از روشهای قدرتمندتر در کتابخانه استاندارد است که در زمینه های مختلفی استفاده می شود.
    ///
    /// اساسی ترین الگویی که در آن از `collect()` استفاده می شود تبدیل یک مجموعه به مجموعه دیگر است.
    /// شما مجموعه ای را می گیرید ، با [`iter`] روی آن تماس می گیرید ، یک سری تحولات را انجام می دهید و در آخر `collect()` را انجام می دهید.
    ///
    /// `collect()` همچنین می تواند نمونه هایی از انواع ایجاد کند که مجموعه معمولی نیستند.
    /// به عنوان مثال ، یک [`String`] می تواند از ["char" ساخته شود ، و یک تکرار کننده آیتم [`Result<T, E>`][`Result`] می تواند در `Result<Collection<T>, E>` جمع شود.
    ///
    /// برای اطلاعات بیشتر به مثالهای زیر مراجعه کنید.
    ///
    /// از آنجا که `collect()` بسیار کلی است ، می تواند باعث استنباط نوع شود.
    /// به همین ترتیب ، `collect()` یکی از معدود مواردی است که نحو را با محبت به عنوان 'turbofish' می شناسید: `::<>`.
    /// این کمک می کند تا الگوریتم استنتاج به طور خاص درک کند که شما در کدام مجموعه جمع آوری می کنید.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// توجه داشته باشید که ما به `: Vec<i32>` در سمت چپ نیاز داشتیم.این به این دلیل است که می توانیم مثلاً [`VecDeque<T>`] را به جای آن جمع کنیم:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// استفاده از 'turbofish' به جای حاشیه نویسی `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// از آنجا که `collect()` فقط به آنچه در حال جمع آوری آن هستید اهمیت می دهد ، شما همچنان می توانید از یک نوع اشاره جزئی ، `_` ، با توربو فیش استفاده کنید:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// با استفاده از `collect()` برای ساخت [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// اگر لیستی از ["نتیجه<T, E>"]["نتیجه"] s ، می توانید از `collect()` استفاده کنید تا ببینید آیا هر یک از آنها خراب است:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // اولین خطا را به ما می دهد
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // لیست پاسخها را به ما می دهد
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// یک تکرار کننده مصرف می کند ، و دو مجموعه از آن ایجاد می کند.
    ///
    /// محمول منتقل شده به `partition()` می تواند `true` یا `false` را برگرداند.
    /// `partition()` یک جفت ، همه عناصری که `true` را برای آن برگردانده است و همه عناصری که `false` را برای آن برگردانده است.
    ///
    ///
    /// همچنین به [`is_partitioned()`] و [`partition_in_place()`] مراجعه کنید.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// عناصر این تکرارکننده *را در محل* مطابق با گزاره داده شده مرتب می کند ، بدین ترتیب که همه کسانی که `true` را برمی گردانند قبل از همه کسانی که `false` را برمی گردانند ، مقدم هستند.
    ///
    /// تعداد عناصر `true` پیدا شده را برمی گرداند.
    ///
    /// ترتیب نسبی موارد پارتیشن بندی شده حفظ نمی شود.
    ///
    /// همچنین به [`is_partitioned()`] و [`partition()`] مراجعه کنید.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // تقسیم در محل بین زوجها و شانس ها
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: آیا باید نگران سرریز شدن تعداد باشیم؟تنها راه داشتن بیش از
        // `usize::MAX` منابع قابل تغییر با ZST ها هستند ، که برای پارتیشن بندی مفید نیستند ...

        // این توابع بسته "factory" برای جلوگیری از عام بودن در `Self` وجود دارد.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // مرتباً اولین `false` را پیدا کرده و با آخرین `true` عوض کنید.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// بررسی می کند که آیا عناصر این تکرار کننده با توجه به محمول داده شده تقسیم شده اند ، به این ترتیب که همه کسانی که `true` را برمی گردانند قبل از همه مواردی که `false` را برمی گردانند ، مقدم هستند.
    ///
    ///
    /// همچنین به [`partition()`] و [`partition_in_place()`] مراجعه کنید.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // یا همه موارد `true` را آزمایش می کنند ، یا بند اول در `false` متوقف می شود و بررسی می کنیم که پس از آن دیگر مورد `true` وجود ندارد.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// یک روش تکرار کننده که تا زمانی که با موفقیت برگردد ، یک تابع را اعمال می کند و یک مقدار نهایی و واحد تولید می کند.
    ///
    /// `try_fold()` دو آرگومان می گیرد: یک مقدار اولیه و یک بسته با دو آرگومان: یک 'accumulator' و یک عنصر.
    /// بسته شدن یا با موفقیت ، با مقداری که باتری برای تکرار بعدی باید داشته باشد ، برمی گردد ، یا اینکه شکست را برمی گرداند ، با یک مقدار خطا که بلافاصله به تماس گیرنده (short-circuiting) ارسال می شود.
    ///
    ///
    /// مقدار اولیه مقداری است که باتری در اولین تماس خواهد داشت.اگر اعمال بسته شدن در برابر هر عنصر تکرار کننده موفقیت آمیز باشد ، `try_fold()` باتری نهایی را به عنوان موفقیت برمی گرداند.
    ///
    /// تاشو هر زمان که مجموعه ای از چیزی را داشته باشید و بخواهید یک مقدار واحد از آن تولید کنید ، مفید است.
    ///
    /// # یادداشت به مجریان
    ///
    /// چندین روش دیگر (forward) از نظر این روش پیاده سازی پیش فرض دارند ، بنابراین اگر می تواند کاری بهتر از اجرای حلقه `for` پیش فرض انجام دهد ، سعی کنید این را به صراحت پیاده سازی کنید.
    ///
    /// به طور خاص ، سعی کنید این تماس `try_fold()` را روی قسمتهای داخلی که این تکرار کننده از آن تشکیل شده است داشته باشید.
    /// در صورت نیاز به تماس های متعدد ، اپراتور `?` ممکن است برای زنجیر زدن مقدار جمع کننده مناسب باشد ، اما مراقب موارد نامطلوبی باشید که باید قبل از بازپرداخت زودهنگام تأیید شوند.
    /// این یک روش `&mut self` است ، بنابراین لازم است تکرار پس از خطا در اینجا از سر گرفته شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // جمع علامت گذاری شده از تمام عناصر آرایه
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // این مقدار هنگام افزودن عنصر 100 سرریز می شود
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // به دلیل اتصال کوتاه ، عناصر باقیمانده هنوز از طریق تکرار کننده در دسترس هستند.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// یک روش تکرار کننده که برای هر مورد در تکرار کننده یک عملکرد قابل سقوط اعمال می کند ، در اولین خطا متوقف می شود و آن خطا را برمی گرداند.
    ///
    ///
    /// این را می توان به عنوان شکل خطای [`for_each()`] یا نسخه بدون حالت [`try_fold()`] نیز در نظر گرفت.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // این اتصال کوتاه است ، بنابراین موارد باقیمانده هنوز در تکرار کننده هستند:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// با استفاده از یک عمل ، هر عنصر را به داخل جمع کننده می زند و نتیجه نهایی را برمی گرداند.
    ///
    /// `fold()` دو آرگومان می گیرد: یک مقدار اولیه و یک بسته با دو آرگومان: یک 'accumulator' و یک عنصر.
    /// بسته شدن مقداری را که باتری برای تکرار بعدی باید داشته باشد ، برمی گرداند.
    ///
    /// مقدار اولیه مقداری است که باتری در اولین تماس خواهد داشت.
    ///
    /// پس از اعمال این بسته شدن بر روی هر عنصر تکرار کننده ، `fold()` باتری را برمی گرداند.
    ///
    /// این عمل را گاهی 'reduce' یا 'inject' می نامند.
    ///
    /// تاشو هر زمان که مجموعه ای از چیزی را داشته باشید و بخواهید یک مقدار واحد از آن تولید کنید ، مفید است.
    ///
    /// Note: `fold()` ، و روشهای مشابه که کل تکرار کننده را پیمایش می کنند ، ممکن است برای تکرارکنندگان بی نهایت خاتمه نیابند ، حتی در traits که نتیجه آن در زمان محدود قابل تعیین است.
    ///
    /// Note: اگر نوع جمع کننده و نوع مورد یکسان باشد ، می توان از [`reduce()`] برای استفاده از عنصر اول به عنوان مقدار اولیه استفاده کرد.
    ///
    /// # یادداشت به مجریان
    ///
    /// چندین روش دیگر (forward) از نظر این روش پیاده سازی پیش فرض دارند ، بنابراین اگر می تواند کاری بهتر از اجرای حلقه `for` پیش فرض انجام دهد ، سعی کنید این را به صراحت پیاده سازی کنید.
    ///
    ///
    /// به طور خاص ، سعی کنید این تماس `fold()` را روی قسمتهای داخلی که این تکرار کننده از آن تشکیل شده است داشته باشید.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // مجموع تمام عناصر آرایه
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// بیایید هر مرحله از تکرار را در اینجا مرور کنیم:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// نتیجه نهایی ما ، `6`.
    ///
    /// معمولاً برای افرادی که زیاد از تکرار کننده ها استفاده نکرده اند ، از حلقه `for` با لیستی از موارد برای ایجاد نتیجه استفاده می کنند.این موارد را می توان به `fold()`s تبدیل کرد:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // برای حلقه:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // آنها همانند
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// با استفاده مکرر از یک عمل کاهش ، عناصر را به یک قسمت واحد کاهش می دهد.
    ///
    /// اگر تکرار کننده خالی باشد ، [`None`] را برمی گرداند.در غیر این صورت ، نتیجه کاهش را برمی گرداند.
    ///
    /// برای تکرارکنندگان با حداقل یک عنصر ، این همان [`fold()`] با اولین عنصر تکرار کننده به عنوان مقدار اولیه است و هر عنصر بعدی را در آن جمع می کند.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// حداکثر مقدار را پیدا کنید:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// آزمایش می کند که اگر هر عنصر تکرار کننده با یک محمول مطابقت داشته باشد.
    ///
    /// `all()` بسته می شود که `true` یا `false` را برمی گرداند.این بسته شدن را برای هر عنصر تکرار کننده اعمال می کند ، و اگر همه آنها `true` را بازگردانند ، `all()` نیز چنین خواهد شد.
    /// اگر هر کدام از آنها `false` را برگرداند ، `false` را برمی گرداند.
    ///
    /// `all()` اتصال کوتاه استبه عبارت دیگر ، به محض یافتن `false` ، پردازش متوقف می شود ، با توجه به اینکه هر اتفاقی دیگر بیفتد ، نتیجه `false` نیز خواهد بود.
    ///
    ///
    /// تکرار کننده خالی `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// توقف در `false` اول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // ما هنوز هم می توانیم از `iter` استفاده کنیم ، زیرا عناصر بیشتری وجود دارد.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// در صورت مطابقت هر یک از عناصر تکرار کننده با یک محمول ، آزمایش می شود.
    ///
    /// `any()` بسته می شود که `true` یا `false` را برمی گرداند.این بسته شدن را برای هر عنصر تکرار کننده اعمال می کند ، و اگر هر کدام از آنها `true` را بازگرداند ، `any()` نیز چنین خواهد شد.
    /// اگر همه آنها `false` را برگردانند ، `false` برمی گردد.
    ///
    /// `any()` اتصال کوتاه استبه عبارت دیگر ، به محض یافتن `true` ، پردازش متوقف می شود ، با توجه به اینکه هر اتفاقی دیگر بیفتد ، نتیجه `true` نیز خواهد بود.
    ///
    ///
    /// تکرار کننده خالی `false` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// توقف در `true` اول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // ما هنوز هم می توانیم از `iter` استفاده کنیم ، زیرا عناصر بیشتری وجود دارد.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// عنصری از یک تکرار کننده را که یک گزاره را ارضا کند جستجو می کند.
    ///
    /// `find()` بسته می شود که `true` یا `false` را برمی گرداند.
    /// این بسته شدن را برای هر عنصر تکرار کننده اعمال می کند ، و اگر هر یک از آنها `true` را بازگرداند ، `find()` [`Some(element)`] را برمی گرداند.
    /// اگر همه آنها `false` را برگردانند ، [`None`] برمی گردد.
    ///
    /// `find()` اتصال کوتاه استبه عبارت دیگر ، به محض بازگشت بسته شدن `true` ، پردازش متوقف می شود.
    ///
    /// از آنجا که `find()` یک مرجع را می گیرد ، و بسیاری از تکرار کنندگان بیشتر از مراجع تکرار می کنند ، این منجر به یک وضعیت احتمالاً گیج کننده می شود که در آن استدلال یک مرجع مضاعف است.
    ///
    /// این اثر را می توانید در مثال های زیر با `&&x` مشاهده کنید.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// توقف در `true` اول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // ما هنوز هم می توانیم از `iter` استفاده کنیم ، زیرا عناصر بیشتری وجود دارد.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// توجه داشته باشید که `iter.find(f)` معادل `iter.filter(f).next()` است.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// تابع را روی عناصر تکرار کننده اعمال می کند و اولین نتیجه بدون هیچ نتیجه را برمی گرداند.
    ///
    ///
    /// `iter.find_map(f)` معادل `iter.filter_map(f).next()` است.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// تابع را روی عناصر تکرار کننده اعمال می کند و اولین نتیجه واقعی یا اولین خطا را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// یک عنصر را در یک تکرار کننده جستجو می کند و شاخص آن را برمی گرداند.
    ///
    /// `position()` بسته می شود که `true` یا `false` را برمی گرداند.
    /// این بسته شدن را برای هر عنصر تکرار کننده اعمال می کند ، و اگر یکی از آنها `true` را بازگرداند ، `position()` [`Some(index)`] را برمی گرداند.
    /// اگر همه آنها `false` را برگردانند ، [`None`] را برمی گرداند.
    ///
    /// `position()` اتصال کوتاه استبه عبارت دیگر ، به محض یافتن `true` پردازش متوقف می شود.
    ///
    /// # رفتار سرریز
    ///
    /// این روش هیچ گونه محافظتی در برابر سرریز نمی کند ، بنابراین اگر بیش از [`usize::MAX`] عنصر غیر همسان وجود داشته باشد ، یا نتیجه اشتباهی ایجاد می کند یا panics.
    ///
    /// اگر ادعای اشکال زدایی فعال باشد ، panic تضمین می شود.
    ///
    /// # Panics
    ///
    /// اگر تکرار کننده بیش از `usize::MAX` عنصر غیر همسان داشته باشد ، این عملکرد ممکن است panic باشد.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// توقف در `true` اول:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // ما هنوز هم می توانیم از `iter` استفاده کنیم ، زیرا عناصر بیشتری وجود دارد.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // شاخص بازگشتی به حالت تکرار کننده بستگی دارد
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// یک عنصر را در یک تکرار کننده از سمت راست جستجو می کند و شاخص آن را برمی گرداند.
    ///
    /// `rposition()` بسته می شود که `true` یا `false` را برمی گرداند.
    /// این بسته شدن را روی هر عنصر تکرار کننده اعمال می کند ، از انتها شروع می شود ، و اگر یکی از آنها `true` را بازگرداند ، `rposition()` [`Some(index)`] را برمی گرداند.
    ///
    /// اگر همه آنها `false` را برگردانند ، [`None`] را برمی گرداند.
    ///
    /// `rposition()` اتصال کوتاه استبه عبارت دیگر ، به محض یافتن `true` پردازش متوقف می شود.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// توقف در `true` اول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // ما هنوز هم می توانیم از `iter` استفاده کنیم ، زیرا عناصر بیشتری وجود دارد.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // در اینجا نیازی به بررسی سرریز نیست ، زیرا `ExactSizeIterator` به این معنی است که تعداد عناصر در `usize` جای می گیرد.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// حداکثر عنصر تکرار کننده را برمی گرداند.
    ///
    /// اگر چندین عنصر به طور مساوی حداکثر باشند ، آخرین عنصر بازگردانده می شود.
    /// اگر تکرار کننده خالی باشد ، [`None`] بازگردانده می شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// حداقل عنصر تکرار کننده را برمی گرداند.
    ///
    /// اگر چندین عنصر به طور مساوی حداقل باشد ، اولین عنصر برمی گردد.
    /// اگر تکرار کننده خالی باشد ، [`None`] بازگردانده می شود.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// عنصری را که حداکثر مقدار را از تابع مشخص شده می دهد ، برمی گرداند.
    ///
    ///
    /// اگر چندین عنصر به طور مساوی حداکثر باشند ، آخرین عنصر بازگردانده می شود.
    /// اگر تکرار کننده خالی باشد ، [`None`] بازگردانده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// عنصری را که با توجه به تابع مقایسه مشخص شده حداکثر مقدار را می دهد ، برمی گرداند.
    ///
    ///
    /// اگر چندین عنصر به طور مساوی حداکثر باشند ، آخرین عنصر بازگردانده می شود.
    /// اگر تکرار کننده خالی باشد ، [`None`] بازگردانده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// عنصری را که حداقل مقدار را از تابع مشخص شده می دهد ، برمی گرداند.
    ///
    ///
    /// اگر چندین عنصر به طور مساوی حداقل باشد ، اولین عنصر برمی گردد.
    /// اگر تکرار کننده خالی باشد ، [`None`] بازگردانده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// عنصری را که با توجه به تابع مقایسه مشخص شده حداقل مقدار را می دهد ، برمی گرداند.
    ///
    ///
    /// اگر چندین عنصر به طور مساوی حداقل باشد ، اولین عنصر برمی گردد.
    /// اگر تکرار کننده خالی باشد ، [`None`] بازگردانده می شود.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// جهت یک تکرار کننده را معکوس می کند.
    ///
    /// معمولاً تکرارکنندگان از چپ به راست تکرار می شوند.
    /// پس از استفاده از `rev()` ، یک تکرار کننده در عوض از راست به چپ تکرار می شود.
    ///
    /// این فقط در صورتی امکان پذیر است که تکرار کننده پایان داشته باشد ، بنابراین `rev()` فقط در ["DoubleEndedIterator"] کار می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// یک تکرار کننده از جفت ها را به یک جفت ظرف تبدیل می کند.
    ///
    /// `unzip()` یک تکرار کننده کامل از جفتها را مصرف می کند و دو مجموعه تولید می کند: یکی از عناصر سمت چپ جفت ها و دیگری از عناصر سمت راست.
    ///
    ///
    /// این عملکرد به تعبیری مخالف [`zip`] است.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// یک تکرار کننده ایجاد می کند که تمام عناصر آن را کپی می کند.
    ///
    /// این مورد زمانی مفید است که یک تکرارکننده بیش از `&T` داشته باشید ، اما به یک تکرار کننده بیش از `T` نیاز دارید.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // کپی شده همان .map(|&x| x) است
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// یک تکرار کننده ایجاد می کند که تمام عناصر آن [کلون] است.
    ///
    /// این مورد زمانی مفید است که یک تکرارکننده بیش از `&T` داشته باشید ، اما به یک تکرار کننده بیش از `T` نیاز دارید.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // کلون شده همان .map(|&x| x) برای اعداد صحیح است
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// تکرار کننده را بی وقفه تکرار می کند.
    ///
    /// به جای توقف در [`None`] ، تکرار کننده در عوض دوباره شروع می کند ، از ابتدا.پس از تکرار مجدد ، از ابتدا دوباره شروع می شود.و دوباره.
    /// و دوباره.
    /// Forever.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// عناصر تکرار کننده را جمع می کند.
    ///
    /// هر عنصر را می گیرد ، آنها را با هم جمع می کند و نتیجه را برمی گرداند.
    ///
    /// تکرار کننده خالی مقدار صفر نوع را برمی گرداند.
    ///
    /// # Panics
    ///
    /// هنگامی که `sum()` فراخوانی می شود و یک نوع عدد ابتدایی بازگردانده می شود ، اگر محاسبات سرریز شود و ادعاهای رفع اشکال فعال شوند ، این روش panic خواهد داشت.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// تکرار کل تکرار کننده ، ضرب همه عناصر
    ///
    /// تکرار کننده خالی یک مقدار از نوع را برمی گرداند.
    ///
    /// # Panics
    ///
    /// هنگامی که `product()` فراخوانی می شود و یک نوع صحیح ابتدایی بازگردانده می شود ، اگر محاسبات سرریز شود و ادعاهای اشکال زدایی فعال شوند ، روش panic خواهد بود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) عناصر این [`Iterator`] را با عناصر دیگری مقایسه می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) عناصر این [`Iterator`] را با توجه به عملکرد مقایسه مشخص شده با عناصر دیگری مقایسه می کند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) عناصر این [`Iterator`] را با عناصر دیگری مقایسه می کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) عناصر این [`Iterator`] را با توجه به عملکرد مقایسه مشخص شده با عناصر دیگری مقایسه می کند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// تعیین می کند که آیا عناصر این [`Iterator`] با عناصر دیگر برابر است.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// تعیین می کند که عناصر این [`Iterator`] با توجه به تابع برابری مشخص شده با عناصر دیگر برابر باشد.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// تعیین می کند که عناصر این [`Iterator`] با عناصر دیگر نابرابر است.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// تعیین می کند که عناصر این [`Iterator`] [lexicographically](Ord#lexicographical-comparison) کمتر از عناصر دیگر باشد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// تعیین می کند که عناصر این [`Iterator`] [lexicographically](Ord#lexicographical-comparison) کمتر یا برابر با عناصر دیگر باشد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// تعیین می کند که آیا عناصر این [`Iterator`] [lexicographically](Ord#lexicographical-comparison) بیشتر از عناصر دیگر است.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// تعیین می کند که آیا عناصر این [`Iterator`] [lexicographically](Ord#lexicographical-comparison) بزرگتر یا برابر با عناصر دیگری هستند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// بررسی می کند که آیا عناصر این تکرار کننده مرتب شده اند.
    ///
    /// یعنی برای هر عنصر `a` و عنصر `b` زیر آن ، `a <= b` باید نگه داشته شود.اگر تکرار کننده دقیقاً صفر یا یک عنصر ارائه دهد ، `true` بازگردانده می شود.
    ///
    /// توجه داشته باشید که اگر `Self::Item` فقط `PartialOrd` باشد ، اما `Ord` نباشد ، تعریف فوق بیانگر این است که اگر هر دو مورد متوالی قابل مقایسه نباشند ، این عملکرد `false` را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// بررسی می کند که آیا عناصر این تکرار کننده با استفاده از عملکرد مقایسه کننده داده شده مرتب شده اند.
    ///
    /// این تابع به جای استفاده از `PartialOrd::partial_cmp` ، از تابع `compare` داده شده برای تعیین ترتیب دو عنصر استفاده می کند.
    /// جدا از آن ، معادل [`is_sorted`] است.برای اطلاعات بیشتر به اسناد آن مراجعه کنید.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// بررسی می کند که آیا عناصر این تکرار کننده با استفاده از تابع استخراج کلید داده شده مرتب شده اند.
    ///
    /// به جای مقایسه مستقیم عناصر تکرار کننده ، این عملکرد کلیدهای عناصر را با تعیین `f` مقایسه می کند.
    /// جدا از آن ، معادل [`is_sorted`] است.برای اطلاعات بیشتر به اسناد آن مراجعه کنید.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// به [TrustedRandomAccess] مراجعه کنید
    // نام غیرمعمول این است که از تصادم نام در وضوح روش جلوگیری کنید #76479 را ببینید.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}