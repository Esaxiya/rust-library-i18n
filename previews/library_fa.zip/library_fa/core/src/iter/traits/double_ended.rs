use crate::ops::{ControlFlow, Try};

/// تکرار کننده ای که قادر به تولید عناصر از هر دو انتها است.
///
/// چیزی که `DoubleEndedIterator` را پیاده سازی می کند یک قابلیت اضافی نسبت به چیزی دارد که [`Iterator`] را پیاده سازی می کند: توانایی گرفتن `Item` از پشت و همچنین جلو.
///
///
/// توجه به این نکته مهم است که هر دو حالت رفت و برگشت در یک محدوده کار می کنند و از هم عبور نمی کنند: تکرار زمانی که آنها در وسط قرار بگیرند به پایان می رسد.
///
/// به روشی مشابه پروتکل [`Iterator`] ، یک بار `DoubleEndedIterator` [`None`] را از [`next_back()`] برمی گرداند ، با فراخوانی مجدد آن ممکن است [`Some`] دوباره برگردد یا نباشد.
/// [`next()`] و [`next_back()`] برای این منظور قابل تعویض هستند.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// یک عنصر را از انتهای تکرار کننده حذف و برمی گرداند.
    ///
    /// `None` را بر می گرداند وقتی دیگر عنصری وجود ندارد.
    ///
    /// اسناد [trait-level] حاوی جزئیات بیشتری است.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// عناصر بدست آمده توسط روشهای "DoubleEndedIterator" ممکن است با موارد بدست آمده توسط روشهای "Iterator"] متفاوت باشد:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// توسط عناصر `n` از پشت به تکرار پیش می رود.
    ///
    /// `advance_back_by` نسخه معکوس [`advance_by`] است.این روش با فراخوانی [`next_back`] تا `n` بار تا رسیدن به [`None`] مشتاقانه عناصر `n` را از عقب رد می کند.
    ///
    /// `advance_back_by(n)` اگر تکرار کننده با عناصر `n` با موفقیت پیشرفت کند ، [`Ok(())`] را برمی گرداند یا اگر [`None`] با [`Err(k)`] روبرو شود ،[`Ok(())`] را بازگرداند ، جایی که `k` تعداد عناصری است که تکرار کننده قبل از اتمام عناصر توسط آن پیشرفت می کند (
    /// طول تکرار کننده).
    /// توجه داشته باشید که `k` همیشه کمتر از `n` است.
    ///
    /// تماس با `advance_back_by(0)` هیچ عنصری را مصرف نمی کند و همیشه [`Ok(())`] را برمی گرداند.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // فقط `&3` رد شد
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// عنصر `n` از انتهای تکرار کننده را برمی گرداند.
    ///
    /// این در اصل نسخه معکوس [`Iterator::nth()`] است.
    /// اگرچه مانند اکثر عملیات نمایه سازی ، شمارش از صفر شروع می شود ، بنابراین `nth_back(0)` مقدار اول را از انتها ، `nth_back(1)` دوم را و غیره برمی گرداند.
    ///
    ///
    /// توجه داشته باشید که تمام عناصر بین انتهای و عنصر برگشتی مصرف می شوند ، از جمله عنصر برگشتی.
    /// این همچنین بدان معنی است که تماس `nth_back(0)` با چندین تکرار در یک تکرار کننده ، عناصر مختلف را برمی گرداند.
    ///
    /// `nth_back()` اگر `n` بزرگتر یا برابر با طول تکرار کننده باشد [`None`] را برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// چند بار تماس با `nth_back()` تکرار کننده را عقب نمی اندازد:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// اگر عناصر `n + 1` کمتر باشد `None` را برمی گردانید:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// این نسخه معکوس [`Iterator::try_fold()`] است: عناصری را از پشت تکرار کننده شروع می کند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // به دلیل اتصال کوتاه ، عناصر باقیمانده هنوز از طریق تکرار کننده در دسترس هستند.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// یک روش تکرار کننده که با شروع از پشت ، عناصر تکرار کننده را به یک مقدار نهایی و نهایی کاهش می دهد.
    ///
    /// این نسخه معکوس [`Iterator::fold()`] است: عناصری را از پشت تکرار کننده شروع می کند.
    ///
    /// `rfold()` دو آرگومان می گیرد: یک مقدار اولیه و یک بسته با دو آرگومان: یک 'accumulator' و یک عنصر.
    /// بسته شدن مقداری را که باتری برای تکرار بعدی باید داشته باشد ، برمی گرداند.
    ///
    /// مقدار اولیه مقداری است که باتری در اولین تماس خواهد داشت.
    ///
    /// پس از اعمال این بسته شدن بر روی هر عنصر تکرار کننده ، `rfold()` باتری را برمی گرداند.
    ///
    /// این عمل را گاهی 'reduce' یا 'inject' می نامند.
    ///
    /// تاشو هر زمان که مجموعه ای از چیزی را داشته باشید و بخواهید یک مقدار واحد از آن تولید کنید ، مفید است.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // مجموع تمام عناصر a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// این مثال یک رشته را می سازد ، با یک مقدار اولیه شروع می شود و با هر عنصر از عقب تا جلو ادامه می یابد:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// عنصر تکرار کننده را از پشت جستجو می کند که یک گزاره را راضی کند.
    ///
    /// `rfind()` بسته می شود که `true` یا `false` را برمی گرداند.
    /// این بسته شدن را برای هر عنصر تکرار کننده اعمال می کند ، از انتها شروع می شود ، و اگر هر یک از آنها `true` را بازگرداند ، `rfind()` [`Some(element)`] را برمی گرداند.
    /// اگر همه آنها `false` را برگردانند ، [`None`] برمی گردد.
    ///
    /// `rfind()` اتصال کوتاه استبه عبارت دیگر ، به محض بازگشت بسته شدن `true` ، پردازش متوقف می شود.
    ///
    /// از آنجا که `rfind()` یک مرجع را می گیرد ، و بسیاری از تکرار کنندگان بیشتر از مراجع تکرار می کنند ، این منجر به یک وضعیت احتمالاً گیج کننده می شود که در آن استدلال یک مرجع مضاعف است.
    ///
    /// این اثر را می توانید در مثال های زیر با `&&x` مشاهده کنید.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// توقف در `true` اول:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // ما هنوز هم می توانیم از `iter` استفاده کنیم ، زیرا عناصر بیشتری وجود دارد.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}