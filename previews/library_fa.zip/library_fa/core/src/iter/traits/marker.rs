/// تکرارکننده ای که همیشه با خستگی به بازده `None` ادامه می دهد.
///
/// تماس بعدی با یک تکرار کننده ذوب شده که یکبار `None` را برگردانده است ، تضمین می کند که [`None`] دوباره بازگردد.
/// این trait باید توسط تمام تکرارکنندگانی که اینگونه رفتار می کنند پیاده سازی شود زیرا امکان بهینه سازی [`Iterator::fuse()`] را فراهم می کند.
///
///
/// Note: به طور کلی ، اگر به یک تکرار کننده ذوب شده نیاز دارید نباید از `FusedIterator` در مرزهای عمومی استفاده کنید.
/// در عوض ، فقط باید با [`Iterator::fuse()`] از طریق تکرار کننده تماس بگیرید.
/// اگر تکرارکننده قبلاً جوش خورده باشد ، بسته اضافی [`Fuse`] ممنوعیت عمل و بدون مجازات عملکرد است.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// تکرار کننده ای که طول دقیق را با استفاده از size_hint گزارش می کند.
///
/// تکرار کننده یک اشاره به اندازه را گزارش می دهد که در آن یا دقیق باشد (حد پایین برابر است با حد بالا) ، یا حد بالا [`None`] است.
///
/// محدوده فوقانی فقط باید [`None`] باشد اگر طول تکرار کننده واقعی از [`usize::MAX`] بزرگتر باشد.
/// در آن حالت ، حد پایین باید [`usize::MAX`] باشد و در نتیجه [`Iterator::size_hint()`] `(usize::MAX, None)` باشد.
///
/// تکرار کننده باید قبل از رسیدن به انتها ، دقیقاً تعداد عناصری را که گزارش کرده یا از یکدیگر جدا می شوند ، تولید کند.
///
/// # Safety
///
/// این trait فقط باید در صورت تأیید قرارداد اجرا شود.
/// مصرف کنندگان این trait باید حد بالای [`Iterator::size_hint()`]’s را بررسی کنند.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// تکرار کننده ای که هنگام ارائه یک مورد حداقل یک عنصر را از [`SourceIter`] زیرین آن گرفته است.
///
/// فراخوانی هر روشی که باعث تکرار شود ، به عنوان مثال
/// [`next()`] یا [`try_fold()`] ، تضمین می کند که برای هر مرحله حداقل یک مقدار از منبع اصلی تکرار کننده به بیرون منتقل شده و نتیجه زنجیره تکرار کننده می تواند در جای خود قرار گیرد ، با این فرض که محدودیت های ساختاری منبع چنین درج را مجاز می کند.
///
/// به عبارت دیگر این trait نشان می دهد که می توان خط لوله تکرار کننده را در محل خود جمع کرد.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}