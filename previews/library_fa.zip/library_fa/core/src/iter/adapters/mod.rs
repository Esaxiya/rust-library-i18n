use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// این trait دسترسی موقت به مرحله منبع را در یک خط لوله آداپتور واسط تحت شرایطی فراهم می کند
/// * منبع تکرار کننده `S` خود `SourceIter<Source = S>` را پیاده سازی می کند
/// * اجرای تفویضی این trait برای هر آداپتور موجود در خط لوله بین منبع و مصرف کننده خط لوله وجود دارد.
///
/// هنگامی که منبع یک ساختار تکرار کننده مخصوص به خود است (که معمولاً `IntoIter` نامیده می شود) ، این می تواند برای تخصصی سازی پیاده سازی های [`FromIterator`] یا بازیابی عناصر باقیمانده پس از اتمام نسبی تکرار کننده مفید باشد.
///
///
/// توجه داشته باشید که پیاده سازی ها لزوماً نیازی به دسترسی به داخلی ترین منبع یک خط لوله ندارند.یک آداپتور متوسط می تواند با اشتیاق بخشی از خط لوله را ارزیابی کرده و ذخیره سازی داخلی آن را به عنوان منبع آشکار کند.
///
/// trait ناامن است زیرا مجریان باید خصوصیات ایمنی بیشتری را حفظ کنند.
/// برای جزئیات بیشتر به [`as_inner`] مراجعه کنید.
///
/// # Examples
///
/// بازیابی یک منبع نیمه مصرف شده:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// یک مرحله منبع در خط لوله تکرار کننده.
    type Source: Iterator;

    /// منبع خط لوله تکرار را بازیابی کنید.
    ///
    /// # Safety
    ///
    /// پیاده سازی ها باید در طول عمر خود همان مرجع متغیر را برگردانند ، مگر اینکه با تماس گیرنده جایگزین شود.
    /// تماس گیرنده ها فقط هنگامی می توانند مرجع را جایگزین کنند که تکرار را متوقف کرده و پس از استخراج منبع ، خط لوله تکرار کننده را رها کنند.
    ///
    /// این بدان معناست که آداپتورهای تکرار کننده می توانند به منبع تغییر دهند و در طول تکرار تغییر نکند اما در پیاده سازی Drop نمی توانند به آن اعتماد کنند.
    ///
    /// اجرای این روش به این معنی است که آداپتورها از دسترسی فقط به منبع خود صرف نظر می کنند و فقط می توانند به تضمین های ارائه شده بر اساس انواع گیرنده روش اعتماد کنند.
    /// همچنین عدم دسترسی محدود به آداپتورها نیاز دارد که API عمومی منبع را حتی در صورت دسترسی به داخلی آن حفظ کنند.
    ///
    /// تماس گیرندگان به نوبه خود باید انتظار داشته باشند که منبع در هر وضعیت سازگار با API عمومی آن باشد ، زیرا آداپتورهای نشسته بین آن و منبع دسترسی یکسانی دارند.
    /// به طور خاص ممکن است یک آداپتور بیش از حد ضروری عناصر مصرف کرده باشد.
    ///
    /// هدف کلی این الزامات این است که مصرف کننده یک خط لوله استفاده کند
    /// * پس از توقف تکرار ، هر آنچه در منبع باقی مانده است
    /// * حافظه ای که با پیشرفت یک تکرار کننده مصرف کننده استفاده نشده است
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// آداپتور تکرار کننده که تا زمانی که تکرار کننده اصلی مقادیر `Result::Ok` تولید کند ، خروجی تولید می کند.
///
///
/// در صورت بروز خطا ، تکرار کننده متوقف شده و خطا ذخیره می شود.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// تکرار کننده داده شده را طوری پردازش کنید که گویی `T` به جای `Result<T, _>` بازده دارد.
/// هرگونه خطا تکرار کننده داخلی را متوقف می کند و نتیجه کلی یک خطا است.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}