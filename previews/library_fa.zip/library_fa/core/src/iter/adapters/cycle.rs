use crate::{iter::FusedIterator, ops::Try};

/// تکرار کننده ای که بی وقفه تکرار می شود.
///
/// این `struct` با روش [`cycle`] روی [`Iterator`] ایجاد می شود.
/// برای اطلاعات بیشتر به مستندات آن مراجعه کنید.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // تکرار کننده چرخه یا خالی است یا بی نهایت
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // تکرارکننده فعلی را به طور کامل تکرار کنید.
        // این ضروری است زیرا `self.iter` حتی در صورت خالی نبودن `self.orig` ممکن است خالی باشد
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // یک چرخه کامل را کامل کنید ، و پیگیری کنید که آیا تکرار کننده دوچرخه خالی است یا خیر.
        // برای جلوگیری از یک حلقه بی نهایت ، باید در صورت وجود تکرار کننده خالی زودتر برگردیم
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // هیچ `fold` جایگزین نمی شود ، زیرا `fold` برای `Cycle` چندان منطقی نیست و ما نمی توانیم کاری بهتر از پیش فرض انجام دهیم.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}