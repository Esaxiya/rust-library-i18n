//! تکرار خارجی قابل انعطاف
//!
//! اگر خود را با مجموعه ای از انواع مختلف پیدا کرده اید و می خواهید عناصر مجموعه گفته شده را عملی کنید ، به سرعت به 'iterators' برخورد خواهید کرد.
//! تکرار کننده ها به شدت در کد Rust اصطلاحی استفاده می شوند ، بنابراین ارزش دارد با آنها آشنا شوید.
//!
//! قبل از توضیح بیشتر ، بیایید در مورد چگونگی ساختار این ماژول صحبت کنیم:
//!
//! # Organization
//!
//! این ماژول تا حد زیادی بر اساس نوع سازماندهی شده است:
//!
//! * [Traits] بخش اصلی هستند: این traits مشخص می کند چه نوع تکرارکننده وجود دارد و چه کاری می توانید با آنها انجام دهید.روشهای این traits ارزش این را دارد که برای مطالعه بیشتر وقت بگذارید.
//! * [Functions] چند روش مفید برای ایجاد برخی از تکرارهای اساسی ارائه دهید.
//! * [Structs] اغلب انواع بازگشتی روشهای مختلف در traits این ماژول است.شما معمولاً می خواهید به جای `struct` ، به روش ایجاد کننده `struct` نگاه کنید.
//! برای جزئیات بیشتر در مورد چرایی ، به "[Implementing Iterator](#implement-iterator)" مراجعه کنید.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! خودشه!بیایید در مکررات تکرار کنیم.
//!
//! # Iterator
//!
//! قلب و روح این ماژول [`Iterator`] trait است.هسته [`Iterator`] به این شکل است:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! تکرار کننده یک روش به نام [`next`] دارد که وقتی فراخوانی می شود ، یک [Option] را برمی گرداند<Item>``
//! [`next`] [`Some(Item)`] را به شرطی که عناصری وجود داشته باشد ، برمی گرداند و هنگامی که همه آنها تمام شد ، `None` را بازمی گرداند تا نشان دهد که تکرار به پایان رسیده است.
//! تکرارکنندگان فردی ممکن است تصمیم بگیرند که تکرار را از سر بگیرند ، بنابراین تماس مجدد با [`next`] ممکن است در بعضی موارد دوباره شروع به بازگشت [`Some(Item)`] کند (یا مثلاً به [`TryIter`] مراجعه کنید).
//!
//!
//! تعریف کامل ["Iterator"] شامل چندین روش دیگر نیز می باشد ، اما آنها روش های پیش فرض هستند که در بالای [`next`] ساخته شده اند ، بنابراین شما آنها را به صورت رایگان دریافت خواهید کرد.
//!
//! تکرارکننده ها نیز قابل ترکیب هستند و زنجیر کردن آنها برای انجام اشکال پیچیده تر از پردازش معمول است.برای جزئیات بیشتر به قسمت [Adapters](#adapters) زیر مراجعه کنید.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # سه شکل تکرار
//!
//! سه روش معمول وجود دارد که می تواند تکرار کننده ها را از یک مجموعه ایجاد کند:
//!
//! * `iter()`, که بیش از `&T` تکرار می شود.
//! * `iter_mut()`, که بیش از `&mut T` تکرار می شود.
//! * `into_iter()`, که بیش از `T` تکرار می شود.
//!
//! موارد مختلف در کتابخانه استاندارد ممکن است در صورت لزوم ، یک یا چند مورد از این سه را اجرا کند.
//!
//! # در حال اجرا Iterator
//!
//! ایجاد یک تکرار کننده از طریق خود شامل دو مرحله است: ایجاد `struct` برای نگه داشتن حالت تکرار کننده و سپس پیاده سازی [`Iterator`] برای آن `struct`.
//! به همین دلیل تعداد زیادی ساختار در این ماژول وجود دارد: برای هر تکرار کننده و آداپتور تکرار کننده یکی وجود دارد.
//!
//! بیایید یک تکرار کننده به نام `Counter` بسازیم که از `1` تا `5` شمارش می شود:
//!
//! ```
//! // اول ، ساختار:
//!
//! /// تکرار کننده ای که از یک تا پنج حساب می کند
//! struct Counter {
//!     count: usize,
//! }
//!
//! // ما می خواهیم تعدادمان از یک شروع شود ، بنابراین بیایید یک روش new() را برای کمک به آن اضافه کنیم.
//! // این کاملاً ضروری نیست ، اما راحت است.
//! // توجه داشته باشید که ما `count` را از صفر شروع می کنیم ، دلیل آن را در اجرای `next()`'s در زیر خواهیم دید.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // سپس ، ما `Iterator` را برای `Counter` خود پیاده سازی می کنیم:
//!
//! impl Iterator for Counter {
//!     // ما با میزان استفاده خواهیم کرد
//!     type Item = usize;
//!
//!     // next() تنها روش مورد نیاز است
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // تعداد ما را افزایش دهید.به همین دلیل است که ما از صفر شروع کردیم.
//!         self.count += 1;
//!
//!         // بررسی کنید که آیا شمارش را به پایان رسانده ایم یا نه.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // و حالا ما می توانیم از آن استفاده کنیم!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! تماس با [`next`] از این طریق تکراری می شود.Rust ساختاری دارد که می تواند [`next`] را از روی تکرار کننده شما صدا کند ، تا زمانی که به `None` برسد.بگذارید بعدی را مرور کنیم.
//!
//! همچنین توجه داشته باشید که `Iterator` پیاده سازی پیش فرض روشهایی مانند `nth` و `fold` را که با `next` داخلی فراخوانی می شوند ، فراهم می کند.
//! اما اگر یک تکرار کننده بتواند بدون تماس با `next` با کارآیی بیشتر آنها را محاسبه کند ، می توان یک پیاده سازی سفارشی از روش هایی مانند `nth` و `fold` نیز نوشت.
//!
//! # `for` حلقه ها و `IntoIterator`
//!
//! نحو حلقه `for` Rust در واقع قند تکرارکنندگان است.در اینجا یک مثال اساسی از `for` آورده شده است:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! با این کار اعداد یک تا پنج چاپ می شوند ، هر کدام روی خط خودشان.اما در اینجا به چیزی توجه خواهید کرد: ما هرگز در vector برای تولید تکرار کننده چیزی صدا نکردیم.چه چیزی می دهد؟
//!
//! trait در کتابخانه استاندارد برای تبدیل چیزی به تکرار وجود دارد: [`IntoIterator`].
//! این trait یک روش دارد ، [`into_iter`] ، که چیزی را که [`IntoIterator`] را اجرا می کند به یک تکرار کننده تبدیل می کند.
//! بیایید دوباره نگاهی به آن حلقه `for` بیندازیم ، و کامپایلر آن را به چه چیزی تبدیل می کند:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust قندهای زدایی را به این موارد:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! ابتدا مقدار `into_iter()` را فراخوانی می کنیم.سپس ، با تکرار کننده برگشتی مطابقت داریم و بارها و بارها با [`next`] تماس می گیریم تا اینکه `None` را می بینیم.
//! در آن مرحله ، ما `break` را از حلقه خارج کردیم ، و تکرار کار ما تمام شد.
//!
//! یک نکته ظریف دیگر نیز در اینجا وجود دارد: کتابخانه استاندارد شامل یک اجرای جالب از [`IntoIterator`] است:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! به عبارت دیگر ، همه ["تکرار کنندگان" [`IntoIterator`] را فقط با بازگشت به سیستم خود پیاده سازی می کنند.این به معنی دو چیز است:
//!
//! 1. اگر در حال نوشتن [`Iterator`] هستید ، می توانید از آن با حلقه `for` استفاده کنید.
//! 2. اگر در حال ایجاد مجموعه ای هستید ، پیاده سازی [`IntoIterator`] برای آن امکان استفاده از مجموعه شما با حلقه `for` را فراهم می کند.
//!
//! # تکرار توسط مرجع
//!
//! از آنجا که [`into_iter()`] مقدار `self` را بدست می آورد ، استفاده از یک حلقه `for` برای تکرار بیش از یک مجموعه ، آن مجموعه را مصرف می کند.اغلب اوقات ، ممکن است بخواهید یک مجموعه را بدون مصرف تکرار کنید.
//! بسیاری از مجموعه ها روشهایی را ارائه می دهند که تکرارها را نسبت به منابع ارائه می دهند ، به ترتیب `iter()` و `iter_mut()` نامیده می شوند:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` هنوز متعلق به این عملکرد است.
//! ```
//!
//! اگر مجموعه ای از نوع `C` `iter()` را ارائه دهد ، معمولاً `IntoIterator` را برای `&C` نیز پیاده سازی می کند ، با پیاده سازی که فقط `iter()` را فراخوانی می کند.
//! به همین ترتیب ، مجموعه `C` که `iter_mut()` را فراهم می کند ، به طور کلی `IntoIterator` را برای `&mut C` با واگذاری به `iter_mut()` پیاده سازی می کند.این خلاصه مختصر را قادر می سازد:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // همان `values.iter_mut()` است
//!     *x += 1;
//! }
//! for x in &values { // همان `values.iter()` است
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! در حالی که بسیاری از مجموعه ها `iter()` را ارائه می دهند ، همه `iter_mut()` را ارائه نمی دهند.
//! به عنوان مثال ، تغییر جهش کلیدهای [`HashSet<T>`] یا [`HashMap<K, V>`] می تواند در صورت تغییر هش کلید ، مجموعه را در وضعیت ناسازگار قرار دهد ، بنابراین این مجموعه ها فقط `iter()` را ارائه می دهند.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! عملکردهایی که [`Iterator`] را می گیرند و [`Iterator`] دیگری را برمی گردانند ، اغلب "آداپتورهای تکرار شونده" خوانده می شوند ، زیرا آنها نوعی آداپتور هستند
//! pattern'.
//!
//! آداپتورهای متداول تکراری شامل [`map`] ، [`take`] و [`filter`] هستند.
//! برای اطلاعات بیشتر ، به اسناد آنها مراجعه کنید.
//!
//! اگر آداپتور تکرار کننده panics باشد ، تکرار کننده در وضعیت نامشخص (اما بدون حافظه) قرار خواهد گرفت.
//! این حالت همچنین تضمین نمی کند که در نسخه های Rust ثابت بماند ، بنابراین باید از تکیه بر مقادیر دقیق برگردانده شده توسط یک تکرارکننده وحشت زده جلوگیری کنید.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! تکرارکنندگان (و تکرار کننده [adapters](#adapters))*تنبل هستند*. این بدان معنی است که فقط ایجاد یک تکرار کننده کاملاً _do_ نیست. تا زمانی که با [`next`] تماس نگیرید هیچ اتفاقی نمی افتد).
//! این مسئله گاهی اوقات هنگام ایجاد تکرار کننده فقط برای عوارض جانبی آن باعث سردرگمی می شود.
//! به عنوان مثال ، روش [`map`] بسته شدن هر عنصر را که تکرار می کند فراخوانی می کند:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! این هیچ مقداری را چاپ نمی کند ، زیرا ما فقط یک تکرار کننده ایجاد کرده ایم ، نه اینکه از آن استفاده کنیم.کامپایلر در مورد این نوع رفتار به ما هشدار می دهد:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! روش اصولی نوشتن [`map`] برای عوارض جانبی آن استفاده از حلقه `for` یا تماس با روش [`for_each`] است:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! روش معمول دیگر برای ارزیابی تکرارکننده استفاده از روش [`collect`] برای تولید مجموعه جدید است.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! تکرارکنندگان لازم نیست محدود باشند.به عنوان مثال ، یک بازه پایان باز تکرار کننده نامحدود است:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! معمولاً استفاده از آداپتور تکرار کننده [`take`] برای تبدیل یک تکرار کننده نامحدود به یک متن محدود:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! با این کار اعداد `0` تا `4` ، هر کدام در خط خود چاپ می شوند.
//!
//! به خاطر داشته باشید که روشهای تکرار کننده نامحدود ، حتی روشهایی که نتیجه آنها را می توان به صورت ریاضی در زمان محدود تعیین کرد ، ممکن است خاتمه نیابند.
//! به طور خاص ، روش هایی مانند [`min`] ، که در حالت کلی نیاز به پیمایش هر عنصر در تکرار کننده دارند ، به احتمال زیاد برای هر تکرار کننده نامحدود با موفقیت بر نمی گردند.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // وای نه!یک حلقه بی نهایت!
//! // `ones.min()` باعث ایجاد یک حلقه نامحدود می شود ، بنابراین ما به این مرحله نمی رسیم!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;