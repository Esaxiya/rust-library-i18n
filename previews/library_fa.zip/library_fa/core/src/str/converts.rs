//! راه های ایجاد `str` از قطعه بایت.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// یک قطعه بایت را به یک برش رشته تبدیل می کند.
///
/// یک برش رشته ([`&str`]) از بایت ([`u8`]) ساخته شده است ، و یک قطعه بایت ([`&[u8]`][byteslice]) از بایت ساخته شده است ، بنابراین این عملکرد بین این دو تبدیل می شود.
/// همه برشهای بایت برشهای رشته ای معتبری نیستند ، با این وجود: [`&str`] مستلزم معتبر بودن UTF-8 است.
/// `from_utf8()` برای اطمینان از معتبر بودن بایت UTF-8 بررسی می کند و سپس تبدیل را انجام می دهد.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// اگر مطمئن هستید که قطعه بایت UTF-8 معتبر است و نمی خواهید سربار بررسی اعتبار شوید ، یک نسخه ناامن از این عملکرد [`from_utf8_unchecked`] وجود دارد که همان رفتار را دارد اما از چک خارج می شود.
///
///
/// اگر به جای `&str` به `String` نیاز دارید ، [`String::from_utf8`][string] را در نظر بگیرید.
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// از آنجا که می توانید `[u8; N]` را به صورت پشته اختصاص دهید و می توانید [`&[u8]`][byteslice] را نیز از آن بگیرید ، این عملکرد یکی از راه های داشتن رشته تخصیص داده شده به پشته است.مثالی از این در قسمت مثالهای زیر وجود دارد.
///
/// [byteslice]: slice
///
/// # Errors
///
/// اگر برش UTF-8 نباشد `Err` را برمی گرداند با توضیح اینکه چرا قطعه ارائه شده UTF-8 نیست.
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::str;
///
/// // برخی از بایت ها ، در vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ما می دانیم که این بایت ها معتبر هستند ، بنابراین فقط از `unwrap()` استفاده کنید.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// بایت نادرست:
///
/// ```
/// use std::str;
///
/// // برخی از بایت های نامعتبر ، در vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// برای جزئیات بیشتر در مورد انواع خطاهای قابل بازگشت ، به اسناد مربوط به [`Utf8Error`] مراجعه کنید.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // برخی از بایت ها ، در یک آرایه تخصیص یافته به پشته
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // ما می دانیم که این بایت ها معتبر هستند ، بنابراین فقط از `unwrap()` استفاده کنید.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // ایمنی: فقط اعتبار سنجی را اجرا کرد.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// یک برش قابل تغییر از بایت ها را به یک برش رشته ای قابل تغییر می دهد.
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" به عنوان یک vector قابل تغییر است
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // همانطور که می دانیم این بایت ها معتبر هستند ، می توانیم از `unwrap()` استفاده کنیم
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// بایت نادرست:
///
/// ```
/// use std::str;
///
/// // برخی از بایت های نامعتبر در vector قابل تغییر
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// برای جزئیات بیشتر در مورد انواع خطاهای قابل بازگشت ، به اسناد مربوط به [`Utf8Error`] مراجعه کنید.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // ایمنی: فقط اعتبار سنجی را اجرا کرد.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// بدون بررسی اینکه رشته حاوی UTF-8 معتبر است ، برشی از بایت را به یک رشته تبدیل می کند.
///
/// برای اطلاعات بیشتر به نسخه امن [`from_utf8`] مراجعه کنید.
///
/// # Safety
///
/// این عملکرد ایمن نیست زیرا بررسی نمی کند که بایت های ارسال شده به آن UTF-8 معتبر باشند.
/// اگر این محدودیت نقض شود ، رفتار تعریف نشده به نتیجه می رسد ، زیرا بقیه Rust فرض می کنند که ["&str"] UTF-8 معتبر است.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::str;
///
/// // برخی از بایت ها ، در vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ایمنی: تماس گیرنده باید معتبر بودن UTF-8 بایت `v` را تضمین کند.
    // همچنین به `&str` و `&[u8]` با همان طرح متکی است.
    unsafe { mem::transmute(v) }
}

/// بدون بررسی اینکه رشته حاوی UTF-8 معتبر است ، برشی از بایت را به یک رشته تبدیل می کند.نسخه قابل تغییر
///
///
/// برای اطلاعات بیشتر به نسخه تغییر ناپذیر [`from_utf8_unchecked()`] مراجعه کنید.
///
/// # Examples
///
/// کاربرد اساسی:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ایمنی: تماس گیرنده باید بایت `v` را تضمین کند
    // UTF-8 معتبر هستند ، بنابراین بازیگران `*mut str` بی خطر هستند.
    // همچنین ، ارجاع اشاره گر ایمن است زیرا این نشانگر از مرجعی تهیه می شود که برای نوشتن معتبر است.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}