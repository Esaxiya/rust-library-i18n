//! عملیات مربوط به اعتبار سنجی UTF-8.

use crate::mem;

use super::Utf8Error;

/// باتری اولیه را برای اولین بایت جمع می کند.
/// اولین بایت ویژه است ، فقط 5 بیت پایین برای عرض 2 ، 4 بیت برای عرض 3 و 3 بیت برای عرض 4 می خواهید.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// مقدار `ch` را که با بایت ادامه `byte` به روز شده است ، برمی گرداند.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// بررسی می کند که آیا بایت یک بایت ادامه دهنده UTF-8 است (یعنی با بیت های `10` شروع می شود).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// کد بعدی را از یک تکرار کننده بایت (با فرض رمزگذاری مانند UTF-8) می خواند.
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // رمزگشایی UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // حالت چند بایت رمزگشایی را از ترکیبی بایت از: [[[x y] z] w] دنبال می کند
    //
    // NOTE: عملکرد به فرمول بندی دقیق در اینجا حساس است
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] مورد
        // بیت 5 در 0xE0 .. 0xEF همیشه واضح است ، بنابراین `init` همچنان معتبر است
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] فقط از 3 بیت پایین `init` استفاده کنید
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// آخرین کد کد را از یک تکرار کننده بایت می خواند (با فرض رمزگذاری مانند UTF-8).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // رمزگشایی UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // حالت چند بایت رمزگشایی را از یک ترکیب بایت دنبال می کند: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// استفاده از برش برای قرار دادن u64 در استفاده
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `true` را در صورت وجود هر بایت در کلمه `x` غیرحرفه ای برمی گرداند (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// از طریق `v` بررسی می کند که این یک توالی UTF-8 معتبر است ، `Ok(())` را در آن حالت برمی گرداند یا اگر نامعتبر است ، `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // ما به داده نیاز داشتیم ، اما هیچ موردی وجود نداشت: خطا!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // رمزگذاری 2 بایت برای نقاط رمزگذاری است\u {0080} تا\u003d اولین C2 80 آخرین DF BF
            // رمزگذاری 3 بایت برای نقاط رمزگذاری است\u {0800} به\u {ffff} اولین E0 A0 80 آخرین EF BF BF به استثنای نقاط رمزگذاری جایگزین\u {d800} به\u {dfff} ED A0 80 به ED BF BF
            // رمزگذاری 4 بایت برای نقاط رمزگذاری است\u {1000} 0 تا\u {10ff} ff first F0 90 80 80 last F4 8F BF BF
            //
            // از نحو UTF-8 از RFC استفاده کنید
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=٪ x00-7F UTF8-2=٪ xC2-DF UTF8-دم UTF8-3= %xE0٪ xA0-BF UTF8-دم/٪ xE1-EC 2( UTF8-tail )/%xED٪ x80-9F UTF8-دم/٪ xEE-EF 2( UTF8-tail ) UTF8-4= %xF0٪ x90-BF 2( UTF8-tail )/٪ xF1-F3 3( UTF8-tail )/%xF4٪ x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // در مورد Ascii ، سعی کنید سریع جلو بروید.
            // وقتی نشانگر تراز شد ، 2 کلمه داده را در هر تکرار بخوانید تا زمانی که کلمه ای را پیدا کنیم که شامل بایت غیر ascii باشد.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // ایمنی: از آنجا که `align - index` و `ascii_block_size` هستند
                    // مضرب های `usize_bytes` ، `block = ptr.add(index)` همیشه با `usize` مطابقت دارد بنابراین برای ارجاع هر دو `block` و `block.offset(1)` ایمن است.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // در صورت وجود بایت nonascii ، شکسته شود
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // از نقطه ای که حلقه wordwise متوقف شود قدم بردارید
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// با توجه به اولین بایت ، مشخص می کند که تعداد بایت های این کاراکتر UTF-8 چقدر است.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// ماسک بیت های مقدار یک بایت ادامه.
const CONT_MASK: u8 = 0b0011_1111;
/// مقدار بیت های برچسب (ماسک برچسب !CONT_MASK است) یک بایت ادامه.
const TAG_CONT_U8: u8 = 0b1000_0000;

// کوتاه `&str` به طول حداکثر برابر با `max` اگر بریده شده باشد `true` را برمی گردانید و str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}