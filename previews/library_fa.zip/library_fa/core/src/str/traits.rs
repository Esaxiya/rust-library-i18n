//! پیاده سازی های Trait برای `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// ترتیب رشته ها را اجرا می کند.
///
/// رشته ها با مقادیر بایت [lexicographically](Ord#lexicographical-comparison) مرتب می شوند.
/// این امتیاز کد یونیکد را بر اساس موقعیت آنها در نمودار کد سفارش می دهد.
/// این لزوماً همان سفارش "alphabetical" نیست که از نظر زبان و محلی متفاوت است.
/// مرتب سازی رشته ها بر اساس استانداردهای پذیرفته شده از نظر فرهنگی به داده های خاص محلی نیاز دارد که از محدوده نوع `str` خارج باشد.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// عملیات مقایسه را روی رشته ها پیاده سازی می کند.
///
/// رشته ها با مقادیر بایت [lexicographically](Ord#lexicographical-comparison) مقایسه می شوند.
/// این نقاط کد یونیکد را بر اساس موقعیت آنها در نمودار کد مقایسه می کند.
/// این لزوماً همان سفارش "alphabetical" نیست که از نظر زبان و محلی متفاوت است.
/// مقایسه رشته ها مطابق با استانداردهای پذیرفته شده از نظر فرهنگی نیاز به داده های خاص محلی دارد که خارج از محدوده نوع `str` باشد.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// برش زیر رشته را با نحو `&self[..]` یا `&mut self[..]` پیاده سازی می کند.
///
/// برشی از کل رشته را برمی گرداند ، یعنی `&self` یا `&mut self` را برمی گرداند.معادل با&&خود [0 ..
/// len] `یا`&mut self [0 ..
/// len]`.
/// برخلاف سایر عملیات نمایه سازی ، این هرگز نمی تواند panic باشد.
///
/// این عملیات *O* است (1).
///
/// قبل از 1.20.0 ، این عملیات نمایه سازی هنوز با اجرای مستقیم `Index` و `IndexMut` پشتیبانی می شد.
///
/// معادل `&self[0 .. len]` یا `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// برش زیر رشته را با نحو `&self[begin .. end]` یا `&mut self[begin .. end]` پیاده سازی می کند.
///
/// برشی از رشته داده شده را از محدوده بایت برمی گرداند ["start" ، `end`).
///
/// این عملیات *O* است (1).
///
/// قبل از 1.20.0 ، این عملیات نمایه سازی هنوز با اجرای مستقیم `Index` و `IndexMut` پشتیبانی می شد.
///
/// # Panics
///
/// Panics اگر `begin` یا `end` به شروع بایت جابجایی یک کاراکتر اشاره ندارد (همانطور که توسط `is_char_boundary` تعریف شده است) ، اگر `begin > end` یا `end > len` باشد.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // اینها panic خواهند بود:
/// // بایت 2 در `ö` قرار دارد:
/// // &s [2 ..3] ؛
///
/// // بایت 8 در `老` و s قرار دارد [1 ..
/// // 8];
///
/// // بایت 100 خارج از رشته&s است [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ایمنی: فقط بررسی کنید که `start` و `end` در مرز کاراکتر قرار دارند ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            // ما همچنین مرزهای char را بررسی کردیم ، بنابراین این UTF-8 معتبر است.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ایمنی: فقط بررسی کنید که `start` و `end` در مرز کاراکتر قرار دارند.
            // ما می دانیم که نشانگر بی نظیر است زیرا آن را از `slice` گرفته ایم.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ایمنی: تماس گیرنده تضمین می کند که `self` در مرزهای `slice` است
        // که تمام شرایط `add` را برآورده می کند.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ایمنی: به نظرات `get_unchecked` مراجعه کنید.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary بررسی می کند که این شاخص در [0 باشد ، .len()] به دلیل مشکل NLL نمی تواند از `get` مانند بالا استفاده مجدد کند
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ایمنی: فقط بررسی کنید که `start` و `end` در مرز کاراکتر قرار دارند ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// برش زیر رشته را با نحو `&self[.. end]` یا `&mut self[.. end]` پیاده سازی می کند.
///
/// برشی از رشته داده شده را از محدوده بایت ["0" ، `end`) برمی گرداند.
/// معادل `&self[0 .. end]` یا `&mut self[0 .. end]`.
///
/// این عملیات *O* است (1).
///
/// قبل از 1.20.0 ، این عملیات نمایه سازی هنوز با اجرای مستقیم `Index` و `IndexMut` پشتیبانی می شد.
///
/// # Panics
///
/// Panics اگر `end` به شروع بایت جابجایی یک کاراکتر اشاره ندارد (همانطور که توسط `is_char_boundary` تعریف شده است) ، یا اگر `end > len` است.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ایمنی: فقط بررسی کنید که `end` در مرز کاراکتر باشد ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ایمنی: فقط بررسی کنید که `end` در مرز کاراکتر باشد ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // ایمنی: فقط بررسی کنید که `end` در مرز کاراکتر باشد ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// برش زیر رشته را با نحو `&self[begin ..]` یا `&mut self[begin ..]` پیاده سازی می کند.
///
/// برشی از رشته داده شده را از محدوده بایت برمی گرداند ["start" ، `len`).معادل `&self [شروع ..
/// len] `یا`&mut self [شروع ..
/// len]`.
///
/// این عملیات *O* است (1).
///
/// قبل از 1.20.0 ، این عملیات نمایه سازی هنوز با اجرای مستقیم `Index` و `IndexMut` پشتیبانی می شد.
///
/// # Panics
///
/// Panics اگر `begin` به شروع بایت جابجایی یک کاراکتر اشاره ندارد (همانطور که توسط `is_char_boundary` تعریف شده است) ، یا اگر `begin > len` است.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ایمنی: فقط بررسی کنید که `start` در مرز کاراکتر باشد ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ایمنی: فقط بررسی کنید که `start` در مرز کاراکتر باشد ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ایمنی: تماس گیرنده تضمین می کند که `self` در مرزهای `slice` است
        // که تمام شرایط `add` را برآورده می کند.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ایمنی: یکسان با `get_unchecked` است.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // ایمنی: فقط بررسی کنید که `start` در مرز کاراکتر باشد ،
            // و ما از یک مرجع ایمن عبور می کنیم ، بنابراین مقدار بازگشتی نیز یک خواهد بود.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// برش زیر رشته را با نحو `&self[begin ..= end]` یا `&mut self[begin ..= end]` پیاده سازی می کند.
///
/// برشی از رشته داده شده را از محدوده بایت [`begin`, `end`] برمی گرداند.معادل `&self [begin .. end + 1]` یا `&mut self[begin .. end + 1]` ، با این تفاوت که `end` حداکثر مقدار را برای `usize` داشته باشد.
///
/// این عملیات *O* است (1).
///
/// # Panics
///
/// Panics اگر `begin` به شروع بایت شروع یک کاراکتر اشاره نمی کند (همانطور که توسط `is_char_boundary` تعریف شده است) ، اگر `end` به انتهای بایت خیز یک کاراکتر اشاره نمی کند (`end + 1` یا یک بایت شروع جبران کننده یا برابر با `len` است) ، اگر `begin > end` ، یا اگر `end >= len` باشد.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked` را رعایت کند.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked_mut` را رعایت کند.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// برش زیر رشته را با نحو `&self[..= end]` یا `&mut self[..= end]` پیاده سازی می کند.
///
/// برشی از رشته داده شده را از محدوده بایت [0, `end`] برمی گرداند.
/// معادل `&self [0 .. end + 1]` ، مگر اینکه `end` حداکثر مقدار را برای `usize` داشته باشد.
///
/// این عملیات *O* است (1).
///
/// # Panics
///
/// Panics اگر `end` به پایان دادن به بایت جابجایی یک کاراکتر اشاره نمی کند (`end + 1` یا یک بایت شروع باند است که توسط `is_char_boundary` تعریف شده است ، یا برابر با `len` است) ، یا اگر `end >= len` است.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked` را رعایت کند.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked_mut` را رعایت کند.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// مقدار را از یک رشته تجزیه کنید
///
/// روش [`from_str`] `FromStr` اغلب به طور ضمنی از طریق روش [`parse`] [str] استفاده می شود.
/// برای مثال به مستندات ["تجزیه"] مراجعه کنید.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` پارامتر طول عمر ندارد ، بنابراین شما فقط می توانید انواع مختلفی را که خودشان پارامتر مادام العمر ندارند تجزیه کنید.
///
/// به عبارت دیگر ، شما می توانید `i32` را با `FromStr` تجزیه کنید ، اما `&i32` را نمی توانید.
/// شما می توانید یک ساختار حاوی `i32` را تجزیه کنید ، اما نه اینکه حاوی `&i32` باشد.
///
/// # Examples
///
/// پیاده سازی اساسی `FromStr` روی نمونه ای از نوع `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// خطای مرتبط که می تواند از تجزیه بازگردد.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// رشته `s` را تجزیه می کند تا مقداری از این نوع را برگرداند.
    ///
    /// در صورت موفقیت در تجزیه ، مقدار داخل [`Ok`] را برگردانید ، در غیر این صورت وقتی رشته نادرست است ، خطای مربوط به [`Err`] داخلی را برمی گردانید.
    /// نوع خطا مخصوص اجرای trait است.
    ///
    /// # Examples
    ///
    /// استفاده اساسی با [`i32`] ، نوعی که `FromStr` را پیاده سازی می کند:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// `bool` را از یک رشته تجزیه کنید.
    ///
    /// `Result<bool, ParseBoolError>` را ارائه می دهد ، زیرا `s` ممکن است در واقع قابل تجزیه باشد.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// توجه داشته باشید ، در بسیاری از موارد ، روش `.parse()` در `str` مناسب تر است.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}