//! نوع خطای utf8 را تعریف می کند.

use crate::fmt;

/// خطاهایی که می توانند هنگام تعبیر توالی [`u8`] به عنوان یک رشته رخ دهند.
///
/// به همین ترتیب ، خانواده توابع و روش های `from_utf8` برای هر دو ["String"] و ["&str"] از این خطا استفاده می کنند ، به عنوان مثال.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// از روشهای این نوع خطا می توان برای ایجاد عملکردی مشابه `String::from_utf8_lossy` بدون اختصاص حافظه heap استفاده کرد:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// شاخص موجود در رشته داده شده را که UTF-8 معتبر آن تأیید شده است ، برمی گرداند.
    ///
    /// این حداکثر شاخص است به طوری که `from_utf8(&input[..index])` `Ok(_)` را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// use std::str;
    ///
    /// // برخی از بایت های نامعتبر ، در vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 یک خطای Utf8E را برمی گرداند
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // بایت دوم در اینجا نامعتبر است
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// اطلاعات بیشتری در مورد خرابی ارائه می دهد:
    ///
    /// * `None`: پایان ورودی به طور غیر منتظره ای به دست آمد.
    ///   `self.valid_up_to()` 1 تا 3 بایت از انتهای ورودی است.
    ///   اگر جریان بایت (مانند پرونده یا سوکت شبکه) به طور تدریجی رمزگشایی شود ، این می تواند `char` معتبری باشد که توالی بایت UTF-8 آن چندین قطعه را پوشانده است.
    ///
    ///
    /// * `Some(len)`: یک بایت غیر منتظره روبرو شد
    ///   طول ارائه شده مربوط به توالی بایت نامعتبر است که از شاخص داده شده توسط `valid_up_to()` شروع می شود.
    ///   رمزگشایی باید پس از آن توالی (پس از قرار دادن [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) در صورت رمزگشایی با ضرر از سر گرفته شود.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// هنگام تجزیه `bool` با استفاده از [`from_str`] خطایی برگشت داده شد
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}