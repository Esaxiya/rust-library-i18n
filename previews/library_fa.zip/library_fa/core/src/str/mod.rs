//! دستکاری رشته.
//!
//! برای جزئیات بیشتر ، به ماژول [`std::str`] مراجعه کنید.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. خارج از محدوده
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. شروع <=پایان
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. مرز شخصیت
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // شخصیت را پیدا کنید
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` باید کمتر از مرز len و مرز باشد
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// طول `self` را برمی گرداند.
    ///
    /// این طول بر حسب بایت است ، نه ["char"] یا نمودارهای گرافیکی.
    /// به عبارت دیگر ، ممکن است آن چیزی نباشد که انسان طول رشته را در نظر می گیرد.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // فانتزی f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// اگر `self` طول صفر بایت داشته باشد `true` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// بررسی می کند که "index"-th بایت اولین بایت در یک دنباله نقطه کد UTF-8 یا انتهای رشته است.
    ///
    ///
    /// شروع و پایان رشته (زمانی که `index== self.len()`) مرز محسوب می شود.)
    ///
    /// اگر `index` بزرگتر از `self.len()` باشد `false` را برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // شروع `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // بایت دوم `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // سوم بایت `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 و len همیشه خوب هستند.
        // صریحاً صفر را امتحان کنید تا بتواند به راحتی بررسی را بهینه کند و از خواندن داده های رشته برای آن مورد صرف نظر کند.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // این جادوی کمی معادل: b <128 || استb>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// یک برش رشته را به یک برش بایت تبدیل می کند.
    /// برای تبدیل برش بایت به قطعه رشته ای ، از عملکرد [`from_utf8`] استفاده کنید.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ایمنی: صدای ثابت به این دلیل است که ما دو نوع با همان طرح را تغییر صدا می دهیم
        unsafe { mem::transmute(self) }
    }

    /// یک برش رشته قابل تغییر را به یک برش بایت قابل تغییر می دهد.
    ///
    /// # Safety
    ///
    /// تماس گیرنده باید اطمینان حاصل کند که محتوای قطعه قبل از پایان وام و استفاده از `str` زیرین ، UTF-8 معتبر است.
    ///
    ///
    /// استفاده از `str` که محتوای آن معتبر نیست UTF-8 یک رفتار تعریف نشده است.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ایمنی: بازیگران از `&str` به `&[u8]` از `str` ایمن هستند
        // همان طرح `&[u8]` را دارد (فقط libstd می تواند این ضمانت را ارائه دهد).
        // ارجاع اشاره گر ایمن است زیرا از یک منبع قابل تغییر که برای نوشتن معتبر است ، حاصل می شود.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// یک برش رشته را به یک نشانگر خام تبدیل می کند.
    ///
    /// از آنجا که برش های رشته ای یک بایت هستند ، نشانگر خام به [`u8`] اشاره می کند.
    /// این نشانگر به اولین بایت برش رشته نشان داده خواهد شد.
    ///
    /// تماس گیرنده باید اطمینان حاصل کند که نشانگر برگشتی هرگز روی آن نوشته نشده است.
    /// اگر می خواهید محتوای برش رشته را جهش دهید ، از [`as_mut_ptr`] استفاده کنید.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// یک برش رشته قابل تغییر را به یک نشانگر خام تبدیل می کند.
    ///
    /// از آنجا که برش های رشته ای یک بایت هستند ، نشانگر خام به [`u8`] اشاره می کند.
    /// این نشانگر به اولین بایت برش رشته نشان داده خواهد شد.
    ///
    /// این مسئولیت شماست که مطمئن شوید برش رشته فقط به شکلی معتبر باقی می ماند که UTF-8 معتبر باشد.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// یک زیرمجموعه `str` برمی گرداند.
    ///
    /// این گزینه جایگزین وحشت زدایی برای نمایه سازی `str` است.
    /// [`None`] را هر زمان که عملکرد نمایه سازی معادل panic داشته باشد ، برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // شاخص ها در مرزهای توالی UTF-8 نیستند
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // خارج از محدوده
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// یک زیرشاخه قابل تغییر `str` برمی گرداند.
    ///
    /// این گزینه جایگزین وحشت زدایی برای نمایه سازی `str` است.
    /// [`None`] را هر زمان که عملکرد نمایه سازی معادل panic داشته باشد ، برمی گرداند.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // طول صحیح
    /// assert!(v.get_mut(0..5).is_some());
    /// // خارج از محدوده
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// یک زیرمجموعه بدون علامت `str` برمی گرداند.
    ///
    /// این گزینه جایگزین نشده برای نمایه سازی `str` است.
    ///
    /// # Safety
    ///
    /// تماس گیرندگان این عملکرد وظیفه دارند این پیش شرط ها را برآورده کنند:
    ///
    /// * شاخص شروع نباید بیش از شاخص پایان باشد.
    /// * شاخص ها باید در محدوده قطعه اصلی باشد.
    /// * نمایه ها باید در مرزهای توالی UTF-8 قرار بگیرند.
    ///
    /// در غیر این صورت ، قطعه رشته برگشتی می تواند حافظه نامعتبر را ارجاع دهد یا موارد نامعتبر ارتباط داده شده توسط نوع `str` را نقض کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked` را حفظ کند.
        // این قطعه قابل استناد است زیرا `self` یک مرجع ایمن است.
        // اشاره گر برگشتی ایمن است زیرا ضمانت `SliceIndex` باید این را تضمین کند.
        unsafe { &*i.get_unchecked(self) }
    }

    /// یک اشتراک قابل تغییر و بدون علامت `str` برمی گرداند.
    ///
    /// این گزینه جایگزین نشده برای نمایه سازی `str` است.
    ///
    /// # Safety
    ///
    /// تماس گیرندگان این عملکرد وظیفه دارند این پیش شرط ها را برآورده کنند:
    ///
    /// * شاخص شروع نباید بیش از شاخص پایان باشد.
    /// * شاخص ها باید در محدوده قطعه اصلی باشد.
    /// * نمایه ها باید در مرزهای توالی UTF-8 قرار بگیرند.
    ///
    /// در غیر این صورت ، قطعه رشته برگشتی می تواند حافظه نامعتبر را ارجاع دهد یا موارد نامعتبر ارتباط داده شده توسط نوع `str` را نقض کند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked_mut` را حفظ کند.
        // این قطعه قابل استناد است زیرا `self` یک مرجع ایمن است.
        // اشاره گر برگشتی ایمن است زیرا ضمانت `SliceIndex` باید این را تضمین کند.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// با دور زدن بررسی های ایمنی ، یک برش رشته را از یک برش رشته دیگر ایجاد می کند.
    ///
    /// این معمولاً توصیه نمی شود ، با احتیاط استفاده کنید!برای یک گزینه ایمن به [`str`] و [`Index`] مراجعه کنید.
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// این برش جدید از `begin` به `end` شامل `begin` اما به استثنای `end` تبدیل نمی شود.
    ///
    /// برای دریافت یک برش رشته قابل تغییر ، به روش [`slice_mut_unchecked`] مراجعه کنید.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// تماس گیرندگان این عملکرد وظیفه دارند سه شرط را برآورده کنند:
    ///
    /// * `begin` نباید بیش از `end` باشد.
    /// * `begin` و `end` باید موقعیت های بایت درون برش رشته باشد.
    /// * `begin` و `end` باید در مرزهای توالی UTF-8 قرار داشته باشد.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked` را حفظ کند.
        // این قطعه قابل استناد است زیرا `self` یک مرجع ایمن است.
        // اشاره گر برگشتی ایمن است زیرا ضمانت `SliceIndex` باید این را تضمین کند.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// با دور زدن بررسی های ایمنی ، یک برش رشته را از یک برش رشته دیگر ایجاد می کند.
    /// این معمولاً توصیه نمی شود ، با احتیاط استفاده کنید!برای یک گزینه ایمن به [`str`] و [`IndexMut`] مراجعه کنید.
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// این برش جدید از `begin` به `end` شامل `begin` اما به استثنای `end` تبدیل نمی شود.
    ///
    /// برای به دست آوردن یک برش رشته غیر قابل تغییر ، به روش [`slice_unchecked`] مراجعه کنید.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// تماس گیرندگان این عملکرد وظیفه دارند سه شرط را برآورده کنند:
    ///
    /// * `begin` نباید بیش از `end` باشد.
    /// * `begin` و `end` باید موقعیت های بایت درون برش رشته باشد.
    /// * `begin` و `end` باید در مرزهای توالی UTF-8 قرار داشته باشد.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ایمنی: تماس گیرنده باید قرارداد ایمنی `get_unchecked_mut` را حفظ کند.
        // این قطعه قابل استناد است زیرا `self` یک مرجع ایمن است.
        // اشاره گر برگشتی ایمن است زیرا ضمانت `SliceIndex` باید این را تضمین کند.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// یک برش رشته را در یک شاخص به دو قسمت کنید.
    ///
    /// آرگومان ، `mid` ، باید از ابتدای رشته یک بایت باشد.
    /// همچنین باید در مرز یک نقطه کد UTF-8 باشد.
    ///
    /// دو برش برگشتی از ابتدای قطعه رشته به `mid` و از `mid` به انتهای قطعه رشته منتقل می شوند.
    ///
    /// در عوض برای دریافت برشهای رشته قابل تغییر ، به روش [`split_at_mut`] مراجعه کنید.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics اگر `mid` در مرز نقطه کد UTF-8 نباشد ، یا اگر از انتهای آخرین نقطه کد قطعه رشته گذشته است.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary بررسی می کند که این شاخص در [0 ، .len()]
        if self.is_char_boundary(mid) {
            // ایمنی: فقط بررسی کرد که `mid` در مرز کاراکتر باشد.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// یک رشته رشته قابل تغییر را در یک شاخص به دو قسمت کنید.
    ///
    /// آرگومان ، `mid` ، باید از ابتدای رشته یک بایت باشد.
    /// همچنین باید در مرز یک نقطه کد UTF-8 باشد.
    ///
    /// دو برش برگشتی از ابتدای قطعه رشته به `mid` و از `mid` به انتهای قطعه رشته منتقل می شوند.
    ///
    /// در عوض برای دریافت برشهای رشته غیرقابل تغییر ، به روش [`split_at`] مراجعه کنید.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics اگر `mid` در مرز نقطه کد UTF-8 نباشد ، یا اگر از انتهای آخرین نقطه کد قطعه رشته گذشته است.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary بررسی می کند که این شاخص در [0 ، .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ایمنی: فقط بررسی کرد که `mid` در مرز کاراکتر باشد.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// یک تکرار کننده را بر روی ["char"] یک برش رشته برمی گرداند.
    ///
    /// از آنجا که یک برش رشته از UTF-8 معتبر تشکیل شده است ، می توانیم از طریق یک قطعه رشته توسط [`char`] تکرار کنیم.
    /// این روش چنین تکرار کننده ای را برمی گرداند.
    ///
    /// مهم است که به یاد داشته باشید که [`char`] نشان دهنده مقیاس Unicode Scalar است و ممکن است با ایده شما درباره 'character' مطابقت نداشته باشد.
    ///
    /// تکرار بیش از خوشه های گرافیم ممکن است همان چیزی باشد که شما در واقع می خواهید.
    /// این قابلیت توسط کتابخانه استاندارد Rust ارائه نشده است ، به جای آن crates.io را بررسی کنید.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// به یاد داشته باشید ، ممکن است [`char`} با شهود شما درباره شخصیت ها مطابقت نداشته باشد:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // نه 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// یک تکرار کننده را از روی قسمتهای "رشته" و موقعیتهای آنها برمی گرداند.
    ///
    /// از آنجا که یک برش رشته از UTF-8 معتبر تشکیل شده است ، می توانیم از طریق یک قطعه رشته توسط [`char`] تکرار کنیم.
    /// این روش تکرار کننده هر دو [char]] و همچنین موقعیت بایت آنها را برمی گرداند.
    ///
    /// تکرار کننده تاپل تولید می کند.موقعیت اول است ، [`char`] دوم است.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// به یاد داشته باشید ، ممکن است [`char`} با شهود شما درباره شخصیت ها مطابقت نداشته باشد:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // نه (0 ، 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // 3 را در اینجا یادداشت کنید ، آخرین کاراکتر دو بایت را اشغال کرد
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// یک تکرار کننده روی بایت های یک برش رشته.
    ///
    /// از آنجا که یک برش رشته از دنباله ای از بایت تشکیل شده است ، می توانیم از طریق یک قطعه رشته به بایت تکرار کنیم.
    /// این روش چنین تکرار کننده ای را برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// یک رشته را توسط فضای سفید تقسیم می کند.
    ///
    /// تکرار کننده برگردانده شده ، برشهای رشته ای را که برشهای فرعی رشته اصلی است ، با هر مقدار فضای خالی از هم جدا می کند ، برمی گرداند.
    ///
    ///
    /// 'Whitespace' با توجه به شرایط Unicode Derived Core Property `White_Space` تعریف شده است.
    /// اگر می خواهید فقط در فضای سفید ASCII تقسیم شوید ، از [`split_ascii_whitespace`] استفاده کنید.
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// انواع فضای سفید در نظر گرفته شده است:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// یک رشته را توسط فضای خالی ASCII تقسیم می کند.
    ///
    /// تکرار کننده بازگشت ، برش های رشته ای را که برش های فرعی رشته اصلی است ، با هر مقدار فضای خالی ASCII از هم جدا می کند ، برمی گرداند.
    ///
    ///
    /// در عوض برای تقسیم شدن توسط Unicode `Whitespace` ، از [`split_whitespace`] استفاده کنید.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// انواع فضای سفید ASCII در نظر گرفته شده است:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// یک تکرار کننده روی خطوط یک رشته ، به عنوان برش های رشته ای.
    ///
    /// خطوط با خط جدید (`\n`) یا بازگشت کالسکه با تغذیه خط (`\r\n`) به پایان می رسند.
    ///
    /// پایان خط نهایی اختیاری است.
    /// رشته ای که با پایان خط نهایی به پایان برسد ، همان رشته های یکسان و بدون پایان خط آخر را برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// پایان خط نهایی مورد نیاز نیست:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// یک تکرار کننده بیش از خطوط یک رشته.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// یک تکرار کننده `u16` را روی رشته رمزگذاری شده به عنوان UTF-16 برمی گرداند.
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// اگر الگوی داده شده با برش فرعی این برش رشته مطابقت داشته باشد ، `true` را برمی گرداند.
    ///
    /// اگر `false` نباشد ، برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// اگر الگوی داده شده با پیشوند این برش رشته مطابقت داشته باشد ، `true` را برمی گرداند.
    ///
    /// اگر `false` نباشد ، برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// اگر الگوی داده شده با پسوند این برش رشته مطابقت داشته باشد ، `true` را برمی گرداند.
    ///
    /// اگر `false` نباشد ، برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// شاخص بایت شخصیت اول این قطعه رشته ای را که مطابق با الگو است ، برمی گرداند.
    ///
    /// اگر الگو مطابقت نداشته باشد [`None`] را برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// الگوهای پیچیده تر با استفاده از سبک بدون نقطه و بسته شدن:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// یافتن الگو:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// شاخص بایت را برای اولین کاراکتر مناسب ترین مطابقت الگو در این قطعه رشته برمی گرداند.
    ///
    /// اگر الگو مطابقت نداشته باشد [`None`] را برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// الگوهای پیچیده تر با بسته شدن:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// یافتن الگو:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// یک تکرار کننده روی زیر رشته های این قطعه رشته ای ، با کاراکترهای منطبق با یک الگو از هم جدا شده است.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد و جستجوی forward/reverse همان عناصر را ارائه دهد ، تکرار کننده برگشتی [`DoubleEndedIterator`] خواهد بود.
    /// این برای [`char`] درست است ، اما برای `&str` صدق نمی کند.
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد اما ممکن است نتایج آن با جستجوی رو به جلو متفاوت باشد ، می توان از روش [`rsplit`] استفاده کرد.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// اگر الگوی یک تکه کاراکتر است ، بر روی هر یک از وقایع هر یک از شخصیت ها تقسیم کنید:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// الگوی پیچیده تر ، با استفاده از بسته شدن:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// اگر یک رشته شامل چندین جداکننده مجاور باشد ، در پایان با رشته های خالی در خروجی مواجه خواهید شد:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// جداکننده های مجاور توسط رشته خالی جدا می شوند.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// جدا کننده ها در آغاز یا انتهای یک رشته با رشته های خالی همسایه می شوند.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// وقتی رشته خالی به عنوان جدا کننده مورد استفاده قرار می گیرد ، همه کاراکترهای رشته را بهمراه ابتدا و انتهای رشته از هم جدا می کند.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// جداکننده های پیوسته هنگامی که از فضای خالی به عنوان جدا کننده استفاده می شود ، می توانند منجر به یک رفتار احتمالاً شگفت آور شوند.این کد صحیح است:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ به شما می دهد:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// برای این رفتار از [`split_whitespace`] استفاده کنید.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// یک تکرار کننده روی زیر رشته های این قطعه رشته ای ، با کاراکترهای منطبق با یک الگو از هم جدا شده است.
    /// تفاوت در تکرار کننده تولید شده توسط `split` در این است که `split_inclusive` قسمت مطابق را به عنوان خاتمه دهنده زیر رشته ترک می کند.
    ///
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// اگر آخرین عنصر رشته مطابقت داشته باشد ، آن عنصر پایان دهنده رشته قبلی محسوب می شود.
    /// این زیر رشته آخرین موردی است که توسط تکرار کننده برگردانده شده است.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// یک تکرار کننده بر روی زیر رشته های برش رشته داده شده ، با کاراکترهای منطبق با یک الگوی از هم جدا شده و به ترتیب معکوس عمل می کند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// تکرارکننده بازگشت نیاز دارد که الگو از جستجوی معکوس پشتیبانی کند و اگر جستجوی forward/reverse همان عناصر را ارائه دهد [`DoubleEndedIterator`] خواهد بود.
    ///
    ///
    /// برای تکرار از جلو ، می توان از روش [`split`] استفاده کرد.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// الگوی پیچیده تر ، با استفاده از بسته شدن:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// یک تکرار کننده بر روی زیر رشته های برش رشته داده شده ، با کاراکترهای منطبق با یک الگوی جدا شده است.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// معادل [`split`] ، با این تفاوت که در صورت خالی بودن زیر رشته عقب ، حذف می شود.
    ///
    /// [`split`]: str::split
    ///
    /// این روش می تواند برای داده های رشته ای که _terminated_ است ، به جای _separated_ توسط یک الگو ، مورد استفاده قرار گیرد.
    ///
    /// # رفتار تکرار شونده
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد و جستجوی forward/reverse همان عناصر را ارائه دهد ، تکرار کننده برگشتی [`DoubleEndedIterator`] خواهد بود.
    /// این برای [`char`] درست است ، اما برای `&str` صدق نمی کند.
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد اما ممکن است نتایج آن با جستجوی رو به جلو متفاوت باشد ، می توان از روش [`rsplit_terminator`] استفاده کرد.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// یک تکرار کننده بر روی زیر رشته های `self` ، با کاراکترهای منطبق با یک الگوی از هم جدا شده و به ترتیب معکوس عمل می کند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// معادل [`split`] ، با این تفاوت که در صورت خالی بودن زیر رشته عقب ، حذف می شود.
    ///
    /// [`split`]: str::split
    ///
    /// این روش می تواند برای داده های رشته ای که _terminated_ است ، به جای _separated_ توسط یک الگو ، مورد استفاده قرار گیرد.
    ///
    /// # رفتار تکرار شونده
    ///
    /// تکرارکننده بازگشت نیاز دارد که الگو از جستجوی معکوس پشتیبانی کند ، و اگر جستجوی forward/reverse همان عناصر را ارائه دهد ، دوبار پایان می یابد.
    ///
    ///
    /// برای تکرار از جلو ، می توان از روش [`split_terminator`] استفاده کرد.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// یک تکرار کننده در زیر رشته های برش رشته داده شده ، با یک الگوی جدا شده ، محدود به بازگشت حداکثر موارد `n` است.
    ///
    /// اگر زیر رشته های `n` برگردانده شوند ، آخرین زیر رشته (زیر رشته `n`) شامل باقی مانده رشته خواهد بود.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// تکرار کننده برگشتی دوبار پایان نخواهد داشت ، زیرا برای پشتیبانی کارآمد نیست.
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد ، می توان از روش [`rsplitn`] استفاده کرد.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// الگوی پیچیده تر ، با استفاده از بسته شدن:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// یک تکرار کننده روی زیر رشته های این برش رشته ، که توسط یک الگوی از هم جدا شده و از انتهای رشته شروع می شود ، محدود به بازگشت حداکثر موارد `n` است.
    ///
    ///
    /// اگر زیر رشته های `n` برگردانده شوند ، آخرین زیر رشته (زیر رشته `n`) شامل باقی مانده رشته خواهد بود.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// تکرار کننده برگشتی دوبار پایان نخواهد داشت ، زیرا برای پشتیبانی کارآمد نیست.
    ///
    /// برای تقسیم از جلو ، می توان از روش [`splitn`] استفاده کرد.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// الگوی پیچیده تر ، با استفاده از بسته شدن:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// رشته را در اولین وقوع جداکننده مشخص می کند و پیشوند را قبل از جدا کننده و پسوند را پس از جدا کننده برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// رشته را روی آخرین وقوع جداکننده مشخص می کند و پیشوند را قبل از جدا کننده و پسوند را پس از جدا کننده برمی گرداند.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// یک تکرار کننده بر روی تطابق جداگانه یک الگوی درون برش رشته داده شده.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد و جستجوی forward/reverse همان عناصر را ارائه دهد ، تکرار کننده برگشتی [`DoubleEndedIterator`] خواهد بود.
    /// این برای [`char`] درست است ، اما برای `&str` صدق نمی کند.
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد اما ممکن است نتایج آن با جستجوی رو به جلو متفاوت باشد ، می توان از روش [`rmatches`] استفاده کرد.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// یک تکرارکننده بیش از تطابق جداگانه یک الگوی درون این قطعه رشته ای ، به ترتیب معکوس عمل می کند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// تکرارکننده بازگشت نیاز دارد که الگو از جستجوی معکوس پشتیبانی کند و اگر جستجوی forward/reverse همان عناصر را ارائه دهد [`DoubleEndedIterator`] خواهد بود.
    ///
    ///
    /// برای تکرار از جلو ، می توان از روش [`matches`] استفاده کرد.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// یک تکرار کننده روی تطابق های جداگانه یک الگوی درون این برش رشته و همچنین شاخصی که مسابقه از آن شروع می شود.
    ///
    /// برای مسابقات `pat` در `self` که با هم تداخل دارند ، فقط شاخص های مربوط به مسابقه اول بازگردانده می شوند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد و جستجوی forward/reverse همان عناصر را ارائه دهد ، تکرار کننده برگشتی [`DoubleEndedIterator`] خواهد بود.
    /// این برای [`char`] درست است ، اما برای `&str` صدق نمی کند.
    ///
    /// اگر الگو اجازه جستجوی معکوس را بدهد اما ممکن است نتایج آن با جستجوی رو به جلو متفاوت باشد ، می توان از روش [`rmatch_indices`] استفاده کرد.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // فقط اولین `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// یک تکرار کننده بر روی تطابق جداگانه یک الگوی در `self` ، به ترتیب معکوس همراه با شاخص مسابقه عملکرد دارد.
    ///
    /// برای مسابقات `pat` در `self` که با هم تداخل دارند ، فقط شاخص های مربوط به آخرین مسابقه بازگردانده می شوند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # رفتار تکرار شونده
    ///
    /// تکرارکننده بازگشت نیاز دارد که الگو از جستجوی معکوس پشتیبانی کند و اگر جستجوی forward/reverse همان عناصر را ارائه دهد [`DoubleEndedIterator`] خواهد بود.
    ///
    ///
    /// برای تکرار از جلو ، می توان از روش [`match_indices`] استفاده کرد.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // فقط `aba` آخر
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// یک برش رشته را باز می کند و فضای خالی پیشرو و دنباله دار برداشته شده است.
    ///
    /// 'Whitespace' با توجه به شرایط Unicode Derived Core Property `White_Space` تعریف شده است.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// برش یک رشته را با فاصله خالی فضای اصلی برمی گرداند.
    ///
    /// 'Whitespace' با توجه به شرایط Unicode Derived Core Property `White_Space` تعریف شده است.
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// `start` در این زمینه اولین موقعیت آن رشته بایت است.برای یک زبان چپ به راست مانند انگلیسی یا روسی ، این سمت چپ خواهد بود و برای زبانهای راست به چپ مانند عربی یا عبری ، این سمت راست خواهد بود.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// یک برش رشته ای را باز می کند که فضای خالی دنباله آن برداشته شده است.
    ///
    /// 'Whitespace' با توجه به شرایط Unicode Derived Core Property `White_Space` تعریف شده است.
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// `end` در این زمینه آخرین موقعیت آن رشته بایت است.برای یک زبان چپ به راست مانند انگلیسی یا روسی ، این سمت راست خواهد بود و برای زبانهای راست به چپ مانند عربی یا عبری ، این سمت چپ خواهد بود.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// برش یک رشته را با فاصله خالی فضای اصلی برمی گرداند.
    ///
    /// 'Whitespace' با توجه به شرایط Unicode Derived Core Property `White_Space` تعریف شده است.
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// 'Left' در این زمینه اولین موقعیت آن رشته بایت است.برای زبانی مانند عربی یا عبری که "راست به چپ" هستند تا "چپ به راست" ، این سمت _right_ خواهد بود ، نه چپ.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// یک برش رشته ای را باز می کند که فضای خالی دنباله آن برداشته شده است.
    ///
    /// 'Whitespace' با توجه به شرایط Unicode Derived Core Property `White_Space` تعریف شده است.
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// 'Right' در این زمینه آخرین موقعیت آن رشته بایت است.برای زبانی مانند عربی یا عبری که "راست به چپ" هستند تا "چپ به راست" ، این سمت _left_ خواهد بود ، نه سمت راست.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// یک قطعه رشته ای را با تمام پیشوندها و پسوندهایی که مطابق با الگویی است که به طور مکرر برداشته شده برمی گرداند
    ///
    /// [pattern] می تواند یک [`char`] ، یک تکه ["char" باشد ، یا یک تابع یا بسته است که تعیین می کند یک شخصیت مطابقت داشته باشد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// الگوی پیچیده تر ، با استفاده از بسته شدن:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // اولین مسابقه شناخته شده را به خاطر بسپارید ، اگر آن را در زیر اصلاح کنید
            // آخرین مسابقه متفاوت است
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ایمنی: `Searcher` برای بازگرداندن شاخص های معتبر شناخته شده است.
        unsafe { self.get_unchecked(i..j) }
    }

    /// یک برش رشته را با تمام پیشوندهایی که مطابق با الگویی است که بارها برداشته شده است برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// `start` در این زمینه اولین موقعیت آن رشته بایت است.برای یک زبان چپ به راست مانند انگلیسی یا روسی ، این سمت چپ خواهد بود و برای زبانهای راست به چپ مانند عربی یا عبری ، این سمت راست خواهد بود.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ایمنی: `Searcher` برای بازگرداندن شاخص های معتبر شناخته شده است.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// یک برش رشته را با پیشوند برداشته شده برمی گرداند.
    ///
    /// اگر رشته با الگوی `prefix` شروع شود ، رشته پس از پیشوند را که در `Some` پیچیده شده است ، برمی گرداند.
    /// برخلاف `trim_start_matches` ، این روش دقیقاً یک بار پیشوند را حذف می کند.
    ///
    /// اگر رشته با `prefix` شروع نشود ، `None` را برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// یک برش رشته را با پسوند حذف شده برمی گرداند.
    ///
    /// اگر رشته با الگوی `suffix` خاتمه یابد ، رشته را قبل از پسوند ، که در `Some` بسته بندی شده است ، برمی گرداند.
    /// برخلاف `trim_end_matches` ، این روش دقیقاً یک بار پسوند را حذف می کند.
    ///
    /// اگر رشته با `suffix` خاتمه نیابد ، `None` را برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// برش رشته ای را با تمام پسوندهایی که مطابق با الگویی است که بارها و بارها برداشته شده برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// `end` در این زمینه آخرین موقعیت آن رشته بایت است.برای یک زبان چپ به راست مانند انگلیسی یا روسی ، این سمت راست خواهد بود و برای زبانهای راست به چپ مانند عربی یا عبری ، این سمت چپ خواهد بود.
    ///
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// الگوی پیچیده تر ، با استفاده از بسته شدن:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ایمنی: `Searcher` برای بازگرداندن شاخص های معتبر شناخته شده است.
        unsafe { self.get_unchecked(0..j) }
    }

    /// یک برش رشته را با تمام پیشوندهایی که مطابق با الگویی است که بارها برداشته شده است برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// 'Left' در این زمینه اولین موقعیت آن رشته بایت است.برای زبانی مانند عربی یا عبری که "راست به چپ" هستند تا "چپ به راست" ، این سمت _right_ خواهد بود ، نه چپ.
    ///
    ///
    /// # Examples
    ///
    /// کاربرد اساسی:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// برش رشته ای را با تمام پسوندهایی که مطابق با الگویی است که بارها و بارها برداشته شده برمی گرداند.
    ///
    /// [pattern] می تواند `&str` ، [`char`] ، برش ["char"] s یا عملکرد یا بسته باشد که تعیین کند که یک شخصیت مطابقت دارد.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # جهت متن
    ///
    /// رشته دنباله ای از بایت است.
    /// 'Right' در این زمینه آخرین موقعیت آن رشته بایت است.برای زبانی مانند عربی یا عبری که "راست به چپ" هستند تا "چپ به راست" ، این سمت _left_ خواهد بود ، نه سمت راست.
    ///
    ///
    /// # Examples
    ///
    /// الگوهای ساده:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// الگوی پیچیده تر ، با استفاده از بسته شدن:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// این رشته را به نوع دیگری تجزیه می کند.
    ///
    /// از آنجا که `parse` بسیار کلی است ، می تواند باعث استنباط نوع شود.
    /// به همین ترتیب ، `parse` یکی از معدود مواردی است که نحو را با محبت به عنوان 'turbofish' می شناسید: `::<>`.
    ///
    /// این کمک می کند تا الگوریتم استنتاج به طور خاص بفهمد که شما در کدام نوع تجزیه می کنید.
    ///
    /// `parse` می تواند به هر نوعی که [`FromStr`] trait را پیاده سازی می کند تجزیه شود.
    ///

    /// # Errors
    ///
    /// اگر تجزیه این قطعه رشته به نوع دلخواه امکان پذیر نباشد ، [`Err`] را برمی گرداند.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// کاربرد اساسی
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// استفاده از 'turbofish' به جای حاشیه نویسی `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// تجزیه نشد:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// بررسی می کند که آیا همه نویسه های این رشته در محدوده ASCII هستند.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // ما می توانیم در اینجا هر بایت را به عنوان کاراکتر در نظر بگیریم: همه نویسه های چند بایت با یک بایت شروع می شوند که در محدوده ascii نیست ، بنابراین ما در آنجا متوقف خواهیم شد.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// بررسی می کند که دو رشته با هم تطابق ندارند.
    ///
    /// همان `to_ascii_lowercase(a) == to_ascii_lowercase(b)` است ، اما بدون اختصاص و کپی کردن افراد معاصر.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// این رشته را به جای بزرگ معادل ASCII تبدیل می کند.
    ///
    /// حروف ASCII 'a' تا 'z' با 'A' تا 'Z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بازگرداندن مقدار بزرگ بزرگ بدون تغییر مقدار موجود ، از [`to_ascii_uppercase()`] استفاده کنید.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ایمنی: بی خطر است زیرا ما دو نوع با همان طرح را تغییر صدا می دهیم.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// این رشته را به معادل کوچک حروف ASCII درجا تبدیل می کند.
    ///
    /// حروف ASCII 'A' تا 'Z' با 'a' تا 'z' ترسیم می شوند ، اما حروف غیر ASCII بدون تغییر هستند.
    ///
    /// برای بازگرداندن مقدار کوچک جدید بدون تغییر مقدار موجود ، از [`to_ascii_lowercase()`] استفاده کنید.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ایمنی: بی خطر است زیرا ما دو نوع با همان طرح را تغییر صدا می دهیم.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// تکرارکننده ای را که در `self` با [`char::escape_debug`] از هر کاراکتر فرار می کند ، برگردانید.
    ///
    ///
    /// Note: فقط رمزهای رمز گرافی طولانی که رشته را آغاز می کنند فرار می کنند.
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// تکرارکننده ای را که در `self` با [`char::escape_default`] از هر کاراکتر فرار می کند ، برگردانید.
    ///
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// تکرارکننده ای را که در `self` با [`char::escape_unicode`] از هر کاراکتر فرار می کند ، برگردانید.
    ///
    ///
    /// # Examples
    ///
    /// به عنوان تکرار کننده:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// با استفاده مستقیم از `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// هر دو معادل:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// با استفاده از `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// یک خیابان خالی ایجاد می کند
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// یک خیابان متحرک خالی ایجاد می کند
    #[inline]
    fn default() -> Self {
        // ایمنی: رشته خالی معتبر UTF-8 است.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// یک نوع fn قابل نامگذاری و قابل شبیه سازی است
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ایمنی: ایمن نیست
        unsafe { from_utf8_unchecked(bytes) }
    };
}