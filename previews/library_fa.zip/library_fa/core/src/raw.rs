#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! شامل تعاریف ساختار برای طرح انواع داخلی کامپایلر است.
//!
//! آنها می توانند به عنوان اهداف تغییر مکان در کد ناامن برای دستکاری مستقیم در نمایش های خام استفاده شوند.
//!
//!
//! تعریف آنها همیشه باید با ABI تعریف شده در `rustc_middle::ty::layout` مطابقت داشته باشد.
//!

/// نمایش یک شی Z trait مانند `&dyn SomeTrait`.
///
/// این ساختار از همان طرحهایی مانند `&dyn SomeTrait` و `Box<dyn AnotherTrait>` برخوردار است.
///
/// `TraitObject` تضمین شده است که با طرح ها مطابقت دارد ، اما نوع اشیا Z trait نیست (به عنوان مثال ، زمینه ها به طور مستقیم در `&dyn SomeTrait` قابل دسترسی نیستند) و همچنین آن طرح را کنترل نمی کند (تغییر تعریف باعث تغییر طرح `&dyn SomeTrait` نمی شود).
///
/// این فقط برای استفاده توسط کد ناامن طراحی شده است که باید جزئیات سطح پایین را دستکاری کند.
///
/// راهی برای مراجعه عمومی به همه اشیا objects trait وجود ندارد ، بنابراین تنها راه ایجاد مقادیر از این نوع با عملکردهایی مانند [`std::mem::transmute`][transmute] است.
/// به همین ترتیب ، تنها راه ایجاد یک شی object واقعی trait از مقدار `TraitObject` ، `transmute` است.
///
/// [transmute]: crate::intrinsics::transmute
///
/// سنتز یک شی Z trait با انواع ناسازگار-جایی که vtable با نوع مقداری که نشانگر داده به آن نشان می دهد مطابقت ندارد-به احتمال زیاد منجر به یک رفتار تعریف نشده می شود.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // به عنوان مثال trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // اجازه دهید کامپایلر یک شی trait بسازد
/// let object: &dyn Foo = &value;
///
/// // به نمایندگی خام نگاه کنید
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // نشانگر داده آدرس `value` است
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // با استفاده از `i32` vtable از `object` ، یک شی جدید بسازید و به `i32` متفاوت اشاره کنید
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // باید درست مثل این باشد که ما مستقیماً یک شی0 trait از `other_value` ساخته باشیم
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}