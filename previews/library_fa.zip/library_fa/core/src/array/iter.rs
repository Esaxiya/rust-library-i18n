//! تکرارکننده `IntoIter` را برای آرایه ها تعریف می کند.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// تکرار کننده [array] با ارزش.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// این آرایه ای است که ما در حال تکرار آن هستیم.
    ///
    /// عناصری با شاخص `i` که `alive.start <= i < alive.end` هنوز بازده نشده است و ورودی های آرایه معتبری هستند.
    /// عناصر دارای شاخص `i < alive.start` یا `i >= alive.end` قبلاً تولید شده اند و دیگر نباید به آنها دسترسی داشت!این عناصر مرده حتی ممکن است در یک حالت کاملاً غیر اولیه باشند!
    ///
    ///
    /// بنابراین موارد ثابت عبارتند از:
    /// - `data[alive]` زنده است (یعنی شامل عناصر معتبری است)
    /// - `data[..alive.start]` و `data[alive.end..]` مرده اند (یعنی عناصر قبلاً خوانده شده اند و دیگر نباید آنها را لمس کرد!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// عناصر موجود در `data` که هنوز تولید نشده اند.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// تکرار کننده جدیدی نسبت به `array` داده شده ایجاد می کند.
    ///
    /// *توجه*: این روش ممکن است پس از [`IntoIterator` is implemented for arrays][array-into-iter] در future منسوخ شود.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // نوع `value` به جای `&i32` در اینجا `i32` است
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ایمنی: تغییر شکل در اینجا بی خطر است.اسناد `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` تضمین شده است که دارای همان اندازه و تراز هستند
        // > به عنوان `T`.
        //
        // اسناد حتی انتقال از آرایه `MaybeUninit<T>` به آرایه `T` را نشان می دهد.
        //
        //
        // با این کار ، این مقدار اولیه رضایت افراد را جلب می کند.

        // FIXME(LukasKalbertodt): در واقع از `mem::transmute` در اینجا استفاده کنید ، یک بار که با ترکیبات عمومی سازگار است:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // تا آن زمان ، ما می توانیم با استفاده از `mem::transmute_copy` یک نسخه بیتی را به عنوان نوع دیگری ایجاد کنیم ، سپس `array` را فراموش کنیم تا حذف نشود.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// یک قطعه تغییرناپذیر از تمام عناصری که هنوز تولید نشده اند را برمی گرداند.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ایمنی: می دانیم که تمام عناصر موجود در `alive` به درستی مقداردهی اولیه می شوند.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// برش قابل تغییر از تمام عناصری که هنوز تولید نشده اند را برمی گرداند.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ایمنی: می دانیم که تمام عناصر موجود در `alive` به درستی مقداردهی اولیه می شوند.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // شاخص بعدی را از جلو بگیرید.
        //
        // افزایش `alive.start` به میزان 1 ، ثابت بودن `alive` را حفظ می کند.
        // با این حال ، به دلیل این تغییر ، برای مدت کوتاهی ، منطقه زنده دیگر `data[alive]` نیست ، بلکه `data[idx..alive.end]` است.
        //
        self.alive.next().map(|idx| {
            // عنصر را از آرایه بخوانید.
            // ایمنی: `idx` نمایه ای در منطقه "alive" سابق است
            // آرایه.خواندن این عنصر به این معنی است که `data[idx]` اکنون مرده تلقی می شود (یعنی لمس نکنید).
            // همانطور که `idx` شروع منطقه زنده بود ، منطقه زنده اکنون دوباره `data[alive]` است و تمام موارد نامحدود را بازیابی می کند.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // شاخص بعدی را از پشت دریافت کنید.
        //
        // کاهش `alive.end` به 1 ، ثابت بودن `alive` را حفظ می کند.
        // با این حال ، به دلیل این تغییر ، برای مدت کوتاهی ، منطقه زنده دیگر `data[alive]` نیست ، بلکه `data[alive.start..=idx]` است.
        //
        self.alive.next_back().map(|idx| {
            // عنصر را از آرایه بخوانید.
            // ایمنی: `idx` نمایه ای در منطقه "alive" سابق است
            // آرایه.خواندن این عنصر به این معنی است که `data[idx]` اکنون مرده تلقی می شود (یعنی لمس نکنید).
            // همانطور که `idx` پایان منطقه زنده بود ، منطقه زنده اکنون دوباره `data[alive]` است و تمام موارد نامحدود را بازیابی می کند.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ایمنی: این بی خطر است: `as_mut_slice` دقیقاً قطعه فرعی را برمی گرداند
        // از عناصری که هنوز منتقل نشده اند و باقی مانده اند که رها شوند.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // به دلیل "زنده" ثابت هرگز کم نخواهد شد. شروع <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// تکرار کننده در واقع طول صحیح را گزارش می کند.
// تعداد عناصر "alive" (که باز هم تولید خواهند شد) طول محدوده `alive` است.
// طول این دامنه در `next` یا `next_back` کاهش می یابد.
// در این روش ها همیشه 1 کاهش می یابد ، اما فقط در صورت بازگشت `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // توجه داشته باشید ، ما واقعاً لازم نیست که دقیقاً با همان دامنه زنده مطابقت داشته باشیم ، بنابراین می توانیم صرف نظر از اینکه `self` کجاست ، 0 را جابجا کنیم.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // تمام عناصر زنده را کلون کنید.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // یک کلون در آرایه جدید بنویسید ، سپس دامنه زنده آن را به روز کنید.
            // در صورت شبیه سازی panics ، موارد قبلی را به درستی رها خواهیم کرد.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // فقط عناصری را که هنوز بازده نشده اند چاپ کنید: دیگر نمی توانیم به عناصر بازده شده دسترسی پیدا کنیم.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}