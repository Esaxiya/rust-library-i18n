# `rustc-std-workspace-std` crate

به اسناد مربوط به `rustc-std-workspace-core` crate مراجعه کنید.