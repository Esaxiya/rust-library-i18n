//! یک کتابخانه پشتیبانی برای نویسندگان کلان هنگام تعریف ماکروهای جدید.
//!
//! این کتابخانه ، تهیه شده توسط توزیع استاندارد ، انواع مصرف شده در رابط های تعریف کلان رویه ای را تعریف می کند ، مانند ماکروهای عملکرد مانند `#[proc_macro]` ، ویژگی های کلان `#[proc_macro_attribute]` و ویژگی های مشتق سفارشی "#[proc_macro_derive]".
//!
//!
//! برای اطلاعات بیشتر به [the book] مراجعه کنید.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// تعیین می کند که proc_macro برای برنامه در حال اجرا قابل دسترسی باشد یا خیر.
///
/// proc_macro crate فقط برای استفاده در اجرای ماکروهای رویه ای در نظر گرفته شده است.تمام عملکردهای موجود در این crate panic در صورت فراخوانی از خارج از ماکرو رویه ای ، مانند اسکریپت ساخت یا تست واحد یا باینری Rust معمولی.
///
/// با در نظر گرفتن کتابخانه های Rust که برای پشتیبانی از موارد استفاده ماکرو و غیر کلان طراحی شده اند ، `proc_macro::is_available()` راهی غیر وحشت زده برای تشخیص اینکه آیا زیرساخت های مورد نیاز برای استفاده از API proc_macro در حال حاضر در دسترس است ، فراهم می کند.
/// اگر از داخل ماکرو رویه ای فراخوانی شود ، true برمی گردد ، اگر از باینری دیگر فراخوانی شود false است.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// نوع اصلی ارائه شده توسط این crate ، نمایانگر جریان انتزاعی tokens یا به طور خاص تر ، توالی درختان token.
/// این نوع رابط هایی برای تکرار بیش از آن درختان token فراهم می کند و برعکس ، تعدادی درخت token را در یک جریان جمع می کند.
///
///
/// این هر دو ورودی و خروجی تعاریف `#[proc_macro]` ، `#[proc_macro_attribute]` و `#[proc_macro_derive]` است.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// خطا از `TokenStream::from_str` برگشت.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// `TokenStream` خالی را برمی گرداند که شامل هیچ درخت token نیست.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// خالی بودن این `TokenStream` را بررسی می کند.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// تلاش برای شکستن رشته به tokens و تجزیه آن tokens به یک جریان token.
/// به عنوان مثال ، اگر رشته حاوی جداکننده های نامتعادل یا کاراکترهایی باشد که در زبان وجود ندارند ، به چند دلیل ممکن است از کار بیفتد.
///
/// تمام tokens موجود در جریان تجزیه شده دهانه `Span::call_site()` دارند.
///
/// NOTE: برخی از خطاها ممکن است باعث شود panics به جای بازگرداندن `LexError`.ما حق تغییر این خطاها را به `LexError` بعداً برای خود محفوظ می دانیم.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB ، پل فقط `to_string` را فراهم می کند ، `fmt::Display` را بر اساس آن پیاده سازی کنید (عکس رابطه معمول بین این دو).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// جریان token را به عنوان رشته ای که قرار است بدون ضرر به همان جریان token (دامنه مدول) تبدیل شود ، چاپ می کند ، به استثنای احتمالاً `TokenTree: : Group` با جداکننده های `Delimiter::None` و اصطلاحات عددی منفی.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token را به شکلی مناسب برای رفع اشکال چاپ می کند.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// یک جریان token ایجاد می کند که شامل یک درخت token است.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// تعدادی درخت token را در یک جریان واحد جمع می کند.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// یک عملیات "flattening" در جریان های token ، درختان token را از چندین جریان token به یک جریان واحد جمع می کند.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) استفاده از if/when بهینه سازی شده امکان پذیر است.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// جزئیات اجرای عمومی برای نوع `TokenStream` ، مانند تکرارها.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// تکرار کننده روی TokenTree `TokenStream`.
    /// تکرار "shallow" است ، به عنوان مثال ، تکرارکننده در گروه های جدا شده جمع نمی شود و کل گروه ها را به عنوان درختان token برمی گرداند.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` tokens دلخواه را می پذیرد و در `TokenStream` توصیف ورودی گسترش می یابد.
/// به عنوان مثال ، `quote!(a + b)` عبارتی را تولید می کند که ، هنگام ارزیابی ، `TokenStream` `[Ident("a") ، Punct('+', Alone) ، Ident("b")]`.
///
///
/// unquotation با `$` انجام می شود و با در نظر گرفتن شناسه بعدی به عنوان اصطلاح بدون نقل قول کار می کند.
/// برای نقل قول `$` خود ، از `$$` استفاده کنید.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// منطقه ای از کد منبع ، همراه با اطلاعات توسعه ماکرو.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `Diagnostic` جدیدی را با `message` داده شده در دهانه `self` ایجاد می کند.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// دهانه ای که در سایت تعریف ماکرو برطرف می شود.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// دامنه فراخوانی کلان رویه فعلی.
    /// شناسه های ایجاد شده با این بازه حل می شوند مانند اینکه مستقیماً در محل تماس کلان نوشته شده باشند (بهداشت سایت تماس) و سایر کدهای سایت مکالمه ماکرو قادر به مراجعه به آنها هستند.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// دهانه ای که نمایانگر بهداشت `macro_rules` است و گاهی در سایت تعریف کلان (متغیرهای محلی ، برچسب ها ، `$crate`) و گاهی در سایت تماس های کلان (سایر موارد) برطرف می شود.
    ///
    /// مکان دهانه از سایت تماس گرفته شده است.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// فایل منبع اصلی که این دهانه به آن اشاره می کند.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` برای tokens در توسعه ماکرو قبلی که `self` از آن تولید شده است ، در صورت وجود.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// دهانه کد منبع اصلی که `self` از آن تولید شده است.
    /// اگر این `Span` از سایر توسعه های ماکرو تولید نشده باشد ، مقدار بازگشتی همان `*self` است.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// line/column شروع را در پرونده منبع برای این بازه دریافت می کند.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// line/column را در پرونده منبع برای این بازه دریافت می کند.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// دهانه جدیدی شامل `self` و `other` ایجاد می کند.
    ///
    /// اگر `self` و `other` از پرونده های مختلف باشد `None` را برمی گرداند.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// یک بازه جدید با همان اطلاعات line/column `self` ایجاد می کند اما نمادها را مانند `other` حل می کند.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// دهانه جدیدی با همان رفتار تفکیک نام `self` اما با اطلاعات line/column `other` ایجاد می کند.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// با دهانه ها مقایسه می شود تا ببینید آیا برابر هستند.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// متن مبدا را در پشت یک بازگرداند.
    /// این کد منبع اصلی ، شامل فضاها و نظرات را حفظ می کند.
    /// تنها درصورتی که دامنه با کد منبع واقعی مطابقت داشته باشد نتیجه را برمی گرداند.
    ///
    /// Note: نتیجه قابل مشاهده ماکرو فقط باید به tokens متکی باشد و نه به این متن منبع.
    ///
    /// نتیجه این عملکرد بهترین تلاش برای استفاده فقط برای تشخیص است.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// یک دهانه را به فرم مناسب برای رفع اشکال چاپ می کند.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// یک جفت ستون خط که نمایانگر شروع یا پایان `Span` است.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// خط 1 ایندکس شده در فایل منبع که دهانه (inclusive) روی آن شروع یا پایان می یابد.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ستون 0-نمایه شده (با نویسه های UTF-8) در پرونده مبدا که دامنه (inclusive) روی آن شروع یا پایان می یابد.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// فایل منبع `Span` داده شده.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// مسیر این فایل منبع را می گیرد.
    ///
    /// ### Note
    /// اگر دامنه کد مرتبط با این `SourceFile` توسط یک ماکرو خارجی ، این ماکرو تولید شده باشد ، ممکن است این یک مسیر واقعی در سیستم فایل نباشد.
    /// برای بررسی از [`is_real`] استفاده کنید.
    ///
    /// همچنین توجه داشته باشید که حتی اگر `is_real` `true` را برگرداند ، اگر `--remap-path-prefix` از خط فرمان عبور کرده باشد ، مسیری که داده شده است در واقع معتبر نیست.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// `true` را برمی گرداند اگر این فایل منبع یک منبع منبع واقعی باشد و توسط توسعه ماکرو خارجی ایجاد نشده باشد.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // این یک هک است تا زمانی که دهانه های intercrate اجرا شوند و ما می توانیم فایل های منبع واقعی برای دهانه های تولید شده در ماکروهای خارجی داشته باشیم.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// یک token یا یک توالی محدود از درختان token (به عنوان مثال ، `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// یک جریان token که توسط جداکننده های براکت احاطه شده است.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// شناسه
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// یک علامت نگارشی منفرد ("+" ، `,` ، `$` و غیره)
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// یک شخصیت واقعی (`'a'`) ، رشته (`"hello"`) ، شماره (`2.3`) و غیره
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// دهانه این درخت را برمی گرداند ، و به روش `span` از token موجود یا یک جریان محدود منتقل می کند.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// دهانه را فقط برای این token * پیکربندی می کند.
    ///
    /// توجه داشته باشید که اگر این token یک `Group` باشد ، این روش طول هر یک از tokens داخلی را پیکربندی نمی کند ، این به سادگی به روش `set_span` هر یک از گزینه ها منتقل می شود.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// درخت token را به شکلی مناسب برای رفع اشکال چاپ می کند.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // هر یک از اینها نام اشکال را در اشکالزدایی مشتق شده آورده اند ، بنابراین با یک لایه اضافی عدم تردید خود را اذیت نکنید
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB ، پل فقط `to_string` را فراهم می کند ، `fmt::Display` را بر اساس آن پیاده سازی کنید (عکس رابطه معمول بین این دو).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// درخت token را به صورت رشته ای چاپ می کند که قرار است بدون ضرر به همان درخت token تبدیل شود (دامنه های مدول) ، به استثنای احتمالاً `TokenTree: : Group` با جداکننده های `Delimiter::None` و اصطلاحات عددی منفی.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// یک جریان محدود token.
///
/// `Group` داخلی شامل `TokenStream` است که توسط `Delimiter` احاطه شده است.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// توصیف چگونگی تعیین توالی درختان token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// یک مرز جداکننده ضمنی ، که ممکن است به عنوان مثال ، در اطراف tokens از "macro variable" `$var` ظاهر شود.
    /// حفظ اولویت های اپراتور در مواردی مانند `$var * 3` که `$var` `1 + 2` است مهم است.
    /// جداکننده های ضمنی ممکن است از مسیر یک جریان token از طریق یک رشته زنده نمانند.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// X30X جدیدی را با جریان جداکننده و جریان token ایجاد می کند.
    ///
    /// این سازنده دهانه این گروه را روی `Span::call_site()` قرار می دهد.
    /// برای تغییر دهانه می توانید از روش `set_span` زیر استفاده کنید.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// جداکننده این `Group` را برمی گرداند
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// `TokenStream` از tokens را که در این `Group` محدود شده اند برمی گرداند.
    ///
    /// توجه داشته باشید که جریان برگشتی token شامل مرز جداشده در بالا نیست.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// بازه را برای جداکننده های این جریان token برمی گرداند و کل `Group` را در بر می گیرد.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// بازه را باز می کند و به مرز جدا کننده این گروه بازمی گردد.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// بازه را با اشاره به جداکننده بسته شدن این گروه برمی گرداند.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// بازه برای جداکننده های این `گروه` ، اما tokens داخلی آن پیکربندی نمی شود.
    ///
    /// این روش ** ** دامنه تمام tokens داخلی ساخته شده توسط این گروه را تنظیم نخواهد کرد ، بلکه فقط دامنه جداکننده tokens را در سطح `Group` تنظیم می کند.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB ، پل فقط `to_string` را فراهم می کند ، `fmt::Display` را بر اساس آن پیاده سازی کنید (عکس رابطه معمول بین این دو).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// گروه را به صورت رشته ای چاپ می کند که باید بدون ضرر به همان گروه تبدیل شود (دامنه های مدول) ، به استثنای احتمالاً `TokenTree: : Group` با جداکننده های `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` یک کاراکتر نقطه گذاری منفرد مانند `+` ، `-` یا `#` است.
///
/// عملگرهای چند کاراکتری مانند `+=` به عنوان دو نمونه `Punct` با اشکال مختلف `Spacing` برگردانده شده نشان داده می شوند.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// چه `Punct` بلافاصله توسط `Punct` دیگر دنبال شود یا token یا فضای سفید دیگر دنبال شود.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// به عنوان مثال ، `+` در `+ =` ، `+ident` یا `+()` `Alone` است.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// به عنوان مثال ، `+` در `+=` یا `'#` `Joint` است.
    /// علاوه بر این ، تک نقل `'` می تواند با شناسه ها پیوند داده و طول عمر `'ident` را تشکیل دهد.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// `Punct` جدیدی را از ویژگی و فاصله داده شده ایجاد می کند.
    /// آرگومان `ch` باید یک نویسه نویسی معتبر باشد که توسط زبان مجاز باشد ، در غیر این صورت تابع panic خواهد بود.
    ///
    /// `Punct` برگشتی دارای دامنه پیش فرض `Span::call_site()` است که با روش `set_span` در زیر پیکربندی می شود.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// مقدار این نویسه نگارشی را به عنوان `char` برمی گرداند.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// فاصله این کاراکتر علائم نگارشی را برمی گرداند ، نشان می دهد که آیا بلافاصله `Punct` دیگری در جریان token دنبال می شود ، بنابراین می توان آنها را به طور بالقوه در یک عملگر چند کاراکتری (`Joint`) ترکیب کرد ، یا توسط token یا فضای سفید (`Alone`) دیگر دنبال می شود ، بنابراین اپراتور مطمئناً به پایان رسید.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// دهانه این کاراکتر نقطه گذاری را برمی گرداند.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// برای این کاراکتر علائم نقطه گذاری پیکربندی کنید.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB ، پل فقط `to_string` را فراهم می کند ، `fmt::Display` را بر اساس آن پیاده سازی کنید (عکس رابطه معمول بین این دو).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// شخصیت علائم نگارشی را به عنوان رشته ای چاپ می کند که باید بدون ضرر به همان کاراکتر تبدیل شود.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// شناسه (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// `Ident` جدید را با `string` داده شده و همچنین `span` مشخص ایجاد می کند.
    /// آرگومان `string` باید یک شناسه معتبر باشد که توسط زبان مجاز باشد (شامل کلمات کلیدی ، به عنوان مثال `self` یا `fn`).در غیر این صورت ، عملکرد panic خواهد بود.
    ///
    /// توجه داشته باشید که `span` ، در حال حاضر در rustc ، اطلاعات بهداشتی را برای این شناسه پیکربندی می کند.
    ///
    /// از این زمان ، `Span::call_site()` صریحاً بهداشت "call-site" را انتخاب می کند ، به این معنی که شناسه های ایجاد شده با این بازه حل می شوند ، مثل اینکه مستقیماً در محل تماس ماکرو نوشته شده اند ، و سایر کدهای سایت تماس ماکرو می توانند به آن مراجعه کنند. آنها نیز هست.
    ///
    ///
    /// دهانه های بعدی مانند `Span::def_site()` امکان انتخاب بهداشت "definition-site" را فراهم می کنند ، به این معنی که شناسه های ایجاد شده با این دهانه در محل تعریف ماکرو حل می شوند و سایر کدهای سایت تماس کلان قادر به مراجعه به آنها نیستند.
    ///
    /// با توجه به اهمیت بهداشت فعلی ، این سازنده ، برخلاف سایر tokens ، به `Span` نیاز دارد تا در هنگام ساخت مشخص شود.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// همان `Ident::new` است ، اما یک شناسه خام (`r#ident`) ایجاد می کند.
    /// آرگومان `string` یک شناسه معتبر است که توسط زبان مجاز است (شامل کلمات کلیدی ، به عنوان مثال `fn`).
    /// کلمات کلیدی قابل استفاده در بخشهای مسیر (به عنوان مثال
    /// `self`, `super`) پشتیبانی نمی شوند و باعث panic می شوند.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// دهانه این `Ident` را برمی گرداند و کل رشته بازگشتی توسط [`to_string`](Self::to_string) را در بر می گیرد.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// دهانه این `Ident` را پیکربندی می کند ، احتمالاً زمینه بهداشتی آن را تغییر می دهد.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB ، پل فقط `to_string` را فراهم می کند ، `fmt::Display` را بر اساس آن پیاده سازی کنید (عکس رابطه معمول بین این دو).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// شناسه را به عنوان رشته ای چاپ می کند که باید بدون ضرر به همان شناسه تبدیل شود.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// یک رشته واقعی (`"hello"`) ، رشته بایت (`b"hello"`) ، کاراکتر (`'a'`) ، کاراکتر بایت (`b'a'`) ، یک عدد صحیح یا نقطه شناور با پسوند یا بدون آن ("1" ، `1u8` ، `2.3` ، `2.3f32`).
///
/// اصطلاحات بولی مانند `true` و `false` متعلق به اینجا نیستند ، آنها `Ident` هستند.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// عدد صحیحی با پسوند جدید با مقدار تعیین شده ایجاد می کند.
        ///
        /// این تابع یک عدد صحیح مانند `1u32` ایجاد می کند که در آن مقدار صحیح مشخص شده اولین قسمت token است و انتگرال نیز در انتهای پسوند است.
        /// اصطلاحاتی که از اعداد منفی ایجاد می شوند ممکن است در طی رفت و برگشت از طریق `TokenStream` یا رشته زنده نمانند و به دو tokens (`-` و مثبت تحت اللفظی) تقسیم شوند.
        ///
        ///
        /// کلیدواژه هایی که از طریق این روش ایجاد می شوند به طور پیش فرض دارای دامنه `Span::call_site()` هستند که می توان با روش `set_span` زیر پیکربندی کرد.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// یک عدد صحیح صحیح بدون تصحیح جدید با مقدار مشخص ایجاد می کند.
        ///
        /// این تابع یک عدد صحیح مانند `1` ایجاد می کند که در آن مقدار صحیح مشخص شده قسمت اول token است.
        /// هیچ پسوندی در این token مشخص نشده است ، به این معنی که فراخوانی هایی مانند `Literal::i8_unsuffixed(1)` معادل `Literal::u32_unsuffixed(1)` هستند.
        /// اصطلاحاتی که از اعداد منفی ایجاد می شوند ممکن است از طریق `TokenStream` یا رشته ها زنده بمانند و به دو tokens (`-` و مثبت تحت اللفظی) تقسیم شوند.
        ///
        ///
        /// کلیدواژه هایی که از طریق این روش ایجاد می شوند به طور پیش فرض دارای دامنه `Span::call_site()` هستند که می توان با روش `set_span` زیر پیکربندی کرد.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// یک نقطه شناور غیر مخلوط جدید به معنای واقعی ایجاد می کند.
    ///
    /// این سازنده مشابه نمونه هایی مانند `Literal::i8_unsuffixed` است که مقدار شناور مستقیماً به token ساطع می شود اما از پسوندی استفاده نمی شود ، بنابراین ممکن است بعداً در کامپایلر استنباط شود `f64`.
    ///
    /// اصطلاحاتی که از اعداد منفی ایجاد می شوند ممکن است از طریق `TokenStream` یا رشته ها زنده بمانند و به دو tokens (`-` و مثبت تحت اللفظی) تقسیم شوند.
    ///
    /// # Panics
    ///
    /// این تابع مستلزم محدود بودن شناور مشخص شده است ، به عنوان مثال اگر بی نهایت باشد یا NaN باشد ، این تابع panic خواهد بود.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// یک حرف شناور پسوند جدید ایجاد می کند.
    ///
    /// این سازنده به معنای واقعی کلمه مانند `1.0f32` ایجاد می کند که مقدار مشخص شده قسمت قبلی token و `f32` پسوند token است.
    /// این token همیشه به عنوان `f32` در کامپایلر استنباط می شود.
    /// اصطلاحاتی که از اعداد منفی ایجاد می شوند ممکن است از طریق `TokenStream` یا رشته ها زنده بمانند و به دو tokens (`-` و مثبت تحت اللفظی) تقسیم شوند.
    ///
    ///
    /// # Panics
    ///
    /// این تابع مستلزم محدود بودن شناور مشخص شده است ، به عنوان مثال اگر بی نهایت باشد یا NaN باشد ، این تابع panic خواهد بود.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// یک نقطه شناور غیر مخلوط جدید به معنای واقعی ایجاد می کند.
    ///
    /// این سازنده مشابه نمونه هایی مانند `Literal::i8_unsuffixed` است که مقدار شناور مستقیماً به token ساطع می شود اما از پسوندی استفاده نمی شود ، بنابراین ممکن است بعداً در کامپایلر استنباط شود `f64`.
    ///
    /// اصطلاحاتی که از اعداد منفی ایجاد می شوند ممکن است از طریق `TokenStream` یا رشته ها زنده بمانند و به دو tokens (`-` و مثبت تحت اللفظی) تقسیم شوند.
    ///
    /// # Panics
    ///
    /// این تابع مستلزم محدود بودن شناور مشخص شده است ، به عنوان مثال اگر بی نهایت باشد یا NaN باشد ، این تابع panic خواهد بود.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// یک حرف شناور پسوند جدید ایجاد می کند.
    ///
    /// این سازنده به معنای واقعی کلمه مانند `1.0f64` ایجاد می کند که مقدار مشخص شده قسمت قبلی token و `f64` پسوند token است.
    /// این token همیشه به عنوان `f64` در کامپایلر استنباط می شود.
    /// اصطلاحاتی که از اعداد منفی ایجاد می شوند ممکن است از طریق `TokenStream` یا رشته ها زنده بمانند و به دو tokens (`-` و مثبت تحت اللفظی) تقسیم شوند.
    ///
    ///
    /// # Panics
    ///
    /// این تابع مستلزم محدود بودن شناور مشخص شده است ، به عنوان مثال اگر بی نهایت باشد یا NaN باشد ، این تابع panic خواهد بود.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// رشته به معنای واقعی
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// شخصیت به معنای واقعی
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// رشته بایت به معنای واقعی
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// بازه ای را در بر می گیرد که شامل این حرف واقعی است.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// دهانه مربوط به این حرف واقعی را پیکربندی می کند.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `Span` را بازمی گرداند که زیرمجموعه `self.span()` است و فقط شامل بایت منبع در محدوده `range` است.
    /// اگر دهانه اصلاح شده خارج از محدوده `self` باشد ، `None` را برمی گرداند.
    ///
    // FIXME(SergioBenitez): بررسی کنید دامنه بایت در مرز UTF-8 منبع شروع و خاتمه یابد.
    // در غیر این صورت ، هنگام چاپ متن منبع ، احتمالاً panic در جای دیگری رخ خواهد داد.
    // FIXME(SergioBenitez): هیچ راهی برای کاربر وجود ندارد تا بداند که `self.span()` در واقع از چه رو نقشه برداری می کند ، بنابراین این روش در حال حاضر فقط می تواند کورکورانه خوانده شود.
    // به عنوان مثال ، `to_string()` برای شخصیت 'c' "'\u{63}'" را برمی گرداند.هیچ راهی برای کاربر وجود ندارد که بداند متن منبع 'c' است یا '\u{63}' است.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) چیزی شبیه به `Option::cloned` ، اما برای `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB ، پل فقط `to_string` را فراهم می کند ، `fmt::Display` را بر اساس آن پیاده سازی کنید (عکس رابطه معمول بین این دو).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// کلمه تحت عنوان رشته ای چاپ می شود که باید بدون ضرر به همان حرف واقعی تبدیل شود (به استثنای گرد کردن احتمالی برای حروف الفبا شناور).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// دسترسی به متغیرهای محیط ردیابی شده است.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// یک متغیر محیطی را بازیابی کنید و آن را برای ایجاد اطلاعات وابستگی اضافه کنید.
    /// سیستم ساخت مجری کامپایلر می داند که به متغیر در هنگام کامپایل دسترسی پیدا شده است و در صورت تغییر مقدار آن متغیر ، قادر به ساخت مجدد آن خواهد بود.
    ///
    /// علاوه بر ردیابی وابستگی ، این عملکرد باید معادل `env::var` از کتابخانه استاندارد باشد ، با این تفاوت که استدلال باید UTF-8 باشد.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}