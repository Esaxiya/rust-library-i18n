//! `Cell` نوع برای طول عمر موجود (scoped).

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// برنامه لامبدا را با طول عمر تایپ کنید.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// لامبدا را تایپ کنید تا یک عمر طول بکشد ، `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) با جایگزینی newtype FIXME(#52812) با `&'a mut <T as ApplyL<'b>>::Out` در محدودیت های فرافکنی کار کنید
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// مقدار `self` را به `replacement` تنظیم می کند در حالی که `f` را اجرا می کنید ، که مقدار قدیمی را به طور متناوب دریافت می کند.
    /// مقدار قدیمی پس از خروج `f` ، حتی توسط panic ، از جمله تغییرات ایجاد شده توسط `f` ، بازیابی خواهد شد.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// لفافه ای که اطمینان حاصل می کند سلول همیشه پر می شود (با حالت اصلی ، به صورت اختیاری با `f` تغییر می کند) ، حتی اگر `f` وحشت کرده باشد.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// هنگام اجرای `f` مقدار `self` را به `value` تنظیم می کند.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}