use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Toto nie je stabilný povrch, ale pomáha udržiavať medzi nimi lacný model `?`, aj keď to LLVM momentálne nemôže vždy využiť.
    //
    // (Je smutné, že výsledok a možnosť sú nekonzistentné, takže ControlFlow sa nemôže zhodovať s oboma.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}