use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri je príliš pomalý
fn exact_sanity_test() {
    // Tento test nakoniec beží, čo môžem len predpokladať, je to nejaký rohový prípad funkcie knižnice `exp2`, definovaný v akomkoľvek runtime C, ktorý používame.
    // Vo VS 2013 táto funkcia zjavne mala chybu, pretože tento test zlyhal, keď bol prepojený, ale s VS 2015 sa chyba javí ako opravená, pretože test beží v poriadku.
    //
    // Chyba sa javí ako rozdiel v návratovej hodnote `exp2(-1057)`, kde vo VS 2013 vráti dvojnásobok s bitovým vzorom 0x2 a vo VS 2015 vráti 0x20000.
    //
    //
    // Nateraz tento test úplne ignorujte na MSVC, pretože je aj tak testovaný inde a nemáme veľký záujem testovať implementáciu exp2 na každej platforme.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}