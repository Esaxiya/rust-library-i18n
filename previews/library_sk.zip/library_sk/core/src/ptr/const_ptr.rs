use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Vráti `true`, ak má ukazovateľ hodnotu null.
    ///
    /// Upozorňujeme, že typy bez veľkosti majú veľa možných nulových ukazovateľov, pretože sa berie do úvahy iba ukazovateľ nespracovaných údajov, nie ich dĺžka, vtable atď.
    /// Preto dva ukazovatele, ktoré majú hodnotu null, sa stále nemôžu navzájom porovnávať.
    ///
    /// ## Správanie sa pri konštantnom hodnotení
    ///
    /// Keď sa táto funkcia použije počas vyhodnotenia konštanty, môže vrátiť `false` pre ukazovatele, ktoré sa za behu ukážu ako nulové.
    /// Konkrétne, keď je ukazovateľ na určitú pamäť posunutý za svoje hranice takým spôsobom, že výsledný ukazovateľ je nulový, funkcia stále vráti `false`.
    ///
    /// Neexistuje spôsob, ako by CTFE mohol poznať absolútnu polohu tejto pamäte, takže nemôžeme zistiť, či je ukazovateľ nulový alebo nie.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Porovnajte pomocou obsadenia s tenkým ukazovateľom, takže tuční ukazovatelia zvažujú svoju časť "data" iba kvôli nulovej platnosti.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Prenáša na ukazovateľ iného typu.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Rozložte (možno široký) ukazovateľ na komponenty adresy a metadát.
    ///
    /// Ukazovateľ je možné neskôr zrekonštruovať pomocou [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Vráti `None`, ak má ukazovateľ hodnotu null, alebo vráti zdieľaný odkaz na hodnotu zabalenú v `Some`.Ak môže byť hodnota neinicializovaná, musí sa namiesto nej použiť [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby *buď* ukazovateľ mal hodnotu NULL *alebo* platilo všetko z nasledujúceho:
    ///
    /// * Ukazovateľ musí byť správne zarovnaný.
    ///
    /// * Musí to byť "dereferencable" v zmysle definovanom v [the module documentation].
    ///
    /// * Ukazovateľ musí smerovať na inicializovanú inštanciu `T`.
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, mutovaná (okrem `UnsafeCell`).
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    /// (O časti týkajúcej sa inicializácie ešte nie je úplne rozhodnuté, ale kým nebude, jediný bezpečný prístup je zabezpečiť, aby boli skutočne inicializované.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Verzia bez začiarknutia
    ///
    /// Ak ste si istí, že ukazovateľ nikdy nemôže mať hodnotu null a hľadáte nejaký typ `as_ref_unchecked`, ktorý vráti `&T` namiesto `Option<&T>`, viete, že môžete ukazovateľ priamo odradiť.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // BEZPEČNOSŤ: volajúci musí zaručiť platnosť `self`
        // pre referenciu, ak nie je null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Vráti `None`, ak má ukazovateľ hodnotu null, alebo vráti zdieľaný odkaz na hodnotu zabalenú v `Some`.
    /// Na rozdiel od [`as_ref`] to nevyžaduje inicializáciu hodnoty.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby *buď* ukazovateľ mal hodnotu NULL *alebo* platilo všetko z nasledujúceho:
    ///
    /// * Ukazovateľ musí byť správne zarovnaný.
    ///
    /// * Musí to byť "dereferencable" v zmysle definovanom v [the module documentation].
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, mutovaná (okrem `UnsafeCell`).
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že `self` spĺňa všetky podmienky
        // požiadavky na referenciu.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Vypočíta posunutie od ukazovateľa.
    ///
    /// `count` je v jednotkách T;napr. `count` 3 predstavuje posunutie ukazovateľa `3 * size_of::<T>()` bajtov.
    ///
    /// # Safety
    ///
    /// Ak dôjde k porušeniu niektorej z nasledujúcich podmienok, výsledkom bude nedefinované správanie:
    ///
    /// * Počiatočný aj výsledný ukazovateľ musia byť v hraniciach alebo v jednom bajte za koncom toho istého prideleného objektu.
    /// Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
    ///
    /// * Vypočítaný posun,**v bajtoch**, nemôže pretekať cez `isize`.
    ///
    /// * Posun v medziach sa nemôže spoliehať na adresný priestor "wrapping around".To znamená, že súčet nekonečnej presnosti **v bajtoch** sa musí zmestiť do veľkosti súboru.
    ///
    /// Kompilátor a štandardná knižnica sa všeobecne snažia zabezpečiť, aby pridelenia nikdy nedosiahli veľkosť, kde je problémom posun.
    /// Napríklad `Vec` a `Box` zabezpečujú, že nikdy nepridelia viac ako `isize::MAX` bajtov, takže `vec.as_ptr().add(vec.len())` je vždy bezpečný.
    ///
    /// Väčšina platforiem v zásade nedokáže takéto pridelenie ani skonštruovať.
    /// Napríklad žiadna známa 64-bitová platforma nemôže nikdy vyhovieť požiadavke na 2 <sup>63</sup> bajtov z dôvodu obmedzení tabuľky stránok alebo rozdelenia adresného priestoru.
    /// Niektoré 32-bitové a 16-bitové platformy však môžu úspešne obslúžiť požiadavku na viac ako `isize::MAX` bajtov napríklad v podobe rozšírenia fyzických adries.
    ///
    /// Preto môže byť pamäť získaná priamo od alokátorov alebo súborov mapovaných do pamäte * príliš veľká na to, aby bola pomocou tejto funkcie spracovaná.
    ///
    /// Ak je ťažké splniť tieto obmedzenia, zvážte použitie [`wrapping_offset`].
    /// Jedinou výhodou tejto metódy je, že umožňuje agresívnejšiu optimalizáciu kompilátora.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Vypočíta posunutie od ukazovateľa pomocou aritmetiky zalamovania.
    ///
    /// `count` je v jednotkách T;napr. `count` 3 predstavuje posunutie ukazovateľa `3 * size_of::<T>()` bajtov.
    ///
    /// # Safety
    ///
    /// Samotná táto operácia je vždy bezpečná, ale použitie výsledného ukazovateľa nie.
    ///
    /// Výsledný ukazovateľ zostáva pripojený k rovnakému pridelenému objektu, na ktorý `self` ukazuje.
    /// Možno *sa nemusí* použiť na prístup k inému pridelenému objektu.Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
    ///
    /// Inými slovami, `let z = x.wrapping_offset((y as isize) - (x as isize))`*nerobí*`z` rovnakým ako `y`, aj keď predpokladáme, že `T` má veľkosť `1` a nedochádza k žiadnemu pretečeniu: `z` je stále pripojený k objektu, ku ktorému je pripojený `x`, a s dereferenciou je to Nedefinované správanie, pokiaľ `y` bod do rovnakého prideleného objektu.
    ///
    /// V porovnaní s [`offset`] táto metóda v zásade odďaľuje požiadavku zostať v rovnakom pridelenom objekte: [`offset`] je okamžité nedefinované správanie pri prekračovaní hraníc objektu;`wrapping_offset` produkuje ukazovateľ, ale stále vedie k nedefinovanému správaniu, ak je ukazovateľ dereferencovaný, keď je mimo hranice objektu, ku ktorému je pripojený.
    /// [`offset`] sa dá lepšie optimalizovať a je preto výhodnejší v kóde citlivej na výkon.
    ///
    /// Pri oneskorenej kontrole sa berie do úvahy iba hodnota ukazovateľa, ktorá bola dereferencovaná, nie stredné hodnoty použité počas výpočtu konečného výsledku.
    /// Napríklad `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` je vždy rovnaký ako `x`.Inými slovami, opustenie prideleného objektu a jeho opätovné zadanie neskôr je povolené.
    ///
    /// Ak potrebujete prekročiť hranice objektu, umiestnite ukazovateľ na celé číslo a urobte tam aritmetiku.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // Iterujte pomocou surového ukazovateľa v prírastkoch po dvoch prvkoch
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Táto slučka vytlačí "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: vnútorný `arith_offset` nemá žiadne predpoklady na to, aby sa dal zavolať.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Vypočíta vzdialenosť medzi dvoma ukazovateľmi.Vrátená hodnota je v jednotkách T: vzdialenosť v bajtoch je vydelená `mem::size_of::<T>()`.
    ///
    /// Táto funkcia je inverznou hodnotou k [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Ak dôjde k porušeniu niektorej z nasledujúcich podmienok, výsledkom bude nedefinované správanie:
    ///
    /// * Počiatočný aj druhý ukazovateľ musia byť v hraniciach alebo v jednom bajte za koncom toho istého prideleného objektu.
    /// Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
    ///
    /// * Oba ukazovatele musia byť *odvodené od* ukazovateľa na rovnaký objekt.
    ///   (Príklad nájdete nižšie.)
    ///
    /// * Vzdialenosť medzi ukazovateľmi, v bajtoch, musí byť presným násobkom veľkosti `T`.
    ///
    /// * Vzdialenosť medzi ukazovateľmi **v bajtoch** nemôže prekročiť hodnotu `isize`.
    ///
    /// * Vzdialenosť v medziach sa nemôže spoliehať na adresný priestor "wrapping around".
    ///
    /// Typy Rust nikdy nie sú väčšie ako `isize::MAX` a pridelenia Rust sa nikdy neobtekajú okolo adresného priestoru, takže dva ukazovatele v rámci nejakej hodnoty ľubovoľného typu 1Rust typu `T` vždy splnia posledné dve podmienky.
    ///
    /// Štandardná knižnica tiež všeobecne zaisťuje, že pridelenia nikdy nedosiahnu veľkosť, kde je problémom posun.
    /// Napríklad `Vec` a `Box` zabezpečujú, že nikdy nepridelia viac ako `isize::MAX` bajtov, takže `ptr_into_vec.offset_from(vec.as_ptr())` vždy spĺňa posledné dve podmienky.
    ///
    /// Väčšina platforiem v zásade nedokáže zostaviť ani tak veľkú alokáciu.
    /// Napríklad žiadna známa 64-bitová platforma nemôže nikdy vyhovieť požiadavke na 2 <sup>63</sup> bajtov z dôvodu obmedzení tabuľky stránok alebo rozdelenia adresného priestoru.
    /// Niektoré 32-bitové a 16-bitové platformy však môžu úspešne obslúžiť požiadavku na viac ako `isize::MAX` bajtov napríklad v podobe rozšírenia fyzických adries.
    /// Preto môže byť pamäť získaná priamo od alokátorov alebo súborov mapovaných do pamäte * príliš veľká na to, aby bola pomocou tejto funkcie spracovaná.
    /// (Upozorňujeme, že modely [`offset`] a [`add`] majú tiež podobné obmedzenie, a preto ich nemožno použiť ani pri tak veľkých alokáciách.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Táto funkcia panics, ak je `T` typ ("ZST") s nulovou veľkosťou.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Nesprávne* použitie:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Vytvorte z ptr2_other "alias" z ptr2, ale odvodeného z ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Pretože ptr2_other a ptr2 sú odvodené z ukazovateľov na rôzne objekty, výpočet ich posunu je nedefinované správanie, aj keď smerujú na rovnakú adresu!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Nedefinované správanie
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Vráti, či sú zaručene rovnaké dva ukazovatele.
    ///
    /// Za behu sa táto funkcia správa ako `self == other`.
    /// Avšak v niektorých kontextoch (napr. Vyhodnotenie v čase kompilácie) nie je vždy možné určiť rovnosť dvoch ukazovateľov, takže táto funkcia môže falošne vrátiť `false` pre ukazovatele, ktoré sa neskôr skutočne ukážu ako rovnaké.
    ///
    /// Ale keď vráti `true`, ukazovatele sú zaručene rovnaké.
    ///
    /// Táto funkcia je zrkadlom modelu [`guaranteed_ne`], nie však jeho inverznou verziou.Existujú porovnania ukazovateľov, pre ktoré obidve funkcie vracajú `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Návratová hodnota sa môže meniť v závislosti od verzie kompilátora a nebezpečný kód sa nemusí spoľahnúť na spoľahlivosť výsledku tejto funkcie.
    /// Túto funkciu sa odporúča používať iba na optimalizáciu výkonu, kde falošné návratové hodnoty `false` touto funkciou neovplyvňujú výsledok, ale iba výkon.
    /// Dôsledky použitia tejto metódy na to, aby sa runtime a kompilačný kód správali odlišne, neboli preskúmané.
    /// Táto metóda by sa nemala používať na zavedenie takýchto rozdielov a tiež by sa nemala stabilizovať, kým nebudeme mať lepšie pochopenie tejto problematiky.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Vráti, či sú dva ukazovatele zaručene nerovnaké.
    ///
    /// Za behu sa táto funkcia správa ako `self != other`.
    /// Avšak v niektorých kontextoch (napr. Vyhodnotenie v čase kompilácie) nie je vždy možné určiť nerovnosť dvoch ukazovateľov, takže táto funkcia môže falošne vrátiť `false` pre ukazovatele, ktoré sa neskôr skutočne ukážu ako nerovnaké.
    ///
    /// Ale keď vráti `true`, ukazovatele sú zaručene nerovnaké.
    ///
    /// Táto funkcia je zrkadlom modelu [`guaranteed_eq`], nie však jeho inverznou verziou.Existujú porovnania ukazovateľov, pre ktoré obe funkcie vracajú `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Návratová hodnota sa môže meniť v závislosti od verzie kompilátora a nebezpečný kód sa nemusí spoľahnúť na spoľahlivosť výsledku tejto funkcie.
    /// Túto funkciu sa odporúča používať iba na optimalizáciu výkonu, kde falošné návratové hodnoty `false` touto funkciou neovplyvňujú výsledok, ale iba výkon.
    /// Dôsledky použitia tejto metódy na to, aby sa runtime a kompilačný kód správali odlišne, neboli preskúmané.
    /// Táto metóda by sa nemala používať na zavedenie takýchto rozdielov a tiež by sa nemala stabilizovať, kým nebudeme mať lepšie pochopenie tejto problematiky.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Vypočíta posunutie od ukazovateľa (výhoda pre `.offset(count as isize)`).
    ///
    /// `count` je v jednotkách T;napr. `count` 3 predstavuje posunutie ukazovateľa `3 * size_of::<T>()` bajtov.
    ///
    /// # Safety
    ///
    /// Ak dôjde k porušeniu niektorej z nasledujúcich podmienok, výsledkom bude nedefinované správanie:
    ///
    /// * Počiatočný aj výsledný ukazovateľ musia byť v hraniciach alebo v jednom bajte za koncom toho istého prideleného objektu.
    /// Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
    ///
    /// * Vypočítaný posun,**v bajtoch**, nemôže pretekať cez `isize`.
    ///
    /// * Ofset, ktorý je v medziach, sa nemôže spoliehať na adresný priestor "wrapping around".To znamená, že súčet nekonečnej presnosti sa musí zmestiť do `usize`.
    ///
    /// Kompilátor a štandardná knižnica sa všeobecne snažia zabezpečiť, aby pridelenia nikdy nedosiahli veľkosť, kde je problémom posun.
    /// Napríklad `Vec` a `Box` zabezpečujú, že nikdy nepridelia viac ako `isize::MAX` bajtov, takže `vec.as_ptr().add(vec.len())` je vždy bezpečný.
    ///
    /// Väčšina platforiem v zásade nedokáže takéto pridelenie ani skonštruovať.
    /// Napríklad žiadna známa 64-bitová platforma nemôže nikdy vyhovieť požiadavke na 2 <sup>63</sup> bajtov z dôvodu obmedzení tabuľky stránok alebo rozdelenia adresného priestoru.
    /// Niektoré 32-bitové a 16-bitové platformy však môžu úspešne obslúžiť požiadavku na viac ako `isize::MAX` bajtov napríklad v podobe rozšírenia fyzických adries.
    ///
    /// Preto môže byť pamäť získaná priamo od alokátorov alebo súborov mapovaných do pamäte * príliš veľká na to, aby bola pomocou tejto funkcie spracovaná.
    ///
    /// Ak je ťažké splniť tieto obmedzenia, zvážte použitie [`wrapping_add`].
    /// Jedinou výhodou tejto metódy je, že umožňuje agresívnejšiu optimalizáciu kompilátora.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Vypočíta posunutie z ukazovateľa (výhoda pre `.offset ((počíta sa ako isize).wrapping_neg())`).
    ///
    /// `count` je v jednotkách T;napr. `count` 3 predstavuje posunutie ukazovateľa `3 * size_of::<T>()` bajtov.
    ///
    /// # Safety
    ///
    /// Ak dôjde k porušeniu niektorej z nasledujúcich podmienok, výsledkom bude nedefinované správanie:
    ///
    /// * Počiatočný aj výsledný ukazovateľ musia byť v hraniciach alebo v jednom bajte za koncom toho istého prideleného objektu.
    /// Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
    ///
    /// * Vypočítaný posun nemôže presiahnuť `isize::MAX`**bajtov**.
    ///
    /// * Posun v medziach sa nemôže spoliehať na adresný priestor "wrapping around".To znamená, že súčet nekonečnej presnosti sa musí zmestiť do veľkosti súboru.
    ///
    /// Kompilátor a štandardná knižnica sa všeobecne snažia zabezpečiť, aby pridelenia nikdy nedosiahli veľkosť, kde je problémom posun.
    /// Napríklad `Vec` a `Box` zabezpečujú, že nikdy nepridelia viac ako `isize::MAX` bajtov, takže `vec.as_ptr().add(vec.len()).sub(vec.len())` je vždy bezpečný.
    ///
    /// Väčšina platforiem v zásade nedokáže takéto pridelenie ani skonštruovať.
    /// Napríklad žiadna známa 64-bitová platforma nemôže nikdy vyhovieť požiadavke na 2 <sup>63</sup> bajtov z dôvodu obmedzení tabuľky stránok alebo rozdelenia adresného priestoru.
    /// Niektoré 32-bitové a 16-bitové platformy však môžu úspešne obslúžiť požiadavku na viac ako `isize::MAX` bajtov napríklad v podobe rozšírenia fyzických adries.
    ///
    /// Preto môže byť pamäť získaná priamo od alokátorov alebo súborov mapovaných do pamäte * príliš veľká na to, aby bola pomocou tejto funkcie spracovaná.
    ///
    /// Ak je ťažké splniť tieto obmedzenia, zvážte použitie [`wrapping_sub`].
    /// Jedinou výhodou tejto metódy je, že umožňuje agresívnejšiu optimalizáciu kompilátora.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Vypočíta posunutie od ukazovateľa pomocou aritmetiky zalamovania.
    /// (pohodlie pre `.wrapping_offset(count as isize)`)
    ///
    /// `count` je v jednotkách T;napr. `count` 3 predstavuje posunutie ukazovateľa `3 * size_of::<T>()` bajtov.
    ///
    /// # Safety
    ///
    /// Samotná táto operácia je vždy bezpečná, ale použitie výsledného ukazovateľa nie.
    ///
    /// Výsledný ukazovateľ zostáva pripojený k rovnakému pridelenému objektu, na ktorý `self` ukazuje.
    /// Možno *sa nemusí* použiť na prístup k inému pridelenému objektu.Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
    ///
    /// Inými slovami, `let z = x.wrapping_add((y as usize) - (x as usize))`*nerobí*`z` rovnakým ako `y`, aj keď predpokladáme, že `T` má veľkosť `1` a nedochádza k pretečeniu: `z` je stále pripojený k objektu, ku ktorému je pripojený `x`, a s dereferenciou je to nedefinované správanie, pokiaľ `x` a `y` bod do rovnakého prideleného objektu.
    ///
    /// V porovnaní s [`add`] táto metóda v zásade odďaľuje požiadavku zostať v rovnakom pridelenom objekte: [`add`] je okamžité nedefinované správanie pri prekračovaní hraníc objektu;`wrapping_add` produkuje ukazovateľ, ale stále vedie k nedefinovanému správaniu, ak je ukazovateľ dereferencovaný, keď je mimo hranice objektu, ku ktorému je pripojený.
    /// [`add`] sa dá lepšie optimalizovať a je preto výhodnejší v kóde citlivej na výkon.
    ///
    /// Pri oneskorenej kontrole sa berie do úvahy iba hodnota ukazovateľa, ktorá bola dereferencovaná, nie stredné hodnoty použité počas výpočtu konečného výsledku.
    /// Napríklad `x.wrapping_add(o).wrapping_sub(o)` je vždy rovnaký ako `x`.Inými slovami, opustenie prideleného objektu a jeho opätovné zadanie neskôr je povolené.
    ///
    /// Ak potrebujete prekročiť hranice objektu, umiestnite ukazovateľ na celé číslo a urobte tam aritmetiku.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // Iterujte pomocou surového ukazovateľa v prírastkoch po dvoch prvkoch
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Táto slučka vytlačí "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Vypočíta posunutie od ukazovateľa pomocou aritmetiky zalamovania.
    /// (výhoda pre `.wrapping_offset ((počíta sa ako isize).wrapping_neg())`)
    ///
    /// `count` je v jednotkách T;napr. `count` 3 predstavuje posunutie ukazovateľa `3 * size_of::<T>()` bajtov.
    ///
    /// # Safety
    ///
    /// Samotná táto operácia je vždy bezpečná, ale použitie výsledného ukazovateľa nie.
    ///
    /// Výsledný ukazovateľ zostáva pripojený k rovnakému pridelenému objektu, na ktorý `self` ukazuje.
    /// Možno *sa nemusí* použiť na prístup k inému pridelenému objektu.Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
    ///
    /// Inými slovami, `let z = x.wrapping_sub((x as usize) - (y as usize))`*nerobí*`z` rovnakým ako `y`, aj keď predpokladáme, že `T` má veľkosť `1` a nedochádza k pretečeniu: `z` je stále pripojený k objektu, ku ktorému je pripojený `x`, a s dereferenciou je to nedefinované správanie, pokiaľ `x` a `y` bod do rovnakého prideleného objektu.
    ///
    /// V porovnaní s [`sub`] táto metóda v zásade odďaľuje požiadavku zostať v rovnakom pridelenom objekte: [`sub`] je okamžité nedefinované správanie pri prekračovaní hraníc objektu;`wrapping_sub` produkuje ukazovateľ, ale stále vedie k nedefinovanému správaniu, ak je ukazovateľ dereferencovaný, keď je mimo hranice objektu, ku ktorému je pripojený.
    /// [`sub`] sa dá lepšie optimalizovať a je preto výhodnejší v kóde citlivej na výkon.
    ///
    /// Pri oneskorenej kontrole sa berie do úvahy iba hodnota ukazovateľa, ktorá bola dereferencovaná, nie stredné hodnoty použité počas výpočtu konečného výsledku.
    /// Napríklad `x.wrapping_add(o).wrapping_sub(o)` je vždy rovnaký ako `x`.Inými slovami, opustenie prideleného objektu a jeho opätovné zadanie neskôr je povolené.
    ///
    /// Ak potrebujete prekročiť hranice objektu, umiestnite ukazovateľ na celé číslo a urobte tam aritmetiku.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // Iterujte pomocou surového ukazovateľa v krokoch po dvoch prvkoch (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Táto slučka vytlačí "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Nastaví hodnotu ukazovateľa na `ptr`.
    ///
    /// V prípade, že `self` je ukazovateľ (fat) na typ bez veľkosti, táto operácia ovplyvní iba časť ukazovateľa, zatiaľ čo pre ukazovatele (thin) na veľké typy to má rovnaký efekt ako jednoduché priradenie.
    ///
    /// Výsledný ukazovateľ bude mať pôvod `val`, tj pre tučný ukazovateľ je táto operácia sémanticky rovnaká ako vytváranie nového tučného ukazovateľa s hodnotou údajového ukazovateľa `val`, ale s metadátami `self`.
    ///
    ///
    /// # Examples
    ///
    /// Táto funkcia je primárne užitočná na povolenie aritmetiky bajtového ukazovateľa na potenciálne tučných ukazovateľoch:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // vytlačí "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // BEZPEČNOSŤ: V prípade tenkého ukazovateľa sú tieto operácie identické
        // na jednoduché zadanie.
        // V prípade tučného ukazovateľa je pri súčasnej implementácii rozloženia tučného ukazovateľa prvým poľom takéhoto ukazovateľa vždy údajový ukazovateľ, ktorý je rovnako priradený.
        //
        unsafe { *thin = val };
        self
    }

    /// Načíta hodnotu z `self` bez jej presunutia.
    /// To ponecháva pamäť v `self` nezmenenú.
    ///
    /// Obavy o bezpečnosť a príklady nájdete na [`ptr::read`].
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `read`.
        unsafe { read(self) }
    }

    /// Vykoná volatilné načítanie hodnoty z `self` bez jej pohybu.To ponecháva pamäť v `self` nezmenenú.
    ///
    /// Prchavé operácie majú pôsobiť na pamäť I/O a je zaručené, že ich kompilátor neodelí alebo nezoradí v iných volatilných operáciách.
    ///
    ///
    /// Obavy a príklady bezpečnosti nájdete v časti [`ptr::read_volatile`].
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Načíta hodnotu z `self` bez jej presunutia.
    /// To ponecháva pamäť v `self` nezmenenú.
    ///
    /// Na rozdiel od `read` môže byť ukazovateľ nezarovnaný.
    ///
    /// Obavy o bezpečnosť a príklady nájdete na [`ptr::read_unaligned`].
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopíruje bajty `count * size_of<T>` z `self` do `dest`.
    /// Zdroj a cieľ sa môžu prekrývať.
    ///
    /// NOTE: toto má *rovnaké* poradie argumentov ako [`ptr::copy`].
    ///
    /// Obavy o bezpečnosť a príklady nájdete na [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopíruje bajty `count * size_of<T>` z `self` do `dest`.
    /// Zdroj a cieľ sa nemusia *prekrývať*.
    ///
    /// NOTE: toto má *rovnaké* poradie argumentov ako [`ptr::copy_nonoverlapping`].
    ///
    /// Obavy o bezpečnosť a príklady nájdete na [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Vypočíta posun, ktorý je potrebné použiť na ukazovateľ, aby bol zarovnaný s `align`.
    ///
    /// Ak nie je možné zarovnať ukazovateľ, implementácia vráti `usize::MAX`.
    /// Pre implementáciu je prípustné *vždy* vrátiť `usize::MAX`.
    /// Iba výkon vášho algoritmu môže závisieť od získania použiteľného posunu tu, nie od jeho správnosti.
    ///
    /// Posun je vyjadrený počtom prvkov `T`, a nie bajtov.Vrátenú hodnotu je možné použiť s metódou `wrapping_add`.
    ///
    /// Neexistujú vôbec žiadne záruky, že posunutie ukazovateľa nebude pretekať alebo neprekročí vyhradenie, na ktoré ukazovateľ smeruje.
    ///
    /// Je na volajúcom, aby sa ubezpečil, že vrátený posun je správny vo všetkých pojmoch okrem zarovnania.
    ///
    /// # Panics
    ///
    /// Funkcia panics, ak `align` nie je sila dvoch.
    ///
    /// # Examples
    ///
    /// Prístup k susedným `u8` ako `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // zatiaľ čo ukazovateľ je možné zarovnať pomocou `offset`, smeroval by mimo alokáciu
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // BEZPEČNOSŤ: `align` bol skontrolovaný na výkon 2 vyššie
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Vráti dĺžku surového plátku.
    ///
    /// Vrátenou hodnotou je počet **prvkov**, nie počet bajtov.
    ///
    /// Táto funkcia je bezpečná, aj keď surový rez nie je možné preniesť na referenciu rezu, pretože ukazovateľ je nulový alebo nezaradený.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // BEZPEČNOSŤ: je to bezpečné, pretože modely `*const [T]` a `FatPtr<T>` majú rovnaké rozloženie.
            // Túto záruku môže poskytnúť iba `std`.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Vráti nespracovaný ukazovateľ do vyrovnávacej pamäte rezu.
    ///
    /// Toto je ekvivalent odovzdania `self` do `*const T`, ale bezpečnejšie pre daný typ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Vráti nespracovaný ukazovateľ na prvok alebo čiastkový rez bez kontroly hraníc.
    ///
    /// Volanie tejto metódy s indexom out-of-bounds alebo keď `self` nie je dereferencable je *[nedefinované správanie]*, aj keď sa výsledný ukazovateľ nepoužíva.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // BEZPEČNOSŤ: volajúci zabezpečí, aby bola `self` dereferenkovateľná a `index` v medziach.
        unsafe { index.get_unchecked(self) }
    }

    /// Vráti `None`, ak má ukazovateľ hodnotu null, alebo vráti zdieľaný rez na hodnotu zabalenú do `Some`.
    /// Na rozdiel od [`as_ref`] to nevyžaduje inicializáciu hodnoty.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby *buď* ukazovateľ mal hodnotu NULL *alebo* platilo všetko z nasledujúceho:
    ///
    /// * Ukazovateľ musí byť [valid] pre čítanie pre mnoho bajtov `ptr.len() * mem::size_of::<T>()` a musí byť správne zarovnaný.To znamená najmä:
    ///
    ///     * Celý rozsah pamäte tohto rezu musí byť obsiahnutý v jednom pridelenom objekte!
    ///       Pláty sa nikdy nemôžu rozprestierať na viacerých pridelených objektoch.
    ///
    ///     * Ukazovateľ musí byť zarovnaný aj pri rezoch nulovej dĺžky.
    ///     Jedným z dôvodov je to, že optimalizácia rozloženia enum sa môže spoliehať na to, že referencie (vrátane rezov ľubovoľnej dĺžky) sú zarovnané a nenulové, aby ich odlíšili od ostatných údajov.
    ///
    ///     Ukazovateľ, ktorý je použiteľný ako `data` pre rezy s nulovou dĺžkou, môžete získať pomocou [`NonNull::dangling()`].
    ///
    /// * Celková veľkosť rezu `ptr.len() * mem::size_of::<T>()` nesmie byť väčšia ako `isize::MAX`.
    ///   Prečítajte si bezpečnostnú dokumentáciu k [`pointer::offset`].
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, mutovaná (okrem `UnsafeCell`).
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    ///
    /// Pozri tiež [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Rovnosť ukazovateľov
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Porovnanie ukazovateľov
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}