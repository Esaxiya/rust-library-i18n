use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ale nenulové a kovariančné.
///
/// Toto je často správna vec, ktorú treba použiť pri vytváraní dátových štruktúr pomocou nespracovaných ukazovateľov, ale nakoniec je nebezpečnejšie ju použiť kvôli jej ďalším vlastnostiam.Ak si nie ste istí, či by ste mali používať `NonNull<T>`, stačí použiť `*mut T`!
///
/// Na rozdiel od `*mut T` musí mať ukazovateľ vždy nenulovú hodnotu, aj keď nikdy nie je dereferencovaný.To preto, aby enums mohli používať túto zakázanú hodnotu ako diskrimináciu-`Option<NonNull<T>>` má rovnakú veľkosť ako `* mut T`.
/// Ukazovateľ sa však môže naďalej hojdať, ak nie je odkázaný.
///
/// Na rozdiel od `*mut T` bol `NonNull<T>` vybraný ako kovariančný s `T`.To umožňuje používať `NonNull<T>` pri vytváraní kovariantných typov, ale predstavuje riziko nepríjemnosti, ak sa použije v type, ktorý by vlastne nemal byť kovariantný.
/// (Pre `*mut T` bola urobená opačná voľba, aj keď technicky mohla byť nepríjemnosť spôsobená iba volaním nebezpečných funkcií.)
///
/// Covariance je správna pre väčšinu bezpečných abstrakcií, ako napríklad `Box`, `Rc`, `Arc`, `Vec` a `LinkedList`.Je to tak preto, lebo poskytujú verejné API, ktoré dodržiava bežné zdieľané premenné pravidlá XOR Rust.
///
/// Ak váš typ nemôže byť bezpečne premenný, musíte sa ubezpečiť, že obsahuje nejaké ďalšie pole na zaistenie invariantnosti.Toto pole bude často typu [`PhantomData`], napríklad `PhantomData<Cell<T>>` alebo `PhantomData<&'a mut T>`.
///
/// Všimnite si, že `NonNull<T>` má inštanciu `From` pre `&T`.To však nemení skutočnosť, že mutovanie prostredníctvom (ukazovateľa odvodeného z a) zdieľaného odkazu je nedefinované správanie, pokiaľ sa mutácia nestane vo vnútri [`UnsafeCell<T>`].To isté platí pre vytvorenie premenlivého odkazu zo zdieľaného odkazu.
///
/// Ak používate túto inštanciu `From` bez `UnsafeCell<T>`, je vašou zodpovednosťou zabezpečiť, aby sa nikdy nevolal `as_mut` a aby sa `as_ptr` nikdy nepoužíval na mutáciu.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ukazovatele nie sú `Send`, pretože údaje, na ktoré odkazujú, môžu byť aliasy.
// NB, tento impl je zbytočný, ale mal by poskytovať lepšie chybové správy.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ukazovatele nie sú `Sync`, pretože údaje, na ktoré odkazujú, môžu byť aliasy.
// NB, tento impl je zbytočný, ale mal by poskytovať lepšie chybové správy.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Vytvorí nový `NonNull`, ktorý je síce visiaci, ale dobre zarovnaný.
    ///
    /// To je užitočné pri inicializácii typov, ktoré lenivo alokujú, ako to robí `Vec::new`.
    ///
    /// Hodnota ukazovateľa môže potenciálne predstavovať platný ukazovateľ na `T`, čo znamená, že sa nesmie používať ako sentinelová hodnota "not yet initialized".
    /// Typy, ktoré lenivo alokujú, musia sledovať inicializáciu nejakými inými prostriedkami.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // BEZPEČNOSŤ: mem::align_of() vráti nenulové použitie, ktoré sa potom odleje
        // na * mut T.
        // Preto `ptr` nemá hodnotu null a sú dodržané podmienky pre volanie new_unchecked().
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Vráti zdieľané odkazy na hodnotu.Na rozdiel od [`as_ref`] to nevyžaduje inicializáciu hodnoty.
    ///
    /// Pre meniteľný ekvivalent pozri [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby boli splnené všetky nasledujúce podmienky:
    ///
    /// * Ukazovateľ musí byť správne zarovnaný.
    ///
    /// * Musí to byť "dereferencable" v zmysle definovanom v [the module documentation].
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, mutovaná (okrem `UnsafeCell`).
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že `self` spĺňa všetky podmienky
        // požiadavky na referenciu.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Vráti jedinečné odkazy na hodnotu.Na rozdiel od [`as_mut`] to nevyžaduje inicializáciu hodnoty.
    ///
    /// Zdieľaný náprotivok pozri [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby boli splnené všetky nasledujúce podmienky:
    ///
    /// * Ukazovateľ musí byť správne zarovnaný.
    ///
    /// * Musí to byť "dereferencable" v zmysle definovanom v [the module documentation].
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, prístupná (čítaná ani zapisovaná) prostredníctvom iného ukazovateľa.
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že `self` spĺňa všetky podmienky
        // požiadavky na referenciu.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Vytvorí nový `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` musí byť nenulové.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že hodnota `ptr` nebude null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Vytvorí nový `NonNull`, ak `ptr` nemá hodnotu null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BEZPEČNOSŤ: Ukazovateľ je už skontrolovaný a nemá hodnotu null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Vykonáva rovnakú funkcionalitu ako [`std::ptr::from_raw_parts`], až na to, že sa vráti ukazovateľ `NonNull`, na rozdiel od nespracovaného ukazovateľa `*const`.
    ///
    ///
    /// Ďalšie informácie nájdete v dokumentácii k [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // BEZPEČNOSŤ: Výsledok `ptr::from::raw_parts_mut` je nenulový, pretože `data_address` áno.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Rozložte (možno široký) ukazovateľ na komponenty adresy a metadát.
    ///
    /// Ukazovateľ je možné neskôr zrekonštruovať pomocou [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Získava podkladový ukazovateľ `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Vráti zdieľaný odkaz na hodnotu.Ak môže byť hodnota neinicializovaná, musí sa namiesto nej použiť [`as_uninit_ref`].
    ///
    /// Pre meniteľný ekvivalent pozri [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby boli splnené všetky nasledujúce podmienky:
    ///
    /// * Ukazovateľ musí byť správne zarovnaný.
    ///
    /// * Musí to byť "dereferencable" v zmysle definovanom v [the module documentation].
    ///
    /// * Ukazovateľ musí smerovať na inicializovanú inštanciu `T`.
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, mutovaná (okrem `UnsafeCell`).
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    /// (O časti týkajúcej sa inicializácie ešte nie je úplne rozhodnuté, ale kým nebude, jediný bezpečný prístup je zabezpečiť, aby boli skutočne inicializované.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že `self` spĺňa všetky podmienky
        // požiadavky na referenciu.
        unsafe { &*self.as_ptr() }
    }

    /// Vráti jedinečný odkaz na hodnotu.Ak môže byť hodnota neinicializovaná, musí sa namiesto nej použiť [`as_uninit_mut`].
    ///
    /// Zdieľaný náprotivok pozri [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby boli splnené všetky nasledujúce podmienky:
    ///
    /// * Ukazovateľ musí byť správne zarovnaný.
    ///
    /// * Musí to byť "dereferencable" v zmysle definovanom v [the module documentation].
    ///
    /// * Ukazovateľ musí smerovať na inicializovanú inštanciu `T`.
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, prístupná (čítaná ani zapisovaná) prostredníctvom iného ukazovateľa.
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    /// (O časti týkajúcej sa inicializácie ešte nie je úplne rozhodnuté, ale kým nebude, jediný bezpečný prístup je zabezpečiť, aby boli skutočne inicializované.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že `self` spĺňa všetky podmienky
        // požiadavky na meniteľný odkaz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Prenáša na ukazovateľ iného typu.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // BEZPEČNOSŤ: `self` je ukazovateľ `NonNull`, ktorý nevyhnutne nemá hodnotu null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Vytvorí nenulový surový plátok z tenkého ukazovateľa a dĺžky.
    ///
    /// Argument `len` predstavuje počet **prvkov**, nie počet bajtov.
    ///
    /// Táto funkcia je bezpečná, ale dereferencovanie návratovej hodnoty je nebezpečné.
    /// Požiadavky na bezpečnosť rezov nájdete v dokumentácii k [`slice::from_raw_parts`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // pri prvom použití ukazovateľa na prvý prvok vytvorte ukazovateľ rezu
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Upozorňujeme, že tento príklad umelo demonštruje použitie tejto metódy, ale `nechajte slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // BEZPEČNOSŤ: `data` je ukazovateľ `NonNull`, ktorý nevyhnutne nemá hodnotu null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Vráti dĺžku surového rezu, ktorý nemá nulovú hodnotu.
    ///
    /// Vrátenou hodnotou je počet **prvkov**, nie počet bajtov.
    ///
    /// Táto funkcia je bezpečná, aj keď nenulový surový rez nie je možné dereferencovať na rez, pretože ukazovateľ nemá platnú adresu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Vráti nenulový ukazovateľ do vyrovnávacej pamäte rezu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // BEZPEČNOSŤ: Vieme, že `self` nemá hodnotu null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Vráti nespracovaný ukazovateľ do vyrovnávacej pamäte rezu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Vráti zdieľaný odkaz na výrez z pravdepodobne neinicializovaných hodnôt.Na rozdiel od [`as_ref`] to nevyžaduje inicializáciu hodnoty.
    ///
    /// Pre meniteľný ekvivalent pozri [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby boli splnené všetky nasledujúce podmienky:
    ///
    /// * Ukazovateľ musí byť [valid] pre čítanie pre mnoho bajtov `ptr.len() * mem::size_of::<T>()` a musí byť správne zarovnaný.To znamená najmä:
    ///
    ///     * Celý rozsah pamäte tohto rezu musí byť obsiahnutý v jednom pridelenom objekte!
    ///       Pláty sa nikdy nemôžu rozprestierať na viacerých pridelených objektoch.
    ///
    ///     * Ukazovateľ musí byť zarovnaný aj pri rezoch nulovej dĺžky.
    ///     Jedným z dôvodov je to, že optimalizácia rozloženia enum sa môže spoliehať na to, že referencie (vrátane rezov ľubovoľnej dĺžky) sú zarovnané a nenulové, aby ich odlíšili od ostatných údajov.
    ///
    ///     Ukazovateľ, ktorý je použiteľný ako `data` pre rezy s nulovou dĺžkou, môžete získať pomocou [`NonNull::dangling()`].
    ///
    /// * Celková veľkosť rezu `ptr.len() * mem::size_of::<T>()` nesmie byť väčšia ako `isize::MAX`.
    ///   Prečítajte si bezpečnostnú dokumentáciu k [`pointer::offset`].
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, mutovaná (okrem `UnsafeCell`).
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    ///
    /// Pozri tiež [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Vráti jedinečný odkaz na výrez z pravdepodobne neinicializovaných hodnôt.Na rozdiel od [`as_mut`] to nevyžaduje inicializáciu hodnoty.
    ///
    /// Zdieľaný náprotivok pozri [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Pri volaní tejto metódy musíte zabezpečiť, aby boli splnené všetky nasledujúce podmienky:
    ///
    /// * Ukazovateľ musí byť [valid] pre čítanie a zápis pre `ptr.len() * mem::size_of::<T>()` veľa bajtov a musí byť správne zarovnaný.To znamená najmä:
    ///
    ///     * Celý rozsah pamäte tohto rezu musí byť obsiahnutý v jednom pridelenom objekte!
    ///       Pláty sa nikdy nemôžu rozprestierať na viacerých pridelených objektoch.
    ///
    ///     * Ukazovateľ musí byť zarovnaný aj pri rezoch nulovej dĺžky.
    ///     Jedným z dôvodov je to, že optimalizácia rozloženia enum sa môže spoliehať na to, že referencie (vrátane rezov ľubovoľnej dĺžky) sú zarovnané a nenulové, aby ich odlíšili od ostatných údajov.
    ///
    ///     Ukazovateľ, ktorý je použiteľný ako `data` pre rezy s nulovou dĺžkou, môžete získať pomocou [`NonNull::dangling()`].
    ///
    /// * Celková veľkosť rezu `ptr.len() * mem::size_of::<T>()` nesmie byť väčšia ako `isize::MAX`.
    ///   Prečítajte si bezpečnostnú dokumentáciu k [`pointer::offset`].
    ///
    /// * Musíte dodržať pravidlá aliasu Rust, pretože vrátená životnosť `'a` je zvolená ľubovoľne a nemusí nevyhnutne odrážať skutočnú životnosť údajov.
    ///   Najmä po dobu tejto životnosti nesmie byť pamäť, na ktorú ukazovateľ smeruje, prístupná (čítaná ani zapisovaná) prostredníctvom iného ukazovateľa.
    ///
    /// To platí, aj keď je výsledok tejto metódy nepoužitý!
    ///
    /// Pozri tiež [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // To je bezpečné, pretože `memory` je platný pre čítanie a zápis pre `memory.len()` mnohých bajtov.
    /// // Upozorňujeme, že volanie `memory.as_mut()` tu nie je povolené, pretože obsah môže byť neinicializovaný.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Vráti nespracovaný ukazovateľ na prvok alebo čiastkový rez bez kontroly hraníc.
    ///
    /// Volanie tejto metódy s indexom out-of-bounds alebo keď `self` nie je dereferencable je *[nedefinované správanie]*, aj keď sa výsledný ukazovateľ nepoužíva.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // BEZPEČNOSŤ: volajúci zabezpečí, aby bola `self` dereferenkovateľná a `index` v medziach.
        // V dôsledku toho výsledný ukazovateľ nemôže mať hodnotu NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // BEZPEČNOSŤ: Unikátny ukazovateľ nemôže mať hodnotu null, takže podmienky pre
        // new_unchecked() sú rešpektované.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BEZPEČNOSŤ: Meniteľný odkaz nemôže mať hodnotu null.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // BEZPEČNOSŤ: Odkaz nemôže mať nulovú hodnotu, takže podmienky pre
        // new_unchecked() sú rešpektované.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}