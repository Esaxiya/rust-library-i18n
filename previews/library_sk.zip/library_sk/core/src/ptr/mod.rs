//! Ručne spravujte pamäť pomocou nespracovaných ukazovateľov.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mnoho funkcií v tomto module berie surové ukazovatele ako argumenty a číta ich alebo do nich zapisuje.Z bezpečnostných dôvodov musia byť tieto ukazovatele *platné*.
//! To, či je ukazovateľ platný, závisí od operácie, na ktorú sa používa (na čítanie alebo na zápis), a od rozsahu prístupnej pamäte (tj. Koľko bajtov je read/written).
//! Väčšina funkcií používa `*mut T` a `* const T` na prístup iba k jednej hodnote, v takom prípade dokumentácia vynechá veľkosť a implicitne predpokladá, že ide o `size_of::<T>()` bajtov.
//!
//! Presné pravidlá platnosti zatiaľ nie sú stanovené.Záruky poskytované v tomto okamihu sú veľmi minimálne:
//!
//! * Ukazovateľ [null] je *nikdy* neplatný, a to ani pri prístupoch k [size zero][zst].
//! * Aby bol ukazovateľ platný, je potrebné, ale nie vždy postačujúce, aby bol ukazovateľ *dereferenceable*: rozsah pamäte danej veľkosti začínajúci na ukazovateli musí byť v medziach jedného prideleného objektu.
//!
//! Všimnite si, že v Rust je každá premenná (stack-allocated) považovaná za samostatný pridelený objekt.
//! * Dokonca aj pri operáciách [size zero][zst] nesmie ukazovateľ smerovať na uvoľnenú pamäť, tj. Pri pridelení sú ukazovatele neplatné aj pri operáciách s nulovou veľkosťou.
//! Avšak odovzdanie ľubovoľného nenulového celého čísla *literálu* do ukazovateľa je platné pre prístupy s nulovou veľkosťou, aj keď na tejto adrese náhodou existuje nejaká pamäť a dôjde k jej zrušeniu.
//! To zodpovedá napísaniu vlastného alokátora: alokácia objektov nulovej veľkosti nie je veľmi náročná.
//! Kanonickým spôsobom, ako získať ukazovateľ, ktorý je platný pre prístupy nulovej veľkosti, je [`NonNull::dangling`].
//! * Všetky prístupy vykonávané funkciami v tomto module sú *neatomové* v zmysle [atomic operations] používaného na synchronizáciu medzi vláknami.
//! To znamená, že je nedefinované správanie vykonávať dva súbežné prístupy k rovnakému umiestneniu z rôznych vlákien, pokiaľ oba prístupy nečítajú iba z pamäte.
//! Všimnite si, že to výslovne zahŕňa [`read_volatile`] a [`write_volatile`]: Prchavé prístupy nie je možné použiť na synchronizáciu medzi vláknami.
//! * Výsledok vrhania odkazu na ukazovateľ je platný dovtedy, kým je podkladový objekt aktívny a na prístup do tej istej pamäte sa nepoužíva žiadny odkaz (iba nespracované ukazovatele).
//!
//! Tieto axiómy spolu s opatrným používaním [`offset`] na aritmetiku ukazovateľa stačia na správnu implementáciu mnohých užitočných vecí v nebezpečnom kóde.
//! Až sa budú určovať pravidlá pre [aliasing], nakoniec poskytneme prísnejšie záruky.
//! Ďalšie informácie nájdete v dokumente [book], ako aj v časti venovanej odkazu na [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Platné nespracované ukazovatele definované vyššie nie sú nevyhnutne správne zarovnané (kde je zarovnanie "proper" definované typom pointee, tj. `*const T` musí byť zarovnané s `mem::align_of::<T>()`).
//! Väčšina funkcií však vyžaduje správne zarovnanie svojich argumentov a túto požiadavku výslovne uvedie vo svojej dokumentácii.
//! Pozoruhodné výnimky sú [`read_unaligned`] a [`write_unaligned`].
//!
//! Ak funkcia vyžaduje správne zarovnanie, urobí to, aj keď má prístup veľkosť 0, tj. Aj keď sa v skutočnosti nedotkne pamäte.V takýchto prípadoch zvážte použitie [`NonNull::dangling`].
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Spustí deštruktor (ak existuje) poukázanej hodnoty.
///
/// Toto je sémanticky ekvivalentné volaniu [`ptr::read`] a zahodeniu výsledku, ale má nasledujúce výhody:
///
/// * *Je povinné* používať `drop_in_place` na vypúšťanie neveľkých typov, ako sú objekty trait, pretože ich nemožno načítať do zásobníka a normálne ich vypustiť.
///
/// * Optimalizátor je priateľskejší robiť to cez [`ptr::read`] pri vypadávaní ručne alokovanej pamäte (napr. Pri implementáciách `Box`/`Rc`/`Vec`), pretože kompilátor nemusí dokazovať, že je zdravé vyhnúť sa kópii.
///
///
/// * Môže sa použiť na vypustenie údajov [pinned], keď `T` nie je `repr(packed)` (pripnuté údaje sa pred presunutím nesmú presúvať).
///
/// Nezaradené hodnoty nemožno umiestniť na miesto, musia sa najskôr skopírovať na zarovnané miesto pomocou [`ptr::read_unaligned`].V prípade zabalených štruktúr sa tento pohyb vykonáva automaticky kompilátorom.
/// To znamená, že polia zabalených štruktúr nie sú umiestnené na mieste.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `to_drop` musí byť [valid] pre čítanie aj zápis.
///
/// * `to_drop` musia byť správne zarovnané.
///
/// * Hodnota `to_drop` bodov, ktorá musí byť platná pre vynechanie, čo môže znamenať, že musí udržiavať ďalšie invarianty, čo je závislé od typu.
///
/// Okrem toho, ak `T` nie je [`Copy`], použitie špicatej hodnoty po volaní `drop_in_place` môže spôsobiť nedefinované správanie.Upozorňujeme, že `*to_drop = foo` sa počíta ako použitie, pretože to spôsobí, že hodnota bude opäť klesať.
/// [`write()`] možno použiť na prepísanie údajov bez toho, aby došlo k ich zahodeniu.
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL a musí byť správne zarovnaný.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ručné odstránenie poslednej položky zo vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Získajte hrubý ukazovateľ na posledný prvok v `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Skráťte `v`, aby ste zabránili spadnutiu poslednej položky.
///     // Najprv to urobíme, aby sme zabránili problémom, ak je `drop_in_place` pod panics.
///     v.set_len(1);
///     // Bez volania `drop_in_place` by posledná položka nikdy neodpadla a unikla by pamäť, ktorú spravuje.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Zaistite, aby posledná položka vypadla.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Všimnite si, že kompilátor vykoná túto kópiu automaticky pri zhadzovaní zabalených štruktúr, tj. Pokiaľ sa neozvete `drop_in_place` manuálne, zvyčajne sa s týmito problémami nemusíte obávať.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Na tomto kóde nezáleží, toto je nahradené skutočným kvapkovým lepidlom kompilátora.
    //

    // BEZPEČNOSŤ: pozri komentár vyššie
    unsafe { drop_in_place(to_drop) }
}

/// Vytvorí nulový surový ukazovateľ.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Vytvorí nulový premenlivý surový ukazovateľ.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Aby sa zabránilo viazaniu na `T: Clone`, je potrebný manuálny impl.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Aby sa zabránilo viazaniu na `T: Copy`, je potrebný manuálny impl.
impl<T> Copy for FatPtr<T> {}

/// Vytvorí surový plátok z ukazovateľa a dĺžky.
///
/// Argument `len` predstavuje počet **prvkov**, nie počet bajtov.
///
/// Táto funkcia je bezpečná, ale použitie návratovej hodnoty je v skutočnosti nebezpečné.
/// Požiadavky na bezpečnosť rezov nájdete v dokumentácii k [`slice::from_raw_parts`].
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // pri prvom použití ukazovateľa na prvý prvok vytvorte ukazovateľ rezu
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // BEZPEČNOSŤ: Prístup k hodnote z únie `Repr` je bezpečný od * const [T]
        //
        // a FatPtr majú rovnaké rozloženia pamäte.Túto záruku môže poskytnúť iba std.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Vykonáva rovnakú funkcionalitu ako [`slice_from_raw_parts`], až na to, že sa vráti nespracovaný premenlivý rez, na rozdiel od nespracovaného nezmeniteľného rezu.
///
///
/// Ďalšie informácie nájdete v dokumentácii k [`slice_from_raw_parts`].
///
/// Táto funkcia je bezpečná, ale použitie návratovej hodnoty je v skutočnosti nebezpečné.
/// Požiadavky na bezpečnosť rezov nájdete v dokumentácii k [`slice::from_raw_parts_mut`].
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // priraďte hodnotu indexu v reze
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // BEZPEČNOSŤ: Prístup k hodnote z únie `Repr` je bezpečný, pretože * mut [T]
        // a FatPtr majú rovnaké rozloženia pamäte
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Zamení hodnoty na dvoch premenlivých miestach rovnakého typu bez deinicializácie.
///
/// Ale pre nasledujúce dve výnimky je táto funkcia sémanticky ekvivalentná s [`mem::swap`]:
///
///
/// * Funguje na surových ukazovateľoch namiesto odkazov.
/// Ak sú k dispozícii referencie, malo by sa uprednostniť [`mem::swap`].
///
/// * Dve ukazované hodnoty sa môžu prekrývať.
/// Ak sa hodnoty prekrývajú, použije sa prekrývajúca sa oblasť pamäte z `x`.
/// To je demonštrované v druhom príklade nižšie.
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `x` aj `y` musia byť [valid] pre čítanie aj zápis.
///
/// * `x` aj `y` musia byť správne zarovnané.
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovatele musia mať inú hodnotu ako NULL a musia byť správne zarovnané.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Zamieňame dva neprekrývajúce sa regióny:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // toto je `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // toto je `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Zamieňame dva prekrývajúce sa regióny:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // toto je `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // toto je `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indexy `1..3` rezu sa prekrývajú medzi `x` a `y`.
///     // Primerané výsledky by boli pre nich `[2, 3]`, takže indexy `0..3` sú `[1, 2, 3]` (zodpovedajúce `y` pred `swap`);alebo aby boli `[0, 1]`, takže indexy `1..4` sú `[0, 1, 2]` (zodpovedajú `x` pred `swap`).
/////
///     // Táto implementácia je definovaná tak, aby sa mohla zvoliť druhá možnosť.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dajte si trochu stieracieho priestoru na prácu.
    // S kvapkami sa nemusíme báť: `MaybeUninit` pri páde nerobí nič.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Vykonajte výmenu BEZPEČNOSŤ: volajúci musí zaručiť, že `x` a `y` sú platné pre zápis a správne zarovnané.
    // `tmp` sa nemôže prekrývať ani `x`, ani `y`, pretože `tmp` bol práve alokovaný v zásobníku ako samostatný pridelený objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` a `y` sa môžu prekrývať
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Zamení bajty `count * size_of::<T>()` medzi dvoma oblasťami pamäte počnúc `x` a `y`.
/// Tieto dva regióny sa nesmú prekrývať.
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `x` aj `y` musia byť [valid] pre čítanie aj zápis počtu *
///   veľkosť: :<T>() " bajtov.
///
/// * `x` aj `y` musia byť správne zarovnané.
///
/// * Oblasť pamäte začínajúca na `x` s veľkosťou `count *
///   veľkosť: :<T>() `bajty sa nesmú *nesmie* prekrývať s oblasťou pamäte začínajúcou na `y` s rovnakou veľkosťou.
///
/// Upozorňujeme, že aj keď je efektívne skopírovaná veľkosť (`count * size_of: :<T>()`) je `0`, ukazovatele musia mať inú hodnotu ako NULL a musia byť správne zarovnané.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // BEZPEČNOSŤ: volajúci musí zaručiť, že `x` a `y` sú
    // platné pre zápisy a správne zarovnané.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // U typov menších ako je optimalizácia bloku uvedená nižšie, stačí priamo zameniť, aby ste sa vyhli pesimizácii kódového kódu.
    //
    if mem::size_of::<T>() < 32 {
        // BEZPEČNOSŤ: volajúci musí zaručiť platnosť `x` a `y`
        // pre zápisy, správne zarovnané a neprekrývajúce sa.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Prístup je v tomto prípade využiť simd na efektívnu výmenu x&y.
    // Testovanie odhalilo, že zámena buď 32 bajtov alebo 64 bajtov naraz je pre procesory Intel Haswell E najefektívnejšia.
    // LLVM je schopnejšia optimalizovať, ak dáme štruktúre #[repr(simd)], aj keď túto štruktúru v skutočnosti priamo nepoužívame.
    //
    //
    // FIXME repr(simd) nefunkčný na emscripten a redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Smyčka cez x a y, ich kopírovanie `Block` súčasne Optimalizátor by mal úplne rozvinúť slučku pre väčšinu typov NB
    // Nemôžeme použiť cyklus for, pretože `range` impl volá rekurzívne `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // Vytvorte neinicializovanú pamäť ako stierací priestor. Deklarovaním `t` sa tu zabráni zarovnaniu zásobníka, keď sa táto slučka nepoužíva
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // BEZPEČNOSŤ: Ako `i < len` a ako volajúci musí zaručiť platnosť `x` a `y`
        // pre bajty `len` musia byť `x + i` a `y + i` platné adresy, ktoré spĺňajú bezpečnostnú zmluvu pre `add`.
        //
        // Volajúci musí tiež zaručiť, že `x` a `y` sú platné pre zápisy, správne zarovnané a neprekrývajúce sa, čo zodpovedá bezpečnostnej zmluve pre `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Zamieňajte blok bajtov x&y pomocou t ako dočasnej vyrovnávacej pamäte. Toto by sa malo optimalizovať na efektívne operácie SIMD, ak sú k dispozícii
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Vymeňte všetky zostávajúce bajty
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // BEZPEČNOSŤ: pozri predchádzajúci bezpečnostný komentár.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Presunie `src` do špicatého `dst` a vráti predchádzajúcu hodnotu `dst`.
///
/// Ani jedna z hodnôt neklesne.
///
/// Táto funkcia je sémanticky ekvivalentná s [`mem::replace`], až na to, že pracuje s nespracovanými ukazovateľmi namiesto referencií.
/// Ak sú k dispozícii referencie, malo by sa uprednostniť [`mem::replace`].
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `dst` musí byť [valid] pre čítanie aj zápis.
///
/// * `dst` musia byť správne zarovnané.
///
/// * `dst` musí ukazovať na správne inicializovanú hodnotu typu `T`.
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL a musí byť správne zarovnaný.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` by malo rovnaký účinok bez vyžadovania nebezpečného bloku.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // BEZPEČNOSŤ: volajúci musí zaručiť, že `dst` je platný
    // cast na premenlivý odkaz (platný pre zápisy, zarovnaný, inicializovaný) a nemôže prekrývať `src`, pretože `dst` musí ukazovať na zreteľný pridelený objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // nemôže sa prekrývať
    }
    src
}

/// Načíta hodnotu z `src` bez jej presunutia.To ponecháva pamäť v `src` nezmenenú.
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `src` pre čítanie musí byť [valid].
///
/// * `src` musia byť správne zarovnané.Ak to tak nie je, použite [`read_unaligned`].
///
/// * `src` musí ukazovať na správne inicializovanú hodnotu typu `T`.
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL a musí byť správne zarovnaný.
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ručne implementujte [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Vytvorte bitovú kópiu hodnoty na `a` v `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukončenie v tomto okamihu (buď explicitným vrátením, alebo zavolaním funkcie, ktorá panics) spôsobí, že hodnota v `tmp` bude spadnutá, zatiaľ čo rovnaká hodnota bude stále odkazovaná `a`.
///         // To by mohlo spustiť nedefinované správanie, ak `T` nie je `Copy`.
/////
/////
///
///         // Vytvorte bitovú kópiu hodnoty na `b` v `a`.
///         // Je to bezpečné, pretože premenlivé odkazy nemožno aliasovať.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ako je uvedené vyššie, ukončenie tu by mohlo spustiť nedefinované správanie, pretože `a` a `b` odkazujú na rovnakú hodnotu.
/////
///
///         // Presuňte `tmp` do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` bol presunutý (`write` preberá vlastníctvo svojho druhého argumentu), takže tu nič implicitne neprepadne.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Vlastníctvo vrátenej hodnoty
///
/// `read` vytvorí bitovú kópiu `T` bez ohľadu na to, či `T` je [`Copy`].
/// Ak `T` nie je [`Copy`], použitie vrátenej hodnoty aj hodnoty na `*src` môže narušiť bezpečnosť pamäte.
/// Upozorňujeme, že priradenie k `*src` sa počíta ako použitie, pretože sa pokúsi hodnotu znížiť na `* src`.
///
/// [`write()`] možno použiť na prepísanie údajov bez toho, aby došlo k ich zahodeniu.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` teraz ukazuje na rovnakú základnú pamäť ako `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Priradenie k `s2` spôsobí pokles jeho pôvodnej hodnoty.
///     // Po tomto bode už nebude potrebné používať `s`, pretože sa uvoľnila podkladová pamäť.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Priradenie k `s` by spôsobilo opätovné zníženie starej hodnoty, čo by malo za následok nedefinované správanie.
/////
///     // s= String::from("bar");//CHYBA
///
///     // `ptr::write` možno použiť na prepísanie hodnoty bez jej vypustenia.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BEZPEČNOSŤ: volajúci musí zaručiť, že `src` je platný pre čítanie.
    // `src` nemôže prekrývať `tmp`, pretože `tmp` bol práve alokovaný v zásobníku ako samostatný pridelený objekt.
    //
    //
    // Pretože sme práve napísali platnú hodnotu do `tmp`, je zaručené, že bude správne inicializovaná.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Načíta hodnotu z `src` bez jej presunutia.To ponecháva pamäť v `src` nezmenenú.
///
/// Na rozdiel od [`read`] pracuje `read_unaligned` s nezaradenými ukazovateľmi.
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `src` pre čítanie musí byť [valid].
///
/// * `src` musí ukazovať na správne inicializovanú hodnotu typu `T`.
///
/// Rovnako ako [`read`], aj `read_unaligned` vytvára bitovú kópiu `T` bez ohľadu na to, či `T` je [`Copy`].
/// Ak `T` nie je [`Copy`], použitie vrátenej hodnoty aj hodnoty na `*src` môže [violate memory safety][read-ownership].
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Na štruktúrach `packed`
///
/// V súčasnosti je nemožné vytvoriť nespracované ukazovatele na nezaradené polia zabalenej štruktúry.
///
/// Pri pokuse o vytvorenie nespracovaného ukazovateľa na pole štruktúry `unaligned` s výrazom, ako je napríklad `&packed.unaligned as *const FieldType`, sa vytvorí sprostredkovaný nezaradený odkaz pred konverziou na nespracovaný ukazovateľ.
///
/// To, že tento odkaz je dočasný a okamžite je obsadený, je bezvýznamné, pretože kompilátor vždy očakáva, že odkazy budú správne zarovnané.
/// Výsledkom je, že použitie `&packed.unaligned as *const FieldType` spôsobí okamžité* nedefinované správanie * vo vašom programe.
///
/// Príklad toho, čo nerobiť a ako to súvisí s `read_unaligned`, je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Tu sa pokúsime prevziať adresu 32-bitového celého čísla, ktoré nie je zarovnané.
///     let unaligned =
///         // Tu sa vytvorí dočasná nezaradená referencia, ktorej výsledkom je nedefinované správanie bez ohľadu na to, či sa referencia použije alebo nie.
/////
///         &packed.unaligned
///         // Prenášanie na surový ukazovateľ nepomáha;chyba sa už stala.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Prístup k nezarovnaným poliam priamo napr. S `packed.unaligned` je však bezpečný.
///
///
///
///
///
///
// FIXME: Aktualizujte dokumenty na základe výsledku RFC #2582 a priateľov.
/// # Examples
///
/// Načítať hodnotu použitia z bajtového bufferu:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // BEZPEČNOSŤ: volajúci musí zaručiť, že `src` je platný pre čítanie.
    // `src` nemôže prekrývať `tmp`, pretože `tmp` bol práve alokovaný v zásobníku ako samostatný pridelený objekt.
    //
    //
    // Pretože sme práve napísali platnú hodnotu do `tmp`, je zaručené, že bude správne inicializovaná.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Prepíše pamäťové miesto zadanou hodnotou bez načítania alebo zrušenia starej hodnoty.
///
/// `write` nevypustí obsah `dst`.
/// Je to bezpečné, ale mohlo by dôjsť k úniku pridelených prostriedkov alebo zdrojov, preto by ste mali venovať pozornosť tomu, aby ste neprepísali objekt, ktorý by mal byť zrušený.
///
///
/// Okrem toho neklesá `src`.Sémanticky sa `src` presunie na miesto, na ktoré ukazuje `dst`.
///
/// Toto je vhodné na inicializáciu neinicializovanej pamäte alebo na prepisovanie pamäte, z ktorej bol predtým [`read`].
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `dst` pre zápis musí byť [valid].
///
/// * `dst` musia byť správne zarovnané.Ak to tak nie je, použite [`write_unaligned`].
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL a musí byť správne zarovnaný.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ručne implementujte [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Vytvorte bitovú kópiu hodnoty na `a` v `tmp`.
///         let tmp = ptr::read(a);
///
///         // Ukončenie v tomto okamihu (buď explicitným vrátením, alebo zavolaním funkcie, ktorá panics) spôsobí, že hodnota v `tmp` bude spadnutá, zatiaľ čo rovnaká hodnota bude stále odkazovaná `a`.
///         // To by mohlo spustiť nedefinované správanie, ak `T` nie je `Copy`.
/////
/////
///
///         // Vytvorte bitovú kópiu hodnoty na `b` v `a`.
///         // Je to bezpečné, pretože premenlivé odkazy nemožno aliasovať.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Ako je uvedené vyššie, ukončenie tu by mohlo spustiť nedefinované správanie, pretože `a` a `b` odkazujú na rovnakú hodnotu.
/////
///
///         // Presuňte `tmp` do `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` bol presunutý (`write` preberá vlastníctvo svojho druhého argumentu), takže tu nič implicitne neprepadne.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Voláme vnútorné, aby sme sa vyhli volaniu funkcií v generovanom kóde, pretože `intrinsics::copy_nonoverlapping` je súhrnná funkcia.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // BEZPEČNOSŤ: volajúci musí zaručiť, že `dst` je platný pre zápisy.
    // `dst` nemôže prekrývať `src`, pretože volajúci má premenlivý prístup k `dst`, zatiaľ čo `src` vlastní táto funkcia.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Prepíše pamäťové miesto zadanou hodnotou bez načítania alebo zrušenia starej hodnoty.
///
/// Na rozdiel od [`write()`] môže byť ukazovateľ nezarovnaný.
///
/// `write_unaligned` nevypustí obsah `dst`.Je to bezpečné, ale mohlo by dôjsť k úniku pridelených prostriedkov alebo zdrojov, preto by ste mali venovať pozornosť tomu, aby ste neprepísali objekt, ktorý by mal byť zrušený.
///
/// Okrem toho neklesá `src`.Sémanticky sa `src` presunie na miesto, na ktoré ukazuje `dst`.
///
/// Toto je vhodné na inicializáciu neinicializovanej pamäte alebo na prepisovanie pamäte, ktorá bola predtým načítaná pomocou [`read_unaligned`].
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `dst` pre zápis musí byť [valid].
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL.
///
/// [valid]: self#safety
///
/// ## Na štruktúrach `packed`
///
/// V súčasnosti je nemožné vytvoriť nespracované ukazovatele na nezaradené polia zabalenej štruktúry.
///
/// Pri pokuse o vytvorenie nespracovaného ukazovateľa na pole štruktúry `unaligned` s výrazom, ako je napríklad `&packed.unaligned as *const FieldType`, sa vytvorí sprostredkovaný nezaradený odkaz pred konverziou na nespracovaný ukazovateľ.
///
/// To, že tento odkaz je dočasný a okamžite je obsadený, je bezvýznamné, pretože kompilátor vždy očakáva, že odkazy budú správne zarovnané.
/// Výsledkom je, že použitie `&packed.unaligned as *const FieldType` spôsobí okamžité* nedefinované správanie * vo vašom programe.
///
/// Príklad toho, čo nerobiť a ako to súvisí s `write_unaligned`, je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Tu sa pokúsime prevziať adresu 32-bitového celého čísla, ktoré nie je zarovnané.
///     let unaligned =
///         // Tu sa vytvorí dočasná nezaradená referencia, ktorej výsledkom je nedefinované správanie bez ohľadu na to, či sa referencia použije alebo nie.
/////
///         &mut packed.unaligned
///         // Prenášanie na surový ukazovateľ nepomáha;chyba sa už stala.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Prístup k nezarovnaným poliam priamo napr. S `packed.unaligned` je však bezpečný.
///
///
///
///
///
///
///
///
///
// FIXME: Aktualizujte dokumenty na základe výsledku RFC #2582 a priateľov.
/// # Examples
///
/// Napíšte hodnotu použitia do bajtového bufferu:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // BEZPEČNOSŤ: volajúci musí zaručiť, že `dst` je platný pre zápisy.
    // `dst` nemôže prekrývať `src`, pretože volajúci má premenlivý prístup k `dst`, zatiaľ čo `src` vlastní táto funkcia.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Voláme intrinsic priamo, aby sme sa vyhli volaniu funkcií v generovanom kóde.
        intrinsics::forget(src);
    }
}

/// Vykoná volatilné načítanie hodnoty z `src` bez jej pohybu.To ponecháva pamäť v `src` nezmenenú.
///
/// Prchavé operácie majú pôsobiť na pamäť I/O a je zaručené, že ich kompilátor neodelí alebo nezoradí v iných volatilných operáciách.
///
/// # Notes
///
/// Rust momentálne nemá dôsledne a formálne definovaný pamäťový model, takže presná sémantika toho, čo tu znamená "volatile", sa môže časom meniť.
/// To znamená, že sémantika takmer vždy skončí pekne podobne ako [C11's definition of volatile][c11].
///
/// Kompilátor by nemal meniť relatívne poradie alebo počet operácií volatilnej pamäte.
/// Avšak operácie volatilnej pamäte na typoch s nulovou veľkosťou (napr. Ak je typ s nulovou veľkosťou odovzdaný `read_volatile`) sú noops a môžu byť ignorované.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `src` pre čítanie musí byť [valid].
///
/// * `src` musia byť správne zarovnané.
///
/// * `src` musí ukazovať na správne inicializovanú hodnotu typu `T`.
///
/// Rovnako ako [`read`], aj `read_volatile` vytvára bitovú kópiu `T` bez ohľadu na to, či `T` je [`Copy`].
/// Ak `T` nie je [`Copy`], použitie vrátenej hodnoty aj hodnoty na `*src` môže [violate memory safety][read-ownership].
/// Ukladanie typov, ktoré nie sú typu " [Copy`] v energeticky nezávislej pamäti, je však takmer určite nesprávne.
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL a musí byť správne zarovnaný.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Rovnako ako v C, či je operácia volatilná, nemá vôbec žiadny vplyv na otázky týkajúce sa súbežného prístupu z viacerých vlákien.Prchavé prístupy sa v tomto ohľade správajú presne ako iné ako atómové prístupy.
///
/// Najmä závod medzi `read_volatile` a akoukoľvek operáciou zápisu na rovnaké miesto je nedefinované správanie.
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Nepodľahnete panike, aby bol dopad kodénu menší.
        abort();
    }
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Vykoná volatilný zápis pamäťového miesta s danou hodnotou bez načítania alebo zrušenia starej hodnoty.
///
/// Prchavé operácie majú pôsobiť na pamäť I/O a je zaručené, že ich kompilátor neodelí alebo nezoradí v iných volatilných operáciách.
///
/// `write_volatile` nevypustí obsah `dst`.Je to bezpečné, ale mohlo by dôjsť k úniku pridelených prostriedkov alebo zdrojov, preto by ste mali venovať pozornosť tomu, aby ste neprepísali objekt, ktorý by mal byť zrušený.
///
/// Okrem toho neklesá `src`.Sémanticky sa `src` presunie na miesto, na ktoré ukazuje `dst`.
///
/// # Notes
///
/// Rust momentálne nemá dôsledne a formálne definovaný pamäťový model, takže presná sémantika toho, čo tu znamená "volatile", sa môže časom meniť.
/// To znamená, že sémantika takmer vždy skončí pekne podobne ako [C11's definition of volatile][c11].
///
/// Kompilátor by nemal meniť relatívne poradie alebo počet operácií volatilnej pamäte.
/// Avšak operácie volatilnej pamäte na typoch s nulovou veľkosťou (napr. Ak je typ s nulovou veľkosťou odovzdaný `write_volatile`) sú noops a môžu byť ignorované.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `dst` pre zápis musí byť [valid].
///
/// * `dst` musia byť správne zarovnané.
///
/// Upozorňujeme, že aj keď má `T` veľkosť `0`, ukazovateľ musí mať hodnotu NULL a musí byť správne zarovnaný.
///
/// [valid]: self#safety
///
/// Rovnako ako v C, či je operácia volatilná, nemá vôbec žiadny vplyv na otázky týkajúce sa súbežného prístupu z viacerých vlákien.Prchavé prístupy sa v tomto ohľade správajú presne ako iné ako atómové prístupy.
///
/// Najmä závod medzi `write_volatile` a akoukoľvek inou operáciou (čítaním alebo zápisom) na rovnakom mieste je nedefinované správanie.
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Nepodľahnete panike, aby bol dopad kodénu menší.
        abort();
    }
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Zarovnajte ukazovateľ `p`.
///
/// Vypočítajte posun (z hľadiska prvkov kroku `stride`), ktorý sa musí použiť na ukazovateľ `p`, aby sa ukazovateľ `p` zarovnal na `a`.
///
/// Note: Táto implementácia bola starostlivo prispôsobená nie panic.Je to UB pre toto k panic.
/// Jedinou skutočnou zmenou, ktorá sa tu dá urobiť, je zmena `INV_TABLE_MOD_16` a súvisiacich konštánt.
///
/// Ak sa niekedy rozhodneme, že umožníme nazvať podstatu `a`, ktorá nie je dvojkou moci, bude asi rozumnejšie iba prejsť na naivnú implementáciu, než sa ju snažiť prispôsobiť tejto zmene.
///
///
/// Prípadné otázky smerujte na@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Priame použitie týchto vnútorných riešení vylepšuje kodegén výrazne na opt-úrovni <=
    // 1, kde verzie metód týchto operácií nie sú vložené.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Vypočítajte multiplikatívnu modulárnu inverznú hodnotu `x` modulo `m`.
    ///
    /// Táto implementácia je šitá na mieru `align_offset` a má nasledujúce predpoklady:
    ///
    /// * `m` je sila dvoch;
    /// * `x < m`; (ak je `x ≥ m`, namiesto toho odovzdajte `x % m`)
    ///
    /// Implementácia tejto funkcie nebude panic.Vždy.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikatívna modulárna inverzná tabuľka modulo 2⁴=16.
        ///
        /// Upozorňujeme, že táto tabuľka neobsahuje hodnoty, kde inverzná neexistuje (tj. Pre `0⁻¹ mod 16`, `2⁻¹ mod 16` atď.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, pre ktoré je `INV_TABLE_MOD_16` určený.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // BEZPEČNOSŤ: Vyžaduje sa, aby `m` bola sila dvoch, teda nenulová.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Opakujeme "up" pomocou nasledujúceho vzorca:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // do 2²ⁿ ≥ m.Potom môžeme zredukovať výsledok na požadovaný `m` a výsledok `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Upozorňujeme, že operácie zabalenia tu používame zámerne-pôvodný vzorec používa napr. Odčítanie `mod n`.
                // Je úplne v poriadku robiť ich namiesto toho `mod usize::MAX`, pretože výsledok `mod n` berieme tak či tak na konci.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // BEZPEČNOSŤ: `a` je sila dvoch, teda nenulová.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` prípad sa dá jednoduchšie vypočítať pomocou `-p (mod a)`, ale bráni to schopnosti LLVM vyberať pokyny ako `lea`.Namiesto toho počítame
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ktorý rozdeľuje operácie okolo nosnosti, ale dostatočne pesimizuje `and`, aby LLVM dokázal využiť rôzne optimalizácie, o ktorých vie.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Už je zarovnané.Jéj!
        return 0;
    } else if stride == 0 {
        // Ak ukazovateľ nie je zarovnaný a prvok má nulovú veľkosť, potom ho nikdy nezrovná žiadne množstvo prvkov.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // BEZPEČNOSŤ: a je sila dvoch, teda nenulová.stride==0 prípadov je riešených vyššie.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // BEZPEČNOSŤ: gcdpow má hornú hranicu, čo je najviac počet bitov v usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // BEZPEČNOSŤ: gcd je vždy väčšie alebo rovné 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Táto branch rieši nasledujúcu rovnicu lineárnej kongruencie:
        //
        // ` p + so = 0 mod a `
        //
        // `p` tu je hodnota ukazovateľa, `s`, krok `T`, `o` posun v `T`s a `a`, požadované zarovnanie.
        //
        // S `g = gcd(a, s)` a vyššie uvedenou podmienkou, ktorá tvrdí, že `p` je tiež deliteľný `g`, môžeme označiť `a' = a/g`, `s' = s/g`, `p' = p/g`, potom sa to stane ekvivalentom:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Prvý termín je "the relative alignment of `p` to `a`" (vydelený `g`), druhý člen je "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (opäť vydelený `g`).
        //
        // Delenie `g` je potrebné na to, aby sa inverzia dobre formovala, ak `a` a `s` nie sú primárne.
        //
        // Výsledok získaný týmto riešením ďalej nie je "minimal", takže je potrebné vziať výsledok `o mod lcm(s, a)`.`lcm(s, a)` môžeme nahradiť iba `a'`.
        //
        //
        //
        //
        //

        // BEZPEČNOSŤ: `gcdpow` má hornú hranicu, ktorá nie je väčšia ako počet koncových 0 bitov v `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // BEZPEČNOSŤ: `a2` je nenulová.Posunutím `a` o `gcdpow` nemôžete posunúť žiadny z nastavených bitov
        // v `a` (z ktorých má presne jednu).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // BEZPEČNOSŤ: `gcdpow` má hornú hranicu, ktorá nie je väčšia ako počet koncových 0 bitov v `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // BEZPEČNOSŤ: `gcdpow` má hornú hranicu, ktorá nie je väčšia ako počet koncových 0 bitov
        // `a`.
        // Ďalej odčítanie nemôže pretekať, pretože `a2 = a >> gcdpow` bude vždy striktne väčšia ako `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // BEZPEČNOSŤ: `a2` je sila dvoch, ako je dokázané vyššie.`s2` je striktne menej ako `a2`
        // pretože `(s % a) >> gcdpow` je striktne menej ako `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Vôbec sa nedá zarovnať.
    usize::MAX
}

/// Porovnáva hrubé ukazovatele rovnosti.
///
/// Je to to isté ako pri použití operátora `==`, ale menej všeobecné:
/// argumenty musia byť surové ukazovatele `*const T`, nie čokoľvek, čo implementuje `PartialEq`.
///
/// To sa dá použiť na porovnanie referencií `&T` (ktoré sa implicitne prenášajú na `*const T`) podľa ich adresy, a nie na porovnanie hodnôt, na ktoré poukazujú (čo implementácia `PartialEq for &T` robí).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Plátky sa tiež porovnávajú podľa svojej dĺžky (tučné ukazovatele):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits sa tiež porovnávajú podľa svojej implementácie:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Ukazovatele majú rovnaké adresy.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekty majú rovnaké adresy, ale `Trait` má rôzne implementácie.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Prevod referencie na `*const u8` sa porovnáva podľa adresy.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash surový ukazovateľ.
///
/// To možno použiť na hash referencie `&T` (ktorá sa implicitne donúti k `*const T`) podľa adresy, a nie podľa hodnoty, na ktorú ukazuje (čo robí implementácia `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls pre ukazovatele funkcií
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pre AVR je potrebný medzikus ako je používaný
                // aby sa adresný priestor ukazovateľa zdrojovej funkcie zachoval v ukazovateli konečnej funkcie.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Pre AVR je potrebný medzikus ako je používaný
                // aby sa adresný priestor ukazovateľa zdrojovej funkcie zachoval v ukazovateli konečnej funkcie.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Žiadne variadické funkcie s 0 parametrami
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Vytvorte surový ukazovateľ `const` na miesto bez vytvorenia sprostredkujúceho odkazu.
///
/// Vytvorenie referencie pomocou `&`/`&mut` je povolené, iba ak je ukazovateľ správne zarovnaný a smeruje na inicializované údaje.
/// V prípade, že tieto požiadavky neplatia, mali by sa namiesto nich použiť surové ukazovatele.
/// `&expr as *const _` však vytvorí odkaz skôr, ako ho nahodí na surový ukazovateľ, a na tento odkaz sa vzťahujú rovnaké pravidlá ako na všetky ostatné odkazy.
///
/// Toto makro dokáže vytvoriť surový ukazovateľ *bez toho, aby* najskôr vytvoril odkaz.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` by vytvoril nezaradený odkaz a bol by tak nedefinovaným správaním!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Vytvorte surový ukazovateľ `mut` na miesto bez vytvorenia sprostredkujúceho odkazu.
///
/// Vytvorenie referencie pomocou `&`/`&mut` je povolené, iba ak je ukazovateľ správne zarovnaný a smeruje na inicializované údaje.
/// V prípade, že tieto požiadavky neplatia, mali by sa namiesto nich použiť surové ukazovatele.
/// `&mut expr as *mut _` však vytvorí odkaz skôr, ako ho nahodí na surový ukazovateľ, a na tento odkaz sa vzťahujú rovnaké pravidlá ako na všetky ostatné odkazy.
///
/// Toto makro dokáže vytvoriť surový ukazovateľ *bez toho, aby* najskôr vytvoril odkaz.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` by vytvoril nezaradený odkaz a bol by tak nedefinovaným správaním!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` vynúti kopírovanie poľa namiesto vytvárania referencie.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}