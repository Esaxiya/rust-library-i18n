#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Poskytuje typ metadát ukazovateľa ktoréhokoľvek ukazovaného typu.
///
/// # Ukazovateľ metadáta
///
/// Surové typy ukazovateľov a referenčné typy v Rust možno považovať za zložené z dvoch častí:
/// ukazovateľ údajov, ktorý obsahuje adresu pamäte hodnoty a niektoré metaúdaje.
///
/// Pre typy so statickou veľkosťou (ktoré implementujú `Sized` traits), ako aj pre typy `extern`, sa o ukazovateľoch hovorí, že sú " tenké`: metadáta majú nulovú veľkosť a ich typ je `()`.
///
///
/// O ukazovateľoch na [dynamically-sized types][dst] sa hovorí, že sú " široké`alebo " tučné`, že majú nenulové metadáta:
///
/// * V prípade štruktúr, ktorých posledným poľom je DST, sú metadáta metadátami posledného poľa
/// * Pre typ `str` sú metadáta dĺžka v bajtoch ako `usize`
/// * Pre typy rezov, ako je `[T]`, sú metadáta dĺžka v položkách ako `usize`
/// * Pre objekty trait ako `dyn SomeTrait` sú metadáta [`DynMetadata<Self>`][DynMetadata] (napr. `DynMetadata<dyn SomeTrait>`)
///
/// V jazyku future môže jazyk Rust získať nové druhy typov, ktoré majú rôzne metadáta ukazovateľa.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Model `Pointee` trait
///
/// Pointou tohto trait je jeho asociovaný typ `Metadata`, ktorým je `()` alebo `usize` alebo `DynMetadata<_>`, ako je opísané vyššie.
/// Automaticky sa implementuje pre každý typ.
/// Možno predpokladať, že je implementovaný v generickom kontexte, a to aj bez zodpovedajúcej väzby.
///
/// # Usage
///
/// Nespracované ukazovatele je možné pomocou metódy [`to_raw_parts`] rozložiť na komponenty dátových adries a metadát.
///
/// Alternatívne je možné extrahovať samotné metadáta pomocou funkcie [`metadata`].
/// Je možné odovzdať odkaz na [`metadata`] a implicitne ho vynútiť.
///
/// Ukazovateľ (possibly-wide) je možné dať dohromady z jeho adresy a metadát pomocou [`from_raw_parts`] alebo [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Typ metadát v ukazovateľoch a odkazoch na `Self`.
    #[lang = "metadata_type"]
    // NOTE: Ponechajte trait bounds v `static_assert_expected_bounds_for_metadata`
    //
    // v `library/core/src/ptr/metadata.rs` synchronizované s tými tu:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ukazovatele na typy implementujúce tento alias trait sú " tenké`.
///
/// Patria sem staticky typy " Size` a typy `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: nestabilizujte to skôr, ako sú aliasy trait stabilné v jazyku?
pub trait Thin = Pointee<Metadata = ()>;

/// Extrahujte komponent metadát ukazovateľa.
///
/// Hodnoty typu `*mut T`, `&T` alebo `&mut T` možno odovzdať priamo do tejto funkcie, pretože sa implicitne nútia k `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // BEZPEČNOSŤ: Prístup k hodnote z únie `PtrRepr` je bezpečný, pretože * const T
    // a PtrComponents<T>majú rovnaké rozloženia pamäte.
    // Túto záruku môže poskytnúť iba std.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Vytvorí surový ukazovateľ (possibly-wide) z dátovej adresy a metadát.
///
/// Táto funkcia je bezpečná, ale vrátený ukazovateľ nemusí byť nevyhnutne bezpečný.
/// Rezy nájdete v dokumentácii [`slice::from_raw_parts`], kde nájdete bezpečnostné požiadavky.
/// Pre objekty trait musia metaúdaje pochádzať z ukazovateľa na rovnaký základný vymazaný typ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // BEZPEČNOSŤ: Prístup k hodnote z únie `PtrRepr` je bezpečný, pretože * const T
    // a PtrComponents<T>majú rovnaké rozloženia pamäte.
    // Túto záruku môže poskytnúť iba std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Vykonáva rovnakú funkcionalitu ako [`from_raw_parts`], až na to, že sa vráti nespracovaný ukazovateľ `*mut`, na rozdiel od nespracovaného ukazovateľa `* const`.
///
///
/// Ďalšie informácie nájdete v dokumentácii k [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // BEZPEČNOSŤ: Prístup k hodnote z únie `PtrRepr` je bezpečný, pretože * const T
    // a PtrComponents<T>majú rovnaké rozloženia pamäte.
    // Túto záruku môže poskytnúť iba std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Aby sa zabránilo viazaniu na `T: Copy`, je potrebný manuálny impl.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Aby sa zabránilo viazaniu na `T: Clone`, je potrebný manuálny impl.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadáta pre typ objektu `Dyn = dyn SomeTrait` trait.
///
/// Je to ukazovateľ na vtable (tabuľka virtuálnych volaní), ktorá predstavuje všetky potrebné informácie na manipuláciu s konkrétnym typom uloženým vo vnútri objektu trait.
/// Tabuľka obsahuje najmä:
///
/// * veľkosť písma
/// * zarovnanie typu
/// * ukazovateľ na implicit typu `drop_in_place` (môže to byť nepovolený pre obyčajné staré údaje)
/// * ukazovatele na všetky metódy implementácie typu trait typu
///
/// Všimnite si, že prvé tri sú špeciálne, pretože sú nevyhnutné na pridelenie, zrušenie a zrušenie pridelenia ľubovoľného objektu trait.
///
/// Je možné pomenovať túto štruktúru pomocou parametra typu, ktorý nie je objektom `dyn` trait (napríklad `DynMetadata<u64>`), ale nie tak, aby sa získala zmysluplná hodnota tejto štruktúry.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Spoločná predpona všetkých tabuliek.Za ním nasledujú ukazovatele funkcií pre metódy trait.
///
/// Súkromná implementácia, detail `DynMetadata::size_of` atď.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Vráti veľkosť typu spojeného s touto tabuľkou.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Vráti zarovnanie typu spojeného s touto tabuľkou.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Vráti veľkosť a zarovnanie spolu ako `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // BEZPEČNOSŤ: kompilátor emitoval tento údaj pre konkrétny typ Rust, ktorý
        // je známe, že má platné rozloženie.Rovnaké zdôvodnenie ako v prípade `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Aby sa zabránilo hraniciam `Dyn: $Trait`, je potrebný manuálny impl.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}