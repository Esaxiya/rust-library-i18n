use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Obálka okolo surovej nenulovej hodnoty `*mut T`, ktorá naznačuje, že vlastník tejto obálky vlastní referenta.
/// Užitočné na vytváranie abstrakcií ako `Box<T>`, `Vec<T>`, `String` a `HashMap<K, V>`.
///
/// Na rozdiel od `*mut T` sa `Unique<T>` chová "as if", išlo o inštanciu `T`.
/// Implementuje `Send`/`Sync`, ak `T` je `Send`/`Sync`.
/// To tiež znamená druh silného aliasingu, ktorý môže inštancia `T` očakávať:
/// referent ukazovateľa by nemal byť upravený bez jedinečnej cesty k jeho vlastnému Unique.
///
/// Ak si nie ste istí, či je správne používať `Unique` pre svoje účely, zvážte použitie `NonNull`, ktorý má slabšiu sémantiku.
///
///
/// Na rozdiel od `*mut T` musí mať ukazovateľ vždy nenulovú hodnotu, aj keď nikdy nie je dereferencovaný.
/// To preto, aby enums mohli používať túto zakázanú hodnotu ako diskrimináciu-`Option<Unique<T>>` má rovnakú veľkosť ako `Unique<T>`.
/// Ukazovateľ sa však môže naďalej hojdať, ak nie je odkázaný.
///
/// Na rozdiel od `*mut T` je `Unique<T>` kovariantný oproti `T`.
/// Toto by malo byť vždy správne pre akýkoľvek typ, ktorý dodržiava požiadavky Unique na aliasy.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: tento marker nemá žiadne dôsledky na odchýlku, ale je nevyhnutný
    // aby Dropck pochopil, že logicky vlastníme `T`.
    //
    // Podrobnosti nájdete na:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ukazovatele sú `Send`, ak `T` je `Send`, pretože údaje, na ktoré odkazujú, sú nealiazované.
/// Všimnite si, že tento invariant aliasingu nie je vynútený typovým systémom;abstrakcia pomocou `Unique` ju musí vynútiť.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ukazovatele sú `Sync`, ak `T` je `Sync`, pretože údaje, na ktoré odkazujú, sú nealiazované.
/// Všimnite si, že tento invariant aliasingu nie je vynútený typovým systémom;abstrakcia pomocou `Unique` ju musí vynútiť.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Vytvorí nový `Unique`, ktorý je síce visiaci, ale dobre zarovnaný.
    ///
    /// To je užitočné pri inicializácii typov, ktoré lenivo alokujú, ako to robí `Vec::new`.
    ///
    /// Hodnota ukazovateľa môže potenciálne predstavovať platný ukazovateľ na `T`, čo znamená, že sa nesmie používať ako sentinelová hodnota "not yet initialized".
    /// Typy, ktoré lenivo alokujú, musia sledovať inicializáciu nejakými inými prostriedkami.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // BEZPEČNOSŤ: mem::align_of() vráti platný ukazovateľ, ktorý nemá hodnotu null.The
        // sú teda dodržané podmienky pre volanie new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Vytvorí nový `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` musí byť nenulové.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že hodnota `ptr` nebude null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Vytvorí nový `Unique`, ak `ptr` nemá hodnotu null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // BEZPEČNOSŤ: Ukazovateľ už bol skontrolovaný a nemá hodnotu null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Získava podkladový ukazovateľ `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Odlišuje obsah.
    ///
    /// Výsledná životnosť je viazaná na seba, takže sa chová "as if", išlo vlastne o inštanciu T, ktorá sa požičiava.
    /// Ak je potrebná dlhšia životnosť (unbound), použite `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že `self` spĺňa všetky podmienky
        // požiadavky na referenciu.
        unsafe { &*self.as_ptr() }
    }

    /// Odlišne dereferencuje obsah.
    ///
    /// Výsledná životnosť je viazaná na seba, takže sa chová "as if", išlo vlastne o inštanciu T, ktorá sa požičiava.
    /// Ak je potrebná dlhšia životnosť (unbound), použite `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že `self` spĺňa všetky podmienky
        // požiadavky na meniteľný odkaz.
        unsafe { &mut *self.as_ptr() }
    }

    /// Prenáša na ukazovateľ iného typu.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // BEZPEČNOSŤ: Unique::new_unchecked() vytvára nový unikát a potreby
        // daný ukazovateľ nemá hodnotu null.
        // Pretože míňame seba ako ukazovateľ, nemôže to byť nulové.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // BEZPEČNOSŤ: Meniteľný odkaz nemôže mať hodnotu null
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}