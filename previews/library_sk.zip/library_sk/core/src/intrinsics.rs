//! Vnútorné vlastnosti kompilátora.
//!
//! Zodpovedajúce definície sú v `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Zodpovedajúce implementácie konštánt sú v `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const vnútorná
//!
//! Note: akékoľvek zmeny stálosti podstaty je potrebné prediskutovať s jazykovým tímom.
//! Patria sem zmeny stability konštanty.
//!
//! Ak chcete, aby bol vnútorný produkt použiteľný v čase kompilácie, je potrebné skopírovať implementáciu z <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> do `compiler/rustc_mir/src/interpret/intrinsics.rs` a pridať do vnútornej verzie `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
//!
//!
//! Ak sa má vnútorná vlastnosť použiť z `const fn` s atribútom `rustc_const_stable`, musí byť tiež vnútorný atribút `rustc_const_stable`.
//! Takáto zmena by sa nemala robiť bez konzultácie s jazykom T-lang, pretože prináša do jazyka funkciu, ktorá sa bez podpory kompilátora nedá replikovať v užívateľskom kóde.
//!
//! # Volatiles
//!
//! Prchavé vnútorné prvky poskytujú operácie určené na prácu s pamäťou I/O, pri ktorých je zaručené, že ich kompilátor nezmení poradie naprieč inými vnútornými vnútornými časťami.Prečítajte si dokumentáciu LLVM k [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atómové podstaty poskytujú bežné atómové operácie na strojových slovách s viacerými možnými radeniami v pamäti.Dodržiavajú rovnakú sémantiku ako C++ 11.Prečítajte si dokumentáciu LLVM k [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Rýchly prehľad o usporiadaní pamäte:
//!
//! * Získajte bariéru pre získanie zámku.Nasledujúce čítania a zápisy prebiehajú za bariérou.
//! * Uvoľnenie, bariéra na uvoľnenie zámku.Pred bariérou sa odohrávajú predchádzajúce čítania a zápisy.
//! * Zaručuje sa, že postupne konzistentné, postupne konzistentné operácie sa uskutočnia v danom poradí.Toto je štandardný režim pre prácu s atómovými typmi a je ekvivalentný s `volatile` Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Tieto importy sa používajú na zjednodušenie odkazov v rámci dokumentu
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // BEZPEČNOSŤ: pozri `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, tieto vnútorné prvky berú surové ukazovatele, pretože mutujú aliasovanú pamäť, ktorá nie je platná pre `&` ani `&mut`.
    //

    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na typoch [`atomic`] pomocou metódy `compare_exchange` odovzdaním [`Ordering::SeqCst`] ako parametrov `success` aj `failure`.
    ///
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na typoch [`atomic`] pomocou metódy `compare_exchange` odovzdaním [`Ordering::Acquire`] ako parametrov `success` aj `failure`.
    ///
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange` tak, že sa parametre [`Ordering::Release`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange` tak, že sa parametre [`Ordering::AcqRel`] odovzdávajú ako parametre `success` a [`Ordering::Acquire`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na typoch [`atomic`] prostredníctvom metódy `compare_exchange` odovzdaním [`Ordering::Relaxed`] ako parametrov `success` aj `failure`.
    ///
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange` tak, že sa parametre [`Ordering::SeqCst`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange` tak, že sa parametre [`Ordering::SeqCst`] odovzdávajú ako parametre `success` a [`Ordering::Acquire`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange` tak, že sa parametre [`Ordering::Acquire`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange` tak, že sa parametre [`Ordering::AcqRel`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na typoch [`atomic`] prostredníctvom metódy `compare_exchange_weak` odovzdaním [`Ordering::SeqCst`] ako parametrov `success` aj `failure`.
    ///
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na typoch [`atomic`] prostredníctvom metódy `compare_exchange_weak` odovzdaním [`Ordering::Acquire`] ako parametrov `success` aj `failure`.
    ///
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange_weak` tak, že sa parametre [`Ordering::Release`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange_weak` tak, že sa parametre [`Ordering::AcqRel`] odovzdávajú ako parametre `success` a [`Ordering::Acquire`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na typoch [`atomic`] pomocou metódy `compare_exchange_weak` odovzdaním [`Ordering::Relaxed`] ako parametrov `success` aj `failure`.
    ///
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange_weak` tak, že sa parametre [`Ordering::SeqCst`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange_weak` tak, že sa parametre [`Ordering::SeqCst`] odovzdávajú ako parametre `success` a [`Ordering::Acquire`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange_weak` tak, že sa parametre [`Ordering::Acquire`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Uloží hodnotu, ak je aktuálna hodnota rovnaká ako hodnota `old`.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `compare_exchange_weak` tak, že sa parametre [`Ordering::AcqRel`] odovzdávajú ako parametre `success` a [`Ordering::Relaxed`] ako parametre `failure`.
    /// Napríklad, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Načíta aktuálnu hodnotu ukazovateľa.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `load` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Načíta aktuálnu hodnotu ukazovateľa.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `load` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Načíta aktuálnu hodnotu ukazovateľa.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `load` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Uloží hodnotu na určené miesto v pamäti.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `store` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Uloží hodnotu na určené miesto v pamäti.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `store` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Uloží hodnotu na určené miesto v pamäti.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `store` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Uloží hodnotu na určené miesto v pamäti a vráti starú hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `swap` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené miesto v pamäti a vráti starú hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `swap` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené miesto v pamäti a vráti starú hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `swap` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené miesto v pamäti a vráti starú hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `swap` tak, že sa [`Ordering::AcqRel`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Uloží hodnotu na určené miesto v pamäti a vráti starú hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `swap` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Pridá k aktuálnej hodnote a vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_add` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridá k aktuálnej hodnote a vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_add` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridá k aktuálnej hodnote a vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_add` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridá k aktuálnej hodnote a vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_add` tak, že sa [`Ordering::AcqRel`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Pridá k aktuálnej hodnote a vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_add` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Odčítajte od aktuálnej hodnoty a vráťte predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_sub` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odčítajte od aktuálnej hodnoty a vráťte predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_sub` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odčítajte od aktuálnej hodnoty a vráťte predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_sub` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odčítajte od aktuálnej hodnoty a vráťte predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_sub` tak, že sa [`Ordering::AcqRel`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odčítajte od aktuálnej hodnoty a vráťte predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_sub` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Po bitoch a s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_and` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch a s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_and` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch a s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_and` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch a s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_and` tak, že sa [`Ordering::AcqRel`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch a s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_and` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitová nand s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typ [`AtomicBool`] pomocou metódy `fetch_nand` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typ [`AtomicBool`] pomocou metódy `fetch_nand` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typ [`AtomicBool`] pomocou metódy `fetch_nand` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typ [`AtomicBool`] pomocou metódy `fetch_nand` tak, že sa [`Ordering::AcqRel`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitová nand s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typ [`AtomicBool`] pomocou metódy `fetch_nand` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Po bitoch alebo s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_or` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch alebo s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_or` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch alebo s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_or` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch alebo s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_or` tak, že sa [`Ordering::AcqRel`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Po bitoch alebo s aktuálnou hodnotou vráti predchádzajúcu hodnotu.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_or` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitový xor s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_xor` tak, že sa [`Ordering::SeqCst`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_xor` tak, že sa [`Ordering::Acquire`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_xor` tak, že sa [`Ordering::Release`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_xor` tak, že sa [`Ordering::AcqRel`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitový xor s aktuálnou hodnotou, návrat k predchádzajúcej hodnote.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii pre typy [`atomic`] pomocou metódy `fetch_xor` tak, že sa [`Ordering::Relaxed`] označuje ako `order`.
    /// Napríklad, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch označených [`atomic`] metódou `fetch_max` tak, že sa [`Ordering::SeqCst`] odovzdá ako `order`.
    /// Napríklad, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch označených [`atomic`] metódou `fetch_max` tak, že sa [`Ordering::Acquire`] odovzdá ako `order`.
    /// Napríklad, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_max` tak, že sa [`Ordering::Release`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_max` tak, že sa [`Ordering::AcqRel`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_max` tak, že sa [`Ordering::Relaxed`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_min` tak, že sa [`Ordering::SeqCst`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_min` tak, že sa [`Ordering::Acquire`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_min` tak, že sa [`Ordering::Release`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_min` tak, že sa [`Ordering::AcqRel`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou podpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na celočíselných typoch podpísaných na [`atomic`] metódou `fetch_min` tak, že sa [`Ordering::Relaxed`] odovzdáva ako `order`.
    /// Napríklad, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_min` tak, že [`Ordering::SeqCst`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_min` tak, že [`Ordering::Acquire`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_min` tak, že [`Ordering::Release`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_min` tak, že [`Ordering::AcqRel`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_min` tak, že [`Ordering::Relaxed`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_max` tak, že [`Ordering::SeqCst`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_max` tak, že [`Ordering::Acquire`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_max` tak, že [`Ordering::Release`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_max` tak, že [`Ordering::AcqRel`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum s aktuálnou hodnotou pomocou nepodpísaného porovnania.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii na nepodpísaných celočíselných typoch [`atomic`] pomocou metódy `fetch_max` tak, že [`Ordering::Relaxed`] sa odovzdá ako `order`.
    /// Napríklad, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Vnútorná vlastnosť `prefetch` je pomôckou pre generátor kódu na vloženie inštrukcie predbežného načítania, ak je podporovaná;inak je to zákaz op.
    /// Predbežné načítania nemajú žiadny vplyv na správanie programu, môžu však zmeniť jeho výkonové charakteristiky.
    ///
    /// Argument `locality` musí byť konštantné celé číslo a je špecifikátorom časovej lokality v rozsahu od (0), bez lokality, po (3), mimoriadne lokálny údaj uložený v pamäti cache.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Vnútorná vlastnosť `prefetch` je pomôckou pre generátor kódu na vloženie inštrukcie predbežného načítania, ak je podporovaná;inak je to zákaz op.
    /// Predbežné načítania nemajú žiadny vplyv na správanie programu, môžu však zmeniť jeho výkonové charakteristiky.
    ///
    /// Argument `locality` musí byť konštantné celé číslo a je špecifikátorom časovej lokality v rozsahu od (0), bez lokality, po (3), mimoriadne lokálny údaj uložený v pamäti cache.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Vnútorná vlastnosť `prefetch` je pomôckou pre generátor kódu na vloženie inštrukcie predbežného načítania, ak je podporovaná;inak je to zákaz op.
    /// Predbežné načítania nemajú žiadny vplyv na správanie programu, môžu však zmeniť jeho výkonové charakteristiky.
    ///
    /// Argument `locality` musí byť konštantné celé číslo a je špecifikátorom časovej lokality v rozsahu od (0), bez lokality, po (3), mimoriadne lokálny údaj uložený v pamäti cache.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Vnútorná vlastnosť `prefetch` je pomôckou pre generátor kódu na vloženie inštrukcie predbežného načítania, ak je podporovaná;inak je to zákaz op.
    /// Predbežné načítania nemajú žiadny vplyv na správanie programu, môžu však zmeniť jeho výkonové charakteristiky.
    ///
    /// Argument `locality` musí byť konštantné celé číslo a je špecifikátorom časovej lokality v rozsahu od (0), bez lokality, po (3), mimoriadne lokálny údaj uložený v pamäti cache.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atómový plot.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::fence`] odovzdaním [`Ordering::SeqCst`] ako `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atómový plot.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::fence`] tak, že [`Ordering::Acquire`] bude predaná ako `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atómový plot.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::fence`] tak, že [`Ordering::Release`] bude predaná ako `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atómový plot.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::fence`] tak, že [`Ordering::AcqRel`] bude predaná ako `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Pamäťová bariéra iba pre prekladač.
    ///
    /// Pamäťové prístupy kompilátor cez túto bariéru nikdy nezmení poradie, ale nebudú pre ňu vydané žiadne pokyny.
    /// To je vhodné pre operácie na rovnakom vlákne, ktoré je možné predísť, napríklad pri interakcii so spracovateľmi signálov.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::compiler_fence`] tak, že [`Ordering::SeqCst`] bude predaná ako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Pamäťová bariéra iba pre prekladač.
    ///
    /// Pamäťové prístupy kompilátor cez túto bariéru nikdy nezmení poradie, ale nebudú pre ňu vydané žiadne pokyny.
    /// To je vhodné pre operácie na rovnakom vlákne, ktoré je možné predísť, napríklad pri interakcii so spracovateľmi signálov.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::compiler_fence`] tak, že [`Ordering::Acquire`] bude predaná ako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Pamäťová bariéra iba pre prekladač.
    ///
    /// Pamäťové prístupy kompilátor cez túto bariéru nikdy nezmení poradie, ale nebudú pre ňu vydané žiadne pokyny.
    /// To je vhodné pre operácie na rovnakom vlákne, ktoré je možné predísť, napríklad pri interakcii so spracovateľmi signálov.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::compiler_fence`] tak, že [`Ordering::Release`] bude predaná ako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Pamäťová bariéra iba pre prekladač.
    ///
    /// Pamäťové prístupy kompilátor cez túto bariéru nikdy nezmení poradie, ale nebudú pre ňu vydané žiadne pokyny.
    /// To je vhodné pre operácie na rovnakom vlákne, ktoré je možné predísť, napríklad pri interakcii so spracovateľmi signálov.
    ///
    /// Stabilizovaná verzia tejto vnútornej verzie je k dispozícii v [`atomic::compiler_fence`] tak, že [`Ordering::AcqRel`] bude predaná ako `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magické vnútorné, ktoré odvodzuje svoj význam od atribútov pripojených k funkcii.
    ///
    /// Napríklad tok údajov to používa na vloženie statických tvrdení, aby `rustc_peek(potentially_uninitialized)` skutočne znova skontroloval, či tok údajov skutočne vypočítal, že je v danom okamihu toku riadenia neinicializovaný.
    ///
    ///
    /// Tento vnútorný by sa nemal používať mimo kompilátora.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Prerušuje vykonávanie procesu.
    ///
    /// Užívateľsky príjemnejšia a stabilnejšia verzia tejto operácie je [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informuje optimalizátor o tom, že tento bod v kóde nie je dosiahnuteľný, a umožňuje tak ďalšiu optimalizáciu.
    ///
    /// NB, toto sa veľmi líši od makra `unreachable!()`: Na rozdiel od makra, ktoré panics pri svojom spustení predstavuje *nedefinované správanie*, aby sa dosiahol kód označený touto funkciou.
    ///
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informuje optimalizátor o tom, že podmienka je vždy pravdivá.
    /// Ak je podmienka nepravdivá, správanie nie je definované.
    ///
    /// Pre tento vnútorný jav sa negeneruje žiadny kód, ale optimalizátor sa ho bude snažiť uchovať (a jeho stav) medzi prechodmi, čo môže narušiť optimalizáciu okolitého kódu a znížiť výkon.
    /// Nemal by sa používať, ak môže invariant sám zistiť optimalizátor, alebo ak neumožňuje žiadne významné optimalizácie.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Rady pre kompilátor, že podmienka branch bude pravdepodobne pravdivá.
    /// Vráti hodnotu, ktorá mu bola odovzdaná.
    ///
    /// Akékoľvek iné použitie ako s príkazmi `if` pravdepodobne nebude mať žiadny účinok.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Rady pre kompilátor, že stav branch je pravdepodobne nepravdivý.
    /// Vráti hodnotu, ktorá mu bola odovzdaná.
    ///
    /// Akékoľvek iné použitie ako s príkazmi `if` pravdepodobne nebude mať žiadny účinok.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Spustí pascu prerušenia na kontrolu debuggerom.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn breakpoint();

    /// Veľkosť typu v bajtoch.
    ///
    /// Konkrétnejšie ide o posun v bajtoch medzi postupnými položkami rovnakého typu vrátane zarovnávacej výplne.
    ///
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Minimálne zarovnanie typu.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Preferované zarovnanie typu.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Veľkosť odkazovanej hodnoty v bajtoch.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Požadované vyrovnanie odkazovanej hodnoty.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Získava statický reťazcový rez obsahujúci názov typu.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Získa identifikátor, ktorý je globálne jedinečný pre zadaný typ.
    /// Táto funkcia vráti rovnakú hodnotu pre typ bez ohľadu na to, v ktorom je crate vyvolaná.
    ///
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Ochranný kryt pre nebezpečné funkcie, ktoré nie je možné vykonať, ak je `T` neobývaný:
    /// Toto staticky buď panic, alebo neurobiť nič.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Ochranný kryt pre nebezpečné funkcie, ktoré sa nikdy nedajú vykonať, ak `T` neumožňuje nulovú inicializáciu: Staticky to urobí buď panic, alebo neurobí nič.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn assert_zero_valid<T>();

    /// Ochranný kryt pre nebezpečné funkcie, ktoré sa nikdy nedajú vykonať, ak má `T` neplatné bitové vzory: Toto bude staticky buď panic, alebo neurobí nič.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn assert_uninit_valid<T>();

    /// Získava odkaz na statický `Location` označujúci, kde bol volaný.
    ///
    /// Zvážte radšej použitie [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Presunie hodnotu mimo rozsah bez použitia kvapkového lepidla.
    ///
    /// Toto existuje iba pre [`mem::forget_unsized`];normal `forget` namiesto toho pouzije `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Znovu interpretuje bity hodnoty jedného typu ako iný typ.
    ///
    /// Oba typy musia mať rovnakú veľkosť.
    /// Originál ani výsledok nemusí byť [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` je sémanticky ekvivalentný s bitovým presunom jedného typu do druhého.Skopíruje bity zo zdrojovej hodnoty do cieľovej hodnoty a potom zabudne originál.
    /// Je to ekvivalent C `memcpy` pod kapotou, rovnako ako `transmute_copy`.
    ///
    /// Pretože `transmute` je operácia podľa hodnoty, zarovnanie samotných *transmutovaných hodnôt* nie je znepokojujúce.
    /// Ako pri každej inej funkcii, kompilátor už zaisťuje správne zarovnanie `T` aj `U`.
    /// Pri premene hodnôt, ktoré *ukazujú inde*(napríklad ukazovatele, odkazy, škatule ...), musí volajúci zabezpečiť správne zarovnanie poukázaných hodnôt.
    ///
    /// `transmute` je **neuveriteľne** nebezpečné.Existuje obrovské množstvo spôsobov, ako spôsobiť [undefined behavior][ub] s touto funkciou.`transmute` by mala byť absolútnou poslednou možnosťou.
    ///
    /// Model [nomicon](../../nomicon/transmutes.html) má ďalšiu dokumentáciu.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Existuje niekoľko vecí, pre ktoré je `transmute` skutočne užitočný.
    ///
    /// Premena ukazovateľa na ukazovateľ funkcie.Toto nie je * prenosné na stroje, kde majú ukazovatele funkcií a ukazovatele údajov rôzne veľkosti.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Predĺženie životnosti alebo skrátenie nemennej životnosti.Toto je pokročilý, veľmi nebezpečný Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Nezúfajte: veľa využití modelu `transmute` je možné dosiahnuť aj inými prostriedkami.
    /// Ďalej uvádzame bežné aplikácie modelu `transmute`, ktoré je možné nahradiť bezpečnejšími konštrukciami.
    ///
    /// Premena surového bytes(`&[u8]`) na `u32`, `f64` atď .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // namiesto toho použite `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // alebo použite `u32::from_le_bytes` alebo `u32::from_be_bytes` na určenie endianity
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Premena ukazovateľa na `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Namiesto toho použite obsadenie `as`
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Premena modelu `*mut T` na model `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Použite radšej prerážačku
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Premena modelu `&mut T` na model `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ak teraz dáte dokopy `as` a znova sa prehĺbite, všimnite si, že reťazenie `as` `as` nie je tranzitívne
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Premena modelu `&str` na model `&[u8]`:
    ///
    /// ```
    /// // toto nie je dobrý spôsob, ako to urobiť.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Môžete použiť `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Alebo použite iba bajtový reťazec, ak máte kontrolu nad reťazcovým literálom
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Premena modelu `Vec<&T>` na model `Vec<Option<&T>>`.
    ///
    /// Ak chcete premeniť vnútorný typ obsahu kontajnera, musíte dbať na to, aby ste neporušili žiadny z invariantov kontajnera.
    /// Pre `Vec` to znamená, že veľkosť *aj zarovnanie* vnútorných typov sa musia zhodovať.
    /// Ostatné kontajnery sa môžu spoliehať na veľkosť typu, zarovnanie alebo dokonca `TypeId`, v takom prípade by transmutácia nebola vôbec možná bez porušenia invariantov kontajnerov.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // naklonujte vector, pretože ich neskôr znova použijeme
    /// let v_clone = v_orig.clone();
    ///
    /// // Použitie transmute: toto sa spolieha na nešpecifikované rozloženie údajov `Vec`, čo je zlý nápad a mohlo by to spôsobiť nedefinované správanie.
    /////
    /// // Nie je to však kópia.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Toto je navrhovaný a bezpečný spôsob.
    /// // Skopíruje však celý vector do nového poľa.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Toto je správny a neškodný spôsob kopírovania "transmuting" a `Vec` bez toho, aby ste sa spoliehali na rozloženie údajov.
    /// // Namiesto toho, aby sme doslova volali `transmute`, vykonávame obsadenie ukazovateľa, ale pokiaľ ide o konverziu pôvodného vnútorného typu (`&i32`) na nový (`Option<&i32>`), má to rovnaké varovania.
    /////
    /// // Okrem vyššie uvedených informácií si pozrite aj dokumentáciu [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Aktualizujte to, keď je stabilizovaná vec_into_raw_parts.
    ///     // Zaistite, aby pôvodný vector nespadol.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementácia `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Existuje niekoľko spôsobov, ako to urobiť, a pri nasledujúcom spôsobe (transmute) existuje niekoľko problémov.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // prvý: premena nie je bezpečná pre typ;všetko, čo kontroluje, je, že T a
    ///         // U sú rovnako veľké.
    ///         // Po druhé, tu máte dva premenlivé odkazy smerujúce na rovnakú pamäť.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Týmto sa zbavíte bezpečnostných problémov typu;`&mut *` vám* len *dá `&mut T` z `&mut T` alebo `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // stále však máte dva premenlivé odkazy smerujúce na rovnakú pamäť.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Takto to robí štandardná knižnica.
    /// // Toto je najlepšia metóda, ak potrebujete niečo také urobiť
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // To má teraz tri premenlivé odkazy smerujúce na rovnakú pamäť.`slice`, rvalue ret.0 a rvalue ret.1.
    ///         // `slice` sa nikdy nepoužíva po `let ptr = ...`, a preto ho môžeme považovať za "dead", a preto máte iba dva skutočné premenlivé plátky.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Aj keď to robí vnútornú konštantu stabilnou, v const fn máme nejaký vlastný kód
    // kontroly, ktoré bránia jeho použitiu v rámci `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Vráti `true`, ak skutočný typ uvedený ako `T` vyžaduje kvapkové lepidlo;vráti `false`, ak skutočný typ poskytnutý pre `T` implementuje `Copy`.
    ///
    ///
    /// Ak skutočný typ nevyžaduje kvapkové lepidlo ani neimplementuje `Copy`, potom je návratová hodnota tejto funkcie nešpecifikovaná.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Vypočíta posunutie od ukazovateľa.
    ///
    /// Toto je implementované ako vnútorná vlastnosť, aby sa zabránilo konverzii na a z celého čísla, pretože konverzia by vyhodila informácie o aliase.
    ///
    /// # Safety
    ///
    /// Počiatočný aj výsledný ukazovateľ musia byť v medziach alebo o jeden bajt za koncom prideleného objektu.
    /// Ak je niektorý z ukazovateľov mimo hraníc alebo dôjde k aritmetickému pretečeniu, akékoľvek ďalšie použitie vrátenej hodnoty bude mať za následok nedefinované správanie.
    ///
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Vypočíta posunutie od ukazovateľa, potenciálne zalomenie.
    ///
    /// Toto je implementované ako vnútorná vlastnosť, aby sa zabránilo konverzii na a z celého čísla, pretože konverzia inhibuje určité optimalizácie.
    ///
    /// # Safety
    ///
    /// Na rozdiel od vnútornej hodnoty `offset` táto vnútorná hodnota neobmedzuje výsledný ukazovateľ tak, aby ukazoval na jeden bajt za koniec prideleného objektu alebo jeden bajt za ním, a zalamuje sa aritmetikou dvoch doplnkov.
    /// Výsledná hodnota nemusí byť nevyhnutne platná, aby sa mohla použiť na skutočný prístup do pamäte.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekvivalent k príslušnému vnútornému `llvm.memcpy.p0i8.0i8.*`, s veľkosťou `count`*`size_of::<T>()` a zarovnaním na
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter volatile je nastavený na `true`, takže sa nebude optimalizovať, pokiaľ sa veľkosť nebude rovnať nule.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalent k príslušnému vnútornému `llvm.memmove.p0i8.0i8.*`, s veľkosťou `count* size_of::<T>()` a zarovnaním na
    ///
    /// `min_align_of::<T>()`
    ///
    /// Parameter volatile je nastavený na `true`, takže sa nebude optimalizovať, pokiaľ sa veľkosť nebude rovnať nule.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekvivalent k príslušnému vnútornému `llvm.memset.p0i8.*`, s veľkosťou `count* size_of::<T>()` a usporiadaním `min_align_of::<T>()`.
    ///
    ///
    /// Parameter volatile je nastavený na `true`, takže sa nebude optimalizovať, pokiaľ sa veľkosť nebude rovnať nule.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Vykoná nestále zaťaženie z ukazovateľa `src`.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Vykoná volatilné uloženie do ukazovateľa `dst`.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Vykoná nestále zaťaženie z ukazovateľa `src` Ukazovateľ nemusí byť zarovnaný.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Vykoná volatilné uloženie do ukazovateľa `dst`.
    /// Ukazovateľ sa nemusí zarovnávať.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Vráti druhú odmocninu `f32`
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Vráti druhú odmocninu `f64`
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Zvyšuje `f32` na celé číslo.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Zvyšuje `f64` na celé číslo.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Vráti sínus `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Vráti sínus `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Vráti kosínus `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Vráti kosínus `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Zvyšuje výkon `f32` na `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Zvyšuje výkon `f64` na `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Vráti exponenciálnu hodnotu `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Vráti exponenciálnu hodnotu `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Vráti hodnotu 2 zvýšenú na hodnotu `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Vráti hodnotu 2 zvýšenú na hodnotu `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Vráti prirodzený logaritmus `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Vráti prirodzený logaritmus `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Vráti základný 10 logaritmus hodnoty `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Vráti základný 10 logaritmus hodnoty `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Vráti základný 2 logaritmus hodnoty `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Vráti základný 2 logaritmus hodnoty `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Vráti `a * b + c` pre hodnoty `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Vráti `a * b + c` pre hodnoty `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Vráti absolútnu hodnotu `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Vráti absolútnu hodnotu `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Vráti minimálne dve hodnoty `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Vráti minimálne dve hodnoty `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Vráti maximálne dve hodnoty `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Vráti maximálne dve hodnoty `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Skopíruje znamienko od `y` do `x` pre hodnoty `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Skopíruje znamienko od `y` do `x` pre hodnoty `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Vráti najväčšie celé číslo menšie alebo rovné `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Vráti najväčšie celé číslo menšie alebo rovné `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Vráti najmenšie celé číslo väčšie alebo rovné `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Vráti najmenšie celé číslo väčšie alebo rovné `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Vráti celočíselnú časť `f32`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Vráti celočíselnú časť `f64`.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Vráti najbližšie celé číslo k `f32`.
    /// Môže zvýšiť nepresnú výnimku s pohyblivou rádovou čiarkou, ak argument nie je celé číslo.
    pub fn rintf32(x: f32) -> f32;
    /// Vráti najbližšie celé číslo k `f64`.
    /// Môže zvýšiť nepresnú výnimku s pohyblivou rádovou čiarkou, ak argument nie je celé číslo.
    pub fn rintf64(x: f64) -> f64;

    /// Vráti najbližšie celé číslo k `f32`.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Vráti najbližšie celé číslo k `f64`.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Vráti najbližšie celé číslo k `f32`.Zaokrúhľuje prípady na pol cesty od nuly.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Vráti najbližšie celé číslo k `f64`.Zaokrúhľuje prípady na pol cesty od nuly.
    ///
    /// Stabilizovaná verzia tohto vnútorného prvku je
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Plávajúci doplnok, ktorý umožňuje optimalizáciu na základe algebraických pravidiel.
    /// Môže predpokladať, že vstupy sú konečné.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Plávajúce odčítanie, ktoré umožňuje optimalizáciu založenú na algebraických pravidlách.
    /// Môže predpokladať, že vstupy sú konečné.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Float multiplikácia, ktorá umožňuje optimalizáciu na základe algebraických pravidiel.
    /// Môže predpokladať, že vstupy sú konečné.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float divízia, ktorá umožňuje optimalizáciu na základe algebraických pravidiel.
    /// Môže predpokladať, že vstupy sú konečné.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Plávajúci zvyšok, ktorý umožňuje optimalizáciu na základe algebraických pravidiel.
    /// Môže predpokladať, že vstupy sú konečné.
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Prevod pomocou LLVM fptoui/fptosi, ktorý môže vrátiť undef pre hodnoty mimo rozsah
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabilizované ako [`f32::to_int_unchecked`] a [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Vráti počet bitov nastavený na celé číslo typu `T`
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `count_ones`.
    /// Napríklad,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Vráti počet úvodných nezastavených bitov (zeroes) v celočíselnom type `T`.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `leading_zeros`.
    /// Napríklad,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` s hodnotou `0` vráti bitovú šírku `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Rovnako ako `ctlz`, ale mimoriadne nebezpečný, pretože vracia `undef`, keď dostane `x` s hodnotou `0`.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Vráti počet koncových nezastavených bitov (zeroes) v celočíselnom type `T`.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `trailing_zeros`.
    /// Napríklad,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` s hodnotou `0` vráti bitovú šírku `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Rovnako ako `cttz`, ale mimoriadne nebezpečný, pretože vracia `undef`, keď dostane `x` s hodnotou `0`.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Obráti bajty v celočíselnom type `T`.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `swap_bytes`.
    /// Napríklad,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Obráti bity v celočíselnom type `T`.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `reverse_bits`.
    /// Napríklad,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Vykoná začiarknutie celého čísla.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `overflowing_add`.
    /// Napríklad,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Vykoná odčítanie skontrolovaného celého čísla
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `overflowing_sub`.
    /// Napríklad,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Vykoná násobené celé číslo
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `overflowing_mul`.
    /// Napríklad,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Vykoná presné rozdelenie, výsledkom bude nedefinované správanie kde `x % y != 0` alebo `y == 0` alebo `x == T::MIN && y == -1`
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Vykoná nekontrolované rozdelenie, výsledkom bude nedefinované správanie pri `y == 0` alebo `x == T::MIN && y == -1`
    ///
    ///
    /// Bezpečné obaly pre túto vnútornú stránku sú k dispozícii na celočíselných primitívach pomocou metódy `checked_div`.
    /// Napríklad,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Vráti zvyšok nekontrolovaného rozdelenia, čo má za následok nedefinované správanie pri `y == 0` alebo `x == T::MIN && y == -1`
    ///
    ///
    /// Bezpečné obaly pre túto vnútornú stránku sú k dispozícii na celočíselných primitívach pomocou metódy `checked_rem`.
    /// Napríklad,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Vykoná nekontrolovaný ľavý posun, čo má za následok nedefinované správanie, keď `y < 0` alebo `y >= N`, kde N je šírka T v bitoch.
    ///
    ///
    /// Bezpečné obaly pre túto vnútornú stránku sú k dispozícii na celočíselných primitívach pomocou metódy `checked_shl`.
    /// Napríklad,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Vykoná nekontrolovaný pravý posun, čo má za následok nedefinované správanie, keď `y < 0` alebo `y >= N`, kde N je šírka T v bitoch.
    ///
    ///
    /// Bezpečné obaly pre túto vnútornú stránku sú k dispozícii na celočíselných primitívach pomocou metódy `checked_shr`.
    /// Napríklad,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Vráti výsledok nekontrolovaného pridania, čo má za následok nedefinované správanie pri `x + y > T::MAX` alebo `x + y < T::MIN`.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Vráti výsledok nekontrolovaného odčítania, ktorého výsledkom je nedefinované správanie pri `x - y > T::MAX` alebo `x - y < T::MIN`.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Vráti výsledok nekontrolovaného násobenia, ktorého výsledkom je nedefinované správanie pri `x *y > T::MAX` alebo `x* y < T::MIN`.
    ///
    ///
    /// Tento vnútorný nemá stabilný náprotivok.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Vykonáva rotáciu doľava.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `rotate_left`.
    /// Napríklad,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Vykonáva rotáciu doprava.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `rotate_right`.
    /// Napríklad,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Vráti (a + b) mod 2 <sup>N</sup>, kde N je šírka T v bitoch.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `wrapping_add`.
    /// Napríklad,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Vráti (a, b) mod 2 <sup>N</sup>, kde N je šírka T v bitoch.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `wrapping_sub`.
    /// Napríklad,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Vráti (a * b) mod 2 <sup>N</sup>, kde N je šírka T v bitoch.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `wrapping_mul`.
    /// Napríklad,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Vypočítava `a + b` a saturuje sa na číselných hraniciach.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `saturating_add`.
    /// Napríklad,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Vypočítava `a - b` a saturuje sa na číselných hraniciach.
    ///
    /// Stabilizované verzie tejto vnútornej sú k dispozícii na celočíselných primitívach pomocou metódy `saturating_sub`.
    /// Napríklad,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Vráti hodnotu diskriminátora pre variant v 'v';
    /// ak `T` nemá žiadny diskriminátor, vráti `0`.
    ///
    /// Stabilizovaná verzia tohto vlastného produktu je [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Vráti počet variantov obsadenia typu `T` do `usize`;
    /// ak `T` nemá žiadne varianty, vráti `0`.Neobývané varianty sa budú počítať.
    ///
    /// Aktuálnou stabilnou verziou tohto modelu je [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Konštrukcia "try catch" Rust, ktorá vyvoláva funkčný ukazovateľ `try_fn` s údajovým ukazovateľom `data`.
    ///
    /// Tretím argumentom je funkcia volaná, ak dôjde k panic.
    /// Táto funkcia prevezme údajový ukazovateľ a ukazovateľ na cieľový objekt výnimky, ktorý bol zachytený.
    ///
    /// Ďalšie informácie nájdete v zdroji kompilátora a implementácii úlovku std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Vydáva obchod `!nontemporal` podľa LLVM (pozri ich dokumenty).
    /// Pravdepodobne sa nikdy nestane stabilným.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Podrobnosti nájdete v dokumentácii k `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Podrobnosti nájdete v dokumentácii k `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Podrobnosti nájdete v dokumentácii k `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Prideliť v čase kompilácie.Nemalo by sa volať za behu.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Tu sú definované niektoré funkcie, pretože boli omylom sprístupnené v tomto module v stajni.
// Pozri <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` tiež spadá do tejto kategórie, ale nemôže byť zabalený kvôli kontrole, že `T` a `U` majú rovnakú veľkosť.)
//

/// Skontroluje, či je `ptr` správne zarovnaný vzhľadom na `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopíruje bajty `count * size_of::<T>()` z `src` do `dst`.Zdroj a cieľ sa nesmú prekrývať.
///
/// Pre oblasti pamäte, ktoré sa môžu prekrývať, použite namiesto nich [`copy`].
///
/// `copy_nonoverlapping` je sémanticky ekvivalentný s [`memcpy`] v C, ale s vymeneným poradím argumentov.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `src` musí byť [valid] pre čítanie `count * size_of::<T>()` bajtov.
///
/// * `dst` musí byť [valid] pre zápisy `count * size_of::<T>()` bajtov.
///
/// * `src` aj `dst` musia byť správne zarovnané.
///
/// * Oblasť pamäte začínajúca na `src` s veľkosťou `count *
///   veľkosť: :<T>() `bajty sa nesmú *nesmie* prekrývať s oblasťou pamäte začínajúcou na `dst` s rovnakou veľkosťou.
///
/// Rovnako ako [`read`], aj `copy_nonoverlapping` vytvára bitovú kópiu `T` bez ohľadu na to, či `T` je [`Copy`].
/// Ak `T` nie je [`Copy`], pomocou *oboch* hodnôt v oblasti začínajúcej na `*src` a oblasti začínajúcej na `* dst` môžete [violate memory safety][read-ownership].
///
///
/// Upozorňujeme, že aj keď je efektívne skopírovaná veľkosť (`count * size_of: :<T>()`) je `0`, ukazovatele musia mať inú hodnotu ako NULL a musia byť správne zarovnané.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ručne implementujte [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Presunie všetky prvky `src` do `dst` a ponechá `src` prázdne.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Zaistite, aby mal `dst` dostatočnú kapacitu na to, aby pojal celý `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Výzva na posunutie je vždy bezpečná, pretože `Vec` nikdy nepridelí viac ako `isize::MAX` bajtov.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Skráťte `src` bez toho, aby ste museli spadnúť z jeho obsahu.
///         // Robíme to ako prvé, aby sme sa vyhli problémom v prípade, že bude niečo ďalej od panics.
///         src.set_len(0);
///
///         // Tieto dve oblasti sa nemôžu prekrývať, pretože premenlivé referencie nie sú alias, a dva rôzne vektory vectors nemôžu vlastniť rovnakú pamäť.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Oznámte `dst`, že teraz obsahuje obsah `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Tieto kontroly vykonávajte iba za behu programu
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Nepodľahnete panike, aby bol dopad kodénu menší.
        abort();
    }*/

    // BEZPEČNOSŤ: zmluva o bezpečnosti pre `copy_nonoverlapping` musí byť
    // potvrdzuje volajúci.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopíruje bajty `count * size_of::<T>()` z `src` do `dst`.Zdroj a cieľ sa môžu prekrývať.
///
/// Ak sa zdroj a cieľ *nikdy* nebudú prekrývať, možno namiesto nich použiť [`copy_nonoverlapping`].
///
/// `copy` je sémanticky ekvivalentný s [`memmove`] v C, ale s vymeneným poradím argumentov.
/// Kopírovanie prebieha, akoby boli bajty skopírované z `src` do dočasného poľa a potom z poľa do `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `src` musí byť [valid] pre čítanie `count * size_of::<T>()` bajtov.
///
/// * `dst` musí byť [valid] pre zápisy `count * size_of::<T>()` bajtov.
///
/// * `src` aj `dst` musia byť správne zarovnané.
///
/// Rovnako ako [`read`], aj `copy` vytvára bitovú kópiu `T` bez ohľadu na to, či `T` je [`Copy`].
/// Ak `T` nie je [`Copy`], použitie hodnôt v oblasti začínajúcej na `*src` a oblasti začínajúcej na `* dst` môže mať [violate memory safety][read-ownership].
///
///
/// Upozorňujeme, že aj keď je efektívne skopírovaná veľkosť (`count * size_of: :<T>()`) je `0`, ukazovatele musia mať inú hodnotu ako NULL a musia byť správne zarovnané.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Efektívne vytvorte Rust vector z nebezpečného bufferu:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` musí byť správne zarovnaný pre svoj typ a nenulový.
/// /// * `ptr` musí byť platné pre čítanie susedných prvkov `elts` typu `T`.
/// /// * Tieto prvky sa po vyvolaní tejto funkcie nesmú používať, ibaže `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // BEZPEČNOSŤ: Náš predpoklad zaisťuje, že zdroj je zarovnaný a platný,
///     // a `Vec::with_capacity` zaisťuje, že máme priestor na ich napísanie.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // BEZPEČNOSŤ: S takouto kapacitou sme ho vytvorili skôr,
///     // a predchádzajúca `copy` tieto prvky inicializovala.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Tieto kontroly vykonávajte iba za behu programu
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Nepodľahnete panike, aby bol dopad kodénu menší.
        abort();
    }*/

    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `copy`.
    unsafe { copy(src, dst, count) }
}

/// Nastaví `count * size_of::<T>()` bajtov pamäte od `dst` do `val`.
///
/// `write_bytes` je podobný [`memset`] od C, ale nastavuje `count * size_of::<T>()` bajtov na `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `dst` musí byť [valid] pre zápisy `count * size_of::<T>()` bajtov.
///
/// * `dst` musia byť správne zarovnané.
///
/// Volajúci musí ďalej zabezpečiť, aby zápis bajtov `count * size_of::<T>()` do danej oblasti pamäte priniesol platnú hodnotu `T`.
/// Používanie oblasti pamäte zadanej ako `T`, ktorá obsahuje neplatnú hodnotu `T`, je nedefinované správanie.
///
/// Upozorňujeme, že aj keď je efektívne skopírovaná veľkosť (`count * size_of: :<T>()`) je `0`, ukazovateľ musí mať inú hodnotu ako NULL a musí byť správne zarovnaný.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Vytvorenie neplatnej hodnoty:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Úniky z predtým držanej hodnoty prepísaním `Box<T>` nulovým ukazovateľom.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // V tomto okamihu vedie použitie alebo vypadnutie `v` k nedefinovanému správaniu.
/// // drop(v); // ERROR
///
/// // Dokonca aj netesnosť `v` "uses", a teda nedefinované správanie.
/// // mem::forget(v); // ERROR
///
/// // V skutočnosti je `v` neplatný podľa základných invariantov rozloženia základného typu, takže *každá* operácia, ktorá sa ho dotýka, je nedefinované správanie.
/////
/// // nech v2 =v;//CHYBA
///
/// unsafe {
///     // Namiesto toho zadajte platnú hodnotu
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Teraz je krabica v poriadku
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `write_bytes`.
    unsafe { write_bytes(dst, val, count) }
}