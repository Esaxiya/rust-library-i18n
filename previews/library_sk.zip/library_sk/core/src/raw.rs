#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Obsahuje definície štruktúr pre rozloženie vstavaných typov kompilátora.
//!
//! Môžu byť použité ako ciele transmutácií v nebezpečnom kóde na priamu manipuláciu so surovými reprezentáciami.
//!
//!
//! Ich definícia by sa mala vždy zhodovať s ABI definovaným v `rustc_middle::ty::layout`.
//!

/// Reprezentácia objektu trait ako `&dyn SomeTrait`.
///
/// Táto štruktúra má rovnaké rozloženie ako typy ako `&dyn SomeTrait` a `Box<dyn AnotherTrait>`.
///
/// `TraitObject` je zaručené, že sa zhoduje s rozloženiami, ale nejde o typ objektov trait (napr. polia nie sú priamo prístupné na `&dyn SomeTrait`), ani to neovláda toto rozloženie (zmena definície nezmení rozloženie `&dyn SomeTrait`).
///
/// Je určený iba na použitie v nebezpečnom kóde, ktorý potrebuje manipuláciu s podrobnosťami na nízkej úrovni.
///
/// Neexistuje spôsob, ako by sa dalo všeobecne odkazovať na všetky objekty trait, takže jediný spôsob, ako vytvoriť hodnoty tohto typu, je pomocou funkcií ako [`std::mem::transmute`][transmute].
/// Podobne jediný spôsob, ako vytvoriť skutočný objekt trait z hodnoty `TraitObject`, je `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Syntéza objektu trait s nezhodnými typmi-taký, kde vtable nezodpovedá typu hodnoty, na ktorú smeruje údajový ukazovateľ-s vysokou pravdepodobnosťou povedie k nedefinovanému správaniu.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // príklad trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // nechajte kompilátor vytvoriť objekt trait
/// let object: &dyn Foo = &value;
///
/// // pozri sa na surové zastúpenie
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // údajový ukazovateľ je adresa `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // skonštruovať nový objekt, ukazujúci na iný `i32`, dávajte pozor, aby ste použili `i32` vtable z `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // malo by to fungovať rovnako, akoby sme priamo z `other_value` zostrojili objekt trait
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}