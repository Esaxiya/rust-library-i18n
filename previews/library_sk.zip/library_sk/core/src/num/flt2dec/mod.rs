/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// Aj keď je to rozsiahlo zdokumentované, je to v zásade súkromné, ktoré je zverejnené iba na testovanie.
// nevystavuj nás.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// Algoritmy generovania číslic.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// Minimálna veľkosť medzipamäte nevyhnutná pre najkratší režim.
///
/// Odvodenie je trochu netriviálne, ale toto je plus plus maximálny počet významných desatinných číslic z formátovacích algoritmov s najkratším výsledkom.
///
/// Presný vzorec je `ceil(# bits in mantissa * log_10 2 + 1)`.
pub const MAX_SIG_DIGITS: usize = 17;

/// Keď `d` obsahuje desatinné číslice, zväčšite poslednú číslicu a šírite prenos.
/// Vráti ďalšiu číslicu, ak spôsobí zmenu dĺžky.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] je všetkých deväť
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 zaokrúhli na 1000..000 so zvýšeným exponentom
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // zaokrúhľuje sa prázdna vyrovnávacia pamäť (trochu zvláštne, ale rozumné)
            Some(b'1')
        }
    }
}

/// Formátované diely.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// Daný počet nulových číslic.
    Zero(usize),
    /// Doslovné číslo až do 5 číslic.
    Num(u16),
    /// Doslovná kópia daných bajtov.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// Vráti presnú dĺžku bajtu danej časti.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// Zapíše časť do dodaného bufferu.
    /// Vráti počet zapísaných bajtov alebo `None`, ak nestačí vyrovnávacia pamäť.
    /// (Stále môže vo vyrovnávacej pamäti ponechať čiastočne napísané bajty; na to sa nespoliehajte.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// Naformátovaný výsledok obsahujúci jednu alebo viac častí.
/// To je možné zapísať do bajtového bufferu alebo previesť na pridelený reťazec.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// Bajtový rez predstavujúci znamienko, buď `""`, `"-"` alebo `"+"`.
    pub sign: &'static str,
    /// Naformátované časti, ktoré sa majú vykresliť po znaku a voliteľnom odsadení nuly.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// Vráti presnú dĺžku bajtu kombinovaného naformátovaného výsledku.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// Zapíše všetky naformátované časti do dodávaného bufferu.
    /// Vráti počet zapísaných bajtov alebo `None`, ak nestačí vyrovnávacia pamäť.
    /// (Stále môže vo vyrovnávacej pamäti ponechať čiastočne napísané bajty; na to sa nespoliehajte.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// Formáty s desatinnými číslicami `0.<...buf...> * 10^exp` do desatinného tvaru s minimálne daným počtom zlomkových číslic.
///
/// Výsledok sa uloží do dodaného poľa častí a vráti sa plátok napísaných častí.
///
/// `frac_digits` môže byť menší ako počet skutočných zlomkových číslic v `buf`;
/// bude ignorované a vytlačia sa celé číslice.Používa sa iba na tlač ďalších núl po vykreslení číslic.
/// `frac_digits` z 0 teda znamená, že bude tlačiť iba dané číslice a nič iné.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // ak existuje obmedzenie na pozícii poslednej číslice, predpokladá sa, že `buf` je ponechaná s ľavými polstrovanými virtuálnymi nulami.
    // počet virtuálnych núl, `nzeroes`, sa rovná `max(0, exp + frac_digits - buf.len())`, takže pozícia poslednej číslice `exp - buf.len() - nzeroes` nie je väčšia ako `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |nuly |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` sa pre každý prípad počíta individuálne, aby sa zabránilo pretečeniu.
    //

    if exp <= 0 {
        // desatinná čiarka je pred vykreslenými číslicami: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..4`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..3`.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // desatinná čiarka je vo vnútri vykreslených číslic: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // BEZPEČNOSŤ: práve sme inicializovali prvky `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // BEZPEČNOSŤ: práve sme inicializovali prvky `..3`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // desatinná čiarka je za vykreslenými číslicami: [1234][____0000] alebo [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // BEZPEČNOSŤ: práve sme inicializovali prvky `..4`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // BEZPEČNOSŤ: práve sme inicializovali prvky `..2`.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// Naformátuje dané desatinné čísla `0.<...buf...> * 10^exp` do exponenciálneho tvaru s minimálne daným počtom platných číslic.
///
/// Keď `upper` je `true`, exponent bude mať predponu `E`;inak je to `e`.
/// Výsledok sa uloží do dodaného poľa častí a vráti sa plátok napísaných častí.
///
/// `min_digits` môže byť menší ako počet skutočných platných číslic v `buf`;
/// bude ignorované a vytlačia sa celé číslice.Používa sa iba na tlač ďalších núl po vykreslení číslic.
/// `min_digits == 0` teda znamená, že vytlačí iba dané číslice a nič iné.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // vyhnúť sa podtečeniu, keď exp je i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // BEZPEČNOSŤ: práve sme inicializovali prvky `..n + 2`.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// Možnosti formátovania znamienka.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// Vytlačí `-` iba pre záporné nenulové hodnoty.
    Minus, // -inf -1 0 0 1 inf nan
    /// Vytlačí `-` iba pre všetky záporné hodnoty (vrátane zápornej nuly).
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// Vytlačí `-` pre záporné nenulové hodnoty, alebo `+` inak.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// Vytlačí `-` pre všetky záporné hodnoty (vrátane zápornej nuly), inak `+`.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// Vráti statický bajtový reťazec zodpovedajúci znaku, ktorý sa má formátovať.
/// Môže to byť buď `""`, `"+"` alebo `"-"`.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// Naformátuje dané číslo s pohyblivou rádovou čiarkou do desatinného tvaru s minimálne daným počtom zlomkových číslic.
/// Výsledok sa uloží do dodávaného poľa dielov, pričom sa daný bajtový buffer použije ako škrabanec.
/// `upper` nie je momentálne používaný, ale zostáva na rozhodnutie future zmeniť prípad neurčitých hodnôt, tj. `inf` a `nan`.
///
/// Prvá časť, ktorá sa má vykresliť, je vždy `Part::Sign` (čo môže byť prázdny reťazec, ak nie je vykreslený žiadny znak).
///
/// `format_shortest` by mala byť základná funkcia generovania číslic.
/// Mala by vrátiť časť medzipamäte, ktorú inicializovala.
/// Pravdepodobne by ste za to chceli `strategy::grisu::format_shortest`.
///
/// `frac_digits` môže byť menší ako počet skutočných zlomkových číslic v `v`;
/// bude ignorované a vytlačia sa celé číslice.Používa sa iba na tlač ďalších núl po vykreslení číslic.
/// `frac_digits` z 0 teda znamená, že bude tlačiť iba dané číslice a nič iné.
///
/// Bajtová vyrovnávacia pamäť by mala byť dlhá najmenej `MAX_SIG_DIGITS` bajtov.
/// K dispozícii by mali byť minimálne 4 časti, kvôli najhoršiemu prípadu ako `[+][0.][0000][2][0000]` s `frac_digits = 10`.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // BEZPEČNOSŤ: práve sme inicializovali prvky `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// Naformátuje dané číslo s pohyblivou rádovou čiarkou do desatinného alebo exponenciálneho tvaru v závislosti od výsledného exponenta.
/// Výsledok sa uloží do dodávaného poľa dielov, pričom sa daný bajtový buffer použije ako škrabanec.
/// `upper` sa používa na určenie prípadu neurčitých hodnôt (`inf` a `nan`) alebo prípadu prefixu exponenta (`e` alebo `E`).
/// Prvá časť, ktorá sa má vykresliť, je vždy `Part::Sign` (čo môže byť prázdny reťazec, ak nie je vykreslený žiadny znak).
///
/// `format_shortest` by mala byť základná funkcia generovania číslic.
/// Mala by vrátiť časť medzipamäte, ktorú inicializovala.
/// Pravdepodobne by ste za to chceli `strategy::grisu::format_shortest`.
///
/// `dec_bounds` je n-tica `(lo, hi)`, takže číslo je naformátované ako desatinné iba vtedy, keď je `10^lo <= V < 10^hi`.
/// Upozorňujeme, že toto je *zdanlivý*`V` namiesto skutočného `v`!Teda žiadny vytlačený exponent v exponenciálnej podobe nemôže byť v tomto rozmedzí, aby nedošlo k zámene.
///
///
/// Bajtová vyrovnávacia pamäť by mala byť dlhá najmenej `MAX_SIG_DIGITS` bajtov.
/// K dispozícii by malo byť minimálne 6 častí, kvôli najhoršiemu prípadu ako `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// Vráti dosť hrubú aproximáciu (hornú hranicu) pre maximálnu veľkosť vyrovnávacej pamäte vypočítanú z daného dekódovaného exponenta.
///
/// Presný limit je:
///
/// - keď `exp < 0`, maximálna dĺžka je `ceil(log_10 (5^-exp * (2^64 - 1)))`.
/// - keď `exp >= 0`, maximálna dĺžka je `ceil(log_10 (2^exp * (2^64 - 1)))`.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` je menej ako `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`, čo je zase menej ako `20 + (1 + exp* log_10 x)`.
/// Používame fakty `log_10 2 < 5/16` a `log_10 5 < 12/16`, ktoré na naše účely stačia.
///
/// Prečo to potrebujeme?Funkcie `format_exact` vyplnia celú vyrovnávaciu pamäť, pokiaľ to nie je obmedzené obmedzením poslednej číslice, ale je možné, že počet požadovaných číslic je smiešne veľký (povedzme 30 000 číslic).
///
/// Drvivá väčšina medzipamäte bude naplnená nulami, takže nechceme vopred alokovať všetku medzipamäť.
/// V dôsledku toho pre všetky dané argumenty
/// Pre `f64` by malo stačiť 826 bajtov vyrovnávacej pamäte.Porovnajte to so skutočným počtom v najhoršom prípade: 770 bajtov (pri `exp = -1074`).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// Formáty, ktoré majú číslo s pohyblivou rádovou čiarkou, do exponenciálneho tvaru s presne daným počtom platných číslic.
/// Výsledok sa uloží do dodávaného poľa dielov, pričom sa daný bajtový buffer použije ako škrabanec.
/// `upper` sa používa na určenie prípadu prefixu exponenta (`e` alebo `E`).
/// Prvá časť, ktorá sa má vykresliť, je vždy `Part::Sign` (čo môže byť prázdny reťazec, ak nie je vykreslený žiadny znak).
///
/// `format_exact` by mala byť základná funkcia generovania číslic.
/// Mala by vrátiť časť medzipamäte, ktorú inicializovala.
/// Pravdepodobne by ste za to chceli `strategy::grisu::format_exact`.
///
/// Bajtová vyrovnávacia pamäť by mala byť dlhá najmenej `ndigits` bajtov, pokiaľ nie je `ndigits` taká veľká, že sa do nej bude môcť zapisovať iba pevný počet číslic.
/// (Bod zlomu pre `f64` je asi 800, takže by malo stačiť 1 000 bajtov.) K dispozícii by malo byť minimálne 6 častí, kvôli najhoršiemu prípadu ako `[+][1][.][2345][e][-][6]`.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // BEZPEČNOSŤ: práve sme inicializovali prvky `..3`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// Formáty, ktoré majú číslo s pohyblivou rádovou čiarkou, do desatinnej formy s presne daným počtom zlomkových číslic.
/// Výsledok sa uloží do dodávaného poľa dielov, pričom sa daný bajtový buffer použije ako škrabanec.
/// `upper` nie je momentálne používaný, ale zostáva na rozhodnutie future zmeniť prípad neurčitých hodnôt, tj. `inf` a `nan`.
/// Prvá časť, ktorá sa má vykresliť, je vždy `Part::Sign` (čo môže byť prázdny reťazec, ak nie je vykreslený žiadny znak).
///
/// `format_exact` by mala byť základná funkcia generovania číslic.
/// Mala by vrátiť časť medzipamäte, ktorú inicializovala.
/// Pravdepodobne by ste za to chceli `strategy::grisu::format_exact`.
///
/// Bajtová vyrovnávacia pamäť by mala stačiť na výstup, pokiaľ nie je `frac_digits` taká veľká, že sa bude môcť zapisovať iba pevný počet číslic.
/// (Bod zlomu pre model `f64` je asi 800 a malo by stačiť 1 000 bajtov.) Mali by byť k dispozícii minimálne 4 diely, a to kvôli najhoršiemu prípadu, ako je `[+][0.][0000][2][0000]` s `frac_digits = 10`.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // BEZPEČNOSŤ: práve sme inicializovali prvky `..2`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // je *možné* možné, že `frac_digits` je smiešne veľký.
            // `format_exact` ukončí vykresľovanie číslic v tomto prípade oveľa skôr, pretože sme striktne obmedzení `maxlen`.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // obmedzenie nebolo možné splniť, takže by sa malo vykresliť ako nulové bez ohľadu na to, či bol `exp`.
                // to nezahŕňa prípad, že obmedzenie bolo splnené až po konečnom zaokrúhlení nahor;s `exp = limit + 1` je to bežný prípad.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // BEZPEČNOSŤ: práve sme inicializovali prvky `..2`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // BEZPEČNOSŤ: práve sme inicializovali prvky `..1`.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}