//! Dekóduje hodnotu s pohyblivou rádovou čiarkou na jednotlivé časti a rozsahy chýb.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekódovaná konečná hodnota bez znamienka, takže:
///
/// - Pôvodná hodnota sa rovná `mant * 2^exp`.
///
/// - Akékoľvek číslo od `(mant - minus)*2^exp` do `(mant + plus)* 2^exp` sa zaokrúhli na pôvodnú hodnotu.
/// Rozsah je zahrnutý iba v prípade, že `inclusive` je `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Škálovaná mantisa.
    pub mant: u64,
    /// Dolný rozsah chýb.
    pub minus: u64,
    /// Horný rozsah chýb.
    pub plus: u64,
    /// Zdieľaný exponent v základe 2.
    pub exp: i16,
    /// Platí, ak je rozsah chýb vrátane.
    ///
    /// V IEEE 754 to platí, keď bola pôvodná mantisa párna.
    pub inclusive: bool,
}

/// Dekódovaná nepodpísaná hodnota.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Nekonečnosti, či už pozitívne alebo negatívne.
    Infinite,
    /// Nula, buď pozitívna alebo negatívna.
    Zero,
    /// Konečné čísla s ďalšími dekódovanými poľami.
    Finite(Decoded),
}

/// Typ s pohyblivou rádovou čiarkou, ktorý je možné `dekódovať`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Minimálna pozitívna normalizovaná hodnota.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Vráti znamienko (ak je záporné) a hodnota `FullDecoded` z daného čísla s pohyblivou rádovou čiarkou.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // susedia: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode vždy zachováva exponent, takže mantisa je upravená pre subnormály.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // susedia: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant, 1, exp)
                // kde maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // susedia: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}