//! Takmer priamy (ale mierne optimalizovaný) preklad Rust obrázka 3 v časti " Tlač čísel s pohyblivou rádovou čiarkou rýchlo a presne` [^ 1].
//!
//!
//! [^1]: Burger, RG a Dybvig, RK 1996. Tlač čísel s pohyblivou rádovou čiarkou
//!   rýchlo a presne.SIGPLAN Nie.31, 5 (máj 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// predpočítané polia číslic na 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// použiteľné iba keď `x < 16 * scale`;`scaleN` by malo byť `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Najkratšia implementácia režimu pre Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // je známe, že číslo `v` do formátu je:
    // - rovná sa `mant * 2^exp`;
    // - pred ním je pôvodný typ `(mant - 2 *minus)* 2^exp`;a
    // - za ktorým nasleduje `(mant + 2 *plus)* 2^exp` v pôvodnom type.
    //
    // `minus` a `plus` samozrejme nemôžu byť nulové.(pre nekonečna používame hodnoty mimo rozsah.) tiež predpokladáme, že je vygenerovaná aspoň jedna číslica, tj. `mant` tiež nemôže byť nula.
    //
    // to tiež znamená, že akékoľvek číslo medzi `low = (mant - minus)*2^exp` a `high = (mant + plus)* 2^exp` sa namapuje na toto presné číslo s pohyblivou desatinnou čiarkou, pričom hranice budú zahrnuté, keď bola pôvodná mantisa párna (tj. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` je `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // odhad `k_0` z pôvodných vstupov vyhovujúcich `10^(k_0-1) < high <= 10^(k_0+1)`.
    // pevná väzba `k` vyhovujúca `10^(k-1) < high <= 10^k` sa počíta neskôr.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // previesť `{mant, plus, minus} * 2^exp` do zlomkovej formy tak, aby:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // rozdeliť `mant` na `10^k`.teraz `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // oprava, keď `mant + plus > scale` (alebo `>=`).
    // v skutočnosti nemeníme `scale`, pretože môžeme namiesto toho preskočiť počiatočné násobenie.
    // teraz `scale < mant + plus <= scale * 10` a sme pripravení generovať číslice.
    //
    // všimnite si, že `d[0]`*môže byť* nula, keď `scale - plus < mant < scale`.
    // v takom prípade sa okamžite spustí podmienka zaokrúhľovania (nižšie `up`).
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // zodpovedá škálovaniu `scale` na 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // vyrovnávacia pamäť `(2, 4, 8) * scale` na generovanie číslic.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invarianty, kde `d[0..n-1]` sú zatiaľ generované číslice:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (teda `mant / scale < 10`), kde `d[i..j]` je skratka pre `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // vygenerovať jednu číslicu: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // toto je zjednodušený popis upraveného Dragonovho algoritmu.
        // veľa intermediárnych derivácií a úplnosti argumentov je pre pohodlie vynechaných.
        //
        // začnite s upravenými invarianty, pretože sme aktualizovali `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // predpokladajme, že `d[0..n-1]` je najkratšie zastúpenie medzi `low` a `high`, tj. `d[0..n-1]` spĺňa obe nasledujúce podmienky, ale `d[0..n-2]` nie:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektivita: číslice zaokrúhlené na `v`);a
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (posledná číslica je správna).
        //
        // druhá podmienka sa zjednodušuje na `2 * mant <= scale`.
        // riešenie invariantov z hľadiska `mant`, `low` a `high` prinesie jednoduchšiu verziu prvej podmienky: `-plus < mant < minus`.
        // od `-plus < 0 <= mant` máme správne najkratšie zastúpenie, keď `mant < minus` a `2 * mant <= scale`.
        // (prvý sa stane `mant <= minus`, keď je pôvodná mantisa párna.)
        //
        // keď druhá nedrží (`2 * mant> scale`), musíme zvýšiť poslednú číslicu.
        // to stačí na obnovenie tejto podmienky: už vieme, že generovanie číslic zaručuje `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // v takom prípade sa prvá podmienka stane `-plus < mant - scale < minus`.
        // od `mant < scale` po generácii máme `scale < mant + plus`.
        // (opäť sa to stane `scale <= mant + plus`, keď je pôvodná mantisa párna.)
        //
        // V skratke:
        // - zastaviť a zaokrúhliť `down` (ponechať číslice tak, ako sú), keď `mant < minus` (alebo `<=`).
        // - zastaviť a zaokrúhliť `up` (zväčšiť poslednú číslicu), keď `scale < mant + plus` (alebo `<=`).
        // - generuj inak.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // máme najkratšie zastúpenie, pokračujte v zaokrúhľovaní

        // obnoviť invarianty.
        // vďaka tomu sa algoritmus vždy končí: `minus` a `plus` sa vždy zväčšujú, ale `mant` je orezaný modulo `scale` a `scale` je pevný.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // zaokrúhlenie nahor sa stane, keď i) bola spustená iba podmienka zaokrúhlenia nahor, alebo ii) obidve podmienky boli spustené a roztrhnutie kravaty uprednostňuje zaokrúhľovanie nahor.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ak zaokrúhlenie nahor zmení dĺžku, mal by sa zmeniť aj exponent.
        // zdá sa, že táto podmienka je veľmi ťažko splnená (možno nemožná), ale tu sme iba v bezpečí a dôslední.
        //
        // BEZPEČNOSŤ: túto pamäť sme inicializovali vyššie.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // BEZPEČNOSŤ: túto pamäť sme inicializovali vyššie.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Presná a pevná implementácia režimu pre Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // odhad `k_0` z pôvodných vstupov vyhovujúcich `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // rozdeliť `mant` na `10^k`.teraz `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // oprava pri `mant + plus >= scale`, kde `plus / scale = 10^-buf.len() / 2`.
    // aby sme udržali pevnú veľkosť bignum, skutočne používame `mant + floor(plus) >= scale`.
    // v skutočnosti nemeníme `scale`, pretože môžeme namiesto toho preskočiť počiatočné násobenie.
    // opäť s najkratším algoritmom môže byť `d[0]` nula, ale nakoniec bude zaokrúhlená nahor.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // zodpovedá škálovaniu `scale` na 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ak pracujeme s obmedzením na poslednú číslicu, musíme pred samotným vykreslením skrátiť vyrovnávaciu pamäť, aby sme sa vyhli dvojitému zaokrúhľovaniu.
    //
    // všimnite si, že keď dôjde k zaokrúhľovaniu nahor, musíme opäť zväčšiť vyrovnávaciu pamäť!
    let mut len = if k < limit {
        // hops, nemôžeme vyrobiť ani jednu * číslicu.
        // to je možné, keď napríklad máme niečo ako 9.5 a zaokrúhľuje sa to na 10.
        // vrátime prázdny buffer, s výnimkou neskoršieho prípadu zaokrúhľovania, ku ktorému dôjde pri `k == limit` a musí vyprodukovať presne jednu číslicu.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // vyrovnávacia pamäť `(2, 4, 8) * scale` na generovanie číslic.
        // (to môže byť drahé, takže ich nevypočítajte, keď je vyrovnávacia pamäť prázdna.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // nasledujúce číslice sú všetky nuly, tu sa zastavíme, neskúšajte * neskúšať!radšej vyplňte zvyšné číslice.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // BEZPEČNOSŤ: túto pamäť sme inicializovali vyššie.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // zaokrúhľovanie nahor, ak zastavíme uprostred číslic, ak sú nasledujúce číslice presne 5 000 ..., skontrolujte predchádzajúcu číslicu a skúste ju zaokrúhliť na párne (tj. vyhnite sa zaokrúhľovaniu nahor, keď je predchádzajúca číslica párna).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // BEZPEČNOSŤ: `buf[len-1]` je inicializovaný.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ak zaokrúhlenie nahor zmení dĺžku, mal by sa zmeniť aj exponent.
        // ale bol od nás požadovaný pevný počet číslic, takže nemeňte medzipamäť ...
        // BEZPEČNOSŤ: túto pamäť sme inicializovali vyššie.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... pokiaľ nás namiesto toho nepožiadali o pevnú presnosť.
            // tiež musíme skontrolovať, že ak bol pôvodný buffer prázdny, ďalšiu číslicu je možné pridať iba pri `k == limit` (prípad edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // BEZPEČNOSŤ: túto pamäť sme inicializovali vyššie.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}