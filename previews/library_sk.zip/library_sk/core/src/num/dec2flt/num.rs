//! Úžitkové funkcie pre bignumy, ktoré nemajú príliš veľký zmysel na to, aby sa zmenili na metódy.

// FIXME Názov tohto modulu je trochu nešťastný, pretože aj iné moduly importujú `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Vyskúšajte, či skrátenie všetkých bitov menej významných ako `ones_place` zavádza relatívnu chybu menšiu, rovnú alebo väčšiu ako 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ak sú všetky zostávajúce bity nulové, je to= 0.5 ULP, inak> 0.5 Ak už nie sú žiadne bity (half_bit==0), nižšie správne vráti Equal.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Skonvertuje reťazec ASCII obsahujúci iba desatinné číslice na `u64`.
///
/// Nevykonáva kontroly pretečenia alebo neplatných znakov, takže ak si volajúci nedáva pozor, výsledkom je falošný pokus a znak panic (aj keď to nebude `unsafe`).
/// S prázdnymi reťazcami sa navyše zaobchádza ako s nulou.
/// Táto funkcia existuje, pretože
///
/// 1. použitie `FromStr` na `&[u8]` vyžaduje `from_utf8_unchecked`, čo je zlé, a
/// 2. zostavenie výsledkov `integral.parse()` a `fractional.parse()` je komplikovanejšie ako celá táto funkcia.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Skonvertuje reťazec číslic ASCII na bignum.
///
/// Rovnako ako `from_str_unchecked`, aj táto funkcia sa spolieha na to, že parser vyradí iné číslice.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Rozbalí bignum na 64 bitové celé číslo.Panics, ak je číslo príliš veľké.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Extrahuje rad bitov.

/// Index 0 je najmenej významný bit a rozsah je ako obvykle polovične otvorený.
/// Panics, ak je požiadaný o extrakciu viac bitov, ako je vhodné pre návratový typ.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}