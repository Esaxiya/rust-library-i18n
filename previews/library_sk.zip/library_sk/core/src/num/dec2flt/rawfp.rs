//! Bit funguje na pozitívnych plavákoch IEEE 754.Záporné čísla nie sú a nemusia byť spracované.
//! Normálne čísla s pohyblivou rádovou čiarkou majú kanonické znázornenie ako (frac, exp), takže hodnota je 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), kde N je počet bitov).
//!
//! Podnormality sú mierne odlišné a zvláštne, ale uplatňuje sa rovnaký princíp.
//!
//! Tu ich však reprezentujeme ako (sig, k) s f pozitívom, takže hodnota je f *
//! 2 <sup>e</sup> .Okrem toho, že "hidden bit" je explicitný, mení exponent takzvaným mantisovým posunom.
//!
//! Inými slovami, normálne plaváky sú napísané ako (1), ale tu sú napísané ako (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! (1) nazývame **zlomková reprezentácia** a (2)**integrálna reprezentácia**.
//!
//! Mnoho funkcií v tomto module pracuje iba s normálnymi číslami.Rutiny dec2flt konzervatívne používajú univerzálnu správnu pomalú cestu (Algoritmus M) pre veľmi malé a veľmi veľké počty.
//! Tento algoritmus potrebuje iba next_float(), ktorý spracováva podnormály a nuly.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Pomocný program trait, ktorý zabráni duplikovaniu v podstate všetkého konverzného kódu pre `f32` a `f64`.
///
/// Prečo je to potrebné, pozrite si komentár k dokumentu nadradeného modulu.
///
/// Nemalo by byť **nikdy** implementované pre iné typy alebo použité mimo modulu dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Typ používaný v `to_bits` a `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Vykoná surovú transmutáciu na celé číslo.
    fn to_bits(self) -> Self::Bits;

    /// Vykoná surovú transmutáciu z celého čísla.
    fn from_bits(v: Self::Bits) -> Self;

    /// Vráti kategóriu, do ktorej spadá toto číslo.
    fn classify(self) -> FpCategory;

    /// Vráti mantisu, exponent a znamienko ako celé čísla.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Dekóduje plavák.
    fn unpack(self) -> Unpacked;

    /// Odliatky z malého celého čísla, ktoré je možné presne znázorniť.
    /// Panic, ak nie je možné reprezentovať celé číslo, ďalší kód v tomto module zabezpečí, že sa tak nikdy nestane.
    fn from_int(x: u64) -> Self;

    /// Získava hodnotu 10 <sup>e</sup> z vopred vypočítanej tabuľky.
    /// Panics pre `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Čo hovorí názov.
    /// Je to jednoduchšie ako pevný kód, než žonglovať s podstatou a dúfať, že ho LLVM konštantná zloží.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Konzervatívna väzba na desatinné číslice vstupov, ktoré nemôžu spôsobiť pretečenie alebo nulu alebo
    /// podnormality.Pravdepodobne desatinný exponent maximálnej normálnej hodnoty, odtiaľ názov.
    const MAX_NORMAL_DIGITS: usize;

    /// Keď má najvýznamnejšia desatinná číslica miestnu hodnotu väčšiu ako táto, číslo sa určite zaokrúhli na nekonečno.
    ///
    const INF_CUTOFF: i64;

    /// Ak má najvýznamnejšia desatinná číslica miestnu hodnotu menšiu ako táto, číslo sa určite zaokrúhli na nulu.
    ///
    const ZERO_CUTOFF: i64;

    /// Počet bitov v exponente.
    const EXP_BITS: u8;

    /// Počet bitov v mysli,*vrátane* skrytého bitu.
    const SIG_BITS: u8;

    /// Počet bitov v mysli,*okrem* skrytého bitu.
    const EXPLICIT_SIG_BITS: u8;

    /// Maximálny právny exponent v zlomkovom zastúpení.
    const MAX_EXP: i16;

    /// Minimálny právny exponent v zlomkovom vyjadrení, s výnimkou podnormálov.
    const MIN_EXP: i16;

    /// `MAX_EXP` pre integrálne znázornenie, tj. s použitým posunom.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kódované (tj. s posunutím posunu)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` pre integrálne znázornenie, tj. s použitým posunom.
    const MIN_EXP_INT: i16;

    /// Maximálny normalizovaný význam v integrálnom zastúpení.
    const MAX_SIG: u64;

    /// Minimálny normalizovaný význam v integrálnom zastúpení.
    const MIN_SIG: u64;
}

// Väčšinou riešenie pre #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Vráti mantisu, exponent a znamienko ako celé čísla.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Predpätie exponenta + posun mantisy
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe nie je isté, či `as` správne zaokrúhľuje na všetkých platformách.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Vráti mantisu, exponent a znamienko ako celé čísla.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Predpätie exponenta + posun mantisy
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe nie je isté, či `as` správne zaokrúhľuje na všetkých platformách.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Skonvertuje `Fp` na najbližší typ float stroja.
/// Nezaobchádza s neobvyklými výsledkami.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f je 64 bit, takže xe má posun mantisy 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Zaokrúhlite 64-bitový význam na bity T::SIG_BITS s polovičnou vyrovnanosťou.
/// Nezaobchádza s pretečením exponenta.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Upravte posun mantisy
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Inverzia `RawFloat::unpack()` pre normalizované čísla.
/// Panics, ak význam alebo exponent nie sú platné pre normalizované čísla.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Odstráňte skrytý bit
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Upravte exponent pre posunutie exponenta a posun mantisy
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Nechajte bit so znamienkom na 0 ("+"), všetky naše čísla sú kladné
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Vytvorte subnormál.Mantisa 0 je povolená a vytvára nulu.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Zakódovaný exponent je 0, znamienkový bit je 0, takže musíme iba reinterpretovať bity.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Približne bignum s Fp.Zaokrúhľuje sa na ulicu 0.5 ULP s polovičnou vyrovnanosťou.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Pred indexom `start` sme odrezali všetky bity, tj. Efektívne posúvame doprava o množstvo `start`, takže to je tiež exponent, ktorý potrebujeme.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Okrúhle (half-to-even) v závislosti od skrátených bitov.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Nájde najväčšie číslo s pohyblivou rádovou čiarkou striktne menšie ako argument.
/// Nespracováva podnormály, nulu alebo podtečenie exponenta.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Nájdite najmenšie číslo s pohyblivou rádovou čiarkou, ktoré je striktne väčšie ako argument.
// Táto operácia je saturačná, tj. next_float(inf) ==inf.
// Na rozdiel od väčšiny kódov v tomto module táto funkcia spracováva nulu, podnormality a nekonečna.
// Rovnako ako všetky ostatné kódy tu, sa však nezaoberá NaN a zápornými číslami.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Zdá sa to príliš dobré, aby to bola pravda, ale funguje to.
        // 0.0 je zakódované ako slovo s nulovou hodnotou.Subnormály sú 0x000m ... m, kde m je mantisa.
        // Najmä najmenšia subnormálna je 0x0 ... 01 a najväčšia je 0x000F ... F.
        // Najmenšie bežné číslo je 0x0010 ... 0, takže aj tento rohový prípad funguje.
        // Ak prírastok pretečie mantisou, nosný bit zvýši exponent tak, ako chceme, a bity mantisy sa stanú nulovými.
        // Kvôli konvencii skrytých bitov je to tiež presne to, čo chceme!
        // Nakoniec f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}