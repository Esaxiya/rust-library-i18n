//! Rôzne algoritmy z článku.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Počet mantinelov vo Fp
const P: u32 = 64;

// Jednoducho uložíme najlepšiu aproximáciu pre exponenty *all*, takže premennú "h" a súvisiace podmienky môžeme vynechať.
// Takto sa vymení výkon za pár kilobajtov priestoru.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Vo väčšine architektúr majú operácie s pohyblivou rádovou čiarkou explicitnú veľkosť bitu, preto sa presnosť výpočtu určuje na základe jednotlivých operácií.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Na x86 sa x87 FPU používa na plavákové operácie, ak nie sú k dispozícii rozšírenia SSE/SSE2.
// x87 FPU štandardne pracuje s 80 bitmi presnosti, čo znamená, že operácie sa zaokrúhlia na 80 bitov, čo spôsobí dvojité zaokrúhlenie, keď sú hodnoty nakoniec reprezentované ako
//
// 32/64 bitové pohyblivé hodnoty.Aby sa to prekonalo, možno riadiace slovo FPU nastaviť tak, aby sa výpočty vykonávali v požadovanej presnosti.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Štruktúra použitá na zachovanie pôvodnej hodnoty riadiaceho slova FPU, aby bolo možné ju obnoviť pri zrušení štruktúry.
    ///
    ///
    /// x87 FPU je 16-bitový register, ktorého polia sú nasledujúce:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentácia pre všetky polia je k dispozícii v príručke pre vývojárov softvéru IA-32 Architectures (zväzok 1).
    ///
    /// Jediné pole, ktoré je relevantné pre nasledujúci kód, je PC, Precision Control.
    /// Toto pole určuje presnosť operácií vykonávaných FPU.
    /// Môže byť nastavený na:
    ///  - 0b00, presnosť jedna, tj. 32 bitov
    ///  - 0b10, dvojnásobná presnosť, tj. 64 bitov
    ///  - 0b11, dvojnásobná rozšírená presnosť, tj. 80 bitov (predvolený stav) Hodnota 0b01 je vyhradená a nemala by sa používať.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // BEZPEČNOSŤ: inštrukcia `fldcw` bola skontrolovaná, aby bolo možné s ňou správne pracovať
        // akýkoľvek `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Na podporu LLVM 8 a LLVM 9 používame syntax ATT.
                options(att_syntax, nostack),
            )
        }
    }

    /// Nastaví pole presnosti FPU na `T` a vráti `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Vypočítajte hodnotu poľa Precision Control, ktorá je vhodná pre `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bitov
            8 => 0x0200, // 64 bitov
            _ => 0x0300, // predvolené, 80 bitov
        };

        // Získajte pôvodnú hodnotu riadiaceho slova a obnovte ho neskôr, keď dôjde k zrušeniu štruktúry `FPUControlWord` BEZPEČNOSŤ: inštrukcia `fnstcw` bola skontrolovaná, aby mohla správne pracovať s akýmkoľvek `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Na podporu LLVM 8 a LLVM 9 používame syntax ATT.
                options(att_syntax, nostack),
            )
        }

        // Nastavte riadiace slovo na požadovanú presnosť.
        // To sa dosiahne maskovaním starej presnosti (bity 8 a 9, 0x300) a jej nahradením príznakom presnosti vypočítaným vyššie.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Rýchla cesta Bellerophonu pomocou celých čísel a plavákov strojovej veľkosti.
///
/// Toto sa extrahuje do samostatnej funkcie, aby sa o ňu dalo pokúsiť pred vytvorením bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Porovnáme presnú hodnotu s hodnotou MAX_SIG na konci, ide len o rýchle a lacné odmietnutie (a tiež zbaví zvyšok kódu obáv z podtečenia).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Rýchla cesta zásadne závisí od zaokrúhlenia aritmetiky na správny počet bitov bez medzikrúžkovania.
    // Na x86 (bez SSE alebo SSE2) to vyžaduje, aby sa zmenila presnosť zásobníka x87 FPU tak, aby sa priamo zaokrúhľoval na bit 64/32.
    // Funkcia `set_precision` sa stará o nastavenie precíznosti na architektúrach, ktoré ju vyžadujú nastavením zmenou globálneho stavu (ako napríklad kontrolné slovo x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Prípad e <0 nie je možné zložiť do druhého branch.
    // Výsledkom záporných právomocí je opakujúca sa zlomková časť v binárnej sústave, ktorá je zaokrúhlená, čo spôsobuje skutočné (a občas dosť významné!) Chyby v konečnom výsledku.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritmus Bellerophon je triviálny kód odôvodnený netriviálnou numerickou analýzou.
///
/// Zaokrúhli písmeno " f` na plavák s 64-bitovým významom a vynásobí ho najlepšou aproximáciou `10^e` (v rovnakom formáte s pohyblivou rádovou čiarkou).Na dosiahnutie správneho výsledku to často stačí.
/// Ak je však výsledok blízko polovice medzi dvoma susednými plavákmi (ordinary), zložená chyba zaokrúhlenia vynásobením dvoch aproximácií znamená, že výsledok môže byť vypnutý o niekoľko bitov.
/// Keď sa to stane, iteračný algoritmus R veci napraví.
///
/// Ručne zvlnená "close to halfway" je numerickou analýzou v článku precízna.
/// Slovami Clingera:
///
/// > Slop, vyjadrený v jednotkách najmenej významného bitu, je inkluzívnou hranicou chyby
/// > akumulované počas výpočtu pohyblivej rádovej čiarky aproximácie na f * 10 ^ e.(Sklon je
/// > nie je viazaný na skutočnú chybu, ale ohraničuje rozdiel medzi aproximáciou z a
/// > najlepšia možná aproximácia, ktorá využíva p bitov významu.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Prípady abs(e) <log5(2^N) sú v fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Je sklon dosť veľký na to, aby sa zmenil pri zaokrúhľovaní na n bitov?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iteračný algoritmus, ktorý zlepšuje aproximáciu pohyblivej rádovej čiarky `f * 10^e`.
///
/// Každá iterácia priblíži jednu jednotku na poslednom mieste, čo sa samozrejme konverguje strašne dlho, ak je `z0` ešte mierne vypnutá.
/// Našťastie, keď sa použije ako náhrada pre Bellerophon, východisková aproximácia je vypnutá najviac o jednu ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Nájdite kladné celé čísla `x`, `y` také, aby `x / y` bolo presne `(f *10^e) / (m* 2^k)`.
        // To nielenže zabráni zvládnutiu znakov `e` a `k`, ale tiež eliminujeme silu dvoch spoločných pre `10^e` a `2^k`, aby sme čísla zmenšili.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Toto je napísané trochu trápne, pretože naše bignumy nepodporujú záporné čísla, takže používame informácie o absolútnej hodnote + znamienko.
        // Násobenie s m_digits nemôže pretekať.
        // Ak sú `x` alebo `y` dostatočne veľké na to, aby sme sa museli obávať pretečenia, potom sú tiež dostatočne veľké na to, aby `make_ratio` znížil zlomok o faktor 2 ^ 64 alebo viac.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Už viac nepotrebujete x, uložte si clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Potrebujete ešte, urobte si kópiu.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Vzhľadom na to, že `x = f` a `y = m`, kde `f` predstavujú vstupné desatinné číslice ako obvykle a `m` je význam aproximácie s pohyblivou rádovou čiarkou, urobte pomer `x / y` rovný `(f *10^e) / (m* 2^k)`, prípadne znížený o silu dvoch, oba majú spoločné.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, až na to, že zlomok znížime o nejakú mocninu dvoch.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m To nemôže pretekať, pretože to vyžaduje kladné `e` a záporné `k`, čo sa môže stať iba pri hodnotách extrémne blízkych 1, čo znamená, že `e` a `k` budú pomerne malé.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Ani toto nemôže pretekať, viď vyššie.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), opäť zníženie spoločnou silou dvoch.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Koncepčne je Algoritmus M najjednoduchší spôsob, ako previesť desatinné miesto na plavák.
///
/// Vytvárame pomer, ktorý sa rovná `f * 10^e`, potom vrháme mocniny dvoch, kým neposkytne platný floatový význam.
/// Binárny exponent `k` je počet, koľkokrát sme vynásobili čitateľa alebo menovateľa dvoma, tj. Vždy, keď sa `f *10^e` rovná `(u / v)* 2^k`.
/// Keď sme zistili význam, stačí zaokrúhliť prehliadku zvyšku rozdelenia, čo sa deje v pomocných funkciách ďalej v texte.
///
///
/// Tento algoritmus je veľmi pomalý, dokonca aj pri optimalizácii popísanej v `quick_start()`.
/// Je to však najjednoduchší z algoritmov na prispôsobenie pre výsledky pretečenia, podtečenia a podnormálnych výsledkov.
/// Táto implementácia prevezme kontrolu nad Bellerophonom a Algorithmom R.
/// Detekcia podtečenia a pretečenia je ľahká: Tento pomer stále nie je významom rozsahu, napriek tomu bol dosiahnutý exponent minimum/maximum.
/// V prípade pretečenia jednoducho vrátime nekonečno.
///
/// Zaobchádzanie s podtečením a podnormami je zložitejšie.
/// Jedným veľkým problémom je, že s minimálnym exponentom môže byť pomer stále príliš veľký na význam.
/// Podrobnosti nájdete v časti underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME možná optimalizácia: zovšeobecniť big_to_fp, aby sme tu mohli urobiť ekvivalent fp_to_float(big_to_fp(u)), iba bez dvojitého zaokrúhlenia.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Musíme sa zastaviť na minimálnom exponente, ak počkáme do `k < T::MIN_EXP_INT`, potom by sme boli dvojnásobne vypnutí.
            // To však nanešťastie znamená, že musíme rozlišovať bežné čísla s minimálnym exponentom.
            // FIXME nájdete elegantnejšiu formuláciu, ale vykonajte test `tiny-pow10` a uistite sa, že je skutočne správny!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Preskočí väčšinu iterácií algoritmu kontrolou dĺžky bitov.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitová dĺžka je odhadom logaritmu dvoch základov a log(u / v) = log(u), log(v).
    // Odhad je vypnutý najviac o 1, ale vždy podhodnotený, takže chyba na log(u) a log(v) je rovnakého znamienka a zruší sa (ak sú obidve veľké).
    // Preto je chyba pre log(u / v) tiež najviac jedna.
    // Cieľový pomer je taký, kde u/v je v významnom rozsahu.Teda naša podmienka ukončenia je log2(u / v), čo sú významné bity, plus/minus.
    // FIXME Pohľad na druhý bit by mohol vylepšiť odhad a vyhnúť sa ďalším deleniam.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow alebo subnormal.Nechajte to na hlavnú funkciu.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Pretečenie.Nechajte to na hlavnú funkciu.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Pomer nie je významovým parametrom v rozsahu s minimálnym exponentom, takže musíme zaokrúhliť prebytočné bity a podľa toho prispôsobiť exponent.
    // Skutočná hodnota teraz vyzerá takto:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(zastúpené rem)
    //
    // Preto keď sú zaokrúhlené bity!= 0.5 ULP, samy rozhodujú o zaokrúhľovaní.
    // Ak sú rovnaké a zvyšok je nenulový, je potrebné hodnotu zaokrúhliť nahor.
    // Iba v prípade, že zaokrúhlené bity sú 1/2 a zvyšok je nula, máme situáciu polovičného vyrovnania.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Bežné zaokrúhľovanie na párne, zahmlievané tým, že sa musí zaokrúhľovať na základe zvyšku rozdelenia.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}