//! Implementácia čísla (bignum) na mieru s ľubovoľnou presnosťou.
//!
//! Toto je navrhnuté tak, aby sa zabránilo alokácii haldy na úkor pamäte zásobníka.
//! Najpoužívanejší typ bignum, `Big32x40`, je obmedzený na 32 × 40=1 280 bitov a zaberie najviac 160 bajtov zásobníka pamäte.
//! To je viac ako dosť na to, aby sa všetky možné konečné hodnoty `f64` skompletizovali.
//!
//! V zásade je možné mať viac typov bignum pre rôzne vstupy, nerobíme to však preto, aby sme sa vyhli nafúknutiu kódu.
//!
//! Každé bignum je stále sledované pre skutočné využitie, takže to zvyčajne nevadí.
//!

// Tento modul je iba pre dec2flt a flt2dec a iba verejný kvôli koretestom.
// Nie je zámerom nikdy sa stabilizovať.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// Aritmetické operácie vyžadované bignummi.
pub trait FullOps: Sized {
    /// Vráti `(carry', v')` také, že `carry' * 2^W + v' = self + other + carry`, kde `W` je počet bitov v `Self`.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// Vráti `(carry', v')` také, že `carry'*2^W + v' = self* other + carry`, kde `W` je počet bitov v `Self`.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// Vráti `(carry', v')` také, že `carry'*2^W + v' = self* other + other2 + carry`, kde `W` je počet bitov v `Self`.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// Vráti `(quo, rem)` také, ako `borrow *2^W + self = quo* other + rem` a `0 <= rem < other`, kde `W` je počet bitov v `Self`.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // To nemôže pretekať;výstup je medzi `0` a `2 * 2^nbits - 1`.
                    // FIXME: optimalizuje to LLVM na ADC alebo podobne?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // To nemôže pretekať;
                    // výstup je medzi `0` a `2^nbits * (2^nbits - 1)`.
                    // FIXME: optimalizuje to LLVM na ADC alebo podobne?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // To nemôže pretekať;
                    // výstup je medzi `0` a `2^nbits * (2^nbits - 1)`.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // To nemôže pretekať;výstup je medzi `0` a `other * (2^nbits - 1)`.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // Povolenie nájdete v dokumente RFC #521.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// Tabuľka mocností 5 reprezentovateľných v čísliciach.Konkrétne najväčšia hodnota {u8, u16, u32}, ktorá je silou päť, plus zodpovedajúci exponent.
/// Používa sa v `mul_pow5`.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// Celé číslo s ľubovoľnou presnosťou (do určitého limitu) pridelené v zásobníku.
        ///
        /// Toto je podporené poľom pevnej veľkosti daného typu ("digit").
        /// Aj keď pole nie je príliš veľké (zvyčajne asi sto bajtov), jeho bezohľadné kopírovanie môže mať za následok zásah do výkonu.
        ///
        /// Toto teda zámerne nie je `Copy`.
        ///
        /// Všetky operácie dostupné pre bignums panic v prípade pretečenia.
        /// Volajúci je zodpovedný za použitie dostatočne veľkých typov bignum.
        pub struct $name {
            /// Jeden plus posun k maximálnemu použitému "digit".
            /// To sa neznižuje, takže si uvedomte poradie výpočtu.
            /// `base[size..]` by mala byť nula.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` predstavuje `a + b *2^W + c* 2^(2W) + ...`, kde `W` je počet bitov v type číslice.
            base: [$ty; $n],
        }

        impl $name {
            /// Z jednej číslice sa vytvorí bignum.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// Vytvára bignum z hodnoty `u64`.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// Vráti interné číslice ako rez `[a, b, c, ...]`, takže číselná hodnota je `a + b *2^W + c* 2^(2W) + ...`, kde `W` je počet bitov v type číslice.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// Vráti `i`-tý bit, kde bit 0 je najmenej významný.
            /// Inými slovami, bit s hmotnosťou `2^i`.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// Vráti `true`, ak je bignum nula.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// Vráti počet bitov potrebný na vyjadrenie tejto hodnoty.
            /// Upozorňujeme, že nula sa považuje za potrebnú 0 bitov.
            pub fn bit_length(&self) -> usize {
                // Preskočte najvýznamnejšie číslice, ktoré sú nulové.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // Neexistujú nenulové číslice, tj počet je nula.
                    return 0;
                }
                // To by sa dalo optimalizovať pomocou leading_zeros() a bitových posunov, ale to asi za to nestojí.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// Pridá k sebe `other` a vráti svoju vlastnú premenlivú referenciu.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// Odpočíta `other` od seba a vráti svoju vlastnú premenlivú referenciu.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// Násobí sa číslom `other` a vráti svoju vlastnú premenlivú referenciu.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// Násobí sa `2^bits` a vráti svoju vlastnú premenlivú referenciu.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // posun o `digits * digitbits` bitov
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // posun o `bits` bitov
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. číslice] je nula, nie je potrebné radiť
                }

                self.size = sz;
                self
            }

            /// Násobí sa `5^e` a vráti svoju vlastnú premenlivú referenciu.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // Na 2 ^ n je presne n koncových núl a jediné relevantné veľkosti číslic sú postupné mocniny dvoch, takže je to vhodný index pre tabuľku.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // Znásobte to s čo najväčšou jednocifernou silou čo najdlhšie ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... a potom dohrajte zvyšok.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// Vynásobí sa číslom opísaným v `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (kde `W` je počet bitov v type číslice) a vráti svoju vlastnú premenlivú referenciu.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // vnútorná rutina.funguje najlepšie, keď aa.len() <= bb.len().
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// Rozdelí sa na `other` o veľkosti číslic a vráti svoju vlastnú premenlivú referenciu *a* zvyšok.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// Rozdeľte seba ďalším bignumom, prepíšu `q` kvocientom a `r` zvyškom.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // Hlúpy pomalý base-2 dlhý diel prevzatý z
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME používa na dlhšie delenie väčšiu základňu ($ty).
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Nastavte bit `i` q na 1.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// Typ číslice pre `Big32x40`.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// tento sa používa iba na testovanie.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}