//! Typy chýb pri prevode na integrálne typy.

use crate::convert::Infallible;
use crate::fmt;

/// Typ chyby sa vrátil, keď zlyhala kontrola prevereného integrálneho typu.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Priraďte sa skôr ako k nátlaku, aby ste sa ubezpečili, že kód ako `From<Infallible> for TryFromIntError` vyššie bude naďalej fungovať, keď sa z `Infallible` stane alias `!`.
        //
        //
        match never {}
    }
}

/// Chyba, ktorá sa môže vrátiť pri analýze celého čísla.
///
/// Táto chyba sa používa ako typ chyby pre funkcie `from_str_radix()` na primitívnych celočíselných typoch, napríklad [`i8::from_str_radix`].
///
/// # Možné príčiny
///
/// Medzi inými príčinami môže byť `ParseIntError` vyhodený z dôvodu vedúceho alebo koncového prázdneho miesta v reťazci, napr. Keď je získaný zo štandardného vstupu.
///
/// Použitie metódy [`str::trim()`] zaručuje, že pred analýzou nezostanú žiadne medzery.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum na ukladanie rôznych typov chýb, ktoré môžu spôsobiť zlyhanie analýzy celého čísla.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Analyzovaná hodnota je prázdna.
    ///
    /// Okrem iného bude tento variant zostavený pri analýze prázdneho reťazca.
    Empty,
    /// Obsahuje neplatnú číslicu v danom kontexte.
    ///
    /// Okrem iných príčin bude tento variant zostavený pri analýze reťazca, ktorý obsahuje znak iný ako ASCII.
    ///
    /// Tento variant je tiež konštruovaný, keď je `+` alebo `-` nesprávne umiestnený v reťazci buď sám o sebe, alebo uprostred čísla.
    ///
    ///
    InvalidDigit,
    /// Celé číslo je príliš veľké na to, aby sa dalo uložiť do typu cieľového celého čísla.
    PosOverflow,
    /// Celé číslo je príliš malé na to, aby sa dalo uložiť do typu cieľového celého čísla.
    NegOverflow,
    /// Hodnota bola nula
    ///
    /// Tento variant bude emitovaný, keď má syntaktický reťazec hodnotu nula, čo by bolo pre nenulové typy nelegálne.
    ///
    Zero,
}

impl ParseIntError {
    /// Na výstup odošle podrobnú príčinu analýzy celého čísla, ktoré zlyhalo.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}