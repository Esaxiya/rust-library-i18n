macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Najmenšia hodnota, ktorú môže reprezentovať tento celočíselný typ.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Najväčšia hodnota, ktorú môže reprezentovať tento celočíselný typ.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Veľkosť tohto celého čísla v bitoch.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Skonvertuje rez reťazca v danom základe na celé číslo.
        ///
        /// Očakáva sa, že reťazec bude voliteľný znak `+` alebo `-`, za ktorým budú nasledovať číslice.
        /// Predné a koncové medzery predstavujú chybu.
        /// Číslice sú podmnožinou týchto znakov, v závislosti od `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Táto funkcia panics, ak `radix` nie je v rozmedzí od 2 do 36.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Vráti počet jednotiek v binárnom zastúpení `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Vráti počet núl v binárnom zastúpení `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Vráti počet úvodných núl v binárnej reprezentácii `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Vráti počet koncových núl v binárnej reprezentácii `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Vráti počet vedúcich v binárnom zastúpení `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Vráti počet koncových v binárnom zastúpení `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Posunie bity doľava o zadanú hodnotu, `n`, pričom skrátené bity zabalí na koniec výsledného celého čísla.
        ///
        ///
        /// Upozorňujeme, že to nie je rovnaká operácia ako operátor radenia `<<`!
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Posunie bity doprava o určené množstvo, `n`, pričom skrátené bity zabalí na začiatok výsledného celého čísla.
        ///
        ///
        /// Upozorňujeme, že to nie je rovnaká operácia ako operátor radenia `>>`!
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Obráti poradie bajtov celého čísla.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// nech m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Obráti poradie bitov v celom čísle.
        /// Z najmenej významného bitu sa stane najvýznamnejší bit, z druhého najmenej významného bitu sa stane druhý najvýznamnejší bit atď.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// nech m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Prevedie celé číslo z veľkého endianu na endiannosť cieľa.
        ///
        /// Na big endiane je to neop-op.Na malom endiane sú byty vymenené.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ak cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Skonvertuje celé číslo z malého endianu na endianitu cieľa.
        ///
        /// Na Little Endiane je to zakázané.Na big endiane sú byty vymenené.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ak cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Skonvertuje `self` na veľký endian z endianity cieľa.
        ///
        /// Na big endiane je to neop-op.Na malom endiane sú byty vymenené.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ak cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // alebo nebyť?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Skonvertuje `self` na malý endian z endianity cieľa.
        ///
        /// Na Little Endiane je to zakázané.Na big endiane sú byty vymenené.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// ak cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Skontrolované pridanie celého čísla.
        /// Vypočíta `self + rhs` a vráti `None`, ak dôjde k pretečeniu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nezačiarknuté pridanie celého čísla.Vypočíta `self + rhs` za predpokladu, že nemôže dôjsť k pretečeniu.
        /// To má za následok nedefinované správanie, keď
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Skontrolované odčítanie celého čísla.
        /// Vypočíta `self - rhs` a vráti `None`, ak dôjde k pretečeniu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nezačiarknuté celé odčítanie.Vypočíta `self - rhs` za predpokladu, že nemôže dôjsť k pretečeniu.
        /// To má za následok nedefinované správanie, keď
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Skontrolované násobenie celých čísel.
        /// Vypočíta `self * rhs` a vráti `None`, ak dôjde k pretečeniu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nezačiarknuté násobenie celých čísel.Vypočíta `self * rhs` za predpokladu, že nemôže dôjsť k pretečeniu.
        /// To má za následok nedefinované správanie, keď
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Skontrolované celočíselné rozdelenie.
        /// Vypočíta `self / rhs` a vráti `None`, ak `rhs == 0` alebo rozdelenie vedie k pretečeniu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // BEZPEČNOSŤ: div nulou a INT_MIN boli skontrolované vyššie
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Skontrolované euklidovské rozdelenie.
        /// Vypočíta `self.div_euclid(rhs)` a vráti `None`, ak `rhs == 0` alebo rozdelenie vedie k pretečeniu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Skontrolovaný zvyšok celého čísla.
        /// Vypočíta `self % rhs` a vráti `None`, ak `rhs == 0` alebo rozdelenie vedie k pretečeniu.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // BEZPEČNOSŤ: div nulou a INT_MIN boli skontrolované vyššie
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Skontrolovaný euklidovský zvyšok.
        /// Vypočíta `self.rem_euclid(rhs)` a vráti `None`, ak `rhs == 0` alebo rozdelenie vedie k pretečeniu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Skontrolovaná negácia.
        /// Vypočíta `-self` a vráti `None`, ak `self == MIN`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Skontrolovaný posun vľavo.
        /// Vypočíta `self << rhs` a vráti `None`, ak je `rhs` väčší alebo rovný počtu bitov v `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Skontrolovaný posun doprava.
        /// Vypočíta `self >> rhs` a vráti `None`, ak je `rhs` väčší alebo rovný počtu bitov v `self`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Skontrolovaná absolútna hodnota.
        /// Vypočíta `self.abs()` a vráti `None`, ak `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Skontrolovaná umocňovanie.
        /// Vypočíta `self.pow(exp)` a vráti `None`, ak dôjde k pretečeniu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // od exp!=0, nakoniec exp musí byť 1.
            // S posledným bitom exponenta sa vysporiadajte osobitne, pretože následné zarovnávanie bázy nie je potrebné a môže spôsobiť zbytočné pretečenie.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Nasýtenie celého čísla.
        /// Vypočítava `self + rhs` a nasýti sa na numerických hraniciach namiesto toho, aby pretekal.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Nasýtenie celého čísla.
        /// Vypočítava `self - rhs` a nasýti sa na numerických hraniciach namiesto toho, aby pretekal.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Nasýtenie celého čísla.
        /// Vypočíta `-self` a vráti `MAX`, ak `self == MIN` namiesto pretečenia.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Sýta absolútna hodnota.
        /// Vypočíta `self.abs()` a vráti `MAX`, ak `self == MIN` namiesto pretečenia.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Nasýtenie celého čísla.
        /// Vypočítava `self * rhs` a nasýti sa na numerických hraniciach namiesto toho, aby pretekal.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Nasýtenie celého čísla.
        /// Vypočítava `self.pow(exp)` a nasýti sa na numerických hraniciach namiesto toho, aby pretekal.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Balenie (modular) navyše.
        /// Vypočítava `self + rhs` a zalomí sa na hranici typu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Zabalené odčítanie (modular).
        /// Vypočítava `self - rhs` a zalomí sa na hranici typu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Zbalenie násobenia (modular).
        /// Vypočítava `self * rhs` a zalomí sa na hranici typu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Zabaľovacia divízia (modular).Vypočítava `self / rhs` a zalomí sa na hranici typu.
        ///
        /// Jediným prípadom, keď k takémuto zabaleniu môže dôjsť, je rozdelenie `MIN / -1` na podpísaný typ (kde `MIN` je záporná minimálna hodnota pre typ);toto je ekvivalent `-MIN`, kladná hodnota, ktorá je príliš veľká na to, aby predstavovala v type.
        /// V takom prípade táto funkcia vráti samotnú `MIN`.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Ovíjajúca sa euklidovská divízia.
        /// Vypočítava `self.div_euclid(rhs)` a zalomí sa na hranici typu.
        ///
        /// K zabaleniu dôjde iba v `MIN / -1` na podpísanom type (kde `MIN` je záporná minimálna hodnota pre typ).
        /// Toto je ekvivalent k `-MIN`, kladnej hodnote, ktorá je príliš veľká na to, aby predstavovala v type.
        /// V takom prípade táto metóda vráti samotný `MIN`.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Zbalenie zvyšku (modular).Vypočítava `self % rhs` a zalomí sa na hranici typu.
        ///
        /// Takéto zabalenie sa v skutočnosti nikdy nevyskytuje matematicky;artefakty implementácie spôsobujú, že `x % y` je neplatný pre `MIN / -1` na podpísanom type (kde `MIN` je záporná minimálna hodnota).
        ///
        /// V takom prípade táto funkcia vráti `0`.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Baliaci euklidovský zvyšok.Vypočítava `self.rem_euclid(rhs)` a zalomí sa na hranici typu.
        ///
        /// K zabaleniu dôjde iba v `MIN % -1` na podpísanom type (kde `MIN` je záporná minimálna hodnota pre typ).
        /// V takom prípade táto metóda vráti 0.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Zabalená negácia (modular).Vypočítava `-self` a zalomí sa na hranici typu.
        ///
        /// Jediným prípadom, keď môže dôjsť k takémuto zabaleniu, je prípad, keď jeden neguje `MIN` na podpísanom type (kde `MIN` je negatívna minimálna hodnota pre typ);toto je kladná hodnota, ktorá je príliš veľká na to, aby predstavovala v type.
        /// V takom prípade táto funkcia vráti samotnú `MIN`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic bez bitového posunu vľavo;poskytne `self << mask(rhs)`, kde `mask` odstráni všetky bity `rhs` vyššieho rádu, ktoré by spôsobili, že posun prekročí bitovú šírku typu.
        ///
        /// Upozorňujeme, že toto nie je * rovnaké ako otočenie doľava;RHS ovíjacej smeny vľavo je obmedzená na rozsah typu, skôr ako sa bity posunuté z LHS vracajú na druhý koniec.
        ///
        /// Všetky primitívne typy celých čísel implementujú funkciu [`rotate_left`](Self::rotate_left), čo môže byť to, čo chcete.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // BEZPEČNOSŤ: maskovanie typu bitsize zaručuje, že sa nebudeme radiť
            // mimo hranice
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic bez bitového posunu doprava;poskytne `self >> mask(rhs)`, kde `mask` odstráni všetky bity `rhs` vyššieho rádu, ktoré by spôsobili, že posun prekročí bitovú šírku typu.
        ///
        /// Upozorňujeme, že to nie je * to isté ako otočenie doprava;RHS ovíjacej posunovacej pravice je obmedzená na rozsah typu, skôr ako sa bity posunuté z LHS vracajú na druhý koniec.
        ///
        /// Všetky primitívne typy celých čísel implementujú funkciu [`rotate_right`](Self::rotate_right), čo môže byť to, čo chcete.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // BEZPEČNOSŤ: maskovanie typu bitsize zaručuje, že sa nebudeme radiť
            // mimo hranice
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Zabalenie absolútnej hodnoty (modular).Vypočítava `self.abs()` a zalomí sa na hranici typu.
        ///
        /// Jediným prípadom, keď môže dôjsť k takémuto zabaleniu, je situácia, keď sa pre typ použije absolútna hodnota zápornej minimálnej hodnoty;toto je kladná hodnota, ktorá je príliš veľká na to, aby predstavovala v type.
        /// V takom prípade táto funkcia vráti samotnú `MIN`.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Vypočíta absolútnu hodnotu `self` bez akejkoľvek zábrany alebo paniky.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Zabalenie exponenciácie (modular).
        /// Vypočítava `self.pow(exp)` a zalomí sa na hranici typu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // od exp!=0, nakoniec exp musí byť 1.
            // S posledným bitom exponenta sa vysporiadajte osobitne, pretože následné zarovnávanie bázy nie je potrebné a môže spôsobiť zbytočné pretečenie.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Vypočíta `self` + `rhs`
        ///
        /// Vráti n-ticu sčítania spolu s logickou hodnotou, ktorá označuje, či by došlo k aritmetickému pretečeniu.
        /// Ak by došlo k pretečeniu, vráti sa zabalená hodnota.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Vypočíta `self`, `rhs`
        ///
        /// Vráti n-ticu odčítania spolu s logickou hodnotou, ktorá označuje, či by došlo k aritmetickému pretečeniu.
        /// Ak by došlo k pretečeniu, vráti sa zabalená hodnota.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Vypočíta násobenie `self` a `rhs`.
        ///
        /// Vráti n-ticu násobenia spolu s logickou hodnotou, ktorá označuje, či by došlo k aritmetickému pretečeniu.
        /// Ak by došlo k pretečeniu, vráti sa zabalená hodnota.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, pravda));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Vypočíta deliteľ, keď je `self` vydelené `rhs`.
        ///
        /// Vráti n-ticu deliteľa spolu s logickou hodnotou, ktorá označuje, či by došlo k aritmetickému pretečeniu.
        /// Ak dôjde k pretečeniu, potom sa vráti self.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Vypočíta kvocient euklidovskej divízie `self.div_euclid(rhs)`.
        ///
        /// Vráti n-ticu deliteľa spolu s logickou hodnotou, ktorá označuje, či by došlo k aritmetickému pretečeniu.
        /// Ak dôjde k pretečeniu, vráti sa `self`.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Vypočíta zvyšok, keď je `self` vydelené `rhs`.
        ///
        /// Vráti n-ticu zvyšku po rozdelení spolu s logickou hodnotou, ktorá označuje, či by došlo k aritmetickému pretečeniu.
        /// Ak dôjde k pretečeniu, vráti sa 0.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Pretekajúci euklidovský zvyšok.Vypočíta `self.rem_euclid(rhs)`.
        ///
        /// Vráti n-ticu zvyšku po rozdelení spolu s logickou hodnotou, ktorá označuje, či by došlo k aritmetickému pretečeniu.
        /// Ak dôjde k pretečeniu, vráti sa 0.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Neguje seba, preteká, ak sa rovná minimálnej hodnote.
        ///
        /// Vráti n-ticu negovanej verzie self spolu s logickou hodnotou, ktorá označuje, či došlo k pretečeniu.
        /// Ak je `self` minimálna hodnota (napr. `i32::MIN` pre hodnoty typu `i32`), potom sa minimálna hodnota vráti znova a `true` sa vráti v prípade pretečenia.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Posunie sa vľavo o `rhs` bitov.
        ///
        /// Vráti n-ticu posunutej verzie funkcie self spolu s booleanom, ktorý označuje, či bola hodnota posunu väčšia alebo rovná počtu bitov.
        /// Ak je hodnota posunu príliš veľká, potom je hodnota maskovaná (N-1), kde N je počet bitov, a táto hodnota sa potom použije na vykonanie posunu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, pravda));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Zaradí sa doprava o `rhs` bitov.
        ///
        /// Vráti n-ticu posunutej verzie funkcie self spolu s booleanom, ktorý označuje, či bola hodnota posunu väčšia alebo rovná počtu bitov.
        /// Ak je hodnota posunu príliš veľká, potom je hodnota maskovaná (N-1), kde N je počet bitov, a táto hodnota sa potom použije na vykonanie posunu.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, pravda));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Vypočíta absolútnu hodnotu `self`.
        ///
        /// Vráti n-ticu absolútnej verzie self spolu s booleanom, ktorý označuje, či došlo k pretečeniu.
        /// Ak je sebestačná minimálna hodnota
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// potom sa vráti minimálna hodnota a hodnota true sa vráti pre prípad pretečenia.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Zvyšuje seba k sile `exp` pomocou umocňovania druhou mocninou.
        ///
        /// Vráti n-ticu exponenciácie spolu so bool, ktorá označuje, či došlo k pretečeniu.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, pravda));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Stierací priestor na ukladanie výsledkov overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // od exp!=0, nakoniec exp musí byť 1.
            // S posledným bitom exponenta sa vysporiadajte osobitne, pretože následné zarovnávanie bázy nie je potrebné a môže spôsobiť zbytočné pretečenie.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Zvyšuje seba k sile `exp` pomocou umocňovania druhou mocninou.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // od exp!=0, nakoniec exp musí byť 1.
            // S posledným bitom exponenta sa vysporiadajte osobitne, pretože následné zarovnávanie bázy nie je potrebné a môže spôsobiť zbytočné pretečenie.
            //
            //
            acc * base
        }

        /// Vypočíta kvocient euklidovského rozdelenia `self` na `rhs`.
        ///
        /// Toto počíta celé číslo `n` také, ako `self = n * rhs + self.rem_euclid(rhs)`, s `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Inými slovami, výsledok je `self / rhs` zaokrúhlený na celé číslo `n`, takže `self >= n * rhs`.
        /// Ak je `self > 0`, rovná sa to zaokrúhlenie na nulu (predvolené v Rust);
        /// ak je `self < 0`, rovná sa to zaokrúhlenie na +/-nekonečno.
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0 alebo výsledkom rozdelenia bude pretečenie.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// nech b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Vypočíta najmenej negatívny zvyšok `self (mod rhs)`.
        ///
        /// Toto sa deje akoby pomocou euklidovského algoritmu delenia-daných `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` a `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Táto funkcia bude panic, ak `rhs` je 0 alebo výsledkom rozdelenia bude pretečenie.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// nech b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Vypočíta absolútnu hodnotu `self`.
        ///
        /// # Chovanie pri pretečení
        ///
        /// Absolútna hodnota
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// nemôže byť reprezentovaný ako
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// a pokus o jeho výpočet spôsobí pretečenie.
        /// To znamená, že kód v režime ladenia v tomto prípade spustí panic a vráti sa optimalizovaný kód
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// bez panic.
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Všimnite si, že#[riadok] vyššie znamená, že sémantika pretečenia odčítania závisí od crate, do ktorej sme vložení.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Vráti číslo predstavujúce znamienko `self`.
        ///
        ///  - `0` ak je číslo nulové
        ///  - `1` ak je číslo kladné
        ///  - `-1` ak je číslo záporné
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Vráti `true`, ak je `self` kladné a `false`, ak je číslo nulové alebo záporné.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Vráti `true`, ak je `self` záporné a `false`, ak je číslo nulové alebo kladné.
        ///
        ///
        /// # Examples
        ///
        /// Základné použitie:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Vráťte pamäťovú reprezentáciu tohto celého čísla ako bajtové pole v poradí bajtov (network) big-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Vráťte pamäťovú reprezentáciu tohto celého čísla ako bajtové pole v poradí bajtov little-endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Vráti reprezentáciu pamäte tohto celého čísla ako bajtové pole v natívnom poradí bajtov.
        ///
        /// Pretože sa používa natívna endianita cieľovej platformy, prenosný kód by mal namiesto toho používať [`to_be_bytes`] alebo [`to_le_bytes`].
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bajtov, ak je cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // BEZPEČNOSŤ: konštantný zvuk, pretože celé čísla sú obyčajné staré dátové typy, takže vždy môžeme
        // premeniť ich na pole bajtov
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // BEZPEČNOSŤ: celé čísla sú obyčajné staré dátové typy, takže ich môžeme kedykoľvek transformovať
            // pole bajtov
            unsafe { mem::transmute(self) }
        }

        /// Vráti reprezentáciu pamäte tohto celého čísla ako bajtové pole v natívnom poradí bajtov.
        ///
        ///
        /// [`to_ne_bytes`] vždy, keď je to možné, by sa malo uprednostniť
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// nechať bajty= num.as_ne_bytes();
        /// assert_eq!(
        ///     bajtov, ak je cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // BEZPEČNOSŤ: celé čísla sú obyčajné staré dátové typy, takže ich môžeme kedykoľvek transformovať
            // pole bajtov
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Vytvorte celočíselnú hodnotu z jej vyjadrenia ako bajtového poľa vo veľkom endiane.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// použite std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * vstup=odpočinok;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Vytvorte celočíselnú hodnotu z jej vyjadrenia ako bajtového poľa v malom endiane.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// použite std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * vstup=odpočinok;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Vytvorte celočíselnú hodnotu z jej pamäťovej reprezentácie ako bajtové pole v natívnej endianness.
        ///
        /// Pretože sa používa natívna endianita cieľovej platformy, prenosný kód pravdepodobne chce namiesto toho použiť [`from_be_bytes`] alebo [`from_le_bytes`].
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } else {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// použite std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * vstup=odpočinok;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // BEZPEČNOSŤ: konštantný zvuk, pretože celé čísla sú obyčajné staré dátové typy, takže vždy môžeme
        // transmutovať im
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // BEZPEČNOSŤ: celé čísla sú obyčajné staré dátové typy, takže na ne môžeme kedykoľvek transformovať
            unsafe { mem::transmute(bytes) }
        }

        /// Nový kód by sa mal radšej používať
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Vráti najmenšiu hodnotu, ktorú môže reprezentovať tento celočíselný typ.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Nový kód by sa mal radšej používať
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Vráti najväčšiu hodnotu, ktorú môže reprezentovať tento celočíselný typ.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}