//! Konštanty pre 16-bitový celočíselný typ so znamienkom.
//!
//! *[See also the `i16` primitive type][i16].*
//!
//! Nový kód by mal používať súvisiace konštanty priamo na primitívnom type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i16`"
)]

int_module! { i16 }