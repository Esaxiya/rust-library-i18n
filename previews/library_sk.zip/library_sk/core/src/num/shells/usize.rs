//! Konštanty pre nepodpísaný celočíselný typ veľkosti ukazovateľa.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Nový kód by mal používať súvisiace konštanty priamo na primitívnom type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }