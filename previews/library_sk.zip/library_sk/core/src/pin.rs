//! Typy, ktoré pripnú údaje na ich miesto v pamäti.
//!
//! Niekedy je užitočné mať objekty, pri ktorých je zaručené, že sa nebudú hýbať, v tom zmysle, že sa ich umiestnenie v pamäti nezmení, a dá sa na ne teda spoľahnúť.
//! Prvotným príkladom takého scenára by bolo vytvorenie sebareferenčných štruktúr, pretože presunutie objektu s ukazovateľmi na seba ich zneplatní, čo by mohlo spôsobiť nedefinované správanie.
//!
//! Na vysokej úrovni [`Pin<P>`] zaisťuje, aby mal pointer ľubovoľného ukazovateľa typu `P` stabilné umiestnenie v pamäti, čo znamená, že ho nie je možné presunúť inam a jeho pamäť nemožno prideliť, kým sa nerozhodí.Hovoríme, že pointee je "pinned".Veci budú jemnejšie, keď diskutujeme o typoch, ktoré kombinujú pripnuté a nepripnuté údaje;[see below](#projections-and-structural-pinning) pre viac informácií.
//!
//! V predvolenom nastavení sú všetky typy v Rust pohyblivé.
//! Rust umožňuje odovzdávanie všetkých typov podľa hodnoty a bežné typy inteligentných ukazovateľov, ako napríklad [`Box<T>`] a `&mut T`, umožňujú nahradenie a presun hodnôt, ktoré obsahujú: z [`Box<T>`] sa môžete presunúť alebo môžete použiť [`mem::swap`].
//! [`Pin<P>`] zalomí ukazovateľ typu `P`, takže [`Pin`]`<<[[Box`] `<T>>`funguje podobne ako bežné
//!
//! [`Box<T>`]: when a [`Pin`]`<<[[Box`] `<T>>`vypadne, rovnako aj jeho obsah a pamäť bude stiahnutá
//!
//! uvoľnený.Podobne je výraz " [Pin`]" <&mut T>`veľmi podobný `&mut T`.[`Pin<P>`] však neumožňuje klientom skutočne získať [`Box<T>`] alebo `&mut T` k pripnutým údajom, čo znamená, že nemôžete používať operácie ako [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` potrebuje `&mut T`, ale nemôžeme to získať.
//!     // Zasekli sme sa, nemôžeme vymeniť obsah týchto odkazov.
//!     // Mohli by sme použiť `Pin::get_unchecked_mut`, ale to je nebezpečné z nejakého dôvodu:
//!     // nesmieme ho používať na premiestňovanie vecí z `Pin`.
//! }
//! ```
//!
//! Stojí za to zopakovať, že [`Pin<P>`]*nemení* skutočnosť, že kompilátor Rust považuje všetky typy za pohyblivé.[`mem::swap`] zostáva volaný pre akýkoľvek `T`.Namiesto toho [`Pin<P>`] zabraňuje presunutiu určitých *hodnôt*(na ktoré poukazujú ukazovatele zabalené v [`Pin<P>`]) tým, že znemožňuje volanie metód, ktoré na ne vyžadujú `&mut T` (napríklad [`mem::swap`]).
//!
//! [`Pin<P>`] môže byť použitý na zabalenie ľubovoľného ukazovateľa typu `P` a ako taký interaguje s [`Deref`] a [`DerefMut`].[`Pin<P>`], kde `P: Deref` by sa mal považovať za "`P`-style pointer" k pripnutému `P::Target`-teda [[Pin`]`<<[[Box`]`<T>> `je vlastnený ukazovateľ na pripnutý `T` a [` Pin`]`<`[`Rc`]`<T>> `je referenčný počítaný ukazovateľ na pripnutú `T`.
//! Pre správnosť sa [`Pin<P>`] spolieha na to, že implementácie [`Deref`] a [`DerefMut`] sa nepresunú z ich parametra `self` a že vždy vrátia ukazovateľ na pripnuté údaje, keď sú vyvolané na pripnutom ukazovateli.
//!
//! # `Unpin`
//!
//! Mnoho typov je vždy voľne pohyblivých, aj keď sú pripnuté, pretože sa nespoliehajú na stabilnú adresu.Patria sem všetky základné typy (ako [`bool`], [`i32`] a referencie), ako aj typy pozostávajúce iba z týchto typov.Typy, ktoré sa nestarajú o pripnutie, implementujú [`Unpin`] auto-trait, ktorý ruší efekt [`Pin<P>`].
//! Pre `T: Unpin`, [`Pin`]`<<[" Box`]`<T>>`a [`Box<T>`] fungujú identicky, rovnako ako [`Pin`] `<&mut T>` a `&mut T`.
//!
//! Upozorňujeme, že pripnutie a [`Unpin`] ovplyvňujú iba špičkový typ `P::Target`, nie samotný typ ukazovateľa `P`, ktorý bol zabalený do [`Pin<P>`].Napríklad to, či [`Box<T>`] je alebo nie je [`Unpin`], nemá žiadny vplyv na chovanie [" Pin`] <<[[Box`]`<T>>`(tu je `T` označený ako typ).
//!
//! # Príklad: sebareferenčná štruktúra
//!
//! Predtým, ako podrobnejšie vysvetlíme záruky a možnosti spojené s `Pin<T>`, prediskutujeme niekoľko príkladov, ako by sa dal použiť.
//! Nebojte sa [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Toto je sebareferenčná štruktúra, pretože pole rezu ukazuje na dátové pole.
//! // O tom nemôžeme kompilátora informovať bežným odkazom, pretože tento vzorec nemožno opísať obvyklými pravidlami vypožičiavania.
//! //
//! // Namiesto toho použijeme hrubý ukazovateľ, aj keď je známe, že nie je nulový, pretože vieme, že ukazuje na reťazec.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Aby sme zabezpečili, že sa dáta po návrate funkcie nebudú hýbať, umiestnime ich na hromadu, kde zostanú po celú dobu životnosti objektu, a jediný spôsob prístupu k nim bude prostredníctvom ukazovateľa na ne.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // ukazovateľ vytvoríme až potom, keď sú údaje na mieste, inak sa už presunuli, ešte než sme začali
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // vieme, že je to bezpečné, pretože úpravou poľa sa neposunie celá štruktúra
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Ukazovateľ by mal smerovať na správne miesto, pokiaľ sa štruktúra nehýbala.
//! //
//! // Zatiaľ môžeme pohybovať ukazovateľom.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Pretože náš typ Unpin neimplementuje, kompilácia sa nepodarí:
//! // nech mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Príklad: dotieravý dvojitý zoznam
//!
//! V dotieravom zozname prepojenom dvakrát kolekcia v skutočnosti neprideľuje pamäť samotným prvkom.
//! Prideľovanie je riadené klientmi a prvky môžu žiť v rámci stohu, ktorý žije kratšie ako kolekcia.
//!
//! Aby to fungovalo, má každý prvok v zozname ukazovatele na svojho predchodcu a nástupcu.Prvky je možné pridať, iba ak sú pripnuté, pretože pohyb prvkov okolo by zneplatnil ukazovatele.Implementácia prepojeného prvku zoznamu [`Drop`] navyše opraví ukazovatele jeho predchodcu a nástupcu, aby sa odstránil zo zoznamu.
//!
//! Rozhodujúce je, že sa musíme môcť spoliehať na to, že sa volá [`drop`].Ak by bolo možné prvok uvoľniť alebo inak zneplatniť bez volania [`drop`], ukazovatele na ne zo susedných prvkov by sa stali neplatnými, čo by narušilo dátovú štruktúru.
//!
//! Preto pripnutie tiež prichádza so zárukou [drop].
//!
//! # `Drop` guarantee
//!
//! Účelom pripnutia je vedieť sa spoľahnúť na umiestnenie niektorých údajov v pamäti.
//! Aby to fungovalo, obmedzuje sa nielen presun údajov;Je tiež obmedzené vyhradenie, opätovné použitie alebo iná neplatnosť pamäte použitej na ukladanie údajov.
//! Konkrétne pre pripnuté údaje musíte zachovať invariant, že *jeho pamäť nebude zneplatnená alebo opätovne použitá od okamihu, keď bude pripnutá, až do doby, keď sa zavolá [`drop`]*.Pamäť sa môže znova použiť iba raz, keď sa vráti [`drop`] alebo panics.
//!
//! Pamäť môže byť "invalidated" uvoľnením, ale aj nahradením [`Some(v)`] [`None`] alebo zavolaním [`Vec::set_len`] na "kill" niektoré prvky zo vector.Môže sa znova použiť pomocou [`ptr::write`] na jeho prepísanie bez toho, aby sa najskôr zavolalo deštruktor.Nič z toho nie je povolené pre pripnuté údaje bez volania [`drop`].
//!
//! Toto je presne ten druh záruky, že rušivý prepojený zoznam z predchádzajúcej časti musí fungovať správne.
//!
//! Upozorňujeme, že táto záruka *neznamená*, že nedochádza k úniku pamäte!Stále je úplne v poriadku, že nikdy nevoláte [`drop`] na pripnutom prvku (napr. Stále môžete volať [`mem::forget`] na [`Pin`]`<`[`Box`] `<T>>`).V príklade dvojnásobne prepojeného zoznamu by tento prvok iba zostal v zozname.Možno však nebudete musieť uvoľniť alebo znova použiť úložisko *bez toho, aby ste zavolali [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Ak váš typ používa pripnutie (napríklad dva vyššie uvedené príklady), pri implementácii [`Drop`] musíte byť opatrní.Funkcia [`drop`] trvá `&mut self`, ale nazýva sa to *, aj keď bol váš typ už predtým pripnutý*!Je to, akoby kompilátor automaticky volal [`Pin::get_unchecked_mut`].
//!
//! Toto nikdy nemôže spôsobiť problém v bezpečnom kóde, pretože implementácia typu, ktorý sa spolieha na pripnutie, vyžaduje nebezpečný kód, ale uvedomte si, že rozhodnutie využiť pripnutie vo vašom type (napríklad implementáciou nejakej operácie na [`Pin`]`<&Self>`alebo [`Pin`] `<&mut Self>`) má dôsledky aj pre vašu implementáciu [`Drop`]: ak by mohol byť pripnutý prvok vášho typu, musíte s [`Drop`] zaobchádzať ako s implicitným užívaním [`Pin`]`<&mut Ja>`.
//!
//!
//! Môžete napríklad implementovať `Drop` nasledovne:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` je v poriadku, pretože vieme, že táto hodnota sa po poklese už nikdy nepoužíva.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Aktuálny drop kód sa zobrazí tu.
//!         }
//!     }
//! }
//! ```
//!
//! Funkcia `inner_drop` má typ, ktorý by mala mať [`drop`] *, takže sa tak zabezpečí, že náhodou nepoužijete `self`/`this` spôsobom, ktorý je v rozpore s pripnutím.
//!
//! Navyše, ak je váš typ `#[repr(packed)]`, kompilátor automaticky presunie polia, aby ich mohol vyhodiť.Mohlo by to byť dokonca aj v prípade polí, ktoré sú náhodou dostatočne zarovnané.V dôsledku toho nemôžete pripnúť pripnutie u typu `#[repr(packed)]`.
//!
//! # Projekcie a štrukturálne pripnutie
//!
//! Pri práci s pripnutými štruktúrami vyvstáva otázka, ako je možné získať prístup k poliam tejto štruktúry v metóde, ktorá zaberá iba [`Pin`]`<&mut Struct>`.
//! Zvyčajným prístupom je písanie pomocných metód (tzv.*Projekcie*), ktoré premenia [`Pin`]`<&mut Struct>`na odkaz na pole, ale aký typ by mal mať tento odkaz?Je to [`Pin`]`<&mut Field>`alebo `&mut Field`?
//! Rovnaká otázka vyvstáva aj pri poliach modelu `enum`, a tiež pri zvažovaní typov container/wrapper, ako napríklad [`Vec<T>`], [`Box<T>`] alebo [`RefCell<T>`].
//! (Táto otázka sa týka premenlivých aj zdieľaných referencií, na ilustráciu používame iba bežnejší prípad premenlivých referencií.)
//!
//! Ukázalo sa, že je v skutočnosti na autorovi dátovej štruktúry, aby rozhodol, či pripnutá projekcia pre konkrétne pole zmení [[Pin`]`<&mut Struct>`na [" Pin`]`<&mut Field>`alebo `&mut Field`.Existujú určité obmedzenia a najdôležitejšou podmienkou je *konzistencia*:
//! každé pole je možné *buď* premietnuť na pripnutú referenciu,*alebo* nechať pripnutie odstrániť ako súčasť projekcie.
//! Ak sa obe vykonajú pre rovnaké pole, bude to pravdepodobne nepríjemné!
//!
//! Ako autor dátovej štruktúry sa budete musieť rozhodnúť pre každé pole, či pripnete "propagates" k tomuto poľu alebo nie.
//! Pripínanie, ktoré sa šíri, sa nazýva aj "structural", pretože sleduje štruktúru typu.
//! V nasledujúcich pododdieloch popisujeme úvahy, ktoré je potrebné urobiť pri výbere.
//!
//! ## Pripnutie *nie je* pre `field` štrukturálne
//!
//! Môže sa zdať neintuitívne, že pole pripnutej štruktúry nemusí byť pripnuté, ale to je vlastne najjednoduchšia voľba: ak sa nikdy nevytvorí [`Pin`]` <&mut Field>, nič sa nemôže pokaziť!Ak sa teda rozhodnete, že niektoré pole nemá štrukturálne pripnutie, musíte sa ubezpečiť, že nikdy nevytvoríte pripnutý odkaz na toto pole.
//!
//! Polia bez štrukturálneho pripnutia môžu mať projekčnú metódu, ktorá premení výraz " " Pin `] <<&mut Struct>` na `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // To je v poriadku, pretože `field` sa nikdy nepovažuje za pripnutý.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Môžete tiež `impl Unpin for Struct`*, aj keď* typ `field` nie je [`Unpin`].To, čo si tento typ myslí o pripnutí, nie je relevantné, keď nikdy nie je vytvorený [" Pin`]` <&mut Field>.
//!
//! ## Pripnutie *je* pre `field` štrukturálne
//!
//! Druhou možnosťou je rozhodnúť sa, že pripnutie je "structural" pre `field`, čo znamená, že ak je pripnutá štruktúra, potom aj toto pole.
//!
//! To umožňuje písať projekciu, ktorá vytvorí [`Pin`]`<&mut Field>`, čím bude svedkom toho, že pole je pripnuté:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // To je v poriadku, pretože `field` je pripnutý, keď je `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Štrukturálne pripevnenie však má niekoľko ďalších požiadaviek:
//!
//! 1. Štruktúra musí byť [`Unpin`], iba ak sú všetky štrukturálne polia [`Unpin`].Toto je predvolené nastavenie, ale [`Unpin`] je bezpečný trait, takže ako autor štruktúry je vašou zodpovednosťou *nie* pridať niečo ako `impl<T> Unpin for Struct<T>`.
//! (Všimnite si, že pridanie projekcie vyžaduje nebezpečný kód, takže skutočnosť, že [`Unpin`] je bezpečný kód trait, neporušuje zásadu, že z ničoho si musíte robiť starosti iba vtedy, ak použijete výraz " nebezpečný`.)
//! 2. Deštruktor štruktúry nesmie presunúť štrukturálne polia z argumentu.Toto je presný bod, ktorý bol vznesený v [previous section][drop-impl]: `drop` zaberá `&mut self`, ale štruktúra (a teda jej polia) mohla byť pripnutá už predtým.
//!     Musíte zaručiť, že vo svojej implementácii [`Drop`] nepresuniete pole.
//!     Ako už bolo vysvetlené vyššie, predovšetkým to znamená, že vaša štruktúra nesmie *byť*`#[repr(packed)]`.
//!     V tejto časti nájdete informácie o tom, ako napísať [`drop`] spôsobom, ktorý vám pomôže kompilátorovi pri náhodnom zlomení pripínania.
//! 3. Musíte sa uistiť, že držíte [`Drop` guarantee][drop-guarantee]:
//!     akonáhle je vaša štruktúra pripnutá, pamäť obsahujúca obsah sa neprepíše alebo nezruší pridelenie bez toho, aby ste zavolali deštruktory obsahu.
//!     To môže byť zložité, čoho dôkazom je [`VecDeque<T>`]: deštruktor [`VecDeque<T>`] môže zlyhať volanie [`drop`] na všetky prvky, ak je jeden z deštruktorov panics.To porušuje záruku [`Drop`], pretože to môže viesť k uvoľneniu prvkov bez toho, aby sa volal ich deštruktor.([`VecDeque<T>`] nemá pripínajúce projekcie, takže to nespôsobuje nepríjemnosti.)
//! 4. Nesmiete ponúkať žiadne ďalšie operácie, ktoré by mohli viesť k presunutiu údajov zo štrukturálnych polí, keď je váš typ pripnutý.Napríklad, ak štruktúra obsahuje [`Option<T>`] a existuje operácia typu " take` s typom `fn(Pin<&mut Struct<T>>) -> Option<T>`, je možné túto operáciu použiť na presun `T` z pripnutého `Struct<T>`-čo znamená, že pripnutie nemôže byť štrukturálne pre pole, v ktorom je tento údaje.
//!
//!     Pre zložitejší príklad presunu údajov z pripnutého typu si predstavte, či mala [`RefCell<T>`] metódu `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Potom by sme mohli urobiť nasledovné:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     To je katastrofické, to znamená, že môžeme najskôr pripnúť obsah [`RefCell<T>`] (pomocou `RefCell::get_pin_mut`) a potom tento obsah presunúť pomocou premenlivého odkazu, ktorý sme dostali neskôr.
//!
//! ## Examples
//!
//! Pre typ ako [`Vec<T>`] majú obe možnosti (štrukturálne pripnutie alebo nie) zmysel.
//! [`Vec<T>`] so štrukturálnym pripnutím môže mať metódy `get_pin`/`get_pin_mut` na získanie pripnutých odkazov na prvky.To by však *nemohlo* umožniť volanie [`pop`][Vec::pop] na pripnutom [`Vec<T>`], pretože by to presunulo (štruktúrne pripnutý) obsah!Tiež by to nemohlo umožniť [`push`][Vec::push], ktorý by mohol prerozdeliť a teda aj presunúť obsah.
//!
//! [`Vec<T>`] bez štrukturálneho pripnutia by mohol byť `impl<T> Unpin for Vec<T>`, pretože obsah nie je nikdy pripnutý a samotný [`Vec<T>`] je v poriadku aj s premiestňovaním.
//! V tom okamihu pripnutie nemá vôbec žiadny vplyv na vector.
//!
//! V štandardnej knižnici typy ukazovateľov spravidla nemajú štrukturálne pripnutie, a preto neponúkajú projekcie pripnutia.Preto platí `Box<T>: Unpin` pre všetky `T`.
//! Je logické to robiť pre typy ukazovateľov, pretože pohyb `Box<T>` v skutočnosti neposúva `T`: [`Box<T>`] môže byť voľne pohyblivý (alias `Unpin`), aj keď `T` nie je.V skutočnosti dokonca aj [`Pin`]`<<[[Box`] `<T>>`a [`Pin`] `<&mut T>` sú vždy [`Unpin`], a to z rovnakého dôvodu: ich obsah (`T`) je pripnutý, ale samotné ukazovatele je možné presunúť bez presunutia pripnutých údajov.
//! Pre [`Box<T>`] aj [`Pin`]`<`[`Box`] `<T>>`, to, či je obsah pripnutý, je úplne nezávislé od toho, či je pripnutý ukazovateľ, čo znamená, že pripnutie nie je * štrukturálne.
//!
//! Pri implementácii kombinátora [`Future`] budete zvyčajne potrebovať štruktúrované pripnutie pre vnorené futures, pretože na ich volanie [`poll`] musíte získať pripnuté odkazy.
//! Ak ale váš kombinátor obsahuje akékoľvek ďalšie údaje, ktoré nie je potrebné pripínať, môžete tieto polia zmeniť tak, aby neboli štrukturálne, a teda k nim mať voľný prístup s premenlivým odkazom, aj keď práve máte [`Pin`]`<&mut Self>`(napr. ako vo vašej vlastnej implementácii [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Pripnutý ukazovateľ.
///
/// Toto je obal okolo druhu ukazovateľa, vďaka ktorému je tento ukazovateľ "pin" svojou hodnotou na svojom mieste a bráni tomu, aby sa hodnota odkazovaná týmto ukazovateľom presunula, pokiaľ neimplementuje [`Unpin`].
///
///
/// *Vysvetlenie pripínania nájdete v dokumentácii k [`pin` module].*
///
/// [`pin` module]: self
///
// Note: nižšie odvodený `Clone` spôsobuje nepríjemnosti, pretože je možné ich implementovať
// `Clone` pre meniteľné referencie.
// Ďalšie informácie nájdete v časti <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Nasledujúce implementácie nie sú odvodené, aby sa predišlo problémom so spoľahlivosťou.
// `&self.pointer` by nemali byť prístupné nedôveryhodným implementáciám trait.
//
// Ďalšie informácie nájdete v časti <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Zostavte nový `Pin<P>` okolo ukazovateľa na niektoré údaje typu, ktorý implementuje [`Unpin`].
    ///
    /// Na rozdiel od `Pin::new_unchecked` je táto metóda bezpečná, pretože ukazovateľ `P` sa oddeľuje od typu [`Unpin`], čím sa zrušia záruky pripnutia.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // BEZPEČNOSŤ: hodnota, na ktorú sa odkazuje, je `Unpin`, a teda nemá žiadne požiadavky
        // okolo pripnutia.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Rozbalí túto `Pin<P>` a vráti podkladový ukazovateľ.
    ///
    /// To si vyžaduje, aby údaje vo vnútri tohto modelu `Pin` boli [`Unpin`], aby sme pri jeho rozbaľovaní mohli ignorovať pripínajúce invarianty.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Zostrojte nový `Pin<P>` okolo odkazu na niektoré údaje typu, ktorý môže alebo nemusí implementovať `Unpin`.
    ///
    /// Ak je `pointer` dereferencia na typ `Unpin`, mala by sa namiesto toho použiť `Pin::new`.
    ///
    /// # Safety
    ///
    /// Tento konštruktor je nebezpečný, pretože nemôžeme zaručiť, že údaje, na ktoré odkazuje `pointer`, sú pripnuté, čo znamená, že údaje nebudú presunuté alebo ich úložisko zneplatnené, kým nebudú vyhodené.
    /// Pokiaľ zostrojená `Pin<P>` nezaručuje, že dáta, na ktoré `P` smeruje, sú pripnuté, znamená to porušenie zmluvy API a môže viesť k nedefinovanému správaniu v ďalších operáciách (safe).
    ///
    /// Použitím tejto metódy vytvárate promise o implementáciách `P::Deref` a `P::DerefMut`, ak existujú.
    /// Najdôležitejšie je, že sa nesmú pohnúť zo svojich argumentov `self`: `Pin::as_mut` a `Pin::as_ref` zavolajú `DerefMut::deref_mut` a `Deref::deref`*na pripnutom ukazovateli* a očakávajú, že tieto metódy potvrdia pripnutie invariantov.
    /// Navyše, volaním tejto metódy promise, že referenčné referencie `P` nebudú znova presunuté;predovšetkým nesmie byť možné získať `&mut P::Target` a potom sa z tejto referencie vymaniť (napríklad pomocou [`mem::swap`]).
    ///
    ///
    /// Napríklad volanie `Pin::new_unchecked` na `&'a mut T` je nebezpečné, pretože aj keď ho môžete pripnúť počas danej životnosti `'a`, nemáte žiadnu kontrolu nad tým, či sa bude pripínať aj po ukončení `'a`:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // To by malo znamenať, že pointee `a` sa už nikdy nemôže pohnúť.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adresa `a` sa zmenila na zásobník typu `b`, takže `a` sa presunul, aj keď sme ho už predtým pripnuli!Porušili sme pripájaciu zmluvu o rozhraní API.
    /////
    /// }
    /// ```
    ///
    /// Po pripnutí hodnoty musí zostať pripnutá navždy (pokiaľ jej typ neimplementuje `Unpin`).
    ///
    /// Podobne je volanie `Pin::new_unchecked` na `Rc<T>` nebezpečné, pretože by mohli existovať aliasy k rovnakým údajom, na ktoré sa nevzťahujú obmedzenia pripínania:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // To by malo znamenať, že pointee sa už nikdy nemôže pohnúť.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Teraz, ak bol `x` jediným odkazom, máme premenlivý odkaz na údaje, ktoré sme pripnuli vyššie, pomocou ktorých by sme ich mohli presunúť, ako sme videli v predchádzajúcom príklade.
    ///     // Porušili sme pripájaciu zmluvu o rozhraní API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Z tohto pripnutého ukazovateľa získa pripnutú zdieľanú referenciu.
    ///
    /// Toto je všeobecná metóda prechodu z `&Pin<Pointer<T>>` na `Pin<&T>`.
    /// Je to bezpečné, pretože v rámci zmluvy so spoločnosťou `Pin::new_unchecked` sa príjemca platby nemôže po vytvorení produktu `Pin<Pointer<T>>` pohybovať.
    ///
    /// "Malicious" implementácie `Pointer::Deref` sú takisto vylúčené zo zmluvy s `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // BEZPEČNOSŤ: pozri dokumentáciu k tejto funkcii
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Rozbalí túto `Pin<P>` a vráti podkladový ukazovateľ.
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná.Musíte sa zaručiť, že po vyvolaní tejto funkcie budete aj naďalej považovať ukazovateľ `P` za pripnutý, aby bolo možné potvrdiť invarianty typu `Pin`.
    /// Pokiaľ kód využívajúci výsledný `P` nepokračuje v udržiavaní pripínajúcich invariantov, je to porušenie zmluvy API a môže viesť k nedefinovanému správaniu v ďalších operáciách (safe).
    ///
    ///
    /// Ak sú podkladové údaje [`Unpin`], malo by sa namiesto nich použiť [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Z tohto pripnutého ukazovateľa získa pripnutú premenlivú referenciu.
    ///
    /// Toto je všeobecná metóda prechodu z `&mut Pin<Pointer<T>>` na `Pin<&mut T>`.
    /// Je to bezpečné, pretože v rámci zmluvy so spoločnosťou `Pin::new_unchecked` sa príjemca platby nemôže po vytvorení produktu `Pin<Pointer<T>>` pohybovať.
    ///
    /// "Malicious" implementácie `Pointer::DerefMut` sú takisto vylúčené zo zmluvy s `Pin::new_unchecked`.
    ///
    /// Táto metóda je užitočná pri viacnásobnom volaní funkcií, ktoré spotrebúvajú pripnutý typ.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // urob niečo
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` spotrebováva `self`, takže znova vypestujte `Pin<&mut Self>` cez `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // BEZPEČNOSŤ: pozri dokumentáciu k tejto funkcii
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Priradí novej hodnote pamäti za pripnutým odkazom.
    ///
    /// Toto prepíše pripnuté údaje, ale to je v poriadku: jeho deštruktor sa spustí skôr, ako sa prepíše, takže nie je porušená žiadna záruka pripnutia.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Vytvorí nový špendlík mapovaním hodnoty interiéru.
    ///
    /// Napríklad, ak ste chceli získať `Pin` poľa niečoho, môžete ho použiť na získanie prístupu k tomuto poľu v jednom riadku kódu.
    /// S týmito "pinning projections" však existuje niekoľko gotchas;
    /// ďalšie podrobnosti k tejto téme nájdete v dokumentácii k produktu [`pin` module].
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná.
    /// Musíte zaručiť, že sa vrátené údaje nebudú pohybovať, pokiaľ sa hodnota argumentu nebude hýbať (napríklad preto, lebo je to jedno z polí tejto hodnoty), a tiež, že sa nepresuniete z argumentu, ktorý dostanete do funkcia interiéru.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // BEZPEČNOSŤ: zmluva o bezpečnosti pre `new_unchecked` musí byť
        // potvrdzuje volajúci.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Z kolíka získa zdieľanú referenciu.
    ///
    /// Je to bezpečné, pretože nie je možné vystúpiť zo zdieľaného odkazu.
    /// Môže sa zdať, že tu existuje problém s premenlivosťou interiéru: v skutočnosti je *je možné* presunúť `T` z `&RefCell<T>`.
    /// To však nie je problém, pokiaľ neexistuje aj `Pin<&T>` smerujúci na rovnaké dáta a `RefCell<T>` vám nedovolí vytvoriť pripnutý odkaz na jeho obsah.
    ///
    /// Ďalšie podrobnosti nájdete v diskusii o ["pinning projections"].
    ///
    /// Note: `Pin` tiež implementuje `Deref` do cieľa, ktorý je možné použiť na prístup k vnútornej hodnote.
    /// `Deref` však poskytuje iba referenciu, ktorá žije tak dlho, ako si požičala `Pin`, nie životnosť samotného `Pin`.
    /// Táto metóda umožňuje zmeniť model `Pin` na referenciu s rovnakou životnosťou ako pôvodný model `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konvertuje tento `Pin<&mut T>` na `Pin<&T>` s rovnakou životnosťou.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Získava premenlivý odkaz na údaje vo vnútri tohto `Pin`.
    ///
    /// To si vyžaduje, aby údaje vo vnútri tohto modelu `Pin` boli `Unpin`.
    ///
    /// Note: `Pin` tiež implementuje `DerefMut` do dát, ktoré možno použiť na prístup k vnútornej hodnote.
    /// `DerefMut` však poskytuje iba referenciu, ktorá žije tak dlho, ako si požičala `Pin`, nie životnosť samotného `Pin`.
    ///
    /// Táto metóda umožňuje zmeniť model `Pin` na referenciu s rovnakou životnosťou ako pôvodný model `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Získava premenlivý odkaz na údaje vo vnútri tohto `Pin`.
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná.
    /// Musíte sa zaručiť, že nikdy nepresuniete údaje z meniteľného odkazu, ktorý dostanete, keď zavoláte túto funkciu, aby bolo možné potvrdiť invarianty typu `Pin`.
    ///
    ///
    /// Ak sú podkladové údaje `Unpin`, malo by sa namiesto nich použiť `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Vytvorte nový špendlík mapovaním hodnoty interiéru.
    ///
    /// Napríklad, ak ste chceli získať `Pin` poľa niečoho, môžete ho použiť na získanie prístupu k tomuto poľu v jednom riadku kódu.
    /// S týmito "pinning projections" však existuje niekoľko gotchas;
    /// ďalšie podrobnosti k tejto téme nájdete v dokumentácii k produktu [`pin` module].
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná.
    /// Musíte zaručiť, že sa vrátené údaje nebudú pohybovať, pokiaľ sa hodnota argumentu nebude hýbať (napríklad preto, lebo je to jedno z polí tejto hodnoty), a tiež, že sa nepresuniete z argumentu, ktorý dostanete do funkcia interiéru.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // BEZPEČNOSŤ: volajúci je zodpovedný za to, že nepohybuje
        // hodnotu z tohto odkazu.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // BEZPEČNOSŤ: pretože hodnota `this` zaručene nebude mať
        // bol presunutý, toto volanie na `new_unchecked` je bezpečné.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Získajte pripnutý odkaz zo statického odkazu.
    ///
    /// Je to bezpečné, pretože `T` je požičaný na dobu životnosti `'static`, ktorá nikdy nekončí.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // BEZPEČNOSŤ: " Statická výpožička zaručuje, že údaje nebudú
        // moved/invalidated kým neklesne (čo nikdy).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Získajte pripnutý premenlivý odkaz zo statického premenlivého odkazu.
    ///
    /// Je to bezpečné, pretože `T` je požičaný na dobu životnosti `'static`, ktorá nikdy nekončí.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // BEZPEČNOSŤ: " Statická výpožička zaručuje, že údaje nebudú
        // moved/invalidated kým neklesne (čo nikdy).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: to znamená, že každý impl z `CoerceUnsized`, ktorý umožňuje nátlak z
// typ, ktorý implikuje `Deref<Target=impl !Unpin>` na typ, ktorý implikuje `Deref<Target=Unpin>`, je nezdravý.
// Akýkoľvek takýto impl by bol pravdepodobne nezdravý z iných dôvodov, takže si musíme dať pozor, aby sme im neumožnili pristáť v std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}