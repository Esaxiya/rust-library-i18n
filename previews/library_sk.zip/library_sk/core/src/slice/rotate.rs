// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Otočí rozsah `[mid-left, mid+right)` tak, aby sa prvok na `mid` stal prvým prvkom.Ekvivalentne otočí prvky rozsahu `left` doľava alebo prvky `right` doprava.
///
/// # Safety
///
/// Zadaný rozsah musí byť platný pre čítanie a zápis.
///
/// # Algorithm
///
/// Algoritmus 1 sa používa pre malé hodnoty `left + right` alebo pre veľké `T`.
/// Prvky sa posúvajú do svojich konečných pozícií jeden po druhom, počnúc `mid - left` a postupujúc krokmi `right` modulo `left + right`, takže je potrebný iba jeden dočasný.
/// Nakoniec dorazíme späť na `mid - left`.
/// Ak však `gcd(left + right, right)` nie je 1, vyššie uvedené kroky preskočili prvky.
/// Napríklad:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Našťastie je počet preskočených prvkov medzi finalizovanými prvkami vždy rovnaký, takže môžeme iba posunúť našu východiskovú pozíciu a urobiť viac kôl (celkový počet kôl je `gcd(left + right, right)` value).
///
/// Konečným výsledkom je, že všetky prvky sú finalizované raz a iba raz.
///
/// Algoritmus 2 sa používa, ak je `left + right` veľká, ale `min(left, right)` je dostatočne malá na to, aby sa zmestila do vyrovnávacej pamäte zásobníka.
/// Prvky `min(left, right)` sa skopírujú do medzipamäte, `memmove` sa aplikuje na ostatné a tie vo vyrovnávacej pamäti sa presunú späť do otvoru na opačnej strane, odkiaľ pochádzajú.
///
/// Algoritmy, ktoré možno vektorizovať, prekonajú vyššie uvedené, keď sa `left + right` stane dostatočne veľkým.
/// Algoritmus 1 možno vektorizovať blokovaním a vykonaním viacerých kôl naraz, ale v priemere je príliš málo kôl, kým nie je `left + right` enormný, a vždy existuje najhorší prípad jedného kola.
/// Namiesto toho algoritmus 3 využíva opakované zamieňanie prvkov `min(left, right)`, kým nezostane menší problém s otáčaním.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// keď `left < right`, prehodenie sa deje zľava.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. nižšie uvedené algoritmy môžu zlyhať, ak sa tieto prípady nekontrolujú
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Mikrobaničky Algoritmu 1 naznačujú, že priemerný výkon pre náhodné posuny je lepší až do doby okolo `left + right == 32`, ale najhorší výkon sa zlomí dokonca okolo 16.
            // 24 bola vybraná ako stredná cesta.
            // Ak je veľkosť súboru `T` väčšia ako 4 veľkosti, tento algoritmus prekonáva aj iné algoritmy.
            //
            //
            let x = unsafe { mid.sub(left) };
            // začiatok prvého kola
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` možno nájsť pred výpočtom `gcd(left + right, right)`, ale je rýchlejšie urobiť jednu slučku, ktorá vypočíta gcd ako vedľajší efekt, a potom urobiť zvyšok bloku
            //
            //
            let mut gcd = right;
            // referenčné hodnoty odhaľujú, že je rýchlejšie zameniť provizórium namiesto prečítania jedného dočasného razu, kopírovania dozadu a následného napísania dočasného úplného konca.
            // Je to pravdepodobne spôsobené skutočnosťou, že zámena alebo výmena dočasných prostriedkov používa v slučke iba jednu adresu pamäte, namiesto toho, aby bolo potrebné spravovať dve.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // namiesto prírastku `i` a následnej kontroly, či je to mimo hraníc, skontrolujeme, či `i` pôjde mimo hranice pri ďalšom prírastku.
                // Tým sa zabráni zabaleniu ukazovateľov alebo `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // koniec prvého kola
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // toto podmienené musí byť tu, ak `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // dokončite blok ďalšími kruhmi
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` nie je nulového typu, takže je v poriadku deliť ho podľa veľkosti.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmus 2 `[T; 0]` sa tu má ubezpečiť, že je to správne zarovnané pre T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmus 3 Existuje alternatívny spôsob výmeny, ktorý spočíva v zistení, kde by bol posledný zámena tohto algoritmu, a výmena pomocou tohto posledného bloku namiesto výmeny susedných blokov, ako je to v prípade tohto algoritmu, ale tento spôsob je stále rýchlejší.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmus 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}