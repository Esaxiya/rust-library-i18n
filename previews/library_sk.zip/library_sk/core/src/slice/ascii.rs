//! Operácie na ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Skontroluje, či sú všetky bajty v tomto segmente v rozsahu ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Skontroluje, či sa dva rezy zhodujú s malými a veľkými písmenami v ASCII.
    ///
    /// Rovnaké ako `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ale bez prideľovania a kopírovania dočasných položiek.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Skonvertuje tento rez na miestny ekvivalent veľkých písmen ASCII.
    ///
    /// Písmená ASCII 'a' až 'z' sú namapované na 'A' až 'Z', ale písmená iné ako ASCII sa nezmenia.
    ///
    /// Ak chcete vrátiť novú hodnotu s veľkými písmenami bez úpravy existujúcej, použite [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Skonvertuje tento rez na miestny ekvivalent s malými písmenami ASCII.
    ///
    /// Písmená ASCII 'A' až 'Z' sú namapované na 'a' až 'z', ale písmená iné ako ASCII sa nezmenia.
    ///
    /// Ak chcete vrátiť novú hodnotu s malými písmenami bez úpravy existujúcej, použite [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Vráti `true`, ak je niektorý bajt v slove `v` nonascii (>=128).
/// Snarfed z `../str/mod.rs`, ktorý robí niečo podobné pre validáciu utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimalizovaný test ASCII, ktorý bude namiesto operácií typu byte-at-time (ak je to možné) používať operácie usize-at-a-time namiesto operácií byte-at-a-time.
///
/// Algoritmus, ktorý tu používame, je dosť jednoduchý.Ak je `s` príliš krátky, jednoducho skontrolujeme každý bajt a skončíme s ním.Inak:
///
/// - Prečítajte si prvé slovo s nezaradenou záťažou.
/// - Zarovnajte ukazovateľ, prečítajte si nasledujúce slová až do konca so zarovnanými načítaniami.
/// - Prečítajte si posledný `usize` z `s` s nevyrovnaným zaťažením.
///
/// Ak ktorékoľvek z týchto zaťažení vyprodukuje niečo, pre čo `contains_nonascii` (above) vráti hodnotu true, potom vieme, že odpoveď je nepravdivá.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Ak by sme z implementácie word-at-a-time nič nezískali, vráťme sa späť k skalárnej slučke.
    //
    // Robíme to aj pre architektúry, kde `size_of::<usize>()` nie je dostatočné zarovnanie pre `usize`, pretože je to čudný prípad edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Vždy čítame prvé slovo nezaradené, čo znamená, že `align_offset` je
    // 0, načítali by sme znova rovnakú hodnotu pre zarovnané čítanie.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // BEZPEČNOSŤ: Overujeme `len < USIZE_SIZE` vyššie.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Toto sme skontrolovali vyššie, trochu implicitne.
    // Upozorňujeme, že `offset_to_aligned` je buď `align_offset`, alebo `USIZE_SIZE`, obe sú výslovne skontrolované vyššie.
    //
    debug_assert!(offset_to_aligned <= len);

    // BEZPEČNOSŤ: word_ptr je (správne zarovnané) použitie ptr, ktoré používame na čítanie súboru
    // stredný kúsok plátku.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` je bajtový index `word_ptr`, ktorý sa používa na kontroly konca slučky.
    let mut byte_pos = offset_to_aligned;

    // Paranoja kontroluje zarovnanie, pretože sa chystáme urobiť veľa nevyrovnaných záťaží.
    // V praxi by to malo byť nemožné vylúčiť chybu v `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Čítajte nasledujúce slová až do posledného zarovnaného slova, okrem posledného zarovnaného slova, ktoré bude urobené pri neskoršej kontrole chvosta, aby ste zaistili, že chvost bude vždy maximálne jeden `usize` po extra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // S rozumom skontrolujte, či je načítanie v medziach
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // A že naše predpoklady o `byte_pos` platia.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // BEZPEČNOSŤ: Vieme, že `word_ptr` je správne zarovnaný (z dôvodu
        // `align_offset`) a vieme, že medzi `word_ptr` a koncom máme dostatok bajtov
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // BEZPEČNOSŤ: Poznáme `byte_pos <= len - USIZE_SIZE`, čo to znamená
        // po tomto `add` bude `word_ptr` nanajvýš jeden za koncom.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Kontrola zdravého rozumu, aby ste sa uistili, že naozaj zostáva už iba jedna `usize`.
    // To by mala zaručiť naša podmienka slučky.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // BEZPEČNOSŤ: To sa spolieha na `len >= USIZE_SIZE`, ktorú na začiatku skontrolujeme.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}