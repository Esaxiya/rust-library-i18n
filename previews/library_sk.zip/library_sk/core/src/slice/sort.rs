//! Triedenie podľa plátkov
//!
//! Tento modul obsahuje algoritmus triedenia založený na rýchlom triedení Orsona Petersa, ktoré poráža vzory, publikované na: <https://github.com/orlp/pdqsort>
//!
//!
//! Nestabilné triedenie je kompatibilné s libcore, pretože na rozdiel od našej implementácie stabilného triedenia neprideľuje pamäť.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Po páde kópie z `src` do `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // BEZPEČNOSŤ: Toto je pomocná trieda.
        //          Správnosť nájdete v jeho použití.
        //          Musíte si byť istí, že sa `src` a `dst` neprekrývajú, ako to vyžaduje `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Posunie prvý prvok doprava, kým nenarazí na väčší alebo rovný prvok.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BEZPEČNOSŤ: Nižšie uvedené nebezpečné operácie zahŕňajú indexovanie bez viazanej kontroly (`get_unchecked` a `get_unchecked_mut`).
    // a kopírovanie pamäte (`ptr::copy_nonoverlapping`).
    //
    // a.Indexovanie:
    //  1. Skontrolovali sme veľkosť poľa na>=2.
    //  2. Všetko indexovanie, ktoré urobíme, je vždy maximálne medzi {0 <= index < len}.
    //
    // b.Kopírovanie pamäte
    //  1. Získavame odkazy na referencie, ktoré sú zaručene platné.
    //  2. Nemôžu sa prekrývať, pretože získavame ukazovatele na indexy rozdielov rezu.
    //     Menovite `i` a `i-1`.
    //  3. Ak je plátok správne zarovnaný, prvky sú správne zarovnané.
    //     Je zodpovednosťou volajúceho zabezpečiť, aby bol plátok správne zarovnaný.
    //
    // Ďalšie podrobnosti nájdete v komentároch nižšie.
    unsafe {
        // Ak sú prvé dva prvky mimo poradia ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Načítajte prvý prvok do premennej priradenej zásobníku.
            // Ak nasledujúca operácia porovnania panics, `hole` bude zrušená a automaticky zapíše prvok späť do rezu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Posuňte `i`-tý prvok o jedno miesto doľava, čím posuniete dieru doprava.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` spadne a tým skopíruje `tmp` do zostávajúcej diery v `v`.
        }
    }
}

/// Posunie posledný prvok doľava, kým nenarazí na menší alebo rovný prvok.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // BEZPEČNOSŤ: Nižšie uvedené nebezpečné operácie zahŕňajú indexovanie bez viazanej kontroly (`get_unchecked` a `get_unchecked_mut`).
    // a kopírovanie pamäte (`ptr::copy_nonoverlapping`).
    //
    // a.Indexovanie:
    //  1. Skontrolovali sme veľkosť poľa na>=2.
    //  2. Všetko indexovanie, ktoré urobíme, je vždy maximálne medzi `0 <= index < len-1`.
    //
    // b.Kopírovanie pamäte
    //  1. Získavame odkazy na referencie, ktoré sú zaručene platné.
    //  2. Nemôžu sa prekrývať, pretože získavame ukazovatele na indexy rozdielov rezu.
    //     Menovite `i` a `i+1`.
    //  3. Ak je plátok správne zarovnaný, prvky sú správne zarovnané.
    //     Je zodpovednosťou volajúceho zabezpečiť, aby bol plátok správne zarovnaný.
    //
    // Ďalšie podrobnosti nájdete v komentároch nižšie.
    unsafe {
        // Ak sú posledné dva prvky mimo poradia ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Načítajte posledný prvok do premennej priradenej zásobníku.
            // Ak nasledujúca operácia porovnania panics, `hole` bude zrušená a automaticky zapíše prvok späť do rezu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Posuňte `i`-tý prvok o jedno miesto doprava, čím posuniete dieru doľava.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` spadne a tým skopíruje `tmp` do zostávajúcej diery v `v`.
        }
    }
}

/// Čiastočne triedi plátok posunutím niekoľkých prvkov mimo poradia.
///
/// Vráti `true`, ak je rez na konci zoradený.Táto funkcia je najhorší prípad *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maximálny počet susedných párov mimo objednávky, ktoré sa posunú.
    const MAX_STEPS: usize = 5;
    // Ak je plátok kratší, nepresuňte žiadne prvky.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // BEZPEČNOSŤ: Kontrolu viazanosti sme už výslovne vykonali pomocou `i < len`.
        // Všetky naše následné indexovanie je iba v rozsahu `0 <= index < len`
        unsafe {
            // Nájdite nasledujúcu dvojicu susedných prvkov mimo poradia.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Sme hotoví?
        if i == len {
            return true;
        }

        // Nepresúvajte prvky na krátkych poliach, čo má náklady na výkon.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Zamieňajte nájdený pár prvkov.Týmto sa dajú do správneho poradia.
        v.swap(i - 1, i);

        // Menší prvok posuňte doľava.
        shift_tail(&mut v[..i], is_less);
        // Posuňte väčší prvok doprava.
        shift_head(&mut v[i..], is_less);
    }

    // Nepodarilo sa zoradiť plátok v obmedzenom počte krokov.
    false
}

/// Zoradí plátok podľa druhu vloženia, čo je najhorší prípad *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Zoradí `v` pomocou haldy, ktorá zaručuje *O*(*n*\*log(* n*)) v najhoršom prípade.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Táto binárna halda rešpektuje invariantný `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Deti `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Vyberte si väčšie dieťa.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Zastavte, ak invariant drží na `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Zamieňajte `node` s väčším dieťaťom, posuňte sa o krok dole a pokračujte v preosievaní.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Budujte hromadu v lineárnom čase.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Popujte maximum prvkov z haldy.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Rozdelí `v` na prvky menšie ako `pivot`, za ktorými nasledujú prvky väčšie alebo rovné `pivot`.
///
///
/// Vráti počet prvkov menší ako `pivot`.
///
/// Delenie na oddiely sa vykonáva blok po bloku, aby sa minimalizovali náklady na operácie rozvetvenia.
/// Táto myšlienka je predstavená v dokumente [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Počet prvkov v typickom bloku.
    const BLOCK: usize = 128;

    // Algoritmus rozdelenia oddielov opakuje nasledujúce kroky až do dokončenia:
    //
    // 1. Trasujte blok z ľavej strany, aby ste identifikovali prvky väčšie alebo rovné otočnému bodu.
    // 2. Trasujte blok z pravej strany a identifikujte prvky menšie ako čap.
    // 3. Vymeňte identifikované prvky medzi ľavou a pravou stranou.
    //
    // Pre blok prvkov ponechávame nasledujúce premenné:
    //
    // 1. `block` - Počet prvkov v bloku.
    // 2. `start` - Spustite ukazovateľ do poľa `offsets`.
    // 3. `end` - Koncový ukazovateľ do poľa `offsets`.
    // 4. `vyrovnania, Indexy prvkov mimo poradia v rámci bloku.

    // Aktuálny blok na ľavej strane (od `l` do `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Aktuálny blok na pravej strane (od `r.sub(block_r)` to `r`).
    // BEZPEČNOSŤ: Dokumentácia k .add() výslovne uvádza, že `vec.as_ptr().add(vec.len())` je vždy bezpečný
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Keď dostaneme VLA, skúste vytvoriť radšej jedno pole s dĺžkou `min(v.len(), 2 * BLOCK) `
    // ako dve polia pevnej veľkosti s dĺžkou `BLOCK`.VLA môžu byť efektívnejšie z hľadiska vyrovnávacej pamäte.

    // Vráti počet prvkov medzi ukazovateľmi `l` (inclusive) a `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Rozdelenie po blokoch sme skončili, keď sa `l` a `r` zblížia.
        // Potom urobíme nejaké opravy, aby sme medzi ne rozdelili zvyšné prvky.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Počet zostávajúcich prvkov (stále nie je porovnaný s pivotom).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Upravte veľkosti blokov tak, aby sa ľavý a pravý blok neprekrývali, ale aby boli dokonale zarovnané, aby zakryli celú zostávajúcu medzeru.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Stopové prvky `block_l` z ľavej strany.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // BEZPEČNOSŤ: Nižšie uvedené nebezpečné operácie zahŕňajú použitie `offset`.
                //         Podľa podmienok vyžadovaných funkciou ich uspokojujeme, pretože:
                //         1. `offsets_l` je zásobníkovo alokovaný, a teda považovaný za samostatný alokovaný objekt.
                //         2. Funkcia `is_less` vráti `bool`.
                //            Casting `bool` nikdy nepretečie `isize`.
                //         3. Zaručili sme, že `block_l` bude `<= BLOCK`.
                //            Plus, `end_l` bol pôvodne nastavený na začiatočný ukazovateľ `offsets_`, ktorý bol deklarovaný v zásobníku.
                //            Vieme teda, že aj v najhoršom prípade (všetky vyvolania `is_less` vráti hodnotu false) nám na konci prejde iba najviac 1 bajt.
                //        Ďalšou bezpečnou operáciou je dereferencovanie `elem`.
                //        Avšak `elem` bol pôvodne počiatočný ukazovateľ na rez, ktorý je vždy platný.
                unsafe {
                    // Porovnanie bez pobočiek.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Stopové prvky `block_r` z pravej strany.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // BEZPEČNOSŤ: Nižšie uvedené nebezpečné operácie zahŕňajú použitie `offset`.
                //         Podľa podmienok vyžadovaných funkciou ich uspokojujeme, pretože:
                //         1. `offsets_r` je zásobníkovo alokovaný, a teda považovaný za samostatný alokovaný objekt.
                //         2. Funkcia `is_less` vráti `bool`.
                //            Casting `bool` nikdy nepretečie `isize`.
                //         3. Zaručili sme, že `block_r` bude `<= BLOCK`.
                //            Plus, `end_r` bol pôvodne nastavený na začiatočný ukazovateľ `offsets_`, ktorý bol deklarovaný v zásobníku.
                //            Vieme teda, že aj v najhoršom prípade (všetky vyvolania `is_less` sa vrátia ako pravdivé) nám na konci prejde iba najviac 1 bajt.
                //        Ďalšou bezpečnou operáciou je dereferencovanie `elem`.
                //        Avšak `elem` bol pôvodne `1 *sizeof(T)` za koncom a pred prístupom sme ho znížili o `1* sizeof(T)`.
                //        Navyše sa tvrdilo, že `block_r` je menej ako `BLOCK` a `elem` bude teda smerovať nanajvýš na začiatok rezu.
                unsafe {
                    // Porovnanie bez pobočiek.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Počet prvkov mimo poradia, ktoré sa majú prepínať medzi ľavou a pravou stranou.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Namiesto výmeny jedného páru v danom čase je efektívnejšie vykonať cyklickú permutáciu.
            // Toto nie je striktne ekvivalentné zámene, ale vytvára podobný výsledok pri menšom počte operácií s pamäťou.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Všetky prvky mimo poradia v ľavom bloku boli presunuté.Presun na ďalší blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Všetky prvky mimo poradia v pravom bloku boli presunuté.Presun na predchádzajúci blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Teraz už zostáva iba jeden blok (ľavý alebo pravý) s prvkami mimo poradia, ktoré je potrebné presunúť.
    // Takéto zvyšné prvky je možné v rámci ich bloku jednoducho posunúť na koniec.
    //

    if start_l < end_l {
        // Ľavý blok zostáva.
        // Presuňte jeho zvyšné prvky mimo poradia úplne doprava.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Pravý blok zostáva.
        // Posuňte jeho zvyšné prvky mimo poradia úplne doľava.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nič iné robiť, sme hotoví.
        width(v.as_mut_ptr(), l)
    }
}

/// Rozdelí `v` na prvky menšie ako `v[pivot]`, za ktorými nasledujú prvky väčšie alebo rovné `v[pivot]`.
///
///
/// Vráti n-ticu:
///
/// 1. Počet prvkov menší ako `v[pivot]`.
/// 2. True, ak už bol `v` rozdelený na oddiely.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Pivot umiestnite na začiatok rezu.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Načítajte otočný čep do premennej priradenej zásobníku kvôli efektivite.
        // Ak nasledujúca operácia porovnania panics, pivot sa automaticky zapíše späť do rezu.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Nájdite prvý pár prvkov mimo poradia.
        let mut l = 0;
        let mut r = v.len();

        // BEZPEČNOSŤ: Nižšie uvedené zaistenie bezpečnosti zahŕňa indexovanie poľa.
        // Prvý: Hranice tu už kontrolujeme pomocou `l < r`.
        // Pre druhú: Spočiatku máme `l == 0` a `r == v.len()` a túto `l < r` sme skontrolovali pri každej indexovacej operácii.
        //                     Od tejto chvíle vieme, že `r` musí byť minimálne `r == l`, o ktorom sa ukázalo, že je platný od prvého.
        unsafe {
            // Nájdite prvý prvok väčší alebo rovný otočnému bodu.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Nájdite posledný prvok menší, než je otočný čap.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` vyjde z rozsahu a zapíše pivot (čo je premenná priradená zásobníku) späť do výseku, kde bol pôvodne.
        // Tento krok je rozhodujúci pri zaistení bezpečnosti!
        //
    };

    // Otočný čap umiestnite medzi dva oddiely.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Rozdelí `v` na prvky rovnajúce sa `v[pivot]` nasledované prvkami väčšími ako `v[pivot]`.
///
/// Vráti počet prvkov rovný kontingenčnej hodnote.
/// Predpokladá sa, že `v` neobsahuje prvky menšie ako pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Pivot umiestnite na začiatok rezu.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Načítajte otočný čep do premennej priradenej zásobníku kvôli efektivite.
    // Ak nasledujúca operácia porovnania panics, pivot sa automaticky zapíše späť do rezu.
    // BEZPEČNOSŤ: Ukazovateľ je platný, pretože sa získava z odkazu na rez.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Teraz rozdeľte plátok.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // BEZPEČNOSŤ: Nižšie uvedené zaistenie bezpečnosti zahŕňa indexovanie poľa.
        // Prvý: Hranice tu už kontrolujeme pomocou `l < r`.
        // Pre druhú: Spočiatku máme `l == 0` a `r == v.len()` a túto `l < r` sme skontrolovali pri každej indexovacej operácii.
        //                     Od tejto chvíle vieme, že `r` musí byť minimálne `r == l`, o ktorom sa ukázalo, že je platný od prvého.
        unsafe {
            // Nájdite prvý prvok väčší ako pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Nájdite posledný prvok rovnajúci sa čapu.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Sme hotoví?
            if l >= r {
                break;
            }

            // Zamieňajte nájdený pár prvkov mimo poradia.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Našli sme prvky `l`, ktoré sa rovnajú otočnému bodu.Pridajte 1 do účtu pre samotný pivot.
    l + 1

    // `_pivot_guard` vyjde z rozsahu a zapíše pivot (čo je premenná priradená zásobníku) späť do výseku, kde bol pôvodne.
    // Tento krok je rozhodujúci pri zaistení bezpečnosti!
}

/// Rozptýli okolo seba niektoré prvky pri pokuse o prelomenie vzorov, ktoré by mohli spôsobiť nevyvážené oddiely v rýchlom roztriedení.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generátor pseudonáhodných čísel z článku "Xorshift RNGs" od Georga Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Vezmite náhodné čísla modulo toto číslo.
        // Toto číslo zapadá do `usize`, pretože `len` nie je väčšie ako `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Niektorí pivotní kandidáti budú v blízkosti tohto indexu.Poďme ich randomizovať.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Vytvorte náhodné číslo modulo `len`.
            // Aby sme sa však vyhli nákladným operáciám, najskôr mu vezmeme modulo s výkonom dva a potom znižujeme o `len`, kým sa nezmestí do rozsahu `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` je zaručene menej ako `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Vyberie pivot v `v` a vráti index a `true`, ak je plátok pravdepodobne už zoradený.
///
/// Počas procesu môže dôjsť k zmene poradia prvkov v `v`.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimálna dĺžka pre výber metódy mediánu mediánov.
    // Kratšie plátky používajú jednoduchú metódu mediánu troch.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maximálny počet swapov, ktoré je možné vykonať v tejto funkcii.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tri indexy, v blízkosti ktorých ideme zvoliť pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Spočítava celkový počet swapov, ktoré sa chystáme vykonať pri triedení indexov.
    let mut swaps = 0;

    if len >= 8 {
        // Zamení indexy tak, aby `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Zamení indexy tak, aby `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Nájde medián `v[a - 1], v[a], v[a + 1]` a index uloží do `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Nájdite mediány v susedstvách `a`, `b` a `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Nájdite medián medzi `a`, `b` a `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Bol vykonaný maximálny počet swapov.
        // Je pravdepodobné, že plátok klesá alebo väčšinou klesá, takže reverzácia ho pravdepodobne pomôže rýchlejšie zoradiť.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Triedi `v` rekurzívne.
///
/// Ak mal plátok predchodcu v pôvodnom poli, je zadaný ako `pred`.
///
/// `limit` je počet povolených nevyvážených oddielov pred prechodom na `heapsort`.
/// Ak je nula, táto funkcia sa okamžite prepne na heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Plátky až do tejto dĺžky sa zoradia pomocou triedenia podľa vloženia.
    const MAX_INSERTION: usize = 20;

    // Pravda, ak bolo posledné rozdelenie primerane vyvážené.
    let mut was_balanced = true;
    // Pravda, ak posledné rozdelenie nerozmiešalo prvky (výsek už bol rozdelený).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Veľmi krátke plátky sa zoradia pomocou triedenia podľa vloženia.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Ak bolo urobených príliš veľa zlých rozhodnutí o otočení, jednoducho sa vráťte k halde, aby ste zaručili najhorší prípad `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Ak bolo posledné rozdelenie nevyvážené, skúste prerušiť vzory v reze zamiešaním niektorých prvkov okolo.
        // Dúfajme, že tentokrát zvolíme lepší pivot.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Vyberte pivot a skúste hádať, či je plátok už zoradený.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Ak bolo posledné rozdelenie slušne vyvážené a nepremiešalo to prvky, a ak výber otáčania predpovedá, že plátok je už pravdepodobne zoradený ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Skúste identifikovať niekoľko prvkov mimo poradia a posuňte ich do správnych pozícií.
            // Ak plátok skončí úplným roztriedením, máme hotovo.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Ak sa zvolený pivot rovná predchodcovi, potom je to najmenší prvok v reze.
        // Rozdeľte rez na prvky rovnaké a prvky väčšie ako čap.
        // Tento prípad je zvyčajne dosiahnutý, keď plátok obsahuje veľa duplicitných prvkov.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Pokračujte v zoraďovaní prvkov väčších ako pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Rozdeľte plátok.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Rozdeľte rez na `left`, `pivot` a `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Opakujte iba na kratšiu stranu, aby ste minimalizovali celkový počet rekurzívnych hovorov a spotrebovali menej miesta v zásobníku.
        // Potom už len pokračujte dlhšou stranou (je to podobné ako pri rekurzii chvosta).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Zoradí `v` pomocou rýchleho triedenia, ktoré poráža vzory, čo je *O*(*n*\*log(* n*)) v najhoršom prípade.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // U typov nulovej veľkosti nemá triedenie nijaké zmysluplné správanie.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Obmedzte počet nevyvážených oddielov na `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Pre plátky do tejto dĺžky je pravdepodobne rýchlejšie ich jednoducho triediť.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Vyberte pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Ak sa zvolený pivot rovná predchodcovi, potom je to najmenší prvok v reze.
        // Rozdeľte rez na prvky rovnaké a prvky väčšie ako čap.
        // Tento prípad je zvyčajne dosiahnutý, keď plátok obsahuje veľa duplicitných prvkov.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ak sme prekonali náš index, potom sme dobrí.
                if mid > index {
                    return;
                }

                // V opačnom prípade pokračujte v triedení prvkov väčších ako je otočný čap.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Rozdeľte rez na `left`, `pivot` a `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Ak je index mid==, sme hotoví, pretože partition() zaručil, že všetky prvky po strede sú väčšie alebo rovné stredu.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // U typov nulovej veľkosti nemá triedenie nijaké zmysluplné správanie.Nerob nič.
    } else if index == v.len() - 1 {
        // Nájdite maximálny prvok a umiestnite ho na poslednú pozíciu poľa.
        // Sme tu, že tu môžeme použiť `unwrap()`, pretože vieme, že v nesmie byť prázdne.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Nájdite prvok min a umiestnite ho na prvú pozíciu poľa.
        // Sme tu, že tu môžeme použiť `unwrap()`, pretože vieme, že v nesmie byť prázdne.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}