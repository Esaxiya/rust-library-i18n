// ignore-tidy-filelength

//! Správa a manipulácia s plátkami.
//!
//! Viac podrobností nájdete na [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Čistá implementácia rust memchr, prevzatá z rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Táto funkcia je verejná iba preto, že neexistuje žiadny iný spôsob ako testovať jednotku heapsort.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Vráti počet prvkov v reze.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // BEZPEČNOSŤ: konštantný zvuk, pretože transmutujeme pole dĺžky ako veľkosť (ktorá musí byť)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // BEZPEČNOSŤ: je to bezpečné, pretože modely `&[T]` a `FatPtr<T>` majú rovnaké rozloženie.
            // Túto záruku môže poskytnúť iba `std`.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Ak je konštantná, nahraďte ju `crate::ptr::metadata(self)`.
            // Od tohto písania to spôsobí chybu "Const-stable functions can only call other const-stable functions".
            //

            // BEZPEČNOSŤ: Prístup k hodnote z únie `PtrRepr` je bezpečný, pretože * const T
            // a PtrComponents<T>majú rovnaké rozloženia pamäte.
            // Túto záruku môže poskytnúť iba std.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Vráti `true`, ak má plátok dĺžku 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Vráti prvý prvok rezu alebo `None`, ak je prázdny.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Vráti premenlivý ukazovateľ na prvý prvok rezu alebo `None`, ak je prázdny.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Vráti prvý a všetky ostatné prvky rezu alebo `None`, ak je prázdny.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Vráti prvý a všetky ostatné prvky rezu alebo `None`, ak je prázdny.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Vráti posledný a všetky ostatné prvky rezu alebo `None`, ak je prázdny.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Vráti posledný a všetky ostatné prvky rezu alebo `None`, ak je prázdny.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Vráti posledný prvok rezu alebo `None`, ak je prázdny.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Vráti premenlivý ukazovateľ na poslednú položku v reze.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Vráti odkaz na prvok alebo čiastkový rez v závislosti od typu indexu.
    ///
    /// - Ak je daná pozícia, vráti odkaz na prvok na tejto pozícii alebo `None`, ak je mimo hraníc.
    ///
    /// - Ak je daný rozsah, vráti čiastkový rez zodpovedajúci tomuto rozsahu alebo `None`, ak je mimo hraníc.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Vráti premenlivý odkaz na prvok alebo čiastkový rez v závislosti od typu indexu (pozri [`get`]) alebo `None`, ak je index mimo hraníc.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Vráti odkaz na prvok alebo čiastkový rez bez kontroly hraníc.
    ///
    /// Pre bezpečnú alternatívu pozri [`get`].
    ///
    /// # Safety
    ///
    /// Volanie tejto metódy s indexom out-of-bounds je *[nedefinované správanie]*, aj keď sa výsledná referencia nepoužíva.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať väčšinu bezpečnostných požiadaviek pre `get_unchecked`;
        // plátok je dereferenčný, pretože `self` je bezpečná referencia.
        // Vrátený ukazovateľ je bezpečný, pretože implikáty `SliceIndex` musia zaručiť, že sú.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Vráti premenlivý odkaz na prvok alebo čiastkový rez bez kontroly hraníc.
    ///
    /// Pre bezpečnú alternatívu pozri [`get_mut`].
    ///
    /// # Safety
    ///
    /// Volanie tejto metódy s indexom out-of-bounds je *[nedefinované správanie]*, aj keď sa výsledná referencia nepoužíva.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostné požiadavky pre `get_unchecked_mut`;
        // plátok je dereferenčný, pretože `self` je bezpečná referencia.
        // Vrátený ukazovateľ je bezpečný, pretože implikáty `SliceIndex` musia zaručiť, že sú.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Vráti nespracovaný ukazovateľ do vyrovnávacej pamäte rezu.
    ///
    /// Volajúci musí zabezpečiť, aby plátok prežil ukazovateľ, ktorý táto funkcia vráti, inak skončí ukazovaním na odpadky.
    ///
    /// Volajúci musí tiež zabezpečiť, aby sa do pamäte, na ktorú ukazovateľ (non-transitively) ukazuje, nikdy nezapisovala (okrem `UnsafeCell`) pomocou tohto ukazovateľa ani z neho odvodeného ukazovateľa.
    /// Ak potrebujete zmutovať obsah rezu, použite [`as_mut_ptr`].
    ///
    /// Úprava kontajnera, na ktorý odkazuje tento plátok, môže spôsobiť opätovné pridelenie jeho vyrovnávacej pamäte, čo by tiež zneplatnilo všetky ukazovatele na neho.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Vráti nebezpečný premenlivý ukazovateľ do vyrovnávacej pamäte rezu.
    ///
    /// Volajúci musí zabezpečiť, aby plátok prežil ukazovateľ, ktorý táto funkcia vráti, inak skončí ukazovaním na odpadky.
    ///
    /// Úprava kontajnera, na ktorý odkazuje tento plátok, môže spôsobiť opätovné pridelenie jeho vyrovnávacej pamäte, čo by tiež zneplatnilo všetky ukazovatele na neho.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Vráti dva nespracované ukazovatele, ktoré sa nachádzajú nad rezom.
    ///
    /// Vrátený rozsah je napoly otvorený, čo znamená, že koncový ukazovateľ ukazuje *jeden za* posledný prvok rezu.
    /// Týmto spôsobom je prázdny rez reprezentovaný dvoma rovnakými ukazovateľmi a rozdiel medzi týmito dvoma ukazovateľmi predstavuje veľkosť rezu.
    ///
    /// Pozri [`as_ptr`] pre varovania o používaní týchto ukazovateľov.Koncový ukazovateľ vyžaduje mimoriadnu opatrnosť, pretože nesmeruje na platný prvok v reze.
    ///
    /// Táto funkcia je užitočná na interakciu s cudzími rozhraniami, ktoré používajú dva ukazovatele na odkaz na celý rad prvkov v pamäti, ako je to bežné v C++ .
    ///
    ///
    /// Môže byť tiež užitočné skontrolovať, či ukazovateľ na prvok odkazuje na prvok tohto rezu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // BEZPEČNOSŤ: Model `add` je tu bezpečný, pretože:
        //
        //   - Oba ukazovatele sú súčasťou toho istého objektu, pretože sa počíta aj ukazovanie priamo za objekt.
        //
        //   - Veľkosť rezu nikdy nie je väčšia ako isize::MAX bajtov, ako je uvedené tu:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Nie je zahrnuté žiadne zalamovanie, pretože rezy sa nezalomia za koniec adresného priestoru.
        //
        // Pozrite si dokumentáciu k pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Vráti dva nebezpečné premenlivé ukazovatele, ktoré sa nachádzajú nad rezom.
    ///
    /// Vrátený rozsah je napoly otvorený, čo znamená, že koncový ukazovateľ ukazuje *jeden za* posledný prvok rezu.
    /// Týmto spôsobom je prázdny rez reprezentovaný dvoma rovnakými ukazovateľmi a rozdiel medzi týmito dvoma ukazovateľmi predstavuje veľkosť rezu.
    ///
    /// Pozri [`as_mut_ptr`] pre varovania o používaní týchto ukazovateľov.
    /// Koncový ukazovateľ vyžaduje mimoriadnu opatrnosť, pretože nesmeruje na platný prvok v reze.
    ///
    /// Táto funkcia je užitočná na interakciu s cudzími rozhraniami, ktoré používajú dva ukazovatele na odkaz na celý rad prvkov v pamäti, ako je to bežné v C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // BEZPEČNOSŤ: Prečo je `add` bezpečný, pozri as_ptr_range() vyššie.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Zamení dva prvky v reze.
    ///
    /// # Arguments
    ///
    /// * a, Index prvého prvku
    /// * b, Index druhého prvku
    ///
    /// # Panics
    ///
    /// Panics, ak sú hodnoty `a` alebo `b` za hranicami.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Z jedného vector si nemôžete vziať dve premenlivé pôžičky, takže namiesto toho použite surové ukazovatele.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // BEZPEČNOSŤ: `pa` a `pb` boli vytvorené z bezpečných premenlivých referencií a referencií
        // k prvkom v reze, a preto sú zaručene platné a zarovnané.
        // Upozorňujeme, že prístup k prvkom za `a` a `b` je začiarknutý a bude panic, keď bude mimo hraníc.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Obráti poradie prvkov v reze na danom mieste.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Pri veľmi malých typoch vykazuje každý jednotlivec čítaný normálnou cestou slabý výkon.
        // Môžeme to urobiť lepšie, ak vezmeme do úvahy efektívnu nezaradenú load/store, načítaním väčšieho bloku a obrátením registra.
        //

        // V ideálnom prípade by to LLVM urobil za nás, pretože vie lepšie ako my, či sú nevyrovnané čítania efektívne (pretože sa to mení napríklad medzi rôznymi verziami ARM) a aká by bola najlepšia veľkosť bloku.
        // Bohužiaľ, od LLVM 4.0 (2017-05) iba odvíja slučku, takže to musíme urobiť sami.
        // (Hypotéza: reverz je nepríjemný, pretože strany môžu byť zarovnané inak-budú, keď bude dĺžka nepárna-takže neexistuje spôsob, ako emitovať pred a po prelúdiách, aby sa v strede použila úplne vyrovnaná SIMD.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Použite vnútorný llvm.bswap na obrátenie u8s vo veľkosti
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // BEZPEČNOSŤ: Tu je možné skontrolovať niekoľko vecí:
                //
                // - Všimnite si, že `chunk` je buď 4 alebo 8 kvôli kontrole CFG vyššie.`chunk - 1` je teda pozitívny.
                // - Indexovanie s indexom `i` je v poriadku, pretože to zaručuje kontrola slučky
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indexovanie s indexom `ln - i - chunk = ln - (i + chunk)` je v poriadku:
                //   - `i + chunk > 0` je triviálne pravda.
                //   - Kontrola slučky zaručuje:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, takže odčítanie nepreteká.
                // - Hovory `read_unaligned` a `write_unaligned` sú v poriadku:
                //   - `pa` ukazuje na index `i`, kde `i < ln / 2 - (chunk - 1)` (pozri vyššie) a `pb` smeruje na index `ln - i - chunk`, takže obe sú od konca `self` vzdialené najmenej `chunk` a mnoho bajtov.
                //
                //   - Akákoľvek inicializovaná pamäť je platná `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Ak chcete v modeli u32 obrátiť u16s, použite otočenie o 16
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // BEZPEČNOSŤ: Nezaradený u32 je možné načítať z `i`, ak `i + 1 < ln`
                // (a samozrejme `i < ln`), pretože každý prvok má 2 bajty a čítame 4.
                //
                // `i + chunk - 1 < ln / 2` # zatiaľ čo stav
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Pretože je to menej ako dĺžka vydelená dvoma, musí to byť v hraniciach.
                //
                // To tiež znamená, že je vždy dodržaná podmienka `0 < i + chunk <= ln`, ktorá zaisťuje bezpečné použitie ukazovateľa `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // BEZPEČNOSŤ: `i` je horší ako polovica dĺžky plátku, takže
            // prístup k `i` a `ln - i - 1` je bezpečný (`i` začína na 0 a nepôjde ďalej ako `ln / 2 - 1`).
            // Výsledné ukazovatele `pa` a `pb` sú preto platné a zarovnané a je možné ich čítať aj zapisovať do nich.
            //
            //
            unsafe {
                // Nebezpečná zámena, aby ste sa vyhli hraniciam, skontrolujte bezpečnú zámenu.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Vráti iterátor nad rezom.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Vráti iterátor, ktorý umožňuje úpravu každej hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Vráti iterátor cez všetky súvislé windows dĺžky `size`.
    /// windows sa prekrývajú.
    /// Ak je rez kratší ako `size`, iterátor nevráti žiadne hodnoty.
    ///
    /// # Panics
    ///
    /// Panics, ak `size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ak je plátok kratší ako `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od začiatku rezu.
    ///
    /// Kusy sú plátky a neprekrývajú sa.Ak `chunk_size` nerozdeľuje dĺžku rezu, potom posledný blok nebude mať dĺžku `chunk_size`.
    ///
    /// Pozri [`chunks_exact`] pre variant tohto iterátora, ktorý vracia bloky vždy presne `chunk_size` prvkov, a [`rchunks`] pre ten istý iterátor, ale začínajúci na konci rezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od začiatku rezu.
    ///
    /// Kusy sú premenlivé plátky a neprekrývajú sa.Ak `chunk_size` nerozdeľuje dĺžku rezu, potom posledný blok nebude mať dĺžku `chunk_size`.
    ///
    /// Pozri [`chunks_exact_mut`] pre variant tohto iterátora, ktorý vracia bloky vždy presne `chunk_size` prvkov, a [`rchunks_mut`] pre ten istý iterátor, ale začínajúci na konci rezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od začiatku rezu.
    ///
    /// Kusy sú plátky a neprekrývajú sa.
    /// Ak `chunk_size` nerozdeľuje dĺžku rezu, potom bude vynechaných posledných až `chunk_size-1` prvkov a bude možné ich načítať z funkcie `remainder` iterátora.
    ///
    ///
    /// Pretože má každý blok presne `chunk_size` prvky, môže kompilátor často optimalizovať výsledný kód lepšie ako v prípade [`chunks`].
    ///
    /// Viď [`chunks`] pre variant tohto iterátora, ktorý tiež vracia zvyšok ako menší blok, a [`rchunks_exact`] pre ten istý iterátor, ale začínajúci na konci rezu.
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od začiatku rezu.
    ///
    /// Kusy sú premenlivé plátky a neprekrývajú sa.
    /// Ak `chunk_size` nerozdeľuje dĺžku rezu, potom bude vynechaných posledných až `chunk_size-1` prvkov a bude možné ich načítať z funkcie `into_remainder` iterátora.
    ///
    ///
    /// Pretože má každý blok presne `chunk_size` prvky, môže kompilátor často optimalizovať výsledný kód lepšie ako v prípade [`chunks_mut`].
    ///
    /// Viď [`chunks_mut`] pre variant tohto iterátora, ktorý tiež vracia zvyšok ako menší blok, a [`rchunks_exact_mut`] pre ten istý iterátor, ale začínajúci na konci rezu.
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Rozdelí plátok na plátok polí s `N` prvkom za predpokladu, že už neexistuje žiadny zvyšok.
    ///
    ///
    /// # Safety
    ///
    /// Toto možno nazvať, iba ak
    /// - Plátok sa rozdelí presne na kúsky s `N` prvkom (alias `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // BEZPEČNOSŤ: 1-prvkové bloky nikdy nemali zvyšok
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // BEZPEČNOSŤ: Dĺžka rezu (6) je násobkom 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Boli by to nezdravé:
    /// // nechajte kúsky: &[[_;5]]= slice.as_chunks_unchecked()//Dĺžka rezu nie je násobkom 5 kusov:&[[_;0]]= slice.as_chunks_unchecked()//Kusy nulovej dĺžky nie sú nikdy povolené
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BEZPEČNOSŤ: Náš predpoklad je presne to, čo je potrebné na to, aby sme to mohli nazvať
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BEZPEČNOSŤ: Odlievame plátok prvkov `new_len * N`
        // plátok `new_len` mnohých častí `N` prvkov.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Rozdelí plátok na plátok polí s `N` prvkom počnúc od začiatku rezu a zvyšný rez s dĺžkou striktne menšou ako `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `N` je 0. Táto kontrola sa s najväčšou pravdepodobnosťou zmení na chybu kompilácie predtým, ako sa táto metóda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // BEZPEČNOSŤ: Už sme spanikárili z nuly a zabezpečené stavbou
        // že dĺžka čiastkového rezu je násobkom N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Rozdelí plátok na plátok polí s `N` prvkom, začínajúc na konci rezu, a zvyšný rez s dĺžkou striktne menšou ako `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `N` je 0. Táto kontrola sa s najväčšou pravdepodobnosťou zmení na chybu kompilácie predtým, ako sa táto metóda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // BEZPEČNOSŤ: Už sme spanikárili z nuly a zabezpečené stavbou
        // že dĺžka čiastkového rezu je násobkom N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Vráti iterátor nad `N` prvkami rezu naraz, počnúc od začiatku rezu.
    ///
    /// Časti sú referenciami poľa a neprekrývajú sa.
    /// Ak `N` nerozdeľuje dĺžku rezu, potom bude vynechaných posledných až `N-1` prvkov a bude možné ich načítať z funkcie `remainder` iterátora.
    ///
    ///
    /// Táto metóda je všeobecným ekvivalentom ekvivalentu [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics, ak `N` je 0. Táto kontrola sa s najväčšou pravdepodobnosťou zmení na chybu kompilácie predtým, ako sa táto metóda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Rozdelí plátok na plátok polí s `N` prvkom za predpokladu, že už neexistuje žiadny zvyšok.
    ///
    ///
    /// # Safety
    ///
    /// Toto možno nazvať, iba ak
    /// - Plátok sa rozdelí presne na kúsky s `N` prvkom (alias `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // BEZPEČNOSŤ: 1-prvkové bloky nikdy nemali zvyšok
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // BEZPEČNOSŤ: Dĺžka rezu (6) je násobkom 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Boli by to nezdravé:
    /// // nechajte kúsky: &[[_;5]]= slice.as_chunks_unchecked_mut()//Dĺžka rezu nie je násobkom 5 kusov:&[[_;0]]= slice.as_chunks_unchecked_mut()//Kusy nulovej dĺžky nie sú nikdy povolené
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // BEZPEČNOSŤ: Náš predpoklad je presne to, čo je potrebné na to, aby sme to mohli nazvať
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // BEZPEČNOSŤ: Odlievame plátok prvkov `new_len * N`
        // plátok `new_len` mnohých častí `N` prvkov.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Rozdelí plátok na plátok polí s `N` prvkom počnúc od začiatku rezu a zvyšný rez s dĺžkou striktne menšou ako `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `N` je 0. Táto kontrola sa s najväčšou pravdepodobnosťou zmení na chybu kompilácie predtým, ako sa táto metóda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // BEZPEČNOSŤ: Už sme spanikárili z nuly a zabezpečené stavbou
        // že dĺžka čiastkového rezu je násobkom N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Rozdelí plátok na plátok polí s `N` prvkom, začínajúc na konci rezu, a zvyšný rez s dĺžkou striktne menšou ako `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `N` je 0. Táto kontrola sa s najväčšou pravdepodobnosťou zmení na chybu kompilácie predtým, ako sa táto metóda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // BEZPEČNOSŤ: Už sme spanikárili z nuly a zabezpečené stavbou
        // že dĺžka čiastkového rezu je násobkom N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Vráti iterátor nad `N` prvkami rezu naraz, počnúc od začiatku rezu.
    ///
    /// Kusy sú premenlivé referencie poľa a neprekrývajú sa.
    /// Ak `N` nerozdeľuje dĺžku rezu, potom bude vynechaných posledných až `N-1` prvkov a bude možné ich načítať z funkcie `into_remainder` iterátora.
    ///
    ///
    /// Táto metóda je všeobecným ekvivalentom ekvivalentu [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics, ak `N` je 0. Táto kontrola sa s najväčšou pravdepodobnosťou zmení na chybu kompilácie predtým, ako sa táto metóda stabilizuje.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Vráti iterátor prekrývajúci windows z `N` prvkov rezu, počnúc od začiatku rezu.
    ///
    ///
    /// Toto je konštantný všeobecný ekvivalent [`windows`].
    ///
    /// Ak je `N` väčšia ako veľkosť rezu, nevráti windows.
    ///
    /// # Panics
    ///
    /// Panics, ak `N` je 0.
    /// Pred stabilizáciou tejto metódy sa táto kontrola s najväčšou pravdepodobnosťou zmení na chybu kompilácie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od konca rezu.
    ///
    /// Kusy sú plátky a neprekrývajú sa.Ak `chunk_size` nerozdeľuje dĺžku rezu, potom posledný blok nebude mať dĺžku `chunk_size`.
    ///
    /// Viď [`rchunks_exact`] pre variant tohto iterátora, ktorý vracia bloky vždy presne `chunk_size` prvkov, a [`chunks`] pre ten istý iterátor, ale začínajúci na začiatku rezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od konca rezu.
    ///
    /// Kusy sú premenlivé plátky a neprekrývajú sa.Ak `chunk_size` nerozdeľuje dĺžku rezu, potom posledný blok nebude mať dĺžku `chunk_size`.
    ///
    /// Viď [`rchunks_exact_mut`] pre variant tohto iterátora, ktorý vracia bloky vždy presne `chunk_size` prvkov, a [`chunks_mut`] pre ten istý iterátor, ale začínajúci na začiatku rezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od konca rezu.
    ///
    /// Kusy sú plátky a neprekrývajú sa.
    /// Ak `chunk_size` nerozdeľuje dĺžku rezu, potom bude vynechaných posledných až `chunk_size-1` prvkov a bude možné ich načítať z funkcie `remainder` iterátora.
    ///
    /// Pretože má každý blok presne `chunk_size` prvky, môže kompilátor často optimalizovať výsledný kód lepšie ako v prípade [`chunks`].
    ///
    /// Viď [`rchunks`] pre variant tohto iterátora, ktorý tiež vracia zvyšok ako menší blok, a [`chunks_exact`] pre ten istý iterátor, ale začínajúci na začiatku rezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Vráti iterátor nad `chunk_size` prvkami rezu naraz, počnúc od konca rezu.
    ///
    /// Kusy sú premenlivé plátky a neprekrývajú sa.
    /// Ak `chunk_size` nerozdeľuje dĺžku rezu, potom bude vynechaných posledných až `chunk_size-1` prvkov a bude možné ich načítať z funkcie `into_remainder` iterátora.
    ///
    /// Pretože má každý blok presne `chunk_size` prvky, môže kompilátor často optimalizovať výsledný kód lepšie ako v prípade [`chunks_mut`].
    ///
    /// Viď [`rchunks_mut`] pre variant tohto iterátora, ktorý tiež vracia zvyšok ako menší blok, a [`chunks_exact_mut`] pre ten istý iterátor, ale začínajúci na začiatku rezu.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak `chunk_size` je 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Vráti iterátor nad rezom, ktorý vytvára neprekrývajúce sa série prvkov pomocou predikátu na ich oddelenie.
    ///
    /// Predikát sa volá na dvoch nasledujúcich prvkoch, čo znamená, že sa volá na `slice[0]` a `slice[1]`, potom na `slice[1]` a `slice[2]` atď.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Touto metódou je možné extrahovať zoradené podskupiny:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Vráti iterátor nad rezom, ktorý vytvára neprekrývajúce sa premenlivé série prvkov pomocou predikátu na ich oddelenie.
    ///
    /// Predikát sa volá na dvoch nasledujúcich prvkoch, čo znamená, že sa volá na `slice[0]` a `slice[1]`, potom na `slice[1]` a `slice[2]` atď.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Touto metódou je možné extrahovať zoradené podskupiny:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Rozdelí jeden plátok na dva pri indexe.
    ///
    /// Prvý bude obsahovať všetky indexy z `[0, mid)` (okrem samotného indexu `mid`) a druhý bude obsahovať všetky indexy z `[mid, len)` (okrem samotného indexu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics ak `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // BEZPEČNOSŤ: `[ptr; mid]` a `[mid; len]` sú vo vnútri `self`, ktoré
        // spĺňa požiadavky `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Rozdelí jeden premenlivý plátok na dva pri indexe.
    ///
    /// Prvý bude obsahovať všetky indexy z `[0, mid)` (okrem samotného indexu `mid`) a druhý bude obsahovať všetky indexy z `[mid, len)` (okrem samotného indexu `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics ak `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // BEZPEČNOSŤ: `[ptr; mid]` a `[mid; len]` sú vo vnútri `self`, ktoré
        // spĺňa požiadavky `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Rozdelí jeden plátok na dva pri indexe bez kontroly hraníc.
    ///
    /// Prvý bude obsahovať všetky indexy z `[0, mid)` (okrem samotného indexu `mid`) a druhý bude obsahovať všetky indexy z `[mid, len)` (okrem samotného indexu `len`).
    ///
    ///
    /// Pre bezpečnú alternatívu pozri [`split_at`].
    ///
    /// # Safety
    ///
    /// Volanie tejto metódy s indexom out-of-bounds je *[nedefinované správanie]*, aj keď sa výsledná referencia nepoužíva.Volajúci musí zabezpečiť, aby `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // BEZPEČNOSŤ: Volajúci musí skontrolovať, či je `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Rozdelí jeden premenlivý plátok na dva pri indexe bez kontroly hraníc.
    ///
    /// Prvý bude obsahovať všetky indexy z `[0, mid)` (okrem samotného indexu `mid`) a druhý bude obsahovať všetky indexy z `[mid, len)` (okrem samotného indexu `len`).
    ///
    ///
    /// Pre bezpečnú alternatívu pozri [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Volanie tejto metódy s indexom out-of-bounds je *[nedefinované správanie]*, aj keď sa výsledná referencia nepoužíva.Volajúci musí zabezpečiť, aby `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // BEZPEČNOSŤ: Volajúci musí skontrolovať, či je `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` a `[mid; len]` sa neprekrývajú, takže vrátenie premenlivej referencie je v poriadku.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Vráti iterátor nad čiastkovými indexmi oddelenými prvkami, ktoré sa zhodujú s `pred`.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ak sa zhoduje prvý prvok, prázdny rez bude prvou položkou vrátenou iterátorom.
    /// Podobne, ak sa zhoduje posledný prvok v reze, prázdny rez bude poslednou položkou vrátenou iterátorom:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ak dva zhodné prvky priamo susedia, bude medzi nimi prázdny rez:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Vráti iterátor nad premenlivými čiastkovými indexmi oddelenými prvkami, ktoré sa zhodujú s `pred`.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Vráti iterátor nad čiastkovými indexmi oddelenými prvkami, ktoré sa zhodujú s `pred`.
    /// Zodpovedajúci prvok je obsiahnutý na konci predchádzajúceho čiastkového segmentu ako zakončovací prvok.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Ak sa zhoduje posledný prvok rezu, bude sa tento prvok považovať za zakončenie predchádzajúceho rezu.
    ///
    /// Tento plátok bude poslednou položkou vrátenou iterátorom.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Vráti iterátor nad premenlivými čiastkovými indexmi oddelenými prvkami, ktoré sa zhodujú s `pred`.
    /// Zodpovedajúci prvok je obsiahnutý v predchádzajúcom čiastkovom reze ako terminátor.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Vráti iterátor nad čiastkovými indexmi oddelenými prvkami, ktoré sa zhodujú s `pred`, začínajúc na konci rezu a pracovať dozadu.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Rovnako ako v prípade `split()`, ak sa porovná prvý alebo posledný prvok, prázdny rez bude prvou (alebo poslednou) položkou vrátenou iterátorom.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Vráti iterátor nad premenlivými čiastkovými indexmi oddelenými prvkami, ktoré sa zhodujú s `pred`, začínajúc na konci rezu a pracovať dozadu.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Vráti iterátor nad podsúbormi oddelenými prvkami, ktoré sa zhodujú s `pred`, obmedzené na vrátenie najviac `n` položiek.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// Posledný vrátený prvok, ak existuje, bude obsahovať zvyšok rezu.
    ///
    /// # Examples
    ///
    /// Vytlačte rozdelenie rezu raz na čísla deliteľné 3 (tj. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Vráti iterátor nad podsúbormi oddelenými prvkami, ktoré sa zhodujú s `pred`, obmedzené na vrátenie najviac `n` položiek.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// Posledný vrátený prvok, ak existuje, bude obsahovať zvyšok rezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Vráti iterátor nad podsúbormi oddelenými prvkami, ktoré zodpovedajú `pred`, s obmedzením na vrátenie najviac `n` položiek.
    /// Začína sa to na konci rezu a funguje to dozadu.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// Posledný vrátený prvok, ak existuje, bude obsahovať zvyšok rezu.
    ///
    /// # Examples
    ///
    /// Vytlačte rozdelenie rezov raz, počnúc koncom, číslami deliteľnými 3 (tj. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Vráti iterátor nad podsúbormi oddelenými prvkami, ktoré zodpovedajú `pred`, s obmedzením na vrátenie najviac `n` položiek.
    /// Začína sa to na konci rezu a funguje to dozadu.
    /// Zhodný prvok nie je obsiahnutý v čiastkových indexoch.
    ///
    /// Posledný vrátený prvok, ak existuje, bude obsahovať zvyšok rezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Vráti `true`, ak rez obsahuje prvok s danou hodnotou.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Ak nemáte `&T`, ale iba `&U`, taký `T: Borrow<U>` (napr
    /// `Reťazec: Požičať si<str>`), môžete použiť `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // plátok `String`
    /// assert!(v.iter().any(|e| e == "hello")); // hľadajte pomocou `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Vráti `true`, ak `needle` je predpona rezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Vždy vráti `true`, ak je `needle` prázdny rez:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Vráti `true`, ak `needle` je prípona rezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Vždy vráti `true`, ak je `needle` prázdny rez:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Vráti čiastkový rez s odstránenou predponou.
    ///
    /// Ak výrez začína na `prefix`, vráti podrezok za predponou zabalený do `Some`.
    /// Ak je `prefix` prázdny, jednoducho vráti pôvodný plátok.
    ///
    /// Ak rez nezačína na `prefix`, vráti `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Táto funkcia bude musieť byť prepísaná, ak a keď sa SlicePattern stane sofistikovanejším.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Vráti čiastkový rez s odstránenou príponou.
    ///
    /// Ak plátok končí `suffix`, vráti čiastkový rez pred príponou zabalený do `Some`.
    /// Ak je `suffix` prázdny, jednoducho vráti pôvodný plátok.
    ///
    /// Ak rez nekončí na `suffix`, vráti `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Táto funkcia bude musieť byť prepísaná, ak a keď sa SlicePattern stane sofistikovanejším.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binárne vyhľadávanie v tomto zoradenom reze pre daný prvok.
    ///
    /// Ak je hodnota nájdená, vráti sa [`Result::Ok`], ktorý obsahuje index zodpovedajúceho prvku.
    /// Ak existuje viac zhôd, potom je možné vrátiť ktorýkoľvek zo zápasov.
    /// Ak sa hodnota nenájde, vráti sa [`Result::Err`], ktorý obsahuje index, do ktorého je možné vložiť zodpovedajúci prvok pri zachovaní zoradeného poradia.
    ///
    ///
    /// Pozri tiež [`binary_search_by`], [`binary_search_by_key`] a [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vyhľadá sériu štyroch prvkov.
    /// Prvý sa nachádza s jedinečne určenou pozíciou;druhý a tretí sa nenájdu;štvrtý sa mohol zhodovať s akoukoľvek pozíciou v `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Ak chcete vložiť položku do zoradeného vector pri zachovaní poradia zoradenia:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binárne hľadanie v tomto triedenom reze pomocou funkcie komparátora.
    ///
    /// Funkcia komparátora by mala implementovať poradie, ktoré je konzistentné s poradím zoradenia podkladového rezu, vrátením kódu objednávky, ktorý označuje, či je jeho argumentom požadovaný cieľ `Less`, `Equal` alebo `Greater`.
    ///
    ///
    /// Ak je hodnota nájdená, vráti sa [`Result::Ok`], ktorý obsahuje index zodpovedajúceho prvku.Ak existuje viac zhôd, potom je možné vrátiť ktorýkoľvek zo zápasov.
    /// Ak sa hodnota nenájde, vráti sa [`Result::Err`], ktorý obsahuje index, do ktorého je možné vložiť zodpovedajúci prvok pri zachovaní zoradeného poradia.
    ///
    /// Pozri tiež [`binary_search`], [`binary_search_by_key`] a [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vyhľadá sériu štyroch prvkov.Prvý sa nachádza s jedinečne určenou pozíciou;druhý a tretí sa nenájdu;štvrtý sa mohol zhodovať s akoukoľvek pozíciou v `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // BEZPEČNOSŤ: hovor je zabezpečený nasledujúcimi invariantmi:
            // - `mid >= 0`
            // - `mid < size`: `mid` je obmedzený viazaným `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Dôvod, prečo používame skôr riadiaci tok if/else než porovnávanie, je ten, že zmeny poradia porovnávacích operácií súradníc sú citlivé.
            //
            // Toto je x86 asm pre u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binárne vyhľadávanie tohto triedeného rezu pomocou funkcie extrakcie kľúčov.
    ///
    /// Predpokladá, že plátok je zoradený podľa kľúča, napríklad pri [`sort_by_key`], ktorý používa rovnakú funkciu extrakcie kľúča.
    ///
    /// Ak je hodnota nájdená, vráti sa [`Result::Ok`], ktorý obsahuje index zodpovedajúceho prvku.
    /// Ak existuje viac zhôd, potom je možné vrátiť ktorýkoľvek zo zápasov.
    /// Ak sa hodnota nenájde, vráti sa [`Result::Err`], ktorý obsahuje index, do ktorého je možné vložiť zodpovedajúci prvok pri zachovaní zoradeného poradia.
    ///
    ///
    /// Pozri tiež [`binary_search`], [`binary_search_by`] a [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Vyhľadá sériu štyroch prvkov v plátku párov zoradených podľa druhých prvkov.
    /// Prvý sa nachádza s jedinečne určenou pozíciou;druhý a tretí sa nenájdu;štvrtý sa mohol zhodovať s akoukoľvek pozíciou v `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links je povolený, pretože `slice::sort_by_key` je v crate `alloc` a ako taký ešte neexistuje pri zostavovaní `core`.
    //
    // odkazy na následný crate: #74481.Pretože primitívne údaje sú zdokumentované iba v knižnici libstd (#73423), v praxi to nikdy nevedie k prerušeniu odkazov.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Zoradí plátok, ale nemusí zachovať poradie rovnakých prvkov.
    ///
    /// Tento druh je nestabilný (tj. Môže meniť poradie rovnakých prvkov), na mieste (tj. Neprideľuje) a *O*(*n*\*log(* n*)) v najhoršom prípade).
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je založený na [pattern-defeating quicksort][pdqsort] od Orsona Petersa, ktorý kombinuje rýchly priemerný prípad randomizovaného quicksortu s najhorším najhorším prípadom heapsortu, pričom dosahuje lineárny čas na rezoch s určitými vzormi.
    /// Využíva určitú randomizáciu, aby sa zabránilo degenerovaným prípadom, ale s pevným seed vždy poskytuje deterministické správanie.
    ///
    /// Spravidla je to rýchlejšie ako stabilné triedenie, okrem niekoľkých zvláštnych prípadov, napr. Keď plátok pozostáva z niekoľkých zreťazených triedených sekvencií.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Triedi rez podľa funkcie komparátora, ale nemusí zachovať poradie rovnakých prvkov.
    ///
    /// Tento druh je nestabilný (tj. Môže meniť poradie rovnakých prvkov), na mieste (tj. Neprideľuje) a *O*(*n*\*log(* n*)) v najhoršom prípade).
    ///
    /// Funkcia komparátora musí definovať celkové usporiadanie prvkov v reze.Ak objednávka nie je celková, nie je určené poradie prvkov.Objednávka je celková objednávka, ak je (pre všetky modely `a`, `b` a `c`):
    ///
    /// * celkový a antisymetrický: presne jeden z `a < b`, `a == b` alebo `a > b` je pravdivý a
    /// * tranzitívne, `a < b` a `b < c` znamená `a < c`.To isté musí platiť pre `==` aj `>`.
    ///
    /// Napríklad zatiaľ čo [`f64`] neimplementuje [`Ord`], pretože `NaN != NaN`, môžeme použiť `partial_cmp` ako našu funkciu triedenia, keď vieme, že rez neobsahuje `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je založený na [pattern-defeating quicksort][pdqsort] od Orsona Petersa, ktorý kombinuje rýchly priemerný prípad randomizovaného quicksortu s najhorším najhorším prípadom heapsortu, pričom dosahuje lineárny čas na rezoch s určitými vzormi.
    /// Využíva určitú randomizáciu, aby sa zabránilo degenerovaným prípadom, ale s pevným seed vždy poskytuje deterministické správanie.
    ///
    /// Spravidla je to rýchlejšie ako stabilné triedenie, okrem niekoľkých zvláštnych prípadov, napr. Keď plátok pozostáva z niekoľkých zreťazených triedených sekvencií.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // spätné triedenie
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Zoradí plátok podľa funkcie extrakcie kľúčov, nemusí však zachovať poradie rovnakých prvkov.
    ///
    /// Tento druh je nestabilný (tj. Môže meniť poradie rovnakých prvkov), na mieste (tj. Neprideľuje) a *O*(m\* * n *\* log(*n*)) najhorší prípad, kde je kľúčová funkcia *O*(*m*).
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je založený na [pattern-defeating quicksort][pdqsort] od Orsona Petersa, ktorý kombinuje rýchly priemerný prípad randomizovaného quicksortu s najhorším najhorším prípadom heapsortu, pričom dosahuje lineárny čas na rezoch s určitými vzormi.
    /// Využíva určitú randomizáciu, aby sa zabránilo degenerovaným prípadom, ale s pevným seed vždy poskytuje deterministické správanie.
    ///
    /// Vďaka svojej hlavnej stratégii volania bude [`sort_unstable_by_key`](#method.sort_unstable_by_key) pravdepodobne pomalší ako [`sort_by_cached_key`](#method.sort_by_cached_key) v prípadoch, keď je kľúčová funkcia drahá.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Zmeňte poradie rezu tak, aby bol prvok v `index` na svojej konečnej zoradenej polohe.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Znovu usporiadajte výrez s funkciou komparátora tak, aby bol prvok v `index` vo svojej konečnej zoradenej polohe.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Zmeňte poradie rezu pomocou funkcie extrakcie klávesov tak, aby bol prvok v `index` vo svojej konečnej zoradenej polohe.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Zmeňte poradie rezu tak, aby bol prvok v `index` na svojej konečnej zoradenej polohe.
    ///
    /// Toto doobjednávanie má ďalšiu vlastnosť, že akákoľvek hodnota na pozícii `i < index` bude menšia alebo rovná akejkoľvek hodnote na pozícii `j > index`.
    /// Toto doobjednávanie je navyše nestabilné (tj
    /// ľubovoľný počet rovnakých prvkov môže skončiť na pozícii `index`), na mieste (tj
    /// neprideľuje) a najhorší prípad *O*(*n*).
    /// Táto funkcia je v iných knižniciach tiež známa ako "kth element".
    /// Vráti triplet nasledujúcich hodnôt: všetky prvky menšie ako ten v danom indexe, hodnota v danom indexe a všetky prvky väčšie ako ten v danom indexe.
    ///
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je založený na časti rýchleho výberu rovnakého algoritmu rýchleho triedenia použitého pre [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics keď `index >= len()`, čo znamená, že vždy panics na prázdnych rezoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Nájdite medián
    /// v.select_nth_unstable(2);
    ///
    /// // Zaručujeme iba to, že rez bude jedným z nasledujúcich, a to na základe spôsobu triedenia podľa zadaného indexu.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Znovu usporiadajte výrez s funkciou komparátora tak, aby bol prvok v `index` vo svojej konečnej zoradenej polohe.
    ///
    /// Toto doobjednávanie má ďalšiu vlastnosť, že akákoľvek hodnota na pozícii `i < index` bude menšia alebo rovná akejkoľvek hodnote na pozícii `j > index` pomocou funkcie komparátora.
    /// Toto doobjednávanie je navyše nestabilné (tj ľubovoľný počet rovnakých prvkov môže skončiť na pozícii `index`), na mieste (tj. Neprideľuje) a najhorší prípad *O*(*n*).
    /// Táto funkcia je v iných knižniciach známa ako "kth element".
    /// Vracia triplet z nasledujúcich hodnôt: všetky prvky menšie ako ten v danom indexe, hodnota v danom indexe a všetky prvky väčšie ako ten v danom indexe, pomocou poskytnutej porovnávacej funkcie.
    ///
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je založený na časti rýchleho výberu rovnakého algoritmu rýchleho triedenia použitého pre [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics keď `index >= len()`, čo znamená, že vždy panics na prázdnych rezoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Nájdite medián, akoby bol plátok zoradený zostupne.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Zaručujeme iba to, že rez bude jedným z nasledujúcich, a to na základe spôsobu triedenia podľa zadaného indexu.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Zmeňte poradie rezu pomocou funkcie extrakcie klávesov tak, aby bol prvok v `index` vo svojej konečnej zoradenej polohe.
    ///
    /// Toto doobjednávanie má ďalšiu vlastnosť, že akákoľvek hodnota na pozícii `i < index` bude menšia alebo rovnaká ako akákoľvek hodnota na pozícii `j > index` pomocou funkcie extrakcie kľúča.
    /// Toto doobjednávanie je navyše nestabilné (tj ľubovoľný počet rovnakých prvkov môže skončiť na pozícii `index`), na mieste (tj. Neprideľuje) a najhorší prípad *O*(*n*).
    /// Táto funkcia je v iných knižniciach známa ako "kth element".
    /// Vráti triplet nasledujúcich hodnôt: pomocou poskytnutej funkcie extrakcie kľúčov vráti všetky prvky menšie ako ten v danom indexe, hodnotu v danom indexe a všetky prvky väčšie ako ten v danom indexe.
    ///
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je založený na časti rýchleho výberu rovnakého algoritmu rýchleho triedenia použitého pre [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics keď `index >= len()`, čo znamená, že vždy panics na prázdnych rezoch.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Vráťte strednú hodnotu, akoby bolo pole zoradené podľa absolútnej hodnoty.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Zaručujeme iba to, že rez bude jedným z nasledujúcich, a to na základe spôsobu triedenia podľa zadaného indexu.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Presunie všetky po sebe idúce opakované prvky na koniec rezu podľa implementácie [`PartialEq`] trait.
    ///
    ///
    /// Vráti dva plátky.Prvý neobsahuje žiadne po sebe nasledujúce opakujúce sa prvky.
    /// Druhá obsahuje všetky duplikáty v nezadanom poradí.
    ///
    /// Ak je plátok zoradený, prvý vrátený plátok neobsahuje žiadne duplikáty.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Presunie všetky nasledujúce prvky okrem prvého na koniec rezu, ktorý spĺňa daný vzťah rovnosti.
    ///
    /// Vráti dva plátky.Prvý neobsahuje žiadne po sebe nasledujúce opakujúce sa prvky.
    /// Druhá obsahuje všetky duplikáty v nezadanom poradí.
    ///
    /// Funkcii `same_bucket` sa odovzdávajú odkazy na dva prvky z rezu a musí sa určiť, či sa prvky porovnávajú rovnako.
    /// Prvky sa odovzdávajú v opačnom poradí od ich poradia v reze, takže ak `same_bucket(a, b)` vráti `true`, `a` sa presunie na koniec rezu.
    ///
    ///
    /// Ak je plátok zoradený, prvý vrátený plátok neobsahuje žiadne duplikáty.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Aj keď máme premenlivý odkaz na `self`, nemôžeme robiť *ľubovoľné* zmeny.Hovory `same_bucket` môžu panic, takže musíme zaistiť, aby bol rez vždy v platnom stave.
        //
        // Riešime to pomocou swapov;iterujeme cez všetky prvky a priebežne ich striedame, takže na konci budú prvky, ktoré si chceme ponechať, vpredu a tie, ktoré chceme odmietnuť, vzadu.
        // Potom môžeme plátok rozdeliť.
        // Táto operácia je stále `O(n)`.
        //
        // Príklad: Začíname v tomto stave, kde `r` predstavuje " ďalší
        // čítať " a `w` predstavuje" ďalšie_písanie `.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // V porovnaní s self[r] proti sebe [w-1] nejde o duplikát, takže zameníme self[r] a self[w] (žiadny efekt ako r==w) a potom zvýšime obidve r a w, takže nám zostáva:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // V porovnaní s self[r] proti sebe [w-1] je táto hodnota duplikát, takže zvyšujeme `r`, ale všetko ostatné nechávame nezmenené:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // V porovnaní s self[r] proti sebe [w-1] nejde o duplikát, preto vymeňte self[r] a self[w] a posuňte r a w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Nejde o duplikát, opakujte:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplikát, advance r. End rezu.Rozdeliť na w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // BEZPEČNOSŤ: stav `while` zaručuje `next_read` a `next_write`
        // sú menšie ako `len`, teda sú vo vnútri `self`.
        // `prev_ptr_write` ukazuje na jeden prvok pred `ptr_write`, ale `next_write` začína na 1, takže `prev_ptr_write` nikdy nie je menší ako 0 a je vo vnútri rezu.
        // Týmto sú splnené požiadavky na dereferencovanie `ptr_read`, `prev_ptr_write` a `ptr_write` a na používanie `ptr.add(next_read)`, `ptr.add(next_write - 1)` a `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` sa tiež zvyšuje najviac raz za slučku, čo znamená, že sa nepreskočí žiadny prvok, keď bude treba ho vymeniť.
        //
        // `ptr_read` a `prev_ptr_write` nikdy neukazujú na rovnaký prvok.To je potrebné, aby boli modely `&mut *ptr_read`, `&mut* prev_ptr_write` bezpečné.
        // Vysvetlenie je jednoduché, že `next_read >= next_write` je vždy pravdivá, teda aj `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Vyhnite sa hraničným kontrolám pomocou nespracovaných ukazovateľov.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Presunie všetky po sebe idúce prvky okrem prvého na koniec rezu, ktoré prechádzajú na rovnaký kľúč.
    ///
    ///
    /// Vráti dva plátky.Prvý neobsahuje žiadne po sebe nasledujúce opakujúce sa prvky.
    /// Druhá obsahuje všetky duplikáty v nezadanom poradí.
    ///
    /// Ak je plátok zoradený, prvý vrátený plátok neobsahuje žiadne duplikáty.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Otočí plátok na mieste tak, aby sa prvé prvky `mid` rezu presunuli na koniec, zatiaľ čo posledné prvky `self.len() - mid` smerom dopredu.
    /// Po zavolaní `rotate_left` sa prvok, ktorý sa predtým nachádzal v indexe `mid`, stane prvým prvkom v reze.
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak je `mid` väčšia ako dĺžka rezu.Všimnite si, že `mid == self.len()` robí _not_ panic a je to no-op rotácia.
    ///
    /// # Complexity
    ///
    /// Berie to lineárne (v čase `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Otáčanie podsekcie:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // BEZPEČNOSŤ: Rozsah `[p.add(mid) - mid, p.add(mid) + k)` je triviálny
        // platí pre čítanie a zápis, ako to vyžaduje `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Otočí plátok na mieste tak, aby sa prvé prvky `self.len() - k` rezu presunuli na koniec, zatiaľ čo posledné prvky `k` smerom dopredu.
    /// Po zavolaní `rotate_right` sa prvok, ktorý sa predtým nachádzal v indexe `self.len() - k`, stane prvým prvkom v reze.
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak je `k` väčšia ako dĺžka rezu.Všimnite si, že `k == self.len()` robí _not_ panic a je to no-op rotácia.
    ///
    /// # Complexity
    ///
    /// Berie to lineárne (v čase `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Otočiť podrezok:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // BEZPEČNOSŤ: Rozsah `[p.add(mid) - mid, p.add(mid) + k)` je triviálny
        // platí pre čítanie a zápis, ako to vyžaduje `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Naplní `self` prvkami klonovaním `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Vyplní `self` prvkami vrátenými opakovaným volaním uzávierky.
    ///
    /// Táto metóda používa uzáver na vytvorenie nových hodnôt.Ak chcete radšej [`Clone`] danej hodnoty, použite [`fill`].
    /// Ak chcete na generovanie hodnôt použiť [`Default`] trait, môžete zadať [`Default::default`] ako argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Skopíruje prvky z `src` do `self`.
    ///
    /// Dĺžka `src` musí byť rovnaká ako `self`.
    ///
    /// Ak `T` implementuje `Copy`, môže byť efektívnejšie používať [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak majú dva plátky rôzne dĺžky.
    ///
    /// # Examples
    ///
    /// Klonovanie dvoch prvkov z rezu do iného:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Pretože rezy musia mať rovnakú dĺžku, rozdelíme zdrojový rez na štyri prvky na dva.
    /// // Ak to neurobíme, bude panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust vynúti, že môže existovať iba jeden premenlivý odkaz bez nemenných odkazov na konkrétny údaj v konkrétnom rozsahu.
    /// Z tohto dôvodu bude mať pokus o použitie `clone_from_slice` na jednom reze za následok zlyhanie kompilácie:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Aby sme to obišli, môžeme pomocou [`split_at_mut`] vytvoriť dva odlišné čiastkové rezy z rezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Skopíruje všetky prvky z `src` do `self` pomocou memcpy.
    ///
    /// Dĺžka `src` musí byť rovnaká ako `self`.
    ///
    /// Ak `T` neimplementuje `Copy`, použite [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak majú dva plátky rôzne dĺžky.
    ///
    /// # Examples
    ///
    /// Kopírovanie dvoch prvkov z rezu do iného:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Pretože rezy musia mať rovnakú dĺžku, rozdelíme zdrojový rez na štyri prvky na dva.
    /// // Ak to neurobíme, bude panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust vynúti, že môže existovať iba jeden premenlivý odkaz bez nemenných odkazov na konkrétny údaj v konkrétnom rozsahu.
    /// Z tohto dôvodu bude mať pokus o použitie `copy_from_slice` na jednom reze za následok zlyhanie kompilácie:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Aby sme to obišli, môžeme pomocou [`split_at_mut`] vytvoriť dva odlišné čiastkové rezy z rezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Cesta kódu panic bola vložená do studenej funkcie, aby nenafúkla miesto volania.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // BEZPEČNOSŤ: `self` je podľa definície platný pre prvky `self.len()` a `src` áno
        // začiarknuté, aby mali rovnakú dĺžku.
        // Rezy sa nemôžu prekrývať, pretože premenlivé odkazy sú exkluzívne.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Skopíruje prvky z jednej časti rezu do inej časti pomocou memmove.
    ///
    /// `src` je rozsah v rámci `self`, z ktorého sa má kopírovať.
    /// `dest` je počiatočný index rozsahu v rámci `self`, do ktorého sa má kopírovať, ktorý bude mať rovnakú dĺžku ako `src`.
    /// Tieto dva rozsahy sa môžu prekrývať.
    /// Konce týchto dvoch rozsahov musia byť menšie alebo rovné `self.len()`.
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak buď rozsah presahuje koniec rezu, alebo ak je koniec `src` pred začiatkom.
    ///
    ///
    /// # Examples
    ///
    /// Kopírovanie štyroch bajtov v reze:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // BEZPEČNOSŤ: podmienky pre `ptr::copy` boli skontrolované vyššie,
        // ako tie pre `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Zamení všetky prvky v `self` za prvky v `other`.
    ///
    /// Dĺžka `other` musí byť rovnaká ako `self`.
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak majú dva plátky rôzne dĺžky.
    ///
    /// # Example
    ///
    /// Zamieňanie dvoch prvkov medzi plátkami:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust vynúti, že na konkrétny údaj v konkrétnom rozsahu môže existovať iba jeden premenlivý odkaz.
    ///
    /// Z tohto dôvodu bude mať pokus o použitie `swap_with_slice` na jednom reze za následok zlyhanie kompilácie:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Aby sme to obišli, môžeme pomocou [`split_at_mut`] vytvoriť dva odlišné premenlivé čiastkové rezy z rezu:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // BEZPEČNOSŤ: `self` je podľa definície platný pre prvky `self.len()` a `src` áno
        // začiarknuté, aby mali rovnakú dĺžku.
        // Rezy sa nemôžu prekrývať, pretože premenlivé odkazy sú exkluzívne.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funkcia na výpočet dĺžok stredného a zadného rezu pre `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Čo urobíme s `rest`, je prísť na to, koľko násobkov znakov " U`môžeme vložiť do najnižšieho počtu znakov " T`.
        //
        // A koľko `T` potrebujeme pre každú takúto "multiple".
        //
        // Uvažujme napríklad T=u8 U=u16.Potom môžeme dať 1 U do 2 Ts.Jednoduché.
        // Teraz zvážte napríklad prípad, keď size_of: :<T>=16, size_of::<U>=24.</u>
        // Môžeme dať 2 nás na miesto každého 3 Ts do rezu `rest`.
        // Trochu komplikovanejšie.
        //
        // Vzorec na výpočet je:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Rozšírené a zjednodušené:
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Našťastie sa to všetko neustále vyhodnocuje ... na výkonnosti tu nezáleží!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iteratívny Steinov algoritmus Tento `const fn` by sme mali stále robiť (a ak to urobíme, vrátiť sa k rekurzívnemu algoritmu), pretože spoliehať sa na to, že to všetko bude lvvm, je ... no, je mi to nepríjemné.
            //
            //

            // BEZPEČNOSŤ: `a` a `b` sa kontrolujú ako nenulové hodnoty.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // odstrániť všetky faktory 2 z b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // BEZPEČNOSŤ: `b` je zaškrtnutá ako nenulová.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Vyzbrojení týmito poznatkami môžeme zistiť, koľko `U` sa zmestíme!
        let us_len = self.len() / ts * us;
        // A koľko `T` bude v koncovom plátku!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmutujte plátok na plátok iného typu a zabezpečte, aby sa zachovalo zarovnanie typov.
    ///
    /// Táto metóda rozdelí plátok na tri odlišné plátky: predponu, správne zarovnaný stredný plátok nového typu a príponový plátok.
    /// Metóda môže urobiť zo stredného rezu najväčšiu možnú dĺžku pre daný typ a vstupný rez, ale na tom by mal závisieť iba výkon vášho algoritmu, nie jeho správnosť.
    ///
    /// Je prípustné, aby sa všetky vstupné údaje vrátili ako predpona alebo prípona.
    ///
    /// Táto metóda nemá zmysel, keď má vstupný prvok `T` alebo výstupný prvok `U` nulovú veľkosť a vráti pôvodný rez bez rozdelenia.
    ///
    /// # Safety
    ///
    /// Táto metóda je v podstate `transmute`, pokiaľ ide o prvky vo vrátenom strednom reze, takže tu platia aj všetky obvyklé výhrady týkajúce sa `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Všimnite si, že väčšina z tejto funkcie bude neustále hodnotená,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manipulujte so ZST špeciálne, čo je-vôbec s nimi nemanipulujte.
            return (self, &[], &[]);
        }

        // Najskôr zistíme, v ktorom bode sa rozdelíme medzi prvý a druhý plátok.
        // Jednoduché s ptr.align_offset.
        let ptr = self.as_ptr();
        // BEZPEČNOSŤ: Podrobné bezpečnostné poznámky nájdete v metóde `align_to_mut`.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // BEZPEČNOSŤ: teraz je `rest` definitívne zarovnaný, takže nižšie uvedený `from_raw_parts` je v poriadku,
            // pretože volajúci zaručuje, že môžeme bezpečne transformovať `T` na `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmutujte plátok na plátok iného typu a zabezpečte, aby sa zachovalo zarovnanie typov.
    ///
    /// Táto metóda rozdelí plátok na tri odlišné plátky: predponu, správne zarovnaný stredný plátok nového typu a príponový plátok.
    /// Metóda môže urobiť zo stredného rezu najväčšiu možnú dĺžku pre daný typ a vstupný rez, ale na tom by mal závisieť iba výkon vášho algoritmu, nie jeho správnosť.
    ///
    /// Je prípustné, aby sa všetky vstupné údaje vrátili ako predpona alebo prípona.
    ///
    /// Táto metóda nemá zmysel, keď má vstupný prvok `T` alebo výstupný prvok `U` nulovú veľkosť a vráti pôvodný rez bez rozdelenia.
    ///
    /// # Safety
    ///
    /// Táto metóda je v podstate `transmute`, pokiaľ ide o prvky vo vrátenom strednom reze, takže tu platia aj všetky obvyklé výhrady týkajúce sa `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Všimnite si, že väčšina z tejto funkcie bude neustále hodnotená,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // manipulujte so ZST špeciálne, čo je-vôbec s nimi nemanipulujte.
            return (self, &mut [], &mut []);
        }

        // Najskôr zistíme, v ktorom bode sa rozdelíme medzi prvý a druhý plátok.
        // Jednoduché s ptr.align_offset.
        let ptr = self.as_ptr();
        // BEZPEČNOSŤ: Tu zaisťujeme, že pre U použijeme zarovnané ukazovatele na U
        // zvyšok metódy.To sa deje odovzdaním ukazovateľa na&[T] so zarovnaním zameraným na U.
        // `crate::ptr::align_offset` sa volá so správne zarovnaným a platným ukazovateľom `ptr` (pochádza z odkazu na `self`) a s veľkosťou, ktorá je silou dvoch (pretože pochádza zo zarovnania pre U) a spĺňa jeho bezpečnostné obmedzenia.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Potom už nebudeme môcť používať `rest`, to by zneplatnilo jeho alias `mut_ptr`!BEZPEČNOSŤ: pozri komentáre k `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Skontroluje, či sú prvky tohto rezu zoradené.
    ///
    /// To znamená, že pre každý prvok `a` a jeho nasledujúci prvok `b` musí `a <= b` platiť.Ak výrez poskytuje presne nulu alebo jeden prvok, vráti sa `true`.
    ///
    /// Upozorňujeme, že ak `Self::Item` je iba `PartialOrd`, ale nie `Ord`, vyššie uvedená definícia znamená, že táto funkcia vráti `false`, ak nie sú dve po sebe nasledujúce položky porovnateľné.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Skontroluje, či sú prvky tohto rezu triedené pomocou danej komparačnej funkcie.
    ///
    /// Namiesto použitia `PartialOrd::partial_cmp` táto funkcia používa danú funkciu `compare` na určenie poradia dvoch prvkov.
    /// Okrem toho je to ekvivalent [`is_sorted`];ďalšie informácie nájdete v jeho dokumentácii.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Skontroluje, či sú prvky tohto rezu triedené pomocou danej funkcie extrakcie kľúčov.
    ///
    /// Namiesto priameho porovnania prvkov rezu táto funkcia porovnáva kľúče prvkov, ako to určuje `f`.
    /// Okrem toho je to ekvivalent [`is_sorted`];ďalšie informácie nájdete v jeho dokumentácii.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Vráti index bodu oddielu podľa daného predikátu (index prvého prvku druhého oddielu).
    ///
    /// Predpokladá sa, že plátok je rozdelený podľa daného predikátu.
    /// To znamená, že všetky prvky, pre ktoré predikát vráti hodnotu true, sú na začiatku rezu a všetky prvky, pre ktoré predikát vráti hodnotu false, sú na konci.
    ///
    /// Napríklad [7, 15, 3, 5, 4, 12, 6] je rozdelený pod predikát x% 2!=0 (všetky nepárne čísla sú na začiatku, všetky dokonca na konci).
    ///
    /// Ak tento rez nie je rozdelený na oddiely, je vrátený výsledok nešpecifikovaný a nezmyselný, pretože táto metóda vykonáva druh binárneho vyhľadávania.
    ///
    /// Pozri tiež [`binary_search`], [`binary_search_by`] a [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // BEZPEČNOSŤ: Keď `left < right`, `left <= mid < right`.
            // Preto `left` vždy rastie a `right` vždy klesá a je vybratá ktorákoľvek z nich.V obidvoch prípadoch je `left <= right` spokojný.Ak je teda `left < right` v jednom kroku, `left <= right` je v ďalšom kroku spokojný.
            //
            // Preto pokiaľ je `left != right`, `0 <= left < right <= len` je spokojný, a ak je tento prípad, je spokojný aj `0 <= mid < len`.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Musíme ich vyslovene nakrájať na rovnakú dĺžku
        // aby optimalizátor ľahšie nemusel kontrolovať hranice.
        // Ale keďže sa na ňu nemožno spoľahnúť, máme pre T: Copy aj výslovnú špecializáciu.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Vytvorí prázdny plátok.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Vytvorí premenlivý prázdny plátok.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Vzory v rezoch, ktoré v súčasnosti používajú iba modely `strip_prefix` a `strip_suffix`.
/// Dúfame, že v bode future zovšeobecníme `core::str::Pattern` (ktorý je v čase písania článku obmedzený na `str`) na plátky a potom bude tento trait nahradený alebo zrušený.
///
pub trait SlicePattern {
    /// Typ prvku spojeného rezu.
    type Item;

    /// V súčasnosti potrebujú zákazníci modelu `SlicePattern` plátok.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}