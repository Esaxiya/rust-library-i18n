//! Bezplatné funkcie na vytváranie modelov `&[T]` a `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Vytvorí výrez z ukazovateľa a dĺžky.
///
/// Argument `len` predstavuje počet **prvkov**, nie počet bajtov.
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `data` musí byť [valid] pre čítanie pre `len * mem::size_of::<T>()` veľa bajtov a musí byť správne zarovnaný.To znamená najmä:
///
///     * Celý rozsah pamäte tohto rezu musí byť obsiahnutý v jednom pridelenom objekte!
///       Pláty sa nikdy nemôžu rozprestierať na viacerých pridelených objektoch.Pozri príklad [below](#incorrect-usage), ktorý to nesprávne neberie do úvahy.
///     * `data` musí byť nenulové a zarovnané dokonca aj pre rezy s nulovou dĺžkou.
///     Jedným z dôvodov je to, že optimalizácia rozloženia enum sa môže spoliehať na to, že referencie (vrátane rezov ľubovoľnej dĺžky) sú zarovnané a nenulové, aby ich odlíšili od ostatných údajov.
///     Ukazovateľ, ktorý je použiteľný ako `data` pre rezy s nulovou dĺžkou, môžete získať pomocou [`NonNull::dangling()`].
///
/// * `data` musí ukazovať na `len` po sebe nasledujúcich správne inicializovaných hodnôt typu `T`.
///
/// * Pamäť, na ktorú sa odkazuje vrátený rez, nesmie byť mutovaná počas celej životnosti `'a`, s výnimkou vnútri `UnsafeCell`.
///
/// * Celková veľkosť rezu `len * mem::size_of::<T>()` nesmie byť väčšia ako `isize::MAX`.
///   Prečítajte si bezpečnostnú dokumentáciu k [`pointer::offset`].
///
/// # Caveat
///
/// Životnosť vráteného rezu je odvodená z jeho použitia.
/// Aby sa zabránilo náhodnému zneužitiu, navrhuje sa viazať životnosť na ktorúkoľvek životnosť zdroja, ktorá je v kontexte bezpečná, napríklad poskytnutím pomocnej funkcie, ktorá vezme životnosť hostiteľskej hodnoty pre rez, alebo explicitnou anotáciou.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // prejaviť rez pre jeden prvok
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Nesprávne použitie
///
/// Nasledujúca funkcia `join_slices` je **nezdravá** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Vyššie uvedené tvrdenie zaručuje, že `fst` a `snd` sú susediace, ale stále môžu byť obsiahnuté v _different allocated objects_, v takom prípade je vytvorenie tohto rezu nedefinované správanie.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` a `b` sú rôzne pridelené objekty ...
///     let a = 42;
///     let b = 27;
///     // ... ktoré môžu byť napriek tomu súvisle uložené v pamäti: a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Vykonáva rovnakú funkcionalitu ako [`from_raw_parts`], až na to, že sa vráti premenlivý rez.
///
/// # Safety
///
/// Správanie nie je definované, ak dôjde k porušeniu niektorej z nasledujúcich podmienok:
///
/// * `data` musí byť [valid] pre čítanie aj zápis pre `len * mem::size_of::<T>()` veľa bajtov a musí byť správne zarovnaný.To znamená najmä:
///
///     * Celý rozsah pamäte tohto rezu musí byť obsiahnutý v jednom pridelenom objekte!
///       Pláty sa nikdy nemôžu rozprestierať na viacerých pridelených objektoch.
///     * `data` musí byť nenulové a zarovnané dokonca aj pre rezy s nulovou dĺžkou.
///     Jedným z dôvodov je to, že optimalizácia rozloženia enum sa môže spoliehať na to, že referencie (vrátane rezov ľubovoľnej dĺžky) sú zarovnané a nenulové, aby ich odlíšili od ostatných údajov.
///
///     Ukazovateľ, ktorý je použiteľný ako `data` pre rezy s nulovou dĺžkou, môžete získať pomocou [`NonNull::dangling()`].
///
/// * `data` musí ukazovať na `len` po sebe nasledujúcich správne inicializovaných hodnôt typu `T`.
///
/// * K pamäti, na ktorú sa odkazuje vrátený rez, sa počas celej životnosti `'a` nesmie pristupovať cez žiadny iný ukazovateľ (nie je odvodený z návratovej hodnoty).
///   Prístup na čítanie aj na zápis je zakázaný.
///
/// * Celková veľkosť rezu `len * mem::size_of::<T>()` nesmie byť väčšia ako `isize::MAX`.
///   Prečítajte si bezpečnostnú dokumentáciu k [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Skonvertuje odkaz na T na plátok dĺžky 1 (bez kopírovania).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Skonvertuje odkaz na T na plátok dĺžky 1 (bez kopírovania).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}