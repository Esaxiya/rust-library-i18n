//! Makrá používané iterátormi rezov.

// Vloženie is_empty a len predstavuje obrovský rozdiel vo výkone
macro_rules! is_empty {
    // To, ako kódujeme dĺžku iterátora ZST, to funguje tak pre ZST, ako aj pre iné ako ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Aby sme sa zbavili niektorých hraničných kontrol (pozri `position`), vypočítame dĺžku trochu neočakávaným spôsobom.
// (Testované programom `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // niekedy sme použití v nebezpečnom bloku

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Táto _cannot_ používa `unchecked_sub`, pretože sme závislí na zabalení, ktoré predstavuje dĺžku dlhých iterátorov segmentov ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Vieme, že `start <= end`, takže môže robiť lepšie ako `offset_from`, ktoré musia riešiť podpísané.
            // Nastavením vhodných príznakov tu môžeme povedať LLVM, čo jej pomáha odstrániť kontroly hraníc.
            // BEZPEČNOSŤ: Podľa typu invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Tým, že tiež poviete LLVM, že ukazovatele sú od seba vzdialené presným násobkom veľkosti písma, môže optimalizovať `len() == 0` až na `start == end` namiesto `(end - start) < size`.
            //
            // BEZPEČNOSŤ: Pri invariantnom type sú ukazovatele zarovnané tak, aby
            //         vzdialenosť medzi nimi musí byť násobkom veľkosti pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Spoločná definícia iterátorov `Iter` a `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Vráti prvý prvok a posunie začiatok iterátora dopredu o 1.
        // Výrazne zvyšuje výkon v porovnaní s vloženou funkciou.
        // Iterátor nesmie byť prázdny.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Vráti posledný prvok a posunie koniec iterátora dozadu o 1.
        // Výrazne zvyšuje výkon v porovnaní s vloženou funkciou.
        // Iterátor nesmie byť prázdny.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Zmenší iterátor, keď T je ZST, posunutím konca iterátora dozadu o `n`.
        // `n` nesmie presiahnuť `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Pomocná funkcia na vytvorenie rezu z iterátora.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // BEZPEČNOSŤ: iterátor bol vytvorený z rezu s ukazovateľom
                // `self.ptr` a dĺžka `len!(self)`.
                // To zaručuje, že sú splnené všetky predpoklady pre `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Pomocná funkcia na posunutie začiatku iterátora dopredu o prvky `offset`, návrat starého začiatku.
            //
            // Nebezpečný, pretože posun nesmie presiahnuť `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // BEZPEČNOSŤ: volajúci zaručuje, že `offset` nepresiahne `self.len()`,
                    // takže tento nový ukazovateľ je vo vnútri `self` a je teda zaručene nenulové.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Pomocná funkcia na posunutie konca iterátora dozadu pomocou prvkov `offset` a vrátenie nového konca.
            //
            // Nebezpečný, pretože posun nesmie presiahnuť `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // BEZPEČNOSŤ: volajúci zaručuje, že `offset` nepresiahne `self.len()`,
                    // ktorý zaručene nepreteká `isize`.
                    // Výsledný ukazovateľ je tiež v medziach `slice`, ktorý spĺňa ďalšie požiadavky pre `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // by sa dali implementovať s plátkami, ale vyhnete sa tým hraničným kontrolám

                // BEZPEČNOSŤ: Hovory `assume` sú bezpečné, pretože ukazovateľ začiatku rezu
                // musí mať nenulovú hodnotu a rezy nad ZST musia mať tiež nenulový koncový ukazovateľ.
                // Hovor na `next_unchecked!` je bezpečný, pretože najskôr skontrolujeme, či je iterátor prázdny.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tento iterátor je teraz prázdny.
                    if mem::size_of::<T>() == 0 {
                        // Musíme to urobiť týmto spôsobom, pretože `ptr` nemusí byť nikdy 0, ale `end` môže byť (kvôli zabaleniu).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // BEZPEČNOSŤ: koniec nemôže byť 0, ak T nie je ZST, pretože ptr nie je 0 a koniec>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // BEZPEČNOSŤ: Sme v medziach.`post_inc_start` robí správnu vec aj pre ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Prepíšeme predvolenú implementáciu, ktorá používa `try_fold`, pretože táto jednoduchá implementácia generuje menej LLVM IR a rýchlejšie sa kompiluje.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Prepíšeme predvolenú implementáciu, ktorá používa `try_fold`, pretože táto jednoduchá implementácia generuje menej LLVM IR a rýchlejšie sa kompiluje.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Prepíšeme predvolenú implementáciu, ktorá používa `try_fold`, pretože táto jednoduchá implementácia generuje menej LLVM IR a rýchlejšie sa kompiluje.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Prepíšeme predvolenú implementáciu, ktorá používa `try_fold`, pretože táto jednoduchá implementácia generuje menej LLVM IR a rýchlejšie sa kompiluje.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Prepíšeme predvolenú implementáciu, ktorá používa `try_fold`, pretože táto jednoduchá implementácia generuje menej LLVM IR a rýchlejšie sa kompiluje.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Prepíšeme predvolenú implementáciu, ktorá používa `try_fold`, pretože táto jednoduchá implementácia generuje menej LLVM IR a rýchlejšie sa kompiluje.
            // Model `assume` sa tiež vyhýba hraničnej kontrole.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // BEZPEČNOSŤ: Zaručene sa nachádzame v medziach invariantnej slučky:
                        // keď `i >= n`, `self.next()` vráti `None` a slučka sa pretrhne.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Prepíšeme predvolenú implementáciu, ktorá používa `try_fold`, pretože táto jednoduchá implementácia generuje menej LLVM IR a rýchlejšie sa kompiluje.
            // Model `assume` sa tiež vyhýba hraničnej kontrole.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // BEZPEČNOSŤ: `i` musí byť nižší ako `n`, pretože začína na `n`
                        // a len klesá.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // BEZPEČNOSŤ: volajúci musí zaručiť, že hodnota `i` je v medziach
                // podkladový rez, takže `i` nemôže pretekať cez `isize` a vrátené referencie zaručene odkazujú na prvok rezu, a teda zaručene platia.
                //
                // Upozorňujeme tiež, že volajúci tiež zaručuje, že už nikdy nebudeme volať s rovnakým indexom a že sa nebudú volať žiadne ďalšie metódy, ktoré budú pristupovať k tomuto podrezaniu, takže je platné, aby bol vrátený odkaz zmeniteľný v prípade
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // by sa dali implementovať s plátkami, ale vyhnete sa tým hraničným kontrolám

                // BEZPEČNOSŤ: Hovory `assume` sú bezpečné, pretože počiatočný ukazovateľ rezu musí mať nenulovú hodnotu,
                // a rezy nad non-ZST musia mať tiež ukazovateľ nenulového konca.
                // Hovor na `next_back_unchecked!` je bezpečný, pretože najskôr skontrolujeme, či je iterátor prázdny.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Tento iterátor je teraz prázdny.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // BEZPEČNOSŤ: Sme v medziach.`pre_dec_end` robí správnu vec aj pre ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}