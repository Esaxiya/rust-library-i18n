// Pôvodná implementácia prevzatá z aplikácie rust-memchr.
// Autorské práva 2015 Andrew Gallant, bluss a Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Použite skrátenie.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Vráti `true`, ak `x` obsahuje akýkoľvek nulový bajt.
///
/// Z *Matters Computational*, J. Arndt:
///
/// " Ide o to, odčítať jeden z každého z bajtov a potom hľadať bajty, kde sa výpožička rozšírila až k najvýznamnejšej
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Vráti prvý index zodpovedajúci bajtu `x` v `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Rýchle cesto na malé plátky
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Vyhľadaním jednej bajtovej hodnoty načítate dve slová `usize` súčasne.
    //
    // Rozdeliť `text` na tri časti
    // - nezaradená začiatočná časť, pred textom zarovnaná adresa s prvým slovom
    // - telo, skenovať naraz o 2 slová
    // - posledná zostávajúca časť, veľkosť <2 slov

    // hľadať až po zarovnanú hranicu
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // prehľadajte text
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // BEZPEČNOSŤ: predikát while zaručuje vzdialenosť najmenej 2 * usize_bytes
        // medzi posunom a koncom rezu.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break, ak existuje zodpovedajúci bajt
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Nájdite byte za bodom, v ktorom sa slučka tela zastavila.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Vráti posledný index zodpovedajúci bajtu `x` v `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Vyhľadaním jednej bajtovej hodnoty načítate dve slová `usize` súčasne.
    //
    // Split `text` na tri časti:
    // - nezaradený chvost, za textom zarovnaná adresa s posledným slovom,
    // - telo, naskenované 2 slovami naraz,
    // - prvých zostávajúcich bajtov, veľkosť <2 slova.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Hovoríme tomu len kvôli získaniu dĺžky predpony a prípony.
        // V strede vždy spracujeme dva kúsky naraz.
        // BEZPEČNOSŤ: premena `[u8]` na `[usize]` je bezpečná, až na rozdiely vo veľkosti, ktoré spracúva `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Vyhľadajte text a uistite sa, že neprekračujeme min_aligned_offset.
    // offset je vždy zarovnaný, takže stačí iba testovanie `>` a zabráni sa možnému pretečeniu.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // BEZPEČNOSŤ: offset začína na len, suffix.len(), pokiaľ je väčší ako
        // min_aligned_offset (prefix.len()), zostávajúca vzdialenosť je najmenej 2 * kusy_bytu.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Ak existuje zodpovedajúci bajt, zalomte ho.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Nájdite bajt pred bodom, v ktorom sa slučka tela zastavila.
    text[..offset].iter().rposition(|elt| *elt == x)
}