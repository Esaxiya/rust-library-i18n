//! Modul pre prácu s vypožičanými dátami.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait na vypožičanie údajov.
///
/// V Rust je bežné poskytnúť rôzne znázornenia typu pre rôzne prípady použitia.
/// Napríklad umiestnenie ukladacieho priestoru a správa hodnoty je možné konkrétne zvoliť ako vhodné pre konkrétne použitie prostredníctvom typov ukazovateľov ako [`Box<T>`] alebo [`Rc<T>`].
/// Okrem týchto všeobecných obalov, ktoré možno použiť s akýmkoľvek typom, poskytujú niektoré typy voliteľné fazety poskytujúce potenciálne nákladné funkcie.
/// Príkladom takéhoto typu je [`String`], ktorý pridáva schopnosť rozšíriť reťazec na základné [`str`].
/// To si vyžaduje, aby ste pre jednoduchý, nemenný reťazec nepotrebovali ďalšie informácie.
///
/// Tieto typy poskytujú prístup k podkladovým údajom prostredníctvom odkazov na typ týchto údajov.Hovorí sa o nich, že sú " požičané ako` tohto typu.
/// Napríklad [`Box<T>`] si môžete požičať ako `T`, zatiaľ čo [`String`] si môžete požičať ako `str`.
///
/// Typy vyjadrujú, že si ich možno požičať ako nejaký typ `T` implementáciou `Borrow<T>`, poskytnutím odkazu na `T` v metóde [`borrow`] trait.Typ si môžete bezplatne požičať ako niekoľko rôznych typov.
/// Ak si chce premenlivo požičať ako typ-umožňujúce modifikáciu podkladových údajov, môže dodatočne implementovať [`BorrowMut<T>`].
///
/// Ďalej pri poskytovaní implementácií pre ďalšie traits je potrebné zvážiť, či by sa mali správať rovnako ako implementácie základného typu v dôsledku pôsobenia ako reprezentácia tohto základného typu.
/// Všeobecný kód zvyčajne používa `Borrow<T>`, keď sa spolieha na identické správanie týchto ďalších implementácií trait.
/// Tieto traits sa pravdepodobne objavia ako ďalšie trait bounds.
///
/// Najmä `Eq`, `Ord` a `Hash` musia byť ekvivalentné pre vypožičané a vlastnené hodnoty: `x.borrow() == y.borrow()` by mal poskytnúť rovnaký výsledok ako `x == y`.
///
/// Ak všeobecný kód musí pracovať iba pre všetky typy, ktoré môžu poskytnúť odkaz na súvisiaci typ `T`, je často lepšie použiť [`AsRef<T>`], pretože ho môže bezpečne implementovať viac typov.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Ako zber dát vlastní [`HashMap<K, V>`] kľúče aj hodnoty.Ak sú skutočné údaje kľúča zabalené do nejakého druhu správy, malo by byť stále možné vyhľadať hodnotu pomocou odkazu na údaje kľúča.
/// Napríklad ak je kľúčom reťazec, potom je pravdepodobne uložený s hashovou mapou ako [`String`], zatiaľ čo by malo byť možné vyhľadávať pomocou [`&str`][`str`].
/// `insert` teda musí pracovať na `String`, zatiaľ čo `get` musí byť schopný používať `&str`.
///
/// Mierne zjednodušené vyzerajú príslušné časti modelu `HashMap<K, V>` takto:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // polia vynechané
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Celá hash mapa je všeobecná pre kláves typu `K`.Pretože sú tieto kľúče uložené s hašovacou mapou, musí tento typ vlastniť údaje kľúča.
/// Pri vkladaní páru kľúč-hodnota dostane mapa taký `K` a musí nájsť správny hash kbelík a na základe toho `K` skontrolovať, či je kľúč už prítomný.Vyžaduje teda `K: Hash + Eq`.
///
/// Pri hľadaní hodnoty na mape by si však vyžadovanie uvedenia odkazu na `K` ako kľúča na vyhľadanie vyžadovalo vždy vytvoriť takúto vlastnenú hodnotu.
/// Pre reťazcové kľúče by to znamenalo, že je potrebné vytvoriť hodnotu `String` iba pre hľadanie prípadov, keď je k dispozícii iba `str`.
///
/// Namiesto toho je metóda `get` všeobecná pre typ základných údajov kľúča, ktorý sa v podpisu metódy nazýva `Q`.Uvádza sa v ňom, že `K` si požičiava ako `Q` požadovaním tejto `K: Borrow<Q>`.
/// Dodatočnou požiadavkou na `Q: Hash + Eq` signalizuje požiadavku, aby `K` a `Q` mali implementácie `Hash` a `Eq` traits, ktoré poskytujú rovnaké výsledky.
///
/// Implementácia `get` sa spolieha najmä na identické implementácie `Hash` určením hashovacieho segmentu kľúča volaním `Hash::hash` na hodnotu `Q`, aj keď vložil kľúč na základe hodnoty hash vypočítanej z hodnoty `K`.
///
///
/// V dôsledku toho sa hashova mapa rozbije, ak `K` zabalenie hodnoty `Q` vyprodukuje iný hash ako `Q`.Predstavte si napríklad, že máte typ, ktorý zalamuje reťazec, ale porovnáva písmená ASCII a ignoruje ich veľké a malé písmená:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Pretože dve rovnaké hodnoty musia produkovať rovnakú hodnotu hash, implementácia `Hash` musí ignorovať aj prípad ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Môže `CaseInsensitiveString` implementovať `Borrow<str>`?Určite môže poskytnúť odkaz na rez reťazca prostredníctvom jeho vlastneného reťazca.
/// Pretože sa však jeho implementácia `Hash` líši, správa sa odlišne od `str`, a preto v skutočnosti nesmie implementovať `Borrow<str>`.
/// Ak chce umožniť ostatným prístup k základnej `str`, môže to urobiť prostredníctvom `AsRef<str>`, ktorá neobsahuje žiadne ďalšie požiadavky.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Nezameniteľne si požičiava z hodnoty, ktorú vlastní.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait pre premenlivo požičiavajúce dáta.
///
/// Ako doplnok k [`Borrow<T>`] umožňuje tento typ trait typu požičať si ako podkladový typ poskytnutím premenlivej referencie.
/// Ďalšie informácie o požičiavaní ako iného typu nájdete v časti [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Premenlivo si požičiava z hodnoty, ktorú vlastní.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}