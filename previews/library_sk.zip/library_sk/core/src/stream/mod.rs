//! Skladateľná asynchrónna iterácia.
//!
//! Ak sú futures asynchrónne hodnoty, potom sú prúdy asynchrónne iterátory.
//! Ak ste sa našli s nejakou asynchrónnou kolekciou a potrebujete vykonať operáciu na prvkoch uvedenej kolekcie, rýchlo narazíte na 'streams'.
//! Prúdy sa intenzívne používajú v idiomatických asynchrónnych kódoch Rust, takže stojí za to sa s nimi oboznámiť.
//!
//! Predtým, ako vysvetlíme viac, si povieme, ako je tento modul štruktúrovaný:
//!
//! # Organization
//!
//! Tento modul je väčšinou organizovaný podľa typu:
//!
//! * [Traits] sú hlavnou časťou: tieto traits definujú, aké druhy prúdov existujú a čo s nimi môžete robiť.Metódy týchto traits stojí za to venovať nejaký čas štúdiu navyše.
//! * Funkcie poskytujú niekoľko užitočných spôsobov, ako vytvoriť niektoré základné streamy.
//! * Štruktúry sú často návratovými typmi rôznych metód na traits tohto modulu.Zvyčajne sa budete chcieť pozrieť na metódu, ktorá vytvára `struct`, a nie na samotný `struct`.
//! Viac podrobností o dôvodoch nájdete v časti " [Implementing Stream](#implementation-stream)`.
//!
//! [Traits]: #traits
//!
//! To je všetko!Poďme kopať do prúdov.
//!
//! # Stream
//!
//! Srdcom a dušou tohto modulu je [`Stream`] trait.Jadro [`Stream`] vyzerá takto:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Na rozdiel od `Iterator` rozlišuje `Stream` medzi metódou [`poll_next`], ktorá sa používa pri implementácii `Stream`, a metódou (to-be-implemented) `next`, ktorá sa používa pri konzumácii streamu.
//!
//! Spotrebiteľom `Stream` stačí vziať do úvahy `next`, ktorý po zavolaní vráti future, ktorá prinesie `Option<Stream::Item>`.
//!
//! future vrátená `next` prinesie `Some(Item)`, pokiaľ existujú prvky, a keď budú všetky vyčerpané, prinesie `None`, čo znamená, že iterácia je dokončená.
//! Ak čakáme na vyriešenie niečoho asynchrónneho, future počká, kým nebude prúd pripravený znovu sa vzdať.
//!
//! Jednotlivé streamy sa môžu rozhodnúť v opakovaní iterácie, a preto opätovné volanie `next` môže alebo nemusí nakoniec v určitom okamihu znova priniesť `Some(Item)`.
//!
//! Úplná definícia [" Stream`] obsahuje aj množstvo ďalších metód, ale sú to predvolené metódy postavené na [`poll_next`], takže ich máte zadarmo.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementuje sa stream
//!
//! Vytvorenie vlastného streamu zahŕňa dva kroky: vytvorenie `struct` na udržanie stavu streamu a následná implementácia [`Stream`] pre tento `struct`.
//!
//! Vytvorme stream s názvom `Counter`, ktorý sa počíta od `1` do `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Najskôr štruktúra:
//!
//! /// Stream, ktorý sa počíta od jednej do piatich
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chceme, aby náš počet začínal na jednej, pridajme preto na pomoc metódu new().
//! // To nie je nevyhnutne potrebné, ale je to pohodlné.
//! // Všimnite si, že `count` začíname na nule, uvidíme prečo v implementácii `poll_next()`'s nižšie.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Potom implementujeme `Stream` pre našu `Counter`:
//!
//! impl Stream for Counter {
//!     // budeme rátať s veľkosťou
//!     type Item = usize;
//!
//!     // poll_next() je jediná požadovaná metóda
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Zvýšiť náš počet.Preto sme začínali na nule.
//!         self.count += 1;
//!
//!         // Skontrolujte, či sme počítanie skončili alebo nie.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Prúdy sú *lenivé*.To znamená, že samotné vytvorenie streamu ešte _do_ veľa neznamená.Skutočne sa nič nedeje, kým nezavoláte `next`.
//! To je niekedy zdroj nejasností pri vytváraní streamu iba kvôli jeho vedľajším účinkom.
//! Kompilátor nás na tento druh správania upozorní:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;