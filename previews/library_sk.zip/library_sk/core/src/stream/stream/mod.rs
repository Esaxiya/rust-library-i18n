use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Rozhranie pre prácu s asynchrónnymi iterátormi.
///
/// Toto je hlavný prúd trait.
/// Viac informácií o koncepcii streamov sa všeobecne nachádza v [module-level documentation].
/// Najmä možno budete chcieť vedieť, ako na [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Typ položiek získaných prúdom.
    type Item;

    /// Pokus vytiahnuť ďalšiu hodnotu tohto streamu, registrácia aktuálnej úlohy na prebudenie, ak hodnota ešte nie je k dispozícii, a návrat `None`, ak je stream vyčerpaný.
    ///
    /// # Návratová hodnota
    ///
    /// Existuje niekoľko možných návratových hodnôt, z ktorých každá označuje odlišný stav streamu:
    ///
    /// - `Poll::Pending` znamená, že ďalšia hodnota tohto streamu ešte nie je pripravená.Implementácie zabezpečia, že aktuálna úloha bude informovaná, keď bude pripravená ďalšia hodnota.
    ///
    /// - `Poll::Ready(Some(val))` znamená, že prúd úspešne vyprodukoval hodnotu `val` a pri ďalších volaniach `poll_next` môže produkovať ďalšie hodnoty.
    ///
    /// - `Poll::Ready(None)` znamená, že stream bol ukončený a `poll_next` by sa už nemal znovu vyvolávať.
    ///
    /// # Panics
    ///
    /// Akonáhle je stream dokončený (vrátil `Ready(None)` from `poll_next`), opätovné volanie jeho metódy `poll_next` môže panic, navždy zablokovať alebo spôsobiť iné druhy problémov; `Stream` trait nekladie žiadne požiadavky na účinky takéhoto volania.
    ///
    /// Pretože však metóda `poll_next` nie je označená ako `unsafe`, platia obvyklé pravidlá Rust: hovory nikdy nesmú spôsobovať nedefinované správanie (poškodenie pamäte, nesprávne použitie funkcií `unsafe` apod.) Bez ohľadu na stav streamu.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Vráti hranice zostávajúcej dĺžky streamu.
    ///
    /// Konkrétne `size_hint()` vracia n-ticu, kde prvý prvok je dolná hranica a druhý prvok je horná hranica.
    ///
    /// Druhá polovica n-tice, ktorá sa vráti, je [`Option`]`<`[`usize`] `>`.
    /// [`None`] tu znamená, že buď nie je známa horná hranica, alebo je horná hranica väčšia ako [`usize`].
    ///
    /// # Poznámky k implementácii
    ///
    /// Nie je vynútené, aby implementácia toku poskytla deklarovaný počet prvkov.Prúd buggy môže poskytovať menej ako dolnú hranicu alebo viac ako hornú hranicu prvkov.
    ///
    /// `size_hint()` je primárne určený na použitie na optimalizácie, ako je rezervácia priestoru pre prvky streamu, ale nesmie sa používať ako dôveryhodný nástroj na vynechanie hraničných kontrol v nebezpečnom kóde.
    /// Nesprávna implementácia `size_hint()` by nemala viesť k narušeniu bezpečnosti pamäte.
    ///
    /// To znamená, že implementácia by mala poskytnúť správny odhad, pretože inak by išlo o porušenie protokolu trait.
    ///
    /// Predvolená implementácia vracia hodnotu " (0," [" Žiadna`]]`) `, ktorá je správna pre každý stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}