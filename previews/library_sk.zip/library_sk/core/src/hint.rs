#![stable(feature = "core_hint", since = "1.27.0")]

//! Rady pre kompilátor, ktoré ovplyvňujú, ako by sa mal kód emitovať alebo optimalizovať.
//! Pomôckou môže byť čas kompilácie alebo doba behu.

use crate::intrinsics;

/// Informuje kompilátor o tom, že tento bod v kóde nie je dosiahnuteľný, a umožňuje tak ďalšiu optimalizáciu.
///
/// # Safety
///
/// Dosiahnutie tejto funkcie je úplne *nedefinované správanie*(UB).Kompilátor predovšetkým predpokladá, že všetko UB sa nikdy nesmie stať, a preto vylúči všetky vetvy, ktoré siahajú po volaní `unreachable_unchecked()`.
///
/// Rovnako ako všetky inštancie UB, ak sa tento predpoklad ukáže ako nesprávny, tj. Volanie `unreachable_unchecked()` je skutočne dosiahnuteľné medzi všetkými možnými tokmi riadenia, kompilátor použije nesprávnu optimalizačnú stratégiu a niekedy môže dokonca poškodiť zdanlivo nesúvisiaci kód, čo spôsobí ťažkosti-ladiť problémy.
///
///
/// Túto funkciu používajte, iba ak preukážete, že ju kód nikdy nenazve.
/// V opačnom prípade zvážte použitie makra [`unreachable!`], ktoré neumožňuje optimalizáciu, ale pri spustení bude panic.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` je vždy kladné (nie nulové), preto `checked_div` nikdy nevráti `None`.
/////
///     // Preto je else branch nedosiahnuteľný.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // BEZPEČNOSŤ: zmluva o bezpečnosti pre `intrinsics::unreachable` musí byť
    // volajúci potvrdil.
    unsafe { intrinsics::unreachable() }
}

/// Vydáva inštrukciu stroja na signalizáciu procesoru, ktorý beží, v spin-loopu s obsadeným čakaním (" spin lock`).
///
/// Po prijatí signálu spinovej slučky môže procesor optimalizovať svoje správanie napríklad úsporou energie alebo prepínaním vlákien hyper.
///
/// Táto funkcia sa líši od [`thread::yield_now`], ktorá priamo prechádza do plánovača systému, zatiaľ čo `spin_loop` neinteraguje s operačným systémom.
///
/// Bežným prípadom použitia pre `spin_loop` je implementácia obmedzeného optimistického pradenia v slučke CAS v synchronizačných primitívach.
/// Aby sa predišlo problémom, ako je prioritná inverzia, dôrazne sa odporúča ukončenie spinovej slučky po konečnom množstve iterácií a vykonaní vhodného blokujúceho syscall.
///
///
/// **Poznámka**: Na platformách, ktoré nepodporujú príjem náznakov spin-loop, táto funkcia nerobí vôbec nič.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Zdieľaná atómová hodnota, ktorú vlákna použijú na koordináciu
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Vo vlákne na pozadí nakoniec nastavíme hodnotu
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Urobte nejakú prácu a potom hodnotu zverejnite
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Späť na naše súčasné vlákno čakáme na nastavenie hodnoty
/// while !live.load(Ordering::Acquire) {
///     // Spinovacia slučka je nápovedou k CPU, na ktorú čakáme, ale pravdepodobne nie príliš dlho
/////
///     hint::spin_loop();
/// }
///
/// // Hodnota je teraz nastavená
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // BEZPEČNOSŤ: atrament `cfg` zaručuje, že to vykonáme iba na cieľoch x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // BEZPEČNOSŤ: atrament `cfg` zaručuje, že to vykonáme iba na cieľoch x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // BEZPEČNOSŤ: atrament `cfg` zaručuje, že to vykonáme iba na cieľoch aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // BEZPEČNOSŤ: atrament `cfg` zaručuje, že to vykonáme iba na cieľoch paží
            // s podporou funkcie v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Funkcia identity, ktorá *__ naznačuje __* kompilátoru, aby bola maximálne pesimistická v tom, čo dokáže `black_box`.
///
/// Na rozdiel od [`std::convert::identity`] sa odporúča kompilátoru Rust predpokladať, že `black_box` môže používať `dummy` akýmkoľvek možným platným spôsobom, ktorý je povolený kódu Rust bez zavedenia nedefinovaného správania do volajúceho kódu.
///
/// Vďaka tejto vlastnosti je `black_box` užitočný na zápis kódu, v ktorom nie sú potrebné určité optimalizácie, ako sú napríklad referenčné hodnoty.
///
/// Upozorňujeme však, že `black_box` je poskytovaná (a môže byť) iba na báze "best-effort".Rozsah, v akom môže blokovať optimalizácie, sa môže líšiť v závislosti od použitej platformy a back-endu gen-kódu.
/// Programy sa nemôžu spoľahnúť na to, že `black_box` bude *správnosť*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Potrebujeme "use" argument nejakým spôsobom, aby LLVM nemohol nahliadnuť, a na cieľoch, ktoré ho podporujú, môžeme na to zvyčajne využiť inline montáž.
    // Výklad LLVM pre inline montáž je taký, že je to čierna skrinka.
    // Toto nie je najväčšia implementácia, pretože pravdepodobne deoptimalizuje viac, ako chceme, ale je zatiaľ dosť dobrá.
    //
    //

    #[cfg(not(miri))] // Toto je iba náznak, takže je dobré vynechať Miri.
    // BEZPEČNOSŤ: vložená montáž je zákaz činnosti.
    unsafe {
        // FIXME: `asm!` nie je možné použiť, pretože nepodporuje MIPS a iné architektúry.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}