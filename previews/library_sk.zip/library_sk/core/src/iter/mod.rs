//! Skladateľná externá iterácia.
//!
//! Ak ste sa ocitli v zbierke nejakého druhu a potrebujete vykonať operáciu na prvkoch uvedenej kolekcie, rýchlo narazíte na 'iterators'.
//! Iterátory sa často používajú v idiomatickom kóde Rust, takže stojí za to sa s nimi oboznámiť.
//!
//! Predtým, ako vysvetlíme viac, si povieme, ako je tento modul štruktúrovaný:
//!
//! # Organization
//!
//! Tento modul je väčšinou organizovaný podľa typu:
//!
//! * [Traits] sú hlavnou časťou: tieto traits definujú, aké iterátory existujú a čo s nimi môžete robiť.Metódy týchto traits stojí za to venovať nejaký čas štúdiu navyše.
//! * [Functions] poskytnúť niekoľko užitočných spôsobov, ako vytvoriť niekoľko základných iterátorov.
//! * [Structs] sú často návratové typy rôznych metód na traits tohto modulu.Zvyčajne sa budete chcieť pozrieť na metódu, ktorá vytvára `struct`, a nie na samotný `struct`.
//! Viac podrobností o dôvodoch nájdete v časti " [Implementing Iterator](#implementation-iterator)`.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! To je všetko!Poďme kopať do iterátorov.
//!
//! # Iterator
//!
//! Srdcom a dušou tohto modulu je [`Iterator`] trait.Jadro [`Iterator`] vyzerá takto:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterátor má metódu [`next`], ktorá po vyvolaní vráti [" Možnosť`]`<Item>".
//! [`next`] vráti [`Some(Item)`], pokiaľ existujú prvky, a keď budú všetky vyčerpané, vráti `None`, čo znamená, že iterácia je ukončená.
//! Jednotlivé iterátory sa môžu rozhodnúť v opakovaní iterácie, a preto opätovné volanie [`next`] môže alebo nemusí nakoniec v určitom okamihu začať znova vracať [`Some(Item)`] (napríklad pozri [`TryIter`]).
//!
//!
//! Úplná definícia [" Iterator`] obsahuje aj množstvo ďalších metód, ale sú to predvolené metódy postavené na [`next`], takže ich máte zadarmo.
//!
//! Iterátory sú tiež skladateľné a je bežné ich spojiť dohromady, aby sa dosiahli zložitejšie formy spracovania.Ďalšie podrobnosti nájdete v sekcii [Adapters](#adapters) nižšie.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tri formy iterácie
//!
//! Existujú tri bežné metódy, ktoré môžu vytvoriť iterátory zo zbierky:
//!
//! * `iter()`, ktorý iteruje cez `&T`.
//! * `iter_mut()`, ktorý iteruje cez `&mut T`.
//! * `into_iter()`, ktorý iteruje cez `T`.
//!
//! V prípade potreby môže jedna alebo viac z troch implementovať rôzne veci v štandardnej knižnici.
//!
//! # Implementuje sa iterátor
//!
//! Vytvorenie vlastného iterátora zahŕňa dva kroky: vytvorenie `struct` na udržanie stavu iterátora a následná implementácia [`Iterator`] pre tento `struct`.
//! Preto je v tomto module toľko `štruktúr`: pre každý iterátor a adaptér iterátora je jeden.
//!
//! Vytvorme iterátor s názvom `Counter`, ktorý počíta od `1` do `5`:
//!
//! ```
//! // Najskôr štruktúra:
//!
//! /// Iterátor, ktorý počíta od jednej do piatich
//! struct Counter {
//!     count: usize,
//! }
//!
//! // chceme, aby náš počet začínal na jednej, pridajme preto na pomoc metódu new().
//! // To nie je nevyhnutne potrebné, ale je to pohodlné.
//! // Všimnite si, že `count` začíname na nule, uvidíme prečo v implementácii `next()`'s nižšie.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Potom implementujeme `Iterator` pre našu `Counter`:
//!
//! impl Iterator for Counter {
//!     // budeme rátať s veľkosťou
//!     type Item = usize;
//!
//!     // next() je jediná požadovaná metóda
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Zvýšiť náš počet.Preto sme začínali na nule.
//!         self.count += 1;
//!
//!         // Skontrolujte, či sme počítanie skončili alebo nie.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // A teraz to môžeme použiť!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Volanie [`next`] týmto spôsobom sa opakuje.Rust má konštrukt, ktorý môže volať iterátor [`next`], kým nedosiahne `None`.Poďme na to ďalej.
//!
//! Upozorňujeme tiež, že `Iterator` poskytuje predvolenú implementáciu metód ako `nth` a `fold`, ktoré interne volajú `next`.
//! Je však tiež možné napísať vlastnú implementáciu metód ako `nth` a `fold`, ak ich môže iterátor vypočítať efektívnejšie bez toho, aby volali `next`.
//!
//! # `for` slučky a `IntoIterator`
//!
//! Syntax slučky `for` v Rust je vlastne cukor pre iterátory.Tu je základný príklad modelu `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Týmto sa vytlačia čísla jedna až päť, každé na svojom vlastnom riadku.Tu si však niečo všimnete: na našom vector sme nikdy nič nezavolali, aby sme vytvorili iterátor.Čo dáva?
//!
//! V štandardnej knižnici je trait na prevod niečoho na iterátor: [`IntoIterator`].
//! Tento trait má jednu metódu, [`into_iter`], ktorá prevádza implementáciu [`IntoIterator`] na iterátor.
//! Pozrime sa znova na túto slučku `for` a na to, na čo ju kompilátor prevádza:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust to zbaví cukru na:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Najskôr voláme `into_iter()` na hodnote.Potom sa zhodujeme s iterátorom, ktorý sa vracia, a opakovane voláme [`next`], kým neuvidíme `None`.
//! V tom okamihu sme `break` zo slučky a skončili sme s iteráciou.
//!
//! Je tu ešte jeden jemný kúsok: štandardná knižnica obsahuje zaujímavú implementáciu [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Inými slovami, všetci [" Iterator`] implementujú [`IntoIterator`] iba tým, že sa vrátia.To znamená dve veci:
//!
//! 1. Ak píšete [`Iterator`], môžete ho použiť so slučkou `for`.
//! 2. Ak vytvárate kolekciu, implementácia [`IntoIterator`] pre ňu umožní použitie vašej kolekcie so slučkou `for`.
//!
//! # Iterácia odkazom
//!
//! Pretože [`into_iter()`] berie `self` podľa hodnoty, použitie cyklu `for` na iteráciu cez kolekciu túto kolekciu spotrebuje.Často môžete zbierku opakovať bez toho, aby ste ju konzumovali.
//! Mnoho kolekcií ponúka metódy, ktoré poskytujú iterátory nad referenciami, konvenčne nazývanými `iter()` a `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` je stále vo vlastníctve tejto funkcie.
//! ```
//!
//! Ak kolekcia typu `C` poskytuje `iter()`, zvyčajne implementuje aj `IntoIterator` pre `&C`, s implementáciou, ktorá volá len `iter()`.
//! Rovnako kolekcia `C`, ktorá poskytuje `iter_mut()`, všeobecne implementuje `IntoIterator` pre `&mut C` delegovaním na `iter_mut()`.Toto umožňuje pohodlnú skratku:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // rovnako ako `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // rovnaké ako `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Aj keď mnoho zbierok ponúka `iter()`, nie všetky ponúkajú `iter_mut()`.
//! Napríklad mutácia kľúčov [`HashSet<T>`] alebo [`HashMap<K, V>`] by mohla kolekciu prepnúť do nekonzistentného stavu, ak sa zmení hash kľúča, takže tieto kolekcie ponúkajú iba `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkcie, ktoré preberajú [`Iterator`] a vracajú iný [`Iterator`], sa často nazývajú " iterátorové adaptéry`, pretože sú formou " adaptéra`
//! pattern'.
//!
//! Medzi bežné iteračné adaptéry patria [`map`], [`take`] a [`filter`].
//! Ďalšie informácie nájdete v ich dokumentácii.
//!
//! Ak je adaptér iterátora panics, bude iterátor v nešpecifikovanom (ale bezpečnom pamäti) stave.
//! Nie je zaručené, že tento stav zostane rovnaký vo všetkých verziách Rust, takže by ste sa nemali spoliehať na presné hodnoty vrátené iterátorom, ktorý spanikáril.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterátory (a iterátor [adapters](#adapters)) sú *lenivé*. To znamená, že iba vytvorenie iterátora nie je _do_ veľa. Nič sa nestane, kým nezavoláte [`next`].
//! To je niekedy zdroj zmätku pri vytváraní iterátora iba pre jeho vedľajšie účinky.
//! Napríklad metóda [`map`] volá uzavretie každého prvku, ktorý iteruje:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Toto nevytlačí žiadne hodnoty, pretože sme vytvorili iba iterátor namiesto jeho použitia.Kompilátor nás na tento druh správania upozorní:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idiomatickým spôsobom, ako napísať [`map`] pre jeho vedľajšie účinky, je použiť slučku `for` alebo zavolať metódu [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Ďalším bežným spôsobom hodnotenia iterátora je použitie metódy [`collect`] na vytvorenie novej kolekcie.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iterátory nemusia byť konečné.Napríklad rozsah neurčitých časov je nekonečný iterátor:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Je bežné používať adaptér iterátora [`take`] na premenu nekonečného iterátora na konečný:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Týmto sa vytlačia čísla `0` až `4`, každé na svojom vlastnom riadku.
//!
//! Majte na pamäti, že metódy na nekonečných iterátoroch, dokonca aj tých, pre ktoré je možné matematicky určiť výsledok v konečnom čase, sa nemusia skončiť.
//! Konkrétne je pravdepodobné, že metódy ako [`min`], ktoré vo všeobecnosti vyžadujú prechod cez každý prvok v iterátore, sa úspešne nevrátia pre všetky nekonečné iterátory.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ale nie!Nekonečná slučka!
//! // `ones.min()` spôsobí nekonečnú slučku, takže nedosiahneme tento bod!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;