use crate::fmt;

/// Vytvorí nový iterátor, kde každá iterácia volá zadaný záver `F: FnMut() -> Option<T>`.
///
/// To umožňuje vytvoriť vlastný iterátor s akýmkoľvek správaním bez použitia podrobnejšej syntaxe vytvorenia vyhradeného typu a implementácie [`Iterator`] trait.
///
/// Upozorňujeme, že iterátor `FromFn` nevytvára predpoklady o chovaní uzáveru, a preto konzervatívne neimplementuje [`FusedIterator`] ani neprepisuje [`Iterator::size_hint()`] od svojej predvolenej verzie `(0, None)`.
///
///
/// Uzávierka môže pomocou snímok a jeho prostredia sledovať stav naprieč iteráciami.V závislosti od toho, ako sa iterátor používa, to môže vyžadovať zadanie kľúčového slova [`move`] na konci.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Znova implementujme iterátor počítadla z [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Zvýšiť náš počet.Preto sme začínali na nule.
///     count += 1;
///
///     // Skontrolujte, či sme počítanie skončili alebo nie.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iterátor, kde každá iterácia volá zadaný záver `F: FnMut() -> Option<T>`.
///
/// Tento model `struct` je vytvorený funkciou [`iter::from_fn()`].
/// Ďalšie informácie nájdete v jeho dokumentácii.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}