use crate::iter::{FusedIterator, TrustedLen};

/// Vytvorí iterátor, ktorý získa prvok presne raz.
///
/// To sa bežne používa na prispôsobenie jednej hodnoty do [`chain()`] iných druhov iterácie.
/// Možno máte iterátor, ktorý pokrýva takmer všetko, ale potrebujete špeciálny prípad navyše.
/// Možno máte funkciu, ktorá pracuje na iterátoroch, ale musíte spracovať iba jednu hodnotu.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::iter;
///
/// // jeden je najosamelejšie číslo
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // iba jeden, to je všetko, čo dostaneme
/// assert_eq!(None, one.next());
/// ```
///
/// Reťazenie spolu s ďalším iterátorom.
/// Povedzme, že chceme iterovať každý súbor adresára `.foo`, ale aj konfiguračný súbor,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // musíme previesť z iterátora DirEntry-s na iterátor PathBufs, takže používame mapu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // teraz náš iterátor iba pre náš konfiguračný súbor
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // zreťazte dva iterátory dohromady do jedného veľkého iterátora
/// let files = dirs.chain(config);
///
/// // takto získate všetky súbory v .foo aj .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterátor, ktorý získa prvok presne raz.
///
/// Tento model `struct` je vytvorený funkciou [`once()`].Ďalšie informácie nájdete v jeho dokumentácii.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}