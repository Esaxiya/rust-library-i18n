use crate::iter::{FusedIterator, TrustedLen};

/// Vytvorí iterátor, ktorý lenivo generuje hodnotu presne raz vyvolaním zadaného uzáveru.
///
/// To sa bežne používa na prispôsobenie generátora jednej hodnoty do [`chain()`] iných druhov iterácií.
/// Možno máte iterátor, ktorý pokrýva takmer všetko, ale potrebujete špeciálny prípad navyše.
/// Možno máte funkciu, ktorá pracuje na iterátoroch, ale musíte spracovať iba jednu hodnotu.
///
/// Na rozdiel od [`once()`] bude táto funkcia lenivo generovať hodnotu na požiadanie.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::iter;
///
/// // jeden je najosamelejšie číslo
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // iba jeden, to je všetko, čo dostaneme
/// assert_eq!(None, one.next());
/// ```
///
/// Reťazenie spolu s ďalším iterátorom.
/// Povedzme, že chceme iterovať každý súbor adresára `.foo`, ale aj konfiguračný súbor,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // musíme previesť z iterátora DirEntry-s na iterátor PathBufs, takže používame mapu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // teraz náš iterátor iba pre náš konfiguračný súbor
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // zreťazte dva iterátory dohromady do jedného veľkého iterátora
/// let files = dirs.chain(config);
///
/// // takto získate všetky súbory v .foo aj .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterátor, ktorý poskytuje jediný prvok typu `A` uplatnením poskytnutého uzáveru `F: FnOnce() -> A`.
///
///
/// Tento model `struct` je vytvorený funkciou [`once_with()`].
/// Ďalšie informácie nájdete v jeho dokumentácii.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}