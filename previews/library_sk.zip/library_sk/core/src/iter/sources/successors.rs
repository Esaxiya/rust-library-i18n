use crate::{fmt, iter::FusedIterator};

/// Vytvorí nový iterátor, kde sa každá nasledujúca položka počíta na základe predchádzajúcej.
///
/// Iterátor začína danou prvou položkou (ak existuje) a volá daný uzáver `FnMut(&T) -> Option<T>`, aby vypočítal nástupcu každej položky.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // Ak táto funkcia vrátila `impl Iterator<Item=T>`, mohlo by to byť založené na `unfold` a nepotrebovať vyhradený typ.
    //
    // Avšak pomenovaný typ `Successors<T, F>` umožňuje, aby bol `Clone`, keď sú `T` a `F`.
    Successors { next: first, succ }
}

/// Nový iterátor, kde sa každá nasledujúca položka počíta na základe predchádzajúcej.
///
/// Tento model `struct` je vytvorený funkciou [`iter::successors()`].
/// Ďalšie informácie nájdete v jeho dokumentácii.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}