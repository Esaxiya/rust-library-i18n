/// Iterátor, ktorý pozná presnú dĺžku.
///
/// Mnoho [" Iterátorov`] nevie, koľkokrát budú iterovať, ale niektorí to vedia.
/// Ak iterátor vie, koľkokrát môže iterovať, môže byť užitočné poskytnúť prístup k týmto informáciám.
/// Ak napríklad chcete iterovať dozadu, dobrým začiatkom je vedieť, kde je koniec.
///
/// Pri implementácii `ExactSizeIterator` musíte implementovať aj [`Iterator`].
/// Pritom implementácia [`Iterator::size_hint`]*musí* vrátiť presnú veľkosť iterátora.
///
/// Metóda [`len`] má predvolenú implementáciu, takže by ste ju zvyčajne nemali implementovať.
/// Možno však budete môcť poskytnúť výkonnejšiu implementáciu ako predvolenú, takže jej prepísanie v tomto prípade má zmysel.
///
///
/// Upozorňujeme, že tento trait je bezpečný trait a ako taký *nie* a *nemôže* zaručovať, že vrátená dĺžka je správna.
/// To znamená, že kód `unsafe` sa nesmie ** spoliehať na správnosť kódu [`Iterator::size_hint`].
/// Nestabilný a nebezpečný model [`TrustedLen`](super::marker::TrustedLen) trait poskytuje túto ďalšiu záruku.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// // konečný rozsah vie presne, koľkokrát bude iterovať
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// V [module-level docs] sme implementovali [`Iterator`], `Counter`.
/// Implementujme pre ňu aj `ExactSizeIterator`:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Ľahko vypočítame zostávajúci počet iterácií.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // A teraz to môžeme použiť!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Vráti presnú dĺžku iterátora.
    ///
    /// Implementácia zaisťuje, že iterátor vráti presne `len()` viackrát hodnotu [`Some(T)`], skôr ako vráti [`None`].
    ///
    /// Táto metóda má predvolenú implementáciu, takže by ste ju zvyčajne nemali implementovať priamo.
    /// Ak však môžete zabezpečiť efektívnejšiu implementáciu, môžete tak urobiť.
    /// Príklad nájdete v dokumentoch [trait-level].
    ///
    /// Táto funkcia má rovnaké bezpečnostné záruky ako funkcia [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // konečný rozsah vie presne, koľkokrát bude iterovať
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Toto tvrdenie je príliš obranné, ale kontroluje invariantnosť
        // zaručené trait.
        // Ak by tento trait bol rust-internal, mohli by sme použiť debug_assert !;assert_eq!skontroluje tiež všetky implementácie používateľov Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Vráti `true`, ak je iterátor prázdny.
    ///
    /// Táto metóda má predvolenú implementáciu pomocou [`ExactSizeIterator::len()`], takže ju nemusíte implementovať sami.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}