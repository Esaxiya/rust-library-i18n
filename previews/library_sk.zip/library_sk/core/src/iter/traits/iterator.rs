// ignore-tidy-filelength Tento súbor takmer výlučne pozostáva z definície `Iterator`.
// To nemôžeme rozdeliť do viacerých súborov.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Rozhranie pre prácu s iterátormi.
///
/// Toto je hlavný iterátor trait.
/// Viac informácií o koncepcii iterátorov sa všeobecne nachádza v [module-level documentation].
/// Najmä možno budete chcieť vedieť, ako na [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Typ prvkov, ktoré sa iterujú.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Posunie iterátor vpred a vráti ďalšiu hodnotu.
    ///
    /// Vráti [`None`] po dokončení iterácie.
    /// Jednotlivé implementácie iterátora sa môžu rozhodnúť v obnovení iterácie, a preto opätovné volanie `next()` môže alebo nemusí nakoniec v určitom okamihu začať znova vracať [`Some(Item)`].
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Volanie next() vráti ďalšiu hodnotu ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... a potom žiadny, až to skončí.
    /// assert_eq!(None, iter.next());
    ///
    /// // Viac hovorov sa môže, ale nemusí vrátiť `None`.Tu vždy budú.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Vráti hranice zostávajúcej dĺžky iterátora.
    ///
    /// Konkrétne `size_hint()` vracia n-ticu, kde prvý prvok je dolná hranica a druhý prvok je horná hranica.
    ///
    /// Druhá polovica n-tice, ktorá sa vráti, je [`Option`]`<`[`usize`] `>`.
    /// [`None`] tu znamená, že buď nie je známa horná hranica, alebo je horná hranica väčšia ako [`usize`].
    ///
    /// # Poznámky k implementácii
    ///
    /// Nie je vynútené, aby implementácia iterátora priniesla deklarovaný počet prvkov.Buggy iterátor môže poskytovať menej ako dolnú hranicu alebo viac ako hornú hranicu prvkov.
    ///
    /// `size_hint()` je primárne určený na použitie na optimalizácie, ako je rezervácia priestoru pre prvky iterátora, ale nesmie sa mu dôverovať, napríklad na vynechanie hraničných kontrol v nebezpečnom kóde.
    /// Nesprávna implementácia `size_hint()` by nemala viesť k narušeniu bezpečnosti pamäte.
    ///
    /// To znamená, že implementácia by mala poskytnúť správny odhad, pretože inak by išlo o porušenie protokolu trait.
    ///
    /// Predvolená implementácia vráti `(0,` [" Žiadny`]`) `, ktorý je správny pre akýkoľvek iterátor.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Zložitejší príklad:
    ///
    /// ```
    /// // Párne čísla od nuly do desať.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Mohli by sme iterovať od nuly do desaťkrát.
    /// // Vedieť, že je to presne päť, by nebolo možné bez vykonania filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Pridajme ďalších päť čísel s chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // teraz sú obidve hranice zvýšené o päť
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Vrátenie `None` pre hornú hranicu:
    ///
    /// ```
    /// // nekonečný iterátor nemá hornú hranicu a maximálnu možnú dolnú hranicu
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Spotrebuje iterátor, počíta počet iterácií a vráti ho.
    ///
    /// Táto metóda bude volať [`next`] opakovane, kým sa nestane [`None`], čím sa vráti počet opakovaní, ktoré videl [`Some`].
    /// Upozorňujeme, že [`next`] musí byť vyvolaný aspoň raz, aj keď iterátor neobsahuje žiadne prvky.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Chovanie pri pretečení
    ///
    /// Metóda nechráni pred pretečením, takže počítanie prvkov iterátora s viac ako [`usize::MAX`] prvkami vedie k nesprávnemu výsledku alebo k panics.
    ///
    /// Ak sú povolené tvrdenia ladenia, je zaručená hodnota panic.
    ///
    /// # Panics
    ///
    /// Táto funkcia môže byť panic, ak má iterátor viac ako [`usize::MAX`] prvkov.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Spotrebuje iterátor a vráti posledný prvok.
    ///
    /// Táto metóda bude vyhodnocovať iterátor, kým vráti [`None`].
    /// Pritom sleduje aktuálny prvok.
    /// Po vrátení [`None`] vráti `last()` posledný prvok, ktorý videl.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Posúva iterátor o prvky `n`.
    ///
    /// Táto metóda nedočkavo preskočí prvky `n` volaním [`next`] až `n` krát, kým sa nestretne s [`None`].
    ///
    /// `advance_by(n)` vráti [`Ok(())`][Ok], ak iterátor úspešne postúpi o prvky `n`, alebo [`Err(k)`][Err], ak sa vyskytne [`None`], kde `k` je počet prvkov, o ktoré je iterátor posunutý pred vyčerpaním prvkov (tj.
    /// dĺžka iterátora).
    /// Upozorňujeme, že hodnota `k` je vždy nižšia ako `n`.
    ///
    /// Volanie `advance_by(0)` nespotrebováva žiadne prvky a vždy vráti [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // preskočená bola iba `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Vráti `n`-tý prvok iterátora.
    ///
    /// Rovnako ako väčšina operácií indexovania, počet začína od nuly, takže `nth(0)` vráti prvú hodnotu, `nth(1)` druhú atď.
    ///
    /// Upozorňujeme, že všetky predchádzajúce prvky, ako aj vrátený prvok, sa spotrebujú z iterátora.
    /// To znamená, že predchádzajúce prvky budú zahodené a tiež to, že volanie `nth(0)` viackrát na rovnakom iterátore vráti rôzne prvky.
    ///
    ///
    /// `nth()` vráti [`None`], ak je `n` väčšia alebo rovná dĺžke iterátora.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Opakované volanie `nth()` neprevinie iterátor:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Vrátenie `None`, ak je menej ako `n + 1` prvkov:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Vytvorí iterátor začínajúci v rovnakom bode, ale krokujúci o danú sumu pri každej iterácii.
    ///
    /// Poznámka 1: Prvý prvok iterátora sa vráti vždy, bez ohľadu na daný krok.
    ///
    /// Poznámka 2: Čas vytiahnutia ignorovaných prvkov nie je pevne stanovený.
    /// `StepBy` správa sa ako sekvencia `next(), nth(step-1), nth(step-1),…`, ale tiež sa môže správať ako sekvencia
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Použitý spôsob sa môže pre niektoré iterátory z dôvodu výkonu zmeniť.
    /// Druhý spôsob posunie iterátor skôr a môže spotrebovať viac položiek.
    ///
    /// `advance_n_and_return_first` je ekvivalentom:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metóda bude panic, ak je daný krok `0`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Vezme dva iterátory a vytvorí nový iterátor nad oboma v poradí.
    ///
    /// `chain()` vráti nový iterátor, ktorý bude najskôr iterovať nad hodnotami z prvého iterátora a potom nad hodnotami z druhého iterátora.
    ///
    /// Inými slovami, spája dva iterátory dohromady, v reťazci.🔗
    ///
    /// [`once`] sa bežne používa na prispôsobenie jednej hodnoty do reťazca iných druhov iterácií.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pretože argument pre `chain()` používa [`IntoIterator`], môžeme odovzdať čokoľvek, čo je možné previesť na [`Iterator`], nielen na samotný [`Iterator`].
    /// Napríklad rezy (`&[T]`) implementujú [`IntoIterator`], a preto je možné ich odovzdať priamo do `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ak pracujete s Windows API, možno budete chcieť previesť [`OsStr`] na `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// " Zipsuje` dva iterátory do jedného iterátora párov.
    ///
    /// `zip()` vráti nový iterátor, ktorý bude iterovať cez dva ďalšie iterátory, pričom vráti n-ticu, kde prvý prvok pochádza z prvého iterátora, a druhý prvok pochádza z druhého iterátora.
    ///
    ///
    /// Inými slovami, zipsuje dva iterátory dohromady do jedného.
    ///
    /// Ak niektorý z iterátorov vráti [`None`], [`next`] zo zazipovaného iterátora vráti [`None`].
    /// Ak prvý iterátor vráti [`None`], `zip` dôjde k skratu a `next` sa nebude volať na druhom iterátore.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pretože argument pre `zip()` používa [`IntoIterator`], môžeme odovzdať čokoľvek, čo je možné previesť na [`Iterator`], nielen na samotný [`Iterator`].
    /// Napríklad rezy (`&[T]`) implementujú [`IntoIterator`], a tak je možné ich odovzdať priamo do `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` sa často používa na zips nekonečného iterátora na konečný.
    /// Funguje to, pretože konečný iterátor nakoniec vráti [`None`] a zips končí.Zipsovanie pomocou `(0..)` môže vyzerať veľmi podobne ako [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Vytvorí nový iterátor, ktorý umiestni kópiu `separator` medzi susedné položky pôvodného iterátora.
    ///
    /// V prípade, že `separator` neimplementuje [`Clone`] alebo ho treba zakaždým vypočítať, použite [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Prvý prvok z `a`.
    /// assert_eq!(a.next(), Some(&100)); // Oddeľovač.
    /// assert_eq!(a.next(), Some(&1));   // Ďalším prvkom z `a`.
    /// assert_eq!(a.next(), Some(&100)); // Oddeľovač.
    /// assert_eq!(a.next(), Some(&2));   // Posledný prvok z `a`.
    /// assert_eq!(a.next(), None);       // Iterátor je dokončený.
    /// ```
    ///
    /// `intersperse` môže byť veľmi užitočné spojiť položky iterátora pomocou spoločného prvku:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Vytvorí nový iterátor, ktorý umiestni položku vygenerovanú `separator` medzi susedné položky pôvodného iterátora.
    ///
    /// Uzávierka sa zavolá presne raz zakaždým, keď sa položka umiestni medzi dve susedné položky zo základného iterátora;
    /// uzávierka sa konkrétne nevyvolá, ak podkladový iterátor prinesie menej ako dve položky a potom, čo sa získa posledná položka.
    ///
    ///
    /// Ak položka iterátora implementuje [`Clone`], môže byť jednoduchšie použiť [`intersperse`].
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Prvý prvok z `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Oddeľovač.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Ďalším prvkom z `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Oddeľovač.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Posledný prvok z `v`.
    /// assert_eq!(it.next(), None);               // Iterátor je dokončený.
    /// ```
    ///
    /// `intersperse_with` možno použiť v situáciách, keď je potrebné vypočítať oddeľovač:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Uzávierka si premenlivo vypožičiava svoj kontext na vygenerovanie položky.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Berie uzáver a vytvára iterátor, ktorý volá tento uzáver pre každý prvok.
    ///
    /// `map()` transformuje jeden iterátor na druhý pomocou svojho argumentu:
    /// niečo, čo implementuje [`FnMut`].Produkuje nový iterátor, ktorý nazýva toto uzavretie pre každý prvok pôvodného iterátora.
    ///
    /// Ak dokážete dobre myslieť na typy, môžete myslieť na `map()` takto:
    /// Ak máte iterátor, ktorý vám dáva prvky nejakého typu `A`, a chcete iterátor nejakého iného typu `B`, môžete použiť `map()` a odovzdať uzáver, ktorý vezme `A` a vráti `B`.
    ///
    ///
    /// `map()` je koncepčne podobný slučke [`for`].Pretože je `map()` lenivý, je najlepšie ho použiť, keď už pracujete s inými iterátormi.
    /// Ak robíte nejaké cyklovanie pre vedľajší efekt, použitie [`for`] ako `map()` sa považuje za idiomatické.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ak robíte nejaké vedľajšie účinky, uprednostnite [`for`] až `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // nerob to:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // nebude ani popravený, keďže je lenivý.Rust vás na to upozorní.
    ///
    /// // Namiesto toho použite na:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Zavolá uzávierku pre každý prvok iterátora.
    ///
    /// Toto je ekvivalentné použitiu slučky [`for`] na iterátore, aj keď `break` a `continue` nie sú možné z uzavretia.
    /// Všeobecne je viac idiomatické používať slučku `for`, ale `for_each` môže byť čitateľnejšia pri spracovaní položiek na konci dlhších reťazcov iterátora.
    ///
    /// V niektorých prípadoch môže byť `for_each` rýchlejší ako slučka, pretože bude používať internú iteráciu na adaptéroch, ako je `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// V takom malom príklade môže byť slučka `for` čistejšia, ale pre zachovanie funkčného štýlu s dlhšími iterátormi by mohlo byť lepšie použiť `for_each`:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Vytvorí iterátor, ktorý pomocou uzáveru určí, či sa má prvok získať.
    ///
    /// Vzhľadom na prvok musí uzávierka vracať `true` alebo `false`.Vrátený iterátor prinesie iba prvky, pre ktoré sa uzávierka vráti ako pravdivá.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pretože uzávierka odovzdaná do `filter()` má referenciu a mnoho iterátorov iteruje nad referenciami, vedie to k pravdepodobne mätúcej situácii, keď je typ uzávierky dvojitou referenciou:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // treba dve * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Je bežné, že namiesto toho použijete deštrukturalizáciu argumentu na odstránenie jedného:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // obaja a *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// alebo obaja:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dve &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// z týchto vrstiev.
    ///
    /// Upozorňujeme, že `iter.filter(f).next()` je ekvivalentný s `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Vytvorí iterátor, ktorý filtruje aj mapuje.
    ///
    /// Vrátený iterátor prinesie iba hodnoty, pre ktoré dodaný uzáver vráti `Some(value)`.
    ///
    /// `filter_map` možno použiť na zvýšenie stručnosti reťazí [`filter`] a [`map`].
    /// Nasledujúci príklad ukazuje, ako je možné `map().filter().map()` skrátiť na jedno volanie na `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tu je rovnaký príklad, ale s [`filter`] a [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Vytvorí iterátor, ktorý poskytne aktuálnemu počtu iterácií aj ďalšiu hodnotu.
    ///
    /// Iterátor vrátil výnosy párov `(i, val)`, kde `i` je aktuálny index iterácie a `val` je hodnota vrátená iterátorom.
    ///
    ///
    /// `enumerate()` zachováva svoj počet ako [`usize`].
    /// Ak chcete počítať podľa iného veľkého čísla, funkcia [`zip`] poskytuje podobnú funkčnosť.
    ///
    /// # Chovanie pri pretečení
    ///
    /// Metóda nechráni pred pretečením, takže výpočet viac ako prvkov [`usize::MAX`] vedie k nesprávnemu výsledku alebo k panics.
    /// Ak sú povolené tvrdenia ladenia, je zaručená hodnota panic.
    ///
    /// # Panics
    ///
    /// Vrátený iterátor by mohol panic, ak by index, ktorý sa má vrátiť, pretečie [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Vytvorí iterátor, ktorý môže pomocou [`peek`] sledovať ďalší prvok iterátora bez jeho konzumácie.
    ///
    /// Pridá do iterátora metódu [`peek`].Ďalšie informácie nájdete v jeho dokumentácii.
    ///
    /// Všimnite si, že podkladový iterátor je stále pokročilý, keď sa [`peek`] volá po prvýkrát: S cieľom načítať ďalší prvok sa [`next`] volá na podkladovom iterátore, teda všetky vedľajšie účinky (tj.
    ///
    /// vyskytne sa čokoľvek iné ako načítanie ďalšej hodnoty) metódy [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() dovoľte nám nahliadnuť do future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // môžeme peek() viackrát, iterátor nepostúpi
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // po dokončení iterátora je aj peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Vytvorí iterátor, ktorý [" preskočí`] prvky na základe predikátu.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` berie uzávierku ako argument.Zavolá toto uzavretie pre každý prvok iterátora a prvky bude ignorovať, kým vráti `false`.
    ///
    /// Po vrátení `false` je úloha `skip_while()`'s ukončená a zvyšok prvkov sa získa.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pretože uzávierka odovzdaná `skip_while()` má odkaz a mnoho iterátorov iteruje nad referenciami, vedie to k pravdepodobne mätúcej situácii, keď je typom argumentu uzávierky dvojitá referencia:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // treba dve * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zastavenie po počiatočnom `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // aj keď by to bolo nepravdivé, pretože už sme dostali nepravdivé, skip_while() sa už nepoužíva
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Vytvorí iterátor, ktorý poskytuje prvky na základe predikátu.
    ///
    /// `take_while()` berie uzávierku ako argument.Zavolá tento uzáver pre každý prvok iterátora a vráti prvky, kým vráti `true`.
    ///
    /// Po vrátení `false` je úloha `take_while()`'s ukončená a ostatné prvky sú ignorované.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pretože uzávierka odovzdaná do `take_while()` má referenciu a mnoho iterátorov iteruje nad referenciami, vedie to k pravdepodobne mätúcej situácii, keď je typ uzávierky dvojitou referenciou:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // treba dve * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zastavenie po počiatočnom `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Máme viac prvkov, ktoré sú menšie ako nula, ale keďže sme už dostali nepravdivý údaj, take_while() sa už viac nepoužíva
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Pretože `take_while()` musí skontrolovať hodnotu, aby zistil, či má alebo nemá byť zahrnutá, konzumácia iterátorov uvidí, že je odstránená:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` tam už nie je, pretože bol spotrebovaný, aby sa zistilo, či sa má iterácia zastaviť, ale nebol vložený späť do iterátora.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Vytvorí iterátor, ktorý poskytne prvky na základe predikátu a máp.
    ///
    /// `map_while()` berie uzávierku ako argument.
    /// Zavolá tento uzáver pre každý prvok iterátora a vráti prvky, kým vráti [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tu je rovnaký príklad, ale s [`take_while`] a [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zastavenie po počiatočnom [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Máme viac prvkov, ktoré by sa zmestili do u32 (4, 5), ale `map_while` vrátil `None` pre `-3` (ako `predicate` vrátil `None`) a `collect` sa zastaví pri prvom stretnutí s `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Pretože `map_while()` musí skontrolovať hodnotu, aby zistil, či má alebo nemá byť zahrnutá, konzumácia iterátorov uvidí, že je odstránená:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` tam už nie je, pretože bol spotrebovaný, aby sa zistilo, či sa má iterácia zastaviť, ale nebol vložený späť do iterátora.
    ///
    /// Upozorňujeme, že na rozdiel od modelu [`take_while`] nie je tento iterátor ** kondenzovaný.
    /// Taktiež nie je zadané, čo tento iterátor vráti po vrátení prvého [`None`].
    /// Ak potrebujete tavený iterátor, použite [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Vytvorí iterátor, ktorý preskočí prvé prvky `n`.
    ///
    /// Po ich spotrebovaní sa získa zvyšok prvkov.
    /// Namiesto priameho prepísania tejto metódy namiesto toho prepíšte metódu `nth`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Vytvorí iterátor, ktorý poskytne prvé prvky `n`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` sa často používa s nekonečným iterátorom, aby bol konečný:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ak je k dispozícii menej ako `n` prvkov, `take` sa obmedzí na veľkosť základného iterátora:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adaptér iterátora podobný [`fold`], ktorý uchováva interný stav a vytvára nový iterátor.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` vezme dva argumenty: počiatočnú hodnotu, ktorá osádza vnútorný stav, a záver s dvoma argumentmi, z ktorých prvý je premenlivý odkaz na vnútorný stav a druhý iteračný prvok.
    ///
    /// Uzávierku je možné priradiť k internému stavu, aby sa mohol zdieľať stav medzi iteráciami.
    ///
    /// Pri iterácii sa uzáver použije na každý prvok iterátora a iterátor získa návratovú hodnotu z uzáveru, [`Option`].
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // pri každej iterácii vynásobíme stav prvkom
    ///     *state = *state * x;
    ///
    ///     // potom sa poddáme negácii štátu
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Vytvorí iterátor, ktorý funguje ako mapa, ale vyrovná vnorenú štruktúru.
    ///
    /// Adaptér [`map`] je veľmi užitočný, ale iba vtedy, keď argument uzavretia vytvára hodnoty.
    /// Ak namiesto toho vytvorí iterátor, existuje ďalšia vrstva nepriamosti.
    /// `flat_map()` odstráni túto ďalšiu vrstvu samostatne.
    ///
    /// Môžete si myslieť, že `flat_map(f)` je sémantický ekvivalent [" mapovania`] pingu a potom [" sploštenie`] ako v `map(f).flatten()`.
    ///
    /// Iný spôsob uvažovania o `flat_map()`: Uzávierka [`mapa`] vráti jednu položku pre každý prvok a uzávierka `flat_map()`'s vráti iterátor pre každý prvok.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vráti iterátor
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Vytvorí iterátor, ktorý vyrovná vnorenú štruktúru.
    ///
    /// Je to užitočné, keď máte iterátor iterátorov alebo iterátor vecí, ktoré sa dajú zmeniť na iterátory, a chcete odstrániť jednu úroveň nepriechodnosti.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mapovanie a následné sploštenie:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vráti iterátor
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Môžete to tiež prepísať na [`flat_map()`], čo je v tomto prípade výhodnejšie, pretože to jasnejšie vyjadruje zámer:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vráti iterátor
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Sploštenie odstráni iba jednu úroveň vnorenia naraz:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Tu vidíme, že `flatten()` nevykonáva sploštenie "deep".
    /// Namiesto toho je odstránená iba jedna úroveň vnorenia.To znamená, že ak použijete trojrozmerné pole `flatten()`, výsledok bude dvojrozmerný a nie jednorozmerný.
    /// Ak chcete získať jednorozmernú štruktúru, musíte znova `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Vytvorí iterátor, ktorý končí po prvom [`None`].
    ///
    /// Keď iterátor vráti [`None`], hovory future môžu, ale nemusia, znova priniesť [`Some(T)`].
    /// `fuse()` prispôsobí iterátor a zabezpečí, že po zadaní [`None`] vráti [`None`] vždy navždy.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // iterátor, ktorý strieda niektoré a žiadne
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ak je párne, Some(i32), iné Žiadne
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // môžeme vidieť náš iterátor chodiť tam a späť
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // akonáhle to však spojíme ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // vždy po prvom návrate vráti `None`.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Robí niečo s každým prvkom iterátora a prenáša hodnotu ďalej.
    ///
    /// Pri použití iterátorov často spojíte niekoľko z nich dohromady.
    /// Pri práci na takomto kóde budete možno chcieť skontrolovať, čo sa deje v rôznych častiach plánu.Urobíte to tak, že zavoláte na číslo `inspect()`.
    ///
    /// Je bežnejšie, že sa `inspect()` používa ako ladiaci nástroj, ako by sa nachádzal vo vašom konečnom kóde, ale aplikáciám sa môže hodiť v určitých situáciách, keď je potrebné pred zahodením zaznamenať chyby.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // táto iterátorová sekvencia je zložitá.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // pridajme nejaké volania inspect(), aby sme preskúmali, čo sa deje
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Týmto sa vytlačí:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Chyby pred prihlásením do denníka:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Týmto sa vytlačí:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Požičia si iterátor, a nie ho konzumovať.
    ///
    /// To je užitočné, ak chcete umožniť použitie adaptérov iterátora, pričom si stále ponecháte vlastníctvo pôvodného iterátora.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ak sa pokúsime znova použiť iter, nebude to fungovať.
    /// // Nasledujúci riadok udáva " chybu: použitie presunutej hodnoty: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // skúsme to znova
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // namiesto toho pridáme .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // teraz je to v poriadku:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Transformuje iterátor na kolekciu.
    ///
    /// `collect()` môže vziať čokoľvek opakovateľné a zmeniť ho na relevantnú zbierku.
    /// Toto je jedna z výkonnejších metód v štandardnej knižnici, ktorá sa používa v rôznych kontextoch.
    ///
    /// Najzákladnejším vzorom, v ktorom sa `collect()` používa, je premena jednej kolekcie na druhú.
    /// Vezmete zbierku, zavoláte na ňu [`iter`], urobíte kopu transformácií a potom na konci `collect()`.
    ///
    /// `collect()` môže tiež vytvárať inštancie typov, ktoré nie sú typickými kolekciami.
    /// Napríklad [`String`] môže byť zostavený z [`char`] s a iterátor položiek [`Result<T, E>`][`Result`] môže byť zhromaždený do `Result<Collection<T>, E>`.
    ///
    /// Ďalšie informácie nájdete v nižšie uvedených príkladoch.
    ///
    /// Pretože `collect()` je taký všeobecný, môže spôsobiť problémy s odvodením typu.
    /// Preto je `collect()` jedným z mála prípadov, kedy uvidíte syntax láskyplne známu ako 'turbofish': `::<>`.
    /// To pomáha odvodzovaciemu algoritmu konkrétne pochopiť, do ktorej zbierky sa snažíte zbierať.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Upozorňujeme, že sme potrebovali `: Vec<i32>` na ľavej strane.Je to preto, že by sme namiesto nich mohli zhromaždiť napríklad [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Použitie 'turbofish' namiesto anotácie `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Pretože `collect()` sa stará iba o to, do čoho zbierate, s turbofish môžete stále používať čiastočný tip typu, `_`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Použitie `collect()` na výrobu [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ak máte zoznam [`Výsledok<T, E>`][`Výsledok`] s, pomocou `collect()` môžete zistiť, či niektorý z nich zlyhal:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nám dáva prvú chybu
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nám dáva zoznam odpovedí
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Spotrebuje iterátor a vytvorí z neho dve kolekcie.
    ///
    /// Predikát predaný `partition()` môže vrátiť `true` alebo `false`.
    /// `partition()` vráti pár, všetky prvky, za ktoré vrátil `true`, a všetky prvky, za ktoré vrátil `false`.
    ///
    ///
    /// Pozri tiež [`is_partitioned()`] a [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Znovu usporiada prvky tohto iterátora *na mieste* podľa daného predikátu, takže všetky, ktoré vrátia `true`, budú predchádzať všetkým, ktoré vrátia `false`.
    ///
    /// Vráti počet nájdených prvkov `true`.
    ///
    /// Relatívne poradie rozdelených položiek nie je zachované.
    ///
    /// Pozri tiež [`is_partitioned()`] a [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Rozdelte na miesto medzi rovnosťami a pravdepodobnosťou
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: mali by sme sa obávať, že počet pretečie?Jediný spôsob, ako mať viac ako
        // `usize::MAX` premenlivé odkazy sú so ZST, ktoré nie sú užitočné na rozdelenie ...

        // Tieto uzatváracie funkcie "factory" existujú, aby sa zabránilo genericite v `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Opakovane nájdite prvý `false` a vymeňte ho za posledný `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Skontroluje, či sú prvky tohto iterátora rozdelené podľa daného predikátu tak, aby všetky, ktoré vracajú `true`, predchádzali všetky, ktoré vrátili `false`.
    ///
    ///
    /// Pozri tiež [`partition()`] a [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Buď všetky položky otestujú `true`, alebo sa prvá klauzula zastaví na `false` a skontrolujeme, či po nej už nebudú žiadne ďalšie položky `true`.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Metóda iterátora, ktorá aplikuje funkciu, pokiaľ sa vráti úspešne, a vytvorí jednu konečnú hodnotu.
    ///
    /// `try_fold()` trvá dva argumenty: počiatočná hodnota a uzávierka s dvoma argumentmi: 'accumulator' a element.
    /// Uzávierka sa vráti úspešne s hodnotou, ktorú by mal mať akumulátor pre nasledujúcu iteráciu, alebo vráti zlyhanie s chybovou hodnotou, ktorá sa okamžite rozšíri späť na volajúceho (short-circuiting).
    ///
    ///
    /// Počiatočná hodnota je hodnota, ktorú bude mať akumulátor pri prvom hovore.Ak bolo použitie uzáveru úspešné proti každému prvku iterátora, vráti `try_fold()` konečný akumulátor ako úspešný.
    ///
    /// Skladanie je užitočné, kedykoľvek máte zbierku niečoho a chcete z toho vyprodukovať jednu hodnotu.
    ///
    /// # Poznámka pre realizátorov
    ///
    /// Niekoľko ďalších metód (forward) má predvolenú implementáciu v zmysle tejto metódy, takže ju skúste implementovať výslovne, ak dokáže niečo lepšie ako predvolená implementácia slučky `for`.
    ///
    /// Snažte sa predovšetkým mať toto volanie `try_fold()` na vnútorných častiach, z ktorých je zložený tento iterátor.
    /// Ak je potrebných viac hovorov, operátor `?` môže byť vhodný na zreťazenie hodnoty akumulátora, pozor však na všetky invarianty, ktoré je potrebné dodržať pred týmito skorými návratmi.
    /// Toto je metóda `&mut self`, takže po zasiahnutí chyby tu je potrebné obnovenie iterácie.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // skontrolovaný súčet všetkých prvkov poľa
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Táto suma preteká pri pridávaní prvku 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Pretože bol skratovaný, zvyšné prvky sú stále dostupné prostredníctvom iterátora.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metóda iterátora, ktorá aplikuje omylnú funkciu na každú položku v iterátore, zastaví sa pri prvej chybe a vráti túto chybu.
    ///
    ///
    /// Dá sa to tiež považovať za omylnú formu [`for_each()`] alebo za bezstavovú verziu [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Skratovalo sa, takže zvyšné položky sú stále v iterátore:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Zloží každý prvok do akumulátora vykonaním operácie a vráti konečný výsledok.
    ///
    /// `fold()` trvá dva argumenty: počiatočná hodnota a uzávierka s dvoma argumentmi: 'accumulator' a element.
    /// Uzávierka vráti hodnotu, ktorú by mal mať akumulátor pre nasledujúcu iteráciu.
    ///
    /// Počiatočná hodnota je hodnota, ktorú bude mať akumulátor pri prvom hovore.
    ///
    /// Po použití tohto uzáveru na každý prvok iterátora vráti `fold()` akumulátor.
    ///
    /// Táto operácia sa niekedy nazýva 'reduce' alebo 'inject'.
    ///
    /// Skladanie je užitočné, kedykoľvek máte zbierku niečoho a chcete z toho vyprodukovať jednu hodnotu.
    ///
    /// Note: `fold()` a podobné metódy, ktoré prechádzajú celým iterátorom, sa nemusia ukončiť pre nekonečné iterátory, a to ani pri traits, pre ktoré je výsledok stanoviteľný v konečnom čase.
    ///
    /// Note: [`reduce()`] možno použiť na použitie prvého prvku ako počiatočnej hodnoty, ak sú typ akumulátora a typ položky rovnaké.
    ///
    /// # Poznámka pre realizátorov
    ///
    /// Niekoľko ďalších metód (forward) má predvolenú implementáciu v zmysle tejto metódy, takže ju skúste implementovať výslovne, ak dokáže niečo lepšie ako predvolená implementácia slučky `for`.
    ///
    ///
    /// Snažte sa predovšetkým mať toto volanie `fold()` na vnútorných častiach, z ktorých je zložený tento iterátor.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // súčet všetkých prvkov poľa
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Prejdime si tu každý krok iterácie:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// A tak náš konečný výsledok, `6`.
    ///
    /// Je bežné, že ľudia, ktorí iterátory príliš nepoužívajú, používajú na vytvorenie výsledku slučku `for` so zoznamom vecí.Tie sa dajú zmeniť na `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // pre slučku:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // sú rovnaké
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Redukuje prvky na jeden opakovaným použitím redukčnej operácie.
    ///
    /// Ak je iterátor prázdny, vráti [`None`];v opačnom prípade vráti výsledok redukcie.
    ///
    /// Pre iterátory s aspoň jedným prvkom je to rovnaké ako [`fold()`] s prvým prvkom iterátora ako počiatočnou hodnotou, do ktorej sa skladá každý nasledujúci prvok.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Nájdite maximálnu hodnotu:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Testuje, či sa každý prvok iterátora zhoduje s predikátom.
    ///
    /// `all()` vezme uzávierku, ktorá vráti `true` alebo `false`.Aplikuje toto uzavretie na každý prvok iterátora, a ak všetky vrátia `true`, potom aj `all()`.
    /// Ak niektorý z nich vráti `false`, vráti `false`.
    ///
    /// `all()` je skratový;inými slovami, prestane sa spracovávať, akonáhle nájde `false`, pretože bez ohľadu na to, čo sa ešte stane, výsledkom bude tiež `false`.
    ///
    ///
    /// Prázdny iterátor vráti `true`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Zastavenie na prvom `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // stále môžeme používať `iter`, pretože prvkov je viac.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Testuje, či sa niektorý prvok iterátora zhoduje s predikátom.
    ///
    /// `any()` vezme uzávierku, ktorá vráti `true` alebo `false`.Aplikuje toto uzavretie na každý prvok iterátora, a ak niektorý z nich vráti `true`, potom aj `any()`.
    /// Ak všetci vrátia `false`, vráti `false`.
    ///
    /// `any()` je skratový;inými slovami, prestane sa spracovávať, akonáhle nájde `true`, pretože bez ohľadu na to, čo sa ešte stane, výsledkom bude tiež `true`.
    ///
    ///
    /// Prázdny iterátor vráti `false`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Zastavenie na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // stále môžeme používať `iter`, pretože prvkov je viac.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Vyhľadá prvok iterátora, ktorý spĺňa predikát.
    ///
    /// `find()` prijme uzávierku, ktorá vráti `true` alebo `false`.
    /// Aplikuje toto uzavretie na každý prvok iterátora, a ak niektorý z nich vráti `true`, potom `find()` vráti [`Some(element)`].
    /// Ak všetci vrátia `false`, vráti [`None`].
    ///
    /// `find()` je skratový;inými slovami, prestane sa spracovávať, akonáhle uzávierka vráti `true`.
    ///
    /// Pretože `find()` berie referenciu a mnoho iterátorov iteruje nad referenciami, vedie to k pravdepodobne mätúcej situácii, keď je argument dvojitým odkazom.
    ///
    /// Tento efekt môžete vidieť na príkladoch nižšie s `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Zastavenie na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // stále môžeme používať `iter`, pretože prvkov je viac.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Upozorňujeme, že `iter.find(f)` je ekvivalentný s `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Aplikuje funkciu na prvky iterátora a vráti prvý non-none výsledok.
    ///
    ///
    /// `iter.find_map(f)` je ekvivalentná s `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Aplikuje funkciu na prvky iterátora a vráti prvý skutočný výsledok alebo prvú chybu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Vyhľadá prvok v iterátore a vráti jeho index.
    ///
    /// `position()` prijme uzávierku, ktorá vráti `true` alebo `false`.
    /// Aplikuje toto uzavretie na každý prvok iterátora, a ak jeden z nich vráti `true`, potom `position()` vráti [`Some(index)`].
    /// Ak všetky vrátia `false`, vráti [`None`].
    ///
    /// `position()` je skratový;inými slovami, prestane sa spracovávať, akonáhle nájde `true`.
    ///
    /// # Chovanie pri pretečení
    ///
    /// Metóda nie je chránená proti pretečeniu, takže ak existuje viac ako [`usize::MAX`] nezhodných prvkov, vytvorí buď nesprávny výsledok, alebo panics.
    ///
    /// Ak sú povolené tvrdenia ladenia, je zaručená hodnota panic.
    ///
    /// # Panics
    ///
    /// Táto funkcia môže byť panic, ak má iterátor viac ako `usize::MAX` nezhodných prvkov.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Zastavenie na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // stále môžeme používať `iter`, pretože prvkov je viac.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Vrátený index závisí od stavu iterátora
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Vyhľadá prvok v iterátore sprava a vráti jeho index.
    ///
    /// `rposition()` prijme uzávierku, ktorá vráti `true` alebo `false`.
    /// Aplikuje toto uzavretie na každý prvok iterátora, počnúc od konca, a ak jeden z nich vráti `true`, potom `rposition()` vráti [`Some(index)`].
    ///
    /// Ak všetky vrátia `false`, vráti [`None`].
    ///
    /// `rposition()` je skratový;inými slovami, prestane sa spracovávať, akonáhle nájde `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Zastavenie na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // stále môžeme používať `iter`, pretože prvkov je viac.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Tu nie je potrebná kontrola pretečenia, pretože `ExactSizeIterator` znamená, že počet prvkov zapadá do `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Vráti maximálny prvok iterátora.
    ///
    /// Ak je niekoľko prvkov rovnako maximálnych, vráti sa posledný prvok.
    /// Ak je iterátor prázdny, vráti sa [`None`].
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Vráti minimálny prvok iterátora.
    ///
    /// Ak je niekoľko prvkov rovnako minimálnych, vráti sa prvý prvok.
    /// Ak je iterátor prázdny, vráti sa [`None`].
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Vráti prvok, ktorý dáva maximálnu hodnotu zo zadanej funkcie.
    ///
    ///
    /// Ak je niekoľko prvkov rovnako maximálnych, vráti sa posledný prvok.
    /// Ak je iterátor prázdny, vráti sa [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Vráti prvok, ktorý dáva maximálnu hodnotu vzhľadom na zadanú porovnávaciu funkciu.
    ///
    ///
    /// Ak je niekoľko prvkov rovnako maximálnych, vráti sa posledný prvok.
    /// Ak je iterátor prázdny, vráti sa [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Vráti prvok, ktorý dáva minimálnu hodnotu zo zadanej funkcie.
    ///
    ///
    /// Ak je niekoľko prvkov rovnako minimálnych, vráti sa prvý prvok.
    /// Ak je iterátor prázdny, vráti sa [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Vráti prvok, ktorý dáva minimálnu hodnotu vzhľadom na zadanú porovnávaciu funkciu.
    ///
    ///
    /// Ak je niekoľko prvkov rovnako minimálnych, vráti sa prvý prvok.
    /// Ak je iterátor prázdny, vráti sa [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Obráti smer iterátora.
    ///
    /// Iterátory zvyčajne iterujú zľava doprava.
    /// Po použití `rev()` bude iterátor namiesto toho iterovať sprava doľava.
    ///
    /// Toto je možné iba v prípade, že má iterátor koniec, takže `rev()` funguje iba na [" DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Skonvertuje iterátor párov na pár kontajnerov.
    ///
    /// `unzip()` spotrebuje celý iterátor párov a vytvorí dve zbierky: jednu z ľavých prvkov dvojíc a jednu z pravých prvkov.
    ///
    ///
    /// Táto funkcia je v istom zmysle opakom [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Vytvorí iterátor, ktorý skopíruje všetky jeho prvky.
    ///
    /// To je užitočné, ak máte iterátor nad `&T`, ale potrebujete iterátor nad `T`.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopírovaný je rovnaký ako .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Vytvorí iterátor, ktorý [klonuje] všetky jeho prvky.
    ///
    /// To je užitočné, ak máte iterátor nad `&T`, ale potrebujete iterátor nad `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonovaný je rovnaký ako .map(|&x| x) pre celé čísla
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Opakuje iterátor donekonečna.
    ///
    /// Namiesto zastavenia na [`None`] sa iterátor začne znova od začiatku.Po opätovnom vykonaní iterácie sa začne znova na začiatku.A znova.
    /// A znova.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sčíta prvky iterátora.
    ///
    /// Zoberie každý prvok, spojí ich a vráti výsledok.
    ///
    /// Prázdny iterátor vráti nulovú hodnotu typu.
    ///
    /// # Panics
    ///
    /// Pri volaní `sum()` a vracaní sa primitívneho celého čísla bude táto metóda panic, ak výpočet pretečie a sú povolené tvrdenia ladenia.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iteruje celým iterátorom a znásobuje všetky prvky
    ///
    /// Prázdny iterátor vráti jednu hodnotu typu.
    ///
    /// # Panics
    ///
    /// Pri volaní `product()` a vracaní sa primitívneho celého čísla bude metóda panic, ak výpočet pretečie a sú povolené tvrdenia ladenia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnáva prvky tohto modelu [`Iterator`] s prvkami iného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnáva prvky tohto [`Iterator`] s prvkami iného s ohľadom na zadanú porovnávaciu funkciu.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnáva prvky tohto modelu [`Iterator`] s prvkami iného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) porovnáva prvky tohto [`Iterator`] s prvkami iného s ohľadom na zadanú porovnávaciu funkciu.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Určuje, či sú prvky tohto prvku [`Iterator`] rovnaké ako prvky iného prvku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Určuje, či sú prvky tohto [`Iterator`] rovnaké ako prvky iného vzhľadom na zadanú funkciu rovnosti.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Určuje, či sú prvky tohto modelu [`Iterator`] nerovnaké s prvkami iného prvku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Určuje, či sú prvky tohto [`Iterator`] o [lexicographically](Ord#lexicographical-comparison) menšie ako prvky iného.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Určuje, či sú prvky tohto prvku [`Iterator`] menšie alebo rovné prvkom iného prvku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Určuje, či sú prvky tohto prvku [`Iterator`] väčšie o [lexicographically](Ord#lexicographical-comparison) ako prvky iného prvku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Určuje, či sú prvky tohto prvku [`Iterator`] väčšie alebo rovné prvkom iného prvku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Skontroluje, či sú prvky tohto iterátora zoradené.
    ///
    /// To znamená, že pre každý prvok `a` a jeho nasledujúci prvok `b` musí `a <= b` platiť.Ak iterátor poskytne presne nulu alebo jeden prvok, vráti sa `true`.
    ///
    /// Upozorňujeme, že ak `Self::Item` je iba `PartialOrd`, ale nie `Ord`, vyššie uvedená definícia znamená, že táto funkcia vráti `false`, ak nie sú dve po sebe nasledujúce položky porovnateľné.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Skontroluje, či sú prvky tohto iterátora zoradené pomocou danej porovnávacej funkcie.
    ///
    /// Namiesto použitia `PartialOrd::partial_cmp` táto funkcia používa danú funkciu `compare` na určenie poradia dvoch prvkov.
    /// Okrem toho je to ekvivalent [`is_sorted`];ďalšie informácie nájdete v jeho dokumentácii.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Skontroluje, či sú prvky tohto iterátora zoradené pomocou danej funkcie extrakcie kľúčov.
    ///
    /// Namiesto priameho porovnania prvkov iterátora táto funkcia porovnáva kľúče prvkov, ako to určuje `f`.
    /// Okrem toho je to ekvivalent [`is_sorted`];ďalšie informácie nájdete v jeho dokumentácii.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Pozri [TrustedRandomAccess]
    // Nezvyčajný názov je zabrániť kolíziám mien v rozlíšení metódy, pozri #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}