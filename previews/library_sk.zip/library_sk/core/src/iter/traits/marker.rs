/// Iterátor, ktorý po vyčerpaní vždy poskytuje výnos `None`.
///
/// Ďalším volaním na tavený iterátor, ktorý raz vrátil `None`, sa zaručene vráti [`None`].
/// Tento trait by mali implementovať všetky iterátory, ktoré sa správajú týmto spôsobom, pretože umožňuje optimalizáciu [`Iterator::fuse()`].
///
///
/// Note: Všeobecne by ste nemali používať `FusedIterator` ako všeobecné hranice, ak potrebujete kondenzovaný iterátor.
/// Namiesto toho by ste mali zavolať [`Iterator::fuse()`] na iterátore.
/// Ak je iterátor už zlúčený, ďalší obal [`Fuse`] bude nepovolený a nebude mať trest za výkon.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterátor, ktorý hlási presnú dĺžku pomocou size_hint.
///
/// Iterátor hlási náznak veľkosti, kde je buď presný (dolná hranica sa rovná hornej hranici), alebo horná hranica je [`None`].
///
/// Horná hranica musí byť iba [`None`], ak je skutočná dĺžka iterátora väčšia ako [`usize::MAX`].
/// V takom prípade musí byť dolná hranica [`usize::MAX`], výsledkom čoho bude [`Iterator::size_hint()`] `(usize::MAX, None)`.
///
/// Pred dosiahnutím konca musí iterátor vyprodukovať presne taký počet prvkov, ktoré nahlásil alebo sa rozchádzajú.
///
/// # Safety
///
/// Tento trait sa musí implementovať, iba ak je zmluva potvrdená.
/// Spotrebitelia tohto produktu trait musia skontrolovať hornú hranicu hodnoty [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iterátor, ktorý pri získaní položky vezme aspoň jeden prvok zo svojho základného [`SourceIter`].
///
/// Volanie akejkoľvek metódy, ktorá posúva iterátor vpred, napr
/// [`next()`] alebo [`try_fold()`], zaručuje, že pre každý krok bola presunutá najmenej jedna hodnota podkladového zdroja iterátora a na jeho miesto by mohol byť vložený výsledok reťazca iterátora, za predpokladu, že štrukturálne obmedzenia zdroja umožňujú takéto vkladanie.
///
/// Inými slovami, táto trait naznačuje, že na mieste je možné zhromažďovať iteračný kanál.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}