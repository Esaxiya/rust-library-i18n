use crate::ops::{ControlFlow, Try};

/// Iterátor schopný získať prvky z oboch koncov.
///
/// Niečo, čo implementuje `DoubleEndedIterator`, má jednu extra schopnosť nad tým, čo implementuje [`Iterator`]: schopnosť brať tiež `Item` zozadu, aj spredu.
///
///
/// Je dôležité si uvedomiť, že tam aj späť fungujú na rovnakom rozsahu a neprekračujú sa: iterácia je u konca, keď sa stretnú v strede.
///
/// Podobným spôsobom ako pri protokole [`Iterator`], akonáhle `DoubleEndedIterator` vráti [`None`] z [`next_back()`], jeho opätovné volanie môže alebo nemusí nikdy vrátiť [`Some`].
/// [`next()`] a [`next_back()`] sú na tento účel zameniteľné.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Odstráni a vráti prvok z konca iterátora.
    ///
    /// Vráti `None`, ak už neexistujú ďalšie prvky.
    ///
    /// Dokumenty [trait-level] obsahujú ďalšie podrobnosti.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Prvky získané metódami `DoubleEndedIterator` sa môžu líšiť od tých, ktoré poskytujú metódy [`Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Posunie iterátor zozadu o prvky `n`.
    ///
    /// `advance_back_by` je reverzná verzia [`advance_by`].Táto metóda nedočkavo preskočí prvky `n` počnúc zozadu tak, že [`next_back`] zavolá až X03x, kým sa nestane [`None`].
    ///
    /// `advance_back_by(n)` vráti [`Ok(())`], ak iterátor úspešne postúpi o prvky `n`, alebo [`Err(k)`], ak sa vyskytne [`None`], kde `k` je počet prvkov, o ktoré je iterátor posunutý pred vyčerpaním prvkov (tj.
    /// dĺžka iterátora).
    /// Upozorňujeme, že hodnota `k` je vždy nižšia ako `n`.
    ///
    /// Volanie `advance_back_by(0)` nespotrebováva žiadne prvky a vždy vráti [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // preskočená bola iba `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Vráti `n`-tý prvok z konca iterátora.
    ///
    /// Toto je v podstate obrátená verzia [`Iterator::nth()`].
    /// Aj keď rovnako ako väčšina operácií indexovania, počet začína od nuly, takže `nth_back(0)` vráti prvú hodnotu od konca, `nth_back(1)` druhú atď.
    ///
    ///
    /// Upozorňujeme, že všetky prvky medzi koncovým a vráteným prvkom budú spotrebované, vrátane vráteného prvku.
    /// To tiež znamená, že volanie `nth_back(0)` viackrát na rovnakom iterátore vráti rôzne prvky.
    ///
    /// `nth_back()` vráti [`None`], ak je `n` väčšia alebo rovná dĺžke iterátora.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Opakované volanie `nth_back()` neprevinie iterátor:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Vrátenie `None`, ak je menej ako `n + 1` prvkov:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Toto je obrátená verzia [`Iterator::try_fold()`]: berie prvky začínajúce od zadnej časti iterátora.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Pretože bol skratovaný, zvyšné prvky sú stále dostupné prostredníctvom iterátora.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metóda iterátora, ktorá redukuje prvky iterátora na jednu konečnú hodnotu, začínajúc zozadu.
    ///
    /// Toto je obrátená verzia [`Iterator::fold()`]: berie prvky začínajúce od zadnej časti iterátora.
    ///
    /// `rfold()` trvá dva argumenty: počiatočná hodnota a uzávierka s dvoma argumentmi: 'accumulator' a element.
    /// Uzávierka vráti hodnotu, ktorú by mal mať akumulátor pre nasledujúcu iteráciu.
    ///
    /// Počiatočná hodnota je hodnota, ktorú bude mať akumulátor pri prvom hovore.
    ///
    /// Po použití tohto uzáveru na každý prvok iterátora vráti `rfold()` akumulátor.
    ///
    /// Táto operácia sa niekedy nazýva 'reduce' alebo 'inject'.
    ///
    /// Skladanie je užitočné, kedykoľvek máte zbierku niečoho a chcete z toho vyprodukovať jednu hodnotu.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // súčet všetkých prvkov a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Tento príklad vytvára reťazec, ktorý začína počiatočnou hodnotou a pokračuje s každým prvkom zozadu až po predok:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Vyhľadá zo zadnej strany prvok iterátora, ktorý spĺňa predikát.
    ///
    /// `rfind()` prijme uzávierku, ktorá vráti `true` alebo `false`.
    /// Aplikuje toto uzavretie na každý prvok iterátora, počnúc koncom a ak niektorý z nich vráti `true`, potom `rfind()` vráti [`Some(element)`].
    /// Ak všetci vrátia `false`, vráti [`None`].
    ///
    /// `rfind()` je skratový;inými slovami, prestane sa spracovávať, akonáhle uzávierka vráti `true`.
    ///
    /// Pretože `rfind()` berie referenciu a mnoho iterátorov iteruje nad referenciami, vedie to k pravdepodobne mätúcej situácii, keď je argument dvojitým odkazom.
    ///
    /// Tento efekt môžete vidieť na príkladoch nižšie s `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Zastavenie na prvom `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // stále môžeme používať `iter`, pretože prvkov je viac.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}