/// Konverzia z modelu [`Iterator`].
///
/// Implementáciou `FromIterator` pre typ definujete, ako sa bude vytvárať z iterátora.
/// To je bežné pre typy, ktoré popisujú zbierku nejakého druhu.
///
/// [`FromIterator::from_iter()`] sa zriedka volá explicitne a namiesto toho sa používa metódou [`Iterator::collect()`].
///
/// Ďalšie príklady nájdete v dokumentácii k produktu [`Iterator::collect()`]'s.
///
/// Pozri tiež: [`IntoIterator`].
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Použitie [`Iterator::collect()`] na implicitné použitie `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementácia `FromIterator` pre váš typ:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Ukážka zbierky, to je iba obal cez Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Dajme tomu niekoľko metód, aby sme mohli jednu vytvoriť a pridať k nej veci.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a implementujeme FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Teraz môžeme vytvoriť nový iterátor ...
/// let iter = (0..5).into_iter();
///
/// // ... a urobte z toho MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // zbierajte aj diela!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Vytvorí hodnotu z iterátora.
    ///
    /// Ďalšie informácie nájdete v [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konverzia na model [`Iterator`].
///
/// Implementáciou `IntoIterator` pre typ definujete, ako sa bude prevádzať na iterátor.
/// To je bežné pre typy, ktoré popisujú zbierku nejakého druhu.
///
/// Jednou z výhod implementácie `IntoIterator` je, že váš typ bude [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Pozri tiež: [`FromIterator`].
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementácia `IntoIterator` pre váš typ:
///
/// ```
/// // Ukážka zbierky, to je iba obal cez Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Dajme tomu niekoľko metód, aby sme mohli jednu vytvoriť a pridať k nej veci.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // a implementujeme IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Teraz môžeme vytvoriť novú kolekciu ...
/// let mut c = MyCollection::new();
///
/// // ... pridajte k tomu nejaké veci ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... a potom z neho urobte iterátor:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Je bežné používať `IntoIterator` ako trait bound.To umožňuje zmeniť typ zhromažďovania vstupov, pokiaľ je stále iterátorom.
/// Ďalšie hranice je možné určiť obmedzením na
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Typ prvkov, ktoré sa iterujú.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Aký druh iterátora z toho robíme?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Vytvorí iterátor z hodnoty.
    ///
    /// Ďalšie informácie nájdete v [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Rozšírte kolekciu o obsah iterátora.
///
/// Iterátory vytvárajú sériu hodnôt a zbierky možno považovať aj za sériu hodnôt.
/// `Extend` trait preklenuje túto medzeru a umožňuje vám rozšíriť kolekciu zahrnutím obsahu tohto iterátora.
/// Pri rozširovaní kolekcie o už existujúci kľúč sa táto položka aktualizuje, alebo v prípade kolekcií, ktoré umožňujú viac položiek s rovnakými kľúčmi, sa táto položka vloží.
///
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// // Reťazec môžete rozšíriť o niekoľko znakov:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementácia `Extend`:
///
/// ```
/// // Ukážka zbierky, to je iba obal cez Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Dajme tomu niekoľko metód, aby sme mohli jednu vytvoriť a pridať k nej veci.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // pretože MyCollection má zoznam i32s, implementujeme Extend pre i32
/// impl Extend<i32> for MyCollection {
///
///     // Toto je s podpisom konkrétneho typu o niečo jednoduchšie: môžeme volať extend na čokoľvek, čo sa dá zmeniť na Iterátor, ktorý nám dáva i32s.
///     // Pretože potrebujeme vložiť i32s do MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Implementácia je veľmi jednoduchá: prechádzajte iterátorom a každý prvok add() si zahrajte sami.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // rozšírme našu zbierku o ďalšie tri čísla
/// c.extend(vec![1, 2, 3]);
///
/// // tieto prvky sme pridali na koniec
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Rozširuje kolekciu o obsah iterátora.
    ///
    /// Pretože toto je jediná požadovaná metóda pre tento trait, dokumenty [trait-level] obsahujú ďalšie podrobnosti.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // Reťazec môžete rozšíriť o niekoľko znakov:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Rozširuje kolekciu presne o jeden prvok.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezervuje kapacitu v zbierke pre daný počet ďalších prvkov.
    ///
    /// Predvolená implementácia nerobí nič.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}