//! Manipulácia s reťazcami.
//!
//! Viac podrobností nájdete v module [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. mimo hranice
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. začiatok <=koniec
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. hranica znakov
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // nájdi postavu
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` musí byť menšie ako len a znaková hranica
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Vráti dĺžku `self`.
    ///
    /// Táto dĺžka je v bajtoch, nie [`char`] s alebo grafémy.
    /// Inými slovami, nemusí to byť to, čo človek považuje za dĺžku šnúrky.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // vymyslený f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Vráti `true`, ak má `self` dĺžku nula bajtov.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Skontroluje, či je " indexovaný` bajt prvý bajt v sekvencii kódových bodov UTF-8 alebo koniec reťazca.
    ///
    ///
    /// Začiatok a koniec reťazca (keď sa `index== self.len()`) považuje za hranice.
    ///
    /// Vráti `false`, ak je `index` väčšie ako `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // začiatok `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // druhý bajt `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // tretí bajt `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 a len sú vždy v poriadku.
        // Explicitne otestujte 0, aby mohla ľahko optimalizovať kontrolu a preskočiť čítanie údajov reťazca pre daný prípad.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Toto je bitová mágia ekvivalentná: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Skonvertuje reťazec na bajtový segment.
    /// Ak chcete previesť bajtový segment späť na reťazcový reťazec, použite funkciu [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // BEZPEČNOSŤ: konštantný zvuk, pretože prevádzame dva typy s rovnakým usporiadaním
        unsafe { mem::transmute(self) }
    }

    /// Skonvertuje premenlivý reťazec na premenlivý bajtový segment.
    ///
    /// # Safety
    ///
    /// Volajúci musí zabezpečiť, aby bol obsah rezu platný UTF-8 pred ukončením vypožičania a pred použitím podkladového `str`.
    ///
    ///
    /// Používanie `str`, ktorého obsah nie je platný UTF-8, je nedefinované správanie.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // BEZPEČNOSŤ: obsadenie z `&str` do `&[u8]` je bezpečné od `str`
        // má rovnaké rozloženie ako `&[u8]` (túto záruku môže poskytnúť iba libstd).
        // Ukazovateľ dereference je bezpečný, pretože pochádza z premenlivého odkazu, ktorý je zaručene platný pre zápisy.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Skonvertuje reťazec na surový ukazovateľ.
    ///
    /// Pretože reťazcové rezy sú plátkom bajtov, surový ukazovateľ ukazuje na [`u8`].
    /// Tento ukazovateľ bude smerovať na prvý bajt rezu reťazca.
    ///
    /// Volajúci musí zabezpečiť, aby sa na vrátený ukazovateľ nikdy nepripisovalo.
    /// Ak potrebujete zmutovať obsah rezu reťazca, použite [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Skonvertuje premenlivý rez reťazca na surový ukazovateľ.
    ///
    /// Pretože reťazcové rezy sú plátkom bajtov, surový ukazovateľ ukazuje na [`u8`].
    /// Tento ukazovateľ bude smerovať na prvý bajt rezu reťazca.
    ///
    /// Je vašou zodpovednosťou zabezpečiť, aby sa rez reťazca upravil iba tak, aby zostal platný UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Vráti čiastkový rez `str`.
    ///
    /// Toto je alternatíva nepanikárenia k indexovaniu `str`.
    /// Vráti [`None`], kedykoľvek by ekvivalentná operácia indexovania bola panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indexy nie sú na hraniciach sekvencií UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // mimo hranice
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Vráti premenlivý čiastkový rez `str`.
    ///
    /// Toto je alternatíva nepanikárenia k indexovaniu `str`.
    /// Vráti [`None`], kedykoľvek by ekvivalentná operácia indexovania bola panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // správna dĺžka
    /// assert!(v.get_mut(0..5).is_some());
    /// // mimo hranice
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Vráti nekontrolovaný čiastkový rez `str`.
    ///
    /// Toto je nekontrolovaná alternatíva k indexovaniu `str`.
    ///
    /// # Safety
    ///
    /// Volajúci tejto funkcie sú zodpovední za splnenie týchto predpokladov:
    ///
    /// * Počiatočný index nesmie prekročiť konečný index;
    /// * Indexy musia byť v medziach pôvodného rezu;
    /// * Indexy musia ležať na hraniciach sekvencií UTF-8.
    ///
    /// Pokiaľ to nie je možné, môže sa vrátený plátok reťazca odvolávať na neplatnú pamäť alebo porušovať invarianty komunikované typom `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked`;
        // plátok je dereferenčný, pretože `self` je bezpečná referencia.
        // Vrátený ukazovateľ je bezpečný, pretože implikáty `SliceIndex` musia zaručiť, že sú.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Vráti premenlivý nekontrolovaný čiastkový rez `str`.
    ///
    /// Toto je nekontrolovaná alternatíva k indexovaniu `str`.
    ///
    /// # Safety
    ///
    /// Volajúci tejto funkcie sú zodpovední za splnenie týchto predpokladov:
    ///
    /// * Počiatočný index nesmie prekročiť konečný index;
    /// * Indexy musia byť v medziach pôvodného rezu;
    /// * Indexy musia ležať na hraniciach sekvencií UTF-8.
    ///
    /// Pokiaľ to nie je možné, môže sa vrátený plátok reťazca odvolávať na neplatnú pamäť alebo porušovať invarianty komunikované typom `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked_mut`;
        // plátok je dereferenčný, pretože `self` je bezpečná referencia.
        // Vrátený ukazovateľ je bezpečný, pretože implikáty `SliceIndex` musia zaručiť, že sú.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Vytvorí rez reťazca z iného rezu reťazca, pričom obchádza kontroly bezpečnosti.
    ///
    /// Toto sa všeobecne neodporúča, používajte opatrne!Pre bezpečnú alternatívu pozri [`str`] a [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Tento nový plátok prechádza z `begin` na `end`, vrátane `begin`, ale s výnimkou `end`.
    ///
    /// Ak chcete namiesto toho získať premenlivý rez reťazca, pozrite si metódu [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Volajúci tejto funkcie sú zodpovední za splnenie troch predpokladov:
    ///
    /// * `begin` nesmie presiahnuť `end`.
    /// * `begin` a `end` musia byť bajtové pozície v reze reťazca.
    /// * `begin` a `end` musia ležať na hraniciach sekvencií UTF-8.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked`;
        // plátok je dereferenčný, pretože `self` je bezpečná referencia.
        // Vrátený ukazovateľ je bezpečný, pretože implikáty `SliceIndex` musia zaručiť, že sú.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Vytvorí rez reťazca z iného rezu reťazca, pričom obchádza kontroly bezpečnosti.
    /// Toto sa všeobecne neodporúča, používajte opatrne!Pre bezpečnú alternatívu pozri [`str`] a [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Tento nový plátok prechádza z `begin` na `end`, vrátane `begin`, ale s výnimkou `end`.
    ///
    /// Ak chcete namiesto toho získať nemenný rez reťazca, pozrite si metódu [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Volajúci tejto funkcie sú zodpovední za splnenie troch predpokladov:
    ///
    /// * `begin` nesmie presiahnuť `end`.
    /// * `begin` a `end` musia byť bajtové pozície v reze reťazca.
    /// * `begin` a `end` musia ležať na hraniciach sekvencií UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked_mut`;
        // plátok je dereferenčný, pretože `self` je bezpečná referencia.
        // Vrátený ukazovateľ je bezpečný, pretože implikáty `SliceIndex` musia zaručiť, že sú.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Jeden index reťazca rozdeľte na dva na indexe.
    ///
    /// Argument `mid` by mal byť posunom bajtu od začiatku reťazca.
    /// Musí byť tiež na hranici kódového bodu UTF-8.
    ///
    /// Vrátené dva plátky prechádzajú od začiatku rezu reťazca do `mid` a od `mid` do konca rezu reťazca.
    ///
    /// Ak chcete namiesto toho získať premenlivé rezy reťazcov, pozrite si metódu [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, ak `mid` nie je na hranici kódového bodu UTF-8, alebo ak je za koncom posledného kódového bodu rezu reťazca.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary skontroluje, či je index v [0, .len()]
        if self.is_char_boundary(mid) {
            // BEZPEČNOSŤ: iba ste skontrolovali, či je `mid` na hranici znakov.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Rozdelte jeden premenlivý rez reťazca na dva v indexe.
    ///
    /// Argument `mid` by mal byť posunom bajtu od začiatku reťazca.
    /// Musí byť tiež na hranici kódového bodu UTF-8.
    ///
    /// Vrátené dva plátky prechádzajú od začiatku rezu reťazca do `mid` a od `mid` do konca rezu reťazca.
    ///
    /// Ak chcete namiesto toho získať nemenné plátky reťazcov, pozrite si metódu [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, ak `mid` nie je na hranici kódového bodu UTF-8, alebo ak je za koncom posledného kódového bodu rezu reťazca.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary skontroluje, či je index v [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // BEZPEČNOSŤ: iba ste skontrolovali, či je `mid` na hranici znakov.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Vráti iterátor nad [`char`] s rezu reťazca.
    ///
    /// Pretože reťazcový rez pozostáva z platného UTF-8, môžeme iterovať cez reťazcový rez [`char`].
    /// Táto metóda vráti takýto iterátor.
    ///
    /// Je dôležité mať na pamäti, že [`char`] predstavuje skalárnu hodnotu Unicode a nemusí zodpovedať vašej predstave o tom, čo je 'character'.
    ///
    /// Iterácia nad grafickými klastrami môže byť to, čo skutočne chcete.
    /// Túto funkčnosť neposkytuje štandardná knižnica Rust, skontrolujte radšej crates.io.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Pamätajte, že [`char`] sa nemusia zhodovať s vašou intuíciou o postavách:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // nie 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Vráti iterátor nad [`char`] s rezu reťazca a ich pozície.
    ///
    /// Pretože reťazcový rez pozostáva z platného UTF-8, môžeme iterovať cez reťazcový rez [`char`].
    /// Táto metóda vráti iterátor oboch týchto [`char`] s, ako aj ich bajtových pozícií.
    ///
    /// Iterátor dáva n-tice.Pozícia je prvá, [`char`] je druhá.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Pamätajte, že [`char`] sa nemusia zhodovať s vašou intuíciou o postavách:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // nie (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // všimnite si 3, posledný znak zabral dva bajty
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Iterátor cez bajty rezu reťazca.
    ///
    /// Pretože reťazcový rez pozostáva zo sekvencie bajtov, môžeme iterovať reťazcový rez by bajtom.
    /// Táto metóda vráti takýto iterátor.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Rozdelí výplet reťazca o medzery.
    ///
    /// Vrátený iterátor vráti rezce reťazca, ktoré sú čiastkovými rezmi pôvodného rezu reťazca, oddelené ľubovoľným počtom medzier.
    ///
    ///
    /// 'Whitespace' je definované v súlade s podmienkami vlastnosti Unicode Derived Core Property `White_Space`.
    /// Ak sa chcete rozdeliť iba na medzery ASCII, použite [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Považujú sa všetky druhy medzier:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Rozdelí rez reťazca o medzery ASCII.
    ///
    /// Vrátený iterátor vráti rezce reťazca, ktoré sú čiastkovými rezmi pôvodného rezu reťazca, oddelené ľubovoľným počtom medzier v ASCII.
    ///
    ///
    /// Ak ich chcete rozdeliť pomocou Unicode `Whitespace`, použite [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Za všetky medzery ASCII sa považujú:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iterátor cez čiary reťazca ako plátky reťazca.
    ///
    /// Riadky sú ukončené buď novým riadkom (`\n`), alebo návratom riadku s posunom riadku (`\r\n`).
    ///
    /// Koniec posledného riadku je voliteľný.
    /// Reťazec, ktorý končí zakončením posledného riadku, vráti rovnaké riadky ako inak identický reťazec bez ukončenia posledného riadku.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Koniec posledného riadku sa nevyžaduje:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Iterátor cez čiary reťazca.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Vráti iterátor `u16` cez reťazec zakódovaný ako UTF-16.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Vráti `true`, ak sa daný vzor zhoduje s čiastkovým rezom tohto rezu reťazca.
    ///
    /// Vráti `false`, ak nie.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Vráti `true`, ak sa daný vzor zhoduje s predponou tohto rezu reťazca.
    ///
    /// Vráti `false`, ak nie.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Vráti `true`, ak sa daný vzor zhoduje s príponou tohto rezu reťazca.
    ///
    /// Vráti `false`, ak nie.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Vráti bajtový index prvého znaku tohto rezu reťazca, ktorý sa zhoduje so vzorom.
    ///
    /// Vráti [`None`], ak sa vzor nezhoduje.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Zložitejšie vzory využívajúce bezbodový štýl a uzávery:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Nenašiel sa vzor:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Vráti bajtový index pre prvý znak úplne vpravo vzoru v tomto reze reťazca.
    ///
    /// Vráti [`None`], ak sa vzor nezhoduje.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Zložitejšie vzory s uzávermi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Nenašiel sa vzor:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iterátor cez podreťazce tohto rezu reťazca, oddelené znakmi, ktoré sa zhodujú so vzorom.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor bude [`DoubleEndedIterator`], ak vzor umožňuje spätné vyhľadávanie a pri vyhľadávaní forward/reverse sa získajú rovnaké prvky.
    /// To platí napríklad pre [`char`], ale nie pre `&str`.
    ///
    /// Ak vzor umožňuje spätné vyhľadávanie, ale jeho výsledky sa môžu líšiť od vyhľadávania vpred, možno použiť metódu [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ak je vzorom výsek znakov, rozdelte sa pri každom výskyte niektorého zo znakov:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Zložitejší vzor pomocou uzáveru:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ak reťazec obsahuje viac súvislých oddeľovačov, vo výstupe skončíte s prázdnymi reťazcami:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Susediace oddeľovače sú oddelené prázdnym reťazcom.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Oddeľovače na začiatku alebo na konci reťazca susedia s prázdnymi reťazcami.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Keď sa prázdny reťazec používa ako oddeľovač, oddeľuje každý znak v reťazci spolu so začiatkom a koncom reťazca.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Súvislé oddeľovače môžu viesť k pravdepodobne prekvapivému správaniu, keď sa ako oddeľovač použije medzera.Tento kód je správny:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Poskytuje _not_:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Na toto správanie použite [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iterátor cez podreťazce tohto rezu reťazca, oddelené znakmi, ktoré sa zhodujú so vzorom.
    /// Rozdiely od iterátora produkovaného `split` v tom, že `split_inclusive` ponecháva spárovanú časť ako zakončenie podreťazca.
    ///
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ak sa zhoduje posledný prvok reťazca, bude sa tento prvok považovať za zakončenie predchádzajúceho podreťazca.
    /// Tento podreťazec bude poslednou položkou vrátenou iterátorom.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iterátor cez podreťazce daného rezu reťazca, oddelené znakmi, ktoré sa zhodujú so vzorom, a poskytujú sa v opačnom poradí.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor vyžaduje, aby vzor podporoval spätné vyhľadávanie, a bude to [`DoubleEndedIterator`], ak vyhľadávanie forward/reverse prinesie rovnaké prvky.
    ///
    ///
    /// Na iteráciu spredu možno použiť metódu [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Zložitejší vzor pomocou uzáveru:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iterátor cez podreťazce daného rezu reťazca, oddelené znakmi, ktoré sa zhodujú so vzorom.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekvivalent k [`split`], s tým rozdielom, že koncový podreťazec je preskočený, ak je prázdny.
    ///
    /// [`split`]: str::split
    ///
    /// Túto metódu je možné použiť pre údaje reťazca, ktoré sú _terminated_, a nie _separated_ podľa vzoru.
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor bude [`DoubleEndedIterator`], ak vzor umožňuje spätné vyhľadávanie a pri vyhľadávaní forward/reverse sa získajú rovnaké prvky.
    /// To platí napríklad pre [`char`], ale nie pre `&str`.
    ///
    /// Ak vzor umožňuje spätné vyhľadávanie, ale jeho výsledky sa môžu líšiť od vyhľadávania vpred, možno použiť metódu [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iterátor cez podreťazce `self`, oddelené znakmi uzavretými vzorom a získaný v opačnom poradí.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekvivalent k [`split`], s tým rozdielom, že koncový podreťazec je preskočený, ak je prázdny.
    ///
    /// [`split`]: str::split
    ///
    /// Túto metódu je možné použiť pre údaje reťazca, ktoré sú _terminated_, a nie _separated_ podľa vzoru.
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor vyžaduje, aby vzor podporoval spätné vyhľadávanie, a ak vyhľadávanie forward/reverse poskytne rovnaké prvky, bude mať dvojitý koniec.
    ///
    ///
    /// Na iteráciu spredu možno použiť metódu [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iterátor cez podreťazce daného rezu reťazca, oddelené vzorom, obmedzený na návrat najviac `n` položiek.
    ///
    /// Ak sa vrátia podreťazce `n`, posledný podreťazec (`n`-tý podreťazec) bude obsahovať zvyšok reťazca.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor nebude mať dvojité ukončenie, pretože jeho podpora nie je efektívna.
    ///
    /// Ak vzor umožňuje spätné vyhľadávanie, možno použiť metódu [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Zložitejší vzor pomocou uzáveru:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iterátor cez podreťazce tohto rezu reťazca, oddelené vzorom, počnúc od konca reťazca, obmedzené na návrat najviac `n` položiek.
    ///
    ///
    /// Ak sa vrátia podreťazce `n`, posledný podreťazec (`n`-tý podreťazec) bude obsahovať zvyšok reťazca.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor nebude mať dvojité ukončenie, pretože jeho podpora nie je efektívna.
    ///
    /// Na štiepanie spredu možno použiť metódu [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Zložitejší vzor pomocou uzáveru:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Rozdelí reťazec pri prvom výskyte zadaného oddeľovača a vráti predponu pred oddeľovačom a príponu za oddeľovačom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Rozdelí reťazec pri poslednom výskyte zadaného oddeľovača a vráti predponu pred oddeľovačom a príponu za oddeľovačom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Iterátor nad disjunktnými zhodami vzoru v danom reze reťazca.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor bude [`DoubleEndedIterator`], ak vzor umožňuje spätné vyhľadávanie a pri vyhľadávaní forward/reverse sa získajú rovnaké prvky.
    /// To platí napríklad pre [`char`], ale nie pre `&str`.
    ///
    /// Ak vzor umožňuje spätné vyhľadávanie, ale jeho výsledky sa môžu líšiť od vyhľadávania vpred, možno použiť metódu [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Iterátor nad disjunktnými zhodami vzoru v tomto reze reťazca, získaný v opačnom poradí.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor vyžaduje, aby vzor podporoval spätné vyhľadávanie, a bude to [`DoubleEndedIterator`], ak vyhľadávanie forward/reverse prinesie rovnaké prvky.
    ///
    ///
    /// Na iteráciu spredu možno použiť metódu [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iterátor nad disjunktnými zhodami vzoru v tomto reze reťazca, ako aj nad indexom, od ktorého zápas začína.
    ///
    /// Pre zhody `pat` v rámci `self`, ktoré sa prekrývajú, sa vrátia iba indexy zodpovedajúce prvej zhode.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor bude [`DoubleEndedIterator`], ak vzor umožňuje spätné vyhľadávanie a pri vyhľadávaní forward/reverse sa získajú rovnaké prvky.
    /// To platí napríklad pre [`char`], ale nie pre `&str`.
    ///
    /// Ak vzor umožňuje spätné vyhľadávanie, ale jeho výsledky sa môžu líšiť od vyhľadávania vpred, možno použiť metódu [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // iba prvý `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iterátor nad disjunktnými zhodami vzoru v rámci `self`, získaný v opačnom poradí spolu s indexom zhody.
    ///
    /// Pre zhody `pat` v rámci `self`, ktoré sa prekrývajú, sa vrátia iba indexy zodpovedajúce poslednej zhode.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Chovanie iterátora
    ///
    /// Vrátený iterátor vyžaduje, aby vzor podporoval spätné vyhľadávanie, a bude to [`DoubleEndedIterator`], ak vyhľadávanie forward/reverse prinesie rovnaké prvky.
    ///
    ///
    /// Na iteráciu spredu možno použiť metódu [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // iba posledny `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Vráti rez reťazca s odstráneným úvodným a zadným bielym priestorom.
    ///
    /// 'Whitespace' je definované v súlade s podmienkami vlastnosti Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Vráti výplet reťazca s odstráneným úvodným prázdnym znakom.
    ///
    /// 'Whitespace' je definované v súlade s podmienkami vlastnosti Unicode Derived Core Property `White_Space`.
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// `start` v tejto súvislosti znamená prvú pozíciu tohto bajtového reťazca;pre jazyk zľava doprava ako angličtina alebo ruština to bude ľavá strana a pre jazyky zľava doprava ako arabčina alebo hebrejčina bude táto strana pravá.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Vráti rez reťazca s odstráneným koncovým prázdnym znakom.
    ///
    /// 'Whitespace' je definované v súlade s podmienkami vlastnosti Unicode Derived Core Property `White_Space`.
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// `end` v tejto súvislosti znamená poslednú pozíciu tohto bajtového reťazca;pre jazyk zľava doprava ako angličtina alebo ruština to bude pravá strana a pre jazyky zľava doprava ako arabčina alebo hebrejčina ľavá strana.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Vráti výplet reťazca s odstráneným úvodným prázdnym znakom.
    ///
    /// 'Whitespace' je definované v súlade s podmienkami vlastnosti Unicode Derived Core Property `White_Space`.
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// 'Left' v tejto súvislosti znamená prvú pozíciu tohto bajtového reťazca;pre jazyk ako arabčina alebo hebrejčina, ktoré sú " sprava doľava`namiesto " zľava doprava`, to bude strana _right_, nie ľavica.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Vráti rez reťazca s odstráneným koncovým prázdnym znakom.
    ///
    /// 'Whitespace' je definované v súlade s podmienkami vlastnosti Unicode Derived Core Property `White_Space`.
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// 'Right' v tejto súvislosti znamená poslednú pozíciu tohto bajtového reťazca;pre jazyk ako arabčina alebo hebrejčina, ktoré sú skôr " sprava doľava`ako " zľava doprava`, to bude strana _left_, nie pravá strana.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Vráti reťazec so všetkými predponami a príponami, ktoré zodpovedajú opakovane odstránenému vzoru.
    ///
    /// [pattern] môže byť [`char`], výsek [`char`] s, alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Zložitejší vzor pomocou uzáveru:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Pamätajte si najskôr známu zhodu, ak je to, opravte ju nižšie
            // posledný zápas je iný
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // BEZPEČNOSŤ: Je známe, že `Searcher` vracia platné indexy.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Vráti rez reťazca so všetkými predponami, ktoré sa zhodujú s opakovane odstráneným vzorom.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// `start` v tejto súvislosti znamená prvú pozíciu tohto bajtového reťazca;pre jazyk zľava doprava ako angličtina alebo ruština to bude ľavá strana a pre jazyky zľava doprava ako arabčina alebo hebrejčina bude táto strana pravá.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // BEZPEČNOSŤ: Je známe, že `Searcher` vracia platné indexy.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Vráti reťazec s odstránenou predponou.
    ///
    /// Ak reťazec začína vzorom `prefix`, vráti podreťazec za predponou zabalený do `Some`.
    /// Na rozdiel od `trim_start_matches` táto metóda odstráni predponu presne raz.
    ///
    /// Ak reťazec nezačína na `prefix`, vráti `None`.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Vráti rez reťazca s odstránenou príponou.
    ///
    /// Ak reťazec končí vzorom `suffix`, vráti podreťazec pred príponou zabalený do `Some`.
    /// Na rozdiel od `trim_end_matches` táto metóda odstráni príponu presne raz.
    ///
    /// Ak reťazec nekončí `suffix`, vráti `None`.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Vráti rez reťazca so všetkými príponami, ktoré zodpovedajú opakovane odstránenému vzoru.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// `end` v tejto súvislosti znamená poslednú pozíciu tohto bajtového reťazca;pre jazyk zľava doprava ako angličtina alebo ruština to bude pravá strana a pre jazyky zľava doprava ako arabčina alebo hebrejčina ľavá strana.
    ///
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Zložitejší vzor pomocou uzáveru:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // BEZPEČNOSŤ: Je známe, že `Searcher` vracia platné indexy.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Vráti rez reťazca so všetkými predponami, ktoré sa zhodujú s opakovane odstráneným vzorom.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// 'Left' v tejto súvislosti znamená prvú pozíciu tohto bajtového reťazca;pre jazyk ako arabčina alebo hebrejčina, ktoré sú " sprava doľava`namiesto " zľava doprava`, to bude strana _right_, nie ľavica.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Vráti rez reťazca so všetkými príponami, ktoré zodpovedajú opakovane odstránenému vzoru.
    ///
    /// [pattern] môže byť `&str`, [`char`], výsek [`char`] s alebo funkcia alebo uzáver, ktorý určuje, či sa znak zhoduje.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Smerovosť textu
    ///
    /// Reťazec je postupnosť bajtov.
    /// 'Right' v tejto súvislosti znamená poslednú pozíciu tohto bajtového reťazca;pre jazyk ako arabčina alebo hebrejčina, ktoré sú skôr " sprava doľava`ako " zľava doprava`, to bude strana _left_, nie pravá strana.
    ///
    ///
    /// # Examples
    ///
    /// Jednoduché vzory:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Zložitejší vzor pomocou uzáveru:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Analyzuje tento rez reťazca na iný typ.
    ///
    /// Pretože `parse` je taký všeobecný, môže spôsobiť problémy s odvodením typu.
    /// Preto je `parse` jedným z mála prípadov, kedy uvidíte syntax láskyplne známu ako 'turbofish': `::<>`.
    ///
    /// To pomáha odvodzovaciemu algoritmu konkrétne pochopiť, na ktorý typ sa pokúšate analyzovať.
    ///
    /// `parse` môže analyzovať na akýkoľvek typ, ktorý implementuje [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Vráti [`Err`], ak nie je možné analyzovať tento rez reťazca na požadovaný typ.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Základné použitie
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Použitie 'turbofish' namiesto anotácie `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Analýza zlyhala:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Skontroluje, či sú všetky znaky v tomto reťazci v rozsahu ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Tu môžeme považovať každý bajt za znak: všetky viacbajtové znaky začínajú na bajt, ktorý nie je v rozsahu ascii, takže sa tam už zastavíme.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Skontroluje, či dva reťazce nie sú v zhode s veľkosťou písmen ASCII.
    ///
    /// Rovnaké ako `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, ale bez prideľovania a kopírovania dočasných položiek.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Skonvertuje tento reťazec na miestny ekvivalent veľkých písmen ASCII.
    ///
    /// Písmená ASCII 'a' až 'z' sú namapované na 'A' až 'Z', ale písmená iné ako ASCII sa nezmenia.
    ///
    /// Ak chcete vrátiť novú hodnotu s veľkými písmenami bez úpravy existujúcej, použite [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // BEZPEČNOSŤ: bezpečné, pretože premieňame dva typy s rovnakým usporiadaním.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Skonvertuje tento reťazec na miestny ekvivalent malých a malých písmen ASCII.
    ///
    /// Písmená ASCII 'A' až 'Z' sú namapované na 'a' až 'z', ale písmená iné ako ASCII sa nezmenia.
    ///
    /// Ak chcete vrátiť novú hodnotu s malými písmenami bez úpravy existujúcej, použite [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // BEZPEČNOSŤ: bezpečné, pretože premieňame dva typy s rovnakým usporiadaním.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Vráťte iterátor, ktorý unikne každému znaku v `self` s [`char::escape_debug`].
    ///
    ///
    /// Note: uniknú iba rozšírené kódové body grafémy, ktoré začínajú reťazcom.
    ///
    /// # Examples
    ///
    /// Ako iterátor:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Priame použitie `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Obidve sú rovnocenné s:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Pomocou `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Vráťte iterátor, ktorý unikne každému znaku v `self` s [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Ako iterátor:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Priame použitie `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Obidve sú rovnocenné s:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Pomocou `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Vráťte iterátor, ktorý unikne každému znaku v `self` s [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Ako iterátor:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Priame použitie `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Obidve sú rovnocenné s:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Pomocou `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Vytvorí prázdny str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Vytvorí prázdny premenlivý reťazec
    #[inline]
    fn default() -> Self {
        // BEZPEČNOSŤ: Prázdny reťazec je platný UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Vymenovateľný, klonovateľný typ fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // BEZPEČNOSŤ: nie je bezpečné
        unsafe { from_utf8_unchecked(bytes) }
    };
}