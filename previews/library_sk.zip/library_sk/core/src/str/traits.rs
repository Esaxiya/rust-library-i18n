//! Implementácie Trait pre `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementuje usporiadanie reťazcov.
///
/// Reťazce sú zoradené [lexicographically](Ord#lexicographical-comparison) podľa ich bajtových hodnôt.
/// Týmto sa zoradia body kódu Unicode na základe ich pozícií v kódových grafoch.
/// Toto nemusí byť nevyhnutne to isté ako poradie "alphabetical", ktoré sa líši podľa jazyka a miestneho nastavenia.
/// Zoradenie reťazcov podľa kultúrne akceptovaných štandardov si vyžaduje údaje špecifické pre miestne nastavenie, ktoré sú mimo rozsahu typu `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementuje operácie porovnania na reťazcoch.
///
/// Reťazce sa porovnávajú [lexicographically](Ord#lexicographical-comparison) podľa ich bajtových hodnôt.
/// Toto porovnáva body kódu Unicode na základe ich pozícií v kódových grafoch.
/// Toto nemusí byť nevyhnutne to isté ako poradie "alphabetical", ktoré sa líši podľa jazyka a miestneho nastavenia.
/// Porovnanie reťazcov podľa kultúrne akceptovaných štandardov vyžaduje miestne údaje, ktoré sú mimo rozsah typu `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementuje krájanie podreťazcov so syntaxou `&self[..]` alebo `&mut self[..]`.
///
/// Vráti výrez celého reťazca, tj vráti `&self` alebo `&mut self`.Ekvivalent k&&sebe [0 ..
/// len] `alebo`&mut self [0 ..
/// len]`.
/// Na rozdiel od iných indexovacích operácií to nikdy nemôže byť panic.
///
/// Táto operácia je *O*(1).
///
/// Pred 1.20.0 boli tieto indexovacie operácie stále podporované priamou implementáciou `Index` a `IndexMut`.
///
/// Ekvivalent k `&self[0 .. len]` alebo `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementuje krájanie podreťazcov so syntaxou `&self[begin .. end]` alebo `&mut self[begin .. end]`.
///
/// Vráti výrez daného reťazca z rozsahu bajtov [" začiatok`, `end`).
///
/// Táto operácia je *O*(1).
///
/// Pred 1.20.0 boli tieto indexovacie operácie stále podporované priamou implementáciou `Index` a `IndexMut`.
///
/// # Panics
///
/// Panics, ak `begin` alebo `end` neukazuje na začiatočný posun bajtu znaku (ako je definované v `is_char_boundary`), ak `begin > end` alebo `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // tieto budú panic:
/// // bajt 2 leží v rámci `ö`:
/// // &s [2 ..3];
///
/// // bajt 8 leží v rámci `老`&s [1 ..
/// // 8];
///
/// // bajt 100 je mimo reťazca&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPEČNOSŤ: stačí skontrolovať, či sú `start` a `end` na hranici znakov,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            // Skontrolovali sme tiež hranice znakov, takže toto je platná hodnota UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPEČNOSŤ: iba ste skontrolovali, či sú `start` a `end` na hranici znakov.
            // Vieme, že ukazovateľ je jedinečný, pretože sme ho získali od `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BEZPEČNOSŤ: volajúci zaručuje, že `self` je v medziach `slice`
        // ktorý spĺňa všetky podmienky pre `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BEZPEČNOSŤ: pozri komentáre k `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontroluje, či je index v [0, .len()] nemôže znovu použiť `get` ako je uvedené vyššie, kvôli problémom s NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // BEZPEČNOSŤ: stačí skontrolovať, či sú `start` a `end` na hranici znakov,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementuje krájanie podreťazcov so syntaxou `&self[.. end]` alebo `&mut self[.. end]`.
///
/// Vráti výrez daného reťazca z rozsahu bajtov [0, `end`].
/// Ekvivalent k `&self[0 .. end]` alebo `&mut self[0 .. end]`.
///
/// Táto operácia je *O*(1).
///
/// Pred 1.20.0 boli tieto indexovacie operácie stále podporované priamou implementáciou `Index` a `IndexMut`.
///
/// # Panics
///
/// Panics, ak `end` neukazuje na začiatočný posun bajtu znaku (ako je definované v `is_char_boundary`), alebo ak `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BEZPEČNOSŤ: stačí skontrolovať, či je `end` na hranici znaku,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // BEZPEČNOSŤ: stačí skontrolovať, či je `end` na hranici znaku,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // BEZPEČNOSŤ: stačí skontrolovať, či je `end` na hranici znaku,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementuje krájanie podreťazcov so syntaxou `&self[begin ..]` alebo `&mut self[begin ..]`.
///
/// Vráti výrez daného reťazca z rozsahu bajtov [" začiatok`, `len`).Ekvivalent k " &sebe [začať ..
/// len] `alebo`&mut self [začať ..
/// len]`.
///
/// Táto operácia je *O*(1).
///
/// Pred 1.20.0 boli tieto indexovacie operácie stále podporované priamou implementáciou `Index` a `IndexMut`.
///
/// # Panics
///
/// Panics, ak `begin` neukazuje na začiatočný posun bajtu znaku (ako je definované v `is_char_boundary`), alebo ak `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BEZPEČNOSŤ: stačí skontrolovať, či je `start` na hranici znaku,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // BEZPEČNOSŤ: stačí skontrolovať, či je `start` na hranici znaku,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // BEZPEČNOSŤ: volajúci zaručuje, že `self` je v medziach `slice`
        // ktorý spĺňa všetky podmienky pre `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // BEZPEČNOSŤ: identická s `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // BEZPEČNOSŤ: stačí skontrolovať, či je `start` na hranici znaku,
            // a odovzdávame bezpečný odkaz, takže návratná hodnota bude tiež jedna.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementuje krájanie podreťazcov so syntaxou `&self[begin ..= end]` alebo `&mut self[begin ..= end]`.
///
/// Vráti výrez daného reťazca z rozsahu bajtov [`begin`, `end`].Ekvivalent k `&self [begin .. end + 1]` alebo `&mut self[begin .. end + 1]`, okrem prípadov, ak má `end` maximálnu hodnotu pre `usize`.
///
/// Táto operácia je *O*(1).
///
/// # Panics
///
/// Panics ak `begin` neukazuje na začiatočný posun bajtu znaku (ako je definované v `is_char_boundary`), ak `end` neukazuje na začiatočný posun bajtu znaku (`end + 1` je buď začiatočný posun bajtu alebo rovný `len`), ak `begin > end`, alebo ak `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementuje krájanie podreťazcov so syntaxou `&self[..= end]` alebo `&mut self[..= end]`.
///
/// Vráti výrez daného reťazca z rozsahu bajtov [0, `end`].
/// Ekvivalent k `&self [0 .. end + 1]`, s výnimkou prípadov, ak má `end` maximálnu hodnotu pre `usize`.
///
/// Táto operácia je *O*(1).
///
/// # Panics
///
/// Panics, ak `end` neukazuje na koncový bajtový posun znaku (`end + 1` je buď počiatočný bajtový posun, ako je definovaný v `is_char_boundary`, alebo sa rovná `len`), alebo ak `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analyzujte hodnotu z reťazca
///
/// `Metóda [`from_str`] od FromStr` sa často používa implicitne, prostredníctvom metódy [`parse`] [`str`].
/// Príklady nájdete v dokumentácii [`parse`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nemá celoživotný parameter, a preto môžete analyzovať iba typy, ktoré samotné neobsahujú celoživotný parameter.
///
/// Inými slovami, môžete analyzovať `i32` s `FromStr`, ale nie `&i32`.
/// Môžete analyzovať štruktúru obsahujúcu `i32`, ale nie štruktúru obsahujúcu `&i32`.
///
/// # Examples
///
/// Základná implementácia `FromStr` na príklade typu `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Priradená chyba, ktorú je možné vrátiť z analýzy.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analyzuje reťazec `s`, aby vrátil hodnotu tohto typu.
    ///
    /// Ak je syntaktická analýza úspešná, vráťte hodnotu do [`Ok`], inak, keď je reťazec zle naformátovaný, vráťte chybu špecifickú pre [`Err`] vo vnútri.
    /// Typ chyby je špecifický pre implementáciu trait.
    ///
    /// # Examples
    ///
    /// Základné použitie s [`i32`], typom, ktorý implementuje `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Analyzujte `bool` z reťazca.
    ///
    /// Vydáva `Result<bool, ParseBoolError>`, pretože `s` môže alebo nemusí byť v skutočnosti porovnateľný.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Všimnite si, že v mnohých prípadoch je metóda `.parse()` na `str` správnejšia.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}