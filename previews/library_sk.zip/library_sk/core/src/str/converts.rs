//! Spôsoby, ako vytvoriť `str` z rezu bajtov.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Skonvertuje plátok bajtov na rezec reťazca.
///
/// Reťazcový rez ([`&str`]) je vyrobený z bajtov ([`u8`]) a bajtový segment ([`&[u8]`][byteslice]) je vyrobený z bajtov, takže táto funkcia prevádza medzi nimi dva.
/// Nie všetky bajtové rezy sú však platné rezy reťazcov: [`&str`] vyžaduje, aby boli platné UTF-8.
/// `from_utf8()` skontroluje, či sú bajty platné UTF-8, a vykoná konverziu.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ak ste si istí, že bajtový segment je platný UTF-8 a nechcete znášať réžiu kontroly platnosti, existuje nebezpečná verzia tejto funkcie, [`from_utf8_unchecked`], ktorá sa chová rovnako, ale kontrolu preskočí.
///
///
/// Ak potrebujete `String` namiesto `&str`, zvážte [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Pretože môžete `[u8; N]` hromadne alokovať a môžete si z neho vziať [`&[u8]`][byteslice], je táto funkcia jedným zo spôsobov, ako mať reťazec alokovaný v zásobníku.V sekcii príkladov nižšie je uvedený príklad.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Vráti `Err`, ak rez nie je UTF-8 s popisom, prečo poskytnutý rez nie je UTF-8.
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::str;
///
/// // nejaké bajty, v vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vieme, že tieto bajty sú platné, takže stačí použiť `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Nesprávne bajty:
///
/// ```
/// use std::str;
///
/// // nejaké neplatné bajty, v vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Ďalšie podrobnosti o druhoch chýb, ktoré je možné vrátiť, nájdete v dokumentoch pre [`Utf8Error`].
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // niekoľko bajtov, do poľa alokovaného do zásobníka
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Vieme, že tieto bajty sú platné, takže stačí použiť `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // BEZPEČNOSŤ: Práve bolo spustené overovanie.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Skonvertuje premenlivý rez bajtov na premenlivý rez reťazca.
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" ako premenlivý vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Ako vieme, že tieto bajty sú platné, môžeme použiť `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Nesprávne bajty:
///
/// ```
/// use std::str;
///
/// // Niektoré neplatné bajty v premenlivom vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Ďalšie podrobnosti o druhoch chýb, ktoré je možné vrátiť, nájdete v dokumentoch pre [`Utf8Error`].
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // BEZPEČNOSŤ: Práve bolo spustené overovanie.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Skonvertuje plátok bajtov na rez reťazca bez kontroly, či reťazec obsahuje platnú UTF-8.
///
/// Ďalšie informácie nájdete v bezpečnej verzii [`from_utf8`].
///
/// # Safety
///
/// Táto funkcia je nebezpečná, pretože nekontroluje, či sú jej odovzdané bajty platné UTF-8.
/// Ak dôjde k porušeniu tohto obmedzenia, dôjde k nedefinovanému správaniu, pretože zvyšok Rust predpokladá, že [" &str`] sú platné UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::str;
///
/// // nejaké bajty, v vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // BEZPEČNOSŤ: volajúci musí zaručiť, že bajty `v` sú platné UTF-8.
    // Tiež sa spolieha na to, že `&str` a `&[u8]` majú rovnaké rozloženie.
    unsafe { mem::transmute(v) }
}

/// Skonvertuje plátok bajtov na rez reťazca bez kontroly, či reťazec obsahuje platnú UTF-8;premenlivá verzia.
///
///
/// Ďalšie informácie nájdete v nemennej verzii [`from_utf8_unchecked()`].
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // BEZPEČNOSŤ: volajúci musí zaručiť, že bajty `v`
    // sú platné UTF-8, takže prenos do `*mut str` je bezpečný.
    // Dereferencia ukazovateľa je tiež bezpečná, pretože tento ukazovateľ pochádza z referencie, ktorá je zaručene platná pre zápisy.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}