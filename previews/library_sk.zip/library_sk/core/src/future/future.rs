#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future predstavuje asynchrónny výpočet.
///
/// future je hodnota, ktorá ešte nemusí dokončiť výpočty.
/// Tento druh "asynchronous value" umožňuje vláknu pokračovať v užitočnej práci, kým čaká na sprístupnenie hodnoty.
///
///
/// # Metóda `poll`
///
/// Základná metóda future, `poll`,*sa pokúša* vyriešiť future na konečnú hodnotu.
/// Táto metóda sa neblokuje, ak hodnota nie je pripravená.
/// Namiesto toho je naplánované prebudenie aktuálnej úlohy, keď je možné dosiahnuť ďalší pokrok opätovným dotazovaním.
/// `context` odovzdaný metóde `poll` môže poskytnúť [`Waker`], čo je rukoväť na prebudenie aktuálnej úlohy.
///
/// Pri použití future vo všeobecnosti nebudete volať `poll` priamo, ale namiesto toho `.await` hodnotu.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Typ hodnoty vyprodukovanej po dokončení.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Pokus o vyriešenie future na konečnú hodnotu, registrácia aktuálnej úlohy na prebudenie, ak hodnota ešte nie je k dispozícii.
    ///
    /// # Návratová hodnota
    ///
    /// Táto funkcia vracia:
    ///
    /// - [`Poll::Pending`] ak future ešte nie je pripravená
    /// - [`Poll::Ready(val)`] s výsledkom `val` tejto future, ak bola úspešne dokončená.
    ///
    /// Akonáhle je future hotový, klienti by ho už nemali `poll`.
    ///
    /// Ak future ešte nie je pripravený, `poll` vráti `Poll::Pending` a uloží klon [`Waker`] skopírovaný z aktuálneho [`Context`].
    /// Táto [`Waker`] sa potom prebudí, keď future môže dosiahnuť pokrok.
    /// Napríklad future čakajúci na to, aby sa soket stal čitateľným, by zavolal `.clone()` na [`Waker`] a uložil ho.
    /// Keď signál dorazí na iné miesto naznačujúce, že soket je čitateľný, zavolá sa [`Waker::wake`] a úloha soketu future sa prebudí.
    /// Po prebudení úlohy by sa mala znova pokúsiť `poll` future, čo môže, ale nemusí, priniesť konečnú hodnotu.
    ///
    /// Upozorňujeme, že pri viacerých hovoroch na `poll` by malo byť prebudenie naplánované iba na [`Waker`] z [`Context`] odovzdaného na posledný hovor.
    ///
    /// # Runtime charakteristiky
    ///
    /// Samotné Futures sú *inertné*;musia byť *aktívne*`anketovaní ', aby dosiahli pokrok, čo znamená, že zakaždým, keď sa aktuálna úloha prebudí, mala by sa aktívne znova" zúčastniť`čakania na futures, o ktoré má stále záujem.
    ///
    /// Funkcia `poll` sa v úzkej slučke nevyvoláva opakovane-mala by sa volať iba vtedy, keď future naznačuje, že je pripravená na pokrok (volaním `wake()`).
    /// Ak poznáte systémové volania `poll(2)` alebo `select(2)` na Unix, stojí za zmienku, že futures zvyčajne netrpia rovnakými problémami ako "all wakeups must poll all events";sú skôr ako `epoll(4)`.
    ///
    /// Implementácia `poll` by sa mala usilovať o rýchly návrat a nemala by blokovať.Rýchly návrat zabráni zbytočnému upchávaniu vlákien alebo slučiek udalostí.
    /// Ak je vopred známe, že volanie do `poll` môže chvíľu trvať, práca by sa mala presunúť do fondu vlákien (alebo niečoho podobného), aby sa zaistilo rýchle vrátenie `poll`.
    ///
    /// # Panics
    ///
    /// Akonáhle je future dokončená (vrátená `Ready` z `poll`), opätovné volanie jej metódy `poll` môže panic zablokovať navždy alebo spôsobiť iné druhy problémov;`Future` trait nekladie žiadne požiadavky na dopady takéhoto hovoru.
    /// Pretože však metóda `poll` nie je označená ako `unsafe`, platia obvyklé pravidlá Rust: volania nikdy nesmú spôsobiť nedefinované správanie (poškodenie pamäte, nesprávne použitie funkcií `unsafe` apod.), Bez ohľadu na stav future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}