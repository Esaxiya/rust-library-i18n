//! Implementácia SipHash.

#![allow(deprecated)] // typy v tomto module sú zastarané

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// Implementácia programu SipHash 1-3.
///
/// Toto je v súčasnosti predvolená funkcia hash používaná štandardnou knižnicou (napr. Štandardne ju používa `collections::HashMap`).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// Implementácia programu SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// Implementácia programu SipHash 2-4.
///
/// See: <https://131002.net/siphash/>
///
/// SipHash je funkcia hash na všeobecné účely: beží pri dobrej rýchlosti (porovnateľná so Spooky a City) a umožňuje silné hashovanie _keyed_.
///
/// Toto vám umožní zadať hašovacie tabuľky zo silného RNG, napríklad [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html).
///
/// Aj keď sa algoritmus SipHash považuje za všeobecne silný, nie je určený na kryptografické účely.
/// Všetky kryptografické použitia tejto implementácie sú preto _strongly discouraged_.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // koľko bajtov sme spracovali
    state: State,  // hash State
    tail: u64,     // nespracované bajty le
    ntail: usize,  // koľko bajtov na konci je platných
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 a v1, v3 sa v algoritme zobrazujú v pároch a simd implementácie SipHash budú používať vectors z v02 a v13.
    //
    // Ich umiestnením v tomto poradí do štruktúry môže kompilátor sám získať iba niekoľko simd optimalizácií.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// Načíta celé číslo požadovaného typu z bajtového streamu v poradí LE.
/// Používa `copy_nonoverlapping`, aby nechal kompilátor vygenerovať najefektívnejší spôsob načítania z prípadne nezaradenej adresy.
///
///
/// Nebezpečné, pretože: nezaškrtnuté indexovanie pri i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// Načíta u64 s použitím až 7 bajtov rezu bajtov.
/// Vyzerá to neohrabane, ale hovory `copy_nonoverlapping`, ktoré sa vyskytujú (cez `load_int_le!`), majú všetky pevné veľkosti a vyhýbajú sa volaniu `memcpy`, čo je dobré pre rýchlosť.
///
///
/// Nebezpečné, pretože: nezačiarknuté indexovanie pri štarte..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // aktuálny bajtový index (z LSB) na výstupe u64
    let mut out = 0;
    if i + 3 < len {
        // BEZPEČNOSŤ: `i` nemôže byť väčší ako `len` a volajúci musí zaručiť
        // že index začína..štart + len je v medziach.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // BEZPEČNOSŤ: rovnaké ako vyššie.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // BEZPEČNOSŤ: rovnaké ako vyššie.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// Vytvorí nový `SipHasher` s dvoma počiatočnými klávesmi nastavenými na 0.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// Vytvorí `SipHasher`, ktorý je odladený od poskytnutých klávesov.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// Vytvorí nový `SipHasher13` s dvoma počiatočnými klávesmi nastavenými na 0.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// Vytvorí `SipHasher13`, ktorý je odladený od poskytnutých klávesov.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: nie sú definované žiadne metódy zatrieďovania celých čísel (`write_u *`, `write_i*`)
    // pre tento typ.
    // Mohli by sme ich pridať, skopírovať implementáciu `short_write` do librustc_data_structures/sip128.rs a pridať metódy `write_u *`/`write_i*` do `SipHasher`, `SipHasher13` a `DefaultHasher`.
    //
    // To by výrazne urýchlilo celé hashovanie týmito hashmi za cenu mierneho spomalenia rýchlostí kompilácie pri niektorých referenčných hodnotách.
    // Podrobnosti nájdete v časti #69152.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // BEZPEČNOSŤ: `cmp::min(length, needed)` zaručene neprekročí `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // Pufrovaný chvost je teraz vypláchnutý, spracujte nový vstup.
        let len = length - needed;
        let left = len & 0x7; // len% 8

        let mut i = needed;
        while i < len - left {
            // BEZPEČNOSŤ: pretože `len - left` je najväčší násobok 8 pod
            // `len`, a pretože `i` začína na `needed`, kde `len` je `length - needed`, je zaručené, že `i + 8` bude menší alebo rovný `length`.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // BEZPEČNOSŤ: `i` je teraz `needed + len.div_euclid(8) * 8`,
        // takže `i + left` = `needed + len` = `length`, čo je podľa definície rovnaké ako `msg.len()`.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// Vytvorí `Hasher<S>` s dvoma počiatočnými klávesmi nastavenými na 0.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}