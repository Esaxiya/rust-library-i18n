//! Primitívne traits a typy predstavujúce základné vlastnosti typov.
//!
//! Typy Rust možno klasifikovať rôznymi užitočnými spôsobmi podľa ich vnútorných vlastností.
//! Tieto klasifikácie sú reprezentované ako traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typy, ktoré je možné prenášať cez hranice vlákien.
///
/// Táto trait sa implementuje automaticky, keď kompilátor určí, že je to vhodné.
///
/// Príkladom typu, ktorý nie je odoslaný, je ukazovateľ počítania odkazov [`rc::Rc`][`Rc`].
/// Ak sa dve vlákna pokúsia naklonovať [`Rc`] s, ktoré poukazujú na rovnakú hodnotu spočítanú referenciou, môžu sa pokúsiť aktualizovať súčasne počet referencií, čo je [undefined behavior][ub], pretože [`Rc`] nepoužíva atómové operácie.
///
/// Jeho bratranec [`sync::Arc`][arc] skutočne používa atómové operácie (s tým, že má nejaké réžie), a teda je to `Send`.
///
/// Ďalšie informácie nájdete v časti [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typy s konštantnou veľkosťou známe v čase kompilácie.
///
/// Všetky parametre typu majú implicitnú hranicu `Sized`.Ak to nie je vhodné, môžete na odstránenie tejto väzby použiť špeciálnu syntax `?Sized`.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//chyba: Veľkosť nie je implementovaná pre [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Jedinou výnimkou je implicitný typ `Self` trait.
/// trait nemá implicitnú hranicu `Sized`, pretože je nekompatibilná s objektmi [trait], kde trait podľa definície musí pracovať so všetkými možnými implementátormi, a teda môže mať ľubovoľnú veľkosť.
///
///
/// Aj keď vám Rust umožní viazať `Sized` na trait, neskôr ho nebudete môcť použiť na vytvorenie objektu trait:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // nech y: &dyn Bar= &Impl;//chyba: z objektu trait `Bar` nie je možné urobiť objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // napríklad Default, ktorý vyžaduje, aby bola `[T]: !Default` vyhodnotiteľná
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typy, ktoré môžu byť od "unsized" po dynamicky veľký typ.
///
/// Napríklad veľké pole typu `[i8; 2]` implementuje `Unsize<[i8]>` a `Unsize<dyn fmt::Debug>`.
///
/// Všetky implementácie `Unsize` poskytuje kompilátor automaticky.
///
/// `Unsize` je implementovaný pre:
///
/// - `[T; N]` je `Unsize<[T]>`
/// - `T` je `Unsize<dyn Trait>`, keď `T: Trait`
/// - `Foo<..., T, ...>` je `Unsize<Foo<..., U, ...>>`, ak:
///   - `T: Unsize<U>`
///   - Foo je štruktúra
///   - Iba posledné pole `Foo` má typ zahŕňajúci `T`
///   - `T` nie je súčasťou typu iných polí
///   - `Bar<T>: Unsize<Bar<U>>`, ak posledné pole `Foo` má typ `Bar<T>`
///
/// `Unsize` sa používa spolu s [`ops::CoerceUnsized`] na umožnenie, aby kontajnery "user-defined", ako napríklad [`Rc`], obsahovali dynamicky veľké typy.
/// Ďalšie informácie nájdete na modeloch [DST coercion RFC][RFC982] a [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Vyžadovaná hodnota trait pre konštanty použité v zhodách vzorov.
///
/// Akýkoľvek typ odvodený od `PartialEq` automaticky implementuje tento trait,*bez ohľadu na* to, či jeho parametre typu implementujú `Eq`.
///
/// Ak položka `const` obsahuje nejaký typ, ktorý neimplementuje tento trait, potom tento typ buď (1.) neimplementuje `PartialEq` (čo znamená, že konštanta neposkytne túto porovnávaciu metódu, ktorá predpokladá generovanie kódu, alebo je k dispozícii), alebo (2.) implementuje *svoj vlastný* verzia `PartialEq` (ktorá, ako predpokladáme, nezodpovedá porovnaniu štruktúrnej rovnosti).
///
///
/// V jednom z dvoch vyššie uvedených scenárov odmietame použitie takejto konštanty v zhode vzorov.
///
/// Pozri tiež modely [structural match RFC][RFC1445] a [issue 63438], ktoré motivovali k prechodu od atribútového dizajnu k tomuto modelu trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Vyžadovaná hodnota trait pre konštanty použité v zhodách vzorov.
///
/// Akýkoľvek typ odvodený od `Eq` automaticky implementuje tento trait,*bez ohľadu na* to, či jeho parametre typu implementujú `Eq`.
///
/// Toto je hack, ktorý obíde obmedzenia v našom typovom systéme.
///
/// # Background
///
/// Chceme požadovať, aby typy konštánt použité pri zhodách vzorov mali atribút `#[derive(PartialEq, Eq)]`.
///
/// V ideálnejšom svete by sme túto požiadavku mohli skontrolovať jednoduchou kontrolou, či daný typ implementuje `StructuralPartialEq` trait *aj*`Eq` trait.
/// Môžete však mať ADT, ktoré *do*`derive(PartialEq, Eq)`, a môže to byť prípad, ktorý chceme, aby kompilátor prijal, a napriek tomu typ konštanty nedokáže implementovať `Eq`.
///
/// Menovite prípad ako tento:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problém vo vyššie uvedenom kóde je, že `Wrap<fn(&())>` neimplementuje `PartialEq` ani `Eq`, pretože `pre <'a> fn(&'a _)` does not implement those traits.)
///
/// Preto sa nemôžeme spoliehať na naivnú kontrolu `StructuralPartialEq` a `Eq`.
///
/// Ako hack na vyriešenie tohto problému používame dva samostatné traits vložené každým z týchto dvoch odvodení (`#[derive(PartialEq)]` a `#[derive(Eq)]`) a skontrolujeme, či sú oba prítomné ako súčasť kontroly štrukturálnej zhody.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typy, ktorých hodnoty možno duplikovať jednoduchým kopírovaním bitov.
///
/// V predvolenom nastavení majú väzby premenných " sémantiku presunu`.Inými slovami:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` sa presunul do `y`, a preto ho nemožno použiť
///
/// // println! ("{: ?}", x);//chyba: použitie presunutej hodnoty
/// ```
///
/// Ak však typ implementuje `Copy`, má namiesto toho " sémantiku kopírovania`:
///
/// ```
/// // Môžeme odvodiť implementáciu `Copy`.
/// // `Clone` je tiež požadovaná, pretože ide o nadpriemer `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` je kópia `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Je dôležité poznamenať, že v týchto dvoch príkladoch sa líši iba to, či máte po priradení oprávnený prístup k `x`.
/// Kópia aj pohyb pod kapotou môžu mať za následok kopírovanie bitov do pamäte, aj keď je to niekedy optimalizované.
///
/// ## Ako môžem implementovať `Copy`?
///
/// Existujú dva spôsoby, ako implementovať `Copy` na váš typ.Najjednoduchšie je použiť `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` a `Clone` môžete implementovať aj manuálne:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Medzi nimi je malý rozdiel: stratégia `derive` tiež umiestni `Copy` viazané na parametre typu, čo nie je vždy požadované.
///
/// ## Aký je rozdiel medzi `Copy` a `Clone`?
///
/// Kópie sa vyskytujú implicitne, napríklad ako súčasť úlohy `y = x`.Chovanie `Copy` nie je preťažiteľné;vždy je to jednoduchá bitová kópia.
///
/// Klonovanie je explicitná akcia, `x.clone()`.Implementácia [`Clone`] môže poskytnúť akékoľvek typovo špecifické správanie potrebné na bezpečnú duplikáciu hodnôt.
/// Napríklad implementácia [`Clone`] pre [`String`] musí skopírovať vyrovnávaciu pamäť poukázaného do reťazca v halde.
/// Jednoduchá bitová kópia hodnôt [`String`] by iba skopírovala ukazovateľ, čo by viedlo k dvojitému voľnému riadku.
/// Z tohto dôvodu je [`String`] [`Clone`], ale nie `Copy`.
///
/// [`Clone`] je supertrénou `Copy`, takže všetko, čo je `Copy`, musí implementovať aj [`Clone`].
/// Ak je typ `Copy`, potom jeho implementácia [`Clone`] musí vrátiť iba `*self` (pozri príklad vyššie).
///
/// ## Kedy môže byť môj typ `Copy`?
///
/// Typ môže implementovať `Copy`, ak všetky jeho komponenty implementujú `Copy`.Napríklad táto štruktúra môže byť `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Štruktúra môže byť `Copy` a [`i32`] je `Copy`, preto `Point` môže byť `Copy`.
/// Naopak, zvážte
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Štruktúra `PointList` nemôže implementovať `Copy`, pretože [`Vec<T>`] nie je `Copy`.Ak sa pokúsime odvodiť implementáciu `Copy`, zobrazí sa chyba:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Zdieľané referencie (`&T`) sú tiež `Copy`, takže typom môže byť `Copy`, aj keď obsahuje zdieľané referencie typov `T`, ktoré *nie sú*`Copy`.
/// Zvážte nasledujúcu štruktúru, ktorá dokáže implementovať `Copy`, pretože obsahuje iba *zdieľaný odkaz* na náš typ `PointList` iného typu ako " Copy`:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kedy *nemôže byť* môj typ `Copy`?
///
/// Niektoré typy nemožno bezpečne kopírovať.Napríklad kopírovanie `&mut T` by vytvorilo aliasovaný premenlivý odkaz.
/// Kopírovanie [`String`] by duplikovalo zodpovednosť za správu vyrovnávacej pamäte [" String`]`, čo by viedlo k dvojitému voľnému použitiu.
///
/// Zovšeobecňujúc druhý prípad, akýkoľvek typ implementujúci [`Drop`] nemôže byť `Copy`, pretože spravuje okrem svojich vlastných bajtov [`size_of::<T>`] aj nejaký zdroj.
///
/// Ak sa pokúsite implementovať `Copy` do štruktúry alebo výčtu obsahujúceho dáta, ktoré nie sú " Kopírovať`, zobrazí sa chyba [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kedy *by mal byť* môj typ `Copy`?
///
/// Všeobecne povedané, ak váš typ _can_ implementuje `Copy`, mal by.
/// Nezabúdajte však, že implementácia `Copy` je súčasťou verejného rozhrania API vášho typu.
/// Ak by sa v future typ mohol stať " non-copy`, bolo by rozumné teraz implementáciu `Copy` vynechať, aby sa zabránilo zlomovej zmene API.
///
/// ## Dodatoční implementátori
///
/// Okrem [implementors listed below][impls] implementujú `Copy` aj nasledujúce typy:
///
/// * Typy funkčných položiek (tj odlišné typy definované pre každú funkciu)
/// * Typy ukazovateľov funkcií (napr. `fn() -> i32`)
/// * Typy polí pre všetky veľkosti, ak typ položky implementuje aj `Copy` (napr. `[i32; 123456]`)
/// * Typy n-tíc, ak každý komponent implementuje aj `Copy` (napr. `()`, `(i32, bool)`)
/// * Typy uzáverov, ak nezachytávajú žiadnu hodnotu z prostredia alebo ak všetky takéto zachytené hodnoty implementujú `Copy` samy.
///   Upozorňujeme, že premenné zachytené zdieľanou referenciou vždy implementujú `Copy` (aj keď referent nie), zatiaľ čo premenné zachytené premenlivou referenciou nikdy neimplementujú `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) To umožňuje kopírovanie typu, ktorý neimplementuje `Copy` z dôvodu neuspokojených hraníc životnosti (kopírovanie `A<'_>`, ak sú iba `A<'static>: Copy` a `A<'_>: Clone`).
// Tento atribút tu máme zatiaľ len preto, že v štandardnej knižnici existuje pomerne veľa existujúcich špecializácií na `Copy` a momentálne neexistuje spôsob, ako toto správanie bezpečne dosiahnuť.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Odvodiť makro generujúce impl. trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typy, pre ktoré je bezpečné zdieľať odkazy medzi vláknami.
///
/// Táto trait sa implementuje automaticky, keď kompilátor určí, že je to vhodné.
///
/// Presná definícia je: typ `T` je [`Sync`] práve vtedy, ak `&T` je [`Send`].
/// Inými slovami, ak pri odovzdávaní referencií `&T` medzi vláknami neexistuje možnosť [undefined behavior][ub] (vrátane rás údajov).
///
/// Ako by sa dalo čakať, primitívne typy ako [`u8`] a [`f64`] sú všetky [`Sync`], a teda aj jednoduché agregované typy, ktoré ich obsahujú, ako napríklad n-tice, štruktúry a výčty.
/// Medzi ďalšie príklady základných typov [`Sync`] patria typy "immutable", ako napríklad `&T`, a typy s jednoduchou dedičnou premenlivosťou, ako napríklad [`Box<T>`][box], [`Vec<T>`][vec] a väčšina ďalších typov zbierok.
///
/// (Všeobecné parametre musia byť [`Sync`], aby ich kontajner bol [" Synchronizácia`].)
///
/// Trochu prekvapujúcim dôsledkom tejto definície je, že `&mut T` je `Sync` (ak `T` je `Sync`), aj keď sa zdá, že by to mohlo poskytnúť nesynchronizovanú mutáciu.
/// Trik spočíva v tom, že premenlivá referencia za zdieľanou referenciou (tj. `& &mut T`) sa stane iba na čítanie, akoby išlo o `& &T`.
/// Neexistuje teda žiadne riziko prenosu údajov.
///
/// Typy, ktoré nie sú `Sync`, sú tie, ktoré majú "interior mutability" vo forme, ktorá nie je bezpečná pre vlákna, ako napríklad [`Cell`][cell] a [`RefCell`][refcell].
/// Tieto typy umožňujú mutáciu ich obsahu aj prostredníctvom nemenného spoločného odkazu.
/// Napríklad metóda `set` na [`Cell<T>`][cell] trvá `&self`, takže vyžaduje iba zdieľanú referenciu [`&Cell<T>`][cell].
/// Metóda nevykonáva žiadnu synchronizáciu, takže [`Cell`][cell] nemôže byť `Sync`.
///
/// Ďalším príkladom typu, ktorý nie je typu " Sync`, je ukazovateľ počítania odkazov [`Rc`][rc].
/// Vzhľadom na akýkoľvek odkaz [`&Rc<T>`][rc] môžete klonovať nový [`Rc<T>`][rc] a upraviť počty odkazov iným spôsobom, ako atómovým.
///
/// Pre prípady, keď potrebujete premenlivú premenlivosť interiéru, ktorá je bezpečná pre vlákna, poskytuje Rust [atomic data types], ako aj explicitné uzamknutie prostredníctvom [`sync::Mutex`][mutex] a [`sync::RwLock`][rwlock].
/// Tieto typy zaisťujú, že žiadna mutácia nemôže spôsobiť dátové preteky, preto sú typy `Sync`.
/// Rovnako model [`sync::Arc`][arc] poskytuje analógový procesor [`Rc`][rc] bezpečný pre vlákna.
///
/// Všetky typy s vnútornou premenlivosťou musia tiež používať obtekanie [`cell::UnsafeCell`][unsafecell] okolo value(s), ktoré je možné mutovať prostredníctvom zdieľaného odkazu.
/// Pokiaľ to neurobíte, je to [undefined behavior][ub].
/// Napríklad [" transmute`][transmute]-ing z `&T` na `&mut T` je neplatný.
///
/// Viac podrobností o `Sync` nájdete na [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): akonáhle podpora pre pridávanie poznámok v `rustc_on_unimplemented` vyjde v beta verzii a bola rozšírená o kontrolu, či je uzávierka kdekoľvek v reťazci požiadaviek, rozšírite ju ako takú (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Typ nulovej veľkosti sa používa na označenie vecí, ktoré "act like" vlastnia ako `T`.
///
/// Pridanie poľa `PhantomData<T>` do vášho typu informuje kompilátor, že váš typ sa chová, akoby ukladal hodnotu typu `T`, aj keď to v skutočnosti nie je.
/// Tieto informácie sa používajú pri výpočte určitých bezpečnostných vlastností.
///
/// Podrobnejšie vysvetlenie toho, ako používať `PhantomData<T>`, nájdete v [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Strašlivá poznámka 👻👻👻
///
/// Aj keď majú obaja strašidelné mená, `PhantomData` a " fantómové typy` sú príbuzné, ale nie identické.Parameter typu fantóm je jednoducho typový parameter, ktorý sa nikdy nepoužíva.
/// V Rust to často spôsobuje sťažnosť kompilátora a riešením je pridať použitie "dummy" prostredníctvom `PhantomData`.
///
/// # Examples
///
/// ## Nepoužívané parametre životnosti
///
/// Možno najbežnejším prípadom použitia pre `PhantomData` je štruktúra, ktorá má nepoužitý parameter životnosti, zvyčajne ako súčasť nejakého nebezpečného kódu.
/// Napríklad tu je štruktúra `Slice`, ktorá má dva ukazovatele typu `*const T`, pravdepodobne smerujúce niekde do poľa:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Zámerom je, aby boli podkladové údaje platné iba po dobu životnosti `'a`, takže `Slice` by nemali prežiť `'a`.
/// Tento zámer však nie je vyjadrený v kóde, pretože neexistuje doživotné použitie počas celej životnosti `'a`, a preto nie je jasné, na ktoré údaje sa vzťahuje.
/// Môžeme to napraviť tak, že kompilátoru povieme, aby konal *, akoby* štruktúra `Slice` obsahovala odkaz na `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// To tiež vyžaduje anotáciu `T: 'a`, ktorá naznačuje, že všetky odkazy v `T` sú platné počas celej životnosti `'a`.
///
/// Pri inicializácii `Slice` jednoducho zadáte hodnotu `PhantomData` pre pole `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Nepoužité parametre typu
///
/// Stáva sa niekedy, že máte nepoužité parametre typu, ktoré označujú, aký typ údajov má štruktúra "tied", aj keď tieto údaje sa v samotnej štruktúre v skutočnosti nenachádzajú.
/// Tu je príklad, keď k tomu dôjde pri [FFI].
/// Cudzie rozhranie používa úchytky typu `*mut ()` na odkazovanie na hodnoty Rust rôznych typov.
/// Sledujeme typ Rust pomocou parametra fantómového typu na štruktúre `ExternalResource`, ktorý obaľuje kľučku.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Vlastníctvo a kontrola pádu
///
/// Pridanie poľa typu `PhantomData<T>` znamená, že váš typ vlastní údaje typu `T`.To zase znamená, že keď je váš typ vypustený, môže vypustiť jednu alebo viac inštancií typu `T`.
/// To má vplyv na analýzu [drop check] kompilátora Rust.
///
/// Ak vaša štruktúra v skutočnosti *nevlastní* údaje typu `T`, je lepšie použiť referenčný typ, napríklad `PhantomData<&'a T>` (ideally) alebo `PhantomData<*const T>` (ak sa nepoužije životnosť), aby sa neuvádzalo vlastníctvo.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Interný kompilátor trait používaný na označenie typu rozlišujúcich znakov enum.
///
/// Táto trait je automaticky implementovaná pre každý typ a neprináša [`mem::Discriminant`] žiadne záruky.
/// Premenovanie medzi `DiscriminantKind::Discriminant` a `mem::Discriminant` je **nedefinované správanie**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Typ diskriminátora, ktorý musí spĺňať trait bounds požadované v `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Interný kompilátor trait sa používa na zistenie, či typ obsahuje interne nejaký `UnsafeCell`, ale nie prostredníctvom spätného smeru.
///
/// Toto ovplyvňuje napríklad to, či je `static` tohto typu vložený do statickej pamäte iba na čítanie alebo do zapisovateľnej statickej pamäte.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typy, ktoré sa po pripnutí dajú bezpečne presunúť.
///
/// Samotný Rust nemá predstavu o nehnuteľných typoch a pohyby (napr. Priradením alebo [`mem::replace`]) považuje za vždy bezpečné.
///
/// Namiesto toho sa používa typ [`Pin`][Pin], aby sa zabránilo pohybom cez typový systém.Ukazovatele `P<T>` zabalené v obale [`Pin<P<T>>`][Pin] nie je možné presunúť z.
/// Ďalšie informácie o pripnutí nájdete v dokumentácii k [`pin` module].
///
/// Implementácia modelu `Unpin` trait pre model `T` zruší obmedzenia pri pripájaní typu, čo potom umožňuje presunúť model `T` z modelu [`Pin<P<T>>`][Pin] pomocou funkcií, ako je napríklad [`mem::replace`].
///
///
/// `Unpin` pre nepripnuté údaje nemá vôbec žiadny dôsledok.
/// Najmä [`mem::replace`] s radosťou presúva dáta z `!Unpin` (funguje to pre každú `&mut T`, nielen pre `T: Unpin`).
/// Nemôžete však použiť [`mem::replace`] na dáta zabalené vo vnútri [`Pin<P<T>>`][Pin], pretože nemôžete získať `&mut T`, ktorý na to potrebujete, a *to* je to, čo robí tento systém funkčným.
///
/// Toto je napríklad možné vykonať iba na typoch implementujúcich `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Na volanie `mem::replace` potrebujeme premenlivý odkaz.
/// // Takýto odkaz môžeme získať vyvolaním `Pin::deref_mut` `Pin::deref_mut`, ale je to možné len preto, že `String` implementuje `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Táto trait je automaticky implementovaná pre takmer každý typ.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Typ značky, ktorý neimplementuje `Unpin`.
///
/// Ak typ obsahuje `PhantomPinned`, nebude implicitne implementovať `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementácie `Copy` pre primitívne typy.
///
/// Implementácie, ktoré nie je možné popísať v Rust, sú implementované v `traits::SelectionContext::copy_clone_conditions()` v `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Zdieľané referencie je možné kopírovať, ale meniteľné referencie *nemôžu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}