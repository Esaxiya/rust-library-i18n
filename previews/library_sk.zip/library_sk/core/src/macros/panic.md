Panics aktuálne vlákno.

To umožňuje programu okamžite ukončiť a poskytnúť spätnú väzbu volajúcemu programu.
`panic!` by sa malo použiť, keď program dosiahne neopraviteľný stav.

Toto makro je dokonalým spôsobom, ako presadiť podmienky v príklade kódu a v testoch.
`panic!` je úzko spätá s metódou `unwrap` enumov [`Option`][ounwrap] aj [`Result`][runwrap].
Obe implementácie volajú `panic!`, keď sú nastavené na varianty [`None`] alebo [`Err`].

Pri použití `panic!()` môžete určiť užitočné zaťaženie reťazca, ktoré je zostavené pomocou syntaxe [`format!`].
Toto užitočné zaťaženie sa používa pri vstrekovaní panic do volajúceho vlákna Rust, čo spôsobí, že vlákno bude úplne panic.

Chovanie predvoleného `std` hook, tj
kód, ktorý sa spustí ihneď po vyvolaní panic, je vytlačiť užitočné zaťaženie správy na `stderr` spolu s informáciami file/line/column o volaní `panic!()`.

panic hook môžete prepísať pomocou [`std::panic::set_hook()`].
Vo vnútri hook je možné k panic pristupovať ako `&dyn Any + Send`, ktorý obsahuje buď `&str`, alebo `String` pre bežné vyvolanie `panic!()`.
Na panic s hodnotou iného iného typu možno použiť [`panic_any`].

[`Result`] enum je často lepším riešením na zotavenie sa z chýb ako použitie makra `panic!`.
Toto makro by sa malo použiť, aby sa zabránilo ďalšiemu používaniu nesprávnych hodnôt, napríklad z externých zdrojov.
Podrobné informácie o riešení chýb sa nachádzajú v [book].

Pozrite si tiež makro [`compile_error!`], kde nájdete zvyšovanie chýb počas kompilácie.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Súčasná implementácia

Ak je hlavné vlákno panics, ukončí sa všetky vaše vlákna a program sa ukončí kódom `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





