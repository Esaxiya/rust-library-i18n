#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Rozširuje sa na `$crate::panic::panic_2015` alebo `$crate::panic::panic_2021` v závislosti od vydania volajúceho.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Tvrdí, že dva výrazy sú si navzájom rovné (pomocou [`PartialEq`]).
///
/// Na panic toto makro vytlačí hodnoty výrazov s ich ladiacimi reprezentáciami.
///
///
/// Rovnako ako [`assert!`] má aj toto makro druhý formulár, kde je možné poskytnúť vlastnú správu panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Znovuzískané rebrá sú zámerné.
                    // Bez nich sa zásobník pre výpožičku inicializuje ešte pred porovnaním hodnôt, čo vedie k znateľnému spomaleniu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Znovuzískané rebrá sú zámerné.
                    // Bez nich sa zásobník pre výpožičku inicializuje ešte pred porovnaním hodnôt, čo vedie k znateľnému spomaleniu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Tvrdí, že dva výrazy sa navzájom nerovnajú (pomocou [`PartialEq`]).
///
/// Na panic toto makro vytlačí hodnoty výrazov s ich ladiacimi reprezentáciami.
///
///
/// Rovnako ako [`assert!`] má aj toto makro druhý formulár, kde je možné poskytnúť vlastnú správu panic.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Znovuzískané rebrá sú zámerné.
                    // Bez nich sa zásobník pre výpožičku inicializuje ešte pred porovnaním hodnôt, čo vedie k znateľnému spomaleniu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Znovuzískané rebrá sú zámerné.
                    // Bez nich sa zásobník pre výpožičku inicializuje ešte pred porovnaním hodnôt, čo vedie k znateľnému spomaleniu.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Tvrdí, že boolovský výraz je za behu `true`.
///
/// Toto vyvolá makro [`panic!`], ak zadaný výraz nemožno za behu vyhodnotiť na `true`.
///
/// Rovnako ako [`assert!`] má aj toto makro druhú verziu, kde je možné poskytnúť vlastnú správu panic.
///
/// # Uses
///
/// Na rozdiel od [`assert!`] sú príkazy `debug_assert!` predvolene povolené iba v neoptimalizovaných zostaveniach.
/// Optimalizované zostavenie nebude vykonávať príkazy `debug_assert!`, pokiaľ `-C debug-assertions` nie je odovzdaný kompilátoru.
/// Vďaka tomu je `debug_assert!` užitočný pre kontroly, ktoré sú príliš drahé na to, aby boli prítomné v zostavení vydania, ale môžu byť užitočné počas vývoja.
/// Výsledok rozšírenia `debug_assert!` sa vždy typovo kontroluje.
///
/// Nekontrolované tvrdenie umožňuje programu v nekonzistentnom stave pokračovať v chode, čo môže mať neočakávané následky, ale nezavádza bezpečie, pokiaľ k tomu dôjde iba v bezpečnom kóde.
///
/// Náklady na výkon tvrdení však nie sú všeobecne merateľné.
/// Výmena [`assert!`] za `debug_assert!` je teda podporovaná až po dôkladnom profilovaní, a čo je dôležitejšie, iba v bezpečnom kóde!
///
/// # Examples
///
/// ```
/// // správa panic pre tieto tvrdenia je prísna hodnota daného výrazu.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // veľmi jednoduchá funkcia
/// debug_assert!(some_expensive_computation());
///
/// // presadiť pomocou vlastnej správy
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Tvrdí, že dva výrazy sú si navzájom rovné.
///
/// Na panic toto makro vytlačí hodnoty výrazov s ich ladiacimi reprezentáciami.
///
/// Na rozdiel od [`assert_eq!`] sú príkazy `debug_assert_eq!` predvolene povolené iba v neoptimalizovaných zostaveniach.
/// Optimalizované zostavenie nebude vykonávať príkazy `debug_assert_eq!`, pokiaľ `-C debug-assertions` nie je odovzdaný kompilátoru.
/// Vďaka tomu je `debug_assert_eq!` užitočný pre kontroly, ktoré sú príliš drahé na to, aby boli prítomné v zostavení vydania, ale môžu byť užitočné počas vývoja.
///
/// Výsledok rozšírenia `debug_assert_eq!` sa vždy typovo kontroluje.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Tvrdí, že dva výrazy sa navzájom nerovnajú.
///
/// Na panic toto makro vytlačí hodnoty výrazov s ich ladiacimi reprezentáciami.
///
/// Na rozdiel od [`assert_ne!`] sú príkazy `debug_assert_ne!` predvolene povolené iba v neoptimalizovaných zostaveniach.
/// Optimalizované zostavenie nebude vykonávať príkazy `debug_assert_ne!`, pokiaľ `-C debug-assertions` nie je odovzdaný kompilátoru.
/// Vďaka tomu je `debug_assert_ne!` užitočný pre kontroly, ktoré sú príliš drahé na to, aby boli prítomné v zostavení vydania, ale môžu byť užitočné počas vývoja.
///
/// Výsledok rozšírenia `debug_assert_ne!` sa vždy typovo kontroluje.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Vráti, či sa daný výraz zhoduje s niektorým z daných vzorov.
///
/// Rovnako ako vo výraze `match`, za vzorom môže prípadne nasledovať `if` a strážny výraz, ktorý má prístup k menám viazaným vzorom.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Rozbalí výsledok alebo rozšíri jeho chybu.
///
/// Na nahradenie `try!` bol pridaný operátor `?`, ktorý by sa mal namiesto toho použiť.
/// Okrem toho je `try` v Rust 2018 vyhradeným slovom, takže ak ho musíte použiť, budete musieť použiť [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` sa zhoduje s daným [`Result`].V prípade variantu `Ok` má výraz hodnotu zabalenej hodnoty.
///
/// V prípade variantu `Err` načíta vnútornú chybu.`try!` potom vykoná konverziu pomocou `From`.
/// Toto poskytuje automatický prevod medzi špecializovanými chybami a všeobecnejšími chybami.
/// Výsledná chyba sa potom okamžite vráti.
///
/// Z dôvodu skorého návratu je možné `try!` použiť iba vo funkciách, ktoré vracajú [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Preferovaná metóda rýchleho vrátenia chýb
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Predchádzajúca metóda rýchleho vrátenia chýb
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Toto je ekvivalentné s:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Zapíše formátované údaje do medzipamäte.
///
/// Toto makro akceptuje 'writer', formátovací reťazec a zoznam argumentov.
/// Argumenty sa naformátujú podľa zadaného formátovacieho reťazca a výsledok sa odošle zapisovateľovi.
/// Zapisovačom môže byť akákoľvek hodnota s metódou `write_fmt`;všeobecne to pochádza z implementácie buď [`fmt::Write`] alebo [`io::Write`] trait.
/// Makro vráti všetko, čo vráti metóda `write_fmt`;obyčajne [`fmt::Result`] alebo [`io::Result`].
///
/// Viac informácií o syntaxi formátovacieho reťazca nájdete na [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modul môže importovať `std::fmt::Write` aj `std::io::Write` a volať `write!` na objekty implementujúce jeden, pretože objekty zvyčajne neimplementujú obidva.
///
/// Modul však musí importovať kvalifikované traits, aby ich názvy neboli v konflikte:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // používa fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // používa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Toto makro je možné použiť aj v nastaveniach `no_std`.
/// V nastavení `no_std` ste zodpovední za implementačné podrobnosti komponentov.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Zapisujte naformátované údaje do medzipamäte s pripojeným novým riadkom.
///
/// Na všetkých platformách je nový rad samotným znakom LINE FEED (`\n`/`U+000A`) (žiadny ďalší PREPRAVA NÁVRATU (`\r`/`U+000D`).
///
/// Ďalšie informácie nájdete v téme [`write!`].Informácie o syntaxi formátovacieho reťazca nájdete v časti [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modul môže importovať `std::fmt::Write` aj `std::io::Write` a volať `write!` na objekty implementujúce jeden, pretože objekty zvyčajne neimplementujú obidva.
/// Modul však musí importovať kvalifikované traits, aby ich názvy neboli v konflikte:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // používa fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // používa io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Označuje nedosiahnuteľný kód.
///
/// Je to užitočné kedykoľvek, keď kompilátor nedokáže určiť, že niektorý kód je nedostupný.Napríklad:
///
/// * Zlaďte zbrane s ochrannými podmienkami.
/// * Smyčky, ktoré sa dynamicky končia.
/// * Iterátory, ktoré sa dynamicky končia.
///
/// Ak sa zistenie, že je kód nedostupný, ukáže ako nesprávny, program sa okamžite ukončí znakom [`panic!`].
///
/// Nebezpečným náprotivkom tohto makra je funkcia [`unreachable_unchecked`], ktorá po dosiahnutí kódu spôsobí nedefinované správanie.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Toto bude vždy [`panic!`].
///
/// # Examples
///
/// Zápasy zbraní:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // chyba kompilácie, ak je komentovaná
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // jedna z najchudobnejších implementácií x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Označuje neimplementovaný kód panikou so správou "not implemented".
///
/// To umožňuje vášmu kódu skontrolovať typ, čo je užitočné, ak prototypujete alebo implementujete model trait, ktorý vyžaduje viac metód, ktoré neplánujete použiť všetky.
///
/// Rozdiel medzi `unimplemented!` a [`todo!`] je v tom, že zatiaľ čo `todo!` vyjadruje úmysel implementovať túto funkcionalitu neskôr a správa je "not yet implemented", `unimplemented!` takéto tvrdenia nerobí.
/// Jeho správa je "not implemented".
/// Niektoré IDE označia aj " todo!` S.
///
/// # Panics
///
/// Toto bude vždy [`panic!`], pretože `unimplemented!` je len skratka pre `panic!` s pevnou konkrétnou správou.
///
/// Rovnako ako `panic!` má aj toto makro druhý formulár na zobrazovanie vlastných hodnôt.
///
/// # Examples
///
/// Povedzme, že máme trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Chceme implementovať `Foo` pre 'MyStruct', ale z nejakého dôvodu má zmysel implementovať iba funkciu `bar()`.
/// `baz()` a `qux()` bude ešte potrebné definovať v našej implementácii `Foo`, ale v ich definíciách môžeme použiť `unimplemented!`, aby sme umožnili kompiláciu nášho kódu.
///
/// Stále chceme, aby náš program prestal bežať, ak sa dosiahnu neimplementované metódy.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Nemá zmysel `baz` a `MyStruct`, takže tu nemáme vôbec žiadnu logiku.
/////
///         // Zobrazí sa "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Máme tu určitú logiku. Môžeme pridať správu k neimplementovaným!aby sme ukázali naše vynechanie.
///         // Zobrazí sa: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Označuje nedokončený kód.
///
/// To môže byť užitočné, ak vytvárate prototypy a hľadáte typecký kód.
///
/// Rozdiel medzi [`unimplemented!`] a `todo!` je v tom, že zatiaľ čo `todo!` vyjadruje úmysel implementovať túto funkcionalitu neskôr a správa je "not yet implemented", `unimplemented!` takéto tvrdenia nerobí.
/// Jeho správa je "not implemented".
/// Niektoré IDE označia aj " todo!` S.
///
/// # Panics
///
/// Toto bude vždy [`panic!`].
///
/// # Examples
///
/// Tu je príklad niektorých prebiehajúcich kódov.Máme trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Chceme implementovať `Foo` na jednom z našich typov, ale najskôr chceme tiež pracovať iba na `bar()`.Aby sa náš kód mohol kompilovať, musíme implementovať `baz()`, aby sme mohli použiť `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementácia ide sem
///     }
///
///     fn baz(&self) {
///         // teraz si nerobme starosti s implementáciou baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // nepoužívame ani baz(), takže je to v poriadku.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definície vstavaných makier.
///
/// Väčšina vlastností makra (stabilita, viditeľnosť atď.) Je tu prevzatá zo zdrojového kódu, s výnimkou rozširujúcich funkcií transformujúcich vstupy makra na výstupy, tieto funkcie poskytuje kompilátor.
///
///
pub(crate) mod builtin {

    /// Spôsobí zlyhanie kompilácie s danou chybovou správou, keď sa vyskytne.
    ///
    /// Toto makro by sa malo použiť, keď crate používa stratégiu podmieneného kompilácie na zabezpečenie lepších chybových správ pre chybné podmienky.
    ///
    /// Je to forma kompilátora na úrovni [`panic!`], ale počas *kompilácie* skôr ako za *runtime* vydáva chybu.
    ///
    /// # Examples
    ///
    /// Dvomi takýmito príkladmi sú makrá a prostredia `#[cfg]`.
    ///
    /// Ak je makru odovzdaná neplatná hodnota, zobrazí sa lepšia chyba kompilátora.
    /// Bez konečnej verzie branch by kompilátor stále vyslal chybu, ale chybové hlásenie by neuvádzalo dve platné hodnoty.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Ak nie je k dispozícii jedna z mnohých funkcií, vyslať chybu kompilátora.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Vytvorí parametre pre ďalšie makrá na formátovanie reťazcov.
    ///
    /// Toto makro funguje tak, že pre každý ďalší odovzdaný argument vezme formátovací reťazcový literál obsahujúci `{}`.
    /// `format_args!` pripraví ďalšie parametre, aby zabezpečil, že výstup bude možné interpretovať ako reťazec, a kanonizuje argumenty do jedného typu.
    /// Akákoľvek hodnota, ktorá implementuje [`Display`] trait, môže byť odovzdaná do `format_args!`, rovnako ako akákoľvek implementácia [`Debug`] môže byť odovzdaná do `{:?}` v rámci formátovacieho reťazca.
    ///
    ///
    /// Toto makro produkuje hodnotu typu [`fmt::Arguments`].Túto hodnotu je možné odovzdať makrám v rámci [`std::fmt`] na vykonávanie užitočného presmerovania.
    /// Všetky ostatné formátovacie makra ([" formát!`], [`write!`], [`println!`] atď.) Sú sprostredkované prostredníctvom tohto makra.
    /// `format_args!`, na rozdiel od odvodených makier sa vyhýba alokáciám haldy.
    ///
    /// Môžete použiť hodnotu [`fmt::Arguments`], ktorú `format_args!` vracia v kontextoch `Debug` a `Display`, ako je vidieť nižšie.
    /// Tento príklad tiež ukazuje, že formát `Debug` a `Display` je to isté: interpolovaný formátovací reťazec v `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Ďalšie informácie nájdete v dokumentácii k produktu [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Rovnaké ako `format_args`, ale nakoniec pridá nový riadok.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Skontroluje premennú prostredia v čase kompilácie.
    ///
    /// Toto makro sa v čase kompilácie rozšíri na hodnotu pomenovanej premennej prostredia, čím sa získa výraz typu `&'static str`.
    ///
    ///
    /// Ak premenná prostredia nie je definovaná, bude vydaná chyba kompilácie.
    /// Ak chcete nevydať chybu kompilácie, použite namiesto toho makro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Chybovú správu môžete prispôsobiť zadaním reťazca ako druhého parametra:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ak premenná prostredia `documentation` nie je definovaná, zobrazí sa nasledujúca chyba:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Voliteľne kontroluje premennú prostredia v čase kompilácie.
    ///
    /// Ak je pomenovaná premenná prostredia prítomná v čase kompilácie, rozšíri sa to na výraz typu `Option<&'static str>`, ktorého hodnota je `Some` hodnoty premennej prostredia.
    /// Ak premenná prostredia nie je k dispozícii, rozšíri sa to na `None`.
    /// Ďalšie informácie o tomto type nájdete v časti [`Option<T>`][Option].
    ///
    /// Pri použití tohto makra sa nikdy nevydá chyba kompilácie bez ohľadu na to, či je alebo nie je prítomná premenná prostredia.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zlučuje identifikátory do jedného identifikátora.
    ///
    /// Toto makro obsahuje ľubovoľný počet identifikátorov oddelených čiarkou a všetky ich spája do jedného, čím poskytuje výraz, ktorý je novým identifikátorom.
    /// Upozorňujeme, že hygiena umožňuje, aby toto makro nezachytávalo miestne premenné.
    /// Makrá sú tiež spravidla povolené iba v pozíciách položiek, výpisov alebo výrazov.
    /// To znamená, že hoci môžete toto makro použiť na odkazovanie na existujúce premenné, funkcie alebo moduly atď., Nemôžete s ním definovať nové.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nové, zábavné, meno) { }//takto nepoužiteľné!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zreťazí literály do statického reťazca.
    ///
    /// Toto makro obsahuje ľubovoľný počet literálov oddelených čiarkami a dáva výraz typu `&'static str`, ktorý predstavuje všetky zreťazené literály zľava doprava.
    ///
    ///
    /// Celé čísla a literály s pohyblivou rádovou čiarkou sú reťazené, aby ich bolo možné zreťaziť.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Rozbalí sa na číslo riadku, na ktorý bol vyvolaný.
    ///
    /// Pri modeloch [`column!`] a [`file!`] tieto makrá poskytujú vývojárom informácie o ladení o umiestnení v zdroji.
    ///
    /// Rozšírený výraz má typ `u32` a je založený na 1, takže prvý riadok v každom súbore sa vyhodnotí na 1, druhý na 2 atď.
    /// Je to v súlade s chybovými hláseniami bežných prekladačov alebo populárnych editorov.
    /// Vrátený riadok nie je *nevyhnutne* riadok samotného vyvolania `line!`, ale skôr prvé vyvolanie makra vedúce k vyvolaniu makra `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Rozbalí sa na číslo stĺpca, v ktorom bol vyvolaný.
    ///
    /// Pri modeloch [`line!`] a [`file!`] tieto makrá poskytujú vývojárom informácie o ladení o umiestnení v zdroji.
    ///
    /// Rozšírený výraz má typ `u32` a je založený na 1, takže prvý stĺpec v každom riadku sa vyhodnotí na 1, druhý na 2 atď.
    /// Je to v súlade s chybovými hláseniami bežných prekladačov alebo populárnych editorov.
    /// Vrátený stĺpec nie je *nevyhnutne* riadok samotného vyvolania `column!`, ale skôr prvé vyvolanie makra vedúce k vyvolaniu makra `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Rozbalí sa na názov súboru, v ktorom bol vyvolaný.
    ///
    /// Pri modeloch [`line!`] a [`column!`] tieto makrá poskytujú vývojárom informácie o ladení o umiestnení v zdroji.
    ///
    /// Rozšírený výraz má typ `&'static str` a vrátený súbor nie je vyvolaním samotného makra `file!`, ale skôr prvým vyvolaním makra, ktoré vedie k vyvolaniu makra `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Posilňuje jeho argumenty.
    ///
    /// Toto makro prinesie výraz typu `&'static str`, ktorý predstavuje sprísnenie všetkých tokens odovzdaných makru.
    /// Na syntax samotného vyvolania makra sa nevzťahujú nijaké obmedzenia.
    ///
    /// Upozorňujeme, že rozšírené výsledky vstupu tokens sa môžu v future zmeniť.Ak sa spoliehate na výstup, mali by ste byť opatrní.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Zahŕňa súbor kódovaný UTF-8 ako reťazec.
    ///
    /// Súbor je umiestnený relatívne k aktuálnemu súboru (podobne ako sa nachádzajú moduly).
    /// Zadaná cesta sa v čase kompilácie interpretuje spôsobom špecifickým pre platformu.
    /// Napríklad vyvolanie s cestou Windows obsahujúce spätné lomky `\` by sa na Unix nezkompilovalo správne.
    ///
    ///
    /// Toto makro poskytne výraz typu `&'static str`, ktorý je obsahom súboru.
    ///
    /// # Examples
    ///
    /// Predpokladajme, že v rovnakom adresári sú dva súbory s týmto obsahom:
    ///
    /// Súbor 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Súbor 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Pri kompilácii 'main.rs' a spustení výsledného binárneho súboru sa vytlačí "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Zahŕňa súbor ako odkaz na bajtové pole.
    ///
    /// Súbor je umiestnený relatívne k aktuálnemu súboru (podobne ako sa nachádzajú moduly).
    /// Zadaná cesta sa v čase kompilácie interpretuje spôsobom špecifickým pre platformu.
    /// Napríklad vyvolanie s cestou Windows obsahujúce spätné lomky `\` by sa na Unix nezkompilovalo správne.
    ///
    ///
    /// Toto makro poskytne výraz typu `&'static [u8; N]`, ktorý je obsahom súboru.
    ///
    /// # Examples
    ///
    /// Predpokladajme, že v rovnakom adresári sú dva súbory s týmto obsahom:
    ///
    /// Súbor 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Súbor 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Pri kompilácii 'main.rs' a spustení výsledného binárneho súboru sa vytlačí "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Rozbalí sa na reťazec, ktorý predstavuje aktuálnu cestu k modulu.
    ///
    /// Aktuálnu cestu k modulu možno považovať za hierarchiu modulov vedúcich späť k crate root.
    /// Prvá zložka vrátenej cesty je názov momentálne kompilovaného crate.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Vyhodnocuje boolovské kombinácie konfiguračných príznakov v čase kompilácie.
    ///
    /// Okrem atribútu `#[cfg]` je toto makro poskytované na umožnenie vyhodnotenia logických výrazov konfiguračných príznakov.
    /// To často vedie k menej duplicitnému kódu.
    ///
    /// Syntax priradená k tomuto makru je rovnaká ako syntax atribútu [`cfg`].
    ///
    /// `cfg!`, na rozdiel od `#[cfg]` neodstráni žiadny kód a vyhodnotí sa iba ako pravdivý alebo nepravdivý.
    /// Napríklad všetky bloky vo výraze if/else musia byť platné, keď sa pre podmienku použije `cfg!`, bez ohľadu na to, čo `cfg!` vyhodnocuje.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analyzuje súbor ako výraz alebo položku podľa kontextu.
    ///
    /// Súbor je umiestnený relatívne k aktuálnemu súboru (podobne ako sa nachádzajú moduly).Zadaná cesta sa v čase kompilácie interpretuje spôsobom špecifickým pre platformu.
    /// Napríklad vyvolanie s cestou Windows obsahujúce spätné lomky `\` by sa na Unix nezkompilovalo správne.
    ///
    /// Používanie tohto makra je často zlý nápad, pretože ak sa súbor analyzuje ako výraz, nehygienicky sa umiestni do okolitého kódu.
    /// To by mohlo viesť k tomu, že premenné alebo funkcie sa budú líšiť od toho, čo súbor očakával, ak existujú premenné alebo funkcie, ktoré majú v aktuálnom súbore rovnaký názov.
    ///
    ///
    /// # Examples
    ///
    /// Predpokladajme, že v rovnakom adresári sú dva súbory s týmto obsahom:
    ///
    /// Súbor 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Súbor 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Pri kompilácii 'main.rs' a spustení výsledného binárneho súboru sa vytlačí "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tvrdí, že boolovský výraz je za behu `true`.
    ///
    /// Toto vyvolá makro [`panic!`], ak zadaný výraz nemožno za behu vyhodnotiť na `true`.
    ///
    /// # Uses
    ///
    /// Tvrdenia sa vždy kontrolujú v zostavách ladenia aj vydaní a nemožno ich deaktivovať.
    /// Na stránke [`debug_assert!`] nájdete tvrdenia, ktoré nie sú v zostaveniach vydaní predvolene povolené.
    ///
    /// Nebezpečný kód sa môže na `assert!` spoliehať na vynútenie invariantov chodu programu, ktoré by v prípade jeho porušenia mohli viesť k bezpečnosti.
    ///
    /// Medzi ďalšie prípady použitia `assert!` patrí testovanie a vynucovanie run-time invariantov v bezpečnom kóde (ktorého porušenie nemôže viesť k bezpečnosti).
    ///
    ///
    /// # Vlastné správy
    ///
    /// Toto makro má druhý formulár, kde je možné poskytnúť vlastnú správu panic s argumentmi na formátovanie alebo bez nich.
    /// Syntax tohto formulára nájdete na [`std::fmt`].
    /// Výrazy použité ako argumenty formátu sa vyhodnotia, iba ak sa tvrdenie nepodarí.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // správa panic pre tieto tvrdenia je prísna hodnota daného výrazu.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // veľmi jednoduchá funkcia
    ///
    /// assert!(some_computation());
    ///
    /// // presadiť pomocou vlastnej správy
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline montáž.
    ///
    /// Prečítajte si o použití [unstable book].
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Inline zostava v štýle LLVM.
    ///
    /// Prečítajte si o použití [unstable book].
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline montáž na úrovni modulu.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Tlače prešli tokens do štandardného výstupu.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Povolí alebo zakáže funkciu sledovania používanú na ladenie iných makier.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro atribútu použité na použitie odvodených makier.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makro atribútu použité na funkciu, aby sa z nej stal jednotkový test.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makro atribútu použité na funkciu, aby sa z nej stal porovnávací test.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Detail implementácie makier `#[test]` a `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Makro atribútu použité na statiku, aby sa zaregistroval ako globálny alokátor.
    ///
    /// Pozri tiež [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Ponechá položku, na ktorú sa vzťahuje, ak je odovzdaná cesta prístupná, a inak ju odstráni.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Rozbalí všetky atribúty `#[cfg]` a `#[cfg_attr]` vo fragmente kódu, na ktorý je aplikovaný.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Nestabilné podrobnosti implementácie kompilátora `rustc`, nepoužívajte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Nestabilné podrobnosti implementácie kompilátora `rustc`, nepoužívajte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}