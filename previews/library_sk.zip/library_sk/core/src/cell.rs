//! Zdieľateľné premenlivé nádoby.
//!
//! Bezpečnosť pamäte Rust je založená na tomto pravidle: Pri objekte `T` je možné mať iba jednu z nasledujúcich možností:
//!
//! - Mať niekoľko nemenných odkazov na objekt (`&T`) (tiež známych ako **aliasing**).
//! - S jedným premenlivým odkazom (" &mut T`) na objekt (tiež známy ako **mutability**).
//!
//! Toto vynucuje kompilátor Rust.Existujú však situácie, keď toto pravidlo nie je dostatočne flexibilné.Niekedy je potrebné mať viac odkazov na objekt a napriek tomu ho mutovať.
//!
//! Existujú zdieľateľné premenlivé kontajnery, ktoré umožňujú kontrolovateľnosť zmeniteľnosti, a to aj za prítomnosti aliasingu.[`Cell<T>`] aj [`RefCell<T>`] to umožňujú robiť jedným vláknom.
//! Avšak ani `Cell<T>` ani `RefCell<T>` nie sú bezpečné pre vlákna (neimplementujú [`Sync`]).
//! Ak potrebujete vykonať aliasing a mutáciu medzi viacerými vláknami, je možné použiť typy [`Mutex<T>`], [`RwLock<T>`] alebo [`atomic`].
//!
//! Hodnoty typov `Cell<T>` a `RefCell<T>` môžu byť mutované prostredníctvom zdieľaných referencií (tj
//! bežný typ `&T`), zatiaľ čo väčšinu typov Rust možno mutovať iba prostredníctvom jedinečných odkazov (&mut T`).
//! Hovoríme, že `Cell<T>` a `RefCell<T>` poskytujú " vnútornú premenlivosť`na rozdiel od typických typov Rust, ktoré vykazujú " zdedenú premenlivosť`.
//!
//! Typy buniek majú dve príchute: `Cell<T>` a `RefCell<T>`.`Cell<T>` implementuje premenlivosť interiéru presunutím hodnôt do a z `Cell<T>`.
//! Ak chcete namiesto hodnôt použiť referencie, musíte použiť typ `RefCell<T>`, ktorý pred mutáciou získa zámok proti zápisu.`Cell<T>` poskytuje metódy na získanie a zmenu aktuálnej hodnoty interiéru:
//!
//!  - Pre typy, ktoré implementujú [`Copy`], metóda [`get`](Cell::get) načíta aktuálnu hodnotu interiéru.
//!  - Pre typy, ktoré implementujú [`Default`], metóda [`take`](Cell::take) nahradí aktuálnu hodnotu interiéru [`Default::default()`] a vráti nahradenú hodnotu.
//!  - Pre všetky typy metóda [`replace`](Cell::replace) nahradí aktuálnu hodnotu interiéru a vráti nahradenú hodnotu a metóda [`into_inner`](Cell::into_inner) spotrebuje `Cell<T>` a vráti hodnotu interiéru.
//!  Metóda [`set`](Cell::set) navyše nahrádza vnútornú hodnotu, čím nahradzuje nahradenú hodnotu.
//!
//! `RefCell<T>` využíva životy Rust na implementáciu " dynamického vypožičiavania`, procesu, pri ktorom je možné požadovať dočasný, výlučný a premenlivý prístup k vnútornej hodnote.
//! Požičiava si na `RefCell<T>" sú sledované" za behu`, na rozdiel od natívnych referenčných typov Rust, ktoré sú úplne sledované staticky, v čase kompilácie.
//! Pretože pôžičky `RefCell<T>` sú dynamické, je možné pokúsiť sa požičať si hodnotu, ktorá je už premenlivo požičaná;keď sa to stane, výsledkom bude vlákno panic.
//!
//! # Kedy zvoliť variabilitu interiéru
//!
//! Bežnejšia zdedená premenlivosť, kde na mutáciu hodnoty musí byť jedinečný prístup, je jedným z kľúčových jazykových prvkov, ktorý umožňuje aplikácii Rust dôrazne uvažovať o aliasingu ukazovateľa a staticky zabrániť chybám pri zlyhaní.
//! Z tohto dôvodu sa uprednostňuje zdedená premenlivosť a vnútorná premenlivosť je krajnou možnosťou.
//! Pretože typy buniek umožňujú mutáciu tam, kde by to bolo inak zakázané, existujú prípady, kedy môže byť vhodná vnútorná mutabilita alebo dokonca musí byť použitá *, napr.
//!
//! * Predstavujeme premenlivosť 'inside' niečoho nemenného
//! * Podrobnosti implementácie logicky nemenných metód.
//! * Mutujúce implementácie [`Clone`].
//!
//! ## Predstavujeme premenlivosť 'inside' niečoho nemenného
//!
//! Mnoho zdieľaných typov inteligentných ukazovateľov, vrátane [`Rc<T>`] a [`Arc<T>`], poskytuje kontajnery, ktoré je možné klonovať a zdieľať medzi viacerými stranami.
//! Pretože obsiahnuté hodnoty môžu byť viacnásobne aliasy, je možné ich požičať iba v `&`, nie `&mut`.
//! Bez buniek by bolo nemožné vôbec mutovať údaje vo vnútri týchto inteligentných ukazovateľov.
//!
//! Je veľmi bežné potom vložiť `RefCell<T>` do zdieľaných typov ukazovateľov, aby sa znova zaviedla premenlivosť:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Vytvorte nový blok, aby ste obmedzili rozsah dynamického výpožičky
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Všimnite si, že ak by sme nenechali predchádzajúcu výpožičku cache vypadnúť z rozsahu, potom by nasledujúca výpožička spôsobila dynamické vlákno panic.
//!     //
//!     // Toto je hlavné nebezpečenstvo pri používaní `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Upozorňujeme, že tento príklad používa `Rc<T>` a nie `Arc<T>`.`RefCell<T>`s sú pre scenáre s jedným vláknom.Ak potrebujete zdieľanú premenlivosť v situácii s viacerými vláknami, zvážte použitie [`RwLock<T>`] alebo [`Mutex<T>`].
//!
//! ## Podrobnosti implementácie logicky nemenných metód
//!
//! Príležitostne môže byť žiaduce nevystavovať v rozhraní API prítomnosť mutácie "under the hood".
//! Môže to byť preto, že operácia je logicky nemenná, ale napríklad ukladanie do medzipamäte núti implementáciu vykonať mutáciu;alebo preto, že na implementáciu metódy trait, ktorá bola pôvodne definovaná na použitie `&self`, musíte použiť mutáciu.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Sem idú drahé výpočty
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Mutujúce implementácie `Clone`
//!
//! Toto je jednoducho zvláštny, ale bežný prípad predchádzajúceho: skrytie premenlivosti pre operácie, ktoré sa javia ako nemenné.
//! Očakáva sa, že metóda [`clone`](Clone::clone) nezmení zdrojovú hodnotu a je deklarovaná ako metóda `&self`, nie `&mut self`.
//! Preto akákoľvek mutácia, ktorá sa vyskytne v metóde `clone`, musí používať typy buniek.
//! Napríklad [`Rc<T>`] udržuje svoje referenčné počty v rámci `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Premenlivá pamäťová pozícia.
///
/// # Examples
///
/// V tomto príklade vidíte, že `Cell<T>` umožňuje mutáciu vo vnútri nemennej štruktúry.
/// Inými slovami umožňuje "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // CHYBA: `my_struct` je nemenná
/// // my_struct.regular_field =new_value;
///
/// // PRÁCE: hoci `my_struct` je nemenný, `special_field` je `Cell`,
/// // ktoré sa dajú vždy zmutovať
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Ďalšie informácie nájdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Vytvorí `Cell<T>` s hodnotou `Default` pre T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Vytvorí nový `Cell` obsahujúci danú hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Nastaví obsiahnutú hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Zamení hodnoty dvoch buniek.
    /// Rozdiel oproti `std::mem::swap` je v tom, že táto funkcia nevyžaduje referenciu `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // BEZPEČNOSŤ: To môže byť riskantné, ak sa volá z samostatných vlákien, ale `Cell`
        // je `!Sync`, takže sa to nestane.
        // Toto tiež nezruší platnosť akýchkoľvek ukazovateľov, pretože `Cell` zaisťuje, že nič iné nebude smerovať do žiadnej z týchto buniek.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Nahradí obsiahnutú hodnotu hodnotou `val` a vráti starú obsiahnutú hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // BEZPEČNOSŤ: Toto môže spôsobiť dátové preteky, ak sú volané zo samostatného vlákna,
        // ale `Cell` je `!Sync`, takže sa to nestane.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Rozbalí hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Vráti kópiu obsiahnutej hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // BEZPEČNOSŤ: Toto môže spôsobiť dátové preteky, ak sú volané zo samostatného vlákna,
        // ale `Cell` je `!Sync`, takže sa to nestane.
        unsafe { *self.value.get() }
    }

    /// Aktualizuje obsiahnutú hodnotu pomocou funkcie a vráti novú hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Vráti nespracovaný ukazovateľ na podkladové údaje v tejto bunke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Vráti premenlivý odkaz na podkladové údaje.
    ///
    /// Toto volanie si požičiava `Cell` premenlivo (v čase kompilácie), čo zaručuje, že vlastníme jediný odkaz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Vráti `&Cell<T>` z `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // BEZPEČNOSŤ: `&mut` zaisťuje jedinečný prístup.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Berie hodnotu bunky a ponecháva `Default::default()` na svojom mieste.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Vráti `&[Cell<T>]` z `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // BEZPEČNOSŤ: `Cell<T>` má rovnaké usporiadanie pamäte ako `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Premenlivá pamäťová pozícia s dynamicky kontrolovanými pravidlami výpožičky
///
/// Ďalšie informácie nájdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Chyba vrátená [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Chyba vrátená [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Kladné hodnoty predstavujú počet aktívnych `Ref`.Záporné hodnoty predstavujú počet aktívnych `RefMut`.
// Viaceré objekty RefMut môžu byť aktívne iba vtedy, ak odkazujú na odlišné neprekrývajúce sa komponenty `RefCell` (napr. Rôzne rozsahy rezu).
//
// `Ref` a `RefMut` sú obe dve slová veľké, takže pravdepodobne nikdy nebude dostatok " Ref`alebo " RefMut` na to, aby pretiekli polovicu rozsahu `usize`.
// `BorrowFlag` teda pravdepodobne nikdy nebude pretekať ani podtekať.
// To však nie je záruka, pretože by sa mohol opakovane vytvoriť patologický program a potom mem::forget `Ref`s alebo`RefMut`s.
// Celý kód teda musí výslovne skontrolovať, či nedochádza k pretečeniu a podtečeniu, aby sa zabránilo nebezpečenstvu, alebo aby sa aspoň správali správne v prípade, že dôjde k pretečeniu alebo podtečeniu (napr. Pozri BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Vytvorí nový `RefCell` obsahujúci `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Spotrebuje `RefCell` a vráti zabalenú hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Pretože táto funkcia má hodnotu `self` (`RefCell`), kompilátor staticky overí, či nie je momentálne požičaná.
        //
        self.value.into_inner()
    }

    /// Nahradí zabalenú hodnotu novou, vráti starú hodnotu bez deinicializácie ktorejkoľvek z nich.
    ///
    ///
    /// Táto funkcia zodpovedá [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics, ak je hodnota momentálne požičaná.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Nahradí zabalenú hodnotu novou vypočítanou z `f`, vráti starú hodnotu bez deinicializácie ktorejkoľvek z nich.
    ///
    ///
    /// # Panics
    ///
    /// Panics, ak je hodnota momentálne požičaná.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Zamení zabalenú hodnotu `self` za zabalenú hodnotu `other` bez deinicializácie ktorejkoľvek z nich.
    ///
    ///
    /// Táto funkcia zodpovedá [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Nezameniteľne si požičia zabalenú hodnotu.
    ///
    /// Výpožička trvá, kým vrátená `Ref` neopustí rámec.
    /// Je možné vybrať naraz niekoľko nemenných pôžičiek.
    ///
    /// # Panics
    ///
    /// Panics, ak je hodnota momentálne zmeniteľne požičaná.
    /// Pre variant, ktorý neprepadá panike, použite [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Príklad panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Nemenne si požičia zabalenú hodnotu a vráti chybu, ak je hodnota v súčasnosti zmeniteľne požičaná.
    ///
    ///
    /// Výpožička trvá, kým vrátená `Ref` neopustí rámec.
    /// Je možné vybrať naraz niekoľko nemenných pôžičiek.
    ///
    /// Toto je variant nepodporujúci paniku modelu [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // BEZPEČNOSŤ: `BorrowRef` zaručuje, že existuje iba nemenný prístup
            // na hodnotu, kým je vypožičaný.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Obojstranne si požičiava zabalenú hodnotu.
    ///
    /// Výpožička trvá, kým vrátená `RefMut` alebo všetky oblasti, ktoré sú z nej odvodené, opustia rozsah.
    ///
    /// Hodnotu nie je možné požičať, kým je táto výpožička aktívna.
    ///
    /// # Panics
    ///
    /// Panics, ak je hodnota momentálne požičaná.
    /// Pre variant, ktorý neprepadá panike, použite [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Príklad panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Obojstranne si požičia zabalenú hodnotu a vráti chybu, ak je hodnota momentálne požičaná.
    ///
    ///
    /// Výpožička trvá, kým vrátená `RefMut` alebo všetky oblasti, ktoré sú z nej odvodené, opustia rozsah.
    /// Hodnotu nie je možné požičať, kým je táto výpožička aktívna.
    ///
    /// Toto je variant nepodporujúci paniku modelu [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // BEZPEČNOSŤ: `BorrowRef` zaručuje jedinečný prístup.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Vráti nespracovaný ukazovateľ na podkladové údaje v tejto bunke.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Vráti premenlivý odkaz na podkladové údaje.
    ///
    /// Toto volanie si požičiava `RefCell` premenlivo (v čase kompilácie), takže nie sú potrebné dynamické kontroly.
    ///
    /// Buďte však opatrní: pri tejto metóde sa očakáva, že `self` bude premenlivý, čo pri použití `RefCell` všeobecne neplatí.
    ///
    /// Ak nie je `self` premenlivá, pozrite sa radšej na metódu [`borrow_mut`].
    ///
    /// Upozorňujeme tiež, že táto metóda je určená iba na zvláštne okolnosti a zvyčajne nie je to, čo chcete.
    /// V prípade pochybností použite radšej [`borrow_mut`].
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Zrušte vplyv uniknutých ochranných krytov na stav vypožičania zariadenia `RefCell`.
    ///
    /// Toto volanie je podobné ako v prípade [`get_mut`], ale je špecializovanejšie.
    /// Požičiava si `RefCell` premenlivo, aby sa zabezpečilo, že neexistujú žiadne pôžičky, a potom vynuluje zdieľané požičiavanie sledujúce stav.
    /// Toto je relevantné, ak došlo k úniku niektorých výpožičiek `Ref` alebo `RefMut`.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Nemenne si požičia zabalenú hodnotu a vráti chybu, ak je hodnota v súčasnosti zmeniteľne požičaná.
    ///
    /// # Safety
    ///
    /// Na rozdiel od `RefCell::borrow` je táto metóda nebezpečná, pretože nevracia `Ref`, čím ponecháva príznak požičania nedotknutý.
    /// Premenlivé požičiavanie `RefCell`, kým je odkaz vrátený touto metódou nažive, je nedefinované správanie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // BEZPEČNOSŤ: Kontrolujeme, či teraz nikto aktívne nepíše, ale je to tak
            // zodpovednosť volajúceho za zabezpečenie toho, že nikto nebude písať, kým sa vrátený odkaz už nebude používať.
            // `self.value.get()` tiež odkazuje na hodnotu vlastnenú `self` a je teda zaručené, že bude platný po celú dobu životnosti `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Berie zabalenú hodnotu a ponecháva `Default::default()` na svojom mieste.
    ///
    /// # Panics
    ///
    /// Panics, ak je hodnota momentálne požičaná.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ak je hodnota momentálne zmeniteľne požičaná.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Vytvorí `RefCell<T>` s hodnotou `Default` pre T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics, ak je hodnota v ktorejkoľvek z `RefCell` momentálne požičaná.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Prírastok výpožičky môže mať za následok nečítanie hodnoty (<=0) v týchto prípadoch:
            // 1. Bolo to <0, tj. Existujú výpožičky, takže nemôžeme povoliť výpožičku na čítanie kvôli pravidlám aliasingu Rust.
            // 2.
            // Bolo to isize::MAX (maximálne množstvo vypožičaných kníh) a pretieklo to do isize::MIN (maximálne množstvo vypožičaných kníh), takže nemôžeme dovoliť ďalšiu výpožičku na čítanie, pretože isize nemôže predstavovať toľko vypožičaných kníh (to sa môže stať iba vtedy, vám mem::forget viac ako malé stále množstvo odporúčaní, čo nie je dobrý postup)
            //
            //
            //
            //
            None
        } else {
            // Zvyšovanie výpožičky môže mať za následok načítanie hodnoty (> 0) v týchto prípadoch:
            // 1. Bolo to=0, tj nebolo to požičané, a berieme si prvé prečítané požičanie
            // 2. Bolo to> 0 a <isize::MAX, tj
            // boli prečítané výpožičky a Isize je dostatočne veľký na to, aby predstavoval ešte jednu vypožičanú knihu
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Pretože tento odkaz existuje, vieme, že príznakom výpožičky je výpožička na čítanie.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Zabráňte pretečeniu počítadla pôžičky do písanej pôžičky.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Zabalí vypožičaný odkaz na hodnotu do poľa `RefCell`.
/// Typ obalu za nezmeniteľnú hodnotu z `RefCell<T>`.
///
/// Ďalšie informácie nájdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopíruje `Ref`.
    ///
    /// `RefCell` je už nemenne požičaný, takže to nemôže zlyhať.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `Ref::clone(...)`.
    /// Implementácia alebo metóda `Clone` by interferovala s rozšíreným používaním `r.borrow().clone()` na klonovanie obsahu `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Vyrába novú `Ref` pre komponent požičaných dát.
    ///
    /// `RefCell` je už nemenne požičaný, takže to nemôže zlyhať.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `Ref::map(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Vyrába nový model `Ref` ako voliteľnú súčasť požičaných údajov.
    /// Pôvodný kryt sa vráti ako `Err(..)`, ak uzávierka vráti `None`.
    ///
    /// `RefCell` je už nemenne požičaný, takže to nemôže zlyhať.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `Ref::filter_map(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Rozdelí `Ref` na viac ref. Pre rôzne komponenty požičaných dát.
    ///
    /// `RefCell` je už nemenne požičaný, takže to nemôže zlyhať.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `Ref::map_split(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Premeniť na odkaz na podkladové údaje.
    ///
    /// Podkladová `RefCell` si už nikdy nemôže byť premenlivo požičaná a vždy sa bude javiť ako nemenne požičaná.
    ///
    /// Nie je dobrý nápad uniknúť viac ako stály počet referencií.
    /// `RefCell` si možno znova a znova zapožičať, ak celkovo došlo k menšiemu počtu únikov.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `Ref::leak(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Zabudnutím na tento odkaz zaistíme, že počítadlo výpožičiek v RefCell sa počas životnosti `'b` nebude môcť vrátiť späť na NEPOUŽITÉ.
        // Obnovenie stavu sledovania referencie by vyžadovalo jedinečný odkaz na požičanú jednotku RefCell.
        // Z pôvodnej bunky nemožno vytvoriť ďalšie mutabilné odkazy.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Vyrába novú `RefMut` pre komponent požičaných dát, napr. Variant enum.
    ///
    /// `RefCell` je už premenlivo požičaný, takže to nemôže zlyhať.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `RefMut::map(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): opraviť výpožičku
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Vyrába nový model `RefMut` ako voliteľnú súčasť požičaných údajov.
    /// Pôvodný kryt sa vráti ako `Err(..)`, ak uzávierka vráti `None`.
    ///
    /// `RefCell` je už premenlivo požičaný, takže to nemôže zlyhať.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `RefMut::filter_map(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): opraviť výpožičku
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // BEZPEČNOSŤ: funkcia má po celú dobu trvania výlučný odkaz
        // jeho volania cez `orig` a ukazovateľ sa ruší iba vo vnútri volania funkcie, čo nikdy neumožňuje únik exkluzívneho odkazu.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // BEZPEČNOSŤ: rovnaké ako vyššie.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Rozdelí `RefMut` na viac `RefMut` pre rôzne komponenty požičaných dát.
    ///
    /// Podkladová `RefCell` zostane premenlivo vypožičaná, kým obaja vrátení `RefMut` nezmiznú z rozsahu.
    ///
    /// `RefCell` je už premenlivo požičaný, takže to nemôže zlyhať.
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `RefMut::map_split(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Premeniť na premenlivý odkaz na podkladové údaje.
    ///
    /// Podkladovú `RefCell` si nie je možné znovu požičať a vždy sa bude javiť ako premenlivo vypožičaná, takže vrátený odkaz je jediný do interiéru.
    ///
    ///
    /// Toto je pridružená funkcia, ktorú je potrebné použiť ako `RefMut::leak(...)`.
    /// Metóda by zasahovala do metód rovnakého názvu obsahu `RefCell` používaného cez `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Zabudnutím na tento BorrowRefMut zabezpečíme, že počítadlo výpožičiek v RefCell sa počas životnosti `'b` nemôže vrátiť späť na NEPOUŽITÉ.
        // Obnovenie stavu sledovania referencie by vyžadovalo jedinečný odkaz na požičanú jednotku RefCell.
        // Z pôvodnej bunky nemožno v priebehu tejto životnosti vytvoriť žiadne ďalšie referencie, čím sa aktuálna výpožička stane jedinou referenciou pre zostávajúcu dobu životnosti.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: Na rozdiel od BorrowRefMut::clone sa na vytvorenie pôvodného názvu volá new
        // premenlivý odkaz, a preto v súčasnosti nesmú existovať žiadne odkazy.
        // Zatiaľ čo teda klon zvyšuje premenlivú refcount, tu výslovne povoľujeme iba prechod z UNUSED na UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Klonuje `BorrowRefMut`.
    //
    // Toto je platné iba v prípade, že sa každá `BorrowRefMut` používa na sledovanie premenlivého odkazu na zreteľný, neprekrývajúci sa rozsah pôvodného objektu.
    //
    // Toto nie je v Clone impl, aby to kód implicitne nenazýval.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Zabráňte podtečeniu počítadla pôžičiek.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Typ obalu za premenlivo vypožičanú hodnotu z `RefCell<T>`.
///
/// Ďalšie informácie nájdete v [module-level documentation](self).
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Základné primitívum pre vnútornú premenlivosť v Rust.
///
/// Ak máte referenčný `&T`, potom kompilátor v Rust zvyčajne vykoná optimalizáciu na základe vedomia, že `&T` ukazuje na nemenné dáta.Mutovanie týchto údajov, napríklad prostredníctvom aliasu alebo prevodom `&T` na `&mut T`, sa považuje za nedefinované správanie.
/// `UnsafeCell<T>` zrušenie záruky nemennosti pre `&T`: zdieľaná referencia `&UnsafeCell<T>` môže ukazovať na dáta, ktoré sú mutované.Toto sa nazýva "interior mutability".
///
/// Všetky ostatné typy, ktoré umožňujú internú premenlivosť, ako napríklad `Cell<T>` a `RefCell<T>`, interne používajú `UnsafeCell` na zabalenie svojich údajov.
///
/// Upozorňujeme, že `UnsafeCell` ovplyvňuje iba záruku nemennosti zdieľaných referencií.Záruka jedinečnosti premenlivých referencií nie je ovplyvnená.Neexistuje *žiadny* legálny spôsob, ako získať aliasing `&mut`, a to ani pri `UnsafeCell<T>`.
///
/// Samotné `UnsafeCell` API je technicky veľmi jednoduché: [`.get()`] vám poskytne surový ukazovateľ `*mut T` na jeho obsah.Je na _you_ ako návrhárovi abstrakcie, aby správne použil tento surový ukazovateľ.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Presné pravidlá aliasu Rust sú trochu v toku, ale hlavné body nie sú sporné:
///
/// - Ak vytvoríte bezpečnú referenciu s doživotnou referenciou `'a` (buď referencia `&T` alebo `&mut T`), ktorá je prístupná pomocou bezpečného kódu (napríklad preto, že ste ju vrátili), nesmiete k údajom pristupovať žiadnym spôsobom, ktorý by odporoval zvyšku tejto referencie z `'a`.
/// Napríklad to znamená, že ak vezmete `*mut T` z `UnsafeCell<T>` a nahodíte ho na `&T`, potom dáta v `T` musia zostať nezmeniteľné (samozrejme modulo akékoľvek dáta `UnsafeCell` nájdené v `T`), kým nevyprší životnosť tohto odkazu.
/// Podobne, ak vytvoríte referenciu `&mut T`, ktorá sa uvoľní do bezpečného kódu, nesmiete pristupovať k údajom v rámci `UnsafeCell`, kým platnosť tejto referencie nevyprší.
///
/// - Vždy sa musíte vyhnúť dátovým pretekom.Ak má viac vlákien prístup k rovnakému `UnsafeCell`, potom všetky zápisy musia mať správny vzťah " before-before` so všetkými ostatnými prístupmi (alebo musia používať atómovú energiu).
///
/// Na uľahčenie správneho návrhu sú nasledujúce scenáre výslovne vyhlásené za legálne pre kód s jedným vláknom:
///
/// 1. Odkaz na `&T` je možné uvoľniť do bezpečného kódu a tam môže koexistovať s inými odkazmi na `&T`, ale nie s `&mut T`.
///
/// 2. Odkaz na `&mut T` môže byť uvoľnený do bezpečného kódu za predpokladu, že s ním koexistujú iné `&mut T` ani `&T`.`&mut T` musí byť vždy jedinečný.
///
/// Všimnite si, že zatiaľ čo mutovanie obsahu `&UnsafeCell<T>` (aj keď iné referencie `&UnsafeCell<T>` alias na bunku) sú v poriadku (za predpokladu, že vyššie uvedené invarianty vynútite iným spôsobom), stále je nedefinované správanie mať viac aliasov `&mut UnsafeCell<T>`.
/// To znamená, že `UnsafeCell` je obal navrhnutý pre špeciálnu interakciu s _shared_ accesses (_i.e._ prostredníctvom odkazu `&UnsafeCell<_>`);pri jednaní s _exclusive_ accesses (_e.g._ prostredníctvom `&mut UnsafeCell<_>` nie je nijaké kúzlo): bunka ani zabalená hodnota nemôžu byť počas trvania tejto výpožičky `&mut` aliasované.
///
/// Toto predvádza prístupový objekt [`.get_mut()`], čo je _safe_ getter, ktorý poskytuje `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Tu je príklad predstavenia, ako zdravo mutovať obsah `UnsafeCell<_>` napriek tomu, že existuje viac referencií aliasujúcich bunku:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Získajte viac/súbežné/zdieľané odkazy na rovnakú `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // BEZPEČNOSŤ: v tomto rozsahu nie sú žiadne ďalšie odkazy na obsah `x`,
///     // takže náš je skutočne jedinečný.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- požičať-+
///     *p1_exclusive += 27; // |
/// } // <---------- nemôže prekročiť tento bod -------------------+
///
/// unsafe {
///     // BEZPEČNOSŤ: v rámci tohto rozsahu nikto neočakáva, že bude mať výlučný prístup k obsahu `x`,
///     // takže môžeme mať viac zdieľaných prístupov súčasne.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Nasledujúci príklad ukazuje skutočnosť, že exkluzívny prístup k `UnsafeCell<T>` znamená exkluzívny prístup k jeho `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // s exkluzívnymi prístupmi,
///                         // `UnsafeCell` je priehľadný obal, ktorý nie je op, takže tu nie je potrebné `unsafe`.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Získajte jedinečný odkaz na `x` skontrolovaný časom kompilácie.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // S exkluzívnym odkazom môžeme obsah bezplatne mutovať.
/// *p_unique.get_mut() = 0;
/// // Alebo ekvivalentne:
/// x = UnsafeCell::new(0);
///
/// // Keď vlastníme hodnotu, môžeme obsah extrahovať zadarmo.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Vytvorí novú inštanciu `UnsafeCell`, ktorá zalomí zadanú hodnotu.
    ///
    ///
    /// Celý prístup k vnútornej hodnote pomocou metód je `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Rozbalí hodnotu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Získava premenlivý ukazovateľ na zalomenú hodnotu.
    ///
    /// To je možné použiť na akýkoľvek ukazovateľ.
    /// Pri prenášaní na `&mut T` sa ubezpečte, že je prístup jedinečný (žiadne aktívne referencie, zmeniteľné alebo nie) a zaistite, aby pri prenášaní na `&T` nedochádzalo k mutáciám alebo zmeniteľným aliasom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Ukazovateľ môžeme jednoducho presunúť z `UnsafeCell<T>` na `T` kvôli #[repr(transparent)].
        // Toto zneužíva špeciálny stav knižnice libstd, neexistuje žiadna záruka pre užívateľský kód, že to bude fungovať vo verziách kompilátora future!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Vráti premenlivý odkaz na podkladové údaje.
    ///
    /// Toto volanie požičiava `UnsafeCell` premenlivo (v čase kompilácie), čo zaručuje, že vlastníme jediný odkaz.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Získava premenlivý ukazovateľ na zalomenú hodnotu.
    /// Rozdiel oproti [`get`] je v tom, že táto funkcia prijíma surový ukazovateľ, čo je užitočné, aby sa zabránilo vytváraniu dočasných odkazov.
    ///
    /// Výsledok je možné prenášať na akýkoľvek ukazovateľ.
    /// Pri prenášaní na `&mut T` sa ubezpečte, že je prístup jedinečný (žiadne aktívne referencie, zmeniteľné alebo nemeniteľné), a zabezpečte, aby pri prenášaní na `&T` neprebiehali žiadne mutácie alebo zmeniteľné aliasy.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Postupná inicializácia `UnsafeCell` vyžaduje `raw_get`, pretože volanie `get` by si vyžadovalo vytvorenie odkazu na neinicializované údaje:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Ukazovateľ môžeme jednoducho presunúť z `UnsafeCell<T>` na `T` kvôli #[repr(transparent)].
        // Toto zneužíva špeciálny stav knižnice libstd, neexistuje žiadna záruka pre užívateľský kód, že to bude fungovať vo verziách kompilátora future!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Vytvorí `UnsafeCell` s hodnotou `Default` pre T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}