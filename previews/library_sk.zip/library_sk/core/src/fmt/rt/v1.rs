//! Toto je interný modul používaný ifmt!beh programu.Tieto štruktúry sa vopred emitujú do statických polí na predkompilovanie formátovacích reťazcov.
//!
//! Tieto definície sú podobné ich ekvivalentom `ct`, ale líšia sa tým, že ich možno staticky prideliť a sú mierne optimalizované za behu programu
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Možné zarovnania, ktoré je možné požadovať ako súčasť smernice o formátovaní.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Označenie, že obsah by mal byť zarovnaný doľava.
    Left,
    /// Označenie, že obsah by mal byť zarovnaný doprava.
    Right,
    /// Označenie, že obsah by mal byť zarovnaný na stred.
    Center,
    /// Nebolo požadované žiadne vyrovnanie.
    Unknown,
}

/// Používa sa v špecifikátoroch [width](https://doc.rust-lang.org/std/fmt/#width) a [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Zadané s doslovným číslom, hodnota sa uloží
    Is(usize),
    /// Zadaný pomocou syntaxí `$` a `*`, uloží index do `args`
    Param(usize),
    /// Nešpecifikované
    Implied,
}