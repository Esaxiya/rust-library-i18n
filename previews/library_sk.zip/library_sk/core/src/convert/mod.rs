//! Traits pre konverzie medzi typmi.
//!
//! traits v tomto module poskytujú spôsob prevodu z jedného typu na iný typ.
//! Každá trait slúži na iný účel:
//!
//! - Implementujte [`AsRef`] trait na lacné konverzie z jedného odkazu na druhý
//! - Implementujte [`AsMut`] trait na lacné konverzie premenlivé na premenlivé
//! - Implementujte [`From`] trait na náročné konverzie medzi hodnotami
//! - Implementujte [`Into`] trait na náročné prevody hodnoty na hodnotu pre typy mimo aktuálneho crate
//! - Modely [`TryFrom`] a [`TryInto`] traits sa správajú ako [`From`] a [`Into`], ale mali by sa implementovať, keď môže zlyhať konverzia.
//!
//! traits v tomto module sa často používajú ako trait bounds pre všeobecné funkcie, takže sú podporované argumenty viacerých typov.Príklady nájdete v dokumentácii ku každému trait.
//!
//! Ako autor knižnice by ste mali vždy uprednostniť implementáciu [`From<T>`][`From`] alebo [`TryFrom<T>`][`TryFrom`] pred [`Into<U>`][`Into`] alebo [`TryInto<U>`][`TryInto`], pretože [`From`] a [`TryFrom`] poskytujú väčšiu flexibilitu a ponúkajú ekvivalentné implementácie [`Into`] alebo [`TryInto`] zadarmo vďaka plošnej implementácii v štandardnej knižnici.
//! Pri zacielení na verziu pred verziou Rust 1.41 bude možno potrebné implementovať [`Into`] alebo [`TryInto`] priamo pri konverzii na typ mimo aktuálny crate.
//!
//! # Všeobecné implementácie
//!
//! - [`AsRef`] a automatická dereferencia [`AsMut`], ak je vnútorný typ odkazom
//! - [" Od`] " <U>pre T` znamená [" Do `]`</u><T><U>pre U`</u>
//! - [`TryFrom`]`<U>pre T` znamená [`TryInto`]`</u><T><U>pre U`</u>
//! - [`From`] a [`Into`] sú reflexné, čo znamená, že všetky typy môžu `into` samy a `from` samy
//!
//! Príklady použitia nájdete v každej trait.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Funkcia identity.
///
/// O tejto funkcii je potrebné si uvedomiť dve veci:
///
/// - Nie vždy to zodpovedá uzáveru ako `|x| x`, pretože uzáver môže donútiť `x` k inému typu.
///
/// - Presunie vstup `x` odovzdaný funkcii.
///
/// Aj keď by sa mohlo zdať čudné mať funkciu, ktorá vráti iba vstup, existuje niekoľko zaujímavých využití.
///
///
/// # Examples
///
/// Používanie `identity` na nič nerobenie v slede ďalších, zaujímavých, funkcií:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Predstierajme, že pridanie jedného je zaujímavá funkcia.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Použitie `identity` ako základného prípadu "do nothing" v podmienenom stave:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Robte ďalšie zaujímavé veci ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Používanie `identity` na udržanie variantov `Some` iterátora `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Používa sa na lacnú konverziu medzi referenciami.
///
/// Tento trait je podobný [`AsMut`], ktorý sa používa na konverziu medzi premenlivými referenciami.
/// Ak potrebujete vykonať nákladnú konverziu, je lepšie implementovať [`From`] s typom `&T` alebo napísať vlastnú funkciu.
///
/// `AsRef` má rovnaký podpis ako [`Borrow`], ale [`Borrow`] sa líši v niekoľkých aspektoch:
///
/// - Na rozdiel od `AsRef` má [`Borrow`] plošný impl pre akýkoľvek `T` a je možné ho použiť na akceptovanie referencie alebo hodnoty.
/// - [`Borrow`] tiež vyžaduje, aby hodnoty [`Hash`], [`Eq`] a [`Ord`] za vypožičanú hodnotu boli ekvivalentné hodnote požičanej hodnoty.
/// Z tohto dôvodu, ak si chcete požičať iba jedno pole štruktúry, môžete implementovať `AsRef`, ale nie [`Borrow`].
///
/// **Note: Táto trait nesmie zlyhať **.Ak konverzia môže zlyhať, použite špeciálnu metódu, ktorá vráti [`Option<T>`] alebo [`Result<T, E>`].
///
/// # Všeobecné implementácie
///
/// - `AsRef` automatické dereferencie, ak je vnútorným typom referencia alebo premenlivá referencia (napr .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Použitím trait bounds môžeme prijímať argumenty rôznych typov, pokiaľ ich možno previesť na zadaný typ `T`.
///
/// Napríklad: Vytvorením všeobecnej funkcie, ktorá zaberá `AsRef<str>`, vyjadrujeme, že chceme prijať ako argument všetky odkazy, ktoré je možné previesť na [`&str`].
/// Pretože [`String`] aj [`&str`] implementujú `AsRef<str>`, môžeme ako vstupný argument akceptovať obidve.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Vykoná prevod.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Používa sa na lacnú konverziu referenčných súborov, ktoré sa dajú meniť.
///
/// Tento trait je podobný [`AsRef`], ale používa sa na konverziu medzi premenlivými referenciami.
/// Ak potrebujete vykonať nákladnú konverziu, je lepšie implementovať [`From`] s typom `&mut T` alebo napísať vlastnú funkciu.
///
/// **Note: Táto trait nesmie zlyhať **.Ak konverzia môže zlyhať, použite špeciálnu metódu, ktorá vráti [`Option<T>`] alebo [`Result<T, E>`].
///
/// # Všeobecné implementácie
///
/// - `AsMut` automatické dereferencie, ak je vnútorný typ premenlivý odkaz (napr .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ak použijeme `AsMut` ako trait bound pre všeobecnú funkciu, môžeme prijať všetky premenlivé odkazy, ktoré je možné previesť na typ `&mut T`.
/// Pretože [`Box<T>`] implementuje `AsMut<T>`, môžeme napísať funkciu `add_one`, ktorá vezme všetky argumenty, ktoré je možné previesť na `&mut u64`.
/// Pretože [`Box<T>`] implementuje `AsMut<T>`, `add_one` prijíma aj argumenty typu `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Vykoná prevod.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Konverzia hodnoty na hodnotu, ktorá spotrebuje vstupnú hodnotu.Opak [`From`].
///
/// Jeden by sa mal vyhnúť implementácii [`Into`] a namiesto toho implementovať [`From`].
/// Implementácia [`From`] automaticky poskytuje implementáciu [`Into`] vďaka plošnej implementácii v štandardnej knižnici.
///
/// Pri zadávaní trait bounds na všeobecnej funkcii uprednostňujte použitie [`Into`] pred [`From`], aby ste zaistili, že je možné použiť aj typy, ktoré implementujú iba [`Into`].
///
/// **Note: Táto trait nesmie zlyhať **.Ak konverzia môže zlyhať, použite [`TryInto`].
///
/// # Všeobecné implementácie
///
/// - [" Od`]`<T>pre U` znamená `Into<U> for T`
/// - [`Into`] je reflexná, čo znamená, že je implementovaná `Into<T> for T`
///
/// # Implementácia [`Into`] na konverzie na externé typy v starých verziách Rust
///
/// Pred rokom Rust 1.41, ak typ cieľa nebol súčasťou aktuálneho crate, ste nemohli implementovať [`From`] priamo.
/// Vezmite si napríklad tento kód:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Toto sa nebude dať kompilovať v starších verziách jazyka, pretože pravidlá osirovania Rust bývali trochu prísnejšie.
/// Ak to chcete obísť, môžete implementovať [`Into`] priamo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Je dôležité si uvedomiť, že [`Into`] neposkytuje implementáciu [`From`] (ako to robí [`From`] pri [`Into`]).
/// Preto by ste sa mali vždy pokúsiť implementovať [`From`] a potom prejsť späť na [`Into`], ak [`From`] nemožno implementovať.
///
/// # Examples
///
/// [`String`] implementuje [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Aby sme vyjadrili, že chceme, aby generická funkcia brala všetky argumenty, ktoré je možné previesť na zadaný typ `T`, môžeme použiť trait bound parametra [`Into`]`<T>".
///
/// Napríklad: Funkcia `is_hello` preberá všetky argumenty, ktoré možno previesť na [`Vec`]`<<[[u8`] `>>.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Vykoná prevod.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Používa sa na uskutočňovanie prevodov hodnoty na hodnotu pri spotrebovaní vstupnej hodnoty.Je to prevrátená hodnota [`Into`].
///
/// Jeden by mal vždy uprednostňovať implementáciu `From` pred [`Into`], pretože implementácia `From` automaticky poskytuje implementáciu [`Into`] vďaka plošnej implementácii v štandardnej knižnici.
///
///
/// [`Into`] implementujte iba pri zacielení na verziu pred Rust 1.41 a prevedení na typ mimo aktuálneho crate.
/// `From` nebol schopný vykonať tieto typy konverzií v starších verziách z dôvodu pravidiel osirotenia Rust.
/// Ďalšie informácie nájdete v časti [`Into`].
///
/// Pri zadávaní trait bounds pri všeobecnej funkcii uprednostnite použitie [`Into`] pred použitím `From`.
/// Týmto spôsobom sa dajú ako argumenty použiť aj typy, ktoré priamo implementujú [`Into`].
///
/// `From` je tiež veľmi užitočný pri vykonávaní chýb.Pri konštrukcii funkcie, ktorá je schopná zlyhania, bude návratový typ spravidla vo formáte `Result<T, E>`.
/// `From` trait zjednodušuje spracovanie chýb tým, že umožňuje funkcii vrátiť jeden typ chyby, ktorý zapuzdruje viac typov chýb.Ďalšie informácie nájdete v sekcii "Examples" a [the book][book].
///
/// **Note: Táto trait nesmie zlyhať **.Ak konverzia môže zlyhať, použite [`TryFrom`].
///
/// # Všeobecné implementácie
///
/// - `From<T> for U` znamená [" do`]` <U>pre</u> T`
/// - `From` je reflexná, čo znamená, že je implementovaná `From<T> for T`
///
/// # Examples
///
/// [`String`] implementuje `From<&str>`:
///
/// Explicitná konverzia z `&str` na String sa vykonáva nasledovne:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Pri spracovávaní chýb je často užitočné implementovať `From` pre váš typ chyby.
/// Prevodom základných typov chýb na náš vlastný vlastný typ chyby, ktorý zapuzdruje základný typ chyby, môžeme vrátiť jeden typ chyby bez straty informácií o základnej príčine.
/// Operátor '?' automaticky prevedie základný typ chyby na náš vlastný typ chyby zavolaním `Into<CliError>::into`, ktorý sa automaticky poskytne pri implementácii `From`.
/// Kompilátor potom odvodí, ktorá implementácia `Into` sa má použiť.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Vykoná prevod.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Pokus o konverziu, ktorý spotrebuje `self`, čo môže, ale nemusí byť drahé.
///
/// Autori knižnice by zvyčajne nemali priamo implementovať tento trait, ale mali by uprednostniť implementáciu [`TryFrom`] trait, ktorá ponúka väčšiu flexibilitu a poskytuje ekvivalentnú implementáciu `TryInto` zadarmo vďaka plošnej implementácii v štandardnej knižnici.
/// Viac informácií nájdete v dokumentácii k [`Into`].
///
/// # Implementuje sa `TryInto`
///
/// Toto podlieha rovnakým obmedzeniam a úvahám ako implementácia [`Into`], podrobnosti nájdete tu.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Typ vrátený v prípade chyby konverzie.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Vykoná prevod.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Jednoduché a bezpečné konverzie typu, ktoré môžu za určitých okolností kontrolovane zlyhať.Je to prevrátená hodnota [`TryInto`].
///
/// Je to užitočné, keď robíte prevod typu, ktorý môže triviálne uspieť, ale môže vyžadovať aj špeciálne zaobchádzanie.
/// Napríklad neexistuje žiadny spôsob, ako prevádzať [`i64`] na [`i32`] pomocou [`From`] trait, pretože [`i64`] môže obsahovať hodnotu, ktorú [`i32`] nemôže predstavovať, a tak by konverzia stratila dáta.
///
/// Toto by sa dalo vyriešiť skrátením [`i64`] na [`i32`] (čím sa v podstate získa hodnota [" i64`] modulo [`i32::MAX`]) alebo jednoduchým vrátením [`i32::MAX`] alebo iným spôsobom.
/// [`From`] trait je určený na dokonalé konverzie, takže `TryFrom` trait informuje programátora, keď sa môže prevod typu pokaziť, a nechá ich rozhodnúť, ako s nimi naložiť.
///
/// # Všeobecné implementácie
///
/// - `TryFrom<T> for U` implikuje [`TryInto`]`<U>pre</u> T`
/// - [`try_from`] je reflexné, čo znamená, že `TryFrom<T> for T` je implementovaný a nemôže zlyhať-pridružený typ `Error` pre volanie `T::try_from()` na hodnote typu `T` je [`Infallible`].
/// Keď je typ [`!`] stabilizovaný, [`Infallible`] a [`!`] budú rovnocenné.
///
/// `TryFrom<T>` možno implementovať nasledovne:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Ako je popísané, [`i32`] implementuje program `TryFrom <` [i64`]`>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Potichu skráti `big_number`, vyžaduje zistenie a spracovanie skrátenia po skutočnosti.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Vráti chybu, pretože `big_number` je príliš veľký na to, aby sa zmestil do `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Vráti `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Typ vrátený v prípade chyby konverzie.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Vykoná prevod.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERICKÉ IMPLY
////////////////////////////////////////////////////////////////////////////////

// Ako sa dvíha nad&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Ako výťahy nad &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): nahraďte vyššie uvedené impls pre&/&mut za nasledujúci všeobecnejší:
// // Ako výťahy nad Derefom
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut sa zdvihne nad &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): nahradiť vyššie uvedený impl pre &mut nasledujúcim všeobecnejším:
// // AsMut sa dvíha nad DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Sized> AsMut <U>for D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Z implikuje do
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Od (a teda do) je reflexné
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Poznámka o stabilite:** Tento impl zatiaľ neexistuje, ale sme "reserving space", aby sme ho pridali do future.
/// Podrobnosti nájdete v časti [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): namiesto toho urobte principiálnu opravu.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom znamená TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Neomylné konverzie sú sémanticky ekvivalentné k omylovým konverziám s neobývaným typom chyby.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETÓNOVÉ IMPLY
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// TYP CHYBY BEZ CHYBY
////////////////////////////////////////////////////////////////////////////////

/// Typ chyby pre chyby, ktoré sa nikdy nemôžu stať.
///
/// Pretože toto enum nemá žiadny variant, hodnota tohto typu v skutočnosti nikdy nemôže existovať.
/// To môže byť užitočné pre všeobecné API, ktoré používajú [`Result`] a parametrizujú typ chyby, aby naznačili, že výsledkom je vždy [`Ok`].
///
/// Napríklad [`TryFrom`] trait (konverzia, ktorá vracia [`Result`]) má plošnú implementáciu pre všetky typy, kde existuje spätná implementácia [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Kompatibilita so Future
///
/// Toto enum má rovnakú rolu ako [the `!`“never”type][never], ktorý je v tejto verzii Rust nestabilný.
/// Keď je `!` stabilizovaný, plánujeme z neho urobiť `Infallible` alias typu:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... a nakoniec zastarať `Infallible`.
///
/// Existuje však jeden prípad, keď je možné použiť syntax `!` skôr, ako sa stabilizuje `!` ako plnohodnotný typ: v pozícii návratového typu funkcie.
/// Konkrétne sú možné implementácie pre dva rôzne typy ukazovateľov funkcií:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Pretože `Infallible` je enum, tento kód je platný.
/// Keď sa však `Infallible` stane aliasom pre never type, dva " impl` sa začnú prekrývať, a preto budú pravidlami súdržnosti jazyka trait zakázané.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}