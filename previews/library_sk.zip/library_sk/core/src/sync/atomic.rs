//! Atómové typy
//!
//! Atómové typy poskytujú primitívnu komunikáciu zdieľanej pamäte medzi vláknami a sú stavebnými kameňmi ďalších súbežných typov.
//!
//! Tento modul definuje atómové verzie vybraného počtu primitívnych typov vrátane [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] atď.
//! Atómové typy predstavujú operácie, ktoré pri správnom použití synchronizujú aktualizácie medzi vláknami.
//!
//! Každá metóda má [`Ordering`], čo predstavuje silu pamäťovej bariéry pre túto operáciu.Toto usporiadanie je rovnaké ako v prípade modelu [C++20 atomic orderings][1].Viac informácií nájdete na [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atómové premenné je bezpečné zdieľať medzi vláknami (implementujú [`Sync`]), samy však neposkytujú mechanizmus zdieľania a riadia sa [threading model](../../../std/thread/index.html#the-threading-model) zo Rust.
//!
//! Najbežnejším spôsobom zdieľania atómovej premennej je vloženie do [`Arc`][arc] (zdieľaný ukazovateľ počítaný pomocou atómovej referencie).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atómové typy môžu byť uložené v statických premenných inicializovaných pomocou konštantných inicializátorov ako [`AtomicBool::new`].Atómová statika sa často používa na lenivú globálnu inicializáciu.
//!
//! # Portability
//!
//! Je zaručené, že všetky atómové typy v tomto module sú [lock-free], ak sú k dispozícii.To znamená, že interne nezískavajú globálny mutex.Atómové typy a operácie nie sú zaručene bez čakania.
//! To znamená, že operácie ako `fetch_or` môžu byť implementované pomocou slučky porovnania a výmeny.
//!
//! Atómové operácie môžu byť implementované na inštrukčnej vrstve s atómami väčšej veľkosti.Napríklad niektoré platformy používajú na implementáciu `AtomicI8` štvorbajtové atómové pokyny.
//! Upozorňujeme, že táto emulácia by nemala mať vplyv na správnosť kódu, je treba si ju len uvedomiť.
//!
//! Atómové typy v tomto module nemusia byť dostupné na všetkých platformách.Atómové typy sú tu všeobecne dostupné a dá sa na ne všeobecne spoľahnúť.Niektoré pozoruhodné výnimky sú:
//!
//! * PowerPC a platformy MIPS s 32-bitovými ukazovateľmi nemajú typy `AtomicU64` alebo `AtomicI64`.
//! * ARM platformy ako `armv5te`, ktoré nie sú pre Linux, poskytujú iba operácie `load` a `store` a nepodporujú operácie porovnania a výmeny (CAS), napríklad `swap`, `fetch_add` atď.
//! Navyše na Linux sú tieto operácie CAS implementované prostredníctvom [operating system support], čo môže byť spojené s výkonnostným trestom.
//! * ARM ciele s `thumbv6m` poskytujú iba operácie `load` a `store` a nepodporujú operácie porovnania a výmeny (CAS), napríklad `swap`, `fetch_add` atď.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Upozorňujeme, že možno pridať platformy future, ktoré tiež nepodporujú niektoré atómové operácie.Maximálne prenosný kód si bude chcieť dať pozor na to, ktoré atómové typy sa používajú.
//! `AtomicUsize` a `AtomicIsize` sú všeobecne najprenosnejšie, ale aj tak nie sú k dispozícii všade.
//! Knižnica `std` vyžaduje atómovú energiu ukazovateľa, hoci `core` nie.
//!
//! V súčasnosti budete musieť použiť `#[cfg(target_arch)]` predovšetkým na podmienečné kompilácie v kóde s atómovými kódmi.K dispozícii je tiež nestabilný model `#[cfg(target_has_atomic)]`, ktorý môže byť v modeli future stabilizovaný.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Jednoduchý spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Počkajte, kým druhý závit neuvoľní zámok
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Udržujte globálny počet živých vlákien:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Logický typ, ktorý je možné bezpečne zdieľať medzi vláknami.
///
/// Tento typ má v pamäti rovnaké zastúpenie ako [`bool`].
///
/// **Poznámka**: Tento typ je k dispozícii iba na platformách, ktoré podporujú atómové zaťaženie a obchody `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Vytvorí `AtomicBool` inicializovaný na `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Odoslanie je pre AtomicBool implicitne implementované.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Nespracovaný typ ukazovateľa, ktorý je možné bezpečne zdieľať medzi vláknami.
///
/// Tento typ má v pamäti rovnaké zastúpenie ako `*mut T`.
///
/// **Poznámka**: Tento typ je k dispozícii iba na platformách, ktoré podporujú atómovú záťaž a ukladajú ukazovatele.
/// Jeho veľkosť závisí od veľkosti cieľového ukazovateľa.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Vytvorí nulovú hodnotu `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Usporiadanie atómovej pamäte
///
/// Poradie pamätí určuje spôsob, akým atómové operácie synchronizujú pamäť.
/// V najslabšom modeli [`Ordering::Relaxed`] sa synchronizuje iba pamäť priamo dotknutá operáciou.
/// Na druhej strane dvojica operácií [`Ordering::SeqCst`] typu store-load synchronizuje inú pamäť, pričom navyše zachováva celkové poradie takýchto operácií vo všetkých vláknach.
///
///
/// Usporiadania pamätí Rust sú [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Viac informácií nájdete na [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Žiadne obmedzenia týkajúce sa objednávania, iba atómové operácie.
    ///
    /// Zodpovedá [`memory_order_relaxed`] v C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Keď sa spojí s obchodom, všetky predchádzajúce operácie sa zoradia pred načítaním tejto hodnoty pri objednávaní [`Acquire`] (alebo silnejšom).
    ///
    /// Najmä všetky predchádzajúce zápisy sa stanú viditeľnými pre všetky vlákna, ktoré vykonávajú [`Acquire`] (alebo silnejšie) načítanie tejto hodnoty.
    ///
    /// Všimnite si, že použitie tohto objednávky pre operáciu, ktorá kombinuje načítanie a ukladanie, vedie k operácii načítania [`Relaxed`]!
    ///
    /// Toto objednávanie je použiteľné iba pre operácie, ktoré môžu vykonať ukladanie.
    ///
    /// Zodpovedá [`memory_order_release`] v C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Ak je v spojení s načítaním, ak bola načítaná hodnota zapísaná operáciou obchodu s objednávaním [`Release`] (alebo silnejším), potom sa všetky nasledujúce operácie zoradia až po tomto obchode.
    /// Najmä všetky nasledujúce načítania uvidia údaje napísané pred obchodom.
    ///
    /// Všimnite si, že použitie tohto objednávky pre operáciu, ktorá kombinuje načítanie a ukladanie, vedie k operácii ukladania [`Relaxed`]!
    ///
    /// Toto objednávanie je použiteľné iba pre operácie, ktoré môžu vykonať načítanie.
    ///
    /// Zodpovedá [`memory_order_acquire`] v C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Má spoločné účinky ako [`Acquire`], tak aj [`Release`]:
    /// Pre zaťaženie používa [`Acquire`] objednávanie.Pre obchody používa objednávanie [`Release`].
    ///
    /// Všimnite si, že v prípade `compare_and_swap` je možné, že operácia nakoniec nevykoná žiadny obchod, a preto má iba [`Acquire`] objednávanie.
    ///
    /// `AcqRel` však nikdy nebude vykonávať prístupy [`Relaxed`].
    ///
    /// Toto objednávanie je použiteľné iba pre operácie, ktoré kombinujú náklady aj sklady.
    ///
    /// Zodpovedá [`memory_order_acq_rel`] v C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Rovnako ako [" Získať`]/[" Vydať`]/[" AcqRel`](pre operácie načítania, ukladania a načítania s ukladaním) s dodatočnou zárukou, že všetky vlákna uvidia všetky postupne konzistentné operácie v rovnakom poradí .
    ///
    ///
    /// Zodpovedá [`memory_order_seq_cst`] v C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] inicializovaný na `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Vytvorí nový `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Vráti premenlivý odkaz na podkladovú [`bool`].
    ///
    /// Je to bezpečné, pretože zmeniteľný odkaz zaručuje, že žiadne ďalšie vlákna súčasne nepristupujú k atómovým údajom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // BEZPEČNOSŤ: meniteľný odkaz zaručuje jedinečné vlastníctvo.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Získajte atómový prístup k `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // BEZPEČNOSŤ: meniteľný odkaz zaručuje jedinečné vlastníctvo a
        // zarovnanie `bool` aj `Self` je 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Spotrebuje atómovú energiu a vráti obsiahnutú hodnotu.
    ///
    /// Je to bezpečné, pretože odovzdanie hodnoty `self` hodnotou zaručuje, že žiadne ďalšie vlákna súčasne nepristupujú k atómovým údajom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Načíta hodnotu z bool.
    ///
    /// `load` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.
    /// Možné hodnoty sú [`SeqCst`], [`Acquire`] a [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ak `order` je [`Release`] alebo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // BEZPEČNOSŤ: akémukoľvek prenosu dát zabráni atómová prirodzenosť a nezrovnalosti
        // vložený ukazovateľ je platný, pretože sme ho dostali z referencie.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Uloží hodnotu do bool.
    ///
    /// `store` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.
    /// Možné hodnoty sú [`SeqCst`], [`Release`] a [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ak `order` je [`Acquire`] alebo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // BEZPEČNOSŤ: akémukoľvek prenosu dát zabráni atómová prirodzenosť a nezrovnalosti
        // vložený ukazovateľ je platný, pretože sme ho dostali z referencie.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Uloží hodnotu do bool a vráti predchádzajúcu hodnotu.
    ///
    /// `swap` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
    /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
    ///
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Uloží hodnotu do [`bool`], ak je aktuálna hodnota rovnaká ako hodnota `current`.
    ///
    /// Návratová hodnota je vždy predchádzajúca hodnota.Ak sa rovná `current`, bola hodnota aktualizovaná.
    ///
    /// `compare_and_swap` tiež vezme argument [`Ordering`], ktorý popisuje zoradenie pamäte tejto operácie.
    /// Všimnite si, že aj keď používate [`AcqRel`], operácia môže zlyhať, a preto stačí vykonať načítanie `Acquire`, ale nebude mať sémantiku `Release`.
    /// Použitie [`Acquire`] robí z úložiska súčasť tejto operácie [`Relaxed`], ak sa to stane, a použitie [`Release`] urobí načítanú časť [`Relaxed`].
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Prebieha migrácia na `compare_exchange` a `compare_exchange_weak`
    ///
    /// `compare_and_swap` je ekvivalentná s `compare_exchange` s nasledujúcim mapovaním pre usporiadanie pamäte:
    ///
    /// Pôvodný |Úspech |Zlyhanie
    /// -------- | ------- | -------
    /// Uvoľnená |Uvoľnená |Uvoľnené Získať |Získať |Získať vydanieUvoľnenie |Uvoľnený AcqRel |AcqRel |Získať SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` je povolené falošne zlyhať, aj keď je porovnanie úspešné, čo umožňuje kompilátoru vygenerovať lepší kód zostavy, keď sa porovnanie a zámena použijú v slučke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Uloží hodnotu do [`bool`], ak je aktuálna hodnota rovnaká ako hodnota `current`.
    ///
    /// Návratová hodnota je výsledok označujúci, či bola nová hodnota napísaná a obsahuje predchádzajúcu hodnotu.
    /// Pri úspechu je táto hodnota zaručene rovná `current`.
    ///
    /// `compare_exchange` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
    /// `success` popisuje požadované zoradenie pre operáciu čítania, úpravy, zápisu, ktorá sa uskutoční, ak bude porovnanie s `current` úspešné.
    /// `failure` popisuje požadované zoradenie pre operáciu načítania, ktorá sa uskutoční pri zlyhaní porovnania.
    /// Použitie [`Acquire`] ako úspešného objednania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] z úspešného zavedenia [`Relaxed`].
    ///
    /// Poruchové poradie môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Uloží hodnotu do [`bool`], ak je aktuálna hodnota rovnaká ako hodnota `current`.
    ///
    /// Na rozdiel od [`AtomicBool::compare_exchange`] môže táto funkcia falošne zlyhať, aj keď je porovnanie úspešné, čo môže mať na niektorých platformách za následok efektívnejší kód.
    ///
    /// Návratová hodnota je výsledok označujúci, či bola nová hodnota napísaná a obsahuje predchádzajúcu hodnotu.
    ///
    /// `compare_exchange_weak` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
    /// `success` popisuje požadované zoradenie pre operáciu čítania, úpravy, zápisu, ktorá sa uskutoční, ak bude porovnanie s `current` úspešné.
    /// `failure` popisuje požadované zoradenie pre operáciu načítania, ktorá sa uskutoční pri zlyhaní porovnania.
    /// Použitie [`Acquire`] ako úspešného objednania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] z úspešného zavedenia [`Relaxed`].
    /// Poruchové poradie môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logická "and" s boolovskou hodnotou.
    ///
    /// Vykoná logickú operáciu "and" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
    ///
    /// Vráti predchádzajúcu hodnotu.
    ///
    /// `fetch_and` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
    /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
    ///
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logická "nand" s boolovskou hodnotou.
    ///
    /// Vykoná logickú operáciu "nand" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
    ///
    /// Vráti predchádzajúcu hodnotu.
    ///
    /// `fetch_nand` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
    /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
    ///
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Tu nemôžeme použiť atomic_nand, pretože to môže mať za následok bool s neplatnou hodnotou.
        // Stáva sa to preto, lebo atómová operácia sa vykonáva s 8-bitovým celým číslom interne, čo by nastavovalo horných 7 bitov.
        //
        // Namiesto toho teda použijeme fetch_xor alebo swap.
        if val {
            // ! (x&true)== !x Musíme obrátiť bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Musíme nastaviť bool na hodnotu true.
            //
            self.swap(true, order)
        }
    }

    /// Logická "or" s boolovskou hodnotou.
    ///
    /// Vykoná logickú operáciu "or" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
    ///
    /// Vráti predchádzajúcu hodnotu.
    ///
    /// `fetch_or` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
    /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
    ///
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logická "xor" s boolovskou hodnotou.
    ///
    /// Vykoná logickú operáciu "xor" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
    ///
    /// Vráti predchádzajúcu hodnotu.
    ///
    /// `fetch_xor` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
    /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
    ///
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Vráti premenlivý ukazovateľ na podkladovú [`bool`].
    ///
    /// Neanómové čítanie a zápis na výslednom celom čísle môže byť dátovým behom.
    /// Táto metóda je väčšinou užitočná pre FFI, kde podpis funkcie môže používať `*mut bool` namiesto `&AtomicBool`.
    ///
    /// Vrátenie ukazovateľa `*mut` zo zdieľaného odkazu na túto atómovú energiu je bezpečné, pretože atómové typy pracujú s vnútornou premenlivosťou.
    /// Všetky úpravy atómu menia hodnotu prostredníctvom zdieľaného odkazu a môžu tak robiť bezpečne, pokiaľ používajú atómové operácie.
    /// Akékoľvek použitie vráteného surového ukazovateľa vyžaduje blok `unsafe` a stále musí dodržiavať rovnaké obmedzenie: operácie na ňom musia byť atómové.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Načíta hodnotu a použije na ňu funkciu, ktorá vráti voliteľnú novú hodnotu.Vráti `Result` z `Ok(previous_value)`, ak funkcia vrátila `Some(_)`, inak `Err(previous_value)`.
    ///
    /// Note: To môže funkciu volať viackrát, ak bola medzitým hodnota zmenená z iných vlákien, pokiaľ funkcia vracia `Some(_)`, ale na uloženú hodnotu bude funkcia použitá iba raz.
    ///
    ///
    /// `fetch_update` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
    /// Prvý popisuje požadované poradie, keď je operácia nakoniec úspešná, druhý popisuje požadované poradie pre načítanie.
    /// Zodpovedajú poradiu úspešnosti a neúspechu modelu [`AtomicBool::compare_exchange`].
    ///
    /// Použitie [`Acquire`] ako úspešného objednávania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] urobí konečné úspešné načítanie [`Relaxed`].
    /// Objednávanie načítania (failed) môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Vytvorí nový `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Vráti premenlivý odkaz na podkladový ukazovateľ.
    ///
    /// Je to bezpečné, pretože zmeniteľný odkaz zaručuje, že žiadne ďalšie vlákna súčasne nepristupujú k atómovým údajom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Získajte atómový prístup k ukazovateľu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - premenlivá referencia zaručuje jedinečné vlastníctvo.
        //  - zarovnanie `*mut T` a `Self` je rovnaké na všetkých platformách podporovaných rust, ako je overené vyššie.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Spotrebuje atómovú energiu a vráti obsiahnutú hodnotu.
    ///
    /// Je to bezpečné, pretože odovzdanie hodnoty `self` hodnotou zaručuje, že žiadne ďalšie vlákna súčasne nepristupujú k atómovým údajom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Načíta hodnotu z ukazovateľa.
    ///
    /// `load` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.
    /// Možné hodnoty sú [`SeqCst`], [`Acquire`] a [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ak `order` je [`Release`] alebo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Ukladá hodnotu do ukazovateľa.
    ///
    /// `store` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.
    /// Možné hodnoty sú [`SeqCst`], [`Release`] a [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics, ak `order` je [`Acquire`] alebo [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Uloží hodnotu do ukazovateľa a vráti predchádzajúcu hodnotu.
    ///
    /// `swap` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
    /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
    ///
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na ukazovateľoch.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Uloží hodnotu do ukazovateľa, ak je aktuálna hodnota rovnaká ako hodnota `current`.
    ///
    /// Návratová hodnota je vždy predchádzajúca hodnota.Ak sa rovná `current`, bola hodnota aktualizovaná.
    ///
    /// `compare_and_swap` tiež vezme argument [`Ordering`], ktorý popisuje zoradenie pamäte tejto operácie.
    /// Všimnite si, že aj keď používate [`AcqRel`], operácia môže zlyhať, a preto stačí vykonať načítanie `Acquire`, ale nebude mať sémantiku `Release`.
    /// Použitie [`Acquire`] robí z úložiska súčasť tejto operácie [`Relaxed`], ak sa to stane, a použitie [`Release`] urobí načítanú časť [`Relaxed`].
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na ukazovateľoch.
    ///
    /// # Prebieha migrácia na `compare_exchange` a `compare_exchange_weak`
    ///
    /// `compare_and_swap` je ekvivalentná s `compare_exchange` s nasledujúcim mapovaním pre usporiadanie pamäte:
    ///
    /// Pôvodný |Úspech |Zlyhanie
    /// -------- | ------- | -------
    /// Uvoľnená |Uvoľnená |Uvoľnené Získať |Získať |Získať vydanieUvoľnenie |Uvoľnený AcqRel |AcqRel |Získať SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` je povolené falošne zlyhať, aj keď je porovnanie úspešné, čo umožňuje kompilátoru vygenerovať lepší kód zostavy, keď sa porovnanie a zámena použijú v slučke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Uloží hodnotu do ukazovateľa, ak je aktuálna hodnota rovnaká ako hodnota `current`.
    ///
    /// Návratová hodnota je výsledok označujúci, či bola nová hodnota napísaná a obsahuje predchádzajúcu hodnotu.
    /// Pri úspechu je táto hodnota zaručene rovná `current`.
    ///
    /// `compare_exchange` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
    /// `success` popisuje požadované zoradenie pre operáciu čítania, úpravy, zápisu, ktorá sa uskutoční, ak bude porovnanie s `current` úspešné.
    /// `failure` popisuje požadované zoradenie pre operáciu načítania, ktorá sa uskutoční pri zlyhaní porovnania.
    /// Použitie [`Acquire`] ako úspešného objednania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] z úspešného zavedenia [`Relaxed`].
    ///
    /// Poruchové poradie môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na ukazovateľoch.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Uloží hodnotu do ukazovateľa, ak je aktuálna hodnota rovnaká ako hodnota `current`.
    ///
    /// Na rozdiel od [`AtomicPtr::compare_exchange`] môže táto funkcia falošne zlyhať, aj keď je porovnanie úspešné, čo môže mať na niektorých platformách za následok efektívnejší kód.
    ///
    /// Návratová hodnota je výsledok označujúci, či bola nová hodnota napísaná a obsahuje predchádzajúcu hodnotu.
    ///
    /// `compare_exchange_weak` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
    /// `success` popisuje požadované zoradenie pre operáciu čítania, úpravy, zápisu, ktorá sa uskutoční, ak bude porovnanie s `current` úspešné.
    /// `failure` popisuje požadované zoradenie pre operáciu načítania, ktorá sa uskutoční pri zlyhaní porovnania.
    /// Použitie [`Acquire`] ako úspešného objednania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] z úspešného zavedenia [`Relaxed`].
    /// Poruchové poradie môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na ukazovateľoch.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // BEZPEČNOSŤ: Tento vnútorný je nebezpečný, pretože pracuje na hrubom ukazovateli
        // ale určite vieme, že ukazovateľ je platný (práve sme ho dostali z `UnsafeCell`, ktorý máme ako referenciu) a samotná atómová operácia nám umožňuje bezpečne mutovať obsah `UnsafeCell`.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Načíta hodnotu a použije na ňu funkciu, ktorá vráti voliteľnú novú hodnotu.Vráti `Result` z `Ok(previous_value)`, ak funkcia vrátila `Some(_)`, inak `Err(previous_value)`.
    ///
    /// Note: To môže funkciu volať viackrát, ak bola medzitým hodnota zmenená z iných vlákien, pokiaľ funkcia vracia `Some(_)`, ale na uloženú hodnotu bude funkcia použitá iba raz.
    ///
    ///
    /// `fetch_update` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
    /// Prvý popisuje požadované poradie, keď je operácia nakoniec úspešná, druhý popisuje požadované poradie pre načítanie.
    /// Zodpovedajú poradiu úspešnosti a neúspechu modelu [`AtomicPtr::compare_exchange`].
    ///
    /// Použitie [`Acquire`] ako úspešného objednávania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] urobí konečné úspešné načítanie [`Relaxed`].
    /// Objednávanie načítania (failed) môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
    ///
    /// **Note:** Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na ukazovateľoch.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Skonvertuje `bool` na `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Toto makro sa nakoniec na niektorých architektúrach nepoužíva.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Celé číslo typu, ktoré je možné bezpečne zdieľať medzi vláknami.
        ///
        /// Tento typ má v pamäti rovnaké zastúpenie ako podkladový celočíselný typ, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Viac informácií o rozdieloch medzi atómovými a neatomovými typmi, ako aj informácie o prenosnosti tohto typu nájdete v dokumente [module-level documentation].
        ///
        ///
        /// **Note:** Tento typ je k dispozícii iba na platformách, ktoré podporujú atómové zaťaženie a sklady [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Atómové celé číslo inicializované na `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Odoslanie je implicitne implementované.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Vytvorí nové atómové celé číslo.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Vráti premenlivý odkaz na príslušné celé číslo.
            ///
            /// Je to bezpečné, pretože zmeniteľný odkaz zaručuje, že žiadne ďalšie vlákna súčasne nepristupujú k atómovým údajom.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// nech mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - premenlivá referencia zaručuje jedinečné vlastníctvo.
                //  - zarovnanie `$int_type` a `Self` je rovnaké, ako sľubuje $cfg_align a overuje sa vyššie.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Spotrebuje atómovú energiu a vráti obsiahnutú hodnotu.
            ///
            /// Je to bezpečné, pretože odovzdanie hodnoty `self` hodnotou zaručuje, že žiadne ďalšie vlákna súčasne nepristupujú k atómovým údajom.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Načíta hodnotu z atómového celého čísla.
            ///
            /// `load` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.
            /// Možné hodnoty sú [`SeqCst`], [`Acquire`] a [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ak `order` je [`Release`] alebo [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Ukladá hodnotu do atómového celého čísla.
            ///
            /// `store` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.
            ///  Možné hodnoty sú [`SeqCst`], [`Release`] a [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics, ak `order` je [`Acquire`] alebo [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Uloží hodnotu do atómového celého čísla a vráti predchádzajúcu hodnotu.
            ///
            /// `swap` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Uloží hodnotu do atómového celého čísla, ak je aktuálna hodnota rovnaká ako hodnota `current`.
            ///
            /// Návratová hodnota je vždy predchádzajúca hodnota.Ak sa rovná `current`, bola hodnota aktualizovaná.
            ///
            /// `compare_and_swap` tiež vezme argument [`Ordering`], ktorý popisuje zoradenie pamäte tejto operácie.
            /// Všimnite si, že aj keď používate [`AcqRel`], operácia môže zlyhať, a preto stačí vykonať načítanie `Acquire`, ale nebude mať sémantiku `Release`.
            ///
            /// Použitie [`Acquire`] robí z úložiska súčasť tejto operácie [`Relaxed`], ak sa to stane, a použitie [`Release`] urobí načítanú časť [`Relaxed`].
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Prebieha migrácia na `compare_exchange` a `compare_exchange_weak`
            ///
            /// `compare_and_swap` je ekvivalentná s `compare_exchange` s nasledujúcim mapovaním pre usporiadanie pamäte:
            ///
            /// Pôvodný |Úspech |Zlyhanie
            /// -------- | ------- | -------
            /// Uvoľnená |Uvoľnená |Uvoľnené Získať |Získať |Získať vydanieUvoľnenie |Uvoľnený AcqRel |AcqRel |Získať SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` je povolené falošne zlyhať, aj keď je porovnanie úspešné, čo umožňuje kompilátoru vygenerovať lepší kód zostavy, keď sa porovnanie a zámena použijú v slučke.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Uloží hodnotu do atómového celého čísla, ak je aktuálna hodnota rovnaká ako hodnota `current`.
            ///
            /// Návratová hodnota je výsledok označujúci, či bola nová hodnota napísaná a obsahuje predchádzajúcu hodnotu.
            /// Pri úspechu je táto hodnota zaručene rovná `current`.
            ///
            /// `compare_exchange` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
            /// `success` popisuje požadované zoradenie pre operáciu čítania, úpravy, zápisu, ktorá sa uskutoční, ak bude porovnanie s `current` úspešné.
            /// `failure` popisuje požadované zoradenie pre operáciu načítania, ktorá sa uskutoční pri zlyhaní porovnania.
            /// Použitie [`Acquire`] ako úspešného objednania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] z úspešného zavedenia [`Relaxed`].
            ///
            /// Poruchové poradie môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Uloží hodnotu do atómového celého čísla, ak je aktuálna hodnota rovnaká ako hodnota `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// tejto funkcii je dovolené falošne zlyhať, aj keď je porovnanie úspešné, čo môže mať na niektorých platformách za následok efektívnejší kód.
            /// Návratová hodnota je výsledok označujúci, či bola nová hodnota napísaná a obsahuje predchádzajúcu hodnotu.
            ///
            /// `compare_exchange_weak` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
            /// `success` popisuje požadované zoradenie pre operáciu čítania, úpravy, zápisu, ktorá sa uskutoční, ak bude porovnanie s `current` úspešné.
            /// `failure` popisuje požadované zoradenie pre operáciu načítania, ktorá sa uskutoční pri zlyhaní porovnania.
            /// Použitie [`Acquire`] ako úspešného objednania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] z úspešného zavedenia [`Relaxed`].
            ///
            /// Poruchové poradie môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// nech je mut starý= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     zápas val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Pridá k aktuálnej hodnote a vráti predchádzajúcu hodnotu.
            ///
            /// Táto operácia sa zalomí pri pretečení.
            ///
            /// `fetch_add` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Odpočíta od aktuálnej hodnoty a vráti predchádzajúcu hodnotu.
            ///
            /// Táto operácia sa zalomí pri pretečení.
            ///
            /// `fetch_sub` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitová "and" s aktuálnou hodnotou.
            ///
            /// Vykoná bitovú operáciu "and" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
            ///
            /// Vráti predchádzajúcu hodnotu.
            ///
            /// `fetch_and` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitová "nand" s aktuálnou hodnotou.
            ///
            /// Vykoná bitovú operáciu "nand" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
            ///
            /// Vráti predchádzajúcu hodnotu.
            ///
            /// `fetch_nand` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13 a 0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitová "or" s aktuálnou hodnotou.
            ///
            /// Vykoná bitovú operáciu "or" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
            ///
            /// Vráti predchádzajúcu hodnotu.
            ///
            /// `fetch_or` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitová "xor" s aktuálnou hodnotou.
            ///
            /// Vykoná bitovú operáciu "xor" s aktuálnou hodnotou a argumentom `val` a nastaví novú hodnotu na výsledok.
            ///
            /// Vráti predchádzajúcu hodnotu.
            ///
            /// `fetch_xor` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Načíta hodnotu a použije na ňu funkciu, ktorá vráti voliteľnú novú hodnotu.Vráti `Result` z `Ok(previous_value)`, ak funkcia vrátila `Some(_)`, inak `Err(previous_value)`.
            ///
            /// Note: To môže funkciu volať viackrát, ak bola medzitým hodnota zmenená z iných vlákien, pokiaľ funkcia vracia `Some(_)`, ale na uloženú hodnotu bude funkcia použitá iba raz.
            ///
            ///
            /// `fetch_update` trvá dva argumenty [`Ordering`] na opísanie zoradenia pamäte tejto operácie.
            /// Prvý popisuje požadované poradie, keď je operácia nakoniec úspešná, druhý popisuje požadované poradie pre načítanie.Zodpovedajú objednávkam na úspech a neúspech
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Použitie [`Acquire`] ako úspešného objednávania robí z obchodu súčasť tejto operácie [`Relaxed`] a použitie [`Release`] urobí konečné úspešné načítanie [`Relaxed`].
            /// Objednávanie načítania (failed) môže byť iba [`SeqCst`], [`Acquire`] alebo [`Relaxed`] a musí byť rovnaké alebo slabšie ako úspešné objednávanie.
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Objednávka: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Objednávka: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maximum s aktuálnou hodnotou.
            ///
            /// Nájde maximum aktuálnej hodnoty a argumentu `val` a nastaví novú hodnotu na výsledok.
            ///
            /// Vráti predchádzajúcu hodnotu.
            ///
            /// `fetch_max` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// nech max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// tvrdiť! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum s aktuálnou hodnotou.
            ///
            /// Nájde minimum aktuálnej hodnoty a argumentu `val` a nastaví novú hodnotu na výsledok.
            ///
            /// Vráti predchádzajúcu hodnotu.
            ///
            /// `fetch_min` vezme argument [`Ordering`], ktorý popisuje usporiadanie pamäte tejto operácie.Všetky režimy objednávania sú možné.
            /// Pamätajte, že použitie [`Acquire`] robí úložnú časť tejto operácie [`Relaxed`] a použitie [`Release`] urobí záťažovú časť [`Relaxed`].
            ///
            ///
            /// **Poznámka**: Táto metóda je k dispozícii iba na platformách, ktoré podporujú atómové operácie na platforme
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=12;
            /// nech min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // BEZPEČNOSŤ: dátovým rasám bráni atómová podstata.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Vráti premenlivý ukazovateľ na príslušné celé číslo.
            ///
            /// Neanómové čítanie a zápis na výslednom celom čísle môže byť dátovým behom.
            /// Táto metóda je väčšinou užitočná pre FFI, kde sa môže podpis funkcie používať
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Vrátenie ukazovateľa `*mut` zo zdieľaného odkazu na túto atómovú energiu je bezpečné, pretože atómové typy pracujú s vnútornou premenlivosťou.
            /// Všetky úpravy atómu menia hodnotu prostredníctvom zdieľaného odkazu a môžu tak robiť bezpečne, pokiaľ používajú atómové operácie.
            /// Akékoľvek použitie vráteného surového ukazovateľa vyžaduje blok `unsafe` a stále musí dodržiavať rovnaké obmedzenie: operácie na ňom musia byť atómové.
            ///
            ///
            /// # Examples
            ///
            /// " ignorovať (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// externý "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // BEZPEČNOSŤ: Bezpečné, pokiaľ je `my_atomic_op` atómová.
            /// nebezpečný {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Vráti predchádzajúcu hodnotu (napríklad __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Vráti predchádzajúcu hodnotu (napríklad __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// vráti maximálnu hodnotu (podpísané porovnanie)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// vráti minimálnu hodnotu (podpísané porovnanie)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// vráti maximálnu hodnotu (nepodpísané porovnanie)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// vráti minimálnu hodnotu (nepodpísané porovnanie)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Atómový plot.
///
/// V závislosti od zadaného poradia oplotenie zabráni kompilátoru a CPU v usporiadaní určitých typov operácií pamäte okolo neho.
/// To vytvára synchronizáciu so vzťahmi medzi ňou a atómovými operáciami alebo plotmi v iných vláknach.
///
/// Ohrada 'A', ktorá má (aspoň) [`Release`] objednávajúcu sémantiku, sa synchronizuje s oplotením 'B' s (aspoň) [`Acquire`] sémantikou, ak a len vtedy, ak existujú operácie X a Y, ktoré fungujú na nejakom atómovom objekte 'M' tak, že A je sekvenované skôr X, Y sa synchronizujú skôr, ako B a Y pozoruje zmenu na M.
/// Toto poskytuje závislosť medzi prípadmi A a B pred vznikom udalosti.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atómové operácie so sémantikou [`Release`] alebo [`Acquire`] sa dajú synchronizovať aj s plotom.
///
/// Plot, ktorý má usporiadanie [`SeqCst`], sa okrem sémantiky [`Acquire`] aj [`Release`] podieľa na globálnom programovom poradí ostatných operácií a/alebo plotov [`SeqCst`].
///
/// Prijíma objednávky [`Acquire`], [`Release`], [`AcqRel`] a [`SeqCst`].
///
/// # Panics
///
/// Panics, ak `order` je [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Primitív vzájomného vylúčenia založený na spinlocku.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Počkajte, kým stará hodnota nebude `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Tento plot sa synchronizuje s obchodom v `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // BEZPEČNOSŤ: použitie atómového plotu je bezpečné.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Pamäťový plot kompilátora.
///
/// `compiler_fence` nevydáva žiadny strojový kód, ale obmedzuje druhy objednávok pamäte, ktoré má kompilátor povolené.Konkrétne, v závislosti od danej sémantiky [`Ordering`], môže byť kompilátoru zakázané presúvať čítania alebo zápisy z pred alebo po volaní na druhú stranu hovoru na `compiler_fence`.Upozorňujeme, že to **hardvéru* nebráni v takomto opätovnom objednaní.
///
/// V kontexte vykonávania s jedným vláknom to nie je problém, ale keď môžu iné vlákna súčasne upravovať pamäť, sú potrebné silnejšie synchronizačné primitívy, ako napríklad [`fence`].
///
/// Re-ordering zabránený rôznymi sémantiky objednávania sú:
///
///  - s [`SeqCst`] nie je povolené žiadne opätovné objednávanie čítaní a zápisov v tomto bode.
///  - s [`Release`] predchádzajúce čítania a zápisy nemožno presunúť za nasledujúce zápisy.
///  - s [`Acquire`] nemožno následné čítania a zápisy posúvať pred predchádzajúce čítania.
///  - s [`AcqRel`] sa uplatňujú obe vyššie uvedené pravidlá.
///
/// `compiler_fence` je všeobecne užitočné iba na zabránenie závitu vlákna v závode *sám so sebou*.To znamená, že ak dané vlákno vykonáva jeden kus kódu, a potom je prerušené, a začne vykonávať kód inde (zatiaľ čo je stále v rovnakom vlákne a koncepčne stále na rovnakom jadre).V tradičných programoch k tomu môže dôjsť iba vtedy, keď je zaregistrovaný obslužný program signálu.
/// V kóde s nízkou úrovňou môžu také situácie nastať aj pri manipulácii s prerušeniami, pri implementácii zelených vlákien s predkupným právom atď.
/// Zvedavým čitateľom sa odporúča prečítať si diskusiu o jadre Linux o [memory barriers].
///
/// # Panics
///
/// Panics, ak `order` je [`Relaxed`].
///
/// # Examples
///
/// Bez `compiler_fence` nie je zaručené, že `assert_eq!` v nasledujúcom kóde uspeje, a to napriek všetkému, čo sa deje v jednom vlákne.
/// Ak chcete zistiť prečo, nezabudnite, že kompilátor môže vymeniť obchody za `IMPORTANT_VARIABLE` a `IS_READ`, pretože obidve sú `Ordering::Relaxed`.Ak áno, a obslužný program signálu sa vyvolá hneď po aktualizácii `IS_READY`, potom obslužný program signálu uvidí `IS_READY=1`, ale `IMPORTANT_VARIABLE=0`.
/// Túto situáciu napraví použitie modelu `compiler_fence`.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // zabrániť presunu starších zápisov za tento bod
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // BEZPEČNOSŤ: použitie atómového plotu je bezpečné.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signalizuje procesor, ktorý je vo vnútri spin-loopu s rušným čakaním (" lock lock`).
///
/// Táto funkcia je zastaraná v prospech [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}