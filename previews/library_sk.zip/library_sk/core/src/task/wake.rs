#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` umožňuje implementátorovi vykonávača úloh vytvoriť [`Waker`], ktorý poskytuje prispôsobené správanie pri prebudení.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Skladá sa z dátového ukazovateľa a [virtual function pointer table (vtable)][vtable], ktoré prispôsobujú správanie `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Ukazovateľ údajov, ktorý je možné použiť na ukladanie ľubovoľných údajov podľa požiadaviek exekútora.
    /// Môže to byť napr
    /// ukazovateľ vymazaného typu na `Arc`, ktorý je spojený s úlohou.
    /// Hodnota tohto poľa sa odovzdá všetkým funkciám, ktoré sú súčasťou tabuľky ako prvý parameter.
    ///
    data: *const (),
    /// Tabuľka ukazovateľov virtuálnych funkcií, ktorá upravuje správanie tohto budiča.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Vytvorí nový `RawWaker` z poskytnutého ukazovateľa `data` a `vtable`.
    ///
    /// Ukazovateľ `data` možno použiť na ukladanie ľubovoľných údajov podľa požiadaviek exekútora.Môže to byť napr
    /// ukazovateľ vymazaného typu na `Arc`, ktorý je spojený s úlohou.
    /// Hodnota tohto ukazovateľa sa prenesie do všetkých funkcií, ktoré sú súčasťou `vtable`, ako prvý parameter.
    ///
    /// `vtable` prispôsobuje správanie `Waker`, ktoré sa vytvorí z `RawWaker`.
    /// Pre každú operáciu na `Waker` sa zavolá asociovaná funkcia v `vtable` podkladového `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tabuľka ukazovateľov virtuálnych funkcií (vtable), ktorá určuje správanie [`RawWaker`].
///
/// Ukazovateľ odovzdaný všetkým funkciám vo vnútri tabuľky je ukazovateľ `data` z ohraničujúceho objektu [`RawWaker`].
///
/// Funkcie vo vnútri tejto štruktúry sú určené iba na vyvolanie na ukazovateli `data` správne zostaveného objektu [`RawWaker`] z vnútra implementácie [`RawWaker`].
/// Volanie jednej z obsiahnutých funkcií pomocou iného ukazovateľa `data` spôsobí nedefinované správanie.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Táto funkcia sa vyvolá, keď sa [`RawWaker`] naklonuje, napr. Keď sa klonuje [`Waker`], v ktorom je uložený [`RawWaker`].
    ///
    /// Pri implementácii tejto funkcie sa musia zachovať všetky zdroje, ktoré sú potrebné pre túto ďalšiu inštanciu úlohy [`RawWaker`] a súvisiace úlohy.
    /// Volanie `wake` na výslednom [`RawWaker`] by malo mať za následok prebudenie rovnakej úlohy, ktorú by prebudil pôvodný [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Táto funkcia sa bude volať, keď sa na [`Waker`] volá `wake`.
    /// Musí prebudiť úlohu spojenú s týmto [`RawWaker`].
    ///
    /// Implementácia tejto funkcie musí zabezpečiť uvoľnenie všetkých prostriedkov, ktoré sú spojené s touto inštanciou [`RawWaker`] a pridruženou úlohou.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Táto funkcia sa bude volať, keď sa na [`Waker`] volá `wake_by_ref`.
    /// Musí prebudiť úlohu spojenú s týmto [`RawWaker`].
    ///
    /// Táto funkcia je podobná ako pri `wake`, ale nesmie spotrebovať poskytnutý ukazovateľ údajov.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Táto funkcia sa zavolá, keď dôjde k pádu [`RawWaker`].
    ///
    /// Implementácia tejto funkcie musí zabezpečiť uvoľnenie všetkých prostriedkov, ktoré sú spojené s touto inštanciou [`RawWaker`] a pridruženou úlohou.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Vytvorí nový `RawWakerVTable` z poskytovaných funkcií `clone`, `wake`, `wake_by_ref` a `drop`.
    ///
    /// # `clone`
    ///
    /// Táto funkcia sa vyvolá, keď sa [`RawWaker`] naklonuje, napr. Keď sa klonuje [`Waker`], v ktorom je uložený [`RawWaker`].
    ///
    /// Pri implementácii tejto funkcie sa musia zachovať všetky zdroje, ktoré sú potrebné pre túto ďalšiu inštanciu úlohy [`RawWaker`] a súvisiace úlohy.
    /// Volanie `wake` na výslednom [`RawWaker`] by malo mať za následok prebudenie rovnakej úlohy, ktorú by prebudil pôvodný [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Táto funkcia sa bude volať, keď sa na [`Waker`] volá `wake`.
    /// Musí prebudiť úlohu spojenú s týmto [`RawWaker`].
    ///
    /// Implementácia tejto funkcie musí zabezpečiť uvoľnenie všetkých prostriedkov, ktoré sú spojené s touto inštanciou [`RawWaker`] a pridruženou úlohou.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Táto funkcia sa bude volať, keď sa na [`Waker`] volá `wake_by_ref`.
    /// Musí prebudiť úlohu spojenú s týmto [`RawWaker`].
    ///
    /// Táto funkcia je podobná ako pri `wake`, ale nesmie spotrebovať poskytnutý ukazovateľ údajov.
    ///
    /// # `drop`
    ///
    /// Táto funkcia sa zavolá, keď dôjde k pádu [`RawWaker`].
    ///
    /// Implementácia tejto funkcie musí zabezpečiť uvoľnenie všetkých prostriedkov, ktoré sú spojené s touto inštanciou [`RawWaker`] a pridruženou úlohou.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` asynchrónnej úlohy.
///
/// V súčasnosti `Context` slúži iba na poskytnutie prístupu k `&Waker`, ktorým je možné prebudiť aktuálnu úlohu.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Zaistite, aby sme boli future-odolní proti zmenám variancie tým, že vynútime, aby bola životnosť nemenná (doby životnosti polohy argumentu sú protikladné, zatiaľ čo životy spätnej polohy sú kovariančné).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Vytvorte nový `Context` z `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Vráti odkaz na `Waker` pre aktuálnu úlohu.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` je rukoväť na prebudenie úlohy oznámením jej vykonávateľovi, že je pripravená na spustenie.
///
/// Tento popisovač zapuzdruje inštanciu [`RawWaker`], ktorá definuje správanie pri prebudení špecifické pre vykonávateľa.
///
///
/// Implementuje [`Clone`], [`Send`] a [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Prebuďte úlohu spojenú s týmto `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Skutočné prebudenie je delegované prostredníctvom volania virtuálnej funkcie na implementáciu, ktorú definuje exekútor.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Nevolajte `drop`-buditeľ bude spotrebovaný `wake`.
        crate::mem::forget(self);

        // BEZPEČNOSŤ: Je to bezpečné, pretože `Waker::from_raw` je jediný spôsob
        // inicializovať `wake` a `data` vyžadujúce od používateľa potvrdenie, že zmluva s `RawWaker` je potvrdená.
        //
        unsafe { (wake)(data) };
    }

    /// Prebuďte úlohu spojenú s týmto modelom `Waker` bez konzumácie modelu `Waker`.
    ///
    /// Je to podobné ako s `wake`, ale môže to byť o niečo menej efektívne v prípade, že je k dispozícii vlastnená `Waker`.
    /// Táto metóda by mala byť uprednostnená pred volaním `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Skutočné prebudenie je delegované prostredníctvom volania virtuálnej funkcie na implementáciu, ktorú definuje exekútor.
        //

        // BEZPEČNOSŤ: pozri `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Vráti `true`, ak tento `Waker` a iný `Waker` prebudili rovnakú úlohu.
    ///
    /// Táto funkcia pracuje na princípe maximálneho úsilia a môže sa vrátiť nepravdivo, aj keď program Waker zobudí rovnakú úlohu.
    /// Ak však táto funkcia vráti `true`, je zaručené, že program " Waker` prebudí rovnakú úlohu.
    ///
    /// Táto funkcia sa primárne používa na účely optimalizácie.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Vytvorí nový `Waker` z [`RawWaker`].
    ///
    /// Správanie vráteného `Waker` nie je definované, ak zmluva uvedená v dokumentácii [" RawWaker`] a [" RawWakerVTable`] `nebude dodržaná.
    ///
    /// Táto metóda je preto nebezpečná.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // BEZPEČNOSŤ: Je to bezpečné, pretože `Waker::from_raw` je jediný spôsob
            // inicializovať `clone` a `data` vyžadujúce od používateľa potvrdenie, že zmluva s [`RawWaker`] je potvrdená.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // BEZPEČNOSŤ: Je to bezpečné, pretože `Waker::from_raw` je jediný spôsob
        // inicializovať `drop` a `data` vyžadujúce od používateľa potvrdenie, že zmluva s `RawWaker` je potvrdená.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}