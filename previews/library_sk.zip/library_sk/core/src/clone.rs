//! `Clone` trait pre typy, ktoré nemožno " implicitne kopírovať`.
//!
//! V Rust sú niektoré jednoduché typy "implicitly copyable" a keď ich priradíte alebo odovzdáte ako argumenty, prijímač získa kópiu a ponechá pôvodnú hodnotu na mieste.
//! Tieto typy nevyžadujú pridelenie na kopírovanie a nemajú finalizátory (tj. Neobsahujú vlastnené boxy ani implementujú [`Drop`]), takže ich kompilátor považuje za lacné a bezpečné kopírovanie.
//!
//! Pre iné typy musia byť kópie vytvorené výslovne, konvenciou implementujúcou [`Clone`] trait a volajúcou metódou [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Základný príklad použitia:
//!
//! ```
//! let s = String::new(); // Reťazcový typ implementuje Clone
//! let copy = s.clone(); // aby sme to mohli naklonovať
//! ```
//!
//! Na ľahkú implementáciu Clone trait môžete tiež použiť `#[derive(Clone)]`.Príklad:
//!
//! ```
//! #[derive(Clone)] // pridáme Clone trait do Morpheusovej štruktúry
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // a teraz to môžeme naklonovať!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Bežný trait pre schopnosť explicitne duplikovať objekt.
///
/// Líši sa od [`Copy`] v tom, že [`Copy`] je implicitný a extrémne lacný, zatiaľ čo `Clone` je vždy explicitný a môže, ale nemusí byť drahý.
/// Z dôvodu presadenia týchto vlastností vám Rust neumožňuje opätovne implementovať [`Copy`], ale môžete znova implementovať `Clone` a spustiť ľubovoľný kód.
///
/// Pretože `Clone` je všeobecnejší ako [`Copy`], môžete z [`Copy`] automaticky urobiť aj `Clone`.
///
/// ## Derivable
///
/// Tento trait je možné použiť s `#[derive]`, ak sú všetky polia `Clone`.Odvodená implementácia [`Clone`] volá [`clone`] pre každé pole.
///
/// [`clone`]: Clone::clone
///
/// Pre všeobecnú štruktúru implementuje `#[derive]` `Clone` podmienene pridaním viazaného `Clone` k všeobecným parametrom.
///
/// ```
/// // `derive` implementuje Klon na čítanie<T>keď T je Klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Ako môžem implementovať `Clone`?
///
/// Typy, ktoré sú [`Copy`], by mali mať triviálnu implementáciu `Clone`.Formálnejšie:
/// ak `T: Copy`, `x: T` a `y: &T`, potom je `let x = y.clone();` ekvivalentom `let x = *y;`.
/// Ručné implementácie by mali byť opatrné, aby sa zachovala táto invariantnosť;nebezpečný kód sa na neho však nesmie spoliehať, aby zaistil bezpečnosť pamäte.
///
/// Príkladom je všeobecná štruktúra obsahujúca ukazovateľ funkcie.V tomto prípade nemožno implementáciu `Clone` odvodiť, ale je možné ju implementovať ako:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Dodatoční implementátori
///
/// Okrem [implementors listed below][impls] implementujú `Clone` aj nasledujúce typy:
///
/// * Typy funkčných položiek (tj odlišné typy definované pre každú funkciu)
/// * Typy ukazovateľov funkcií (napr. `fn() -> i32`)
/// * Typy polí pre všetky veľkosti, ak typ položky implementuje aj `Clone` (napr. `[i32; 123456]`)
/// * Typy n-tíc, ak každý komponent implementuje aj `Clone` (napr. `()`, `(i32, bool)`)
/// * Uzáverové typy, ak nezachytávajú žiadnu hodnotu z prostredia alebo ak všetky takéto zachytené hodnoty implementujú `Clone` samy.
///   Upozorňujeme, že premenné zachytené zdieľanou referenciou vždy implementujú `Clone` (aj keď referent nie), zatiaľ čo premenné zachytené premenlivou referenciou nikdy neimplementujú `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Vráti kópiu hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str realizuje Klon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Vykoná priradenie kopírovania z `source`.
    ///
    /// `a.clone_from(&b)` je funkcionalitou ekvivalentný `a = b.clone()`, ale môže byť prepísaný, aby sa zdroje `a` znovu použili, aby sa zabránilo zbytočnému alokovaniu.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Odvodiť makro generujúce impl. trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): tieto štruktúry používa výhradne#[odvodiť] na tvrdenie, že každá súčasť typu implementuje Clone alebo Copy.
//
//
// Tieto štruktúry by sa nikdy nemali objaviť v kóde používateľa.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementácie `Clone` pre primitívne typy.
///
/// Implementácie, ktoré nie je možné popísať v Rust, sú implementované v `traits::SelectionContext::copy_clone_conditions()` v `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Zdieľané referencie je možné klonovať, ale zmeniteľné referencie *nemôžu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Zdieľané referencie je možné klonovať, ale zmeniteľné referencie *nemôžu*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}