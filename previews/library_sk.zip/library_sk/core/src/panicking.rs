//! Podpora Panic pre libcore
//!
//! Knižnica jadra nemôže definovať paniku, ale robí *deklaráciu* paniky.
//! To znamená, že funkcie vo vnútri libcore sú povolené pre panic, ale aby to bolo užitočné, predradený crate musí pre použitie libcore definovať paniku.
//! Aktuálne rozhranie pre paniku je:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Táto definícia umožňuje paniku s akoukoľvek všeobecnou správou, ale neumožňuje zlyhanie s hodnotou `Box<Any>`.
//! (`PanicInfo` obsahuje iba `&(dyn Any + Send)`, pre ktorý vyplníme fiktívnu hodnotu v `PanicInfo: : internal_constructor`.) Dôvodom je to, že libcore nemá povolené alokovať.
//!
//!
//! Tento modul obsahuje niekoľko ďalších panikárskych funkcií, ale jedná sa iba o nevyhnutné jazykové položky pre kompilátor.Všetky panics sú financované prostredníctvom tejto jednej funkcie.
//! Skutočný symbol je deklarovaný prostredníctvom atribútu `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Základná implementácia makra lib00 `panic!`, keď sa nepoužíva žiadne formátovanie.
#[cold]
// nikdy inline, pokiaľ nie je panic_immediate_abort, aby sa čo najviac zabránilo nadúvaniu kódu na stránkach hovorov
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // potrebné pre codegen pre panic pri pretečení a ďalšie `Assert` MIR terminátory
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Použite Arguments::new_v1 namiesto format_args! ("{}", Expr) na potenciálne zníženie režijných nákladov.
    // Format_args!makro používa str's Display trait na zápis výrazu, ktorý volá Formatter::pad, ktorý musí vyhovovať skráteniu reťazca a odsadeniu (aj keď sa tu žiaden nepoužíva).
    //
    // Použitie Arguments::new_v1 môže umožniť kompilátoru vynechať Formatter::pad z výstupného binárneho súboru, čo ušetrí až niekoľko kilobajtov.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // potrebné pre konštantne vyhodnotené panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // potrebné pre codegen pre panic pri prístupe OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Pri formátovaní sa používa podkladová implementácia makra lib00 `panic!`.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // POZNÁMKA Táto funkcia nikdy neprekračuje hranicu FFI;je to volanie Rust-to-Rust, ktoré sa vyrieši na funkciu `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // BEZPEČNOSŤ: `panic_impl` je definovaná v bezpečnom kóde Rust, a preto je bezpečné volať.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Interná funkcia pre makra `assert_eq!` a `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}