//! Tento modul implementuje `Any` trait, ktorý umožňuje dynamické písanie ľubovoľného typu `'static` prostredníctvom runtime reflexie.
//!
//! `Any` sám o sebe môže byť použitý na získanie `TypeId` a má viac funkcií, keď sa použije ako objekt trait.
//! Ako `&dyn Any` (požičaný objekt trait) má metódy `is` a `downcast_ref` na testovanie, či je obsiahnutá hodnota daného typu, a na získanie odkazu na vnútornú hodnotu ako typ.
//! Ako `&mut dyn Any` existuje aj metóda `downcast_mut` na získanie premenlivého odkazu na vnútornú hodnotu.
//! `Box<dyn Any>` pridáva metódu `downcast`, ktorá sa pokúša previesť na `Box<T>`.
//! Všetky podrobnosti nájdete v dokumentácii k produktu [`Box`].
//!
//! Upozorňujeme, že `&dyn Any` sa obmedzuje na testovanie, či je hodnota konkrétneho typu betónu, a nemožno ho použiť na testovanie, či daný typ implementuje trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Inteligentné ukazovatele a `dyn Any`
//!
//! Pri používaní `Any` ako objektu trait, najmä u typov ako `Box<dyn Any>` alebo `Arc<dyn Any>`, je treba mať na pamäti, že jednoduché volanie hodnoty `.type_id()` na hodnotu vyprodukuje hodnotu `TypeId`*kontajnera*, nie podkladový objekt trait.
//!
//! Tomu sa dá zabrániť prevedením inteligentného ukazovateľa na `&dyn Any`, ktorý vráti `TypeId` objektu.
//! Napríklad:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Je pravdepodobnejšie, že budete chcieť toto:
//! let actual_id = (&*boxed).type_id();
//! // ... ako toto:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Zvážte situáciu, keď chceme odhlásiť hodnotu odovzdanú funkcii.
//! Poznáme hodnotu, na ktorej pracujeme, implementuje Debug, ale nepoznáme jej konkrétny typ.Chceme venovať osobitnú pozornosť určitým typom: v tomto prípade vytlačiť dĺžku reťazcových hodnôt pred ich hodnotou.
//! Konkrétny typ našej hodnoty v čase kompilácie nepoznáme, takže musíme namiesto toho použiť runtime reflexiu.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funkcia protokolovania pre akýkoľvek typ, ktorý implementuje ladenie.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Pokúste sa previesť našu hodnotu na `String`.
//!     // Ak bude úspešný, chceme vygenerovať dĺžku a hodnotu reťazca.
//!     // Ak nie, je to iný typ: jednoducho si ho vytlačte bez ozdôb.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Táto funkcia chce pred vykonaním práce odhlásiť svoj parameter.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... urobte nejaké ďalšie práce
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Akýkoľvek trait
///////////////////////////////////////////////////////////////////////////////

/// trait na emuláciu dynamického písania.
///
/// Väčšina typov implementuje `Any`.Akýkoľvek typ, ktorý obsahuje nestatický odkaz, však nie.
/// Ďalšie informácie nájdete v modeli [module-level documentation][mod].
///
/// [mod]: crate::any
// Táto trait nie je nebezpečná, aj keď sa spoliehame na špecifiká jej funkcie jediného impl `type_id` v nebezpečnom kóde (napr. `downcast`).Normálne by to bol problém, ale pretože jediným implementom `Any` je plošná implementácia, žiadny iný kód nedokáže implementovať `Any`.
//
// Mohli by sme pravdepodobne urobiť tento trait nebezpečným-nespôsobilo by to rozbitie, pretože kontrolujeme všetky implementácie-ale rozhodli sme sa nie, pretože to nie je skutočne nevyhnutné a môže to používateľov zmiasť rozdielom medzi nebezpečnými metódami traits a nebezpečnými metódami (tj. `type_id` by bolo stále bezpečné zavolať, ale pravdepodobne by sme to chceli uviesť v dokumentácii).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Získava `TypeId` z `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metódy rozšírenia pre ľubovoľné objekty trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Zaistite, aby bolo možné výsledok napr. Spojenia nite vytlačiť a teda použiť v `unwrap`.
// Možno už nebude viac potrebný, ak odosielanie funguje so zvyšujúcim sa počtom obyvateľov.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Vráti `true`, ak je rámčekovaný typ rovnaký ako `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Získajte `TypeId` typu, s ktorým je táto funkcia vytvorená.
        let t = TypeId::of::<T>();

        // Získajte `TypeId` typu v objekte trait (`self`).
        let concrete = self.type_id();

        // Porovnajte obidva typy zadávaného textu o rovnosti.
        t == concrete
    }

    /// Vráti nejaký odkaz na hodnotu v škatuli, ak je typu `T`, alebo `None`, ak nie je.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // BEZPEČNOSŤ: stačí skontrolovať, či ukazujeme na správny typ, a môžeme sa spoľahnúť
            // ktoré kontrolujú bezpečnosť pamäte, pretože sme implementovali ľubovoľný pre všetky typy;nemôžu existovať žiadne ďalšie imply, pretože by boli v rozpore s našimi impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Vráti premenlivý odkaz na hodnotu v škatuli, ak je typu `T`, alebo `None`, ak nie je.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // BEZPEČNOSŤ: stačí skontrolovať, či ukazujeme na správny typ, a môžeme sa spoľahnúť
            // ktoré kontrolujú bezpečnosť pamäte, pretože sme implementovali ľubovoľný pre všetky typy;nemôžu existovať žiadne ďalšie imply, pretože by boli v rozpore s našimi impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Ďalej k metóde definovanej pre typ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ďalej k metóde definovanej pre typ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ďalej k metóde definovanej pre typ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Ďalej k metóde definovanej pre typ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Ďalej k metóde definovanej pre typ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Ďalej k metóde definovanej pre typ `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID a jeho metódy
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` predstavuje globálne jedinečný identifikátor typu.
///
/// Každá `TypeId` je nepriehľadný objekt, ktorý neumožňuje kontrolu toho, čo je vo vnútri, ale umožňuje základné operácie, ako je klonovanie, porovnávanie, tlač a zobrazovanie.
///
///
/// `TypeId` je v súčasnosti k dispozícii iba pre typy, ktoré pripisujú `'static`, ale toto obmedzenie môže byť v future odstránené.
///
/// Zatiaľ čo `TypeId` implementuje `Hash`, `PartialOrd` a `Ord`, treba poznamenať, že hodnoty hash a ich usporiadanie sa bude medzi jednotlivými vydaniami Rust líšiť.
/// Dajte si pozor, aby ste sa na ne spoliehali vo svojom kóde!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Vráti `TypeId` typu, s ktorým bola inštanovaná táto všeobecná funkcia.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Vráti názov typu ako rez reťazca.
///
/// # Note
///
/// Toto je určené na diagnostické použitie.
/// Presný obsah a formát vráteného reťazca nie sú špecifikované, okrem toho, že ide o popis typu s najlepším úsilím.
/// Napríklad medzi reťazce, ktoré by `type_name::<Option<String>>()` mohol vrátiť, sú `"Option<String>"` a `"std::option::Option<std::string::String>"`.
///
///
/// Vrátený reťazec sa nesmie považovať za jedinečný identifikátor typu, pretože viaceré typy sa môžu namapovať na rovnaký názov typu.
/// Podobne neexistuje záruka, že sa všetky časti typu zobrazia vo vrátenom reťazci: napríklad momentálne nie sú zahrnuté špecifikátory životnosti.
/// Okrem toho sa výstup môže meniť medzi verziami kompilátora.
///
/// Aktuálna implementácia používa rovnakú infraštruktúru ako diagnostika kompilátora a ladenie, ale nie je to zaručené.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Vráti názov typu poukázanej hodnoty ako reťazcový rez.
/// Je to rovnaké ako `type_name::<T>()`, ale dá sa použiť tam, kde typ premennej nie je ľahko dostupný.
///
/// # Note
///
/// Toto je určené na diagnostické použitie.Presný obsah a formát reťazca nie sú špecifikované, okrem toho, že ide o najlepší popis typu.
/// Napríklad `type_name_of_val::<Option<String>>(None)` môže vrátiť `"Option<String>"` alebo `"std::option::Option<std::string::String>"`, ale nie `"foobar"`.
///
/// Okrem toho sa výstup môže meniť medzi verziami kompilátora.
///
/// Táto funkcia nerozlišuje objekty trait, čo znamená, že `type_name_of_val(&7u32 as &dyn Debug)` môže vrátiť `"dyn Debug"`, ale nie `"u32"`.
///
/// Názov typu by sa nemal považovať za jedinečný identifikátor typu;
/// viac typov môže zdieľať rovnaký názov typu.
///
/// Aktuálna implementácia používa rovnakú infraštruktúru ako diagnostika kompilátora a ladenie, ale nie je to zaručené.
///
/// # Examples
///
/// Vypíše predvolené typy celých a floatových typov.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}