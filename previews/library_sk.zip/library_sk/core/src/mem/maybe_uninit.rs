use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Typ obálky na vytvorenie neinicializovaných inštancií `T`.
///
/// # Inicializácia invariantná
///
/// Kompilátor všeobecne predpokladá, že premenná je správne inicializovaná podľa požiadaviek typu premennej.Napríklad premenná referenčného typu musí byť zarovnaná a nesmie mať NULL.
/// Toto je invariant, ktorý musí byť *vždy* potvrdený, a to aj v nebezpečnom kóde.
/// Dôsledkom toho je, že nulová inicializácia premennej referenčného typu spôsobí okamžité [undefined behavior][ub], bez ohľadu na to, či si táto referencia niekedy zvykne na prístup do pamäte:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // nedefinované správanie!⚠️
/// // Ekvivalentný kód pre `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // nedefinované správanie!⚠️
/// ```
///
/// Toto kompilátor využíva na rôzne optimalizácie, ako je napríklad kontrola priebehu a optimalizácia rozloženia `enum`.
///
/// Podobne môže mať úplne neinicializovaná pamäť akýkoľvek obsah, zatiaľ čo `bool` musí byť vždy `true` alebo `false`.Vytvorenie neinicializovaného `bool` je teda nedefinované správanie:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // nedefinované správanie!⚠️
/// // Ekvivalentný kód pre `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinované správanie!⚠️
/// ```
///
/// Neinicializovaná pamäť je navyše zvláštna tým, že nemá pevnú hodnotu ("fixed", čo znamená "it won't change without being written to").Čítanie toho istého neinicializovaného bytu viackrát môže priniesť rôzne výsledky.
/// Vďaka tomu je nedefinované správanie mať neinicializované údaje v premennej, aj keď má táto premenná celočíselný typ, ktorý inak môže obsahovať akýkoľvek *pevný* bitový vzor:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // nedefinované správanie!⚠️
/// // Ekvivalentný kód pre `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinované správanie!⚠️
/// ```
/// (Všimnite si, že pravidlá týkajúce sa neinicializovaných celých čísel ešte nie sú dokončené, ale kým nebudú, je vhodné sa im vyhnúť.)
///
/// Okrem toho nezabudnite, že väčšina typov má ďalšie invarianty, okrem toho, že sa považujú iba za inicializované na úrovni typov.
/// Napríklad [`Vec<T>`] inicializovaný na " 1` sa považuje za inicializovaný (pri súčasnej implementácii; to nepredstavuje stabilnú záruku), pretože kompilátor o ňom vie iba jedinú požiadavku, že ukazovateľ údajov musí mať nenulovú hodnotu.
/// Vytvorenie takého `Vec<T>` nespôsobí *okamžité* nedefinované správanie, ale spôsobí nedefinované správanie pri väčšine bezpečných operácií (vrátane jeho zrušenia).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` slúži na povolenie nebezpečného kódu pri riešení neinicializovaných údajov.
/// Je to signál pre kompilátor označujúci, že tu uvedené údaje sa nemusia *inicializovať*:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Vytvorte výslovne neinicializovaný odkaz.
/// // Kompilátor vie, že údaje vo vnútri `MaybeUninit<T>` môžu byť neplatné, a preto to nie je UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Nastavte platnú hodnotu.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Extrahujte inicializované dáta-to je povolené *až po* správnej inicializácii `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Kompilátor potom vie, že v tomto kóde neurobí žiadne nesprávne predpoklady alebo optimalizácie.
///
/// Môžete si myslieť, že `MaybeUninit<T>` je trochu ako `Option<T>`, ale bez sledovania chodu a bez bezpečnostných kontrol.
///
/// ## out-pointers
///
/// Môžete použiť `MaybeUninit<T>` na implementáciu "out-pointers": namiesto vrátenia údajov z funkcie jej odovzdajte ukazovateľ na nejakú pamäť (uninitialized), do ktorej chcete výsledok vložiť.
/// To môže byť užitočné, keď je pre volajúceho dôležité kontrolovať, ako sa alokuje pamäť, do ktorej je uložený výsledok, a vy sa chcete vyhnúť zbytočným pohybom.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` nevypustí starý obsah, čo je dôležité.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Teraz vieme, že `v` je inicializovaný!To tiež zaisťuje, aby sa vector správne spadol.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicializácia poľa prvok po prvku
///
/// `MaybeUninit<T>` možno použiť na inicializáciu veľkého poľa od prvku po prvku:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Vytvorte neinicializované pole `MaybeUninit`.
///     // `assume_init` je bezpečný, pretože typ, ktorý tu údajne inicializujeme, je kopa súborov " MožnáUninit`, ktoré nevyžadujú inicializáciu.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Pustenie `MaybeUninit` nič nerobí.
///     // Použitie surového priradenia ukazovateľa namiesto `ptr::write` teda nespôsobí zrušenie starej neinicializovanej hodnoty.
/////
///     // Tiež ak počas tejto slučky dôjde k panic, dôjde k úniku pamäte, ale nevyskytuje sa žiadny problém s bezpečnosťou pamäte.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Všetko je inicializované.
///     // Premeňte pole na inicializovaný typ.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Môžete tiež pracovať s čiastočne inicializovanými poľami, ktoré nájdete v nízkoúrovňových údajových štruktúrach.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Vytvorte neinicializované pole `MaybeUninit`.
/// // `assume_init` je bezpečný, pretože typ, ktorý tu údajne inicializujeme, je kopa súborov " MožnáUninit`, ktoré nevyžadujú inicializáciu.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Spočítajte počet prvkov, ktoré sme priradili.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Pre každú položku v poli vynechajte, ak sme ju pridelili.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicializuje sa štruktúra pole po poli
///
/// Môžete použiť `MaybeUninit<T>` a makro [`std::ptr::addr_of_mut`] na inicializáciu štruktúr pole po poli:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicializuje sa pole `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicializácia poľa `list` Ak je tu panic, potom `String` v poli `name` presakuje.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Všetky polia sú inicializované, preto voláme `assume_init`, aby sme dostali inicializovaný Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` je zaručené, že bude mať rovnakú veľkosť, zarovnanie a ABI ako `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Pamätajte však, že typ *obsahujúci* a `MaybeUninit<T>` nemusí byť nutne rovnakého rozloženia;Rust všeobecne nezaručuje, že polia `Foo<T>` majú rovnaké poradie ako `Foo<U>`, aj keď majú `T` a `U` rovnakú veľkosť a zarovnanie.
///
/// Pretože je pre `MaybeUninit<T>` platná akákoľvek bitová hodnota, kompilátor nemôže použiť optimalizácie non-zero/niche-filling, čo môže mať za následok väčšiu veľkosť:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ak je `T` bezpečný pre FFI, tak je to aj pre `MaybeUninit<T>`.
///
/// Zatiaľ čo `MaybeUninit` je `#[repr(transparent)]` (čo znamená, že zaručuje rovnakú veľkosť, zarovnanie a ABI ako `T`), to *nezmení* nijaké z predchádzajúcich upozornení.
/// `Option<T>` a `Option<MaybeUninit<T>>` môžu mať stále rôzne veľkosti a typy obsahujúce pole typu `T` môžu byť rozložené (a dimenzované) odlišne, ako keby toto pole bolo `MaybeUninit<T>`.
/// `MaybeUninit` je typ spojenia a `#[repr(transparent)]` na zväzkoch je nestabilný (pozri [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Postupom času sa môžu vyvinúť presné záruky `#[repr(transparent)]` na odbory a `MaybeUninit` môže alebo nemusí zostať `#[repr(transparent)]`.
/// To znamená, že `MaybeUninit<T>`*vždy* zaručí, že má rovnakú veľkosť, zarovnanie a ABI ako `T`;je to tak, že spôsob, akým `MaybeUninit` implementuje túto záruku, sa môže vyvíjať.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang položka, aby sme do nej mohli zabaliť ďalšie typy.To je užitočné pre generátory.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Ak nebudeme volať `T::clone()`, nemôžeme vedieť, či sme na to dostatočne inicializovaní.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Vytvorí nový `MaybeUninit<T>` inicializovaný s danou hodnotou.
    /// Je bezpečné zavolať [`assume_init`] na návratovú hodnotu tejto funkcie.
    ///
    /// Upozorňujeme, že vypadnutie `MaybeUninit<T>` nikdy nezavolá drop kód `T`.
    /// Je vašou zodpovednosťou ubezpečiť sa, že `T` vypadne, ak sa inicializuje.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Vytvorí nový `MaybeUninit<T>` v neinicializovanom stave.
    ///
    /// Upozorňujeme, že vypadnutie `MaybeUninit<T>` nikdy nezavolá drop kód `T`.
    /// Je vašou zodpovednosťou ubezpečiť sa, že `T` vypadne, ak sa inicializuje.
    ///
    /// Niekoľko príkladov nájdete v [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Vytvorte nové pole položiek `MaybeUninit<T>` v neinicializovanom stave.
    ///
    /// Note: vo verzii future Rust sa táto metóda môže stať nepotrebnou, ak literálna syntax poľa umožňuje [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Nasledujúci príklad by potom mohol používať `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Vráti (možno menší) výrez údajov, ktoré boli skutočne načítané
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // BEZPEČNOSŤ: Neinicializovaná `[MaybeUninit<_>; LEN]` je platná.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Vytvorí nový `MaybeUninit<T>` v neinicializovanom stave s pamäťou vyplnenou `0` bajtmi.Závisí to od `T`, či to už umožňuje správnu inicializáciu.
    ///
    /// Napríklad `MaybeUninit<usize>::zeroed()` je inicializovaný, ale `MaybeUninit<&'static i32>::zeroed()` nie je, pretože referencie nesmú byť nulové.
    ///
    /// Upozorňujeme, že vypadnutie `MaybeUninit<T>` nikdy nezavolá drop kód `T`.
    /// Je vašou zodpovednosťou ubezpečiť sa, že `T` vypadne, ak sa inicializuje.
    ///
    /// # Example
    ///
    /// Správne použitie tejto funkcie: inicializácia štruktúry s nulou, kde všetky polia štruktúry môžu obsahovať bitový vzor 0 ako platnú hodnotu.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Nesprávne* použitie tejto funkcie: volanie `x.zeroed().assume_init()`, keď `0` nie je platný bitový vzor pre typ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Vo vnútri páru vytvoríme `NotZero`, ktorý nemá platný diskriminátor.
    /// // Toto je nedefinované správanie.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // BEZPEČNOSŤ: `u.as_mut_ptr()` bodov do pridelenej pamäte.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Nastavuje hodnotu `MaybeUninit<T>`.
    /// Týmto sa prepíše akákoľvek predchádzajúca hodnota bez toho, aby bola vypustená, takže buďte opatrní, aby ste ju nepoužívali dvakrát, pokiaľ nechcete preskočiť spustenie deštruktora.
    ///
    /// Pre vaše pohodlie to tiež vráti premenlivý odkaz na (teraz bezpečne inicializovaný) obsah `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // BEZPEČNOSŤ: Túto hodnotu sme práve inicializovali.
        unsafe { self.assume_init_mut() }
    }

    /// Získava ukazovateľ na obsiahnutú hodnotu.
    /// Čítanie z tohto ukazovateľa alebo jeho zmena v odkaz je nedefinované správanie, pokiaľ nie je inicializovaný `MaybeUninit<T>`.
    /// Zápis do pamäte, na ktorý tento ukazovateľ (non-transitively) ukazuje, je nedefinované správanie (s výnimkou vnútri `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Správne použitie tejto metódy:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Vytvorte odkaz na `MaybeUninit<T>`.To je v poriadku, pretože sme to inicializovali.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Nesprávne* použitie tejto metódy:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Vytvorili sme odkaz na neinicializovaný vector!Toto je nedefinované správanie.⚠️
    /// ```
    ///
    /// (Všimnite si, že pravidlá týkajúce sa odkazov na neinicializované údaje ešte nie sú dokončené, ale kým nebudú, je vhodné sa im vyhnúť.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` a `ManuallyDrop` sú obidve `repr(transparent)`, takže môžeme vrhať ukazovateľ.
        self as *const _ as *const T
    }

    /// Získava premenlivý ukazovateľ na obsiahnutú hodnotu.
    /// Čítanie z tohto ukazovateľa alebo jeho zmena v odkaz je nedefinované správanie, pokiaľ nie je inicializovaný `MaybeUninit<T>`.
    ///
    /// # Examples
    ///
    /// Správne použitie tejto metódy:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Vytvorte odkaz na `MaybeUninit<Vec<u32>>`.
    /// // To je v poriadku, pretože sme to inicializovali.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Nesprávne* použitie tejto metódy:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Vytvorili sme odkaz na neinicializovaný vector!Toto je nedefinované správanie.⚠️
    /// ```
    ///
    /// (Všimnite si, že pravidlá týkajúce sa odkazov na neinicializované údaje ešte nie sú dokončené, ale kým nebudú, je vhodné sa im vyhnúť.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` a `ManuallyDrop` sú obidve `repr(transparent)`, takže môžeme vrhať ukazovateľ.
        self as *mut _ as *mut T
    }

    /// Extrahuje hodnotu z kontajnera `MaybeUninit<T>`.Je to vynikajúci spôsob, ako zabezpečiť, aby sa dáta vynechali, pretože výsledný model `T` podlieha obvyklému spracovaniu súborov.
    ///
    /// # Safety
    ///
    /// Je na volajúcom, aby zaručil, že je `MaybeUninit<T>` skutočne v inicializovanom stave.Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí okamžité nedefinované správanie.
    /// [type-level documentation][inv] obsahuje viac informácií o tejto inicializácii invariantu.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Okrem toho nezabudnite, že väčšina typov má ďalšie invarianty, okrem toho, že sa považujú iba za inicializované na úrovni typov.
    /// Napríklad [`Vec<T>`] inicializovaný na " 1` sa považuje za inicializovaný (pri súčasnej implementácii; to nepredstavuje stabilnú záruku), pretože kompilátor o ňom vie iba jedinú požiadavku, že ukazovateľ údajov musí mať nenulovú hodnotu.
    ///
    /// Vytvorenie takého `Vec<T>` nespôsobí *okamžité* nedefinované správanie, ale spôsobí nedefinované správanie pri väčšine bezpečných operácií (vrátane jeho zrušenia).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Správne použitie tejto metódy:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Nesprávne* použitie tejto metódy:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ešte neboli inicializované, takže tento posledný riadok spôsobil nedefinované správanie.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // BEZPEČNOSŤ: volajúci musí zaručiť inicializáciu `self`.
        // To tiež znamená, že `self` musí byť variantom `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Číta hodnotu z kontajnera `MaybeUninit<T>`.Výsledný `T` podlieha obvyklému spracovaniu kvapiek.
    ///
    /// Vždy, keď je to možné, je lepšie použiť radšej [`assume_init`], čo zabráni duplikovaniu obsahu `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Je na volajúcom, aby zaručil, že je `MaybeUninit<T>` skutočne v inicializovanom stave.Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí nedefinované správanie.
    /// [type-level documentation][inv] obsahuje viac informácií o tejto inicializácii invariantu.
    ///
    /// Navyše to v `MaybeUninit<T>` zanecháva kópiu rovnakých údajov.
    /// Pri použití viacerých kópií údajov (opakovaným volaním na `assume_init_read` alebo najskôr na `assume_init_read` a potom [`assume_init`]) je vašou zodpovednosťou zabezpečiť, aby sa tieto údaje skutočne mohli duplikovať.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Správne použitie tejto metódy:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` je `Copy`, takže môžeme čítať viackrát.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Duplikovanie hodnoty `None` je v poriadku, takže môžeme čítať viackrát.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Nesprávne* použitie tejto metódy:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Teraz sme vytvorili dve kópie toho istého vector, čo viedlo k dvojitej voľnosti ⚠️, keď obidve vypadnú!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // BEZPEČNOSŤ: volajúci musí zaručiť inicializáciu `self`.
        // Čítanie z `self.as_ptr()` je bezpečné, pretože `self` by sa mal inicializovať.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Zníži obsiahnutú hodnotu na miesto.
    ///
    /// Ak ste vlastníkom modelu `MaybeUninit`, môžete namiesto neho použiť model [`assume_init`].
    ///
    /// # Safety
    ///
    /// Je na volajúcom, aby zaručil, že je `MaybeUninit<T>` skutočne v inicializovanom stave.Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí nedefinované správanie.
    ///
    /// Okrem toho musia byť splnené všetky ďalšie invarianty typu `T`, pretože na to sa môže spoliehať implementácia `Drop` v `T` (alebo jeho členoch).
    /// Napríklad [`Vec<T>`] inicializovaný na " 1` sa považuje za inicializovaný (pri súčasnej implementácii; to nepredstavuje stabilnú záruku), pretože kompilátor o ňom vie iba jedinú požiadavku, že ukazovateľ údajov musí mať nenulovú hodnotu.
    ///
    /// Pád takejto `Vec<T>` však spôsobí nedefinované správanie.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // BEZPEČNOSŤ: volajúci musí zaručiť, že je `self` inicializovaný a
        // spĺňa všetky invarianty `T`.
        // Ak je to tak, hodenie hodnoty na miesto je bezpečné.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Získava zdieľaný odkaz na obsiahnutú hodnotu.
    ///
    /// To môže byť užitočné, keď chceme získať prístup k `MaybeUninit`, ktorý bol inicializovaný, ale nevlastníme `MaybeUninit` (bráni to použitiu `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Toto volanie, keď ešte nie je obsah úplne inicializovaný, spôsobí nedefinované správanie: je na volajúcom, aby zaručil, že `MaybeUninit<T>` je skutočne v inicializovanom stave.
    ///
    ///
    /// # Examples
    ///
    /// ### Správne použitie tejto metódy:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicializovať `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Teraz, keď je známe, že je naša `MaybeUninit<_>` inicializovaná, je v poriadku vytvoriť si na ňu zdieľaný odkaz:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // BEZPEČNOSŤ: `x` bol inicializovaný.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Nesprávne* použitie tejto metódy:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Vytvorili sme odkaz na neinicializovaný vector!Toto je nedefinované správanie.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicializujte `MaybeUninit` pomocou `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Odkaz na neinicializovaný `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // BEZPEČNOSŤ: volajúci musí zaručiť inicializáciu `self`.
        // To tiež znamená, že `self` musí byť variantom `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Získava premenlivý odkaz (unique) na obsiahnutú hodnotu.
    ///
    /// To môže byť užitočné, keď chceme získať prístup k `MaybeUninit`, ktorý bol inicializovaný, ale nevlastníme `MaybeUninit` (bráni to použitiu `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Toto volanie, keď ešte nie je obsah úplne inicializovaný, spôsobí nedefinované správanie: je na volajúcom, aby zaručil, že `MaybeUninit<T>` je skutočne v inicializovanom stave.
    /// Napríklad `.assume_init_mut()` nemožno použiť na inicializáciu `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Správne použitie tejto metódy:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializuje *všetky* bajty vstupnej medzipamäte.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicializovať `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Teraz vieme, že `buf` bol inicializovaný, takže sme ho mohli `.assume_init()`.
    /// // Používanie `.assume_init()` však môže spustiť `memcpy` z 2 048 bajtov.
    /// // Aby sme tvrdili, že náš buffer bol inicializovaný bez jeho kopírovania, inovujeme `&mut MaybeUninit<[u8; 2048]>` na `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // BEZPEČNOSŤ: `buf` bol inicializovaný.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Teraz môžeme použiť `buf` ako normálny plátok:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Nesprávne* použitie tejto metódy:
    ///
    /// Na inicializáciu hodnoty nemôžete použiť `.assume_init_mut()`:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Vytvorili sme odkaz (mutable) na neinicializovaný `bool`!
    ///     // Toto je nedefinované správanie.⚠️
    /// }
    /// ```
    ///
    /// Napríklad nemôžete [`Read`] vložiť do neinicializovaného bufferu:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) odkaz na neinicializovanú pamäť!
    ///                             // Toto je nedefinované správanie.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Priamy prístup k poľu tiež nemôžete použiť na postupnú inicializáciu poľa po poli:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) odkaz na neinicializovanú pamäť!
    ///                  // Toto je nedefinované správanie.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) odkaz na neinicializovanú pamäť!
    ///                  // Toto je nedefinované správanie.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): V súčasnosti sa spoliehame na to, že vyššie uvedené je nesprávne, tj. Máme odkazy na neinicializované údaje (napr. V `libcore/fmt/float.rs`).
    // Pred stabilizáciou by sme mali prijať konečné rozhodnutie o pravidlách.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // BEZPEČNOSŤ: volajúci musí zaručiť inicializáciu `self`.
        // To tiež znamená, že `self` musí byť variantom `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Extrahuje hodnoty z poľa kontajnerov `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Je na volajúcom, aby zaručil, že všetky prvky poľa sú v inicializovanom stave.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // BEZPEČNOSŤ: Teraz sme v bezpečí, pretože sme inicializovali všetky prvky
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Volajúci zaručuje, že sú inicializované všetky prvky poľa
        // * `MaybeUninit<T>` a T majú zaručene rovnaké rozloženie
        // * Možno, že Ununint neklesne, takže nedochádza k dvojitému uvoľneniu, takže konverzia je bezpečná
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Za predpokladu, že sú všetky prvky inicializované, získajte k nim kúsok.
    ///
    /// # Safety
    ///
    /// Je na volajúcom, aby zaručil, že prvky `MaybeUninit<T>` sú skutočne v inicializovanom stave.
    ///
    /// Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí nedefinované správanie.
    ///
    /// Ďalšie podrobnosti a príklady nájdete v časti [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // BEZPEČNOSŤ: vrhanie plátkov na `*const [T]` je bezpečné, pretože to volajúci zaručuje
        // `slice` je inicializovaný a je zaručené, že`MaybeUninit` bude mať rovnaké rozloženie ako `T`.
        // Získaný ukazovateľ je platný, pretože sa týka pamäte vo vlastníctve `slice`, ktorá je referenciou, a teda je zaručene platná pre čítanie.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Za predpokladu, že sú všetky prvky inicializované, získajte k nim premenlivý plátok.
    ///
    /// # Safety
    ///
    /// Je na volajúcom, aby zaručil, že prvky `MaybeUninit<T>` sú skutočne v inicializovanom stave.
    ///
    /// Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí nedefinované správanie.
    ///
    /// Ďalšie podrobnosti a príklady nájdete v časti [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // BEZPEČNOSŤ: podobné bezpečnostným poznámkam pre `slice_get_ref`, ale máme a
        // meniteľný odkaz, ktorý je tiež zaručene platný pre zápisy.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Získava ukazovateľ na prvý prvok poľa.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Získava premenlivý ukazovateľ na prvý prvok poľa.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Skopíruje prvky z `src` do `this` a vráti premenlivý odkaz na teraz inicializovaný obsah `this`.
    ///
    /// Ak `T` neimplementuje `Copy`, použite [`write_slice_cloned`]
    ///
    /// Je to podobné ako v prípade [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak majú dva plátky rôzne dĺžky.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BEZPEČNOSŤ: práve sme skopírovali všetky prvky len do voľnej kapacity
    /// // prvé prvky src.len() vec sú teraz platné.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // BEZPEČNOSŤ: &[T] a&[MožnáUninit<T>] majú rovnaké rozloženie
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // BEZPEČNOSŤ: Platné prvky boli práve skopírované do `this`, takže je inicializovaná
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonuje prvky z `src` do `this` a vracia premenlivý odkaz na teraz inicializovaný obsah `this`.
    /// Všetky už inicializované prvky nebudú zahodené.
    ///
    /// Ak `T` implementuje `Copy`, použite [`write_slice`]
    ///
    /// Je to podobné ako v prípade [`slice::clone_from_slice`], ale nejde o zrušenie existujúcich prvkov.
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak majú dva plátky rôzne dĺžky, alebo ak je implementácia `Clone` panics.
    ///
    /// Ak existuje panic, už klonované prvky budú zrušené.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // BEZPEČNOSŤ: práve sme naklonovali všetky prvky len do voľnej kapacity
    /// // prvé prvky src.len() vec sú teraz platné.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // na rozdiel od copy_from_slice to nevolá clone_from_slice na reze, je to preto, lebo `MaybeUninit<T: Clone>` neimplementuje Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // BEZPEČNOSŤ: tento surový plátok bude obsahovať iba inicializované objekty
                // preto je dovolené ho vypustiť.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Musíme ich vyslovene nakrájať na rovnakú dĺžku
        // aby bola kontrola hraníc odstránená a optimalizátor vygeneruje memcpy pre jednoduché prípady (napríklad T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // je potrebný ochranný kryt b/c panic sa môže stať počas klonu
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // BEZPEČNOSŤ: Platné prvky boli práve zapísané do `this`, takže sú inicializované
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}