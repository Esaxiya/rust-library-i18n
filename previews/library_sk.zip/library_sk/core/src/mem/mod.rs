//! Základné funkcie pre prácu s pamäťou.
//!
//! Tento modul obsahuje funkcie na zisťovanie veľkosti a zarovnávania typov, inicializáciu a manipuláciu s pamäťou.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Berie vlastníctvo a "forgets" o hodnote **bez spustenia jej deštruktora**.
///
/// Všetky prostriedky, ktoré hodnota spravuje, ako napríklad halda pamäte alebo rukoväť súborov, zostanú navždy v nedosiahnuteľnom stave.Nezaručuje však, že odkazy na túto pamäť zostanú v platnosti.
///
/// * Ak chcete únik pamäte, pozrite si [`Box::leak`].
/// * Ak chcete získať surový ukazovateľ na pamäť, pozrite si [`Box::into_raw`].
/// * Ak sa chcete hodnoty správne zbaviť, spustite jej deštruktor, pozrite si [`mem::drop`].
///
/// # Safety
///
/// `forget` nie je označený ako `unsafe`, pretože bezpečnostné záruky Rust nezahŕňajú záruku, že deštruktory budú vždy v prevádzke.
/// Napríklad program môže vytvoriť referenčný cyklus pomocou [`Rc`][rc] alebo zavolať [`process::exit`][exit] na ukončenie bez spustenia deštruktorov.
/// Povolenie `mem::forget` z bezpečného kódu teda zásadne nemení bezpečnostné záruky Rust.
///
/// To znamená, že únik zdrojov, ako sú pamäť alebo objekty I/O, je zvyčajne nežiaduci.
/// Potreba prichádza v niektorých špecializovaných prípadoch použitia pre FFI alebo nebezpečný kód, ale aj tak sa zvyčajne uprednostňuje [`ManuallyDrop`].
///
/// Pretože je povolené zabudnutie na hodnotu, musí s touto možnosťou počítať akýkoľvek kód `unsafe`, ktorý napíšete.Nemôžete vrátiť hodnotu a očakávať, že volajúci nevyhnutne spustí destruktor hodnoty.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kanonickým bezpečným použitím `mem::forget` je obchádzanie deštruktora hodnoty implementovaného `Drop` trait.Napríklad z tohto unikne `File`, tj
/// znovu získať priestor zaberaný premennou, ale nikdy nezatvárať podkladový systémový zdroj:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// To je užitočné, keď sa vlastníctvo podkladového zdroja predtým prenieslo do kódu mimo Rust, napríklad prenosom surového deskriptora súboru do kódu C.
///
/// # Vzťah s `ManuallyDrop`
///
/// Zatiaľ čo `mem::forget` možno použiť aj na prenos vlastníctva *pamäte*, je to náchylné na chyby.
/// [`ManuallyDrop`] by sa malo použiť namiesto toho.Zvážte napríklad tento kód:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Postavte `String` pomocou obsahu `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // únik `v`, pretože jeho pamäť je teraz spravovaná `s`
/// mem::forget(v);  // ERROR, v je neplatné a nesmie byť postúpené funkcii
/// assert_eq!(s, "Az");
/// // `s` je implicitne zrušená a jej pamäť je uvoľnená.
/// ```
///
/// Vyššie uvedený príklad má dva problémy:
///
/// * Ak by bol medzi konštrukciu `String` a vyvolanie `mem::forget()` pridaný ďalší kód, panic v ňom by spôsobil dvojité voľno, pretože `v` aj `s` spracováva rovnakú pamäť.
/// * Po volaní `v.as_mut_ptr()` a prenose vlastníctva údajov do `s` je hodnota `v` neplatná.
/// Aj keď je hodnota práve presunutá do `mem::forget` (ktorá ju nebude kontrolovať), niektoré typy majú prísne požiadavky na svoje hodnoty, vďaka ktorým sú neplatné, keď sú visiace alebo už viac nie sú vlastníctvom.
/// Používanie neplatných hodnôt akýmkoľvek spôsobom, vrátane ich prenosu do funkcií alebo ich vrátenia z funkcií, predstavuje nedefinované správanie a môže narušiť predpoklady kompilátora.
///
/// Prepnutím na `ManuallyDrop` sa vyhnete obom problémom:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Predtým, ako rozoberieme `v` na jeho surové časti, uistite sa, že neklesne!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Teraz rozoberte `v`.Tieto operácie nemôžu panic, takže nemôže dôjsť k úniku.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Nakoniec postavte `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` je implicitne zrušená a jej pamäť je uvoľnená.
/// ```
///
/// `ManuallyDrop` dôrazne zabraňuje dvojitej voľnosti, pretože predtým, ako urobíme čokoľvek, vypneme deštruktor `v`.
/// `mem::forget()` to neumožňuje, pretože to spotrebováva jeho argumenty a núti nás volať ho až po extrakcii všetkého potrebného z `v`.
/// Aj keby bol medzi konštrukciou `ManuallyDrop` a zostavením reťazca zavedený model panic (čo sa v kóde nemôže stať, ako je znázornené), viedlo by to k úniku informácií, a nie k dvojitému uvoľneniu.
/// Inými slovami, `ManuallyDrop` sa chybe na strane presakovania namiesto chyby na strane (dvojitého) spadnutia.
///
/// `ManuallyDrop` nám tiež bráni v tom, aby sme po prevode vlastníctva na `s` museli platiť "touch" `v`-poslednému kroku interakcie s `v` a jeho likvidácii bez spustenia jeho deštruktora sa úplne vyhneme.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Rovnako ako [`forget`], ale akceptuje aj hodnoty bez veľkosti.
///
/// Táto funkcia je iba vložka určená na odstránenie, keď sa funkcia `unsized_locals` stabilizuje.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Vráti veľkosť typu v bajtoch.
///
/// Konkrétnejšie ide o posun v bajtoch medzi po sebe nasledujúcimi prvkami v poli s daným typom položky vrátane zarovnávacej výplne.
///
/// Teda pre akýkoľvek typ `T` a dĺžku `n` má `[T; n]` veľkosť `n * size_of::<T>()`.
///
/// Veľkosť typu nie je vo všetkých kompiláciách všeobecne stabilná, ale sú to konkrétne typy, napríklad primitívne.
///
/// V nasledujúcej tabuľke je uvedená veľkosť pre primitívy.
///
/// Typ |veľkosť: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 znakov |4
///
/// `usize` a `isize` majú navyše rovnakú veľkosť.
///
/// Všetky typy `*const T`, `&T`, `Box<T>`, `Option<&T>` a `Option<Box<T>>` majú rovnakú veľkosť.
/// Ak má veľkosť `T`, všetky tieto typy majú rovnakú veľkosť ako `usize`.
///
/// Premenlivosť ukazovateľa nemení jeho veľkosť.Preto majú modely `&T` a `&mut T` rovnakú veľkosť.
/// Rovnako pre `*const T` a `* mut T`.
///
/// # Veľkosť položiek `#[repr(C)]`
///
/// Reprezentácia `C` pre položky má definované rozloženie.
/// Pri tomto rozložení je stabilná aj veľkosť položiek, pokiaľ majú všetky polia stabilnú veľkosť.
///
/// ## Veľkosť štruktúr
///
/// Pre model `structs` je veľkosť určená nasledujúcim algoritmom.
///
/// Pre každé pole v štruktúre zoradené podľa poradia vyhlásenia:
///
/// 1. Pridajte veľkosť poľa.
/// 2. Aktuálna veľkosť sa zaokrúhli na najbližší násobok [alignment] nasledujúceho poľa.
///
/// Nakoniec zaokrúhlite veľkosť štruktúry na najbližší násobok jej [alignment].
/// Zarovnanie štruktúry je zvyčajne najväčšie zarovnanie zo všetkých jej polí;to sa dá zmeniť použitím `repr(align(N))`.
///
/// Na rozdiel od `C` sa štruktúry nulovej veľkosti nezaokrúhľujú na viac ako jeden bajt.
///
/// ## Veľkosť enumov
///
/// Enumy, ktoré neprenášajú žiadne iné dáta ako diskriminujúce, majú rovnakú veľkosť ako enumy C na platforme, pre ktorú sú kompilované.
///
/// ## Veľkosť odborov
///
/// Veľkosť únie je veľkosťou jej najväčšieho poľa.
///
/// Na rozdiel od `C` sa odbory nulovej veľkosti nezaokrúhľujú na viac ako jeden bajt.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Nejakí primitívi
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Niektoré polia
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Rovnosť veľkosti ukazovateľa
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Pomocou `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Veľkosť prvého poľa je 1, takže k veľkosti pripočítajte 1.Veľkosť je 1.
/// // Zarovnanie druhého poľa je 2, takže k veľkosti pre výplň pripočítajte 1.Veľkosť je 2.
/// // Veľkosť druhého poľa je 2, takže k veľkosti pripočítajte 2.Veľkosť je 4.
/// // Zarovnanie tretieho poľa je 1, takže k veľkosti pre výplň pripočítajte 0.Veľkosť je 4.
/// // Veľkosť tretieho poľa je 1, takže k veľkosti pripočítajte 1.Veľkosť je 5.
/// // Nakoniec je zarovnanie štruktúry 2 (pretože najväčšie zarovnanie medzi jej poľami je 2), takže k veľkosti pre výplň pripočítajte 1.
/// // Veľkosť je 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Štruktúry n-tice dodržiavajú rovnaké pravidlá.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Upozorňujeme, že zmena poradia polí môže zmenšiť veľkosť.
/// // Oba vyplňujúce bajty môžeme odstrániť vložením `third` pred `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Veľkosť Únie je veľkosť najväčšieho poľa.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Vráti veľkosť poukázanej hodnoty v bajtoch.
///
/// Zvyčajne je to rovnaké ako `size_of::<T>()`.
/// Ak však `T`*nemá* žiadnu staticky známu veľkosť, napr. Plátok [`[T]`][slice] alebo [trait object], potom na získanie dynamicky známej veľkosti možno použiť `size_of_val`.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPEČNOSŤ: `val` je referencia, takže ide o platný surový ukazovateľ
    unsafe { intrinsics::size_of_val(val) }
}

/// Vráti veľkosť poukázanej hodnoty v bajtoch.
///
/// Zvyčajne je to rovnaké ako `size_of::<T>()`.Ak však `T`*nemá* žiadnu staticky známu veľkosť, napr. Plátok [`[T]`][slice] alebo [trait object], potom na získanie dynamicky známej veľkosti možno použiť `size_of_val_raw`.
///
/// # Safety
///
/// Túto funkciu je možné bezpečne zavolať, iba ak sú splnené nasledujúce podmienky:
///
/// - Ak je `T` `Sized`, táto funkcia sa dá volať vždy bezpečne.
/// - Ak je veľkosť `T` bez chvosta:
///     - a [slice], potom dĺžka chvosta rezu musí byť inicializované celé číslo a veľkosť *celej hodnoty*(dynamická dĺžka chvosta + predpona so statickou veľkosťou) sa musí zmestiť do `isize`.
///     - a [trait object], potom musí vtable časť ukazovateľa smerovať na platný vtable získaný nátlakom na zmenu veľkosti a veľkosť *celej hodnoty*(dĺžka dynamického chvosta + predpätie so statickou veľkosťou) sa musí zmestiť do `isize`.
///
///     - (unstable) [extern type], potom je táto funkcia vždy bezpečná, ale môže panic alebo inak vrátiť nesprávnu hodnotu, pretože rozloženie externého typu nie je známe.
///     Toto je rovnaké správanie ako [`size_of_val`] pri odkaze na typ s chvostom externého typu.
///     - inak nie je konzervatívne dovolené volať túto funkciu.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BEZPEČNOSŤ: volajúci musí poskytnúť platný surový ukazovateľ
    unsafe { intrinsics::size_of_val(val) }
}

/// Vráti minimálne požadované zarovnanie typu [ABI].
///
/// Každý odkaz na hodnotu typu `T` musí byť násobkom tohto čísla.
///
/// Toto je zarovnanie použité pre štruktúrne polia.Môže byť menší ako preferované zarovnanie.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vráti minimálne [ABI] požadované zarovnanie typu hodnoty, na ktorú `val` ukazuje.
///
/// Každý odkaz na hodnotu typu `T` musí byť násobkom tohto čísla.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPEČNOSŤ: val je odkaz, takže je to platný surový ukazovateľ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vráti minimálne požadované zarovnanie typu [ABI].
///
/// Každý odkaz na hodnotu typu `T` musí byť násobkom tohto čísla.
///
/// Toto je zarovnanie použité pre štruktúrne polia.Môže byť menší ako preferované zarovnanie.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vráti minimálne [ABI] požadované zarovnanie typu hodnoty, na ktorú `val` ukazuje.
///
/// Každý odkaz na hodnotu typu `T` musí byť násobkom tohto čísla.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // BEZPEČNOSŤ: val je odkaz, takže je to platný surový ukazovateľ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vráti minimálne [ABI] požadované zarovnanie typu hodnoty, na ktorú `val` ukazuje.
///
/// Každý odkaz na hodnotu typu `T` musí byť násobkom tohto čísla.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Túto funkciu je možné bezpečne zavolať, iba ak sú splnené nasledujúce podmienky:
///
/// - Ak je `T` `Sized`, táto funkcia sa dá volať vždy bezpečne.
/// - Ak je veľkosť `T` bez chvosta:
///     - a [slice], potom dĺžka chvosta rezu musí byť inicializované celé číslo a veľkosť *celej hodnoty*(dynamická dĺžka chvosta + predpona so statickou veľkosťou) sa musí zmestiť do `isize`.
///     - a [trait object], potom musí vtable časť ukazovateľa smerovať na platný vtable získaný nátlakom na zmenu veľkosti a veľkosť *celej hodnoty*(dĺžka dynamického chvosta + predpätie so statickou veľkosťou) sa musí zmestiť do `isize`.
///
///     - (unstable) [extern type], potom je táto funkcia vždy bezpečná, ale môže panic alebo inak vrátiť nesprávnu hodnotu, pretože rozloženie externého typu nie je známe.
///     Toto je rovnaké správanie ako [`align_of_val`] pri odkaze na typ s chvostom externého typu.
///     - inak nie je konzervatívne dovolené volať túto funkciu.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // BEZPEČNOSŤ: volajúci musí poskytnúť platný surový ukazovateľ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vráti `true`, ak záleží na klesajúcich hodnotách typu `T`.
///
/// Toto je čisto tip na optimalizáciu a dá sa implementovať konzervatívne:
/// môže vrátiť `true` pre typy, ktoré v skutočnosti nie je potrebné zrušiť.
/// Ako vždy by bol návrat `true` platnou implementáciou tejto funkcie.Ak však táto funkcia v skutočnosti vráti `false`, môžete si byť istí, že vynechanie `T` nemá žiadne vedľajšie účinky.
///
/// Nízkoúrovňové implementácie vecí, ako sú napríklad zbierky, ktoré potrebujú manuálne odhodiť svoje údaje, by mali pomocou tejto funkcie zabrániť zbytočnému pokusu vyhodiť všetok ich obsah, keď sú zničené.
///
/// Toto nemusí robiť zmeny v zostavách vydaní (kde sa ľahko detekuje a eliminuje slučka bez vedľajších účinkov), ale pre zostavenia ladenia je to často veľká výhra.
///
/// Upozorňujeme, že [`drop_in_place`] už túto kontrolu vykonáva, takže ak je možné vaše pracovné zaťaženie znížiť na malý počet hovorov [`drop_in_place`], je toto použitie zbytočné.
/// Obzvlášť si všimnite, že môžete rez [`drop_in_place`] a tým urobíte jedinú kontrolu need_drop všetkých hodnôt.
///
/// Typy ako Vec preto iba `drop_in_place(&mut self[..])` bez výslovného použitia `needs_drop`.
/// Na druhej strane, typy ako [`HashMap`], musia klesať hodnoty po jednom a mali by používať toto API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Tu je príklad toho, ako môže zbierka využívať `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // zahodiť údaje
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Vráti hodnotu typu `T` predstavovanú vzorom bajtov s nulovou hodnotou.
///
/// To znamená, že napríklad výplňový bajt v `(u8, u16)` nemusí byť nevyhnutne vynulovaný.
///
/// Nie je zaručené, že vzor nulového bajtu predstavuje platnú hodnotu niektorého typu `T`.
/// Napríklad nulový bajtový vzor nie je platnou hodnotou pre referenčné typy (`&T`, `&mut T`) a ukazovatele funkcií.
/// Použitie `zeroed` na takýchto typoch spôsobí okamžité [undefined behavior][ub], pretože [the Rust compiler assumes][inv], že v premennej, ktorú považuje za inicializovanú, vždy existuje platná hodnota.
///
///
/// To má rovnaký účinok ako [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Je to niekedy užitočné pre FFI, ale všeobecne by ste sa mu mali vyhnúť.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Správne použitie tejto funkcie: inicializácia celého čísla s nulou.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Nesprávne* použitie tejto funkcie: inicializácia referencie nulou.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Nedefinované správanie!
/// let _y: fn() = unsafe { mem::zeroed() }; // A znova!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // BEZPEČNOSŤ: volajúci musí zaručiť, že pre `T` je platná nulová hodnota.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Obchádza bežné kontroly inicializácie pamäte Rust predstieraním, že produkuje hodnotu typu `T`, pričom nerobí vôbec nič.
///
/// **Táto funkcia je zastaraná.** Použite radšej [`MaybeUninit<T>`].
///
/// Dôvod ukončenia podpory je ten, že funkcia sa v podstate nedá správne použiť: má rovnaký účinok ako [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Ako vysvetľuje [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv], že hodnoty sú správne inicializované.
/// V dôsledku toho volanie napr
/// `mem::uninitialized::<bool>()` spôsobí okamžité nedefinované správanie pri vrátení `bool`, ktorý určite nie je `true` ani `false`.
/// Horšie je, že skutočne neinicializovaná pamäť, ako napríklad to, čo sa sem vráti, je špeciálna v tom, že kompilátor vie, že nemá pevnú hodnotu.
/// Vďaka tomu je nedefinované správanie mať neinicializované údaje v premennej, aj keď má premenná celočíselný typ.
/// (Všimnite si, že pravidlá týkajúce sa neinicializovaných celých čísel ešte nie sú dokončené, ale kým nebudú, je vhodné sa im vyhnúť.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // BEZPEČNOSŤ: volajúci musí zaručiť, že jednotková hodnota je platná pre `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Zamení hodnoty na dvoch premenlivých miestach bez deinicializácie jedného z nich.
///
/// * Ak chcete zameniť predvolenú alebo zdanlivú hodnotu, pozrite si [`take`].
/// * Ak chcete zameniť odovzdanú hodnotu a vrátiť starú hodnotu, pozrite si [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // BEZPEČNOSŤ: nespracované ukazovatele boli vytvorené z bezpečných premenlivých odkazov, ktoré vyhovujú všetkým požiadavkám
    // obmedzenia na `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Nahradí `dest` predvolenou hodnotou `T`, vráti predchádzajúcu hodnotu `dest`.
///
/// * Ak chcete nahradiť hodnoty dvoch premenných, pozrite si [`swap`].
/// * Ak chcete namiesto prednastavenej hodnoty nahradiť odovzdanú hodnotu, pozrite si [`replace`].
///
/// # Examples
///
/// Jednoduchý príklad:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` umožňuje prevziať vlastníctvo poľa struct jeho nahradením hodnotou "empty".
/// Bez modelu `take` sa môžete stretnúť s problémami, ako sú tieto:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Upozorňujeme, že `T` nemusí nutne implementovať [`Clone`], takže nemôže ani klonovať a resetovať `self.buf`.
/// Ale `take` je možné použiť na odpojenie pôvodnej hodnoty `self.buf` od `self`, čo umožňuje jej vrátenie:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Presunie `src` do referenčného `dest` a vráti predchádzajúcu hodnotu `dest`.
///
/// Ani jedna z hodnôt neklesne.
///
/// * Ak chcete nahradiť hodnoty dvoch premenných, pozrite si [`swap`].
/// * Ak chcete nahradiť predvolenú hodnotu, pozrite si [`take`].
///
/// # Examples
///
/// Jednoduchý príklad:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` umožňuje spotrebu štruktúrovaného poľa jeho nahradením inou hodnotou.
/// Bez modelu `replace` sa môžete stretnúť s problémami, ako sú tieto:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Upozorňujeme, že `T` nemusí nutne implementovať [`Clone`], takže nemôžeme ani klonovať `self.buf[i]`, aby sme sa vyhli presunu.
/// Ale `replace` je možné použiť na odpojenie pôvodnej hodnoty v danom indexe od `self`, čo umožňuje jej vrátenie:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // BEZPEČNOSŤ: Čítame z `dest`, ale potom do neho priamo zapisujeme `src`,
    // tak, že stará hodnota nie je duplikovaná.
    // Nič nie je zahodené a nič tu nemôže panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Disponuje hodnotou.
///
/// To sa deje volaním implementácie argumentu [`Drop`][drop].
///
/// Toto efektívne nerobí nič pre typy, ktoré implementujú `Copy`, napr
/// integers.
/// Takéto hodnoty sa skopírujú a _then_ sa presunú do funkcie, takže hodnota po tomto volaní funkcie pretrváva.
///
///
/// Táto funkcia nie je mágia;je doslova definovaný ako
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Pretože `_x` je presunutý do funkcie, je automaticky zrušený pred návratom funkcie.
///
/// [drop]: Drop
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // výslovne zrušte vector
/// ```
///
/// Pretože [`RefCell`] vynucuje pravidlá výpožičky za behu, `drop` môže uvoľniť výpožičku [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // vzdať sa premenlivej výpožičky v tomto slote
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Celé čísla a ďalšie typy implementujúce [`Copy`] nie sú `drop` ovplyvnené.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kópia `x` sa presunie a zahodí
/// drop(y); // kópia `y` sa presunie a zahodí
///
/// println!("x: {}, y: {}", x, y.0); // stále dostupný
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretuje `src` ako typ `&U` a potom číta `src` bez presunutia obsiahnutej hodnoty.
///
/// Táto funkcia bude bezpečne predpokladať, že ukazovateľ `src` je platný pre bajty [`size_of::<U>`][size_of] transmutáciou `&T` na `&U` a následným načítaním `&U` (okrem toho, že sa tak deje správnym spôsobom, aj keď `&U` vyžaduje prísnejšie požiadavky na zarovnanie ako `&T`).
/// Namiesto presunutia mimo `src` tiež nebezpečne vytvorí kópiu obsiahnutej hodnoty.
///
/// Nejde o chybu v čase kompilácie, ak majú modely `T` a `U` rôzne veľkosti, ale veľmi sa odporúča vyvolať túto funkciu iba vtedy, keď majú modely `T` a `U` rovnakú veľkosť.Táto funkcia spustí [undefined behavior][ub], ak je `U` väčšia ako `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Skopírujte údaje z 'foo_array' a považujte ich za 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Upravte skopírované údaje
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Obsah 'foo_array' sa nemal meniť
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ak má U vyššiu požiadavku na zarovnanie, nemusí byť src vhodne vyrovnaný.
    if align_of::<U>() > align_of::<T>() {
        // BEZPEČNOSŤ: `src` je referencia, ktorá je zaručene platná pre čítanie.
        // Volajúci musí zaručiť, že skutočná premena je bezpečná.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // BEZPEČNOSŤ: `src` je referencia, ktorá je zaručene platná pre čítanie.
        // Len sme skontrolovali, či je `src as *const U` správne zarovnaný.
        // Volajúci musí zaručiť, že skutočná premena je bezpečná.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Nepriehľadný typ predstavujúci diskriminátora enum.
///
/// Ďalšie informácie nájdete v časti Funkcia [`discriminant`] v tomto module.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Tieto implementácie trait nemožno odvodiť, pretože na T. nechceme žiadne hranice.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Vráti hodnotu jednoznačne identifikujúcu variant enum v `v`.
///
/// Ak `T` nie je enum, volanie tejto funkcie nebude mať za následok nedefinované správanie, ale návratová hodnota je nešpecifikovaná.
///
///
/// # Stability
///
/// Diskriminujúci variant enum sa môže zmeniť, ak sa zmení definícia enum.
/// Diskriminujúci niektorý variant sa medzi kompiláciami s rovnakým prekladačom nezmení.
///
/// # Examples
///
/// To možno použiť na porovnanie enumov, ktoré prenášajú údaje, bez ohľadu na skutočné údaje:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Vráti počet variantov typu enum `T`.
///
/// Ak `T` nie je enum, volanie tejto funkcie nebude mať za následok nedefinované správanie, ale návratová hodnota je nešpecifikovaná.
/// Rovnako, ak `T` je enum s viac variantmi ako `usize::MAX`, návratová hodnota je nešpecifikovaná.
/// Neobývané varianty sa budú počítať.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}