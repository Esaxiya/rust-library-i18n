use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Obal, ktorý zabráni kompilátoru v automatickom volaní deštruktora `T`.
/// Tento obal je bez nákladov.
///
/// `ManuallyDrop<T>` podlieha rovnakým optimalizáciám rozloženia ako `T`.
/// V dôsledku toho nemá *žiadny vplyv* na predpoklady kompilátora týkajúce sa jeho obsahu.
/// Napríklad inicializácia `ManuallyDrop<&mut T>` pomocou [`mem::zeroed`] je nedefinované správanie.
/// Ak potrebujete spracovať neinicializované údaje, použite radšej [`MaybeUninit<T>`].
///
/// Upozorňujeme, že prístup k hodnote vo vnútri `ManuallyDrop<T>` je bezpečný.
/// To znamená, že `ManuallyDrop<T>`, ktorého obsah bol zahodený, nesmie byť vystavený cez verejné bezpečné API.
/// Zodpovedajúcim spôsobom je `ManuallyDrop::drop` nebezpečný.
///
/// # `ManuallyDrop` a zrušiť objednávku.
///
/// Rust má presne definovaných [drop order] hodnôt.
/// Ak sa chcete ubezpečiť, že polia alebo miestni obyvatelia sú zrušené v konkrétnom poradí, usporiadajte zostavy deklarácií tak, aby bolo implicitné poradie presunov správne.
///
/// Na kontrolu poradia presunov je možné použiť `ManuallyDrop`, vyžaduje to však nebezpečný kód a je ťažké ho vykonať správne v prípade rozvinutia.
///
///
/// Ak sa napríklad chcete ubezpečiť, že konkrétne pole je za ostatnými, zrušte ho, urobte z neho posledné pole štruktúry:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` bude zrušené po `children`.
///     // Rust zaručuje, že polia budú zrušené v poradí deklarácie.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Zbaliť hodnotu, ktorá sa má manuálne vypustiť.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Na hodnote môžete stále bezpečne pracovať
    /// assert_eq!(*x, "Hello");
    /// // `Drop` tu ale nebude bežať
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Extrahuje hodnotu z kontajnera `ManuallyDrop`.
    ///
    /// To umožňuje opätovné zníženie hodnoty.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Týmto vypadne `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Vyberie hodnotu z kontajnera `ManuallyDrop<T>`.
    ///
    /// Táto metóda je primárne určená na presunutie hodnôt v poklese.
    /// Namiesto manuálneho poklesu hodnoty pomocou [`ManuallyDrop::drop`] môžete pomocou tejto metódy hodnotu prevziať a použiť ju, ako je to žiaduce.
    ///
    /// Vždy, keď je to možné, je lepšie použiť radšej [`into_inner`][`ManuallyDrop::into_inner`], čo zabráni duplikovaniu obsahu `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Táto funkcia sémanticky presunie obsiahnutú hodnotu bez toho, aby zabránila ďalšiemu použitiu, pričom stav tohto kontajnera zostane nezmenený.
    /// Je vašou zodpovednosťou zabezpečiť, aby sa tento `ManuallyDrop` už nepoužíval.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // BEZPEČNOSŤ: čítame z referencie, ktorá je zaručená
        // byť platný pre čítanie.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ručne klesne obsiahnutá hodnota.Toto je presne ekvivalent volania [`ptr::drop_in_place`] s ukazovateľom na obsiahnutú hodnotu.
    /// Preto, pokiaľ obsiahnutá hodnota nie je zabalená štruktúra, bude sa destruktor nazývať na mieste bez toho, aby sa hodnota presunula, a dá sa teda použiť na bezpečné vyhodenie údajov [pinned].
    ///
    /// Ak ste vlastníkom tejto hodnoty, môžete namiesto toho použiť [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Táto funkcia spustí deštruktor obsiahnutej hodnoty.
    /// Okrem zmien vykonaných samotným deštruktorom zostáva pamäť nezmenená, a teda pokiaľ ide o kompilátor, stále obsahuje bitový vzor platný pre typ `T`.
    ///
    ///
    /// Táto hodnota "zombie" by však nemala byť vystavená bezpečnému kódu a táto funkcia by sa nemala volať viackrát.
    /// Ak chcete použiť hodnotu po jej vypustení alebo ju opakovane vypustiť, môže to spôsobiť nedefinované správanie (v závislosti od toho, čo robí `drop`).
    /// Normálne tomu typový systém zabráni, ale používatelia `ManuallyDrop` musia tieto záruky dodržiavať bez pomoci kompilátora.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // BEZPEČNOSŤ: znižujeme hodnotu, na ktorú poukazuje premenlivý odkaz
        // ktorý je zaručene platný pre zápisy.
        // Je na volajúcom, aby sa ubezpečil, že `slot` už neklesne.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}