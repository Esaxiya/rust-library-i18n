use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Aj keď sa táto funkcia používa na jednom mieste a jej implementácia sa dá podčiarknuť, predchádzajúce pokusy o jej vykonanie spôsobili, že rustc bol pomalší:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Usporiadanie bloku pamäte.
///
/// Inštancia `Layout` popisuje konkrétne rozloženie pamäte.
/// Zostavíte `Layout` ako vstup, ktorý poskytnete prideľovaču.
///
/// Všetky rozloženia majú priradenú veľkosť a vyrovnanie sily dvoch.
///
/// (Upozorňujeme, že rozloženia *nie sú* povinné, ak majú nenulovú veľkosť, aj keď `GlobalAlloc` vyžaduje, aby všetky požiadavky na pamäť boli nenulové.
/// Volajúci musí zabezpečiť, aby boli splnené podmienky, ako je tento, použiť špecifické prideľovače s voľnejšími požiadavkami alebo použiť miernejšie rozhranie `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // veľkosť požadovaného bloku pamäte, meraná v bajtoch.
    size_: usize,

    // zarovnanie požadovaného bloku pamäte, merané v bajtoch.
    // Zaisťujeme, že toto je vždy sila dvoch, pretože API ako `posix_memalign` to vyžadujú a je to rozumné obmedzenie, ktoré treba uložiť konštruktérom rozloženia.
    //
    //
    // (Analogicky však nevyžadujeme `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Vytvorí `Layout` z daných `size` a `align` alebo vráti `LayoutError`, ak nie je splnená niektorá z nasledujúcich podmienok:
    ///
    /// * `align` nesmie byť nula,
    ///
    /// * `align` musí byť sila dvoch,
    ///
    /// * `size`, ak je zaokrúhlená na najbližší násobok `align`, nesmie pretekať (tj. zaokrúhlená hodnota musí byť menšia alebo rovná `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (dvojitá sila znamená zarovnanie!=0.)

        // Zaokrúhlená veľkosť je:
        //   size_rounded_up=(size + align, 1)&! (align, 1);
        //
        // Zhora vieme, že zarovnanie!=0.
        // Ak pridanie (zarovnanie, 1) nepreteká, bude zaokrúhľovanie nahor dobré.
        //
        // Naopak,&-masking with! (Align, 1) bude odpočítavať iba od bitov nižšieho rádu.
        // Ak teda dôjde k pretečeniu so súčtom,&-mask sa nemôže dostatočne odpočítať, aby sa toto pretečenie vrátilo.
        //
        //
        // Vyššie uvedené znamená, že kontrola pretečenia súčtu je nevyhnutná a dostatočná.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // BEZPEČNOSŤ: podmienky pre `from_size_align_unchecked` boli
        // skontrolované vyššie.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Vytvorí rozloženie, obchádza všetky kontroly.
    ///
    /// # Safety
    ///
    /// Táto funkcia je nebezpečná, pretože neoveruje predpoklady z [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // BEZPEČNOSŤ: volajúci musí zabezpečiť, aby hodnota `align` bola väčšia ako nula.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minimálna veľkosť v bajtoch pre pamäťový blok tohto rozloženia.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Minimálne zarovnanie bajtov pre pamäťový blok tohto rozloženia.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Zostrojí `Layout` vhodný na uchovanie hodnoty typu `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // BEZPEČNOSŤ: vyrovnanie je zaručené Rust ako sila dvoch a
        // kombinácia combo size + align sa zaručene zmestí do nášho adresného priestoru.
        // Výsledkom je použitie nekontrolovaného konštruktora, aby ste sa vyhli vloženiu kódu panics, ak nie je dostatočne optimalizovaný.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produkuje rozloženie popisujúce záznam, ktorý by sa mohol použiť na pridelenie podpornej štruktúry pre `T` (čo môže byť trait alebo iný typ bez veľkosti, napríklad rez).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZPEČNOSŤ: prečítajte si odôvodnenie v dokumente `new`, prečo sa používa nebezpečný variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Produkuje rozloženie popisujúce záznam, ktorý by sa mohol použiť na pridelenie podpornej štruktúry pre `T` (čo môže byť trait alebo iný typ bez veľkosti, napríklad rez).
    ///
    /// # Safety
    ///
    /// Túto funkciu je možné bezpečne zavolať, iba ak sú splnené nasledujúce podmienky:
    ///
    /// - Ak je `T` `Sized`, táto funkcia sa dá volať vždy bezpečne.
    /// - Ak je veľkosť `T` bez chvosta:
    ///     - a [slice], potom dĺžka chvosta rezu musí byť intializované celé číslo a veľkosť *celej hodnoty*(dynamická dĺžka chvosta + predpona so statickou veľkosťou) sa musí zmestiť do `isize`.
    ///     - a [trait object], potom musí vtable časť ukazovateľa smerovať na platnú vtable pre typ `T` získanú nemerzívnou koerziou a veľkosť *celej hodnoty*(dynamická dĺžka chvosta + predpona statickej veľkosti) musí zodpovedať `isize`.
    ///
    ///     - (unstable) [extern type], potom je táto funkcia vždy bezpečná, ale môže panic alebo inak vrátiť nesprávnu hodnotu, pretože rozloženie externého typu nie je známe.
    ///     Toto je rovnaké správanie ako [`Layout::for_value`] pri odkaze na chvost externého typu.
    ///     - inak nie je konzervatívne dovolené volať túto funkciu.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // BEZPEČNOSŤ: predpoklady týchto funkcií odovzdáme volajúcemu
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // BEZPEČNOSŤ: prečítajte si odôvodnenie v dokumente `new`, prečo sa používa nebezpečný variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Vytvorí `NonNull`, ktorý je visiaci, ale pre toto rozloženie dobre zarovnaný.
    ///
    /// Upozorňujeme, že hodnota ukazovateľa môže potenciálne predstavovať platný ukazovateľ, čo znamená, že sa nesmie používať ako kontrolná hodnota "not yet initialized".
    /// Typy, ktoré lenivo alokujú, musia sledovať inicializáciu nejakými inými prostriedkami.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // BEZPEČNOSŤ: Zarovnanie je zaručene nenulové
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Vytvorí rozloženie popisujúce záznam, ktoré môže obsahovať hodnotu rovnakého rozloženia ako `self`, ale ktoré je tiež zarovnané k zarovnaniu `align` (merané v bajtoch).
    ///
    ///
    /// Ak `self` už spĺňa predpísané zarovnanie, vráti `self`.
    ///
    /// Upozorňujeme, že táto metóda nepridáva k celkovej veľkosti žiadne polstrovanie bez ohľadu na to, či má vrátené rozloženie odlišné zarovnanie.
    /// Inými slovami, ak má `K` veľkosť 16, `K.align_to(32)` bude *stále* mať veľkosť 16.
    ///
    /// Vráti chybu, ak kombinácia `self.size()` a daného `align` porušuje podmienky uvedené v [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Vráti množstvo odsadenia, ktoré musíme vložiť za `self`, aby sme zaistili, že nasledujúca adresa bude vyhovovať `align` (merané v bajtoch).
    ///
    /// napr. ak je `self.size()` 9, potom `self.padding_needed_for(4)` vráti 3, pretože to je minimálny počet bajtov výplne potrebný na získanie adresy 4-zarovnanej (za predpokladu, že zodpovedajúci blok pamäte začína na adrese 4-zarovnanej).
    ///
    ///
    /// Návratová hodnota tejto funkcie nemá žiadny význam, ak `align` nie je sila dvoch.
    ///
    /// Všimnite si, že užitočnosť vrátenej hodnoty vyžaduje, aby `align` bolo menšie alebo rovnaké ako zarovnanie počiatočnej adresy pre celý pridelený blok pamäte.Jedným zo spôsobov, ako uspokojiť toto obmedzenie, je zabezpečenie `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Zaokrúhlená hodnota je:
        //   len_rounded_up=(len + zarovnať, 1)&! (zarovnať, 1);
        // a potom vrátime rozdiel výplne: `len_rounded_up - len`.
        //
        // Modulárnu aritmetiku používame v nasledujúcich jazykoch:
        //
        // 1. Zarovnanie je zaručene> 0, takže zarovnanie, 1 je vždy platné.
        //
        // 2.
        // `len + align - 1` môže pretekať najviac `align - 1`, takže&-mask s `!(align - 1)` zabezpečí, že v prípade pretečenia bude `len_rounded_up` sám o sebe 0.
        //
        //    Vrátená výplň teda po pridaní k `len` dáva 0, čo triviálne uspokojuje zarovnanie `align`.
        //
        // (Samozrejme, pokusy o pridelenie blokov pamäte, ktorých veľkosť a výplň pretekajú vyššie uvedeným spôsobom, by rovnako mali spôsobiť, že alokátor spôsobí chybu.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Vytvorí rozloženie zaokrúhlením veľkosti tohto rozloženia na násobok zarovnania rozloženia.
    ///
    ///
    /// Toto je ekvivalentné pridaniu výsledku `padding_needed_for` k aktuálnej veľkosti rozloženia.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Toto nemôže pretekať.Citát z invariantu rozloženia:
        // > `size`, po zaokrúhlení na najbližší násobok `align` nahor,
        // > nesmie pretekať (tj zaokrúhlená hodnota musí byť menšia ako
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Vytvorí rozloženie popisujúce záznam pre inštancie `n` pre `self` s vhodným množstvom polstrovania medzi každou, aby sa zaistilo, že každej inštancii bude poskytnutá požadovaná veľkosť a zarovnanie.
    /// Pri úspechu vráti `(k, offs)`, kde `k` je rozloženie poľa a `offs` je vzdialenosť medzi začiatkom každého prvku v poli.
    ///
    /// Pri aritmetickom pretečení vráti `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Toto nemôže pretekať.Citát z invariantu rozloženia:
        // > `size`, po zaokrúhlení na najbližší násobok `align` nahor,
        // > nesmie pretekať (tj zaokrúhlená hodnota musí byť menšia ako
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // BEZPEČNOSŤ: O produkte self.align je už známe, že je platný, a alloc_size už bol
        // už polstrované.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Vytvorí rozloženie popisujúce záznam pre `self`, za ktorým nasleduje `next`, vrátane všetkých potrebných výplní, aby sa zabezpečilo správne zarovnanie `next`, ale *žiadne koncové výplne*.
    ///
    /// Aby ste sa zhodovali s rozložením reprezentácie C `repr(C)`, mali by ste zavolať `pad_to_align` po rozšírení rozloženia o všetky polia.
    /// (Neexistuje žiadny spôsob, ako zodpovedať predvolenému rozloženiu zastúpenia Rust `repr(Rust)`, as it is unspecified.)
    ///
    /// Upozorňujeme, že zarovnanie výsledného rozloženia bude maximálne také, ako je zoskupenie `self` a `next`, aby sa zabezpečilo vyrovnanie oboch častí.
    ///
    /// Vráti `Ok((k, offset))`, kde `k` je rozloženie zreťazeného záznamu a `offset` je relatívne umiestnenie v bajtoch začiatku `next` vloženého do zreťazeného záznamu (za predpokladu, že samotný záznam začína posunom 0).
    ///
    ///
    /// Pri aritmetickom pretečení vráti `LayoutError`.
    ///
    /// # Examples
    ///
    /// Ak chcete vypočítať rozloženie štruktúry `#[repr(C)]` a posuny polí z rozložení jej polí:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Nezabudnite finalizovať pomocou `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // vyskúšajte, či to funguje
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Vytvorí rozloženie popisujúce záznam pre inštancie `n` pre `self` bez polstrovania medzi každou inštanciou.
    ///
    /// Upozorňujeme, že na rozdiel od `repeat`, `repeat_packed` nezaručuje, že opakované inštancie `self` budú správne zarovnané, aj keď je daná inštancia `self` správne zarovnaná.
    /// Inými slovami, ak sa na pridelenie poľa použije rozloženie vrátené `repeat_packed`, nie je zaručené, že všetky prvky v poli budú správne zarovnané.
    ///
    /// Pri aritmetickom pretečení vráti `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Vytvorí rozloženie popisujúce záznam pre `self`, za ktorým nasleduje `next`, bez ďalšej výplne medzi nimi.
    /// Pretože nie je vložená žiadna výplň, je zarovnanie `next` irelevantné a nie je do výsledného rozloženia začlenené *vôbec*.
    ///
    ///
    /// Pri aritmetickom pretečení vráti `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Vytvorí rozloženie popisujúce záznam pre `[T; n]`.
    ///
    /// Pri aritmetickom pretečení vráti `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametre dané `Layout::from_size_align` alebo nejakému inému konštruktoru `Layout` nespĺňajú jeho zdokumentované obmedzenia.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (potrebujeme to pre následný impl chyby trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}