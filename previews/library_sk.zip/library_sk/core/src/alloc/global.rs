use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Alokátor pamäte, ktorý je možné zaregistrovať ako predvolenú štandardnú knižnicu prostredníctvom atribútu `#[global_allocator]`.
///
/// Niektoré z metód vyžadujú, aby bol pamäťový blok *aktuálne alokovaný* prostredníctvom alokátora.To znamená, že:
///
/// * počiatočná adresa pre tento pamäťový blok bola predtým vrátená predchádzajúcim volaním metódy alokácie, ako napríklad `alloc`, a
///
/// * pamäťový blok nebol následne uvoľnený, kde bloky sú uvoľnené buď odovzdaním metóde zrušenia pridelenia, ako je `dealloc`, alebo odovzdaním metóde opätovného pridelenia, ktorá vráti nenulový ukazovateľ.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait je `unsafe` trait z mnohých dôvodov a implementátori sa musia ubezpečiť, že dodržiavajú tieto zmluvy:
///
/// * Ak sa globálni alokátori uvoľnia, je to nedefinované správanie.Toto obmedzenie sa môže v future zrušiť, ale v súčasnosti môže panic z ktorejkoľvek z týchto funkcií viesť k bezpečnosti pamäte.
///
/// * `Layout` dotazy a výpočty musia byť vo všeobecnosti správne.Volajúci tejto trait sa môžu spoľahnúť na zmluvy definované pre každú metódu a implementátori musia zabezpečiť, aby tieto zmluvy zostali pravdivé.
///
/// * Možno sa nebudete spoliehať na to, že sa pridelenia skutočne uskutočnia, aj keď sú v zdroji výslovne pridelené haldy.
/// Optimalizátor môže zistiť nevyužité pridelenia, ktoré môže buď úplne vylúčiť, alebo sa presunúť do zásobníka, a teda nikdy nevyvolá alokátor.
/// Optimalizátor môže ďalej predpokladať, že alokácia je neomylná, takže kód, ktorý zlyhal v dôsledku zlyhania alokátora, môže teraz náhle fungovať, pretože optimalizátor obišiel potrebu alokácie.
/// Konkrétnejšie, nasledujúci príklad kódu je nepríjemný, bez ohľadu na to, či váš vlastný alokátor umožňuje počítať, koľko alokácií sa stalo.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Upozorňujeme, že vyššie uvedené optimalizácie nie sú jedinou optimalizáciou, ktorú je možné použiť.Vo všeobecnosti sa nemusíte spoliehať na to, že dôjde k prideleniu haldy, ak ich možno odstrániť bez zmeny správania programu.
///   To, či k prideleniu dôjde alebo nie, nie je súčasťou správania programu, aj keď by ho bolo možné zistiť pomocou prideľovača, ktorý sleduje pridelenia tlačou alebo iným spôsobom s vedľajšími účinkami.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Prideľte pamäť podľa popisu v danom `layout`.
    ///
    /// Vráti ukazovateľ na novo pridelenú pamäť alebo nulovú hodnotu, ktorá indikuje zlyhanie alokácie.
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná, pretože môže dôjsť k nedefinovanému správaniu, ak volajúci nezabezpečí, že `layout` má nenulovú veľkosť.
    ///
    /// (Subtraity rozšírenia môžu poskytovať konkrétnejšie hranice správania, napr. Zaručiť sentinelovú adresu alebo nulový ukazovateľ v reakcii na žiadosť o pridelenie nulovej veľkosti.)
    ///
    /// Alokovaný blok pamäte môže alebo nemusí byť inicializovaný.
    ///
    /// # Errors
    ///
    /// Vrátenie nulového ukazovateľa naznačuje, že buď je pamäť vyčerpaná, alebo `layout` nespĺňa obmedzenia veľkosti a zarovnania tohto alokátora.
    ///
    /// Implementáciam sa odporúča vrátiť nulovú hodnotu vyčerpania pamäte namiesto prerušenia, ale nejde o prísnu požiadavku.
    /// (Konkrétne: je *legálne* implementovať tento trait na vrchu základnej natívnej alokačnej knižnice, ktorá sa prerušuje pri vyčerpaní pamäte.)
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu pri prideľovaní, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Blok pamäte uvoľnite v danom ukazovateli `ptr` s daným `layout`.
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná, pretože nedefinované správanie môže mať za následok, ak volajúci nezabezpečí všetko nasledovné:
    ///
    ///
    /// * `ptr` musí označovať blok pamäte aktuálne pridelený prostredníctvom tohto prideľovača,
    ///
    /// * `layout` musí byť rovnaké rozloženie, aké bolo použité na pridelenie daného bloku pamäte.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Chová sa ako `alloc`, ale tiež zaisťuje, že je obsah pred vrátením nastavený na nulu.
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná z rovnakých dôvodov ako `alloc`.
    /// Zaradený blok pamäte je však zaručene inicializovaný.
    ///
    /// # Errors
    ///
    /// Vrátenie nulového ukazovateľa naznačuje, že buď je pamäť vyčerpaná, alebo `layout` nespĺňa obmedzenia veľkosti a zarovnania alokátora, rovnako ako v prípade `alloc`.
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu pri prideľovaní, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu pre `alloc`.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // BEZPEČNOSŤ: ako bolo pridelenie úspešné, región od `ptr`
            // veľkosti `size` je zaručene platná pre zápisy.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Zmenšiť alebo zväčšiť blok pamäte na danú `new_size`.
    /// Blok je opísaný daným ukazovateľom `ptr` a `layout`.
    ///
    /// Ak toto vráti nenulový ukazovateľ, potom sa vlastníctvo pamäťového bloku, na ktoré odkazuje `ptr`, prenieslo do tohto alokátora.
    /// Pamäť mohla alebo nemusí byť alokovaná a mala by sa považovať za nepoužiteľnú (pokiaľ samozrejme nebola prenesená späť volajúcemu znova prostredníctvom návratovej hodnoty tejto metódy).
    /// Nový blok pamäte je pridelený `layout`, ale s `size` aktualizovaným na `new_size`.
    /// Toto nové rozloženie by sa malo použiť pri prerozdeľovaní nového pamäťového bloku pomocou `dealloc`.
    /// Je zaručené, že rozsah `0..min(layout.size(), new_size) `nového pamäťového bloku bude mať rovnaké hodnoty ako pôvodný blok.
    ///
    /// Ak táto metóda vráti hodnotu null, potom sa vlastníctvo pamäťového bloku neprenieslo do tohto prideľovača a obsah pamäťového bloku sa nezmení.
    ///
    /// # Safety
    ///
    /// Táto funkcia nie je bezpečná, pretože nedefinované správanie môže mať za následok, ak volajúci nezabezpečí všetko nasledovné:
    ///
    /// * `ptr` musia byť v súčasnosti pridelené prostredníctvom tohto prideľovača,
    ///
    /// * `layout` musí byť rovnaké rozloženie, aké bolo použité na pridelenie daného bloku pamäte,
    ///
    /// * `new_size` musí byť väčšie ako nula.
    ///
    /// * `new_size`, ak je zaokrúhlená na najbližší násobok `layout.align()`, nesmie pretekať (tj zaokrúhlená hodnota musí byť menšia ako `usize::MAX`).
    ///
    /// (Subtraity rozšírenia môžu poskytovať konkrétnejšie hranice správania, napr. Zaručiť sentinelovú adresu alebo nulový ukazovateľ v reakcii na žiadosť o pridelenie nulovej veľkosti.)
    ///
    /// # Errors
    ///
    /// Vráti hodnotu null, ak nové rozloženie nespĺňa obmedzenia veľkosti a zarovnania alokátora, alebo ak prerozdelenie inak zlyhá.
    ///
    /// Implementácia sa odporúča vrátiť skôr na nulové vyčerpanie pamäte, než na paniku alebo prerušenie, ale nejde o prísnu požiadavku.
    /// (Konkrétne: je *legálne* implementovať tento trait na vrchu základnej natívnej alokačnej knižnice, ktorá sa prerušuje pri vyčerpaní pamäte.)
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu v realokácii, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // BEZPEČNOSŤ: volajúci musí zabezpečiť, aby `new_size` nepretekal.
        // `layout.align()` pochádza z `Layout` a je teda zaručene platný.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // BEZPEČNOSŤ: volajúci musí zabezpečiť, aby hodnota `new_layout` bola väčšia ako nula.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // BEZPEČNOSŤ: predtým pridelený blok nemôže prekrývať novo pridelený blok.
            // Bezpečnostnú zmluvu pre `dealloc` musí volajúci dodržať.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}