//! Rozhrania API na prideľovanie pamäte

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Chyba `AllocError` indikuje zlyhanie alokácie, ktoré môže byť spôsobené vyčerpaním prostriedkov alebo niečím nesprávnym pri kombinácii daných vstupných argumentov s týmto alokátorom.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (potrebujeme to pre následný impl chyby trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implementácia `Allocator` môže alokovať, zväčšovať, zmenšovať a prideľovať ľubovoľné bloky dát popísaných prostredníctvom [`Layout`][].
///
/// `Allocator` je navrhnutý na implementáciu v ZST, referenciách alebo inteligentných ukazovateľoch, pretože mať alokátor ako `MyAlloc([u8; N])` nemožno presunúť bez aktualizácie ukazovateľov na pridelenú pamäť.
///
/// Na rozdiel od [`GlobalAlloc`][] sú v `Allocator` povolené alokácie nulovej veľkosti.
/// Ak to podkladový alokátor nepodporuje (napríklad jemalloc) alebo vracia nulový ukazovateľ (napríklad `libc::malloc`), musí to implementácia zachytiť.
///
/// ### Aktuálne pridelená pamäť
///
/// Niektoré z metód vyžadujú, aby bol pamäťový blok *aktuálne alokovaný* prostredníctvom alokátora.To znamená, že:
///
/// * počiatočná adresa pre tento pamäťový blok bola predtým vrátená znakmi [`allocate`], [`grow`] alebo [`shrink`] a
///
/// * pamäťový blok nebol dodatočne uvoľnený, kde bloky sú uvoľnené priamo odovzdaním do [`deallocate`] alebo boli zmenené odovzdaním do [`grow`] alebo [`shrink`], ktoré vracia `Ok`.
///
/// Ak `grow` alebo `shrink` vrátili `Err`, odovzdaný ukazovateľ zostáva v platnosti.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Pamäťové vybavenie
///
/// Niektoré z metód vyžadujú, aby rozloženie *vyhovovalo* pamäťovému bloku.
/// Čo to znamená pre rozloženie na "fit" pamäťový blok znamená (alebo ekvivalentne pre pamäťový blok pre "fit" rozloženie) je to, že musia platiť nasledujúce podmienky:
///
/// * Blok musí byť pridelený s rovnakým zarovnaním ako [`layout.align()`], a
///
/// * Poskytnutá [`layout.size()`] musí spadať do rozsahu `min ..= max`, kde:
///   - `min` je veľkosť rozloženia, ktoré sa naposledy použilo na pridelenie bloku, a
///   - `max` je najnovšia skutočná veľkosť vrátená z [`allocate`], [`grow`] alebo [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Pamäťové bloky vrátené od alokátora musia ukazovať na platnú pamäť a zachovať si svoju platnosť, kým inštancia a všetky jej klony nebudú zrušené,
///
/// * klonovanie alebo presunutie alokátora nesmie zneplatniť pamäťové bloky vrátené z tohto alokátora.Klonovaný alokátor sa musí správať ako ten istý alokátor a
///
/// * akýkoľvek ukazovateľ na blok pamäte, ktorý je [*currently allocated*], môže byť odovzdaný ktorejkoľvek inej metóde alokátora.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Pokusy o pridelenie bloku pamäte.
    ///
    /// Pri úspechu vráti [`NonNull<[u8]>`][NonNull], ktorý spĺňa záruky veľkosti a zarovnania `layout`.
    ///
    /// Vrátený blok môže mať väčšiu veľkosť, ako je špecifikované v `layout.size()`, a môže alebo nemusí mať inicializovaný obsah.
    ///
    /// # Errors
    ///
    /// Vrátenie `Err` naznačuje, že buď je pamäť vyčerpaná, alebo `layout` nespĺňa obmedzenia veľkosti a zarovnania alokátora.
    ///
    /// Implementáciam sa odporúča vrátiť `Err` skôr na vyčerpanie pamäte ako na paniku alebo prerušenie, ale nejde o prísnu požiadavku.
    /// (Konkrétne: je *legálne* implementovať tento trait na vrchu základnej natívnej alokačnej knižnice, ktorá sa prerušuje pri vyčerpaní pamäte.)
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu pri prideľovaní, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Chová sa ako `allocate`, ale tiež zaisťuje nulovú inicializáciu vrátenej pamäte.
    ///
    /// # Errors
    ///
    /// Vrátenie `Err` naznačuje, že buď je pamäť vyčerpaná, alebo `layout` nespĺňa obmedzenia veľkosti a zarovnania alokátora.
    ///
    /// Implementáciam sa odporúča vrátiť `Err` skôr na vyčerpanie pamäte ako na paniku alebo prerušenie, ale nejde o prísnu požiadavku.
    /// (Konkrétne: je *legálne* implementovať tento trait na vrchu základnej natívnej alokačnej knižnice, ktorá sa prerušuje pri vyčerpaní pamäte.)
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu pri prideľovaní, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // BEZPEČNOSŤ: `alloc` vráti platný blok pamäte
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Uvoľňuje pamäť, na ktorú odkazuje `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovať blok pamäte [*currently allocated*] prostredníctvom tohto prideľovača a
    /// * `layout` musí [*fit*] ten blok pamäte.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Pokusy o rozšírenie pamäťového bloku.
    ///
    /// Vráti nový [`NonNull<[u8]>`][NonNull] obsahujúci ukazovateľ a skutočnú veľkosť pridelenej pamäte.Ukazovateľ je vhodný na uchovávanie údajov opísaných v `new_layout`.
    /// Za týmto účelom môže alokátor rozšíriť alokáciu, na ktorú odkazuje `ptr`, aby sa zmestila do nového rozloženia.
    ///
    /// Ak sa vráti `Ok`, potom sa vlastníctvo pamäťového bloku, na ktorý odkazuje `ptr`, prenieslo do tohto prideľovača.
    /// Pamäť mohla alebo nemusí byť uvoľnená a mala by sa považovať za nepoužiteľnú, pokiaľ nebola opätovne prenesená späť volajúcemu prostredníctvom návratovej hodnoty tejto metódy.
    ///
    /// Ak táto metóda vráti `Err`, potom sa vlastníctvo pamäťového bloku neprenieslo do tohto prideľovača a obsah pamäťového bloku sa nezmení.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovať blok pamäte [*currently allocated*] cez tento alokátor.
    /// * `old_layout` musí [*fit*] tento blok pamäte (Argument `new_layout` sa naň nemusí zmestiť.).
    /// * `new_layout.size()` musí byť väčší alebo rovný `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vráti `Err`, ak nové rozloženie nespĺňa obmedzenia alokátora obmedzenia alokátora alokátora alokátora, alebo ak zväčšenie zlyhá.
    ///
    /// Implementáciam sa odporúča vrátiť `Err` skôr na vyčerpanie pamäte ako na paniku alebo prerušenie, ale nejde o prísnu požiadavku.
    /// (Konkrétne: je *legálne* implementovať tento trait na vrchu základnej natívnej alokačnej knižnice, ktorá sa prerušuje pri vyčerpaní pamäte.)
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu pri prideľovaní, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BEZPEČNOSŤ: pretože `new_layout.size()` musí byť väčší alebo rovný
        // `old_layout.size()`, alokácia starej aj novej pamäte je platná pre čítanie a zápis pre bajty `old_layout.size()`.
        // Pretože stará alokácia ešte nebola uvoľnená, nemôže sa prekrývať s `new_ptr`.
        // Hovor na `copy_nonoverlapping` je teda bezpečný.
        // Bezpečnostnú zmluvu pre `dealloc` musí volajúci dodržať.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Chová sa ako `grow`, ale tiež zaisťuje, že nový obsah je pred vrátením nastavený na nulu.
    ///
    /// Po úspešnom vyvolaní čísla bude blok pamäte obsahovať nasledujúci obsah
    /// `grow_zeroed`:
    ///   * Bajty `0..old_layout.size()` sa zachovajú z pôvodného pridelenia.
    ///   * Bajty `old_layout.size()..old_size` sa buď zachovajú, alebo vynulujú, v závislosti od implementácie prideľovača.
    ///   `old_size` odkazuje na veľkosť pamäťového bloku pred volaním `grow_zeroed`, ktorá môže byť väčšia ako veľkosť, ktorá bola pôvodne požadovaná pri jeho pridelení.
    ///   * Bajty `old_size..new_size` sú vynulované.`new_size` označuje veľkosť bloku pamäte vráteného volaním `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovať blok pamäte [*currently allocated*] cez tento alokátor.
    /// * `old_layout` musí [*fit*] tento blok pamäte (Argument `new_layout` sa naň nemusí zmestiť.).
    /// * `new_layout.size()` musí byť väčší alebo rovný `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vráti `Err`, ak nové rozloženie nespĺňa obmedzenia alokátora obmedzenia alokátora alokátora alokátora, alebo ak zväčšenie zlyhá.
    ///
    /// Implementáciam sa odporúča vrátiť `Err` skôr na vyčerpanie pamäte ako na paniku alebo prerušenie, ale nejde o prísnu požiadavku.
    /// (Konkrétne: je *legálne* implementovať tento trait na vrchu základnej natívnej alokačnej knižnice, ktorá sa prerušuje pri vyčerpaní pamäte.)
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu pri prideľovaní, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // BEZPEČNOSŤ: pretože `new_layout.size()` musí byť väčší alebo rovný
        // `old_layout.size()`, alokácia starej aj novej pamäte je platná pre čítanie a zápis pre bajty `old_layout.size()`.
        // Pretože stará alokácia ešte nebola uvoľnená, nemôže sa prekrývať s `new_ptr`.
        // Hovor na `copy_nonoverlapping` je teda bezpečný.
        // Bezpečnostnú zmluvu pre `dealloc` musí volajúci dodržať.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Pokusy o zmenšenie pamäťového bloku.
    ///
    /// Vráti nový [`NonNull<[u8]>`][NonNull] obsahujúci ukazovateľ a skutočnú veľkosť pridelenej pamäte.Ukazovateľ je vhodný na uchovávanie údajov opísaných v `new_layout`.
    /// Za týmto účelom môže alokátor zmenšiť alokáciu, na ktorú odkazuje `ptr`, aby sa zmestila do nového rozloženia.
    ///
    /// Ak sa vráti `Ok`, potom sa vlastníctvo pamäťového bloku, na ktorý odkazuje `ptr`, prenieslo do tohto prideľovača.
    /// Pamäť mohla alebo nemusí byť uvoľnená a mala by sa považovať za nepoužiteľnú, pokiaľ nebola opätovne prenesená späť volajúcemu prostredníctvom návratovej hodnoty tejto metódy.
    ///
    /// Ak táto metóda vráti `Err`, potom sa vlastníctvo pamäťového bloku neprenieslo do tohto prideľovača a obsah pamäťového bloku sa nezmení.
    ///
    /// # Safety
    ///
    /// * `ptr` musí označovať blok pamäte [*currently allocated*] cez tento alokátor.
    /// * `old_layout` musí [*fit*] tento blok pamäte (Argument `new_layout` sa naň nemusí zmestiť.).
    /// * `new_layout.size()` musí byť menší alebo rovný `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vráti `Err`, ak nové rozloženie nespĺňa obmedzenia veľkosti a zarovnania alokátora alokátora alokátora, alebo ak zmenšenie inak zlyhá.
    ///
    /// Implementáciam sa odporúča vrátiť `Err` skôr na vyčerpanie pamäte ako na paniku alebo prerušenie, ale nejde o prísnu požiadavku.
    /// (Konkrétne: je *legálne* implementovať tento trait na vrchu základnej natívnej alokačnej knižnice, ktorá sa prerušuje pri vyčerpaní pamäte.)
    ///
    /// Klientom, ktorí chcú prerušiť výpočet v reakcii na chybu pri prideľovaní, sa odporúča zavolať funkciu [`handle_alloc_error`] namiesto priameho vyvolania `panic!` alebo podobného.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // BEZPEČNOSŤ: pretože `new_layout.size()` musí byť menší alebo rovný
        // `old_layout.size()`, alokácia starej aj novej pamäte je platná pre čítanie a zápis pre bajty `new_layout.size()`.
        // Pretože stará alokácia ešte nebola uvoľnená, nemôže sa prekrývať s `new_ptr`.
        // Hovor na `copy_nonoverlapping` je teda bezpečný.
        // Bezpečnostnú zmluvu pre `dealloc` musí volajúci dodržať.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Vytvorí adaptér "by reference" pre túto inštanciu `Allocator`.
    ///
    /// Vrátený adaptér tiež implementuje `Allocator` a tento si jednoducho požičia.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // BEZPEČNOSŤ: volajúci musí dodržiavať bezpečnostnú zmluvu
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}