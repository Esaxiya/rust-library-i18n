//! Libcore prelude
//!
//! Tento modul je určený pre používateľov libcore, ktorí tiež neprepojujú s libstd.
//! Tento modul sa predvolene importuje, keď sa `#![no_std]` používa rovnakým spôsobom ako prelude štandardnej knižnice.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Verzia 2015 jadra prelude.
///
/// Ďalšie informácie nájdete v [module-level documentation](self).
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Verzia 2018 jadra prelude.
///
/// Ďalšie informácie nájdete v [module-level documentation](self).
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Verzia 2021 jadra prelude.
///
/// Ďalšie informácie nájdete v [module-level documentation](self).
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Pridajte ďalšie veci.
}