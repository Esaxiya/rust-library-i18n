//! Konverzie postáv.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Skonvertuje `u32` na `char`.
///
/// Všimnite si, že všetky [`znaky`] sú platné [`u32`] s a dajú sa spojiť do jedného s
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Opak však nie je pravdivý: nie všetky platné [`u32`] s sú platné [`char`] s.
/// `from_u32()` vráti `None`, ak vstup nie je platná hodnota pre [`char`].
///
/// Informácie o nebezpečnej verzii tejto funkcie, ktorá tieto kontroly ignoruje, nájdete v časti [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Vrátenie `None`, ak vstup nie je platný [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Skonvertuje `u32` na `char`, ignoruje platnosť.
///
/// Všimnite si, že všetky [`znaky`] sú platné [`u32`] s a dajú sa spojiť do jedného s
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Opak však nie je pravdivý: nie všetky platné [`u32`] s sú platné [`char`] s.
/// `from_u32_unchecked()` to bude ignorovať a naslepo hodí na [`char`], prípadne vytvorí neplatný.
///
///
/// # Safety
///
/// Táto funkcia nie je bezpečná, pretože môže vytvárať neplatné hodnoty `char`.
///
/// Bezpečnú verziu tejto funkcie nájdete vo funkcii [`from_u32`].
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // BEZPEČNOSŤ: volajúci musí zaručiť, že `i` je platná hodnota znaku.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Skonvertuje [`char`] na [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Skonvertuje [`char`] na [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Znak sa odovzdá na hodnotu kódového bodu a potom sa nula rozšíri na 64 bitov.
        // Pozri [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Skonvertuje [`char`] na [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Znak sa odovzdá na hodnotu kódového bodu a potom sa nula rozšíri na 128 bitov.
        // Pozri [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Mapuje bajt v 0x00 ..=0xFF na `char`, ktorého kódový bod má rovnakú hodnotu, v U + 0000 ..=U + 00FF.
///
/// Unicode je navrhnutý tak, aby efektívne dekódoval bajty pomocou kódovania znakov, ktoré IANA nazýva ISO-8859-1.
/// Toto kódovanie je kompatibilné s ASCII.
///
/// Toto sa líši od ISO/IEC 8859-1 aka
/// ISO 8859-1 (s jednou pomlčkou menej), ktorá ponecháva niektoré bajtové hodnoty "blanks", ktoré nie sú priradené k žiadnemu znaku.
/// ISO-8859-1 (IANA) ich prideľuje riadiacim kódom C0 a C1.
///
/// Toto sa *tiež* líši od Windows-1252 aka
/// kódová stránka 1252, čo je nadmnožina ISO/IEC 8859-1, ktorá priraďuje niektoré (nie všetky!) medzery interpunkcii a rôznym latinským znakom.
///
/// Pre ďalšie zmätenie sú [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` a `windows-1252` aliasmi pre nadmnožinu Windows-1252, ktorá vyplní zvyšné medzery zodpovedajúcimi riadiacimi kódmi C0 a C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Skonvertuje [`u8`] na [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Chyba, ktorú je možné vrátiť pri analýze znaku.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // BEZPEČNOSŤ: skontrolovalo sa, či ide o legálnu hodnotu unicode
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Typ chyby sa vrátil, keď zlyhala konverzia z u32 na char.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Skonvertuje číslicu v danom radixe na `char`.
///
/// 'radix' sa tu niekedy nazýva aj 'base'.
/// Radix dva označuje binárne číslo, radix desať, desatinné číslo a radix šestnásť, hexadecimálne, aby poskytli niektoré bežné hodnoty.
///
/// Ľubovoľné radice sú podporované.
///
/// `from_digit()` vráti `None`, ak vstup nie je číslica v danom radixe.
///
/// # Panics
///
/// Panics, ak sa získa radix väčší ako 36.
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Desatinné miesto 11 je jedna číslica v základe 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Vrátenie `None`, ak vstup nie je číslica:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Prechod veľkého radixu spôsobujúci panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}