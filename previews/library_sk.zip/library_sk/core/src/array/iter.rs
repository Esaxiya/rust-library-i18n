//! Definuje iterátor polí `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Vedľajší iterátor [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Toto je pole, ktoré iterujeme.
    ///
    /// Prvky s indexom `i`, kde `alive.start <= i < alive.end` ešte neboli získané a sú platnými položkami poľa.
    /// Prvky s indexmi `i < alive.start` alebo `i >= alive.end` už boli získané a už k nim nie je možné pristupovať!Tieto mŕtve prvky môžu byť dokonca v úplne neinicializovanom stave!
    ///
    ///
    /// Takže invarianty sú:
    /// - `data[alive]` je nažive (tj obsahuje platné prvky)
    /// - `data[..alive.start]` a `data[alive.end..]` sú mŕtve (tj. prvky už boli prečítané a už sa ich nesmie dotknúť!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Prvky v `data`, ktoré ešte neboli poskytnuté.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Vytvorí nový iterátor nad daným `array`.
    ///
    /// *Poznámka*: Táto metóda môže byť v future, po [`IntoIterator` is implemented for arrays][array-into-iter], zastaraná.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Typ `value` je tu `i32`, namiesto `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // BEZPEČNOSŤ: Premena tu je skutočne bezpečná.Dokumenty `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` má zaručene rovnakú veľkosť a zarovnanie
        // > ako `T`.
        //
        // Dokumenty dokonca ukazujú transmutáciu z poľa `MaybeUninit<T>` na pole `T`.
        //
        //
        // Týmto inicializácia uspokojuje invarianty.

        // FIXME(LukasKalbertodt): vlastne tu používajte `mem::transmute`, hneď ako to bude fungovať s generikami const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Do tej doby môžeme pomocou `mem::transmute_copy` vytvoriť bitovú kópiu ako iný typ, potom `array` zabudnúť, aby sa nerozhodil.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Vráti nemenný výrez všetkých prvkov, ktoré ešte neboli získané.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // BEZPEČNOSŤ: Vieme, že všetky prvky v rámci `alive` sú správne inicializované.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Vráti premenlivý výrez všetkých prvkov, ktoré ešte neboli získané.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // BEZPEČNOSŤ: Vieme, že všetky prvky v rámci `alive` sú správne inicializované.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Získajte ďalší index spredu.
        //
        // Zvýšenie `alive.start` o 1 udržuje invariant ohľadom `alive`.
        // Kvôli tejto zmene však na krátky čas živá zóna už nie je `data[alive]`, ale `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Prečítajte si prvok z poľa.
            // BEZPEČNOSŤ: `idx` je index do bývalej oblasti "alive" regiónu
            // pole.Čítanie tohto prvku znamená, že `data[idx]` sa teraz považuje za mŕtvu (tj. Nedotýkajte sa).
            // Pretože `idx` bol začiatkom živej zóny, živá zóna je teraz opäť `data[alive]` a obnovuje všetky invarianty.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Získajte ďalší index zozadu.
        //
        // Znížením `alive.end` o 1 sa zachová invariant týkajúci sa `alive`.
        // Kvôli tejto zmene však na krátky čas živá zóna už nie je `data[alive]`, ale `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Prečítajte si prvok z poľa.
            // BEZPEČNOSŤ: `idx` je index do bývalej oblasti "alive" regiónu
            // pole.Čítanie tohto prvku znamená, že `data[idx]` sa teraz považuje za mŕtvu (tj. Nedotýkajte sa).
            // Pretože `idx` bol koniec živej zóny, živá zóna je teraz opäť `data[alive]` a obnovuje všetky invarianty.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // BEZPEČNOSŤ: Je to bezpečné: `as_mut_slice` vráti presne čiastkový plátok
        // prvkov, ktoré ešte neboli presunuté a zostáva ich upustiť.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nikdy nebude pretekať kvôli invariantu `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iterátor skutočne hlási správnu dĺžku.
// Počet prvkov "alive" (ktoré sa budú aj naďalej získavať) je dĺžka rozsahu `alive`.
// Dĺžka tohto rozsahu je zmenšená v `next` alebo `next_back`.
// V týchto metódach sa vždy zníži o 1, ale iba ak sa vráti `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Upozorňujeme, že sa skutočne nemusíme zhodovať s úplne rovnakým rozsahom živých snímok, takže môžeme klonovať iba do offsetu 0 bez ohľadu na to, kde je `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonujte všetky živé prvky.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Napíšte klon do nového poľa a potom aktualizujte jeho živý rozsah.
            // Ak klonujeme panics, správne odhodíme predchádzajúce položky.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Vytlačte iba prvky, ktoré ešte neboli získané: k získaným prvkom už nemáme prístup.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}