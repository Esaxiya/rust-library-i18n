/// Vlastný kód v rámci deštruktora.
///
/// Ak už hodnota nie je potrebná, Rust spustí "destructor" s touto hodnotou.
/// Najbežnejším spôsobom, že hodnota už nie je potrebná, je situácia, keď dôjde mimo rozsah.Destruktory sa môžu stále spúšťať za iných okolností, ale tu sa zameriame na rozsah príkladov.
/// Ak sa chcete dozvedieť viac o niektorých ďalších prípadoch, prečítajte si časť [the reference] o destruktoroch.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Tento deštruktor sa skladá z dvoch komponentov:
/// - Výzva `Drop::drop` pre túto hodnotu, ak je pre tento typ implementovaná táto špeciálna `Drop` trait.
/// - Automaticky generovaný "drop glue", ktorý rekurzívne volá deštruktory všetkých polí tejto hodnoty.
///
/// Pretože Rust automaticky volá deštruktory všetkých obsiahnutých polí, vo väčšine prípadov nemusíte implementovať `Drop`.
/// Existujú ale prípady, kedy je to užitočné, napríklad pre typy, ktoré priamo spravujú zdroj.
/// Tým zdrojom môže byť pamäť, môže to byť deskriptor súborov, môže to byť sieťová zásuvka.
/// Akonáhle sa hodnota tohto typu už nebude používať, mala by "clean up" svoj zdroj uvoľniť pamäť alebo zavrieť súbor alebo soket.
/// Toto je práca deštruktora, a teda práca `Drop::drop`.
///
/// ## Examples
///
/// Ak chcete vidieť deštruktory v akcii, pozrime sa na nasledujúci program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust najskôr zavolá `Drop::drop` pre `_x` a potom pre `_x.one` aj `_x.two`, čo znamená, že jeho spustením sa vytlačí
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Aj keď odstránime implementáciu `Drop` pre `HasTwoDrop`, destruktory jej polí sa stále volajú.
/// To by malo za následok
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop` nemôžete volať sami
///
/// Pretože `Drop::drop` sa používa na vyčistenie hodnoty, môže byť nebezpečné používať túto hodnotu po vyvolaní metódy.
/// Pretože `Drop::drop` nepreberá vlastníctvo svojho vstupu, Rust zabráni zneužitiu tým, že vám neumožní zavolať priamo na `Drop::drop`.
///
/// Inými slovami, ak by ste sa pokúsili vo vyššie uvedenom príklade výslovne zavolať `Drop::drop`, zobrazila by sa vám chyba kompilátora.
///
/// Ak chcete explicitne zavolať deštruktor hodnoty, môžete namiesto neho použiť [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Zrušiť objednávku
///
/// Ktorý z našich dvoch `HasDrop` však klesá ako prvý?Pre štruktúry je to rovnaké poradie, v akom sú deklarované: najskôr `one`, potom `two`.
/// Ak si to chcete vyskúšať sami, môžete vyššie upraviť `HasDrop` tak, aby obsahoval určité údaje, napríklad celé číslo, a potom ich použiť v `println!` vo vnútri `Drop`.
/// Toto správanie je jazykom zaručené.
///
/// Na rozdiel od štruktúr sú lokálne premenné vypúšťané v opačnom poradí:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Toto sa vytlačí
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Úplné pravidlá nájdete na [the reference].
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` a `Drop` sú exkluzívne
///
/// Nemôžete implementovať [`Copy`] aj `Drop` na rovnaký typ.Typy, ktoré sú `Copy`, kompilátor implicitne duplikuje, takže je veľmi ťažké predpovedať, kedy a ako často sa budú deštruktory vykonávať.
///
/// Preto tieto typy nemôžu mať deštruktory.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Spustí deštruktor pre tento typ.
    ///
    /// Táto metóda sa volá implicitne, keď hodnota zmizne z rozsahu, a nemožno ju zavolať explicitne (jedná sa o chybu kompilátora [E0040]).
    /// Funkciu [`mem::drop`] v prelude je však možné použiť na vyvolanie implementácie argumentu `Drop`.
    ///
    /// Keď bola táto metóda vyvolaná, `self` ešte nebol uvoľnený.
    /// K tomu dôjde až po ukončení metódy.
    /// Keby to tak nebolo, bol by `self` visiacim odkazom.
    ///
    /// # Panics
    ///
    /// Vzhľadom na to, že [`panic!`] bude pri odvíjaní volať `drop`, akýkoľvek [`panic!`] v implementácii `drop` sa pravdepodobne preruší.
    ///
    /// Upozorňujeme, že aj keď je táto hodnota panics, hodnota sa považuje za vypustenú;
    /// nesmiete spôsobiť opätovné volanie `drop`.
    /// Toto je zvyčajne automaticky spracované kompilátorom, ale pri použití nebezpečného kódu sa to môže niekedy vyskytnúť neúmyselne, najmä pri použití [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}