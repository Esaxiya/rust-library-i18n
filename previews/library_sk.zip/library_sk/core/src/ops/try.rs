/// trait na prispôsobenie správania operátora `?`.
///
/// Typ implementujúci `Try` je typ, ktorý má kanonický spôsob, ako ho zobraziť z hľadiska dichotómie success/failure.
/// Tento trait umožňuje extrahovať tieto hodnoty úspechu alebo zlyhania z existujúcej inštancie a vytvárať novú inštanciu z hodnoty úspechu alebo zlyhania.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Typ tejto hodnoty, ak sa považuje za úspešnú.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Typ tejto hodnoty, keď sa považuje za neúspešnú.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Použije operátor "?".Návrat `Ok(t)` znamená, že vykonávanie by malo pokračovať normálne a výsledkom `?` je hodnota `t`.
    /// Návrat `Err(e)` znamená, že vykonanie by malo branch do najvnútornejšej ohraničujúcej `catch`, alebo návrat z funkcie.
    ///
    /// Ak sa vráti výsledok `Err(e)`, hodnota `e` bude "wrapped" v návratovom type ohraničujúceho rozsahu (ktorý musí sám implementovať `Try`).
    ///
    /// Konkrétne sa vráti hodnota `X::from_error(From::from(e))`, kde `X` je návratový typ obklopujúcej funkcie.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Zbaliť chybovú hodnotu na zostavenie zloženého výsledku.
    /// Napríklad `Result::Err(x)` a `Result::from_error(x)` sú ekvivalentné.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Zbalením hodnoty OK vytvoríte zložený výsledok.
    /// Napríklad `Result::Ok(x)` a `Result::from_ok(x)` sú ekvivalentné.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}