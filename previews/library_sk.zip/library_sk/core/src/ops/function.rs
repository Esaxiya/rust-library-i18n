/// Verzia operátora hovoru, ktorý prijíma nemenný prijímač.
///
/// Inštancie `Fn` je možné volať opakovane bez mutačného stavu.
///
/// *Tento trait (`Fn`) sa nesmie zamieňať s [function pointers] (`fn`).*
///
/// `Fn` sa implementuje automaticky uzáverami, ktoré berú iba nemenné odkazy na zachytené premenné alebo nezachytávajú vôbec nič, rovnako ako (safe) [function pointers] (s niekoľkými výhradami, ďalšie podrobnosti nájdete v ich dokumentácii).
///
/// Okrem toho pre akýkoľvek typ `F`, ktorý implementuje `Fn`, implementuje `&F` aj `Fn`.
///
/// Pretože [`FnMut`] aj [`FnOnce`] sú supertraity `Fn`, možno ako parameter, kde sa očakáva [`FnMut`] alebo [`FnOnce`], použiť ktorákoľvek inštancia `Fn`.
///
/// Použite `Fn` ako väzbu, keď chcete prijať parameter funkčného typu a potrebujete ho volať opakovane a bez mutácie stavu (napr. Pri súčasnom volaní).
/// Ak nepotrebujete také prísne požiadavky, použite ako hranice [`FnMut`] alebo [`FnOnce`].
///
/// Ďalšie informácie o tejto téme nájdete na [chapter on closures in *The Rust Programming Language*][book].
///
/// Za zmienku stojí aj špeciálna syntax pre `Fn` traits (napr
/// `Fn(usize, bool) -> usize`).Záujemcovia o technické podrobnosti sa môžu obrátiť na produkt [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Volá sa uzávierka
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Použitie parametra `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby sa regex mohol spoľahnúť na to `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Vykoná operáciu hovoru.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Verzia operátora hovoru, ktorý prijíma premenlivý prijímač.
///
/// Inštancie `FnMut` je možné volať opakovane a môžu mutovať.
///
/// `FnMut` je implementovaný automaticky uzáverami, ktoré berú premenlivé odkazy na zachytené premenné, ako aj všetkými typmi, ktoré implementujú [`Fn`], napr. (safe) [function pointers] (keďže `FnMut` je supertrénou [`Fn`]).
/// Okrem toho pre akýkoľvek typ `F`, ktorý implementuje `FnMut`, implementuje `&mut F` aj `FnMut`.
///
/// Pretože [`FnOnce`] je supertrénou `FnMut`, je možné použiť ktorúkoľvek inštanciu `FnMut`, kde sa očakáva [`FnOnce`], a keďže [`Fn`] je subtrait `FnMut`, je možné použiť ktorúkoľvek inštanciu [`Fn`] tam, kde sa očakáva `FnMut`.
///
/// Použite `FnMut` ako väzbu, keď chcete prijať parameter funkčného typu a potrebujete ho opakovane volať, pričom mu umožníte mutovať stav.
/// Ak nechcete, aby parameter mutoval stav, použite [`Fn`] ako viazaný;ak ho nepotrebujete volať opakovane, použite [`FnOnce`].
///
/// Ďalšie informácie o tejto téme nájdete na [chapter on closures in *The Rust Programming Language*][book].
///
/// Za zmienku stojí aj špeciálna syntax pre `Fn` traits (napr
/// `Fn(usize, bool) -> usize`).Záujemcovia o technické podrobnosti sa môžu obrátiť na produkt [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Volá sa premenlivo zachytávajúca uzávierka
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Použitie parametra `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby sa regex mohol spoľahnúť na to `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Vykoná operáciu hovoru.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Verzia operátora hovoru, ktorý prijíma prijímač vedľajšej hodnoty.
///
/// Je možné volať inštancie `FnOnce`, ale nemusí byť možné ich zavolať viackrát.Z tohto dôvodu, ak je o type známe iba to, že implementuje `FnOnce`, je možné ho zavolať iba raz.
///
/// `FnOnce` sa implementuje automaticky uzáverami, ktoré môžu spotrebovať zachytené premenné, ako aj všetkými typmi, ktoré implementujú [`FnMut`], napr. (safe) [function pointers] (pretože `FnOnce` je supertrénou [`FnMut`]).
///
///
/// Pretože [`Fn`] aj [`FnMut`] sú subtraity `FnOnce`, je možné použiť ktorúkoľvek inštanciu [`Fn`] alebo [`FnMut`], kde sa očakáva `FnOnce`.
///
/// Použite `FnOnce` ako väzbu, keď chcete prijať parameter funkčného typu a stačí ho zavolať iba raz.
/// Ak potrebujete opakovane volať parameter, použite [`FnMut`] ako viazaný;ak tiež potrebujete, aby nemutoval stav, použite [`Fn`].
///
/// Ďalšie informácie o tejto téme nájdete na [chapter on closures in *The Rust Programming Language*][book].
///
/// Za zmienku stojí aj špeciálna syntax pre `Fn` traits (napr
/// `Fn(usize, bool) -> usize`).Záujemcovia o technické podrobnosti sa môžu obrátiť na produkt [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Použitie parametra `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` spotrebováva svoje zachytené premenné, takže ju nemožno spustiť viackrát.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Pokus o opätovné vyvolanie `func()` spôsobí chybu `use of moved value` pre `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` v tomto okamihu už nie je možné vyvolať
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // aby sa regex mohol spoľahnúť na to `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Vrátený typ po použití operátora hovoru.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Vykoná operáciu hovoru.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}