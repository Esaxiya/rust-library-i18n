/// Používa sa na nezmeniteľné operácie dereferencie, ako napríklad `*v`.
///
/// Okrem toho, že sa kompilátor `Deref` používa na explicitné dereferenčné operácie s operátorom (unary) `*` v nemenných kontextoch, za mnohých okolností ho implicitne používa aj implicitne.
/// Tento mechanizmus sa nazýva ['`Deref` coercion'][more].
/// V premenlivých kontextoch sa používa [`DerefMut`].
///
/// Implementácia `Deref` pre inteligentné ukazovatele uľahčuje prístup k údajom za nimi, a preto implementujú `Deref`.
/// Na druhej strane boli pravidlá týkajúce sa `Deref` a [`DerefMut`] navrhnuté špeciálne pre inteligentné ukazovatele.
/// Z tohto dôvodu by sa slovo " Deref` malo implementovať iba pre inteligentné ukazovatele **, aby nedošlo k zámene.
///
/// Z podobných dôvodov by **tento trait nemal nikdy zlyhať**.Zlyhanie počas dereferencie môže byť veľmi mätúce, keď je implicitne vyvolaná `Deref`.
///
/// # Viac o nátlaku `Deref`
///
/// Ak `T` implementuje `Deref<Target = U>` a `x` je hodnota typu `T`, potom:
///
/// * V nemenných kontextoch je `*x` (kde `T` nie je ani referencia, ani surový ukazovateľ) ekvivalentná `* Deref::deref(&x)`.
/// * Hodnoty typu `&T` sú prepočítané na hodnoty typu `&U`
/// * `T` implicitne implementuje všetky metódy (immutable) typu `U`.
///
/// Ďalšie informácie nájdete na [the chapter in *The Rust Programming Language*][book], ako aj v referenčných sekciách na modeloch [the dereference operator][ref-deref-op], [method resolution] a [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Štruktúra s jedným poľom, ktorá je prístupná dereferenciou štruktúry.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Výsledný typ po dereferencii.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Odčíta hodnotu.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Používa sa na premenlivé dereferenčné operácie, ako napríklad v `*v = 1;`.
///
/// Okrem toho, že sa kompilátor `DerefMut` používa na explicitné dereferenčné operácie s operátorom (unary) `*` v premenlivých kontextoch, za mnohých okolností ho implicitne používa aj implicitne.
/// Tento mechanizmus sa nazýva ['`Deref` coercion'][more].
/// V nemenných kontextoch sa používa [`Deref`].
///
/// Vďaka implementácii `DerefMut` pre inteligentné ukazovatele je mutovanie údajov za nimi pohodlné, a preto implementujú `DerefMut`.
/// Na druhej strane boli pravidlá týkajúce sa [`Deref`] a `DerefMut` navrhnuté špeciálne pre inteligentné ukazovatele.
/// Z tohto dôvodu by sa výraz " `DerefMut` mal implementovať iba pre inteligentné ukazovatele **, aby nedošlo k zámene.
///
/// Z podobných dôvodov by **tento trait nemal nikdy zlyhať**.Zlyhanie počas dereferencie môže byť veľmi mätúce, keď je implicitne vyvolaná `DerefMut`.
///
/// # Viac o nátlaku `Deref`
///
/// Ak `T` implementuje `DerefMut<Target = U>` a `x` je hodnota typu `T`, potom:
///
/// * V premenlivých kontextoch je `*x` (kde `T` nie je ani referencia, ani surový ukazovateľ) ekvivalentná `* DerefMut::deref_mut(&mut x)`.
/// * Hodnoty typu `&mut T` sú prepočítané na hodnoty typu `&mut U`
/// * `T` implicitne implementuje všetky metódy (mutable) typu `U`.
///
/// Ďalšie informácie nájdete na [the chapter in *The Rust Programming Language*][book], ako aj v referenčných sekciách na modeloch [the dereference operator][ref-deref-op], [method resolution] a [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Štruktúra s jedným poľom, ktoré je možné upraviť dereferenciou štruktúry.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Hodnota sa dereferencuje.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Označuje, že štruktúru je možné použiť ako prijímač metód bez funkcie `arbitrary_self_types`.
///
/// Toto je implementované typmi ukazovateľov stdlib ako `Box<T>`, `Rc<T>`, `&T` a `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}