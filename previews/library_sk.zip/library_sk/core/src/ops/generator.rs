use crate::marker::Unpin;
use crate::pin::Pin;

/// Výsledok obnovenia generátora.
///
/// Toto množstvo je vrátené z metódy `Generator::resume` a označuje možné návratové hodnoty generátora.
/// V súčasnosti to zodpovedá buď závesnému bodu (`Yielded`), alebo koncovému bodu (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generátor pozastavený s hodnotou.
    ///
    /// Tento stav naznačuje, že generátor bol pozastavený a zvyčajne zodpovedá vyhláseniu `yield`.
    /// Hodnota poskytnutá v tomto variante zodpovedá výrazu odovzdanému `yield` a umožňuje generátorom poskytnúť hodnotu zakaždým, keď sa dostanú.
    ///
    ///
    Yielded(Y),

    /// Generátor je doplnený o návratovú hodnotu.
    ///
    /// Tento stav označuje, že generátor dokončil vykonávanie s poskytnutou hodnotou.
    /// Len čo generátor vrátil `Complete`, považuje sa za chybu programátora opätovné volanie `resume`.
    ///
    Complete(R),
}

/// trait implementovaný pomocou zabudovaných typov generátorov.
///
/// Generátory, ktoré sa bežne označujú aj ako korutíny, sú v súčasnosti v Rust experimentálnou jazykovou funkciou.
/// Pridané do generátorov [RFC 2033] sú v súčasnosti určené predovšetkým na poskytovanie stavebného bloku pre syntax async/await, ale pravdepodobne sa rozšíria aj na poskytovanie ergonomickej definície pre iterátory a ďalšie primitívne prvky.
///
///
/// Syntax a sémantika generátorov je nestabilná a na stabilizáciu bude potrebné ďalšie RFC.V súčasnosti je však syntax podobná uzavretiu:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Ďalšiu dokumentáciu generátorov nájdete v nestabilnej knihe.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Typ hodnoty, ktorú tento generátor poskytuje.
    ///
    /// Tento asociovaný typ zodpovedá výrazu `yield` a hodnotám, ktoré sa môžu vrátiť zakaždým, keď generátor získa.
    ///
    /// Napríklad iterátor ako generátor by pravdepodobne mal tento typ ako `T`, pričom typ je iterovaný.
    ///
    type Yield;

    /// Typ hodnoty, ktorú vráti tento generátor.
    ///
    /// To zodpovedá typu vrátenému z generátora buď s príkazom `return`, alebo implicitne ako posledný výraz literálu generátora.
    /// Napríklad futures by to použil ako `Result<T, E>`, pretože predstavuje dokončenú future.
    ///
    ///
    type Return;

    /// Obnoví vykonávanie tohto generátora.
    ///
    /// Táto funkcia obnoví výkon generátora alebo zaháji výkon, ak ešte nebol vykonaný.
    /// Toto volanie sa vráti späť do posledného bodu pozastavenia generátora a obnoví vykonávanie od najnovšej `yield`.
    /// Generátor bude pokračovať v vykonávaní, kým neprinesie alebo sa nevráti, a potom sa vráti táto funkcia.
    ///
    /// # Návratová hodnota
    ///
    /// Výčet `GeneratorState` vrátený z tejto funkcie označuje, v akom stave je generátor po návrate.
    /// Ak sa vráti variant `Yielded`, generátor dosiahol bod pozastavenia a bola získaná hodnota.
    /// Generátory v tomto stave sú k dispozícii na obnovenie neskôr.
    ///
    /// Ak sa vráti `Complete`, generátor úplne skončil s poskytnutou hodnotou.Obnovenie generátora je neplatné.
    ///
    /// # Panics
    ///
    /// Táto funkcia môže mať panic, ak je volaná po predchádzajúcom vrátení variantu `Complete`.
    /// Zatiaľ čo generálne literály v jazyku sú pri obnovení po `Complete` zaručene panic, nie je to zaručené pre všetky implementácie `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}