# Model `rustc-std-workspace-std` crate

Pozrite si dokumentáciu k `rustc-std-workspace-core` crate.