//! Implementácia Rust panics prostredníctvom prerušenia procesu
//!
//! V porovnaní s implementáciou pomocou odvíjania je tento crate *oveľa* jednoduchší!To znamená, že to nie je také všestranné, ale je to tu!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" užitočné zaťaženie a podložka k príslušnému prerušeniu činnosti na príslušnej platforme.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // volať std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Na Windows použite mechanizmus __fastfail špecifický pre procesor.V Windows 8 a novších sa tým proces okamžite ukončí bez spustenia akýchkoľvek obslužných rutín výnimiek v procese.
            // V starších verziách Windows sa s touto sekvenciou pokynov bude zaobchádzať ako s narušením prístupu, ktoré ukončí proces, ale nevyhnutne obíde všetky obslužné rutiny výnimiek.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: toto je rovnaká implementácia ako v `abort_internal` libstd
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Toto ... je trochu zvláštnosť.Tl; dr;je to, že je to potrebné na správne prepojenie, dlhšie vysvetlenie je uvedené nižšie.
//
// Momentálne sú všetky binárne súbory libcore/libstd, ktoré dodávame, kompilované s `-C panic=unwind`.Toto je zaistené, aby boli binárne súbory maximálne kompatibilné s čo najväčším počtom situácií.
// Kompilátor však vyžaduje "personality function" pre všetky funkcie skompilované s `-C panic=unwind`.Táto osobnostná funkcia je pevne zakódovaná na symbol `rust_eh_personality` a je definovaná položkou jazyka `eh_personality`.
//
// So...
// prečo tu nedefinovať iba tú položku lang?Dobrá otázka!Spôsob, akým sú prepojené runtime panic, je v skutočnosti trochu subtílny v tom, že sú "sort of" v obchode crate kompilátora, ale skutočne prepojené, iba ak iné nie sú skutočne prepojené.
//
// To nakoniec znamená, že tento crate aj panic_unwind crate sa môžu zobraziť v obchode crate kompilátora, a ak obaja definujú položku jazyka `eh_personality`, potom to spôsobí chybu.
//
// Aby to bolo možné zvládnuť, kompilátor vyžaduje iba definíciu `eh_personality`, ak je runtime panic, ktorý je prepojený, odvíjacím runtime, inak nie je potrebné ho definovať (oprávnene).
// V tomto prípade však táto knižnica iba definuje tento symbol, takže niekde je aspoň nejaká osobnosť.
//
// Tento symbol je v podstate definovaný iba na zapojenie binárnych súborov libcore/libstd, ale nikdy by sa nemal volať, pretože vôbec nespájame v odvíjajúcom sa runtime.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Na x86_64-pc-windows-gnu používame našu vlastnú osobnostnú funkciu, ktorá musí vrátiť `ExceptionContinueSearch`, keď odovzdávame všetky naše rámce.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Podobne ako v predchádzajúcom prípade to zodpovedá položke `eh_catch_typeinfo` lang, ktorá sa v súčasnosti používa iba v Emscriptene.
    //
    // Pretože panics negeneruje výnimky a zahraničné výnimky sú momentálne UB s -C panic=abort (aj keď sa to môže zmeniť), akékoľvek volania catch_unwind nikdy nepoužijú tento typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Tieto dva objekty volajú naše spúšťacie objekty na serveri i686-pc-windows-gnu, ale nepotrebujú nič robiť, aby telá boli zhlukové.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}