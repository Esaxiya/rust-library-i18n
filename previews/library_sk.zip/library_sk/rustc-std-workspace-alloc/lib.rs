#![feature(no_core)]
#![no_core]

// Prečo je tento crate potrebný, pozri rustc-std-workspace-core.

// Premenujte crate, aby ste predišli konfliktom s alokačným modulom v liballoc.
extern crate alloc as foo;

pub use foo::*;