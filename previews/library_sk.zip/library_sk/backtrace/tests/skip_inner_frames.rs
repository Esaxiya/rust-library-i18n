use backtrace::Backtrace;

// Tento test funguje iba na platformách, ktoré majú funkčnú funkciu `symbol_address` pre rámce, ktoré hlásia začiatočnú adresu symbolu.
// Vo výsledku je povolený iba na niekoľkých platformách.
//
const ENABLED: bool = cfg!(all(
    // Windows nebol skutočne testovaný a OSX nepodporuje skutočné nájdenie ohraničujúceho rámca, takže toto vypnite
    //
    target_os = "linux",
    // Na ARM nájdenie uzatváracej funkcie jednoducho vráti samotnú ip.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}