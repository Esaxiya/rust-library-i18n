# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Knižnica na získavanie spätných záznamov za behu modulu Rust.
Táto knižnica si kladie za cieľ zvýšiť podporu štandardnej knižnice poskytnutím programového rozhrania na prácu, ale podporuje tiež jednoduchú ľahkú tlač súčasnej stopy ako libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Ak chcete jednoducho zachytiť spätný chod a odložiť riešenie s ním na neskôr, môžete použiť typ `Backtrace` najvyššej úrovne.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Ak by ste však chceli surovejší prístup k skutočnej funkcii sledovania, môžete priamo použiť funkcie `trace` a `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Tento ukazovateľ inštrukcie vyriešte na názov symbolu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // pokračuj na ďalší snímok
    });
}
```

# License

Tento projekt je licencovaný v rámci jednej z týchto licencií:

 * Licencia Apache, verzia 2.0, ([LICENSE-APACHE](LICENSE-APACHE) alebo http://www.apache.org/licenses/LICENSE-2.0)
 * Licencia MIT ([LICENSE-MIT](LICENSE-MIT) alebo http://opensource.org/licenses/MIT)

podľa vášho výberu.

### Contribution

Pokiaľ výslovne neurčíte inak, akýkoľvek príspevok, ktorý ste zámerne predložili na zaradenie do backtrace-rs, ako je definované v licencii Apache-2.0, bude mať dvojitú licenciu, ako je uvedené vyššie, bez akýchkoľvek ďalších podmienok.







