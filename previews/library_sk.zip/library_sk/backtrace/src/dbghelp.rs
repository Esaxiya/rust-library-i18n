//! Modul na pomoc pri správe väzieb dbghelp na Windows
//!
//! Spätné stopy na Windows (aspoň pre MSVC) sú z veľkej časti napájané cez `dbghelp.dll` a rôzne funkcie, ktoré obsahuje.
//! Tieto funkcie sú momentálne načítané *dynamicky* a nie ako odkazy na `dbghelp.dll` staticky.
//! V súčasnosti to robí štandardná knižnica (a teoreticky sa to tam vyžaduje), ale jedná sa o snahu pomôcť znížiť statické závislosti DLL od knižnice, pretože spätné stopy sú zvyčajne dosť voliteľné.
//!
//! To znamená, že `dbghelp.dll` sa takmer vždy úspešne načítava na Windows.
//!
//! Všimnite si však, že keďže načítavame túto podporu dynamicky, nemôžeme v skutočnosti použiť nespracované definície v `winapi`, ale skôr si musíme definovať typy ukazovateľov funkcií sami a použiť ich.
//! V skutočnosti sa nechceme zaoberať duplikovaním winapi, takže máme funkciu Cargo `verify-winapi`, ktorá tvrdí, že všetky väzby sa zhodujú s väzbami vo winapi a táto funkcia je povolená v CI.
//!
//! Na záver si tu všimnete, že dll pre `dbghelp.dll` sa nikdy nenačíta a je to momentálne zámerné.
//! Myslí sa, že to môžeme globálne uložiť do medzipamäte a používať ju medzi hovormi na API, aby sme sa vyhli drahej loads/unloads.
//! Ak je to problém s detektormi únikov alebo s niečím takým, môžeme prejsť cez most, keď sa tam dostaneme.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Práce okolo `SymGetOptions` a `SymSetOptions` nie sú prítomné v samotnom winapi.
// Inak sa to používa iba vtedy, keď dvakrát kontrolujeme typy proti winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Vo winapi zatiaľ nie je definované
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Toto je definované vo winapi, ale je to nesprávne (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Vo winapi zatiaľ nie je definované
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Toto makro sa používa na definovanie štruktúry `Dbghelp`, ktorá interne obsahuje všetky ukazovatele funkcií, ktoré by sme mohli načítať.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Načítaná DLL pre `dbghelp.dll`
            dll: HMODULE,

            // Každý ukazovateľ funkcie pre každú funkciu, ktorú by sme mohli použiť
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Spočiatku sme nenačítali DLL
            dll: 0 as *mut _,
            // Na začiatku sú všetky funkcie nastavené na nulu, čo znamená, že je potrebné ich načítať dynamicky.
            //
            $($name: 0,)*
        };

        // Pohodlné zadanie typu pre každý typ funkcie.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Pokusy o otvorenie `dbghelp.dll`.
            /// Vráti úspech, ak funguje, alebo chybu, ak zlyhá `LoadLibraryW`.
            ///
            /// Panics, ak je knižnica už načítaná.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkcia pre každú metódu, ktorú by sme chceli použiť.
            // Pri volaní bude buď načítať ukazovateľ funkcie uloženej v pamäti, alebo ju načíta a vráti načítanú hodnotu.
            // Zaťažuje sa, aby bol úspech úspešný.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Pohodlie proxy na použitie zámkov vyčistenia na odkazovanie na funkcie dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicializujte všetku podporu potrebnú na prístup k funkciám `dbghelp` API z tohto crate.
///
///
/// Táto funkcia je **bezpečná**, má interne svoju vlastnú synchronizáciu.
/// Pamätajte tiež, že je bezpečné zavolať túto funkciu viackrát rekurzívne.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Prvá vec, ktorú musíme urobiť, je synchronizovať túto funkciu.To možno nazvať súbežne z iných vlákien alebo rekurzívne v rámci jedného vlákna.
        // Je to však zložitejšie, pretože to, čo tu používame, `dbghelp`,*tiež* je potrebné synchronizovať so všetkými ostatnými volajúcimi do `dbghelp` v tomto procese.
        //
        // Spravidla v rovnakom procese nie je toľko hovorov na `dbghelp` a pravdepodobne môžeme bezpečne predpokladať, že k nim pristupujeme iba my.
        // Je tu však jeden primárny ďalší používateľ, ktorého sa musíme obávať, a ktorý sme ironicky my sami, ale v štandardnej knižnici.
        // Štandardná knižnica Rust závisí od tejto crate pre podporu spätného sledovania a táto crate existuje aj na crates.io.
        // To znamená, že ak štandardná knižnica tlačí panic backtrace, môže závodiť s týmto crate pochádzajúcim z crates.io, čo spôsobí chyby.
        //
        // Aby sme pomohli vyriešiť tento problém so synchronizáciou, použijeme tu trik špecifický pre Windows (je to koniec koncov špecifické obmedzenie synchronizácie pre Windows).
        // Na ochranu tohto hovoru vytvárame *session-local* s názvom mutex.
        // Zámerom je, aby štandardná knižnica a táto crate nemuseli zdieľať API na úrovni Rust, aby sa tu mohli synchronizovať, ale môžu namiesto toho pracovať v zákulisí, aby sa ubezpečili, že sa navzájom synchronizujú.
        //
        // Takto, keď sa táto funkcia volá cez štandardnú knižnicu alebo cez crates.io, môžeme si byť istí, že sa získa ten istý mutex.
        //
        // Všetko teda znamená, že prvá vec, ktorú tu urobíme, je to, že atomicky vytvoríme `HANDLE`, ktorý je na Windows pomenovaný ako mutex.
        // Trochu synchronizujeme s ostatnými vláknami zdieľajúcimi túto funkciu konkrétne a zabezpečujeme, aby sa pre každú inštanciu tejto funkcie vytvoril iba jeden popisovač.
        // Upozorňujeme, že popisovač sa nikdy nezatvorí, akonáhle sa uloží do globálneho formátu.
        //
        // Potom, čo sme skutočne dostali zámok, jednoducho ho získame a naša rukoväť `Init`, ktorú rozdávame, bude zodpovedná za jej prípadné zrušenie.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Dobre, fuj!Teraz, keď sme všetci bezpečne synchronizovaní, začnime vlastne všetko spracovávať.
        // Najprv musíme zabezpečiť, aby sa proces `dbghelp.dll` skutočne načítal.
        // Robíme to dynamicky, aby sme sa vyhli statickej závislosti.
        // Toto sa historicky robilo s cieľom obísť podivné problémy s prepájaním a má za cieľ urobiť binárne súbory trochu prenosnejšími, pretože ide zväčša iba o ladiaci nástroj.
        //
        //
        // Len čo otvoríme `dbghelp.dll`, musíme v ňom zavolať nejaké inicializačné funkcie, a to je podrobnejšie nižšie.
        // Robíme to však iba raz, takže máme globálny logický údaj, ktorý naznačuje, či sme už skončili alebo nie.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Skontrolujte, či je nastavený príznak `SYMOPT_DEFERRED_LOADS`, pretože podľa vlastných dokumentov MSVC o tomto: "This is the fastest, most efficient way to use the symbol handler.", tak poďme na to!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // V skutočnosti inicializujte symboly pomocou MSVC.Upozorňujeme, že to môže zlyhať, ale ignorujeme to.
        // Nie je to veľa doterajšieho stavu techniky ako také, ale zdá sa, že LLVM interne ignoruje návratovú hodnotu a jedna z knižníc dezinfekčných prostriedkov v LLVM vytlačí strašidelné varovanie, ak to zlyhá, ale v dlhodobom horizonte ju v podstate ignoruje.
        //
        //
        // Jedným z prípadov, keď to pre Rust príde veľa, je to, že štandardná knižnica a táto crate na crates.io chcú súťažiť o `SymInitializeW`.
        // Štandardná knižnica historicky chcela inicializovať a potom vyčistiť väčšinu času, ale teraz, keď používa túto crate, znamená to, že sa niekto najskôr dostane k inicializácii a druhý túto inicializáciu prevezme.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}