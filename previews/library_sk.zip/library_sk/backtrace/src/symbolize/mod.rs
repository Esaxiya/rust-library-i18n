use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Vyriešte adresu na symbol a odovzdajte symbol do určenej uzávierky.
///
/// Táto funkcia vyhľadá danú adresu v oblastiach, ako je napríklad tabuľka lokálnych symbolov, dynamická tabuľka symbolov alebo informácie o ladení DWARF (v závislosti od aktivovanej implementácie), aby sa našli symboly, ktoré sa majú získať.
///
///
/// Uzávierka sa nemusí dať vyvolať, ak nie je možné vykonať rozlíšenie, a v prípade vložených funkcií ju možno vyvolať aj viackrát.
///
/// Získané symboly predstavujú vykonanie na zadanom `addr`, vracajúcom páry file/line pre túto adresu (ak je k dispozícii).
///
/// Upozorňujeme, že ak máte model `Frame`, odporúča sa namiesto tohto použiť funkciu `resolve_frame`.
///
/// # Požadované funkcie
///
/// Táto funkcia vyžaduje, aby bola povolená funkcia `std` modelu `backtrace` crate, a funkcia `std` je predvolene povolená.
///
/// # Panics
///
/// Táto funkcia sa nikdy nesnaží panic, ale ak `cb` poskytla panics, niektoré platformy vynútia dvojitý panic, aby proces prerušil.
/// Niektoré platformy používajú knižnicu C, ktorá interne používa spätné volania, ktoré sa nedajú odmotať, takže panika z `cb` môže spôsobiť prerušenie procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // pozri sa iba na horný rám
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Vyriešte predchádzajúci snímací rámec na symbol a odovzdajte symbol zadanému uzáveru.
///
/// Tento funkčný prvok vykonáva rovnakú funkciu ako `resolve` s tým rozdielom, že namiesto adresy berie `Frame` ako argument.
/// To môže umožniť niektorým implementáciám platformy spätného sledovania poskytnúť presnejšie informácie o symboloch alebo napríklad informácie o vložených rámcoch.
///
/// Odporúča sa použiť toto, ak je to možné.
///
/// # Požadované funkcie
///
/// Táto funkcia vyžaduje, aby bola povolená funkcia `std` modelu `backtrace` crate, a funkcia `std` je predvolene povolená.
///
/// # Panics
///
/// Táto funkcia sa nikdy nesnaží panic, ale ak `cb` poskytla panics, niektoré platformy vynútia dvojitý panic, aby proces prerušil.
/// Niektoré platformy používajú knižnicu C, ktorá interne používa spätné volania, ktoré sa nedajú odmotať, takže panika z `cb` môže spôsobiť prerušenie procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // pozri sa iba na horný rám
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Hodnoty IP zo rámcov zásobníka sú zvyčajne (always?) inštrukcia *po* volaní, ktorá je skutočným sledovaním zásobníka.
// Symbolizácia tohto zapnutia spôsobí, že číslo filename/line bude o jedno dopredu a možno aj v prázdne, ak sa bude blížiť ku koncu funkcie.
//
// Zdá sa, že to v podstate vždy platí na všetkých platformách, takže vždy odčítame jeden od vyriešeného ip, aby sme ho vyriešili na predchádzajúcu inštrukciu volania namiesto inštrukcie, na ktorú sa vrátime.
//
//
// V ideálnom prípade by sme to neurobili.
// V ideálnom prípade by sme od volajúcich API `resolve` vyžadovali, aby tu ručne vykonali -1 a zaznamenali, že chcú informácie o polohe pre *predchádzajúcu* inštrukciu, nie aktuálnu.
// V ideálnom prípade by sme tiež vystavili na `Frame`, ak sme skutočne adresou nasledujúcej inštrukcie alebo prúdu.
//
// Zatiaľ je to však dosť špecializovaná záležitosť, takže vždy vnútorne vždy jednu odčítame.
// Spotrebitelia by mali naďalej pracovať a dosahovať celkom dobré výsledky, takže by sme mali byť dosť dobrí.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Rovnako ako `resolve`, iba nebezpečné, pretože je nesynchronizované.
///
/// Táto funkcia nemá zaručených synchronizáciu, ale je k dispozícii, ak nie je zahrnutá funkcia `std` tohto crate.
/// Ďalšiu dokumentáciu a príklady nájdete vo funkcii `resolve`.
///
/// # Panics
///
/// Informácie o panike `cb` nájdete v informáciách na `resolve`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Rovnako ako `resolve_frame`, iba nebezpečné, pretože je nesynchronizované.
///
/// Táto funkcia nemá zaručených synchronizáciu, ale je k dispozícii, ak nie je zahrnutá funkcia `std` tohto crate.
/// Ďalšiu dokumentáciu a príklady nájdete vo funkcii `resolve_frame`.
///
/// # Panics
///
/// Informácie o panike `cb` nájdete v informáciách na `resolve_frame`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait predstavujúca rozlíšenie symbolu v súbore.
///
/// Táto funkcia trait sa získa ako objekt trait uzávierky danej funkcii `backtrace::resolve` a je prakticky odoslaná, pretože nie je známe, ktorá implementácia je za ňou.
///
///
/// Symbol môže poskytovať kontextové informácie o funkcii, napríklad meno, názov súboru, číslo riadku, presná adresa atď.
/// Nie všetky informácie sú však vždy k dispozícii v symbole, takže všetky metódy vrátia `Option`.
///
///
pub struct Symbol {
    // TODO: toto doživotné viazanie je potrebné nakoniec vydržať na `Symbol`,
    // ale to je momentálne zlomová zmena.
    // Zatiaľ je to bezpečné, pretože `Symbol` sa rozdáva iba ako referencia a nemožno ho klonovať.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Vráti názov tejto funkcie.
    ///
    /// Vrátenú štruktúru je možné použiť na dopytovanie rôznych vlastností názvu symbolu:
    ///
    ///
    /// * Implementácia `Display` vytlačí demangled symbol.
    /// * Je možné získať prístup k nespracovanej hodnote symbolu `str` (ak je platná utf-8).
    /// * Je možné získať nespracované bajty pre názov symbolu.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Vráti začiatočnú adresu tejto funkcie.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Vráti pôvodný názov súboru ako rez.
    /// To je užitočné hlavne pre prostredia `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Vráti číslo stĺpca, kde sa tento symbol momentálne vykonáva.
    ///
    /// Iba gimli tu v súčasnosti poskytuje hodnotu, a to iba vtedy, ak `filename` vráti `Some`, a preto na neho následne vzťahujú podobné výhrady.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Vráti číslo riadku, kde sa tento symbol momentálne vykonáva.
    ///
    /// Táto návratová hodnota je zvyčajne `Some`, ak `filename` vráti `Some`, a preto podlieha podobným výhradám.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Vráti názov súboru, kde bola definovaná táto funkcia.
    ///
    /// Toto je v súčasnosti k dispozícii iba vtedy, keď sa používa libbacktrace alebo gimli (napr
    /// unix iné platformy) a keď je binárny súbor kompilovaný s debuginfo.
    /// Ak nie je splnená žiadna z týchto podmienok, pravdepodobne sa vráti `None`.
    ///
    /// # Požadované funkcie
    ///
    /// Táto funkcia vyžaduje, aby bola povolená funkcia `std` modelu `backtrace` crate, a funkcia `std` je predvolene povolená.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Možno analyzovaný symbol C++ , ak syntaktická analýza pozmeneného symbolu ako Rust zlyhala.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Nezabudnite ponechať túto nulovú veľkosť, aby funkcia `cpp_demangle` pri deaktivácii nemala žiadne náklady.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Obal okolo názvu symbolu, ktorý poskytuje ergonomický prístup k demanglovanému názvu, nespracovaným bajtom, nespracovanému reťazcu atď.
///
// Ak nie je povolená funkcia `cpp_demangle`, povoľte mŕtvy kód.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Vytvorí nový názov symbolu zo základných bajtov.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Vráti pôvodný názov symbolu (mangled) ako `str`, ak je symbol platný utf-8.
    ///
    /// Ak chcete demanglovanú verziu, použite implementáciu `Display`.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Vráti pôvodný názov symbolu ako zoznam bajtov
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Toto sa môže vytlačiť, ak odštiepený symbol nie je v skutočnosti platný, takže s chybou tu zaobchádzajte ladne tak, že ju nerozširujete smerom von.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Pokus o získanie späť pamäte uloženej v pamäti použitej na symbolizáciu adries.
///
/// Táto metóda sa pokúsi uvoľniť akékoľvek globálne dátové štruktúry, ktoré boli inak uložené globálne alebo vo vlákne, ktoré zvyčajne predstavujú analyzované informácie DWARF alebo podobné.
///
///
/// # Caveats
///
/// Aj keď je táto funkcia vždy k dispozícii, vo väčšine implementácií vlastne nerobí nič.
/// Knižnice ako dbghelp alebo libbacktrace neposkytujú prostriedky na pridelenie stavu a správu pridelenej pamäte.
/// Pre túto chvíľu je funkcia `gimli-symbolize` tohto crate jedinou funkciou, kde má táto funkcia nejaký efekt.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}