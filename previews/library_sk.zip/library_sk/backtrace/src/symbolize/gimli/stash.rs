// používa sa momentálne iba na Linux, takže povoľte mŕtvy kód inde
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Jednoduchý alokátor arény pre bajtové medzipamäte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Pridelí vyrovnávaciu pamäť určenej veľkosti a vráti k nej premenlivý odkaz.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // BEZPEČNOSŤ: toto je jediná funkcia, ktorá kedy vytvorí premenlivý
        // odkaz na `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // BEZPEČNOSŤ: z `self.buffers` nikdy neodstraňujeme prvky, takže odkaz
        // na dáta vo vnútri akejkoľvek vyrovnávacej pamäte budú žiť tak dlho, ako to robí `self`.
        &mut buffers[i]
    }
}