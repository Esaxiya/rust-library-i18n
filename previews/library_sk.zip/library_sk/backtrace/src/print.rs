#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formátor pre spätné stopy.
///
/// Tento typ je možné použiť na tlač spätného sledovania bez ohľadu na to, odkiaľ samotné spätné sledovanie pochádza.
/// Ak máte typ `Backtrace`, potom jeho implementácia `Debug` už používa tento formát tlače.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Štýly tlače, ktoré môžeme tlačiť
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Vytlačí spätný chod tersera, ktorý ideálne obsahuje iba relevantné informácie
    Short,
    /// Vytlačí spätný chod, ktorý obsahuje všetky možné informácie
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Vytvorte nový `BacktraceFmt`, ktorý bude zapisovať výstup na dodaný `fmt`.
    ///
    /// Argument `format` bude riadiť štýl, v ktorom sa tlačí backtrace, a argument `print_path` sa použije na tlač inštancií súborov `BytesOrWideString`.
    /// Samotný tento typ nevykonáva žiadnu tlač súborov, ale je na to potrebné toto spätné volanie.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Vytlačí preambulu pre spätný chod, ktorý sa má vytlačiť.
    ///
    /// To je na niektorých platformách požadované, aby spätné stopy boli neskôr plne symbolizované, inak by to mala byť len prvá metóda, ktorú po vytvorení `BacktraceFmt` zavoláte.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Pridá rámec do výstupu spätného sledovania.
    ///
    /// Toto potvrdenie vráti inštanciu RAII `BacktraceFrameFmt`, ktorá sa dá použiť na skutočnú tlač rámca, a po zničení zvýši počítadlo rámca.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Dokončí výstup spätného sledovania.
    ///
    /// Toto je momentálne zakázaný režim, ale pridáva sa kvôli kompatibilite future s formátmi backtrace.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Momentálne nie je v prevádzke-vrátane tohto hook, aby bolo možné pridávať future.
        Ok(())
    }
}

/// Formátovač iba pre jeden snímok spätného sledovania.
///
/// Tento typ je vytvorený funkciou `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Vytlačí `BacktraceFrame` s týmto formátovačom snímok.
    ///
    /// Toto rekurzívne vytlačí všetky inštancie `BacktraceSymbol` v rámci `BacktraceFrame`.
    ///
    /// # Požadované funkcie
    ///
    /// Táto funkcia vyžaduje, aby bola povolená funkcia `std` modelu `backtrace` crate, a funkcia `std` je predvolene povolená.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Vytlačí `BacktraceSymbol` v rámci `BacktraceFrame`.
    ///
    /// # Požadované funkcie
    ///
    /// Táto funkcia vyžaduje, aby bola povolená funkcia `std` modelu `backtrace` crate, a funkcia `std` je predvolene povolená.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: to nie je skvelé, že nakoniec nič nevytlačíme
            // s názvami súborov, ktoré nie sú utf8.
            // Našťastie takmer všetko je utf8, takže by to nemalo byť príliš zlé.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Vytlačí surové sledované `Frame` a `Symbol`, zvyčajne z nespracovaných spätných volaní tohto crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Pridá nespracovaný rámec k výstupu spätného sledovania.
    ///
    /// Táto metóda, na rozdiel od predchádzajúcej, berie surové argumenty pre prípad, že sú zdrojom z rôznych umiestnení.
    /// Upozorňujeme, že pre jeden rámec to možno nazvať viackrát.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Pridá nespracovaný rámec do výstupu spätného sledovania vrátane informácií o stĺpci.
    ///
    /// Táto metóda, rovnako ako predchádzajúca, berie surové argumenty pre prípad, že sú zdrojom z rôznych umiestnení.
    /// Upozorňujeme, že pre jeden rámec to možno nazvať viackrát.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia nie je schopná symbolizovať v rámci procesu, má preto špeciálny formát, ktorý je možné použiť na neskoršiu symbolizáciu.
        // Vytlačte ich namiesto tlačenia adries v našom vlastnom formáte tu.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Nie je potrebné tlačiť rámy "null", v podstate to znamená, že systémová spätná väzba bola trochu horlivá na to, aby bolo možné vystopovať super ďaleko.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Aby sme zmenšili veľkosť TCB v enkláve Sgx, nechceme implementovať funkčnosť rozlíšenia symbolov.
        // Namiesto toho tu môžeme vytlačiť posun adresy, ktorý je možné neskôr zmapovať na správnu funkciu.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Vytlačte index rámu, ako aj voliteľný ukazovateľ pokynov pre rám.
        // Pokiaľ sme za prvým symbolom tohto rámca, vytlačíme iba príslušné medzery.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Ďalej napíšeme názov symbolu. Ak máme úplnú spätnú stopu, pre ďalšie informácie použite alternatívne formátovanie.
        // Tu tiež narábame so symbolmi, ktoré nemajú meno,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // A nakoniec, vytlačte si číslo filename/line, ak je k dispozícii.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line sú vytlačené na riadkoch pod názvom symbolu, takže si vytlačte nejaké vhodné medzery, aby sme sa mohli zarovnať doprava.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegujte naše interné spätné volanie, aby ste vytlačili názov súboru a potom vytlačili číslo riadku.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Pridajte číslo stĺpca, ak je k dispozícii.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Záleží nám iba na prvom symbole rámu
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}