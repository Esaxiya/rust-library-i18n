use core::ffi::c_void;
use core::fmt;

/// Skontroluje aktuálny zásobník hovorov a odovzdá všetky aktívne rámce do poskytnutého uzáveru na výpočet trasovania zásobníka.
///
/// Táto funkcia je ťažným koňom tejto knižnice pri výpočte stôp zásobníka pre program.Daná uzávierka `cb` je získaná inštanciou `Frame`, ktorá predstavuje informáciu o tomto volacom rámci v zásobníku.
/// Uzáverom sa poskytujú rámce zhora nadol (naposledy sa volajú najskôr funkcie).
///
/// Návratová hodnota uzávierky naznačuje, či má spätný chod pokračovať.Návratová hodnota `false` ukončí spätný chod a vráti sa okamžite.
///
/// Po získaní `Frame` budete pravdepodobne chcieť zavolať `backtrace::resolve` a previesť `ip` (ukazovateľ inštrukcie) alebo adresu symbolu na `Symbol`, cez ktorý sa dá naučiť meno a/alebo názov súboru/číslo linky.
///
///
/// Upozorňujeme, že ide o funkciu na relatívne nízkej úrovni a ak chcete napríklad zachytiť spätný chod, ktorý sa má skontrolovať neskôr, môže byť vhodnejší typ `Backtrace`.
///
/// # Požadované funkcie
///
/// Táto funkcia vyžaduje, aby bola povolená funkcia `std` modelu `backtrace` crate, a funkcia `std` je predvolene povolená.
///
/// # Panics
///
/// Táto funkcia sa nikdy nesnaží panic, ale ak `cb` poskytla panics, niektoré platformy vynútia dvojitý panic, aby proces prerušil.
/// Niektoré platformy používajú knižnicu C, ktorá interne používa spätné volania, ktoré sa nedajú odmotať, takže panika z `cb` môže spôsobiť prerušenie procesu.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // pokračovať v spätnom slede
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Rovnako ako `trace`, iba nebezpečné, pretože je nesynchronizované.
///
/// Táto funkcia nemá zaručených synchronizáciu, ale je k dispozícii, ak nie je zahrnutá funkcia `std` tohto crate.
/// Ďalšiu dokumentáciu a príklady nájdete vo funkcii `trace`.
///
/// # Panics
///
/// Informácie o panike `cb` nájdete v informáciách na `trace`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait predstavujúci jeden rámec spätného sledu, sa dostal k funkcii `trace` tohto crate.
///
/// Uzavretím funkcie sledovania sa získajú rámce a rám sa prakticky odošle, pretože podkladová implementácia nie je vždy známa až do spustenia.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Vráti aktuálny ukazovateľ inštrukcie tohto rámca.
    ///
    /// Toto je zvyčajne ďalšia inštrukcia, ktorá sa má vykonať v rámci, ale nie všetky implementácie ju uvádzajú so 100% presnosťou (ale je všeobecne dosť blízka).
    ///
    ///
    /// Odporúča sa odovzdať túto hodnotu `backtrace::resolve`, aby sa zmenila na názov symbolu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Vráti aktuálny ukazovateľ zásobníka tohto rámca.
    ///
    /// V prípade, že backend nemôže obnoviť ukazovateľ zásobníka pre tento rámec, vráti sa nulový ukazovateľ.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Vráti adresu počiatočného symbolu rámca tejto funkcie.
    ///
    /// To sa pokúsi pretočiť ukazovateľ inštrukcie vrátený `ip` na začiatok funkcie a vrátiť túto hodnotu.
    ///
    /// V niektorých prípadoch však back-end vráti iba `ip` z tejto funkcie.
    ///
    /// Vrátená hodnota môže byť niekedy použitá, ak `backtrace::resolve` zlyhal na `ip` uvedenom vyššie.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Vráti základnú adresu modulu, ku ktorému rámec patrí.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // To musí byť na prvom mieste, aby sa zabezpečilo, že Miri bude mať pred hostiteľskou platformou prednosť
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // použité iba v dbghelp symbolizujú
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}