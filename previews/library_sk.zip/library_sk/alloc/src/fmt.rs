//! Obslužné programy pre formátovanie a tlač `String`s.
//!
//! Tento modul obsahuje podporu behu pre rozšírenie syntaxe [`format!`].
//! Toto makro je implementované v kompilátore na emitovanie hovorov do tohto modulu s cieľom formátovania argumentov za behu do reťazcov.
//!
//! # Usage
//!
//! Makro [`format!`] má byť oboznámené s nástrojmi pochádzajúcimi z funkcií `printf`/`fprintf` od C alebo z `str.format` funkcie Python.
//!
//! Niektoré príklady rozšírenia [`format!`] sú:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" s úvodnými nulami
//! ```
//!
//! Z nich môžete vidieť, že prvým argumentom je formátovací reťazec.Kompilátor to vyžaduje ako reťazcový literál;nemôže to byť odovzdaná premenná (na účely kontroly platnosti).
//! Kompilátor potom analyzuje formátovací reťazec a určí, či je poskytnutý zoznam argumentov vhodný na odovzdanie do tohto formátovacieho reťazca.
//!
//! Ak chcete previesť jednu hodnotu na reťazec, použite metódu [`to_string`].Použije sa formátovanie trait vo formáte [`Display`].
//!
//! ## Pozičné parametre
//!
//! Každý argument formátovania môže určiť, na ktorý hodnotový argument odkazuje, a ak sa vynechá, predpokladá sa, že je "the next argument".
//! Napríklad formátovací reťazec `{} {} {}` bude trvať tri parametre a budú formátované v rovnakom poradí, v akom sú dané.
//! Formátovací reťazec `{2} {1} {0}` by však formátoval argumenty v opačnom poradí.
//!
//! Veci môžu byť trochu komplikované, akonáhle začnete miešať dva typy polohových špecifikátorov.O špecifikátore "next argument" sa dá uvažovať ako o iterátore argumentu.
//! Zakaždým, keď sa zobrazí špecifikátor "next argument", iterátor pokročí.To vedie k takémuto správaniu:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Interný iterátor argumentu nebol pokročilý v čase, keď je prvý `{}` viditeľný, takže vypíše prvý argument.Potom po dosiahnutí druhého `{}` iterátor postúpil vpred k druhému argumentu.
//! Parametre, ktoré výslovne pomenujú svoj argument, v zásade neovplyvňujú parametre, ktoré nepomenujú argument z hľadiska pozičných špecifikátorov.
//!
//! Na použitie všetkých svojich argumentov je potrebný formátovací reťazec, inak sa jedná o chybu pri kompilácii.Na ten istý argument môžete vo formátovacom reťazci odkazovať viackrát.
//!
//! ## Pomenované parametre
//!
//! Samotný Rust nemá ekvivalent pomenovaných parametrov k funkcii podobný Python, ale makro [`format!`] je rozšírenie syntaxe, ktoré mu umožňuje využívať pomenované parametre.
//! Pomenované parametre sú uvedené na konci zoznamu argumentov a majú syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Napríklad všetky nasledujúce výrazy [`format!`] používajú pomenovaný argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Nie je platné umiestňovať pozičné parametre (tie bez mien) za argumenty, ktoré majú názvy.Rovnako ako v prípade pozičných parametrov nie je platné poskytovať pomenované parametre, ktoré formátový reťazec nepoužíva.
//!
//! # Parametre formátovania
//!
//! Každý formátovaný argument je možné transformovať pomocou niekoľkých formátovacích parametrov (zodpovedajúcich `format_spec` v [the syntax](#syntax)). Tieto parametre ovplyvňujú reťazcovú reprezentáciu formátovaného parametra.
//!
//! ## Width
//!
//! ```
//! // Všetky tieto tlačové verzie "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Toto je parameter pre "minimum width", ktorý by mal formát zaberať.
//! Ak reťazec hodnoty nespĺňa toľko znakov, použije sa na zaberanie požadovaného miesta výplň zadaná fill/alignment (pozri nižšie).
//!
//! Hodnotu šírky je možné zadať aj ako [`usize`] v zozname parametrov pridaním postfixu `$`, čo naznačuje, že druhým argumentom je [`usize`] určujúci šírku.
//!
//! Odkaz na argument so syntaxou dolára nemá vplyv na počítadlo "next argument", takže je zvyčajne dobré odkazovať na argumenty podľa polohy alebo použiť pomenované argumenty.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Voliteľný znak vyplnenia a zarovnanie sa poskytuje bežne v spojení s parametrom [`width`](#width).Musí byť definované pred `width`, hneď za `:`.
//! To znamená, že ak je formátovaná hodnota menšia ako `width`, budú sa okolo nej tlačiť ďalšie znaky.
//! Výplň sa dodáva v nasledujúcich variantoch pre rôzne zarovnania:
//!
//! * `[fill]<` - argument je zarovnaný doľava v stĺpcoch `width`
//! * `[fill]^` - argument je zarovnaný na stred v stĺpcoch `width`
//! * `[fill]>` - argument je zarovnaný doprava v stĺpcoch `width`
//!
//! Predvolená hodnota [fill/alignment](#fillalignment) pre nečíselné znaky je medzera a zarovnanie doľava.Predvolená hodnota pre číselných formátovačov je tiež znak medzery, ale so zarovnaním doprava.
//! Ak je pre numeriku zadaný príznak `0` (pozri nižšie), potom je implicitný znak výplne `0`.
//!
//! Upozorňujeme, že niektoré typy nemusia zarovnávanie implementovať.Najmä to nie je všeobecne implementované pre `Debug` trait.
//! Dobrým spôsobom, ako zabezpečiť, aby sa výplň používala, je naformátovať váš vstup a potom tento výsledný reťazec vložiť, aby ste získali svoj výstup:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => " Ahoj Some("hi")!`
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Všetko sú to príznaky, ktoré menia správanie formátovača.
//!
//! * `+` - Je to určené pre číselné typy a znamená to, že znamienko by malo byť vždy vytlačené.Pozitívne znamienka sa štandardne nikdy nevytlačia a záporné znamienko sa štandardne vytlačí iba pre model `Signed` trait.
//! Tento príznak označuje, že sa má vždy vytlačiť správny znak (`+` alebo `-`).
//! * `-` - Momentálne sa nepoužíva
//! * `#` - Tento príznak označuje, že by sa mala použiť forma tlače "alternate".Alternatívne formy sú:
//!     * `#?` - pekne vytlačte formátovanie [`Debug`]
//!     * `#x` - predchádza argumentu s `0x`
//!     * `#X` - predchádza argumentu s `0x`
//!     * `#b` - predchádza argumentu s `0b`
//!     * `#o` - predchádza argumentu s `0o`
//! * `0` - Toto sa používa na označenie celočíselných formátov, že výplň do `width` by sa mala robiť pomocou znaku `0`, ako aj na zabezpečenie znaku.
//! Formát ako `{:08}` by priniesol `00000001` pre celé číslo `1`, zatiaľ čo rovnaký formát by priniesol `-0000001` pre celé číslo `-1`.
//! Všimnite si, že negatívna verzia má o jednu nulu menej ako pozitívna verzia.
//!         Upozorňujeme, že nuly výplne sú vždy umiestnené za znamienkom (ak existujú) a pred číslice.Ak sa použije spolu s príznakom `#`, platí podobné pravidlo: vypĺňajúce nuly sa vkladajú za predponu, ale pred číslice.
//!         Predpona je zahrnutá v celkovej šírke.
//!
//! ## Precision
//!
//! Pre nečíselné typy to možno považovať za "maximum width".
//! Ak je výsledný reťazec dlhší ako táto šírka, potom sa skráti na tento počet znakov a táto skrátená hodnota sa vydá so správnymi `fill`, `alignment` a `width`, ak sú tieto parametre nastavené.
//!
//! Pre integrálne typy sa to ignoruje.
//!
//! Pre typy s pohyblivou rádovou čiarkou to označuje, koľko číslic za desatinnou čiarkou sa má vytlačiť.
//!
//! Existujú tri možné spôsoby, ako určiť požadovaný `precision`:
//!
//! 1. Celé číslo `.N`:
//!
//!    celé číslo `N` je presnosť.
//!
//! 2. Celé číslo alebo meno, za ktorým nasleduje znak dolára `.N$`:
//!
//!    ako presnosť použite format *argument*`N` (čo musí byť `usize`).
//!
//! 3. Hviezdička `.*`:
//!
//!    `.*` znamená, že táto `{...}` je spojená skôr s *dvoma* formátmi ako s jedným: prvý vstup má presnosť `usize` a druhý hodnotu pre tlač.
//!    Upozorňujeme, že v takom prípade, ak použijete formátovací reťazec `{<arg>:<spec>.*}`, potom časť `<arg>` odkazuje na* hodnotu *, ktorá sa má vytlačiť, a `precision` musí byť vo vstupe predchádzajúcom `<arg>`.
//!
//! Napríklad nasledujúce hovory tlačia to isté na `Hello x is 0.01000`:
//!
//! ```
//! // Dobrý deň, {arg 0 ("x")} je {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Dobrý deň, {arg 1 ("x")} je {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Dobrý deň, {arg 0 ("x")} je {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Dobrý deň, {next arg ("x")} je {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Dobrý deň, {next arg ("x")} je {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Dobrý deň, {next arg ("x")} je {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Aj keď tieto:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! vytlačiť tri výrazne odlišné veci:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! V niektorých programovacích jazykoch závisí správanie funkcií formátovania reťazcov od nastavenia miestneho nastavenia operačného systému.
//! Funkcie formátovania poskytované štandardnou knižnicou Rust nemajú žiadny koncept miestneho nastavenia a budú produkovať rovnaké výsledky vo všetkých systémoch bez ohľadu na konfiguráciu používateľa.
//!
//! Napríklad nasledujúci kód vždy vytlačí `1.5`, aj keď miestne nastavenie systému používa oddeľovač desatinných miest iný ako bodka.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Doslovné znaky `{` a `}` je možné zahrnúť do reťazca tak, že ich predošlete s rovnakým znakom.Napríklad znak `{` je uniknutý znakom `{{` a znak `}` znakom `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Ak to zhrnieme, tu nájdete celú gramatiku formátovacích reťazcov.
//! Syntax použitého jazyka na formátovanie je čerpaná z iných jazykov, takže by nemala byť príliš cudzia.Argumenty sú naformátované pomocou syntaxe podobnej Python, čo znamená, že argumenty sú obklopené znakom `{}` namiesto znakom `%` podobným písmenu C.
//! Aktuálna gramatika syntaxe formátovania je:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Vo vyššie uvedenej gramatike nesmie `text` obsahovať žiadne znaky `'{'` alebo `'}'`.
//!
//! # Formátovanie traits
//!
//! Keď požadujete formátovanie argumentu konkrétnym typom, skutočne požadujete, aby sa argument pripísal konkrétnemu trait.
//! To umožňuje formátovanie viacerých aktuálnych typov cez `{:x}` (napríklad [`i8`] aj [`isize`]).Aktuálne mapovanie typov na traits je:
//!
//! * *nič* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] s malými šestnástkovými celými číslami
//! * `X?` ⇒ [`Debug`] s veľkými hexadecimálnymi celými číslami
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! To znamená, že akýkoľvek typ argumentu, ktorý implementuje [`fmt::Binary`][`Binary`] trait, možno potom naformátovať pomocou `{:b}`.Štandardná knižnica poskytuje implementácie pre tieto traits aj pre množstvo primitívnych typov.
//!
//! Ak nie je zadaný žiadny formát (ako v `{}` alebo `{:6}`), použije sa formát trait v [`Display`] trait.
//!
//! Pri implementácii formátu trait pre váš vlastný typ budete musieť implementovať metódu podpisu:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // náš vlastný typ
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Váš typ bude odoslaný ako vedľajšia referencia `self` a funkcia by potom mala vysielať výstup do streamu `f.buf`.Je na implementácii každého formátu trait, aby správne dodržiaval požadované parametre formátovania.
//! Hodnoty týchto parametrov budú uvedené v poliach štruktúry [`Formatter`].S cieľom pomôcť s tým poskytuje štruktúra [`Formatter`] tiež niektoré pomocné metódy.
//!
//! Návratová hodnota tejto funkcie je navyše [`fmt::Result`], čo je alias typu [`Výsledok`]`<(),`[`std: : fmt::Chyba`] `>.
//! Implementácie formátovania by mali zabezpečiť, aby šírili chyby z [`Formatter`] (napr. Pri volaní [`write!`]).
//! Nikdy by však nemali chyby vracať podvodne.
//! To znamená, že implementácia formátovania musí a môže vrátiť chybu, iba ak vrátená chyba [`Formatter`] vráti chybu.
//! Je to tak preto, že na rozdiel od toho, čo by mohol podpis funkcie naznačovať, je formátovanie reťazca neomylnou operáciou.
//! Táto funkcia vracia iba výsledok, pretože zápis do základného toku môže zlyhať a musí poskytnúť spôsob šírenia skutočnosti, že došlo k chybe, späť do zásobníka.
//!
//! Príklad implementácie formátovania traits by vyzeral takto:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Hodnota `f` implementuje `Write` trait, o čom je zápis!makro očakáva.
//!         // Upozorňujeme, že toto formátovanie ignoruje rôzne príznaky poskytované formátovacím reťazcom.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Rôzne traits umožňujú rôzne formy výstupu typu.
//! // Zmyslom tohto formátu je vytlačiť veľkosť vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Rešpektujte príznaky formátovania pomocou pomocnej metódy `pad_integral` na objekte Formatter.
//!         // Podrobnosti nájdete v dokumentácii k metóde. Funkciu `pad` je možné použiť na vloženie reťazcov.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Tieto dva formátovacie znaky traits majú odlišné účely:
//!
//! - [`fmt::Display`][`Display`] implementácie tvrdia, že typ je možné kedykoľvek verne zobraziť ako reťazec UTF-8.** Neočakáva sa, že všetky typy implementujú [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementácie by sa mali implementovať pre **všetky** verejné typy.
//!   Výstup bude typicky predstavovať vnútorný stav čo najvernejšie.
//!   Účelom [`Debug`] trait je uľahčiť ladenie kódu Rust.Vo väčšine prípadov je použitie `#[derive(Debug)]` dostatočné a odporúčané.
//!
//! Niekoľko príkladov výstupu z obidvoch traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Súvisiace makrá
//!
//! V rodine [`format!`] existuje množstvo súvisiacich makier.V súčasnosti sa implementujú tieto nástroje:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Toto a [`writeln!`] sú dve makrá, ktoré sa používajú na emitovanie formátovacieho reťazca do určeného streamu.Používa sa na zabránenie stredného pridelenia formátovacích reťazcov a na priamy zápis výstupu.
//! Pod kapotou táto funkcia v skutočnosti vyvoláva funkciu [`write_fmt`] definovanú v modeli [`std::io::Write`] trait.
//! Príklad použitia je:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Toto a [`println!`] vydávajú svoj výstup do stdout.Podobne ako v makre [`write!`], cieľom týchto makier je vyhnúť sa medzičasovým alokáciám pri tlačovom výstupe.Príklad použitia je:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makrá [`eprint!`] a [`eprintln!`] sú identické s makrami [`print!`] a [`println!`], až na to, že vydávajú svoj výstup do stderr.
//!
//! ### `format_args!`
//!
//! Toto je kuriózne makro používané na bezpečné obídenie nepriehľadného objektu popisujúceho formátovací reťazec.Tento objekt nevyžaduje na vytvorenie žiadne pridelenie haldy a odkazuje iba na informácie v zásobníku.
//! Z tohto dôvodu sú pod kapotou implementované všetky súvisiace makrá.
//! Najprv je niekoľko príkladov použitia:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Výsledkom makra [`format_args!`] je hodnota typu [`fmt::Arguments`].
//! Túto štruktúru je potom možné odovzdať funkcii [`write`] a [`format`] vo vnútri tohto modulu, aby sa mohol spracovať formátovací reťazec.
//! Cieľom tohto makra je ešte viac zabrániť prechodným alokáciám pri práci s formátovacími reťazcami.
//!
//! Napríklad knižnica protokolovania mohla používať štandardnú syntax formátovania, ale vnútorne by prechádzala okolo tejto štruktúry, kým by nebolo určené, kam má smerovať výstup.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funkcia `format` prevezme štruktúru [`Arguments`] a vráti výsledný formátovaný reťazec.
///
///
/// Inštanciu [`Arguments`] je možné vytvoriť pomocou makra [`format_args!`].
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Upozorňujeme, že použitie [`format!`] môže byť výhodnejšie.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}