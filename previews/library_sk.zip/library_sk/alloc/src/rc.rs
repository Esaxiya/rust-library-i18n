//! Ukazovatele počítania odkazov s jedným vláknom.'Rc' znamená " referencia`
//! Counted'.
//!
//! Typ [`Rc<T>`][`Rc`] poskytuje zdieľané vlastníctvo hodnoty typu `T` pridelenej v halde.
//! Vyvolanie [`clone`][clone] na [`Rc`] vytvorí nový ukazovateľ na rovnaké pridelenie v halde.
//! Keď sa zničí posledný ukazovateľ [`Rc`] na dané pridelenie, hodnota uložená v tomto pridelení (často označovaná ako "inner value") sa tiež zruší.
//!
//! Zdieľané odkazy v Rust predvolene nepovoľujú mutáciu a [`Rc`] nie je výnimkou: vo všeobecnosti nemôžete získať premenlivý odkaz na niečo vo vnútri [`Rc`].
//! Ak potrebujete premenlivosť, vložte [`Cell`] alebo [`RefCell`] do [`Rc`];pozri [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] používa počítanie nenatomových odkazov.
//! To znamená, že réžia je veľmi nízka, ale [`Rc`] nie je možné poslať medzi vláknami, a následne [`Rc`] neimplementuje [`Send`][send].
//! Vo výsledku kompilátor Rust skontroluje *v čase kompilácie*, či medzi vláknami neposielate [`Rc`] s.
//! Ak potrebujete viacvláknové počítanie atómových odkazov, použite [`sync::Arc`][arc].
//!
//! Metódu [`downgrade`][downgrade] možno použiť na vytvorenie ukazovateľa [`Weak`], ktorý nevlastní.
//! Ukazovateľ [`Weak`] môže byť ["upgrade"][upgrade] d na [`Rc`], ale vráti [`None`], ak už bola hodnota uložená v alokácii zrušená.
//! Inými slovami, ukazovatele `Weak` neudržiavajú hodnotu v rámci alokácie nažive;udržujú však alokáciu (záložný obchod pre vnútornú hodnotu) nažive.
//!
//! Cyklus medzi ukazovateľmi [`Rc`] nebude nikdy pridelený.
//! Z tohto dôvodu sa [`Weak`] používa na prerušenie cyklov.
//! Napríklad strom môže mať silné ukazovatele [`Rc`] z rodičovských uzlov na deti a ukazovatele [`Weak`] z detí späť na svojich rodičov.
//!
//! `Rc<T>` automaticky dereferencie na `T` (cez [`Deref`] trait), takže môžete zavolať `T` metódy na hodnotu typu [`Rc<T>`][`Rc`].
//! Aby sa zabránilo stretom mien s metódami `T`, sú metódy samotného [`Rc<T>`][`Rc`] pridružené funkcie nazývané pomocou [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! " Rc<T>" Implementácie traits ako `Clone` možno tiež nazývať pomocou plne kvalifikovanej syntaxe.
//! Niektorí ľudia uprednostňujú použitie plne kvalifikovanej syntaxe, zatiaľ čo iní uprednostňujú použitie syntaxe hovorov metódami.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Syntax volania metódy
//! let rc2 = rc.clone();
//! // Plne kvalifikovaná syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] nemá automatickú dereferenciu k `T`, pretože vnútorná hodnota už mohla byť zrušená.
//!
//! # Klonovacie referencie
//!
//! Vytvorenie nového odkazu na rovnakú alokáciu ako existujúceho ukazovateľa spočítaného odkazu sa uskutoční pomocou `Clone` trait implementovaného pre [`Rc<T>`][`Rc`] a [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Dve nižšie uvedené syntaxe sú ekvivalentné.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a a b ukazujú na rovnaké pamäťové miesto ako foo.
//! ```
//!
//! Syntax `Rc::clone(&from)` je najidiomatickejšia, pretože explicitnejšie vyjadruje význam kódu.
//! Vo vyššie uvedenom príklade táto syntax uľahčuje zistenie, že tento kód vytvára nový odkaz a nie kopíruje celý obsah foo.
//!
//! # Examples
//!
//! Zvážte scenár, keď sadu `modulov gadget 'vlastní daný model `Owner`.
//! Chceme, aby náš `modul gadget` ukazoval na ich `Owner`.Toto nemôžeme urobiť s jedinečným vlastníctvom, pretože k tomu istému `Owner` môže patriť viac ako jeden modul gadget.
//! [`Rc`] umožňuje nám zdieľať `Owner` medzi viacerými `modulmi gadget` a nechať `Owner` zostať alokovaný, pokiaľ na ňom budú akékoľvek `Gadget` body.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... ďalšie polia
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ďalšie polia
//! }
//!
//! fn main() {
//!     // Vytvorte `Owner` s počítaním referencií.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Vytvorte `Gadget` patriaci k `gadget_owner`.
//!     // Klonovanie `Rc<Owner>` nám dáva nový ukazovateľ na rovnaké pridelenie `Owner`, čím sa zvyšuje počet referencií v procese.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Zlikvidujte našu lokálnu premennú `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Aj napriek vypadnutiu `gadget_owner`, sme stále schopní vytlačiť si názov `Owner` " Gadgetov`.
//!     // Je to tak preto, lebo sme zhodili iba jednu `Rc<Owner>`, nie `Owner`, na ktorú ukazuje.
//!     // Pokiaľ existujú ďalšie `Rc<Owner>` smerujúce k rovnakému prideleniu `Owner`, zostane aktívny.
//!     // Polná projekcia `gadget1.owner.name` funguje, pretože `Rc<Owner>` sa automaticky dereferencuje na `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Na konci funkcie sú `gadget1` a `gadget2` zničené a s nimi aj posledné spočítané odkazy na našu `Owner`.
//!     // Gadget Man je teraz tiež zničený.
//!     //
//! }
//! ```
//!
//! Ak sa naše požiadavky zmenia a budeme tiež musieť byť schopní prechádzať z `Owner` na `Gadget`, narazíme na problémy.
//! Ukazovateľ [`Rc`] od `Owner` do `Gadget` zavádza cyklus.
//! To znamená, že ich referenčné počty nikdy nemôžu dosiahnuť 0 a pridelenie nikdy nebude zničené:
//! únik pamäte.Aby sme to obišli, môžeme použiť ukazovatele [`Weak`].
//!
//! Rust v skutočnosti sťažuje výrobu tejto slučky na prvom mieste.Aby sme dosiahli dve hodnoty, ktoré ukazujú na seba, musí byť jedna z nich premenlivá.
//! To je ťažké, pretože [`Rc`] vynucuje bezpečnosť pamäte tým, že vydáva iba zdieľané odkazy na hodnotu, ktorú zalamuje, a tieto neumožňujú priamu mutáciu.
//! Časť hodnoty, ktorú chceme mutovať, musíme zabaliť do [`RefCell`], ktorá poskytuje *vnútornú premenlivosť*: metódu na dosiahnutie mutovateľnosti prostredníctvom zdieľaného odkazu.
//! [`RefCell`] vynucuje pravidlá výpožičky Rust za behu.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... ďalšie polia
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... ďalšie polia
//! }
//!
//! fn main() {
//!     // Vytvorte `Owner` s počítaním referencií.
//!     // Všimnite si, že sme vložili vector " vlastníka`" Gadgetu` do `RefCell`, aby sme ho mohli mutovať prostredníctvom zdieľaného odkazu.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Vytvorte gadget patriaci k `gadget_owner`, ako predtým.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Pridajte k svojmu `Owner` ``Gadget`s.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` tu sa končí dynamický výpožička.
//!     }
//!
//!     // Iterujte nad našimi `gadgetmi 'a tlačte ich podrobnosti.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` je `Weak<Gadget>`.
//!         // Pretože ukazovatele `Weak` nemôžu zaručiť, že pridelenie stále existuje, musíme zavolať `upgrade`, ktorý vráti `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // V tomto prípade vieme, že alokácia stále existuje, takže jednoducho `unwrap` a `Option`.
//!         // V komplikovanejšom programe budete pre výsledok `None` potrebovať elegantné spracovanie chýb.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Na konci funkcie sú `gadget_owner`, `gadget1` a `gadget2` zničené.
//!     // Teraz na gadgety neexistujú žiadne silné ukazovatele (`Rc`), takže sú zničené.
//!     // To vynuluje referenčný počet na Gadget Mana, takže sa tiež zničí.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Toto je odolné repr(C) až future proti možnému preskupeniu polí, ktoré by rušilo inak bezpečné [into|from]_raw() transmutovateľných vnútorných typov.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Ukazovateľ počítania odkazov s jedným vláknom.'Rc' znamená " referencia`
/// Counted'.
///
/// Ďalšie informácie nájdete v modeli [module-level documentation](./index.html).
///
/// Inherentnou metódou `Rc` sú všetky pridružené funkcie, čo znamená, že ich musíte volať napr. [`Rc::get_mut(&mut value)`][get_mut] namiesto `value.get_mut()`.
/// Tým sa zabráni konfliktom s metódami vnútorného typu `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Táto bezpečnosť je v poriadku, pretože keď je tento Rc nažive, máme zaručené, že vnútorný ukazovateľ je platný.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konštruuje nový `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Všetky silné ukazovatele vlastnia implicitný slabý ukazovateľ, ktorý zaisťuje, že slabý deštruktor nikdy neuvoľní alokáciu, kým je silný deštruktor spustený, aj keď je slabý ukazovateľ uložený vo vnútri silného ukazovateľa.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konštruuje nový model `Rc<T>` so slabým odkazom na seba.
    /// Pokus o aktualizáciu slabej referencie pred návratom tejto funkcie bude mať za následok hodnotu `None`.
    ///
    /// Slabá referencia však môže byť voľne klonovaná a uložená na neskoršie použitie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... viac polí
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Zostrojte vnútorný v stave "uninitialized" s jednou slabou referenciou.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Je dôležité, aby sme sa nevzdali vlastníctva slabého ukazovateľa, inak by sa mohla pamäť uvoľniť do času, keď sa vráti `data_fn`.
        // Ak by sme skutočne chceli odovzdať vlastníctvo, mohli by sme pre seba vytvoriť ďalšieho slabého ukazovateľa, čo by však malo za následok ďalšie aktualizácie slabého referenčného počtu, ktoré by inak neboli potrebné.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Silné referencie by mali spoločne vlastniť zdieľanú slabú referenciu, takže nespúšťajte deštruktor pre našu starú slabú referenciu.
        //
        mem::forget(weak);
        strong
    }

    /// Vyrába nový model `Rc` s neinicializovaným obsahom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializácia:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Zostrojí nový model `Rc` s neinicializovaným obsahom a pamäť bude vyplnená bajtmi `0`.
    ///
    ///
    /// Príklady správneho a nesprávneho použitia tejto metódy nájdete v časti [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Vytvorí nový `Rc<T>` a vráti chybu, ak alokácia zlyhá
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Všetky silné ukazovatele vlastnia implicitný slabý ukazovateľ, ktorý zaisťuje, že slabý deštruktor nikdy neuvoľní alokáciu, kým je silný deštruktor spustený, aj keď je slabý ukazovateľ uložený vo vnútri silného ukazovateľa.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Vytvorí nový model `Rc` s neinicializovaným obsahom a vráti chybu, ak alokácia zlyhá
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odložená inicializácia:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Zostrojí nový `Rc` s neinicializovaným obsahom, pričom pamäť bude vyplnená bajtmi `0` a v prípade zlyhania alokácie vráti chybu.
    ///
    ///
    /// Príklady správneho a nesprávneho použitia tejto metódy nájdete v časti [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konštruuje nový `Pin<Rc<T>>`.
    /// Ak `T` neimplementuje `Unpin`, potom bude `value` pripnutý v pamäti a nebude ho možné presunúť.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Vráti vnútornú hodnotu, ak má `Rc` presne jednu silnú referenciu.
    ///
    /// V opačnom prípade sa vráti [`Err`] s rovnakým `Rc`, ktorý bol odovzdaný.
    ///
    ///
    /// To sa podarí, aj keď existujú vynikajúce slabé referencie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // skopírujte obsiahnutý objekt

                // Naznačte Weaksovi, že ich nemožno povýšiť znížením silného počtu, a potom odstráňte implicitný ukazovateľ "strong weak" a zároveň zvládnite logiku poklesu iba vytvorením falošného slabého.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Vytvorí nový rezom počítaný odkaz s neinicializovaným obsahom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializácia:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Vytvorí nový rezom počítaný odkaz s neinicializovaným obsahom, pričom pamäť sa vyplní bajtmi `0`.
    ///
    ///
    /// Príklady správneho a nesprávneho použitia tejto metódy nájdete v časti [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Konvertuje na `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Rovnako ako v prípade modelu [`MaybeUninit::assume_init`], je na volajúcom, aby zaručil, že vnútorná hodnota je skutočne v inicializovanom stave.
    ///
    /// Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí okamžité nedefinované správanie.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializácia:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Konvertuje na `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Rovnako ako v prípade modelu [`MaybeUninit::assume_init`], je na volajúcom, aby zaručil, že vnútorná hodnota je skutočne v inicializovanom stave.
    ///
    /// Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí okamžité nedefinované správanie.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializácia:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Spotrebuje `Rc` a vráti zabalený ukazovateľ.
    ///
    /// Aby sa zabránilo úniku pamäte, musí byť ukazovateľ prevedený späť na `Rc` pomocou [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Poskytuje nespracovaný ukazovateľ na údaje.
    ///
    /// Počty nie sú nijako ovplyvnené a `Rc` sa nespotrebováva.
    /// Ukazovateľ je platný, pokiaľ je v `Rc` vysoký počet.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // BEZPEČNOSŤ: Toto nemôže ísť cez Deref::deref alebo Rc::inner, pretože
        // to je potrebné na zachovanie pôvodu raw/mut tak, aby napr
        // `get_mut` môže písať cez ukazovateľ po obnovení Rc cez `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Vytvorí `Rc<T>` zo surového ukazovateľa.
    ///
    /// Nespracovaný ukazovateľ musel byť predtým vrátený volaním [`Rc<U>::into_raw`][into_raw], kde `U` musí mať rovnakú veľkosť a zarovnanie ako `T`.
    /// Platí to triviálne, ak `U` je `T`.
    /// Upozorňujeme, že ak `U` nie je `T`, ale má rovnakú veľkosť a zarovnanie, je to v podstate ako transmutácia referencií rôznych typov.
    /// Ďalšie informácie o tom, aké obmedzenia platia v tomto prípade, nájdete na [`mem::transmute`][transmute].
    ///
    /// Užívateľ `from_raw` sa musí uistiť, že konkrétna hodnota `T` klesne iba raz.
    ///
    /// Táto funkcia nie je bezpečná, pretože nesprávne použitie môže viesť k nezabezpečeniu pamäte, a to aj v prípade, že k vrátenému `Rc<T>` nikdy nie je prístup.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Prestavte späť na `Rc`, aby ste zabránili úniku.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ďalšie volania na `Rc::from_raw(x_ptr)` by neboli bezpečné z hľadiska pamäte.
    /// }
    ///
    /// // Pamäť sa uvoľnila, keď `x` vyšlo z rozsahu vyššie, takže `x_ptr` sa teraz motá!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Otočte posunutím a nájdite pôvodný RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Vytvorí nový ukazovateľ [`Weak`] na toto pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Uistite sa, že nevytvárame visiaci Slabý
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Získava počet ukazovateľov [`Weak`] na toto pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Získava počet silných ukazovateľov (`Rc`) na toto pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Vráti `true`, ak na toto pridelenie nie sú žiadne ďalšie ukazovatele `Rc` alebo [`Weak`].
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Vráti premenlivý odkaz na danú `Rc`, ak neexistujú žiadne ďalšie ukazovatele `Rc` alebo [`Weak`] na rovnaké pridelenie.
    ///
    ///
    /// V opačnom prípade vráti [`None`], pretože nie je bezpečné mutovať zdieľanú hodnotu.
    ///
    /// Pozri tiež [`make_mut`][make_mut], ktorý bude [`clone`][clone] vnútornú hodnotu, keď existujú ďalšie ukazovatele.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Vráti premenlivú referenciu do danej `Rc` bez akejkoľvek kontroly.
    ///
    /// Pozri tiež [`get_mut`], ktorý je bezpečný a vykonáva príslušné kontroly.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Žiadne ďalšie ukazovatele `Rc` alebo [`Weak`] na rovnaké pridelenie nesmú byť po dobu vrátenej výpožičky dereferencované.
    ///
    /// Toto je triviálny prípad, ak neexistujú žiadne také ukazovatele, napríklad bezprostredne po `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Dávame pozor, aby sme *nevytvorili* referenciu pokrývajúcu polia "count", pretože by to bolo v rozpore s prístupmi k počtu referencií (napr.
        // od `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vráti `true`, ak dva `Rc`s ukazujú na rovnakú alokáciu (v duchu podobnom [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Vytvorí premenlivý odkaz na danú `Rc`.
    ///
    /// Ak existujú ďalšie ukazovatele `Rc` na rovnaké pridelenie, potom `make_mut` zmení [`clone`] vnútornú hodnotu na nové pridelenie, aby sa zabezpečilo jedinečné vlastníctvo.
    /// Toto sa tiež označuje ako klon-na-zápis.
    ///
    /// Ak na toto pridelenie neexistujú žiadne ďalšie ukazovatele `Rc`, potom budú ukazovatele [`Weak`] na toto pridelenie zrušené.
    ///
    /// Pozri tiež [`get_mut`], ktorý skôr ako pri klonovaní zlyhá.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Nebudem nič klonovať
    /// let mut other_data = Rc::clone(&data);    // Nebudú sa klonovať vnútorné údaje
    /// *Rc::make_mut(&mut data) += 1;        // Klony vnútorné dáta
    /// *Rc::make_mut(&mut data) += 1;        // Nebudem nič klonovať
    /// *Rc::make_mut(&mut other_data) *= 2;  // Nebudem nič klonovať
    ///
    /// // Teraz `data` a `other_data` ukazujú na rôzne alokácie.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ukazovatele budú odpojené:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Musím naklonovať dáta, existujú aj ďalšie Rcs.
            // Predbežne pridelte pamäť, aby ste umožnili priamy zápis klonovanej hodnoty.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Stačí len ukradnúť údaje, zostane iba Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Odstrániť implicitné silné a slabé odporúčanie (nie je potrebné vytvárať falošné Slabé tu-vieme, že iné slabé stránky môžu za nás vyčistiť)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Táto nebezpečnosť je v poriadku, pretože máme zaručené, že vrátený ukazovateľ je *iba* ukazovateľ, ktorý bude kedy vrátený do T.
        // Náš referenčný počet je v tomto okamihu zaručene 1 a požadovali sme, aby samotný `Rc<T>` bol `mut`, takže vraciame jediný možný odkaz na pridelenie.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pokus o downcast `Rc<dyn Any>` na konkrétny typ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Pridelí `RcBox<T>` s dostatočným priestorom pre vnútornú hodnotu s možnou veľkosťou, kde má hodnota dané rozloženie.
    ///
    /// Funkcia `mem_to_rcbox` sa volá pomocou údajového ukazovateľa a musí vrátiť späť (potenciálne tučný) ukazovateľ pre `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Vypočítajte rozloženie pomocou rozloženia s danou hodnotou.
        // Predtým bolo rozloženie vypočítané na základe výrazu `&*(ptr as* const RcBox<T>)`, čím sa však vytvoril nesprávne zarovnaný odkaz (pozri #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Priradí `RcBox<T>` s dostatočným priestorom pre vnútornú hodnotu s možnou veľkosťou, kde má hodnota poskytnuté rozloženie, a vráti chybu, ak sa alokácia nepodarí.
    ///
    ///
    /// Funkcia `mem_to_rcbox` sa volá pomocou údajového ukazovateľa a musí vrátiť späť (potenciálne tučný) ukazovateľ pre `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Vypočítajte rozloženie pomocou rozloženia s danou hodnotou.
        // Predtým bolo rozloženie vypočítané na základe výrazu `&*(ptr as* const RcBox<T>)`, čím sa však vytvoril nesprávne zarovnaný odkaz (pozri #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Pridelené pre rozloženie.
        let ptr = allocate(layout)?;

        // Inicializujte RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Priraďuje `RcBox<T>` s dostatočným priestorom pre vnútornú hodnotu bez veľkosti
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Priraďte pre `RcBox<T>` danú hodnotu.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Skopírujte hodnotu ako bajty
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Uvoľnite alokáciu bez toho, aby ste pustili jej obsah
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Pridelí `RcBox<[T]>` s danou dĺžkou.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Skopírujte prvky z rezu do novo prideleného Rc <\[T\]>
    ///
    /// Nebezpečné, pretože volajúci musí buď prevziať vlastníctvo, alebo viazať reťazec `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Vytvorí `Rc<[T]>` z iterátora, o ktorom sa vie, že má určitú veľkosť.
    ///
    /// Správanie nie je definované, ak je veľkosť nesprávna.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Ochranu Panic pri klonovaní T prvkov.
        // V prípade panic sa prvky, ktoré boli zapísané do nového RcBoxu, zahodia a potom sa uvoľní pamäť.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ukazovateľ na prvý prvok
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Všetko jasné.Zabudnite na strážcu, aby neuvoľnil nový RcBox.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Špecializácia trait použitá pre `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Klesne `Rc`.
    ///
    /// To zníži počet silných referencií.
    /// Ak počet silných referencií dosiahne nulu, potom jediné ďalšie referencie (ak existujú) sú [`Weak`], takže `drop` máme vnútornú hodnotu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Netlačí nič
    /// drop(foo2);   // Vytlačí "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // zničiť obsiahnutý objekt
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // teraz, keď sme zničili obsah, odstráňte implicitný ukazovateľ "strong weak".
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Vytvorí klon ukazovateľa `Rc`.
    ///
    /// Týmto sa vytvorí ďalší ukazovateľ na rovnaké pridelenie, čím sa zvýši počet silných referencií.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Vytvorí nový `Rc<T>` s hodnotou `Default` pre `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack povoliť špecializáciu na `Eq`, aj keď `Eq` má metódu.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Túto špecializáciu robíme tu, a nie ako všeobecnejšiu optimalizáciu na `&T`, pretože by to inak zvýšilo náklady na všetky kontroly rovnosti v ref.
/// Predpokladáme, že súbory " Rc` sa používajú na ukladanie veľkých hodnôt, ktoré sa pomaly klonujú, ale tiež ťažko kontrolujú rovnosť, čo spôsobuje, že sa tieto náklady ľahšie vyplatia.
///
/// Je tiež pravdepodobnejšie, že budú mať dva klony `Rc`, ktoré ukazujú na rovnakú hodnotu, ako dva znaky " &T`.
///
/// Môžeme to urobiť, iba keď môže byť `T: Eq` ako `PartialEq` zámerne nereflexívna.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Rovnosť pre dve `RC '.
    ///
    /// Dve hodnoty " Rc` sú rovnaké, ak sú ich vnútorné hodnoty rovnaké, aj keď sú uložené v inom priradení.
    ///
    /// Ak `T` implementuje aj `Eq` (z čoho vyplýva reflexivita rovnosti), dva body " Rc`, ktoré smerujú k rovnakému rozdeleniu, sú vždy rovnaké.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Nerovnosť pre dvoch Rc.
    ///
    /// Dve " Rc` sú nerovnaké, ak sú ich vnútorné hodnoty nerovnaké.
    ///
    /// Ak `T` implementuje aj `Eq` (z čoho vyplýva reflexivita rovnosti), dva body " Rc`, ktoré poukazujú na rovnaké pridelenie, nie sú nikdy nerovnaké.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Čiastočné porovnanie pre dve `RC '.
    ///
    /// Tieto dva sú porovnané volaním `partial_cmp()` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Menej ako porovnanie pre dve Rc.
    ///
    /// Tieto dva sú porovnané volaním `<` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Porovnanie " menšie alebo rovnaké ako pre`dve " RC`.
    ///
    /// Tieto dva sú porovnané volaním `<=` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Lepšie ako porovnanie pre dve " RC`.
    ///
    /// Tieto dva sú porovnané volaním `>` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Porovnanie " väčšie alebo rovné`pre dve " RC`.
    ///
    /// Tieto dva sú porovnané volaním `>=` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Porovnanie pre dve `RC '.
    ///
    /// Tieto dva sú porovnané volaním `cmp()` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Priraďte plátok počítaný podľa referencie a naplňte ho klonovaním položiek `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Priraďte referenčný počítaný rez reťazca a skopírujte do neho `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Priraďte referenčný počítaný rez reťazca a skopírujte do neho `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Presuňte orámovaný objekt na nové, pridelené počítanie referencií.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Priraďte plátok počítaný podľa referencie a presuňte do neho položky `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Nechajte Vec uvoľniť pamäť, ale nezničiť jej obsah
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Vezme každý prvok v `Iterator` a zhromaždí ho do `Rc<[T]>`.
    ///
    /// # Výkonové charakteristiky
    ///
    /// ## Všeobecný prípad
    ///
    /// Všeobecne sa zhromažďovanie do `Rc<[T]>` uskutočňuje tak, že sa najskôr zhromažďuje do `Vec<T>`.Teda pri písaní nasledujúcich textov:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// toto sa správa, akoby sme napísali:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Prvá skupina pridelení sa deje tu.
    ///     .into(); // Tu dôjde k druhému prideleniu pre `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Týmto sa pridelí toľkokrát, koľkokrát je potrebné na zostavenie `Vec<T>`, a potom sa pridelí raz na premenu `Vec<T>` na `Rc<[T]>`.
    ///
    ///
    /// ## Iterátory známej dĺžky
    ///
    /// Keď váš `Iterator` implementuje `TrustedLen` a má presnú veľkosť, pre `Rc<[T]>` sa urobí jedno pridelenie.Napríklad:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Tu sa uskutoční iba jedna alokácia.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Špecializácia trait použitá na zhromažďovanie do `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // To je prípad iterátora `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BEZPEČNOSŤ: Musíme sa ubezpečiť, že iterátor má presnú dĺžku a my máme.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Vrátiť sa k normálnej implementácii.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` je verzia [`Rc`], ktorá obsahuje nenáležitý odkaz na spravovanú alokáciu.Alokácia je prístupná volaním [`upgrade`] na ukazovateli `Weak`, ktorý vráti [" Možnosť`] <<[[Rc`] `<T>>`.
///
/// Pretože referencia `Weak` sa nezapočítava do vlastníctva, nezabráni tomu, aby došlo k zrušeniu hodnoty uloženej v alokácii a samotný `Weak` neposkytuje žiadne záruky týkajúce sa stále existujúcej hodnoty.
/// Môže sa teda vrátiť [`None`], keď [`upgrade`] d.
/// Pamätajte však, že referencia `Weak`*nezabraňuje* v pridelení samotnej alokácie (záložného úložiska).
///
/// Ukazovateľ `Weak` je užitočný na uchovanie dočasného odkazu na alokáciu spravovanú [`Rc`] bez toho, aby zabránil zrušeniu jeho vnútornej hodnoty.
/// Používa sa tiež na zabránenie cyklickým odkazom medzi ukazovateľmi [`Rc`], pretože vzájomné vlastníctvo odkazov by nikdy neumožnilo zrušenie ktoréhokoľvek z [`Rc`].
/// Napríklad strom môže mať silné ukazovatele [`Rc`] z rodičovských uzlov na deti a ukazovatele `Weak` z detí späť na svojich rodičov.
///
/// Typickým spôsobom, ako získať ukazovateľ `Weak`, je volanie [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Toto je `NonNull`, ktorý umožňuje optimalizáciu veľkosti tohto typu v enumoch, ale nemusí to byť nevyhnutne platný ukazovateľ.
    //
    // `Weak::new` nastaví to na `usize::MAX`, aby nebolo potrebné alokovať priestor na halde.
    // To nie je hodnota, ktorú skutočný ukazovateľ bude mať, pretože RcBox má zarovnanie minimálne na 2.
    // Toto je možné iba v prípade `T: Sized`;bezrozmerný model `T` sa nikdy nerozmotáva.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konštruuje nový `Weak<T>` bez vyhradenia akejkoľvek pamäte.
    /// Volanie [`upgrade`] na návratovú hodnotu dáva vždy [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Typ pomocníka, ktorý umožňuje prístup k počtu referencií bez akýchkoľvek tvrdení o údajovom poli.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Vráti hrubý ukazovateľ na objekt `T`, na ktorý ukazuje tento `Weak<T>`.
    ///
    /// Ukazovateľ je platný, iba ak existujú silné referencie.
    /// Ukazovateľ môže byť visiaci, nezarovnaný alebo dokonca [`null`] inak.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Oba ukazujú na ten istý objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Silní ho tu udržujú pri živote, takže k objektu máme stále prístup.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ale už nie.
    /// // Môžeme urobiť weak.as_ptr(), ale prístup k ukazovateľu by viedol k nedefinovanému správaniu.
    /// // assert_eq! ("ahoj", nebezpečné {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ak je ukazovateľ visiaci, vrátime priamo strážnu stráž.
            // Toto nemôže byť platná adresa užitočného zaťaženia, pretože užitočné zaťaženie je minimálne rovnako zarovnané ako RcBox (usize).
            ptr as *const T
        } else {
            // BEZPEČNOSŤ: ak is_dangling vráti hodnotu false, potom je ukazovateľ dereferencable.
            // Užitočné zaťaženie môže v tomto okamihu klesnúť a my musíme zachovať pôvod, preto používajte manipuláciu s hrubým ukazovateľom.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Spotrebuje `Weak<T>` a urobí z neho surový ukazovateľ.
    ///
    /// Týmto sa slabý ukazovateľ prevedie na surový ukazovateľ, pričom sa zachová vlastníctvo jednej slabej referencie (slabý počet sa touto operáciou nezmení).
    /// Môže byť otočený späť do `Weak<T>` s [`from_raw`].
    ///
    /// Pri prístupe k cieľu ukazovateľa platia rovnaké obmedzenia ako pri [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Skonvertuje surový ukazovateľ, ktorý predtým vytvoril [`into_raw`], na `Weak<T>`.
    ///
    /// To možno použiť na bezpečné získanie silnej referencie (volaním [`upgrade`] neskôr) alebo na uvoľnenie slabého počtu poklesnutím `Weak<T>`.
    ///
    /// Berie vlastníctvo jednej slabej referencie (s výnimkou ukazovateľov vytvorených [`new`], pretože tieto nič nevlastnia; metóda na nich stále funguje).
    ///
    /// # Safety
    ///
    /// Ukazovateľ musí pochádzať z [`into_raw`] a musí stále vlastniť svoju potenciálne slabú referenciu.
    ///
    /// V čase volania tohto čísla je povolený maximálny počet 0.
    /// Toto však berie na seba vlastnosť jednej slabej referencie, ktorá je v súčasnosti reprezentovaná ako surový ukazovateľ (slabý počet nie je touto operáciou upravený), a preto musí byť spárovaná s predchádzajúcim volaním na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Odpočítať posledný slabý počet.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Pozri Weak::as_ptr pre kontext, ako je odvodený vstupný ukazovateľ.

        let ptr = if is_dangling(ptr as *mut T) {
            // Toto je visiaci Slabý.
            ptr as *mut RcBox<T>
        } else {
            // Inak máme zaručené, že ukazovateľ pochádzal z nerozmotaného slabého.
            // BEZPEČNOSŤ: data_offset je bezpečné volať, pretože ptr odkazuje na skutočné (potenciálne spadnuté) T.
            let offset = unsafe { data_offset(ptr) };
            // Preto obrátime posun, aby sme získali celý RcBox.
            // BEZPEČNOSŤ: ukazovateľ pochádza zo slabého, takže tento posun je bezpečný.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BEZPEČNOSŤ: teraz sme obnovili pôvodný ukazovateľ Slabý, takže môžeme vytvoriť Slabý.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Pokusy o aktualizáciu ukazovateľa `Weak` na [`Rc`], v prípade úspechu sa oneskorí pokles vnútornej hodnoty.
    ///
    ///
    /// Vráti [`None`], ak medzitým vnútorná hodnota klesla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zničte všetky silné ukazovatele.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Získava počet silných ukazovateľov (`Rc`) smerujúcich k tomuto prideleniu.
    ///
    /// Ak bol `self` vytvorený pomocou [`Weak::new`], vráti hodnotu 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Získava počet ukazovateľov `Weak` smerujúcich k tomuto prideleniu.
    ///
    /// Ak nezostanú žiadne silné ukazovatele, vráti sa nula.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // odčítať implicitné slabé ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Vráti `None`, keď je ukazovateľ visiaci a nie je pridelená žiadna `RcBox`, (tj. Keď bola táto `Weak` vytvorená pomocou `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Dávame pozor, aby sme *nie* vytvorili referenciu pokrývajúcu pole "data", pretože pole môže byť súčasne mutované (napríklad ak je zrušený posledný `Rc`, dátové pole bude presunuté na miesto).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vráti `true`, ak dva argumenty " Slabé` ukazujú na rovnakú alokáciu (podobne ako [`ptr::eq`]), alebo ak obidve neukazujú na žiadnu alokáciu (pretože boli vytvorené pomocou `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Pretože toto porovnáva ukazovatele, znamená to, že `Weak::new()` sa budú rovnať, aj keď neukazujú na žiadne pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Porovnávam `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Spustí ukazovateľ `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Netlačí nič
    /// drop(foo);        // Vytlačí "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // slabý počet začína na 1 a vynuluje sa, iba ak všetky silné ukazovatele zmiznú.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Vytvorí klon ukazovateľa `Weak`, ktorý ukazuje na rovnaké pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Vytvorí novú `Weak<T>` alokuje pamäť pre `T` bez jej inicializácie.
    /// Volanie [`upgrade`] na návratovú hodnotu dáva vždy [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Skontrolovali sme_add, aby sme bezpečne pracovali s mem::forget.Najmä
// ak máte mem::forget Rcs (alebo Weaks), počet ref môže pretiecť a potom môžete uvoľniť alokáciu, kým existujú vynikajúce Rcs (alebo Weaks).
//
// Potratíme, pretože ide o taký zdegenerovaný scenár, že sa nestaráme o to, čo sa stane-žiadny skutočný program by to nikdy nemal zažiť.
//
// To by malo mať zanedbateľnú réžiu, pretože v skutočnosti nemusíte toľko klonovať v Rust vďaka vlastníctvu a sémantike pohybu.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Namiesto poklesu hodnoty chceme prerušiť pretečenie.
        // Počet odkazov nebude nikdy nulový, keď sa to volá;
        // napriek tomu sem vložíme prerušenie, aby sme naznačili LLVM pri inak zmeškanej optimalizácii.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Namiesto poklesu hodnoty chceme prerušiť pretečenie.
        // Počet odkazov nebude nikdy nulový, keď sa to volá;
        // napriek tomu sem vložíme prerušenie, aby sme naznačili LLVM pri inak zmeškanej optimalizácii.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Získajte offset v rámci `RcBox` pre užitočné zaťaženie za ukazovateľom.
///
/// # Safety
///
/// Ukazovateľ musí ukazovať na (a mať platné metadáta) predtým platnej inštancie T, ale T je dovolené zrušiť.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Zarovnajte hodnotu bez veľkosti na koniec RcBoxu.
    // Pretože RcBox je repr(C), bude to vždy posledné pole v pamäti.
    // BEZPEČNOSŤ: keďže jediné možné veľkosti sú iba plátky, objekty trait,
    // a externé typy, požiadavka na vstupnú bezpečnosť je v súčasnosti dostatočná na splnenie požiadaviek align_of_val_raw;toto je detail implementácie jazyka, na ktorý sa mimo std nemožno spoľahnúť.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}