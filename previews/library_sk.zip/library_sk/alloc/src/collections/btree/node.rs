// Toto je pokus o implementáciu podľa ideálu
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Pretože Rust v skutočnosti nemá závislé typy a polymorfnú rekurziu, vystačíme si s mnohými nebezpečenstvami.
//

// Hlavným cieľom tohto modulu je vyhnúť sa zložitosti tým, že sa so stromom bude zaobchádzať ako s generickým (ak je to zvláštne tvarovaným) kontajnerom a nebude sa zaoberať väčšinou invariantov B-stromu.
//
// Tento modul ako taký nezaujíma, či sú položky zoradené, ktoré uzly môžu byť nedostatočne naplnené, alebo dokonca, čo významne obmedzený.Spoliehame sa však na niekoľko invariantov:
//
// - Stromy musia mať uniformu depth/height.To znamená, že každá cesta k listu z daného uzla má presne rovnakú dĺžku.
// - Uzol dĺžky `n` má klávesy `n`, hodnoty `n` a hrany `n + 1`.
//   To znamená, že aj prázdny uzol má aspoň jeden edge.
//   Pre listový uzol "having an edge" znamená iba to, že dokážeme identifikovať polohu v uzle, pretože okraje listov sú prázdne a nepotrebujú žiadnu reprezentáciu údajov.
// Vo vnútornom uzle identifikuje edge pozíciu a obsahuje ukazovateľ na podradený uzol.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Základné znázornenie listových uzlov a časť znázornenia vnútorných uzlov.
struct LeafNode<K, V> {
    /// Chceme byť kovariantní v `K` a `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Index tohto uzla do poľa `edges` nadradeného uzla.
    /// `*node.parent.edges[node.parent_idx]` by malo byť to isté ako `node`.
    /// Toto je zaručené iba pri inicializácii, keď `parent` nemá hodnotu null.
    parent_idx: MaybeUninit<u16>,

    /// Počet kľúčov a hodnôt, ktoré tento uzol uchováva.
    len: u16,

    /// Polia ukladajúce skutočné údaje uzla.
    /// Inicializované a platné sú iba prvé prvky `len` každého poľa.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inicializuje novú `LeafNode` na mieste.
    unsafe fn init(this: *mut Self) {
        // Ako všeobecnú zásadu ponechávame polia neinicializované, ak môžu byť, pretože by to malo byť vo Valgrinde o niečo rýchlejšie a ľahšie sledovateľné.
        //
        unsafe {
            // parent_idx, kľúče a VALS sú všetko MožnáUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Vytvorí novú krabicu `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Základné znázornenie vnútorných uzlov.Rovnako ako v prípade parametra `LeafNode` by tieto mali byť skryté za parametrom`BoxedNode`, aby sa zabránilo zhodeniu neinicializovaných kľúčov a hodnôt.
/// Akýkoľvek ukazovateľ na `InternalNode` je možné priamo vrhnúť na ukazovateľ na podkladovú časť uzla `LeafNode`, čo umožňuje kódu pôsobiť na listové a vnútorné uzly všeobecne bez toho, aby ste museli dokonca kontrolovať, na ktoré z týchto ukazovateľov smeruje.
///
/// Táto vlastnosť je povolená používaním `repr(C)`.
///
#[repr(C)]
// gdb_providers.py používa tento názov typu pre introspekciu.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Ukazovatele na deti tohto uzla.
    /// `len + 1` z nich sa považujú za inicializované a platné, až na to, že blízko konca, zatiaľ čo strom je držaný prostredníctvom výpožičky typu `Dying`, niektoré z týchto ukazovateľov visia.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Vytvorí novú krabicu `InternalNode`.
    ///
    /// # Safety
    /// Invariant vnútorných uzlov je, že majú aspoň jeden inicializovaný a platný edge.
    /// Táto funkcia nenastavuje taký edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Potrebujeme iba inicializovať údaje;okraje sú MožnáUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Spravovaný, nenulový ukazovateľ na uzol.Toto je buď vlastnený ukazovateľ na `LeafNode<K, V>`, alebo vlastnený ukazovateľ na `InternalNode<K, V>`.
///
/// `BoxedNode` však neobsahuje žiadne informácie o tom, ktorý z dvoch typov uzlov v skutočnosti obsahuje, a čiastočne kvôli tomuto nedostatku informácií nie je samostatným typom a nemá žiadny deštruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Koreňový uzol vlastneného stromu.
///
/// Upozorňujeme, že táto jednotka nemá deštruktor a musí sa vyčistiť manuálne.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Vráti nový vlastnený strom s vlastným koreňovým uzlom, ktorý je pôvodne prázdny.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` nesmie byť nula.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Premenlivo si požičiava vlastnený koreňový uzol.
    /// Na rozdiel od `reborrow_mut` je to bezpečné, pretože návratovú hodnotu nemožno použiť na zničenie koreňového adresára a nemôžu existovať ďalšie odkazy na strom.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Trochu premenlivo si požičiava vlastnený koreňový uzol.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nezvratne prechádza na referenciu, ktorá umožňuje prechod a ponúka deštruktívne metódy a ešte niečo iné.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Pridá nový interný uzol s jediným edge smerujúcim na predchádzajúci koreňový uzol, urobí z tohto nového uzla koreňový uzol a vráti ho.
    /// Zvyšuje sa tým výška o 1 a je to opak `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, až na to, že sme práve zabudli, že sme teraz interní:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Odstráni interný koreňový uzol a použije jeho prvé dieťa ako nový koreňový uzol.
    /// Pretože sa má volať iba vtedy, keď má koreňový uzol iba jedno dieťa, nevykoná sa čistenie žiadneho z kľúčov, hodnôt a iných detí.
    ///
    /// Tým sa zníži výška o 1 a je to opak `push_internal_level`.
    ///
    /// Vyžaduje výlučný prístup k objektu `Root`, ale nie ku koreňovému uzlu;
    /// nezruší platnosť ostatných popisovačov alebo odkazov na koreňový uzol.
    ///
    /// Panics, ak neexistuje vnútorná úroveň, tj ak je koreňovým uzlom list.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // BEZPEČNOSŤ: tvrdili sme, že sme interní.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // BEZPEČNOSŤ: exkluzívne sme si požičali `self` a jeho typ výpožičky je exkluzívny.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // BEZPEČNOSŤ: prvý edge je vždy inicializovaný.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` je vždy kovariantný v `K` a `V`, aj keď `BorrowType` je `Mut`.
// Toto je technicky nesprávne, ale nemôže to viesť k akejkoľvek bezpečnosti kvôli internému použitiu `NodeRef`, pretože v prípade `K` a `V` zostávame úplne druhí.
//
// Kedykoľvek však verejný typ zalomí `NodeRef`, uistite sa, že má správnu odchýlku.
//
/// Odkaz na uzol.
///
/// Tento typ má niekoľko parametrov, ktoré riadia jeho činnosť:
/// - `BorrowType`: Fiktívny typ, ktorý popisuje druh výpožičky a nesie celý život.
///    - Keď je toto `Immut<'a>`, `NodeRef` sa správa zhruba ako `&'a Node`.
///    - Ak je toto `ValMut<'a>`, `NodeRef` sa chová zhruba ako `&'a Node`, pokiaľ ide o kľúče a štruktúru stromu, ale umožňuje tiež koexistenciu mnohých premenlivých odkazov na hodnoty v celom strome.
///    - Keď je toto `Mut<'a>`, `NodeRef` funguje zhruba ako `&'a mut Node`, hoci metódy vloženia umožňujú koexistenciu premenlivého ukazovateľa na hodnotu.
///    - Keď je toto `Owned`, `NodeRef` sa správa zhruba ako `Box<Node>`, ale nemá deštruktor a musí byť vyčistený ručne.
///    - Ak je toto `Dying`, `NodeRef` stále funguje zhruba ako `Box<Node>`, ale má metódy na zničenie stromu kúsok po kúsku a bežné metódy, ktoré nie sú označené ako nebezpečné pri volaní, môžu vyvolať UB, ak sú volané nesprávne.
///
///   Pretože ktorýkoľvek `NodeRef` umožňuje navigáciu v strome, `BorrowType` sa efektívne vzťahuje na celý strom, nielen na samotný uzol.
/// - `K` a `V`: Toto sú typy kľúčov a hodnôt uložených v uzloch.
/// - `Type`: Môže to byť `Leaf`, `Internal` alebo `LeafOrInternal`.
/// Keď je to `Leaf`, `NodeRef` ukazuje na listový uzol, keď je to `Internal`, `NodeRef` ukazuje na interný uzol, a keď je to `LeafOrInternal`, `NodeRef` môže smerovať na ktorýkoľvek typ uzla.
///   `Type` keď sa používa mimo `NodeRef`, má názov `NodeType`.
///
/// `BorrowType` aj `NodeType` obmedzujú metódy, ktoré implementujeme, aby sme využili bezpečnosť statického typu.Spôsob, akým môžeme tieto obmedzenia uplatňovať, sú obmedzené:
/// - Pre každý parameter typu môžeme definovať metódu iba všeobecne alebo pre jeden konkrétny typ.
/// Napríklad nemôžeme definovať metódu ako `into_kv` všeobecne pre všetky `BorrowType`, ani raz pre všetky typy, ktoré majú životnosť, pretože chceme, aby vracala referencie `&'a`.
///   Preto ho definujeme iba pre najmenej výkonný typ `Immut<'a>`.
/// - Nemôžeme dostať implicitné nátlak od povedzme `Mut<'a>` do `Immut<'a>`.
///   Preto musíme explicitne zavolať `reborrow` na výkonnejšom `NodeRef`, aby sme dosiahli metódu ako `into_kv`.
///
/// Všetky metódy na `NodeRef`, ktoré vracajú nejaký odkaz, buď:
/// - Vezmite `self` podľa hodnoty a vráťte životnosť, ktorú nesie `BorrowType`.
///   Na vyvolanie takejto metódy niekedy musíme zavolať `reborrow_mut`.
/// - Vezmite `self` ako referenciu a (implicitly) vráti životnosť tejto referencie namiesto životnosti prenášanej `BorrowType`.
/// Týmto spôsobom kontroluje výpožička, že `NodeRef` zostane požičaná, pokiaľ sa použije vrátená referencia.
///   Metódy podporujúce vložku ohýbajú toto pravidlo vrátením surového ukazovateľa, tj referencie bez životnosti.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Počet úrovní, ktoré sú od seba vzdialené od uzla, a úroveň listov, konštanta od uzla, ktorú nedokáže `Type` celkom opísať, a ktorú samotný uzol neukladá.
    /// Potrebujeme iba uložiť výšku koreňového uzla a od neho odvodiť výšku každého druhého uzla.
    /// Musí byť nula, ak `Type` je `Leaf` a nenulová, ak `Type` je `Internal`.
    ///
    ///
    height: usize,
    /// Ukazovateľ na list alebo vnútorný uzol.
    /// Definícia `InternalNode` zaisťuje, že ukazovateľ je platný v oboch smeroch.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Rozbaľte odkaz na uzol, ktorý bol zabalený ako `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Vystavuje údaje interného uzla.
    ///
    /// Vráti pôvodný súbor ptr, aby nedošlo k zneplatneniu ďalších odkazov na tento uzol.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // BEZPEČNOSŤ: typ statického uzla je `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Požičiava si exkluzívny prístup k údajom interného uzla.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Nájde dĺžku uzla.Toto je počet kľúčov alebo hodnôt.
    /// Počet hrán je `len() + 1`.
    /// Všimnite si, že napriek bezpečnosti môže mať volanie tejto funkcie vedľajší efekt zneplatnenia premenlivých odkazov, ktoré vytvoril nebezpečný kód.
    ///
    pub fn len(&self) -> usize {
        // Rozhodujúce je, že tu vstupujeme iba do poľa `len`.
        // Ak je typ BorrowType marker::ValMut, môžu existovať vynikajúce premenlivé odkazy na hodnoty, ktoré nesmieme zneplatniť.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Vráti počet úrovní, ktoré sú od seba vzdialené od uzla a listov.
    /// Nulová výška znamená, že uzol je samotný list.
    /// Ak zobrazujete stromy s koreňom navrchu, číslo hovorí, v ktorej nadmorskej výške sa uzol objaví.
    /// Ak si predstavujete stromy s listami na vrchu, číslo hovorí, ako vysoko sa strom rozprestiera nad uzlom.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Dočasne vyradí ďalší, nemenný odkaz na ten istý uzol.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Vystavuje listovú časť ktoréhokoľvek listu alebo vnútorného uzla.
    ///
    /// Vráti pôvodný súbor ptr, aby nedošlo k zneplatneniu ďalších odkazov na tento uzol.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Uzol musí byť platný aspoň pre časť LeafNode.
        // Toto nie je odkaz v type NodeRef, pretože nevieme, či by mal byť jedinečný alebo zdieľaný.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Nájde rodič aktuálneho uzla.
    /// Vráti `Ok(handle)`, ak má aktuálny uzol v skutočnosti rodiča, kde `handle` ukazuje na edge rodiča, ktorý ukazuje na aktuálny uzol.
    ///
    /// Vráti `Err(self)`, ak aktuálny uzol nemá rodiča, vráti pôvodné `NodeRef`.
    ///
    /// Názov metódy predpokladá, že zobrazujete stromy s koreňovým uzlom navrchu.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` by po úspechu nemali robiť nič.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Musíme použiť surové ukazovatele na uzly, pretože ak je BorrowType marker::ValMut, môžu existovať vynikajúce premenlivé odkazy na hodnoty, ktoré nesmieme zneplatniť.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Upozorňujeme, že položka `self` nesmie byť prázdna.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Upozorňujeme, že položka `self` nesmie byť prázdna.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Vystavuje listovú časť ktoréhokoľvek listu alebo vnútorného uzla v nemennom strome.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // BEZPEČNOSŤ: do tohto stromu nemôžu byť žiadne zmeniteľné odkazy požičané ako `Immut`.
        unsafe { &*ptr }
    }

    /// Požičia si pohľad na kľúče uložené v uzle.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Podobne ako v prípade `ascend`, získa odkaz na nadradený uzol uzla, ale v rámci procesu tiež pridelí aktuálny uzol.
    /// To nie je bezpečné, pretože aktuálny uzol bude stále prístupný aj napriek jeho prideleniu.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nebezpečne tvrdí kompilátorovi statické informácie, že tento uzol je `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Nebezpečne tvrdí kompilátorovi statické informácie, že tento uzol je `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Dočasne vyradí ďalší, premenlivý odkaz na ten istý uzol.Pozor, táto metóda je veľmi nebezpečná, a to dvojnásobne, pretože sa nemusí okamžite javiť ako nebezpečná.
    ///
    /// Pretože premenlivé ukazovatele sa môžu pohybovať kdekoľvek v strome, vrátený ukazovateľ sa dá ľahko použiť na to, aby bol pôvodný ukazovateľ visiaci, mimo medzí alebo neplatný podľa hromadných pravidiel výpožičky.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) zvážte pridanie ešte jedného parametra typu do `NodeRef`, ktorý obmedzuje použitie metód navigácie na opätovne vypustených ukazovateľoch a bráni tejto bezpečnosti.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Požičiava si exkluzívny prístup k listovej časti ktoréhokoľvek listu alebo vnútorného uzla.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // BEZPEČNOSŤ: máme exkluzívny prístup k celému uzlu.
        unsafe { &mut *ptr }
    }

    /// Ponúka exkluzívny prístup k listovej časti ľubovoľného listu alebo vnútorného uzla.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // BEZPEČNOSŤ: máme exkluzívny prístup k celému uzlu.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Požičiava si exkluzívny prístup k prvku úložného priestoru kľúčov.
    ///
    /// # Safety
    /// `index` je v medziach 0..KAPACITA
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // BEZPEČNOSŤ: volajúci nebude môcť sám volať ďalšie metódy
        // až kým neodpadne referencia kľúčového rezu, pretože máme jedinečný prístup po celú dobu výpožičky.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Požičiava si exkluzívny prístup k prvku alebo výrezu oblasti na ukladanie hodnôt uzla.
    ///
    /// # Safety
    /// `index` je v medziach 0..KAPACITA
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // BEZPEČNOSŤ: volajúci nebude môcť sám volať ďalšie metódy
        // až kým neodpadne referencia hodnotového rezu, pretože máme jedinečný prístup po celú dobu výpožičky.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Požičiava si výlučný prístup k prvku alebo výrezu úložnej oblasti uzla pre obsah edge.
    ///
    /// # Safety
    /// `index` je v medziach 0..KAPACITA + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // BEZPEČNOSŤ: volajúci nebude môcť sám volať ďalšie metódy
        // kým nezruší odkaz na rez edge, pretože máme jedinečný prístup po celú dobu výpožičky.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Uzol má viac ako `idx` inicializovaných prvkov.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Vytvoríme iba odkaz na jeden prvok, ktorý nás zaujíma, aby sme sa vyhli aliasingu s vynikajúcimi odkazmi na ďalšie prvky, najmä tie, ktoré sa vrátili volajúcemu v predchádzajúcich iteráciách.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Kvôli problému Rust #74679 musíme vynútiť použitie ukazovateľov na inú veľkosť.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Požičiava si exkluzívny prístup k dĺžke uzla.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Nastaví odkaz uzla na jeho nadradený edge bez toho, aby zneplatnil ďalšie odkazy na uzol.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Vymaže koreňový odkaz na jeho nadradený edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Pridá pár kľúč-hodnota na koniec uzla.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Každá položka vrátená `range` je platným indexom edge pre uzol.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Pridá pár kľúč-hodnota a edge na prechod napravo od tohto páru na koniec uzla.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Skontroluje, či je uzol uzlom `Internal` alebo uzlom `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Odkaz na konkrétny pár kľúč-hodnota alebo edge v uzle.
/// Parameter `Node` musí byť `NodeRef`, zatiaľ čo `Type` môže byť buď `KV` (označujúci kľuč na páre kľúč-hodnota) alebo `Edge` (označujúci kľučku na edge).
///
/// Upozorňujeme, že aj uzly `Leaf` môžu mať popisovače `Edge`.
/// Namiesto toho, aby predstavovali ukazovateľ na podriadený uzol, tieto predstavujú priestory, kde by sa podradené ukazovatele dostali medzi páry kľúč-hodnota.
/// Napríklad v uzle s dĺžkou 2 by boli 3 možné miesta edge, jedno vľavo od uzla, jedno medzi dvoma pármi a jedno vpravo od uzla.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Nepotrebujeme úplnú všeobecnosť `#[derive(Clone)]`, pretože `Node` bude " Clone` možné iba vtedy, keď bude nemennou referenciou, a teda `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Načíta uzol, ktorý obsahuje pár edge alebo pár kľúč-hodnota, na ktorý tento popisovač smeruje.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Vráti pozíciu tejto rukoväte v uzle.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Vytvorí nový popisovač pre pár kľúč-hodnota v `node`.
    /// Nebezpečný, pretože volajúci musí zabezpečiť, aby `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Môže to byť verejná implementácia PartialEq, ale používa sa iba v tomto module.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Dočasne vytiahne ďalšiu nemennú rukoväť na rovnakom mieste.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Nemôžeme použiť Handle::new_kv alebo Handle::new_edge, pretože nepoznáme náš typ
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Nebezpečne tvrdí kompilátorovi statické informácie, že uzol rukoväte je `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Dočasne vytiahne inú, premenlivú rukoväť na rovnakom mieste.
    /// Pozor, táto metóda je veľmi nebezpečná, a to dvojnásobne, pretože sa nemusí okamžite javiť ako nebezpečná.
    ///
    ///
    /// Podrobnosti nájdete v časti `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Nemôžeme použiť Handle::new_kv alebo Handle::new_edge, pretože nepoznáme náš typ
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Vytvorí nový popisovač pre edge v `node`.
    /// Nebezpečný, pretože volajúci musí zabezpečiť, aby `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Ak vezmeme do úvahy index edge, ktorý chceme vložiť do uzla naplneného na kapacitu, vypočítame rozumný index KV deleného bodu a kde vykonáme vloženie.
///
/// Cieľom bodu rozdelenia je, aby jeho kľúč a hodnota skončili v nadradenom uzle;
/// klávesy, hodnoty a hrany naľavo od bodu rozdelenia sa stanú ľavým potomkom;
/// kľúče, hodnoty a hrany napravo od bodu rozdelenia sa stanú správnymi potomkami.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust vydanie #74834 sa pokúša vysvetliť tieto symetrické pravidlá.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Vloží nový pár kľúč-hodnota medzi páry kľúč-hodnota vpravo a vľavo od tohto edge.
    /// Táto metóda predpokladá, že v uzle je dostatok miesta na to, aby sa nový pár zmestil.
    ///
    /// Vrátený ukazovateľ ukazuje na vloženú hodnotu.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Vloží nový pár kľúč-hodnota medzi páry kľúč-hodnota vpravo a vľavo od tohto edge.
    /// Táto metóda rozdelí uzol, ak nie je dostatok miesta.
    ///
    /// Vrátený ukazovateľ ukazuje na vloženú hodnotu.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Opravuje nadradený ukazovateľ a index v podradenom uzle, na ktorý tento edge odkazuje.
    /// Je to užitočné, keď sa zmenilo usporiadanie hrán,
    fn correct_parent_link(self) {
        // Vytvorte spätný ukazovateľ bez zneplatnenia ďalších odkazov na uzol.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Vloží nový pár kľúč-hodnota a edge, ktorý pôjde napravo od tohto nového páru medzi tento edge a pár kľúč-hodnota napravo od tohto edge.
    /// Táto metóda predpokladá, že v uzle je dostatok miesta na to, aby sa nový pár zmestil.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Vloží nový pár kľúč-hodnota a edge, ktorý pôjde napravo od tohto nového páru medzi tento edge a pár kľúč-hodnota napravo od tohto edge.
    /// Táto metóda rozdelí uzol, ak nie je dostatok miesta.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Vloží nový pár kľúč-hodnota medzi páry kľúč-hodnota vpravo a vľavo od tohto edge.
    /// Táto metóda rozdelí uzol, ak nie je dostatok miesta, a pokúsi sa vložiť oddelenú časť do nadradeného uzla rekurzívne, kým sa nedosiahne koreň.
    ///
    ///
    /// Ak je vráteným výsledkom `Fit`, uzlom jeho manipulácie môže byť tento uzol edge alebo predok.
    /// Ak je vráteným výsledkom `Split`, koreňovým uzlom bude pole `left`.
    /// Vrátený ukazovateľ ukazuje na vloženú hodnotu.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Nájde uzol, na ktorý ukazuje tento edge.
    ///
    /// Názov metódy predpokladá, že zobrazujete stromy s koreňovým uzlom navrchu.
    ///
    /// `edge.descend().ascend().unwrap()` a `node.ascend().unwrap().descend()` by po úspechu nemali robiť nič.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Musíme použiť surové ukazovatele na uzly, pretože ak je BorrowType marker::ValMut, môžu existovať vynikajúce premenlivé odkazy na hodnoty, ktoré nesmieme zneplatniť.
        // S prístupom do poľa výšky sa nemusíte báť, pretože táto hodnota je skopírovaná.
        // Dajte pozor, akonáhle je dereferencovaný ukazovateľ uzla, pristupujeme k okrajovému poľu s odkazom (Rust problém #73987) a zneplatňujeme všetky ďalšie odkazy na alebo vo vnútri poľa, pokiaľ by nejaké boli.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Nemôžeme volať samostatné metódy kľúča a hodnoty, pretože volanie druhej zneplatní referenciu vrátenú prvou.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Vymeňte kľúč a hodnotu, na ktorú odkazuje KV handle.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Pomáha implementáciám `split` pre konkrétny `NodeType` tým, že sa stará o listové údaje.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Rozdelí podkladový uzol na tri časti:
    ///
    /// - Uzol je skrátený tak, aby obsahoval iba páry kľúč-hodnota vľavo od tohto popisovača.
    /// - Kľúč a hodnota, na ktoré tento popisovač odkazuje, sa extrahujú.
    /// - Všetky páry kľúč-hodnota napravo od tohto popisovača sa vložia do novo prideleného uzla.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Odstráni pár kľúč-hodnota, na ktorý odkazuje táto rukoväť, a vráti ho spolu so edge, do ktorého sa pár kľúč-hodnota zrútil.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Rozdelí podkladový uzol na tri časti:
    ///
    /// - Uzol je skrátený, aby obsahoval iba páry okrajov a párov kľúč-hodnota vľavo od tohto popisovača.
    /// - Kľúč a hodnota, na ktoré tento popisovač odkazuje, sa extrahujú.
    /// - Všetky okraje a páry kľúč-hodnota napravo od tohto popisovača sú vložené do novo prideleného uzla.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Predstavuje reláciu na vyhodnotenie a vykonanie operácie vyváženia okolo interného páru kľúč-hodnota.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Vyberie vyvažovací kontext zahŕňajúci uzol ako dieťa, teda medzi KV okamžite vľavo alebo vpravo v nadradenom uzle.
    /// Vráti `Err`, ak nie je žiadny rodič.
    /// Panics, ak je rodič prázdny.
    ///
    /// Preferuje ľavú stranu, aby bola optimálna, ak je daný uzol akosi poddimenzovaný, to znamená iba to, že má menej prvkov ako ľavý súrodenec a než pravý súrodenec, ak existujú.
    /// V takom prípade je zlúčenie s ľavým súrodencom rýchlejšie, pretože stačí presunúť iba N prvkov uzla, namiesto toho, aby sme ich posunuli doprava a viac ako N prvkov vpredu.
    /// Kradnutie od ľavého súrodenca je tiež zvyčajne rýchlejšie, pretože stačí posunúť N prvkov uzla doprava, namiesto toho, aby sme posunuli aspoň N prvkov súrodenca doľava.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Vráti, či je zlúčenie možné, tj. Či je v uzle dostatok priestoru na kombináciu centrálneho KV s oboma susednými podradenými uzlami.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Vykoná zlúčenie a nechá uzávierku rozhodnúť, čo sa vráti.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // BEZPEČNOSŤ: výška zlučovaných uzlov je jedna pod výškou
                // uzla tohto edge, teda nad nulou, takže sú interné.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Zlúči dvojicu kľúč-hodnota rodiča a obidva susedné podriadené uzly do ľavého podriadeného uzla a vráti zmenšený nadradený uzol.
    ///
    ///
    /// Panics, pokiaľ nebudeme `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Zlúči dvojicu kľúč-hodnota rodiča a obidva susedné podriadené uzly do ľavého podriadeného uzla a vráti tento podradený uzol.
    ///
    ///
    /// Panics, pokiaľ nebudeme `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Zlúči dvojicu kľúč-hodnota rodiča a obidva susedné podriadené uzly do ľavého podriadeného uzla a vráti popisovač edge v tomto podradenom uzle, kde skončilo sledované podradené uzol edge,
    ///
    ///
    /// Panics, pokiaľ nebudeme `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Odstráni pár kľúč-hodnota z ľavého dieťaťa a umiestni ho do úložiska kľúč-hodnota rodiča, zatiaľ čo starý pár kľúč-hodnota zatlačí do pravého dieťaťa.
    ///
    /// Vráti rukoväť na edge u pravého dieťaťa zodpovedajúcu miestu, kde skončil pôvodný edge určený `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Odstráni pár kľúč-hodnota z pravého dieťaťa a umiestni ho do úložiska kľúč-hodnota rodiča, zatiaľ čo starý pár kľúč-hodnota tlačí na ľavé dieťa.
    ///
    /// Vráti rukoväť na edge v ľavom potomku zadanom `track_left_edge_idx`, ktorý sa nepohol.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Toto kradne podobne ako `steal_left`, ale kradne viac prvkov naraz.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Zaistite, aby sme mohli bezpečne kradnúť.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Presunúť údaje listu.
            {
                // Vytvorte miesto pre ukradnuté prvky správnemu dieťaťu.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Presuňte prvky z ľavého dieťaťa do pravého.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Presuňte dvojicu najviac ukradnutej rodiča k rodičovi.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Presuňte pár kľúč-hodnota rodiča k správnemu dieťaťu.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Vytvorte miesto pre ukradnuté hrany.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Ukradnite okraje.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Symetrický klon `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Zaistite, aby sme mohli bezpečne kradnúť.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Presunúť údaje listu.
            {
                // Presuňte najviac ukradnutý pár k rodičovi.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Presuňte pár kľúč-hodnota rodiča k ľavému dieťaťu.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Presuňte prvky z pravého dieťaťa do ľavého.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Vyplňte medzeru tam, kde boli kedysi ukradnuté prvky.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ukradnite okraje.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Vyplňte medzeru tam, kde bývali ukradnuté hrany.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Odstráni všetky statické informácie, ktoré tvrdia, že tento uzol je uzlom `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Odstráni všetky statické informácie, ktoré tvrdia, že tento uzol je uzlom `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Skontroluje, či je podkladovým uzlom uzol `Internal` alebo uzol `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Presunúť príponu za `self` z jedného uzla do druhého.`right` musí byť prázdny.
    /// Prvý model edge modelu `right` zostáva nezmenený.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Výsledok vloženia, keď sa uzol potreboval rozšíriť nad svoju kapacitu.
pub struct SplitResult<'a, K, V, NodeType> {
    // Zmenený uzol v existujúcom strome s prvkami a hranami, ktoré patria naľavo od `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Niektoré kľúče a hodnoty sa oddelia, vložia sa inde.
    pub kv: (K, V),
    // Vlastnený, nepripojený, nový uzol s prvkami a hranami, ktoré patria napravo od `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Či odkazy na uzly tohto typu výpožičky umožňujú prechod na ďalšie uzly v strome.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal nie je potrebný, deje sa to pomocou výsledku `borrow_mut`.
        // Zakázaním prechodu a vytváraním iba nových odkazov na korene vieme, že každý odkaz typu `Owned` je na koreňový uzol.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Vloží hodnotu do rezu inicializovaných prvkov, za ktorým nasleduje jeden neinicializovaný prvok.
///
/// # Safety
/// Plátok má viac ako `idx` prvkov.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Odstráni a vráti hodnotu z rezu všetkých inicializovaných prvkov a zanechá za sebou jeden koncový neinicializovaný prvok.
///
///
/// # Safety
/// Plátok má viac ako `idx` prvkov.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Posunie prvky v polohách rezu `distance` doľava.
///
/// # Safety
/// Plátok má najmenej `distance` prvkov.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Posúva prvky v polohách rezu `distance` doprava.
///
/// # Safety
/// Plátok má najmenej `distance` prvkov.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Presunie všetky hodnoty z výseku inicializovaných prvkov na výsek neinicializovaných prvkov a zanechá za sebou `src` ako všetky neinicializované.
///
/// Funguje ako `dst.copy_from_slice(src)`, ale nevyžaduje, aby `T` bol `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;