use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Dočasne vyberie ďalší, nemenný ekvivalent rovnakého rozsahu.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Nájde zreteľné okraje listov ohraničujúce zadaný rozsah v strome.
    /// Vráti buď dvojicu rôznych úchytov do rovnakého stromu, alebo dvojicu prázdnych možností.
    ///
    /// # Safety
    ///
    /// Pokiaľ `BorrowType` nie je `Immut`, nepoužívajte duplicitné rukoväte na to, aby ste dvakrát navštívili ten istý KV.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Ekvivalent k `(root1.first_leaf_edge(), root2.last_leaf_edge())`, ale efektívnejší.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Nájde dvojicu okrajov listov ohraničujúcu konkrétny rozsah na strome.
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča, ako je strom v `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // BEZPEČNOSŤ: náš typ pôžičky je nemenný.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Nájde dvojicu okrajov listov ohraničujúcu celý strom.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Rozdelí jedinečný odkaz na pár okrajov listov ohraničujúcich zadaný rozsah.
    /// Výsledkom sú nejedinečné odkazy umožňujúce mutáciu (some), ktoré sa musia používať opatrne.
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča, ako je strom v `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Nepoužívajte duplicitné úchyty na to, aby ste dvakrát navštívili ten istý KV.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Rozdelí jedinečný odkaz na pár okrajov listov ohraničujúcich celý rozsah stromu.
    /// Výsledkom sú nejedinečné odkazy umožňujúce mutáciu (iba hodnôt), preto ich treba používať opatrne.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Tu duplikujeme koreňový NodeRef-nikdy nenavštívime dvakrát to isté KV a nikdy neskončíme s prekrývajúcimi sa hodnotovými referenciami.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Rozdelí jedinečný odkaz na pár okrajov listov ohraničujúcich celý rozsah stromu.
    /// Výsledkom sú nejedinečné odkazy umožňujúce masívne deštruktívne mutácie, preto ich treba používať s maximálnou opatrnosťou.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Duplikujeme tu root NodeRef-nikdy k nemu nepristúpime spôsobom, ktorý prekrýva odkazy získané z root.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Vzhľadom na kľučku listu edge vráti [`Result::Ok`] s rukoväťou do susedného KV na pravej strane, ktorý je buď v rovnakom uzle listu, alebo v uzle predka.
    ///
    /// Ak je list edge posledný na strome, vráti [`Result::Err`] s koreňovým uzlom.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Vzhľadom na kľučku listu edge vráti [`Result::Ok`] s rukoväťou do susedného KV na ľavej strane, ktorý je buď v rovnakom uzle listu, alebo v uzle predka.
    ///
    /// Ak je list edge prvý na strome, vráti [`Result::Err`] s koreňovým uzlom.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Vzhľadom na interný popisovač edge vráti [`Result::Ok`] s popisovačom do susedného KV na pravej strane, ktorý je buď v rovnakom vnútornom uzle, alebo v uzle predka.
    ///
    /// Ak je interný edge posledný v strome, vráti [`Result::Err`] s koreňovým uzlom.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Keď dáte rukoväť listu edge do umierajúceho stromu, vráti nasledujúci list edge na pravej strane a pár kľúč-hodnota medzi nimi, ktorý je buď v rovnakom uzle listu, v uzle predka alebo neexistuje.
    ///
    ///
    /// Táto metóda tiež uvoľní všetky node(s), ktoré dosiahne na konci.
    /// To znamená, že ak už viac párov kľúč-hodnota neexistuje, bude pridelený celý zvyšok stromu a už niet čo vrátiť.
    ///
    /// # Safety
    /// Daný edge nesmie byť predtým vrátený náprotivkom `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Keď dáte rukoväť listu edge do umierajúceho stromu, vráti nasledujúci list edge na ľavej strane a pár kľúč-hodnota medzi nimi, ktorý je buď v rovnakom uzle listu, v uzle predka, alebo neexistuje.
    ///
    ///
    /// Táto metóda tiež uvoľní všetky node(s), ktoré dosiahne na konci.
    /// To znamená, že ak už viac párov kľúč-hodnota neexistuje, bude pridelený celý zvyšok stromu a už niet čo vrátiť.
    ///
    /// # Safety
    /// Daný edge nesmie byť predtým vrátený náprotivkom `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Oddeľuje hromadu uzlov od listu až po koreň.
    /// To je jediný spôsob, ako uvoľniť zvyšok stromu po tom, čo `deallocating_next` a `deallocating_next_back` obhrýzajú obe strany stromu a zasiahli rovnaký edge.
    /// Pretože sa má volať iba vtedy, keď sa vrátia všetky kľúče a hodnoty, nevykoná sa žiadne vyčistenie žiadneho z kľúčov alebo hodnôt.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Presunie kľučku listu edge na ďalší list edge a vráti odkazy na kľúč a hodnotu medzi nimi.
    ///
    ///
    /// # Safety
    /// V danom smere musí byť ďalší KV.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Presunie kľučku listu edge na predchádzajúci list edge a vráti odkazy na kľúč a hodnotu medzi nimi.
    ///
    ///
    /// # Safety
    /// V danom smere musí byť ďalší KV.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Presunie kľučku listu edge na ďalší list edge a vráti odkazy na kľúč a hodnotu medzi nimi.
    ///
    ///
    /// # Safety
    /// V danom smere musí byť ďalší KV.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Posledný krok je podľa referenčných kritérií rýchlejší.
        kv.into_kv_valmut()
    }

    /// Presunie kľučku listu edge na predchádzajúci list a vráti odkazy na kľúč a hodnotu medzi nimi.
    ///
    ///
    /// # Safety
    /// V danom smere musí byť ďalší KV.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Posledný krok je podľa referenčných kritérií rýchlejší.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Presunie rukoväť listu edge na ďalší list edge a vráti medzi nimi kľúč a hodnotu, čím uvoľní akýkoľvek uzol, ktorý zostal po sebe, zatiaľ čo zodpovedajúci edge zostane visieť v jeho nadradenom uzle.
    ///
    /// # Safety
    /// - V danom smere musí byť ďalší KV.
    /// - Toto KV predtým náprotivok `next_back_unchecked` nevrátil na nijakej kópii rukovätí použitých na prekonanie stromu.
    ///
    /// Jediným bezpečným spôsobom, ako pokračovať v aktualizovanej rukoväti, je porovnať ju, zrušiť, zavolať túto metódu znova podľa jej bezpečnostných podmienok alebo zavolať náprotivok `next_back_unchecked` podľa jej bezpečnostných podmienok.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Presunie rukoväť listu edge na predchádzajúci list edge a vráti medzi nimi kľúč a hodnotu, pričom uvoľní akýkoľvek uzol, ktorý zostal po sebe, zatiaľ čo zodpovedajúci edge zostane visieť v jeho nadradenom uzle.
    ///
    /// # Safety
    /// - V danom smere musí byť ďalší KV.
    /// - Tento list edge predtým náprotivok `next_unchecked` nevrátil na nijakej kópii rukovätí použitých na prechádzanie stromom.
    ///
    /// Jediným bezpečným spôsobom, ako pokračovať v aktualizovanej rukoväti, je porovnať ju, zrušiť, zavolať túto metódu znova podľa jej bezpečnostných podmienok alebo zavolať náprotivok `next_unchecked` podľa jej bezpečnostných podmienok.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vráti list edge vľavo najviac v uzle alebo pod ním, inými slovami edge, ktorý potrebujete ako prvý pri navigácii dopredu (alebo posledný pri navigácii dozadu).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Vráti pravý list edge v uzle alebo pod ním, inými slovami edge, ktorý potrebujete ako posledný pri navigácii dopredu (alebo prvý pri navigácii dozadu).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Navštívi listové uzly a interné KV v poradí vzostupných kľúčov a tiež navštevuje interné uzly ako celok v hĺbke prvého rádu, čo znamená, že interné uzly predchádzajú ich jednotlivým KV a ich podriadeným uzlom.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Vypočíta počet prvkov v (pod) strome.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Vráti list edge najbližšie k KV pre navigáciu vpred.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Vráti list edge najbližšie k KV pre spätnú navigáciu.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}