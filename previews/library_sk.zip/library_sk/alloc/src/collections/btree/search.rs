use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Inkluzívum, ktoré treba hľadať, rovnako ako `Bound::Included(T)`.
    Included(T),
    /// Exkluzívne, čo treba hľadať, rovnako ako `Bound::Excluded(T)`.
    Excluded(T),
    /// Bezpodmienečná inkluzívna väzba, rovnako ako `Bound::Unbounded`.
    AllIncluded,
    /// Bezpodmienečná výlučná väzba.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vyhľadá daný kľúč v (pod) strome vedenom uzlom rekurzívne.
    /// Vráti `Found` s rukoväťou zodpovedajúceho KV, ak existuje.
    /// V opačnom prípade vráti `GoDown` s rukoväťou krídla edge, kam patrí kľúč.
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča, ako je strom v `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Zostupuje do najbližšieho uzla, kde edge zodpovedajúci dolnej hranici rozsahu sa líši od edge zodpovedajúcej hornej hranici, tj. Najbližší uzol, ktorý má v rozsahu najmenej jeden kľúč.
    ///
    ///
    /// Ak sa nájde, vráti `Ok` s týmto uzlom, dvojica indexov edge v ňom ohraničujúcich rozsah a zodpovedajúca dvojica hraníc pre pokračovanie vyhľadávania v podradených uzloch, ak je uzol interný.
    ///
    /// Ak sa nenájde, vráti `Err` s listom edge zodpovedajúcim celému rozsahu.
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Je potrebné sa vyhnúť vloženiu týchto premenných.
        // Predpokladáme, že hranice hlásené `range` zostávajú rovnaké, ale protikladná implementácia by sa medzi hovormi (#81138) mohla zmeniť.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Nájde edge v uzle ohraničujúcom dolnú hranicu rozsahu.
    /// Vráti aj dolnú hranicu použitú na pokračovanie vyhľadávania v zodpovedajúcom podradenom uzle, ak je `self` interným uzlom.
    ///
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon `find_lower_bound_edge` pre hornú hranicu.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Vyhľadá daný kľúč v uzle bez rekurzie.
    /// Vráti `Found` s rukoväťou zodpovedajúceho KV, ak existuje.
    /// V opačnom prípade vráti `GoDown` s rukoväťou edge, kde je možné nájsť kľúč (ak je uzol interný) alebo kde je možné kľúč vložiť.
    ///
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča, ako je strom v `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Vráti index KV v uzle, v ktorom kľúč (alebo ekvivalent) existuje, alebo index edge, kam kľúč patrí.
    ///
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča, ako je strom v `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Nájde index edge v uzle ohraničujúcom dolnú hranicu rozsahu.
    /// Vráti aj dolnú hranicu použitú na pokračovanie vyhľadávania v zodpovedajúcom podradenom uzle, ak je `self` interným uzlom.
    ///
    ///
    /// Výsledok je zmysluplný, iba ak je strom zoradený podľa kľúča.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon `find_lower_bound_index` pre hornú hranicu.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}