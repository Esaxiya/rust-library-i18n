use core::intrinsics;
use core::mem;
use core::ptr;

/// Toto nahradzuje hodnotu za jedinečným odkazom `v` volaním príslušnej funkcie.
///
///
/// Ak sa v uzávere `change` vyskytne panic, celý proces sa preruší.
#[allow(dead_code)] // ponechajte ako ilustráciu a na použitie future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Týmto sa nahradí hodnota za jedinečným odkazom `v` vyvolaním príslušnej funkcie a vráti sa výsledok získaný týmto spôsobom.
///
///
/// Ak sa v uzávere `change` vyskytne panic, celý proces sa preruší.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}