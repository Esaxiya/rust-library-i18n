use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Pripojí všetky páry kľúč-hodnota zo spojenia dvoch vzostupných iterátorov, pričom počas toho bude zvyšovať premennú `length`.Toto druhé umožňuje volajúcemu vyhnúť sa úniku, keď obsluha kvapky spanikári.
    ///
    /// Ak oba iterátory produkujú rovnaký kľúč, táto metóda odhodí pár z ľavého iterátora a pripojí pár z pravého iterátora.
    ///
    /// Ak chcete, aby strom skončil v striktne vzostupnom poradí, podobne ako v prípade `BTreeMap`, oba iterátory by mali produkovať kľúče v striktne vzostupnom poradí, pričom každý z nich by mal byť väčší ako všetky kľúče v strome, vrátane akýchkoľvek kľúčov, ktoré sa už v strome nachádzajú.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Pripravujeme sa na zlúčenie `left` a `right` do triedenej postupnosti v lineárnom čase.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Medzitým v lineárnom čase zostavíme strom zo zoradenej postupnosti.
        self.bulk_push(iter, length)
    }

    /// Posunie všetky páry kľúč-hodnota na koniec stromu a pozdĺž toho zvýši premennú `length`.
    /// Posledné menované uľahčuje volajúcemu vyhnúť sa úniku, keď iterátor spanikári.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterujte cez všetky páry kľúč-hodnota a tlačte ich do uzlov na správnej úrovni.
        for (key, value) in iter {
            // Pokúste sa vložiť pár kľúč-hodnota do aktuálneho uzla listu.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Nezostáva miesto, choďte hore a zatlačte tam.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Našiel sa uzol s medzerou vľavo, zatlačte sem.
                                open_node = parent;
                                break;
                            } else {
                                // Choď znova hore.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Sme na vrchole, vytvoríme nový koreňový uzol a zatlačíme tam.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Push pár kľúč-hodnota a nový pravý podstrom.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Znova choďte dole k listu úplne vpravo.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Zvyšujte dĺžku každej iterácie, aby ste sa ubezpečili, že mapa odhodí pripojené prvky, aj keď panikár iterátora postupuje ďalej.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iterátor na zlúčenie dvoch triedených sekvencií do jednej
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Ak sú dva kľúče rovnaké, vráti pár kľúč-hodnota zo správneho zdroja.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}