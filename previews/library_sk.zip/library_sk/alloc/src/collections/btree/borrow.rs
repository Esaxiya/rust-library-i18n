use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modeluje reborrow nejakej jedinečnej referencie, keď viete, že reborrow a všetci jej potomkovia (tj. Všetky ukazovatele a referencie z nich odvodené) sa v určitom okamihu už viac nebudú používať. Potom budete chcieť znova použiť pôvodnú jedinečnú referenciu .
///
///
/// Kontrola výpožičiek zvyčajne zvládne toto stohovanie výpožičiek za vás, ale niektoré riadiace toky, ktoré dosiahnu toto stohovanie, sú pre kompilátora príliš komplikované.
/// `DormantMutRef` vám umožňuje skontrolovať si pôžičku sami, zatiaľ čo stále vyjadrujete svoju komponovanú povahu, a zapuzdruje surový kód ukazovateľa, ktorý je na to potrebný, bez nedefinovaného správania.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Zachyťte jedinečnú výpožičku a okamžite ju znova zhodnoťte.
    /// Pre kompilátor je životnosť novej referencie rovnaká ako životnosť pôvodnej referencie, ale promise ju budete používať kratšie.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // BEZPEČNOSŤ: výpožičku držíme počas celého roka a cez `_marker` a vystavujeme ju
        // iba tento odkaz, takže je jedinečný.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Vrátiť sa k pôvodne zachytenému jedinečnému výpožičke.
    ///
    /// # Safety
    ///
    /// Znovuzískanie musí skončiť, tj referencia vrátená `new` a všetky ukazovatele a referencie z nej odvodené sa už nesmú používať.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // BEZPEČNOSŤ: naše vlastné bezpečnostné podmienky naznačujú, že tento odkaz je opäť jedinečný.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;