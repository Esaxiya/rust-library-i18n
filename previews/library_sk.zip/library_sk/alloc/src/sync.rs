#![stable(feature = "rust1", since = "1.0.0")]

//! Ukazovatele na počítanie odkazov bezpečné pre vlákna.
//!
//! Ďalšie informácie nájdete v dokumentácii k produktu [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Mierny limit na počet odkazov, ktoré je možné vykonať na `Arc`.
///
/// Prekročenie tohto limitu preruší váš program (aj keď nie nevyhnutne) pri referenciách _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer nepodporuje ploty pamäte.
// Aby ste sa vyhli falošne pozitívnym správam v implementácii Arc/Weak, použite namiesto toho na synchronizáciu atómové zaťaženie.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Ukazovateľ počítania odkazov bezpečný pre vlákna.'Arc' je skratka pre " Atomically Reference Counted`.
///
/// Typ `Arc<T>` poskytuje zdieľané vlastníctvo hodnoty typu `T` pridelenej v halde.Vyvolaním [`clone`][clone] na `Arc` vznikne nová inštancia `Arc`, ktorá ukazuje na rovnaké haldy ako zdroj `Arc`, a zároveň zvyšuje počet referencií.
/// Keď sa zničí posledný ukazovateľ `Arc` na dané pridelenie, hodnota uložená v tomto pridelení (často označovaná ako "inner value") sa tiež zruší.
///
/// Zdieľané odkazy v Rust predvolene nepovoľujú mutáciu a `Arc` nie je výnimkou: vo všeobecnosti nemôžete získať premenlivý odkaz na niečo vo vnútri `Arc`.Ak potrebujete mutovať prostredníctvom `Arc`, použite [`Mutex`][mutex], [`RwLock`][rwlock] alebo niektorý z typov [`Atomic`][atomic].
///
/// ## Bezpečnosť závitu
///
/// Na rozdiel od [`Rc<T>`], `Arc<T>` používa na počítanie referencií atómové operácie.To znamená, že je bezpečný pre vlákna.Nevýhodou je, že atómové operácie sú nákladnejšie ako bežné prístupy do pamäte.Ak nezdieľate alokácie počítané podľa referenčných údajov medzi vláknami, zvážte použitie [`Rc<T>`] pre nižšiu réžiu.
/// [`Rc<T>`] je bezpečná predvolená hodnota, pretože kompilátor zachytí každý pokus o odoslanie [`Rc<T>`] medzi vláknami.
/// Knižnica si však môže zvoliť `Arc<T>`, aby poskytla zákazníkom knižnice väčšiu flexibilitu.
///
/// `Arc<T>` bude implementovať [`Send`] a [`Sync`], pokiaľ `T` implementuje [`Send`] a [`Sync`].
/// Prečo nemôžete vložiť typ `T`, ktorý nie je bezpečný pre vlákna, do modelu `Arc<T>`, aby bol bezpečný pre vlákna?To môže byť spočiatku trochu protiintuitívne: koniec koncov, nejde o bezpečnosť vlákna `Arc<T>`?Kľúč je tento: `Arc<T>` zaisťuje, že vlákna majú viacnásobné vlastníctvo tých istých údajov, ale neprispieva k bezpečnosti vlákien k ich údajom.
///
/// Zvážte `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] nie je [`Sync`], a ak `Arc<T>` bol vždy [`Send`], zobrazí sa `Arc <` [`RefCell<T>`]`>`by bolo tiež.
/// Ale potom by sme mali problém:
/// [`RefCell<T>`] nie je bezpečný pre vlákna;sleduje počet zapožičaných pomocou iných ako atómových operácií.
///
/// Nakoniec to znamená, že možno budete musieť spárovať `Arc<T>` s nejakým typom [`std::sync`], zvyčajne s [`Mutex<T>`][mutex].
///
/// ## Lámacie cykly s `Weak`
///
/// Metódu [`downgrade`][downgrade] možno použiť na vytvorenie ukazovateľa [`Weak`], ktorý nevlastní.Ukazovateľ [`Weak`] môže byť ['upgrade`][upgrade] d na `Arc`, ale vráti [`None`], ak už bola hodnota uložená v alokácii zrušená.
/// Inými slovami, ukazovatele `Weak` neudržiavajú hodnotu v rámci alokácie nažive;ale *udržujú* udržanie alokácie (záložného úložiska pre túto hodnotu) nažive.
///
/// Cyklus medzi ukazovateľmi `Arc` nebude nikdy pridelený.
/// Z tohto dôvodu sa [`Weak`] používa na prerušenie cyklov.Napríklad strom môže mať silné ukazovatele `Arc` z nadradených uzlov na deti a [`Weak`] ukazovatele z detí späť na svojich rodičov.
///
/// # Klonovacie referencie
///
/// Vytvorenie novej referencie z existujúceho ukazovateľa spočítaného referencie sa vykonáva pomocou `Clone` trait implementovaného pre [`Arc<T>`][Arc] a [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Dve nižšie uvedené syntaxe sú ekvivalentné.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b a foo sú všetky oblúky, ktoré ukazujú na rovnaké miesto v pamäti
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automaticky dereferencie na `T` (cez [`Deref`][deref] trait), takže môžete volať `T` metódy na hodnotu typu `Arc<T>`.Aby sa zabránilo stretom mien s metódami `T`, sú samotné metódy `Arc<T>` pridruženými funkciami, ktoré sa volajú pomocou [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// " Oblúk<T>" Implementácie traits ako `Clone` možno tiež nazývať pomocou plne kvalifikovanej syntaxe.
/// Niektorí ľudia uprednostňujú použitie plne kvalifikovanej syntaxe, zatiaľ čo iní uprednostňujú použitie syntaxe hovorov metódami.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Syntax volania metódy
/// let arc2 = arc.clone();
/// // Plne kvalifikovaná syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] nemá automatickú dereferenciu k `T`, pretože vnútorná hodnota už mohla byť zrušená.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Zdieľanie nemenných údajov medzi vláknami:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Upozorňujeme, že tu ** tieto testy nespúšťame.
// Stavatelia windows sú veľmi nešťastní, ak vlákno prežije hlavné vlákno a potom súčasne skončí (niečo zablokované), takže sa tomu úplne vyhneme tým, že tieto testy nespustíme.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Zdieľanie premenlivého [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Viac príkladov počítania referencií nájdete na [`rc` documentation][rc_examples] vo všeobecnosti.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` je verzia [`Arc`], ktorá obsahuje nenáležitý odkaz na spravovanú alokáciu.
/// Alokácia je prístupná volaním [`upgrade`] na ukazovateli `Weak`, ktorý vráti [" Možnosť`]`<`[" Oblúk`] `<T>>`.
///
/// Pretože referencia `Weak` sa nezapočítava do vlastníctva, nezabráni tomu, aby došlo k zrušeniu hodnoty uloženej v alokácii a samotný `Weak` neposkytuje žiadne záruky týkajúce sa stále existujúcej hodnoty.
///
/// Môže sa teda vrátiť [`None`], keď [`upgrade`] d.
/// Pamätajte však, že referencia `Weak`*nezabraňuje* v pridelení samotnej alokácie (záložného úložiska).
///
/// Ukazovateľ `Weak` je užitočný na uchovanie dočasného odkazu na alokáciu spravovanú [`Arc`] bez toho, aby zabránil zrušeniu jeho vnútornej hodnoty.
/// Používa sa tiež na zabránenie cyklickým odkazom medzi ukazovateľmi [`Arc`], pretože vzájomné vlastníctvo odkazov by nikdy neumožnilo zrušenie ktoréhokoľvek z [`Arc`].
/// Napríklad strom môže mať silné ukazovatele [`Arc`] z rodičovských uzlov na deti a ukazovatele `Weak` z detí späť na svojich rodičov.
///
/// Typickým spôsobom, ako získať ukazovateľ `Weak`, je volanie [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Toto je `NonNull`, ktorý umožňuje optimalizáciu veľkosti tohto typu v enumoch, ale nemusí to byť nevyhnutne platný ukazovateľ.
    //
    // `Weak::new` nastaví to na `usize::MAX`, aby nebolo potrebné alokovať priestor na halde.
    // To nie je hodnota, ktorú skutočný ukazovateľ bude mať, pretože RcBox má zarovnanie minimálne na 2.
    // Toto je možné iba v prípade `T: Sized`;bezrozmerný model `T` sa nikdy nerozmotáva.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Toto je odolné repr(C) až future proti možnému preskupeniu polí, ktoré by rušilo inak bezpečné [into|from]_raw() transmutovateľných vnútorných typov.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // hodnota usize::MAX funguje ako indikátor dočasnej schopnosti "locking" upgradovať slabé ukazovatele alebo downgradovať silné ukazovatele;toto sa používa na vyhnutie sa závodom v `make_mut` a `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konštruuje nový `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Začnite počítať slabý ukazovateľ ako 1, čo je slabý ukazovateľ, ktorý držia všetky silné ukazovatele (kinda), ďalšie informácie nájdete v std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konštruuje nový model `Arc<T>` so slabým odkazom na seba.
    /// Pokus o aktualizáciu slabej referencie pred návratom tejto funkcie bude mať za následok hodnotu `None`.
    /// Slabá referencia však môže byť voľne klonovaná a uložená na neskoršie použitie.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Zostrojte vnútorný v stave "uninitialized" s jednou slabou referenciou.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Je dôležité, aby sme sa nevzdali vlastníctva slabého ukazovateľa, inak by sa mohla pamäť uvoľniť do času, keď sa vráti `data_fn`.
        // Ak by sme skutočne chceli odovzdať vlastníctvo, mohli by sme pre seba vytvoriť ďalšieho slabého ukazovateľa, čo by však malo za následok ďalšie aktualizácie slabého referenčného počtu, ktoré by inak neboli potrebné.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Teraz môžeme správne inicializovať vnútornú hodnotu a urobiť z našej slabej referencie silnú referenciu.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Vyššie uvedený zápis do dátového poľa musí byť viditeľný pre všetky vlákna, ktoré sledujú nenulový silný počet.
            // Preto potrebujeme aspoň "Release" objednávanie, aby sme mohli synchronizovať s `compare_exchange_weak` v `Weak::upgrade`.
            //
            // "Acquire" objednávka nie je nutná.
            // Keď uvažujeme o možnom správaní sa `data_fn`, musíme sa iba pozrieť na to, čo by mohlo robiť s odkazom na neupgradovateľný `Weak`:
            //
            // - Môže *klonovať*`Weak` a zvýšiť tak slabý referenčný počet.
            // - Môže tieto klony odhodiť a znížiť tak slabý referenčný počet (nikdy však na nulu).
            //
            // Tieto vedľajšie účinky nás nijako neovplyvňujú a iba s použitím bezpečného kódu nie sú možné žiadne ďalšie vedľajšie účinky.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Silné referencie by mali spoločne vlastniť zdieľanú slabú referenciu, takže nespúšťajte deštruktor pre našu starú slabú referenciu.
        //
        mem::forget(weak);
        strong
    }

    /// Vyrába nový model `Arc` s neinicializovaným obsahom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializácia:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Zostrojí nový model `Arc` s neinicializovaným obsahom a pamäť bude vyplnená bajtmi `0`.
    ///
    ///
    /// Príklady správneho a nesprávneho použitia tejto metódy nájdete v časti [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konštruuje nový `Pin<Arc<T>>`.
    /// Ak `T` neimplementuje `Unpin`, bude `data` pripnutý v pamäti a nebude ho možné presunúť.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Vytvorí nový `Arc<T>` a vráti chybu, ak alokácia zlyhá.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Začnite počítať slabý ukazovateľ ako 1, čo je slabý ukazovateľ, ktorý držia všetky silné ukazovatele (kinda), ďalšie informácie nájdete v std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Zostrojí nový `Arc` s neinicializovaným obsahom a vráti chybu, ak alokácia zlyhá.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odložená inicializácia:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Zostrojí nový `Arc` s neinicializovaným obsahom, pričom pamäť sa vyplní bajtmi `0` a v prípade zlyhania alokácie vráti chybu.
    ///
    ///
    /// Príklady správneho a nesprávneho použitia tejto metódy nájdete v časti [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Vráti vnútornú hodnotu, ak má `Arc` presne jednu silnú referenciu.
    ///
    /// V opačnom prípade sa vráti [`Err`] s rovnakým `Arc`, ktorý bol odovzdaný.
    ///
    ///
    /// To sa podarí, aj keď existujú vynikajúce slabé referencie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Vytvorte slabý ukazovateľ na vyčistenie implicitnej silno-slabej referencie
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Vytvorí nový plátok spočítaný pomocou atómových odkazov s neinicializovaným obsahom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializácia:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Vytvorí nový výsek počítaný podľa atómových odkazov s neinicializovaným obsahom, pričom pamäť je vyplnená bajtmi `0`.
    ///
    ///
    /// Príklady správneho a nesprávneho použitia tejto metódy nájdete v časti [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konvertuje na `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Rovnako ako v prípade modelu [`MaybeUninit::assume_init`], je na volajúcom, aby zaručil, že vnútorná hodnota je skutočne v inicializovanom stave.
    ///
    /// Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí okamžité nedefinované správanie.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložená inicializácia:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konvertuje na `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Rovnako ako v prípade modelu [`MaybeUninit::assume_init`], je na volajúcom, aby zaručil, že vnútorná hodnota je skutočne v inicializovanom stave.
    ///
    /// Toto volanie, keď obsah ešte nie je úplne inicializovaný, spôsobí okamžité nedefinované správanie.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložená inicializácia:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Spotrebuje `Arc` a vráti zabalený ukazovateľ.
    ///
    /// Aby sa zabránilo úniku pamäte, musí byť ukazovateľ prevedený späť na `Arc` pomocou [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Poskytuje nespracovaný ukazovateľ na údaje.
    ///
    /// Počty nie sú nijako ovplyvnené a `Arc` sa nespotrebováva.
    /// Ukazovateľ je platný, pokiaľ je v `Arc` vysoký počet.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // BEZPEČNOSŤ: Toto nemôže ísť cez Deref::deref alebo RcBoxPtr::inner, pretože
        // to je potrebné na zachovanie pôvodu raw/mut tak, aby napr
        // `get_mut` môže písať cez ukazovateľ po obnovení Rc cez `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Vytvorí `Arc<T>` zo surového ukazovateľa.
    ///
    /// Nespracovaný ukazovateľ musel byť predtým vrátený volaním [`Arc<U>::into_raw`][into_raw], kde `U` musí mať rovnakú veľkosť a zarovnanie ako `T`.
    /// Platí to triviálne, ak `U` je `T`.
    /// Upozorňujeme, že ak `U` nie je `T`, ale má rovnakú veľkosť a zarovnanie, je to v podstate ako transmutácia referencií rôznych typov.
    /// Ďalšie informácie o tom, aké obmedzenia platia v tomto prípade, nájdete na [`mem::transmute`][transmute].
    ///
    /// Užívateľ `from_raw` sa musí uistiť, že konkrétna hodnota `T` klesne iba raz.
    ///
    /// Táto funkcia nie je bezpečná, pretože nesprávne použitie môže viesť k nezabezpečeniu pamäte, a to aj v prípade, že k vrátenému `Arc<T>` nikdy nie je prístup.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Prestavte späť na `Arc`, aby ste zabránili úniku.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Ďalšie volania na `Arc::from_raw(x_ptr)` by neboli bezpečné z hľadiska pamäte.
    /// }
    ///
    /// // Pamäť sa uvoľnila, keď `x` vyšlo z rozsahu vyššie, takže `x_ptr` sa teraz motá!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Ak chcete nájsť pôvodný ArcInner, obráťte posunutie.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Vytvorí nový ukazovateľ [`Weak`] na toto pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Toto uvoľnené je v poriadku, pretože kontrolujeme hodnotu v CAS nižšie.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // skontrolujte, či je momentálne slabé počítadlo "locked";ak ano tak tocit.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: tento kód momentálne ignoruje možnosť pretečenia
            // do usize::MAX;všeobecne je potrebné upraviť Rc aj Arc, aby sa zabránilo pretečeniu.
            //

            // Na rozdiel od Clone() potrebujeme, aby to bolo čítanie Acquire, ktoré sa synchronizuje s zápisom prichádzajúcim z `is_unique`, aby sa udalosti pred týmto zápisom udiali pred týmto čítaním.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Uistite sa, že nevytvárame visiaci Slabý
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Získava počet ukazovateľov [`Weak`] na toto pridelenie.
    ///
    /// # Safety
    ///
    /// Táto metóda je sama o sebe bezpečná, ale jej správne použitie si vyžaduje osobitnú starostlivosť.
    /// Iné vlákno môže kedykoľvek zmeniť slabý počet, a to aj potenciálne medzi volaním tejto metódy a pôsobením na výsledok.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Toto tvrdenie je deterministické, pretože sme medzi vláknami nezdieľali `Arc` alebo `Weak`.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Ak je slabý počet momentálne zamknutý, bola hodnota počítania 0 tesne pred odobratím zámku.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Získava počet silných ukazovateľov (`Arc`) na toto pridelenie.
    ///
    /// # Safety
    ///
    /// Táto metóda je sama o sebe bezpečná, ale jej správne použitie si vyžaduje osobitnú starostlivosť.
    /// Iné vlákno môže kedykoľvek zmeniť silný počet, vrátane potenciálneho medzi volaním tejto metódy a pôsobením na výsledok.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Toto tvrdenie je deterministické, pretože sme `Arc` nezdieľali medzi vláknami.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Zvyšuje silný referenčný počet na `Arc<T>` spojený s poskytnutým ukazovateľom o jednu.
    ///
    /// # Safety
    ///
    /// Ukazovateľ musí byť získaný prostredníctvom `Arc::into_raw` a pridružená inštancia `Arc` musí byť platná (tj
    /// silný počet musí byť po dobu tejto metódy najmenej 1).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Toto tvrdenie je deterministické, pretože sme `Arc` nezdieľali medzi vláknami.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Ponechajte si oblúk, ale nedotýkajte sa refcountu zabalením do programu ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Teraz zvýšte refcount, ale neznižujte ani nový refcount
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// O jednu zníži silný počet referencií na `Arc<T>` spojený s poskytnutým ukazovateľom.
    ///
    /// # Safety
    ///
    /// Ukazovateľ musí byť získaný prostredníctvom `Arc::into_raw` a pridružená inštancia `Arc` musí byť platná (tj
    /// silný počet musí byť pri vyvolaní tejto metódy aspoň 1).
    /// Túto metódu je možné použiť na uvoľnenie finálnej verzie `Arc` a zálohovania, ale po uvoľnení finálnej verzie `Arc` by sa nemalo **volať**.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Tieto tvrdenia sú deterministické, pretože sme `Arc` nezdieľali medzi vláknami.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Táto bezpečnosť je v poriadku, pretože zatiaľ čo tento oblúk žije, máme zaručené, že vnútorný ukazovateľ je platný.
        // Ďalej vieme, že samotná štruktúra `ArcInner` je `Sync`, pretože aj vnútorné dáta sú `Sync`, takže si môžeme požičať nemenný ukazovateľ na tento obsah.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Neuviazaná časť `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // V tejto chvíli zničte údaje, aj keď nemusíme uvoľniť samotné pridelenie schránky (stále môžu ležať slabí ukazovatelia).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Zrušte slabé ref. Kolektívne držané všetkými silnými odkazmi
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vráti `true`, ak dva argumenty " Arc` ukazujú na rovnakú alokáciu (v duchu podobnom [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Pridelí `ArcInner<T>` s dostatočným priestorom pre vnútornú hodnotu s možnou veľkosťou, kde má hodnota dané rozloženie.
    ///
    /// Funkcia `mem_to_arcinner` sa volá pomocou údajového ukazovateľa a musí vrátiť späť (potenciálne tučný) ukazovateľ pre `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Vypočítajte rozloženie pomocou rozloženia s danou hodnotou.
        // Predtým bolo rozloženie vypočítané na základe výrazu `&*(ptr as* const ArcInner<T>)`, čím sa však vytvoril nesprávne zarovnaný odkaz (pozri #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Priradí `ArcInner<T>` s dostatočným priestorom pre vnútornú hodnotu s možnou veľkosťou, kde má hodnota poskytnuté rozloženie, a vráti chybu, ak sa alokácia nepodarí.
    ///
    ///
    /// Funkcia `mem_to_arcinner` sa volá pomocou údajového ukazovateľa a musí vrátiť späť (potenciálne tučný) ukazovateľ pre `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Vypočítajte rozloženie pomocou rozloženia s danou hodnotou.
        // Predtým bolo rozloženie vypočítané na základe výrazu `&*(ptr as* const ArcInner<T>)`, čím sa však vytvoril nesprávne zarovnaný odkaz (pozri #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicializujte ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Priraďuje `ArcInner<T>` s dostatočným priestorom pre vnútornú hodnotu bez veľkosti.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Priraďte pre `ArcInner<T>` danú hodnotu.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Skopírujte hodnotu ako bajty
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Uvoľnite alokáciu bez toho, aby ste pustili jej obsah
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Pridelí `ArcInner<[T]>` s danou dĺžkou.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Skopírujte prvky z rezu do novo prideleného oblúka <\[T\]>
    ///
    /// Nebezpečné, pretože volajúci musí buď prevziať vlastníctvo, alebo viazať reťazec `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Vytvorí `Arc<[T]>` z iterátora, o ktorom sa vie, že má určitú veľkosť.
    ///
    /// Správanie nie je definované, ak je veľkosť nesprávna.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Ochranu Panic pri klonovaní T prvkov.
        // V prípade panic budú prvky, ktoré boli zapísané do novej ArcInner, zahodené a potom uvoľnená pamäť.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Ukazovateľ na prvý prvok
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Všetko jasné.Zabudnite na strážcu, aby neuvoľnil nový ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Špecializácia trait použitá pre `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Vytvorí klon ukazovateľa `Arc`.
    ///
    /// Týmto sa vytvorí ďalší ukazovateľ na rovnaké pridelenie, čím sa zvýši počet silných referencií.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Použitie uvoľneného poradia je v poriadku, pretože znalosť pôvodného odkazu zabráni iným vláknam v chybnom vymazaní objektu.
        //
        // Ako je vysvetlené v [Boost documentation][1], zvýšenie počítadla referencií je možné vykonať vždy pomocou memory_order_relaxed: Nové referencie na objekt je možné vytvoriť iba z existujúcej referencie a odovzdanie existujúcej referencie z jedného vlákna do druhého musí už poskytovať potrebnú synchronizáciu.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Musíme sa však chrániť pred masívnymi zúčtovaniami pre prípad, že by niekto pamätal Arcs.
        // Ak to neurobíme, počet môže pretekať a používatelia budú používať bezplatne.
        // Rázne nasýtime `isize::MAX` za predpokladu, že neexistuje ~2 miliárd vlákien zvyšujúcich počet referencií naraz.
        //
        // Táto branch nebude nikdy použitá v žiadnom realistickom programe.
        //
        // Potratíme, pretože takýto program je neuveriteľne zdegenerovaný a je nám jedno, že ho podporujeme.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Vytvorí premenlivý odkaz na danú `Arc`.
    ///
    /// Ak existujú ďalšie ukazovatele `Arc` alebo [`Weak`] na rovnaké pridelenie, potom `make_mut` vytvorí nové pridelenie a vyvolá [`clone`][clone] na vnútornú hodnotu, aby zabezpečil jedinečné vlastníctvo.
    /// Toto sa tiež označuje ako klon-na-zápis.
    ///
    /// Toto sa líši od správania [`Rc::make_mut`], ktoré disociuje všetky zostávajúce ukazovatele `Weak`.
    ///
    /// Pozri tiež [`get_mut`][get_mut], ktorý skôr ako pri klonovaní zlyhá.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Nebudem nič klonovať
    /// let mut other_data = Arc::clone(&data); // Nebudú sa klonovať vnútorné údaje
    /// *Arc::make_mut(&mut data) += 1;         // Klony vnútorné dáta
    /// *Arc::make_mut(&mut data) += 1;         // Nebudem nič klonovať
    /// *Arc::make_mut(&mut other_data) *= 2;   // Nebudem nič klonovať
    ///
    /// // Teraz `data` a `other_data` ukazujú na rôzne alokácie.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Upozorňujeme, že máme silnú aj slabú referenciu.
        // Uvoľnenie iba nášho silného odkazu teda samo o sebe nespôsobí uvoľnenie pamäte.
        //
        // Použite príkaz Acquire na zabezpečenie toho, aby sme videli všetky zápisy do `weak`, ku ktorým dôjde pred zápisom do vydania (tj. Zníženia) do `strong`.
        // Pretože máme slabý počet, nie je šanca, že by sa samotný ArcInner mohol uvoľniť.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Existuje ďalší silný ukazovateľ, takže musíme klonovať.
            // Predbežne pridelte pamäť, aby ste umožnili priamy zápis klonovanej hodnoty.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Vyššie uvedené je uvoľnené, pretože toto je v zásade optimalizácia: vždy jazdíme so slabými ukazovateľmi.
            // V najhoršom prípade nakoniec zbytočne pridelíme nový oblúk.
            //

            // Odstránili sme posledné silné hodnotenie, ale zostávajú ďalšie slabé hodnotenia.
            // Presunieme obsah do nového oblúka a zneplatníme ďalšie slabé odkazy.
            //

            // Všimnite si, že nie je možné, aby čítanie `weak` poskytlo usize::MAX (tj. Uzamknuté), pretože slabý počet je možné uzamknúť iba pomocou vlákna so silnou referenciou.
            //
            //

            // Zhmotnite náš vlastný implicitný slabý ukazovateľ, aby mohol podľa potreby vyčistiť ArcInner.
            //
            let _weak = Weak { ptr: this.ptr };

            // Stačí len ukradnúť údaje, zostane iba Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Boli sme jediným odkazom každého druhu;bump back up the strong ref count.
            //
            this.inner().strong.store(1, Release);
        }

        // Rovnako ako v prípade modelu `get_mut()` je nebezpečenstvo v poriadku, pretože naša referencia bola na začiatok buď jedinečná, alebo sa ňou stala po klonovaní obsahu.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Vráti premenlivý odkaz na danú `Arc`, ak neexistujú žiadne ďalšie ukazovatele `Arc` alebo [`Weak`] na rovnaké pridelenie.
    ///
    ///
    /// V opačnom prípade vráti [`None`], pretože nie je bezpečné mutovať zdieľanú hodnotu.
    ///
    /// Pozri tiež [`make_mut`][make_mut], ktorý bude [`clone`][clone] vnútornú hodnotu, keď existujú ďalšie ukazovatele.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Táto nebezpečnosť je v poriadku, pretože máme zaručené, že vrátený ukazovateľ je *iba* ukazovateľ, ktorý bude kedy vrátený do T.
            // Náš počet odkazov je v tomto okamihu zaručene 1 a vyžadovali sme, aby samotný oblúk bol `mut`, takže vraciame jediný možný odkaz na vnútorné údaje.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Vráti premenlivú referenciu do danej `Arc` bez akejkoľvek kontroly.
    ///
    /// Pozri tiež [`get_mut`], ktorý je bezpečný a vykonáva príslušné kontroly.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Žiadne ďalšie ukazovatele `Arc` alebo [`Weak`] na rovnaké pridelenie nesmú byť po dobu vrátenej výpožičky dereferencované.
    ///
    /// Toto je triviálny prípad, ak neexistujú žiadne také ukazovatele, napríklad bezprostredne po `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Dávame pozor, aby sme *nevytvorili* referenciu pokrývajúcu polia "count", pretože by to bol alias so súčasným prístupom k počtu referencií (napr.
        // od `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Určte, či ide o jedinečný odkaz (vrátane slabých odkazov) na podkladové údaje.
    ///
    ///
    /// To si vyžaduje uzamknutie počtu slabých ref.
    fn is_unique(&mut self) -> bool {
        // uzamknite počet slabých ukazovateľov, ak sa javíme ako jediný držiteľ slabého ukazovateľa.
        //
        // Štítok nadobudnutia tu zaisťuje vzťah " before-before` s akýmikoľvek zápismi do `strong` (najmä v `Weak::upgrade`) pred znížením počtu `weak` (cez `Weak::drop`, ktorý používa release).
        // Ak aktualizovaný slabý ref nikdy neklesol, CAS tu zlyhá, takže sa nestaráme o synchronizáciu.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Toto musí byť `Acquire`, aby sa synchronizoval s poklesom počítadla `strong` v `drop`-jediný prístup, ku ktorému dôjde, keď dôjde k zrušeniu akejkoľvek inej referencie, ako je posledná.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Vydanie pre zápis sa tu synchronizuje s čítaním v `downgrade`, čo účinne bráni tomu, aby sa vyššie uvedené čítanie `strong` stalo po zápise.
            //
            //
            self.inner().weak.store(1, Release); // uvoľnite zámok
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Klesne `Arc`.
    ///
    /// To zníži počet silných referencií.
    /// Ak počet silných referencií dosiahne nulu, potom jediné ďalšie referencie (ak existujú) sú [`Weak`], takže `drop` máme vnútornú hodnotu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Netlačí nič
    /// drop(foo2);   // Vytlačí "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Pretože `fetch_sub` je už atómový, nemusíme synchronizovať s inými vláknami, pokiaľ nebudeme vymazávať objekt.
        // Rovnaká logika platí aj pre nižšie `fetch_sub` a `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Tento plot je potrebný, aby sa zabránilo zmene poradia použitia údajov a ich vymazaniu.
        // Pretože je označený ako `Release`, znižovanie počtu referencií sa synchronizuje s týmto plotom `Acquire`.
        // To znamená, že použitie údajov sa uskutoční pred znížením počtu referencií, čo sa stane pred týmto ohradením, ktoré sa stane pred odstránením údajov.
        //
        // Ako je vysvetlené v [Boost documentation][1],
        //
        // > Je dôležité vynútiť možný prístup k objektu v jednom
        // > vlákno (prostredníctvom existujúceho odkazu) na *stať sa pred* vymazaním
        // > objekt v inom vlákne.Toto je dosiahnuté modelom "release"
        // > operácia po zrušení odkazu (akýkoľvek prístup k objektu
        // > prostredníctvom tohto odkazu sa samozrejme malo stať predtým), a
        // > "acquire" pred vymazaním objektu.
        //
        // Konkrétne, zatiaľ čo obsah oblúka je zvyčajne nemenný, je možné, aby vnútorné zápisy fungovali ako niečo ako Mutex<T>.
        // Pretože Mutex nie je získaný, keď je vymazaný, nemôžeme sa spoliehať na jeho synchronizačnú logiku, že zápisy vo vlákne A budú viditeľné pre deštruktor bežiaci vo vlákne B.
        //
        //
        // Tiež si všimnite, že plot Acquire by tu mohol byť pravdepodobne nahradený nákladom Acquire, čo by mohlo zlepšiť výkon vo veľmi náročných situáciách.Pozri [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Pokus o downcast `Arc<dyn Any + Send + Sync>` na konkrétny typ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konštruuje nový `Weak<T>` bez vyhradenia akejkoľvek pamäte.
    /// Volanie [`upgrade`] na návratovú hodnotu dáva vždy [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Typ pomocníka, ktorý umožňuje prístup k počtu referencií bez akýchkoľvek tvrdení o údajovom poli.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Vráti hrubý ukazovateľ na objekt `T`, na ktorý ukazuje tento `Weak<T>`.
    ///
    /// Ukazovateľ je platný, iba ak existujú silné referencie.
    /// Ukazovateľ môže byť visiaci, nezarovnaný alebo dokonca [`null`] inak.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Oba ukazujú na ten istý objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Silní ho tu udržujú pri živote, takže k objektu máme stále prístup.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Ale už nie.
    /// // Môžeme urobiť weak.as_ptr(), ale prístup k ukazovateľu by viedol k nedefinovanému správaniu.
    /// // assert_eq! ("ahoj", nebezpečné {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Ak je ukazovateľ visiaci, vrátime priamo strážnu stráž.
            // Toto nemôže byť platná adresa užitočného zaťaženia, pretože užitočné zaťaženie je minimálne rovnako zarovnané ako ArcInner (usize).
            ptr as *const T
        } else {
            // BEZPEČNOSŤ: ak is_dangling vráti hodnotu false, potom je ukazovateľ dereferencable.
            // Užitočné zaťaženie môže v tomto okamihu klesnúť a my musíme zachovať pôvod, preto používajte manipuláciu s hrubým ukazovateľom.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Spotrebuje `Weak<T>` a urobí z neho surový ukazovateľ.
    ///
    /// Týmto sa slabý ukazovateľ prevedie na surový ukazovateľ, pričom sa zachová vlastníctvo jednej slabej referencie (slabý počet sa touto operáciou nezmení).
    /// Môže byť otočený späť do `Weak<T>` s [`from_raw`].
    ///
    /// Pri prístupe k cieľu ukazovateľa platia rovnaké obmedzenia ako pri [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Skonvertuje surový ukazovateľ, ktorý predtým vytvoril [`into_raw`], na `Weak<T>`.
    ///
    /// To možno použiť na bezpečné získanie silnej referencie (volaním [`upgrade`] neskôr) alebo na uvoľnenie slabého počtu poklesnutím `Weak<T>`.
    ///
    /// Berie vlastníctvo jednej slabej referencie (s výnimkou ukazovateľov vytvorených [`new`], pretože tieto nič nevlastnia; metóda na nich stále funguje).
    ///
    /// # Safety
    ///
    /// Ukazovateľ musí pochádzať z [`into_raw`] a musí stále vlastniť svoju potenciálne slabú referenciu.
    ///
    /// V čase volania tohto čísla je povolený maximálny počet 0.
    /// Toto však berie na seba vlastnosť jednej slabej referencie, ktorá je v súčasnosti reprezentovaná ako surový ukazovateľ (slabý počet nie je touto operáciou upravený), a preto musí byť spárovaná s predchádzajúcim volaním na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Odpočítať posledný slabý počet.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Pozri Weak::as_ptr pre kontext, ako je odvodený vstupný ukazovateľ.

        let ptr = if is_dangling(ptr as *mut T) {
            // Toto je visiaci Slabý.
            ptr as *mut ArcInner<T>
        } else {
            // Inak máme zaručené, že ukazovateľ pochádzal z nerozmotaného slabého.
            // BEZPEČNOSŤ: data_offset je bezpečné volať, pretože ptr odkazuje na skutočné (potenciálne spadnuté) T.
            let offset = unsafe { data_offset(ptr) };
            // Preto obrátime posun, aby sme získali celý RcBox.
            // BEZPEČNOSŤ: ukazovateľ pochádza zo slabého, takže tento posun je bezpečný.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // BEZPEČNOSŤ: teraz sme obnovili pôvodný ukazovateľ Slabý, takže môžeme vytvoriť Slabý.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Pokusy o aktualizáciu ukazovateľa `Weak` na [`Arc`], v prípade úspechu sa oneskorí pokles vnútornej hodnoty.
    ///
    ///
    /// Vráti [`None`], ak medzitým vnútorná hodnota klesla.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Zničte všetky silné ukazovatele.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Na zvýšenie silného počtu namiesto fetch_add používame slučku CAS, pretože táto funkcia by nikdy nemala brať referenčný počet z nuly na jednu.
        //
        //
        let inner = self.inner()?;

        // Uvoľnené načítanie, pretože akýkoľvek zápis 0, ktorý môžeme pozorovať, opúšťa pole v permanentne nulovom stave (takže čítanie "stale" 0 je v poriadku) a akákoľvek iná hodnota sa potvrdzuje prostredníctvom CAS nižšie.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Prečo to robíme, si prečítajte v komentári v `Arc::clone` (pre `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Uvoľnená je v poriadku pre prípad zlyhania, pretože nemáme žiadne očakávania týkajúce sa nového stavu.
            // Získanie je nevyhnutné pre úspešný prípad synchronizácie s `Arc::new_cyclic`, keď je možné vnútornú hodnotu inicializovať po vytvorení referencií `Weak`.
            // V takom prípade očakávame pozorovanie úplne inicializovanej hodnoty.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null skontrolované vyššie
                Err(old) => n = old,
            }
        }
    }

    /// Získava počet silných ukazovateľov (`Arc`) smerujúcich k tomuto prideleniu.
    ///
    /// Ak bol `self` vytvorený pomocou [`Weak::new`], vráti hodnotu 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Získava aproximáciu počtu ukazovateľov `Weak` smerujúcich k tomuto prideleniu.
    ///
    /// Ak bol `self` vytvorený pomocou [`Weak::new`], alebo ak nezostanú žiadne silné ukazovatele, vráti hodnotu 0.
    ///
    /// # Accuracy
    ///
    /// Kvôli podrobnostiam implementácie môže byť vrátená hodnota vypnutá o 1 v obidvoch smeroch, keď iné vlákna manipulujú s akýmkoľvek oblúkom alebo slabým ukazujúcim na rovnaké pridelenie.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Pretože sme pozorovali, že po prečítaní slabého počtu existoval aspoň jeden silný ukazovateľ, vieme, že implicitná slabá referencia (prítomná vždy, keď sú akékoľvek silné referencie živé) bola stále okolo, keď sme pozorovali slabý počet, a preto ju môžeme bezpečne odčítať.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Vráti `None`, keď je ukazovateľ visiaci a nie je pridelená žiadna `ArcInner`, (tj. Keď bola táto `Weak` vytvorená pomocou `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Dávame pozor, aby sme *nie* vytvorili referenciu pokrývajúcu pole "data", pretože pole môže byť súčasne mutované (napríklad ak je zrušený posledný `Arc`, dátové pole bude presunuté na miesto).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vráti `true`, ak dva argumenty " Slabé` ukazujú na rovnakú alokáciu (podobne ako [`ptr::eq`]), alebo ak obidve neukazujú na žiadnu alokáciu (pretože boli vytvorené pomocou `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Pretože toto porovnáva ukazovatele, znamená to, že `Weak::new()` sa budú rovnať, aj keď neukazujú na žiadne pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Porovnávam `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Vytvorí klon ukazovateľa `Weak`, ktorý ukazuje na rovnaké pridelenie.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Prečo je to uvoľnené, si pozrite komentáre v Arc::clone().
        // To môže použiť fetch_add (ignorovanie zámku), pretože slabý počet je uzamknutý iba tam, kde neexistujú *žiadne iné* slabé ukazovatele.
        //
        // (Takže v takom prípade nemôžeme spustiť tento kód).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Prečo to robíme, si prečítajte v komentári v Arc::clone() (pre mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konštruuje nový `Weak<T>` bez alokácie pamäte.
    /// Volanie [`upgrade`] na návratovú hodnotu dáva vždy [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Spustí ukazovateľ `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Netlačí nič
    /// drop(foo);        // Vytlačí "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Ak zistíme, že sme boli posledným slabým ukazovateľom, potom je čas na úplné uvoľnenie údajov.Prečítajte si diskusiu v Arc::drop() o usporiadaní pamätí
        //
        // Tu nie je potrebné kontrolovať uzamknutý stav, pretože slabý počet je možné uzamknúť iba vtedy, ak existoval práve jeden slabý ref, čo znamená, že pokles mohol až následne spustiť ON zostávajúci slabý ref, čo sa môže stať až po uvoľnení zámku.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Túto špecializáciu robíme tu, a nie ako všeobecnejšiu optimalizáciu na `&T`, pretože by to inak zvýšilo náklady na všetky kontroly rovnosti v ref.
/// Predpokladáme, že `Arc`s sa používajú na ukladanie veľkých hodnôt, ktoré sa pomaly klonujú, ale tiež ťažko kontrolujú rovnosť, čo spôsobuje, že sa tieto náklady ľahšie vyplácajú.
///
/// Je tiež pravdepodobnejšie, že budú mať dva klony `Arc`, ktoré ukazujú na rovnakú hodnotu, ako dva znaky " &T`.
///
/// Môžeme to urobiť, iba keď môže byť `T: Eq` ako `PartialEq` zámerne nereflexívna.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Rovnosť pre dva " oblúky`.
    ///
    /// Dva argumenty " Arc` sú rovnaké, ak sú ich vnútorné hodnoty rovnaké, aj keď sú uložené v inom priradení.
    ///
    /// Ak `T` implementuje aj `Eq` (z čoho vyplýva reflexivita rovnosti), dva " oblúky`, ktoré smerujú k rovnakému rozdeleniu, sú vždy rovnaké.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Nerovnosť pre dva oblúky.
    ///
    /// Dva " oblúky` sú nerovnaké, ak sú ich vnútorné hodnoty nerovnaké.
    ///
    /// Ak `T` implementuje aj `Eq` (z čoho vyplýva reflexivita rovnosti), dva " oblúky`, ktoré ukazujú na rovnakú hodnotu, nie sú nikdy nerovnaké.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Čiastočné porovnanie pre dva oblúky.
    ///
    /// Tieto dva sú porovnané volaním `partial_cmp()` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Menej ako porovnanie pre dva oblúky.
    ///
    /// Tieto dva sú porovnané volaním `<` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Porovnanie " menšie alebo rovné`pre dva " oblúkové`.
    ///
    /// Tieto dva sú porovnané volaním `<=` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Lepšie ako porovnanie pre dva oblúky.
    ///
    /// Tieto dva sú porovnané volaním `>` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Porovnanie " väčšie alebo rovné`pre dva " oblúkové`.
    ///
    /// Tieto dva sú porovnané volaním `>=` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Porovnanie pre dva oblúky.
    ///
    /// Tieto dva sú porovnané volaním `cmp()` na ich vnútorné hodnoty.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Vytvorí nový `Arc<T>` s hodnotou `Default` pre `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Priraďte plátok počítaný podľa referencie a naplňte ho klonovaním položiek `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Pridelte `str` počítaný podľa referencie a skopírujte do neho `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Pridelte `str` počítaný podľa referencie a skopírujte do neho `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Presuňte orámovaný objekt do novej alokácie počítanej podľa referencie.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Priraďte plátok počítaný podľa referencie a presuňte do neho položky `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Nechajte Vec uvoľniť pamäť, ale nezničiť jej obsah
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Vezme každý prvok v `Iterator` a zhromaždí ho do `Arc<[T]>`.
    ///
    /// # Výkonové charakteristiky
    ///
    /// ## Všeobecný prípad
    ///
    /// Všeobecne sa zhromažďovanie do `Arc<[T]>` uskutočňuje tak, že sa najskôr zhromažďuje do `Vec<T>`.Teda pri písaní nasledujúcich textov:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// toto sa správa, akoby sme napísali:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Prvá skupina pridelení sa deje tu.
    ///     .into(); // Tu dôjde k druhému prideleniu pre `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Týmto sa pridelí toľkokrát, koľkokrát je potrebné na zostavenie `Vec<T>`, a potom sa pridelí raz na premenu `Vec<T>` na `Arc<[T]>`.
    ///
    ///
    /// ## Iterátory známej dĺžky
    ///
    /// Keď váš `Iterator` implementuje `TrustedLen` a má presnú veľkosť, pre `Arc<[T]>` sa urobí jedno pridelenie.Napríklad:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Tu sa uskutoční iba jedna alokácia.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Špecializácia trait použitá na zhromažďovanie do `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // To je prípad iterátora `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // BEZPEČNOSŤ: Musíme sa ubezpečiť, že iterátor má presnú dĺžku a my máme.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Vrátiť sa k normálnej implementácii.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Získajte offset v rámci `ArcInner` pre užitočné zaťaženie za ukazovateľom.
///
/// # Safety
///
/// Ukazovateľ musí ukazovať na (a mať platné metadáta) predtým platnej inštancie T, ale T je dovolené zrušiť.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Zarovnajte hodnotu bez veľkosti na koniec ArcInner.
    // Pretože RcBox je repr(C), bude to vždy posledné pole v pamäti.
    // BEZPEČNOSŤ: keďže jediné možné veľkosti sú iba plátky, objekty trait,
    // a externé typy, požiadavka na vstupnú bezpečnosť je v súčasnosti dostatočná na splnenie požiadaviek align_of_val_raw;toto je detail implementácie jazyka, na ktorý sa mimo std nemožno spoľahnúť.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}