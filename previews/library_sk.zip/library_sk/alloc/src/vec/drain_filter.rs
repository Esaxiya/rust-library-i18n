use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Iterátor, ktorý pomocou uzáveru určuje, či by sa mal prvok odstrániť.
///
/// Túto štruktúru vytvoril [`Vec::drain_filter`].
/// Ďalšie informácie nájdete v jeho dokumentácii.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Index položky, ktorá bude skontrolovaná ďalším volaním na `next`.
    pub(super) idx: usize,
    /// Počet doteraz vyčerpaných položiek (removed).
    pub(super) del: usize,
    /// Pôvodná dĺžka `vec` pred vypustením.
    pub(super) old_len: usize,
    /// Predikát testu filtra.
    pub(super) pred: F,
    /// V predikáte testu filtra sa vyskytol príznak, ktorý naznačuje, že panic.
    /// Toto sa používa ako pomôcka pri implementácii dropu, aby sa zabránilo spotrebe zvyšku `DrainFilter`.
    /// Všetky nespracované položky budú v `vec` spätne posunuté, ale žiadne ďalšie položky nebudú zahodené alebo testované predikátom filtra.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Vráti odkaz na podkladový alokátor.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Aktualizujte index *po* volaní predikátu.
                // Ak je index aktualizovaný pred a predikát panics, prvok v tomto indexe by bol prepustený.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Toto je dosť pokazený stav a naozaj nie je zjavne správna vec, ktorú treba robiť.
                        // Nechceme sa stále pokúšať spúšťať `pred`, takže iba posúvame spätne všetky nespracované prvky a povieme vec, že stále existujú.
                        //
                        // Spätný posun je potrebný, aby sa zabránilo dvojitému poklesu poslednej úspešne vyprázdnenej položky pred hodnotou panic v predikáte.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Pokus o spotrebovanie zvyšných prvkov, ak predikát filtra ešte nebol panický.
        // Vrátime spätný posun všetkých zvyšných prvkov, či už sme spanikárili, alebo či je spotreba tu panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}