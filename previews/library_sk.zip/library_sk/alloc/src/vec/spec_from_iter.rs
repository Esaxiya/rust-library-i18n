use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Špecializácia trait použitá pre Vec::from_iter
///
/// ## Graf delegácie:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Bežným prípadom je odovzdanie vector do funkcie, ktorá sa okamžite znovu zhromaždí do vector.
        // Môžeme to skratovať, ak IntoIter nebol vôbec pokročilý.
        // Keď to bolo pokročilé, môžeme tiež znovu použiť pamäť a presunúť dáta dopredu.
        // Robíme to však iba vtedy, keď by výsledný Vec nemal viac nevyužitej kapacity, ako by ho vytvoril prostredníctvom všeobecnej implementácie FromIterator.
        //
        // Toto obmedzenie nie je nevyhnutne potrebné, pretože Vecovo alokačné správanie je zámerne nešpecifikované.
        // Je to však konzervatívna voľba.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // musí delegovať na spec_extend(), pretože extend() sám deleguje na spec_from pre prázdne Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Toto využíva `iterator.as_slice().to_vec()`, pretože spec_extend musí podniknúť viac krokov, aby zdôvodnil konečnú kapacitu + dĺžku, a tak urobiť viac práce.
// `to_vec()` priamo pridelí správne množstvo a presne ho vyplní.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): s cfg(test) nie je k dispozícii inherentná metóda `[T]::to_vec`, ktorá je vyžadovaná pre túto definíciu metódy.
    // Namiesto toho použite funkciu `slice::to_vec`, ktorá je k dispozícii iba pre cfg(test) NB, ďalšie informácie nájdete v module slice::hack v slice.rs.
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}