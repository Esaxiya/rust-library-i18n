use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Značka špecializácie na zhromažďovanie iteračného potrubia do Vec pri opätovnom použití pridelenia zdroja, tj
/// vedenie potrubia na danom mieste.
///
/// Rodič SourceIter trait je potrebný na to, aby špecializačná funkcia mala prístup k prideleniu, ktoré sa má znovu použiť.
/// Platnosť špecializácie však nestačí.
/// Ďalšie hranice nájdete na impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Interné std SourceIter/InPlaceIterable traits sú implementované iba pomocou reťazcov adaptéra <Adapter<Adapter<IntoIter>>> (všetko vlastní spoločnosť core/std).
// Ďalšie hranice implementácií adaptéra (nad rámec `impl<I: Trait> Trait for Adapter<I>`) závisia iba od iných traits, ktoré sú už označené ako špecializácia traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. značka nezávisí od životnosti typov poskytovaných používateľom.Modulovajte otvor Copy, od ktorého už závisí niekoľko ďalších špecializácií.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Ďalšie požiadavky, ktoré nie je možné vyjadriť prostredníctvom trait bounds.Namiesto toho sa spoliehame na konšt eval:
        // a) žiadne ZST, pretože by nebolo možné prideliť ich na opätovné použitie a aritmetika ukazovateľa by bola panic b) zhoda veľkosti podľa požiadaviek zmluvy Alloc c) zhody zhody podľa požiadaviek zmluvy Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // návrat k všeobecnejším implementáciám
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // používajte try-fold od
        // - lepšie sa vektorizuje pre niektoré adaptéry iterátorov
        // - na rozdiel od väčšiny metód internej iterácie trvá iba &mut
        // - umožňuje nám prevliecť ukazovateľ zápisu cez jeho vnútornosti a na konci ho získať späť
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterácia bola úspešná, neklesaj
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // skontrolujte, či bola zmluva SourceIter potvrdená: ak by neboli, možno sa do tohto bodu ani nedostaneme
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // skontrolujte zmluvu InPlaceIterable.To je možné iba v prípade, že iterátor vôbec posunul zdrojový ukazovateľ.
        // Ak používa nekontrolovaný prístup cez TrustedRandomAccess, ukazovateľ zdroja zostane vo svojej pôvodnej polohe a nemôžeme ho použiť ako referenciu.
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // zrušte všetky zostávajúce hodnoty na konci zdroja, ale zabráňte poklesu samotnej alokácie, akonáhle IntoIter zmizne z rozsahu, ak pokles panics potom tiež prepúšťame všetky prvky zhromaždené do dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // tu sa nedá presne overiť zmluva InPlaceIterable, pretože try_fold má výhradný odkaz na ukazovateľ zdroja, čo môžeme urobiť, je skontrolovať, či je stále v rozsahu
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}