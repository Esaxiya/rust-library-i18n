//! Zliatina Prelude
//!
//! Účelom tohto modulu je zmierniť import bežne používaných položiek modelu `alloc` crate pridaním globálneho importu do hornej časti modulov:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;