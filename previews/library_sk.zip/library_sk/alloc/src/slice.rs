//! Dynamicky veľký pohľad do súvislej postupnosti, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Plátky sú pohľad do bloku pamäte predstavovaný ako ukazovateľ a dĺžka.
//!
//! ```
//! // krájanie Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // vynútenie poľa na plátok
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Plátky sú buď meniteľné, alebo zdieľané.
//! Zdieľaný typ rezu je `&[T]`, zatiaľ čo typ premenlivého segmentu je `&mut [T]`, kde `T` predstavuje typ prvku.
//! Môžete napríklad mutovať blok pamäte, na ktorý ukazuje premenlivý rez:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Tu sú niektoré z vecí, ktoré tento modul obsahuje:
//!
//! ## Structs
//!
//! Existuje niekoľko štruktúr, ktoré sú užitočné pre rezy, napríklad [`Iter`], čo predstavuje iteráciu nad rezom.
//!
//! ## Implementácie Trait
//!
//! Existuje niekoľko implementácií bežných traits pre plátky.Niektoré príklady:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], na rezy, ktorých typ prvku je [`Eq`] alebo [`Ord`].
//! * [`Hash`] - pre plátky, ktorých typ prvku je [`Hash`].
//!
//! ## Iteration
//!
//! Plátky implementujú `IntoIterator`.Iterátor poskytuje odkazy na prvky rezu.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Premenlivý rez poskytuje premenlivé odkazy na prvky:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Tento iterátor poskytuje premenlivé odkazy na prvky rezu, takže zatiaľ čo typ prvku rezu je `i32`, typ prvku iterátora je `&mut i32`.
//!
//!
//! * [`.iter`] a [`.iter_mut`] sú explicitné metódy na vrátenie predvolených iterátorov.
//! * Ďalšie metódy, ktoré vracajú iterátory, sú [`.split`], [`.splitn`], [`.chunks`], [`.windows`] a ďalšie.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Mnoho použití v tomto module sa používa iba v testovacej konfigurácii.
// Je čistejšie iba vypnúť varovanie nepoužívaných_importov, než ich opraviť.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Základné metódy rozšírenia rezov
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) potrebné na implementáciu makra `vec!` počas testovania NB, ďalšie podrobnosti nájdete v module `hack` v tomto súbore.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) potrebné na implementáciu `Vec::clone` počas testovania NB, ďalšie podrobnosti nájdete v module `hack` v tomto súbore.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Pretože cfg(test) `impl [T]` nie je k dispozícii, tieto tri funkcie sú vlastne metódami, ktoré sú v `impl [T]`, ale nie v `core::slice::SliceExt`, musíme tieto funkcie dodať pre test `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Nemali by sme k tomu pridávať vložený atribút, pretože sa používa väčšinou v makre `vec!` a spôsobuje regresiu.
    // Pozri #71204 pre diskusiu a výsledky perf.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // položky boli označené inicializované v slučke nižšie
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) je nevyhnutný pre LLVM na odstránenie hraničných kontrol a má lepší kódex ako zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec bola pridelená a inicializovaná vyššie aspoň na túto dĺžku.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // alokované vyššie s kapacitou `s` a inicializovať na `s.len()` v ptr::copy_to_non_overlapping nižšie.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Triedi plátok.
    ///
    /// Tento druh je stabilný (tj. Nemení poradie rovnakých prvkov) a *O*(*n*\*log(* n*)) najhorší prípad).
    ///
    /// Ak je to vhodné, uprednostňuje sa nestabilné triedenie, pretože je zvyčajne rýchlejšie ako stabilné triedenie a neprideľuje pomocnú pamäť.
    /// Pozri [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je adaptívny, iteračný spôsob zlučovania inšpirovaný [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Je navrhnutý tak, aby bol veľmi rýchly v prípadoch, keď je plátok takmer zoradený alebo pozostáva z dvoch alebo viacerých triedených sekvencií zreťazených jedna za druhou.
    ///
    ///
    /// Alokuje tiež dočasné úložisko o polovicu menšie ako `self`, ale pre krátke plátky sa namiesto nich použije druh nepridelenia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Zoradí plátok podľa funkcie komparátora.
    ///
    /// Tento druh je stabilný (tj. Nemení poradie rovnakých prvkov) a *O*(*n*\*log(* n*)) najhorší prípad).
    ///
    /// Funkcia komparátora musí definovať celkové usporiadanie prvkov v reze.Ak objednávka nie je celková, nie je určené poradie prvkov.
    /// Objednávka je celková objednávka, ak je (pre všetky modely `a`, `b` a `c`):
    ///
    /// * celkový a antisymetrický: presne jeden z `a < b`, `a == b` alebo `a > b` je pravdivý a
    /// * tranzitívne, `a < b` a `b < c` znamená `a < c`.To isté musí platiť pre `==` aj `>`.
    ///
    /// Napríklad zatiaľ čo [`f64`] neimplementuje [`Ord`], pretože `NaN != NaN`, môžeme použiť `partial_cmp` ako našu funkciu triedenia, keď vieme, že rez neobsahuje `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Ak je to vhodné, uprednostňuje sa nestabilné triedenie, pretože je zvyčajne rýchlejšie ako stabilné triedenie a neprideľuje pomocnú pamäť.
    /// Pozri [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je adaptívny, iteračný spôsob zlučovania inšpirovaný [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Je navrhnutý tak, aby bol veľmi rýchly v prípadoch, keď je plátok takmer zoradený alebo pozostáva z dvoch alebo viacerých triedených sekvencií zreťazených jedna za druhou.
    ///
    /// Alokuje tiež dočasné úložisko o polovicu menšie ako `self`, ale pre krátke plátky sa namiesto nich použije druh nepridelenia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // spätné triedenie
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Triedi plátok pomocou funkcie extrakcie klávesov.
    ///
    /// Tento druh je stabilný (tj. Nemení poradie rovnakých prvkov) a *O*(*m*\* * n *\* log(*n*)) najhorší prípad, kde je kľúčová funkcia *O*(*m*).
    ///
    /// Pre drahé kľúčové funkcie (napr
    /// funkcie, ktoré nie sú jednoduchými prístupmi k vlastnostiam alebo základnými operáciami), [`sort_by_cached_key`](slice::sort_by_cached_key) bude pravdepodobne podstatne rýchlejší, pretože neprepočíta kľúče prvkov.
    ///
    ///
    /// Ak je to vhodné, uprednostňuje sa nestabilné triedenie, pretože je zvyčajne rýchlejšie ako stabilné triedenie a neprideľuje pomocnú pamäť.
    /// Pozri [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je adaptívny, iteračný spôsob zlučovania inšpirovaný [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Je navrhnutý tak, aby bol veľmi rýchly v prípadoch, keď je plátok takmer zoradený alebo pozostáva z dvoch alebo viacerých triedených sekvencií zreťazených jedna za druhou.
    ///
    /// Alokuje tiež dočasné úložisko o polovicu menšie ako `self`, ale pre krátke plátky sa namiesto nich použije druh nepridelenia.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Triedi plátok pomocou funkcie extrakcie klávesov.
    ///
    /// Počas triedenia sa funkcia klávesu vyvolá na jeden prvok iba raz.
    ///
    /// Tento druh je stabilný (tj. Nemení poradie rovnakých prvkov) a *O*(*m*\* * n *+* n *\* log(*n*)) najhorší prípad, kde je kľúčová funkcia *O*(*m*) .
    ///
    /// Pre jednoduché kľúčové funkcie (napr. Funkcie, ktoré sú prístupom k vlastnostiam alebo základnými operáciami) bude [`sort_by_key`](slice::sort_by_key) pravdepodobne rýchlejší.
    ///
    /// # Súčasná implementácia
    ///
    /// Aktuálny algoritmus je založený na [pattern-defeating quicksort][pdqsort] od Orsona Petersa, ktorý kombinuje rýchly priemerný prípad randomizovaného quicksortu s najhorším najhorším prípadom heapsortu, pričom dosahuje lineárny čas na rezoch s určitými vzormi.
    /// Využíva určitú randomizáciu, aby sa zabránilo degenerovaným prípadom, ale s pevným seed vždy poskytuje deterministické správanie.
    ///
    /// V najhoršom prípade algoritmus alokuje dočasné úložisko v `Vec<(K, usize)>` na dĺžku rezu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Pomocné makro na indexovanie nášho vector čo najmenším možným typom, aby sa znížila alokácia.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Prvky `indices` sú jedinečné, pretože sú indexované, takže akýkoľvek druh bude stabilný vzhľadom na pôvodný rez.
                // Používame tu `sort_unstable`, pretože to vyžaduje menej alokácie pamäte.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopíruje `self` do nového `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Tu je možné `s` a `x` modifikovať nezávisle.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopíruje `self` do nového `Vec` s alokátorom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Tu je možné `s` a `x` modifikovať nezávisle.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, pozrite si modul `hack` v tomto súbore, kde nájdete ďalšie podrobnosti.
        hack::to_vec(self, alloc)
    }

    /// Skonvertuje `self` na vector bez klonov alebo alokácie.
    ///
    /// Výsledný vector je možné previesť späť do škatule pomocou `Vec<T>" je metóda `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` sa už nedá použiť, pretože bol prevedený na `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, pozrite si modul `hack` v tomto súbore, kde nájdete ďalšie podrobnosti.
        hack::into_vec(self)
    }

    /// Vytvorí vector opakovaním rezu `n` krát.
    ///
    /// # Panics
    ///
    /// Táto funkcia bude panic, ak by kapacita pretiekla.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic pri pretečení:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Ak je `n` väčšia ako nula, dá sa rozdeliť ako `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` je číslo predstavované najviac '1' bitom `n` vľavo a `rem` je zvyšná časť `n`.
        //
        //

        // Používanie `Vec` na prístup k `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` opakovanie sa deje zdvojnásobením " expn`-krát `buf`.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Ak je `m > 0`, zostávajú bity až po úplne ľavú '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` má kapacitu `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) opakovanie sa vykonáva kopírovaním prvých opakovaní `rem` zo samotného `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // To sa od `2^expn > rem` neprekrýva.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` sa rovná `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Zarovná plátok `T` na jednu hodnotu `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Zarovná plátok `T` na jednu hodnotu `Self::Output` a medzi každú umiestni daný oddeľovač.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Zarovná plátok `T` na jednu hodnotu `Self::Output` a medzi každú umiestni daný oddeľovač.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Vráti vector obsahujúci kópiu tohto rezu, kde je každý bajt namapovaný na jeho ekvivalent ASCII s veľkými písmenami.
    ///
    ///
    /// Písmená ASCII 'a' až 'z' sú namapované na 'A' až 'Z', ale písmená iné ako ASCII sa nezmenia.
    ///
    /// Na veľké napísanie hodnoty na mieste použite [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Vráti vector obsahujúci kópiu tohto rezu, kde je každý bajt namapovaný na jeho ekvivalent ASCII malými písmenami.
    ///
    ///
    /// Písmená ASCII 'A' až 'Z' sú namapované na 'a' až 'z', ale písmená iné ako ASCII sa nezmenia.
    ///
    /// Ak chcete malú hodnotu vložiť na miesto, použite [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Rozšírenie traits pre segmenty nad konkrétnymi druhmi údajov
////////////////////////////////////////////////////////////////////////////////

/// Pomocník trait pre [`[T]: : concat`](slice::concat).
///
/// Note: parameter typu `Item` sa v tejto trait nepoužíva, ale umožňuje to byť všeobecnejšie.
/// Bez toho dostaneme túto chybu:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Je to preto, že by mohli existovať typy `V` s viacerými implikáciami `Borrow<[_]>`, takže by platilo viac typov `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Výsledný typ po zreťazení
    type Output;

    /// Implementácia [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Pomocník trait pre [`[T]: : join`](slice::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Výsledný typ po zreťazení
    type Output;

    /// Implementácia [`[T]: : join`](slice::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Štandardné implementácie trait pre rezy
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // umiestnite na cieľ čokoľvek, čo sa neprepíše
        target.truncate(self.len());

        // target.len <= self.len z dôvodu skrátenia vyššie, takže tu sú rezy vždy v medziach.
        //
        let (init, tail) = self.split_at(target.len());

        // znovu použite obsiahnuté hodnoty allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Vloží `v[0]` do vopred vytriedenej sekvencie `v[1..]`, aby sa roztriedil celý `v[..]`.
///
/// Toto je integrálny podprogram triedenia vloženia.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Existujú tri spôsoby, ako tu implementovať:
            //
            // 1. Zamieňajte susedné prvky, kým sa prvý nedostane do svojho konečného cieľa.
            //    Týmto spôsobom však kopírujeme údaje viac, ako je potrebné.
            //    Ak sú prvky veľké štruktúry (kopírovanie je nákladné), bude tento spôsob pomalý.
            //
            // 2. Iterujte, kým nenájdete správne miesto pre prvý prvok.
            // Potom posuňte nasledujúce prvky, aby ste uvoľnili miesto pre ňu, a nakoniec ju vložte do zvyšnej diery.
            // Toto je dobrá metóda.
            //
            // 3. Skopírujte prvý prvok do dočasnej premennej.Iterujte, kým nenájdete správne miesto.
            // Keď ideme ďalej, skopírujte každý prekonaný prvok do slotu pred ním.
            // Nakoniec skopírujte údaje z dočasnej premennej do zostávajúcej diery.
            // Táto metóda je veľmi dobrá.
            // Benchmarky preukázali mierne lepší výkon ako pri 2. metóde.
            //
            // Všetky metódy boli porovnané a tretia ukázala najlepšie výsledky.Takže sme si vybrali ten.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Stredný stav procesu vkladania vždy sleduje `hole`, ktorý slúži na dva účely:
            // 1. Chráni integritu `v` pred panics v `is_less`.
            // 2. Nakoniec vyplní zvyšnú dieru v `v`.
            //
            // Bezpečnosť Panic:
            //
            // Ak `is_less` panics kedykoľvek počas procesu dôjde k spadnutiu `hole` a vyplní dieru v `v` `tmp`, zaistí sa tak, že `v` bude mať stále každý objekt, ktorý pôvodne obsahoval, presne raz.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` spadne a tým skopíruje `tmp` do zostávajúcej diery v `v`.
        }
    }

    // Po páde kópie z `src` do `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Zlúči neklesajúce spustenia `v[..mid]` a `v[mid..]` s použitím `buf` ako dočasného úložiska a výsledok uloží do `v[..]`.
///
/// # Safety
///
/// Dva rezy musia byť neprázdne a `mid` musí byť v medziach.
/// Buffer `buf` musí byť dostatočne dlhý na to, aby pojal kópiu kratšieho rezu.
/// `T` tiež nesmie byť nulového typu.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Proces zlúčenia najskôr skopíruje kratší chod do `buf`.
    // Potom sleduje novo kopírovaný chod a dlhší chod dopredu (alebo dozadu), porovnáva ich ďalšie nespotrebované prvky a menší (alebo väčší) kopíruje do `v`.
    //
    // Akonáhle je kratší chod úplne spotrebovaný, proces je hotový.Ak sa najskôr spotrebuje dlhší cyklus, potom musíme do zvyšnej diery v `v` skopírovať všetko, čo zostane z kratšieho cyklu.
    //
    // Stredný stav procesu vždy sleduje `hole`, ktorý slúži na dva účely:
    // 1. Chráni integritu `v` pred panics v `is_less`.
    // 2. Vyplní zostávajúcu jamku v `v`, ak sa najskôr spotrebuje dlhší cyklus.
    //
    // Bezpečnosť Panic:
    //
    // Ak `is_less` panics kedykoľvek počas procesu, `hole` spadne a vyplní dieru v `v` nespotrebovaným rozsahom v `buf`, čím zaistí, že `v` bude mať stále každý objekt, ktorý pôvodne obsahoval, presne raz.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Ľavý beh je kratší.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Tieto ukazovatele spočiatku poukazujú na začiatky ich polí.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Spotrebujte menšiu stranu.
            // Ak sú rovnaké, pre udržanie stability uprednostnite chod vľavo.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Správny beh je kratší.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Spočiatku tieto ukazovatele smerujú za konce ich polí.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Konzumujte väčšiu stranu.
            // Ak sú rovnaké, uprednostnite správny beh, aby ste udržali stabilitu.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Nakoniec `hole` vypadne.
    // Ak kratší chod nebol úplne spotrebovaný, všetko, čo z neho zostane, sa teraz skopíruje do otvoru v `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Pri páde skopíruje rozsah `start..end` do `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` nie je nulového typu, takže je v poriadku deliť ho podľa veľkosti.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Toto zlúčenie si požičia niektoré (ale nie všetky) nápady od spoločnosti TimSort, ktorá je podrobne popísaná v [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritmus identifikuje striktne zostupné a neklesajúce subsekvencie, ktoré sa nazývajú prirodzené behy.Existuje ešte hromada čakajúcich behov, ktoré sa majú zlúčiť.
/// Každý novo nájdený beh je vložený do zásobníka a potom sú párované dvojice susedných cyklov zlúčené, kým nie sú uspokojené tieto dva invarianty:
///
/// 1. pre každý `i` v `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. pre každý `i` v `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invarianty zabezpečujú, že celková doba chodu je *O*(*n*\*log(* n*)) najhorší prípad.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Plátky až do tejto dĺžky sa zoradia pomocou triedenia podľa vloženia.
    const MAX_INSERTION: usize = 20;
    // Veľmi krátke cykly sa rozširujú pomocou triedenia vloženia tak, aby zahŕňalo aspoň tento počet prvkov.
    const MIN_RUN: usize = 10;

    // U typov nulovej veľkosti nemá triedenie nijaké zmysluplné správanie.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Krátke polia sa triedia na mieste prostredníctvom triedenia vkladania, aby sa zabránilo alokáciám.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Pridelte vyrovnávaciu pamäť, ktorá sa použije ako pomocná pamäť.Ponechávame dĺžku 0, aby sme v nej mohli uchovávať plytké kópie obsahu `v` bez toho, aby sme riskovali spustenie dtors na kópiách, ak `is_less` panics.
    //
    // Pri zlúčení dvoch triedených cyklov obsahuje táto vyrovnávacia pamäť kópiu kratšieho cyklu, ktorý bude mať vždy dĺžku najviac `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Aby sme mohli identifikovať prirodzené behy v `v`, prechádzame ich dozadu.
    // To by sa mohlo zdať ako čudné rozhodnutie, ale zvážte skutočnosť, že zlúčenie sa deje častejšie opačným smerom ako (forwards).
    // Podľa referenčných kritérií je zlúčenie dopredu mierne rýchlejšie ako zlúčenie dozadu.
    // Záverom je, že identifikácia behov traverzom dozadu zlepšuje výkon.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Nájdite ďalší prirodzený beh a ak prísne klesá, obráťte ho.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Ak je to príliš krátke, vložte do chodu ďalšie prvky.
        // Zoradenie vloženia je rýchlejšie ako zlučovanie zoradenia v krátkych sekvenciách, čo výrazne zvyšuje výkon.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Zatlačte tento chod na stoh.
        runs.push(Run { start, len: end - start });
        end = start;

        // Spojte niekoľko párov susedných behov, aby ste uspokojili invarianty.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Nakoniec v zásobníku musí zostať presne jeden chod.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Preskúma hromadu behov a identifikuje ďalšiu dvojicu behov, ktoré sa majú zlúčiť.
    // Presnejšie, ak sa vráti `Some(r)`, znamená to, že `runs[r]` a `runs[r + 1]` musia byť zlúčené ako ďalšie.
    // Ak by algoritmus mal namiesto toho pokračovať v vytváraní nového behu, vráti sa `None`.
    //
    // TimSort je neslávne známy pre svoje buggy implementácie, ako je popísané tu:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Podstata príbehu je: musíme presadiť invarianty na prvých štyroch priečkach v zásobníku.
    // Ich vynútenie iba na prvých troch nie je dostatočné na zabezpečenie toho, že invarianty budú stále držať *všetky* behy v zásobníku.
    //
    // Táto funkcia správne kontroluje invarianty pre štyri najlepšie cykly.
    // Okrem toho, ak horná časť cyklu začína na indexe 0, bude na dokončenie zoradenia vždy vyžadovať operáciu zlúčenia, kým sa zásobník úplne nezbalí.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}