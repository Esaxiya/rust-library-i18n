use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Písanie testu integrácie medzi alokátormi tretích strán a `RawVec` je trochu zložité, pretože `RawVec` API nevystavuje omylné alokačné metódy, takže nemôžeme skontrolovať, čo sa stane, keď je alokátor vyčerpaný (okrem detekcie panic).
    //
    //
    // Namiesto toho sa tým iba kontroluje, či metódy `RawVec` pri rezervácii úložiska aspoň prechádzajú cez Allocator API.
    //
    //
    //
    //
    //

    // Tichý prideľovač, ktorý spotrebuje fixné množstvo paliva predtým, ako začnú zlyhávať pokusy o pridelenie.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (spôsobí realokáciu, teda použitie 50 + 150=200 jednotiek paliva)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // Najskôr sa `reserve` alokuje ako `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 je viac ako dvojnásobok 7, takže `reserve` by mal fungovať ako `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 je menej ako polovica z 12, takže `reserve` musí rásť exponenciálne.
        // V čase písania tohto testu bol rastový faktor 2, takže nová kapacita je 24, rastový faktor 1.5 je však tiež v poriadku.
        //
        // Preto `>= 18` v tvrdení.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}