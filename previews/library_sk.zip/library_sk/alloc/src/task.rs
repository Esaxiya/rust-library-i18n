#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typy a Traits na prácu s asynchrónnymi úlohami.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Implementácia prebudenia úlohy na exekútora.
///
/// Tento trait sa dá použiť na vytvorenie [`Waker`].
/// Exekútor môže definovať implementáciu tohto trait a použiť ho na skonštruovanie Wakera, aby prešiel na úlohy, ktoré sa na tomto exekútorovi vykonávajú.
///
/// Tento trait je pamäťovo bezpečná a ergonomická alternatíva ku konštrukcii modelu [`RawWaker`].
/// Podporuje spoločný návrh vykonávateľa, v ktorom sú údaje použité na prebudenie úlohy uložené v pamäti [`Arc`].
/// Niektorí vykonávatelia (najmä pre vstavané systémy) nemôžu toto API používať, a preto pre tieto systémy existuje alternatíva [`RawWaker`].
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Základná funkcia `block_on`, ktorá prevezme future a spustí ju až do konca v aktuálnom vlákne.
///
/// **Note:** V tomto príklade sa kvôli jednoduchosti vymieňa správnosť.
/// Aby sa zabránilo zablokovaniu, implementácie na úrovni výroby budú musieť spracovať aj medzilehlé volania na `thread::unpark`, ako aj vnorené vyvolania.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Budič, ktorý pri volaní prebudí súčasné vlákno.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Spustite future do dokončenia v aktuálnom vlákne.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pripnite future, aby bolo možné ho poľovať.
///     let mut fut = Box::pin(fut);
///
///     // Vytvorte nový kontext, ktorý sa má odovzdať future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Spustite future až do konca.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Prebuďte túto úlohu.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Prebuďte túto úlohu bez toho, aby ste spotrebovali buditeľa.
    ///
    /// Ak exekútor podporuje lacnejší spôsob prebudenia bez konzumácie buditeľa, mal by túto metódu prekonať.
    /// V predvolenom nastavení klonuje [`Arc`] a volá [`wake`] v klone.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // BEZPEČNOSŤ: Je to bezpečné, pretože raw_waker bezpečne vytvára
        // RawWaker z Arku<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Táto súkromná funkcia na zostavenie RawWakeru sa používa skôr ako
// vložením do `From<Arc<W>> for RawWaker` impl, aby sa zabezpečilo, že bezpečnosť `From<Arc<W>> for Waker` nezávisí od správneho odoslania trait, namiesto toho oba impls volajú túto funkciu priamo a explicitne.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Ak chcete klonovať, zvýšte referenčný počet oblúkov.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Prebuďte sa podľa hodnoty a posuňte oblúk do funkcie Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Zobuďte sa referenciou, zabaľovač zabaľte do balíka ManuallyDrop, aby vám nepadol
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Znížte referenčný počet oblúkov pri poklese
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}