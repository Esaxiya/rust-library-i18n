//! Pestovateľný reťazec kódovaný UTF-8.
//!
//! Tento modul obsahuje typ [`String`], [`ToString`] trait na konverziu na reťazce a niekoľko typov chýb, ktoré môžu vyplynúť z práce s [" String`] s.
//!
//!
//! # Examples
//!
//! Existuje niekoľko spôsobov, ako vytvoriť nový [`String`] z reťazcového literálu:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Novú [`String`] môžete vytvoriť z existujúcej zreťazením pomocou
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Ak máte vector platných bajtov UTF-8, môžete z nich vytvoriť [`String`].Môžete to urobiť aj naopak.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Vieme, že tieto bajty sú platné, takže použijeme `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Pestovateľný reťazec kódovaný UTF-8.
///
/// Typ `String` je najbežnejší typ reťazca, ktorý vlastní obsah reťazca.Má úzky vzťah so svojím požičaným náprotivkom, primitívom [`str`].
///
/// # Examples
///
/// Môžete vytvoriť `String` z [a literal string][`str`] s [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// [`char`] môžete pripojiť k `String` pomocou metódy [`push`] a [`&str`] môžete pridať pomocou metódy [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Ak máte vector bajtov UTF-8, môžete z neho vytvoriť `String` pomocou metódy [`from_utf8`]:
///
/// ```
/// // nejaké bajty, v vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vieme, že tieto bajty sú platné, takže použijeme `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Reťazce sú vždy platné UTF-8.To má niekoľko dôsledkov, z ktorých prvý je, že ak potrebujete reťazec, ktorý nie je UTF-8, zvážte [`OsString`].Je to podobné, ale bez obmedzenia UTF-8.Druhým dôsledkom je, že nemôžete indexovať do `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexovanie má byť operáciou v konštantnom čase, ale kódovanie UTF-8 nám to neumožňuje.Ďalej nie je jasné, čo by mal index vrátiť: bajt, kódový bod alebo klaster grafém.
/// Metódy [`bytes`] a [`chars`] vracajú iterátory po prvých dvoch.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `Reťazcový implementovať [` Deref`]`<Target=str>`, a tak zdediť všetky metódy [` str`]].To navyše znamená, že môžete odovzdať `String` funkcii, ktorá zaberá [`&str`], pomocou ampersandu (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Toto vytvorí [`&str`] z `String` a odovzdá ho ďalej. Táto konverzia je veľmi lacná, a tak všeobecne budú funkcie akceptovať [" &str`] s ako argumenty, pokiaľ `String` z nejakého konkrétneho dôvodu nepotrebujú.
///
/// V určitých prípadoch nemá Rust dostatok informácií na uskutočnenie tejto konverzie, známej ako nátlak [`Deref`].V nasledujúcom príklade reťazcový rez [`&'a str`][`&str`] implementuje trait `TraitExample` a funkcia `example_func` preberá všetko, čo implementuje trait.
/// V takom prípade by Rust musel urobiť dve implicitné konverzie, na ktoré Rust nemá prostriedky.
/// Z tohto dôvodu sa nasledujúci príklad nebude kompilovať.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Namiesto toho by existovali dve možnosti.Prvou by bola zmena riadku `example_func(&example_string);` na `example_func(example_string.as_str());` pomocou metódy [`as_str()`] na výslovné extrahovanie reťazca obsahujúceho reťazec.
/// Druhý spôsob mení `example_func(&example_string);` na `example_func(&*example_string);`.
/// V tomto prípade dereferujeme `String` na [`str`][`&str`] a potom odkazujeme na [`str`][`&str`] späť na [`&str`].
/// Druhá cesta je idiomatickejšia, obaja však pracujú na uskutočnení konverzie skôr, než aby sa spoliehali na implicitnú konverziu.
///
/// # Representation
///
/// `String` sa skladá z troch komponentov: ukazovateľ na niektoré bajty, dĺžka a kapacita.Ukazovateľ smeruje na internú medzipamäť, ktorú `String` používa na ukladanie svojich údajov.Dĺžka predstavuje počet bajtov aktuálne uložených vo vyrovnávacej pamäti a kapacita predstavuje veľkosť vyrovnávacej pamäte v bajtoch.
///
/// Dĺžka bude ako taká vždy menšia alebo rovná kapacite.
///
/// Táto vyrovnávacia pamäť je vždy uložená na halde.
///
/// Môžete sa na ne pozrieť metódami [`as_ptr`], [`len`] a [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Aktualizujte to, keď je stabilizovaná vec_into_raw_parts.
/// // Zabráňte automatickému vypusteniu údajov reťazca
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // príbeh má devätnásť bajtov
/// assert_eq!(19, len);
///
/// // Môžeme znova vytvoriť reťazec z ptr, len a kapacity.
/// // To všetko nie je bezpečné, pretože sme zodpovední za zaistenie platnosti komponentov:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Ak má `String` dostatočnú kapacitu, pridaním prvkov sa znova nepridelí.Zvážte napríklad tento program:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Takto sa vygeneruje toto:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Spočiatku nemáme pridelenú vôbec žiadnu pamäť, ale keď sa pripojíme k reťazcu, primerane zvýši jeho kapacitu.Ak namiesto toho použijeme metódu [`with_capacity`] na počiatočné pridelenie správnej kapacity:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Nakoniec skončíme s iným výstupom:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Tu nie je potrebné vo vnútri slučky alokovať viac pamäte.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Možná hodnota chyby pri prevode `String` z UTF-8 bajtu vector.
///
/// Tento typ je typ chyby pre metódu [`from_utf8`] na [`String`].
/// Je navrhnutý tak, aby sa opatrne vyhlo realokáciám: metóda [`into_bytes`] vráti bajt vector, ktorý bol použitý pri pokuse o konverziu.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Typ [`Utf8Error`] poskytovaný [`std::str`] predstavuje chybu, ktorá sa môže vyskytnúť pri prevode rezu ["u8"] s na [`&str`].
/// V tomto zmysle je to analóg k `FromUtf8Error` a jeden môžete získať z `FromUtf8Error` metódou [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Základné použitie:
///
/// ```
/// // nejaké neplatné bajty, v vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Možná hodnota chyby pri konverzii `String` z bajtového rezu UTF-16.
///
/// Tento typ je typ chyby pre metódu [`from_utf16`] na [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Základné použitie:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Vytvorí nový prázdny `String`.
    ///
    /// Vzhľadom na to, že `String` je prázdny, nebude mu pridelená žiadna počiatočná vyrovnávacia pamäť.Aj keď to znamená, že táto počiatočná operácia je veľmi lacná, môže neskôr spôsobiť nadmerné pridelenie, keď pridáte údaje.
    ///
    /// Ak máte predstavu o tom, koľko údajov bude mať `String`, zvážte metódu [`with_capacity`], aby ste zabránili nadmernému opätovnému prideľovaniu.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Vytvorí nový prázdny `String` s konkrétnou kapacitou.
    ///
    /// `Reťazec má internú medzipamäť na uchovanie ich údajov.
    /// Kapacita je dĺžka daného bufferu a dá sa na ňu dopytovať metódou [`capacity`].
    /// Táto metóda vytvorí prázdny `String`, ale jeden s počiatočným bufferom, ktorý pojme `capacity` bajtov.
    /// Je to užitočné, keď k `String` môžete pripájať množstvo údajov, čím sa zníži počet opätovných pridelení, ktoré je potrebné vykonať.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Ak je daná kapacita `0`, k alokácii nedôjde a táto metóda je totožná s metódou [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String neobsahuje žiadne znaky, aj keď má kapacitu na viac
    /// assert_eq!(s.len(), 0);
    ///
    /// // To všetko sa deje bez prerozdelenia ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ale to môže spôsobiť opätovné pridelenie reťazca
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): s cfg(test) nie je k dispozícii inherentná metóda `[T]::to_vec`, ktorá je vyžadovaná pre túto definíciu metódy.
    // Pretože túto metódu na testovacie účely nevyžadujeme, jednoducho ju vložím na vedomie. Viac informácií nájdete v module slice::hack v slice.rs.
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Prevedie vector bajtov na `String`.
    ///
    /// Reťazec ([`String`]) je vyrobený z bajtov ([`u8`]) a vector bajtov ([`Vec<u8>`]) je vyrobený z bajtov, takže táto funkcia prevádza medzi nimi dva.
    /// Nie všetky rezy bajtov sú platné " reťazce`: `String` vyžaduje, aby boli platné UTF-8.
    /// `from_utf8()` skontroluje, či sú bajty platné UTF-8, a vykoná konverziu.
    ///
    /// Ak ste si istí, že bajtový segment je platný UTF-8 a nechcete znášať réžiu kontroly platnosti, existuje nebezpečná verzia tejto funkcie, [`from_utf8_unchecked`], ktorá sa chová rovnako, ale kontrolu preskočí.
    ///
    ///
    /// Táto metóda sa kvôli efektivite postará o to, aby ste nekopírovali vector.
    ///
    /// Ak potrebujete [`&str`] namiesto `String`, zvážte [`str::from_utf8`].
    ///
    /// Inverzná hodnota tejto metódy je [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Vráti [`Err`], ak rez nie je UTF-8 s popisom, prečo poskytnuté bajty nie sú UTF-8.Zahrnutý je aj vector, do ktorého ste sa nasťahovali.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // nejaké bajty, v vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Vieme, že tieto bajty sú platné, takže použijeme `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Nesprávne bajty:
    ///
    /// ```
    /// // nejaké neplatné bajty, v vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Ďalšie informácie o tom, čo môžete robiť s touto chybou, nájdete v dokumentoch pre [`FromUtf8Error`].
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Skonvertuje plátok bajtov na reťazec vrátane neplatných znakov.
    ///
    /// Reťazce sú tvorené z bajtov ([`u8`]) a výrez bajtov ([`&[u8]`][byteslice]) je tvorený z bajtov, takže táto funkcia prevádza medzi týmito dvoma.Nie všetky bajtové rezy sú však platné reťazce: reťazce musia byť platné ako UTF-8.
    /// Počas tejto konverzie `from_utf8_lossy()` nahradí všetky neplatné sekvencie UTF-8 [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], ktoré vyzerajú takto:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Ak ste si istí, že bajtový segment je platný UTF-8 a nechcete znášať réžiu konverzie, existuje nebezpečná verzia tejto funkcie, [`from_utf8_unchecked`], ktorá sa chová rovnako, ale kontroly preskočí.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Táto funkcia vráti [`Cow<'a, str>`].Ak je náš bajtový rez neplatný UTF-8, musíme vložiť náhradné znaky, ktoré zmenia veľkosť reťazca, a teda budú vyžadovať `String`.
    /// Ak už ale platí UTF-8, nové pridelenie nepotrebujeme.
    /// Tento návratový typ nám umožňuje vybaviť oba prípady.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // nejaké bajty, v vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Nesprávne bajty:
    ///
    /// ```
    /// // nejaké neplatné bajty
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekódujte kódovaný kód UTF-16 vector `v` na `String`. Ak `v` obsahuje neplatné údaje, vráti [`Err`].
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Toto sa nedeje cez collect: : <Result<_, _>> () z výkonnostných dôvodov.
        // FIXME: funkcia môže byť opäť zjednodušená, keď je #48994 zatvorený.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dekódujte plátok `v` kódovaný UTF-16 na `String` a neplatné údaje nahraďte [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Na rozdiel od [`from_utf8_lossy`], ktorý vracia [`Cow<'a, str>`], `from_utf16_lossy` vracia `String`, pretože konverzia UTF-16 na UTF-8 vyžaduje pridelenie pamäte.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Rozkladá `String` na svoje nespracované komponenty.
    ///
    /// Vráti nespracovaný ukazovateľ na podkladové údaje, dĺžku reťazca (v bajtoch) a pridelenú kapacitu údajov (v bajtoch).
    /// Sú to rovnaké argumenty v rovnakom poradí ako argumenty pre [`from_raw_parts`].
    ///
    /// Po vyvolaní tejto funkcie je volajúci zodpovedný za pamäť predtým spravovanú `String`.
    /// Jediným spôsobom, ako to urobiť, je previesť nespracovaný ukazovateľ, dĺžku a kapacitu späť na `String` pomocou funkcie [`from_raw_parts`], čo umožní deštruktoru vyčistiť.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Vytvorí nový `String` z dĺžky, kapacity a ukazovateľa.
    ///
    /// # Safety
    ///
    /// Toto je veľmi nebezpečné z dôvodu počtu nekontrolovaných invariantov:
    ///
    /// * Pamäť v `buf` musí byť predtým alokovaná rovnakým alokátorom, aký používa štandardná knižnica, s požadovaným zarovnaním presne na 1.
    /// * `length` musí byť menšia alebo rovná `capacity`.
    /// * `capacity` musí byť správna hodnota.
    /// * Prvé bajty `length` v `buf` musia byť platné UTF-8.
    ///
    /// Ich porušenie môže spôsobiť problémy, ako napríklad poškodenie vnútorných štruktúr údajov alokátora.
    ///
    /// Vlastníctvo `buf` sa efektívne prevedie na `String`, ktorý potom môže prideliť, prerozdeliť alebo zmeniť obsah pamäte, na ktorý bude ukazovateľ ľubovoľne smerovať.
    /// Zaistite, aby po vyvolaní tejto funkcie nič iné nepoužilo ukazovateľ.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Aktualizujte to, keď je stabilizovaná vec_into_raw_parts.
    ///     // Zabráňte automatickému vypusteniu údajov reťazca
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Prevedie vector bajtov na `String` bez kontroly, či reťazec obsahuje platných UTF-8.
    ///
    /// Ďalšie informácie nájdete v bezpečnej verzii [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Táto funkcia je nebezpečná, pretože nekontroluje, či sú jej odovzdané bajty platné UTF-8.
    /// Ak je toto obmedzenie porušené, môže to spôsobiť problémy s bezpečnosťou pamäte u používateľov future `String`, pretože zvyšok štandardnej knižnice predpokladá, že reťazce " String` sú platné UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // nejaké bajty, v vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Skonvertuje `String` na bajt vector.
    ///
    /// Toto spotrebúva `String`, takže nemusíme kopírovať jeho obsah.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Extrahuje rez reťazca obsahujúci celú `String`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Skonvertuje `String` na premenlivý rez reťazca.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Pripojí daný rez reťazca na koniec tohto `String`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Vráti kapacitu tohto " reťazca` v bajtoch.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Zaisťuje, aby kapacita tohto reťazca bola minimálne o `additional` bajtov väčšia ako jeho dĺžka.
    ///
    /// Ak sa tak rozhodne, kapacita sa môže zvýšiť o viac ako `additional` bajtov, aby sa zabránilo častým opätovným prideleniam.
    ///
    ///
    /// Ak nechcete toto správanie "at least", pozrite si metódu [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics, ak nová kapacita pretečie [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Toto nemusí skutočne zvýšiť kapacitu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s má teraz dĺžku 2 a kapacitu 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Pretože už máme ďalších 8 kapacít, volá sa toto ...
    /// s.reserve(8);
    ///
    /// // ... v skutočnosti sa nezvyšuje.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Zaisťuje, že kapacita tohto reťazca je o `additional` bajtov väčšia ako jeho dĺžka.
    ///
    /// Zvážte použitie metódy [`reserve`], pokiaľ absolútne neviete lepšie ako alokátor.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, ak nová kapacita pretečie `usize`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Toto nemusí skutočne zvýšiť kapacitu:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s má teraz dĺžku 2 a kapacitu 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Pretože už máme ďalších 8 kapacít, volá sa toto ...
    /// s.reserve_exact(8);
    ///
    /// // ... v skutočnosti sa nezvyšuje.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Pokúša sa vyhradiť kapacitu najmenej pre `additional` ďalších prvkov, ktoré sa majú vložiť do daného `String`.
    /// Zbierka môže vyhradiť viac miesta, aby sa zabránilo častému prerozdeľovaniu.
    /// Po zavolaní na `reserve` bude kapacita väčšia alebo rovná `self.len() + additional`.
    /// Nerobí nič, ak je kapacita už dostatočná.
    ///
    /// # Errors
    ///
    /// Ak kapacita pretečie alebo alokátor nahlási poruchu, vráti sa chyba.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Predbežne si rezervujte pamäť, opustite ju, ak nemôžeme
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Teraz vieme, že to nemôže byť OOM uprostred našej zložitej práce
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Pokúša sa vyhradiť minimálnu kapacitu pre presne ďalších `additional` prvkov, ktoré sa majú vložiť do daného `String`.
    ///
    /// Po zavolaní na `reserve_exact` bude kapacita väčšia alebo rovná `self.len() + additional`.
    /// Nerobí nič, ak je kapacita už dostatočná.
    ///
    /// Upozorňujeme, že alokátor môže dať kolekcii viac priestoru, ako požaduje.
    /// Preto sa nemožno spoliehať na to, že kapacita je úplne minimálna.
    /// Ak sa očakávajú vloženia future, uprednostnite `reserve`.
    ///
    /// # Errors
    ///
    /// Ak kapacita pretečie alebo alokátor nahlási poruchu, vráti sa chyba.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Predbežne si rezervujte pamäť, opustite ju, ak nemôžeme
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Teraz vieme, že to nemôže byť OOM uprostred našej zložitej práce
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Zmenšuje kapacitu tohto modelu `String` tak, aby zodpovedal jeho dĺžke.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Zmenšuje kapacitu tohto modelu `String` s dolnou medzou.
    ///
    /// Kapacita zostane minimálne taká veľká ako dĺžka aj dodaná hodnota.
    ///
    ///
    /// Ak je súčasná kapacita nižšia ako dolná hranica, jedná sa o zákaz činnosti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Pripojí daný [`char`] na koniec tohto `String`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Vráti bajtový výsek obsahu tohto " reťazca`.
    ///
    /// Inverzná hodnota tejto metódy je [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Skracuje toto `String` na zadanú dĺžku.
    ///
    /// Ak je hodnota `new_len` väčšia ako aktuálna dĺžka reťazca, nemá to žiadny vplyv.
    ///
    ///
    /// Upozorňujeme, že táto metóda nemá žiadny vplyv na pridelenú kapacitu reťazca
    ///
    /// # Panics
    ///
    /// Panics, ak `new_len` neleží na hranici [`char`].
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Odstráni posledný znak z medzipamäte reťazca a vráti ho.
    ///
    /// Vráti [`None`], ak je tento `String` prázdny.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Odstráni [`char`] z tohto `String` na pozícii bajtu a vráti ho.
    ///
    /// Toto je operácia *O*(*n*), pretože vyžaduje kopírovanie všetkých prvkov vo vyrovnávacej pamäti.
    ///
    /// # Panics
    ///
    /// Panics, ak je `idx` väčšia alebo rovná dĺžke `String` alebo ak neleží na hranici [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Odstráňte všetky zhody vzoru `pat` v `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Zhody budú zistené a odstránené iteratívne, takže v prípadoch, keď sa vzory prekrývajú, bude odstránený iba prvý vzor:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // BEZPEČNOSŤ: začiatok a koniec budú na hraniciach bajtov utf8 za
        // dokument hľadač
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Zachová iba znaky určené predikátom.
    ///
    /// Inými slovami, odstráňte všetky znaky `c`, takže `f(c)` vráti `false`.
    /// Táto metóda funguje na mieste, každý znak navštívi presne raz v pôvodnom poradí a zachováva poradie zachovaných znakov.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Presné poradie môže byť užitočné na sledovanie externého stavu, napríklad indexu.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Ukážte idx na ďalší znak
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Vloží znak do tohto `String` na pozícii bajtu.
    ///
    /// Toto je operácia *O*(*n*), pretože vyžaduje kopírovanie všetkých prvkov vo vyrovnávacej pamäti.
    ///
    /// # Panics
    ///
    /// Panics, ak je `idx` väčšia ako dĺžka reťazca, alebo ak neleží na hranici [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Vloží do tohto `String` rez reťazca na pozícii bajtu.
    ///
    /// Toto je operácia *O*(*n*), pretože vyžaduje kopírovanie všetkých prvkov vo vyrovnávacej pamäti.
    ///
    /// # Panics
    ///
    /// Panics, ak je `idx` väčšia ako dĺžka reťazca, alebo ak neleží na hranici [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Vráti premenlivý odkaz na obsah tohto `String`.
    ///
    /// # Safety
    ///
    /// Táto funkcia je nebezpečná, pretože nekontroluje, či sú jej odovzdané bajty platné UTF-8.
    /// Ak je toto obmedzenie porušené, môže to spôsobiť problémy s bezpečnosťou pamäte u používateľov future `String`, pretože zvyšok štandardnej knižnice predpokladá, že reťazce " String` sú platné UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Vráti dĺžku tohto `String` v bajtoch, nie [`char`] s alebo grafémy.
    /// Inými slovami, nemusí to byť to, čo človek považuje za dĺžku šnúrky.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Vráti `true`, ak má tento `String` dĺžku nula, inak `false`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Rozdelí reťazec na dva pri danom indexe bajtov.
    ///
    /// Vráti novo pridelené `String`.
    /// `self` obsahuje bajty `[0, at)` a vrátený `String` obsahuje bajty `[at, len)`.
    /// `at` musí byť na hranici kódového bodu UTF-8.
    ///
    /// Upozorňujeme, že kapacita modelu `self` sa nemení.
    ///
    /// # Panics
    ///
    /// Panics, ak `at` nie je na hranici kódového bodu `UTF-8`, alebo ak je za posledným bodom kódu v reťazci.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Orezá tento `String` a odstráni všetok obsah.
    ///
    /// Aj keď to znamená, že `String` bude mať dĺžku nula, nedotkne sa svojej kapacity.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Vytvorí odtokový iterátor, ktorý odstráni zadaný rozsah v `String` a poskytne odstránený `chars`.
    ///
    ///
    /// Note: Rozsah prvkov sa odstráni, aj keď sa iterátor nespotrebuje až do konca.
    ///
    /// # Panics
    ///
    /// Panics, ak počiatočný bod alebo koncový bod nespočívajú na hranici [`char`], alebo ak sú mimo hraníc.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Odstráňte rozsah až po β z reťazca
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Celý rad vymaže reťazec
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Bezpečnosť pamäte
        //
        // Verzia Drain typu String nemá problémy s bezpečnosťou pamäte verzie vector.
        // Údaje sú iba obyčajné bajty.
        // Pretože odstránenie rozsahu sa deje v službe Drop, ak dôjde k úniku iterátora Drain, odstránenie sa nestane.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Vyberte dve súčasné výpožičky.
        // K reťazcu &mut sa nebude pristupovať, kým neskončí iterácia, a to v Drop.
        let self_ptr = self as *mut _;
        // BEZPEČNOSŤ: `slice::range` a `is_char_boundary` vykonávajú príslušné kontroly hraníc.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Odstráni zadaný rozsah v reťazci a nahradí ho daným reťazcom.
    /// Zadaný reťazec nemusí mať rovnakú dĺžku ako rozsah.
    ///
    /// # Panics
    ///
    /// Panics, ak počiatočný bod alebo koncový bod nespočívajú na hranici [`char`], alebo ak sú mimo hraníc.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Nahraďte rozsah až po β z reťazca
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Bezpečnosť pamäte
        //
        // Replace_range nemá problémy s bezpečnosťou pamäte spojenia vector.
        // verzie vector.Údaje sú iba obyčajné bajty.

        // UPOZORNENIE: Vloženie tejto premennej by bolo nevhodné (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // UPOZORNENIE: Vloženie tejto premennej by bolo nevhodné (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Opätovné použitie `range` by bolo nezdravé. (#81138) Predpokladáme, že hranice hlásené `range` zostávajú rovnaké, ale medzi hovormi by sa mohla zmeniť protikladná implementácia.
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Skonvertuje tento `String` na [`Box`]`<`[`str`] `>`.
    ///
    /// Týmto sa zníži nadbytočná kapacita.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Vráti plátok bajtov [`u8`] s, ktoré sa pokúsili previesť na `String`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // nejaké neplatné bajty, v vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Vráti bajty, ktoré sa pokúsili previesť na `String`.
    ///
    /// Táto metóda je starostlivo konštruovaná, aby sa zabránilo alokácii.
    /// Po spotrebovaní chyby dôjde k presunutiu bajtov, takže nie je potrebné vytvárať kópie bajtov.
    ///
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // nejaké neplatné bajty, v vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Stiahnutím `Utf8Error` získate ďalšie podrobnosti o zlyhaní konverzie.
    ///
    /// Typ [`Utf8Error`] poskytovaný [`std::str`] predstavuje chybu, ktorá sa môže vyskytnúť pri prevode rezu ["u8"] s na [`&str`].
    /// V tomto zmysle je to obdoba modelu `FromUtf8Error`.
    /// V jeho dokumentácii nájdete ďalšie podrobnosti o jeho používaní.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// // nejaké neplatné bajty, v vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // prvý bajt je tu neplatný
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Pretože iterujeme cez `String`s, môžeme sa vyhnúť aspoň jednej alokácii získaním prvého reťazca z iterátora a pripojením k nemu všetky nasledujúce reťazce.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Pretože iterujeme cez CoWs, môžeme sa (potentially) vyhnúť aspoň jednej alokácii získaním prvej položky a pripojením k nej všetkých nasledujúcich položiek.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Pohodlie impl, ktoré deleguje na impl pre `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Vytvorí prázdny `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Implementuje operátor `+` na zreťazenie dvoch reťazcov.
///
/// Toto spotrebuje `String` na ľavej strane a znovu použije jeho vyrovnávacia pamäť (v prípade potreby ju vypestuje).
/// Toto sa robí, aby sa zabránilo alokovaniu nového `String` a kopírovaniu celého obsahu pri každej operácii, čo by viedlo k dobe chodu *O*(*n*^ 2) pri vytváraní reťazca *n*-byte opakovaným zreťazením.
///
///
/// Šnúrka na pravej strane je iba požičaná;jeho obsah sa skopíruje do vráteného `String`.
///
/// # Examples
///
/// Zreťazenie dvoch reťazcov `String`s má prvé hodnotu a druhé si požičiava:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` je presunutý a už ho tu nemožno použiť.
/// ```
///
/// Ak chcete naďalej používať prvý `String`, môžete ho klonovať a namiesto neho ho pridať:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` tu stále platí.
/// ```
///
/// Zreťazenie rezov `&str` je možné prevedením prvého na `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementuje operátor `+=` na pripojenie k `String`.
///
/// Toto má rovnaké správanie ako metóda [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Alias typu pre [`Infallible`].
///
/// Tento alias existuje pre spätnú kompatibilitu a môže byť nakoniec zastaraný.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait na prevod hodnoty na `String`.
///
/// Táto trait sa automaticky implementuje pre akýkoľvek typ, ktorý implementuje [`Display`] trait.
/// `ToString` by sa preto nemal implementovať priamo:
/// [`Display`] namiesto toho by mala byť implementovaná a implementáciu `ToString` získate zadarmo.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Skonvertuje danú hodnotu na `String`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// V tejto implementácii metóda `to_string` panics, ak implementácia `Display` vráti chybu.
/// To naznačuje nesprávnu implementáciu `Display`, pretože `fmt::Write for String` nikdy nevráti samotnú chybu.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Bežným pravidlom je nezaradiť všeobecné funkcie.
    // Odstránenie `#[inline]` z tejto metódy však spôsobí nezanedbateľné regresie.
    // Pozri <https://github.com/rust-lang/rust/pull/74852>, posledný pokus o odstránenie.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Skonvertuje `&mut str` na `String`.
    ///
    /// Výsledok je alokovaný na halde.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test stiahne libstd, ktorý tu spôsobuje chyby
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Skonvertuje daný boxovaný rez `str` na `String`.
    /// Je pozoruhodné, že plátok `str` je vo vlastníctve.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Skonvertuje daný `String` na zabalený plátok `str`, ktorý vlastní.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Skonvertuje rezček reťazca na vypožičaný variant.
    /// Neuskutočňuje sa žiadne priradenie haldy a reťazec sa nekopíruje.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Skonvertuje reťazec na variant s vlastníctvom.
    /// Neuskutočňuje sa žiadne priradenie haldy a reťazec sa nekopíruje.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Skonvertuje odkaz na reťazec na vypožičaný variant.
    /// Neuskutočňuje sa žiadne priradenie haldy a reťazec sa nekopíruje.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Skonvertuje daný `String` na vector `Vec`, ktorý obsahuje hodnoty typu `u8`.
    ///
    /// # Examples
    ///
    /// Základné použitie:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Odtokový iterátor pre `String`.
///
/// Táto štruktúra je vytvorená metódou [`drain`] na [`String`].
/// Ďalšie informácie nájdete v jeho dokumentácii.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Bude použitý ako&'mut reťazec v deštruktore
    string: *mut String,
    /// Začiatok časti na odstránenie
    start: usize,
    /// Koniec časti na odstránenie
    end: usize,
    /// Aktuálny zostávajúci rozsah na odstránenie
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Použite Vec::drain.
            // "Reaffirm" hranice kontrolujú, aby sa zabránilo opätovnému vloženiu kódu panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Vráti zostávajúci (pod) reťazec tohto iterátora ako rez.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: odkomentovať AsRef nižšie pri stabilizácii.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Pri stabilizácii `string_drain_as_str` odkomentujte.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>pre Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> pre Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}