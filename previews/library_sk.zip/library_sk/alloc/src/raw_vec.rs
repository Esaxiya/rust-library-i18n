#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Obsah novej pamäte je neinicializovaný.
    Uninitialized,
    /// Nová pamäť je zaručene vynulovaná.
    Zeroed,
}

/// Nízkoúrovňový nástroj na ergonomickejšie prideľovanie, prerozdelenie a prerozdelenie medzipamäte pamäte na halde bez obáv zo všetkých zahrnutých rohových prípadov.
///
/// Tento typ je vynikajúci na vytváranie vlastných dátových štruktúr, ako sú Vec a VecDeque.
/// Najmä:
///
/// * Produkuje `Unique::dangling()` na typoch nulovej veľkosti.
/// * Produkuje `Unique::dangling()` s pridelením nulovej dĺžky.
/// * Vyhýba sa uvoľneniu `Unique::dangling()`.
/// * Zachytáva všetky pretečenia vo výpočtoch kapacity (povýši ich na "capacity overflow" panics).
/// * Chráni pred 32-bitovými systémami prideľujúcimi viac ako isize::MAX bajtov.
/// * Chráni pred pretečením vašej dĺžky.
/// * Vyzýva `handle_alloc_error` na omylné pridelenie.
/// * Obsahuje `ptr::Unique` a poskytuje tak používateľovi všetky súvisiace výhody.
/// * Využíva prebytok vrátený od prideľovača na využitie najväčšej dostupnej kapacity.
///
/// Tento typ každopádne nekontroluje pamäť, ktorú spravuje.Po páde *uvoľní* svoju pamäť, ale nebude sa *pokúšať* odhodiť jej obsah.
/// Je na používateľovi `RawVec`, aby spracoval skutočné veci *uložené* vo vnútri `RawVec`.
///
/// Upozorňujeme, že prebytok typov nulovej veľkosti je vždy nekonečný, takže `capacity()` vždy vráti `usize::MAX`.
/// To znamená, že pri obchádzaní tohto typu s modelom `Box<[T]>` musíte byť opatrní, pretože `capacity()` nebude mať dĺžku.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Toto existuje, pretože `#[unstable]` `const fn`s nemusí vyhovovať `min_const_fn`, a preto ich nemožno volať ani v`min_const_fn`s.
    ///
    /// Ak zmeníte `RawVec<T>::new` alebo závislosti, buďte opatrní, aby ste nezavádzali nič, čo by skutočne porušovalo `min_const_fn`.
    ///
    /// NOTE: Tomuto hacknutiu by sme sa mohli vyhnúť a skontrolovať zhodu s nejakým atribútom `#[rustc_force_min_const_fn]`, ktorý vyžaduje zhodu s `min_const_fn`, ale nemusí nutne umožňovať jeho volanie v `stable(...) const fn`/užívateľský kód neumožňujúci `foo`, keď je `#[rustc_const_unstable(feature = "foo", issue = "01234")]` prítomný.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Vytvorí najväčší možný `RawVec` (na systémovej halde) bez alokácie.
    /// Ak má `T` kladnú veľkosť, potom z neho bude `RawVec` s kapacitou `0`.
    /// Ak je `T` nulovej veľkosti, vytvorí sa z neho `RawVec` s kapacitou `usize::MAX`.
    /// Užitočné na implementáciu oneskoreného pridelenia.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Vytvorí `RawVec` (na systémovej halde) s presnou požiadavkou na kapacitu a zarovnanie pre `[T; capacity]`.
    /// Toto je ekvivalent volania `RawVec::new`, keď `capacity` je `0` alebo `T` je nulovej veľkosti.
    /// Upozorňujeme, že ak má `T` nulovú veľkosť, znamená to, že *nezískate*`RawVec` s požadovanou kapacitou.
    ///
    /// # Panics
    ///
    /// Panics, ak požadovaná kapacita presahuje `isize::MAX` bajtov.
    ///
    /// # Aborts
    ///
    /// Prerušuje OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Rovnako ako `with_capacity`, ale zaručuje, že vyrovnávacia pamäť je vynulovaná.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonštituuje `RawVec` z ukazovateľa a kapacity.
    ///
    /// # Safety
    ///
    /// `ptr` musí byť pridelený (na halde systému) a s daným `capacity`.
    /// `capacity` nemôže prekročiť `isize::MAX` pre veľké typy.(týka sa iba 32-bitových systémov).
    /// ZST vectors môžu mať kapacitu až `usize::MAX`.
    /// Ak modely `ptr` a `capacity` pochádzajú z modelu `RawVec`, je to zaručené.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Malí Vecs sú hlúpi.Preskočiť na:
    // - 8, ak je veľkosť prvku 1, pretože akýkoľvek alokátor haldy pravdepodobne zaokrúhli požiadavku menšiu ako 8 bajtov na najmenej 8 bajtov.
    //
    // - 4, ak sú prvky stredne veľké (<=1 KiB).
    // - 1, inak by ste zbytočne nestrácali príliš veľa miesta veľmi krátkymi vecami.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Rovnako ako `new`, ale parametrizovaný výberom alokátora pre vrátený `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` znamená "unallocated".nulové typy sú ignorované.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Rovnako ako `with_capacity`, ale parametrizovaný výberom alokátora pre vrátený `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Rovnako ako `with_capacity_zeroed`, ale parametrizovaný výberom alokátora pre vrátený `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Skonvertuje `Box<[T]>` na `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Prevedie celú vyrovnávaciu pamäť na `Box<[MaybeUninit<T>]>` so zadanou `len`.
    ///
    /// Upozorňujeme, že sa tým správne rekonštituujú všetky zmeny, ktoré sa mohli v `cap` vykonať.(Podrobnosti nájdete v popise typu.)
    ///
    /// # Safety
    ///
    /// * `len` - musí byť väčšia alebo rovná naposledy požadovanej kapacite a-
    /// * `len` musí byť menšia alebo rovná `self.capacity()`.
    ///
    /// Upozorňujeme, že požadovaná kapacita a `self.capacity()` sa môžu líšiť, pretože alokátor mohol nadmerne alokovať a vrátiť väčší blok pamäte, ako sa požadovalo.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Zdravý rozum-skontrolujte jednu polovicu bezpečnostných požiadaviek (druhú polovicu nemôžeme skontrolovať).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Tu sa vyhýbame `unwrap_or_else`, pretože nafukuje množstvo generovaného LLVM IR.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonštituuje `RawVec` z ukazovateľa, kapacity a alokátora.
    ///
    /// # Safety
    ///
    /// `ptr` musí byť pridelený (prostredníctvom daného prideľovača `alloc`) a s daným `capacity`.
    /// `capacity` nemôže prekročiť `isize::MAX` pre veľké typy.
    /// (týka sa iba 32-bitových systémov).
    /// ZST vectors môžu mať kapacitu až `usize::MAX`.
    /// Ak modely `ptr` a `capacity` pochádzajú z modelu `RawVec` vytvoreného prostredníctvom modelu `alloc`, je to zaručené.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Získava surový ukazovateľ na začiatok pridelenia.
    /// Upozorňujeme, že toto je `Unique::dangling()`, ak `capacity == 0` alebo `T` majú nulovú veľkosť.
    /// V prvom prípade musíte byť opatrní.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Získava kapacitu alokácie.
    ///
    /// Toto bude vždy `usize::MAX`, ak je `T` nulovej veľkosti.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Vráti zdieľaný odkaz na alokátor podporujúci tento `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Máme pridelený kus pamäte, takže môžeme obísť kontroly behu, aby sme získali naše súčasné rozloženie.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Zaisťuje, aby vyrovnávacia pamäť obsahovala najmenej dostatok priestoru na uloženie prvkov `len + additional`.
    /// Ak ešte nemá dostatočnú kapacitu, prerozdelí dostatok priestoru plus pohodlný voľný priestor na získanie amortizovaného správania *O*(1).
    ///
    /// Obmedzí toto správanie, ak by sa zbytočne spôsobilo panic.
    ///
    /// Ak `len` prekročí `self.capacity()`, môže dôjsť k zlyhaniu skutočného pridelenia požadovaného priestoru.
    /// Toto nie je skutočne nebezpečné, ale nebezpečný kód *, ktorý napíšete*, ktorý sa spolieha na správanie tejto funkcie, sa môže zlomiť.
    ///
    /// To je ideálne pre implementáciu operácie hromadného stlačenia, ako je `extend`.
    ///
    /// # Panics
    ///
    /// Panics, ak nová kapacita presahuje `isize::MAX` bajtov.
    ///
    /// # Aborts
    ///
    /// Prerušuje OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerva by sa prerušila alebo spanikárila, ak by hodnota prekročila `isize::MAX`, takže teraz je to bezpečné.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Rovnaké ako `reserve`, ale vráti sa pri chybách namiesto paniky alebo prerušenia.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Zaisťuje, aby vyrovnávacia pamäť obsahovala najmenej dostatok priestoru na uloženie prvkov `len + additional`.
    /// Ak to ešte neurobí, prerozdelí potrebné minimálne množstvo pamäte.
    /// Spravidla to bude presne potrebné množstvo pamäte, ale v zásade môže alokátor vrátiť viac, ako sme požadovali.
    ///
    ///
    /// Ak `len` prekročí `self.capacity()`, môže dôjsť k zlyhaniu skutočného pridelenia požadovaného priestoru.
    /// Toto nie je skutočne nebezpečné, ale nebezpečný kód *, ktorý napíšete*, ktorý sa spolieha na správanie tejto funkcie, sa môže zlomiť.
    ///
    /// # Panics
    ///
    /// Panics, ak nová kapacita presahuje `isize::MAX` bajtov.
    ///
    /// # Aborts
    ///
    /// Prerušuje OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Rovnaké ako `reserve_exact`, ale vráti sa pri chybách namiesto paniky alebo prerušenia.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Zmenší pridelenie na zadanú sumu.
    /// Ak je daná suma 0, skutočne sa úplne uvoľní.
    ///
    /// # Panics
    ///
    /// Panics, ak je zadané množstvo *väčšie* ako súčasná kapacita.
    ///
    /// # Aborts
    ///
    /// Prerušuje OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Vráti sa, ak vyrovnávacia pamäť musí rásť, aby splnila potrebnú ďalšiu kapacitu.
    /// Používa sa hlavne na umožnenie vloženia rezervných hovorov bez vloženia `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Táto metóda je zvyčajne inštancovaná mnohokrát.Takže chceme, aby to bolo čo najmenšie, aby sa zlepšili časy kompilácie.
    // Tiež však chceme, aby bolo čo najviac jeho obsahu staticky vypočítateľných, aby bol vygenerovaný kód rýchlejší.
    // Preto je táto metóda starostlivo napísaná tak, aby sa v nej nachádzal všetok kód závislý na `T`, zatiaľ čo čo najviac kódu nezávislého na `T` je vo funkciách, ktoré nie sú generické pre `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Toto zabezpečujú volajúce kontexty.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Pretože vrátime kapacitu `usize::MAX`, keď je `elem_size`
            // 0, cesta sem nevyhnutne znamená, že `RawVec` je preplnený.
            return Err(CapacityOverflow);
        }

        // Bohužiaľ s týmito kontrolami nemôžeme nič urobiť.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // To zaručuje exponenciálny rast.
        // Zdvojnásobenie nemôže pretekať, pretože `cap <= isize::MAX` a typ `cap` sú `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nie je generický pre `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Obmedzenia tejto metódy sú takmer rovnaké ako obmedzenia v prípade `grow_amortized`, ale táto metóda je zvyčajne inštancovaná menej často, takže je menej kritická.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Pretože pri veľkosti písma vrátime kapacitu `usize::MAX`
            // 0, cesta sem nevyhnutne znamená, že `RawVec` je preplnený.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` nie je generický pre `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Táto funkcia je mimo `RawVec`, aby sa minimalizovali časy kompilácie.Podrobnosti nájdete v komentári vyššie `RawVec::grow_amortized`.
// (Parameter `A` nie je významný, pretože počet rôznych typov `A`, ktoré sa v praxi vyskytujú, je oveľa menší ako počet typov `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Tu skontrolujte chybu, aby ste minimalizovali veľkosť `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Alokátor kontroluje rovnosť zarovnania
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Uvoľní pamäť vo vlastníctve `RawVec`*bez toho, aby sa* pokúsil zhodiť jej obsah.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centrálna funkcia pre spracovanie chýb rezervy.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Musíme zaručiť nasledujúce:
// * Nikdy nepridelíme objekty veľkosti `> isize::MAX` bajtov.
// * `usize::MAX` nepretekáme a v skutočnosti pridelíme príliš málo.
//
// Na 64-bitovom serveri stačí skontrolovať pretečenie, pretože pokus o pridelenie bajtov `> isize::MAX` určite zlyhá.
// Na 32-bitových a 16-bitových systémoch je potrebné pridať ďalšiu ochranu pre prípad, že pracujeme na platforme, ktorá dokáže využiť všetky 4 GB v užívateľskom priestore, napríklad PAE alebo x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Jedna ústredná funkcia zodpovedná za pretečenie kapacity hlásenia.
// Tým sa zabezpečí, že generovanie kódu súvisiaceho s týmito panics je minimálne, pretože v module je iba jedno miesto, ktoré je panics, a nie skupina.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}