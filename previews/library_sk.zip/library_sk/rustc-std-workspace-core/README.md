# Model `rustc-std-workspace-core` crate

Tento crate je vložka a prázdna crate, ktorá jednoducho závisí od `libcore` a reexportuje všetok jeho obsah.
crate je podstatou posilnenia štandardnej knižnice tak, aby bola závislá na crate z crates.io

Crates na crates.io, že štandardná knižnica závisí od potreby závisieť od `rustc-std-workspace-core` crate z crates.io, ktorý je prázdny.

Používame `[patch]` na jeho prepísanie k tomuto crate v tomto úložisku.
Výsledkom bude, že crates na crates.io nakreslí závislosť edge na `libcore`, verziu definovanú v tomto úložisku.
To by malo vykresliť všetky okraje závislostí, aby sa zabezpečilo, že Cargo úspešne zostaví crates!

Všimnite si, že crates na crates.io musí závisieť od tohto crate s názvom `core`, aby všetko fungovalo správne.Môžu na to použiť:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Použitím klávesu `package` sa crate premenuje na `core`, čo znamená, že bude vyzerať

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

keď Cargo vyvolá kompilátor a spĺňa implicitnú smernicu `extern crate core` vloženú kompilátorom.




