use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Používa sa na to, aby sme povedali našim anotáciám `#[assert_instr]`, že na testovanie ich kodegénu sú k dispozícii všetky vnútorné vlastnosti simd, pretože niektoré sú bránené za extra `-Ctarget-feature=+unimplemented-simd128`, ktorý práve nemá ekvivalent v `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}