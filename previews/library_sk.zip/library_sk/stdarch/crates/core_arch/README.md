`core::arch` - Základné vlastnosti architektúry jadra knižnice Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` implementuje vnútorné architektúry závislé (napr. SIMD).

# Usage 

`core::arch` je k dispozícii ako súčasť balíka `libcore` a je znovu exportovaný produktom `libstd`.Používajte ho radšej cez `core::arch` alebo `std::arch` ako cez tento crate.
Nestabilné funkcie sú často dostupné v nočných Rust cez `feature(stdsimd)`.

Používanie `core::arch` cez tento crate vyžaduje nočný Rust a môže sa (a robí) často lámať.Jediné prípady, v ktorých by ste mali zvážiť použitie prostredníctvom tohto crate, sú:

* ak potrebujete znova zostaviť `core::arch`, napr. s povolenými konkrétnymi cieľovými funkciami, ktoré nie sú povolené pre `libcore`/`libstd`.
Note: Ak ho potrebujete znova skompilovať pre neštandardný cieľ, radšej použite `xargo` a prípadne znova zostavte `libcore`/`libstd` namiesto použitia tohto crate.
  
* pomocou niektorých funkcií, ktoré nemusia byť k dispozícii ani za nestabilnými funkciami Rust.Snažíme sa ich obmedziť na minimum.
Ak potrebujete použiť niektoré z týchto funkcií, otvorte problém, aby sme ich mohli vystaviť v nočnej Rust a odtiaľ ich potom mohli používať.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` je primárne distribuovaný za podmienok licencie MIT aj licencie Apache (verzia 2.0), na časti sa vzťahujú rôzne licencie podobné BSD.

Podrobnosti nájdete v častiach LICENSE-APACHE a LICENSE-MIT.

# Contribution

Pokiaľ výslovne neurčíte inak, akýkoľvek príspevok, ktorý ste zámerne predložili na zahrnutie do `core_arch`, ako je definované v licencii Apache-2.0, bude mať dvojitú licenciu, ako je uvedené vyššie, bez akýchkoľvek ďalších podmienok alebo podmienok.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












