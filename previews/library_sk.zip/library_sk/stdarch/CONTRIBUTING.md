# Prispievanie do programu stdarch

`stdarch` crate je viac než ochotný prijímať príspevky!Najskôr si pravdepodobne budete chcieť pozrieť úložisko a uistiť sa, že testy pre vás vyhovejú:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kde `<your-target-arch>` je trojitý terč, ako ho používa `rustup`, napr. `x86_x64-unknown-linux-gnu` (bez predchádzajúceho `nightly-` alebo podobného).
Pamätajte tiež, že toto úložisko vyžaduje nočný kanál Rust!
Vyššie uvedené testy v skutočnosti vyžadujú, aby bola vo vašom systéme predvolená nočná rust, aby bolo možné nastaviť použitie `rustup default nightly` (a `rustup default stable` na návrat).

Ak niektorý z vyššie uvedených krokov nefunguje, [please let us know][new]!

Ďalej vám môžeme pomôcť [find an issue][issues], vybrali sme niekoľko značiek so značkami [`help wanted`][help] a [`impl-period`][impl], ktoré by mohli obzvlášť pomôcť. 
Mohla by vás najviac zaujímať [#40][vendor], ktorá implementuje všetky vnútorné vlastnosti dodávateľa na x86.Toto vydanie má niekoľko dobrých rád, kde začať!

Ak máte všeobecné otázky, neváhajte a kontaktujte [join us on gitter][gitter]!Pokojne pingnite na otázky@BurntSushi alebo@alexcrichton.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Ako písať príklady vnútorných riešení stdarch

Existuje niekoľko funkcií, ktoré musia byť povolené, aby daná vnútorná funkcia fungovala správne a príklad musí byť spustený programom `cargo test --doc`, iba ak je táto funkcia podporovaná procesorom.

Výsledkom je, že predvolená hodnota `fn main`, ktorá je generovaná `rustdoc`, nebude fungovať (vo väčšine prípadov).
Zvážte použitie nasledujúcej príručky, aby ste zaistili, že váš príklad bude fungovať podľa očakávaní.

```rust
/// # // Potrebujeme cfg_target_feature, aby sme sa uistili, že ide iba o príklad
/// # // beží na `cargo test --doc`, keď CPU túto funkciu podporuje
/// # #![feature(cfg_target_feature)]
/// # // Potrebujeme target_feature, aby to skutočne fungovalo
/// # #![feature(target_feature)]
/// #
/// # // rustdoc štandardne používa `extern crate stdarch`, ale potrebujeme
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Skutočná hlavná funkcia
/// # fn main() {
/// #     // Toto spustite, iba ak je podporovaná verzia `<target feature>`
/// #     ak je cfg_feature_enabled! ("<target feature>"){
/// #         // Vytvorte funkciu `worker`, ktorá sa spustí iba v prípade cieľovej funkcie
/// #         // je podporovaná a uistite sa, že je pre vášho pracovníka povolená funkcia `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nebezpečné fn worker() {
/// // Sem napíš svoj príklad.Tu bude fungovať špecifická vlastnosť funkcií!Roztočiť to!
///
/// #         }
///
/// #         nebezpečné { worker(); }
/// #     }
/// # }
```

Ak niektorá z vyššie uvedených syntaxí nevyzerá dobre, časť [Documentation as tests] v [Rust Book] popisuje syntax `rustdoc` celkom dobre.
Ako vždy, neváhajte [join us on gitter][gitter] a opýtajte sa nás, či narazíte na nejaké problémy, a ďakujeme vám za pomoc pri zlepšovaní dokumentácie `stdarch`!

# Alternatívne pokyny na testovanie

Všeobecne sa odporúča, aby ste na vykonanie testov použili `ci/run.sh`.
To však nemusí fungovať, napríklad ak ste na Windows.

V takom prípade sa môžete vrátiť k spusteniu `cargo +nightly test` a `cargo +nightly test --release -p core_arch` na testovanie generovania kódu.
Upozorňujeme, že to vyžaduje inštaláciu nočného reťazca nástrojov a aby `rustc` vedel o vašom cieľovom triple a jeho CPU.
Najmä musíte nastaviť premennú prostredia `TARGET`, ako by ste to urobili pre `ci/run.sh`.
Okrem toho musíte nastaviť `RUSTCFLAGS` (potrebujete `C`) na označenie cieľových funkcií, napr `RUSTCFLAGS="-C -target-features=+avx2"`.
Môžete tiež nastaviť `-C -target-cpu=native`, ak vyvíjate "just" proti aktuálnemu CPU.

Upozorňujeme, že keď použijete tieto alternatívne pokyny, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], napr
Testy generovania inštrukcií môžu zlyhať, pretože disassembler ich pomenoval inak, napr
môže generovať `vaesenc` namiesto pokynov `aesenc` napriek tomu, že sa správajú rovnako.
Tieto pokyny tiež vykonávajú menej testov, ako by sa zvyčajne robili, takže sa nečudujte, že keď nakoniec požiadate o načítanie, môžu sa pri testoch, ktoré tu nie sú uvedené, zobraziť niektoré chyby.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






