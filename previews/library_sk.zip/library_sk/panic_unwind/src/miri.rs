//! Odvíjanie panics pre Miri.
use alloc::boxed::Box;
use core::any::Any;

// Typ užitočného zaťaženia, ktoré sa motorom Miri šíri odvíjaním pre nás.
// Musí mať veľkosť ukazovateľa.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri poskytovaná externá funkcia pre začatie odvíjania.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Užitočné zaťaženie, ktoré odovzdáme `miri_start_panic`, bude presne argumentom, ktorý dostaneme v `cleanup` nižšie.
    // Takže to iba raz zabaľujeme, aby sme dostali niečo ako ukazovateľ.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Obnovte podkladovú `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}