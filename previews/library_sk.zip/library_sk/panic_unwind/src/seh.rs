//! Windows SEH
//!
//! Na Windows (v súčasnosti iba na MSVC) je predvoleným mechanizmom spracovania výnimiek Štruktúrované spracovanie výnimiek (SEH).
//! To je úplne iné ako zaobchádzanie s výnimkami založené na trpaslíkoch (napr. Čo používajú iné platformy unix), čo sa týka vnútorných častí kompilátora, takže od LLVM sa vyžaduje, aby mal pre SEH značnú podporu navyše.
//!
//! Stručne povedané, čo sa tu deje, je:
//!
//! 1. Funkcia `panic` volá štandardnú funkciu Windows `_CxxThrowException`, aby vyvolala výnimku podobnú C++ , ktorá spustí proces odvíjania.
//! 2.
//! Všetky pristávacie plochy vygenerované kompilátorom používajú osobnostnú funkciu `__CxxFrameHandler3`, funkciu v CRT, a odvíjací kód v Windows použije túto osobnostnú funkciu na vykonanie celého čistiaceho kódu v zásobníku.
//!
//! 3. Všetky hovory generované kompilátorom do `invoke` majú pristávaciu plochu nastavenú ako inštrukciu `cleanuppad` LLVM, ktorá označuje začiatok rutiny vyčistenia.
//! Osobnosť (v kroku 2, definovaná v CRT) je zodpovedná za vykonávanie čistiacich rutín.
//! 4. Nakoniec sa vykoná kód "catch" vo vnútornej hodnote `try` (vygenerovaný kompilátorom), ktorý naznačuje, že riadenie by sa malo vrátiť k Rust.
//! To sa deje pomocou inštrukcie `catchswitch` plus `catchpad` v podmienkach LLVM IR a nakoniec sa vráti normálne riadenie do programu pomocou inštrukcie `catchret`.
//!
//! Niektoré špecifické rozdiely od spracovania výnimiek založených na gcc sú:
//!
//! * Rust nemá žiadnu vlastnú osobnostnú funkciu, je namiesto toho *vždy*`__CxxFrameHandler3`.Ďalej sa nevykonáva žiadne ďalšie filtrovanie, takže nakoniec zachytíme všetky výnimky v C++ , ktoré vyzerajú ako tie, ktoré vrháme.
//! Všimnite si, že použitie výnimky do Rust je rovnako nedefinované správanie, takže by to malo byť v poriadku.
//! * Máme niekoľko údajov na prenos cez odvíjajúcu sa hranicu, konkrétne `Box<dyn Any + Send>`.Rovnako ako v prípade Dwarfových výnimiek, tieto dva ukazovatele sú uložené ako užitočné zaťaženie v samotnej výnimke.
//! Na MSVC však nie je potrebné ďalšie alokovanie haldy, pretože zásobník volaní je zachovaný aj počas vykonávania funkcií filtra.
//! To znamená, že ukazovatele sa odovzdávajú priamo do `_CxxThrowException`, ktoré sa potom obnovia vo funkcii filtra, aby sa zapísali do rámca zásobníka vlastného `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Toto musí byť Option, pretože výnimku zachytíme odkazom a jej deštruktor sa vykoná v prostredí runtime C++ .
    // Keď vezmeme Box z výnimky, musíme nechať výnimku v platnom stave, aby sa jej deštruktor spustil bez toho, aby sme Box dvakrát vyhodili.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Najskôr celá skupina definícií typov.Je tu niekoľko zvláštností špecifických pre jednotlivé platformy a veľa z nich je len zjavne skopírované z LLVM.Účelom toho všetkého je implementovať nižšie uvedenú funkciu `panic` prostredníctvom volania na `_CxxThrowException`.
//
// Táto funkcia má dva argumenty.Prvý je ukazovateľ na údaje, ktoré odovzdávame, čo je v tomto prípade náš objekt trait.Je to dosť ľahké nájsť!Ďalšia je však komplikovanejšia.
// Toto je ukazovateľ na štruktúru `_ThrowInfo` a všeobecne je určený iba na opísanie vyvolanej výnimky.
//
// V súčasnosti je definícia tohto typu [1] trochu chlpatá a hlavnou zvláštnosťou (a rozdielom od článku online) je, že na 32-bitových ukazovateľoch sú ukazovatele, ale na 64-bitových ukazovateľoch sú vyjadrené ako 32-bitové posuny od Symbol `__ImageBase`.
//
// Na vyjadrenie sa používajú makra `ptr_t` a `ptr!` v nižšie uvedených moduloch.
//
// Labyrint definícií typov tiež pozorne sleduje to, čo LLVM vyžaruje pre tento druh operácie.Napríklad, ak kompilujete tento kód C++ na MSVC a emitujete IR LLVM:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      void foo() { rust_panic a = {0, 1};
//          hodiť;}
//
// To je v podstate to, čo sa snažíme napodobniť.Väčšina konštantných hodnôt uvedených nižšie bola skopírovaná z LLVM,
//
// V každom prípade sú všetky tieto štruktúry konštruované podobným spôsobom a sú pre nás iba trochu podrobné.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Všimnite si, že tu zámerne ignorujeme pravidlá upravovania názvu: nechceme, aby C++ bolo schopné zachytiť Rust panics jednoduchým vyhlásením za `struct rust_panic`.
//
//
// Pri úprave sa uistite, či sa reťazec názvu typu presne zhoduje s reťazcom použitým v `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Vedúci bajt `\x01` je v skutočnosti magickým signálom pre LLVM na *nepoužitie* iného manglovania, ako je predpona so znakom `_`.
    //
    //
    // Tento symbol predstavuje vtable používaný `std::type_info` v C++ .
    // Objekty typu `std::type_info`, deskriptory typov, majú smerník na túto tabuľku.
    // Na deskriptory typov sa odvolávajú štruktúry C++ EH definované vyššie a ktoré zostrojíme nižšie.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Tento typový deskriptor sa používa iba pri vyvolaní výnimky.
// S chytacou časťou sa stará try intrinsic, ktorý generuje vlastný TypeDescriptor.
//
// To je v poriadku, pretože modul runtime MSVC používa porovnanie reťazcov v názve typu, aby sa zhodoval s TypeDescriptors, a nie s rovnosťou ukazovateľa.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktor sa použije, ak sa kód C++ rozhodne zachytiť výnimku a zrušiť ju bez jej šírenia.
// Časť catch intrinsic try nastaví prvé slovo objektu výnimky na 0 tak, aby ho deštruktor preskočil.
//
// Upozorňujeme, že x86 Windows používa pre členské funkcie C++ konvenciu volaní "thiscall" namiesto predvolenej konvencie volaní "C".
//
// Funkcia exception_copy je tu trochu zvláštna: je vyvolaná runtime MSVC v rámci bloku try/catch a panic, ktorý tu generujeme, bude použitý ako výsledok kópie výnimky.
//
// Toto používa runtime C++ na podporu zachytávania výnimiek s std::exception_ptr, ktoré nemôžeme podporovať, pretože Box<dyn Any>nie je klonovateľný.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException sa vykonáva výlučne na tomto rámci zásobníka, takže nie je potrebné inak prenášať `data` na haldu.
    // Práve odovzdáme ukazovateľ zásobníka tejto funkcii.
    //
    // ManuallyDrop je tu potrebný, pretože nechceme, aby bola výnimka pri odvíjaní zrušená.
    // Namiesto toho ho zruší výnimka_cleanup, ktorú vyvolá runtime C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Toto ... sa môže zdať prekvapivé a oprávnene.Na 32-bitových MSVC sú ukazovatele medzi týmito štruktúrami práve také, ukazovatele.
    // Na 64-bitovom MSVC sú však ukazovatele medzi štruktúrami skôr vyjadrené ako 32-bitové posuny od `__ImageBase`.
    //
    // V dôsledku toho na 32-bitovom MSVC môžeme deklarovať všetky tieto ukazovatele v statickej časti vyššie.
    // Na 64-bitovom MSVC by sme museli staticky vyjadrovať odčítanie ukazovateľov, čo Rust momentálne neumožňuje, takže to vlastne nemôžeme urobiť.
    //
    // Ďalšou najlepšou vecou je potom vyplnenie týchto štruktúr za behu (panika je už aj tak "slow path").
    // Takže tu znova interpretujeme všetky tieto polia ukazovateľa ako 32-bitové celé čísla a potom do nich uložíme príslušnú hodnotu (atomicky, pretože môže dochádzať k súbežnému panics).
    //
    // Technicky runtime pravdepodobne vykoná neaatomické čítanie týchto polí, ale teoreticky nikdy nečítali *nesprávnu* hodnotu, takže by to nemalo byť zlé ...
    //
    // V každom prípade musíme v zásade niečo také urobiť, kým nebudeme môcť v statike vyjadriť viac operácií (a možno to nikdy nebudeme schopní).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL užitočné zaťaženie tu znamená, že sme sa sem dostali z úlovku (...) z __rust_try.
    // To sa stane, keď sa zachytí zahraničná výnimka iná ako Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Toto je potrebné, aby kompilátor existoval (napr. Je to položka v jazyku lang), ale kompilátor ju v skutočnosti nikdy nezavolá, pretože __C_specific_handler alebo_except_handler3 je osobnostná funkcia, ktorá sa vždy používa.
//
// Z tohto dôvodu je to iba prerušený útržok.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}