//! ការអនុវត្តន៍ Rust panics តាមរយៈការរំលូតកូនដំណើរការ
//!
//! នៅពេលប្រៀបធៀបទៅនឹងការអនុវត្តតាមរយៈការបង្រួបបង្រួម crate នេះគឺច្រើន * សាមញ្ញណាស់!ដែលត្រូវបានគេនិយាយថា, វាមិនមែនជាការល្អផង, ប៉ុន្តែនៅទីនេះទៅ!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" បន្ទុកនិងលាក់ចំពោះការរំលូតកូនដែលពាក់ព័ន្ធនៅលើវេទិកានៅក្នុងសំណួរ។
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ហៅទូរស័ព្ទ std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // នៅថ្ងៃទី Windows, ប្រើប្រព័ន្ធដំណើរការជាក់លាក់ __fastfail យន្តការ។នៅក្នុង Windows 8 និងក្រោយមកវានឹងបញ្ចប់ដំណើរការភ្លាមៗដោយមិនចាំបាច់បើកកម្មវិធីដោះស្រាយករណីលើកលែងណាមួយឡើយ។
            // នៅក្នុងកំណែមុននៃ Windows, លំដាប់នៃការណែនាំនេះនឹងត្រូវបានចាត់ទុកថាជាការរំលោភសិទ្ធិចូលដំណើរការបានបញ្ចប់ដំណើរការនេះទេប៉ុន្តែដោយមិនចាំបាច់ឆ្លងកាត់ដោះស្រាយករណីលើកលែងទាំងអស់។
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: នេះគឺជាការអនុវត្តដូចគ្នានឹង `abort_internal` របស់ libstd ដែរ
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// នេះ ... គឺជាភាពចម្លែកបន្តិច។TL នេះលោកបណ្ឌិត;គឺថានេះគឺត្រូវបានទាមទារដើម្បីភ្ជាប់បានត្រឹមត្រូវ, ការពន្យល់យូរទៀតទេគឺនៅខាងក្រោម។
//
// ឥលូវនេះប្រព័ន្ធគោលពីរនៃ libcore/libstd ដែលយើងដឹកជញ្ជូនត្រូវបានគេចងក្រងជាមួយ `-C panic=unwind` ។នេះត្រូវបានធ្វើដើម្បីធានាថាប្រព័ន្ធគោលពីរនេះគឺជាការឆបគ្នាជាស្ថានភាពអប្បរមាជាច្រើនដូចជាអាចធ្វើទៅបាន។
// ចងក្រងទោះជាយ៉ាងណាតម្រូវឱ្យ "personality function" សម្រាប់មុខងារទាំងអស់ដែលបានចងក្រងជាមួយ `-C panic=unwind` មួយ។មុខងារបុគ្គលិកលក្ខណៈនេះត្រូវបាន hardcoded ទៅនឹងនិមិត្តសញ្ញា `rust_eh_personality` ហើយត្រូវបានកំណត់ដោយធាតុ `eh_personality` lang ។
//
// So...
// ហេតុអ្វីបានជាមិនគ្រាន់តែកំណត់ធាតុឡង់នៅទីនេះ?សំណួរល្អ!វិធីដែលពេលរត់ panic ត្រូវបានភ្ជាប់នៅជាតិចតួចគឺជាការពិតដែលថាពួកគេច្បាស់នៅក្នុងហាងមាន "sort of" ចងក្រងរបស់ crate, ប៉ុន្តែបានតែការពិតប្រសិនបើមានម្នាក់ទៀតបានតភ្ជាប់មិនបានតភ្ជាប់ពិតជាត្រូវ។
//
// ចុងនេះមានន័យថាទាំងពីរឡើងនេះនិង panic_unwind crate នេះអាចលេចឡើង crate ហាង crate ចងក្រងក្នុងរបស់, ហើយប្រសិនបើអ្នកទាំងពីរកំណត់ធាតុ `eh_personality` ឡង់បន្ទាប់មកថានឹងបុកកំហុស។
//
// ដើម្បីដោះស្រាយនេះចងក្រងតែតម្រូវឱ្យមានការ `eh_personality` នេះត្រូវបានកំណត់ប្រសិនបើពេលរត់ panic ត្រូវបានភ្ជាប់នៅក្នុងគឺពេលរត់ដកចេញ, ហើយបើមិនដូច្នេះទេវាមិនត្រូវបានទាមទារដើម្បីត្រូវបានកំណត់ (យ៉ាងត្រឹមត្រូវដូច្នេះ) ។
// ទោះយ៉ាងណាក៏ដោយក្នុងករណីនេះបណ្ណាល័យនេះគ្រាន់តែកំណត់និមិត្តសញ្ញានេះដូច្នេះយ៉ាងហោចណាស់មានបុគ្គលិកលក្ខណៈខ្លះនៅកន្លែងណាមួយ។
//
// សំខាន់ជានិមិត្តរូបនេះត្រូវបានគ្រាន់តែត្រូវបានកំណត់ដើម្បីទទួលបានខ្សែឡើងទៅប្រព័ន្ធគោលពីរ libcore/libstd នោះទេប៉ុន្តែវាមិនគួរត្រូវបានគេហៅថាជាការដែលយើងមិនបានភ្ជាប់នៅក្នុងពេលវេលារត់ដកចេញទាំងអស់។
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // នៅលើ x86_64-pc-windows-gnu យើងប្រើមុខងារបុគ្គលិកលក្ខណៈផ្ទាល់ខ្លួនរបស់យើងដែលត្រូវការត្រឡប់ `ExceptionContinueSearch` នៅពេលយើងឆ្លងកាត់ស៊ុមរបស់យើងទាំងអស់។
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // ស្រដៀងគ្នាទៅខាងលើ, ឆ្លើយតបនេះទៅធាតុ `eh_catch_typeinfo` ឡង់ដែលត្រូវបានប្រើតែនៅលើ Emscripten បច្ចុប្បន្ន។
    //
    // ចាប់តាំងពីពេល panics មិនបានបង្កើតករណីលើកលែងនិងករណីលើកលែងបរទេសបច្ចុប្បន្ន UB បានជាមួយ -C panic=បោះបង់ (បើទោះបីនេះអាចជាកម្មវត្ថុនៃការផ្លាស់ប្តូរ), ការហៅទូរស័ព្ទ catch_unwind ណាមួយដែលនឹងមិនប្រើ typeinfo នេះ។
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // ទាំងពីរនេះត្រូវបានគេហៅដោយវត្ថុពេលចាប់ផ្ដើមរបស់យើងនៅលើ i686-កុំព្យូទ័រ-windows-gnu, ប៉ុន្តែពួកគេមិនត្រូវធ្វើអ្វីនោះទេដូច្នេះស្ថាប័នមាន nops ។
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}