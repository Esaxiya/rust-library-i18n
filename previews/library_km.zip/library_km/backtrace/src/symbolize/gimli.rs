//! គាំទ្រនិមិត្តសញ្ញាដោយប្រើ `gimli` crate នៅលើ crates.io
//!
//! នេះគឺជាការអនុវត្តនិមិត្តសញ្ញាលំនាំដើមសម្រាប់ Rust ។

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // "ជីវិតឋិតិវន្តគឺជាការកុហកដើម្បី hack ជុំវិញការខ្វះខាតនៃការគាំទ្រសម្រាប់ structs ដោយខ្លួនឯងយោងមួយ។
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // បំលែងទៅ 'អាយុកាលឋិតិវន្តចាប់តាំងពីនិមិត្តសញ្ញាគួរតែខ្ចីតែ `map` និង `stash` ហើយយើងកំពុងថែរក្សាវានៅខាងក្រោម។
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // សម្រាប់ផ្ទុកបណ្ណាល័យដើមកំណើតនៅលើ Windows សូមមើលការពិភាក្សាមួយចំនួននៅលើ rust-lang/rust#71060 សម្រាប់យុទ្ធសាស្រ្តនានានៅទីនេះ។
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW libraries មិនបច្ចុប្បន្ននេះគាំទ្រ ASLR (rust-lang/rust#16514) ទេប៉ុន្តែ DLLs តែអាចត្រូវបានផ្លាស់ប្តូរទីតាំងនៅជុំវិញក្នុងចន្លោះអាសយដ្ឋាន។
            // វាបង្ហាញថាអាស័យដ្ឋាននៅក្នុងព័ត៌មានបំបាត់កំហុសគឺដូចជាប្រសិនបើបណ្ណាល័យនេះត្រូវបានផ្ទុកនៅ "image base" របស់វាដែលជាវាលនៅក្នុងបឋមកថាឯកសារ COFF របស់វា។
            // ចាប់តាំងពីនេះគឺជាអ្វីដែល debuginfo ហាក់ដូចជាចុះបញ្ជីយើងញែកតារាងនិមិត្តសញ្ញានិងអាស័យដ្ឋានហាងដូចជាបណ្ណាល័យត្រូវបានផ្ទុកនៅ "image base" ផងដែរ។
            //
            // ទោះយ៉ាងណាបណ្ណាល័យប្រហែលជាមិនផ្ទុកនៅ "image base" ទេ។
            // (សន្មតថាមានអ្វីផ្សេងទៀតអាចផ្ទុកនៅទីនោះ?) នេះគឺជាកន្លែងដែលវាល `bias` ចូលមកលេងហើយយើងត្រូវរកតម្លៃ `bias` នៅទីនេះ។ជាអកុសលទោះបីជាវាមិនច្បាស់អំពីរបៀបដើម្បីទទួលបានពីម៉ូឌុលដែលផ្ទុក។
            // អ្វីដែលយើងមាន, ទោះជាយ៉ាងណា, គឺជាអាសយដ្ឋានពិតប្រាកដ (`modBaseAddr`) ផ្ទុក។
            //
            // ក្នុងនាមជាប៊ីតនៃប៉ូលិសចេញសម្រាប់ឥឡូវនេះយើងបាន mmap ឯកសារអានពបឋមកថាឯកសារបន្ទាប់មកទម្លាក់ mmap នេះ។នេះជាការខ្ជះខ្ជាយពីព្រោះយើងប្រហែលជានឹងបើក mmap នៅពេលក្រោយប៉ុន្តែនេះគួរតែដំណើរការល្អគ្រប់គ្រាន់សម្រាប់ពេលនេះ។
            //
            // នៅពេលដែលយើងមាន `image_base` (ទីតាំងផ្ទុកដែលចង់បាន) និង `base_addr` (ទីតាំងផ្ទុកជាក់ស្តែង) យើងអាចបំពេញ `bias` (ភាពខុសគ្នារវាងការពិតនិងចង់បាន) ហើយបន្ទាប់មកអាសយដ្ឋានដែលបានបញ្ជាក់នៃផ្នែកនីមួយៗគឺ `image_base` ចាប់តាំងពីនោះហើយជាអ្វីដែលឯកសារនិយាយ។
            //
            //
            // សម្រាប់ពេលនេះវាហាក់ដូចជាថាមិនដូច ELF/MachO យើងអាចធ្វើឱ្យធ្វើជាមួយមួយផ្នែកក្នុងមួយបណ្ណាល័យដោយប្រើ `modBaseSize` ជាទំហំទាំងមូល។
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS ប្រើ APIs ទ្រង់ទ្រាយឯកសារម៉ាអូនិងការប្រើប្រាស់ DYLD ជាក់លាក់ដើម្បីផ្ទុកបញ្ជីនៃបណ្ណាល័យដែលមានដើមកំណើតដែលជាផ្នែកមួយនៃកម្មវិធីនេះ។
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // យកឈ្មោះបណ្ណាល័យនេះដែលត្រូវនឹងផ្លូវនៃកន្លែងដែលត្រូវផ្ទុកវាផងដែរ។
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // ផ្ទុកបឋមកថារូបភាពនៃបណ្ណាល័យនេះហើយធ្វើប្រតិភូកម្មទៅ `object` ដើម្បីញែកពាក្យបញ្ជាបន្ទុកទាំងអស់ដូច្នេះយើងអាចរកឃើញផ្នែកទាំងអស់ដែលពាក់ព័ន្ធនៅទីនេះ។
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // លាយបញ្ចូលគ្នានៅលើផ្នែកនិងចុះឈ្មោះតំបន់ដែលគេស្គាល់សម្រាប់ផ្នែកដែលយើងរកឃើញ។
            // បន្ថែមការកត់ត្រាព័ត៌មានទាក់ទងនឹងផ្នែកអត្ថបទសម្រាប់ដំណើរការនៅពេលក្រោយសូមមើលយោបល់ខាងក្រោម។
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // កំណត់ "slide" សម្រាប់បណ្ណាល័យនេះដែលបញ្ចប់ដោយភាពលំអៀងដែលយើងប្រើដើម្បីរកកន្លែងដែលផ្ទុកវត្ថុចងចាំ។
            // នេះគឺជាការគណនាចំលែកបន្តិចហើយជាលទ្ធផលនៃការព្យាយាមរឿងមួយចំនួននៅក្នុងព្រៃនិងមើលឃើញអ្វីដែលនៅជាប់។
            //
            // គំនិតទូទៅគឺថា `bias` បូកនឹងផ្នែក `stated_virtual_memory_address` របស់ផ្នែកនឹងទៅកន្លែងដែលនៅក្នុងអាស័យដ្ឋានពិតប្រាកដដែលផ្នែកស្ថិតនៅ។
            // រឿងផ្សេងទៀតដែលយើងពឹងផ្អែកលើការទោះបីគឺថាជាការពិតប្រាកដដក `bias` អាសយដ្ឋាននេះគឺសន្ទស្សន៍ដើម្បីរកមើលនៅក្នុងតារាងនិមិត្តសញ្ញានិង debuginfo នេះ។
            //
            // ទោះយ៉ាងណាក៏ដោយវាប្រែថាសម្រាប់បណ្ណាល័យដែលផ្ទុកប្រព័ន្ធប្រព័ន្ធការគណនាទាំងនេះមិនត្រឹមត្រូវទេ។ទោះយ៉ាងណាក៏ដោយសម្រាប់ការប្រតិបត្តិកំណើតវាហាក់ដូចជាត្រឹមត្រូវ។
            // លើកតក្កមួយចំនួនពីប្រភពរបស់វាបាន LLDB មួយចំនួនពិសេសករណីសម្រាប់ផ្នែក `__TEXT` ជាលើកដំបូងត្រូវបានផ្ទុកពីឯកសារដែលបានទូទាត់ដែលមានទំហំមិនសូន្យ 0 មួយ។
            // សម្រាប់ហេតុផលអ្វីដែលនៅពេលនេះគឺមានវត្តមានវាហាក់ដូចជាមានន័យថាតារាងនេះគឺទាក់ទងជានិមិត្តរូបដើម្បីគ្រាន់តែស្លាយ vmaddr សម្រាប់បណ្ណាល័យនេះ។
            // ប្រសិនបើវាមិនមានវត្តមានទេនោះតារាងនិមិត្តសញ្ញាគឺទាក់ទងទៅនឹងស្លាយ vmaddr បូកនឹងអាសយដ្ឋានដែលបានបញ្ជាក់របស់ផ្នែក។
            //
            // ដើម្បីដោះស្រាយស្ថានការណ៍នេះប្រសិនបើយើងមិនបានរកផ្នែកអត្ថបទនៅឯអុហ្វសិតឯកសារទេនោះយើងបង្កើនភាពលំអៀងដោយអាស័យដ្ឋានដែលបានបញ្ជាក់នៅក្នុងផ្នែកដំបូងនិងបន្ថយអាស័យដ្ឋានដែលបានបញ្ជាក់ដោយចំនួននោះផងដែរ។
            //
            // វិធីនោះតារាងនិមិត្តសញ្ញាតែងតែលេចឡើងទាក់ទងនឹងចំនួនលំអៀងរបស់បណ្ណាល័យ។
            // នេះហាក់ដូចជាមានលទ្ធផលត្រឹមត្រូវសម្រាប់និមិត្តសញ្ញាតាមរយៈតារាងនិមិត្តសញ្ញា។
            //
            // និយាយតាមត្រង់ទៅខ្ញុំមិនច្បាស់ទេថាតើនេះជាការត្រឹមត្រូវឬមានអ្វីផ្សេងទៀតដែលគួរតែបង្ហាញពីរបៀបធ្វើវា។
            // សំរាប់ពេលនេះទោះបីជាវាហាក់ដូចជាដំណើរការបានល្អគ្រប់គ្រាន់ក៏ដោយ (?) ហើយយើងគួរតែអាចបង្កើនល្បឿននេះបានគ្រប់ពេលប្រសិនបើចាំបាច់។
            //
            // សម្រាប់ព័ត៌មានបន្ថែមសូមមើល #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Unix ផ្សេងទៀត (ឧ
        // លីនុច) វេទិកាប្រើ ELF ដែលជាទ្រង់ទ្រាយឯកសារវត្ថុនិងជាធម្មតាគេហៅថា `dl_iterate_phdr` អនុវត្តការ API ដើម្បីផ្ទុកបណ្ណាល័យមួយដែលមានដើមកំណើត។
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` គួរតែជាអ្នកចង្អុលបង្ហាញត្រឹមត្រូវ។
        // `vec` គួរតែជាទ្រនិចត្រឹមត្រូវដល់ `std::Vec` ។
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 មិនគាំទ្រព័ត៌មានបំបាត់កំហុសទេប៉ុន្តែប្រព័ន្ធស្ថាបនានឹងដាក់ព័ត៌មានបំបាត់កំហុសនៅផ្លូវ `romfs:/debug_info.elf` ។
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // អ្វីៗផ្សេងទៀតគួរតែប្រើអេហ្វអ៊ីអេហ្វប៉ុន្តែមិនដឹងពីរបៀបផ្ទុកបណ្ណាល័យជនជាតិដើម។
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// បណ្ណាល័យដែលបានចែករំលែកទាំងអស់ដែលត្រូវបានគេស្គាល់ថាបានផ្ទុក។
    libraries: Vec<Library>,

    /// ធ្វើផែនទីឃ្លាំងសម្ងាត់ដែលយើងរក្សាទុកព័ត៌មានមនុស្សតឿដែលញែកជាផ្នែក ៗ ។
    ///
    /// បញ្ជីនេះមានសមត្ថភាពថេរសម្រាប់ការលើករបស់វាទាំងមូលដែលមិនដែលកើនឡើង។
    /// ធាតុ `usize` នៃគូនីមួយៗគឺជាសន្ទស្សន៍មួយទៅក្នុង `libraries` ខាងលើដែល `usize::max_value()` តំណាងឱ្យប្រតិបត្តិការបច្ចុប្បន្ន។
    ///
    /// `Mapping` គឺជាព័ត៌មានតឿមនុស្សតឿដែលត្រូវគ្នា។
    ///
    /// ចំណាំថានេះជាឃ្លាំងសម្ងាត់ LRU មួយហើយយើងនឹងផ្លាស់ប្តូរអ្វីៗនៅទីនេះនៅពេលយើងធ្វើនិមិត្តសញ្ញាអាសយដ្ឋាន។
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// ផ្នែកនៃបណ្ណាល័យនេះបានផ្ទុកទៅក្នុងសតិនិងកន្លែងដែលផ្ទុក។
    segments: Vec<LibrarySegment>,
    /// "bias" នៃបណ្ណាល័យនេះជាធម្មតាកន្លែងដែលវាផ្ទុកទៅក្នុងមេម៉ូរី។
    /// តម្លៃនេះត្រូវបានបន្ថែមទៅអាសយដ្ឋានថ្លែងផ្នែករបស់គ្នាដើម្បីទទួលបានអាស័យដ្ឋាននេះពិតប្រាកដសតិនិម្មិតដែលបានផ្ទុកផ្នែកចូលទៅក្នុង។
    /// លើសពីនេះទៀតភាពលំអៀងនេះត្រូវបានដកចេញពីអាសយដ្ឋានសតិពិតជាក់ស្តែងដើម្បីធ្វើសន្ទស្សន៍ទៅក្នុង debuginfo និងតារាងនិមិត្តសញ្ញា។
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// អាសយដ្ឋានដែលបានបញ្ជាក់នៃផ្នែកនេះនៅក្នុងឯកសារវត្ថុ។
    /// នេះគឺជាការពិតជាមិនមែនជាកន្លែងដែលផ្នែកនេះត្រូវបានផ្ទុកទេប៉ុន្តែជាអាសយដ្ឋាននេះបូក `bias` បណ្ណាល័យដែលមានគឺកន្លែងដែលត្រូវរកវាឃើញ។
    ///
    stated_virtual_memory_address: usize,
    /// ទំហំនៃផ្នែកទីនៅក្នុងសតិ។
    len: usize,
}

// មិនមានសុវត្ថិភាពនោះទេព្រោះនេះគឺត្រូវបានទាមទារដើម្បីធ្វើសមកាលកម្មខាងក្រៅ
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // មិនមានសុវត្ថិភាពនោះទេព្រោះនេះគឺត្រូវបានទាមទារដើម្បីធ្វើសមកាលកម្មខាងក្រៅ
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ឃ្លាំងសម្ងាត់ LRU តូចនិងសាមញ្ញបំផុតសម្រាប់ការគូសផែនទីព័ត៌មានបំបាត់កំហុស។
        //
        // អត្រាបុកគួរខ្ពស់ណាស់ព្រោះជង់ធម្មតាមិនឆ្លងរវាងបណ្ណាល័យដែលចែករំលែកគ្នាច្រើនទេ។
        //
        // រចនាសម្ព័ន្ធ `addr2line::Context` មានតម្លៃថ្លៃណាស់ក្នុងការបង្កើត។
        // ការចំណាយរបស់វាត្រូវបានគេរំពឹងថានឹងត្រូវបានផ្តល់តម្លៃដោយការសួរសំណួរ `locate` ជាបន្តបន្ទាប់ដែលជួយជម្រុញរចនាសម្ព័ន្ធដែលបានសាងសង់នៅពេលសាងសង់ `addr2line: : បរិបទ` ដើម្បីទទួលបានការបង្កើនល្បឿន។
        //
        // ប្រសិនបើយើងមិនមានឃ្លាំងសម្ងាត់នេះរំលស់ដែលនឹងមិនដែលកើតឡើងហើយនឹងមានដាន symbolicating ssssllllooooowwww ។
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ឡើងជាលើកដំបូង, ការធ្វើតេស្តនេះមានប្រសិនបើ `lib` ណាដែលមានផ្នែក (ការរើលំនៅដ្ឋានដោះស្រាយ) `addr` ។ប្រសិនបើការត្រួតពិនិត្យនេះឆ្លងកាត់បន្ទាប់មកយើងអាចបន្តនៅខាងក្រោមហើយបកប្រែអាសយដ្ឋាន។
                //
                // ចំណាំថាយើងកំពុងប្រើ `wrapping_add` នៅទីនេះដើម្បីជៀសវាងការត្រួតពិនិត្យលើសចំណុះ។វាត្រូវបានគេមើលឃើញនៅក្នុងព្រៃដែលគណនាលំអៀង SVMA + + ហូរ។
                // វាហាក់ដូចជាចម្លែកបន្តិចដែលនឹងកើតឡើងប៉ុន្តែមិនមានចំនួនដ៏ច្រើនដែលយើងអាចធ្វើអំពីវាក្រៅពីការមិនអើពើនឹងចម្រៀកទាំងនោះចាប់តាំងពីពួកគេទំនងជាកំពុងចូលទៅកាន់ទីអវកាស។
                //
                // ដើមឡើយបានកើតឡើងនៅក្នុង rust-lang/backtrace-rs#329 ។
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // ឥឡូវនេះយើងដឹងថា `lib` មានផ្ទុក `addr` យើងអាចទូទាត់ជាមួយនឹងភាពលំអៀងដើម្បីរកអាស័យដ្ឋានមេម៉ូរីដែលបានបញ្ជាក់។
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // មិនប្រែប្រួល: បន្ទាប់ពីបញ្ចប់លក្ខខណ្ឌនេះដោយគ្មានការវិលត្រឡប់មកដើម
        // ពីកំហុសការបញ្ចូលឃ្លាំងសម្ងាត់សម្រាប់ផ្លូវនេះគឺនៅសន្ទស្សន៍ ០ ។

        if let Some(idx) = idx {
            // នៅពេលដែលការគូសផែនទីមាននៅក្នុងឃ្លាំងសម្ងាត់រួចហើយសូមផ្លាស់ទីវាទៅផ្នែកខាងមុខ។
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // នៅពេលដែលការគូសផែនទីមិនមាននៅក្នុងឃ្លាំងសម្ងាត់បង្កើតផែនទីថ្មីបញ្ចូលវាទៅផ្នែកខាងមុខនៃឃ្លាំងសម្ងាត់ហើយបណ្តេញធាតុបញ្ចូលឃ្លាំងសម្ងាត់ចាស់ជាងគេបើចាំបាច់។
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // កុំធ្វើឱ្យលេចធ្លាយអាយុកាល `'static` សូមប្រាកដថាវាត្រូវបានគេធ្វើឱ្យប្រសើរសម្រាប់ខ្លួនយើង
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // ពង្រីកអាយុកាលរបស់ `sym` ដល់ `'static` ចាប់តាំងពីយើងត្រូវបានតម្រូវឱ្យអកុសលមកដល់ទីនេះប៉ុន្តែវាមិនមានជាឯកសារយោងទេដូច្នេះគ្មានឯកសារយោងណាមួយទាក់ទងនឹងវាគួរតែត្រូវបានបន្តហួសពីស៊ុមនេះទេ។
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // ចុងក្រោយទទួលយកផែនទីឃ្លាំងសម្ងាត់ឬបង្កើតផែនទីថ្មីសម្រាប់ឯកសារនេះហើយវាយតម្លៃព័ត៌មាន DWARF ដើម្បីរក file/line/name សម្រាប់អាសយដ្ឋាននេះ។
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// យើងអាចរកឃើញព័ត៌មានអំពីស៊ុមសម្រាប់និមិត្តសញ្ញានេះហើយស៊ុមរបស់ `addr2line នៅខាងក្នុងមានព័ត៌មានលម្អិតតូចតាចបំផុត។
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// មិនអាចរកឃើញពបំបាត់កំហុសប៉ុន្តែយើងបានរកឃើញវានៅក្នុងតារាងនិមិត្តរូបនៃ ELF ដែលអាចប្រតិបត្តិបាន។
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}