//! យុទ្ធសាស្រ្តជានិមិត្តសញ្ញាដែលបានប្រើកូដមនុស្សតឿ-ការញែកនៅ libbacktrace ។
//!
//! បណ្ណាល័យ libbacktrace C ដែលចែកចាយជាធម្មតាជាមួយ gcc គាំទ្រមិនត្រឹមតែបង្កើតដានទេ (ដែលយើងមិនប្រើ) ប៉ុន្តែក៏ជានិមិត្តរូបនៃដាននិងដោះស្រាយព័ត៌មានបំបាត់កំហុសអំពីវត្ថុផ្សេងៗដូចជាស៊ុមដែលបានបញ្ចូលនិងអ្វីដែលមិនមាន។
//!
//!
//! នេះមានភាពស្មុគស្មាញខ្លះដោយសារការព្រួយបារម្ភជាច្រើននៅទីនេះប៉ុន្តែគំនិតជាមូលដ្ឋានគឺ៖
//!
//! * ដំបូងយើងហៅថា `backtrace_syminfo` ។នេះទទួលបានពនិមិត្តសញ្ញាពីតារាងនិមិត្តសញ្ញាថាមវន្តប្រសិនបើយើងអាចធ្វើបាន។
//! * បន្ទាប់យើងហៅថា `backtrace_pcinfo` ។ការនេះនឹងញែក debuginfo តុប្រសិនបើពួកគេអាចប្រើបានជាច្រើនគេនិងអនុញ្ញាតឱ្យយើងងើបឡើងវិញអំពីស៊ុមក្នុងតួឈ្មោះឯកសារចំនួនបន្ទាត់, ល
//!
//! មានច្រើនឆបោកអំពីការទទួលតារាងមនុស្សតឿចូលទៅក្នុង libbacktrace នោះទេប៉ុន្តែសង្ឃឹមថាវាមិនមែនជាទីបញ្ចប់នៃពិភពលោកនេះហើយគឺគ្រប់គ្រាន់ច្បាស់ណាស់ពេលអានដូចខាងក្រោម។
//!
//! នេះគឺជាយុទ្ធសាស្រ្តនិមិត្តសញ្ញាលំនាំដើមសម្រាប់វេទិកាមិនមែនអេសវីអេជស៊ីនិងមិនមែនប្រព័ន្ធអូអេច។នៅក្នុង libstd ទោះបីជានេះជាយុទ្ធសាស្ត្រលំនាំដើមសម្រាប់ OSX ក៏ដោយ។
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // ប្រសិនបើអាចធ្វើបានចូលចិត្តឈ្មោះ `function` ដែលមកពី debuginfo ហើយជាធម្មតាអាចមានភាពត្រឹមត្រូវជាងមុនសម្រាប់ស៊ុមក្នុងតួឧទាហរណ៍។
                // ប្រសិនបើមិនមានទេទោះបីត្រលប់ទៅឈ្មោះតារាងនិមិត្តសញ្ញាដែលបានបញ្ជាក់នៅក្នុង `symname` ។
                //
                // ចំណាំថាពេលខ្លះ `function` អាចមានអារម្មណ៍ថាមិនត្រឹមត្រូវបន្តិចឧទាហរណ៍ឧទាហរណ៍ត្រូវបានចុះបញ្ជីជា `try<i32,closure>` isntead of `std::panicking::try::do_call` ។
                //
                // វាពិតជាមិនច្បាស់ថាហេតុអ្វីបាន, ប៉ុន្តែជារួមឈ្មោះ `function` ហាក់ដូចជាមានភាពត្រឹមត្រូវបន្ថែមទៀត។
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // កុំធ្វើអ្វីនៅពេលនេះ
}

/// ប្រភេទនៃទ្រនិច `data` បានឆ្លងចូលទៅក្នុង `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // នៅពេលការហៅត្រឡប់មកវិញនេះត្រូវបានគេហៅពី `backtrace_syminfo` នៅពេលយើងចាប់ផ្តើមដោះស្រាយយើងទៅហៅ `backtrace_pcinfo` បន្ថែមទៀត។
    // មុខងារ `backtrace_pcinfo` នឹងពិគ្រោះពបំបាត់កំហុសនិងការ attemp tto ធ្វើអ្វីដែលចង់សង្គ្រោះទិន្នន័យ file/line ថាជាស៊ុមផងដែរ inlined ជា។
    // ចំណាំថា `backtrace_pcinfo` អាចបរាជ័យឬមិនធ្វើអ្វីច្រើនប្រសិនបើមិនមានព័ត៌មានបំបាត់កំហុសដូច្នេះប្រសិនបើវាកើតឡើងយើងប្រាកដជាហៅទូរស័ព្ទមកវិញដែលមាននិមិត្តសញ្ញាយ៉ាងហោចណាស់មួយពី `syminfo_cb` ។
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// ប្រភេទនៃទ្រនិច `data` បានឆ្លងចូលទៅក្នុង `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API គាំទ្រការបង្កើតរដ្ឋប៉ុន្តែវាមិនគាំទ្រការបំផ្លាញរដ្ឋទេ។
// ខ្ញុំផ្ទាល់ទទួលយកនេះទៅមានន័យថារដ្ឋមួយមានន័យដើម្បីត្រូវបានបង្កើតឡើងហើយបន្ទាប់មកការផ្សាយបន្តផ្ទាល់ជារៀងរហូត។
//
// ខ្ញុំចង់ចុះឈ្មោះអ្នកដោះស្រាយ at_exit() ដែលសំអាតរដ្ឋនេះប៉ុន្តែ libbacktrace មិនមានវិធីដើម្បីធ្វើដូច្នេះទេ។
//
// ជាមួយនឹងឧបសគ្គទាំងនេះមុខងារនេះមានស្ថានភាពលាក់ទុកដែលត្រូវបានគណនាជាលើកដំបូងដែលត្រូវបានស្នើសុំ។
//
// សូមចងចាំថាការទ្រទ្រង់ទាំងអស់គឺកើតឡើងជារឿងធម្មតា (សោសកលមួយ) ។
//
// ចំណាំកង្វះនៃការធ្វើសមកាលកម្មនៅទីនេះគឺដោយសារតែតម្រូវការដែល `resolve` ត្រូវបានធ្វើសមកាលកម្មខាងក្រៅ។
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // មិនហាត់ប្រាណសមត្ថភាពនៃ libbacktrace threadsafe ចាប់តាំងពីពេលដែលយើងកំពុងបានហៅវាតែងតែនៅក្នុងម៉ូដធ្វើសមកាលកម្មមួយ។
        //
        0,
        error_cb,
        ptr::null_mut(), // មិនមានទិន្នន័យបន្ថែម
    );

    return STATE;

    // ចំណាំថាដើម្បីឱ្យ libbacktrace ដំណើរការវាចាំបាច់ត្រូវស្វែងរកព័ត៌មានបំបាត់កំហុសរបស់ DWARF សម្រាប់ប្រតិបត្តិការបច្ចុប្បន្ន។ជាធម្មតាវាធ្វើតាមរយៈយន្តការមួយចំនួនរួមទាំងប៉ុន្តែមិនកំណត់ចំពោះ៖
    //
    // * /proc/self/exe នៅលើវេទិកាដែលបានគាំទ្រ
    // * ឈ្មោះឯកសារបានឆ្លងកាត់យ៉ាងច្បាស់នៅពេលបង្កើតស្ថានភាព
    //
    // បណ្ណាល័យ libbacktrace គឺជាកូដដ៏ធំនៃកូដ C ។តាមធម្មជាតិនេះមានន័យថាវាមានភាពងាយរងគ្រោះខាងការចងចាំជាពិសេសនៅពេលដោះស្រាយ debuginfo ដែលមិនត្រឹមត្រូវ។
    // Libstd បានរត់ចូលទៅក្នុងបានើននៃការទាំងនេះជាប្រវត្តិសាស្ត្រ។
    //
    // ប្រសិនបើមាន /proc/self/exe ត្រូវបានប្រើបន្ទាប់មកយើងជាធម្មតាអាចមិនអើពើទាំងនេះជាយើងសន្មត់ថាគឺជាការ "mostly correct" libbacktrace ហើយបើមិនដូច្នេះទេមិនបានធ្វើអ្វីដែលចំលែកមួយ info កំហុសមនុស្សតឿ "attempted to be correct" ។
    //
    //
    // ទោះយ៉ាងណាក៏ដោយប្រសិនបើយើងហុចនៅក្នុងឈ្មោះឯកសារមួយបន្ទាប់មកវាអាចទៅរួចនៅលើវេទិកាមួយចំនួន (ដូចជាអេឌីអេសអេស) ដែលជាកន្លែងដែលតួអង្គព្យាបាទអាចបណ្តាលឱ្យឯកសារដែលបំពានត្រូវបានដាក់នៅទីតាំងនោះ។
    // នេះមានន័យថាប្រសិនបើយើងប្រាប់ libbacktrace អំពីឈ្មោះឯកសារវាអាចប្រើឯកសារបំពានដែលអាចបណ្តាលឱ្យមានអំពើហឹង្សា។
    // ប្រសិនបើយើងមិនប្រាប់អ្វីដែល libbacktrace ទេនោះវានឹងមិនធ្វើអ្វីនៅលើវេទិកាដែលមិនគាំទ្រផ្លូវដូចជា /proc/self/exe ទេ!
    //
    // អ្វីគ្រប់យ៉ាងដែលយើងបានព្យាយាមតាមដែលអាចធ្វើទៅបានដើម្បីមិនឆ្លងកាត់ឈ្មោះឯកសារប៉ុន្តែយើងត្រូវតែនៅលើវេទិកាដែលមិនគាំទ្រ /proc/self/exe ទាល់តែសោះ។
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // ចំណាំថាយើងចង់ប្រើ `std::env::current_exe` ប៉ុន្តែយើងមិនអាចទាមទារ `std` នៅទីនេះទេ។
            //
            // ប្រើ `_NSGetExecutablePath` ដើម្បីផ្ទុកផ្លូវដែលអាចប្រតិបត្តិបានបច្ចុប្បន្នទៅក្នុងតំបន់ឋិតិវន្ត (ដែលប្រសិនបើវាតូចពេកគ្រាន់តែបោះបង់) ។
            //
            //
            // ចំណាំថាយើងកំពុងទុកចិត្តយ៉ាងខ្លាំង libbacktrace នៅទីនេះដើម្បីមិនស្លាប់នៅលើប្រតិបត្តិប្រព្រឹត្តអំពើពុករលួយនោះទេប៉ុន្តែវាច្បាស់ណាស់ថាធ្វើ ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows មានរបៀបនៃការបើកឯកសារដែលបន្ទាប់ពីបើកវាវាមិនអាចលុបបានទេ។
            // នោះជាអ្វីដែលយើងចង់បាននៅទីនេះពីព្រោះយើងចង់ធានាថាការអនុវត្តរបស់យើងមិនត្រូវបានផ្លាស់ប្តូរចេញពីយើងទេបន្ទាប់ពីយើងប្រគល់ទៅ libbacktrace សង្ឃឹមថាអាចកាត់បន្ថយសមត្ថភាពបញ្ជូនទិន្នន័យដែលបំពានទៅក្នុង libbacktrace (ដែលអាចត្រូវបានបំភាន់) ។
            //
            //
            // បានផ្ដល់ឱ្យថាយើងធ្វើបន្តិចនៃការរាំនៅទីនេះមួយដើម្បីព្យាយាមដើម្បីទទួលបានតម្រៀបនៃការចាក់សោនៅលើរូបភាពផ្ទាល់ខ្លួនរបស់យើង:
            //
            // * យកចំណុចទាញទៅដំណើរការបច្ចុប្បន្នផ្ទុកឈ្មោះឯកសាររបស់វា។
            // * បើកឯកសារមួយទៅប្រព័ន្ធឯកសារជាមួយទង់ស្ដាំ។
            // * ផ្ទុកឈ្មោះឯកសារនៃដំណើរការបច្ចុប្បន្នដោយធ្វើឱ្យប្រាកដថាវាដូចគ្នា
            //
            // ប្រសិនបើវាឆ្លងកាត់ទាំងអស់តាមទ្រឹស្តីយើងពិតជាបានបើកឯកសារដំណើរការរបស់យើងហើយយើងត្រូវបានធានាថាវានឹងមិនផ្លាស់ប្តូរទេ។FWIW bunch នៃនេះត្រូវបានចម្លងមកពី libstd ប្រវត្តិសាស្ត្រ, ដូច្នេះនេះគឺជាការបកស្រាយល្អបំផុតនៃអ្វីដែលបានកើតឡើងរបស់ខ្ញុំ។
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // នេះរស់នៅក្នុងការចងចាំឋិតិវន្តដូច្នេះយើងអាចយកវាមកវិញបាន ។.
                static mut BUF: [i8; N] = [0; N];
                // ... ហើយនេះរស់នៅលើជង់ចាប់តាំងពីវាជាបណ្តោះអាសន្ន
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // ការលេចចេញ `handle` X ដោយចេតនានៅទីនេះពីព្រោះការបើកនោះគួរតែការពារសោរបស់យើងលើឈ្មោះឯកសារនេះ។
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // យើងចង់ត្រលប់មកវិញនូវចំណិតដែលត្រូវបានបញ្ចប់ដូច្នេះបើអ្វីៗគ្រប់យ៉ាងត្រូវបានបំពេញហើយវាស្មើនឹងប្រវែងសរុបបន្ទាប់មកស្មើនឹងការបរាជ័យ។
                //
                //
                // បើមិនដូច្នោះទេនៅពេលត្រឡប់មកវិញភាពជោគជ័យត្រូវប្រាកដថាបៃណុលត្រូវបានបញ្ចូលក្នុងចំណិត។
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // កំហុសដានបច្ចុប្បន្នត្រូវបានបោកបក់នៅក្រោមព្រំ
    let state = init_state();
    if state.is_null() {
        return;
    }

    // ហៅ API របស់ `backtrace_syminfo` ដែល (ពីការអានកូដ) គួរហៅ `syminfo_cb` យ៉ាងពិតប្រាកដម្តង (ឬបរាជ័យដោយមានកំហុសមួយសន្មត) ។
    // បន្ទាប់មកយើងដោះស្រាយបន្ថែមទៀតនៅក្នុង `syminfo_cb` ។
    //
    // ចំណាំថាយើងធ្វើដូចនេះព្រោះ `syminfo` នឹងពិគ្រោះជាមួយតារាងនិមិត្តសញ្ញាដោយស្វែងរកឈ្មោះនិមិត្តសញ្ញាទោះបីជាមិនមានព័ត៌មានបំបាត់កំហុសនៅក្នុងប្រព័ន្ធគោលពីរក៏ដោយ។
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}