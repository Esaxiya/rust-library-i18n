use super::{Context, Mapping, Path, Stash, Vec};
use core::convert::TryFrom;
use object::elf::{ELFCOMPRESS_ZLIB, SHF_COMPRESSED};
use object::read::elf::{CompressionHeader, FileHeader, SectionHeader, SectionTable, Sym};
use object::read::StringTable;
use object::{BigEndian, Bytes, NativeEndian};

#[cfg(target_pointer_width = "32")]
type Elf = object::elf::FileHeader32<NativeEndian>;
#[cfg(target_pointer_width = "64")]
type Elf = object::elf::FileHeader64<NativeEndian>;

impl Mapping {
    pub fn new(path: &Path) -> Option<Mapping> {
        let map = super::mmap(path)?;
        Mapping::mk(map, |data, stash| Context::new(stash, Object::parse(data)?))
    }
}

struct ParsedSym {
    address: u64,
    size: u64,
    name: u32,
}

pub struct Object<'a> {
    /// ប្រភេទទំហំសូន្យតំណាងឱ្យ endianness ដើម។
    ///
    /// យើងអាចប្រើព្យញ្ជនៈជំនួសវិញប៉ុន្តែវាជួយធានានូវភាពត្រឹមត្រូវ។
    endian: NativeEndian,
    /// ទិន្នន័យឯកសារទាំងមូល។
    data: Bytes<'a>,
    sections: SectionTable<'a, Elf>,
    strings: StringTable<'a>,
    /// បញ្ជីនិមិត្តសញ្ញាដែលបានបែងចែកជាមុននិងតម្រៀបតាមអាស័យដ្ឋានគោល។
    syms: Vec<ParsedSym>,
}

impl<'a> Object<'a> {
    fn parse(data: &'a [u8]) -> Option<Object<'a>> {
        let data = object::Bytes(data);
        let elf = Elf::parse(data).ok()?;
        let endian = elf.endian().ok()?;
        let sections = elf.sections(endian, data).ok()?;
        let mut syms = sections
            .symbols(endian, data, object::elf::SHT_SYMTAB)
            .ok()?;
        if syms.is_empty() {
            syms = sections
                .symbols(endian, data, object::elf::SHT_DYNSYM)
                .ok()?;
        }
        let strings = syms.strings();

        let mut syms = syms
            .iter()
            // មើលតែនិមិត្តសញ្ញា function/object ប៉ុណ្ណោះ។
            // នេះឆ្លុះបញ្ចាំងពីអ្វីដែល libbacktrace ធ្វើហើយជាទូទៅយើងគ្រាន់តែជានិមិត្តរូបនៃមុខងារមុខងារនៅក្នុងទ្រឹស្តីប៉ុណ្ណោះ។
            // និមិត្តសញ្ញាវត្ថុទាក់ទងនឹងទិន្នន័យហើយប្រហែលជានរណាម្នាក់ឆ្កួតល្មមដែលមានមុខងារចូលទៅក្នុងទិន្នន័យឋិតិវន្ត?
            //
            //
            .filter(|sym| {
                let st_type = sym.st_type();
                st_type == object::elf::STT_FUNC || st_type == object::elf::STT_OBJECT
            })
            // រំលងអ្វីៗដែលមាននៅក្នុងផ្នែកក្បាលដែលមិនបានកំណត់ព្រោះវាមានន័យថាវាជាមុខងារនាំចូលហើយយើងគ្រាន់តែជានិមិត្តរូបជាមួយមុខងារដែលបានកំណត់ក្នុងមូលដ្ឋានប៉ុណ្ណោះ។
            //
            //
            .filter(|sym| sym.st_shndx(endian) != object::elf::SHN_UNDEF)
            .map(|sym| {
                let address = sym.st_value(endian).into();
                let size = sym.st_size(endian).into();
                let name = sym.st_name(endian);
                ParsedSym {
                    address,
                    size,
                    name,
                }
            })
            .collect::<Vec<_>>();
        syms.sort_unstable_by_key(|s| s.address);
        Some(Object {
            endian,
            data,
            sections,
            strings,
            syms,
        })
    }

    pub fn section(&self, stash: &'a Stash, name: &str) -> Option<&'a [u8]> {
        if let Some(section) = self.section_header(name) {
            let mut data = section.data(self.endian, self.data).ok()?;

            // ពិនិត្យមើលសម្រាប់ការបង្ហាប់ (gABI) មនុស្សតឿស្តង់ដារពោលគឺជាការបង្កើតដោយទង់ជាតិ `--compress-debug-sections=zlib-gabi` ld នេះ។
            //
            let flags: u64 = section.sh_flags(self.endian).into();
            if (flags & u64::from(SHF_COMPRESSED)) == 0 {
                // មិនបានបង្ហាប់។
                return Some(data.0);
            }

            let header = data.read::<<Elf as FileHeader>::CompressionHeader>().ok()?;
            if header.ch_type(self.endian) != ELFCOMPRESS_ZLIB {
                // ការបង្ហាប់ Zlib គឺជាប្រភេទដែលគេស្គាល់តែមួយគត់។
                return None;
            }
            let size = usize::try_from(header.ch_size(self.endian)).ok()?;
            let buf = stash.allocate(size);
            decompress_zlib(data.0, buf)?;
            return Some(buf);
        }

        // ពិនិត្យមើលទ្រង់ទ្រាយបង្ហាប់ GNU ដែលមិនមែនជាស្តង់ដារពោលគឺបានបង្កើតដោយទង់ `--compress-debug-sections=zlib-gnu` របស់អិល។
        // នេះមានន័យថាប្រសិនបើយើងពិតជាស្នើសុំ `.debug_info` បន្ទាប់មកយើងត្រូវរកមើលផ្នែកមួយដែលមានឈ្មោះថា `.zdebug_info` ។
        //
        //
        if !name.starts_with(".debug_") {
            return None;
        }
        let debug_name = name[7..].as_bytes();
        let compressed_section = self
            .sections
            .iter()
            .filter_map(|header| {
                let name = self.sections.section_name(self.endian, header).ok()?;
                if name.starts_with(b".zdebug_") && &name[8..] == debug_name {
                    Some(header)
                } else {
                    None
                }
            })
            .next()?;
        let mut data = compressed_section.data(self.endian, self.data).ok()?;
        if data.read_bytes(8).ok()?.0 != b"ZLIB\0\0\0\0" {
            return None;
        }
        let size = usize::try_from(data.read::<object::U32Bytes<_>>().ok()?.get(BigEndian)).ok()?;
        let buf = stash.allocate(size);
        decompress_zlib(data.0, buf)?;
        Some(buf)
    }

    fn section_header(&self, name: &str) -> Option<&<Elf as FileHeader>::SectionHeader> {
        self.sections
            .section_by_name(self.endian, name.as_bytes())
            .map(|(_index, section)| section)
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        // ការស្វែងរកគោលពីរដូចគ្នានឹង Windows ខាងលើ
        let i = match self.syms.binary_search_by_key(&addr, |sym| sym.address) {
            Ok(i) => i,
            Err(i) => i.checked_sub(1)?,
        };
        let sym = self.syms.get(i)?;
        if sym.address <= addr && addr <= sym.address + sym.size {
            self.strings.get(sym.name).ok()
        } else {
            None
        }
    }

    pub(super) fn search_object_map(&self, _addr: u64) -> Option<(&Context<'_>, u64)> {
        None
    }
}

fn decompress_zlib(input: &[u8], output: &mut [u8]) -> Option<()> {
    use miniz_oxide::inflate::core::inflate_flags::{
        TINFL_FLAG_PARSE_ZLIB_HEADER, TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF,
    };
    use miniz_oxide::inflate::core::{decompress, DecompressorOxide};
    use miniz_oxide::inflate::TINFLStatus;

    let (status, in_read, out_read) = decompress(
        &mut DecompressorOxide::new(),
        input,
        output,
        0,
        TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF | TINFL_FLAG_PARSE_ZLIB_HEADER,
    );
    if status == TINFLStatus::Done && in_read == input.len() && out_read == output.len() {
        Some(())
    } else {
        None
    }
}