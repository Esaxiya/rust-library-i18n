use super::{Context, Mapping, Path, Stash, Vec};
use core::convert::TryFrom;
use object::pe::{ImageDosHeader, ImageSymbol};
use object::read::pe::{ImageNtHeaders, ImageOptionalHeader, SectionTable};
use object::read::StringTable;
use object::{Bytes, LittleEndian as LE};

#[cfg(target_pointer_width = "32")]
type Pe = object::pe::ImageNtHeaders32;
#[cfg(target_pointer_width = "64")]
type Pe = object::pe::ImageNtHeaders64;

impl Mapping {
    pub fn new(path: &Path) -> Option<Mapping> {
        let map = super::mmap(path)?;
        Mapping::mk(map, |data, stash| Context::new(stash, Object::parse(data)?))
    }
}

pub struct Object<'a> {
    data: Bytes<'a>,
    sections: SectionTable<'a>,
    symbols: Vec<(usize, &'a ImageSymbol)>,
    strings: StringTable<'a>,
}

pub fn get_image_base(data: &[u8]) -> Option<usize> {
    let data = Bytes(data);
    let dos_header = ImageDosHeader::parse(data).ok()?;
    let (nt_headers, _, _) = dos_header.nt_headers::<Pe>(data).ok()?;
    usize::try_from(nt_headers.optional_header().image_base()).ok()
}

impl<'a> Object<'a> {
    fn parse(data: &'a [u8]) -> Option<Object<'a>> {
        let data = Bytes(data);
        let dos_header = ImageDosHeader::parse(data).ok()?;
        let (nt_headers, _, nt_tail) = dos_header.nt_headers::<Pe>(data).ok()?;
        let sections = nt_headers.sections(nt_tail).ok()?;
        let symtab = nt_headers.symbols(data).ok()?;
        let strings = symtab.strings();
        let image_base = usize::try_from(nt_headers.optional_header().image_base()).ok()?;

        // ប្រមូលនិមិត្តសញ្ញាទាំងអស់ទៅក្នុង vector ក្នុងតំបន់ដែលត្រូវបានតម្រៀបតាមអាស័យដ្ឋាននិងមានទិន្នន័យគ្រប់គ្រាន់ដើម្បីរៀនអំពីឈ្មោះនិមិត្តសញ្ញា។
        // ចំណាំថាយើងមើលតែនិមិត្តសញ្ញាមុខងារហើយក៏ត្រូវកត់សម្គាល់ផងដែរថាផ្នែកត្រូវបានដាក់លិបិក្រមព្រោះផ្នែកសូន្យគឺពិសេស (apparently) ។
        //
        //
        //
        let mut symbols = Vec::new();
        let mut i = 0;
        let len = symtab.len();
        while i < len {
            let sym = symtab.symbol(i).ok()?;
            i += 1 + sym.number_of_aux_symbols as usize;
            let section_number = sym.section_number.get(LE);
            if sym.derived_type() != object::pe::IMAGE_SYM_DTYPE_FUNCTION || section_number == 0 {
                continue;
            }
            let addr = usize::try_from(sym.value.get(LE)).ok()?;
            let section = sections
                .section(usize::try_from(section_number).ok()?)
                .ok()?;
            let va = usize::try_from(section.virtual_address.get(LE)).ok()?;
            symbols.push((addr + va + image_base, sym));
        }
        symbols.sort_unstable_by_key(|x| x.0);
        Some(Object {
            data,
            sections,
            strings,
            symbols,
        })
    }

    pub fn section(&self, _: &Stash, name: &str) -> Option<&'a [u8]> {
        Some(
            self.sections
                .section_by_name(self.strings, name.as_bytes())?
                .1
                .pe_data(self.data)
                .ok()?
                .0,
        )
    }

    pub fn search_symtab<'b>(&'b self, addr: u64) -> Option<&'b [u8]> {
        // ចំណាំថាមិនដូចទ្រង់ទ្រាយផ្សេងទៀតទេ COFF មិនបង្កប់ទំហំនិមិត្តសញ្ញានីមួយៗឡើយ។
        // ក្នុងនាមជាការខិតខំប្រឹងប្រែងស្នាមភ្លោះចុងក្រោយស្វែងរកនិមិត្តសញ្ញា * ដែលនៅជិតបំផុតទៅអាសយដ្ឋានជាក់លាក់ហើយប្រគល់វាវិញ។
        // នេះទទួលបានពិតជា wonky ម្តងនិមិត្តសញ្ញាចាប់ផ្តើមការយកចេញព្រោះតែនិមិត្តសញ្ញាដែលបានត្រឡប់មកវិញនៅទីនេះអាចជាការមិនត្រឹមត្រូវទាំងស្រុងនោះទេប៉ុន្តែយើងមានគំនិតនៃការដឹងពីរបៀបដើម្បីរកឱ្យឃើញថាគ្មាន។
        //
        //
        //
        let addr = usize::try_from(addr).ok()?;
        let i = match self.symbols.binary_search_by_key(&addr, |p| p.0) {
            Ok(i) => i,
            // ជាធម្មតា `addr` មិនស្ថិតនៅក្នុងជួរនោះទេប៉ុន្តែ `i` គឺជាកន្លែងដែលយើងបញ្ចូលវាដូច្នេះទីតាំងមុនត្រូវតែតូចជាង `addr` ។
            //
            //
            Err(i) => i.checked_sub(1)?,
        };
        self.symbols[i].1.name(self.strings).ok()
    }

    pub(super) fn search_object_map(&self, _addr: u64) -> Option<(&Context<'_>, u64)> {
        None
    }
}