// ប្រើតែលើ Linux ឥឡូវនេះដូច្នេះអនុញ្ញាតអោយលេខកូដដែលស្លាប់នៅកន្លែងផ្សេង
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// អ្នកបែងចែកសង្វៀនធម្មតាសម្រាប់ប៊ូហ្វេ។
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// បែងចែកសតិបណ្ដោះអាសន្ននៃទំហំដែលបានបញ្ជាក់ហើយត្រឡប់សេចក្តីយោងដែលអាចប្តូរបានទៅវា។
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // សុវត្ថិភាព: នេះគឺជាមុខងារតែមួយគត់ដែលបង្កើតការផ្លាស់ប្តូរបាន
        // យោងទៅ `self.buffers` ។
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // សុវត្ថិភាព: យើងមិនដែលយកធាតុចេញពី `self.buffers` ទេដូច្នេះឯកសារយោង
        // ចំពោះទិន្នន័យនៅខាងក្នុងសតិបណ្ដោះអាសន្នណាមួយនឹងរស់នៅដរាបណា `self` មានដំណើរការ។
        &mut buffers[i]
    }
}