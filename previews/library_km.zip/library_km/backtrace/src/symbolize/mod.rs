use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// ដោះស្រាយអាស័យដ្ឋានទៅនិមិត្តសញ្ញាដោយឆ្លងកាត់និមិត្តសញ្ញាទៅនឹងការបិទដែលបានបញ្ជាក់។
///
/// មុខងារនេះនឹងរកមើលអាស័យដ្ឋានដែលបានផ្តល់នៅក្នុងតំបន់ដូចជាតារាងនិមិត្តសញ្ញាក្នុងតំបន់តារាងនិមិត្តសញ្ញាថាមវន្តឬព័ត៌មានបំបាត់កំហុសរបស់ DWARF (អាស្រ័យលើការអនុវត្តដែលបានធ្វើឱ្យសកម្ម) ដើម្បីស្វែងរកនិមិត្តសញ្ញាដើម្បីទទួលបានលទ្ធផល។
///
///
/// ការបិទនេះប្រហែលជាមិនត្រូវបានគេហៅទេប្រសិនបើដំណោះស្រាយមិនអាចត្រូវបានអនុវត្តហើយវាក៏អាចត្រូវបានគេហៅថាច្រើនជាងម្តងក្នុងករណីមុខងារបញ្ចូល។
///
/// និមិត្តសញ្ញាជំរុញអោយតំណាងឱ្យការប្រតិបត្តិនៅ `addr` បានបញ្ជាក់ត្រឡប់គូ file/line សម្រាប់អាសយដ្ឋានថា (ប្រសិនបើមាន) ។
///
/// ចំណាំថាប្រសិនបើអ្នកមាន `Frame` មួយហើយបន្ទាប់មកវាត្រូវបានផ្ដល់អនុសាសន៍ឱ្យប្រើមុខងារ `resolve_frame` ជំនួសឱ្យការមួយនេះ។
///
/// # លក្ខណៈពិសេសដែលត្រូវការ
///
/// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
///
/// # Panics
///
/// មុខងារនេះព្យាយាមមិនដែល panic ទេប៉ុន្តែប្រសិនបើ `cb` បានផ្តល់ panics បន្ទាប់មកវេទិកាមួយចំនួននឹងបង្ខំឱ្យ panic ទ្វេរដងដើម្បីបញ្ឈប់ដំណើរការ។
/// វេទិកាខ្លះប្រើបណ្ណាល័យ C ដែលប្រើការហៅត្រឡប់មកវិញដែលមិនអាចធ្វើបានដូច្នេះការភ័យស្លន់ស្លោពី `cb` អាចបង្កឱ្យមានការបញ្ឈប់ដំណើរការ។
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // មើលតែស៊ុមខាងលើប៉ុណ្ណោះ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// ដោះស្រាយការចាប់យកពីមុនស៊ុមមួយដើម្បីជានិមិត្តរូបមួយឆ្លងកាត់និមិត្តសញ្ញាទៅបិទបានបញ្ជាក់នោះទេ។
///
/// Functin នេះដំណើរការមុខងារដូចគ្នានឹង `resolve` ដែរលើកលែងតែវាយក `Frame` ជាអាគុយម៉ង់ជំនួសឱ្យអាស័យដ្ឋាន។
/// នេះអាចអនុញ្ញាតឱ្យមានការអនុវត្តវេទិកាមួយចំនួននៃការគាំទ្រខាងក្រោយដើម្បីផ្តល់ព័ត៌មាននិមិត្តសញ្ញាឬព័ត៌មាននិមិត្តសញ្ញាដែលមានភាពត្រឹមត្រូវជាងមុន។
///
/// វាត្រូវបានផ្ដល់អនុសាសន៍ឱ្យប្រើវាប្រសិនបើអ្នកអាចធ្វើបាន។
///
/// # លក្ខណៈពិសេសដែលត្រូវការ
///
/// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
///
/// # Panics
///
/// មុខងារនេះព្យាយាមមិនដែល panic ទេប៉ុន្តែប្រសិនបើ `cb` បានផ្តល់ panics បន្ទាប់មកវេទិកាមួយចំនួននឹងបង្ខំឱ្យ panic ទ្វេរដងដើម្បីបញ្ឈប់ដំណើរការ។
/// វេទិកាខ្លះប្រើបណ្ណាល័យ C ដែលប្រើការហៅត្រឡប់មកវិញដែលមិនអាចធ្វើបានដូច្នេះការភ័យស្លន់ស្លោពី `cb` អាចបង្កឱ្យមានការបញ្ឈប់ដំណើរការ។
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // មើលតែស៊ុមខាងលើប៉ុណ្ណោះ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// តម្លៃ IP ពីស៊ុមជង់ជាធម្មតា (always?) ការណែនាំ *បន្ទាប់ពី* ការហៅដែលជាដានជង់ពិតប្រាកដ។
// និមិត្តសញ្ញានេះនៅលើបណ្តាលឱ្យលេខ filename/line ឈានមុខគេហើយប្រហែលជាចូលទៅក្នុងមោឃៈប្រសិនបើវាជិតដល់ចុងបញ្ចប់នៃមុខងារ។
//
// ហាក់ដូចជាមូលដ្ឋានតែងតែនេះជាករណីលើគ្រប់វេទិកាទាំងអស់នេះដូច្នេះយើងតែងតែដកលេខមួយពី IP ដោះស្រាយមួយដើម្បីដោះស្រាយវាដើម្បីការណែនាំការហៅមុនជំនួសឱ្យការការបង្រៀនដែលត្រូវបានវិលត្រឡប់ទៅវិញ។
//
//
// តាមឧត្ដមគតិយើងនឹងមិនធ្វើបែបនេះទេ។
// តាមឧត្ដមគតិយើងតម្រូវឱ្យអ្នកទូរស័ព្ទ `resolve` APIs នៅទីនេះធ្វើ -1 ដោយដៃហើយគណនីដែលពួកគេចង់បានព័ត៌មានទីតាំងសម្រាប់ការណែនាំមុន * មិនមែនបច្ចុប្បន្នទេ។
// តាមឧត្ដមគតិផងដែរនឹងលាតត្រដាងយើងនៅលើ `Frame` បើយើងពិតជាអាសយដ្ឋានរបស់ការណែនាំបន្ទាប់ឬបច្ចុប្បន្ន។
//
// សំរាប់ពេលនេះទោះបីជានេះគឺជាការព្រួយបារម្ភពិសេសណាស់ដូច្នេះយើងគ្រាន់តែដកខ្លួនចេញពីខាងក្នុងប៉ុណ្ណោះ។
// អតិថិជនគួររក្សាការធ្វើការនិងទទួលបានលទ្ធផលល្អណាស់, ដូច្នេះយើងគួរតែគ្រប់គ្រាន់ល្អ។
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// ដូចគ្នា `resolve`, តែមិនមានសុវត្ថិភាពដូចជាវាជា unsynchronized ។
///
/// មុខងារនេះមិនមាន guarentees ធ្វើសមកាលកម្មទេប៉ុន្តែអាចប្រើបាននៅពេលដែលលក្ខណៈពិសេស `std` នៃ crate មិនត្រូវបានចងក្រង។
/// មើលមុខងារ `resolve` សម្រាប់ឯកសារនិងឧទាហរណ៍បន្ថែម។
///
/// # Panics
///
/// សូមមើលអំពី `resolve` សម្រាប់ការរំលឹកនៅលើ panicking `cb` ។
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// ដូចគ្នា `resolve_frame`, តែមិនមានសុវត្ថិភាពដូចជាវាជា unsynchronized ។
///
/// មុខងារនេះមិនមាន guarentees ធ្វើសមកាលកម្មទេប៉ុន្តែអាចប្រើបាននៅពេលដែលលក្ខណៈពិសេស `std` នៃ crate មិនត្រូវបានចងក្រង។
/// សូមមើលមុខងារ `resolve_frame` ឯកសារនិងឧទាហរណ៍បន្ថែមទៀត។
///
/// # Panics
///
/// សូមមើលអំពី `resolve_frame` សម្រាប់ការរំលឹកនៅលើ panicking `cb` ។
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait តំណាងឱ្យដំណោះស្រាយនៃនិមិត្តសញ្ញានៅក្នុងឯកសារមួយ។
///
/// trait នេះត្រូវបានផ្តល់ជាវត្ថុ trait ទៅនឹងការបិទដែលត្រូវបានផ្តល់ទៅឱ្យមុខងារ `backtrace::resolve` ហើយវាត្រូវបានគេចែកចាយស្ទើរតែមិនដឹងថាតើការអនុវត្តមួយណានៅពីក្រោយវា។
///
///
/// និមិត្តសញ្ញាអាចផ្តល់ព័ត៌មានបរិបទអំពីមុខងារឧទាហរណ៍ឈ្មោះឈ្មោះឯកសារលេខបន្ទាត់អាសយដ្ឋានច្បាស់លាស់ជាដើម។
/// មិនមានព័ត៌មានទាំងអស់សុទ្ធតែមាននៅក្នុងនិមិត្តសញ្ញានោះទេដូច្នេះវិធីសាស្រ្តទាំងអស់ផ្តល់មកវិញនូវ `Option` ។
///
///
pub struct Symbol {
    // TODO: ជីវិតនេះតម្រូវការនឹងត្រូវបានចងនៅទីបំផុតទៅ `Symbol` បន្ត,
    // ប៉ុន្តែនោះជាការផ្លាស់ប្តូរថ្មី។
    // សម្រាប់ពេលឥឡូវនេះគឺមានសុវត្ថិភាពចាប់តាំងពីការដែលមិនធ្លាប់មានតែមួយគត់ដែលត្រូវបាន `Symbol` ប្រគល់ដោយយោងនិងមិនអាចត្រូវបានក្លូន។
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ត្រឡប់ឈ្មោះនៃអនុគមន៍នេះ។
    ///
    /// រចនាសម្ព័ន្ធដែលត្រឡប់មកវិញអាចត្រូវបានប្រើដើម្បីសាកសួរអំពីលក្ខណៈសម្បត្តិផ្សេងៗគ្នាអំពីឈ្មោះនិមិត្តសញ្ញា
    ///
    ///
    /// * ការអនុវត្ត `Display` នឹងបោះពុម្ពចេញសញ្ញា demangled ។
    /// * តម្លៃ `str` ធាតុដើមនៃនិមិត្តសញ្ញាដែលអាចត្រូវបានចូលដំណើរការ (បើវា utf-8 ត្រឹមត្រូវ) ។
    /// * បៃឆៅសម្រាប់ឈ្មោះនិមិត្តសញ្ញាអាចចូលបាន។
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// ត្រឡប់អាសយដ្ឋានចាប់ផ្តើមនៃមុខងារនេះ។
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// ត្រឡប់ឈ្មោះឯកសារឆៅជាចំណិត ៗ ។
    /// នេះគឺជាចម្បងប្រយោជន៍សម្រាប់បរិស្ថាន `no_std` ។
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ត្រឡប់ចំនួនជួរឈរសម្រាប់កន្លែងដែលបច្ចុប្បន្ននេះត្រូវបានប្រតិបត្តិជានិមិត្តរូប។
    ///
    /// មានតែ gimli បច្ចុប្បន្ននេះផ្តល់នូវតម្លៃនៅទីនេះហើយសូម្បីតែបន្ទាប់មកប្រសិនបើ `filename` ត្រឡប់ `Some` ហើយដូច្នេះវាជាលទ្ធផលដែលត្រូវបានធ្វើឱ្យស្រដៀងគ្នា។
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ត្រឡប់លេខជួរសម្រាប់កន្លែងដែលនិមិត្តសញ្ញានេះកំពុងប្រតិបត្តិ។
    ///
    /// តម្លៃត្រឡប់នេះជាធម្មតា `Some` ប្រសិនបើ `filename` ត្រឡប់ `Some` ហើយដូច្នេះវាអាចមានលក្ខណៈស្រដៀងគ្នា។
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ត្រឡប់ឈ្មោះឯកសារដែលមុខងារនេះត្រូវបានកំណត់។
    ///
    /// បច្ចុប្បន្ននេះអាចប្រើបានតែនៅពេល libbacktrace ឬ gimli កំពុងត្រូវបានប្រើ (ឧ
    /// unix វេទិកាផ្សេងទៀត) ហើយនៅពេលដែលប្រព័ន្ធគោលពីរត្រូវបានចងក្រងជាមួយ debuginfo ។
    /// បើសិនជាមិនមាននៃលក្ខខណ្ឌទាំងនេះត្រូវបានជួបប្រជុំគ្នាបន្ទាប់មកនេះនឹងវិលត្រឡប់មកវិញ `None` ទំនង។
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ប្រហែលជាមាននិមិត្តសញ្ញា C++ ញែក, បើញែកជានិមិត្តរូប mangled ជាការ Rust បរាជ័យ។
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ធ្វើឱ្យប្រាកដថាដើម្បីរក្សាការនេះមានទំហំសូន្យដូច្នេះថាលក្ខណៈពិសេស `cpp_demangle` មានការចំណាយនោះទេនៅពេលដែលជនពិការ។
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// រុំព័ទ្ធជុំវិញឈ្មោះនិមិត្តសញ្ញាដើម្បីផ្តល់នូវគ្រឿងបន្លាស់ដែលមិនត្រឹមត្រូវទៅនឹងឈ្មោះដែលបានបោះចោលបៃឆៅខ្សែអក្សរដើម។ ល។
///
// អនុញ្ញាតឱ្យកូដដែលបានស្លាប់សម្រាប់នៅពេលដែលលក្ខណៈពិសេស `cpp_demangle` មិនត្រូវបានបើក។
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// បង្កើតឈ្មោះនិមិត្តសញ្ញាថ្មីពីបាសមូលដ្ឋានឆៅ។
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// ត្រឡប់ឈ្មោះនិមិត្តសញ្ញា (mangled) ឆៅជា `str` ប្រសិនបើនិមិត្តសញ្ញាមានសុពលភាព utf-8 ។
    ///
    /// ប្រើការអនុវត្ត `Display` ប្រសិនបើអ្នកចង់បានកំណែដែលបានដោះចេញ។
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// ត្រឡប់ឈ្មោះនិមិត្តសញ្ញាឆៅជាបញ្ជីបៃ
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // វាអាចបោះពុម្ពប្រសិនបើនិមិត្តសញ្ញាដែលបានបោះចោលមិនត្រឹមត្រូវដូច្នេះត្រូវដោះស្រាយកំហុសនៅទីនេះដោយមិនផ្សព្វផ្សាយវានៅខាងក្រៅ។
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// ព្យាយាមដើម្បីទាមទារការចងចាំទុកក្នុងឃ្លាំងសម្ងាត់ដែលបានប្រើដើម្បីអាសយដ្ឋាននិមិត្តសញ្ញា។
///
/// វិធីសាស្រ្តនេះនឹងព្យាយាមបញ្ចេញរចនាសម្ព័ន្ធទិន្នន័យសកលណាមួយដែលត្រូវបានរក្សាទុកជាសកលឬនៅក្នុងខ្សែស្រឡាយដែលជាធម្មតាតំណាងឱ្យពត៌មាន DWARF ដែលញែកឬស្រដៀងគ្នា។
///
///
/// # Caveats
///
/// ខណៈពេលដែលមុខងារនេះគឺអាចប្រើបានជានិច្ចវាពិតជាមិនធ្វើអ្វីលើការអនុវត្តភាគច្រើនទេ។
/// បណ្ណាល័យដូចជា dbghelp ឬ libbacktrace មិនផ្តល់គ្រឿងបរិក្ខារដើម្បីដោះស្រាយរដ្ឋនិងគ្រប់គ្រងអង្គចងចាំដែលបានបម្រុងទុកទេ។
/// សម្រាប់ពេលនេះលក្ខណៈពិសេស `gimli-symbolize` នៃ crate នេះគឺជាមុខងារតែមួយគត់ដែលមុខងារនេះមានប្រសិទ្ធិភាព។
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}