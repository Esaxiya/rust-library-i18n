//! បណ្ណាល័យសម្រាប់ការទទួលបានដាននៅពេលរត់
//!
//! បណ្ណាល័យនេះត្រូវបានន័យដើម្បីបន្ថែមការគាំទ្រ `RUST_BACKTRACE=1` បណ្ណាល័យស្ដង់ដារដោយអនុញ្ញាតឱ្យការទិញយកដានមួយនៅពេលរត់កម្មវិធី។
//! ផ្ទាំងខាងក្រោយបង្កើតដោយបណ្ណាល័យនេះមិនចាំបាច់វិភាគឧទាហរណ៍និងលាតត្រដាងមុខងារនៃការអនុវត្តផ្នែកខាងក្រោយច្រើនទេ។
//!
//! # Usage
//!
//! ដំបូងបន្ថែមវាទៅ Cargo.toml របស់អ្នក
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // នៅទីនេះដូច្នេះការធ្វើតេស្តគ្មានសុវត្ថិភាពនៅលើ no_std ឆ្លងកាត់។
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // ដោះស្រាយទ្រនិចណែនាំនេះទៅឈ្មោះនិមិត្តសញ្ញា
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // បន្តទៅស៊ុមបន្ទាប់
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// នៅពេលដែលយើងកំពុងតែកសាងជាផ្នែកមួយនៃ libstd, ទាំងអស់ចាប់តាំងពីការព្រមានបំបិទសំឡេងដែលពួកគេកំពុងមិនពាក់ព័ន្ធដែលជា crate នេះត្រូវបានបង្កើតចេញនៃដើមឈើ។
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// នេះត្រូវបានប្រើសម្រាប់តែការ gimli ឥឡូវនេះ, ដែលត្រូវបានប្រើតែនៅលើវេទិកាមួយចំនួន, ដូច្នេះមិនបារម្ភប្រសិនបើវាជាការដែលមិនបានប្រើនៅក្នុងការកំណត់រចនាសម្ព័ន្ធផ្សេងទៀត។
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;