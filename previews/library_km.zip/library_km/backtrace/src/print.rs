#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ទម្រង់បែបបទសម្រាប់ដាន។
///
/// ប្រភេទនេះអាចត្រូវបានប្រើដើម្បីបោះពុម្ពដានដោយមិនគិតពីដានដែលខ្លួនវាមកពី។
/// ប្រសិនបើអ្នកមានប្រភេទ `Backtrace` បន្ទាប់មកការអនុវត្ត `Debug` របស់វាប្រើទ្រង់ទ្រាយបោះពុម្ពនេះរួចហើយ។
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// រចនាប័ទ្មនៃការបោះពុម្ពដែលយើងអាចបោះពុម្ពបាន
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// បោះពុម្ពដាន terser មួយតាមឧត្ដមគតិដែលមានតែពពាក់ព័ន្ធ
    Short,
    /// បោះពុម្ពដានដែលមានព័ត៌មានដែលអាចមានទាំងអស់
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// បង្កើត `BacktraceFmt` ថ្មីដែលនឹងសរសេរលទ្ធផលដែលបានផ្ដល់ `fmt` ។
    ///
    /// អាគុយម៉ង់ `format` នឹងគ្រប់គ្រងរចនាប័ទ្មដែលដានត្រូវបានបោះពុម្ពហើយអាគុយម៉ង់ `print_path` នឹងត្រូវបានប្រើដើម្បីបោះពុម្ពធាតុឈ្មោះ `BytesOrWideString` ។
    /// ប្រភេទខ្លួនវាមិនធ្វើការបោះពុម្ពឈ្មោះឯកសារណាមួយទេប៉ុន្តែការហៅត្រលប់នេះគឺ តម្រូវឲ្យ ធ្វើ។
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// បោះពុម្ពបុព្វកថាសម្រាប់ដានអំពីការត្រូវបានបោះពុម្ពមួយ។
    ///
    /// នេះត្រូវបានទាមទារសម្រាប់ការនៅលើប្រព័ន្ធប្រតិបត្តិការមួយចំនួនដែលត្រូវបាន symbolicated ដានយ៉ាងពេញលេញនៅពេលក្រោយបាន, ហើយបើមិនដូច្នេះទេនេះគ្រាន់តែគួរតែមានវិធីសាស្រ្តជាលើកដំបូងបន្ទាប់ពីការបង្កើតអ្នកហៅមួយ `BacktraceFmt` ។
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// បន្ថែមស៊ុមមួយទៅលទ្ធផលនៃដាន។
    ///
    /// ការប្តេជ្ញាចិត្តនេះត្រឡប់ជាឧទាហរណ៍ RAII នៃ `BacktraceFrameFmt` ដែលអាចត្រូវបានប្រើដើម្បីបោះពុម្ពស៊ុមហើយនៅលើការបំផ្លាញវានឹងបង្កើនការរាប់ស៊ុម។
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// បញ្ចប់លទ្ធផលនៃដាន។
    ///
    /// បច្ចុប្បន្ននេះមិនមានទេប៉ុន្តែត្រូវបានបន្ថែមសម្រាប់ភាពឆបគ្នា future ជាមួយនឹងទ្រង់ទ្រាយដាន។
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // បច្ចុប្បន្ននេះមិនមាន-រួមទាំង hook នេះដើម្បីអនុញ្ញាតឱ្យបន្ថែម future ។
        Ok(())
    }
}

/// ទម្រង់បែបបទសម្រាប់ស៊ុមតែមួយនៃដាន។
///
/// ប្រភេទនេះត្រូវបានបង្កើតឡើងដោយមុខងារ `BacktraceFmt::frame` ។
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// បោះពុម្ព `BacktraceFrame` ជាមួយទម្រង់ស៊ុមនេះ។
    ///
    /// ការនេះនឹងហៅខ្លួនឯងបោះពុម្ពករណី `BacktraceSymbol` ទាំងអស់នៅក្នុង `BacktraceFrame` នេះ។
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// បោះពុម្ព `BacktraceSymbol` ក្នុង `BacktraceFrame` ។
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: នេះមិនល្អទេដែលយើងមិនបញ្ចប់ការបោះពុម្ពអ្វីទាំងអស់
            // ជាមួយឈ្មោះឯកសារមិនមែន utf8 ។
            // អរគុណណាស់ស្ទើរតែអ្វីគ្រប់យ៉ាងគឺ utf8 ដូច្នេះនេះមិនគួរត្រូវបានពេកអាក្រក់ផងដែរ។
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ព្រីនឆៅ `Frame` និង `Symbol` ឆៅជាធម្មតាមកពីក្នុងការហៅត្រលប់មកវិញរបស់ឆៅ crate ។
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// បន្ថែមស៊ុមឆៅទៅលទ្ធផលដាន។
    ///
    /// វិធីសាស្រ្តនេះមិនដូចអ្វីដែលបានលើកឡើងពីមុនទេដែលត្រូវការអំណះអំណាងឆៅក្នុងករណីដែលពួកគេបានមកពីប្រភពផ្សេងៗគ្នា។
    /// ចំណាំថានេះអាចត្រូវបានហៅជាច្រើនដងសម្រាប់ស៊ុមមួយ។
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// បន្ថែមស៊ុមឆៅទៅលទ្ធផលដានរួមទាំងព័ត៌មានជួរឈរ។
    ///
    /// វិធីសាស្រ្តនេះដូចលើកមុនដែរប្រើអំណះអំណាងឆៅក្នុងករណីដែលពួកគេបានមកពីប្រភពផ្សេងៗគ្នា។
    /// ចំណាំថានេះអាចត្រូវបានហៅជាច្រើនដងសម្រាប់ស៊ុមមួយ។
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia មិនអាចជានិមិត្តរូបនៅក្នុងដំណើរការមួយដូច្នេះវាមានទ្រង់ទ្រាយពិសេសមួយដែលអាចត្រូវបានប្រើដើម្បីជានិមិត្តរូបនៅពេលក្រោយ។
        // បោះពុម្ពជំនួសឱ្យការបោះពុម្ពអាសយដ្ឋាននៅក្នុងទ្រង់ទ្រាយផ្ទាល់ខ្លួនរបស់យើងនៅទីនេះ។
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // មិនចាំបាច់បោះពុម្ពស៊ុម "null" ទេវាគ្រាន់តែមានន័យថាប្រព័ន្ធដានមានការចង់តាមដានពីចម្ងាយឆ្ងាយ។
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // ដើម្បីកាត់បន្ថយទំហំ TCB នៅក្នុងអេសជីនយើងមិនចង់អនុវត្តមុខងារដោះស្រាយនិមិត្តសញ្ញាទេ។
        // ផ្ទុយទៅវិញយើងអាចបោះពុម្ពអុហ្វសិតនៃអាស័យដ្ឋាននៅទីនេះដែលអាចត្រូវបានគូសនៅពេលក្រោយដើម្បីកែមុខងារ។
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // បោះពុម្ពសន្ទស្សន៍នៃស៊ុមក៏ដូចជាទ្រនិចណែនាំជម្រើសនៃស៊ុម។
        // ប្រសិនបើយើងហួសពីនិមិត្តសញ្ញាដំបូងនៃស៊ុមនេះទោះបីជាយើងទើបតែបោះពុម្ពចន្លោះដែលសមរម្យក៏ដោយ។
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // បន្ទាប់សរសេរឈ្មោះនិមិត្តសញ្ញាដោយប្រើទម្រង់ឆ្លាស់គ្នាសម្រាប់ព័ត៌មានបន្ថែមប្រសិនបើយើងជាដានពេញលេញ។
        // នៅទីនេះយើងក៏គ្រប់គ្រងនិមិត្តសញ្ញាដែលមិនមានឈ្មោះ
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // ហើយចុងក្រោយត្រូវបោះពុម្ពលេខ filename/line ប្រសិនបើមាន។
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ត្រូវបានបោះពុម្ពនៅលើបន្ទាត់ក្រោមឈ្មោះនិមិត្តសញ្ញា, ដូច្នេះបោះពុម្ពចន្លោះសមរម្យមួយចំនួនដើម្បីតម្រៀបនៃការតម្រឹមស្តាំខ្លួនយើង។
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ប្រតិភូទៅផ្នែកហៅត្រឡប់មកវិញរបស់យើងដើម្បីបោះពុម្ពឈ្មោះឯកសារហើយបន្ទាប់មកបោះពុម្ពលេខទូរស័ព្ទ។
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // បន្ថែមលេខជួរឈរបើមាន។
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // យើងគ្រាន់តែខ្វល់អំពីនិមិត្តសញ្ញាដំបូងនៃស៊ុម
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}