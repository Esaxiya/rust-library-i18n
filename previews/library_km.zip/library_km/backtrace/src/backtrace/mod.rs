use core::ffi::c_void;
use core::fmt;

/// ពិនិត្យមើលការហៅជង់បច្ចុប្បន្នដោយឆ្លងកាត់ស៊ុមសកម្មទាំងអស់ទៅក្នុងការបិទដែលបានផ្តល់ដើម្បីគណនាដានជង់។
///
/// មុខងារនេះគឺជាការងាររបស់បណ្ណាល័យនេះក្នុងការគណនាដានជង់សម្រាប់កម្មវិធីមួយ។ការបិទ `cb` ដែលបានផ្តល់ឱ្យគឺជាលទ្ធផលនៃ `Frame` ដែលតំណាងឱ្យព័ត៌មានអំពីស៊ុមហៅនោះនៅលើជង់។
/// ការបិទនេះត្រូវបានផ្តល់ទិន្នផលស៊ុមក្នុងរបៀបចុះក្រោម (ភាគច្រើនហៅថាមុខងារដំបូង) ។
///
/// តម្លៃត្រឡប់មកវិញនៃការបិទគឺជាការចង្អុលបង្ហាញថាតើដាននឹងបន្ត។តម្លៃត្រឡប់មកវិញនៃ `false` នឹងបញ្ចប់ដាននិងត្រឡប់មកវិញភ្លាមៗ។
///
/// នៅពេលដែល `Frame` ត្រូវបានទិញអ្នកទំនងជាចង់ហៅ `backtrace::resolve` ដើម្បីបម្លែង `ip` (ទ្រនិចណែនាំ) ឬអាស័យដ្ឋាននិមិត្តសញ្ញាទៅជា `Symbol` តាមរយៈឈ្មោះនិង/ឬឈ្មោះឯកសារ/លេខទូរស័ព្ទអាចរៀនបាន។
///
///
/// ចំណាំថានេះគឺជាមុខងារកម្រិតទាបហើយប្រសិនបើអ្នកចង់ឧទាហរណ៍ចាប់យកដានដើម្បីត្រូវបានត្រួតពិនិត្យនៅពេលក្រោយបន្ទាប់មកប្រភេទ `Backtrace` អាចសមស្របជាង។
///
/// # លក្ខណៈពិសេសដែលត្រូវការ
///
/// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
///
/// # Panics
///
/// មុខងារនេះព្យាយាមមិនដែល panic ទេប៉ុន្តែប្រសិនបើ `cb` បានផ្តល់ panics បន្ទាប់មកវេទិកាមួយចំនួននឹងបង្ខំឱ្យ panic ទ្វេរដងដើម្បីបញ្ឈប់ដំណើរការ។
/// វេទិកាខ្លះប្រើបណ្ណាល័យ C ដែលប្រើការហៅត្រឡប់មកវិញដែលមិនអាចធ្វើបានដូច្នេះការភ័យស្លន់ស្លោពី `cb` អាចបង្កឱ្យមានការបញ្ឈប់ដំណើរការ។
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // បន្តដាន
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// ដូចគ្នានឹង `trace` ដែរមានតែមិនមានសុវត្ថិភាពដូចដែលវាមិនដំណើរការ។
///
/// មុខងារនេះមិនមាន guarentees ធ្វើសមកាលកម្មទេប៉ុន្តែអាចប្រើបាននៅពេលដែលលក្ខណៈពិសេស `std` នៃ crate មិនត្រូវបានចងក្រង។
/// មើលមុខងារ `trace` សម្រាប់ឯកសារនិងឧទាហរណ៍បន្ថែម។
///
/// # Panics
///
/// សូមមើលព័ត៌មានអំពី `trace` សម្រាប់ការនិយាយតៗគ្នានៅលើ `cb` ។
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait តំណាងឱ្យស៊ុមមួយនៃដានដែលផ្តល់ដល់មុខងារ `trace` នៃ crate នេះ។
///
/// បិទមុខងារតាមដានរបស់នឹងត្រូវបានជំរុញអោយមានស៊ុមនិងស៊ុមត្រូវបានបញ្ជូនស្ទើរតែជាការអនុវត្ដន៍មូលដ្ឋានត្រូវបានគេស្គាល់ថាតែងតែរហូតដល់មិនដំណើរការកូដ។
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// ត្រឡប់ទ្រនិចណែនាំបច្ចុប្បន្ននៃស៊ុមនេះ។
    ///
    /// នេះគឺជាការធម្មតាការបង្រៀនក្រោយដើម្បីប្រតិបត្តិនៅក្នុងស៊ុម, ប៉ុន្តែមិនត្រូវបានប្រតិបត្តិការទាំងអស់នេះជាមួយនឹង% បញ្ជីភាពត្រឹមត្រូវ 100 (ជាទូទៅប៉ុន្តែវាស្អាតយ៉ាងជិតស្និទ្ធ) ។
    ///
    ///
    /// វាត្រូវបានផ្ដល់អនុសាសន៍ឱ្យបញ្ជូនតម្លៃនេះទៅ `backtrace::resolve` ប្រែក្លាយវាទៅជាឈ្មោះនិមិត្តសញ្ញាមួយ។
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// ត្រឡប់ទ្រនិចជង់បច្ចុប្បន្ននៃស៊ុមនេះ។
    ///
    /// ក្នុងករណីដែលអ្នកខាងក្រោយមិនអាចស្តារទ្រនិចទ្រនាប់សម្រាប់ស៊ុមនេះទ្រនិចទ្រនិចត្រូវបានបញ្ជូនត្រឡប់មកវិញ។
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// ត្រឡប់អាសយដ្ឋាននិមិត្តសញ្ញាចាប់ផ្តើមនៃស៊ុមនៃមុខងារនេះ។
    ///
    /// នេះនឹងព្យាយាមរំtoកទ្រនិចចង្អុលបង្ហាញដែលបានត្រឡប់ដោយ `ip` ទៅការចាប់ផ្តើមនៃមុខងារដោយត្រឡប់តម្លៃនោះ។
    ///
    /// ទោះយ៉ាងណាក៏ដោយក្នុងករណីខ្លះផ្នែកខាងក្រោយនឹងត្រឡប់មកវិញនូវ `ip` ពីមុខងារនេះ។
    ///
    /// ពេលខ្លះតម្លៃត្រឡប់មកវិញអាចត្រូវបានប្រើប្រសិនបើ `backtrace::resolve` បានបរាជ័យនៅលើ `ip` ដែលបានផ្តល់ឱ្យខាងលើ។
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// ត្រឡប់អាសយដ្ឋានមូលដ្ឋានរបស់ម៉ូឌុលដែលស៊ុមជាកម្មសិទ្ធិ។
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // នេះចាំបាច់ត្រូវមកមុនគេដើម្បីធានាថាគីរីមានអាទិភាពជាងវេទិកាម៉ាស៊ីន
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // ប្រើតែក្នុងនិមិត្តសញ្ញា dbghelp
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}