//! Backtrace គាំទ្រដោយប្រើ libunwind/gcc_s/etc APIs ។
//!
//! ម៉ូឌុលនេះមានសមត្ថភាពក្នុងការបញ្ឈប់ជង់ដោយប្រើ APIs បែប libunwind ។
//! ចំណាំថាមានការអនុវត្តទាំងមូលនៃ API ដូច libunwind ហើយនេះគ្រាន់តែព្យាយាមធ្វើឱ្យត្រូវគ្នាជាមួយពួកគេភាគច្រើនក្នុងពេលតែមួយជំនួសឱ្យការជ្រើសរើស។
//!
//!
//! API libunwind ត្រូវបានបំពាក់ដោយ `_Unwind_Backtrace` ហើយជាការអនុវត្តជាក់ស្តែងអាចទុកចិត្តបានក្នុងការបង្កើតដាន។
//! វាមិនច្បាស់ទេថាតើវាដំណើរការវាយ៉ាងដូចម្តេច (ចង្អុលបង្ហាញអំពីស៊ុម? ព័ត៌មានអំពីទាំងពីរ?) ប៉ុន្តែវាហាក់ដូចជាដំណើរការ!
//!
//! ភាគច្រើននៃភាពស្មុគស្មាញនៃម៉ូឌុលនេះគឺត្រូវបានដោះស្រាយភាពខុសគ្នានៃវេទិកាផ្សេងៗគ្នានៅក្នុងការប្រតិបត្តិ libunwind ។
//! បើមិនដូច្នោះទេនេះគឺជាការផ្សារភ្ជាប់ Rust ត្រង់ស្អាតទៅនឹង APIs libunwind ។
//!
//! នេះជាលំនាំដើមដកចេញសម្រាប់ API របស់ទាំងអស់ដែលមិនមែនជាប្រព័ន្ធប្រតិបត្តិការ Windows វេទិកាបច្ចុប្បន្ន។
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// ដោយព្រួញ libunwind ឆៅវាតែប៉ុណ្ណោះដែលមិនធ្លាប់មានគួរតែមានការចូលដំណើរការនៅក្នុងរបៀប threadsafe អានមួយដូច្នេះវាជាការ `Sync` ។
// នៅពេលផ្ញើទៅកាន់ខ្សែស្រលាយផ្សេងទៀតតាមរយៈ `Clone` យើងតែងតែប្ដូរទៅជាកំណែដែលមិនបានរក្សាព្រួញមហាផ្ទៃដូច្នេះយើងគួរតែមានការ `Send` ផងដែរ។
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // វាហាក់ដូចជាថានៅលើ OSX `_Uww__FindEnclosingFunction` ត្រឡប់ទ្រនិចទៅ ... អ្វីដែលមិនច្បាស់។
        // វាជាការពិតជាមិនមែនតែងតែមានមុខងារភ្ជាប់សម្រាប់ហេតុផលអ្វី។
        // វាមិនច្បាស់ចំពោះខ្ញុំទេថាតើមានអ្វីកំពុងកើតឡើងនៅទីនេះដូច្នេះសូមផ្អាកវាសម្រាប់ពេលនេះហើយគ្រាន់តែត្រឡប់ ip ជានិច្ច។
        //
        // ចំណាំការធ្វើតេស្ត `skip_inner_frames.rs` ត្រូវបានរំលងនៅលើ OSX ដោយសារតែឃ្លានេះហើយប្រសិនបើវាត្រូវបានជួសជុលការធ្វើតេស្តនោះតាមទ្រឹស្តីអាចត្រូវបានដំណើរការលើ OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// ចំណុចប្រទាក់បណ្ណាល័យមិនត្រូវបានប្រើសម្រាប់ដាន
///
/// ចំណាំថាលេខកូដមរណៈត្រូវបានអនុញ្ញាតដូចដែលនៅទីនេះគ្រាន់តែជាការភ្ជាប់ប្រព័ន្ធប្រតិបត្តិការ iOS មិនប្រើវាទាំងអស់នោះទេប៉ុន្តែការបន្ថែមលេខកូដវេទិកាជាក់លាក់បន្ថែមទៀតបំពុលកូដច្រើនពេក។
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ប្រើដោយ ARM EABI ប៉ុណ្ណោះ
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // គ្មានដើមកំណើត _Unwind_Backtrace នៅលើប្រព័ន្ធប្រតិបត្តិការ iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // អាចប្រើបានចាប់តាំងពី GCC 4.2.0 គួរតែល្អសម្រាប់គោលបំណងរបស់យើង
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // មុខងារនេះគឺមិនត្រឹមត្រូវ៖ ជាជាងការទទួលអាសយដ្ឋាន Canonical របស់ស៊ុម (ហៅអេសអេសរបស់អ្នកហៅ) វាត្រឡប់អេសរបស់ស៊ុម។
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x ប្រើតម្លៃស៊ីអេហ្វអេដែលមានភាពលំអៀងដូច្នេះយើងត្រូវប្រើ _Unwind_GetGR ដើម្បីទទួលបានការចុះឈ្មោះទ្រនិចទ្រនិច (%r15) ជំនួសឱ្យការពឹងផ្អែកលើ _Unwind_GetCFA ។
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // នៅលើ android និងដៃមុខងារ `_Unwind_GetIP` និងបណ្តុំផ្សេងៗទៀតគឺម៉ាក្រូដូច្នេះយើងកំណត់មុខងារដែលមានការពង្រីកម៉ាក្រូ។
    //
    //
    // TODO: ភ្ជាប់ទៅបឋមកថាឯកសារដែលកំណត់ម៉ាក្រូទាំងនេះប្រសិនបើអ្នកអាចរកវាឃើញ។
    // (ខ្ញុំមិនអាចរកឃើញចំណងជើងឯកសារដែលការពង្រីកម៉ាក្រូមួយចំនួនត្រូវបានខ្ចីពីដំបូងទេ។)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 គឺជាទ្រនិចទ្រនិចនៅលើដៃ។
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // មុខងារនេះក៏មិនមាននៅលើ Android ឬ ARM/Linux ដែរដូច្នេះធ្វើឱ្យវាមិនមែនជាអេច។
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}