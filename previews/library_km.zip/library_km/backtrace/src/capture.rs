use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// តំណាងឱ្យដានដែលមាននិងជាម្ចាស់ដោយខ្លួនឯង។
///
/// រចនាសម្ព័ននេះអាចត្រូវបានប្រើដើម្បីចាប់យកដាននៅចំណុចផ្សេងៗគ្នានៅក្នុងកម្មវិធីហើយក្រោយមកត្រូវបានគេប្រើដើម្បីពិនិត្យមើលថាតើដានអ្វីនៅពេលនោះ។
///
///
/// `Backtrace` គាំទ្រការបោះពុម្ពស្អាត-ដានតាមរយៈការអនុវត្តរបស់ខ្លួន `Debug` ។
///
/// # លក្ខណៈពិសេសដែលត្រូវការ
///
/// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // ស៊ុមនៅទីនេះត្រូវបានរាយបញ្ជីពីកំពូលទៅបាតនៃជង់
    frames: Vec<BacktraceFrame>,
    // លិបិក្រមដែលយើងជឿជាក់គឺជាការចាប់ផ្តើមពិតប្រាកដនៃដានថយក្រោយលុបស៊ុមដូចជា `Backtrace::new` និង `backtrace::trace` ។
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// បានចាប់យកកំណែនៃស៊ុមនៅក្នុងដាន។
///
/// ប្រភេទនេះត្រូវបានត្រឡប់ជាបញ្ជីពី `Backtrace::frames` និងជាតំណាងស៊ុមជង់មួយនៅក្នុងដានចាប់យកមួយ។
///
/// # លក្ខណៈពិសេសដែលត្រូវការ
///
/// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// បានចាប់យកកំណែនៃនិមិត្តសញ្ញានៅក្នុងដាន។
///
/// ប្រភេទនេះត្រូវបានត្រឡប់មកវិញជាបញ្ជីពី `BacktraceFrame::symbols` និងតំណាងឱ្យទិន្នន័យមេតាសម្រាប់និមិត្តសញ្ញានៅក្នុងដាន។
///
/// # លក្ខណៈពិសេសដែលត្រូវការ
///
/// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// ចាប់បានដានមួយនៅ callsite នៃអនុគមន៍នេះត្រឡប់ជាតំណាងម្ចាស់។
    ///
    /// មុខងារនេះមានប្រយោជន៍សម្រាប់តំណាងឱ្យដានមួយដែលជាវត្ថុនៅក្នុង Rust ។តម្លៃត្រឡប់មកវិញនេះអាចត្រូវបានបញ្ជូនឆ្លងកាត់ខ្សែស្រឡាយនិងបោះពុម្ពនៅកន្លែងផ្សេងទៀតហើយគោលបំណងនៃតម្លៃនេះគឺត្រូវផ្ទុកដោយខ្លួនឯង។
    ///
    /// ចំណាំថានៅលើវេទិកាមួយចំនួនទទួលបានដានពេញលេញនិងដោះស្រាយវាអាចមានតម្លៃថ្លៃណាស់។
    /// ប្រសិនបើការចំណាយច្រើនពេកសម្រាប់កម្មវិធីរបស់អ្នកវាត្រូវបានគេណែនាំឱ្យប្រើ `Backtrace::new_unresolved()` ដែលជៀសវាងជំហានដោះស្រាយនិមិត្តសញ្ញា (ដែលជាធម្មតាចំណាយពេលយូរបំផុត) និងអនុញ្ញាតឱ្យពន្យាពេលនោះទៅកាលបរិច្ឆេទក្រោយ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // ចង់ធ្វើឱ្យប្រាកដថាមានស៊ុមនៅទីនេះដើម្បីយកចេញ
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// ស្រដៀងនឹង `new` លើកលែងតែវាមិនដោះស្រាយនិមិត្តសញ្ញាណាមួយទេនេះគ្រាន់តែចាប់ដានដានជាបញ្ជីអាសយដ្ឋាន។
    ///
    /// នៅពេលក្រោយមកមុខងារ `resolve` អាចត្រូវបានគេហៅថាដើម្បីដោះស្រាយនិមិត្តសញ្ញាដាននេះទៅជាឈ្មោះដែលអាចអានបាន។
    /// មុខងារនេះមានពីព្រោះដំណើរការដោះស្រាយពេលខ្លះអាចត្រូវការពេលវេលាច្រើនចំណែកឯដានណាមួយអាចត្រូវបានបោះពុម្ពយ៉ាងកម្រ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // គ្មានឈ្មោះនិមិត្តសញ្ញា
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ឈ្មោះនិមិត្តសញ្ញាបច្ចុប្បន្ននេះមានវត្តមាន
    /// ```
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    ///
    ///
    #[inline(never)] // ចង់ធ្វើឱ្យប្រាកដថាមានស៊ុមនៅទីនេះដើម្បីយកចេញ
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// ត្រឡប់ស៊ុមពីពេលដាននេះត្រូវបានចាប់យក។
    ///
    /// ធាតុដំបូងនៃចម្រៀកនេះគឺទំនងជាមុខងារ `Backtrace::new`, និងស៊ុមចុងក្រោយគឺទំនងជាអ្វីមួយអំពីរបៀបដែលខ្សែស្រឡាយនេះឬមុខងារសំខាន់ចាប់ផ្តើម។
    ///
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// ប្រសិនបើដាននេះត្រូវបានបង្កើតចេញពី `new_unresolved` ពេលនោះមុខងារនេះនឹងដោះស្រាយរាល់អាស័យដ្ឋានក្នុងដានទៅនឹងឈ្មោះនិមិត្តសញ្ញារបស់ពួកគេ។
    ///
    ///
    /// ប្រសិនបើការដាននេះត្រូវបានដោះស្រាយមុនឬត្រូវបានបង្កើតឡើងតាមរយៈការ `new` អនុគមន៍នេះមិនមានអ្វី។
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// ដូចគ្នានឹង `Frame::ip` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// ដូចគ្នានឹង `Frame::symbol_address` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// ដូចគ្នានឹង `Frame::module_base_address` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// ត្រឡប់បញ្ជីនិមិត្តសញ្ញាដែលស៊ុមនេះត្រូវគ្នា។
    ///
    /// ជាធម្មតាមានតែមួយជានិមិត្តរូបក្នុងស៊ុម, ប៉ុន្តែពេលខ្លះប្រសិនបើចំនួននៃមុខងារត្រូវបាន inlined ចូលទៅក្នុងស៊ុមមួយបន្ទាប់មកនិមិត្តសញ្ញាជាច្រើននឹងត្រូវបានត្រឡប់មកវិញ។
    /// និមិត្តសញ្ញាដំបូងដែលបានចុះបញ្ជីគឺ "innermost function" ចំណែកឯនិមិត្តសញ្ញាចុងក្រោយគឺនៅខាងក្រៅ (អ្នកទូរស័ព្ទចុងក្រោយ) ។
    ///
    /// ចំណាំថាប្រសិនបើស៊ុមនេះមកពីដានដែលមិនបានដោះស្រាយបន្ទាប់មកវានឹងត្រលប់មកវិញនូវបញ្ជីទទេ។
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// ដូចគ្នានឹង `Symbol::name` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// ដូចគ្នានឹង `Symbol::addr` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// ដូចគ្នានឹង `Symbol::filename` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// ដូចគ្នានឹង `Symbol::lineno` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// ដូចគ្នានឹង `Symbol::colno` ដែរ
    ///
    /// # លក្ខណៈពិសេសដែលត្រូវការ
    ///
    /// មុខងារនេះតម្រូវឱ្យមានលក្ខណៈពិសេស `std` នៃ `backtrace` crate ត្រូវបើកនិងលក្ខណៈពិសេស `std` ត្រូវបានបើកដោយលំនាំដើម។
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // នៅពេលបោះពុម្ពផ្លូវយើងព្យាយាមច្រូតយកក្បូនប្រសិនបើវាមានបើមិនដូច្នេះទេយើងគ្រាន់តែបោះពុម្ពផ្លូវដូច។
        // ចំណាំថាយើងធ្វើដូចនេះសម្រាប់ទំរង់ខ្លីពីព្រោះប្រសិនបើវាពេញយើងសន្មតចង់បោះពុម្ពអ្វីៗទាំងអស់។
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}