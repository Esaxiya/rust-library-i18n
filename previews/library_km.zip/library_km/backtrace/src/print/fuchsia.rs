use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ចំណាយពេលហៅទៅវិញថានឹងទទួលបានការទស្សន៍ទ្រនិច dl_phdr_info សម្រាប់រាល់ DSO ដែលត្រូវបានភ្ជាប់ចូលទៅក្នុងដំណើរការនេះ។
    // dl_iterate_phdr ក៏ធានាថាតំណភ្ជាប់ថាមវន្តត្រូវបានចាក់សោពីការចាប់ផ្តើមរហូតដល់ការបញ្ចប់នៃការនិយាយឡើងវិញ។
    // ប្រសិនបើការហៅត្រឡប់មកវិញផ្តល់នូវតម្លៃមិនមែនសូន្យការរើឡើងវិញត្រូវបានបញ្ចប់មុនកាលកំណត់។
    // 'data' នឹងត្រូវបានបញ្ជូនជាអាគុយម៉ង់ទីបីទៅការហៅត្រឡប់មកវិញនៅលើការហៅនីមួយៗ។
    // 'size' ផ្តល់ទំហំរបស់ dl_phdr_info ។
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// យើងត្រូវការញែកចេញកសាងនិងទិន្នន័យលេខសម្គាល់កម្មវិធីបឋមកថាមួយចំនួនដែលជាមធ្យោបាយជាមូលដ្ឋានដែលយើងត្រូវការបន្តិចថាការពីវត្ថុប្រភេទ ELF ផងដែរ។
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ឥឡូវនេះយើងមានការចម្លង, បន្តិចសម្រាប់បន្តិច, រចនាសម្ព័ន្ធនៃប្រភេទ dl_phdr_info ដែលបានប្រើដោយ linker ថាមវន្តបច្ចុប្បន្នក្រហមទុំនេះ។
// ក្រូមីញ៉ូមក៏មានព្រំប្រទល់ ABI នេះផងដែរ។
// ជាយថាហេតុយើងចង់ផ្លាស់ប្តូរករណីទាំងនេះដើម្បីប្រើការស្វែងរក elf-ប៉ុន្តែយើងត្រូវការផ្តល់ជូននៅក្នុងអេសខេអេសហើយរឿងនោះមិនទាន់ត្រូវបានធ្វើនៅឡើយទេ។
//
// ដូច្នេះយើង (ហើយពួកគេ) គឺជាអ្នកជាប់គាំងមានការប្រើវិធីសាស្រ្តដែលបានកើតឡើងជាគូស្វាម៉ីភរិយាតឹងជាមួយ libc ក្រហមទុំនេះ។
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // យើងមានវិធីមួយនៃការដឹងការពិនិត្យមើលប្រសិនបើ e_phoff ទេហើយ e_phnum មានសុពលភាព។
    // libc គួរតែធានាថាវាសម្រាប់យើងទោះយ៉ាងណាវាមានសុវត្ថិភាពក្នុងការបង្កើតចំណែកនៅទីនេះ។
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr តំណាងឱ្យក្បាលកម្មវិធីកម្មវិធីអេហ្វអ៊ីអេហ្វ ៦៤ ប៊ីតនៅក្នុងភាពស្ថិតស្ថេរនៃស្ថាបត្យកម្មគោលដៅ។
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr តំណាងឱ្យបឋមកថាកម្មវិធី ELF ដែលមានសុពលភាពនិងមាតិការបស់វា។
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // យើងមិនមានវិធីដើម្បីពិនិត្យមើលថាតើ p_addr ឬ p_memsz ត្រឹមត្រូវទេ។
    // libc របស់ Fuchsia ធ្វើការវិភាគលើកំណត់ចំណាំជាមុនទោះយ៉ាងណាដោយសារគុណធម៌នៅទីនេះបឋមកថាទាំងនេះត្រូវតែមានសុពលភាព។
    //
    // NoteIter មិនតម្រូវឱ្យមានទិន្នន័យមូលដ្ឋានត្រឹមត្រូវប៉ុន្តែវាមិនតម្រូវឱ្យមានព្រំដែនដើម្បីឱ្យមានសុពលភាព។
    // យើងជឿជាក់ថា libc បានធានាថានេះជាករណីរបស់យើងនៅទីនេះ។
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ប្រភេទចំណាំសម្រាប់លេខសម្គាល់ស្ថាបនា។
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr តំណាងឱ្យបឋមកថាចំណាំ ELF ក្នុងគោលដៅនៃការចំណងជើងនេះ។
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// កំណត់សំគាល់តំណាងឱ្យកំណត់សំគាល់ ELF (ចំណងជើង + មាតិកា) ។
// ឈ្មោះនេះត្រូវបានទុកថាជាចំណែក u8 ដោយសារតែវាមិនមែនតែងតែ NULL បញ្ចប់និង rust ធ្វើឱ្យវាងាយស្រួលគ្រប់គ្រាន់ដើម្បីពិនិត្យមើលថាបៃផ្គូផ្គង eitherway ។
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter អនុញ្ញាតឱ្យអ្នកធ្វើឱ្យមានសុវត្ថិភាពនៅលើផ្នែកចំណាំ។
// វាបញ្ចប់ភ្លាមៗនៅពេលមានកំហុសកើតឡើងឬមិនមានកំណត់ចំណាំទៀត។
// ប្រសិនបើអ្នកនិយាយអំពីទិន្នន័យមិនត្រឹមត្រូវវានឹងដំណើរការដូចជាគ្មានកំណត់ត្រាត្រូវបានរកឃើញទេ។
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // វាគឺជាមុខងារដែលមិនធ្លាប់មានដែលព្រួញកណ្តុរនិងទំហំដែលបានផ្តល់ឱ្យបង្ហាញពីចំនួនបៃដែលមានសុពលភាពដែលអាចអានបានទាំងអស់។
    // ខ្លឹមសារនៃបៃទាំងនេះអាចជាអ្វីទាំងអស់ប៉ុន្តែជួរត្រូវតែមានសុពលភាពដើម្បីឱ្យវាមានសុវត្ថិភាព។
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to តម្រឹម 'x' ទៅ 'តម្រឹម to' បៃសន្មត់ថា 'to' គឺជាថាមពលនៃ 2 ។
// នេះធ្វើតាមគំរូស្តង់ដារនៅក្នុងកូដ C/C ++ ELF ដែលកូដ (x + ដល់, 1)&-to ត្រូវបានប្រើ។
// Rust មិនអនុញ្ញាតឱ្យអ្នក negate usize ដូច្នេះខ្ញុំបានប្រើ
// ការបំលែងបំរែបំរួលបន្ថែម ២ ដើម្បីបង្កើតវាឡើងវិញ។
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 ប្រើប្រាស់ចំនួនបៃពីចំណិត (ប្រសិនបើមាន) ហើយធានាថាចំណែកចុងក្រោយត្រូវបានតម្រឹមយ៉ាងត្រឹមត្រូវ។
// ប្រសិនបើចំនួនបៃដែលបានស្នើមានទំហំធំពេកឬចំណែកមិនអាចបែងចែកជាថ្មីបានទេដោយសារមិនមានបៃដែលនៅសេសសល់មិនមានហើយមិនត្រូវបានត្រឡប់ហើយចំណែកមិនត្រូវបានកែប្រែទេ។
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// មុខងារនេះមិនមានអ្នកទូរស័ព្ទចូលពិតប្រាកដមិនប្រែប្រួលត្រូវគាំទ្រផ្សេងទៀតដែលប្រហែលជាថា 'bytes' ជាងអ្នកត្រូវបានតម្រឹមសម្រាប់ការគួរសម្តែង (និងនៅលើមួយចំនួនត្រឹមត្រូវស្ថាបត្យកម្ម) ។
// តម្លៃនៅក្នុងវាល Elf_Nhdr ប្រហែលជាមិនសមហេតុសមផលទេប៉ុន្តែមុខងារនេះធានាថាគ្មានរឿងបែបនេះទេ។
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // នេះមានសុវត្ថិភាពដរាបណាមានកន្លែងទំនេរគ្រប់គ្រាន់ហើយយើងគ្រាន់តែបញ្ជាក់ថាប្រសិនបើសេចក្តីថ្លែងការណ៍ខាងលើដូច្នេះនេះមិនគួរមានសុវត្ថិភាពទេ។
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // ចំណាំថា sice_of: :<Elf_Nhdr>() តែងតែតម្រឹម ៤ បៃ។
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // ពិនិត្យមើលថាតើយើងបានដល់ទីបញ្ចប់ហើយឬនៅ។
        if self.base.len() == 0 || self.error {
            return None;
        }
        // យើងបញ្ជូន nhdr មួយប៉ុន្តែយើងពិចារណាដោយប្រុងប្រយ័ត្នរចនាសម្ព័ន្ធលទ្ធផល។
        // យើងមិនទុកចិត្តលើឈ្មោះហ្សាស់ឬដេសហើយយើងមិនធ្វើការសំរេចចិត្តគ្មានសុវត្ថិភាពដោយផ្អែកលើប្រភេទ។
        //
        // ដូច្នេះទោះបីយើងចេញសំរាមពេញយើងនៅតែមានសុវត្ថិភាព។
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// បង្ហាញថាផ្នែកមួយអាចប្រតិបត្តិបាន។
const PERM_X: u32 = 0b00000001;
/// បង្ហាញថាផ្នែកមួយអាចសរសេរបាន។
const PERM_W: u32 = 0b00000010;
/// បង្ហាញថាផ្នែកអាចអានបាន។
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// តំណាងផ្នែក ELF នៅពេលដំណើរការ។
struct Segment {
    /// ផ្តល់នូវអាសយដ្ឋាននិម្មិតពេលរត់មាតិកាផ្នែកនេះ។
    addr: usize,
    /// ផ្តល់ទំហំអង្គចងចាំនៃមាតិកានៃផ្នែកនេះ។
    size: usize,
    /// ផ្តល់នូវអាសយដ្ឋាននិម្មិតម៉ូឌុលនៃចម្រៀកជាមួយឯកសារ ELF នេះ។
    mod_rel_addr: usize,
    /// ផ្តល់សិទ្ធិដែលរកឃើញនៅក្នុងឯកសារ ELF ។
    /// ការអនុញ្ញាតទាំងនេះមិនចាំបាច់មានសិទ្ធិអនុញ្ញាតទេពេលរត់។
    flags: Perm,
}

/// អនុញ្ញាតឱ្យអន្តរកម្មមួយនៅលើអង្កត់ពី DSO មួយ។
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// តំណាងមួយ ELF DSO (វត្ថុថាមវន្តដែលបានចែករំលែក) ។
/// ប្រភេទនេះយោងទិន្នន័យដែលផ្ទុកនៅក្នុង DSO ជាក់ស្តែងជាជាងការថតចម្លងដោយខ្លួនឯង។
struct Dso<'a> {
    /// អ្នកភ្ជាប់ថាមវន្តតែងតែផ្តល់ឱ្យយើងនូវឈ្មោះទោះបីជាឈ្មោះទទេក៏ដោយ។
    /// នៅក្នុងករណីនៃការប្រតិបត្តិមេឈ្មោះនេះនឹងត្រូវទទេ។
    /// ក្នុងករណីវត្ថុដែលបានចែករំលែកវានឹងជាឈ្មោះដើម (សូមមើល DT_SONAME) ។
    name: &'a str,
    /// នៅលើហ្វុយស៊ីសប៊ីប៊ីនទាំងអស់មានអត្តសញ្ញាណប័ណ្ណប៉ុន្តែនេះមិនមែនជាតម្រូវការតឹងរឹងទេ។
    /// មានវិធីមួយដើម្បីផ្គូផ្គងឡើង DSO ជាមួយនឹងឯកសារពជាការពិតបន្ទាប់ពីនោះ ELF គឺមាន build_id ប្រសិនបើដូច្នេះយើងទាមទារឱ្យមានការមិនមានជារៀងរាល់ DSO មានថាម្នាក់នៅទីនេះទេ។
    ///
    /// របស់អេសអូអេសមិនមានការស្ថាបនាទេ។
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ត្រឡប់បម្រុងជាងចម្រៀកក្នុង DSO នេះ។
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// កំហុសទាំងនេះអ៊ិនកូដបញ្ហាដែលកើតឡើងខណៈពេលកំពុងវិភាគព័ត៌មានអំពី DSO នីមួយៗ។
///
enum Error {
    /// NameError មានន័យថាកំហុសមួយបានកើតឡើងខណៈពេលដែលបម្លែងខ្សែអក្សរ C ទៅជាខ្សែអក្សរ rust ។
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError មានន័យថាយើងមិនបានរកឃើញអត្តសញ្ញាណប័ណ្ណទេ។
    /// នេះអាចមកពី DSO គ្មានលេខសម្គាល់សាងសង់ឬដោយសារផ្នែកដែលមានលេខសម្គាល់សាងសង់មិនត្រឹមត្រូវ។
    ///
    BuildIDError,
}

/// ហៅទាំង 'dso' ឬ 'error' សម្រាប់អេឌីអេសនីមួយៗភ្ជាប់ទៅនឹងដំណើរការដោយអ្នកភ្ជាប់ថាមវន្ត។
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter ដែលនឹងមានវិធីសាស្រ្តបរិភោគមួយដែលគេហៅថា foreach DSO ។
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ធានាថា info.name នឹងចង្អុលទៅទីតាំងត្រឹមត្រូវ។
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// មុខងារនេះជានិមិត្តរូបបោះពុម្ពមួយ Fuchsia នេះសម្រាប់សម្គាល់ទាំងអស់ដែលមាននៅក្នុងព DSO មួយ។
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}