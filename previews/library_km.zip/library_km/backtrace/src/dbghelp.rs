//! ម៉ូឌុលការដើម្បីជួយក្នុងការគ្រប់គ្រងការចង dbghelp នៅលើ Windows
//!
//! ផ្ទាំងខាងក្រោយនៅលើ Windows (យ៉ាងហោចណាស់សម្រាប់អេសភីអេចស៊ី) ត្រូវបានផ្តល់ថាមពលយ៉ាងទូលំទូលាយតាមរយៈ `dbghelp.dll` និងមុខងារផ្សេងៗដែលវាមាន។
//! មុខងារទាំងនេះបច្ចុប្បន្នត្រូវបានផ្ទុក *ថាមវន្ត* ជាជាងភ្ជាប់ទៅនឹង `dbghelp.dll` តាមលក្ខណៈ។
//! បច្ចុប្បន្ននេះត្រូវបានធ្វើឡើងដោយបណ្ណាល័យស្តង់ដារ (ហើយតាមទ្រឹស្តីទាមទារនៅទីនោះ) ប៉ុន្តែជាការខិតខំដើម្បីជួយកាត់បន្ថយភាពអាស្រ័យឋិតិវន្តនៃបណ្ណាល័យមួយចាប់តាំងពីផ្ទាំងខាងក្រោយមានលក្ខណៈស្រេចចិត្ត។
//!
//! ដែលត្រូវបានគេនិយាយថា `dbghelp.dll` តែងតែផ្ទុកដោយជោគជ័យនៅលើ Windows ។
//!
//! សូមកត់សម្គាល់ថាចាប់តាំងពីយើងផ្ទុកការគាំទ្រទាំងអស់នេះតាមលក្ខណៈជាក់ស្តែងយើងមិនអាចប្រើនិយមន័យឆៅនៅក្នុង `winapi` ទេប៉ុន្តែយើងត្រូវកំណត់ប្រភេទទ្រនិចមុខងារដោយខ្លួនឯងហើយប្រើវា។
//! យើងពិតជាមិនចង់ឱ្យមាននៅក្នុងអាជីវកម្មរបស់ស្ទួន winapi ដូច្នេះយើងមានលក្ខណៈពិសេស Cargo `verify-winapi` ដែលបានអះអាងថាការចងទាំងអស់ផ្គូផ្គងទាំងនោះនៅក្នុង winapi និងលក្ខណៈពិសេសនេះត្រូវបានបើកនៅលើអង្គការ CI ។
//!
//! ជាចុងក្រោយអ្នកនឹងកត់សំគាល់នៅទីនេះថាឌឺសម្រាប់ `dbghelp.dll` មិនដែលត្រូវបានផ្ទុកទេហើយនោះជាចេតនាបច្ចុប្បន្ន។
//! ការគិតគឺថាយើងអាចលាក់វាជាសកលហើយប្រើវារវាងការហៅទៅ API ដោយជៀសវាង loads/unloads ដែលមានតម្លៃថ្លៃ។
//! ប្រសិនបើនេះជាបញ្ហាសម្រាប់ឧបករណ៍រាវរកលេចធ្លាយឬអ្វីមួយដូចនេះយើងអាចឆ្លងកាត់ស្ពាននៅពេលយើងទៅដល់ទីនោះ។
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// ការងារនៅជុំវិញ `SymGetOptions` និង `SymSetOptions` ការមិនមានវត្តមាននៅក្នុង winapi ខ្លួនវាផ្ទាល់។
// បើមិនដូច្នោះទេវាត្រូវបានប្រើតែនៅពេលដែលយើងកំពុងពិនិត្យប្រភេទទ្វេដងជាមួយ winapi ។
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // មិនបានកំណត់នៅ winapi នៅឡើយទេ
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // នេះត្រូវបានកំណត់ជា winapi ប៉ុន្តែវាមិនត្រឹមត្រូវទេ (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // មិនបានកំណត់នៅ winapi នៅឡើយទេ
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ម៉ាក្រូនេះត្រូវបានប្រើដើម្បីកំណត់រចនាសម្ព័ន្ធ `Dbghelp` ដែលមានផ្នែកចង្អុលមុខងារទាំងអស់ដែលយើងអាចផ្ទុកបាន។
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// ឌីអេសអិលដែលផ្ទុកសម្រាប់ `dbghelp.dll`
            dll: HMODULE,

            // ទ្រនិចមុខងារនីមួយៗសម្រាប់មុខងារនីមួយៗដែលយើងអាចប្រើ
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // ដំបូងយើងបានមិនត្រូវបានផ្ទុក DLL នេះ
            dll: 0 as *mut _,
            // ដំបូងមុខងារទាំងអស់ត្រូវបានកំណត់ទៅសូន្យដើម្បីនិយាយថាពួកគេត្រូវការផ្ទុកឌីណាមិក។
            //
            $($name: 0,)*
        };

        // typedef ភាពងាយស្រួលសម្រាប់ប្រភេទមុខងារនីមួយ។
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// ការប៉ុនប៉ងបើក `dbghelp.dll` ។
            /// ត្រឡប់ជោគជ័យប្រសិនបើវាដំណើរការឬមានកំហុសប្រសិនបើ `LoadLibraryW` បរាជ័យ។
            ///
            /// Panics ប្រសិនបើបណ្ណាល័យបានផ្ទុករួចហើយ។
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // មុខងារសម្រាប់វិធីសាស្រ្តដែលយើងចង់ប្រើ។
            // នៅពេលដែលគេហៅថាវានឹងអានទ្រនិចមុខងារដែលបានដាក់ក្នុងឃ្លាំងសម្ងាត់ឬផ្ទុកវាហើយប្រគល់តម្លៃដែលផ្ទុក។
            // បន្ទុកត្រូវបានអះអាងថាទទួលជោគជ័យ។
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // ប្រូកស៊ីភាពងាយស្រួលក្នុងការប្រើសោសម្អាតដើម្បីមុខងារ dbghelp ជាឯកសារយោង។
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ចាប់ផ្តើមការគាំទ្រទាំងអស់ដែលចាំបាច់ដើម្បីដំណើរការមុខងារ `dbghelp` API ពី crate នេះ។
///
///
/// ចំណាំថាមុខងារនេះមានសុវត្ថិភាព ** វាមានការធ្វើសមកាលកម្មផ្ទាល់ខ្លួន។
/// ចំណាំផងដែរថាវាមានសុវត្ថិភាពដើម្បីហៅមុខងារនេះច្រើនដងលែងកើតដោយភ្ជាប់ឡើងវិញ។
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // រឿងដំបូងដែលយើងត្រូវធ្វើគឺធ្វើសមកាលកម្មមុខងារនេះ។នេះអាចត្រូវបានគេហៅថាដំណាលគ្នាពីខ្សែស្រឡាយផ្សេងទៀតឬកើតឡើងម្តងទៀតក្នុងខ្សែស្រឡាយមួយ។
        // ចំណាំថាវាមានល្បិចកលជាងនេះទៅទៀតពីព្រោះអ្វីដែលយើងកំពុងប្រើនៅទីនេះ `dbghelp`, * ក៏ត្រូវការធ្វើសមកាលកម្មជាមួយអ្នកហៅចូលទាំងអស់ទៅ `dbghelp` នៅក្នុងដំណើរការនេះ។
        //
        // ជាធម្មតាមិនមានការហៅចូលច្រើនទៅកាន់ `dbghelp` ទេនៅក្នុងដំណើរការតែមួយហើយយើងអាចស្មានដោយសុវត្ថិភាពថាយើងគឺជាអ្នកដែលចូលប្រើវា។
        // ទោះយ៉ាងណាក៏ដោយមានអ្នកប្រើប្រាស់បឋមមួយផ្សេងទៀតដែលយើងត្រូវព្រួយបារម្ភអំពីអ្វីដែលគួរឱ្យហួសចិត្តប៉ុន្តែនៅក្នុងបណ្ណាល័យស្តង់ដារ។
        // បណ្ណាល័យស្តង់ដារ Rust ពឹងផ្អែកលើ crate នេះសម្រាប់ការគាំទ្រដានហើយ crate នេះក៏មាននៅលើ crates.io ផងដែរ។
        // នេះមានន័យថាប្រសិនបើបណ្ណាល័យស្ដង់ដារកំពុងបោះពុម្ពផ្ទាំងរូបភាព panic វាអាចប្រជែងជាមួយ crate នេះមកពី crates.io ដែលបណ្តាលឱ្យមានអំពើហឹង្សា។
        //
        // ដើម្បីជួយដោះស្រាយបញ្ហាធ្វើសមកាលកម្មនេះយើងប្រើល្បិចជាក់លាក់របស់វីនដូនៅទីនេះ (វាគឺជាការរឹតត្បិតជាក់លាក់របស់វីនដូអំពីការធ្វើសមកាលកម្ម) ។
        // យើងបង្កើត *វគ្គតាមតំបន់* ដែលមានឈ្មោះថា mutex ដើម្បីការពារការហៅនេះ។
        // គោលបំណងនៅទីនេះគឺថាបណ្ណាល័យស្តង់ដារនិង crate នេះមិនមានការចែករំលែក APIs កម្រិតទៅ Rust នៅទីនេះទេប៉ុន្តែអាចធ្វើសមកាលកម្មជំនួសឱ្យការងារនៅពីក្រោយឆាកដើម្បីធ្វើឱ្យប្រាកដថាពួកគេធ្វើសមកាលកម្មជាច្រើនគេជាមួយនឹងការមួយផ្សេងទៀត។
        //
        // វិធីនោះនៅពេលមុខងារនេះត្រូវបានហៅតាមរយៈបណ្ណាល័យស្តង់ដារឬតាមរយៈ crates.io យើងអាចប្រាកដថា mutex ដូចគ្នាកំពុងត្រូវបានទទួល។
        //
        // ដូច្នេះអ្វីៗទាំងអស់ត្រូវនិយាយថារឿងដំបូងដែលយើងធ្វើនៅទីនេះគឺយើងបង្កើតអាតូម `HANDLE` 1 ដែលជាឈ្មោះ mutex នៅលើ Windows ។
        // យើងធ្វើសមកាលកម្មបន្តិចជាមួយខ្សែស្រឡាយផ្សេងទៀតចែករំលែកមុខងារនេះជាពិសេសហើយធានាថាមានតែចំណុចទាញតែមួយប៉ុណ្ណោះដែលត្រូវបានបង្កើតឡើងក្នុងឧទាហរណ៍នៃមុខងារនេះ។
        // ចំណាំថាចំណុចទាញត្រូវបានមិនដែលបានបិទនៅពេលដែលវាត្រូវបានរក្សាទុកនៅក្នុងពិភពលោក។
        //
        // បន្ទាប់ពីយើងបានពិតជាបានចូលទៅចាក់សោយើងគ្រាន់តែទទួលបានវាហើយ `Init` របស់យើងដោះស្រាយដែលយើងប្រគល់ចេញនឹងទទួលខុសត្រូវចំពោះការទម្លាក់វានៅទីបំផុត។
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // អូខេ!ឥឡូវនេះយើងកំពុងធ្វើសមកាលកម្មដែលមានទាំងអស់ដោយសុវត្ថិភាព, ចូរយើងពិតជាបានចាប់ផ្តើមដំណើរការអ្វីទាំងអស់។
        // ដំបូងយើងត្រូវធានាថា `dbghelp.dll` ពិតជាត្រូវបានផ្ទុកនៅក្នុងដំណើរការនេះ។
        // យើងធ្វើវាយ៉ាងស្វាហាប់ដើម្បីចៀសវាងភាពអាស្រ័យឋិតិវន្ត។
        // នេះត្រូវបានធ្វើឡើងជាប្រវត្តិសាស្ត្រដើម្បីធ្វើការទាក់ទងនឹងបញ្ហាភ្ជាប់ចំលែកហើយត្រូវបានបម្រុងទុកដើម្បីធ្វើឱ្យប៊ីតប៊ីតអាចផ្ទុកបានច្រើនជាងមុនពីព្រោះនេះភាគច្រើនគ្រាន់តែជាឧបករណ៍បំបាត់កំហុស។
        //
        //
        // នៅពេលដែលយើងបានបើក `dbghelp.dll` ដែលយើងត្រូវការដើម្បីហៅមុខងារមួយចំនួននៅក្នុងវាចាប់ផ្ដើមនិងថាបានលម្អិតបន្ថែមទៀតដូចខាងក្រោម។
        // យើងធ្វើវាបានតែម្ដងដូច្នេះយើងមានប៊ូលីនជាសកលដែលចង្អុលបង្ហាញថាតើយើងបានធ្វើរួចហើយឬនៅ។
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // ធានាថាទង់ `SYMOPT_DEFERRED_LOADS` ត្រូវបានកំណត់នោះទេព្រោះបើយោងតាមឯកសាររបស់ខ្លួន MSVC អំពីនេះ: "This is the fastest, most efficient way to use the symbol handler." ដូច្នេះអនុញ្ញាតឱ្យធ្វើនោះ!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // ជាការពិតនិមិត្តសញ្ញាជាមួយ MSVC ចាប់ផ្ដើម។ចំណាំថាវាអាចបរាជ័យប៉ុន្តែយើងមិនអើពើនឹងវា។
        // មិនមានសិល្បៈមុនមួយតោនទេសម្រាប់នេះប៉ុន្តែនៅខាងក្នុងអិលអិលអិមមើលទៅហាក់ដូចជាមិនអើពើនឹងតម្លៃត្រឡប់មកវិញនៅទីនេះហើយបណ្ណាល័យអនាម័យមួយនៅក្នុងអិលអិលអិមបោះពុម្ពការព្រមានគួរឱ្យខ្លាចប្រសិនបើរឿងនេះបរាជ័យប៉ុន្តែជាទូទៅមិនអើពើនឹងវាក្នុងរយៈពេលវែង។
        //
        //
        // ករណីមួយនេះកើតឡើងច្រើនសម្រាប់ Rust គឺបណ្ណាល័យស្តង់ដារនិង crate នេះនៅលើ crates.io ទាំងពីរចង់ប្រកួតប្រជែងសម្រាប់ `SymInitializeW` ។
        // ជាប្រវត្តិសាស្ត្របណ្ណាល័យស្តង់ដារចង់ចាប់ផ្តើមបន្ទាប់មកសម្អាតពេលវេលាភាគច្រើនប៉ុន្តែឥឡូវនេះវាកំពុងប្រើ crate នេះមានន័យថានរណាម្នាក់នឹងចាប់ផ្តើមដំបូងហើយមួយទៀតនឹងចាប់ផ្តើមការចាប់ផ្តើមនេះ។
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}