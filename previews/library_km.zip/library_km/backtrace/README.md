# backtrace-rs

[Documentation](https://docs.rs/backtrace)

បណ្ណាល័យសម្រាប់ទទួលបានដាននៅពេលរត់សម្រាប់ Rust ។
បណ្ណាល័យនេះមានគោលបំណងបង្កើនការគាំទ្របណ្ណាល័យស្ដង់ដារដោយផ្តល់នូវចំណុចប្រទាក់កម្មវិធីដើម្បីធ្វើការជាមួយប៉ុន្តែវាក៏គាំទ្រផងដែរនូវការបោះពុម្ពនូវដានបច្ចុប្បន្នដូចជា panics របស់ libstd ។

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

ដើម្បីចាប់យកដាននិងពន្យាពេលក្នុងការដោះស្រាយវារហូតដល់ពេលក្រោយអ្នកអាចប្រើប្រភេទ `Backtrace` កម្រិតខ្ពស់។

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

ទោះយ៉ាងណាក៏ដោយប្រសិនបើអ្នកចង់ទទួលបានមុខងារឆៅបន្ថែមអ្នកអាចប្រើមុខងារ `trace` និង `resolve` ដោយផ្ទាល់។

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ដោះស្រាយទ្រនិចណែនាំនេះទៅឈ្មោះនិមិត្តសញ្ញា
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // បន្តទៅស៊ុមបន្ទាប់
    });
}
```

# License

គម្រោងនេះត្រូវបានទទួលបានអាជ្ញាប័ណ្ណក្រោមទាំង

 * អាជ្ញាប័ណ្ណ Apache, កំណែ 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ឬ http://www.apache.org/licenses/LICENSE-2.0)
 * អាជ្ញាប័ណ្ណ MIT ([LICENSE-MIT](LICENSE-MIT) ឬ http://opensource.org/licenses/MIT)

តាមជម្រើសរបស់អ្នក។

### Contribution

លើកលែងតែអ្នកបញ្ជាក់ច្បាស់បើមិនដូច្នោះទេរាល់ការចូលរួមវិភាគទានណាមួយត្រូវបានដាក់ដោយចេតនាសម្រាប់ការដាក់បញ្ចូលទៅក្នុងផ្ទាំងរូបភាពដោយអ្នកដែលបានកំណត់នៅក្នុងអាជ្ញាប័ណ្ណ Apache-2.0 នឹងត្រូវទទួលបានអាជ្ញាប័ណ្ណពីរដូចខាងលើដោយគ្មានលក្ខខណ្ឌបន្ថែម។







