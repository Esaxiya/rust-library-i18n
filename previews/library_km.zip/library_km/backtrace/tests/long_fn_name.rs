use backtrace::Backtrace;

// ឈ្មោះម៉ូឌុល ៥០ តួអក្សរ
mod _234567890_234567890_234567890_234567890_234567890 {
    // ឈ្មោះរចនាសម្ព័ន្ធ ៥០ តួអក្សរ
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// ឈ្មោះមុខងារវែងត្រូវតែកាត់ឱ្យខ្លីទៅ (MAX_SYM_NAME, ១) តួអក្សរ។
// ដំណើរការការធ្វើតេស្តនេះសម្រាប់តែអិមភីធីប៉ុណ្ណោះព្រោះថា gnu បោះពុម្ព "<no info>" សម្រាប់ស៊ុមទាំងអស់។
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // ពាក្យដដែលៗចំនួន ១០ នៃឈ្មោះរចនាសម្ព័ន្ធដូច្នេះឈ្មោះមុខងារដែលមានសមត្ថភាពពេញលេញគឺយ៉ាងហោចណាស់ ១០ *(៥០ + ៥០)* ២=២០០០ តួអក្សរ។
    //
    // តាមពិតវាវែងជាងមុនព្រោះវាក៏រួមបញ្ចូល `::`, `<>` និងឈ្មោះម៉ូឌុលបច្ចុប្បន្ន
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}