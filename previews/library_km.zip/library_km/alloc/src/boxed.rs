//! ប្រភេទទ្រនិចសម្រាប់ការបែងចែកហ៊ា។
//!
//! [`Box<T>`], បានហៅជាធម្មតាថាជា 'box', ផ្តល់នូវទម្រង់សាមញ្ញបំផុតនៃការបែងចែកហ៊ារនៅក្នុង Rust ។ប្រអប់ផ្តល់នូវភាពជាម្ចាស់សម្រាប់ការបែងចែកនេះហើយទម្លាក់មាតិការបស់ពួកគេនៅពេលពួកគេហួសទំហំ។ប្រអប់ក៏ធានាថាពួកគេមិនដែលបម្រុងច្រើនជាង `isize::MAX` បៃទេ។
//!
//! # Examples
//!
//! ផ្លាស់ទីតម្លៃពីជង់ទៅជាគំនរដោយបង្កើត [`Box`]៖
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! រំកិលតម្លៃពី [`Box`] ត្រឡប់ទៅជង់វិញដោយ [dereferencing]៖
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! ការបង្កើតរចនាសម្ព័ន្ធទិន្នន័យដែលហៅខ្លួនឯង៖
//!
//! ```
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{:?}", list);
//! ```
//!
//! វានឹងបោះពុម្ព `Cons (១, Cons(2, Nil))`.
//!
//! រចនាសម្ព័នដែលត្រូវធ្វើឡើងវិញត្រូវតែត្រូវបានដាក់ក្នុងប្រអប់ពីព្រោះប្រសិនបើនិយមន័យនៃ `Cons` មើលទៅដូចនេះ៖
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! វានឹងមិនដំណើរការទេ។នេះគឺដោយសារតែទំហំនៃ `List` ពឹងផ្អែកលើចំនួនធាតុដែលមាននៅក្នុងបញ្ជីហើយដូច្នេះយើងមិនដឹងថាចំនួនអង្គចងចាំប៉ុន្មានដែលត្រូវបម្រុងទុកសម្រាប់ `Cons` ។តាមរយៈការណែនាំអំពី [`Box<T>`] ដែលមានទំហំកំណត់យើងដឹងថា `Cons` ធំប៉ុនណា។
//!
//! # ប្លង់សតិ
//!
//! ចំពោះតម្លៃដែលមិនមានទំហំសូន្យ [`Box`] នឹងប្រើអ្នកបែងចែក [`Global`] សម្រាប់ការបែងចែករបស់វា។វាមានសុពលភាពក្នុងការបំលែងមធ្យោបាយទាំងពីររវាង [`Box`] និងទ្រនិចឆៅដែលបានបម្រុងទុកជាមួយអ្នកបែងចែក [`Global`] ដែលបានផ្តល់ឱ្យថា [`Layout`] ប្រើជាមួយអ្នកបែងចែកគឺត្រឹមត្រូវសម្រាប់ប្រភេទ។
//!
//! កាន់តែច្បាស់ជាងនេះទៅទៀត `value:*mut T` ដែលត្រូវបានបម្រុងទុកជាមួយអ្នកបែងចែក [`Global`] ជាមួយ `Layout::for_value(&* value)` អាចត្រូវបានបំលែងទៅជាប្រអប់មួយដោយប្រើ [`Box::<T>::from_raw(value)`] ។
//! ផ្ទុយទៅវិញការចងចាំដែលគាំទ្រ `value:*mut T` ដែលទទួលបានពី [`Box::<T>::into_raw`] អាចត្រូវបានដោះស្រាយដោយប្រើអ្នកបែងចែក [`Global`] ជាមួយ [`Layout::for_value(&* value)`] ។
//!
//! ចំពោះតម្លៃដែលមានទំហំសូន្យទ្រនិច `Box` នៅតែត្រូវជា [valid] សម្រាប់អាននិងសរសេរនិងតម្រឹមបានគ្រប់គ្រាន់។
//! ជាពិសេសការដាក់លេខគត់ដែលមិនតម្រឹមសូន្យទៅនឹងទ្រនិចឆៅបង្កើតទ្រនិចត្រឹមត្រូវប៉ុន្តែទ្រនិចចង្អុលទៅការចងចាំដែលបានបម្រុងទុកពីមុនដែលត្រូវបានដោះលែងមិនមានសុពលភាព។
//! វិធីដែលត្រូវបានណែនាំក្នុងការបង្កើតប្រអប់ទៅ ZST ប្រសិនបើ `Box::new` មិនអាចប្រើបានគឺត្រូវប្រើ [`ptr::NonNull::dangling`] ។
//!
//! ដរាបណា `T: Sized`, `Box<T>` ត្រូវបានធានាថាត្រូវបានតំណាងជាទ្រនិចតែមួយហើយវាក៏អាចមានអាយអេអាយអាយដែលឆបគ្នាជាមួយចំណុចចង្អុល C (ឧ។ ប្រភេទស៊ីអ៊ិច `T*`) ។
//! នេះមានន័យថាប្រសិនបើអ្នកមានមុខងារខាងក្រៅ "C" Rust ដែលនឹងត្រូវបានហៅចេញពី C អ្នកអាចកំណត់មុខងារ Rust ទាំងនោះដោយប្រើប្រភេទ `Box<T>` ហើយប្រើ `T*` ជាប្រភេទត្រូវគ្នានៅខាង C ។
//! ជាឧទាហរណ៍សូមពិចារណាបឋមកថា C នេះដែលប្រកាសមុខងារដែលបង្កើតនិងបំផ្លាញប្រភេទមួយចំនួននៃតម្លៃ `Foo`៖
//!
//! ```c
//! /* ក្បាលក្បាល C */
//!
//! /* ត្រឡប់ភាពជាម្ចាស់ទៅអ្នកទូរស័ព្ទចូល */
//! struct Foo* foo_new(void);
//!
//! /* យកភាពជាម្ចាស់ពីអ្នកហៅចូល;ហាមប្រើពេលហៅជាមួយ NULL */
//! void foo_delete(struct Foo*);
//! ```
//!
//! មុខងារទាំងពីរនេះអាចត្រូវបានអនុវត្តនៅក្នុង Rust ដូចខាងក្រោម។នៅទីនេះប្រភេទ `struct Foo*` ពី C ត្រូវបានបកប្រែទៅ `Box<Foo>` ដែលចាប់យកនូវឧបសគ្គនៃភាពជាម្ចាស់។
//! ចំណាំផងដែរថាអាគុយម៉ង់ដែលមិនអាចដកហូតបានចំពោះ `foo_delete` ត្រូវបានតំណាងនៅក្នុង Rust ជា `Option<Box<Foo>>` ចាប់តាំងពី `Box<Foo>` មិនអាចទុកជាមោឃៈ។
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[no_mangle]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[no_mangle]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! ទោះបីជា `Box<T>` មានតំណាងនិង C ABI ដូចគ្នានឹងទ្រនិច C ក៏ដោយនេះមិនមានន័យថាអ្នកអាចបំលែង `T*` តាមចិត្តទៅជា `Box<T>` ហើយរំពឹងថាអ្វីៗនឹងដំណើរការ។
//! `Box<T>` តម្លៃនឹងត្រូវបានតម្រឹមយ៉ាងពេញលេញមិនមែនជាអ្នកចង្អុល។លើសពីនេះទៀតអ្នកបំផ្លាញសម្រាប់ `Box<T>` នឹងព្យាយាមដោះលែងតម្លៃជាមួយអ្នកបែងចែកពិភពលោក។ជាទូទៅការអនុវត្តល្អបំផុតគឺប្រើតែ `Box<T>` សម្រាប់អ្នកចង្អុលបង្ហាញដែលមានប្រភពចេញពីអ្នកបែងចែកសកល។
//!
//! **សំខាន់** យ៉ាងហោចណាស់អ្នកគួរតែចៀសវាងការប្រើប្រាស់ប្រភេទ `Box<T>` សំរាប់មុខងារដែលត្រូវបានកំនត់ក្នុង C ប៉ុន្តែត្រូវបានហៅពី Rust ។ក្នុងករណីទាំងនោះអ្នកគួរតែឆ្លុះកញ្ចក់ប្រភេទ C ឱ្យជិតបំផុតតាមដែលអាចធ្វើទៅបាន។
//! ការប្រើប្រាស់ប្រភេទដូចជា `Box<T>` ដែលនិយមន័យ C កំពុងប្រើ `T*` អាចនាំឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់ដូចបានពិពណ៌នានៅក្នុង [rust-lang/unsafe-code-guidelines#198][ucg#198] ។
//!
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator, Iterator};
use core::marker::{Unpin, Unsize};
use core::mem;
use core::ops::{
    CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Generator, GeneratorState, Receiver,
};
use core::pin::Pin;
use core::ptr::{self, Unique};
use core::stream::Stream;
use core::task::{Context, Poll};

use crate::alloc::{handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw};
use crate::borrow::Cow;
use crate::raw_vec::RawVec;
use crate::str::from_boxed_utf8_unchecked;
use crate::vec::Vec;

/// ប្រភេទទ្រនិចសម្រាប់ការបែងចែកហ៊ា។
///
/// មើល [module-level documentation](../../std/boxed/index.html) សម្រាប់ព័ត៌មានបន្ថែម។
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Box<
    T: ?Sized,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
>(Unique<T>, A);

impl<T> Box<T> {
    /// បែងចែកការចងចាំនៅលើគំនរហើយបន្ទាប់មកដាក់ `x` ទៅក្នុងនោះ។
    ///
    /// នេះពិតជាមិនបែងចែកទេប្រសិនបើ `T` មានទំហំសូន្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    #[inline(always)]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(x: T) -> Self {
        box x
    }

    /// សាងសង់ប្រអប់ថ្មីមួយដែលមានមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        Self::new_uninit_in(Global)
    }

    /// សាងសង់ `Box` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[inline]
    #[doc(alias = "calloc")]
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// សាងសង់ `Pin<Box<T>>` ថ្មី។
    /// ប្រសិនបើ `T` មិនអនុវត្ត `Unpin` នោះ `x` នឹងត្រូវបានបញ្ចូលក្នុងសតិហើយមិនអាចផ្លាស់ទីបាន។
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        (box x).into()
    }

    /// បែងចែកសតិនៅលើគំនរបន្ទាប់មកដាក់ `x` ទៅក្នុងវាដោយត្រឡប់កំហុសប្រសិនបើការបែងចែកបរាជ័យ
    ///
    ///
    /// នេះពិតជាមិនបែងចែកទេប្រសិនបើ `T` មានទំហំសូន្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// សាងសង់ប្រអប់ថ្មីមួយដែលមានមាតិកាដែលមិនមានលក្ខណៈចម្រុះនៅលើគំនរសំរាមដោយត្រឡប់កំហុសប្រសិនបើការបែងចែកបរាជ័យ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// សាងសង់ `Box` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃនៅលើគំនរ
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// បែងចែកសតិនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់បន្ទាប់មកដាក់ `x` ទៅក្នុងវា។
    ///
    /// នេះពិតជាមិនបែងចែកទេប្រសិនបើ `T` មានទំហំសូន្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        unsafe {
            boxed.as_mut_ptr().write(x);
            boxed.assume_init()
        }
    }

    /// បែងចែកសតិនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់បន្ទាប់មកដាក់ `x` ទៅក្នុងវាត្រឡប់មកវិញដោយមានកំហុសប្រសិនបើការបែងចែកបរាជ័យ
    ///
    ///
    /// នេះពិតជាមិនបែងចែកទេប្រសិនបើ `T` មានទំហំសូន្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        unsafe {
            boxed.as_mut_ptr().write(x);
            Ok(boxed.assume_init())
        }
    }

    /// សាងសង់ប្រអប់ថ្មីដែលមានមាតិកាដែលមិនមានលក្ខណៈចម្រុះនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់ឱ្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: ចូលចិត្តការប្រកួតលើសពីការមិនពេញចិត្តចាប់តាំងពីការបិទពេលខ្លះមិនអាចពិពណ៌នាបាន។
        // នោះនឹងធ្វើឱ្យទំហំកូដកាន់តែធំ។
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// សាងសង់ប្រអប់ថ្មីមួយដែលមានមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់ឱ្យត្រឡប់មកវិញដោយមានកំហុសប្រសិនបើការបែងចែកបរាជ័យ
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// សាងសង់ `Box` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: ចូលចិត្តការប្រកួតលើសពីការមិនពេញចិត្តចាប់តាំងពីការបិទពេលខ្លះមិនអាចពិពណ៌នាបាន។
        // នោះនឹងធ្វើឱ្យទំហំកូដកាន់តែធំ។
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// សាងសង់ `Box` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានឯកសិទ្ធិដោយសតិត្រូវបានបំពេញដោយ `0` បៃនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់ឱ្យត្រឡប់កំហុសប្រសិនបើការបែងចែកបរាជ័យ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        let ptr = alloc.allocate_zeroed(layout)?.cast();
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// សាងសង់ `Pin<Box<T, A>>` ថ្មី។
    /// ប្រសិនបើ `T` មិនអនុវត្ត `Unpin` នោះ `x` នឹងត្រូវបានបញ្ចូលក្នុងសតិហើយមិនអាចផ្លាស់ទីបាន។
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: 'static,
    {
        Self::new_in(x, alloc).into()
    }

    /// បំលែង `Box<T>` ទៅជា `Box<[T]>`
    ///
    /// ការបំលែងនេះមិនមានការបែងចែកនៅលើគំនរនិងកើតឡើងនៅកន្លែងនោះទេ។
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// ប្រើប្រាស់ `Box`, ត្រឡប់មកវិញតម្លៃរុំ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }
}

impl<T> Box<[T]> {
    /// សាងសង់ចំណិតប្រអប់ថ្មីដែលមានមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// សាងសង់ចំណិតប្រអប់ថ្មីដែលមានមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// សាងសង់ចំណិតប្រអប់ថ្មីមួយដែលមានមាតិកាគ្មានមនុស្សនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់ឱ្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    ///
    /// let values = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// សាងសង់ចំណិតប្រអប់ថ្មីដែលមានមាតិកាដែលមិនមានឯកសិទ្ធិនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់ឱ្យដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// បំលែងទៅជា `Box<T, A>` ។
    ///
    /// # Safety
    ///
    /// ដូចគ្នានឹង [`MaybeUninit::assume_init`] ដែរវាអាស្រ័យលើអ្នកទូរស័ព្ទចូលដើម្បីធានាថាតម្លៃពិតជាស្ថិតនៅក្នុងស្ថានភាពដំបូង។
    ///
    /// ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗ។
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut five = Box::<u32>::new_uninit();
    ///
    /// let five: Box<u32> = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     five.as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<T, A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut T, alloc) }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// បំលែងទៅជា `Box<[T], A>` ។
    ///
    /// # Safety
    ///
    /// ដូចគ្នានឹង [`MaybeUninit::assume_init`] ដែរវាអាស្រ័យលើអ្នកទូរស័ព្ទចូលដើម្បីធានាថាតម្លៃពិតជាស្ថិតនៅក្នុងស្ថានភាពដំបូង។
    ///
    /// ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗ។
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     values[0].as_mut_ptr().write(1);
    ///     values[1].as_mut_ptr().write(2);
    ///     values[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// សាងសង់ប្រអប់ពីទ្រនិចឆៅ។
    ///
    /// បន្ទាប់ពីហៅមុខងារនេះទ្រនិចឆៅត្រូវបានគ្រប់គ្រងដោយ `Box` លទ្ធផល។
    /// ជាពិសេសអ្នកបំផ្លាញវាសនា `Box` នឹងហៅអ្នកនាំផ្លូវ `T` និងទុកអង្គចងចាំដែលបានបម្រុងទុក។
    /// ដើម្បីឱ្យមានសុវត្ថិភាពសតិត្រូវតែត្រូវបានបម្រុងទុកស្របតាម [memory layout] ដែលប្រើដោយ `Box` ។
    ///
    ///
    /// # Safety
    ///
    /// មុខងារនេះមិនមានសុវត្ថិភាពទេពីព្រោះការប្រើប្រាស់មិនត្រឹមត្រូវអាចនាំឱ្យមានបញ្ហានៃការចងចាំ។
    /// ឧទាហរណ៍ការឥតគិតថ្លៃទ្វេដងអាចកើតឡើងប្រសិនបើមុខងារត្រូវបានហៅពីរដងលើទ្រនិចឆៅដូចគ្នា។
    ///
    /// លក្ខខណ្ឌសុវត្ថិភាពត្រូវបានពិពណ៌នានៅក្នុងផ្នែក [memory layout] ។
    ///
    /// # Examples
    ///
    /// បង្កើត `Box` ដែលត្រូវបានប្តូរទៅជាទ្រនិចឆៅដោយប្រើ [`Box::into_raw`]៖
    ///
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// បង្កើត `Box` ដោយដៃពីទទេដោយប្រើអ្នកបែងចែកជាសកល៖
    ///
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // ជាទូទៅ .write ត្រូវបានទាមទារដើម្បីចៀសវាងការប៉ុនប៉ងបំផ្លាញមាតិកា (uninitialized) ពីមុនរបស់ `ptr` ទោះបីជាឧទាហរណ៍សាមញ្ញ `*ptr = 5` ក៏អាចដំណើរការបានដែរ។
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        unsafe { Self::from_raw_in(raw, Global) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// សាងសង់ប្រអប់មួយពីទ្រនិចឆៅនៅក្នុងអ្នកបែងចែកដែលបានផ្តល់ឱ្យ។
    ///
    /// បន្ទាប់ពីហៅមុខងារនេះទ្រនិចឆៅត្រូវបានគ្រប់គ្រងដោយ `Box` លទ្ធផល។
    /// ជាពិសេសអ្នកបំផ្លាញវាសនា `Box` នឹងហៅអ្នកនាំផ្លូវ `T` និងទុកអង្គចងចាំដែលបានបម្រុងទុក។
    /// ដើម្បីឱ្យមានសុវត្ថិភាពសតិត្រូវតែត្រូវបានបម្រុងទុកស្របតាម [memory layout] ដែលប្រើដោយ `Box` ។
    ///
    ///
    /// # Safety
    ///
    /// មុខងារនេះមិនមានសុវត្ថិភាពទេពីព្រោះការប្រើប្រាស់មិនត្រឹមត្រូវអាចនាំឱ្យមានបញ្ហានៃការចងចាំ។
    /// ឧទាហរណ៍ការឥតគិតថ្លៃទ្វេដងអាចកើតឡើងប្រសិនបើមុខងារត្រូវបានហៅពីរដងលើទ្រនិចឆៅដូចគ្នា។
    ///
    /// # Examples
    ///
    /// បង្កើត `Box` ដែលត្រូវបានប្តូរទៅជាទ្រនិចឆៅដោយប្រើ [`Box::into_raw_with_allocator`]៖
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// បង្កើត `Box` ដោយដៃពីទទេដោយប្រើអ្នកបែងចែកប្រព័ន្ធ៖
    ///
    /// ```
    /// #![feature(allocator_api, slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr();
    ///     // ជាទូទៅ .write ត្រូវបានទាមទារដើម្បីចៀសវាងការប៉ុនប៉ងបំផ្លាញមាតិកា (uninitialized) ពីមុនរបស់ `ptr` ទោះបីជាឧទាហរណ៍សាមញ្ញ `*ptr = 5` ក៏អាចដំណើរការបានដែរ។
    /////
    /////
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`Layout`]: crate::Layout
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        Box(unsafe { Unique::new_unchecked(raw) }, alloc)
    }

    /// ប្រើប្រាស់ `Box` ត្រឡប់ទ្រនិចខ្ចប់រុំ។
    ///
    /// ទ្រនិចនឹងត្រូវបានតម្រឹមត្រឹមត្រូវហើយមិនត្រូវទុកចោល។
    ///
    /// បន្ទាប់ពីហៅមុខងារនេះអ្នកទូរស័ព្ទចូលត្រូវទទួលខុសត្រូវចំពោះអង្គចងចាំដែលបានគ្រប់គ្រងពីមុនដោយ `Box` ។
    /// ជាពិសេសអ្នកទូរស័ព្ទចូលគួរបំផ្លាញ `T` ឱ្យបានត្រឹមត្រូវនិងបញ្ចេញអង្គចងចាំដោយគិតពី [memory layout] ដែលប្រើដោយ `Box` ។
    /// វិធីងាយស្រួលបំផុតគឺប្តូរទ្រនិចឆៅត្រឡប់ទៅជា `Box` ដែលមានមុខងារ [`Box::from_raw`] ដែលអនុញ្ញាតឱ្យអ្នកបំផ្លាញ `Box` ធ្វើការសំអាត។
    ///
    ///
    /// Note: នេះគឺជាមុខងារដែលមានន័យថាអ្នកត្រូវហៅវាថា `Box::into_raw(b)` ជំនួសឱ្យ `b.into_raw()` ។
    /// នេះគឺដូច្នេះថាមិនមានការប៉ះទង្គិចជាមួយវិធីសាស្ត្រលើប្រភេទខាងក្នុងទេ។
    ///
    /// # Examples
    /// បំលែងទ្រនិចឆៅត្រឡប់ទៅជា `Box` ជាមួយ [`Box::from_raw`] សម្រាប់ការសម្អាតស្វ័យប្រវត្តិ៖
    ///
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    ///
    /// ការសម្អាតដោយដៃដោយដំណើរការអ្នកបំផ្លាញនិងចែករំលេកសតិ៖
    ///
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let p = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(p);
    ///     dealloc(p as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        Self::into_raw_with_allocator(b).0
    }

    /// ប្រើប្រាស់ `Box` ត្រឡប់ទ្រនិចខ្ចប់រុំនិងអ្នកបែងចែក។
    ///
    /// ទ្រនិចនឹងត្រូវបានតម្រឹមត្រឹមត្រូវហើយមិនត្រូវទុកចោល។
    ///
    /// បន្ទាប់ពីហៅមុខងារនេះអ្នកទូរស័ព្ទចូលត្រូវទទួលខុសត្រូវចំពោះអង្គចងចាំដែលបានគ្រប់គ្រងពីមុនដោយ `Box` ។
    /// ជាពិសេសអ្នកទូរស័ព្ទចូលគួរបំផ្លាញ `T` ឱ្យបានត្រឹមត្រូវនិងបញ្ចេញអង្គចងចាំដោយគិតពី [memory layout] ដែលប្រើដោយ `Box` ។
    /// វិធីងាយស្រួលបំផុតគឺប្តូរទ្រនិចឆៅត្រឡប់ទៅជា `Box` ដែលមានមុខងារ [`Box::from_raw_in`] ដែលអនុញ្ញាតឱ្យអ្នកបំផ្លាញ `Box` ធ្វើការសំអាត។
    ///
    ///
    /// Note: នេះគឺជាមុខងារដែលមានន័យថាអ្នកត្រូវហៅវាថា `Box::into_raw_with_allocator(b)` ជំនួសឱ្យ `b.into_raw_with_allocator()` ។
    /// នេះគឺដូច្នេះថាមិនមានការប៉ះទង្គិចជាមួយវិធីសាស្ត្រលើប្រភេទខាងក្នុងទេ។
    ///
    /// # Examples
    /// បំលែងទ្រនិចឆៅត្រឡប់ទៅជា `Box` ជាមួយ [`Box::from_raw_in`] សម្រាប់ការសម្អាតស្វ័យប្រវត្តិ៖
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    ///
    /// ការសម្អាតដោយដៃដោយដំណើរការអ្នកបំផ្លាញនិងចែករំលេកសតិ៖
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let (leaked, alloc) = Box::into_unique(b);
        (leaked.as_ptr(), alloc)
    }

    #[unstable(
        feature = "ptr_internals",
        issue = "none",
        reason = "use `Box::leak(b).into()` or `Unique::from(Box::leak(b))` instead"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn into_unique(b: Self) -> (Unique<T>, A) {
        // ប្រអប់ត្រូវបានគេទទួលស្គាល់ថាជា "unique pointer" ដោយ Stacked Borrows ប៉ុន្តែនៅខាងក្នុងវាគឺជាទ្រនិចចង្អុលសម្រាប់ប្រព័ន្ធប្រភេទ។
        // ការប្រែក្លាយវាដោយផ្ទាល់ទៅជាទ្រនិចឆៅនឹងមិនត្រូវបានគេទទួលស្គាល់ថាជា "releasing" ជាទ្រនិចតែមួយគត់ដើម្បីអនុញ្ញាតឱ្យចូលប្រើឆៅទេដូច្នេះវិធីសាស្ត្រទ្រនិចចង្អុលឆៅទាំងអស់ត្រូវឆ្លងកាត់ `Box::leak` ។
        //
        // ងាក *ថា* ទៅទ្រនិចឆៅមានឥរិយាបថត្រឹមត្រូវ។
        //
        let alloc = unsafe { ptr::read(&b.1) };
        (Unique::from(Box::leak(b)), alloc)
    }

    /// ត្រឡប់សេចក្តីយោងទៅអ្នកបែងចែកមូលដ្ឋាន។
    ///
    /// Note: នេះគឺជាមុខងារដែលមានន័យថាអ្នកត្រូវហៅវាថា `Box::allocator(&b)` ជំនួសឱ្យ `b.allocator()` ។
    /// នេះគឺដូច្នេះថាមិនមានការប៉ះទង្គិចជាមួយវិធីសាស្ត្រលើប្រភេទខាងក្នុងទេ។
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// ប្រើប្រាស់និងលេចធ្លាយ `Box` ត្រលប់មកវិញនូវឯកសារយោងដែលអាចផ្លាស់ប្តូរបាន។ `&'a mut T`.
    /// ចំណាំថាប្រភេទ `T` ត្រូវតែមានអាយុកាលវែងជាងអាយ `'a` ដែលបានជ្រើសរើស។
    /// ប្រសិនបើប្រភេទមានសេចក្តីយោងឋិតិវន្តឬគ្មានអ្វីទាំងអស់នោះនេះអាចត្រូវបានជ្រើសរើសជា `'static` ។
    ///
    /// មុខងារនេះមានអត្ថប្រយោជន៍ជាចម្បងសម្រាប់ទិន្នន័យដែលរស់នៅពេញមួយជីវិតរបស់កម្មវិធី។
    /// ទម្លាក់ឯកសារយោងដែលបានត្រឡប់មកវិញនឹងបណ្តាលឱ្យលេចធ្លាយសតិ។
    /// ប្រសិនបើនេះមិនអាចទទួលយកបានទេសេចក្តីយោងដំបូងគួរតែត្រូវបានរុំជាមួយមុខងារ [`Box::from_raw`] ដែលផលិត `Box` ។
    ///
    /// `Box` នេះអាចត្រូវបានទម្លាក់ដែលនឹងបំផ្លាញ `T` យ៉ាងត្រឹមត្រូវនិងបញ្ចេញអង្គចងចាំដែលបានបម្រុងទុក។
    ///
    /// Note: នេះគឺជាមុខងារដែលមានន័យថាអ្នកត្រូវហៅវាថា `Box::leak(b)` ជំនួសឱ្យ `b.leak()` ។
    /// នេះគឺដូច្នេះថាមិនមានការប៉ះទង្គិចជាមួយវិធីសាស្ត្រលើប្រភេទខាងក្នុងទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់សាមញ្ញ៖
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// ```
    ///
    /// ទិន្នន័យមិនត្រូវបានកំណត់៖
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        unsafe { &mut *mem::ManuallyDrop::new(b).0.as_ptr() }
    }

    /// បំលែង `Box<T>` ទៅជា `Pin<Box<T>>`
    ///
    /// ការបំលែងនេះមិនមានការបែងចែកនៅលើគំនរនិងកើតឡើងនៅកន្លែងនោះទេ។
    ///
    /// នេះក៏មានផងដែរតាមរយៈ [`From`] ។
    #[unstable(feature = "box_into_pin", issue = "62370")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: 'static,
    {
        // វាមិនអាចទៅរួចទេក្នុងការផ្លាស់ទីឬជំនួសផ្នែកខាងក្នុងនៃ `Pin<Box<T>>` នៅពេល `T: !Unpin` ដូច្នេះវាមានសុវត្ថិភាពក្នុងការភ្ជាប់វាដោយផ្ទាល់ដោយមិនចាំបាច់មានតម្រូវការបន្ថែម។
        //
        //
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    fn drop(&mut self) {
        // FIXME: មិនធ្វើអ្វីទេការទម្លាក់បច្ចុប្បន្នត្រូវបានអនុវត្តដោយអ្នកចងក្រង។
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// បង្កើត `Box<T>` មួយដែលមានតម្លៃ `Default` សំរាប់ T ។
    fn default() -> Self {
        box T::default()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    fn default() -> Self {
        Box::<[T; 0]>::new([])
    }
}

#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    fn default() -> Self {
        unsafe { from_boxed_utf8_unchecked(Default::default()) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// ត្រឡប់ប្រអប់ថ្មីមួយដែលមាន `clone()` នៃមាតិការបស់ប្រអប់នេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // តម្លៃគឺដូចគ្នា
    /// assert_eq!(x, y);
    ///
    /// // ប៉ុន្តែពួកវាជាវត្ថុប្លែកៗ
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // បែងចែកការចងចាំជាមុនដើម្បីអនុញ្ញាតឱ្យសរសេរតម្លៃក្លូនដោយផ្ទាល់។
        let mut boxed = Self::new_uninit_in(self.1.clone());
        unsafe {
            (**self).write_clone_into_raw(boxed.as_mut_ptr());
            boxed.assume_init()
        }
    }

    /// ថតចម្លងមាតិកា `ប្រភព` ទៅជាអ៊ិចស៊ីអ៊ិចដោយមិនបង្កើតការបែងចែកថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // តម្លៃគឺដូចគ្នា
    /// assert_eq!(x, y);
    ///
    /// // ហើយគ្មានការបែងចែកកើតឡើងទេ
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl Clone for Box<str> {
    fn clone(&self) -> Self {
        // នេះធ្វើការចម្លងទិន្នន័យ
        let buf: Box<[u8]> = self.as_bytes().into();
        unsafe { from_boxed_utf8_unchecked(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Box<T> {
    /// បំលែងប្រភេទទូទៅ `T` ទៅជា `Box<T>`
    ///
    /// ការផ្លាស់ប្តូរបែងចែកនៅលើគំនរនិងផ្លាស់ទី `t` ពីជង់ចូលទៅក្នុងវា។
    ///
    /// # Examples
    ///
    /// ```rust
    /// let x = 5;
    /// let boxed = Box::new(5);
    ///
    /// assert_eq!(Box::from(x), boxed);
    /// ```
    fn from(t: T) -> Self {
        Box::new(t)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> From<Box<T, A>> for Pin<Box<T, A>>
where
    A: 'static,
{
    /// បំលែង `Box<T>` ទៅជា `Pin<Box<T>>`
    ///
    /// ការបំលែងនេះមិនមានការបែងចែកនៅលើគំនរនិងកើតឡើងនៅកន្លែងនោះទេ។
    fn from(boxed: Box<T, A>) -> Self {
        Box::into_pin(boxed)
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl<T: Copy> From<&[T]> for Box<[T]> {
    /// បំលែង `&[T]` ទៅជា `Box<[T]>`
    ///
    /// ការបម្លែងនេះបម្រុងទុកនៅលើគំនរនិងអនុវត្តច្បាប់ចម្លងនៃ `slice` ។
    ///
    /// # Examples
    ///
    /// ```rust
    /// // បង្កើត&[u8] ដែលនឹងត្រូវបានប្រើដើម្បីបង្កើតប្រអប់ <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice: Box<[u8]> = Box::from(slice);
    ///
    /// println!("{:?}", boxed_slice);
    /// ```
    fn from(slice: &[T]) -> Box<[T]> {
        let len = slice.len();
        let buf = RawVec::with_capacity(len);
        unsafe {
            ptr::copy_nonoverlapping(slice.as_ptr(), buf.ptr(), len);
            buf.into_box(slice.len()).assume_init()
        }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl<T: Copy> From<Cow<'_, [T]>> for Box<[T]> {
    #[inline]
    fn from(cow: Cow<'_, [T]>) -> Box<[T]> {
        match cow {
            Cow::Borrowed(slice) => Box::from(slice),
            Cow::Owned(slice) => Box::from(slice),
        }
    }
}

#[stable(feature = "box_from_slice", since = "1.17.0")]
impl From<&str> for Box<str> {
    /// បំលែង `&str` ទៅជា `Box<str>`
    ///
    /// ការបម្លែងនេះបម្រុងទុកនៅលើគំនរនិងអនុវត្តច្បាប់ចម្លងនៃ `s` ។
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<str> = Box::from("hello");
    /// println!("{}", boxed);
    /// ```
    #[inline]
    fn from(s: &str) -> Box<str> {
        unsafe { from_boxed_utf8_unchecked(Box::from(s.as_bytes())) }
    }
}

#[stable(feature = "box_from_cow", since = "1.45.0")]
impl From<Cow<'_, str>> for Box<str> {
    #[inline]
    fn from(cow: Cow<'_, str>) -> Box<str> {
        match cow {
            Cow::Borrowed(s) => Box::from(s),
            Cow::Owned(s) => Box::from(s),
        }
    }
}

#[stable(feature = "boxed_str_conv", since = "1.19.0")]
impl<A: Allocator> From<Box<str, A>> for Box<[u8], A> {
    /// បំលែង `Box<str>` ទៅជា `Box<[u8]>`
    /// ការបំលែងនេះមិនមានការបែងចែកនៅលើគំនរនិងកើតឡើងនៅកន្លែងនោះទេ។
    ///
    /// # Examples
    ///
    /// ```rust
    /// // បង្កើតប្រអប់មួយ<str>ដែលនឹងត្រូវបានប្រើដើម្បីបង្កើតប្រអប់ <[u8]>
    /// let boxed: Box<str> = Box::from("hello");
    /// let boxed_str: Box<[u8]> = Box::from(boxed);
    ///
    /// // បង្កើត&[u8] ដែលនឹងត្រូវបានប្រើដើម្បីបង្កើតប្រអប់ <[u8]>
    /// let slice: &[u8] = &[104, 101, 108, 108, 111];
    /// let boxed_slice = Box::from(slice);
    ///
    /// assert_eq!(boxed_slice, boxed_str);
    /// ```
    #[inline]
    fn from(s: Box<str, A>) -> Self {
        let (raw, alloc) = Box::into_raw_with_allocator(s);
        unsafe { Box::from_raw_in(raw as *mut [u8], alloc) }
    }
}

#[stable(feature = "box_from_array", since = "1.45.0")]
impl<T, const N: usize> From<[T; N]> for Box<[T]> {
    /// បំលែង `[T; N]` ទៅជា `Box<[T]>`
    /// ការបម្លែងនេះផ្លាស់ទីអារេទៅសតិដែលបានបម្រុងទុកហ៊ាថ្មី។
    ///
    /// # Examples
    ///
    /// ```rust
    /// let boxed: Box<[u8]> = Box::from([4, 2]);
    /// println!("{:?}", boxed);
    /// ```
    fn from(array: [T; N]) -> Box<[T]> {
        box array
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Box<[T]>> for Box<[T; N]> {
    type Error = Box<[T]>;

    fn try_from(boxed_slice: Box<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Box::from_raw(Box::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

impl<A: Allocator> Box<dyn Any, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// ព្យាយាមទម្លាក់ប្រអប់ទៅនឹងប្រភេទបេតុង។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut dyn Any, _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send, A> {
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    /// ព្យាយាមទម្លាក់ប្រអប់ទៅនឹងប្រភេទបេតុង។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send), _) = Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

impl<A: Allocator> Box<dyn Any + Send + Sync, A> {
    #[inline]
    #[stable(feature = "box_send_sync_any_downcast", since = "1.51.0")]
    /// ព្យាយាមទម្លាក់ប្រអប់ទៅនឹងប្រភេទបេតុង។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(value: Box<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Box::new(my_string));
    /// print_if_string(Box::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Box<T, A>, Self> {
        if self.is::<T>() {
            unsafe {
                let (raw, alloc): (*mut (dyn Any + Send + Sync), _) =
                    Box::into_raw_with_allocator(self);
                Ok(Box::from_raw_in(raw as *mut T, alloc))
            }
        } else {
            Err(self)
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // វាមិនអាចទៅរួចទេក្នុងការទាញយក Uniq ខាងក្នុងដោយផ្ទាល់ពីប្រអប់ផ្ទុយទៅវិញយើងបោះវាទៅជា * const ដែលហៅឈ្មោះថាប្លែក
        //
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> Receiver for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized, A: Allocator> Iterator for Box<I, A> {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth(n)
    }
    fn last(self) -> Option<I::Item> {
        BoxIter::last(self)
    }
}

trait BoxIter {
    type Item;
    fn last(self) -> Option<Self::Item>;
}

impl<I: Iterator + ?Sized, A: Allocator> BoxIter for Box<I, A> {
    type Item = I::Item;
    default fn last(self) -> Option<I::Item> {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }
}

/// ឯកទេសសម្រាប់ទំហំ `I` ដែលប្រើ `I`s នៃ `last()` ជំនួសឱ្យលំនាំដើម។
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, A: Allocator> BoxIter for Box<I, A> {
    fn last(self) -> Option<I::Item> {
        (*self).last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator + ?Sized, A: Allocator> DoubleEndedIterator for Box<I, A> {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized, A: Allocator> ExactSizeIterator for Box<I, A> {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized, A: Allocator> FusedIterator for Box<I, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "boxed_slice_from_iter", since = "1.32.0")]
impl<I> FromIterator<I> for Box<[I]> {
    fn from_iter<T: IntoIterator<Item = I>>(iter: T) -> Self {
        iter.into_iter().collect::<Vec<_>>().into_boxed_slice()
    }
}

#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    fn clone_from(&mut self, other: &Self) {
        if self.len() == other.len() {
            self.clone_from_slice(&other);
        } else {
            *self = other.clone();
        }
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> borrow::BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        &mut **self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> where A: 'static {}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R, A: Allocator> Generator<R> for Box<G, A>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R, A: Allocator> Generator<R> for Pin<Box<G, A>>
where
    A: 'static,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A>
where
    A: 'static,
{
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for Box<S> {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut **self).poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}