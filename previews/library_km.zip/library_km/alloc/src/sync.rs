#![stable(feature = "rust1", since = "1.0.0")]

//! ចង្អុលរាប់ការយោង-មានសុវត្ថិភាព។
//!
//! សូមមើលឯកសារ [`Arc<T>`][Arc] សម្រាប់ព័ត៌មានលម្អិត។

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// ដែនកំណត់ទន់លើចំនួនឯកសារយោងដែលអាចត្រូវបានធ្វើឡើងចំពោះ `Arc` ។
///
/// លើសពីដែនកំណត់នេះនឹងបញ្ឈប់កម្មវិធីរបស់អ្នក (ទោះបីជាមិនចាំបាច់ក៏ដោយ) នៅឯឯកសារយោង _exactly_ `MAX_REFCOUNT + 1` ។
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer មិនគាំទ្ររបងចងចាំទេ។
// ដើម្បីចៀសវាងរបាយការណ៍វិជ្ជមានក្លែងក្លាយនៅក្នុងការអនុវត្តធ្នូ/ខ្សោយប្រើបន្ទុកអាតូមសម្រាប់ធ្វើសមកាលកម្មជំនួស។
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ទ្រនិចរាប់ការយោង-ខ្សែស្រឡាយ-មានសុវត្ថិភាព។'Arc' តំណាងឱ្យ 'ការរាប់យោងតាមអាតូម' ។
///
/// ប្រភេទ `Arc<T>` ផ្តល់នូវកម្មសិទ្ធិរួមគ្នានៃតម្លៃនៃប្រភេទ `T` ដែលបានបម្រុងទុកនៅក្នុងគំនរ។ការហៅ [`clone`][clone] លើ `Arc` បង្កើតឧទាហរណ៍ `Arc` ថ្មីដែលចង្អុលបង្ហាញការបម្រុងទុកដូចគ្នានៅលើហ៊ាជាប្រភព `Arc` ខណៈពេលកំពុងបង្កើនចំនួនយោង។
/// នៅពេលដែលទ្រនិច `Arc` ចុងក្រោយទៅនឹងការបែងចែកដែលបានផ្តល់ឱ្យត្រូវបានបំផ្លាញតម្លៃដែលបានរក្សាទុកនៅក្នុងការបែងចែកនោះ (ជាញឹកញាប់សំដៅទៅលើ "inner value") ក៏ត្រូវបានធ្លាក់ចុះដែរ។
///
/// ចែករំលែកការផ្លាស់ប្តូរ Rust សេចក្តីយោងនៅតាមលំនាំដើមមិនអនុញ្ញាតនិងមិនមានករណីលើកលែងគឺ `Arc`: អ្នកមិនអាចទទួលបានសេចក្ដីយោងជាទូទៅទៅជាអ្វីនៅខាងក្នុង mutable មួយ `Arc` ។ប្រសិនបើអ្នកត្រូវការផ្លាស់ប្តូរតាមរយៈ `Arc` សូមប្រើ [`Mutex`][mutex], [`RwLock`][rwlock] ឬមួយនៃប្រភេទ [`Atomic`][atomic] ។
///
/// ## សុវត្ថិភាពខ្សែស្រឡាយ
///
/// មិនដូច [`Rc<T>`] ទេ `Arc<T>` ប្រើប្រតិបត្តិការអាតូមិចសម្រាប់ការរាប់យោងរបស់វា។នេះមានន័យថាវាមានសុវត្ថិភាពហើយ។គុណវិបត្តិគឺថាប្រតិបត្តិការអាតូមិចមានតម្លៃថ្លៃជាងការចូលប្រើសតិធម្មតា។ប្រសិនបើអ្នកមិនចែករំលែកការបែងចែករាប់យោងរវាងខ្សែស្រឡាយសូមពិចារណាប្រើ [`Rc<T>`] សម្រាប់ផ្នែកខាងលើទាប។
/// [`Rc<T>`] ជាលំនាំដើមដែលមានសុវត្ថិភាពពីព្រោះអ្នកចងក្រងនឹងចាប់ការប៉ុនប៉ងផ្ញើ [`Rc<T>`] រវាងខ្សែស្រឡាយ។
/// ទោះយ៉ាងណាបណ្ណាល័យមួយអាចជ្រើសរើស `Arc<T>` ដើម្បីផ្តល់ភាពងាយស្រួលដល់អ្នកប្រើប្រាស់បណ្ណាល័យ។
///
/// `Arc<T>` នឹងអនុវត្ត [`Send`] និង [`Sync`] ដរាបណា `T` អនុវត្ត [`Send`] និង [`Sync`] ។
/// ហេតុអ្វីបានជាអ្នកមិនអាចដាក់ប្រភេទ `T` ដែលមិនមែនជាខ្សែស្រឡាយដែលមានសុវត្ថិភាពក្នុង `Arc<T>` ដើម្បីធ្វើឱ្យវាមានសុវត្ថិភាព?ដំបូងនេះអាចប្រឆាំងនឹងវិចារណញាណបន្តិច៖ បន្ទាប់ពីទាំងអស់តើនេះមិនមែនជាសុវត្ថិភាពនៃខ្សែស្រឡាយ `Arc<T>` ទេឬ?ចំណុចសំខាន់គឺនេះ៖ `Arc<T>` ធ្វើឱ្យវាមានសុវត្ថិភាពក្នុងការមានកម្មសិទ្ធិច្រើននៃទិន្នន័យតែមួយប៉ុន្តែវាមិនបន្ថែមសុវត្ថិភាពខ្សែស្រឡាយទៅទិន្នន័យរបស់វាទេ។
///
/// ពិចារណា `ធ្នូធ្នូ` [`RefCell<T>`]`>`។
/// [`RefCell<T>`] មិនមែន [`Sync`] ទេហើយបើ `Arc<T>` គឺតែងតែជា [`Send`] នោះគឺ Arc <`[` RefCell<T>`]`> `ក៏ដូចគ្នាដែរ។
/// ប៉ុន្តែបន្ទាប់មកយើងនឹងមានបញ្ហា៖
/// [`RefCell<T>`] មិនខ្សែស្រឡាយមានសុវត្ថិភាព;វាតាមដានចំនួននៃការខ្ចីប្រាក់ដោយប្រើប្រតិបត្តិការមិនមែនអាតូមិច។
///
/// នៅចុងបញ្ចប់នេះមានន័យថាអ្នកប្រហែលជាត្រូវភ្ជាប់ `Arc<T>` ជាមួយនឹងប្រភេទខ្លះនៃប្រភេទ [`std::sync`] ជាធម្មតា [`Mutex<T>`][mutex] ។
///
/// ## បំបែកវដ្តជាមួយ `Weak`
///
/// វិធីសាស្ត្រ [`downgrade`][downgrade] អាចត្រូវបានប្រើដើម្បីបង្កើតទ្រនិច [`Weak`] ដែលមិនមែនជាកម្មសិទ្ធិ។ទ្រនិច [`Weak`] អាចត្រូវបាន [`ធ្វើឱ្យប្រសើរ`][ធ្វើឱ្យប្រសើរឡើង] ឃទៅ `Arc` ប៉ុន្តែនេះនឹងត្រឡប់ [`None`] ប្រសិនបើតម្លៃដែលបានរក្សាទុកនៅក្នុងការបែងចែកត្រូវបានទម្លាក់រួចហើយ។
/// និយាយម៉្យាងទៀតអ្នកចង្អុល `Weak` មិនរក្សាតម្លៃនៅក្នុងការបែងចែកឱ្យនៅរស់ទេ។ទោះជាយ៉ាងណា, ពួកគេ *ធ្វើ* រក្សាការបែងចែក (ហាងគាំទ្រសម្រាប់តម្លៃ) នៅរស់។
///
/// វដ្តរវាងអ្នកចង្អុល `Arc` នឹងមិនត្រូវបានដោះស្រាយទេ។
/// សម្រាប់ហេតុផលនេះ [`Weak`] ត្រូវបានប្រើដើម្បីបំបែកវដ្ត។ឧទាហរណ៍ដើមឈើមួយអាចមានចង្អុលបង្ហាញ `Arc` ខ្លាំងពីថ្នាំងឪពុកម្តាយដល់កូនហើយចំណុច [`Weak`] ពីក្មេងត្រឡប់ទៅឪពុកម្តាយវិញ។
///
/// # ក្លូនយោង
///
/// ការបង្កើតសេចក្តីយោងថ្មីពីទ្រនិចដែលបានរាប់-យោងត្រូវបានអនុវត្តដោយប្រើ `Clone` trait ដែលបានអនុវត្តសម្រាប់ [`Arc<T>`][Arc] និង [`Weak<T>`][Weak] ។
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // វាក្យសម្ពន្ធទាំងពីរខាងក្រោមគឺស្មើគ្នា។
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, និង foo សុទ្ធតែជាធ្នូដែលចង្អុលទៅទីតាំងចងចាំដូចគ្នា
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` ការបដិសេធដោយស្វ័យប្រវត្តិចំពោះ `T` (តាមរយៈ [`Deref`][deref] trait) ដូច្នេះអ្នកអាចហៅវិធី `ធី` លើតម្លៃនៃប្រភេទ `Arc<T>` ។ដើម្បីជៀសវាងការប៉ះទង្គិចឈ្មោះជាមួយវិធី `ធី` វិធីសាស្រ្តនៃ `Arc<T>` ខ្លួនវាគឺជាមុខងារដែលត្រូវបានគេហៅថាការប្រើ [fully qualified syntax]៖
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `ធ្នូ<T>ការអនុវត្តរបស់`traits ដូចជា `Clone` ក៏អាចត្រូវបានហៅដោយប្រើវាក្យសម្ពន្ធដែលមានសមត្ថភាពពេញលេញផងដែរ។
/// មនុស្សខ្លះចូលចិត្តប្រើវាក្យសម្ពន្ធដែលមានលក្ខណៈសម្បត្តិគ្រប់គ្រាន់ខណៈពេលដែលអ្នកផ្សេងទៀតចូលចិត្តប្រើវាក្យសម្ព័ន្ធវិធីហៅ។
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // សំយោគវិធីសាស្រ្តហៅ
/// let arc2 = arc.clone();
/// // វាក្យសម្ព័ន្ធដែលមានសមត្ថភាពពេញលេញ
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] មិនបដិសេធដោយស្វ័យប្រវត្តិចំពោះ `T` ទេពីព្រោះតម្លៃខាងក្នុងអាចត្រូវបានទម្លាក់រួចហើយ។
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// ចែករំលែកទិន្នន័យដែលមិនអាចផ្លាស់ប្តូរបានរវាងខ្សែស្រឡាយ៖
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// ចំណាំថាយើង **មិន** ដំណើរការតេស្តទាំងនេះនៅទីនេះ។
// អ្នកសាងសង់ windows ទទួលបានការមិនសប្បាយចិត្តទំនើបប្រសិនបើខ្សែស្រឡាយមួយមានខ្សែស្រឡាយសំខាន់ហើយបន្ទាប់មកចាកចេញក្នុងពេលតែមួយ (អ្វីមួយដែលជាប់គាំង) ដូច្នេះយើងគ្រាន់តែជៀសវាងបញ្ហានេះទាំងស្រុងដោយមិនដំណើរការការធ្វើតេស្តទាំងនេះ។
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// ចែករំលែក [`AtomicUsize`] ដែលអាចផ្លាស់ប្តូរបាន៖
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// សូមមើល [`rc` documentation][rc_examples] សម្រាប់ឧទាហរណ៍បន្ថែមនៃការរាប់យោងជាទូទៅ។
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` គឺជាជំនាន់មួយនៃ [`Arc`] ដែលមានឯកសារយោងដែលមិនមែនជាកម្មសិទ្ធិរបស់ការបែងចែកដែលបានគ្រប់គ្រង។
/// ការបែងចែកត្រូវបានចូលប្រើតាមរយៈការហៅទូរស័ព្ទ [`upgrade`] នៅលើទ្រនិច `Weak` ដែលត្រឡប់មកវិញ [`ជម្រើស`] `<` [`ធ្នូ»]`<T>> `។
///
/// ចាប់តាំងពីឯកសារយោង `Weak` មិនរាប់ឆ្ពោះទៅរកភាពជាម្ចាស់, វានឹងមិនបងា្ករតម្លៃដែលរក្សាទុកនៅក្នុងការបែងចែកពីត្រូវបានធ្លាក់ចុះនិង `Weak` ខ្លួនវាធ្វើឱ្យការធានាទេអំពីតម្លៃនេះនៅតែមានវត្តមាន។
///
/// ដូច្នេះវាអាចត្រឡប់ [`None`] នៅពេល [`ធ្វើឱ្យប្រសើរឡើង] ឃ។
/// ទោះជាយ៉ាងណាចំណាំថា `Weak` យោង *ធ្វើ* រារាំងការបែងចែកដោយខ្លួនវា (ហាងគាំទ្រ) ពីការត្រូវបានដោះស្រាយ។
///
/// ព្រួញមួយ `Weak` មានប្រយោជន៍សម្រាប់ការរក្សាសេចក្ដីយោងទៅនឹងការបែងចែកនេះជាបណ្តោះអាសន្នដោយ [`Arc`] ដោយគ្មានការគ្រប់គ្រងការការពារតម្លៃខាងក្នុងរបស់ខ្លួនពីត្រូវបានធ្លាក់ចុះ។
/// វាក៏ត្រូវបានប្រើដើម្បីការពារការយោងជារង្វង់រវាងចំនុចចង្អុល [`Arc`] ព្រោះថាឯកសារយោងដែលជាកម្មសិទ្ធិទៅវិញទៅមកនឹងមិនអនុញ្ញាតឱ្យទម្លាក់ [`Arc`] ឡើយ។
/// ឧទាហរណ៍ដើមឈើមួយអាចមានចំណុចចង្អុល [`Arc`] ខ្លាំងពីថ្នាំងឪពុកម្តាយទៅកូនហើយចំណុច `Weak` ពីកូន ៗ ត្រឡប់ទៅឪពុកម្តាយវិញ។
///
/// វិធីធម្មតាដើម្បីទទួលបានទ្រនិច `Weak` គឺត្រូវហៅទូរស័ព្ទ [`Arc::downgrade`] ។
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // នេះគឺជា `NonNull` ដើម្បីអនុញ្ញាតឱ្យបង្កើនទំហំនៃប្រភេទនេះនៅក្នុងអ៊ីនធឺរណែតប៉ុន្តែវាមិនចាំបាច់ជាទ្រនិចត្រឹមត្រូវទេ។
    //
    // `Weak::new` កំណត់វាទៅ `usize::MAX` ដូច្នេះវាមិនចាំបាច់បែងចែកទំហំនៅលើគំនរទេ។
    // នោះមិនមែនជាតម្លៃដែលព្រួញកណ្តុរពិតប្រាកដនឹងមាននោះទេព្រោះ RcBox មានការតម្រឹមយ៉ាងតិច ២ ។
    // នេះគឺអាចធ្វើទៅបាននៅពេល `T: Sized`;`T` មិនបានកំណត់
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// នេះគឺជា repr(C) ទៅ future-ភស្តុតាងប្រឆាំងនឹងការតំរែតំរង់វាលដែលអាចរំខានដល់ [into|from]_raw() ប្រភេទខាងក្នុងដែលអាចដឹកជញ្ជូនបាន។
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // តម្លៃ usize::MAX ដើរតួជាអ្នកផ្ញើសារសម្រាប់ "locking" ជាបណ្តោះអាសន្ននូវសមត្ថភាពក្នុងការធ្វើឱ្យប្រសើរឡើងនូវចំនុចខ្សោយឬបន្ទាបចំនុចខ្លាំង។វាត្រូវបានប្រើដើម្បីជៀសវាងការប្រណាំងក្នុង `make_mut` និង `get_mut` ។
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// សាងសង់ `Arc<T>` ថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // ចាប់ផ្តើមរាប់ទ្រនិចខ្សោយគឺ ១ ដែលជាទ្រនិចខ្សោយដែលត្រូវបានកាន់កាប់ដោយចំនុចខ្លាំង (kinda) សូមមើល std/rc.rs សម្រាប់ព័ត៌មានបន្ថែម
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// សាងសង់ `Arc<T>` ថ្មីដោយប្រើឯកសារយោងខ្សោយទៅខ្លួនវា។
    /// ការប៉ុនប៉ងធ្វើឱ្យប្រសើរឡើងនូវឯកសារយោងខ្សោយមុនពេលមុខងារនេះត្រឡប់មកវិញនឹងនាំឱ្យមានតំលៃ `None` ។
    /// ទោះយ៉ាងណាក៏ដោយឯកសារយោងខ្សោយអាចត្រូវបានក្លូនដោយសេរីនិងរក្សាទុកសម្រាប់ប្រើនៅពេលក្រោយ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // សាងសង់ផ្នែកខាងក្នុងនៅក្នុងរដ្ឋ "uninitialized" ជាមួយនឹងឯកសារយោងខ្សោយមួយ។
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // វាសំខាន់ណាស់ដែលយើងមិនបោះបង់ចោលភាពជាម្ចាស់នៃទ្រនិចខ្សោយបើមិនដូច្នេះទេអង្គចងចាំអាចត្រូវបានដោះលែងនៅពេលដែល `data_fn` ត្រឡប់មកវិញ។
        // ប្រសិនបើយើងពិតជាចង់ប្រគល់ភាពជាម្ចាស់កម្មសិទ្ធិយើងអាចបង្កើតទ្រនិចទន់ខ្សោយបន្ថែមសម្រាប់ខ្លួនយើងប៉ុន្តែនេះនឹងបណ្តាលឱ្យមានការធ្វើបច្ចុប្បន្នភាពបន្ថែមទៀតចំពោះចំនួនឯកសារយោងខ្សោយដែលមិនចាំបាច់បើមិនដូច្នេះទេ។
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ឥឡូវនេះយើងអាចចាប់ផ្តើមតម្លៃខាងក្នុងឱ្យបានត្រឹមត្រូវហើយបង្វែរឯកសារយោងខ្សោយទៅជាឯកសារយោងរឹងមាំ។
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ការសរសេរខាងលើទៅក្នុងវាលទិន្នន័យត្រូវតែមើលឃើញដោយខ្សែស្រឡាយណាមួយដែលសង្កេតឃើញការរាប់ដ៏រឹងមាំដែលមិនមែនសូន្យ។
            // ដូច្នេះយើងត្រូវការយ៉ាងហោចណាស់លំដាប់ "Release" ដើម្បីធ្វើសមកាលកម្មជាមួយ `compare_exchange_weak` ក្នុង `Weak::upgrade` ។
            //
            // "Acquire" ការបញ្ជាទិញមិនត្រូវបានទាមទារទេ។
            // នៅពេលពិចារណាពីអាកប្បកិរិយាដែលអាចកើតមាននៃ `data_fn` យើងគ្រាន់តែពិនិត្យមើលអ្វីដែលវាអាចធ្វើបានដោយយោងទៅលើ `Weak` ដែលមិនអាចកែលម្អបាន:
            //
            // - វាអាច *ក្លូន*`Weak`, បង្កើនចំនួនឯកសារយោងខ្សោយ។
            // - វាអាចទម្លាក់ក្លូនទាំងនោះបន្ថយចំនួនឯកសារយោងខ្សោយ (ប៉ុន្តែមិនដល់សូន្យទេ) ។
            //
            // ផលប៉ះពាល់ទាំងនេះមិនជះឥទ្ធិពលដល់យើងតាមមធ្យោបាយណាមួយឡើយហើយគ្មានផលប៉ះពាល់អ្វីផ្សេងទៀតដែលអាចកើតមានជាមួយកូដសុវត្ថិភាពតែម្នាក់ឯងនោះទេ។
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // សេចក្តីយោងខ្លាំងគួររួមជាម្ចាស់ជាឯកសារយោងខ្សោយចែករំលែកដូច្នេះមិនរត់សម្រាប់ជាឯកសារយោងទន់ខ្សោយបំផ្លាញអាយុរបស់យើង។
        //
        mem::forget(weak);
        strong
    }

    /// សង់ជាថ្មីជាមួយនឹងមាតិកា `Arc` uninitiated ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// សាងសង់ `Arc` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// សាងសង់ `Pin<Arc<T>>` ថ្មី។
    /// ប្រសិនបើ `T` មិនអនុវត្ត `Unpin` នោះ `data` នឹងត្រូវបានបញ្ចូលក្នុងសតិហើយមិនអាចផ្លាស់ទីបាន។
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// សាងសង់ `Arc<T>` ថ្មី, ត្រឡប់កំហុសប្រសិនបើការបែងចែកបរាជ័យ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // ចាប់ផ្តើមរាប់ទ្រនិចខ្សោយគឺ ១ ដែលជាទ្រនិចខ្សោយដែលត្រូវបានកាន់កាប់ដោយចំនុចខ្លាំង (kinda) សូមមើល std/rc.rs សម្រាប់ព័ត៌មានបន្ថែម
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// សាងសង់ `Arc` ថ្មីជាមួយនឹងមាតិកាដែលមិនត្រូវបានគេយកមកធ្វើឱ្យមានកំហុសប្រសិនបើការបែងចែកបរាជ័យ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// សាងសង់ `Arc` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានឯកសិទ្ធិដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃត្រឡប់កំហុសប្រសិនបើការបែងចែកបរាជ័យ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// ត្រឡប់តម្លៃខាងក្នុង, បើ `Arc` មានសេចក្ដីយោងខ្លាំងពិតប្រាកដមួយ។
    ///
    /// បើមិនដូច្នោះទេ [`Err`] មួយត្រូវបានត្រឡប់មកវិញជាមួយ `Arc` ដូចគ្នាដែលត្រូវបានបញ្ជូនចូល។
    ///
    ///
    /// នេះនឹងទទួលបានជោគជ័យទោះបីជាមានឯកសារយោងខ្សោយឆ្នើមក៏ដោយ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // ធ្វើទ្រនិចខ្សោយដើម្បីសម្អាតសេចក្តីយោងដែលខ្សោយ-ខ្លាំង
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// បង្កើតចំណិតយោងយោងតាមអាតូមថ្មីជាមួយមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// សាងសង់ចំណិតយោងតាមអាតូមថ្មីជាមួយមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// បំលែងទៅជា `Arc<T>` ។
    ///
    /// # Safety
    ///
    /// ដូចគ្នានឹង [`MaybeUninit::assume_init`] ដែរវាអាស្រ័យលើអ្នកទូរស័ព្ទចូលដើម្បីធានាថាតម្លៃខាងក្នុងពិតជាស្ថិតនៅក្នុងស្ថានភាពដំបូង។
    ///
    /// ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗ។
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// បំលែងទៅជា `Arc<[T]>` ។
    ///
    /// # Safety
    ///
    /// ដូចគ្នានឹង [`MaybeUninit::assume_init`] ដែរវាអាស្រ័យលើអ្នកទូរស័ព្ទចូលដើម្បីធានាថាតម្លៃខាងក្នុងពិតជាស្ថិតនៅក្នុងស្ថានភាពដំបូង។
    ///
    /// ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗ។
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ប្រើប្រាស់ `Arc` ត្រឡប់ទ្រនិចរុំ។
    ///
    /// ដើម្បីជៀសវាងការលេចធ្លាយការចងចាំស្សន៍ទ្រនិចត្រូវតែត្រឡប់មកវិញបានបម្លែងទៅជាការប្រើ [`Arc::from_raw`] `Arc` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ផ្តល់ទ្រនិចចង្អុលទៅទិន្នន័យ។
    ///
    /// ការរាប់មិនត្រូវបានប៉ះពាល់ក្នុងវិធីណាមួយទេហើយ `Arc` មិនត្រូវបានប្រើប្រាស់ទេ។
    /// ទ្រនិចមានសុពលភាពដរាបណាមានចំនួនច្រើននៅក្នុង `Arc` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // សុវត្ថិភាព: នេះមិនអាចឆ្លងកាត់ Deref::deref ឬ RcBoxPtr::inner ទេពីព្រោះ
        // នេះត្រូវបានទាមទារដើម្បីរក្សាភស្តុតាង raw/mut ដូចជាឧ
        // `get_mut` អាចសរសេរតាមរយៈទ្រនិចបន្ទាប់ពីកាក់ត្រូវបានរកឃើញឡើងវិញតាមរយៈអេចស៊ីអ៊ិច។
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// សាងសង់ `Arc<T>` ពីទ្រនិចឆៅ។
    ///
    /// ទ្រនិចឆៅត្រូវបានត្រឡប់មកវិញដោយការហៅទៅ [`Arc<U>::into_raw`][into_raw] ដែល `U` ត្រូវតែមានទំហំនិងតម្រឹមដូចគ្នានឹង `T` ។
    /// នេះជាការពិតបន្តិចបន្តួចបើ `U` គឺ `T` ។
    /// ចំណាំថាប្រសិនបើ `U` មិនមែនជា `T` ទេប៉ុន្តែមានទំហំនិងការតម្រឹមដូចគ្នានេះគឺជាមូលដ្ឋានដូចជាការបញ្ជូនសេចក្តីយោងនៃប្រភេទផ្សេងៗគ្នា។
    /// សូមមើល [`mem::transmute`][transmute] សម្រាប់ព័ត៌មានបន្ថែមអំពីការរឹតបន្តឹងអ្វីដែលត្រូវអនុវត្តក្នុងករណីនេះ។
    ///
    /// អ្នកប្រើ `from_raw` ត្រូវតែធានាថាតម្លៃជាក់លាក់នៃ `T` នឹងត្រូវធ្លាក់ចុះម្តង។
    ///
    /// មុខងារនេះមិនមានសុវត្ថិភាពទេពីព្រោះការប្រើប្រាស់មិនត្រឹមត្រូវអាចបណ្តាលឱ្យការចងចាំមិនមានសុវត្ថិភាពទោះបីជា `Arc<T>` ដែលបានត្រឡប់មកវិញមិនដែលចូលក៏ដោយ។
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // បំលែងទៅជា `Arc` វិញដើម្បីការពារការលេចធ្លាយ។
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ការហៅទូរស័ព្ទទៅ `Arc::from_raw(x_ptr)` បន្ថែមទៀតអាចជាការចងចាំមិនមានសុវត្ថិភាព។
    /// }
    ///
    /// // ការចងចាំត្រូវបានដោះលែងនៅពេលដែល `x` មិនមានវិសាលភាពខាងលើដូច្នេះឥឡូវនេះ `x_ptr` កំពុងតែគាំង!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // បញ្ច្រាសអុហ្វសិតដើម្បីរក ArcInner ដើម។
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// បង្កើតទ្រនិច [`Weak`] ថ្មីមួយសម្រាប់ការបែងចែកនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // ការសំរាកលំហែនេះគឺមិនអីទេពីព្រោះយើងកំពុងពិនិត្យមើលតម្លៃនៅក្នុង CAS ខាងក្រោម។
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ពិនិត្យមើលថាតើការប្រឆាំងខ្សោយបច្ចុប្បន្ន "locked";បើដូច្នោះវិលចុះ។
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: បច្ចុប្បន្នលេខកូដនេះមិនអើពើនឹងលទ្ធភាពនៃការហៀរចេញ
            // ចូលទៅក្នុង usize::MAX;ជាទូទៅទាំង Rc និង Arc ត្រូវការកែសំរួលដើម្បីដោះស្រាយជាមួយនឹងការហៀរហៀរ។
            //

            // មិនដូចនឹង Clone() ទេយើងត្រូវការនេះជាការទទួលបានអានដើម្បីធ្វើសមកាលកម្មជាមួយនឹងការសរសេរចេញពី `is_unique` ដូច្នេះព្រឹត្តិការណ៍មុនការសរសេរកើតឡើងមុនពេលការអាននេះ។
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ត្រូវប្រាកដថាយើងមិនបង្កើតដង្កូវខ្សោយ
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// ទទួលបានចំនួនសូចនាករ [`Weak`] ចំពោះការបែងចែកនេះ។
    ///
    /// # Safety
    ///
    /// វិធីសាស្រ្តនេះដោយខ្លួនឯងគឺមានសុវត្ថិភាពប៉ុន្តែការប្រើប្រាស់វាឱ្យបានត្រឹមត្រូវត្រូវការការថែទាំបន្ថែម។
    /// ខ្សែស្រឡាយមួយទៀតអាចផ្លាស់ប្តូរការរាប់ខ្សោយនៅពេលណាមួយរួមទាំងសក្តានុពលរវាងការហៅវិធីសាស្ត្រនេះនិងការធ្វើសកម្មភាព។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // ការអះអាងនេះគឺជាកត្តាកំណត់ពីព្រោះយើងមិនបានចែករំលែក `Arc` ឬ `Weak` រវាងខ្សែស្រឡាយទេ។
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // ប្រសិនបើការរាប់ខ្សោយត្រូវបានចាក់សោបច្ចុប្បន្ននេះចំនួននៃការរាប់គឺមុនពេលយកសោ។
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// ទទួលបានចំនួនសូចនាករ (`Arc`) ខ្លាំងចំពោះការបែងចែកនេះ។
    ///
    /// # Safety
    ///
    /// វិធីសាស្រ្តនេះដោយខ្លួនឯងគឺមានសុវត្ថិភាពប៉ុន្តែការប្រើប្រាស់វាឱ្យបានត្រឹមត្រូវត្រូវការការថែទាំបន្ថែម។
    /// ខ្សែស្រឡាយមួយទៀតអាចផ្លាស់ប្តូរការរាប់ដ៏រឹងមាំនៅពេលណាមួយរួមទាំងសក្តានុពលរវាងការហៅវិធីសាស្ត្រនេះនិងការធ្វើសកម្មភាព។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // ការអះអាងនេះគឺជាកត្តាកំណត់ពីព្រោះយើងមិនបានចែករំលែក `Arc` រវាងខ្សែស្រឡាយទេ។
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// បង្កើនចំនួនឯកសារយោងខ្លាំងលើ `Arc<T>` ដែលជាប់ទាក់ទងនឹងទ្រនិចដែលបានផ្តល់ដោយមួយ។
    ///
    /// # Safety
    ///
    /// ទ្រនិចត្រូវតែបានទទួលតាមរយៈ `Arc::into_raw` ហើយវត្ថុ `Arc` ដែលជាប់ទាក់ទងត្រូវតែមានសុពលភាព (ឧ
    /// ការរាប់ខ្លាំងត្រូវមានយ៉ាងហោចណាស់ ១) សម្រាប់រយៈពេលនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ការអះអាងនេះគឺជាកត្តាកំណត់ពីព្រោះយើងមិនបានចែករំលែក `Arc` រវាងខ្សែស្រឡាយទេ។
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // រក្សាធ្នូប៉ុន្តែកុំប៉ះទឹកដកដោយរុំក្នុងម៉ានីនដារី
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ឥឡូវបង្កើនចំនួនទឹកប្រាក់ប៉ុន្តែកុំទម្លាក់ចំនួនទឹកប្រាក់ថ្មី
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// បន្ថយចំនួនយោងយោងខ្លាំងលើ `Arc<T>` ដែលទាក់ទងនឹងទ្រនិចដែលបានផ្តល់ដោយមួយ។
    ///
    /// # Safety
    ///
    /// ទ្រនិចត្រូវតែបានទទួលតាមរយៈ `Arc::into_raw` ហើយវត្ថុ `Arc` ដែលជាប់ទាក់ទងត្រូវតែមានសុពលភាព (ឧ
    /// ចំនួនដ៏ច្រើនត្រូវតែមានយ៉ាងហោចណាស់ ១) នៅពេលដែលប្រើវិធីសាស្ត្រនេះ។
    /// វិធីសាស្រ្តនេះអាចត្រូវបានប្រើដើម្បីបញ្ចេញការផ្ទុកចុងក្រោយ `Arc` និងការផ្ទុកខាងក្រោយប៉ុន្តែ ** មិនគួរត្រូវបានគេហៅថាបន្ទាប់ពី `Arc` ចុងក្រោយត្រូវបានចេញផ្សាយ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ការអះអាងទាំងនោះគឺជាកត្តាកំណត់ពីព្រោះយើងមិនបានចែករំលែក `Arc` រវាងខ្សែស្រឡាយទេ។
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // សុវត្ថិភាពនេះមិនអីទេពីព្រោះខណៈពេលធ្នូនេះនៅរស់យើងធានាថាទ្រនិចខាងក្នុងមានសុពលភាព។
        // លើសពីនេះទៅទៀតយើងដឹងថារចនាសម្ព័ន្ធ `ArcInner` ខ្លួនវាគឺ `Sync` ពីព្រោះទិន្នន័យខាងក្នុងគឺ `Sync` ផងដែរដូច្នេះយើងយល់ព្រមខ្ចីទ្រនិចដែលមិនអាចផ្លាស់ប្តូរបានចំពោះមាតិកាទាំងនេះ។
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // ផ្នែកដែលមិនត្រូវបានតំរង់ជួរនៃ `drop` ។
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // បំផ្លាញទិន្នន័យនៅពេលនេះទោះបីជាយើងមិនដោះលែងការបែងចែកប្រអប់ដោយខ្លួនវា (វានៅតែមានអ្នកចង្អុលខ្សោយដែលនៅក្បែរ) ។
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // ទម្លាក់វត្ថុខ្សោយដែលត្រូវបានប្រមូលរួមគ្នាដោយឯកសារយោងរឹងមាំទាំងអស់
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ត្រឡប់ `true` ប្រសិនបើ `អ័ក្សពីរចង្អុលទៅការបែងចែកដូចគ្នា (ជាសរសៃស្រដៀងទៅនឹង [`ptr::eq`]) ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// បែងចែក `ArcInner<T>` ជាមួយនឹងទំហំគ្រប់គ្រាន់សម្រាប់តម្លៃខាងក្នុងដែលអាចកំណត់បានដែលតម្លៃមានប្លង់ដែលបានផ្តល់។
    ///
    /// មុខងារ `mem_to_arcinner` នេះត្រូវបានហៅជាមួយព្រួញទិន្នន័យនិងត្រូវតែត្រឡប់មកវិញជាមួយ-pointer (ជាតិខ្លាញ់មានសក្តានុពល) សម្រាប់ `ArcInner<T>` នេះ។
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // គណនាប្លង់ដោយប្រើប្លង់តម្លៃដែលបានផ្តល់។
        // កាលពីមុនប្លង់ត្រូវបានគណនាលើកន្សោម `&*(ptr as* const ArcInner<T>)` ប៉ុន្តែនេះបានបង្កើតឯកសារយោងខុស (សូមមើល #54908) ។
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// ការបែងចែក `ArcInner<T>` មួយជាមួយនឹងទំហំគ្រប់គ្រាន់សម្រាប់តម្លៃខាងក្នុងដែលជាកន្លែងដែលអាចធ្វើទៅបាន-unsized មានប្លង់តម្លៃដែលបានផ្ដល់ត្រឡប់កំហុសមួយប្រសិនបើមានការបែងចែកបរាជ័យ។
    ///
    ///
    /// មុខងារ `mem_to_arcinner` នេះត្រូវបានហៅជាមួយព្រួញទិន្នន័យនិងត្រូវតែត្រឡប់មកវិញជាមួយ-pointer (ជាតិខ្លាញ់មានសក្តានុពល) សម្រាប់ `ArcInner<T>` នេះ។
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // គណនាប្លង់ដោយប្រើប្លង់តម្លៃដែលបានផ្តល់។
        // កាលពីមុនប្លង់ត្រូវបានគណនាលើកន្សោម `&*(ptr as* const ArcInner<T>)` ប៉ុន្តែនេះបានបង្កើតឯកសារយោងខុស (សូមមើល #54908) ។
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ចាប់ផ្តើម ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// បែងចែក `ArcInner<T>` ជាមួយនឹងទំហំគ្រប់គ្រាន់សម្រាប់តម្លៃខាងក្នុងដែលមិនបានបញ្ជាក់។
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // បែងចែកសម្រាប់ `ArcInner<T>` ដោយប្រើតម្លៃដែលបានផ្តល់។
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // ចម្លងតម្លៃជាបៃ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // ការបែងចែកដោយឥតគិតថ្លៃដោយមិនទម្លាក់មាតិការបស់វា
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// បែងចែក `ArcInner<[T]>` ជាមួយនឹងប្រវែងដែលបានផ្តល់។
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// ចម្លងធាតុពីចំណិតទៅក្នុងធ្នូដែលបានបម្រុងទុកថ្មី
    ///
    /// មិនមានសុវត្ថិភាពទេព្រោះអ្នកហៅទូរស័ព្ទត្រូវតែទទួលយកភាពជាម្ចាស់ឬភ្ជាប់ `T: Copy` ។
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// សាងសង់ `Arc<[T]>` ពីឧបករណ៍វាស់ស្ទង់ដែលត្រូវបានគេដឹងថាមានទំហំជាក់លាក់។
    ///
    /// ឥរិយាបថនេះត្រូវបានកំណត់គួរមានទំហំខុស។
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic យាមពេលក្លូនធាតុ T ។
        // ក្នុងករណី panic ធាតុដែលត្រូវបានសរសេរទៅក្នុង ArcInner ថ្មីនឹងត្រូវបានទម្លាក់បន្ទាប់មកការចងចាំត្រូវបានដោះលែង។
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ទ្រនិចទៅធាតុទីមួយ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ច្បាស់លាស់ទាំងអស់។ភ្លេចឆ្មាំដូច្នេះវាមិនដោះលែង ArcInner ថ្មីទេ។
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ឯកទេស trait ប្រើសំរាប់ `From<&[T]>` ។
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// បង្កើតក្លូននៃទ្រនិច `Arc` ។
    ///
    /// នេះបង្កើតទ្រនិចមួយផ្សេងទៀតទៅនឹងការបែងចែកដូចគ្នាបង្កើនចំនួនឯកសារយោងខ្លាំង។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // ការប្រើប្រាស់លំដាប់លំដោយធូរស្បើយគឺល្អនៅទីនេះព្រោះចំណេះដឹងនៃឯកសារយោងដើមការពារខ្សែស្រឡាយផ្សេងទៀតពីការលុបវត្ថុដោយមិនត្រឹមត្រូវ។
        //
        // ដូចដែលបានពន្យល់នៅក្នុង [Boost documentation][1] ការបង្កើនការយោងអាចត្រូវបានធ្វើជាមួយមេម៉ូរី-ចងចាំជានិច្ច៖ សេចក្តីយោងថ្មីចំពោះវត្ថុអាចត្រូវបានបង្កើតឡើងពីឯកសារយោងដែលមានស្រាប់ហើយការបញ្ជូនសេចក្តីយោងដែលមានស្រាប់ពីខ្សែស្រឡាយមួយទៅខ្សែមួយទៀតត្រូវតែផ្តល់នូវការធ្វើសមកាលកម្មរួចហើយ។
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // ទោះយ៉ាងណាយើងចាំបាច់ត្រូវការពារប្រឆាំងនឹងការដកប្រាក់ដ៏ច្រើនក្នុងករណីមាននរណាម្នាក់ mem ភ្លេច: : ភ្លេចធ្នូ។
        // ប្រសិនបើយើងមិនធ្វើវាទេចំនួនអាចលើសហើយអ្នកប្រើប្រាស់នឹងប្រើដោយឥតគិតថ្លៃ។
        // យើងតិត្ថិភាពយ៉ាងរហ័សទៅនឹង `isize::MAX` លើការសន្មតថាមិនមានខ្សែស្រឡាយ ~2 ពាន់លានបង្កើនចំនួនយោងក្នុងពេលតែមួយទេ។
        //
        // branch នេះនឹងមិនត្រូវបានគេយកទៅក្នុងកម្មវិធីជាក់ស្តែងណាមួយឡើយ។
        //
        // យើងបោះបង់ចោលពីព្រោះកម្មវិធីបែបនេះខូចទ្រង់ទ្រាយមិនគួរឱ្យជឿហើយយើងមិនយកចិត្តទុកដាក់គាំទ្រវាទេ។
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ធ្វើឱ្យសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅជា `Arc` ដែលបានផ្តល់ឱ្យ។
    ///
    /// ប្រសិនបើមានចំណុច `Arc` ឬ [`Weak`] ផ្សេងទៀតចំពោះការបែងចែកដូចគ្នានោះ `make_mut` នឹងបង្កើតការបែងចែកថ្មីហើយនឹងហៅ [`clone`][clone] លើតម្លៃខាងក្នុងដើម្បីធានានូវភាពជាម្ចាស់តែមួយគត់។
    /// នេះក៏ត្រូវបានគេហៅថាក្លូន-សរសេរផងដែរ។
    ///
    /// ចំណាំថាវាខុសគ្នាពីឥរិយាបថរបស់ [`Rc::make_mut`] ដែលផ្តាច់ចំណុចចង្អុល `Weak` ដែលនៅសល់។
    ///
    /// សូមមើលផងដែរ [`get_mut`][get_mut] ដែលនឹងបរាជ័យជាជាងការក្លូន។
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // នឹងមិនក្លូនអ្វីទាំងអស់
    /// let mut other_data = Arc::clone(&data); // នឹងមិនក្លូនទិន្នន័យខាងក្នុងទេ
    /// *Arc::make_mut(&mut data) += 1;         // ក្លូនទិន្នន័យខាងក្នុង
    /// *Arc::make_mut(&mut data) += 1;         // នឹងមិនក្លូនអ្វីទាំងអស់
    /// *Arc::make_mut(&mut other_data) *= 2;   // នឹងមិនក្លូនអ្វីទាំងអស់
    ///
    /// // ឥឡូវ `data` និង `other_data` ចង្អុលទៅការបែងចែកផ្សេងៗគ្នា។
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // ចំណាំថាយើងកាន់ទាំងឯកសារយោងខ្លាំងនិងឯកសារយោងខ្សោយ។
        // ដូច្នេះការបញ្ចេញឯកសារយោងយ៉ាងខ្លាំងរបស់យើងតែនឹងមិនត្រូវបានដោយខ្លួនវាផ្ទាល់, បណ្តាលឱ្យការចងចាំដែលត្រូវបាន deallocated ។
        //
        // ប្រើ Acquire ដើម្បីធានាថាយើងបានឃើញការសរសេរណាមួយទៅកាន់ `weak` ដែលកើតឡើងមុនពេលការចេញផ្សាយសរសេរ (មានន័យថាការថយចុះ) ដល់ `strong` ។
        // ដោយសារយើងកាន់ចំនួនខ្សោយវាមិនមាន the កាសដែល ArcInner អាចត្រូវបានដោះស្រាយនោះទេ។
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // ទ្រនិចរឹងមាំមួយទៀតមានដូច្នេះយើងត្រូវតែក្លូន។
            // បែងចែកការចងចាំជាមុនដើម្បីអនុញ្ញាតឱ្យសរសេរតម្លៃក្លូនដោយផ្ទាល់។
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // ការសំរាកលំហែរអារម្មណ៍នៅខាងលើព្រោះនេះជាមូលដ្ឋានគ្រឹះនៃការបង្កើនប្រសិទ្ធិភាព៖ យើងតែងតែប្រណាំងជាមួយអ្នកចង្អុលខ្សោយ។
            // ករណីអាក្រក់បំផុតយើងបញ្ចប់ការបម្រុងទុកធ្នូថ្មីដោយមិនចាំបាច់។
            //

            // យើងបានដកកន្លែងចំណាំងផ្លាតចុងក្រោយចេញហើយប៉ុន្តែនៅមានកន្លែងផ្ទុកខ្សោយបន្ថែមទៀតនៅសល់។
            // យើងនឹងផ្លាស់ប្តូរខ្លឹមសារទៅធ្នូថ្មីមួយហើយធ្វើឱ្យឯកសារយោងខ្សោយផ្សេងទៀតមានសុពលភាព។
            //

            // ចំណាំថាវាមិនអាចទៅរួចទេសម្រាប់ការអាន `weak` ដើម្បីផ្តល់លទ្ធផល usize::MAX (មានន័យថាចាក់សោ) ចាប់តាំងពីចំនួនខ្សោយអាចត្រូវបានចាក់សោដោយខ្សែស្រឡាយដែលមានសេចក្តីយោងរឹងមាំ។
            //
            //

            // កំណត់ទ្រនិចខ្សោយជាក់ស្តែងរបស់យើងដូច្នេះវាអាចសម្អាត ArcInner តាមតម្រូវការ។
            //
            let _weak = Weak { ptr: this.ptr };

            // គ្រាន់តែអាចលួចទិន្ន័យអ្វីដែលនៅសេសសល់គឺ Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // យើងជាឯកសារយោងតែមួយគត់នៃប្រភេទណាមួយ។bump back up the ref ref count ។
            //
            this.inner().strong.store(1, Release);
        }

        // ដូចគ្នានឹង `get_mut()` ដែរសុវត្ថភាពគឺមិនអីទេពីព្រោះឯកសារយោងរបស់យើងគឺមានលក្ខណៈប្លែកដើម្បីចាប់ផ្តើមជាមួយរឺក្លាយជាអ្នកបង្កើតមាតិកា។
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅក្នុង `Arc` ដែលបានផ្តល់ប្រសិនបើមិនមានចង្អុល `Arc` ឬ [`Weak`] ផ្សេងទៀតទៅនឹងការបែងចែកដូចគ្នា។
    ///
    ///
    /// ត្រឡប់ [`None`] បើមិនដូច្នេះទេព្រោះវាមិនមានសុវត្ថិភាពក្នុងការផ្លាស់ប្តូរតម្លៃដែលបានចែករំលែក។
    ///
    /// សូមមើលផងដែរ [`make_mut`][make_mut] ដែលនឹង [`clone`][clone] តម្លៃខាងក្នុងនៅពេលមានចំណុចចង្អុលផ្សេងទៀត។
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // សុវត្ថិភាពនេះមិនអីទេពីព្រោះយើងធានាថាទ្រនិចត្រឡប់មកវិញគឺមានតែព្រួញ * ប៉ុណ្ណោះដែលនឹងត្រូវបានបញ្ជូនទៅធី។
            // ចំនួនយោងរបស់យើងត្រូវបានធានាថាមាន ១ នៅចំណុចនេះហើយយើងតម្រូវឱ្យធ្នូខ្លួនវាជា `mut` ដូច្នេះយើងត្រឡប់ឯកសារយោងដែលអាចធ្វើទៅបានចំពោះទិន្នន័យខាងក្នុង។
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ត្រឡប់សេចក្តីយោង mutable ចូលទៅក្នុង `Arc` ដែលបានផ្ដល់ឱ្យដោយគ្មានការត្រួតពិនិត្យណាមួយ។
    ///
    /// សូមមើល [`get_mut`] ផងដែរដែលមានសុវត្ថិភាពនិងត្រួតពិនិត្យត្រឹមត្រូវ។
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// រាល់ការព្រួញ `Arc` ឬ [`Weak`] ផ្សេងទៀតដើម្បីបែងចែកដូចគ្នានេះមិនត្រូវ dereferenced សម្រាប់រយៈពេលនៃការវិលត្រឡប់មកខ្ចីនេះ។
    ///
    /// នេះជាករណីតូចតាចប្រសិនបើគ្មានអ្នកចង្អុលបង្ហាញបែបនេះទេឧទាហរណ៍ភ្លាមៗបន្ទាប់ពី `Arc::new` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // យើងប្រយ័ត្នប្រយែងក្នុងការ *មិន* បង្កើតឯកសារយោងដែលគ្របដណ្ដប់លើវាលស្រែ "count" ព្រោះថានេះអាចជាឈ្មោះក្លែងក្លាយជាមួយនឹងការចូលដំណាលគ្នានៃចំនួនឯកសារយោង (ឧទាហរណ៍
        // ដោយ `Weak`) ។
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// កំណត់ថាតើនេះជាឯកសារយោងតែមួយគត់ (រួមបញ្ចូលទាំងឯកសារយោងខ្សោយ) ចំពោះទិន្នន័យមូលដ្ឋាន។
    ///
    ///
    /// ចំណាំថាវាតម្រូវឱ្យចាក់សោចំនួនយោងយោងខ្សោយ។
    fn is_unique(&mut self) -> bool {
        // ចាក់សោចំនួនទ្រនិចខ្សោយប្រសិនបើយើងបង្ហាញថាជាអ្នកកាន់ទ្រនិចទ្រនិចខ្សោយ។
        //
        // នៅទីនេះទទួលបានស្លាកសញ្ញាមួយដែលកើតឡើង-ធានាទំនាក់ទំនងជាមួយសរសេរមុនពេលណាមួយក្នុងការ `strong` (ជាពិសេសនៅក្នុង `Weak::upgrade`) មុនពេលនៃការបន្ថយការរាប់ `weak` (តាមរយៈ `Weak::drop` ដែលប្រើការចេញផ្សាយ) ។
        // ប្រសិនបើការថយចុះខ្សោយមិនត្រូវបានទម្លាក់ទេ CAS នៅទីនេះនឹងបរាជ័យដូច្នេះយើងមិនយកចិត្តទុកដាក់ធ្វើសមកាលកម្មទេ។
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // នេះត្រូវការជា `Acquire` ដើម្បីធ្វើសមកាលកម្មជាមួយនឹងការថយចុះនៃការប្រឆាំងនៃ `strong` នៅក្នុង `drop`-ការចូលប្រើតែមួយគត់ដែលកើតឡើងនៅពេលណាមួយប៉ុន្តែសេចក្តីយោងចុងក្រោយកំពុងត្រូវបានទម្លាក់។
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // ការសរសេរចេញផ្សាយនៅទីនេះធ្វើសមកាលកម្មជាមួយនឹងការអាននៅ `downgrade` ជាការការពារយ៉ាងមានប្រសិទ្ធិភាពខាងលើនៃ `strong` អានពីការកើតឡើងសរសេរបន្ទាប់។
            //
            //
            self.inner().weak.store(1, Release); // ដោះសោ
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// ទម្លាក់ `Arc` ។
    ///
    /// នេះនឹងកាត់បន្ថយចំនួនយោងយោងខ្លាំង។
    /// ប្រសិនបើចំនួនយោងខ្លាំងឈានដល់សូន្យនោះមានតែសេចក្តីយោងផ្សេងទៀត (ប្រសិនបើមាន) គឺ [`Weak`] ដូច្នេះយើង `drop` តម្លៃខាងក្នុង។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // មិនបោះពុម្ពអ្វីទាំងអស់
    /// drop(foo2);   // បោះពុម្ព "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // ដោយសារតែ `fetch_sub` មានអាតូមិចរួចហើយយើងមិនចាំបាច់ធ្វើសមកាលកម្មជាមួយខ្សែស្រឡាយផ្សេងទៀតទេដរាបណាយើងនឹងលុបវត្ថុនោះចោល។
        // តក្កវិជ្ជាដូចគ្នានេះអនុវត្តចំពោះ `fetch_sub` ខាងក្រោមចំពោះចំនួន `weak` ។
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // របងនេះត្រូវការជាចាំបាច់ដើម្បីការពារការតម្រង់ជួរនៃការប្រើប្រាស់ទិន្នន័យនិងការលុបទិន្នន័យ។
        // ដោយសារតែវាត្រូវបានសម្គាល់ `Release` ការថយចុះនៃចំនួនយោងយោងធ្វើសមកាលកម្មជាមួយនឹងរបង `Acquire` នេះ។
        // នេះមានន័យថាការប្រើប្រាស់នៃទិន្នន័យដែលកើតឡើងមុនពេលការកាត់បន្ថយការរាប់សេចក្តីយោងដែលបានកើតឡើងមុនពេលរបងនេះដែលកើតមានឡើងមុនពេលការលុបទិន្នន័យ។
        //
        // ដូចដែលបានពន្យល់នៅក្នុង [Boost documentation][1],
        //
        // > វាមានសារៈសំខាន់ណាស់ក្នុងការអនុវត្តការចូលទៅកាន់វត្ថុដែលអាចកើតមាន
        // > ខ្សែស្រឡាយ (តាមរយៈឯកសារយោងដែលមានស្រាប់) ដើម្បី *កើតឡើងមុនពេល* លុប
        // > វត្ថុនៅក្នុងខ្សែស្រឡាយផ្សេង។នេះត្រូវបានសម្រេចដោយ "release"
        // > ប្រតិបត្ដិការបន្ទាប់ពីទម្លាក់ឯកសារយោង (ចូលប្រើវត្ថុណាមួយ
        // > តាមរយៈឯកសារយោងនេះច្បាស់ជាបានកើតឡើងពីមុន) និងមួយ
        // > "acquire" ប្រតិបត្ដិការមុនពេលលុបវត្ថុ។
        //
        // ជាពិសេសខណៈពេលដែលមាតិកានៃធ្នូជាធម្មតាមិនអាចផ្លាស់ប្តូរបានវាអាចទៅរួចដែលមានផ្នែកខាងក្នុងសរសេរទៅអ្វីមួយដូចជា Mutex<T>។
        // ដោយសារ Mutex មិនត្រូវបានទទួលនៅពេលដែលវាត្រូវបានលុបយើងមិនអាចពឹងផ្អែកលើតក្កវិជ្ជាធ្វើសមកាលកម្មរបស់វាដើម្បីធ្វើឱ្យមានការសរសេរជាខ្សែស្រឡាយដែលអាចមើលឃើញចំពោះអ្នកបំផ្លាញដែលកំពុងរត់នៅក្នុងខ្សែខ។
        //
        //
        // សូមកត់សម្គាល់ផងដែរថារបង Acquire នៅទីនេះប្រហែលជាអាចត្រូវបានជំនួសដោយបន្ទុក Acquire ដែលអាចធ្វើឱ្យប្រសើរឡើងនូវការអនុវត្តនៅក្នុងស្ថានភាពដែលមានជម្លោះ។មើល [2] ។
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// ប៉ុនប៉ងទម្លាក់ `Arc<dyn Any + Send + Sync>` ទៅនឹងប្រភេទបេតុង។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// សាងសង់ `Weak<T>` ថ្មីដោយមិនចាំបាច់បែងចែកសតិណាមួយឡើយ។
    /// ការហៅទូរស័ព្ទ [`upgrade`] លើតម្លៃត្រឡប់មកវិញតែងតែផ្តល់ឱ្យ [`None`] ។
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ប្រភេទអ្នកជំនួយការដើម្បីអនុញ្ញាតឱ្យចូលប្រើចំនួនយោងដោយមិនមានការអះអាងណាមួយអំពីវាលទិន្នន័យ។
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// ត្រឡប់ទ្រនិចចង្អុលទៅវត្ថុ `T` ចង្អុលទៅ `Weak<T>` X នេះ។
    ///
    /// ទ្រនិចមានសុពលភាពលុះត្រាតែមានឯកសារយោងរឹងមាំខ្លះ។
    /// ទ្រនិចអាចត្រូវបានព្យួរមិនស្មើគ្នាឬសូម្បីតែ [`null`] បើមិនដូច្នេះទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // ទាំងពីរចង្អុលទៅវត្ថុតែមួយ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // អ្នកខ្លាំងនៅទីនេះរក្សាវាឱ្យនៅរស់ដូច្នេះយើងនៅតែអាចចូលមើលវត្ថុបាន។
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ប៉ុន្តែមិនមានទៀតទេ។
    /// // យើងអាចធ្វើបាន weak.as_ptr() ប៉ុន្តែការចូលទៅកាន់ទ្រនិចអាចនាំឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
    /// // assert_eq! ("សួស្តី", គ្មានសុវត្ថិភាព {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // ប្រសិនបើទ្រនិចកំពុងរដុបយើងបញ្ជូនអ្នកបញ្ជូនផ្ទាល់។
            // នេះមិនអាចជាអាស័យដ្ឋានបន្ទុកដែលមានសុពលភាពទេព្រោះបន្ទុកយ៉ាងតិចក៏ត្រូវគ្នាទៅនឹង ArcInner (usize) ដែរ។
            ptr as *const T
        } else {
            // សុវត្ថិភាព: ប្រសិនបើ is_dangling ត្រឡប់មិនពិត, បន្ទាប់មកទ្រនិចគឺមិនអាចប្រកែកបាន។
            // បន្ទុកអាចត្រូវបានទម្លាក់នៅចំណុចនេះហើយយើងត្រូវតែរក្សាភស្តុតាងដូច្នេះត្រូវប្រើឧបករណ៏ទ្រនិចឆៅ។
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// ប្រើប្រាស់ `Weak<T>` ហើយប្រែវាទៅជាទ្រនិចឆៅ។
    ///
    /// នេះបម្លែងទ្រនិចខ្សោយទៅជាទ្រនិចឆៅខណៈពេលដែលនៅតែរក្សាភាពជាម្ចាស់នៃឯកសារយោងខ្សោយមួយ (ការរាប់ខ្សោយមិនត្រូវបានកែប្រែដោយប្រតិបត្តិការនេះទេ) ។
    /// វាអាចប្រែទៅជា `Weak<T>` ជាមួយ [`from_raw`] ។
    ///
    /// ការរឹតបន្តឹងដូចគ្នានៃការចូលគោលដៅនៃទ្រនិចដូចគ្នានឹង [`as_ptr`] ត្រូវបានអនុវត្ត។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// បំលែងទ្រនិចឆៅដែលបានបង្កើតពីមុនដោយ [`into_raw`] ត្រលប់ទៅជា `Weak<T>` ។
    ///
    /// នេះអាចត្រូវបានប្រើដើម្បីទទួលបានឯកសារយោងរឹងមាំ (ដោយហៅទូរស័ព្ទទៅ [`upgrade`] នៅពេលក្រោយ) ឬដោះស្រាយចំនួនខ្សោយដោយទម្លាក់ `Weak<T>` ។
    ///
    /// វាត្រូវការភាពជាម្ចាស់នៃឯកសារយោងខ្សោយមួយ (លើកលែងតែចំណុចចង្អុលបង្ហាញដែលបង្កើតដោយ [`new`] ព្រោះវាមិនមែនជារបស់អ្វីទាំងអស់។ វិធីសាស្ត្រនៅតែមានលើពួកវា) ។
    ///
    /// # Safety
    ///
    /// ទ្រនិចត្រូវតែមានប្រភពចេញពី [`into_raw`] ហើយនៅតែត្រូវតែជាម្ចាស់ឯកសារយោងខ្សោយសក្តានុពលរបស់វា។
    ///
    /// វាត្រូវបានអនុញ្ញាតសម្រាប់ការរាប់យ៉ាងខ្លាំងគឺ 0 នៅពេលហៅវា។
    /// ទោះយ៉ាងណាក៏ដោយវាត្រូវការភាពជាម្ចាស់នៃឯកសារយោងខ្សោយមួយដែលបច្ចុប្បន្នត្រូវបានចង្អុលបង្ហាញជាទ្រនិចឆៅ (ចំនួនខ្សោយមិនត្រូវបានកែប្រែដោយប្រតិបត្តិការនេះទេ) ដូច្នេះវាត្រូវភ្ជាប់ជាមួយការហៅពីមុនទៅ [`into_raw`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // បន្ថយចំនួនខ្សោយចុងក្រោយ។
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // សូមមើល Weak::as_ptr សម្រាប់បរិបទអំពីរបៀបដែលទ្រនិចបញ្ចូលត្រូវបានចេញ។

        let ptr = if is_dangling(ptr as *mut T) {
            // នេះគឺជាដង្កូវខ្សោយ។
            ptr as *mut ArcInner<T>
        } else {
            // បើមិនដូច្នោះទេយើងត្រូវបានធានាថាទ្រនិចកើតចេញពីចំណុចខ្សោយដែលមិនចេះនិយាយ។
            // សុវត្ថិភាព: data_offset មានសុវត្ថិភាពក្នុងការហៅព្រោះឯកសារយោង ptr ជាការធ្លាក់ចុះពិតប្រាកដ (T សក្តានុពល) ។
            let offset = unsafe { data_offset(ptr) };
            // ដូច្នេះយើងបញ្ច្រាសអុហ្វសិតដើម្បីទទួលបាន RcBox ទាំងមូល។
            // សុវត្ថិភាព: ទ្រនិចមានប្រភពមកពីខ្សោយដូច្នេះអុហ្វសិតនេះមានសុវត្ថិភាព។
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // សុវត្ថិភាព៖ ឥឡូវនេះយើងបានរកឃើញទ្រនិចខ្សោយរបស់ដើមដូច្នេះអាចបង្កើតបានជា Weak ។
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// ការប៉ុនប៉ងធ្វើឱ្យប្រសើរឡើងនូវទ្រនិច `Weak` ទៅ [`Arc`] X ពន្យារពេលទម្លាក់តម្លៃខាងក្នុងប្រសិនបើទទួលបានជោគជ័យ។
    ///
    ///
    /// ត្រឡប់ [`None`] ប្រសិនបើតម្លៃខាងក្នុងត្រូវបានទម្លាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // បំផ្លាញចំណុចខ្លាំងទាំងអស់។
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // យើងប្រើរង្វិលជុំ CAS ដើម្បីបង្កើនចំនួនដ៏រឹងមាំជំនួសឱ្យការប្រមូលយកពីព្រោះមុខងារនេះមិនគួរយកការរាប់ពីលេខសូន្យទៅមួយទេ។
        //
        //
        let inner = self.inner()?;

        // ការផ្ទុកបានធូរស្បើយពីព្រោះការសរសេរណាមួយនៃលេខ ០ ដែលយើងអាចសង្កេតឃើញទុកវាលនៅក្នុងស្ថានភាពសូន្យជាអចិន្ត្រៃយ៍ (ដូច្នេះអានអក្សរ X០០X ០ គឺមិនអីទេ) ហើយតម្លៃផ្សេងទៀតត្រូវបានបញ្ជាក់តាមរយៈ CAS ខាងក្រោម។
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // មើលយោបល់នៅក្នុង `Arc::clone` សម្រាប់មូលហេតុដែលយើងធ្វើវា (សម្រាប់ `mem::forget`) ។
            if n > MAX_REFCOUNT {
                abort();
            }

            // សម្រាកគឺល្អសម្រាប់ករណីបរាជ័យពីព្រោះយើងមិនមានការរំពឹងទុកអំពីរដ្ឋថ្មីនេះទេ។
            // ការទទួលបានគឺចាំបាច់សម្រាប់ករណីជោគជ័យដើម្បីធ្វើសមកាលកម្មជាមួយ `Arc::new_cyclic` នៅពេលដែលតម្លៃខាងក្នុងអាចត្រូវបានចាប់ផ្តើមបន្ទាប់ពីឯកសារយោង `Weak` ត្រូវបានបង្កើតរួចហើយ។
            // ក្នុងករណីនេះយើងរំពឹងថានឹងសង្កេតមើលតម្លៃដែលបានចាប់ផ្តើមពេញលេញ។
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // បានចាត់ទុកជាមោឃៈខាងលើ
                Err(old) => n = old,
            }
        }
    }

    /// ទទួលបានចំនួនអ្នកចង្អុល (`Arc`) ដែលចង្អុលទៅការបែងចែកនេះ។
    ///
    /// ប្រសិនបើ `self` ត្រូវបានបង្កើតឡើងដោយប្រើ [`Weak::new`] វានឹងត្រឡប់ 0 ។
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// ទទួលបានប្រមាណប្រហាក់ប្រហែលនៃចំនួនសូចនាករ `Weak` ដែលចង្អុលទៅការបែងចែកនេះ។
    ///
    /// ប្រសិនបើ `self` ត្រូវបានបង្កើតឡើងដោយប្រើ [`Weak::new`] ឬប្រសិនបើមិនមានចំនុចខ្លាំងដែលនៅសល់ទេនេះនឹងត្រលប់ 0 ។
    ///
    /// # Accuracy
    ///
    /// ដោយសារតែអនុវត្តន៍លម្អិត, តម្លៃត្រឡប់មកវិញនេះអាចត្រូវបានបិទដោយ 1 ក្នុងទិសទាំងពេលខ្សែស្រលាយផ្សេងទៀតត្រូវបានរៀបចំណា `ឬ` Weak`s Arc`s ចង្អុលទៅការបែងចែកដូចគ្នា។
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // ដោយសារយើងសង្កេតឃើញថាមានយ៉ាងហោចណាស់ទ្រនិចខ្លាំងមួយបន្ទាប់ពីអានការរាប់ខ្សោយយើងដឹងថាឯកសារយោងខ្សោយដែលមិនច្បាស់ (មានវត្តមាននៅពេលណាដែលឯកសារយោងខ្លាំងនៅមានជីវិត) នៅតែមាននៅពេលយើងសង្កេតមើលចំនួនខ្សោយហើយដូច្នេះអាចដកវាចេញដោយសុវត្ថិភាព។
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// ត្រឡប់ `None` នៅពេលព្រួញកន្ត្រាក់ហើយមិនត្រូវបានបម្រុងទុក `ArcInner` (មានន័យថានៅពេល `Weak` នេះត្រូវបានបង្កើតដោយ `Weak::new`) ។
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // យើងប្រយ័ត្នប្រយែងក្នុងការ *មិន* បង្កើតឯកសារយោងដែលគ្របដណ្តប់លើវាល "data" ព្រោះថាវាលនេះអាចត្រូវបានផ្លាស់ប្តូរក្នុងពេលដំណាលគ្នា (ឧទាហរណ៍ប្រសិនបើ `Arc` ចុងក្រោយត្រូវបានទម្លាក់នោះវាលទិន្នន័យនឹងត្រូវបានទម្លាក់នៅនឹងកន្លែង) ។
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើសញ្ញា `ខ្សោយទាំងពីរចង្អុលទៅការបែងចែកដូចគ្នា (ស្រដៀងនឹង [`ptr::eq`]) ឬប្រសិនបើទាំងពីរមិនចង្អុលទៅការបែងចែកណាមួយ (ពីព្រោះពួកវាត្រូវបានបង្កើតជាមួយ `Weak::new()`) ។
    ///
    ///
    /// # Notes
    ///
    /// ដោយសារនេះប្រៀបធៀបចំណុចចង្អុលបង្ហាញវាមានន័យថា `Weak::new()` នឹងស្មើគ្នាទោះបីជាពួកគេមិនចង្អុលទៅការបែងចែកក៏ដោយ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// ប្រៀបធៀប `Weak::new` ។
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// បង្កើតក្លូននៃទ្រនិច `Weak` ដែលចង្អុលទៅការបែងចែកដូចគ្នា។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // សូមមើលយោបល់នៅក្នុង Arc::clone() សម្រាប់មូលហេតុដែលនេះត្រូវបានសម្រាក។
        // នេះអាចប្រើ fetch_add មួយ (មិនអើពើនឹងចាក់សោ) ដោយសារតែចំនួនអ្នកដែលខ្សោយត្រូវបានចាក់សោតែជាកន្លែងដែលមាន *គ្មានផ្សេងទៀត* ទន់ខ្សោយការចង្អុលបង្ហាញនៅក្នុងជីវិត។
        //
        // (ដូច្នេះយើងមិនអាចដំណើរការលេខកូដនេះក្នុងករណីនោះទេ) ។
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // មើលយោបល់នៅក្នុង Arc::clone() សម្រាប់មូលហេតុដែលយើងធ្វើវា (សម្រាប់ mem::forget) ។
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// សាងសង់ `Weak<T>` ថ្មីដោយមិនចាំបាច់បែងចែកអង្គចងចាំ។
    /// ការហៅទូរស័ព្ទ [`upgrade`] លើតម្លៃត្រឡប់មកវិញតែងតែផ្តល់ឱ្យ [`None`] ។
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// ទម្លាក់ទ្រនិច `Weak` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // មិនបោះពុម្ពអ្វីទាំងអស់
    /// drop(foo);        // បោះពុម្ព "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // ប្រសិនបើយើងរកឃើញថាយើងជាអ្នកចង្អុលចុងក្រោយខ្សោយពេលនោះវាដល់ពេលដែលត្រូវចែកចាយទិន្នន័យទាំងស្រុង។សូមមើលការពិភាក្សានៅក្នុង Arc::drop() អំពីការបញ្ជាទិញអង្គចងចាំ
        //
        // វាមិនចាំបាច់ក្នុងការត្រួតពិនិត្យស្ថានភាពចាក់សោរនៅទីនេះទេពីព្រោះចំនួនខ្សោយអាចត្រូវបានចាក់សោប្រសិនបើមានការបដិសេធខ្សោយមួយដែលមានន័យថាការធ្លាក់ចុះអាចដំណើរការជាបន្តបន្ទាប់លើការថយចុះខ្សោយដែលនៅសល់ដែលអាចកើតឡើងបានបន្ទាប់ពីការចាក់សោត្រូវបានចេញផ្សាយ។
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// យើងកំពុងធ្វើឯកទេសនេះនៅទីនេះហើយមិនមែនជាការបង្កើនប្រសិទ្ធិភាពទូទៅបន្ថែមលើ `&T` ទេពីព្រោះវានឹងបន្ថែមការចំណាយទៅលើការត្រួតពិនិត្យសមភាពទាំងអស់លើក្រដាសប្រាក់។
/// យើងសន្មត់ថាអាខេស៊ីត្រូវបានប្រើដើម្បីរក្សាទុកតម្លៃធំ ៗ ដែលយឺតដើម្បីក្លូនប៉ុន្តែក៏ធ្ងន់ដើម្បីពិនិត្យមើលភាពស្មើគ្នាដែលបណ្តាលឱ្យការចំណាយនេះទូទាត់កាន់តែងាយស្រួល។
///
/// វាទំនងជាមានក្លូន `Arc` ពីរដែលចង្អុលទៅតម្លៃដូចគ្នាជាងពីរ `&T`s ទៅទៀត។
///
/// យើងអាចធ្វើវាបានលុះត្រាតែ `T: Eq` ជា `PartialEq` អាចមិនសមហេតុផលដោយចេតនា។
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// សមភាពសំរាប់ពីរធ្នូ។
    ///
    /// ធ្នូពីរគឺស្មើគ្នាប្រសិនបើតម្លៃខាងក្នុងរបស់ពួកគេស្មើគ្នាទោះបីវាត្រូវបានរក្សាទុកក្នុងការបែងចែកខុសគ្នាក៏ដោយ។
    ///
    /// ប្រសិនបើ `T` ក៏អនុវត្ត `Eq` (បង្ហាញការឆ្លុះបញ្ចាំងពីភាពស្មើគ្នា), ពីរធ្នូដែលចង្អុលទៅការបែងចែកដូចគ្នាគឺតែងតែស្មើគ្នា។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// វិសមភាពសំរាប់ `អ័ក្សពីរ។
    ///
    /// ធ្នូពីរគឺមិនស្មើគ្នាប្រសិនបើតម្លៃខាងក្នុងរបស់ពួកគេមិនស្មើគ្នា។
    ///
    /// ប្រសិនបើ `T` ក៏អនុវត្ត `Eq` (បង្ហាញការឆ្លុះបញ្ចាំងពីភាពស្មើគ្នា), ពីរធ្នូដែលចង្អុលទៅតម្លៃដូចគ្នាគឺមិនដែលស្មើគ្នានោះទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// ការប្រៀបធៀបដោយផ្នែកសម្រាប់ `អ័ក្សពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `partial_cmp()` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ការប្រៀបធៀបតិចជាងសម្រាប់ `ធ្នូពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `<` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// ការប្រៀបធៀប Less តូចជាងឬស្មើ 'សម្រាប់ `Arc` ពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `<=` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// ការប្រៀបធៀបដែលប្រសើរជាងសំរាប់ `ធ្នូពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `>` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// ការប្រៀបធៀប Great ធំជាងឬស្មើ›សំរាប់ `អ័ក្សពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `>=` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// ការប្រៀបធៀបសម្រាប់ពីរធ្នូ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `cmp()` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// បង្កើត `Arc<T>` ថ្មីមួយដែលមានតម្លៃ `Default` សម្រាប់ `T` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// បែងចែកចំណិតយោងដែលបានរាប់ហើយបំពេញវាដោយក្លូនរបស់ `v` ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// បែងចែក `str` ដែលបានរាប់យោងហើយចម្លង `v` ទៅក្នុងនោះ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// បែងចែក `str` ដែលបានរាប់យោងហើយចម្លង `v` ទៅក្នុងនោះ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ផ្លាស់ទីវត្ថុដែលមានប្រអប់មួយទៅការបែងចែកដែលបានរាប់ដោយយោងថ្មី។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// បែងចែកចំណិតយោងដែលបានរាប់ហើយយករបស់របស់ `v ចូលទៅក្នុងនោះ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // អនុញ្ញាតឱ្យ Vec ដោះលែងការចងចាំរបស់វាប៉ុន្តែមិនបំផ្លាញមាតិការបស់វាទេ
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// យកធាតុនីមួយៗនៅក្នុង `Iterator` ហើយប្រមូលវាទៅជា `Arc<[T]>` ។
    ///
    /// # លក្ខណៈនៃការអនុវត្ត
    ///
    /// ## ករណីទូទៅ
    ///
    /// ក្នុងករណីទូទៅការប្រមូលចូលទៅក្នុង `Arc<[T]>` ត្រូវបានធ្វើឡើងដោយការប្រមូលដំបូងទៅក្នុង `Vec<T>` ។នោះគឺជា, ពេលសរសេរដូចខាងក្រោម:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// នេះមានឥរិយាបទដូចជាយើងបានសរសេរ៖
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // សំណុំនៃការបែងចែកដំបូងកើតឡើងនៅទីនេះ។
    ///     .into(); // ការបែងចែកទីពីរសម្រាប់ `Arc<[T]>` កើតឡើងនៅទីនេះ។
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// នេះនឹងបែងចែកច្រើនដងតាមតម្រូវការសម្រាប់ការសាងសង់ `Vec<T>` ហើយបន្ទាប់មកវានឹងបម្រុងទុកសម្រាប់ការបង្វែរ `Vec<T>` ទៅជា `Arc<[T]>` ។
    ///
    ///
    /// ## ឧបករណ៍បំបែកប្រវែងដែលស្គាល់
    ///
    /// នៅពេលដែល `Iterator` របស់អ្នកអនុវត្ត `TrustedLen` និងមានទំហំពិតប្រាកដការបែងចែកតែមួយនឹងត្រូវបានធ្វើឡើងសម្រាប់ `Arc<[T]>` ។ឧទាហរណ៍:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // គ្រាន់តែការបែងចែកតែមួយកើតឡើងនៅទីនេះ។
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// ឯកទេស trait ប្រើសម្រាប់ប្រមូលចូល `Arc<[T]>` ។
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // នេះជាករណីសម្រាប់ឧបករណ៍ `TrustedLen` iterator ។
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // សុវត្ថិភាព: យើងត្រូវធានាថាឧបករណ៍វាស់មានប្រវែងពិតប្រាកដហើយយើងមាន។
                Arc::from_iter_exact(self, low)
            }
        } else {
            // ត្រលប់ទៅការអនុវត្តធម្មតាវិញ។
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ទទួលបានអុហ្វសិតក្នុងរយៈពេល `ArcInner` សម្រាប់បន្ទុកនៅពីក្រោយទ្រនិច។
///
/// # Safety
///
/// ទ្រនិចត្រូវតែចង្អុលទៅ (និងមានទិន្នន័យមេតាដែលមានសុពលភាពសម្រាប់) ឧទាហរណ៍ដែលមានសុពលភាពនៃ T ប៉ុន្តែ T ត្រូវបានអនុញ្ញាតឱ្យទម្លាក់។
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // តម្រឹមតម្លៃដែលមិនបានបញ្ជាក់ទៅចុងបញ្ចប់នៃ ArcInner ។
    // ដោយសារតែ RcBox គឺជា repr(C) វានឹងក្លាយជាវាលចុងក្រោយនៅក្នុងការចងចាំជានិច្ច។
    // សុវត្ថិភាព: ចាប់តាំងពីប្រភេទដែលមិនមានសុពលភាពតែមួយគត់ដែលអាចធ្វើបានគឺចំណិតវត្ថុ trait,
    // និងប្រភេទខាងក្រៅតម្រូវការសុវត្ថិភាពបញ្ចូលគឺគ្រប់គ្រាន់ដើម្បីបំពេញតាមតម្រូវការនៃការតំរឹម;នេះគឺជាសេចក្តីលំអិតនៃការអនុវត្តភាសាដែលមិនអាចពឹងផ្អែកលើ std ។
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}