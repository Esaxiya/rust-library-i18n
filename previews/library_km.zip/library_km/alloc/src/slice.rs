//! ទិដ្ឋភាពដែលមានទំហំឌីណាមិកទៅជាលំដាប់ជាប់គ្នា `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! ចំណិតគឺជាទិដ្ឋភាពចូលទៅក្នុងប្លុកនៃសតិដែលតំណាងឱ្យទ្រនិចនិងប្រវែង។
//!
//! ```
//! // កាត់វ៉ិចទ័រ
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // បង្ខំអារេមួយចំណែក ៗ
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ស្លាយអាចផ្លាស់ប្តូរបានឬចែករំលែក។
//! ប្រភេទចែករំឡែកគឺ `&[T]` ចំណែកឯប្រភេទចំណែកដែលអាចប្តូរបានគឺ `&mut [T]` ដែល `T` តំណាងអោយប្រភេទធាតុ។
//! ឧទាហរណ៍អ្នកអាចផ្លាស់ប្តូរប្លុកនៃការចងចាំដែលជាចំណែកដែលអាចផ្លាស់ប្តូរបានចង្អុលទៅ:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! នេះគឺជារបស់មួយចំនួនដែលម៉ូឌុលនេះមានៈ
//!
//! ## Structs
//!
//! មានរចនាសម្ព័នជាច្រើនដែលមានប្រយោជន៍សម្រាប់ចំណិតដូចជា [`Iter`] ដែលតំណាងឱ្យការនិយាយឡើងវិញនៅលើចំណិត ៗ ។
//!
//! ## ការអនុវត្ត Trait
//!
//! មានការអនុវត្តជាច្រើននៃ traits ធម្មតាសម្រាប់ចំណិត។ឧទាហរណ៍ខ្លះរួមមាន៖
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] សម្រាប់ចំណិតដែលមានប្រភេទធាតុគឺ [`Eq`] ឬ [`Ord`] ។
//! * [`Hash`] - សម្រាប់ចំណិតដែលមានប្រភេទធាតុគឺ [`Hash`] ។
//!
//! ## Iteration
//!
//! ចំណិតអនុវត្ត `IntoIterator` ។ទ្រនិចបង្ហាញលទ្ធផលយោងតាមធាតុផ្សំ។
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! ចំណិតដែលអាចផ្លាស់ប្តូរបានផ្តល់នូវសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានចំពោះធាតុ៖
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ឧបករណ៍រំកិលនេះផ្តល់នូវការយោងដែលអាចផ្លាស់ប្តូរទៅធាតុនៃចំណែកដូច្នេះនៅពេលដែលប្រភេទធាតុនៃចំណែកគឺ `i32` ប្រភេទធាតុរបស់វាគឺ `&mut i32` ។
//!
//!
//! * [`.iter`] និង [`.iter_mut`] គឺជាវិធីសាស្រ្តច្បាស់លាស់ក្នុងការប្រើឧបករណ៍ដដែល។
//! * វិធីសាស្រ្តផ្សេងទៀតដែលផ្តល់នូវការវិលត្រឡប់មកវិញគឺ [`.split`], [`.splitn`], [`.chunks`], [`.windows`] និងច្រើនទៀត។
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ការប្រើប្រាស់ជាច្រើននៅក្នុងម៉ូឌុលនេះត្រូវបានប្រើតែនៅក្នុងការកំណត់រចនាសម្ព័ន្ធការធ្វើតេស្តប៉ុណ្ណោះ។
// វាស្អាតជាងមុនដើម្បីគ្រាន់តែបិទការព្រមានអំពីរបាយការណ៍ដែលមិនបានប្រើជាជាងជួសជុលវា។
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// វិធីសាស្រ្តពង្រីកមូលដ្ឋានគ្រឹះ
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) ត្រូវការសម្រាប់ការអនុវត្តម៉ាក្រូ `vec!` X កំឡុងពេលធ្វើតេស្តអិនប៊ីសូមមើលម៉ូឌុល `hack` នៅក្នុងឯកសារនេះសម្រាប់ព័ត៌មានលំអិត។
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) ត្រូវការសម្រាប់ការអនុវត្ត `Vec::clone` កំឡុងពេលធ្វើតេស្ត NB សូមមើលម៉ូឌុល `hack` នៅក្នុងឯកសារនេះសម្រាប់ព័ត៌មានលំអិត។
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): ជាមួយនឹង cfg(test) `impl [T]` មិនអាចប្រើបានទេមុខងារទាំងបីនេះពិតជាវិធីសាស្រ្តដែលមាននៅក្នុង `impl [T]` ប៉ុន្តែមិនមាននៅក្នុង `core::slice::SliceExt` ទេយើងត្រូវផ្គត់ផ្គង់មុខងារទាំងនេះសម្រាប់ការធ្វើតេស្ត `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // យើងមិនគួរបន្ថែមគុណលក្ខណៈក្នុងជួរទេពីព្រោះវាត្រូវបានប្រើជាម៉ាក្រូ `vec!` X ភាគច្រើនហើយបណ្តាលឱ្យមានតំរែតំរង់ដ៏ល្អ។
    // សូមមើល #71204 សម្រាប់ការពិភាក្សានិងលទ្ធផលល្អឥតខ្ចោះ។
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ធាតុត្រូវបានសម្គាល់នៅក្នុងរង្វិលជុំខាងក្រោម
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) គឺចាំបាច់សម្រាប់អិលអិលអេមអិមដកការត្រួតពិនិត្យព្រំដែនចេញនិងមានលេខកូដហ្គែនល្អជាងហ្ស៊ីប។
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec នេះត្រូវបានត្រៀមទុកហើយចាប់ផ្ដើមខាងលើយ៉ាងហោចណាស់ប្រវែងនេះ។
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // បានបម្រុងទុកខាងលើជាមួយនឹងសមត្ថភាពរបស់ `s` និងចាប់ផ្តើមទៅ `s.len()` ក្នុង ptr::copy_to_non_overlapping ខាងក្រោម។
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// តម្រៀបចំណិត។
    ///
    /// ប្រភេទនេះមានស្ថេរភាព (ពោលគឺការមិនមានធាតុស្មើមិនត្រូវបានតម្រៀបឡើងវិញ) និង *ឱ*(*n*\*log(* n*)) អាក្រក់បំផុតករណី។
    ///
    /// នៅពេលអនុវត្តការតម្រៀបមិនស្ថិតស្ថេរត្រូវបានគេពេញចិត្តព្រោះជាទូទៅវាលឿនជាងការតម្រៀបដែលមានស្ថេរភាពហើយវាមិនបែងចែកអង្គចងចាំជំនួយទេ។
    /// មើល [`sort_unstable`](slice::sort_unstable) ។
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// ក្បួនដោះស្រាយបច្ចុប្បន្នគឺជាអាដាប់ធ័រនិងការបញ្ចូលគ្នាដែលបញ្ចូលគ្នាដែលត្រូវបានបំផុសគំនិតដោយ [timsort](https://en.wikipedia.org/wiki/Timsort) ។
    /// វាត្រូវបានរចនាឡើងយ៉ាងលឿនក្នុងករណីដែលបំណែកជិតត្រូវបានតម្រៀបឬមានលំដាប់ពីរឬច្រើនដែលត្រូវបានតំរៀបគ្នាជាបន្តបន្ទាប់គ្នា។
    ///
    ///
    /// ដូចគ្នានេះផងដែរវាបែងចែកការផ្ទុកបណ្តោះអាសន្នពាក់កណ្តាលទំហំនៃ `self` ប៉ុន្តែសម្រាប់ចំណិតខ្លីការតម្រៀបបញ្ចូលដែលមិនបែងចែកត្រូវបានប្រើជំនួសវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// តម្រៀបចំណិតជាមួយនឹងមុខងារប្រៀបធៀប។
    ///
    /// ប្រភេទនេះមានស្ថេរភាព (ពោលគឺការមិនមានធាតុស្មើមិនត្រូវបានតម្រៀបឡើងវិញ) និង *ឱ*(*n*\*log(* n*)) អាក្រក់បំផុតករណី។
    ///
    /// មុខងារប្រៀបធៀបនេះត្រូវតែកំណត់លំដាប់សរុបសម្រាប់ធាតុក្នុងចំណិត។ប្រសិនបើការបញ្ជាទិញមិនមានសរុបទេលំដាប់នៃធាតុមិនត្រូវបានបញ្ជាក់ទេ។
    /// ការបញ្ជាទិញគឺជាការបញ្ជាទិញសរុបប្រសិនបើវា (សម្រាប់ `a`, `b` និង `c` ទាំងអស់)៖
    ///
    /// * សរុបនិង antisymmetric: ពិតជាមួយនៃ `a < b`, `a == b` ឬ `a > b` ពិតហើយ
    /// * ការផ្លាស់ប្តូរ, `a < b` និង `b < c` បង្កប់ន័យ `a < c` ។ដូចគ្នាត្រូវតែកាន់ទាំង `==` និង `>` ។
    ///
    /// ឧទាហរណ៍ខណៈពេលដែល [`f64`] មិនអនុវត្ត [`Ord`] ព្រោះ `NaN != NaN` យើងអាចប្រើ `partial_cmp` ជាមុខងារតម្រៀបរបស់យើងនៅពេលដែលយើងដឹងថាចំណិតមិនមាន `NaN` ។
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// នៅពេលអនុវត្តការតម្រៀបមិនស្ថិតស្ថេរត្រូវបានគេពេញចិត្តព្រោះជាទូទៅវាលឿនជាងការតម្រៀបដែលមានស្ថេរភាពហើយវាមិនបែងចែកអង្គចងចាំជំនួយទេ។
    /// មើល [`sort_unstable_by`](slice::sort_unstable_by) ។
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// ក្បួនដោះស្រាយបច្ចុប្បន្នគឺជាអាដាប់ធ័រនិងការបញ្ចូលគ្នាដែលបញ្ចូលគ្នាដែលត្រូវបានបំផុសគំនិតដោយ [timsort](https://en.wikipedia.org/wiki/Timsort) ។
    /// វាត្រូវបានរចនាឡើងយ៉ាងលឿនក្នុងករណីដែលបំណែកជិតត្រូវបានតម្រៀបឬមានលំដាប់ពីរឬច្រើនដែលត្រូវបានតំរៀបគ្នាជាបន្តបន្ទាប់គ្នា។
    ///
    /// ដូចគ្នានេះផងដែរវាបែងចែកការផ្ទុកបណ្តោះអាសន្នពាក់កណ្តាលទំហំនៃ `self` ប៉ុន្តែសម្រាប់ចំណិតខ្លីការតម្រៀបបញ្ចូលដែលមិនបែងចែកត្រូវបានប្រើជំនួសវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // តម្រៀបបញ្ច្រាស
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// តម្រៀបចំណិតដែលមានមុខងារទាញយកគន្លឹះ។
    ///
    /// ការតម្រៀបនេះគឺមានស្ថេរភាព (មានន័យថាមិនតំរឹមធាតុស្មើគ្នាទេ) និង *O*(*m*\* * n *\* log(*n*)) ករណីអាក្រក់បំផុតដែលមុខងារសំខាន់គឺ *O*(*m*) ។
    ///
    /// សម្រាប់មុខងារសំខាន់ៗដែលមានតំលៃថ្លៃ (ឧ
    /// មុខងារដែលមិនមែនជាការចូលប្រើទ្រព្យសម្បត្តិសាមញ្ញឬប្រតិបត្តិការមូលដ្ឋាន) [`sort_by_cached_key`](slice::sort_by_cached_key) ទំនងជាលឿនជាងមុនយ៉ាងខ្លាំងព្រោះវាមិនបានគិតគូរពីធាតុផ្សំសំខាន់ៗទេ។
    ///
    ///
    /// នៅពេលអនុវត្តការតម្រៀបមិនស្ថិតស្ថេរត្រូវបានគេពេញចិត្តព្រោះជាទូទៅវាលឿនជាងការតម្រៀបដែលមានស្ថេរភាពហើយវាមិនបែងចែកអង្គចងចាំជំនួយទេ។
    /// មើល [`sort_unstable_by_key`](slice::sort_unstable_by_key) ។
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// ក្បួនដោះស្រាយបច្ចុប្បន្នគឺជាអាដាប់ធ័រនិងការបញ្ចូលគ្នាដែលបញ្ចូលគ្នាដែលត្រូវបានបំផុសគំនិតដោយ [timsort](https://en.wikipedia.org/wiki/Timsort) ។
    /// វាត្រូវបានរចនាឡើងយ៉ាងលឿនក្នុងករណីដែលបំណែកជិតត្រូវបានតម្រៀបឬមានលំដាប់ពីរឬច្រើនដែលត្រូវបានតំរៀបគ្នាជាបន្តបន្ទាប់គ្នា។
    ///
    /// ដូចគ្នានេះផងដែរវាបែងចែកការផ្ទុកបណ្តោះអាសន្នពាក់កណ្តាលទំហំនៃ `self` ប៉ុន្តែសម្រាប់ចំណិតខ្លីការតម្រៀបបញ្ចូលដែលមិនបែងចែកត្រូវបានប្រើជំនួសវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// តម្រៀបចំណិតដែលមានមុខងារទាញយកគន្លឹះ។
    ///
    /// ក្នុងអំឡុងពេលនៃការតម្រៀបមុខងារសំខាន់ត្រូវបានគេហៅថាតែម្តងក្នុងមួយធាតុ។
    ///
    /// ការតម្រៀបនេះគឺមានស្ថេរភាព (មានន័យថាមិនតំរឹមធាតុស្មើគ្នាទេ) និង *O*(*m*\* * n *+* n *\* log(*n*)) ករណីដ៏អាក្រក់បំផុតដែលមុខងារសំខាន់គឺ *O*(*m*) ។
    ///
    /// សម្រាប់មុខងារសំខាន់ៗសាមញ្ញ (ឧទាហរណ៍មុខងារដែលជាការចូលប្រើទ្រព្យសម្បត្តិឬប្រតិបត្តិការមូលដ្ឋាន) [`sort_by_key`](slice::sort_by_key) ទំនងជាលឿនជាង។
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// ក្បួនដោះស្រាយបច្ចុប្បន្នគឺផ្អែកលើ [pattern-defeating quicksort][pdqsort] ដោយអ័រសុនផឺរដែលរួមបញ្ចូលគ្នានូវករណីមធ្យមដែលមានល្បឿនលឿនដោយចៃដន្យជាមួយនឹងករណីដ៏អាក្រក់បំផុតនៃហេបស្តុនខណៈពេលដែលសម្រេចបានពេលវេលាលីនេអ៊ែរនៅលើចំណិតជាមួយនឹងលំនាំជាក់លាក់។
    /// វាប្រើការចៃដន្យមួយចំនួនដើម្បីចៀសវាងករណីអន់ថយប៉ុន្តែជាមួយនឹងហ្សែនហ្សេហ្សេហ្ស៊ីថេរដើម្បីផ្តល់ឥរិយាបថកំណត់ជានិច្ច។
    ///
    /// ក្នុងករណីដ៏អាក្រក់បំផុតក្បួនដោះស្រាយបែងចែកការផ្ទុកបណ្តោះអាសន្ននៅក្នុង `Vec<(K, usize)>` ប្រវែងនៃចំណិត។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // ជំនួយម៉ាក្រូសម្រាប់ធ្វើលិបិក្រម vector របស់យើងដោយប្រភេទតូចបំផុតដែលអាចធ្វើទៅបានដើម្បីកាត់បន្ថយការបែងចែក។
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // ធាតុនៃ `indices` គឺមានតែមួយគត់ដែលវាត្រូវបានធ្វើលិបិក្រមដូច្នេះប្រភេទណាមួយនឹងមានស្ថេរភាពដោយគោរពតាមចំណិតដើម។
                // យើងប្រើ `sort_unstable` នៅទីនេះព្រោះវាទាមទារការបែងចែកសតិតិច។
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// ចម្លង `self` ទៅក្នុង `Vec` ថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // នៅទីនេះ `s` និង `x` អាចត្រូវបានកែប្រែដោយឯករាជ្យ។
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ចម្លង `self` ទៅក្នុង `Vec` ថ្មីជាមួយអ្នកបែងចែក។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // នៅទីនេះ `s` និង `x` អាចត្រូវបានកែប្រែដោយឯករាជ្យ។
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB សូមមើលម៉ូឌុល `hack` នៅក្នុងឯកសារនេះសម្រាប់ព័ត៌មានលំអិត។
        hack::to_vec(self, alloc)
    }

    /// បំលែង `self` ទៅជា vector ដោយគ្មានក្លូនឬការបែងចែក។
    ///
    /// លទ្ធផល vector អាចត្រូវបានបំលែងទៅក្នុងប្រអប់មួយតាមរយៈ `វី<T>វិធី `into_boxed_slice`` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` មិនអាចប្រើបានទៀតទេព្រោះវាត្រូវបានប្តូរទៅជា `x` ។
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB សូមមើលម៉ូឌុល `hack` នៅក្នុងឯកសារនេះសម្រាប់ព័ត៌មានលំអិត។
        hack::into_vec(self)
    }

    /// បង្កើត vector ដោយការធ្វើម្តងទៀតនូវ `n` X ដង។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើសមត្ថភាពនឹងហៀរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic ពេលលើសចំណុះ៖
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // ប្រសិនបើ `n` ធំជាងសូន្យវាអាចបំបែកជា `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` ។
        // `2^expn` គឺជាលេខដែលតំណាងដោយប៊ីត '1' ខាងឆ្វេងនៃ `n` ហើយ `rem` គឺជាផ្នែកដែលនៅសល់នៃ `n` ។
        //
        //

        // ការប្រើប្រាស់ `Vec` ដើម្បីចូលប្រើ `set_len()` ។
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` ពាក្យដដែលៗត្រូវបានធ្វើឡើងដោយ `buf` ទ្វេដងដង។
        buf.extend(self);
        {
            let mut m = n >> 1;
            // ប្រសិនបើ `m > 0` មានប៊ីតនៅសល់រហូតដល់ '1' ខាងឆ្វេង។
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` មានសមត្ថភាព `self.len() * n` ។
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ពាក្យដដែលៗត្រូវបានធ្វើឡើងដោយចម្លងពាក្យដដែលៗ `rem` ដំបូងពី `buf` ដោយខ្លួនឯង។
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // នេះមិនមែនជាការត្រួតស៊ីគ្នាទេចាប់តាំងពី `2^expn > rem` ។
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` ស្មើនឹង `buf.capacity()` (`= self.len() * n`) ។
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// បង្រួមចំណិត `T` ទៅជាតម្លៃតែមួយ `Self::Output` ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// បង្រួមចំណិត `T` ទៅជាតម្លៃតែមួយ `Self::Output` ដោយដាក់សញ្ញាបំបែករវាងលេខនីមួយៗ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// បង្រួមចំណិត `T` ទៅជាតម្លៃតែមួយ `Self::Output` ដោយដាក់សញ្ញាបំបែករវាងលេខនីមួយៗ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// ត្រឡប់ vector ដែលមានច្បាប់ចម្លងនៃចំណែកនេះដែលបៃនីមួយៗត្រូវបានផ្គូផ្គងទៅនឹងអក្សរធំ ASCII ។
    ///
    ///
    /// អក្សរ ASCII 'a' ទៅ 'z' ត្រូវបានគូសផែនទីទៅ 'A' ទៅ 'Z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីបង្កើនតម្លៃនៅនឹងកន្លែងសូមប្រើ [`make_ascii_uppercase`] ។
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// ត្រឡប់ vector ដែលមានច្បាប់ចម្លងនៃចំណែកនេះដែលបៃនីមួយៗត្រូវបានគូសទៅនឹងអក្សរតូច ASCII ។
    ///
    ///
    /// អក្សរ ASCII 'A' ទៅ 'Z' ត្រូវបានគូសផែនទីទៅ 'a' ទៅ 'z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីបន្ទាបតម្លៃនៅនឹងកន្លែងសូមប្រើ [`make_ascii_lowercase`] ។
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// ផ្នែកបន្ថែម traits សម្រាប់ចំណិតលើប្រភេទទិន្នន័យជាក់លាក់
////////////////////////////////////////////////////////////////////////////////

/// ជំនួយការ trait សម្រាប់ [`[T]: : concat`](slice::concat) ។
///
/// Note: ប៉ារ៉ាម៉ែត្រប្រភេទ `Item` មិនត្រូវបានប្រើនៅក្នុង trait នេះទេប៉ុន្តែវាអនុញ្ញាតអោយបង្កប់នូវលក្ខណៈទូទៅ។
/// បើគ្មានវាទេយើងទទួលបានកំហុសនេះ៖
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// នេះដោយសារតែវាអាចមានប្រភេទ `V` ដែលមានប្រភេទ `Borrow<[_]>` ច្រើនប្រភេទដែលប្រភេទ `T` ច្រើនអាចអនុវត្តបាន៖
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ប្រភេទលទ្ធផលបន្ទាប់ពីការបូកសរុប
    type Output;

    /// ការអនុវត្តន៍ [`[ធី]: : តាក់តា៉](គ្រាលំបាក::)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// ជំនួយការ trait សម្រាប់ [`[T]: : ចូលរួម`](slice::ចូលរួម)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// ប្រភេទលទ្ធផលបន្ទាប់ពីការបូកសរុប
    type Output;

    /// ការអនុវត្តន៍ [`[T]: : ចូលរួម`](slice::ចូលរួម)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// ការអនុវត្តស្តង់ដារ trait សម្រាប់ចំណិត
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // ទម្លាក់អ្វីមួយនៅក្នុងគោលដៅដែលនឹងមិនត្រូវបានសរសេរជាន់ពីលើ
        target.truncate(self.len());

        // target.len <= self.len ដោយសារតែការកាត់ចេញខាងលើដូច្នេះចំណិតនៅទីនេះតែងតែស្ថិតក្នុងចន្លោះ។
        //
        let (init, tail) = self.split_at(target.len());

        // ប្រើឡើងវិញនូវតម្លៃដែលមាន allocations/resources ។
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// បញ្ចូល `v[0]` ទៅក្នុងលំដាប់ `v[1..]` ដែលបានតម្រៀបជាមុនដូច្នេះ `v[..]` ទាំងមូលក្លាយជាតម្រៀប។
///
/// នេះគឺជាទម្រង់រងសំខាន់នៃតម្រៀបបញ្ចូល។
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // មានវិធីបីយ៉ាងដើម្បីអនុវត្តសិលាចារឹកនៅទីនេះ៖
            //
            // 1. ផ្លាស់ប្តូរធាតុដែលនៅជាប់គ្នារហូតដល់អ្នកទីមួយទៅដល់ទិសដៅចុងក្រោយរបស់វា។
            //    ទោះយ៉ាងណាក៏ដោយវិធីនេះយើងចម្លងទិន្នន័យជុំវិញអ្វីដែលចាំបាច់។
            //    ប្រសិនបើធាតុគឺជារចនាសម្ព័ន្ធធំ (ចំណាយក្នុងការចម្លង) វិធីសាស្ត្រនេះនឹងយឺត។
            //
            // 2. ច្របាច់រហូតដល់កន្លែងដែលត្រឹមត្រូវសម្រាប់ធាតុទីមួយត្រូវបានរកឃើញ។
            // បនា្ទាប់មកប្តូរធាតុដ្លទទួលបានជោគជ័យដើម្របីបង្កើតបន្ទប់សម្រាប់វាហើយទីបំផុតដាក់វាចូលទៅក្នុងរន្ធដ្រលនៅសល់។
            // នេះជាវិធីសាស្ត្រល្អ។
            //
            // 3. ចម្លងធាតុទីមួយទៅក្នុងអថេរបណ្តោះអាសន្ន។រលាយរហូតដល់កន្លែងត្រឹមត្រូវសម្រាប់វាត្រូវបានរកឃើញ។
            // នៅពេលយើងធ្វើដំណើរទៅមុខសូមចម្លងរាល់ធាតុឆ្លងកាត់ទៅក្នុងរន្ធដោតមុន។
            // ចុងបញ្ចប់ចម្លងទិន្នន័យពីអថេរបណ្តោះអាសន្នទៅក្នុងរន្ធដែលនៅសល់។
            // វិធីសាស្ត្រនេះល្អណាស់។
            // គោលការណ៍គោលបានបង្ហាញពីការសម្តែងប្រសើរជាងបន្តិចជាមួយនឹងវិធីសាស្ត្រទី ២ ។
            //
            // វិធីសាស្រ្តទាំងអស់ត្រូវបានកំណត់ជាគំរូហើយទី ៣ បានបង្ហាញលទ្ធផលល្អបំផុត។ដូច្នេះយើងជ្រើសរើសយកមួយនោះ។
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // ស្ថានភាពកម្រិតមធ្យមនៃដំណើរការបញ្ចូលតែងតែត្រូវបានតាមដានដោយ `hole` ដែលបម្រើគោលបំណងពីរ៖
            // 1. ការពារភាពសុចរិតនៃ `v` ពី panics ក្នុង `is_less` ។
            // 2. បំពេញរន្ធដែលនៅសល់នៅក្នុង `v` នៅចុងបញ្ចប់។
            //
            // សុវត្ថិភាព Panic៖
            //
            // ប្រសិនបើ `is_less` panics នៅចំណុចណាមួយក្នុងកំឡុងពេលដំណើរការនោះ `hole` នឹងត្រូវបានទម្លាក់ហើយបំពេញរន្ធនៅក្នុង `v` ជាមួយ `tmp` ដូច្នេះធានាថា `v` នៅតែកាន់កាប់វត្ថុទាំងអស់ដែលវាបានកាន់កាប់ដំបូង។
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ត្រូវបានទម្លាក់ហើយដូច្នេះចំលង `tmp` ទៅក្នុងរន្ធដែលនៅសេសសល់ក្នុង `v` ។
        }
    }

    // នៅពេលដែលការធ្លាក់ចុះ, ច្បាប់ចម្លងពី `src` ចូលទៅក្នុង `dest` ។
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// បញ្ចូលគ្នានូវការរត់មិនថយចុះ `v[..mid]` និង `v[mid..]` ដោយប្រើ `buf` ជាការផ្ទុកបណ្តោះអាសន្នហើយរក្សាទុកលទ្ធផលទៅជា `v[..]` ។
///
/// # Safety
///
/// ចំណិតទាំងពីរត្រូវតែមិនទទេហើយ `mid` ត្រូវតែស្ថិតនៅក្នុងព្រំដែន។
/// សតិបណ្ដោះអាសន្ន `buf` ត្រូវតែមានរយៈពេលយូរដើម្បីកាន់ច្បាប់ចម្លងខ្លីៗ។
/// ដូចគ្នានេះផងដែរ `T` មិនត្រូវជាប្រភេទទំហំសូន្យទេ។
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ដំណើរការបញ្ចូលគ្នាជាលើកដំបូងដែលចម្លងចូលទៅក្នុង `buf` រត់ខ្លី។
    // បន្ទាប់មកវាតាមដានការរត់ដែលបានចម្លងថ្មីនិងការរត់ទៅមុខកាន់តែវែង (ឬថយក្រោយ) ដោយប្រៀបធៀបធាតុដែលមិនត្រូវបានគិតបន្ទាប់របស់ពួកគេហើយចម្លងធាតុតូចជាង (ឬធំជាង) ទៅក្នុង `v` ។
    //
    // ដរាបណាការរត់ខ្លីត្រូវបានប្រើប្រាស់ពេញលេញដំណើរការត្រូវបានធ្វើ។ប្រសិនបើការរត់យូរជាងមុនត្រូវបានគេប្រើមុន, បន្ទាប់មកយើងត្រូវតែចម្លងអ្វីដែលនៅសល់នៃការរត់ខ្លីទៅក្នុងរន្ធដែលនៅសល់នៅក្នុង `v` ។
    //
    // ស្ថានភាពកម្រិតមធ្យមនៃដំណើរការតែងតែត្រូវបានតាមដានដោយ `hole` ដែលបម្រើគោលបំណងពីរ៖
    // 1. ការពារភាពសុចរិតនៃ `v` ពី panics ក្នុង `is_less` ។
    // 2. បំពេញរន្ធដែលនៅសល់នៅក្នុង `v` ប្រសិនបើការរត់យូរជាងមុនត្រូវបានគេប្រើប្រាស់មុន។
    //
    // សុវត្ថិភាព Panic៖
    //
    // ប្រសិនបើ `is_less` panics នៅចំណុចណាមួយក្នុងកំឡុងពេលដំណើរការនោះ `hole` នឹងត្រូវបានទម្លាក់និងបំពេញប្រហោងនៅក្នុង `v` ជាមួយនឹងជួរដែលមិនមាននៅក្នុង `buf` ដូច្នេះធានាថា `v` នៅតែកាន់កាប់វត្ថុទាំងអស់ដែលវាបានកាន់កាប់ដំបូង។
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // ការរត់ខាងឆ្វេងគឺខ្លីជាង។
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // ដំបូងអ្នកចង្អុលបង្ហាញទាំងនេះចង្អុលបង្ហាញពីការចាប់ផ្តើមនៃអារេរបស់ពួកគេ។
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // ប្រើប្រាស់ផ្នែកខាងតិចជាង។
            // ប្រសិនបើស្មើសូមចូលចិត្តការរត់ខាងឆ្វេងដើម្បីរក្សាស្ថេរភាព។
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // ការរត់ត្រឹមត្រូវគឺខ្លីជាង។
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // ដំបូងអ្នកចង្អុលបង្ហាញទាំងនេះចង្អុលបង្ហាញចុងបញ្ចប់នៃអារេរបស់ពួកគេ។
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // ប្រើប្រាស់ផ្នែកខាងធំជាង។
            // បើស្មើគឺចូលចិត្តរត់ត្រឹមត្រូវដើម្បីរក្សាស្ថេរភាព។
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // ទីបំផុត `hole` ត្រូវបានទម្លាក់។
    // ប្រសិនបើការរត់ខ្លីមិនត្រូវបានប្រើប្រាស់ពេញលេញអ្វីដែលនៅសល់នឹងត្រូវបានចម្លងចូលទៅក្នុងរន្ធ `v` ។

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // នៅពេលទម្លាក់សូមចម្លងជួរ `start..end` ទៅជា `dest..` ។
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` មិនមែនជាប្រភេទសូន្យទេដូច្នេះវាមិនអីទេក្នុងការបែងចែកតាមទំហំរបស់វា។
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ការរួមបញ្ចូលគ្នានេះផ្តល់នូវគំនិតមួយចំនួន (ប៉ុន្តែមិនមែនទាំងអស់) ពីធីមថេតដែលត្រូវបានពិពណ៌នាលម្អិត [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) ។
///
///
/// ក្បួនដោះស្រាយកំណត់យ៉ាងតឹងរ៉ឹងពីកំណើតនិងមិនចុះក្រោមដែលត្រូវបានគេហៅថាដំណើរការធម្មជាតិ។មិនទាន់មានការដាក់បញ្ចូលគ្នាជាជួរនៅឡើយទេ។
/// ការរត់ថ្មីដែលបានរកឃើញនីមួយៗត្រូវបានរុញទៅលើជណ្តើរហើយបន្ទាប់មកគូនៃការរត់ជិតគ្នាមួយចំនួនត្រូវបានបញ្ចូលគ្នារហូតដល់ការលុកលុយទាំងពីរត្រូវបានពេញចិត្ត:
///
/// 1. សម្រាប់រាល់ `i` ក្នុង `1..runs.len()`៖ `runs[i - 1].len > runs[i].len`
/// 2. សម្រាប់រាល់ `i` ក្នុង `2..runs.len()`៖ `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// ការលុកលុយធានាថាពេលវេលាដំណើរការសរុបគឺ *O*(*n*\*log(* n*)) ដែលជាករណីដ៏អាក្រក់បំផុត) ។
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ចំណិតរហូតដល់ប្រវែងនេះត្រូវបានតម្រៀបដោយប្រើតម្រៀបបញ្ចូល។
    const MAX_INSERTION: usize = 20;
    // ការរត់ខ្លីបំផុតត្រូវបានពង្រីកដោយប្រើតម្រៀបបញ្ចូលដើម្បីពង្រីកយ៉ាងហោចណាស់ធាតុជាច្រើននេះ។
    const MIN_RUN: usize = 10;

    // ការតម្រៀបមិនមានអាកប្បកិរិយាដែលមានអត្ថន័យលើប្រភេទដែលមានទំហំសូន្យទេ។
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // អារេខ្លីទទួលបានតំរៀបតាមកន្លែងតាមរយៈការបញ្ចូលដើម្បីជៀសវាងការបែងចែក។
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // បែងចែកសតិបណ្ដោះអាសន្នដើម្បីប្រើជាអង្គចងចាំកោស។យើងរក្សាប្រវែង ០ ដូច្នេះយើងអាចរក្សាទុកនូវមាតិការនៃ `v` ច្បាប់ចម្លងរាក់ ៗ ដោយមិនប្រថុយនឹង dtors រត់លើច្បាប់ចម្លងទេប្រសិនបើ `is_less` panics ។
    //
    // នៅពេលបញ្ចូលគ្នានូវការរត់ដែលបានតម្រៀបជាពីរសតិបណ្ដោះអាសន្ននេះផ្ទុកនូវការរត់ខ្លីជាងដែលតែងតែមានប្រវែងយ៉ាងច្រើនបំផុតដល់ `len / 2` ។
    //
    let mut buf = Vec::with_capacity(len / 2);

    // ក្នុងគោលបំណងដើម្បីកំណត់អត្តសញ្ញាណធម្មជាតិនៅ `v` រត់យើងបានឆ្លងកាត់វា backwards ។
    // វាហាក់ដូចជាការសម្រេចចិត្តចម្លែកប៉ុន្តែពិចារណាលើការពិតដែលការរួមបញ្ចូលគ្នាច្រើនតែដើរផ្ទុយពី (forwards) ។
    // យោងទៅតាមគោលការរួមបញ្ចូលទៅមុខគឺលឿនជាងការច្របាច់ថយក្រោយ។
    // ដើម្បីសន្និដ្ឋានការកំណត់អត្តសញ្ញាណរត់ដោយឆ្លងកាត់ថយក្រោយធ្វើអោយប្រសើរឡើងនូវការអនុវត្ត។
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // ស្វែងរកការរត់ធម្មជាតិបន្ទាប់ហើយបញ្ច្រាសវាប្រសិនបើវាចុះយ៉ាងតឹងរ៉ឹង។
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // បញ្ចូលធាតុបន្ថែមមួយចំនួនទៅក្នុងដំណើរការប្រសិនបើវាខ្លីពេក។
        // ការបញ្ចូលប្រភេទបញ្ចូលលឿនជាងការបញ្ចូលចូលគ្នាក្នុងលំដាប់ខ្លីដូច្នេះនេះធ្វើអោយប្រសើរឡើងនូវការអនុវត្ត។
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // រុញការរត់នេះទៅលើជង់។
        runs.push(Run { start, len: end - start });
        end = start;

        // បញ្ចូលគ្នានូវគូមួយចំនួនដែលរត់ជាប់គ្នាដើម្បីបំពេញការលុកលុយ។
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // ទីបំផុតការរត់មួយត្រូវតែស្ថិតនៅក្នុងជង់។
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // ពិនិត្យជង់នៃការរត់និងកំណត់គូរត់បន្ទាប់ដើម្បីបញ្ចូលគ្នា។
    // កាន់តែពិសេសប្រសិនបើ `Some(r)` ត្រូវបានត្រឡប់មកវិញនោះមានន័យថា `runs[r]` និង `runs[r + 1]` ត្រូវតែបញ្ចូលគ្នាបន្ទាប់។
    // ប្រសិនបើក្បួនដោះស្រាយគួរតែបន្តបង្កើតការរត់ថ្មីជំនួសវិញ `None` ត្រូវបានត្រឡប់មកវិញ។
    //
    // TimSort គឺមិនសូវល្បីល្បាញសម្រាប់ការអនុវត្តកំហុសរបស់វាដូចដែលបានពិពណ៌នានៅទីនេះ៖
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // ចំណុចសំខាន់នៃរឿងគឺយើងត្រូវអនុវត្តការលុកលុយនៅលើកំពូលទាំងបួនរត់លើជង់។
    // ការបង្ខំឱ្យពួកគេនៅលើកំពូលទាំងបីគឺមិនគ្រប់គ្រាន់ទេដើម្បីធានាថាអ្នកឈ្លានពាននឹងនៅតែកាន់សម្រាប់ *ទាំងអស់* រត់នៅក្នុងជង់។
    //
    // មុខងារនេះត្រួតពិនិត្យយ៉ាងត្រឹមត្រូវនូវវិក្កយបត្រសម្រាប់ដំណើរការកំពូលទាំងបួន។
    // លើសពីនេះទៀតប្រសិនបើដំណើរការកំពូលចាប់ផ្តើមនៅសន្ទស្សន៍ 0 វានឹងទាមទារប្រតិបត្តិការបញ្ចូលគ្នាជានិច្ចរហូតដល់ជង់ត្រូវបានដួលរលំទាំងស្រុងដើម្បីបញ្ចប់ការតម្រៀប។
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}