#![stable(feature = "wake_trait", since = "1.51.0")]
//! ប្រភេទនិង Traits សម្រាប់ធ្វើការជាមួយភារកិច្ចអសមកាល។
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// ការអនុវត្តនៃការភ្ញាក់ភារកិច្ចលើអ្នកប្រតិបត្តិម្នាក់។
///
/// trait នេះអាចត្រូវបានប្រើដើម្បីបង្កើត [`Waker`] មួយ។
/// ប្រតិបត្តិអាចកំណត់ការអនុវត្ត trait នេះហើយប្រើវាដើម្បីសាងសង់ Waker មួយដើម្បីឆ្លងទៅភារកិច្ចដែលត្រូវប្រតិបត្តិនៅលើប្រតិបត្តិនោះ។
///
/// trait នេះគឺជាជម្រើសនៃការចងចាំនិងមានសុវត្ថិភាពក្នុងការបង្កើត [`RawWaker`] ។
/// វាគាំទ្រការរចនាអ្នកប្រតិបត្តិទូទៅដែលទិន្នន័យដែលត្រូវបានប្រើដើម្បីដាស់ភារកិច្ចត្រូវបានរក្សាទុកនៅក្នុងអេចអេស [`Arc`]។
/// ប្រតិបត្តិខ្លះ (ជាពិសេសសម្រាប់ប្រព័ន្ធដែលបានបង្កប់) មិនអាចប្រើ API នេះបានទេដែលនេះជាមូលហេតុដែល [`RawWaker`] មានជាជម្រើសសម្រាប់ប្រព័ន្ធទាំងនោះ។
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// មុខងារ `block_on` មូលដ្ឋានដែលយក future ហើយដំណើរការវាឱ្យចប់នៅលើខ្សែស្រឡាយបច្ចុប្បន្ន។
///
/// **Note:** ឧទាហរណ៍នេះជួញដូរភាពត្រឹមត្រូវសម្រាប់ភាពសាមញ្ញ។
/// ដើម្បីបងា្ករការជាប់គាំងការអនុវត្តន៍ថ្នាក់ផលិតកម្មក៏នឹងត្រូវការដោះស្រាយការហៅទូរស័ព្ទកម្រិតមធ្យមទៅកាន់ `thread::unpark` ក៏ដូចជាការអំពាវនាវជារួមផងដែរ។
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// អ្នកតាក់តែងដែលដាស់ខ្សែស្រឡាយបច្ចុប្បន្ននៅពេលហៅ។
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// ដំណើរការ future ដើម្បីបញ្ចប់លើខ្សែស្រឡាយបច្ចុប្បន្ន។
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // ដាក់កូដ future ដូច្នេះវាអាចត្រូវបានគេស្ទង់មតិ។
///     let mut fut = Box::pin(fut);
///
///     // បង្កើតបរិបទថ្មីដែលត្រូវបញ្ជូនទៅ future ។
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // ដំណើរការ future ដើម្បីបញ្ចប់។
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// ភ្ញាក់ពីភារកិច្ចនេះ។
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// ដាស់ភារកិច្ចនេះដោយមិនប្រើអ្នកបង្កើត។
    ///
    /// ប្រសិនបើអ្នកប្រតិបត្តិម្នាក់គាំទ្រវិធីដែលមានតម្លៃថោកជាងដើម្បីភ្ញាក់ដោយមិនប្រើអ្នកធ្វើវាគួរតែបដិសេធវិធីនេះ។
    /// តាមលំនាំដើមវាក្លូន [`Arc`] ហើយហៅ [`wake`] នៅលើក្លូន។
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // សុវត្ថិភាព: នេះគឺមានសុវត្ថិភាពពីព្រោះអ្នកផលិតឆៅសាងសង់ដោយសុវត្ថិភាព
        // RawWaker មកពី Arc<W>។
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: មុខងារឯកជននេះសម្រាប់សាងសង់ RawWaker ត្រូវបានប្រើជាជាង
// បញ្ចូលវាទៅក្នុង `From<Arc<W>> for RawWaker` ដើម្បីធានាថាសុវត្ថិភាពរបស់ `From<Arc<W>> for Waker` មិនពឹងផ្អែកលើការបញ្ជូន trait ត្រឹមត្រូវទេផ្ទុយទៅវិញទាំងពីរបង្កប់ន័យហៅមុខងារនេះដោយផ្ទាល់និងជាក់លាក់។
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // បង្កើនចំនួនសេចក្ដីយោងនៃធ្នូដើម្បីក្លូនវា។
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // ភ្ញាក់ដោយតម្លៃដោយផ្លាស់ប្តូរធ្នូទៅក្នុងមុខងារ Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // ភ្ញាក់ដោយយោងរុំអ្នកតាក់ស៊ីនៅក្នុងសៀវភៅដៃដោយដៃដើម្បីជៀសវាងការទម្លាក់វា
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // បន្ថយចំនួនយោងនៃធ្នូនៅពេលធ្លាក់ចុះ
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}