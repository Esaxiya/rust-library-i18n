//! # បណ្ណាល័យបែងចែកនិងប្រមូលស្នូល Rust
//!
//! បណ្ណាល័យនេះផ្តល់នូវការចង្អុលបង្ហាញនិងការប្រមូលដ៏ឆ្លាតវៃសម្រាប់ការគ្រប់គ្រងគុណតម្លៃដែលបានបែងចែក។
//!
//! បណ្ណាល័យនេះដូចជា libcore ជាទូទៅមិនចាំបាច់ត្រូវបានប្រើដោយផ្ទាល់ទេពីព្រោះមាតិការបស់វាត្រូវបាននាំចេញជាថ្មីនៅក្នុង [`std` crate](../std/index.html) ។
//! Crates ដែលប្រើគុណលក្ខណៈ `#![no_std]` ទោះជាយ៉ាងណានឹងមិនពឹងផ្អែកលើ `std` ទេដូច្នេះពួកគេនឹងប្រើ crate ជំនួសវិញ។
//!
//! ## តម្លៃប្រអប់
//!
//! ប្រភេទ [`Box`] គឺជាប្រភេទទ្រនិចឆ្លាត។អាចមានម្ចាស់តែមួយនៃ [`Box`] ហើយម្ចាស់អាចសម្រេចចិត្តផ្លាស់ប្តូរមាតិកាដែលរស់នៅលើគំនរ។
//!
//! ប្រភេទនេះអាចត្រូវបានបញ្ជូនក្នុងចំណោមខ្សែស្រឡាយប្រកបដោយប្រសិទ្ធភាពព្រោះទំហំនៃតម្លៃ `Box` គឺដូចគ្នានឹងទ្រនិចដែរ។
//! រចនាសម្ព័ន្ធទិន្នន័យដូចមែកធាងជារឿយៗត្រូវបានសាងសង់ដោយប្រអប់ពីព្រោះថ្នាំងនីមួយៗជារឿយៗមានម្ចាស់តែមួយគឺមេ។
//!
//! ## សេចក្តីយោងរាប់ចំណុចចង្អុលបង្ហាញ
//!
//! ប្រភេទ [`Rc`] គឺជាប្រភេទទ្រនិចដែលត្រូវបានរាប់ដោយមិនមានខ្សែស្រឡាយដែលត្រូវបានបម្រុងទុកសម្រាប់ចែករំលែកការចងចាំនៅក្នុងខ្សែស្រឡាយ។
//! ទ្រនិច [`Rc`] រុំប្រភេទ `T` ហើយអនុញ្ញាតឱ្យចូលប្រើ `&T` ដែលជាឯកសារយោងរួម។
//!
//! ប្រភេទនេះមានប្រយោជន៍នៅពេលទទួលមរតកភាពផ្លាស់ប្តូរ (ដូចជាការប្រើប្រាស់ [`Box`]) គឺជាឧបសគ្គសម្រាប់កម្មវិធីហើយជារឿយៗត្រូវបានផ្គូរផ្គងជាមួយប្រភេទ [`Cell`] ឬ [`RefCell`] ដើម្បីអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរ។
//!
//!
//! ## សេចក្តីយោងរាប់អាតូម
//!
//! ប្រភេទ [`Arc`] គឺជាប្រភេទខ្សែស្រឡាយដែលស្មើនឹង [`Rc`] ។វាផ្តល់មុខងារដូចគ្នាទាំងអស់របស់ [`Rc`] លើកលែងតែវាតម្រូវឱ្យមានប្រភេទ `T` ដែលអាចផ្ទុកបាន។
//! លើសពីនេះទៀត [`Arc<T>`][`Arc`] អាចផ្ញើបានដោយខ្លួនឯងខណៈពេលដែល [`Rc<T>`][`Rc`] មិន។
//!
//! ប្រភេទនេះអនុញ្ញាតឱ្យមានការចូលប្រើរួមគ្នាចំពោះទិន្នន័យដែលមានហើយជារឿយៗត្រូវបានផ្គូរផ្គងជាមួយការធ្វើសមកាលកម្មដូចជា mutexes ដើម្បីអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរធនធានដែលបានចែករំលែក។
//!
//! ## Collections
//!
//! ការអនុវត្តរចនាសម្ព័ន្ធទិន្នន័យគោលបំណងទូទៅបំផុតត្រូវបានកំណត់នៅក្នុងបណ្ណាល័យនេះ។ពួកវាត្រូវបាននាំចេញម្តងទៀតតាមរយៈ [standard collections library](../std/collections/index.html) ។
//!
//! ## ចំណុចប្រទាក់ហ៊ា
//!
//! ម៉ូឌុល [`alloc`](alloc/index.html) កំណត់ចំណុចប្រទាក់កម្រិតទាបទៅអ្នកបែងចែកសកលលំនាំដើម។វាមិនត្រូវគ្នាជាមួយ API អ្នកបែងចែក libc ទេ។
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// តាមបច្ចេកទេសនេះគឺជាកំហុសមួយនៅក្នុង rustdoc: rustdoc មើលឃើញឯកសារនៅលើប្លុក `#[lang = slice_alloc]` គឺសម្រាប់ `&[T]` ដែលមានឯកសារដោយប្រើលក្ខណៈពិសេសនេះនៅក្នុង `core` ហើយឆ្កួតដែលទ្វារពិសេសមិនត្រូវបានបើក។
// តាមឧត្ដមគតិវានឹងមិនពិនិត្យមើលច្រកទ្វារលក្ខណៈពិសេសសម្រាប់ឯកសារពី crates ផ្សេងទៀតទេប៉ុន្តែដោយសារតែវាអាចលេចឡើងសម្រាប់ធាតុឡង់ប៉ុណ្ណោះវាហាក់ដូចជាមិនមានតម្លៃទេ។
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// អនុញ្ញាតឱ្យសាកល្បងបណ្ណាល័យនេះ

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// ម៉ូឌុលជាមួយម៉ាក្រូផ្ទៃក្នុងត្រូវបានប្រើដោយម៉ូឌុលផ្សេងទៀត (ត្រូវការបញ្ចូលមុនម៉ូឌុលផ្សេងទៀត) ។
#[macro_use]
mod macros;

// ហ៊ាផ្តល់ជូនសម្រាប់យុទ្ធសាស្ត្របែងចែកកម្រិតទាប

pub mod alloc;

// ប្រភេទបឋមដោយប្រើគំនរខាងលើ

// ត្រូវការកំណត់វិមាត្រ mod ពី `boxed.rs` ដើម្បីចៀសវាងការចម្លងធាតុដែលជាប់គ្នានៅពេលសាងសង់ក្នុងការសាកល្បង cfg;ប៉ុន្តែក៏ត្រូវអនុញ្ញាតឱ្យលេខកូដមានសេចក្តីប្រកាស `use boxed::Box;` ផងដែរ។
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}