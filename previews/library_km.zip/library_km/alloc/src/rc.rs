//! ចង្អុលរាប់ការរាប់ជាខ្សែតែមួយ។'Rc' តំណាងឱ្យ 'សេចក្តីយោង
//! Counted'.
//!
//! ប្រភេទ [`Rc<T>`][`Rc`] ផ្តល់នូវកម្មសិទ្ធិរួមគ្នានៃតម្លៃនៃប្រភេទ `T` ដែលបានបម្រុងទុកនៅក្នុងគំនរ។
//! ការហៅ [`clone`][clone] នៅលើ [`Rc`] បង្កើតទ្រនិចថ្មីទៅនឹងការបែងចែកដូចគ្នានៅក្នុងគំនរ។
//! នៅពេលដែលទ្រនិច [`Rc`] ចុងក្រោយទៅនឹងការបែងចែកដែលបានផ្តល់ឱ្យត្រូវបានបំផ្លាញតម្លៃដែលបានរក្សាទុកនៅក្នុងការបែងចែកនោះ (ជាញឹកញាប់សំដៅទៅលើ "inner value") ក៏ត្រូវបានធ្លាក់ចុះដែរ។
//!
//! ឯកសារយោងដែលបានចែករំលែកនៅក្នុង Rust មិនផ្លាស់ប្តូរការផ្លាស់ប្តូរតាមលំនាំដើមហើយ [`Rc`] មិនមានករណីលើកលែងនោះទេ៖ ជាទូទៅអ្នកមិនអាចទទួលបានឯកសារយោងដែលអាចផ្លាស់ប្តូរបានចំពោះអ្វីមួយនៅក្នុង [`Rc`] ទេ។
//! ប្រសិនបើអ្នកត្រូវការការផ្លាស់ប្តូរបានដាក់ [`Cell`] ឬ [`RefCell`] នៅខាងក្នុង [`Rc`];សូមមើល [an example of mutability inside an `Rc`][mutability] ។
//!
//! [`Rc`] ប្រើដែលមិនមែនជាការរាប់ជាឯកសារយោងនុយក្លេអ៊ែរ។
//! នេះមានន័យថាផ្នែកខាងលើទាបណាស់ប៉ុន្តែ [`Rc`] មិនអាចផ្ញើររវាងខ្សែស្រឡាយបានទេហើយដូច្នេះ [`Rc`] មិនអនុវត្ត [`Send`][send] ទេ។
//! ជាលទ្ធផលអ្នកចងក្រង Rust នឹងពិនិត្យមើល *នៅពេលចងក្រង* ដែលអ្នកមិនផ្ញើ [`Rc`] រវាងខ្សែស្រឡាយ។
//! ប្រសិនបើអ្នកត្រូវការរាប់ពហុខ្សែនិងការរាប់យោងអាតូមិកសូមប្រើ [`sync::Arc`][arc] ។
//!
//! វិធីសាស្ត្រ [`downgrade`][downgrade] អាចត្រូវបានប្រើដើម្បីបង្កើតទ្រនិច [`Weak`] ដែលមិនមែនជាកម្មសិទ្ធិ។
//! ទ្រនិច [`Weak`] អាចត្រូវបាន [`ធ្វើឱ្យប្រសើរ`][ធ្វើឱ្យប្រសើរឡើង] ឃទៅ [`Rc`] ប៉ុន្តែនេះនឹងត្រឡប់ [`None`] ប្រសិនបើតម្លៃដែលបានរក្សាទុកនៅក្នុងការបែងចែកត្រូវបានទម្លាក់រួចហើយ។
//! និយាយម៉្យាងទៀតអ្នកចង្អុល `Weak` មិនរក្សាតម្លៃនៅក្នុងការបែងចែកឱ្យនៅរស់ទេ។ទោះជាយ៉ាងណា, ពួកគេ *ធ្វើ* រក្សាការបម្រុងទុក (ហាងគាំទ្រសម្រាប់តម្លៃខាងក្នុង) នៅរស់។
//!
//! វដ្តរវាងអ្នកចង្អុល [`Rc`] នឹងមិនត្រូវបានដោះស្រាយទេ។
//! សម្រាប់ហេតុផលនេះ [`Weak`] ត្រូវបានប្រើដើម្បីបំបែកវដ្ត។
//! ឧទាហរណ៍ដើមឈើមួយអាចមានចំណុចចង្អុល [`Rc`] ខ្លាំងពីថ្នាំងឪពុកម្តាយដល់កូនហើយចំណុច [`Weak`] ពីកូន ៗ ត្រឡប់ទៅឪពុកម្តាយវិញ។
//!
//! `Rc<T>` ការបដិសេធដោយស្វ័យប្រវត្តិចំពោះ `T` (តាមរយៈ [`Deref`] trait) ដូច្នេះអ្នកអាចហៅវិធី `ធី` លើតម្លៃនៃប្រភេទ [`Rc<T>`][`Rc`] ។
//! ដើម្បីជៀសវាងការប៉ះទង្គិចគ្នាជាមួយ `វិធីសាស្រ្តឈ្មោះរបស់ T` វិធីសាស្រ្តនៃការ [`Rc<T>`][`Rc`] ខ្លួនវាត្រូវបានផ្សារភ្ជាប់មុខងារ, ដែលហៅថាការប្រើ [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `រ៉ូ<T>ការប្រតិបត្តិរបស់`traits ដូចជា `Clone` ក៏អាចត្រូវបានហៅដោយប្រើវាក្យសម្ព័ន្ធដែលមានសមត្ថភាពពេញលេញផងដែរ។
//! មនុស្សខ្លះចូលចិត្តប្រើវាក្យសម្ពន្ធដែលមានលក្ខណៈសម្បត្តិគ្រប់គ្រាន់ខណៈពេលដែលអ្នកផ្សេងទៀតចូលចិត្តប្រើវាក្យសម្ព័ន្ធវិធីហៅ។
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // សំយោគវិធីសាស្រ្តហៅ
//! let rc2 = rc.clone();
//! // វាក្យសម្ព័ន្ធដែលមានសមត្ថភាពពេញលេញ
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] មិនបដិសេធដោយស្វ័យប្រវត្តិចំពោះ `T` ទេពីព្រោះតម្លៃខាងក្នុងអាចត្រូវបានទម្លាក់រួចហើយ។
//!
//! # ក្លូនយោង
//!
//! ការបង្កើតឯកសារយោងថ្មីចំពោះការបែងចែកដូចគ្នានឹងការចង្អុលបង្ហាញចង្អុលបង្ហាញទ្រនិចចង្អុលត្រូវបានធ្វើដោយប្រើ `Clone` trait អនុវត្តសម្រាប់ [`Rc<T>`][`Rc`] និង [`Weak<T>`][`Weak`] ។
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // វាក្យសម្ពន្ធទាំងពីរខាងក្រោមគឺស្មើគ្នា។
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a និង b ទាំងពីរចង្អុលទៅទីតាំងនៃការចងចាំដូចគ្នានឹង foo ។
//! ```
//!
//! វាក្យសម្ព័ន្ធ `Rc::clone(&from)` គឺមានលក្ខណៈពិសេសបំផុតពីព្រោះវាបញ្ជាក់អត្ថន័យនៃលេខកូដកាន់តែច្បាស់។
//! ក្នុងឧទាហរណ៍ខាងលើវាក្យសម្ព័ន្ធនេះធ្វើឱ្យវាកាន់តែងាយស្រួលដើម្បីមើលថាកូដនេះកំពុងបង្កើតឯកសារយោងថ្មីជាជាងការចម្លងមាតិកាទាំងមូលនៃហ្វុ។
//!
//! # Examples
//!
//! ពិចារណាលើសេណារីយ៉ូមួយដែលសំណុំនៃ 'Gadget`s ត្រូវបានគ្រប់គ្រងដោយ `Owner` ដែលបានផ្តល់ឱ្យ។
//! យើងចង់អោយចំនុចរបស់យើងទៅដល់ចំនុច `Owner` របស់ពួកគេ។យើងមិនអាចធ្វើវាដោយភាពជាម្ចាស់តែមួយបានទេពីព្រោះឧបករណ៍ច្រើនជាងមួយអាចជាកម្មសិទ្ធិរបស់ `Owner` តែមួយ។
//! [`Rc`] អនុញ្ញាតឱ្យយើងចែករំលែក `Owner` រវាង `ធាតុក្រាហ្វិក multiple ច្រើននិងមាន `Owner` នៅតែត្រូវបានបម្រុងទុកដរាបណាចំណុច `Gadget` នៅវា។
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... វាលផ្សេងទៀត
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... វាលផ្សេងទៀត
//! }
//!
//! fn main() {
//!     // បង្កើតការរាប់ `Owner` យោង។
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // បង្កើត `ធាតុក្រាហ្វិក` ដែលជាកម្មសិទ្ធិរបស់ `gadget_owner` ។
//!     // ក្លូន `Rc<Owner>` ផ្តល់ឱ្យយើងនូវទ្រនិចថ្មីមួយទៅនឹងការបែងចែក `Owner` ដូចគ្នាបង្កើនចំនួនសេចក្តីយោងនៅក្នុងដំណើរការ។
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // បោះចោលអថេរ `gadget_owner` ក្នុងតំបន់របស់យើង។
//!     drop(gadget_owner);
//!
//!     // ទោះបីជាទម្លាក់ `gadget_owner` ក៏ដោយយើងនៅតែអាចបោះពុម្ភឈ្មោះ `Owner` នៃ `Gadget`s បាន។
//!     // នេះក៏ព្រោះតែយើងបានទម្លាក់ `Rc<Owner>` តែមួយប៉ុណ្ណោះមិនមែន `Owner` វាចង្អុលបង្ហាញទេ។
//!     // ដរាបណាមានចំនុច `Rc<Owner>` ផ្សេងទៀតនៅឯការបែងចែក `Owner` តែមួយវានឹងនៅតែបន្តរស់។
//!     // ការព្យាករណ៍វាល `gadget1.owner.name` ដំណើរការពីព្រោះ `Rc<Owner>` យោងដោយស្វ័យប្រវត្តិទៅ `Owner` ។
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // នៅចុងបញ្ចប់នៃមុខងារ `gadget1` និង `gadget2` ត្រូវបានបំផ្លាញហើយជាមួយពួកគេឯកសារយោងដែលបានរាប់ចុងក្រោយទៅ `Owner` របស់យើង។
//!     // ឥឡូវនេះ Gadget Man ក៏ត្រូវបានបំផ្លាញដែរ។
//!     //
//! }
//! ```
//!
//! ប្រសិនបើតម្រូវការរបស់យើងផ្លាស់ប្តូរហើយយើងក៏ត្រូវមានលទ្ធភាពឆ្លងកាត់ពី `Owner` ទៅ `Gadget` យើងនឹងជួបបញ្ហា។
//! ទ្រនិច [`Rc`] ពី `Owner` ដល់ `Gadget` ណែនាំវដ្តមួយ។
//! នេះមានន័យថាចំនួនឯកសារយោងរបស់ពួកគេមិនអាចឈានដល់លេខ ០ ហើយការបែងចែកនឹងមិនត្រូវបានបំផ្លាញឡើយ៖
//! ការលេចធ្លាយសតិ។ដើម្បីទទួលបាននៅជុំវិញនេះយើងអាចប្រើចង្អុល [`Weak`] ។
//!
//! តាមពិត Rust ពិតជាមានការលំបាកក្នុងការផលិតរង្វិលជុំនេះជាមុន។ដើម្បីបញ្ចប់នូវគុណតម្លៃពីរដែលចង្អុលបង្ហាញពីគ្នាទៅវិញទៅមកមួយក្នុងចំណោមនោះត្រូវការផ្លាស់ប្តូរគ្នាទៅវិញទៅមក។
//! នេះគឺជាការលំបាកពីព្រោះ [`Rc`] ពង្រឹងសុវត្ថិភាពនៃការចងចាំដោយគ្រាន់តែផ្តល់នូវឯកសារយោងដែលបានចែកចាយទៅនឹងតម្លៃដែលវាបានរុំហើយទាំងនេះមិនអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរដោយផ្ទាល់ទេ។
//! យើងត្រូវត្បាញផ្នែកមួយនៃតម្លៃដែលយើងចង់ផ្លាស់ប្តូរនៅក្នុង [`RefCell`] ដែលផ្តល់នូវការផ្លាស់ប្តូរផ្នែកខាងក្នុង *: វិធីសាស្រ្តដើម្បីសម្រេចបាននូវការផ្លាស់ប្តូរគ្នាតាមរយៈឯកសារយោងរួម។
//! [`RefCell`] អនុវត្តច្បាប់ខ្ចីប្រាក់របស់ Rust នៅពេលដំណើរការ។
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... វាលផ្សេងទៀត
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... វាលផ្សេងទៀត
//! }
//!
//! fn main() {
//!     // បង្កើតការរាប់ `Owner` យោង។
//!     // ចំណាំថាយើងបានដាក់ vector របស់ `ម្ចាស់` របស់ហ្គាឌិន inside នៅខាងក្នុង `RefCell` ដូច្នេះយើងអាចផ្លាស់ប្តូរវាបានតាមរយៈឯកសារយោងរួម។
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // បង្កើត `ធាតុក្រាហ្វិក` ដែលជាកម្មសិទ្ធិរបស់ `gadget_owner` ដូចពីមុន។
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // បន្ថែម `ធាតុក្រាហ្វិក` ទៅ `Owner` របស់ពួកគេ។
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ប្រាក់កម្ចីឌីណាមិចបញ្ចប់នៅទីនេះ
//!     }
//!
//!     // ងាយយល់ពីឧបករណ៍របស់យើងបោះពុម្ពពត៌មានលំអិតរបស់ពួកគេចេញ។
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` គឺជា `Weak<Gadget>` ។
//!         // ដោយសារអ្នកចង្អុលបង្ហាញ `Weak` មិនអាចធានាថាការបែងចែកនៅតែមាននៅឡើយទេយើងត្រូវហៅទូរស័ព្ទ `upgrade` ដែលត្រលប់មកវិញនូវ `Option<Rc<Gadget>>` ។
//!         //
//!         //
//!         // ក្នុងករណីនេះយើងដឹងថាការបែងចែកនៅតែមានដូច្នេះយើងគ្រាន់តែ `unwrap``Option` X ។
//!         // នៅក្នុងកម្មវិធីដែលមានភាពស្មុគស្មាញជាងនេះអ្នកប្រហែលជាត្រូវការការដោះស្រាយកំហុសប្រកបដោយគុណប្រយោជន៍សម្រាប់លទ្ធផល `None` ។
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // នៅចុងបញ្ចប់នៃមុខងារ `gadget_owner`, `gadget1`, និង `gadget2` ត្រូវបានបំផ្លាញ។
//!     // ឥឡូវនេះមិនមានចង្អុលបង្ហាញ (`Rc`) ខ្លាំងចំពោះឧបករណ៍ទេដូច្នេះពួកគេត្រូវបានបំផ្លាញ។
//!     // នេះបញ្ជាក់ការរាប់យោងលើហ្គីតាមេដូច្នេះគាត់ក៏ត្រូវបានបំផ្លាញដែរ។
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// នេះគឺជា repr(C) ទៅ future-ភស្តុតាងប្រឆាំងនឹងការតំរែតំរង់វាលដែលអាចរំខានដល់ [into|from]_raw() ប្រភេទខាងក្នុងដែលអាចដឹកជញ្ជូនបាន។
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ទ្រនិចរាប់ការរាប់ជាខ្សែតែមួយ។'Rc' តំណាងឱ្យ 'សេចក្តីយោង
/// Counted'.
///
/// សូមមើល [module-level documentation](./index.html) សម្រាប់ព័ត៌មានលម្អិត។
///
/// វិធីសាស្រ្តដែលមានស្រាប់នៃ `Rc` គឺជាមុខងារដែលជាប់ទាក់ទងទាំងអស់ដែលមានន័យថាអ្នកត្រូវហៅវាជាឧទាហរណ៍ [`Rc::get_mut(&mut value)`][get_mut] ជំនួសឱ្យ `value.get_mut()` ។
/// នេះជៀសវាងជម្លោះជាមួយវិធីសាស្រ្តនៃប្រភេទខាងក្នុង `T` ។
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // សុវត្ថិភាពនេះមិនអីទេពីព្រោះខណៈពេលដែលក្រេបនេះនៅរស់យើងធានាថាទ្រនិចខាងក្នុងមានសុពលភាព។
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// សាងសង់ `Rc<T>` ថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // មានទ្រនិចខ្សោយជាក់ស្តែងដែលគ្រប់គ្រងដោយអ្នកចង្អុលបង្ហាញខ្លាំងទាំងអស់ដែលធានាថាអ្នកបំផ្លាញខ្សោយមិនដែលចែកចាយការចែកចាយទេខណៈពេលដែលអ្នកបំផ្លាញខ្លាំងកំពុងរត់ទោះបីទ្រនិចខ្សោយត្រូវបានរក្សាទុកនៅខាងក្នុងខ្លាំងក៏ដោយ។
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// សាងសង់ `Rc<T>` ថ្មីដោយប្រើឯកសារយោងខ្សោយទៅខ្លួនវា។
    /// ការប៉ុនប៉ងធ្វើឱ្យប្រសើរឡើងនូវឯកសារយោងខ្សោយមុនពេលមុខងារនេះត្រឡប់មកវិញនឹងនាំឱ្យមានតំលៃ `None` ។
    ///
    /// ទោះយ៉ាងណាក៏ដោយឯកសារយោងខ្សោយអាចត្រូវបានក្លូនដោយសេរីនិងរក្សាទុកសម្រាប់ប្រើនៅពេលក្រោយ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... វាលច្រើនទៀត
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // សាងសង់ផ្នែកខាងក្នុងនៅក្នុងរដ្ឋ "uninitialized" ជាមួយនឹងឯកសារយោងខ្សោយមួយ។
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // វាសំខាន់ណាស់ដែលយើងមិនបោះបង់ចោលភាពជាម្ចាស់នៃទ្រនិចខ្សោយបើមិនដូច្នេះទេអង្គចងចាំអាចត្រូវបានដោះលែងនៅពេលដែល `data_fn` ត្រឡប់មកវិញ។
        // ប្រសិនបើយើងពិតជាចង់ប្រគល់ភាពជាម្ចាស់កម្មសិទ្ធិយើងអាចបង្កើតទ្រនិចទន់ខ្សោយបន្ថែមសម្រាប់ខ្លួនយើងប៉ុន្តែនេះនឹងបណ្តាលឱ្យមានការធ្វើបច្ចុប្បន្នភាពបន្ថែមទៀតចំពោះចំនួនឯកសារយោងខ្សោយដែលមិនចាំបាច់បើមិនដូច្នេះទេ។
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // សេចក្តីយោងខ្លាំងគួររួមជាម្ចាស់ជាឯកសារយោងខ្សោយចែករំលែកដូច្នេះមិនរត់សម្រាប់ជាឯកសារយោងទន់ខ្សោយបំផ្លាញអាយុរបស់យើង។
        //
        mem::forget(weak);
        strong
    }

    /// សាងសង់ `Rc` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានការសម្រិតសម្រាំង។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// សង់ជាថ្មីជាមួយនឹងមាតិកា `Rc` uninitiated, ជាមួយនឹងការចងចាំត្រូវបានគេពោរពេញទៅដោយ `0` បៃនេះ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// សាងសង់ `Rc<T>` ថ្មី, ត្រឡប់កំហុសប្រសិនបើការបែងចែកបរាជ័យ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // មានទ្រនិចខ្សោយជាក់ស្តែងដែលគ្រប់គ្រងដោយអ្នកចង្អុលបង្ហាញខ្លាំងទាំងអស់ដែលធានាថាអ្នកបំផ្លាញខ្សោយមិនដែលចែកចាយការចែកចាយទេខណៈពេលដែលអ្នកបំផ្លាញខ្លាំងកំពុងរត់ទោះបីទ្រនិចខ្សោយត្រូវបានរក្សាទុកនៅខាងក្នុងខ្លាំងក៏ដោយ។
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// សាងសង់ `Rc` ថ្មីជាមួយនឹងមាតិកាដែលមិនត្រូវបានគេយកមកធ្វើឱ្យមានកំហុសប្រសិនបើការបែងចែកបរាជ័យ
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// សាងសង់ `Rc` ថ្មីជាមួយនឹងមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃត្រឡប់កំហុសប្រសិនបើការបែងចែកបរាជ័យ
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// សាងសង់ `Pin<Rc<T>>` ថ្មី។
    /// ប្រសិនបើ `T` មិនអនុវត្ត `Unpin` នោះ `value` នឹងត្រូវបានបញ្ចូលក្នុងសតិហើយមិនអាចផ្លាស់ទីបាន។
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// ត្រឡប់តម្លៃខាងក្នុងប្រសិនបើ `Rc` មានសេចក្តីយោងដ៏រឹងមាំមួយ។
    ///
    /// បើមិនដូច្នោះទេ [`Err`] មួយត្រូវបានត្រឡប់មកវិញជាមួយ `Rc` ដូចគ្នាដែលត្រូវបានបញ្ជូនចូល។
    ///
    ///
    /// នេះនឹងទទួលបានជោគជ័យទោះបីជាមានឯកសារយោងខ្សោយឆ្នើមក៏ដោយ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // ចម្លងវត្ថុដែលមាន

                // ចង្អុលបង្ហាញដល់ Weaks ថាពួកគេមិនអាចត្រូវបានតំឡើងឋានៈដោយបន្ថយចំនួនដ៏ខ្លាំងនោះទេហើយបន្ទាប់មកដកទ្រនិច "strong weak" ដែលមិនច្បាស់ចេញខណៈពេលកំពុងដោះស្រាយតក្កវិជ្ជាទម្លាក់ដោយគ្រាន់តែក្លែងបន្លំចំណុចខ្សោយ។
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// បង្កើតចំណិតយោងយោងថ្មីជាមួយមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// បង្កើតចំណិតយោងយោងថ្មីជាមួយមាតិកាដែលមិនមានមូលដ្ឋានគ្រឹះដោយអង្គចងចាំត្រូវបានបំពេញដោយ `0` បៃ។
    ///
    ///
    /// សូមមើល [`MaybeUninit::zeroed`][zeroed] សម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់ត្រឹមត្រូវនិងមិនត្រឹមត្រូវនៃវិធីសាស្ត្រនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// បំលែងទៅជា `Rc<T>` ។
    ///
    /// # Safety
    ///
    /// ដូចគ្នានឹង [`MaybeUninit::assume_init`] ដែរវាអាស្រ័យលើអ្នកទូរស័ព្ទចូលដើម្បីធានាថាតម្លៃខាងក្នុងពិតជាស្ថិតនៅក្នុងស្ថានភាពដំបូង។
    ///
    /// ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗ។
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// បំលែងទៅជា `Rc<[T]>` ។
    ///
    /// # Safety
    ///
    /// ដូចគ្នានឹង [`MaybeUninit::assume_init`] ដែរវាអាស្រ័យលើអ្នកទូរស័ព្ទចូលដើម្បីធានាថាតម្លៃខាងក្នុងពិតជាស្ថិតនៅក្នុងស្ថានភាពដំបូង។
    ///
    /// ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗ។
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ការចាប់ផ្តើមពនរៈ
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// ប្រើប្រាស់ `Rc` ត្រឡប់ទ្រនិចរុំ។
    ///
    /// ដើម្បីចៀសវាងការលេចធ្លាយសតិទ្រនិចត្រូវតែប្តូរទៅ `Rc` ដោយប្រើ [`Rc::from_raw`][from_raw] ។
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ផ្តល់ទ្រនិចចង្អុលទៅទិន្នន័យ។
    ///
    /// ការរាប់មិនត្រូវបានប៉ះពាល់ក្នុងវិធីណាមួយទេហើយ `Rc` មិនត្រូវបានប្រើប្រាស់ទេ។
    /// ទ្រនិចមានសុពលភាពសម្រាប់ដរាបណាមានចំនួនច្រើននៅក្នុង `Rc` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // សុវត្ថិភាព: នេះមិនអាចឆ្លងកាត់ Deref::deref ឬ Rc::inner ទេពីព្រោះ
        // នេះត្រូវបានទាមទារដើម្បីរក្សាភស្តុតាង raw/mut ដូចជាឧ
        // `get_mut` អាចសរសេរតាមរយៈទ្រនិចបន្ទាប់ពីកាក់ត្រូវបានរកឃើញឡើងវិញតាមរយៈអេចស៊ីអ៊ិច។
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// សាងសង់ `Rc<T>` ពីទ្រនិចឆៅ។
    ///
    /// ទ្រនិចឆៅត្រូវតែត្រូវបានត្រឡប់មកវិញដោយការហៅទៅ [`Rc<U>::into_raw`][into_raw] ដែល `U` ត្រូវតែមានទំហំនិងតម្រឹមដូចគ្នានឹង `T` ។
    /// នេះជាការពិតបន្តិចបន្តួចបើ `U` គឺ `T` ។
    /// ចំណាំថាប្រសិនបើ `U` មិនមែនជា `T` ទេប៉ុន្តែមានទំហំនិងការតម្រឹមដូចគ្នានេះគឺជាមូលដ្ឋានដូចជាការបញ្ជូនសេចក្តីយោងនៃប្រភេទផ្សេងៗគ្នា។
    /// សូមមើល [`mem::transmute`][transmute] សម្រាប់ព័ត៌មានបន្ថែមអំពីការរឹតបន្តឹងអ្វីដែលត្រូវអនុវត្តក្នុងករណីនេះ។
    ///
    /// អ្នកប្រើ `from_raw` ត្រូវតែធានាថាតម្លៃជាក់លាក់នៃ `T` នឹងត្រូវធ្លាក់ចុះម្តង។
    ///
    /// មុខងារនេះមិនមានសុវត្ថិភាពទេពីព្រោះការប្រើប្រាស់មិនត្រឹមត្រូវអាចបណ្តាលឱ្យការចងចាំមិនមានសុវត្ថិភាពទោះបីជា `Rc<T>` ដែលបានត្រឡប់មកវិញមិនដែលចូលក៏ដោយ។
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // បំលែងទៅជា `Rc` វិញដើម្បីការពារការលេចធ្លាយ។
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // ការហៅទូរស័ព្ទទៅ `Rc::from_raw(x_ptr)` បន្ថែមទៀតអាចជាការចងចាំមិនមានសុវត្ថិភាព។
    /// }
    ///
    /// // ការចងចាំត្រូវបានដោះលែងនៅពេលដែល `x` មិនមានវិសាលភាពខាងលើដូច្នេះឥឡូវនេះ `x_ptr` កំពុងតែគាំង!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // បញ្ច្រាសអុហ្វសិតដើម្បីរក RcBox ដើម។
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// បង្កើតទ្រនិច [`Weak`] ថ្មីមួយសម្រាប់ការបែងចែកនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ត្រូវប្រាកដថាយើងមិនបង្កើតដង្កូវខ្សោយ
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// ទទួលបានចំនួនសូចនាករ [`Weak`] ចំពោះការបែងចែកនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// ទទួលបានចំនួនសូចនាករ (`Rc`) ខ្លាំងចំពោះការបែងចែកនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// ត្រឡប់ `true` ប្រសិនបើមិនមានអ្នកចង្អុល `Rc` ឬ [`Weak`] ផ្សេងទៀតចំពោះការបែងចែកនេះ។
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅក្នុង `Rc` ដែលបានផ្តល់ប្រសិនបើមិនមានចង្អុល `Rc` ឬ [`Weak`] ផ្សេងទៀតទៅនឹងការបែងចែកដូចគ្នា។
    ///
    ///
    /// ត្រឡប់ [`None`] បើមិនដូច្នេះទេព្រោះវាមិនមានសុវត្ថិភាពក្នុងការផ្លាស់ប្តូរតម្លៃដែលបានចែករំលែក។
    ///
    /// សូមមើលផងដែរ [`make_mut`][make_mut] ដែលនឹង [`clone`][clone] តម្លៃខាងក្នុងនៅពេលមានចំណុចចង្អុលផ្សេងទៀត។
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅក្នុង `Rc` ដែលបានផ្តល់ឱ្យដោយគ្មានការត្រួតពិនិត្យ។
    ///
    /// សូមមើល [`get_mut`] ផងដែរដែលមានសុវត្ថិភាពនិងត្រួតពិនិត្យត្រឹមត្រូវ។
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ចំណុច `Rc` ឬ [`Weak`] ផ្សេងទៀតចំពោះការបែងចែកដូចគ្នាមិនត្រូវបានបញ្ជាក់សម្រាប់រយៈពេលនៃប្រាក់កម្ចីដែលបានត្រឡប់មកវិញនោះទេ។
    ///
    /// នេះជាករណីតូចតាចប្រសិនបើគ្មានអ្នកចង្អុលបង្ហាញបែបនេះទេឧទាហរណ៍ភ្លាមៗបន្ទាប់ពី `Rc::new` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // យើងប្រយ័ត្នប្រយែងក្នុងការ *មិន* បង្កើតឯកសារយោងដែលគ្របដណ្តប់លើវាល "count" ព្រោះវាអាចប៉ះទង្គិចជាមួយនឹងការចូលមើលចំនួនឯកសារយោង (ឧ។
        // ដោយ `Weak`) ។
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// ត្រឡប់ `true` ប្រសិនបើ `Rc` ទាំងពីរចង្អុលទៅការបែងចែកដូចគ្នា (ជាសរសៃស្រដៀងនឹង [`ptr::eq`]) ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// ធ្វើឱ្យសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅជា `Rc` ដែលបានផ្តល់ឱ្យ។
    ///
    /// ប្រសិនបើមានចំណុច `Rc` ផ្សេងទៀតចំពោះការបែងចែកដូចគ្នានោះ `make_mut` នឹង [`clone`] តម្លៃខាងក្នុងចំពោះការបែងចែកថ្មីដើម្បីធានាភាពជាម្ចាស់តែមួយគត់។
    /// នេះក៏ត្រូវបានគេហៅថាក្លូន-សរសេរផងដែរ។
    ///
    /// ប្រសិនបើមិនមានអ្នកចង្អុល `Rc` ផ្សេងទៀតចំពោះការបែងចែកនេះទេនោះចំនុច [`Weak`] ចំពោះការបែងចែកនេះនឹងត្រូវផ្តាច់ចេញ។
    ///
    /// សូមមើលផងដែរ [`get_mut`] ដែលនឹងបរាជ័យជាជាងការក្លូន។
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // នឹងមិនក្លូនអ្វីទាំងអស់
    /// let mut other_data = Rc::clone(&data);    // នឹងមិនក្លូនទិន្នន័យខាងក្នុងទេ
    /// *Rc::make_mut(&mut data) += 1;        // ក្លូនទិន្នន័យខាងក្នុង
    /// *Rc::make_mut(&mut data) += 1;        // នឹងមិនក្លូនអ្វីទាំងអស់
    /// *Rc::make_mut(&mut other_data) *= 2;  // នឹងមិនក្លូនអ្វីទាំងអស់
    ///
    /// // ឥឡូវ `data` និង `other_data` ចង្អុលទៅការបែងចែកផ្សេងៗគ្នា។
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] ចង្អុលនឹងត្រូវបានផ្តាច់:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // ហ្គូតតាក្លូនទិន្នន័យ, មាន Rcs ផ្សេងទៀត។
            // បែងចែកការចងចាំជាមុនដើម្បីអនុញ្ញាតឱ្យសរសេរតម្លៃក្លូនដោយផ្ទាល់។
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // គ្រាន់តែអាចលួចទិន្ន័យអ្វីដែលនៅសេសសល់គឺ Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // យកហ្វាំងឡង់ខ្សោយដែលមិនច្បាស់ចេញ (មិនចាំបាច់បង្កើតចំណុចខ្សោយនៅទីនេះ-យើងដឹងថាក្រវ៉ាត់ផ្សេងទៀតអាចសម្អាតសម្រាប់យើង)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // សុវត្ថិភាពនេះមិនអីទេពីព្រោះយើងធានាថាទ្រនិចត្រឡប់មកវិញគឺមានតែព្រួញ * ប៉ុណ្ណោះដែលនឹងត្រូវបានបញ្ជូនទៅធី។
        // ចំនួនយោងរបស់យើងត្រូវបានធានាថាមាន ១ នៅចំណុចនេះហើយយើងតម្រូវឱ្យ `Rc<T>` ខ្លួនវាទៅជា `mut` ដូច្នេះយើងត្រលប់មកវិញនូវឯកសារយោងដែលអាចធ្វើទៅបានចំពោះការបែងចែក។
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// ប៉ុនប៉ងទម្លាក់ `Rc<dyn Any>` ទៅនឹងប្រភេទបេតុង។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// បែងចែក `RcBox<T>` ជាមួយនឹងទំហំគ្រប់គ្រាន់សម្រាប់តម្លៃខាងក្នុងដែលអាចកំណត់បានដែលតម្លៃមានប្លង់ដែលបានផ្តល់។
    ///
    /// មុខងារ `mem_to_rcbox` ត្រូវបានគេហៅថាជាមួយទ្រនិចទិន្នន័យហើយត្រូវត្រលប់មកវិញនូវចំនុចខ្សោយ (X) សំរាប់ `RcBox<T>` ។
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // គណនាប្លង់ដោយប្រើប្លង់តម្លៃដែលបានផ្តល់។
        // កាលពីមុនប្លង់ត្រូវបានគណនាលើកន្សោម `&*(ptr as* const RcBox<T>)` ប៉ុន្តែនេះបានបង្កើតឯកសារយោងខុស (សូមមើល #54908) ។
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// បែងចែក `RcBox<T>` ជាមួយនឹងទំហំគ្រប់គ្រាន់សម្រាប់តម្លៃខាងក្នុងដែលអាចកំណត់បានដែលតម្លៃមានប្លង់ដែលបានផ្តល់ឱ្យត្រឡប់មកវិញដោយមានកំហុសប្រសិនបើការបែងចែកបរាជ័យ។
    ///
    ///
    /// មុខងារ `mem_to_rcbox` ត្រូវបានគេហៅថាជាមួយទ្រនិចទិន្នន័យហើយត្រូវត្រលប់មកវិញនូវចំនុចខ្សោយ (X) សំរាប់ `RcBox<T>` ។
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // គណនាប្លង់ដោយប្រើប្លង់តម្លៃដែលបានផ្តល់។
        // កាលពីមុនប្លង់ត្រូវបានគណនាលើកន្សោម `&*(ptr as* const RcBox<T>)` ប៉ុន្តែនេះបានបង្កើតឯកសារយោងខុស (សូមមើល #54908) ។
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // បម្រុងទុកសម្រាប់ប្លង់។
        let ptr = allocate(layout)?;

        // ចាប់ផ្តើម RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// បែងចែក `RcBox<T>` ជាមួយនឹងទំហំគ្រប់គ្រាន់សម្រាប់តម្លៃខាងក្នុងដែលមិនបានបញ្ជាក់
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // បែងចែកសម្រាប់ `RcBox<T>` ដោយប្រើតម្លៃដែលបានផ្តល់។
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // ចម្លងតម្លៃជាបៃ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // ការបែងចែកដោយឥតគិតថ្លៃដោយមិនទម្លាក់មាតិការបស់វា
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// បែងចែក `RcBox<[T]>` ជាមួយនឹងប្រវែងដែលបានផ្តល់។
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// ចម្លងធាតុពីចំណិតទៅក្នុងក។ ជ។ ដែលបានបម្រុងទុកថ្មី
    ///
    /// មិនមានសុវត្ថិភាពទេព្រោះអ្នកហៅទូរស័ព្ទត្រូវតែទទួលយកភាពជាម្ចាស់ឬភ្ជាប់ `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// សាងសង់ `Rc<[T]>` ពីឧបករណ៍វាស់ស្ទង់ដែលត្រូវបានគេដឹងថាមានទំហំជាក់លាក់។
    ///
    /// ឥរិយាបថនេះត្រូវបានកំណត់គួរមានទំហំខុស។
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic យាមពេលក្លូនធាតុ T ។
        // ក្នុងករណី panic ធាតុដែលត្រូវបានសរសេរទៅក្នុង RcBox ថ្មីនឹងត្រូវបានទម្លាក់បន្ទាប់មកការចងចាំត្រូវបានដោះលែង។
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ទ្រនិចទៅធាតុទីមួយ
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ច្បាស់លាស់ទាំងអស់។ភ្លេចឆ្មាំដូច្នេះវាមិនដោះលែង RcBox ថ្មីទេ។
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// ឯកទេស trait ប្រើសំរាប់ `From<&[T]>` ។
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// ទម្លាក់ `Rc` ។
    ///
    /// នេះនឹងកាត់បន្ថយចំនួនយោងយោងខ្លាំង។
    /// ប្រសិនបើចំនួនយោងខ្លាំងឈានដល់សូន្យនោះមានតែសេចក្តីយោងផ្សេងទៀត (ប្រសិនបើមាន) គឺ [`Weak`] ដូច្នេះយើង `drop` តម្លៃខាងក្នុង។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // មិនបោះពុម្ពអ្វីទាំងអស់
    /// drop(foo2);   // បោះពុម្ព "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // បំផ្លាញវត្ថុដែលមាន
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // យកទ្រនិច "strong weak" ដែលមិនច្បាស់ចេញឥឡូវយើងបានបំផ្លាញមាតិកា។
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// បង្កើតក្លូននៃទ្រនិច `Rc` ។
    ///
    /// នេះបង្កើតទ្រនិចមួយផ្សេងទៀតទៅនឹងការបែងចែកដូចគ្នាបង្កើនចំនួនឯកសារយោងខ្លាំង។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// បង្កើត `Rc<T>` ថ្មីដែលមានតម្លៃ `Default` សំរាប់ `T` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack ដើម្បីអនុញ្ញាតឱ្យមានជំនាញលើ `Eq` ទោះបីជា `Eq` មានវិធីសាស្ត្រក៏ដោយ។
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// យើងកំពុងធ្វើឯកទេសនេះនៅទីនេះហើយមិនមែនជាការបង្កើនប្រសិទ្ធិភាពទូទៅបន្ថែមលើ `&T` ទេពីព្រោះវានឹងបន្ថែមការចំណាយទៅលើការត្រួតពិនិត្យសមភាពទាំងអស់លើក្រដាសប្រាក់។
/// យើងសន្មត់ថា `រ៉ូខេត្រូវបានប្រើដើម្បីរក្សាទុកតម្លៃធំ ៗ ដែលយឺតដើម្បីក្លូនប៉ុន្តែក៏ធ្ងន់ផងដែរដើម្បីពិនិត្យមើលភាពស្មើគ្នាដែលបណ្តាលឱ្យការចំណាយនេះទូទាត់កាន់តែងាយស្រួល។
///
/// វាទំនងជាមានក្លូន `Rc` ពីរដែលចង្អុលទៅតម្លៃដូចគ្នាជាងពីរ `&T`s ទៅទៀត។
///
/// យើងអាចធ្វើវាបានលុះត្រាតែ `T: Eq` ជា `PartialEq` អាចមិនសមហេតុផលដោយចេតនា។
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// សមភាពសំរាប់ពីរ R ស។ ព។
    ///
    /// ពីរ `Rc` គឺស្មើគ្នាប្រសិនបើតម្លៃខាងក្នុងរបស់ពួកគេស្មើគ្នាទោះបីវាត្រូវបានរក្សាទុកក្នុងការបែងចែកខុសគ្នាក៏ដោយ។
    ///
    /// ប្រសិនបើ `T` អនុវត្ត `Eq` (បង្ហាញការឆ្លុះបញ្ចាំងពីភាពស្មើគ្នា) នោះ R Rc ពីរដែលចង្អុលទៅការបែងចែកដូចគ្នាគឺតែងតែស្មើគ្នា។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// វិសមភាពសម្រាប់ពីរ R ស។ ព។
    ///
    /// ពីរ `រ៉ូខេគឺមិនស្មើគ្នាប្រសិនបើតម្លៃខាងក្នុងរបស់ពួកគេមិនស្មើគ្នា។
    ///
    /// ប្រសិនបើ `T` ក៏អនុវត្ត `Eq` (បង្ហាញការឆ្លុះបញ្ចាំងពីភាពស្មើគ្នា) នោះ R Rc ពីរដែលចង្អុលទៅការបែងចែកដូចគ្នាមិនដែលស្មើគ្នាទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// ការប្រៀបធៀបដោយផ្នែកសម្រាប់ពីរ `រ៉ូខេ s ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `partial_cmp()` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// ការប្រៀបធៀបតិចជាងសម្រាប់ `Rc` ពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `<` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// ការប្រៀបធៀប Less ប្រៀបធៀបតូចជាងឬស្មើ៉សម្រាប់ `Rc` ពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `<=` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// ការប្រៀបធៀបដែលប្រសើរជាងសម្រាប់ពីរ R អិលស៊ី។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `>` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// ការប្រៀបធៀប Great ប្រៀបធៀបធំជាងឬស្មើ for សំរាប់ `Rc` ពីរ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `>=` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// ការប្រៀបធៀបសម្រាប់ពីរ R Rc`s ។
    ///
    /// ទាំងពីរត្រូវបានប្រៀបធៀបដោយហៅទូរស័ព្ទ `cmp()` លើតម្លៃខាងក្នុងរបស់ពួកគេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// បែងចែកចំណិតយោងដែលបានរាប់ហើយបំពេញវាដោយក្លូនរបស់ `v` ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// បែងចែកចំណែកខ្សែដែលបានរាប់យោងហើយចំលង `v` ទៅក្នុងនោះ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// បែងចែកចំណែកខ្សែដែលបានរាប់យោងហើយចំលង `v` ទៅក្នុងនោះ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// រំកិលវត្ថុដែលដាក់ក្នុងប្រអប់មួយទៅកន្លែងថ្មីដែលបានរាប់ជាយោង។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// បែងចែកចំណិតយោងដែលបានរាប់ហើយយករបស់របស់ `v ចូលទៅក្នុងនោះ។
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // អនុញ្ញាតឱ្យ Vec ដោះលែងការចងចាំរបស់វាប៉ុន្តែមិនបំផ្លាញមាតិការបស់វាទេ
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// យកធាតុនីមួយៗនៅក្នុង `Iterator` ហើយប្រមូលវាទៅជា `Rc<[T]>` ។
    ///
    /// # លក្ខណៈនៃការអនុវត្ត
    ///
    /// ## ករណីទូទៅ
    ///
    /// ក្នុងករណីទូទៅការប្រមូលចូលទៅក្នុង `Rc<[T]>` ត្រូវបានធ្វើឡើងដោយការប្រមូលដំបូងទៅក្នុង `Vec<T>` ។នោះគឺនៅពេលសរសេរដូចខាងក្រោមៈ
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// នេះមានឥរិយាបទដូចជាយើងបានសរសេរ៖
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // សំណុំនៃការបែងចែកដំបូងកើតឡើងនៅទីនេះ។
    ///     .into(); // ការបែងចែកទីពីរសម្រាប់ `Rc<[T]>` កើតឡើងនៅទីនេះ។
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// នេះនឹងបែងចែកច្រើនដងតាមតម្រូវការសម្រាប់ការសាងសង់ `Vec<T>` ហើយបន្ទាប់មកវានឹងបម្រុងទុកសម្រាប់ការបង្វែរ `Vec<T>` ទៅជា `Rc<[T]>` ។
    ///
    ///
    /// ## ឧបករណ៍បំបែកប្រវែងដែលស្គាល់
    ///
    /// នៅពេលដែល `Iterator` របស់អ្នកអនុវត្ត `TrustedLen` និងមានទំហំពិតប្រាកដការបែងចែកតែមួយនឹងត្រូវបានធ្វើឡើងសម្រាប់ `Rc<[T]>` ។ឧទាហរណ៍:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // គ្រាន់តែការបែងចែកតែមួយកើតឡើងនៅទីនេះ។
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// ឯកទេស trait ប្រើសម្រាប់ប្រមូលចូល `Rc<[T]>` ។
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // នេះជាករណីសម្រាប់ឧបករណ៍ `TrustedLen` iterator ។
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // សុវត្ថិភាព: យើងត្រូវធានាថាឧបករណ៍វាស់មានប្រវែងពិតប្រាកដហើយយើងមាន។
                Rc::from_iter_exact(self, low)
            }
        } else {
            // ត្រលប់ទៅការអនុវត្តធម្មតាវិញ។
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` គឺជាកំណែ [`Rc`] ដែលមានឯកសារយោងមិនមែនជាកម្មសិទ្ធិរបស់ការគ្រប់គ្រងដែលបានគ្រប់គ្រង។ការបែងចែកត្រូវបានចូលប្រើតាមរយៈការហៅទូរស័ព្ទ [`upgrade`] នៅលើទ្រនិច `Weak` ដែលត្រឡប់មកវិញ [`ជម្រើស`] `<` [`Rc`]`<T>>`។
///
/// ចាប់តាំងពីឯកសារយោង `Weak` មិនរាប់ឆ្ពោះទៅរកភាពជាម្ចាស់, វានឹងមិនបងា្ករតម្លៃដែលរក្សាទុកនៅក្នុងការបែងចែកពីត្រូវបានធ្លាក់ចុះនិង `Weak` ខ្លួនវាធ្វើឱ្យការធានាទេអំពីតម្លៃនេះនៅតែមានវត្តមាន។
/// ដូច្នេះវាអាចត្រឡប់ [`None`] នៅពេល [`ធ្វើឱ្យប្រសើរឡើង] ឃ។
/// ទោះជាយ៉ាងណាចំណាំថា `Weak` យោង *ធ្វើ* រារាំងការបែងចែកដោយខ្លួនវា (ហាងគាំទ្រ) ពីការត្រូវបានដោះស្រាយ។
///
/// ទ្រនិច `Weak` មានប្រយោជន៍សម្រាប់រក្សាទុកឯកសារយោងបណ្តោះអាសន្នចំពោះការបែងចែកដែលគ្រប់គ្រងដោយ [`Rc`] ដោយមិនរារាំងតម្លៃខាងក្នុងរបស់វាពីការធ្លាក់ចុះ។
/// វាក៏ត្រូវបានប្រើដើម្បីការពារការយោងជារង្វង់រវាងចំនុចចង្អុល [`Rc`] ព្រោះថាឯកសារយោងដែលជាកម្មសិទ្ធិទៅវិញទៅមកនឹងមិនអនុញ្ញាតឱ្យទម្លាក់ [`Rc`] ឡើយ។
/// ឧទាហរណ៍ដើមឈើមួយអាចមានចំណុចចង្អុល [`Rc`] ខ្លាំងពីថ្នាំងឪពុកម្តាយទៅកូនហើយចំណុច `Weak` ពីកូន ៗ ត្រឡប់ទៅឪពុកម្តាយវិញ។
///
/// វិធីធម្មតាដើម្បីទទួលបានទ្រនិច `Weak` គឺត្រូវហៅទូរស័ព្ទ [`Rc::downgrade`] ។
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // នេះគឺជា `NonNull` ដើម្បីអនុញ្ញាតឱ្យបង្កើនទំហំនៃប្រភេទនេះនៅក្នុងអ៊ីនធឺរណែតប៉ុន្តែវាមិនចាំបាច់ជាទ្រនិចត្រឹមត្រូវទេ។
    //
    // `Weak::new` កំណត់វាទៅ `usize::MAX` ដូច្នេះវាមិនចាំបាច់បែងចែកទំហំនៅលើគំនរទេ។
    // នោះមិនមែនជាតម្លៃដែលព្រួញកណ្តុរពិតប្រាកដនឹងមាននោះទេព្រោះ RcBox មានការតម្រឹមយ៉ាងតិច ២ ។
    // នេះគឺអាចធ្វើទៅបាននៅពេល `T: Sized`;`T` មិនបានកំណត់
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// សាងសង់ `Weak<T>` ថ្មីដោយមិនចាំបាច់បែងចែកសតិណាមួយឡើយ។
    /// ការហៅទូរស័ព្ទ [`upgrade`] លើតម្លៃត្រឡប់មកវិញតែងតែផ្តល់ឱ្យ [`None`] ។
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ប្រភេទអ្នកជំនួយការដើម្បីអនុញ្ញាតឱ្យចូលប្រើចំនួនយោងដោយមិនមានការអះអាងណាមួយអំពីវាលទិន្នន័យ។
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// ត្រឡប់ទ្រនិចចង្អុលទៅវត្ថុ `T` ចង្អុលទៅ `Weak<T>` X នេះ។
    ///
    /// ទ្រនិចមានសុពលភាពលុះត្រាតែមានឯកសារយោងរឹងមាំខ្លះ។
    /// ទ្រនិចអាចត្រូវបានព្យួរមិនស្មើគ្នាឬសូម្បីតែ [`null`] បើមិនដូច្នេះទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // ទាំងពីរចង្អុលទៅវត្ថុតែមួយ
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // អ្នកខ្លាំងនៅទីនេះរក្សាវាឱ្យនៅរស់ដូច្នេះយើងនៅតែអាចចូលមើលវត្ថុបាន។
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // ប៉ុន្តែមិនមានទៀតទេ។
    /// // យើងអាចធ្វើបាន weak.as_ptr() ប៉ុន្តែការចូលទៅកាន់ទ្រនិចអាចនាំឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
    /// // assert_eq! ("សួស្តី", គ្មានសុវត្ថិភាព {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // ប្រសិនបើទ្រនិចកំពុងរដុបយើងបញ្ជូនអ្នកបញ្ជូនផ្ទាល់។
            // នេះមិនអាចជាអាស័យដ្ឋានបន្ទុកដែលមានសុពលភាពទេពីព្រោះបន្ទុកនោះយ៉ាងហោចណាស់ត្រូវបានតម្រឹមដូច RcBox (usize) ដែរ។
            ptr as *const T
        } else {
            // សុវត្ថិភាព: ប្រសិនបើ is_dangling ត្រឡប់មិនពិត, បន្ទាប់មកទ្រនិចគឺមិនអាចប្រកែកបាន។
            // បន្ទុកអាចត្រូវបានទម្លាក់នៅចំណុចនេះហើយយើងត្រូវតែរក្សាភស្តុតាងដូច្នេះត្រូវប្រើឧបករណ៏ទ្រនិចឆៅ។
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// ប្រើប្រាស់ `Weak<T>` ហើយប្រែវាទៅជាទ្រនិចឆៅ។
    ///
    /// នេះបម្លែងទ្រនិចខ្សោយទៅជាទ្រនិចឆៅខណៈពេលដែលនៅតែរក្សាភាពជាម្ចាស់នៃឯកសារយោងខ្សោយមួយ (ការរាប់ខ្សោយមិនត្រូវបានកែប្រែដោយប្រតិបត្តិការនេះទេ) ។
    /// វាអាចប្រែទៅជា `Weak<T>` ជាមួយ [`from_raw`] ។
    ///
    /// ការរឹតបន្តឹងដូចគ្នានៃការចូលគោលដៅនៃទ្រនិចដូចគ្នានឹង [`as_ptr`] ត្រូវបានអនុវត្ត។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// បំលែងទ្រនិចឆៅដែលបានបង្កើតពីមុនដោយ [`into_raw`] ត្រលប់ទៅជា `Weak<T>` ។
    ///
    /// នេះអាចត្រូវបានប្រើដើម្បីទទួលបានឯកសារយោងរឹងមាំ (ដោយហៅទូរស័ព្ទទៅ [`upgrade`] នៅពេលក្រោយ) ឬដោះស្រាយចំនួនខ្សោយដោយទម្លាក់ `Weak<T>` ។
    ///
    /// វាត្រូវការភាពជាម្ចាស់នៃឯកសារយោងខ្សោយមួយ (លើកលែងតែចំណុចចង្អុលបង្ហាញដែលបង្កើតដោយ [`new`] ព្រោះវាមិនមែនជារបស់អ្វីទាំងអស់។ វិធីសាស្ត្រនៅតែមានលើពួកវា) ។
    ///
    /// # Safety
    ///
    /// ទ្រនិចត្រូវតែមានប្រភពចេញពី [`into_raw`] ហើយនៅតែត្រូវតែជាម្ចាស់ឯកសារយោងខ្សោយសក្តានុពលរបស់វា។
    ///
    /// វាត្រូវបានអនុញ្ញាតសម្រាប់ការរាប់យ៉ាងខ្លាំងគឺ 0 នៅពេលហៅវា។
    /// ទោះយ៉ាងណាក៏ដោយវាត្រូវការភាពជាម្ចាស់នៃឯកសារយោងខ្សោយមួយដែលបច្ចុប្បន្នត្រូវបានចង្អុលបង្ហាញជាទ្រនិចឆៅ (ចំនួនខ្សោយមិនត្រូវបានកែប្រែដោយប្រតិបត្តិការនេះទេ) ដូច្នេះវាត្រូវភ្ជាប់ជាមួយការហៅពីមុនទៅ [`into_raw`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // បន្ថយចំនួនខ្សោយចុងក្រោយ។
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // សូមមើល Weak::as_ptr សម្រាប់បរិបទអំពីរបៀបដែលទ្រនិចបញ្ចូលត្រូវបានចេញ។

        let ptr = if is_dangling(ptr as *mut T) {
            // នេះគឺជាដង្កូវខ្សោយ។
            ptr as *mut RcBox<T>
        } else {
            // បើមិនដូច្នោះទេយើងត្រូវបានធានាថាទ្រនិចកើតចេញពីចំណុចខ្សោយដែលមិនចេះនិយាយ។
            // សុវត្ថិភាព: data_offset មានសុវត្ថិភាពក្នុងការហៅព្រោះឯកសារយោង ptr ជាការធ្លាក់ចុះពិតប្រាកដ (T សក្តានុពល) ។
            let offset = unsafe { data_offset(ptr) };
            // ដូច្នេះយើងបញ្ច្រាសអុហ្វសិតដើម្បីទទួលបាន RcBox ទាំងមូល។
            // សុវត្ថិភាព: ទ្រនិចមានប្រភពមកពីខ្សោយដូច្នេះអុហ្វសិតនេះមានសុវត្ថិភាព។
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // សុវត្ថិភាព៖ ឥឡូវនេះយើងបានរកឃើញទ្រនិចខ្សោយរបស់ដើមដូច្នេះអាចបង្កើតបានជា Weak ។
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// ការប៉ុនប៉ងធ្វើឱ្យប្រសើរឡើងនូវទ្រនិច `Weak` ទៅ [`Rc`] X ពន្យារពេលទម្លាក់តម្លៃខាងក្នុងប្រសិនបើទទួលបានជោគជ័យ។
    ///
    ///
    /// ត្រឡប់ [`None`] ប្រសិនបើតម្លៃខាងក្នុងត្រូវបានទម្លាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // បំផ្លាញចំណុចខ្លាំងទាំងអស់។
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// ទទួលបានចំនួនអ្នកចង្អុល (`Rc`) ដែលចង្អុលទៅការបែងចែកនេះ។
    ///
    /// ប្រសិនបើ `self` ត្រូវបានបង្កើតឡើងដោយប្រើ [`Weak::new`] វានឹងត្រឡប់ 0 ។
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// ទទួលបានចំនួនអ្នកចង្អុល `Weak` ដែលចង្អុលទៅការបែងចែកនេះ។
    ///
    /// ប្រសិនបើគ្មានអ្នកចង្អុលបង្ហាញរឹងមាំទេនេះនឹងត្រឡប់មកវិញសូន្យ។
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ដក ptr ខ្សោយជាក់ស្តែង
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// ត្រឡប់ `None` នៅពេលព្រួញកន្ត្រាក់ហើយមិនត្រូវបានបម្រុងទុក `RcBox` (មានន័យថានៅពេល `Weak` នេះត្រូវបានបង្កើតដោយ `Weak::new`) ។
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // យើងប្រយ័ត្នប្រយែងក្នុងការ *មិន* បង្កើតឯកសារយោងដែលគ្របដណ្តប់លើវាល "data" ព្រោះថាវាលនេះអាចត្រូវបានផ្លាស់ប្តូរក្នុងពេលដំណាលគ្នា (ឧទាហរណ៍ប្រសិនបើ `Rc` ចុងក្រោយត្រូវបានទម្លាក់នោះវាលទិន្នន័យនឹងត្រូវបានទម្លាក់នៅនឹងកន្លែង) ។
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើសញ្ញា `ខ្សោយទាំងពីរចង្អុលទៅការបែងចែកដូចគ្នា (ស្រដៀងនឹង [`ptr::eq`]) ឬប្រសិនបើទាំងពីរមិនចង្អុលទៅការបែងចែកណាមួយ (ពីព្រោះពួកវាត្រូវបានបង្កើតជាមួយ `Weak::new()`) ។
    ///
    ///
    /// # Notes
    ///
    /// ដោយសារនេះប្រៀបធៀបចំណុចចង្អុលបង្ហាញវាមានន័យថា `Weak::new()` នឹងស្មើគ្នាទោះបីជាពួកគេមិនចង្អុលទៅការបែងចែកក៏ដោយ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// ប្រៀបធៀប `Weak::new` ។
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// ទម្លាក់ទ្រនិច `Weak` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // មិនបោះពុម្ពអ្វីទាំងអស់
    /// drop(foo);        // បោះពុម្ព "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ការរាប់ខ្សោយចាប់ផ្តើមពីលេខ ១ ហើយនឹងមានតែសូន្យប្រសិនបើចំនុចខ្លាំងទាំងអស់បានបាត់។
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// បង្កើតក្លូននៃទ្រនិច `Weak` ដែលចង្អុលទៅការបែងចែកដូចគ្នា។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// សាងសង់ `Weak<T>` ថ្មី, បម្រុងទុកអង្គចងចាំសម្រាប់ `T` ដោយមិនចាំបាច់ចាប់ផ្តើម។
    /// ការហៅទូរស័ព្ទ [`upgrade`] លើតម្លៃត្រឡប់មកវិញតែងតែផ្តល់ឱ្យ [`None`] ។
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: យើងបានពិនិត្យមើលនៅទីនេះដើម្បីដោះស្រាយជាមួយ mem::forget ដោយសុវត្ថិភាព។ជាពិសេស
// ប្រសិនបើអ្នក mem::forget Rcs (ឬ Weaks) ការរាប់ឡើងវិញអាចលើសហើយបន្ទាប់មកអ្នកអាចបែងចែកការបែងចែកខណៈពេលដែល Rcs (ឬ Weaks) លេចធ្លោ។
//
// យើងបោះបង់ចោលព្រោះនេះជាសេណារីយ៉ូអន់ថយដែលយើងមិនខ្វល់ពីអ្វីដែលកើតឡើង-មិនមានកម្មវិធីពិតគួរជួបប្រទះបញ្ហានេះទេ។
//
// វាគួរតែមានការធ្វេសប្រហែសដែលអ្នកមិនអាចទទួលយកបានពីព្រោះអ្នកមិនត្រូវការក្លូនច្រើនទេនៅក្នុងហ្សុមអរហ្សុហ្សុដោយសារតែអរគុណចំពោះភាពជាម្ចាស់និងចលនា។
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // យើងចង់បោះបង់ចោលការហៀរចេញជំនួសឱ្យការទម្លាក់តម្លៃ។
        // ចំនួនយោងនឹងមិនដែលសូន្យទេនៅពេលដែលគេហៅវា។
        // ទោះយ៉ាងណាយើងបញ្ចូលរំលូតកូននៅទីនេះដើម្បីណែនាំអិលអិលអេមអេមនៅការខកខានមិនបានធ្វើឱ្យប្រសើរ។
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // យើងចង់បោះបង់ចោលការហៀរចេញជំនួសឱ្យការទម្លាក់តម្លៃ។
        // ចំនួនយោងនឹងមិនដែលសូន្យទេនៅពេលដែលគេហៅវា។
        // ទោះយ៉ាងណាយើងបញ្ចូលរំលូតកូននៅទីនេះដើម្បីណែនាំអិលអិលអេមអេមនៅការខកខានមិនបានធ្វើឱ្យប្រសើរ។
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// ទទួលបានអុហ្វសិតក្នុងរយៈពេល `RcBox` សម្រាប់បន្ទុកនៅពីក្រោយទ្រនិច។
///
/// # Safety
///
/// ទ្រនិចត្រូវតែចង្អុលទៅ (និងមានទិន្នន័យមេតាដែលមានសុពលភាពសម្រាប់) ឧទាហរណ៍ដែលមានសុពលភាពនៃ T ប៉ុន្តែ T ត្រូវបានអនុញ្ញាតឱ្យទម្លាក់។
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // តម្រឹមតម្លៃដែលមិនបានបញ្ជាក់ទៅខាងចុង RcBox ។
    // ដោយសារតែ RcBox គឺជា repr(C) វានឹងក្លាយជាវាលចុងក្រោយនៅក្នុងការចងចាំជានិច្ច។
    // សុវត្ថិភាព: ចាប់តាំងពីប្រភេទដែលមិនមានសុពលភាពតែមួយគត់ដែលអាចធ្វើបានគឺចំណិតវត្ថុ trait,
    // និងប្រភេទខាងក្រៅតម្រូវការសុវត្ថិភាពបញ្ចូលគឺគ្រប់គ្រាន់ដើម្បីបំពេញតាមតម្រូវការនៃការតំរឹម;នេះគឺជាសេចក្តីលំអិតនៃការអនុវត្តភាសាដែលមិនអាចពឹងផ្អែកលើ std ។
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}