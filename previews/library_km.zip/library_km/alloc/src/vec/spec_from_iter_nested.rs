use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// ជំនាញពិសេសមួយទៀតគឺ trait សម្រាប់ Vec::from_iter ដែលចាំបាច់ត្រូវផ្តល់អាទិភាពដល់ជំនាញត្រួតលើគ្នាដោយដៃសូមមើល [`SpecFromIter`](super::SpecFromIter) សម្រាប់ព័ត៌មានលំអិត។
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // រំtheកការនិយាយឡើងវិញលើកដំបូងព្រោះថា vector នឹងត្រូវបានពង្រីកលើការនិយាយឡើងវិញនេះក្នុងករណីនីមួយៗនៅពេលដែលការនិយាយឡើងវិញមិនទទេប៉ុន្តែរង្វិលជុំនៅក្នុង extend_desugared() នឹងមិនឃើញ vector ពេញនៅក្នុងរង្វិលជុំជាបន្តបន្ទាប់ទេ។
        //
        // ដូច្នេះយើងទទួលបានការព្យាករណ៍ branch កាន់តែប្រសើរ។
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // ត្រូវតែធ្វើប្រតិភូកម្មដល់ក្រុមហ៊ុន spec_extend() ចាប់តាំងពី extend() ខ្លួនវាផ្ទាល់ប្រគល់អោយ spec_from សំរាប់ Vecs ទទេ
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // ត្រូវតែធ្វើប្រតិភូកម្មដល់ក្រុមហ៊ុន spec_extend() ចាប់តាំងពី extend() ខ្លួនវាផ្ទាល់ប្រគល់អោយ spec_from សំរាប់ Vecs ទទេ
        //
        vector.spec_extend(iterator);
        vector
    }
}