use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// សញ្ញាសម្គាល់ជំនាញសម្រាប់ការប្រមូលបំពង់បង្ហូរចូលទៅក្នុងវេបខណៈពេលប្រើឡើងវិញនូវការបែងចែកប្រភពពោលគឺ
/// ប្រតិបត្តិបំពង់បង្ហូរនៅនឹងកន្លែង។
///
/// trait មេ SourceIter គឺចាំបាច់សម្រាប់មុខងារជំនាញដើម្បីចូលប្រើការបែងចែកដែលត្រូវប្រើឡើងវិញ។
/// ប៉ុន្តែវាមិនគ្រប់គ្រាន់ទេសម្រាប់ការធ្វើឱ្យឯកទេសមានសុពលភាព។
/// សូមមើលព្រំដែនបន្ថែមនៅលើ impl នេះ។
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// ការ std-ផ្ទៃក្នុង SourceIter/InPlaceIterable traits ត្រូវបានអនុវត្តដោយខ្សែសង្វាក់អាដាប់ទ័រតែប៉ុណ្ណោះ <Adapter<Adapter<IntoIter>>> (ទាំងអស់ជាកម្មសិទ្ធិរបស់ core/std) ។
// ព្រំដែនបន្ថែមលើការអនុវត្តអាដាប់ធ័រ (លើសពី `impl<I: Trait> Trait for Adapter<I>`) ពឹងផ្អែកតែ traits ផ្សេងទៀតដែលត្រូវបានសម្គាល់រួចហើយថាជាជំនាញ traits (ចម្លង, ជឿទុកចិត្តRandomAccess, FusedIterator) ។
//
// I.e. សញ្ញាសម្គាល់មិនអាស្រ័យលើអាយុកាលនៃប្រភេទដែលផ្គត់ផ្គង់ដោយអ្នកប្រើប្រាស់។Modulo the Copy រន្ធដែលជំនាញជាច្រើនផ្សេងទៀតពឹងផ្អែករួចទៅហើយ។
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // តម្រូវការបន្ថែមដែលមិនអាចបង្ហាញតាមរយៈ trait bounds ។យើងពឹងផ្អែកលើការបង្ហាញជំនួសវិញ៖
        // ក) គ្មាន ZST ដូចដែលមិនមានការបែងចែកដើម្បីប្រើឡើងវិញនិងការគណនាលេខនព្វន្តនឹងហ្សីនស៊ីនហ្សិចហ្សីន panic ខ) ត្រូវនឹងទំហំដែលត្រូវបានតម្រូវដោយកិច្ចសន្យាអាល់ឡោះ។
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // ត្រឡប់ទៅការអនុវត្តទូទៅបន្ថែមទៀត
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // ប្រើសាកល្បងដង
        // - វាវ៉ិចទ័រល្អជាងមុនសម្រាប់អាដាប់ទ័រទ្រេត
        // - មិនដូចវិធីសាស្រ្តរំinternalកផ្ទៃក្នុងភាគច្រើនទេវាប្រើតែ &mut ដោយខ្លួនឯង
        // - វាអនុញ្ញាតឱ្យយើងត្បាញទ្រនិចសរសេរតាមរយៈផ្នែកខាងក្នុងរបស់វាហើយយកវាមកវិញនៅចុងបញ្ចប់
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // ជោគជ័យឡើងវិញកុំទម្លាក់ក្បាលចុះ
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // ពិនិត្យមើលថាតើកិច្ចសន្យារបស់ SourceIter ត្រូវបានគេលើកយកមកពន្យល់យ៉ាងម៉េច៖ ប្រសិនបើពួកគេមិនបានយើងមិនទាំងឈានដល់ចំនុចនេះផង
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // ពិនិត្យមើលកិច្ចសន្យា InPlaceIterable ។នេះអាចធ្វើទៅបានប្រសិនបើអ្នកធ្វើឱ្យប្រសើរឡើងនូវទ្រនិចប្រភព។
        // ប្រសិនបើវាប្រើការចូលប្រើដែលមិនបានត្រួតពិនិត្យតាមរយៈ TrustedRandomAccess នោះទ្រនិចប្រភពនឹងស្ថិតនៅក្នុងទីតាំងដំបូងហើយយើងមិនអាចប្រើវាជាឯកសារយោងបានទេ។
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ការធ្លាក់ចុះតម្លៃនៅសល់ណាមួយនៅកន្ទុយរបស់ប្រភពនោះទេប៉ុន្តែការធ្លាក់ចុះនៃការបែងចែកទប់ស្កាត់ការខ្លួនវាផ្ទាល់នៅពេលដែល IntoIter ចេញពីវិសាលភាពប្រសិនបើការធ្លាក់ចុះ panics បន្ទាប់មកយើងបានលេចធ្លាយធាតុណាមួយដែលប្រមូលបានចូលទៅក្នុង dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // កិច្ចសន្យា InPlaceIterable នេះមិនអាចត្រូវបានផ្ទៀងផ្ទាត់យ៉ាងច្បាស់ណាស់នៅទីនេះតាំងពី try_fold មានសេចក្ដីយោងផ្តាច់មុខទៅឱ្យព្រួញប្រភពទាំងអស់ដែលយើងអាចធ្វើគឺពិនិត្យមើលប្រសិនបើវានៅតែនៅក្នុងជួរ
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}