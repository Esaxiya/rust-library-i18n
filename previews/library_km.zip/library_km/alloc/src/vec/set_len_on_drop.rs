// កំណត់ប្រវែងវ៉ិចទ័រនៅពេលដែលតម្លៃ `SetLenOnDrop` ផុតកំណត់។
//
// គំនិតនេះគឺ: វាលប្រវែងនៅក្នុង SetLenOnDrop គឺជាការល្អប្រសើរអថេរមូលដ្ឋានដែលនឹងមើលឃើញមិនមានឈ្មោះក្លែងក្លាយដោយមានហាងណាមួយតាមរយៈការទស្សន៍ទ្រនិចទិន្នន័យ VEC នេះ។
// នេះគឺជាការធ្វើការសម្រាប់បញ្ហាការវិភាគឈ្មោះក្លែងក្លាយ #32155 មួយ
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}