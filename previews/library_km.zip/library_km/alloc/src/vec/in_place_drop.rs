use core::ptr::{self};
use core::slice::{self};

// រចនាសម្ព័ន្ធជំនួយសម្រាប់ការនិយាយឡើងវិញនៅកន្លែងដែលទម្លាក់ចំណែកនៃការនិយាយឡើងវិញពោលគឺក្បាល។
// ចំណិតប្រភព (កន្ទុយ) ត្រូវបានទម្លាក់ដោយ IntoIter ។
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}