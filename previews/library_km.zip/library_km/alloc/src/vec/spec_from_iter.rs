use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// ឯកទេស trait ប្រើសម្រាប់ Vec::from_iter
///
/// ## ក្រាហ្វប្រតិភូ៖
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ករណីទូទៅមួយគឺការបញ្ជូន vector ទៅក្នុងមុខងារដែលប្រមូលភ្លាមៗទៅក្នុង vector ។
        // យើងអាចធ្វើសៀគ្វីខ្លីនេះបានប្រសិនបើ IntoIter មិនបានជឿនលឿនទាល់តែសោះ។
        // នៅពេលវាបានជឿនលឿនយើងក៏អាចប្រើអង្គចងចាំនិងផ្លាស់ប្តូរទិន្នន័យទៅផ្នែកខាងមុខបានដែរ។
        // ប៉ុន្តែយើងគ្រាន់តែធ្វើដូច្នេះនៅពេលដែលលទ្ធផលដែលនឹងទទួលបាននឹងមិនមានសមត្ថភាពដែលមិនប្រើច្រើនជាងការបង្កើតវាតាមរយៈការអនុវត្តទូទៅពីអ្នកផ្គត់ផ្គង់។
        //
        // ដែនកំណត់នោះគឺជាការមិនចាំបាច់យ៉ាងតឹងរឹងជាឥរិយាបទការបែងចែកមិនបានបញ្ជាក់របស់ VEC ចេតនា។
        // ប៉ុន្តែវាជាជម្រើសអភិរក្ស។
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // ត្រូវតែធ្វើប្រតិភូកម្មដល់ក្រុមហ៊ុន spec_extend() ចាប់តាំងពី extend() ខ្លួនវាផ្ទាល់ប្រគល់អោយ spec_from សំរាប់ Vecs ទទេ
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// វិធីនេះប្រើ `iterator.as_slice().to_vec()` ព្រោះ spec_extend ត្រូវចាត់វិធានការបន្ថែមទៀតដើម្បីវែកញែកអំពីសមត្ថភាពចុងក្រោយ + ប្រវែងហើយដូច្នេះត្រូវធ្វើការងារបន្ថែមទៀត។
// `to_vec()` ចំនួនទឹកប្រាក់ដែលត្រឹមត្រូវដោយផ្ទាល់ផ្តល់និងបំពេញវាបានយ៉ាងច្បាស់។
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ជាមួយ cfg(test) វិធីសាស្ត្រ `[T]::to_vec` ជាប់ទាក់ទងដែលត្រូវការសំរាប់និយមន័យវិធីសាស្ត្រនេះគឺមិនអាចប្រើបានទេ។
    // ផ្ទុយទៅវិញប្រើមុខងារ `slice::to_vec` ដែលមានតែជាមួយ cfg(test) NB សូមមើលម៉ូឌុល slice::hack ក្នុង slice.rs សម្រាប់ព័ត៌មានបន្ថែម
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}