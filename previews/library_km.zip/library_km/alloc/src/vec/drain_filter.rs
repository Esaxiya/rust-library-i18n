use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// ឧបករណ៍រំកិលដែលប្រើការបិទដើម្បីកំណត់ថាតើធាតុមួយគួរតែត្រូវបានដកចេញ។
///
/// រចនាសម្ព័ន្ធនេះត្រូវបានបង្កើតឡើងដោយ [`Vec::drain_filter`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// សន្ទស្សន៍នៃធាតុដែលនឹងត្រូវបានត្រួតពិនិត្យដោយការហៅបន្ទាប់ទៅ `next` ។
    pub(super) idx: usize,
    /// ចំនួនធាតុដែលត្រូវបានគេបង្ហូរ (removed) រហូតមកដល់ពេលនេះ។
    pub(super) del: usize,
    /// ប្រវែងដើមនៃ `vec` មុនពេលបង្ហូរ។
    pub(super) old_len: usize,
    /// ការធ្វើតេស្តត្រងទាយទុកជាមុន។
    pub(super) pred: F,
    /// ទង់ដែលបង្ហាញពី panic បានកើតឡើងនៅក្នុងការធ្វើតេស្តត្រងជាមុន។
    /// នេះត្រូវបានប្រើជាព័ត៌មានជំនួយក្នុងការអនុវត្តទម្លាក់ដើម្បីទប់ស្កាត់ការប្រើប្រាស់នៅសេសសល់នៃ `DrainFilter` ។
    /// វត្ថុដែលមិនបានកែច្នៃណាមួយនឹងត្រូវបានបញ្ជូនត្រលប់មកវិញនៅក្នុង `vec` ប៉ុន្តែមិនមានធាតុបន្ថែមទៀតនឹងត្រូវទម្លាក់ឬសាកល្បងដោយតម្រងកំណត់ទុកជាមុនទេ។
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// ត្រឡប់សេចក្តីយោងទៅអ្នកបែងចែកមូលដ្ឋាន។
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // ធ្វើបច្ចុប្បន្នភាពលិបិក្រម *បន្ទាប់ពី* ព្យាករណ៍ត្រូវបានហៅ។
                // ប្រសិនបើសន្ទស្សន៍ត្រូវបានធ្វើបច្ចុប្បន្នភាពមុននិងការប៉ាន់ប្រមាណ panics ធាតុនៅលិបិក្រមនេះនឹងត្រូវលេចធ្លាយ។
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // នេះគឺជារដ្ឋដែលរញ៉េរញ៉ៃណាស់ហើយពិតជាមិនមានអ្វីដែលត្រូវធ្វើទេ។
                        // យើងមិនចង់បន្តព្យាយាមប្រតិបត្តិ `pred` ទេដូច្នេះយើងគ្រាន់តែដកហូតធាតុដែលមិនបានដំណើរការទាំងអស់ហើយប្រាប់វីអ៊ីធីថាវានៅតែមាន។
                        //
                        // ការវិលត្រឡប់ត្រូវបានទាមទារដើម្បីទប់ស្កាត់ការធ្លាក់ចុះទ្វេដងនៃវត្ថុដែលបានបង្ហូរចុងក្រោយដោយជោគជ័យមុនពេល panic នៅក្នុងការទស្សន៍ទាយ។
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // ព្យាយាមប្រើប្រាស់ធាតុដែលនៅសេសសល់ប្រសិនបើតម្រងកំណត់ទុកជាមុនមិនបានភ័យស្លន់ស្លោ។
        // យើងនឹងផ្លាស់ប្តូរធាតុដែលនៅសេសសល់ទោះបីយើងបានភ័យស្លន់ស្លោរួចទៅហើយឬប្រសិនបើការប្រើប្រាស់ panics ក៏ដោយ។
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}