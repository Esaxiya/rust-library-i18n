#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// ខ្លឹមសារនៃសតិថ្មីគឺមិនមានលក្ខណៈឯកឯងទេ។
    Uninitialized,
    /// ការចងចាំថ្មីត្រូវបានធានាថានឹងត្រូវបានដាក់សូន្យ។
    Zeroed,
}

/// ឧបករណ៍ប្រើប្រាស់កម្រិតទាបសម្រាប់ការបែងចែកផ្លាស់ប្តូរទីតាំងនិងដោះស្រាយសតិបណ្ដោះអាសន្ននៅលើគំនរដោយមិនចាំបាច់ព្រួយបារម្ភអំពីបញ្ហាជ្រុងទាំងអស់ដែលពាក់ព័ន្ធ។
///
/// ប្រភេទនេះគឺល្អបំផុតសម្រាប់ការកសាងរចនាសម្ព័ន្ធទិន្នន័យផ្ទាល់ខ្លួនរបស់អ្នកដូចជា Vec និង VecDeque ។
/// ជាពិសេស:
///
/// * ផលិត `Unique::dangling()` លើប្រភេទសូន្យ។
/// * ផលិត `Unique::dangling()` លើការបែងចែកប្រវែងសូន្យ។
/// * ជៀសវាងការដោះលែង `Unique::dangling()` ។
/// * ចាប់រាល់លំហូរលើសនៅក្នុងការគណនាសមត្ថភាព (លើកកម្ពស់ពួកគេទៅ "capacity overflow" panics) ។
/// * ឆ្មាំប្រឆាំងនឹងប្រព័ន្ធប៊ីត 32 ប៊ីតបែងចែកច្រើនជាង isize::MAX បៃ។
/// * ឆ្មាំប្រឆាំងនឹងប្រវែងរបស់អ្នក។
/// * ហៅទូរស័ព្ទ `handle_alloc_error` សម្រាប់ការបែងចែកដែលអាចជឿទុកចិត្តបាន។
/// * មានផ្ទុកនូវ `ptr::Unique` ហើយដូច្នេះធ្វើឱ្យអ្នកប្រើប្រាស់មានអត្ថប្រយោជន៍ដែលពាក់ព័ន្ធទាំងអស់។
/// * ប្រើលើសដែលបានត្រឡប់មកវិញពីអ្នកបែងចែកដើម្បីប្រើសមត្ថភាពដែលអាចរកបានធំបំផុត។
///
/// ប្រភេទនេះមិននៅក្នុងការត្រួតពិនិត្យសតិដែលវាគ្រប់គ្រងទេ។នៅពេលដែលទម្លាក់វានឹងធ្វើអោយការចងចាំរបស់វាទំនេរប៉ុន្តែវានឹងមិនព្យាយាមទម្លាក់មាតិការបស់វាឡើយ។
/// វាអាស្រ័យលើអ្នកប្រើ `RawVec` ដើម្បីដោះស្រាយរឿងជាក់ស្តែង *ដែលបានរក្សាទុក* នៅខាងក្នុងនៃ `RawVec` ។
///
/// ចំណាំថាចំនួនលើសនៃប្រភេទសូន្យគឺមិនចេះរីងស្ងួតដូច្នេះ `capacity()` តែងតែត្រឡប់ `usize::MAX` ។
/// នេះមានន័យថាអ្នកត្រូវប្រយ័ត្នពេលក្រឡុកប្រភេទនេះជាមួយ `Box<[T]>` ព្រោះ `capacity()` នឹងមិនមានប្រវែងទេ។
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): វាមានពីព្រោះ `#[unstable]` `const fn` មិនអនុលោមតាម `min_const_fn` ទេដូច្នេះពួកវាមិនអាចត្រូវបានហៅនៅក្នុង `min_const_fn`s ទេ។
    ///
    /// ប្រសិនបើអ្នកផ្លាស់ប្តូរ `RawVec<T>::new` ឬភាពអាស្រ័យសូមយកចិត្តទុកដាក់កុំណែនាំអ្វីដែលនឹងរំលោភលើ `min_const_fn` ។
    ///
    /// NOTE: យើងអាចចៀសវាងការ hack នេះនិងពិនិត្យមើលភាពស្របគ្នាជាមួយនឹងគុណលក្ខណៈ `#[rustc_force_min_const_fn]` មួយចំនួនដែលតម្រូវឱ្យមានការអនុលោមជាមួយ `min_const_fn` ប៉ុន្តែមិនចាំបាច់អនុញ្ញាតឱ្យហៅវានៅក្នុងលេខកូដ `stable(...) const fn`/អ្នកប្រើមិនអាចបើក `foo` នៅពេល `#[rustc_const_unstable(feature = "foo", issue = "01234")]` មាន។
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// បង្កើត `RawVec` ដែលអាចធ្វើបានធំបំផុត (នៅលើគំនរប្រព័ន្ធ) ដោយមិនចាំបាច់បែងចែក។
    /// ប្រសិនបើ `T` មានទំហំវិជ្ជមានបន្ទាប់មកនេះធ្វើឱ្យ `RawVec` មានសមត្ថភាព `0` ។
    /// ប្រសិនបើ `T` មានទំហំសូន្យបន្ទាប់មកវាធ្វើឱ្យ `RawVec` មានសមត្ថភាព `usize::MAX` ។
    /// មានប្រយោជន៍សម្រាប់ការអនុវត្តការបែងចែកយឺត។
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// បង្កើត `RawVec` មួយ (នៅលើគំនរប្រព័ន្ធ) ជាមួយនឹងការពិតជាតម្រូវការសមត្ថភាពនិងការតម្រឹមសម្រាប់ `[T; capacity]` មួយ។
    /// នេះស្មើនឹងការហៅទូរស័ព្ទ `RawVec::new` នៅពេល `capacity` គឺ `0` ឬ `T` មានទំហំសូន្យ។
    /// ចំណាំថាប្រសិនបើ `T` មានទំហំសូន្យនេះមានន័យថាអ្នកនឹងមិន * ទទួលបាន `RawVec` ដែលមានសមត្ថភាពដែលបានស្នើសុំទេ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពដែលបានស្នើសុំលើសពី `isize::MAX` បៃ។
    ///
    /// # Aborts
    ///
    /// បញ្ឈប់នៅលើអូម។
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// ដូច `with_capacity` ដែរប៉ុន្តែធានាថាសតិបណ្ដោះអាសន្នគឺសូន្យ។
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// កំណត់ឡើងវិញនូវ `RawVec` ពីទ្រនិចនិងសមត្ថភាព។
    ///
    /// # Safety
    ///
    /// `ptr` ត្រូវតែត្រូវបានបម្រុងទុក (នៅលើគំនរប្រព័ន្ធ) និងជាមួយ `capacity` ដែលបានផ្តល់ឱ្យ។
    /// `capacity` មិនអាចលើសពី `isize::MAX` សម្រាប់ប្រភេទទំហំ។(តែមានការព្រួយបារម្ភមួយនៅលើប្រព័ន្ធ 32 ប៊ីត) ។
    /// ZST vectors អាចមានសមត្ថភាពរហូតដល់ `usize::MAX` ។
    /// ប្រសិនបើ `ptr` និង `capacity` មកពី `RawVec` បន្ទាប់មកនេះត្រូវបានធានា។
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // វ៉េដវីសតូចច្រឡោត។រំលងទៅ៖
    // - 8 ប្រសិនបើទំហំធាតុគឺ 1, ដោយសារតែពួកអ្នកវិនិយោគទុនគំនរទំនងប្រមូលសំណើរបស់តិចជាង 8 បៃដើម្បីឱ្យយ៉ាងហោចណាស់ 8 បៃ។
    //
    // - ៤ ប្រសិនបើធាតុមានទំហំមធ្យម (<=១ គីប) ។
    // - ១ បើមិនដូច្នេះទេដើម្បីចៀសវាងការខ្ជះខ្ជាយកន្លែងទំនេរច្រើនពេកសម្រាប់វីដខ្លីខ្លី។
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// ដូច `new` ដែរប៉ុន្តែបានកំណត់លើជម្រើសនៃអ្នកបែងចែកសម្រាប់ `RawVec` ដែលបានត្រឡប់មកវិញ។
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` មានន័យថា "unallocated" ។ប្រភេទដែលមានទំហំសូន្យត្រូវបានគេមិនអើពើ។
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// ដូច `with_capacity` ដែរប៉ុន្តែបានកំណត់លើជម្រើសនៃអ្នកបែងចែកសម្រាប់ `RawVec` ដែលបានត្រឡប់មកវិញ។
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// ដូច `with_capacity_zeroed` ដែរប៉ុន្តែបានកំណត់លើជម្រើសនៃអ្នកបែងចែកសម្រាប់ `RawVec` ដែលបានត្រឡប់មកវិញ។
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// បំលែង `Box<[T]>` ទៅជា `RawVec<T>` ។
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// បម្លែងសតិបណ្ដោះអាសន្នទាំងមូលទៅជា `Box<[MaybeUninit<T>]>` ជាមួយ `len` ដែលបានបញ្ជាក់។
    ///
    /// ចំណាំថាវានឹងបង្កើតឡើងវិញនូវការផ្លាស់ប្តូរ `cap` យ៉ាងត្រឹមត្រូវដែលអាចត្រូវបានអនុវត្ត។(សូមមើលការពិពណ៌នាអំពីប្រភេទសម្រាប់ព័ត៌មានលម្អិត)
    ///
    /// # Safety
    ///
    /// * `len` ត្រូវតែធំជាងឬស្មើនឹងសមត្ថភាពដែលបានស្នើសុំថ្មីៗនេះនិង
    /// * `len` ត្រូវតែតិចជាងឬស្មើ `self.capacity()` ។
    ///
    /// ចំណាំថាសមត្ថភាពដែលបានស្នើសុំនិង `self.capacity()` អាចខុសគ្នាព្រោះអ្នកបែងចែកអាចពង្រីកទំហំនិងបញ្ជូនមកវិញនូវប្លុកចងចាំធំជាងការស្នើសុំ។
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // អនាម័យ-ពិនិត្យមើលពាក់កណ្តាលនៃតម្រូវការសុវត្ថិភាព (យើងមិនអាចពិនិត្យមើលពាក់កណ្តាលទៀតទេ) ។
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // យើងជៀសវាង `unwrap_or_else` នៅទីនេះព្រោះវាហើមបរិមាណ LLVM IR ដែលបានបង្កើត។
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// កំណត់ឡើងវិញនូវ `RawVec` ពីទ្រនិចសមត្ថភាពនិងអ្នកបែងចែក។
    ///
    /// # Safety
    ///
    /// `ptr` ត្រូវតែបែងចែក (តាមរយៈអ្នកបែងចែកដែលបានផ្តល់ឱ្យ `alloc`) និងជាមួយ `capacity` ដែលបានផ្តល់ឱ្យ។
    /// `capacity` មិនអាចលើសពី `isize::MAX` សម្រាប់ប្រភេទទំហំ។
    /// (មានតែការព្រួយបារម្ភលើប្រព័ន្ធ 32 ប៊ីត) ។
    /// ZST vectors អាចមានសមត្ថភាពរហូតដល់ `usize::MAX` ។
    /// ប្រសិនបើ `ptr` និង `capacity` មកពី `RawVec` ដែលបានបង្កើតតាមរយៈ `alloc` បន្ទាប់មកនេះត្រូវបានធានា។
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// ទទួលបានការទស្សន៍ទ្រនិចឆៅដើម្បីចាប់ផ្តើមនៃការបែងចែកនេះ។
    /// ចំណាំថានេះគឺជា `Unique::dangling()` ប្រសិនបើ `capacity == 0` ឬ `T` មានទំហំសូន្យ។
    /// ក្នុងករណីចាស់អ្នកត្រូវតែប្រយ័ត្ន។
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// ទទួលបានសមត្ថភាពនៃការបែងចែក។
    ///
    /// វានឹងក្លាយជា `usize::MAX` ជានិច្ចប្រសិនបើ `T` មានទំហំសូន្យ។
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// ត្រឡប់ឯកសារយោងដែលបានចែករំលែកទៅអ្នកបែងចែកដែលគាំទ្រ `RawVec` នេះ។
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // យើងមានបណ្តុំនៃអង្គចងចាំដូច្នេះយើងអាចឆ្លងកាត់ការត្រួតពិនិត្យពេលវេលាដំណើរការដើម្បីទទួលបានប្លង់បច្ចុប្បន្នរបស់យើង។
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// ធានាថាសតិបណ្ដោះអាសន្នមានយ៉ាងហោចណាស់ទំហំផ្ទុកគ្រប់គ្រាន់ដើម្បីផ្ទុកធាតុ `len + additional` ។
    /// ប្រសិនបើវាមិនទាន់មានសមត្ថភាពគ្រប់គ្រាន់ទេនោះនឹងកំណត់ទំហំទំនេរគ្រប់គ្រាន់និងកន្លែងទំនេរដែលមានផាសុខភាពដើម្បីទទួលបានឥរិយាបទរំលោះ *O*(១) ។
    ///
    /// នឹងដាក់កម្រិតលើឥរិយាបថនេះប្រសិនបើវានឹងបណ្តាលឱ្យខ្លួនវាមិនចាំបាច់ចំពោះ panic ។
    ///
    /// ប្រសិនបើ `len` លើសពី `self.capacity()` នេះប្រហែលជាបរាជ័យក្នុងការបែងចែកទំហំដែលបានស្នើសុំ។
    /// នេះពិតជាមិនមានសុវត្ថិភាពទេប៉ុន្តែលេខកូដដែលមិនមានសុវត្ថិភាព *អ្នក* សរសេរដែលពឹងផ្អែកលើឥរិយាបទនៃមុខងារនេះអាចនឹងខូច។
    ///
    /// នេះគឺល្អសម្រាប់អនុវត្តប្រតិបត្តិការជំរុញដូចជា `extend` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីលើសពី `isize::MAX` បៃ។
    ///
    /// # Aborts
    ///
    /// បញ្ឈប់នៅលើអូម។
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ទុនបំរុងនឹងត្រូវបោះបង់ចោលឬភ័យស្លន់ស្លោប្រសិនបើឡេនលើស `isize::MAX` ដូច្នេះវាមានសុវត្ថិភាពក្នុងការដោះធីកឥឡូវនេះ។
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// ដូចគ្នានឹង `reserve` ដែរប៉ុន្តែត្រលប់មកវិញនូវកំហុសឆ្គងជំនួសឱ្យការភ័យស្លន់ស្លោឬបោះបង់ចោល។
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// ធានាថាសតិបណ្ដោះអាសន្នមានយ៉ាងហោចណាស់ទំហំផ្ទុកគ្រប់គ្រាន់ដើម្បីផ្ទុកធាតុ `len + additional` ។
    /// ប្រសិនបើវាមិនទាន់មានទេនឹងរកចំនួនអប្បបរមាដែលអាចធ្វើទៅបាននៃអង្គចងចាំចាំបាច់។
    /// ជាទូទៅនេះនឹងជាចំនួនទឹកប្រាក់នៃការចងចាំដែលចាំបាច់ប៉ុន្តែជាគោលការណ៍អ្នកបែងចែកមានសេរីភាពក្នុងការផ្តល់មកវិញច្រើនជាងអ្វីដែលយើងបានស្នើសុំ។
    ///
    ///
    /// ប្រសិនបើ `len` លើសពី `self.capacity()` នេះប្រហែលជាបរាជ័យក្នុងការបែងចែកទំហំដែលបានស្នើសុំ។
    /// នេះពិតជាមិនមានសុវត្ថិភាពទេប៉ុន្តែលេខកូដដែលមិនមានសុវត្ថិភាព *អ្នក* សរសេរដែលពឹងផ្អែកលើឥរិយាបទនៃមុខងារនេះអាចនឹងខូច។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីលើសពី `isize::MAX` បៃ។
    ///
    /// # Aborts
    ///
    /// បញ្ឈប់នៅលើអូម។
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// ដូចគ្នានឹង `reserve_exact` ទេប៉ុន្តែត្រឡប់មកវិញនៅលើកំហុសជំនួសឱ្យការភ័យខ្លាចឬបោះបង់។
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// បង្រួមការបែងចែកទៅចំនួនដែលបានបញ្ជាក់។
    /// ប្រសិនបើចំនួនដែលបានផ្តល់គឺ ០ នោះពិតជាចែកចាយទាំងស្រុង។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើចំនួនដែលផ្ដល់នេះគឺមានទំហំធំជាង * * សមត្ថភាពបច្ចុប្បន្ន។
    ///
    /// # Aborts
    ///
    /// បញ្ឈប់នៅលើអូម។
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// ត្រឡប់ប្រសិនបើសតិបណ្ដោះអាសន្នត្រូវការដើម្បីបង្កើនសមត្ថភាពបន្ថែមដែលត្រូវការ។
    /// ត្រូវបានប្រើជាចម្បងដើម្បីធ្វើឱ្យការហៅទូរស័ព្ទនៅក្នុងខ្សែអាចធ្វើទៅបានដោយគ្មានការភ្ជាប់ `grow` ។
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // វិធីសាស្រ្តនេះត្រូវបានបង្កើតឡើងភ្លាមៗច្រើនដង។ដូច្នេះយើងចង់ឱ្យវាតូចតាមដែលអាចធ្វើទៅបានដើម្បីកែលម្អពេលវេលាចងក្រង។
    // ប៉ុន្តែយើងក៏ចង់អោយមាតិការបស់វាត្រូវបានគណនាតាមដែលអាចធ្វើទៅបានដើម្បីធ្វើឱ្យកូដដែលបានបង្កើតលឿនជាងមុន។
    // ដូច្នេះវិធីសាស្រ្តនេះត្រូវបានសរសេរយ៉ាងប្រុងប្រយ័ត្នដូច្នេះកូដទាំងអស់ដែលពឹងផ្អែកលើ `T` គឺស្ថិតនៅក្នុងនោះខណៈដែលកូដភាគច្រើនមិនអាស្រ័យលើ `T` តាមដែលអាចធ្វើទៅបានគឺមុខងារដែលមិនមែនជាប្រភេទទូទៅលើ `T` ។
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // នេះត្រូវបានធានាដោយបរិបទហៅ។
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // ចាប់តាំងពីយើងត្រឡប់មកវិញសមត្ថភាពនៃ `usize::MAX` នៅពេល `elem_size` គឺ
            // 0, ការមកដល់ទីនេះចាំបាច់មានន័យថា `RawVec` គឺហួសកំរិត។
            return Err(CapacityOverflow);
        }

        // គ្មានអ្វីដែលយើងអាចធ្វើបានពិតប្រាកដអំពីការត្រួតពិនិត្យទាំងនេះគួរឱ្យស្តាយ។
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // នេះធានានូវកំណើនអិចស្ប៉ូណង់ស្យែល។
        // ការកើនឡើងទ្វេដងមិនអាចហៀរចេញបានទេព្រោះ `cap <= isize::MAX` និងប្រភេទ `cap` គឺ `usize` ។
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` គឺមិនមែនទូទៅលើ `T` ទេ។
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ឧបសគ្គលើវិធីសាស្រ្តនេះគឺមានច្រើនដូចគ្នានឹងអ្វីដែលមាននៅលើ `grow_amortized` ដែរប៉ុន្តែវិធីសាស្ត្រនេះត្រូវបានបង្កើតឡើងភ្លាមៗតិចជាងមុនដូច្នេះវាមិនសូវសំខាន់ទេ។
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // ចាប់តាំងពីយើងត្រឡប់មកវិញសមត្ថភាពនៃ `usize::MAX` នៅពេលទំហំប្រភេទ
            // 0, ការមកដល់ទីនេះចាំបាច់មានន័យថា `RawVec` គឺហួសកំរិត។
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` គឺមិនមែនទូទៅលើ `T` ទេ។
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// មុខងារនេះគឺនៅខាងក្រៅ `RawVec` ដើម្បីកាត់បន្ថយពេលវេលាចងក្រងអប្បបរមា។សូមមើលការអត្ថាធិប្បាយខាងលើ `RawVec::grow_amortized` សម្រាប់ព័ត៌មានលម្អិត។
// (ប៉ារ៉ាម៉ែត្រ `A` មិនសំខាន់ទេពីព្រោះចំនួន `A` ប្រភេទផ្សេងៗគ្នាដែលគេឃើញក្នុងការអនុវត្តគឺតូចជាងចំនួននៃប្រភេទ `T` ។)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // ពិនិត្យមើលកំហុសនៅទីនេះដើម្បីកាត់បន្ថយទំហំ `RawVec::grow_*` ។
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // អ្នកបែងចែកពិនិត្យមើលភាពស្មើគ្នានៃការតំរឹម
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// យល់ព្រមការចងចាំដែលជាកម្មសិទ្ធិរបស់ `RawVec`*ដោយគ្មាន* ព្យាយាមទម្លាក់មាតិការបស់វា។
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// មុខងារកណ្តាលសម្រាប់ដោះស្រាយកំហុសបំរុង។
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// យើងត្រូវធានាដូចខាងក្រោមៈ
// * យើងមិនដែលបម្រុងទុកវត្ថុទំហំ `> isize::MAX` បៃទេ។
// * យើងមិនលើសចំណុះ `usize::MAX` ទេហើយយើងបែងចែកតិចតួចណាស់។
//
// 64 ប៊ីតយើងគ្រាន់តែត្រូវការពិនិត្យមើលការហៀរចេញចាប់តាំងពីការព្យាយាមបម្រុងទុក `> isize::MAX` បៃច្បាស់ជានឹងបរាជ័យ។
// 32 ប៊ីតនិង 16 ប៊ីតយើងត្រូវការបន្ថែមឆ្មាំបន្ថែមសម្រាប់ករណីនេះក្នុងករណីដែលយើងកំពុងដំណើរការនៅលើវេទិកាដែលអាចប្រើទំហំ 4GB ទាំងអស់នៅក្នុងទំហំអ្នកប្រើប្រាស់ឧទាហរណ៍ PAE ឬ x32 ។
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// មុខងារកណ្តាលមួយទទួលខុសត្រូវចំពោះការរាយការណ៍សមត្ថភាពលើសចំណុះ។
// នេះនឹងធានាថាការបង្កើតលេខកូដទាក់ទងនឹងហ្សីនផិននិចហ្សេហ្សិនទាំងនេះមានតិចតួចបំផុតពីព្រោះមានតែទីតាំងតែមួយប៉ុណ្ណោះដែលហ្សហ្ស៊ីពននិកហ្សិចជាជាងបណ្តុំម៉ូឌុល។
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}