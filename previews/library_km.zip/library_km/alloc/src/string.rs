//! UTF-8 - បានអ៊ិនកូដជាខ្សែអក្សរដែលអាចលូតលាស់បាន។
//!
//! ម៉ូឌុលនេះមានប្រភេទ [`String`] ប្រភេទ [`ToString`] trait សម្រាប់បំលែងទៅជាខ្សែអក្សរនិងប្រភេទកំហុសជាច្រើនដែលអាចបណ្តាលមកពីការធ្វើការជាមួយ [`ខ្សែអក្សរ` s) ។
//!
//!
//! # Examples
//!
//! មានវិធីច្រើនយ៉ាងដើម្បីបង្កើត [`String`] ថ្មីពីខ្សែអក្សរត្រង់៖
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! អ្នកអាចបង្កើត [`String`] ថ្មីពីមួយដែលមានស្រាប់ដោយការផ្សំជាមួយ
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! ប្រសិនបើអ្នកមាន vector មួយនៃសុពលភាព UTF-8 បៃ, អ្នកអាចធ្វើឱ្យ [`String`] មួយចេញពីវា។អ្នកក៏អាចធ្វើបញ្ច្រាសបានដែរ។
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // យើងដឹងថាបៃទាំងនេះមានសុពលភាពដូច្នេះយើងនឹងប្រើ `unwrap()` ។
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// UTF-8 - បានអ៊ិនកូដជាខ្សែអក្សរដែលអាចលូតលាស់បាន។
///
/// ប្រភេទ `String` គឺជាប្រភេទខ្សែអក្សរទូទៅបំផុតដែលមានកម្មសិទ្ធិលើមាតិកានៃខ្សែអក្សរ។វាមានទំនាក់ទំនងជិតស្និទ្ធជាមួយសមភាគីខ្ចីរបស់វាគឺ [`str`] បឋម។
///
/// # Examples
///
/// អ្នកអាចបង្កើត `String` ពី [a literal string][`str`] ជាមួយ [`String::from`]៖
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// អ្នកអាចបន្ថែម [`char`] ទៅ `String` ជាមួយនឹងវិធីសាស្ត្រ [`push`] និងបន្ថែម [`&str`] ជាមួយនឹងវិធីសាស្ត្រ [`push_str`]៖
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// ប្រសិនបើអ្នកមាន vector នៃ UTF-8 បៃអ្នកអាចបង្កើត `String` ពីវាដោយប្រើវិធីសាស្ត្រ [`from_utf8`]៖
///
/// ```
/// // បៃខ្លះក្នុងហ្សុងវ៉េហ្ស័រ ០ ហ្ស
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // យើងដឹងថាបៃទាំងនេះមានសុពលភាពដូច្នេះយើងនឹងប្រើ `unwrap()` ។
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `ខ្សែអក្សរ` តែងតែមានសុពលភាព UTF-8 ។នេះមានផលប៉ះពាល់មួយចំនួនដែលដំបូងបង្អស់គឺប្រសិនបើអ្នកត្រូវការខ្សែអក្សរដែលមិនមែនជាយូធីហ្វា-8 សូមពិចារណា [`OsString`] ។វាស្រដៀងគ្នាប៉ុន្តែដោយគ្មានឧបសគ្គ UTF-8 ។ផលប៉ះពាល់ទីពីរគឺអ្នកមិនអាចដាក់លិបិក្រមទៅជា `String` ទេ៖
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// ការបង្កើតលិបិក្រមត្រូវបានបម្រុងទុកសម្រាប់ប្រតិបត្តិការថេរប៉ុន្តែការអ៊ិនកូដ UTF-8 មិនអនុញ្ញាតឱ្យយើងធ្វើបែបនេះទេ។លើសពីនេះទៀតវាមិនច្បាស់ទេថាតើអ្វីទៅជាប្រភេទនៃសន្ទស្សន៍គួរវិលត្រឡប់មកវិញ: បៃចំណុចកូដឬចង្កោមទំពាំងបាយជូរ។
/// វិធីសាស្រ្ត [`bytes`] និង [`chars`] ត្រលប់មកវិញម្តងទៀតក្នុងរយៈពេលពីរដំបូងរៀងៗខ្លួន។
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `ខ្សែអក្សរ` អនុវត្ត [`ដឺរេហ្វ`] `<Target=str>`ហើយដូច្នេះវិធីសាស្រ្តទាំងអស់របស់ [`str`] គឺទទួលមរតក។លើសពីនេះទៀតនេះមានន័យថាអ្នកអាចហុច `String` ទៅមុខងារដែលយក [`&str`] ដោយប្រើ ampersand (`&`)៖
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// នេះនឹងបង្កើត [`&str`] ពី `String` ហើយហុចវា។ ការបំលែងនេះមានតំលៃថោកណាស់ហើយដូច្នេះមុខងារនឹងទទួលយក [`&str`] ជាអាគុយម៉ង់លើកលែងតែពួកគេត្រូវការ `String` សម្រាប់ហេតុផលជាក់លាក់។
///
/// ក្នុងករណីខ្លះ Rust មិនមានព័ត៌មានគ្រប់គ្រាន់ដើម្បីធ្វើការផ្លាស់ប្តូរនេះដែលគេហៅថាការបង្ខិតបង្ខំ [`Deref`] ។ក្នុងឧទាហរណ៍ខាងក្រោមការកាត់ខ្សែអក្សរ [`&'a str`][`&str`] អនុវត្ត trait `TraitExample` ហើយមុខងារ `example_func` យកអ្វីដែលអនុវត្ត trait ។
/// ក្នុងករណីនេះ Rust ត្រូវការធ្វើការផ្លាស់ប្តូរការសន្ទនាពីរយ៉ាងដែល Rust មិនមានមធ្យោបាយធ្វើ។
/// សម្រាប់ហេតុផលនេះឧទាហរណ៍ខាងក្រោមនឹងមិនចងក្រងទេ។
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// មានជម្រើសពីរដែលនឹងធ្វើការជំនួស។ទីមួយគឺត្រូវផ្លាស់ប្តូរបន្ទាត់ `example_func(&example_string);` ទៅ `example_func(example_string.as_str());` ដោយប្រើវិធីសាស្ត្រ [`as_str()`] ដើម្បីស្រង់ចេញជាចំណែក ៗ ដែលមានខ្សែអក្សរ។
/// វិធីទីពីរផ្លាស់ប្តូរ `example_func(&example_string);` ទៅ `example_func(&*example_string);` ។
/// ក្នុងករណីនេះយើងកំពុងបដិសេធ `String` ទៅ [`str`][`&str`] បន្ទាប់មកយោង [`str`][`&str`] ត្រលប់ទៅ [`&str`] វិញ។
/// វិធីទី ២ គឺប្លែកជាងនេះទៅទៀតទោះយ៉ាងណាអ្នកទាំងពីរធ្វើការផ្លាស់ប្តូរការផ្លាស់ប្តូរយ៉ាងជាក់លាក់ជាជាងពឹងផ្អែកលើការប្រែចិត្តជឿជាក់។
///
/// # Representation
///
/// `String` ត្រូវបានផ្សំឡើងដោយសមាសធាតុបីយ៉ាងគឺព្រួញចង្អុលទៅបៃប្រវែងនិងសមត្ថភាព។ទ្រនិចចង្អុលទៅសតិបណ្ដោះអាសន្ន `String` ប្រើដើម្បីរក្សាទុកទិន្នន័យរបស់វា។ប្រវែងគឺជាចំនួនបៃដែលផ្ទុកក្នុងសតិបណ្ដោះអាសន្នហើយសមត្ថភាពគឺទំហំរបស់សតិបណ្ដោះអាសន្នគិតជាបៃ។
///
/// ដូចនោះប្រវែងនឹងតិចជាងឬស្មើនឹងសមត្ថភាពជានិច្ច។
///
/// សតិបណ្ដោះអាសន្ននេះតែងតែត្រូវបានរក្សាទុកនៅលើគំនរ។
///
/// អ្នកអាចមើលវិធីទាំងនេះដោយប្រើវិធីសាស្ត្រ [`as_ptr`], [`len`], និង [`capacity`]៖
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME ធ្វើបច្ចុប្បន្នភាពវានៅពេល vec_into_raw_parts មានស្ថេរភាព។
/// // រារាំងការទម្លាក់ទិន្នន័យរបស់ខ្សែអក្សរដោយស្វ័យប្រវត្តិ
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // រឿងមានដប់ប្រាំបួនបៃ
/// assert_eq!(19, len);
///
/// // យើងអាចសាងសង់ឡើងវិញចេញពីខ្សែអក្សរ PTR, Len និងសមត្ថភាព។
/// // ទាំងអស់នេះមិនមានសុវត្ថិភាពទេពីព្រោះយើងទទួលខុសត្រូវក្នុងការធ្វើឱ្យប្រាកដថាសមាសធាតុមានសុពលភាព៖
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// ប្រសិនបើ `String` មានសមត្ថភាពគ្រប់គ្រាន់ការបន្ថែមធាតុទៅវានឹងមិនបែងចែកឡើងវិញទេ។ឧទាហរណ៍ពិចារណាកម្មវិធីនេះ៖
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// លទ្ធផលនេះនឹងមានដូចខាងក្រោមៈ
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// ដំបូងយើងគ្មានសតិបម្រុងទុកទាល់តែសោះប៉ុន្តែនៅពេលយើងបន្ថែមខ្សែអក្សរវាបង្កើនសមត្ថភាពរបស់វាឱ្យបានត្រឹមត្រូវ។ប្រសិនបើយើងប្រើវិធី [`with_capacity`] ជំនួសដើម្បីបែងចែកសមត្ថភាពត្រឹមត្រូវដំបូង៖
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// យើងបញ្ចប់ដោយលទ្ធផលផ្សេង៖
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// នៅទីនេះមិនចាំបាច់បែងចែកសតិបន្ថែមទៀតនៅក្នុងរង្វិលជុំទេ។
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// តម្លៃកំហុសដែលអាចកើតមាននៅពេលបំលែង `String` ពី UTF-8 បៃ vector ។
///
/// ប្រភេទនេះគឺជាប្រភេទកំហុសសម្រាប់វិធីសាស្ត្រ [`from_utf8`] នៅលើ [`String`] ។
/// វាត្រូវបានរចនាតាមរបៀបដើម្បីចៀសវាងការផ្លាស់ប្តូរទីតាំងដោយប្រុងប្រយ័ត្ន: វិធីសាស្ត្រ [`into_bytes`] នឹងផ្តល់នូវបៃ vector ដែលត្រូវបានប្រើក្នុងការប៉ុនប៉ងបំលែង។
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// ប្រភេទ [`Utf8Error`] ដែលផ្តល់ដោយ [`std::str`] តំណាងឱ្យកំហុសដែលអាចកើតឡើងនៅពេលបំលែងចំណែក [`u8`] ទៅជា [`&str`] ។
/// ក្នុងន័យនេះវាជាអាណាឡូកទៅនឹង `FromUtf8Error` ហើយអ្នកអាចទទួលបានពីលេខ `FromUtf8Error` តាមរយៈវិធីសាស្ត្រ [`utf8_error`] ។
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// // បៃមិនត្រឹមត្រូវមួយចំនួននៅក្នុងហ្សុនហ្សេវីហ្សហ្សិនហ្សហ្ស៊ីហ្ស
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// តម្លៃកំហុសដែលអាចកើតមាននៅពេលបំលែង `String` ពីចំណិត UTF-16 បៃ។
///
/// ប្រភេទនេះគឺជាប្រភេទកំហុសសម្រាប់វិធីសាស្ត្រ [`from_utf16`] នៅលើ [`String`] ។
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// បង្កើត `String` ទទេថ្មី។
    ///
    /// ដែលបានផ្តល់ឱ្យថា `String` គឺទទេនេះនឹងមិនបែងចែកសតិបណ្ដោះអាសន្នដំបូងទេ។ខណៈពេលនោះមានន័យថាប្រតិបត្តិការដំបូងនេះមានតំលៃថោកណាស់វាអាចបណ្តាលឱ្យមានការបែងចែកហួសប្រមាណនៅពេលក្រោយនៅពេលអ្នកបន្ថែមទិន្នន័យ។
    ///
    /// ប្រសិនបើអ្នកមានគំនិតថាតើទិន្នន័យចំនួនប៉ុន្មានដែល `String` នឹងរក្សាទុកសូមពិចារណាវិធីសាស្ត្រ [`with_capacity`] ដើម្បីការពារការបែងចែកឡើងវិញច្រើនពេក។
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// បង្កើត `String` ទទេថ្មីដែលមានសមត្ថភាពជាក់លាក់។
    ///
    /// `ឃ្លា` មានសតិបណ្ដោះអាសន្នផ្ទៃក្នុងមួយដើម្បីរៀបចំទិន្នន័យរបស់ពួកគេ។
    /// សមត្ថភាពគឺប្រវែងនៃអង្គចងចាំបណ្ដោះអាសន្ននោះហើយអាចត្រូវបានសួរជាមួយនឹងវិធីសាស្ត្រ [`capacity`] ។
    /// វិធីសាស្រ្តនេះបង្កើត `String` ទទេប៉ុន្តែមួយដែលមានសតិបណ្ដោះអាសន្នដំបូងដែលអាចផ្ទុក `capacity` បៃ។
    /// វាមានប្រយោជន៍នៅពេលដែលអ្នកអាចនឹងត្រូវបានបន្ថែម bunch នៃទិន្នន័យដើម្បី `String` មួយកាត់បន្ថយចំនួននៃវិភាជន៍ឡើងវិញវាត្រូវការដើម្បីធ្វើ។
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// ប្រសិនបើសមត្ថភាពដែលបានផ្តល់គឺ `0` នោះគ្មានការបែងចែកនឹងកើតឡើងទេហើយវិធីសាស្ត្រនេះគឺដូចគ្នាទៅនឹងវិធីសាស្ត្រ [`new`] ដែរ។
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // ខ្សែនេះមិនមានគំនូសតាងទេទោះបីជាវាមានសមត្ថភាពច្រើនក៏ដោយ
    /// assert_eq!(s.len(), 0);
    ///
    /// // ទាំងអស់នេះត្រូវបានធ្វើដោយមិនចាំបាច់បែងចែក ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... ប៉ុន្តែនេះអាចធ្វើឱ្យខ្សែនេះរុះរើ
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ជាមួយ cfg(test) វិធីសាស្ត្រ `[T]::to_vec` ជាប់ទាក់ទងដែលត្រូវការសំរាប់និយមន័យវិធីសាស្ត្រនេះគឺមិនអាចប្រើបានទេ។
    // ដោយសារយើងមិនត្រូវការវិធីសាស្ត្រនេះសម្រាប់គោលបំណងតេស្តខ្ញុំនឹងចាក់វាត្រង់ NB សូមមើលម៉ូឌុល slice::hack នៅក្នុង slice.rs សម្រាប់ព័ត៌មានបន្ថែម។
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// បំលែង vector បៃទៅជា `String` ។
    ///
    /// ខ្សែអក្សរ ([`String`]) ត្រូវបានបង្កើតឡើងដោយបៃ ([`u8`]) ហើយ vector នៃបៃ ([`Vec<u8>`]) ត្រូវបានបង្កើតឡើងដោយបៃដូច្នេះមុខងារនេះបំលែងរវាងពីរ។
    /// ចំណិតបៃទាំងអស់មិនមានសុពលភាព `ខ្សែអក្សរទេប៉ុន្តែ `String` ទាមទារថាវាមានសុពលភាព UTF-8 ។
    /// `from_utf8()` ត្រួតពិនិត្យដើម្បីធានាថាបៃមានសុពលភាព UTF-8 ហើយបន្ទាប់មកធ្វើការបម្លែង។
    ///
    /// ប្រសិនបើអ្នកប្រាកដថាចំណែកបៃគឺមានសុពលភាព UTF-8 ហើយអ្នកមិនចង់ទទួលរងនូវការត្រួតពិនិត្យសុពលភាពទេមានមុខងារមិនមានសុវត្ថិភាពគឺ [`from_utf8_unchecked`] ដែលមានឥរិយាបទដូចគ្នាប៉ុន្តែរំលងការត្រួតពិនិត្យ។
    ///
    ///
    /// វិធីសាស្រ្តនេះនឹងយកចិត្តទុកដាក់ក្នុងការមិនចំលង vector ដើម្បីផលប្រយោជន៍។
    ///
    /// ប្រសិនបើអ្នកត្រូវការ [`&str`] ជំនួសឱ្យ `String` សូមពិចារណា [`str::from_utf8`] ។
    ///
    /// ការដាក់បញ្ច្រាសនៃវិធីសាស្ត្រនេះគឺ [`into_bytes`] ។
    ///
    /// # Errors
    ///
    /// ត្រឡប់ [`Err`] ប្រសិនបើចំណិតមិនមែនជា UTF-8 ជាមួយនឹងការពិពណ៌នាអំពីមូលហេតុដែលបៃដែលបានផ្តល់មិនមែនជា UTF-8 ។vector ដែលអ្នកបានផ្លាស់ទីលំនៅក៏ត្រូវបានរាប់បញ្ចូលផងដែរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // បៃខ្លះក្នុងហ្សុងវ៉េហ្ស័រ ០ ហ្ស
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // យើងដឹងថាបៃទាំងនេះមានសុពលភាពដូច្នេះយើងនឹងប្រើ `unwrap()` ។
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// បៃមិនត្រឹមត្រូវ:
    ///
    /// ```
    /// // បៃមិនត្រឹមត្រូវមួយចំនួននៅក្នុងហ្សុនហ្សេវីហ្សហ្សិនហ្សហ្ស៊ីហ្ស
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// សូមមើលឯកសារសម្រាប់ [`FromUtf8Error`] សម្រាប់ព័ត៌មានលម្អិតបន្ថែមអំពីអ្វីដែលអ្នកអាចធ្វើបានជាមួយកំហុសនេះ។
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// បម្លែងបៃមួយចំណែកទៅជាខ្សែអក្សររួមទាំងតួអក្សរមិនត្រឹមត្រូវ។
    ///
    /// ខ្សែត្រូវបានធ្វើពីបៃ ([`u8`]) ហើយបៃមួយចំណែក ([`&[u8]`][byteslice]) ត្រូវបានបង្កើតឡើងដោយបៃដូច្នេះមុខងារនេះបម្លែងរវាងពីរ។មិនមែនចំណិតបៃទាំងអស់សុទ្ធតែជាខ្សែអក្សរត្រឹមត្រូវនោះទេ៖ ខ្សែអក្សរត្រូវមានលេខ UTF-8 ត្រឹមត្រូវ។
    /// ក្នុងអំឡុងពេលនៃការបំលែងនេះ `from_utf8_lossy()` នឹងជំនួសលេខ UTF-8 ដែលមិនត្រឹមត្រូវជាមួយ [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ដែលមើលទៅដូចនេះ៖
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// ប្រសិនបើអ្នកប្រាកដថាចំណែកបៃគឺមានសុពលភាព UTF-8 ហើយអ្នកមិនចង់ទទួលរងនូវការផ្លាស់ប្តូរនោះទេមានមុខងារមិនមានសុវត្ថិភាពមួយគឺ [`from_utf8_unchecked`] ដែលមានឥរិយាបទដូចគ្នាប៉ុន្តែរំលងការត្រួតពិនិត្យ។
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// មុខងារនេះត្រឡប់ [`Cow<'a, str>`] ។ប្រសិនបើចំណុះបៃរបស់យើងមិនត្រឹមត្រូវ UTF-8 បន្ទាប់មកយើងត្រូវបញ្ចូលតួអក្សរជំនួសដែលនឹងផ្លាស់ប្តូរទំហំខ្សែអក្សរហេតុដូចនេះហើយតម្រូវឱ្យមាន `String` ។
    /// ប៉ុន្តែប្រសិនបើវាមានសុពលភាពរួចហើយ UTF-8 យើងមិនត្រូវការការបែងចែកថ្មីទេ។
    /// ប្រភេទត្រឡប់មកវិញនេះអនុញ្ញាតឱ្យយើងដោះស្រាយករណីទាំងពីរ។
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // បៃខ្លះក្នុងហ្សុងវ៉េហ្ស័រ ០ ហ្ស
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// បៃមិនត្រឹមត្រូវ:
    ///
    /// ```
    /// // បៃមិនត្រឹមត្រូវ
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// ឌិគ្រីប UTF-16 - បានអ៊ិនកូដ vector `v` ទៅជា `String`, ត្រឡប់ [`Err`] ប្រសិនបើ `v` មានទិន្នន័យមិនត្រឹមត្រូវ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // នេះមិនត្រូវបានធ្វើតាមរយៈការប្រមូល: : <Result<_, _>> () សម្រាប់ហេតុផលនៃការអនុវត្ត។
        // FIXME: មុខងារអាចត្រូវបានធ្វើឱ្យសាមញ្ញម្តងទៀតនៅពេល #48994 ត្រូវបានបិទ។
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// ឌិកូដ UTF-16 slice ដែលបានអ៊ិនកូដ `v` ទៅជា `String` ជំនួសទិន្នន័យមិនត្រឹមត្រូវជាមួយ [the replacement character (`U+FFFD`)][U+FFFD] ។
    ///
    /// មិនដូច [`from_utf8_lossy`] ដែលត្រឡប់ [`Cow<'a, str>`] ទេ `from_utf16_lossy` ត្រឡប់ `String` ចាប់តាំងពីការបំលែង UTF-16 ទៅ UTF-8 ត្រូវការការបែងចែកសតិ។
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// បំបែក `String` ទៅក្នុងសមាសធាតុឆៅរបស់វា។
    ///
    /// ត្រឡប់ទ្រនិចឆៅទៅទិន្នន័យមូលដ្ឋានប្រវែងខ្សែអក្សរ (គិតជាបៃ) និងសមត្ថភាពបែងចែកទិន្នន័យ (គិតជាបៃ) ។
    /// ទាំងនេះគឺជាអាគុយម៉ង់ដូចគ្នានៅក្នុងលំដាប់ដូចគ្នានឹងអាគុយម៉ង់ទៅ [`from_raw_parts`] ។
    ///
    /// បន្ទាប់ពីហៅមុខងារនេះអ្នកទូរស័ព្ទចូលត្រូវទទួលខុសត្រូវចំពោះអង្គចងចាំដែលបានគ្រប់គ្រងពីមុនដោយ `String` ។
    /// មធ្យោបាយតែមួយគត់ក្នុងការធ្វើដូចនេះគឺបំលែងទ្រនិចប្រវែងនិងសមត្ថភាពត្រឡប់ទៅជា `String` ដែលមានមុខងារ [`from_raw_parts`] ដែលអាចឱ្យអ្នកបំផ្លាញបំផ្លាញការសម្អាត។
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// បង្កើត `String` ថ្មីពីប្រវែងសមត្ថភាពនិងទ្រនិច។
    ///
    /// # Safety
    ///
    /// នេះមិនមានសុវត្ថិភាពខ្ពស់ទេដោយសារចំនួននៃការលុកលុយដែលមិនបានត្រួតពិនិត្យ៖
    ///
    /// * សតិនៅ `buf` ត្រូវការអោយប្រើពីមុនដោយអ្នកបែងចែកដូចគ្នានឹងបណ្ណាល័យស្តង់ដាប្រើជាមួយការតម្រឹមដែលត្រូវការគឺពិតប្រាកដ ១ ។
    /// * `length` ត្រូវការតិចជាងរឺស្មើ `capacity` ។
    /// * `capacity` ត្រូវការជាតំលៃត្រឹមត្រូវ។
    /// * `length` បៃដំបូងនៅ `buf` ត្រូវមានសុពលភាព UTF-8 ។
    ///
    /// ការបំពានទាំងនេះអាចបណ្តាលឱ្យមានបញ្ហាដូចជាការធ្វើឱ្យខូចរចនាសម្ព័ន្ធទិន្នន័យផ្ទៃក្នុងរបស់អ្នកបែងចែក។
    ///
    /// ភាពជាម្ចាស់របស់ `buf` ត្រូវបានផ្ទេរទៅឱ្យ `String` ដែលបន្ទាប់មកអាចផ្លាស់ប្តូរទីតាំងផ្លាស់ប្តូរទីតាំងឬផ្លាស់ប្តូរខ្លឹមសារនៃការចងចាំដែលចង្អុលបង្ហាញដោយទ្រនិចតាមឆន្ទៈ។
    /// ធានាថាមិនមានអ្វីផ្សេងទៀតប្រើទ្រនិចបន្ទាប់ពីហៅមុខងារនេះ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME ធ្វើបច្ចុប្បន្នភាពវានៅពេល vec_into_raw_parts មានស្ថេរភាព។
    ///     // រារាំងការទម្លាក់ទិន្នន័យរបស់ខ្សែអក្សរដោយស្វ័យប្រវត្តិ
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// បំលែង vector បៃទៅជា `String` ដោយមិនពិនិត្យមើលថាខ្សែនេះមានអក្សរ UTF-8 ត្រឹមត្រូវ។
    ///
    /// មើលកំណែសុវត្ថិភាព [`from_utf8`] សម្រាប់ព័ត៌មានលម្អិត។
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// មុខងារនេះគឺមិនមានសុវត្ថិភាពនោះទេព្រោះវាមិនពិនិត្យមើលថាបៃកន្លងផុតទៅវាមានសុពលភាព UTF-8 ។
    /// ប្រសិនបើឧបសគ្គនេះត្រូវបានរំលោភបំពានវាអាចបណ្តាលឱ្យមានបញ្ហាអសមត្ថភាពក្នុងការចងចាំជាមួយអ្នកប្រើប្រាស់ future នៃ `String` ខណៈដែលបណ្ណាល័យស្ដង់ដារផ្សេងទៀតសន្មតថា `ខ្សែអក្សរគឺត្រឹមត្រូវ UTF-8 ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // បៃខ្លះក្នុងហ្សុងវ៉េហ្ស័រ ០ ហ្ស
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// បំលែង `String` ទៅជាបៃ vector ។
    ///
    /// នេះស៊ី `String` ដូច្នេះយើងមិនចាំបាច់ចម្លងមាតិការបស់វាទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// ដកស្រង់ចំណែកខ្សែដែលមានអក្សរ `String` ទាំងមូល។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// បំលែង `String` ទៅជាខ្សែអក្សរដែលអាចផ្លាស់ប្តូរបាន។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// ដាក់ផ្នែកមួយនៃខ្សែអក្សរដែលដាក់នៅចុង `String` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// ត្រឡប់សមត្ថភាព `ខ្សែអក្សរ` នេះជាបៃ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ធានាថាសមត្ថភាព `ខ្សែនេះ` គឺយ៉ាងហោចណាស់ `additional` បៃធំជាងប្រវែងរបស់វា។
    ///
    /// សមត្ថភាពអាចនឹងកើនឡើងជាង `additional` បៃប្រសិនបើវាជ្រើសរើសដើម្បីការពារការផ្លាស់ទីលំនៅជាញឹកញាប់។
    ///
    ///
    /// ប្រសិនបើអ្នកមិនចង់បានអាកប្បកិរិយា "at least" នេះទេសូមមើលវិធីសាស្ត្រ [`reserve_exact`] ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីហូរលើស [`usize`] ។
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// នេះប្រហែលជាមិនបង្កើនសមត្ថភាពទេ។
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // ឥឡូវមានប្រវែង ២ និងចំណុះ ១០
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ដោយសារយើងមានសមត្ថភាពបន្ថែម ៨ រួចទៅហើយដោយហៅវាថា ...
    /// s.reserve(8);
    ///
    /// // ... តាមពិតមិនមានការកើនឡើងទេ។
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ធានាថាសមត្ថភាព `ខ្សែនេះ` គឺ `additional` បៃធំជាងប្រវែងរបស់វា។
    ///
    /// ពិចារណាប្រើវិធី [`reserve`] លុះត្រាតែអ្នកដឹងច្បាស់ជាងអ្នកបែងចែក។
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីហូរលើស `usize` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// នេះប្រហែលជាមិនបង្កើនសមត្ថភាពទេ។
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // ឥឡូវមានប្រវែង ២ និងចំណុះ ១០
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ដោយសារយើងមានសមត្ថភាពបន្ថែម ៨ រួចទៅហើយដោយហៅវាថា ...
    /// s.reserve_exact(8);
    ///
    /// // ... តាមពិតមិនមានការកើនឡើងទេ។
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// ព្យាយាមបម្រុងទុកសម្រាប់ធាតុយ៉ាងតិច `additional` បន្ថែមទៀតដែលត្រូវបញ្ចូលក្នុង `String` ដែលបានផ្តល់ឱ្យ។
    /// ការប្រមូលផ្ដុំអាចមានកន្លែងទំនេរច្រើនដើម្បីចៀសវាងការផ្លាស់ទីលំនៅជាញឹកញាប់។
    /// បន្ទាប់ពីហៅទូរស័ព្ទ `reserve` សមត្ថភាពនឹងធំជាងឬស្មើ `self.len() + additional` ។
    /// មិនធ្វើអ្វីទាំងអស់ប្រសិនបើសមត្ថភាពគ្រប់គ្រាន់ហើយ។
    ///
    /// # Errors
    ///
    /// ប្រសិនបើសមត្ថភាពហួសចំណុះឬអ្នកបែងចែករាយការណ៍ពីការបរាជ័យបន្ទាប់មកកំហុសនឹងត្រូវបានប្រគល់មកវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // ទុកការចងចាំទុកជាមុនសិនបើយើងមិនអាច
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ឥឡូវនេះយើងដឹងថានេះមិនអាចជាអូមនៅពាក់កណ្តាលការងារស្មុគស្មាញរបស់យើងទេ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// ព្យាយាមបម្រុងទុកសមត្ថភាពអប្បបរមាសម្រាប់ធាតុបន្ថែមចំនួន `additional` ដែលត្រូវបញ្ចូលក្នុង `String` ដែលបានផ្តល់ឱ្យ។
    ///
    /// បន្ទាប់ពីហៅទូរស័ព្ទ `reserve_exact` សមត្ថភាពនឹងធំជាងឬស្មើ `self.len() + additional` ។
    /// មិនធ្វើអ្វីទេប្រសិនបើសមត្ថភាពគ្រប់គ្រាន់ហើយ។
    ///
    /// ចំណាំថាអ្នកបែងចែកអាចផ្តល់កន្លែងប្រមូលច្រើនជាងកន្លែងដែលវាស្នើសុំ។
    /// ដូច្នេះសមត្ថភាពមិនអាចពឹងផ្អែកបានលើចំនួនតិចតួចបំផុតទេ។
    /// ចូលចិត្ត `reserve` ប្រសិនបើការបញ្ចូល future ត្រូវបានរំពឹងទុក។
    ///
    /// # Errors
    ///
    /// ប្រសិនបើសមត្ថភាពហួសចំណុះឬអ្នកបែងចែករាយការណ៍ពីការបរាជ័យបន្ទាប់មកកំហុសនឹងត្រូវបានប្រគល់មកវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // ទុកការចងចាំទុកជាមុនសិនបើយើងមិនអាច
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ឥឡូវនេះយើងដឹងថានេះមិនអាចជាអូមនៅពាក់កណ្តាលការងារស្មុគស្មាញរបស់យើងទេ
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// បង្រួមសមត្ថភាពរបស់ `String` នេះឱ្យត្រូវនឹងប្រវែងរបស់វា។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// បង្រួមសមត្ថភាពរបស់ `String` នេះជាមួយនឹងកម្រិតទាប។
    ///
    /// សមត្ថភាពនឹងនៅតែមានយ៉ាងហោចណាស់យ៉ាងហោចណាស់ទាំងប្រវែងនិងតម្លៃដែលបានផ្គត់ផ្គង់។
    ///
    ///
    /// ប្រសិនបើសមត្ថភាពបច្ចុប្បន្នតិចជាងដែនកំណត់ទាបនេះមិនមែនជាអាយភីទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// បញ្ចូល [`char`] ដល់ចុង `String` នេះ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ត្រឡប់ចំណែកបៃនៃមាតិកា `ខ្សែអក្សរ` នេះ។
    ///
    /// ការដាក់បញ្ច្រាសនៃវិធីសាស្ត្រនេះគឺ [`from_utf8`] ។
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// បង្រួម `String` នេះទៅនឹងប្រវែងដែលបានបញ្ជាក់។
    ///
    /// ប្រសិនបើ `new_len` ធំជាងប្រវែងបច្ចុប្បន្ននៃខ្សែអក្សរនេះមិនមានផលប៉ះពាល់ទេ។
    ///
    ///
    /// ចំណាំថាវិធីសាស្រ្តនេះមិនមានឥទ្ធិពលលើសមត្ថភាពដែលបានបម្រុងទុកនៃខ្សែអក្សរទេ
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `new_len` មិនដែលនិយាយកុហកនៅលើព្រំដែន [`char`] ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// យកតួអក្សរចុងក្រោយចេញពីសតិបណ្ដោះអាសន្នហើយត្រឡប់វា។
    ///
    /// ត្រឡប់ [`None`] ប្រសិនបើ `String` នេះទទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// យក [`char`] ចេញពី `String` នេះនៅទីតាំងបៃហើយត្រឡប់វា។
    ///
    /// នេះគឺជាប្រតិបត្តិការ *O*(*n*) ព្រោះវាតម្រូវឱ្យចម្លងរាល់ធាតុទាំងអស់ក្នុងសតិបណ្ដោះអាសន្ន។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `idx` គឺមានទំហំធំជាងឬស្មើទៅនឹង `ឃ្លាប្រវែងរបស់, ឬប្រសិនបើវាមិនដែលនិយាយកុហកនៅលើព្រំដែន [`char`] ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// ដកការប្រកួតទាំងអស់នៃលំនាំ `pat` ក្នុង `String` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// ការផ្គូផ្គងនឹងត្រូវបានរកឃើញនិងដកចេញជាដដែលដូច្នេះក្នុងករណីដែលលំនាំត្រួតគ្នាមានតែលំនាំដំបូងប៉ុណ្ណោះដែលនឹងត្រូវបានយកចេញ៖
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // សុវត្ថិភាព: ការចាប់ផ្តើមនិងបញ្ចប់នឹងមាននៅលើព្រំដែនបៃហ្សិច utf8 ក្នុងមួយ
        // នេះឯកសារឧបករស្វែងរក
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// រក្សាទុកតែតួអក្សរដែលបានបញ្ជាក់ដោយអ្នកព្យាករណ៍។
    ///
    /// និយាយម្យ៉ាងទៀតដកតួអក្សរទាំងអស់ `c` ចេញដែល `f(c)` ត្រឡប់ `false` ។
    /// វិធីសាស្រ្តនេះដំណើរការនៅនឹងកន្លែងដោយទស្សនាតួអក្សរនីមួយៗយ៉ាងជាក់លាក់តាមលំដាប់ដើមហើយរក្សាលំដាប់នៃតួអក្សរដែលបានរក្សាទុក។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// លំដាប់ពិតប្រាកដអាចមានប្រយោជន៍សម្រាប់តាមដានស្ថានភាពខាងក្រៅដូចជាសន្ទស្សន៍។
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // ចង្អុល idx ទៅ char បន្ទាប់
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// បញ្ចូលតួអក្សរទៅក្នុង `String` នេះនៅទីតាំងបៃ។
    ///
    /// នេះគឺជាប្រតិបត្តិការ *O*(*n*) ព្រោះវាតម្រូវឱ្យចម្លងរាល់ធាតុនៅក្នុងអង្គចងចាំ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `idx` ធំជាងប្រវែងរបស់ `ខ្សែអក្សរ` ឬប្រសិនបើវាមិនស្ថិតនៅលើព្រំដែន [`char`] ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// បញ្ចូលខ្សែអក្សរទៅក្នុង `String` នេះនៅទីតាំងបៃ។
    ///
    /// នេះគឺជាប្រតិបត្តិការ *O*(*n*) ព្រោះវាតម្រូវឱ្យចម្លងរាល់ធាតុនៅក្នុងអង្គចងចាំ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `idx` ធំជាងប្រវែងរបស់ `ខ្សែអក្សរ` ឬប្រសិនបើវាមិនស្ថិតនៅលើព្រំដែន [`char`] ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅមាតិកានៃ `String` នេះ។
    ///
    /// # Safety
    ///
    /// មុខងារនេះគឺមិនមានសុវត្ថិភាពនោះទេព្រោះវាមិនពិនិត្យមើលថាបៃកន្លងផុតទៅវាមានសុពលភាព UTF-8 ។
    /// ប្រសិនបើឧបសគ្គនេះត្រូវបានរំលោភបំពានវាអាចបណ្តាលឱ្យមានបញ្ហាអសមត្ថភាពក្នុងការចងចាំជាមួយអ្នកប្រើប្រាស់ future នៃ `String` ខណៈដែលបណ្ណាល័យស្ដង់ដារផ្សេងទៀតសន្មតថា `ខ្សែអក្សរគឺត្រឹមត្រូវ UTF-8 ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// ត្រឡប់ប្រវែង `String` នេះគិតជាបៃមិនមែនជា [gra char]] ឬ graphemes ទេ។
    /// និយាយម៉្យាងទៀតវាប្រហែលជាមិនមែនជាអ្វីដែលមនុស្សម្នាក់គិតពីប្រវែងនៃខ្សែនោះទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `String` នេះមានប្រវែងសូន្យហើយបើមិនដូច្នេះទេ `false` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// បំបែកខ្សែអក្សរជាពីរនៅសន្ទស្សន៍បៃដែលបានផ្តល់ឱ្យ។
    ///
    /// ត្រឡប់ `String` ដែលបានបម្រុងទុកថ្មី។
    /// `self` មានបៃ `[0, at)` ហើយ `String` ដែលត្រឡប់មកវិញមានផ្ទុកបៃ `[at, len)` ។
    /// `at` ត្រូវតែស្ថិតនៅលើព្រំដែននៃចំនុចកូដ UTF-8 ។
    ///
    /// ចំណាំថាសមត្ថភាពរបស់ `self` មិនផ្លាស់ប្តូរទេ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `at` មិនស្ថិតនៅលើព្រំដែនចំនុចលេខកូដ `UTF-8` ឬប្រសិនបើវាហួសពីចំនុចកូដចុងក្រោយនៃខ្សែ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// កាត់ចេញ `String` នេះដោយដកចេញមាតិកាទាំងអស់។
    ///
    /// ខណៈពេលដែលនេះមានន័យថា `String` នឹងមានប្រវែងសូន្យវាមិនប៉ះសមត្ថភាពរបស់វាទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// បង្កើតឧបករណ៍ច្រោះទឹកដែលដកជួរដែលបានបញ្ជាក់នៅក្នុង `String` ហើយផ្តល់ទិន្នផល `chars` ដែលបានដកចេញ។
    ///
    ///
    /// Note: ជួរធាតុត្រូវបានដកចេញទោះបីជាឧបករណ៍រំកិលមិនត្រូវបានប្រើប្រាស់រហូតដល់ទីបញ្ចប់ក៏ដោយ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើការចាប់ផ្តើមឬចំណុចចុងមិនមានចំណុចនៅលើព្រំដែនកុហក [`char`] ឬប្រសិនបើពួកគេស្ថិតនៅក្រៅព្រំដែន។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // យកជួរឡើងរហូតដល់លេខβពីខ្សែអក្សរ
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // ជួរពេញលេញលុបខ្សែ
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // សុវត្ថិភាពនៃការចងចាំ
        //
        // កំណែខ្សែអក្សររបស់ Drain មិនមានបញ្ហាសុវត្ថិភាពនៃការចងចាំនៃកំណែ vector ទេ។
        // ទិន្នន័យគ្រាន់តែជាបៃធម្មតាប៉ុណ្ណោះ។
        // ដោយសារតែការដកយកចេញជួរដែលបានកើតឡើងនៅក្នុងទម្លាក់បើបម្រុង Drain ត្រូវបានលេចធ្លាយដកយកចេញនេះនឹងមិនកើតឡើង។
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // យកខ្ចីពីរក្នុងពេលដំណាលគ្នា។
        // ខ្សែអក្សរ &mut នឹងមិនអាចចូលប្រើបានទេរហូតទាល់តែវាចប់។
        let self_ptr = self as *mut _;
        // សុវត្ថិភាព: `slice::range` និង `is_char_boundary` ធ្វើការត្រួតពិនិត្យព្រំដែនត្រឹមត្រូវ។
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// យកជួរដែលបានបញ្ជាក់នៅក្នុងខ្សែអក្សរចេញហើយជំនួសវាដោយខ្សែដែលបានផ្តល់ឱ្យ។
    /// ខ្សែអក្សរដែលបានផ្តល់មិនចាំបាច់មានប្រវែងដូចគ្នានឹងជួរទេ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើការចាប់ផ្តើមឬចំណុចចុងមិនមានចំណុចនៅលើព្រំដែនកុហក [`char`] ឬប្រសិនបើពួកគេស្ថិតនៅក្រៅព្រំដែន។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // ជំនួសជួររហូតដល់លេខβពីខ្សែអក្សរ
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // សុវត្ថិភាពនៃការចងចាំ
        //
        // Replace_range មិនមានបញ្ហាសុវត្ថិភាពនៃការចងចាំរបស់ vector Splice ទេ។
        // នៃកំណែ vector ។ទិន្នន័យគ្រាន់តែជាបៃធម្មតាប៉ុណ្ណោះ។

        // ការព្រមាន: ការដាក់បញ្ចូលអថេរនេះនឹងមិនមាន (#81138) ទេ
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // ការព្រមាន: ការដាក់បញ្ចូលអថេរនេះនឹងមិនមាន (#81138) ទេ
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // ការប្រើប្រាស់ `range` ម្តងទៀតនឹងមិនមានសុពលភាពទេ (#81138) យើងសន្មតថាព្រំដែនដែលបានរាយការណ៍ដោយ `range` នៅតែដដែលប៉ុន្តែការអនុវត្តផ្ទុយអាចផ្លាស់ប្តូររវាងការហៅទូរស័ព្ទ
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// បម្លែង `String` នេះទៅជា [`ប្រអប់`] `<` [`str`]`>`។
    ///
    /// នេះនឹងធ្លាក់ចុះសមត្ថភាពលើស។
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// ត្រឡប់ចំណែកនៃ [`u8`] បៃដែលបានព្យាយាមបំលែងទៅជា `String` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // បៃមិនត្រឹមត្រូវមួយចំនួននៅក្នុងហ្សុនហ្សេវីហ្សហ្សិនហ្សហ្ស៊ីហ្ស
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// ត្រឡប់បៃដែលបានព្យាយាមបំលែងទៅជា `String` ។
    ///
    /// វិធីសាស្រ្តនេះត្រូវបានសាងសង់យ៉ាងប្រុងប្រយ័ត្នដើម្បីជៀសវាងការបែងចែក។
    /// វានឹងប្រើប្រាស់នូវកំហុសដោយរំកិលខ្លួនចេញពីបៃដូច្នេះការចម្លងបៃមិនចាំបាច់ធ្វើទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // បៃមិនត្រឹមត្រូវមួយចំនួននៅក្នុងហ្សុនហ្សេវីហ្សហ្សិនហ្សហ្ស៊ីហ្ស
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// ទៅយក `Utf8Error` ដើម្បីទទួលបានព័ត៌មានលម្អិតបន្ថែមអំពីការបរាជ័យក្នុងការបំលែង។
    ///
    /// ប្រភេទ [`Utf8Error`] ដែលផ្តល់ដោយ [`std::str`] តំណាងឱ្យកំហុសដែលអាចកើតឡើងនៅពេលបំលែងចំណែក [`u8`] ទៅជា [`&str`] ។
    /// ក្នុងន័យនេះវាជាអាណាឡូកទៅនឹង `FromUtf8Error` ។
    /// សូមមើលឯកសាររបស់វាសម្រាប់ព័ត៌មានលម្អិតអំពីការប្រើប្រាស់វា។
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // បៃមិនត្រឹមត្រូវមួយចំនួននៅក្នុងហ្សុនហ្សេវីហ្សហ្សិនហ្សហ្ស៊ីហ្ស
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // បៃទី ១ មិនមានសុពលភាពនៅទីនេះទេ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ដោយសារតែយើងនិយាយអំពីខ្សែអក្សរ `យើងអាចចៀសវាងការបែងចែកយ៉ាងតិចមួយដោយទទួលខ្សែទីមួយពីអ្នកតាក់តែងហើយបន្ថែមទៅខ្សែអក្សរបន្តបន្ទាប់ទៀត។
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ដោយសារតែយើងធ្វើវាលើសពី CoWs យើងអាច (potentially) ចៀសវាងការបែងចែកយ៉ាងតិចមួយដោយទទួលបានធាតុទីមួយហើយបន្ថែមវាទៅវត្ថុបន្ទាប់។
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// ភាពងាយស្រួលបង្ហាញថាប្រតិភូទៅលេខ `&str` ។
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// បង្កើត `String` ទទេ។
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// អនុវត្តប្រតិបត្តិករ `+` សម្រាប់ការដាក់ខ្សែពីរ។
///
/// វាស៊ីស៊ី `String` នៅខាងឆ្វេងហើយប្រើសតិបណ្ដោះអាសន្នរបស់វាឡើងវិញ (ដាំវាបើចាំបាច់) ។
/// នេះត្រូវបានធ្វើដើម្បីចៀសវាងការបែងចែក `String` ថ្មីនិងការចម្លងមាតិកាទាំងមូលលើប្រតិបត្តិការទាំងអស់ដែលនឹងនាំឱ្យមានពេលវេលារត់ *O*(*n*^ ២) នៅពេលសាងសង់ខ្សែអក្សរ *n*-byte ដោយការបូកសរុបម្តងហើយម្តងទៀត។
///
///
/// ខ្សែនៅខាងស្តាំត្រូវបានខ្ចីតែប៉ុណ្ណោះ។មាតិការបស់វាត្រូវបានចម្លងទៅក្នុង `String` ដែលបានត្រឡប់មកវិញ។
///
/// # Examples
///
/// ការបញ្ចូលគ្នានូវខ្សែអក្សរពីរគឺទីមួយដោយតម្លៃហើយខ្ចីទីពីរ៖
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` ត្រូវបានផ្លាស់ទីហើយមិនអាចប្រើនៅទីនេះទៀតទេ។
/// ```
///
/// ប្រសិនបើអ្នកចង់បន្តប្រើប្រាស់ `String` ដំបូងអ្នកអាចក្លូនវាហើយបន្ថែមទៅក្លូនជំនួស៖
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` គឺនៅតែមានសុពលភាពនៅទីនេះ។
/// ```
///
/// ចំណិតដាក់បន្តគ្នា `&str` អាចត្រូវបានធ្វើដោយការបម្លែងជាលើកដំបូងដើម្បី `String` មួយ:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// អនុវត្តប្រតិបត្តិករ `+=` សម្រាប់បន្ថែមទៅ `String` ។
///
/// នេះមានឥរិយាបទដូចគ្នានឹងវិធីសាស្ត្រ [`push_str`][String::push_str] ដែរ។
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// ឈ្មោះហៅក្រៅមួយប្រភេទសម្រាប់ [`Infallible`] ។
///
/// ឈ្មោះហៅក្រៅនេះមានសម្រាប់ភាពឆបគ្នាថយក្រោយហើយអាចត្រូវបានបដិសេធនៅទីបំផុត។
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait សម្រាប់បំលែងតំលៃទៅជា `String` ។
///
/// trait នេះត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិសម្រាប់ប្រភេទណាមួយដែលអនុវត្ត [`Display`] trait ។
/// ដូច្នេះ `ToString` មិនគួរត្រូវបានអនុវត្តដោយផ្ទាល់ទេ៖
/// [`Display`] គួរតែត្រូវបានអនុវត្តជំនួសវិញហើយអ្នកនឹងទទួលបានការអនុវត្ត `ToString` ដោយឥតគិតថ្លៃ។
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// បម្លែងតម្លៃដែលបានផ្តល់ទៅជា `String` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// នៅក្នុងការអនុវត្តនេះវិធីសាស្ត្រ `to_string` panics ប្រសិនបើការអនុវត្ត `Display` ត្រលប់មកវិញនូវកំហុស។
/// នេះបង្ហាញពីការអនុវត្ត `Display` មិនត្រឹមត្រូវចាប់តាំងពី `fmt::Write for String` មិនដែលត្រឡប់កំហុសដោយខ្លួនឯង។
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // គោលការណ៍ណែនាំទូទៅគឺមិនដាក់បញ្ចូលមុខងារទូទៅ។
    // ទោះយ៉ាងណាក៏ដោយការយក `#[inline]` ចេញពីវិធីសាស្ត្រនេះបណ្តាលឱ្យមានការតំរែតំរង់មិនធ្វេសប្រហែស។
    // សូមមើល <https://github.com/rust-lang/rust/pull/74852>, ការប៉ុនប៉ងចុងក្រោយដើម្បីព្យាយាមយកវាចេញ។
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// បំលែង `&mut str` ទៅជា `String` ។
    ///
    /// លទ្ធផលត្រូវបានបម្រុងទុកនៅលើគំនរ។
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ការសាកល្បងទាញនៅក្នុង libstd ដែលបណ្តាលឱ្យមានកំហុសនៅទីនេះ
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// បំលែងចំណែកប្រអប់ដែលបានផ្តល់អោយ `str` ទៅជា `String` ។
    /// គួរកត់សម្គាល់ថាចំណិត `str` ជាកម្មសិទ្ធិ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// បម្លែង `String` ដែលបានផ្តល់ទៅជាចំណែក `str` ដែលមានប្រអប់ដែលជាកម្មសិទ្ធិ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// បម្លែងចំណែកមួយជាខ្សែអក្សរទៅជាវ៉ារ្យ៉ង់ខ្ចី។
    /// គ្មានការបែងចែកហ៊ាត្រូវបានអនុវត្តទេហើយខ្សែអក្សរមិនត្រូវបានចម្លងទេ។
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// បំលែងខ្សែអក្សរទៅជាបំរែបំរួលកម្មសិទ្ធិ។
    /// គ្មានការបែងចែកហ៊ាត្រូវបានអនុវត្តទេហើយខ្សែអក្សរមិនត្រូវបានចម្លងទេ។
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// បម្លែងសេចក្តីយោងខ្សែអក្សរទៅជាវ៉ារ្យ៉ង់ខ្ចី។
    /// គ្មានការបែងចែកហ៊ាត្រូវបានអនុវត្តទេហើយខ្សែអក្សរមិនត្រូវបានចម្លងទេ។
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// បម្លែង `String` ដែលបានផ្តល់ទៅឱ្យ vector `Vec` ដែលផ្ទុកតម្លៃនៃប្រភេទ `u8` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// ឧបករណ៍ច្រោះទឹកសម្រាប់ `String` ។
///
/// struct នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ដ្រ [`drain`] លើ [`String`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// នឹងត្រូវបានប្រើជា&'mut ខ្សែអក្សរនៅក្នុងអ្នកបំផ្លាញ
    string: *mut String,
    /// ចាប់ផ្តើមនៃផ្នែកដើម្បីដកចេញ
    start: usize,
    /// ចុងបញ្ចប់នៃផ្នែកដើម្បីដកចេញ
    end: usize,
    /// ជួរដែលនៅសល់បច្ចុប្បន្នត្រូវដកចេញ
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // ប្រើ Vec::drain ។
            // "Reaffirm" ការត្រួតពិនិត្យព្រំដែនដើម្បីជៀសវាងលេខកូដ panic ត្រូវបានបញ្ចូលម្តងទៀត។
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// ត្រឡប់ខ្សែអក្សរនៅសល់ (រង) នៃឧបករណ៍ដដែលនេះជាចំណិត។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: ការមិនពេញចិត្ត AsRef បង្កប់នៅខាងក្រោមនៅពេលមានស្ថេរភាព។
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// សេចក្តីអធិប្បាយនៅពេលដែលស្ថិរភាព `string_drain_as_str` ។
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>សម្រាប់ Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> សម្រាប់ Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}