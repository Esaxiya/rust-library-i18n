use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // ការសរសេរការធ្វើតេស្តនៃការធ្វើសមាហរណកម្មរវាងអ្នកបែងចែកភាគីទីបីនិង `RawVec` គឺពិបាកបន្តិចពីព្រោះ `RawVec` API មិនបង្ហាញវិធីសាស្ត្របែងចែកដែលអាចទទួលយកបានទេដូច្នេះយើងមិនអាចពិនិត្យមើលថាមានអ្វីកើតឡើងនៅពេលអ្នកបែងចែកអស់កម្លាំង (ក្រៅពីរកឃើញ panic) ។
    //
    //
    // ផ្ទុយទៅវិញនេះគ្រាន់តែពិនិត្យមើលថាវិធីសាស្ត្រ `RawVec` យ៉ាងហោចណាស់ត្រូវឆ្លងកាត់ Allocator API នៅពេលវារក្សាទុកការផ្ទុក។
    //
    //
    //
    //
    //

    // អ្នកបែងចែកមិនចេះនិយាយដែលប្រើប្រាស់បរិមាណប្រេងថេរមុនពេលការប៉ុនប៉ងការបែងចែកចាប់ផ្តើមបរាជ័យ។
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (បណ្តាលឱ្យមានទីតាំងពិតប្រាកដដូច្នេះការប្រើប្រាស់ប្រេងឥន្ធនៈ 50 + 150=200 គ្រឿង)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ដំបូង `reserve` បែងចែកដូចជា `reserve_exact` ។
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // ៩៧ ច្រើនជាងទ្វេដងនៃ ៧ ដូច្នេះ `reserve` គួរតែដំណើរការដូច `reserve_exact` ។
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // ៣ គឺតិចជាងពាក់កណ្តាល ១២ ដូច្នេះ `reserve` ត្រូវតែរីកចម្រើននិទស្សន្ត។
        // នៅពេលសរសេរកត្តាលូតលាស់នៃតេស្តនេះគឺ ២ ដូច្នេះសមត្ថភាពថ្មីគឺ ២៤ ទោះយ៉ាងណាកត្តាលូតលាស់របស់ 1.5 ក៏មិនអីដែរ។
        //
        // ដូច្នេះ `>= 18` នៅក្នុងការអះអាង។
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}