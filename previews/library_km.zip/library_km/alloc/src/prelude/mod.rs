//! ការបែងចែក Preclus
//!
//! គោលបំណងនៃម៉ូឌុលនេះគឺដើម្បីកាត់បន្ថយការនាំចូលទំនិញដែលត្រូវបានប្រើជាទូទៅរបស់ `alloc` crate ដោយបន្ថែមការនាំចូលគ្លីបទៅផ្នែកខាងលើនៃម៉ូឌុល៖
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;