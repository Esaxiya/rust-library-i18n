use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// បញ្ចូលគូតម្លៃសំខាន់ៗទាំងអស់ពីសហជីពពីរឡើងលើបង្កើន `length` X អថេរ។ក្រោយមកទៀតធ្វើឱ្យអ្នកហៅទូរស័ព្ទងាយជាងមុនដើម្បីចៀសវាងការលេចធ្លាយនៅពេលដែលឧបករណ៍ដោះស្រាយធ្លាក់ចុះ។
    ///
    /// ប្រសិនបើអ្នកធ្វើវាទាំងពីរបង្កើតកូនសោតែមួយវិធីសាស្ត្រនេះទម្លាក់គូពីអ្នកធ្វើឆ្វេងនិយមហើយបញ្ចោញគូពីអ្នកធ្វើខាងស្តាំ។
    ///
    /// ប្រសិនបើអ្នកចង់ឱ្យដើមឈើបញ្ចប់ដោយលំដាប់ឡើងយ៉ាងតឹងរឹងដូចជាសម្រាប់ `BTreeMap` អ្នកធ្វើវាទាំងពីរគួរតែបង្កើតកូនសោតាមលំដាប់ឡើងយ៉ាងតឹងរឹងដែលធំជាងគ្រាប់ចុចទាំងអស់នៅក្នុងមែកធាងរួមទាំងកូនសោណាមួយដែលមានរួចហើយនៅក្នុងមែកធាងនៅពេលចូល។
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // យើងរៀបចំបញ្ចូល `left` X និង `right` ចូលទៅក្នុងលំដាប់តម្រៀបតាមពេលវេលាលីនេអ៊ែរ។
        let iter = MergeIter(MergeIterInner::new(left, right));

        // ទន្ទឹមនឹងនេះយើងសាងសង់មែកធាងពីលំដាប់តម្រៀបតាមពេលវេលាលីនេអ៊ែរ។
        self.bulk_push(iter, length)
    }

    /// ជំរុញគូដែលមានតម្លៃគ្រាប់ចុចទៅចុងដើមឈើបង្កើនអថេរ `length` នៅតាមផ្លូវ។
    /// ក្រោយមកទៀតធ្វើឱ្យអ្នកហៅទូរស័ព្ទងាយជាងមុនដើម្បីចៀសវាងការលេចធ្លាយនៅពេលដែលឧបករណ៍រំកិលកើតឡើង។
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // ច្របាច់បញ្ចូលគ្នារវាងគូដែលមានតម្លៃសំខាន់ទាំងអស់រុញវាទៅជាថ្នាំងនៅកម្រិតត្រឹមត្រូវ។
        for (key, value) in iter {
            // ព្យាយាមជំរុញគូដែលមានតម្លៃគ្រាប់ចុចទៅក្នុងថ្នាំងស្លឹកបច្ចុប្បន្ន។
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // មិនមានកន្លែងទំនេរទេឡើងទៅលើហើយរុញនៅទីនោះ។
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // រកឃើញថ្នាំងដែលមានដកឃ្លានៅខាងឆ្វេងរុញនៅទីនេះ។
                                open_node = parent;
                                break;
                            } else {
                                // ឡើងម្តងទៀត។
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // យើងស្ថិតនៅខាងលើបង្កើតថ្នាំងឫសថ្មីហើយរុញនៅទីនោះ។
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // ជំរុញគូតម្លៃសំខាន់និងអនុក្រឹត្យខាងស្តាំថ្មី។
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // ចុះទៅស្លឹកខាងស្តាំម្តងទៀត។
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // បង្កើនប្រវែងរាល់ការឆ្លើយតបដើម្បីធ្វើឱ្យប្រាកដថាផែនទីទម្លាក់ធាតុដែលបានបន្ថែមទោះបីជាវាកំពុងកើនឡើងក៏ដោយ។
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// ឧបករណ៍រំកិលមួយសម្រាប់បញ្ចូលគ្នានូវលំដាប់ដែលបានតម្រៀបជាពីរ
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// ប្រសិនបើកូនសោពីរស្មើគ្នាសូមត្រឡប់គូតម្លៃគ្រាប់ចុចពីប្រភពខាងស្តាំ។
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}