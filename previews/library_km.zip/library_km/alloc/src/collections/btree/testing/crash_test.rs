use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// ប្លង់មេសម្រាប់ការសាកល្បងគាំងអត់ចេះសោះដែលតាមដានព្រឹត្តិការណ៍ជាក់លាក់។
/// វត្ថុខ្លះអាចត្រូវបានតំឡើងទៅ panic នៅចំណុចខ្លះ។
/// ព្រឹត្តិការណ៍គឺ `clone`, `drop` ឬ `query` អនាមិកមួយចំនួន។
///
/// នំប៉ាវសាកល្បងគាំងត្រូវបានកំណត់និងបញ្ជាដោយលេខសម្គាល់ដូច្នេះពួកគេអាចត្រូវបានប្រើជាកូនសោនៅក្នុង BTreeMap ។
/// ការប្រើប្រាស់ដោយចេតនាមិនពឹងផ្អែកលើអ្វីដែលបានកំណត់នៅក្នុង crate ក្រៅពី `Debug` trait ។
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// បង្កើតការរចនាឌីមមីសាកល្បងសាកល្បងគាំង។`id` កំណត់លំដាប់និងភាពស្មើគ្នានៃវត្ថុ។
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// បង្កើតឧទាហរណ៏នៃការអត់ចេះសោះការគាំងគាំងដែលកត់ត្រាព្រឹត្តិការណ៍អ្វីដែលវាបានជួបប្រទះនិងជាជម្រើស panics ។
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// ត្រឡប់ចំនួនដងនៃករណីអត់ចេះសោះត្រូវបានក្លូន។
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// ត្រឡប់ចំនួនដងនៃករណីអត់ចេះសោះត្រូវបានទម្លាក់។
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// ត្រឡប់តើមានករណីអត់ចេះសោះប៉ុន្មានដងដែលបានហៅសមាជិក `query` របស់ពួកគេ។
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// សំណួរអនាមិកមួយចំនួនដែលលទ្ធផលត្រូវបានផ្តល់ឱ្យរួចហើយ។
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}