// នេះគឺជាការប៉ុនប៉ងក្នុងការអនុវត្តស្របតាមឧត្តមគតិ
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// ដោយហេតុថា Rust ពិតជាមិនមានប្រភេទពឹងផ្អែកនិងការហៅឡើងវិញច្រើនទេយើងធ្វើជាមួយសុវត្ថិភាពច្រើន។
//

// គោលដៅសំខាន់នៃម៉ូឌុលនេះគឺដើម្បីចៀសវាងភាពស្មុគស្មាញដោយចាត់ទុកដើមឈើជាធុងផ្ទុកទូទៅ (ប្រសិនបើមានរាងចម្លែក) និងចៀសវាងការទាក់ទងនឹងការលុកលុយរបស់មែកធាង B-Tree ភាគច្រើន។
//
// ដូច, ម៉ូឌុលនេះមិនខ្វល់ថាតើធាតុត្រូវបានតម្រៀបដែលជាថ្នាំងដែលអាចត្រូវបាន underfull ឬសូម្បីតែអ្វីដែលមានន័យថា underfull ។ទោះយ៉ាងណាយើងពឹងផ្អែកលើការលុកលុយមួយចំនួន៖
//
// - ដើមឈើត្រូវតែមានឯកសណ្ឋាន depth/height ។នេះមានន័យថារាល់ផ្លូវចុះទៅស្លឹកពីថ្នាំងដែលបានផ្តល់ឱ្យមានប្រវែងដូចគ្នា។
// - ថ្នាំងនៃប្រវែង `n` មានកូនសោ `n` តម្លៃ `n` និងគែម `n + 1` ។
//   នេះបញ្ជាក់ថាសូម្បីតែថ្នាំងទទេក៏មានយ៉ាងហោចណាស់ edge ដែរ។
//   ចំពោះថ្នាំងស្លឹកវិញ "having an edge" គ្រាន់តែមានន័យថាយើងអាចកំណត់ទីតាំងនៅក្នុងថ្នាំងបានព្រោះគែមស្លឹកទទេហើយមិនត្រូវការតំណាងទិន្នន័យទេ។
// នៅក្នុងថ្នាំងខាងក្នុងមួយ edge ទាំងពីរកំណត់ទីតាំងនិងមានទ្រនិចចង្អុលទៅថ្នាំងកុមារ។
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// ការតំណាងជាមូលដ្ឋាននៃថ្នាំងស្លឹកនិងផ្នែកនៃតំណាងនៃថ្នាំងខាងក្នុង។
struct LeafNode<K, V> {
    /// យើងចង់ក្លាយជាអ្នកariantនៅក្នុង `K` និង `V` ។
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// សន្ទស្សន៍របស់ថ្នាំងនេះទៅក្នុងអារេ `edges` របស់ថ្នាំងមេ។
    /// `*node.parent.edges[node.parent_idx]` គួរតែដូចគ្នានឹង `node` ដែរ។
    /// នេះត្រូវបានធានាថានឹងត្រូវបានចាប់ផ្តើមនៅពេលដែល `parent` មិនមែនជាមោឃៈ។
    parent_idx: MaybeUninit<u16>,

    /// ចំនួនកូនសោនិងតម្លៃនៃថ្នាំងនេះផ្ទុក។
    len: u16,

    /// អារេរក្សាទុកទិន្នន័យជាក់ស្តែងនៃថ្នាំង។
    /// មានតែធាតុ `len` ដំបូងនៃអារេនីមួយៗត្រូវបានចាប់ផ្តើមនិងមានសុពលភាព។
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// ចាប់ផ្តើមកន្លែងថ្មី `LeafNode` ។
    unsafe fn init(this: *mut Self) {
        // ក្នុងនាមជាគោលការណ៍ទូទៅយើងទុកវាលដែលមិនមានឯកសិទ្ធិប្រសិនបើពួកគេអាចធ្វើបានព្រោះវាគួរតែលឿននិងងាយស្រួលក្នុងការតាមដាននៅវ៉ាលហ្គិន។
        //
        unsafe {
            // parent_idx គ្រាប់ចុចនិងវ៉លលុគឺប្រហែលជាយូប៊ីននិត
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// បង្កើតប្រអប់ថ្មី `LeafNode` ។
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// តំណាងមូលដ្ឋាននៃថ្នាំងខាងក្នុង។ដូចគ្នានឹង `LeafNode`s ទាំងនេះគួរតែត្រូវបានលាក់នៅពីក្រោយ`BoxedNode`ដើម្បីការពារការទម្លាក់គ្រាប់ចុចនិងតម្លៃដែលមិនមានឯកសិទ្ធិ។
/// ទ្រនិចណាមួយទៅ `InternalNode` អាចត្រូវបានបោះដោយផ្ទាល់ទៅទ្រនិចទៅផ្នែក `LeafNode` នៃថ្នាំងដែលអនុញ្ញាតឱ្យលេខកូដធ្វើសកម្មភាពនៅលើស្លឹកនិងថ្នាំងខាងក្នុងដោយមិនចាំបាច់ពិនិត្យមើលថាតើមួយណាដែលទ្រនិចចង្អុលកំពុងចង្អុល។
///
/// ទ្រព្យសម្បត្តិនេះត្រូវបានបើកដោយការប្រើប្រាស់ `repr(C)` ។
///
#[repr(C)]
// gdb_providers.py ប្រើឈ្មោះប្រភេទនេះសម្រាប់ការស្រាវជ្រាវ។
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// ចង្អុលបង្ហាញដល់កុមារនៃថ្នាំងនេះ។
    /// `len + 1` ទាំងនេះត្រូវបានគេចាត់ទុកថាជាការចាប់ផ្តើមនិងមានសុពលភាពលើកលែងតែនៅជិតចុងបញ្ចប់ខណៈពេលដែលដើមឈើត្រូវបានកាន់កាប់តាមរយៈប្រភេទខ្ចី `Dying` ចំនុចខ្លះទាំងនេះត្រូវបានព្យួរ។
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// បង្កើតប្រអប់ថ្មី `InternalNode` ។
    ///
    /// # Safety
    /// ការរាតត្បាតនៃថ្នាំងខាងក្នុងគឺថាពួកគេមានយ៉ាងហោចណាស់មួយបានចាប់ផ្តើមនិងមានសុពលភាព edge ។
    /// មុខងារនេះមិនបានតំឡើង edge បែបនេះទេ។
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // យើងគ្រាន់តែត្រូវការចាប់ផ្តើមទិន្នន័យប៉ុណ្ណោះ។គែមគឺប្រហែលជាយូនីនិត។
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ទ្រនិចដែលមិនត្រូវបានគ្រប់គ្រងទៅនឹងថ្នាំង។នេះគឺជាទស្សន៍ទ្រនិចដែលជាកម្មសិទ្ធិរបស់ `LeafNode<K, V>` ឬចង្អុលទៅម្ចាស់ `InternalNode<K, V>` ។
///
/// ទោះយ៉ាងណាក៏ដោយ `BoxedNode` មិនមានព័ត៌មានថាតើថ្នាំងពីរប្រភេទណាដែលវាមានហើយមួយផ្នែកដោយសារតែកង្វះព័ត៌មាននេះមិនមែនជាប្រភេទដាច់ដោយឡែកនិងគ្មានអ្នកបំផ្លាញ។
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ថ្នាំងឫសនៃមែកធាងដែលជាកម្មសិទ្ធិ។
///
/// ចំណាំថានេះមិនមានអ្នកបំផ្លាញទេហើយត្រូវតែសម្អាតដោយដៃ។
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// ត្រឡប់មែកធាងដែលមានកម្មសិទ្ធិថ្មីដោយមានថ្នាំងជា root របស់វាដែលដំបូងគឺទទេ។
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` មិនត្រូវសូន្យ។
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// ខ្ចីថ្នាំង root ដែលជាកម្មសិទ្ធិរបស់គ្នាទៅវិញទៅមក។
    /// មិនដូច `reborrow_mut` វាមានសុវត្ថិភាពពីព្រោះតម្លៃត្រឡប់មកវិញមិនអាចត្រូវបានប្រើដើម្បីបំផ្លាញឫសហើយមិនមានឯកសារយោងផ្សេងទៀតទាក់ទងនឹងដើមឈើទេ។
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ខ្ចីថ្នាំងប្ញសរបស់ម្ចាស់។
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ការផ្លាស់ប្តូរដែលមិនអាចផ្លាស់ប្តូរបានទៅជាឯកសារយោងដែលអនុញ្ញាតឱ្យមានការឆ្លងកាត់និងផ្តល់នូវវិធីសាស្ត្របំផ្លិចបំផ្លាញនិងតិចតួច។
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// បន្ថែមថ្នាំងខាងក្នុងថ្មីដែលមាន edge តែមួយចង្អុលទៅថ្នាំងឫសមុនធ្វើថ្នាំងថ្មីជាថ្នាំង root ហើយត្រឡប់វា។
    /// នេះបង្កើនកម្ពស់ត្រឹម ១ និងផ្ទុយពី `pop_internal_level` ។
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, លើកលែងតែថាយើងគ្រាន់តែភ្លេចយើងឥឡូវនេះផ្ទៃក្នុង:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// យកថ្នាំងឫសខាងក្នុងចេញដោយប្រើកូនដំបូងរបស់វាជាថ្នាំងឫសថ្មី។
    /// ដូចដែលវាត្រូវបានគេហៅថាតែនៅពេលដែលថ្នាំងជា root មានកូនតែមួយគ្មានការសម្អាតត្រូវបានធ្វើឡើងលើកូនសោតម្លៃនិងកូនដទៃទៀតទេ។
    ///
    /// នេះបន្ថយកម្ពស់ត្រឹម ១ និងផ្ទុយពី `push_internal_level` ។
    ///
    /// តម្រូវឱ្យមានការចូលប្រើផ្តាច់មុខលើវត្ថុ `Root` ប៉ុន្តែមិនដល់ថ្នាំង root;
    /// វានឹងមិនធ្វើឱ្យចំណុចទាញផ្សេងទៀតមិនត្រឹមត្រូវឬសេចក្តីយោងទៅថ្នាំងឫស។
    ///
    /// Panics ប្រសិនបើមិនមានកម្រិតផ្ទៃក្នុងទេពោលគឺប្រសិនបើថ្នាំងជា root គឺជាស្លឹក។
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // សុវត្ថិភាព: យើងអះអាងថាជាផ្ទៃក្នុង។
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // សុវត្ថិភាព: យើងបានខ្ចី `self` ទាំងស្រុងហើយប្រភេទខ្ចីរបស់វាគឺផ្តាច់មុខ។
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // សុវត្ថិភាព: edge ដំបូងបង្អស់តែងតែត្រូវបានចាប់ផ្តើម។
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` តែងតែជាវត្ថុariantនៅក្នុង `K` និង `V` សូម្បីតែនៅពេល `BorrowType` គឺ `Mut` ក៏ដោយ។
// នេះជាបច្ចេកទេសខុសប៉ុន្តែមិនអាចបណ្តាលឱ្យគ្មានសុវត្ថភាពណាមួយដោយសារតែការប្រើប្រាស់ខាងក្នុង `NodeRef` ទេពីព្រោះយើងរក្សាជាទូទៅទាំងស្រុងលើ `K` និង `V` ។
//
// ទោះយ៉ាងណាក៏ដោយនៅពេលណាដែលប្រភេទសាធារណៈរុំ `NodeRef` ត្រូវប្រាកដថាវាមានភាពត្រឹមត្រូវត្រឹមត្រូវ។
//
/// ឯកសារយោងទៅថ្នាំង។
///
/// ប្រភេទនេះមានប៉ារ៉ាម៉ែត្រមួយចំនួនដែលគ្រប់គ្រងសកម្មភាពរបស់វា:
/// - `BorrowType`: ប្រភេទអត់ចេះសោះដែលពិពណ៌នាអំពីប្រភេទនៃការខ្ចីប្រាក់និងការថែរក្សាពេញមួយជីវិត។
///    - នៅពេលនេះជា `Immut<'a>`, `NodeRef` ដើរតួរដូច `&'a Node` ។
///    - នៅពេលនេះគឺជា `ValMut<'a>`, `NodeRef` ដើរតួដូចជា `&'a Node` ទាក់ទងទៅនឹងគ្រាប់ចុចនិងរចនាសម្ព័ន្ធមែកធាងប៉ុន្តែក៏អនុញ្ញាតឱ្យមានការយោងដែលអាចផ្លាស់ប្តូរបានជាច្រើនចំពោះតម្លៃនៅទូទាំងដើមឈើដើម្បីរួមរស់ជាមួយគ្នា។
///    - នៅពេលនេះជា `Mut<'a>`, `NodeRef` ដើរតួរដូច `&'a mut Node` ទោះបីជាវិធីសាស្ត្របញ្ចូលអនុញ្ញាតឱ្យព្រួញដែលអាចផ្លាស់ប្តូរទៅជាតម្លៃដើម្បីរួមរស់ក៏ដោយ។
///    - នៅពេលនេះគឺជា `Owned`, `NodeRef` ដើរតួរដូច `Box<Node>` ប៉ុន្តែមិនមានអ្នកបំផ្លាញទេហើយត្រូវតែសម្អាតដោយដៃ។
///    - នៅពេលនេះគឺជា `Dying`, `NodeRef` នៅតែដើរតួរដូចជា `Box<Node>` ប៉ុន្តែមានវិធីដើម្បីបំផ្លាញមែកធាងបន្តិចម្តង ៗ និងវិធីសាស្រ្តធម្មតាខណៈពេលដែលមិនត្រូវបានសម្គាល់ថាមិនមានសុវត្ថិភាពក្នុងការហៅអាចហៅ UB ប្រសិនបើបានហៅមិនត្រឹមត្រូវ។
///
///   ដោយសារ `NodeRef` ណាមួយអនុញ្ញាតឱ្យធ្វើនាវាចរណ៍ឆ្លងកាត់មែកធាងនោះ `BorrowType` អនុវត្តទៅដើមឈើទាំងមូលយ៉ាងមានប្រសិទ្ធិភាពមិនត្រឹមតែចំពោះថ្នាំងខ្លួនឯងទេ។
/// - `K` និង `V`: ទាំងនេះគឺជាប្រភេទនៃគ្រាប់ចុចនិងតម្លៃដែលផ្ទុកនៅក្នុងថ្នាំង។
/// - `Type`: នេះអាចជា `Leaf`, `Internal`, ឬ `LeafOrInternal` ។
/// នៅពេលនេះគឺជា `Leaf`, `NodeRef` ចង្អុលទៅថ្នាំងស្លឹកនៅពេលដែលនេះគឺជា `Internal` `NodeRef` ចង្អុលទៅថ្នាំងខាងក្នុងហើយនៅពេលនេះគឺជា `LeafOrInternal` `NodeRef` អាចចង្អុលទៅថ្នាំងណាមួយ។
///   `Type` ត្រូវបានដាក់ឈ្មោះថា `NodeType` នៅពេលប្រើក្រៅ `NodeRef` ។
///
/// ទាំង `BorrowType` និង `NodeType` រឹតបន្តឹងលើវិធីណាដែលយើងអនុវត្តដើម្បីកេងចំណេញសុវត្ថិភាពប្រភេទឋិតិវន្ត។មានកំរិតនៅក្នុងវិធីដែលយើងអាចអនុវត្តការរឹតត្បិតបែបនេះ:
/// - ចំពោះប៉ារ៉ាម៉ែត្រប្រភេទនីមួយៗយើងគ្រាន់តែអាចកំណត់វិធីសាស្រ្តមួយដែលមានលក្ខណៈទូទៅឬសម្រាប់ប្រភេទជាក់លាក់មួយ។
/// ឧទាហរណ៍យើងមិនអាចកំណត់វិធីសាស្ត្រដូចជា `into_kv` ទូទៅសម្រាប់ `BorrowType` ទាំងអស់ឬម្តងសម្រាប់ប្រភេទទាំងអស់ដែលមានអាយុកាលមួយពីព្រោះយើងចង់អោយវាត្រឡប់ឯកសារយោង `&'a` ។
///   ដូច្នេះយើងកំណត់វាសម្រាប់តែប្រភេទ `Immut<'a>` ដែលមានថាមពលតិចបំផុត។
/// - យើងមិនអាចទទួលបានការបង្ខិតបង្ខំជាក់ស្ដែងពីពាក្យថា `Mut<'a>` ទៅ `Immut<'a>` ទេ។
///   ដូច្នេះយើងត្រូវហៅទូរស័ព្ទ `reborrow` យ៉ាងច្បាស់នៅលើ `NodeRef` ដែលមានអានុភាពខ្លាំងជាងមុនដើម្បីឈានដល់វិធីសាស្ត្រមួយដូចជា `into_kv` ។
///
/// វិធីសាស្រ្តទាំងអស់នៅលើ `NodeRef` ដែលត្រលប់មកវិញនូវប្រភេទឯកសារយោងមួយចំនួន៖
/// - យក `self` តាមតម្លៃហើយត្រឡប់អាយុកាលរបស់ `BorrowType` ។
///   ពេលខ្លះដើម្បីហៅវិធីសាស្ត្របែបនេះយើងត្រូវហៅទូរស័ព្ទ `reborrow_mut` ។
/// - យក `self` ដោយយោងហើយ (implicitly) ត្រឡប់អាយុកាលយោងនោះជំនួសអាយុកាលរបស់ `BorrowType` ។
/// តាមវិធីនេះអ្នកត្រួតពិនិត្យប្រាក់កម្ចីធានាថា `NodeRef` នៅតែត្រូវបានខ្ចីដរាបណាឯកសារយោងត្រឡប់មកវិញត្រូវបានប្រើ។
///   វិធីសាស្រ្តក្នុងការបញ្ចូលបញ្ចូលពត់ច្បាប់នេះដោយត្រឡប់ទ្រនិចឆៅពោលគឺសេចក្តីយោងដោយគ្មានអាយុកាលណាមួយឡើយ។
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// ចំនួនកម្រិតដែលថ្នាំងនិងកម្រិតនៃស្លឹកដាច់ពីគ្នាដែលជាចំនួនថេរនៃថ្នាំងដែលមិនអាចពិពណ៌នាបានទាំងស្រុងដោយ `Type` ហើយថាថ្នាំងខ្លួនឯងមិនផ្ទុក។
    /// យើងគ្រាន់តែត្រូវរក្សាទុកកម្ពស់នៃថ្នាំងជា root ហើយទាញយកកម្ពស់ថ្នាំងផ្សេងទៀតពីវា។
    /// ត្រូវតែជាលេខសូន្យប្រសិនបើ `Type` គឺជា `Leaf` និងមិនមែនសូន្យប្រសិនបើ `Type` គឺជា `Internal` ។
    ///
    ///
    height: usize,
    /// ទ្រនិចទៅស្លឹកឬថ្នាំងខាងក្នុង។
    /// និយមន័យនៃ `InternalNode` ធានាថាទ្រនិចគឺត្រឹមត្រូវតាមមធ្យោបាយណាមួយ។
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ខ្ចប់សេចក្តីយោងថ្នាំងដែលត្រូវបានខ្ចប់ជា `NodeRef::parent` ។
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// លាតត្រដាងទិន្នន័យនៃថ្នាំងខាងក្នុង។
    ///
    /// ត្រឡប់ ptr ឆៅដើម្បីជៀសវាងការធ្វើឱ្យឯកសារយោងមិនត្រឹមត្រូវទៅនឹងថ្នាំងនេះ។
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // សុវត្ថិភាព: ប្រភេទថ្នាំងឋិតិវន្តគឺ `Internal` ។
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ផ្តល់សិទ្ធិចូលប្រើទិន្នន័យរបស់ថ្នាំងខាងក្នុង។
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// រកប្រវែងនៃថ្នាំង។នេះគឺជាចំនួនគ្រាប់ចុចឬតម្លៃ។
    /// ចំនួនគែមគឺ `len() + 1` ។
    /// ចំណាំថាទោះបីជាមានសុវត្ថិភាពក៏ដោយការហៅមុខងារនេះអាចមានផលប៉ះពាល់នៃការយោងដែលមិនអាចផ្លាស់ប្តូរបានដែលកូដមិនមានសុវត្ថិភាពបានបង្កើត។
    ///
    pub fn len(&self) -> usize {
        // អ្វីដែលសំខាន់នោះគឺយើងចូលប្រើតែ `len` ប៉ុណ្ណោះនៅទីនេះ។
        // ប្រសិនបើ BorrowType ជា marker::ValMut វាអាចមានឯកសារយោងដែលអាចផ្លាស់ប្តូរបានចំពោះតម្លៃដែលយើងមិនត្រូវទុកចោល។
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// ត្រឡប់ចំនួនកម្រិតដែលថ្នាំងនិងស្លឹកនៅដាច់ពីគ្នា។
    /// កម្ពស់សូន្យមានន័យថាថ្នាំងគឺជាស្លឹកដោយខ្លួនឯង។
    /// ប្រសិនបើអ្នកឃើញដើមឈើដែលមានឫសនៅខាងលើលេខនិយាយថានៅពេលណាដែលកម្ពស់នៃថ្នាំងលេចឡើង។
    /// ប្រសិនបើអ្នកស្រមៃដើមឈើដែលមានស្លឹកនៅខាងលើលេខនិយាយថាតើដើមឈើនោះលាតសន្ធឹងខ្ពស់ជាងថ្នាំង។
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// យកឯកសារយោងដែលមិនចេះប្រែប្រួលទៅជាថ្នាំងតែមួយ។
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// បញ្ចោញផ្នែកស្លឹកនៃស្លឹកឬថ្នាំងខាងក្នុងណាមួយ។
    ///
    /// ត្រឡប់ ptr ឆៅដើម្បីជៀសវាងការធ្វើឱ្យឯកសារយោងមិនត្រឹមត្រូវទៅនឹងថ្នាំងនេះ។
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // ថ្នាំងត្រូវតែមានសុពលភាពយ៉ាងហោចណាស់ផ្នែក LeafNode ។
        // នេះមិនមែនជាឯកសារយោងនៅក្នុងប្រភេទ NodeRef ទេពីព្រោះយើងមិនដឹងថាតើវាគួរតែប្លែកឬចែករំលែកទេ។
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// រកមេនៃថ្នាំងបច្ចុប្បន្ន។
    /// ត្រឡប់ `Ok(handle)` ប្រសិនបើថ្នាំងបច្ចុប្បន្នមានមេដែល `handle` ចង្អុលទៅ edge នៃមេដែលចង្អុលទៅថ្នាំងបច្ចុប្បន្ន។
    ///
    /// ត្រឡប់ `Err(self)` ប្រសិនបើថ្នាំងបច្ចុប្បន្នគ្មានមេដោយផ្តល់ `NodeRef` ដើមវិញ។
    ///
    /// ឈ្មោះវិធីសាស្រ្តសន្មតថាអ្នកមើលឃើញដើមឈើដែលមានថ្នាំងឫសនៅខាងលើ។
    ///
    /// `edge.descend().ascend().unwrap()` ហើយ `node.ascend().unwrap().descend()` គួរតែទាំងពីរមិនទទួលបានជោគជ័យឡើយ។
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // យើងត្រូវប្រើទ្រនិចចង្អុលទៅថ្នាំងពីព្រោះប្រសិនបើ BorrowType ជា marker::ValMut វាអាចមានឯកសារយោងដែលអាចផ្លាស់ប្តូរបានចំពោះតម្លៃដែលយើងមិនត្រូវលុបចោល។
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// ចំណាំថា `self` ត្រូវតែមិនមែនជាការមិនគោរព។
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// ចំណាំថា `self` ត្រូវតែមិនមែនជាការមិនគោរព។
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// បញ្ចោញផ្នែកស្លឹកនៃស្លឹកឬថ្នាំងខាងក្នុងនៅក្នុងមែកធាងដែលមិនអាចផ្លាស់ប្តូរបាន។
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // សុវត្ថិភាព: មិនអាចមានសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានទៅក្នុងមែកធាងនេះដែលបានខ្ចីជា `Immut` ទេ។
        unsafe { &*ptr }
    }

    /// បញ្ចូលទស្សនៈទៅក្នុងគ្រាប់ចុចដែលផ្ទុកនៅក្នុងថ្នាំង។
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// ស្រដៀងគ្នាទៅនឹង `ascend` ទទួលបានឯកសារយោងទៅថ្នាំងមេរបស់ថ្នាំងប៉ុន្តែក៏ដោះស្រាយថ្នាំងបច្ចុប្បន្ននៅក្នុងដំណើរការផងដែរ។
    /// នេះមិនមានសុវត្ថិភាពទេពីព្រោះថ្នាំងបច្ចុប្បន្ននៅតែអាចចូលដំណើរការបានទោះបីជាត្រូវបានដោះស្រាយក៏ដោយ។
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// មិនមានសុវត្ថិភាពអះអាងចំពោះអ្នកចងក្រងព័ត៌មានឋិតិវន្តដែលថ្នាំងនេះគឺជា `Leaf` ។
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// មិនមានសុវត្ថិភាពអះអាងចំពោះអ្នកចងក្រងព័ត៌មានឋិតិវន្តដែលថ្នាំងនេះគឺជាអេចអេស `Internal`។
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// យកឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅកាន់ថ្នាំងតែមួយ។ប្រយ័ត្នព្រោះវិធីសាស្ត្រនេះមានគ្រោះថ្នាក់ខ្លាំងណាស់ទ្វេដងដូច្នេះវាអាចនឹងមិនមានគ្រោះថ្នាក់ភ្លាមៗទេ។
    ///
    /// ដោយសារទ្រនិចចង្អុលអាចផ្លាស់ប្តូរបានគ្រប់ទីកន្លែងជុំវិញដើមឈើនោះទ្រនិចដែលវិលត្រឡប់មកវិញអាចត្រូវបានប្រើយ៉ាងងាយស្រួលដើម្បីធ្វើឱ្យទ្រនិចដើមចងខ្សែក្រៅព្រំដែនឬមិនត្រឹមត្រូវតាមច្បាប់ខ្ចីជាជង់។
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) ពិចារណាបន្ថែមប៉ារ៉ាម៉ែត្រប្រភេទថ្មីមួយទៀតទៅ `NodeRef` ដែលរឹតត្បិតការប្រើប្រាស់វិធីសាស្រ្តរុករកនៅលើចំណុចចង្អុលបង្ហាញការពារការការពារសុវត្ថិភាពនេះ។
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// បញ្ចោញសិទ្ធិផ្តាច់មុខទៅផ្នែកស្លឹកនៃស្លឹកឬថ្នាំងខាងក្នុង។
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // សុវត្ថិភាព: យើងមានផ្លូវចូលផ្តាច់មុខទៅថ្នាំងទាំងមូល។
        unsafe { &mut *ptr }
    }

    /// ផ្តល់ជូននូវការចូលប្រើផ្តាច់មុខលើផ្នែកស្លឹកនៃស្លឹកឬថ្នាំងខាងក្នុងណាមួយ។
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // សុវត្ថិភាព: យើងមានផ្លូវចូលផ្តាច់មុខទៅថ្នាំងទាំងមូល។
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ផ្ដល់សិទ្ធិផ្តាច់មុខដល់ធាតុនៃកន្លែងផ្ទុកសំខាន់។
    ///
    /// # Safety
    /// `index` គឺស្ថិតនៅក្នុងព្រំដែននៃ 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលនឹងមិនអាចហៅវិធីសាស្ត្របន្ថែមដោយខ្លួនឯងបានទេ
        // រហូតដល់សេចក្តីយោងចំណែកគន្លឹះត្រូវបានធ្លាក់ចុះដូចដែលយើងមានសិទ្ធិចូលដំណើរការតែមួយគត់សម្រាប់អាយុកាលនៃប្រាក់កម្ចី។
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// បញ្ចោញសិទ្ធិផ្តាច់មុខទៅនឹងធាតុឬចំណែកនៃទំហំផ្ទុករបស់ថ្នាំង។
    ///
    /// # Safety
    /// `index` គឺស្ថិតនៅក្នុងព្រំដែននៃ 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលនឹងមិនអាចហៅវិធីសាស្ត្របន្ថែមដោយខ្លួនឯងបានទេ
        // រហូតដល់សេចក្តីយោងចំណែកតម្លៃត្រូវបានធ្លាក់ចុះដូចដែលយើងមានសិទ្ធិចូលដំណើរការតែមួយគត់សម្រាប់អាយុកាលរបស់អ្នកខ្ចី។
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ផ្ដល់សិទ្ធិផ្តាច់មុខដល់ធាតុឬចំណែកនៃកន្លែងផ្ទុករបស់ថ្នាំងសម្រាប់មាតិកា edge ។
    ///
    /// # Safety
    /// `index` គឺស្ថិតនៅក្នុងព្រំដែននៃ 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលនឹងមិនអាចហៅវិធីសាស្ត្របន្ថែមដោយខ្លួនឯងបានទេ
        // រហូតដល់សេចក្តីយោងចំណែក edge ត្រូវបានធ្លាក់ចុះដូចដែលយើងមានសិទ្ធិពិសេសសម្រាប់អាយុកាលខ្ចី។
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - ថ្នាំងមានធាតុចាប់ផ្តើមច្រើនជាង `idx` ។
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // យើងគ្រាន់តែបង្កើតឯកសារយោងទៅនឹងធាតុមួយដែលយើងចាប់អារម្មណ៍ដើម្បីចៀសវាងការក្លែងបន្លំជាមួយនឹងឯកសារយោងដែលលេចធ្លោទៅនឹងធាតុផ្សេងទៀតជាពិសេសអ្នកដែលបានត្រលប់មកអ្នកទូរស័ព្ទចូលម្តងទៀត។
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // យើងត្រូវតែបង្ខិតបង្ខំឱ្យចង្អុលអារេដែលមិនមានសុពលភាពដោយសារតែបញ្ហា Rust ចេញ #74679 ។
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ផ្តល់សិទ្ធិឱ្យផ្តាច់មុខទៅនឹងប្រវែងនៃថ្នាំង។
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// កំណត់តំណរបស់ថ្នាំងទៅមេ edge ដោយមិនធ្វើឱ្យសេចក្តីយោងផ្សេងទៀតទៅថ្នាំង។
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// ជម្រះតំណឫសទៅនឹងមេ edge ។
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// បន្ថែមគូតម្លៃតម្លៃទៅចុងថ្នាំង។
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// រាល់វត្ថុដែលបានត្រឡប់មកវិញដោយ `range` គឺជាសន្ទស្សន៍ edge ត្រឹមត្រូវសម្រាប់ថ្នាំង។
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// បន្ថែមគូដែលមានតម្លៃសំខាន់ហើយ edge ទៅខាងស្តាំគូនោះរហូតដល់ចុងថ្នាំង។
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ពិនិត្យមើលថាតើថ្នាំងគឺជាថ្នាំង `Internal` ឬថ្នាំង `Leaf` ។
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// សេចក្តីយោងចំពោះគូតម្លៃគ្រាប់ចុចជាក់លាក់ឬ edge នៅក្នុងថ្នាំង។
/// ប៉ារ៉ាម៉ែត្រ `Node` ត្រូវតែជា `NodeRef` ខណៈពេលដែល `Type` អាចជា `KV` (បង្ហាញសញ្ញាចំណុចទាញនៅលើគូតម្លៃគ្រាប់ចុច) ឬ `Edge` (បង្ហាញសញ្ញាចំណុចទាញនៅលើ edge) ។
///
/// ចំណាំថាសូម្បីតែថ្នាំង `Leaf` ក៏អាចមានចំណុចទាញ `Edge` ដែរ។
/// ជំនួសឱ្យការចង្អុលបង្ហាញទ្រនិចទៅថ្នាំងកុមារទាំងនេះតំណាងឱ្យចន្លោះដែលអ្នកចង្អុលបង្ហាញកុមារនឹងនៅចន្លោះគូតម្លៃគ្រាប់ចុច។
/// ឧទាហរណ៍នៅក្នុងថ្នាំងដែលមានប្រវែង ២ វាអាចមាន ៣ ទីតាំងដែលអាចធ្វើទៅបាន edge គឺមួយនៅខាងឆ្វេងថ្នាំងមួយនៅចន្លោះគូទាំងពីរនិងមួយនៅខាងស្តាំថ្នាំង។
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// យើងមិនត្រូវការភាពពេញលេញនៃ `#[derive(Clone)]` ទេព្រោះថាពេលវេលាតែមួយគត់ដែល `Node` នឹងក្លាយជាក្លូនគឺនៅពេលដែលវាជាឯកសារយោងដែលមិនអាចផ្លាស់ប្តូរបានហើយដូច្នេះ `Copy` ។
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ទាញយកថ្នាំងដែលមាន edge ឬគូតម្លៃគ្រាប់ចុចដែលចំណុចទាញនេះចង្អុលទៅ។
    pub fn into_node(self) -> Node {
        self.node
    }

    /// ត្រឡប់ទីតាំងនៃចំណុចទាញនេះនៅក្នុងថ្នាំង។
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// បង្កើតចំណុចទាញថ្មីមួយចំពោះគូដែលមានតម្លៃសំខាន់នៅក្នុង `node` ។
    /// មិនមានសុវត្ថិភាពទេព្រោះអ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `idx < node.len()` ។
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// អាចជាការអនុវត្តជាសាធារណៈនៃផ្នែកខ្លះប៉ុន្តែត្រូវបានប្រើតែនៅក្នុងម៉ូឌុលនេះប៉ុណ្ណោះ។
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// ជាបណ្តោះអាសន្នយកចំណុចទាញដែលមិនផ្លាស់ប្តូរមួយចេញនៅទីតាំងតែមួយ។
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // យើងមិនអាចប្រើ Handle::new_kv ឬ Handle::new_edge បានទេព្រោះយើងមិនដឹងប្រភេទរបស់យើង
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// មិនមានសុវត្ថិភាពអះអាងចំពោះអ្នកចងក្រងព័ត៌មានឋិតិវន្តដែលថ្នាំងរបស់ចំណុចទាញគឺជា `Leaf` ។
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// ដកយកចំណុចទាញដែលអាចផ្លាស់ប្តូរបាននៅទីតាំងតែមួយជាបណ្តោះអាសន្ន។
    /// ប្រយ័ត្នព្រោះវិធីសាស្ត្រនេះមានគ្រោះថ្នាក់ខ្លាំងណាស់ទ្វេដងដូច្នេះវាអាចនឹងមិនមានគ្រោះថ្នាក់ភ្លាមៗទេ។
    ///
    ///
    /// សម្រាប់ព័ត៌មានលម្អិតសូមមើល `NodeRef::reborrow_mut` ។
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // យើងមិនអាចប្រើ Handle::new_kv ឬ Handle::new_edge បានទេព្រោះយើងមិនដឹងប្រភេទរបស់យើង
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// បង្កើតចំណុចទាញថ្មីទៅ edge ក្នុង `node` ។
    /// មិនមានសុវត្ថិភាពទេព្រោះអ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `idx <= node.len()` ។
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ដែលបានផ្តល់ឱ្យសន្ទស្សន៍ edge ដែលយើងចង់បញ្ចូលថ្នាំងដែលបំពេញទៅនឹងសមត្ថភាពគណនាសន្ទស្សន៍គីវីដែលសមរម្យនៃចំណុចបំបែកនិងកន្លែងដែលត្រូវអនុវត្តការបញ្ចូល។
///
/// គោលដៅនៃចំណុចបំបែកគឺសម្រាប់គន្លឹះនិងតម្លៃរបស់វាដើម្បីបញ្ចប់នៅក្នុងថ្នាំងមេ។
/// កូនសោតម្លៃនិងគែមនៅខាងឆ្វេងនៃចំណុចបំបែកក្លាយជាកូនខាងឆ្វេង។
/// កូនសោតម្លៃនិងគែមនៅខាងស្តាំនៃចំនុចបំបែកក្លាយជាកូនត្រឹមត្រូវ។
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // បញ្ហា Rust #74834 ព្យាយាមពន្យល់អំពីច្បាប់ស៊ីមេទ្រីទាំងនេះ។
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// បញ្ចូលគូតម្លៃគ្រាប់ចុចថ្មីរវាងគូតម្លៃគ្រាប់ចុចទៅខាងស្តាំនិងខាងឆ្វេងនៃ edge នេះ។
    /// វិធីសាស្រ្តនេះសន្មតថាមានចន្លោះគ្រប់គ្រាន់នៅក្នុងថ្នាំងសម្រាប់គូថ្មីសម។
    ///
    /// ទ្រនិចចង្អុលត្រឡប់ទៅតម្លៃដែលបានបញ្ចូល។
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// បញ្ចូលគូតម្លៃគ្រាប់ចុចថ្មីរវាងគូតម្លៃគ្រាប់ចុចទៅខាងស្តាំនិងខាងឆ្វេងនៃ edge នេះ។
    /// វិធីសាស្រ្តនេះបំបែកថ្នាំងប្រសិនបើមិនមានបន្ទប់គ្រប់គ្រាន់។
    ///
    /// ទ្រនិចចង្អុលត្រឡប់ទៅតម្លៃដែលបានបញ្ចូល។
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ជួសជុលទ្រនិចចង្អុលនិងសន្ទស្សន៍នៅក្នុងថ្នាំងកុមារដែល edge ភ្ជាប់ទៅ។
    /// វាមានប្រយោជន៍នៅពេលការបញ្ជាទិញគែមត្រូវបានផ្លាស់ប្តូរ,
    fn correct_parent_link(self) {
        // បង្កើតផ្ទាំងខាងក្រោយដោយមិនធ្វើឱ្យសេចក្តីយោងផ្សេងទៀតទៅថ្នាំង។
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// បញ្ចូលលេខគូតម្លៃថ្មីនិង edge ដែលនឹងទៅខាងស្តាំគូថ្មីនោះរវាង edge និងគូសោតម្លៃនៅខាងស្តាំ edge ។
    /// វិធីសាស្រ្តនេះសន្មតថាមានចន្លោះគ្រប់គ្រាន់នៅក្នុងថ្នាំងសម្រាប់គូថ្មីសម។
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// បញ្ចូលលេខគូតម្លៃថ្មីនិង edge ដែលនឹងទៅខាងស្តាំគូថ្មីនោះរវាង edge និងគូសោតម្លៃនៅខាងស្តាំ edge ។
    /// វិធីសាស្រ្តនេះបំបែកថ្នាំងប្រសិនបើមិនមានបន្ទប់គ្រប់គ្រាន់។
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// បញ្ចូលគូតម្លៃគ្រាប់ចុចថ្មីរវាងគូតម្លៃគ្រាប់ចុចទៅខាងស្តាំនិងខាងឆ្វេងនៃ edge នេះ។
    /// វិធីសាស្រ្តនេះបំបែកថ្នាំងប្រសិនបើមិនមានបន្ទប់គ្រប់គ្រាន់ហើយព្យាយាមបញ្ចូលផ្នែកដែលបំបែកទៅក្នុងថ្នាំងមេម្តងទៀតរហូតទាល់តែដល់ឫស។
    ///
    ///
    /// ប្រសិនបើលទ្ធផលត្រឡប់មកវិញគឺជា `Fit` ថ្នាំងចំណុចទាញរបស់វាអាចជាថ្នាំងរបស់ edge ឬបុព្វបុរស។
    /// ប្រសិនបើលទ្ធផលត្រឡប់មកវិញគឺជាលេខ `Split` នោះវាល `left` នឹងក្លាយជាថ្នាំង root ។
    /// ទ្រនិចចង្អុលត្រឡប់ទៅតម្លៃដែលបានបញ្ចូល។
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// រកឃើញថ្នាំងដែលចង្អុលដោយ edge នេះ។
    ///
    /// ឈ្មោះវិធីសាស្រ្តសន្មតថាអ្នកមើលឃើញដើមឈើដែលមានថ្នាំងឫសនៅខាងលើ។
    ///
    /// `edge.descend().ascend().unwrap()` ហើយ `node.ascend().unwrap().descend()` គួរតែទាំងពីរមិនទទួលបានជោគជ័យឡើយ។
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // យើងត្រូវប្រើទ្រនិចចង្អុលទៅថ្នាំងពីព្រោះប្រសិនបើ BorrowType ជា marker::ValMut វាអាចមានឯកសារយោងដែលអាចផ្លាស់ប្តូរបានចំពោះតម្លៃដែលយើងមិនត្រូវលុបចោល។
        // មិនមានអ្វីគួរឱ្យព្រួយបារម្ភក្នុងការចូលទៅក្នុងវាលកម្ពស់ទេពីព្រោះតម្លៃនោះត្រូវបានចម្លង។
        // សូមប្រយ័ត្នថានៅពេលដែលទ្រនិចថ្នាំងត្រូវបានដកហូតយើងអាចចូលទៅកាន់គែមគែមដោយសេចក្តីយោង (លេខ Rust លេខ #73987) និងធ្វើឱ្យមានភាពមិនត្រឹមត្រូវនូវសេចក្តីយោងផ្សេងទៀតទៅឬនៅខាងក្នុងអារេគួរតែនៅជុំវិញ។
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // យើងមិនអាចហៅវិធីសាស្ត្រគន្លឹះនិងតម្លៃដាច់ដោយឡែកពីគ្នាបានទេពីព្រោះការហៅលេខ ២ ធ្វើឱ្យសេចក្តីយោងត្រឡប់ដោយលេខទីមួយវិញ។
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// ជំនួសកូនសោរនិងតម្លៃដែលចំណុចទាញរបស់ខេអេសសំដៅទៅលើ។
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// ជួយដល់ការអនុវត្ត `split` សម្រាប់ `NodeType` ពិសេសដោយថែរក្សាទិន្នន័យស្លឹក។
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// បំបែកថ្នាំងមូលដ្ឋានជាបីផ្នែក៖
    ///
    /// - ថ្នាំងត្រូវបានកាត់ឱ្យខ្លីមានតែកូនសោតម្លៃសំខាន់ៗនៅខាងឆ្វេងនៃចំណុចទាញនេះ។
    /// - គន្លឹះនិងតម្លៃដែលចង្អុលបង្ហាញដោយចំណុចទាញនេះត្រូវបានស្រង់ចេញ។
    /// - គូតម្លៃសំខាន់ៗទាំងអស់នៅខាងស្តាំចំណុចទាញនេះត្រូវបានដាក់ចូលទៅក្នុងថ្នាំងដែលបានបម្រុងទុកថ្មី។
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// ដោះគូតម្លៃគ្រាប់ចុចដែលចង្អុលបង្ហាញដោយចំណុចទាញនេះហើយប្រគល់វាមកវិញរួមជាមួយ edge ដែលគូតម្លៃគ្រាប់ចុចដួលរលំ។
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// បំបែកថ្នាំងមូលដ្ឋានជាបីផ្នែក៖
    ///
    /// - ថ្នាំងត្រូវបានកាត់ឱ្យខ្លីមានតែគែមនិងគូតម្លៃគ្រាប់ចុចនៅខាងឆ្វេងនៃចំណុចទាញនេះ។
    /// - គន្លឹះនិងតម្លៃដែលចង្អុលបង្ហាញដោយចំណុចទាញនេះត្រូវបានស្រង់ចេញ។
    /// - គែមនិងគូតម្លៃសំខាន់ៗនៅខាងស្តាំចំណុចទាញនេះត្រូវបានដាក់ចូលទៅក្នុងថ្នាំងដែលបានបម្រុងទុកថ្មី។
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// តំណាងឱ្យវគ្គមួយសម្រាប់វាយតម្លៃនិងអនុវត្តប្រតិបត្តិការដែលមានតុល្យភាពជុំវិញគូតម្លៃសំខាន់ខាងក្នុង។
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ជ្រើសរើសបរិបទដែលមានតុល្យភាពទាក់ទងនឹងថ្នាំងនៅពេលកុមារដូច្នេះរវាងគីវីភ្លាមៗទៅខាងឆ្វេងឬទៅខាងស្តាំនៅក្នុងថ្នាំងមេ។
    /// ត្រឡប់ `Err` ប្រសិនបើគ្មានមេ។
    /// Panics ប្រសិនបើឪពុកម្តាយទទេ។
    ///
    /// ចូលចិត្តផ្នែកខាងឆ្វេងដើម្បីឱ្យល្អបំផុតប្រសិនបើថ្នាំងដែលបានផ្តល់ឱ្យមានភាពមិនច្បាស់មានន័យថានៅទីនេះមានតែវាមានធាតុតិចជាងបងប្អូនខាងឆ្វេងរបស់វានិងបងប្អូនបង្កើតខាងស្តាំប្រសិនបើពួកគេមាន។
    /// ក្នុងករណីនេះការរួមបញ្ចូលគ្នាជាមួយបងប្អូនបង្កើតខាងឆ្វេងគឺលឿនជាងមុនពីព្រោះយើងគ្រាន់តែត្រូវការផ្លាស់ប្តូរធាតុ N នៃថ្នាំងជំនួសឱ្យការផ្លាស់ប្តូរពួកវាទៅខាងស្តាំនិងផ្លាស់ទីច្រើនជាងធាតុ N នៅខាងមុខ។
    /// ការលួចពីបងប្អូនបង្កើតខាងឆ្វេងក៏លឿនជាងដែរព្រោះយើងគ្រាន់តែត្រូវការប្តូរធាតុ N នៃថ្នាំងទៅខាងស្តាំជំនួសឱ្យការផ្លាស់ប្តូរយ៉ាងហោចណាស់ N នៃធាតុរបស់បងប្អូនបង្កើតទៅខាងឆ្វេង។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ត្រឡប់ថាតើការរួមបញ្ចូលគ្នាអាចធ្វើទៅបានទេថាតើមានបន្ទប់គ្រប់គ្រាន់នៅក្នុងថ្នាំងដើម្បីបញ្ចូលកណ្តាលខេអេសវីជាមួយកូនក្មេងដែលនៅជាប់គ្នា។
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// អនុវត្តការរួមបញ្ចូលគ្នានិងអនុញ្ញាតឱ្យបិទការសម្រេចចិត្តអ្វីដែលត្រូវត្រឡប់មកវិញ។
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // សុវត្ថិភាព: កម្ពស់ថ្នាំងដែលត្រូវបានបញ្ចូលគ្នាគឺមួយក្រោមកម្ពស់
                // នៃថ្នាំងនៃ edge នេះ, ដូច្នេះខាងលើសូន្យដូច្នេះពួកគេគឺផ្ទៃក្នុង។
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// បញ្ចូលគ្នានូវកូនសោតម្លៃរបស់ឪពុកម្តាយនិងកូនក្មេងដែលនៅជាប់គ្នាចូលទៅក្នុងកូនតូចខាងឆ្វេងហើយប្រគល់ថ្នាំងឪពុកម្តាយដែលរួញ។
    ///
    ///
    /// Panics លើកលែងតែយើង `.can_merge()` ។
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// បញ្ចូលគ្នានូវកូនសោតម្លៃរបស់ឪពុកម្តាយនិងកូនក្មេងដែលនៅជាប់គ្នាចូលទៅក្នុងកូនតូចខាងឆ្វេងហើយត្រឡប់ថ្នាំងកូននោះ។
    ///
    ///
    /// Panics លើកលែងតែយើង `.can_merge()` ។
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// បញ្ចូលគ្នានូវកូនសោតម្លៃរបស់ឪពុកម្តាយនិងកូនក្មេងដែលនៅជាប់គ្នាចូលទៅក្នុងកូនតូចខាងឆ្វេងហើយប្រគល់ចំណុចទាញ edge នៅក្នុងថ្នាំងកុមារដែលជាកន្លែងដែលកុមារតាមដាន edge បានបញ្ចប់
    ///
    ///
    /// Panics លើកលែងតែយើង `.can_merge()` ។
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// យកកូនសោតម្លៃកូនសោពីកូនខាងឆ្វេងហើយដាក់វានៅក្នុងការផ្ទុកកូនសោររបស់ឪពុកម្តាយខណៈពេលដែលរុញកូនសោសំខាន់របស់ឪពុកម្តាយចាស់ទៅកូនខាងស្តាំ។
    ///
    /// ត្រឡប់ចំណុចទាញទៅ edge ក្នុងកូនខាងស្តាំត្រូវនឹងកន្លែងដែល edge ដើមបញ្ជាក់ដោយ `track_right_edge_idx` បានបញ្ចប់។
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// យកកូនសោតម្លៃកូនសោពីកូនខាងស្តាំហើយដាក់វានៅក្នុងការផ្ទុកកូនសោររបស់ឪពុកម្តាយខណៈពេលដែលរុញកូនសោតម្លៃមេចាស់ទៅកូនខាងឆ្វេង។
    ///
    /// ត្រឡប់ចំណុចទាញទៅ edge នៅក្នុងកូនខាងឆ្វេងដែលបានបញ្ជាក់ដោយ `track_left_edge_idx` ដែលមិនបានផ្លាស់ទី។
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// នេះពិតជាធ្វើប្រហាក់ប្រហែលនឹង `steal_left` ដែរតែលួចមានធាតុជាច្រើនក្នុងពេលតែមួយ។
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ត្រូវប្រាកដថាយើងអាចលួចដោយសុវត្ថិភាព។
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ផ្លាស់ទីទិន្នន័យស្លឹក។
            {
                // ធ្វើឱ្យបន្ទប់សម្រាប់ធាតុដែលត្រូវបានគេលួចនៅក្នុងកុមារត្រឹមត្រូវ។
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // ផ្លាស់ទីធាតុពីកូនខាងឆ្វេងទៅស្តាំ។
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ផ្លាស់ទីគូដែលត្រូវបានគេលួចនៅខាងឆ្វេងទៅឪពុកម្តាយ។
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // ផ្លាស់ប្តូរគូតម្លៃសំខាន់របស់ឪពុកម្តាយទៅកូនត្រឹមត្រូវ។
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // ធ្វើឱ្យបន្ទប់សម្រាប់គែមលួច។
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // លួចគែម។
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// ក្លូនស៊ីមេទ្រីនៃ `bulk_steal_left` ។
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ត្រូវប្រាកដថាយើងអាចលួចដោយសុវត្ថិភាព។
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ផ្លាស់ទីទិន្នន័យស្លឹក។
            {
                // ផ្លាស់ទីគូដែលត្រូវគេលួចជាងគេទៅឪពុកម្តាយ។
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // រំកិលកូនសោតម្លៃរបស់ឪពុកម្តាយទៅកូនខាងឆ្វេង។
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // ផ្លាស់ទីធាតុពីកូនខាងស្តាំទៅខាងឆ្វេង។
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // បំពេញចន្លោះដែលជាកន្លែងដែលធាតុដែលត្រូវបានគេលួចធ្លាប់មាន។
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // លួចគែម។
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // បំពេញចន្លោះដែលគែមត្រូវបានគេលួច។
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ដកចេញនូវព័ត៌មានឋិតិវន្តណាមួយដែលអះអាងថាថ្នាំងនេះគឺជាថ្នាំង `Leaf` ។
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ដកចេញនូវព័ត៌មានឋិតិវន្តណាមួយដែលអះអាងថាថ្នាំងនេះគឺជាថ្នាំង `Internal` ។
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// ពិនិត្យថាតើថ្នាំងខាងក្រោមជាថ្នាំង `Internal` ឬថ្នាំង `Leaf` ។
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// ផ្លាស់ទីបច្ច័យបន្ទាប់ពី `self` ពីថ្នាំងមួយទៅមួយទៀត។`right` ត្រូវតែទទេ។
    /// edge ដំបូងនៃ `right` នៅតែមិនផ្លាស់ប្តូរ។
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// លទ្ធផលនៃការបញ្ចូលនៅពេលថ្នាំងត្រូវការពង្រីកលើសពីសមត្ថភាពរបស់វា។
pub struct SplitResult<'a, K, V, NodeType> {
    // ផ្លាស់ប្តូរថ្នាំងនៅក្នុងមែកធាងដែលមានស្រាប់ជាមួយនឹងធាតុនិងគែមដែលជាកម្មសិទ្ធិរបស់ខាងឆ្វេងនៃ `kv` ។
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // គ្រាប់ចុចនិងតម្លៃមួយចំនួនត្រូវបានបំបែកចេញដើម្បីដាក់នៅកន្លែងផ្សេងទៀត។
    pub kv: (K, V),
    // ជាកម្មសិទ្ធិដែលគ្មានការភ្ជាប់ថ្នាំងថ្មីដែលមានធាតុនិងគែមដែលជាកម្មសិទ្ធិរបស់ `kv` ។
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // ថាតើសេចក្តីយោងថ្នាំងនៃប្រភេទខ្ចីនេះអនុញ្ញាតឱ្យឆ្លងកាត់ថ្នាំងផ្សេងទៀតនៅក្នុងដើមឈើដែរឬទេ។
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal មិនចាំបាច់ទេវាកើតឡើងដោយប្រើលទ្ធផល `borrow_mut` ។
        // ដោយការបិទដំណើរឆ្លងកាត់ហើយមានតែការបង្កើតសេចក្តីយោងថ្មីដល់ឬសប៉ុណ្ណោះយើងដឹងថារាល់ឯកសារយោងប្រភេទ `Owned` គឺសំដៅទៅលើថ្នាំងឫស។
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// បញ្ចូលតម្លៃទៅជាចំណែកតូចៗនៃធាតុដែលបានចាប់ផ្តើមអមដោយធាតុដែលមិនមែនមនុស្សម្នាក់។
///
/// # Safety
/// ចំណិតមានធាតុច្រើនជាង `idx` ។
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// យកចេញនិងត្រឡប់តម្លៃពីចំណែកនៃធាតុដែលបានចាប់ផ្តើមទាំងអស់ទុកនៅពីក្រោយធាតុដែលមិនមានលក្ខណៈជាក្រោយ។
///
///
/// # Safety
/// ចំណិតមានធាតុច្រើនជាង `idx` ។
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// ផ្លាស់ប្តូរធាតុនៅក្នុងទីតាំង `distance` មួយចំហៀងទៅខាងឆ្វេង។
///
/// # Safety
/// ចំណិតយ៉ាងហោចណាស់មានធាតុ `distance` ។
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// ផ្លាស់ប្តូរធាតុនៅក្នុងទីតាំងតូច `distance` ទៅខាងស្តាំ។
///
/// # Safety
/// ចំណិតយ៉ាងហោចណាស់មានធាតុ `distance` ។
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// ផ្លាស់ប្តូរតម្លៃទាំងអស់ពីផ្នែកដំបូងនៃធាតុទៅផ្នែកមួយនៃធាតុដែលមិនមានឯកសិទ្ធិដោយបន្សល់ទុកនូវ `src` ដែលមិនមែនជាឯកសិទ្ធិទាំងអស់។
///
/// ធ្វើការដូច `dst.copy_from_slice(src)` ប៉ុន្តែមិនតម្រូវឱ្យ `T` ក្លាយជា `Copy` ទេ។
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;