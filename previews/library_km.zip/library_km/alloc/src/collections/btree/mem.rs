use core::intrinsics;
use core::mem;
use core::ptr;

/// នេះជំនួសតម្លៃនៅពីក្រោយឯកសារយោងពិសេស `v` ដោយហៅមុខងារពាក់ព័ន្ធ។
///
///
/// ប្រសិនបើ panic កើតឡើងនៅក្នុងការបិទ `change` នោះដំណើរការទាំងមូលនឹងត្រូវបោះបង់ចោល។
#[allow(dead_code)] // រក្សាទុកជារូបភាពនិងសម្រាប់ការប្រើប្រាស់ future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// នេះជំនួសតម្លៃនៅពីក្រោយឯកសារយោងពិសេស `v` ដោយហៅមុខងារដែលពាក់ព័ន្ធហើយត្រឡប់លទ្ធផលដែលទទួលបាននៅតាមផ្លូវ។
///
///
/// ប្រសិនបើ panic កើតឡើងនៅក្នុងការបិទ `change` នោះដំណើរការទាំងមូលនឹងត្រូវបោះបង់ចោល។
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}