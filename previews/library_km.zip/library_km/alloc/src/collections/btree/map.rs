use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// ចំនួនអប្បបរមានៃធាតុនៅក្នុងថ្នាំងដែលមិនមែនជាឫស។
/// យើងប្រហែលជាមានធាតុតិចជាងមុនក្នុងកំឡុងពេលវិធីសាស្ត្រ។
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// មែកធាងមួយនៅក្នុង `BTreeMap` គឺជាមែកធាងនៅក្នុងម៉ូឌុល `node` ដែលមានការលុកលុយបន្ថែម:
// - គ្រាប់ចុចត្រូវតែលេចឡើងតាមលំដាប់ឡើង (យោងទៅតាមប្រភេទរបស់កូនសោ) ។
// - ប្រសិនបើថ្នាំងជា root វាត្រូវតែមានយ៉ាងហោចណាស់ធាតុ 1 ។
// - រាល់ថ្នាំងដែលមិនមែនជា root មានយ៉ាងហោចណាស់ធាតុ MIN_LEN ។
//
// ផែនទីទទេមួយអាចត្រូវបានតំណាងទាំងអវត្តមាននៃថ្នាំងជា root ឬដោយថ្នាំងឫសដែលជាស្លឹកទទេ។
//

/// ផែនទីមានមូលដ្ឋានលើ [B-Tree] ។
///
/// ខ-ដើមឈើតំណាងឱ្យការសម្របសម្រួលជាមូលដ្ឋានរវាងប្រសិទ្ធភាពឃ្លាំងសម្ងាត់និងកាត់បន្ថយបរិមាណការងារដែលបានអនុវត្តនៅក្នុងការស្វែងរក។តាមទ្រឹស្តីមែកធាងការស្វែងរកគោលពីរ (BST) គឺជាជំរើសដ៏ប្រសើរបំផុតសំរាប់ផែនទីដែលបានតំរៀបជា BST ដែលមានតុល្យភាពឥតខ្ចោះអនុវត្តចំនួនប្រៀបធៀបទ្រឹស្តីដែលចាំបាច់ដើម្បីរកធាតុ (log<sub>2</sub>n) ។
/// ទោះយ៉ាងណាក៏ដោយនៅក្នុងការអនុវត្តវិធីដែលវិធីនេះត្រូវបានធ្វើគឺ * មិនមានប្រសិទ្ធិភាពទេសម្រាប់ស្ថាបត្យកម្មកុំព្យូទ័រទំនើប។
/// ជាពិសេសរាល់ធាតុទាំងអស់ត្រូវបានផ្ទុកនៅក្នុងថ្នាំងដែលបែងចែកជាគំនររៀងៗខ្លួន។
/// នេះមានន័យថារាល់ការបញ្ចូលតែមួយបង្កឱ្យមានការបែងចែកហ៊ារហើយរាល់ការប្រៀបធៀបតែមួយគួរតែជាឃ្លាំងសំងាត់។
/// ដោយហេតុថាទាំងនេះជារបស់ដែលមានតម្លៃគួរឱ្យកត់សម្គាល់នៅក្នុងការអនុវត្តជាក់ស្តែងយើងត្រូវបានបង្ខំឱ្យពិចារណាឡើងវិញយ៉ាងហោចណាស់នូវយុទ្ធសាស្ត្រ BST ។
///
/// មែកធាង B ជំនួសឱ្យថ្នាំងនីមួយៗមានធាតុ B-1 ទៅ 2B-1 នៅក្នុងអារេជាប់គ្នា។តាមរយៈការធ្វើដូចនេះយើងកាត់បន្ថយចំនួននៃការបែងចែកដោយកត្តានៃខនិងធ្វើអោយប្រសើរឡើងនូវប្រសិទ្ធភាពនៃឃ្លាំងសម្ងាត់ក្នុងការស្វែងរក។ទោះយ៉ាងណាក៏ដោយនេះមានន័យថាការស្វែងរកនឹងត្រូវធ្វើការប្រៀបធៀប *ច្រើនជាង* ជាមធ្យម។
/// ចំនួនប្រៀបធៀបជាក់លាក់អាស្រ័យលើយុទ្ធសាស្ត្រស្វែងរកថ្នាំងដែលបានប្រើ។សម្រាប់ប្រសិទ្ធភាពឃ្លាំងសម្ងាត់ល្អបំផុតអ្នកអាចស្វែងរកថ្នាំងលីនេអ៊ែរ។សម្រាប់ការប្រៀបធៀបល្អប្រសើរបំផុតមនុស្សម្នាក់អាចស្វែងរកថ្នាំងដោយប្រើការស្វែងរកគោលពីរ។ក្នុងនាមជាការសម្របសម្រួលមួយអ្នកក៏អាចធ្វើការស្រាវជ្រាវលីនេអ៊ែរផងដែរដែលដំបូងឡើយគ្រាន់តែត្រួតពិនិត្យរាល់ធាតុ <sup>ទី ១</sup> សម្រាប់ជំរើសខ្លះនៃអាយ។
///
/// បច្ចុប្បន្ននេះការអនុវត្តរបស់យើងអនុវត្តការស្វែងរកតាមបែបឆោតល្ងង់។នេះផ្តល់នូវការសម្តែងដ៏ល្អលើថ្នាំង *តូចនៃធាតុដែលមានតំលៃថោកដើម្បីប្រៀបធៀប។ទោះយ៉ាងណាក៏ដោយនៅក្នុង future យើងចង់ស្វែងយល់បន្ថែមទៀតជ្រើសរើសយុទ្ធសាស្រ្តស្វែងរកដែលល្អប្រសើរដោយផ្អែកលើជំរើសនៃខនិងកត្តាផ្សេងទៀត។ការប្រើប្រាស់លីនេអ៊ែរស្វែងរកធាតុចៃដន្យត្រូវបានគេរំពឹងថានឹងយកការប្រៀបធៀប O(B* log(n)) ដែលជាទូទៅអាក្រក់ជាងអេសប៊ីអេស។
///
/// ទោះជាយ៉ាងណាក៏ដោយនៅក្នុងការអនុវត្តជាក់ស្តែងការសម្តែងគឺល្អឥតខ្ចោះ។
///
/// វាគឺជាកំហុសតក្កវិជ្ជាដែលកូនសោត្រូវបានកែប្រែតាមរបៀបដែលការបញ្ជាទិញរបស់កូនសោទាក់ទងទៅនឹងកូនសោផ្សេងទៀតដូចដែលបានកំណត់ដោយ [`Ord`] trait ការផ្លាស់ប្តូរខណៈពេលដែលវាស្ថិតនៅក្នុងផែនទី។នេះជាធម្មតាអាចធ្វើទៅបានតាមរយៈ [`Cell`], [`RefCell`], រដ្ឋសកល, I/O, ឬកូដគ្មានសុវត្ថិភាព។
/// ឥរិយាបថដែលបណ្តាលមកពីកំហុសតក្កវិជ្ជាមិនត្រូវបានបញ្ជាក់ទេប៉ុន្តែនឹងមិនបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។នេះអាចរួមបញ្ចូលទាំង panics លទ្ធផលមិនត្រឹមត្រូវការបោះបង់ការលេចធ្លាយសតិនិងការមិនបញ្ចប់។
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // ប្រភេទ inference អនុញ្ញាតឱ្យយើងលុបហត្ថលេខាប្រភេទជាក់លាក់មួយ (ដែលនឹងជា `BTreeMap<&str, &str>` ក្នុងឧទាហរណ៍នេះ) ។
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // ពិនិត្យឡើងវិញនូវខ្សែភាពយន្តមួយចំនួន។
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // ពិនិត្យរកមើលជាក់លាក់មួយ។
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // អូការពិនិត្យឡើងវិញនេះមានកំហុសអក្ខរាវិរុទ្ធជាច្រើនសូមលុបវាចោល។
/// movie_reviews.remove("The Blues Brothers");
///
/// // រកមើលតម្លៃដែលទាក់ទងនឹងកូនសោមួយចំនួន។
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // រកមើលតម្លៃសម្រាប់កូនសោមួយ (នឹង panic ប្រសិនបើរកមិនឃើញកូនសោ) ។
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // រមាស់លើអ្វីៗទាំងអស់។
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` អនុវត្ត [`Entry API`] X ផងដែរដែលអនុញ្ញាតឱ្យមានវិធីសាស្រ្តស្មុគស្មាញក្នុងការទទួលយកការកំណត់ធ្វើបច្ចុប្បន្នភាពនិងដោះកូនសោនិងតម្លៃរបស់វា៖
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // ប្រភេទ inference អនុញ្ញាតឱ្យយើងលុបហត្ថលេខាប្រភេទជាក់លាក់មួយ (ដែលនឹងជា `BTreeMap<&str, u8>` ក្នុងឧទាហរណ៍នេះ) ។
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // ពិតជាអាចប្រគល់តម្លៃចៃដន្យខ្លះនៅទីនេះតោះត្រឡប់មកវិញនូវតំលៃថេរមួយចំនួនឥឡូវនេះ
/////
///     42
/// }
///
/// // បញ្ចូលកូនសោរលុះត្រាតែវាមិនទាន់មាន
/// player_stats.entry("health").or_insert(100);
///
/// // បញ្ចូលកូនសោរដោយប្រើមុខងារដែលផ្តល់នូវតម្លៃថ្មីលុះត្រាតែវាមិនទាន់មាន
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // ធ្វើឱ្យទាន់សម័យគន្លឹះមួយ, ការការពារប្រឆាំងនឹងគ្រាប់ចុចដែលអាចត្រូវបានមិនបានកំណត់
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // ការដាក់អីវ៉ាន់ដោយជោគជ័យពីព្រោះយើងទើបតែរុំ
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // យើងមិនអាចបំផ្លាញអនុក្រិតនេះដោយផ្ទាល់ទេពីព្រោះ BTreeMap អនុវត្តទម្លាក់
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // តាមឧត្ដមគតិយើងចង់ហៅ `BTreeMap::new` នៅទីនេះប៉ុន្តែនោះមាន `ខេ៖
            // ឧបសគ្គ Ord `ដែលវិធីសាស្ត្រនេះខ្វះ។
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // unwrap ជោគជ័យព្រោះមិនទទេ
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// អ្នកត្រួតត្រាលើធាតុនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`iter`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// អ្នកផ្លាស់ប្តូរវេនគ្នាលើធាតុនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`iter_mut`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// ម្ចាស់កម្មសិទ្ធិជាម្ចាស់លើធាតុនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`into_iter`] នៅលើ [`BTreeMap`] (ផ្តល់ដោយ `IntoIterator` trait) ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// ត្រឡប់អ្នកធ្វើសេចក្តីយោងលើធាតុដែលនៅសល់។
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// កំណែ `IntoIter` សាមញ្ញដែលមិនត្រូវបានបញ្ចប់ទ្វេដងហើយមានគោលបំណងតែមួយ: ដើម្បីទម្លាក់នៅសល់នៃ `IntoIter` ។
/// ដូច្នេះវាក៏ផ្តល់នូវការទម្លាក់ដើមឈើទាំងមូលដោយមិនចាំបាច់រកមើលស្លឹក `back` X0X edge ។
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// អ្នកត្រួតត្រាលើកូនសោរនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`keys`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// អ្នកត្រួតត្រាលើតម្លៃនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`values`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ឧបករណ៍រំកិលដែលអាចផ្លាស់ប្តូរបានលើតម្លៃនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`values_mut`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// ម្ចាស់កម្មសិទ្ធិលើកូនសោរនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`into_keys`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// ម្ចាស់កម្មសិទ្ធិលើតម្លៃនៃ `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`into_values`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// អ្នកត្រួតត្រាលើជួររងនៃធាតុនៅក្នុង `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`range`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// អ្នកផ្លាស់ប្តូរវេនគ្នាលើអនុជួរនៃធាតុនៅក្នុង `BTreeMap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`range_mut`] នៅលើ [`BTreeMap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // ឈ្លានពានក្នុង `K` និង `V`
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// ធ្វើឱ្យ `BTreeMap` ទទេថ្មី។
    ///
    /// មិនបែងចែកអ្វីទាំងអស់ដោយខ្លួនឯង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // ឥឡូវធាតុបញ្ចូលអាចត្រូវបានបញ្ចូលទៅក្នុងផែនទីទទេ
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// សម្អាតផែនទីដកចេញធាតុទាំងអស់។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// ត្រឡប់សេចក្តីយោងទៅតម្លៃដែលត្រូវនឹងកូនសោ។
    ///
    /// គ្រាប់ចុចអាចជាទម្រង់ដែលបានខ្ចីនៃប្រភេទកូនសោនៃផែនទីប៉ុន្តែការបញ្ជាទិញនៅលើទម្រង់ដែលបានខ្ចី *ត្រូវតែ* ផ្គូផ្គងការបញ្ជាទិញនៅលើប្រភេទសំខាន់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// ត្រឡប់គូតម្លៃគ្រាប់ចុចដែលត្រូវគ្នាទៅនឹងកូនសោដែលបានផ្គត់ផ្គង់។
    ///
    /// គ្រាប់ចុចដែលបានផ្តល់អាចជាទម្រង់ដែលបានខ្ចីនៃប្រភេទគ្រាប់ចុចរបស់ផែនទីប៉ុន្តែការបញ្ជាទិញនៅលើទម្រង់ដែលបានខ្ចី *ត្រូវតែ* ត្រូវគ្នាទៅនឹងការបញ្ជាទិញនៅលើប្រភេទសំខាន់។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// ត្រឡប់គូតម្លៃគ្រាប់ចុចដំបូងនៅក្នុងផែនទី។
    /// កូនសោនៅក្នុងគូនេះគឺជាកូនសោអប្បបរមានៅក្នុងផែនទី។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// ត្រឡប់ធាតុដំបូងនៅក្នុងផែនទីសម្រាប់ការរៀបចំកន្លែង។
    /// កូនសោនៃធាតុនេះគឺជាកូនសោអប្បបរមានៅក្នុងផែនទី។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// យកនិងត្រឡប់ធាតុដំបូងនៅក្នុងផែនទី។
    /// គន្លឹះនៃធាតុនេះគឺជាកូនសោអប្បបរមាដែលមាននៅក្នុងផែនទី។
    ///
    /// # Examples
    ///
    /// ធាតុផ្សំនៅក្នុងលំដាប់ឡើងខណៈពេលដែលរក្សាផែនទីដែលអាចប្រើបាន។
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// ត្រឡប់គូតម្លៃគ្រាប់ចុចចុងក្រោយនៅក្នុងផែនទី។
    /// កូនសោនៅក្នុងគូនេះគឺជាកូនសោអតិបរមានៅក្នុងផែនទី។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// ត្រឡប់ធាតុចុងក្រោយនៅក្នុងផែនទីសម្រាប់ការរៀបចំកន្លែង។
    /// កូនសោនៃធាតុនេះគឺជាកូនសោអតិបរមានៅក្នុងផែនទី។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// យកនិងត្រឡប់ធាតុចុងក្រោយនៅក្នុងផែនទី។
    /// កូនសោនៃធាតុនេះគឺជាកូនសោអតិបរមាដែលមាននៅក្នុងផែនទី។
    ///
    /// # Examples
    ///
    /// ធាតុផ្សំនៅក្នុងលំដាប់ចុះ, ខណៈពេលដែលរក្សាផែនទីដែលអាចប្រើបានរៀងរាល់ការនិយាយឡើងវិញ។
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// ត្រឡប់ `true` ប្រសិនបើផែនទីមានតម្លៃសម្រាប់កូនសោដែលបានបញ្ជាក់។
    ///
    /// គ្រាប់ចុចអាចជាទម្រង់ដែលបានខ្ចីនៃប្រភេទកូនសោនៃផែនទីប៉ុន្តែការបញ្ជាទិញនៅលើទម្រង់ដែលបានខ្ចី *ត្រូវតែ* ផ្គូផ្គងការបញ្ជាទិញនៅលើប្រភេទសំខាន់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅតម្លៃដែលត្រូវគ្នានឹងគ្រាប់ចុច។
    ///
    /// គ្រាប់ចុចអាចជាទម្រង់ដែលបានខ្ចីនៃប្រភេទកូនសោនៃផែនទីប៉ុន្តែការបញ្ជាទិញនៅលើទម្រង់ដែលបានខ្ចី *ត្រូវតែ* ផ្គូផ្គងការបញ្ជាទិញនៅលើប្រភេទសំខាន់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // សូមមើល `get` សម្រាប់កំណត់ចំណាំការអនុវត្តនេះគឺជាមូលដ្ឋាននៃការចម្លងជាមួយការបន្ថែមរបស់ mut
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// បញ្ចូលគូតម្លៃតម្លៃទៅក្នុងផែនទី។
    ///
    /// ប្រសិនបើផែនទីមិនមានវត្តមានសំខាន់នេះទេ `None` ត្រូវបានត្រឡប់មកវិញ។
    ///
    /// ប្រសិនបើផែនទីមានវត្តមានសំខាន់នេះតម្លៃត្រូវបានធ្វើបច្ចុប្បន្នភាពហើយតម្លៃចាស់ត្រូវបានត្រឡប់មកវិញ។
    /// គន្លឹះមិនត្រូវបានធ្វើបច្ចុប្បន្នភាពទេ។នេះសំខាន់សម្រាប់ប្រភេទដែលអាចជា `==` ដោយមិនដូចគ្នា។
    ///
    /// មើល [module-level documentation] សម្រាប់ព័ត៌មានបន្ថែម។
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// ព្យាយាមបញ្ចូលគូតម្លៃតម្លៃចូលទៅក្នុងផែនទីហើយត្រឡប់ការយោងដែលអាចផ្លាស់ប្តូរទៅតម្លៃនៅក្នុងធាតុ។
    ///
    /// ប្រសិនបើផែនទីមានវត្តមានកូនសោនេះរួចហើយគ្មានអ្វីត្រូវបានធ្វើបច្ចុប្បន្នភាពទេហើយកំហុសដែលមានធាតុកាន់កាប់និងតម្លៃត្រូវបានត្រឡប់មកវិញ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// យកកូនសោចេញពីផែនទីដោយត្រឡប់តម្លៃនៅគ្រាប់ចុចប្រសិនបើគ្រាប់ចុចពីមុននៅក្នុងផែនទី។
    ///
    /// គ្រាប់ចុចអាចជាទម្រង់ដែលបានខ្ចីនៃប្រភេទកូនសោនៃផែនទីប៉ុន្តែការបញ្ជាទិញនៅលើទម្រង់ដែលបានខ្ចី *ត្រូវតែ* ផ្គូផ្គងការបញ្ជាទិញនៅលើប្រភេទសំខាន់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// យកកូនសោចេញពីផែនទីដោយប្រគល់កូនសោនិងតម្លៃដែលបានរក្សាទុកប្រសិនបើគ្រាប់ចុចពីមុននៅក្នុងផែនទី។
    ///
    /// គ្រាប់ចុចអាចជាទម្រង់ដែលបានខ្ចីនៃប្រភេទកូនសោនៃផែនទីប៉ុន្តែការបញ្ជាទិញនៅលើទម្រង់ដែលបានខ្ចី *ត្រូវតែ* ផ្គូផ្គងការបញ្ជាទិញនៅលើប្រភេទសំខាន់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// រក្សាទុកតែធាតុដែលបានបញ្ជាក់ដោយអ្នកព្យាករណ៍។
    ///
    /// និយាយម៉្យាងទៀតដកគូទាំងអស់ `(k, v)` ចេញដែល `f(&k, &mut v)` ត្រឡប់មកវិញ `false` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // រក្សាទុកតែធាតុដែលមានលេខគូ។
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// ផ្លាស់ទីធាតុទាំងអស់ពី `other` ទៅជា `Self` ទុកឱ្យ `other` ទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // តើយើងត្រូវបន្ថែមអ្វីទៀតទេ?
        if other.is_empty() {
            return;
        }

        // យើងគ្រាន់តែអាចប្តូរ `self` និង `other` ប្រសិនបើ `self` ទទេ។
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// សាងសង់ទ្រនាប់ទ្រនាប់ចុងទ្វេលើធាតុរងក្នុងផែនទី។
    /// វិធីសាមញ្ញបំផុតគឺប្រើវាក្យសម្ព័ន្ធជួរ `min..max` ដូច្នេះ `range(min..max)` នឹងផ្តល់លទ្ធផលពីមីនី (inclusive) ដល់អតិបរមា (exclusive) ។
    /// ជួរក៏អាចត្រូវបានបញ្ចូលជា `(Bound<T>, Bound<T>)` ផងដែរឧទាហរណ៍ `range((Excluded(4), Included(10)))` នឹងផ្តល់ជួរខាងឆ្វេង-ផ្តាច់មុខ-ពីស្តាំដល់លេខ 4 ដល់លេខ 10 ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើជួរ `start > end` ។
    /// Panics ប្រសិនបើជួរ `start == end` និងព្រំដែនទាំងពីរគឺ `Excluded` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// សាងសង់ទ្រនិចទ្រេតទ្វេដែលអាចបំលែងបានលើធាតុរងនៃផែនទី។
    /// វិធីសាមញ្ញបំផុតគឺប្រើវាក្យសម្ព័ន្ធជួរ `min..max` ដូច្នេះ `range(min..max)` នឹងផ្តល់លទ្ធផលពីមីនី (inclusive) ដល់អតិបរមា (exclusive) ។
    /// ជួរក៏អាចត្រូវបានបញ្ចូលជា `(Bound<T>, Bound<T>)` ផងដែរឧទាហរណ៍ `range((Excluded(4), Included(10)))` នឹងផ្តល់ជួរខាងឆ្វេង-ផ្តាច់មុខ-ពីស្តាំដល់លេខ 4 ដល់លេខ 10 ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើជួរ `start > end` ។
    /// Panics ប្រសិនបើជួរ `start == end` និងព្រំដែនទាំងពីរគឺ `Excluded` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// ទទួលបានធាតុដែលត្រូវគ្នានៃកូនសោដែលបានផ្តល់នៅក្នុងផែនទីសម្រាប់ការរៀបចំកន្លែង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // រាប់ចំនួននៃការកើតឡើងនៃអក្សរនៅក្នុងវី
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) ជៀសវាងការបែងចែកប្រសិនបើយើងមិនបញ្ចូល
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// បំបែកការប្រមូលជាពីរនៅគ្រាប់ចុចដែលបានផ្តល់ឱ្យ។
    /// ប្រគល់អ្វីគ្រប់យ៉ាងឡើងវិញបន្ទាប់ពីកូនសោដែលបានផ្តល់ឱ្យរួមទាំងកូនសោ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // unwrap ជោគជ័យព្រោះមិនទទេ

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// បង្កើតឧបករណ៍វាស់ស្ទង់ដែលចូលមើលធាតុទាំងអស់ (គូតម្លៃគ្រាប់ចុច) នៅក្នុងលំដាប់ឡើងដ៏សំខាន់ហើយប្រើការបិទដើម្បីកំណត់ថាតើធាតុមួយគួរតែត្រូវបានដកចេញ។
    /// ប្រសិនបើការបិទត្រលប់មកវិញ `true` ធាតុត្រូវបានដកចេញពីផែនទីហើយផ្តល់លទ្ធផល។
    /// ប្រសិនបើការបិទត្រលប់មកវិញ `false`, ឬ panics, ធាតុនៅតែមាននៅក្នុងផែនទីហើយនឹងមិនត្រូវបានផ្តល់លទ្ធផលទេ។
    ///
    /// ឧបករណ៍រំកិលក៏អនុញ្ញាតឱ្យអ្នកផ្លាស់ប្តូរតម្លៃនៃធាតុនីមួយៗនៅក្នុងការបិទដោយមិនគិតពីថាតើអ្នកជ្រើសរើសរក្សាទុកឬយកវាចេញ។
    ///
    /// ប្រសិនបើឧបករណ៍រំកិលត្រូវបានប្រើប្រាស់ដោយផ្នែកខ្លះឬមិនបានប្រើប្រាស់ទាល់តែសោះធាតុដែលនៅសល់នីមួយៗនៅតែត្រូវបានគេបិទដែលអាចផ្លាស់ប្តូរតម្លៃរបស់វាហើយដោយការត្រឡប់ `true` មានធាតុត្រូវបានដកចេញនិងទម្លាក់។
    ///
    ///
    /// គេមិនបានបញ្ជាក់ថាតើមានធាតុប៉ុន្មានទៀតដែលនឹងត្រូវ ដាក់ឲ្យ បិទនោះទេប្រសិនបើ panic កើតឡើងក្នុងការបិទឬ panic កើតឡើងនៅពេលទម្លាក់ធាតុឬបើតម្លៃ `DrainFilter` លេចធ្លាយ។
    ///
    /// # Examples
    ///
    /// បំបែកផែនទីទៅជាកូនសោគូនិងលេខសេសដោយប្រើផែនទីដើម៖
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// បង្កើតឧបករណ៍រំអិលប្រើប្រាស់ដោយទស្សនាកូនសោទាំងអស់តាមលំដាប់លំដោយ។
    /// ផែនទីមិនអាចត្រូវបានប្រើបន្ទាប់ពីការហៅនេះ។
    /// ប្រភេទធាតុទ្រនាប់គឺ `K` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// បង្កើតឧបករណ៍វាស់ស្ទង់ការប្រើប្រាស់ដោយមើលតម្លៃទាំងអស់តាមលំដាប់។
    /// ផែនទីមិនអាចត្រូវបានប្រើបន្ទាប់ពីការហៅនេះ។
    /// ប្រភេទធាតុទ្រនាប់គឺ `V` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// ត្រឡប់អ្នកធ្វើសេចក្តីយោងលើធាតុដែលនៅសល់។
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // ប្រហាក់ប្រហែលនឹងការជឿនលឿននៃទ្រនាប់ដែលមិនរលាយ។
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // បន្តរង្វិលជុំដូចគ្នាដែលយើងអនុវត្តខាងក្រោម។
                // វាដំណើរការតែនៅពេលបង្រួបបង្រួមដូច្នេះយើងមិនចាំបាច់ខ្វល់អំពី panics នៅពេលនេះទេ (ពួកគេនឹងបោះបង់ចោល) ។
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// ឧបករណ៍រំកិលដែលផលិតដោយការហៅទូរស័ព្ទ `drain_filter` តាម BTreeMap ។
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// ភាគច្រើននៃការអនុវត្តនៃលូបង្ហូរទឹកគឺមានលក្ខណៈទូទៅជាងប្រភេទនៃការទស្សន៍ទាយដូច្នេះក៏បម្រើដល់ BTreeSet::DrainFilter ផងដែរ។
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// ឯកសារយោងទៅវាលដែលមានប្រវែងនៅក្នុងផែនទីដែលបានខ្ចីធ្វើបច្ចុប្បន្នភាពផ្ទាល់។
    length: &'a mut usize,
    /// កប់ឯកសារយោងទៅមូលដ្ឋានឫសក្នុងផែនទីដែលបានខ្ចី។
    /// រុំក្នុង `Option` ដើម្បីអនុញ្ញាតឱ្យអ្នកដោះស្រាយទម្លាក់ទៅ `take` ។
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// មានស្លឹក edge មុនធាតុបន្ទាប់ដែលត្រូវត្រលប់មកវិញឬស្លឹកចុងក្រោយ edge ។
    /// ទទេប្រសិនបើផែនទីមិនមានឬសប្រសិនបើការបង្កើតឡើងវិញហួសពីស្លឹកចុងក្រោយ edge ឬប្រសិនបើ panic បានកើតឡើងនៅក្នុងការប៉ាន់ស្មាន។
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// អនុញ្ញាតឱ្យការអនុវត្តការអនុវត្តបំបាត់កំហុសដើម្បីទស្សន៍ទាយធាតុបន្ទាប់។
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// ការអនុវត្តវិធីសាស្ត្រ `DrainFilter::next` ធម្មតាដែលបានផ្តល់ឱ្យជាមុន។
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // សុវត្ថិភាព: យើងនឹងប៉ះឬសតាមរបៀបដែលមិនមាន
                    // ធ្វើឱ្យទីតាំងមិនមានសុពលភាព។
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// ការអនុវត្តវិធីសាស្ត្រ `DrainFilter::size_hint` ធម្មតា។
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // ភាគច្រើននៃអាយធីប៊ីប៊ីធី `self.length` គឺជាចំនួននៃធាតុដែលមិនទាន់ត្រូវបានទស្សនា។
        // នៅទីនេះវារួមបញ្ចូលនូវធាតុដែលត្រូវបានទៅទស្សនាហើយអ្នកព្យាករណ៍បានសំរេចមិនធ្វើ drain ។
        // ការធ្វើឱ្យខ័ណ្ឌខាងលើមានភាពត្រឹមត្រូវជាងមុនទាមទារឱ្យមានកន្លែងបន្ថែមហើយមិនមានតម្លៃទេ។
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// ត្រឡប់អ្នកធ្វើសេចក្តីយោងលើធាតុដែលនៅសល់។
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// បង្កើត `BTreeMap` ទទេ។
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// ត្រឡប់សេចក្តីយោងទៅតម្លៃដែលត្រូវគ្នានឹងកូនសោដែលបានផ្គត់ផ្គង់។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើគ្រាប់ចុចមិនមាននៅក្នុង `BTreeMap` ។
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// ធ្វើឱ្យអ្នកត្រួតត្រាលើធាតុនៃផែនទីតម្រៀបតាមគ្រាប់ចុច។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// ទទួលបានការផ្លាស់ប្តូរការផ្លាស់ប្តូរលើធាតុនៃផែនទី, តម្រៀបតាមគ្រាប់ចុច។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // បន្ថែមលេខ ១០ ទៅតម្លៃប្រសិនបើកូនសោមិនមែន "a"
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// ចាប់យកអ្នកត្រួតត្រាលើកូនសោនៃផែនទីតាមលំដាប់លំដោយ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// ទទួលបានការដំឡើងតម្លៃលើផែនទីតាមលំដាប់លំដោយ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// ទទួលបានការផ្លាស់ប្តូរការផ្លាស់ប្តូរលើតម្លៃនៃផែនទីតាមលំដាប់។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// ត្រឡប់ចំនួនធាតុក្នុងផែនទី។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// ត្រឡប់ `true` ប្រសិនបើផែនទីគ្មានធាតុ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ប្រសិនបើថ្នាំង root គឺជាថ្នាំង root (non-allocated) ទទេបែងចែកថ្នាំងផ្ទាល់ខ្លួន។
    /// គឺជាមុខងារដែលពាក់ព័ន្ធដើម្បីចៀសវាងការខ្ចីប្រាក់ BTreeMap ទាំងមូល។
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;