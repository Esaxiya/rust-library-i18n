use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// យកគូដែលមានតម្លៃមួយចេញពីមែកឈើហើយប្រគល់មកវិញនូវគូនោះក៏ដូចជាស្លឹក edge ដែលត្រូវនឹងអតីតគូ។
    /// វាអាចទៅរួចដែលបញ្ចោញថ្នាំងឫសដែលមាននៅខាងក្នុងដែលអ្នកហៅទូរស័ព្ទគួរតែលេចឡើងពីផែនទីកាន់ដើមឈើ។
    /// អ្នកទូរស័ព្ទចូលក៏គួរបន្ថយប្រវែងផែនទីផងដែរ។
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // យើងត្រូវភ្លេចប្រភេទកុមារជាបណ្តោះអាសន្នព្រោះមិនមានប្រភេទថ្នាំងខុសគ្នាសម្រាប់ឪពុកម្តាយភ្លាមៗនៃស្លឹក។
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // សុវត្ថិភាព: `new_pos` គឺជាស្លឹកដែលយើងបានចាប់ផ្តើមពីឬបងប្អូនបង្កើត។
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // ប្រសិនបើយើងបញ្ចូលគ្នាឪពុកម្តាយ (ប្រសិនបើមាន) បានរួញតូចប៉ុន្តែរំលងជំហានខាងក្រោមបើមិនដូច្នេះទេមិនត្រូវបានបង់តាមគំរូទេ។
            //
            // សុវត្ថិភាព: យើងនឹងមិនបំផ្លាញឬរៀបចំស្លឹកឈើដែលជាកន្លែងដែល `pos` ស្ថិតនៅ
            // ដោយដោះស្រាយឪពុកម្តាយរបស់ខ្លួនម្តងហើយម្តងទៀត;នៅពេលដែលអាក្រក់បំផុតយើងនឹងបំផ្លាញឬរៀបចំឪពុកម្តាយតាមរយៈជីតាដូច្នេះប្តូរតំណទៅមេនៅខាងក្នុងស្លឹក។
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // យកគីវីដែលនៅជាប់នឹងស្លឹករបស់វាចេញហើយបន្ទាប់មកដាក់វាជំនួសឱ្យធាតុដែលយើងត្រូវបានគេស្នើសុំឱ្យយកចេញ។
        //
        // ចូលចិត្ត KV ដែលនៅជាប់គ្នាខាងឆ្វេងសម្រាប់ហេតុផលដែលបានរាយក្នុង `choose_parent_kv` ។
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // ថ្នាំងខាងក្នុងអាចត្រូវបានគេលួចឬបញ្ចូលចូលគ្នា។
        // ត្រលប់ទៅខាងស្តាំដើម្បីរកកន្លែងដែលគីវីដើមបានបញ្ចប់។
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}