use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ស្តុកទុកថ្នាំងដែលអាចធ្វើទៅបានដោយការច្របាច់បញ្ចូលគ្នាឬលួចពីបងប្អូនបង្កើត។
    /// ប្រសិនបើទទួលបានជោគជ័យប៉ុន្តែក្នុងការចំណាយបង្រួមថ្នាំងមេត្រឡប់ថ្នាំងមេដែលរួញតូច។
    /// ត្រឡប់ `Err` ប្រសិនបើថ្នាំងជាឫសទទេ។
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ស្តុកទុកថ្នាំងដែលអាចធ្វើទៅបានហើយប្រសិនបើនោះបណ្តាលឱ្យថ្នាំងមេរបស់វារួញតូចស្តុកទុកមេឡើងវិញ។
    /// ត្រឡប់ `true` ប្រសិនបើវាជួសជុលមែកធាង `false` X ប្រសិនបើវាមិនអាចទេពីព្រោះថ្នាំងឫសក្លាយជាទទេ។
    ///
    /// វិធីសាស្រ្តនេះមិនរំពឹងថាជីដូនជីតាអាចស្ថិតនៅក្រោមការចូលនិង panics រួចហើយប្រសិនបើវាជួបជាមួយជីដូនជីតាទទេ។
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// ដកកម្រិតទទេនៅលើកំពូលប៉ុន្តែរក្សាស្លឹកទទេប្រសិនបើដើមឈើទាំងមូលទទេ។
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// ស្តុកទុកឬច្របាច់បញ្ចូលថ្នាំងក្រោមដីនៅខាងស្តាំដើមឈើ។
    /// ថ្នាំងផ្សេងទៀតដែលមិនមែនជាឬមិនមែនជា edge ត្រូវត្រូវតែមានធាតុយ៉ាងហោច MIN_LEN រួចហើយ។
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// ក្លូនស៊ីមេទ្រីនៃ `fix_right_border` ។
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// ស្តុកទុកថ្នាំង underfull ណាមួយនៅព្រំដែនខាងស្តាំនៃដើមឈើ។
    /// ថ្នាំងផ្សេងទៀតដែលមិនមែនជាឬសមិនមែនជារបស់ edge ត្រូវតែត្រូវបានគេរៀបចំឱ្យមានធាតុដែលបានលួចរហូតដល់ទៅ MIN_LEN ។
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // ពិនិត្យមើលថាតើកុមារដែលត្រឹមត្រូវបំផុតគឺ underfull ។
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // យើងត្រូវលួច។
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // ចុះទៅក្រោមទៀត។
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// ស្តុកទុកក្មេងខាងឆ្វេងដោយសន្មតថាកូនខាងស្តាំមិនមានភាពខ្វះខាតហើយបទប្បញ្ញត្តិជាធាតុបន្ថែមដើម្បីអនុញ្ញាតឱ្យមានការរួមបញ្ចូលគ្នារវាងកូន ៗ របស់ខ្លួនជាវេនដោយមិនចាំបាច់ក្លាយជាក្មេងតូចតាច។
    ///
    /// ត្រឡប់កូនខាងឆ្វេង។
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ដើម្បីចៀសវាងការធ្វើយុត្តិធម៍ប្រសិនបើការបញ្ចូលគ្នាកើតឡើងនៅកម្រិតបន្ទាប់។
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// ស្តុកទុកកូនខាងស្តាំដោយសន្មតថាក្មេងខាងឆ្វេងមិនមានភាពខ្វះខាតហើយបទប្បញ្ញត្តិជាធាតុបន្ថែមដើម្បីអនុញ្ញាតឱ្យមានការរួមបញ្ចូលគ្នារវាងកូន ៗ របស់ខ្លួនជាវេនដោយមិនបានក្លាយជាក្មេងតូចតាច។
    ///
    /// ត្រឡប់កន្លែងណាដែលកុមារត្រឹមត្រូវបញ្ចប់។
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` ដើម្បីចៀសវាងការធ្វើយុត្តិធម៍ប្រសិនបើការបញ្ចូលគ្នាកើតឡើងនៅកម្រិតបន្ទាប់។
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}