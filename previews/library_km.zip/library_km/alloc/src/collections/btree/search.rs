use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// ការរួមបញ្ចូលដើម្បីស្វែងរកដូចជា `Bound::Included(T)` ។
    Included(T),
    /// វត្ថុផ្តាច់មុខដើម្បីរកមើល, ដូចជា `Bound::Excluded(T)` ។
    Excluded(T),
    /// ការដាក់បញ្ចូលដោយគ្មានលក្ខខណ្ឌដូចជា `Bound::Unbounded` ។
    AllIncluded,
    /// ព្រំដែនផ្តាច់មុខដោយគ្មានលក្ខខណ្ឌ។
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// រកមើលកូនសោដែលបានផ្តល់ឱ្យនៅក្នុងមែកធាង (រង) ដែលដឹកនាំដោយថ្នាំងម្តងហើយម្តងទៀត។
    /// ត្រឡប់ `Found` ជាមួយចំណុចទាញនៃគីវីដែលត្រូវគ្នាប្រសិនបើមាន។
    /// បើមិនដូច្នោះទេត្រឡប់ `GoDown` ជាមួយនឹងចំណុចទាញនៃស្លឹក edge ដែលជាកន្លែងដែលកូនសោជាកម្មសិទ្ធិ។
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយកូនសោរដូចជាដើមឈើដែលមាននៅក្នុង `BTreeMap` អញ្ចឹង។
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// ចុះដល់ថ្នាំងដែលនៅជិតបំផុតដែល edge ផ្គូផ្គងព្រំដែនទាបនៃជួរខុសគ្នាពី edge ផ្គូផ្គងព្រំដែនខាងលើពោលគឺថ្នាំងដែលនៅជិតបំផុតដែលមានកូនសោយ៉ាងហោចមួយដែលមាននៅក្នុងជួរ។
    ///
    ///
    /// ប្រសិនបើរកឃើញត្រឡប់ `Ok` ជាមួយថ្នាំងនោះគូនៃសន្ទស្សន៍ edge នៅក្នុងវាកំណត់ព្រំដែនជួរនិងគូដែលត្រូវគ្នាសម្រាប់បន្តស្វែងរកនៅក្នុងថ្នាំងកុមារក្នុងករណីថ្នាំងខាងក្នុង។
    ///
    /// ប្រសិនបើរកមិនឃើញទេត្រឡប់លេខ `Err` ជាមួយស្លឹក edge ដែលត្រូវនឹងជួរទាំងមូល។
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយគ្រាប់ចុច។
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ការបញ្ចូលអថេរទាំងនេះគួរតែត្រូវជៀសវាង។
        // យើងសន្មតថាព្រំដែនដែលបានរាយការណ៍ដោយ `range` នៅតែដដែលប៉ុន្តែការអនុវត្តផ្ទុយអាចផ្លាស់ប្តូររវាងការហៅទូរស័ព្ទ (#81138) ។
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// រកឃើញ edge នៅក្នុងថ្នាំងកំណត់ព្រំដែនទាបនៃជួរ។
    /// បញ្ជូនត្រឡប់ក្រោមដែលត្រូវប្រើសម្រាប់បន្តការស្វែងរកនៅក្នុងកូនដែលត្រូវគ្នាប្រសិនបើ `self` គឺជាថ្នាំងខាងក្នុង។
    ///
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយគ្រាប់ចុច។
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// ក្លូននៃ `find_lower_bound_edge` សម្រាប់ព្រំដែនខាងលើ។
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// រកមើលកូនសោដែលបានផ្តល់ឱ្យនៅក្នុងថ្នាំងដោយគ្មានការហៅឡើងវិញ។
    /// ត្រឡប់ `Found` ជាមួយចំណុចទាញនៃគីវីដែលត្រូវគ្នាប្រសិនបើមាន។
    /// បើមិនដូច្នោះទេត្រឡប់ `GoDown` ជាមួយនឹងចំណុចទាញរបស់ edge ដែលអាចរកឃើញកូនសោ (ប្រសិនបើថ្នាំងនៅខាងក្នុង) ឬកន្លែងដែលអាចបញ្ចូលកូនសោបាន។
    ///
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយកូនសោរដូចជាដើមឈើដែលមាននៅក្នុង `BTreeMap` អញ្ចឹង។
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// ត្រឡប់លិបិក្រម KV នៅក្នុងថ្នាំងដែលមានកូនសោ (ឬសមមូល) ឬសន្ទស្សន៍ edge ដែលជាកន្លែងដែលកូនសោមាន។
    ///
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយកូនសោរដូចជាដើមឈើដែលមាននៅក្នុង `BTreeMap` អញ្ចឹង។
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// រកលិបិក្រម edge នៅក្នុងថ្នាំងកំណត់ព្រំដែនទាបនៃជួរ។
    /// បញ្ជូនត្រឡប់ក្រោមដែលត្រូវប្រើសម្រាប់បន្តការស្វែងរកនៅក្នុងកូនដែលត្រូវគ្នាប្រសិនបើ `self` គឺជាថ្នាំងខាងក្នុង។
    ///
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយគ្រាប់ចុច។
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// ក្លូននៃ `find_lower_bound_index` សម្រាប់ព្រំដែនខាងលើ។
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}