use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// ស្នូលនៃឧបករណ៍រំកិលដែលរួមបញ្ចូលគ្នានូវលទ្ធផលនៃការកើនឡើងពីរយ៉ាងតឹងរ៉ឹងឧទាហរណ៍សហជីពឬភាពខុសគ្នាស៊ីមេទ្រី។
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// ចំនុចគោលលឿនជាងការរុំទ្រនាប់ទ្រនាប់ទ្រនាប់ទាំងពីរនៅក្នុង Peekable ប្រហែលជាដោយសារយើងអាចមានលទ្ធភាពដាក់ FusedIterator ។
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// បង្កើតស្នូលថ្មីសម្រាប់អ្នកធ្វើសមាហរណកម្មបញ្ចូលគ្នានូវប្រភពពីរ។
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// ត្រឡប់ធាតុបន្ទាប់នៃធាតុដែលមកពីប្រភពដែលកំពុងត្រូវបានបញ្ចូលគ្នា។
    /// ប្រសិនបើជម្រើសត្រឡប់មកវិញទាំងពីរមានតំលៃនោះតម្លៃនោះគឺស្មើគ្នាហើយកើតឡើងនៅក្នុងប្រភពទាំងពីរ។
    /// ប្រសិនបើជម្រើសមួយក្នុងចំណោមជម្រើសដែលត្រឡប់មកវិញមានតំលៃនោះតម្លៃនោះមិនមាននៅក្នុងប្រភពផ្សេងទៀត (ឬប្រភពមិនមានការកើនឡើងខ្ពស់ទេ) ។
    ///
    /// ប្រសិនបើគ្មានជម្រើសត្រឡប់មកវិញមានតម្លៃទេការនិយាយឡើងវិញបានបញ្ចប់ហើយការហៅជាបន្តបន្ទាប់នឹងត្រឡប់មកវិញគូទទេដូចគ្នា។
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// ត្រឡប់គូខាងលើនៃព្រំដែនសម្រាប់ `size_hint` នៃការលើកចុងក្រោយ។
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}