use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// យកចេញជាបណ្តោះអាសន្នដែលអាចផ្លាស់ប្តូរបាននៃជួរដូចគ្នា។
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// រកគែមស្លឹកខុសគ្នាកំណត់ព្រំដែនជួរដែលបានបញ្ជាក់នៅក្នុងមែកធាង។
    /// ត្រឡប់ចំណុចទាញផ្សេងៗគ្នាទៅជាមែកធាងតែមួយឬជម្រើសទទេមួយគូ។
    ///
    /// # Safety
    ///
    /// លើកលែងតែ `BorrowType` ជា `Immut` សូមកុំប្រើចំណុចទាញស្ទួនដើម្បីទស្សនាវីវ៉ាតែមួយពីរដង។
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// ស្មើនឹង `(root1.first_leaf_edge(), root2.last_leaf_edge())` ប៉ុន្តែមានប្រសិទ្ធភាពជាង។
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// រកឃើញគែមស្លឹកមួយគូដែលកំណត់ព្រំដែនជួរជាក់លាក់មួយក្នុងមែកធាង។
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយកូនសោរដូចជាដើមឈើដែលមាននៅក្នុង `BTreeMap` អញ្ចឹង។
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // សុវត្ថិភាព: ប្រភេទប្រាក់កម្ចីរបស់យើងគឺមិនអាចផ្លាស់ប្តូរបានទេ។
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// រកឃើញគែមស្លឹកមួយគូដែលកំណត់ព្រំដែនដើមឈើមួយដើម។
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// ពុះឯកសារយោងដាច់ដោយឡែកមួយចូលទៅក្នុងគែមស្លឹកគូកំណត់ព្រំដែនជួរដែលបានបញ្ជាក់។
    /// លទ្ធផលគឺជាឯកសារយោងដែលមិនមានតែមួយដែលអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរ (some) ដែលត្រូវតែប្រើដោយប្រុងប្រយ័ត្ន។
    ///
    /// លទ្ធផលគឺមានអត្ថន័យលុះត្រាតែដើមឈើត្រូវបានបញ្ជាដោយកូនសោរដូចជាដើមឈើដែលមាននៅក្នុង `BTreeMap` អញ្ចឹង។
    ///
    ///
    /// # Safety
    /// កុំប្រើចំណុចទាញស្ទួនដើម្បីទស្សនាវីវ៉ាដូចគ្នាពីរដង។
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ពុះឯកសារយោងតែមួយគត់ទៅជាគែមស្លឹកមួយគូដែលកំណត់ព្រំដែនដើមឈើទាំងមូល។
    /// លទ្ធផលគឺជាឯកសារយោងដែលមិនមានតែមួយដែលអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរ (នៃតម្លៃតែប៉ុណ្ណោះ) ដូច្នេះត្រូវតែប្រើដោយយកចិត្តទុកដាក់។
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // យើងស្ទួនឫស NodeRef នៅទីនេះ-យើងនឹងមិនដែលទៅ KV ដដែលពីរដងហើយមិនដែលបញ្ចប់សេចក្តីយោងតម្លៃត្រួតគ្នាទេ។
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// ពុះឯកសារយោងតែមួយគត់ទៅជាគែមស្លឹកមួយគូដែលកំណត់ព្រំដែនដើមឈើទាំងមូល។
    /// លទ្ធផលមិនមែនជាឯកសារយោងប្លែកៗដែលអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរការបំផ្លាញយ៉ាងខ្លាំងដូច្នេះត្រូវតែប្រើដោយយកចិត្តទុកដាក់បំផុត។
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // យើងស្ទួនឫស NodeRef នៅទីនេះ-យើងនឹងមិនចូលប្រើវាតាមរបៀបដែលត្រួតលើសេចក្តីយោងដែលទទួលបានពីឫសទេ។
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// ដែលបានផ្តល់ឱ្យនូវចំណុចទាញស្លឹក edge ត្រឡប់ [`Result::Ok`] ជាមួយនឹងចំណុចទាញទៅ KV ដែលនៅជិតខាងនៅខាងស្តាំដែលមានទាំងនៅក្នុងថ្នាំងស្លឹកតែមួយឬនៅក្នុងថ្នាំងដូនតា។
    ///
    /// ប្រសិនបើស្លឹក edge គឺជាស្លឹកចុងក្រោយនៅក្នុងមែកឈើសូមត្រឡប់ [`Result::Err`] ដោយថ្នាំងឫស។
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// ដែលបានផ្តល់ឱ្យចំណុចទាញស្លឹក edge, ត្រឡប់ [`Result::Ok`] ជាមួយនឹងចំណុចទាញទៅ KV ដែលនៅជិតគ្នានៅខាងឆ្វេងដែលស្ថិតនៅក្នុងថ្នាំងស្លឹកតែមួយឬនៅក្នុងថ្នាំងដូនតា។
    ///
    /// ប្រសិនបើស្លឹក edge គឺជាស្លឹកទីមួយនៅក្នុងមែកធាងសូមត្រឡប់ [`Result::Err`] ដោយថ្នាំងឫស។
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ដែលបានផ្តល់នូវចំណុចទាញ edge ខាងក្នុងត្រឡប់ [`Result::Ok`] ជាមួយនឹងចំណុចទាញទៅ KV ដែលនៅជិតខាងនៅខាងស្តាំដែលមានទាំងនៅក្នុងថ្នាំងខាងក្នុងដូចគ្នាឬនៅក្នុងថ្នាំងដូនតា។
    ///
    /// ប្រសិនបើផ្ទៃក្នុង edge គឺជាចុងក្រោយនៅក្នុងមែកធាងសូមត្រឡប់ [`Result::Err`] ជាមួយថ្នាំងឫស។
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ដែលបានផ្តល់ឱ្យស្លឹក edge ដោះស្រាយចូលទៅក្នុងមែកធាងដែលងាប់ត្រឡប់មកវិញនូវស្លឹកបន្ទាប់ edge នៅផ្នែកខាងស្តាំនិងគូតម្លៃគ្រាប់ចុចដែលស្ថិតនៅចន្លោះថ្នាំងតែមួយនៅក្នុងថ្នាំងដូនតាឬមិនមាន។
    ///
    ///
    /// វិធីសាស្រ្តនេះក៏ចែក node(s) ណាមួយដែលវាឈានដល់ទីបញ្ចប់ដែរ។
    /// នេះបញ្ជាក់ថាប្រសិនបើមិនមានគូដែលមានតម្លៃសំខាន់ទៀតទេដើមឈើដែលនៅសល់នឹងត្រូវបានដោះស្រាយហើយមិនមានអ្វីត្រូវត្រលប់មកវិញទេ។
    ///
    /// # Safety
    /// edge ដែលបានផ្តល់ឱ្យមិនត្រូវបានត្រឡប់មកវិញដោយសមភាគី `deallocating_next_back` ពីមុនទេ។
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ដែលបានផ្តល់ឱ្យស្លឹក edge ដោះស្រាយចូលទៅក្នុងមែកធាងដែលងាប់ត្រឡប់មកវិញនូវស្លឹកបន្ទាប់ edge នៅផ្នែកខាងឆ្វេងនិងគូតម្លៃគ្រាប់ចុចដែលស្ថិតនៅចន្លោះថ្នាំងតែមួយនៅក្នុងថ្នាំងដូនតាឬមិនមាន។
    ///
    ///
    /// វិធីសាស្រ្តនេះក៏ចែក node(s) ណាមួយដែលវាឈានដល់ទីបញ្ចប់ដែរ។
    /// នេះបញ្ជាក់ថាប្រសិនបើមិនមានគូដែលមានតម្លៃសំខាន់ទៀតទេដើមឈើដែលនៅសល់នឹងត្រូវបានដោះស្រាយហើយមិនមានអ្វីត្រូវត្រលប់មកវិញទេ។
    ///
    /// # Safety
    /// edge ដែលបានផ្តល់ឱ្យមិនត្រូវបានត្រឡប់មកវិញដោយសមភាគី `deallocating_next` ពីមុនទេ។
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// បែងចែកគំនរថ្នាំងពីស្លឹករហូតដល់ឫស។
    /// នេះគឺជាមធ្យោបាយតែមួយគត់ដើម្បីដោះស្រាយដើមឈើដែលនៅសល់បន្ទាប់ពី `deallocating_next` និង `deallocating_next_back` ត្រូវបានទុកចោលទាំងសងខាងនៃដើមឈើហើយបានបុកជាមួយ edge ដូចគ្នា។
    /// ដូចដែលវាត្រូវបានគេហៅថាត្រូវបានហៅនៅពេលដែលគ្រាប់ចុចនិងតម្លៃទាំងអស់ត្រូវបានត្រឡប់មកវិញគ្មានការសម្អាតណាមួយត្រូវបានធ្វើឡើងលើគ្រាប់ចុចឬតម្លៃណាមួយឡើយ។
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ផ្លាស់ទីស្លឹកដោះស្រាយ edge ទៅស្លឹកបន្ទាប់ edge ហើយត្រឡប់ឯកសារយោងទៅគន្លឹះនិងតម្លៃនៅចន្លោះ។
    ///
    ///
    /// # Safety
    /// ត្រូវតែមានគីវីមួយទៀតនៅក្នុងទិសដៅដែលបានធ្វើដំណើរ។
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// ផ្លាស់ទីស្លឹកដោះស្រាយ edge ទៅស្លឹកមុន edge ហើយត្រឡប់ឯកសារយោងទៅនឹងគន្លឹះនិងតម្លៃនៅចន្លោះ។
    ///
    ///
    /// # Safety
    /// ត្រូវតែមានគីវីមួយទៀតនៅក្នុងទិសដៅដែលបានធ្វើដំណើរ។
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ផ្លាស់ទីស្លឹកដោះស្រាយ edge ទៅស្លឹកបន្ទាប់ edge ហើយត្រឡប់ឯកសារយោងទៅគន្លឹះនិងតម្លៃនៅចន្លោះ។
    ///
    ///
    /// # Safety
    /// ត្រូវតែមានគីវីមួយទៀតនៅក្នុងទិសដៅដែលបានធ្វើដំណើរ។
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // ធ្វើចុងក្រោយនេះលឿនជាងនេះបើយោងតាមគោល។
        kv.into_kv_valmut()
    }

    /// ផ្លាស់ទីស្លឹកដោះស្រាយ edge ទៅស្លឹកមុនហើយត្រឡប់ឯកសារយោងទៅកូនសោនិងតម្លៃនៅចន្លោះ។
    ///
    ///
    /// # Safety
    /// ត្រូវតែមានគីវីមួយទៀតនៅក្នុងទិសដៅដែលបានធ្វើដំណើរ។
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // ធ្វើចុងក្រោយនេះលឿនជាងនេះបើយោងតាមគោល។
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// រំកិលស្លឹកចេក edge ទៅស្លឹកបន្ទាប់ edge ហើយត្រឡប់គ្រាប់ចុចនិងតម្លៃនៅចន្លោះនោះចែកថ្នាំងណាដែលនៅសេសសល់ខណៈពេលដែលទុក edge ដែលត្រូវគ្នាទៅនឹងថ្នាំងមេរបស់វា។
    ///
    /// # Safety
    /// - ត្រូវតែមានគីវីមួយទៀតនៅក្នុងទិសដៅដែលបានធ្វើដំណើរ។
    /// - ខ្សែកាបនោះមិនត្រូវបានប្រគល់ឱ្យដោយសមភាគី `next_back_unchecked` ទេនៅលើច្បាប់ចម្លងនៃចំណុចទាញណាមួយដែលត្រូវបានប្រើដើម្បីឆ្លងកាត់ដើមឈើ។
    ///
    /// មធ្យោបាយមានសុវត្ថិភាពតែមួយគត់ដើម្បីដំណើរការជាមួយចំណុចទាញដែលបានធ្វើបច្ចុប្បន្នភាពគឺប្រៀបធៀបវាទម្លាក់វាហៅវិធីនេះម្តងទៀតចំពោះលក្ខខណ្ឌសុវត្ថិភាពរបស់វាឬហៅទូរស័ព្ទទៅសមភាគី `next_back_unchecked` ទៅនឹងលក្ខខណ្ឌសុវត្ថិភាពរបស់វា។
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// ផ្លាស់ប្តូរចំណុចទាញ edge ទៅនឹងស្លឹកមុន edge ហើយត្រឡប់គន្លឺះនិងតម្លៃនៅចន្លោះនោះចែកថ្នាំងណាដែលនៅសេសសល់ខណៈពេលដែលទុក edge ដែលត្រូវគ្នានៅក្នុងថ្នាំងមេរបស់វា។
    ///
    /// # Safety
    /// - ត្រូវតែមានគីវីមួយទៀតនៅក្នុងទិសដៅដែលបានធ្វើដំណើរ។
    /// - ស្លឹកនោះ edge មិនត្រូវបានប្រគល់ឱ្យដោយសមភាគី `next_unchecked` ទេនៅលើច្បាប់ចម្លងនៃចំណុចទាញណាមួយដែលត្រូវបានប្រើដើម្បីឆ្លងកាត់ដើមឈើ។
    ///
    /// មធ្យោបាយមានសុវត្ថិភាពតែមួយគត់ដើម្បីដំណើរការជាមួយចំណុចទាញដែលបានធ្វើបច្ចុប្បន្នភាពគឺប្រៀបធៀបវាទម្លាក់វាហៅវិធីនេះម្តងទៀតចំពោះលក្ខខណ្ឌសុវត្ថិភាពរបស់វាឬហៅទូរស័ព្ទទៅសមភាគី `next_unchecked` ទៅនឹងលក្ខខណ្ឌសុវត្ថិភាពរបស់វា។
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ត្រឡប់ស្លឹកខាងឆ្វេងបំផុត edge នៅក្នុងឬនៅក្រោមថ្នាំងនិយាយម្យ៉ាងទៀតថា edge ដែលអ្នកត្រូវការដំបូងនៅពេលធ្វើដំណើរទៅមុខ (ឬចុងក្រោយនៅពេលធ្វើដំណើរទៅមុខ) ។
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// ត្រឡប់ស្លឹកខាងស្តាំ edge នៅក្នុងឬនៅក្រោមថ្នាំងនិយាយម្យ៉ាងទៀត edge ដែលអ្នកត្រូវការចុងក្រោយនៅពេលធ្វើដំណើរទៅមុខ (ឬដំបូងនៅពេលធ្វើដំណើរទៅមុខ) ។
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ទស្សនាថ្នាំងស្លឹកនិងគីវីអេហ្វអេសខាងក្នុងតាមលំដាប់នៃគ្រាប់ចុចឡើងលើហើយក៏ចូលមើលថ្នាំងខាងក្នុងទាំងមូលតាមលំដាប់ទី ១ ដែលមានន័យថាថ្នាំងខាងក្នុងមានអាទិភាព KVs និងកូនរបស់ពួកគេ។
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// គណនាចំនួនធាតុនៅក្នុងមែកធាង (រង) ។
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ត្រឡប់ស្លឹក edge ដែលជិតបំផុតទៅនឹងគីវីសំរាប់ការបញ្ជូនបន្តទៅមុខ។
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// ត្រឡប់ស្លឹក edge ជិតបំផុតទៅនឹងគីវីសម្រាប់ការធ្វើនាវាចរថយក្រោយ។
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}