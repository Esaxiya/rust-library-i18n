//! បញ្ជីដែលជាប់ទាក់ទងទ្វេដងជាមួយថ្នាំងដែលជាកម្មសិទ្ធិ។
//!
//! `LinkedList` អនុញ្ញាតឱ្យមានការរុញច្រាននិងរឹបអូសធាតុនៅចុងបញ្ចប់ទាំងពេលវេលាថេរ។
//!
//! NOTE: វាតែងតែល្អប្រសើរក្នុងការប្រើ [`Vec`] ឬ [`VecDeque`] ពីព្រោះជាទូទៅកុងតឺន័រដែលមានមូលដ្ឋានលើអារេជាទូទៅលឿនជាងមុនការចងចាំកាន់តែមានប្រសិទ្ធិភាពនិងធ្វើអោយការប្រើប្រាស់ស៊ីភីយូកាន់តែប្រសើរ។
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// បញ្ជីដែលជាប់ទាក់ទងទ្វេដងជាមួយថ្នាំងដែលជាកម្មសិទ្ធិ។
///
/// `LinkedList` អនុញ្ញាតឱ្យមានការរុញច្រាននិងរឹបអូសធាតុនៅចុងបញ្ចប់ទាំងពេលវេលាថេរ។
///
/// NOTE: វាតែងតែល្អប្រសើរក្នុងការប្រើ `Vec` ឬ `VecDeque` ពីព្រោះជាទូទៅកុងតឺន័រដែលមានមូលដ្ឋានលើអារេជាទូទៅលឿនជាងមុនការចងចាំកាន់តែមានប្រសិទ្ធិភាពនិងធ្វើឱ្យការប្រើប្រាស់ស៊ីភីយូកាន់តែប្រសើរ។
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// ឧបករណ៍រំកិលលើធាតុនៃ `LinkedList` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយ [`LinkedList::iter()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) យកចេញនៅក្នុងការពេញចិត្តនៃ `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// ឧបករណ៍រំកិលដែលអាចផ្លាស់ប្តូរបានលើធាតុនៃ `LinkedList` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយ [`LinkedList::iter_mut()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // យើងមិន * មិនមែនជាម្ចាស់បញ្ជីទាំងមូលនៅទីនេះទេឯកសារយោងទៅ `element` របស់ថ្នាំងត្រូវបានប្រគល់ឱ្យដោយអ្នកតាក់តែង!ដូច្នេះសូមប្រយ័ត្ននៅពេលប្រើវា។វិធីសាស្រ្តដែលគេហៅថាត្រូវតែដឹងថាវាអាចមានសូចនាករក្លែងក្លាយដល់ `element` ។
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// ម្ចាស់ទ្រនាប់ដែលមានម្ចាស់លើធាតុនៃ `LinkedList` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`into_iter`] នៅលើ [`LinkedList`] (ផ្តល់ដោយ `IntoIterator` trait) ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// វិធីសាស្ត្រឯកជន
impl<T> LinkedList<T> {
    /// បន្ថែមថ្នាំងដែលបានផ្តល់ទៅផ្នែកខាងមុខនៃបញ្ជី។
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // វិធីសាស្រ្តនេះយកចិត្តទុកដាក់មិនបង្កើតឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅថ្នាំងទាំងមូលដើម្បីរក្សាសុពលភាពនៃចង្អុលបង្ហាញឈ្មោះក្លែងក្លាយទៅជា `element` ។
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // មិនបង្កើតឯកសារយោង (unique!) ដែលអាចផ្លាស់ប្តូរថ្មីត្រួតលើ `element` ។
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// ដោះចេញនិងប្រគល់ថ្នាំងនៅផ្នែកខាងមុខនៃបញ្ជី។
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // វិធីសាស្រ្តនេះយកចិត្តទុកដាក់មិនបង្កើតឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅថ្នាំងទាំងមូលដើម្បីរក្សាសុពលភាពនៃចង្អុលបង្ហាញឈ្មោះក្លែងក្លាយទៅជា `element` ។
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // មិនបង្កើតឯកសារយោង (unique!) ដែលអាចផ្លាស់ប្តូរថ្មីត្រួតលើ `element` ។
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// បន្ថែមថ្នាំងដែលបានផ្តល់ទៅខាងក្រោយបញ្ជី។
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // វិធីសាស្រ្តនេះយកចិត្តទុកដាក់មិនបង្កើតឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅថ្នាំងទាំងមូលដើម្បីរក្សាសុពលភាពនៃចង្អុលបង្ហាញឈ្មោះក្លែងក្លាយទៅជា `element` ។
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // មិនបង្កើតឯកសារយោង (unique!) ដែលអាចផ្លាស់ប្តូរថ្មីត្រួតលើ `element` ។
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// ដកនិងត្រឡប់ថ្នាំងនៅខាងក្រោយបញ្ជី។
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // វិធីសាស្រ្តនេះយកចិត្តទុកដាក់មិនបង្កើតឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅថ្នាំងទាំងមូលដើម្បីរក្សាសុពលភាពនៃចង្អុលបង្ហាញឈ្មោះក្លែងក្លាយទៅជា `element` ។
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // មិនបង្កើតឯកសារយោង (unique!) ដែលអាចផ្លាស់ប្តូរថ្មីត្រួតលើ `element` ។
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// ផ្តាច់ថ្នាំងដែលបានបញ្ជាក់ពីបញ្ជីបច្ចុប្បន្ន។
    ///
    /// ការព្រមាន: នេះនឹងមិនពិនិត្យមើលថាថ្នាំងដែលបានផ្តល់ជាកម្មសិទ្ធិរបស់បញ្ជីបច្ចុប្បន្នទេ។
    ///
    /// វិធីសាស្រ្តនេះយកចិត្តទុកដាក់មិនឱ្យបង្កើតឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅ `element` ដើម្បីរក្សាសុពលភាពនៃចង្អុលបង្ហាញឈ្មោះក្លែងក្លាយ។
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // មួយនេះគឺជារបស់យើងឥឡូវនេះយើងអាចបង្កើត &mut ។

        // មិនបង្កើតឯកសារយោង (unique!) ដែលអាចផ្លាស់ប្តូរថ្មីត្រួតលើ `element` ។
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // ថ្នាំងនេះគឺជាថ្នាំងក្បាល
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // ថ្នាំងនេះគឺជាថ្នាំងកន្ទុយ
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// បំបែកស៊េរីនៃថ្នាំងរវាងថ្នាំងដែលមានស្រាប់ពីរ។
    ///
    /// ការព្រមាន: នេះនឹងមិនពិនិត្យមើលថាថ្នាំងដែលបានផ្តល់ជាកម្មសិទ្ធិរបស់បញ្ជីដែលមានស្រាប់ពីរទេ។
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // វិធីសាស្រ្តនេះយកចិត្តទុកដាក់មិនឱ្យបង្កើតឯកសារយោងដែលអាចផ្លាស់ប្តូរបានច្រើនទៅថ្នាំងទាំងមូលក្នុងពេលតែមួយដើម្បីរក្សាសុពលភាពនៃចង្អុលបង្ហាញឈ្មោះក្លែងក្លាយទៅជា `element` ។
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// ផ្ដាច់ថ្នាំងទាំងអស់ពីបញ្ជីដែលភ្ជាប់ជាស៊េរីនៃថ្នាំង។
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // ថ្នាំងបំបែកគឺជាថ្នាំងក្បាលថ្មីនៃផ្នែកទីពីរ
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // ជួសជុលក្បាល ptr នៃផ្នែកទីពីរ
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // ថ្នាំងបំបែកគឺជាថ្នាំងកន្ទុយថ្មីនៃផ្នែកទីមួយនិងជាម្ចាស់ក្បាលផ្នែកទីពីរ។
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // ជួសជុលកន្ទុយកន្ទុយនៃផ្នែកដំបូង
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// បង្កើត `LinkedList<T>` ទទេ។
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// បង្កើត `LinkedList` ទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// ផ្លាស់ទីធាតុទាំងអស់ពី `other` ទៅចុងបញ្ចប់នៃបញ្ជី។
    ///
    /// នេះប្រើថ្នាំងទាំងអស់ពី `other` ហើយផ្លាស់ទីពួកវាទៅជា `self` ។
    /// បន្ទាប់ពីប្រតិបត្តិការនេះ `other` ក្លាយជាទទេ។
    ///
    /// ប្រតិបត្ដិការនេះគួរតែគណនានៅក្នុងពេលវេលា *O*(1) និងអង្គចងចាំ *O*(1) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` មិនអីទេនៅទីនេះពីព្រោះយើងមានសិទ្ធិចូលដំណើរការបញ្ជីឈ្មោះទាំងពីរទាំងមូល។
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// ផ្លាស់ទីធាតុទាំងអស់ពី `other` ទៅការចាប់ផ្តើមនៃបញ្ជី។
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` មិនអីទេនៅទីនេះពីព្រោះយើងមានសិទ្ធិចូលដំណើរការបញ្ជីឈ្មោះទាំងពីរទាំងមូល។
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// ផ្តល់នូវការរំកិលទៅមុខ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// ផ្តល់នូវការបញ្ជូនបន្តជាមួយសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// ផ្តល់ទស្សន៍ទ្រនិចនៅធាតុខាងមុខ។
    ///
    /// ទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បើបញ្ជីទទេ។
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// ផ្តល់ទស្សន៍ទ្រនិចជាមួយនឹងប្រតិបត្តិការកែសម្រួលនៅធាតុខាងមុខ។
    ///
    /// ទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បើបញ្ជីទទេ។
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// ផ្តល់ទស្សន៍ទ្រនិចនៅធាតុខាងក្រោយ។
    ///
    /// ទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បើបញ្ជីទទេ។
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// ផ្តល់ទស្សន៍ទ្រនិចជាមួយនឹងប្រតិបត្តិការកែសម្រួលនៅធាតុខាងក្រោយ។
    ///
    /// ទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បើបញ្ជីទទេ។
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `LinkedList` ទទេ។
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(1) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// ត្រឡប់ប្រវែង `LinkedList` ។
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(1) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// យកធាតុទាំងអស់ចេញពី `LinkedList` ។
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(*n*) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `LinkedList` មានធាតុស្មើនឹងតម្លៃដែលបានផ្តល់។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// ផ្តល់សេចក្តីយោងទៅធាតុខាងមុខឬ `None` ប្រសិនបើបញ្ជីទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// ផ្តល់នូវសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅធាតុខាងមុខឬ `None` ប្រសិនបើបញ្ជីទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// ផ្តល់នូវឯកសារយោងទៅធាតុខាងក្រោយរឺ `None` ប្រសិនបើបញ្ជីទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// ផ្តល់នូវសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅធាតុខាងក្រោយឬ `None` ប្រសិនបើបញ្ជីទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// បន្ថែមធាតុដំបូងក្នុងបញ្ជី។
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(1) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// យកធាតុដំបូងចេញហើយប្រគល់វាមកវិញឬ `None` ប្រសិនបើបញ្ជីនោះទទេ។
    ///
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(1) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// ដាក់ធាតុនៅខាងក្រោយនៃបញ្ជី។
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(1) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// យកធាតុចុងក្រោយចេញពីបញ្ជីហើយប្រគល់វាមកវិញឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(1) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// បំបែកបញ្ជីជាពីរនៅសន្ទស្សន៍ដែលបានផ្តល់ឱ្យ។
    /// ត្រឡប់អ្វីគ្រប់យ៉ាងបន្ទាប់ពីសន្ទស្សន៍ដែលបានផ្តល់រួមទាំងសន្ទស្សន៍។
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(*n*) ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `at > len` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // ខាងក្រោមនេះយើងឆ្ពោះទៅរកថ្នាំង `i-1` ទាំងពីពេលចាប់ផ្តើមឬនៅចុងបញ្ចប់អាស្រ័យលើអ្វីដែលលឿនជាង។
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // ជំនួសឱ្យការរំលងដោយប្រើ .skip() (ដែលបង្កើតរចនាសម្ព័ន្ធថ្មី) យើងរំលងដោយដៃដូច្នេះយើងអាចចូលមើលផ្នែកក្បាលដោយមិនផ្អែកលើព័ត៌មានលម្អិតនៃការអនុវត្តរបស់រំលង។
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // ចាប់ផ្តើមល្អពីការបញ្ចប់
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// យកធាតុចេញនៅលិបិក្រមដែលបានផ្តល់ហើយប្រគល់វាមកវិញ។
    ///
    /// ប្រតិបត្តិការនេះគួរតែគណនាក្នុងរយៈពេល *O*(*n*) ។
    ///
    /// # Panics
    /// Panics ប្រសិនបើនៅ>=len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // ខាងក្រោមនេះយើងតម្រង់ឆ្ពោះទៅថ្នាំងនៅលិបិក្រមដែលបានផ្តល់ឱ្យទាំងពីពេលចាប់ផ្តើមឬចុងបញ្ចប់អាស្រ័យលើអ្វីដែលលឿនជាង។
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// បង្កើតឧបករណ៍វាស់ស្ទង់ដែលប្រើការបិទដើម្បីកំណត់ថាតើធាតុមួយគួរតែត្រូវបានដកចេញ។
    ///
    /// ប្រសិនបើមានការបិទត្រឡប់ពិតនោះធាតុត្រូវបានយកចេញនិងជំរុញអោយមាន។
    /// ប្រសិនបើការបិទត្រឡប់មកវិញមិនពិតធាតុនឹងស្ថិតនៅក្នុងបញ្ជីហើយនឹងមិនត្រូវបានផ្តល់ឱ្យដោយអ្នកតាក់តែងទេ។
    ///
    /// ចំណាំថា `drain_filter` អនុញ្ញាតឱ្យអ្នកផ្លាស់ប្តូរធាតុទាំងអស់នៅក្នុងការបិទតម្រងដោយមិនគិតពីថាតើអ្នកជ្រើសរើសរក្សាទុកឬយកវាចេញទេ។
    ///
    ///
    /// # Examples
    ///
    /// បំបែកបញ្ជីទៅជាអែវនិងសេសដោយប្រើបញ្ជីដើមវិញ៖
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // ជៀសវាងបញ្ហាខ្ចីប្រាក់
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // បន្តរង្វិលជុំដូចគ្នាដែលយើងធ្វើនៅខាងក្រោម។វាដំណើរការតែនៅពេលដែលអ្នកបំផ្លាញម្នាក់ភ័យស្លន់ស្លោ។
                // ប្រសិនបើមួយផ្សេងទៀត panics នេះនឹងបោះបង់ចោល។
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // ត្រូវការជីវិតគ្មានព្រំដែនដើម្បីទទួលបាន 'ក
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // ត្រូវការជីវិតគ្មានព្រំដែនដើម្បីទទួលបាន 'ក
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // ត្រូវការជីវិតគ្មានព្រំដែនដើម្បីទទួលបាន 'ក
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // ត្រូវការជីវិតគ្មានព្រំដែនដើម្បីទទួលបាន 'ក
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// ទស្សន៍ទ្រនិចលើ `LinkedList` ។
///
/// `Cursor` គឺដូចជាអ្នកធ្វើវារលើកលែងតែវាអាចស្វែងរកត្រឡប់មកវិញនិងចេញទៅដោយសេរី។
///
/// ទស្សន៍ទ្រនិចតែងតែស្ថិតនៅចន្លោះធាតុពីរក្នុងបញ្ជីនិងលិបិក្រមតាមរបៀបឡូជីខល។
/// ដើម្បីផ្ទុកវាមានធាតុមិនមែន "ghost" ដែលផ្តល់ទិន្នផល `None` រវាងក្បាលនិងកន្ទុយនៃបញ្ជី។
///
///
/// នៅពេលបង្កើតទស្សន៍ទ្រនិចចាប់ផ្តើមនៅផ្នែកខាងមុខនៃបញ្ជីរឺធាតុមិនមែន "ghost" ប្រសិនបើបញ្ជីនោះទទេ។
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// ទស្សន៍ទ្រនិចលើ `LinkedList` ជាមួយនឹងប្រតិបត្តិការកែសម្រួល។
///
/// `Cursor` គឺដូចជាអ្នកធ្វើវារលើកលែងតែវាអាចស្វែងរកត្រឡប់មកវិញនិងចេញទៅដោយសេរីហើយអាចផ្លាស់ប្តូរបញ្ជីដោយសុវត្ថិភាពក្នុងកំឡុងពេលបង្កើតឡើងវិញ។
/// នេះគឺដោយសារតែអាយុកាលនៃឯកសារយោងដែលទទួលបានត្រូវបានភ្ជាប់ទៅនឹងអាយុកាលផ្ទាល់ខ្លួនជំនួសឱ្យតែបញ្ជីមូលដ្ឋានប៉ុណ្ណោះ។
/// នេះមានន័យថាទស្សន៍ទ្រនិចមិនអាចផ្តល់លទ្ធផលច្រើនក្នុងពេលតែមួយបានទេ
///
/// ទស្សន៍ទ្រនិចតែងតែស្ថិតនៅចន្លោះធាតុពីរក្នុងបញ្ជីនិងលិបិក្រមតាមរបៀបឡូជីខល។
/// ដើម្បីផ្ទុកវាមានធាតុមិនមែន "ghost" ដែលផ្តល់ទិន្នផល `None` រវាងក្បាលនិងកន្ទុយនៃបញ្ជី។
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// ត្រឡប់សន្ទស្សន៍ទីតាំងទស្សន៍ទ្រនិចក្នុង `LinkedList` ។
    ///
    /// នេះត្រឡប់ `None` ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលទៅធាតុមិនមែន "ghost" ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// ផ្លាស់ទីទស្សន៍ទ្រនិចទៅធាតុបន្ទាប់នៃ `LinkedList` ។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" នោះវានឹងផ្លាស់ទីវាទៅធាតុដំបូងនៃ `LinkedList` ។
    /// ប្រសិនបើវាចង្អុលទៅធាតុចុងក្រោយនៃ `LinkedList` បន្ទាប់មកនេះនឹងផ្លាស់ទីវាទៅធាតុមិនមែន "ghost" ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // យើងគ្មានធាតុបច្ចុប្បន្នទេ។ទស្សន៍ទ្រនិចត្រូវបានគេអង្គុយនៅទីតាំងចាប់ផ្តើមធាតុបន្ទាប់គួរតែជាក្បាលនៃបញ្ជី
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // យើងមានធាតុពីមុនដូច្នេះតោះទៅធាតុបន្ទាប់
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// ផ្លាស់ទីទស្សន៍ទ្រនិចទៅធាតុមុននៃ `LinkedList` ។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" នោះវានឹងផ្លាស់ទីវាទៅធាតុចុងក្រោយនៃ `LinkedList` ។
    /// ប្រសិនបើវាត្រូវបានចង្អុលទៅធាតុដំបូងនៃ `LinkedList` បន្ទាប់មកនេះនឹងផ្លាស់ទីវាទៅធាតុមិនមែន "ghost" ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // គ្មានចរន្ត។យើងកំពុងចាប់ផ្តើមបញ្ជី។ផ្តល់ទិន្នផលគ្មានហើយលោតដល់ទីបញ្ចប់។
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // មាន prev មួយ។ដាក់វាហើយចូលទៅធាតុមុន។
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុដែលទស្សន៍ទ្រនិចកំពុងចង្អុលទៅ។
    ///
    /// នេះត្រឡប់ `None` ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលទៅធាតុមិនមែន "ghost" ។
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុបន្ទាប់។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បន្ទាប់មកធាតុនេះត្រឡប់ធាតុដំបូងនៃ `LinkedList` ។
    /// ប្រសិនបើវាកំពុងចង្អុលទៅធាតុចុងក្រោយនៃ `LinkedList` បន្ទាប់មកវាត្រលប់មកវិញ `None` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុមុន។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បន្ទាប់មកធាតុនេះត្រឡប់ធាតុចុងក្រោយនៃ `LinkedList` ។
    /// ប្រសិនបើវាកំពុងចង្អុលទៅធាតុដំបូងនៃ `LinkedList` បន្ទាប់មកវាត្រលប់មកវិញ `None` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// ត្រឡប់សន្ទស្សន៍ទីតាំងទស្សន៍ទ្រនិចក្នុង `LinkedList` ។
    ///
    /// នេះត្រឡប់ `None` ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលទៅធាតុមិនមែន "ghost" ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// ផ្លាស់ទីទស្សន៍ទ្រនិចទៅធាតុបន្ទាប់នៃ `LinkedList` ។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" នោះវានឹងផ្លាស់ទីវាទៅធាតុដំបូងនៃ `LinkedList` ។
    /// ប្រសិនបើវាចង្អុលទៅធាតុចុងក្រោយនៃ `LinkedList` បន្ទាប់មកនេះនឹងផ្លាស់ទីវាទៅធាតុមិនមែន "ghost" ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // យើងគ្មានធាតុបច្ចុប្បន្នទេ។ទស្សន៍ទ្រនិចត្រូវបានគេអង្គុយនៅទីតាំងចាប់ផ្តើមធាតុបន្ទាប់គួរតែជាក្បាលនៃបញ្ជី
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // យើងមានធាតុពីមុនដូច្នេះតោះទៅធាតុបន្ទាប់
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// ផ្លាស់ទីទស្សន៍ទ្រនិចទៅធាតុមុននៃ `LinkedList` ។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" នោះវានឹងផ្លាស់ទីវាទៅធាតុចុងក្រោយនៃ `LinkedList` ។
    /// ប្រសិនបើវាត្រូវបានចង្អុលទៅធាតុដំបូងនៃ `LinkedList` បន្ទាប់មកនេះនឹងផ្លាស់ទីវាទៅធាតុមិនមែន "ghost" ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // គ្មានចរន្ត។យើងកំពុងចាប់ផ្តើមបញ្ជី។ផ្តល់ទិន្នផលគ្មានហើយលោតដល់ទីបញ្ចប់។
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // មាន prev មួយ។ដាក់វាហើយចូលទៅធាតុមុន។
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុដែលទស្សន៍ទ្រនិចកំពុងចង្អុលទៅ។
    ///
    /// នេះត្រឡប់ `None` ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលទៅធាតុមិនមែន "ghost" ។
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុបន្ទាប់។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បន្ទាប់មកធាតុនេះត្រឡប់ធាតុដំបូងនៃ `LinkedList` ។
    /// ប្រសិនបើវាកំពុងចង្អុលទៅធាតុចុងក្រោយនៃ `LinkedList` បន្ទាប់មកវាត្រលប់មកវិញ `None` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុមុន។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចចង្អុលទៅធាតុមិនមែន "ghost" បន្ទាប់មកធាតុនេះត្រឡប់ធាតុចុងក្រោយនៃ `LinkedList` ។
    /// ប្រសិនបើវាកំពុងចង្អុលទៅធាតុដំបូងនៃ `LinkedList` បន្ទាប់មកវាត្រលប់មកវិញ `None` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// ត្រឡប់ទស្សន៍ទ្រនិចបានតែអានចង្អុលទៅធាតុបច្ចុប្បន្ន។
    ///
    /// អាយុកាលរបស់ `Cursor` ដែលបានត្រឡប់មកវិញត្រូវបានភ្ជាប់ទៅនឹង `CursorMut` ដែលមានន័យថាវាមិនអាចធ្វើឱ្យ `CursorMut` ហួសប្រមាណហើយថា `CursorMut` ត្រូវបានកកសម្រាប់អាយុកាលរបស់ `Cursor` ។
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// ឥឡូវនេះប្រតិបត្តិការកែសម្រួលបញ្ជី

impl<'a, T> CursorMut<'a, T> {
    /// បញ្ចូលធាតុថ្មីទៅក្នុង `LinkedList` បន្ទាប់ពីធាតុបច្ចុប្បន្ន។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលនៅចំណុចមិនមែន "ghost" បន្ទាប់មកធាតុថ្មីត្រូវបានបញ្ចូលនៅផ្នែកខាងមុខនៃ `LinkedList` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // សន្ទស្សន៍មិនមែនធាតុ "ghost" បានផ្លាស់ប្តូរ។
                self.index = self.list.len;
            }
        }
    }

    /// បញ្ចូលធាតុថ្មីទៅក្នុង `LinkedList` មុនធាតុបច្ចុប្បន្ន។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលនៅធាតុមិនមែន "ghost" បន្ទាប់មកធាតុថ្មីត្រូវបានបញ្ចូលនៅចុងបញ្ចប់នៃ `LinkedList` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// យកធាតុបច្ចុប្បន្នចេញពី `LinkedList` ។
    ///
    /// ធាតុដែលត្រូវបានយកចេញត្រូវបានត្រលប់មកវិញហើយទស្សន៍ទ្រនិចត្រូវបានផ្លាស់ទីទៅចង្អុលទៅធាតុបន្ទាប់នៅក្នុង `LinkedList` ។
    ///
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលទៅធាតុមិនមែន "ghost" បន្ទាប់មកគ្មានធាតុត្រូវបានដកចេញទេហើយ `None` ត្រូវបានត្រឡប់មកវិញ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// យកធាតុបច្ចុប្បន្នចេញពី `LinkedList` ដោយមិនផ្លាស់ប្តូរថ្នាំងបញ្ជី។
    ///
    /// ថ្នាំងដែលត្រូវបានដកចេញត្រូវបានត្រឡប់ជា `LinkedList` ថ្មីដែលផ្ទុកតែថ្នាំងនេះ។
    /// ទស្សន៍ទ្រនិចត្រូវបានផ្លាស់ទីទៅចង្អុលទៅធាតុបន្ទាប់នៅក្នុង `LinkedList` បច្ចុប្បន្ន។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលទៅធាតុមិនមែន "ghost" បន្ទាប់មកគ្មានធាតុត្រូវបានដកចេញទេហើយ `None` ត្រូវបានត្រឡប់មកវិញ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// បញ្ចូលធាតុពី `LinkedList` ដែលបានផ្តល់បន្ទាប់ពីធាតុបច្ចុប្បន្ន។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលនៅធាតុមិនមែន "ghost" បន្ទាប់មកធាតុថ្មីត្រូវបានបញ្ចូលនៅដើម `LinkedList` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // សន្ទស្សន៍មិនមែនធាតុ "ghost" បានផ្លាស់ប្តូរ។
                self.index = self.list.len;
            }
        }
    }

    /// បញ្ចូលធាតុពី `LinkedList` ដែលបានផ្តល់មុនធាតុបច្ចុប្បន្ន។
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលនៅចំណុចមិនមែន "ghost" បន្ទាប់មកធាតុថ្មីត្រូវបានបញ្ចូលនៅចុងបញ្ចប់នៃ `LinkedList` ។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// បំបែកបញ្ជីជាពីរបន្ទាប់ពីធាតុបច្ចុប្បន្ន។
    /// នេះនឹងត្រលប់មកវិញនូវបញ្ជីថ្មីដែលមានអ្វីៗគ្រប់យ៉ាងបន្ទាប់ពីទស្សន៍ទ្រនិចដែលមានបញ្ជីដើមរក្សាទុកអ្វីគ្រប់យ៉ាងមុន។
    ///
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលនៅធាតុមិនមែន "ghost" បន្ទាប់មកមាតិកាទាំងមូលនៃ `LinkedList` ត្រូវបានផ្លាស់ទី។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // សន្ទស្សន៍មិនមែនធាតុ "ghost" បានប្តូរទៅ ០ ។
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// បំបែកបញ្ជីជាពីរមុនពេលធាតុបច្ចុប្បន្ន។
    /// នេះនឹងត្រលប់មកវិញនូវបញ្ជីថ្មីដែលមានផ្ទុកអ្វីៗគ្រប់យ៉ាងមុនពេលដាក់ទស្សន៍ទ្រនិចដោយមានបញ្ជីដើមរក្សាទុកអ្វីទាំងអស់។
    ///
    ///
    /// ប្រសិនបើទស្សន៍ទ្រនិចកំពុងចង្អុលនៅធាតុមិនមែន "ghost" បន្ទាប់មកមាតិកាទាំងមូលនៃ `LinkedList` ត្រូវបានផ្លាស់ទី។
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// ឧបករណ៍រំកិលដែលផលិតដោយការហៅទូរស័ព្ទ `drain_filter` តាម LinkedList ។
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` មិនអីទេជាមួយនឹងឯកសារយោងឈ្មោះ `element` ។
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ប្រើប្រាស់បញ្ជីនេះទៅក្នុងធាតុធ្វើអន្តរកម្មដែលផ្តល់តម្លៃតាមតម្លៃ។
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// សូមប្រាកដថា `LinkedList` និងអ្នកអានបានតែអានគឺមានភាពខុសគ្នានៅក្នុងប៉ារ៉ាម៉ែត្រប្រភេទរបស់ពួកគេ។
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}