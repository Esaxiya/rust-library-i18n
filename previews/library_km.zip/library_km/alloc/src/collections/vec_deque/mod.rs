//! ជួរពីរជាន់ដែលបានអនុវត្តជាមួយសតិបណ្ដោះអាសន្នដែលអាចរីកចម្រើនបាន។
//!
//! ជួរនេះមានការបញ្ចូលនិងដកហូត *O*(1) ដែលបានរំលោះចេញពីចុងកុងតឺន័រទាំងពីរ។
//! វាក៏មានសន្ទស្សន៍ *O*(1) ដូចជា vector ។
//! ធាតុដែលមានមិនចាំបាច់អាចចម្លងបានទេហើយជួរនឹងអាចបញ្ជូនបានប្រសិនបើប្រភេទដែលមានអាចផ្ញើបាន។
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // ២ ^ ៣, ១
const MINIMUM_CAPACITY: usize = 1; // ២, ១

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // ថាមពលដែលអាចធ្វើបានធំបំផុតពីរ

/// ជួរពីរជាន់ដែលបានអនុវត្តជាមួយសតិបណ្ដោះអាសន្នដែលអាចរីកចម្រើនបាន។
///
/// ការប្រើប្រាស់ "default" នៃប្រភេទនេះជាជួរគឺត្រូវប្រើ [`push_back`] ដើម្បីបន្ថែមទៅជួរហើយ [`pop_front`] ដើម្បីយកចេញពីជួរ។
///
/// [`extend`] ហើយ [`append`] រុញទៅលើខ្នងតាមរបៀបនេះហើយការបើកបរលើ `VecDeque` គឺទៅមុខ។
///
/// ដោយសារ `VecDeque` គឺជាអង្គចងចាំបណ្ដោះអាសន្នធាតុរបស់វាមិនចាំបាច់ជាប់ទាក់ទងនឹងសតិទេ។
/// ប្រសិនបើអ្នកចង់ចូលប្រើធាតុជាចំណែកតែមួយដូចជាសម្រាប់ការតម្រៀបប្រកបដោយប្រសិទ្ធភាពអ្នកអាចប្រើ [`make_contiguous`] ។
/// វាបង្វិល `VecDeque` ដូច្នេះធាតុរបស់វាមិនរុំហើយត្រឡប់ចំណែកដែលអាចផ្លាស់ប្តូរបានទៅជាធាតុដែលជាប់គ្នាឥឡូវនេះ។
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // កន្ទុយនិងក្បាលជាសសរចង្អុលទៅសតិបណ្ដោះអាសន្ន។
    // កន្ទុយតែងតែចង្អុលទៅធាតុទីមួយដែលអាចអានបានក្បាលតែងតែចង្អុលទៅកន្លែងដែលគួរសរសេរទិន្នន័យ។
    //
    // ប្រសិនបើកន្ទុយ==ក្បាលសតិបណ្ដោះអាសន្នគឺទទេ។ប្រវែងរបស់អ្នករោទិ៍ត្រូវបានកំណត់ជាចម្ងាយរវាងពីរ។
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// ដំណើរការអ្នកបំផ្លាញសម្រាប់វត្ថុទាំងអស់នៅក្នុងចំណិតនៅពេលវាត្រូវបានទម្លាក់ (ធម្មតាឬកំឡុងពេលចុះក្រោម) ។
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // ប្រើធ្លាក់ចុះសម្រាប់ [T]
            ptr::drop_in_place(front);
        }
        // RawVec ដោះស្រាយការចែកចាយ
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// បង្កើត `VecDeque<T>` ទទេ។
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// បន្ទាប់បន្សំកាន់តែងាយស្រួល
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// បន្ទាប់បន្សំកាន់តែងាយស្រួល
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // ចំពោះប្រភេទសូន្យយើងតែងតែមានសមត្ថភាពអតិបរមា
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// បង្វែរ ptr ទៅជាចំណិត
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// បង្វែរ ptr ទៅជាចំណិតគ្នា
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// ផ្លាស់ទីធាតុចេញពីសតិបណ្ដោះអាសន្ន
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// សរសេរធាតុមួយទៅក្នុងអង្គចងចាំហើយរំកិលវា។
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើសតិបណ្ដោះអាសន្នមានសមត្ថភាពពេញលេញ។
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// ត្រឡប់សន្ទស្សន៍ក្នុងសតិបណ្ដោះអាសន្នមូលដ្ឋានសម្រាប់សន្ទស្សន៍ធាតុឡូជីខលដែលបានផ្តល់។
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// ត្រឡប់សន្ទស្សន៍ក្នុងសតិបណ្ដោះអាសន្នមូលដ្ឋានសម្រាប់សន្ទស្សន៍ធាតុឡូជីខល + បូកបន្ថែម។
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// ត្រឡប់លិបិក្រមក្នុងសតិបណ្ដោះអាសន្នមូលដ្ឋានសម្រាប់លិបិក្រមធាតុឡូជីខលដែលបានផ្តល់ឱ្យ។
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// ថតចម្លងប្លុកជាប់គ្នានៃសតិវែងពី src ទៅ dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// ថតចម្លងប្លុកជាប់គ្នានៃសតិវែងពី src ទៅ dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// ថតចំលងបណ្តុំនៃមេម៉ូរីដែលមានសក្តានុពលពី src ទៅទិសដៅ។
    /// (abs(dst - src) + len) មិនត្រូវធំជាង cap() ទេ (ត្រូវតែមានតំបន់ត្រួតស៊ីគ្នាច្រើនបំផុតរវាង src និងទិសដៅ) ។
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src មិនរុំមិនជាប់
                //
                //        ស។។។
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] ឃ។
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst មុន src, src មិនរុំទេ
                //
                //
                //    ស។។។
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // ៣ X០០X .. ឃ។
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src មុនថ្ងៃ, src មិនរុំ, dst រុំ
                //
                //
                //              ស។។។
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // ៣ X០០X .. ឃ។
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst មុន src, src រុំ, dst មិនរុំ
                //
                //
                //    .. ស។
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] ឃ។។។
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src មុនពេល DST, src រុំ, DST មិនរុំ
                //
                //
                //    .. ស។
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] ឃ។។។
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst មុន src, src រុំ, dst រុំ
                //
                //
                //    ។.. ស។
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // ៣ X០០X
                // 4 [B C C D _ E G H A] .. ឃ។។
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src មុន dst, src រុំ, dst រុំ
                //
                //
                //    .. ស។។
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // ៣ X០០X
                // ៤ X០០X ។.. ឃ។
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// ចាប់ក្បាលនិងកន្ទុយនៅជុំវិញដើម្បីដោះស្រាយការពិតដែលថាយើងទើបតែផ្លាស់ប្តូរទីតាំង។
    /// មិនមានសុវត្ថិភាពព្រោះវាជឿជាក់លើភាពចាស់។
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // ផ្លាស់ទីផ្នែកជាប់គ្នាខ្លីបំផុតនៃសង្វៀនទ្រនាប់ TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          បាត [។។។អូហូវូ។។។។។។
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // ណុប
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// បង្កើត `VecDeque` ទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// បង្កើត `VecDeque` ទទេដែលមានចន្លោះសម្រាប់ធាតុយ៉ាងហោចណាស់ `capacity` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 ចាប់តាំងពីអ្នករោទិ៍តែងតែទុកចន្លោះទំនេរមួយ
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// ផ្តល់សេចក្តីយោងទៅធាតុនៅលិបិក្រមដែលបានផ្តល់ឱ្យ។
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ផ្តល់នូវសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានចំពោះធាតុនៅលិបិក្រមដែលបានផ្តល់។
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// ប្តូរធាតុនៅសន្ទស្សន៍ `i` និង `j` ។
    ///
    /// `i` និង `j` អាចស្មើ។
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសន្ទស្សន៍ទាំងនោះនៅក្រៅព្រំដែន។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// ត្រឡប់ចំនួននៃធាតុដែល `VecDeque` អាចផ្ទុកដោយមិនចាំបាច់រើចេញ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// រក្សាសមត្ថភាពអប្បបរមាសម្រាប់ធាតុបន្ថែមទៀត `additional` ដែលត្រូវបញ្ចូលក្នុង `VecDeque` ដែលបានផ្តល់ឱ្យ។
    /// មិនធ្វើអ្វីទេប្រសិនបើសមត្ថភាពគ្រប់គ្រាន់ហើយ។
    ///
    /// ចំណាំថាអ្នកបែងចែកអាចផ្តល់កន្លែងប្រមូលច្រើនជាងកន្លែងដែលវាស្នើសុំ។
    /// ដូច្នេះសមត្ថភាពមិនអាចពឹងផ្អែកបានតិចតួចទេ។
    /// ចូលចិត្ត [`reserve`] ប្រសិនបើការបញ្ចូល future ត្រូវបានរំពឹងទុក។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីហូរលើស `usize` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// រក្សាទុកសមត្ថភាពយ៉ាងហោចណាស់ធាតុ `additional` បន្ថែមទៀតដែលត្រូវបញ្ចូលក្នុង `VecDeque` ដែលបានផ្តល់ឱ្យ។
    /// ការប្រមូលផ្ដុំអាចមានកន្លែងទំនេរច្រើនដើម្បីចៀសវាងការផ្លាស់ទីលំនៅជាញឹកញាប់។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីហូរលើស `usize` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// ព្យាយាមបម្រុងទុកសមត្ថភាពអប្បបរមាសម្រាប់ធាតុបន្ថែមចំនួន `additional` ដែលត្រូវបញ្ចូលក្នុង `VecDeque<T>` ដែលបានផ្តល់ឱ្យ។
    ///
    /// បន្ទាប់ពីហៅទូរស័ព្ទ `try_reserve_exact` សមត្ថភាពនឹងធំជាងឬស្មើ `self.len() + additional` ។
    /// មិនធ្វើអ្វីទេប្រសិនបើសមត្ថភាពគ្រប់គ្រាន់ហើយ។
    ///
    /// ចំណាំថាអ្នកបែងចែកអាចផ្តល់កន្លែងប្រមូលច្រើនជាងកន្លែងដែលវាស្នើសុំ។
    /// ដូច្នេះសមត្ថភាពមិនអាចពឹងផ្អែកបានលើចំនួនតិចតួចបំផុតទេ។
    /// ចូលចិត្ត `reserve` ប្រសិនបើការបញ្ចូល future ត្រូវបានរំពឹងទុក។
    ///
    /// # Errors
    ///
    /// ប្រសិនបើសមត្ថភាពហួសចំណុះ `usize` ឬអ្នកបែងចែករាយការណ៍ពីការបរាជ័យបន្ទាប់មកកំហុសត្រូវបានត្រឡប់មកវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // ទុកការចងចាំទុកជាមុនសិនបើយើងមិនអាច
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ឥឡូវនេះយើងដឹងថានេះមិនអាច OOM(Out-Of-Memory) នៅពាក់កណ្តាលការងារស្មុគស្មាញរបស់យើងទេ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ស្មុគស្មាញណាស់
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// ព្យាយាមបម្រុងទុកសម្រាប់ធាតុយ៉ាងតិច `additional` បន្ថែមទៀតដែលត្រូវបញ្ចូលក្នុង `VecDeque<T>` ដែលបានផ្តល់ឱ្យ។
    /// ការប្រមូលផ្ដុំអាចមានកន្លែងទំនេរច្រើនដើម្បីចៀសវាងការផ្លាស់ទីលំនៅជាញឹកញាប់។
    /// បន្ទាប់ពីហៅទូរស័ព្ទ `try_reserve` សមត្ថភាពនឹងធំជាងឬស្មើ `self.len() + additional` ។
    /// មិនធ្វើអ្វីទាំងអស់ប្រសិនបើសមត្ថភាពគ្រប់គ្រាន់ហើយ។
    ///
    /// # Errors
    ///
    /// ប្រសិនបើសមត្ថភាពហួសចំណុះ `usize` ឬអ្នកបែងចែករាយការណ៍ពីការបរាជ័យបន្ទាប់មកកំហុសត្រូវបានត្រឡប់មកវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // ទុកការចងចាំទុកជាមុនសិនបើយើងមិនអាច
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ឥឡូវនេះយើងដឹងថានេះមិនអាចជាអូមនៅពាក់កណ្តាលការងារស្មុគស្មាញរបស់យើងទេ
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ស្មុគស្មាញណាស់
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// បង្រួមសមត្ថភាពរបស់ `VecDeque` តាមដែលអាចធ្វើទៅបាន។
    ///
    /// វានឹងធ្លាក់ចុះយ៉ាងជិតបំផុតតាមដែលអាចធ្វើទៅបានទៅនឹងប្រវែងប៉ុន្តែអ្នកបែងចែកនៅតែជូនដំណឹងដល់ `VecDeque` ថាមានកន្លែងសម្រាប់ធាតុពីរបីទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// បង្រួមសមត្ថភាពរបស់ `VecDeque` ជាមួយនឹងខ្សែទាប។
    ///
    /// សមត្ថភាពនឹងនៅតែមានយ៉ាងហោចណាស់យ៉ាងហោចណាស់ទាំងប្រវែងនិងតម្លៃដែលបានផ្គត់ផ្គង់។
    ///
    ///
    /// ប្រសិនបើសមត្ថភាពបច្ចុប្បន្នតិចជាងដែនកំណត់ទាបនេះមិនមែនជាអាយភីទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // យើងមិនចាំបាច់ព្រួយបារម្ភអំពីការហៀរហៀរទេដូចជា `self.len()` និង `self.capacity()` មិនអាចជា `usize::MAX` ទេ។
        // +1 ក្នុងនាមជាអ្នករោទិ៍តែងតែទុកចន្លោះទំនេរមួយ។
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // មានចំណាប់អារម្មណ៍បីករណី៖
            //   ធាតុទាំងអស់គឺនៅក្រៅព្រំដែនដែលចង់បានធាតុមានរាងជាប់គ្នាហើយក្បាលគឺនៅក្រៅព្រំដែនដែលចង់បានធាតុមានលក្ខណៈមិនដាច់ពីគ្នាហើយកន្ទុយគឺនៅក្រៅព្រំដែនដែលចង់បាន។
            //
            //
            // គ្រប់ពេលវេលាទាំងអស់មុខតំណែងធាតុមិនត្រូវបានប៉ះពាល់ទេ។
            //
            // ចង្អុលបង្ហាញថាធាតុនៅក្បាលគួរតែត្រូវបានផ្លាស់ទី។
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // ផ្លាស់ប្តូរធាតុចេញពីព្រំដែនដែលចង់បាន (ទីតាំងបន្ទាប់ពីគោលដៅ _ ក្រុង)
            if self.tail >= target_cap && head_outside {
                // ថ
                //   [. . . . . . . . o o o o o o o . ]
                //    ថ
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // ថ
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// បង្រួម `VecDeque` រក្សាធាតុ `len` ដំបូងហើយទម្លាក់នៅសល់។
    ///
    ///
    /// ប្រសិនបើ `len` ធំជាងប្រវែងបច្ចុប្បន្នរបស់ `VecDeque` នេះមិនមានប្រសិទ្ធិភាពទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// ដំណើរការអ្នកបំផ្លាញសម្រាប់វត្ថុទាំងអស់នៅក្នុងចំណិតនៅពេលវាត្រូវបានទម្លាក់ (ធម្មតាឬកំឡុងពេលចុះក្រោម) ។
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // សុវត្ថិភាពពីព្រោះ៖
        //
        // * ចំណែកណាមួយដែលបញ្ជូនទៅ `drop_in_place` មានសុពលភាព។ករណីទី ២ មាន `len <= front.len()` ហើយត្រឡប់លើ `len > self.len()` ធានាថា `begin <= back.len()` ក្នុងករណីដំបូង
        //
        // * ក្បាលវ៉ិចទ័រត្រូវបានផ្លាស់ប្តូរមុនពេលហៅទូរស័ព្ទ `drop_in_place` ដូច្នេះគ្មានតម្លៃត្រូវបានទម្លាក់ពីរដងទេប្រសិនបើ `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // ត្រូវប្រាកដថាពាក់កណ្តាលទីពីរត្រូវបានទម្លាក់សូម្បីតែនៅពេលដែលអ្នកបំផ្លាញម្នាក់នៅក្នុងក្រុមហ៊ុន panics ដំបូងក៏ដោយ។
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// ត្រឡប់ទ្រនាប់ទ្រនាប់ខាងមុខទៅខាងក្រោយ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// ត្រឡប់ទ្រនិចទ្រនាប់ពីមុខទៅខាងក្រោយដែលត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // សុវត្តិភាពៈផ្ទៃក្នុងសុវតិ្ថភាពសុវត្ថិភាព `IterMut` ត្រូវបានបង្កើតឡើងដោយសារតែឯកសារ
        // `ring` យើងបង្កើតគឺជាចំណិតដែលមិនអាចកាត់ផ្តាច់បានសម្រាប់មួយជីវិត។
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// ត្រឡប់ចំណិតមួយគូដែលមានមាតិការបស់ `VecDeque` តាមលំដាប់លំដោយ។
    ///
    /// ប្រសិនបើ [`make_contiguous`] ត្រូវបានគេហៅពីមុនធាតុទាំងអស់នៃ `VecDeque` នឹងស្ថិតនៅក្នុងចំណិតទីមួយហើយចំណែកទីពីរនឹងនៅទទេ។
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// ត្រឡប់ចំណិតមួយគូដែលមានមាតិការបស់ `VecDeque` តាមលំដាប់លំដោយ។
    ///
    /// ប្រសិនបើ [`make_contiguous`] ត្រូវបានគេហៅពីមុនធាតុទាំងអស់នៃ `VecDeque` នឹងស្ថិតនៅក្នុងចំណិតទីមួយហើយចំណែកទីពីរនឹងនៅទទេ។
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// ត្រឡប់ចំនួនធាតុក្នុង `VecDeque` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `VecDeque` ទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// បង្កើតឧបករណ៍រំកិលដែលគ្របដណ្ដប់ជួរដែលបានបញ្ជាក់នៅក្នុង `VecDeque` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើចំនុចចាប់ផ្តើមធំជាងចំនុចបញ្ចប់រឺបើចំនុចបញ្ចប់ធំជាងប្រវែងរបស់ vector ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // ជួរពេញលេញគ្របដណ្តប់មាតិកាទាំងអស់
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // ឯកសារយោងរួមដែលយើងមាននៅក្នុង &self ត្រូវបានរក្សាទុកនៅក្នុង '_ របស់ Iter ។
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// បង្កើតឧបករណ៍រំកិលដែលគ្របដណ្ដប់ជួរដែលអាចផ្លាស់ប្តូរបាននៅក្នុង `VecDeque` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើចំនុចចាប់ផ្តើមធំជាងចំនុចបញ្ចប់រឺបើចំនុចបញ្ចប់ធំជាងប្រវែងរបស់ vector ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // ជួរពេញលេញគ្របដណ្តប់មាតិកាទាំងអស់
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // សុវត្តិភាពៈផ្ទៃក្នុងសុវតិ្ថភាពសុវត្ថិភាព `IterMut` ត្រូវបានបង្កើតឡើងដោយសារតែឯកសារ
        // `ring` យើងបង្កើតគឺជាចំណិតដែលមិនអាចកាត់ផ្តាច់បានសម្រាប់មួយជីវិត។
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// បង្កើតឧបករណ៍បំលែងទឹកដែលដកចេញជួរដែលបានបញ្ជាក់នៅក្នុង `VecDeque` ហើយផ្តល់ទិន្នផលដល់ធាតុដែលបានដកចេញ។
    ///
    /// ចំណាំទី ១ ៈជួរធាតុត្រូវបានដកចេញទោះបីជាឧបករណ៍វាស់មិនត្រូវបានប្រើប្រាស់រហូតដល់ទីបញ្ចប់ក៏ដោយ។
    ///
    /// ចំណាំទី ២ ៈវាមិនត្រូវបានបញ្ជាក់ថាតើមានធាតុប៉ុន្មានត្រូវបានដកចេញពីដេសនោះទេប្រសិនបើតម្លៃ `Drain` មិនត្រូវបានទម្លាក់ប៉ុន្តែប្រាក់កម្ចីដែលវាបានផុតកំណត់ (ឧទាហរណ៍ដោយសារតែ `mem::forget`) ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើចំនុចចាប់ផ្តើមធំជាងចំនុចបញ្ចប់រឺបើចំនុចបញ្ចប់ធំជាងប្រវែងរបស់ vector ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // ជួរពេញលេញលុបមាតិកាទាំងអស់
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // សុវត្ថិភាពនៃការចងចាំ
        //
        // នៅពេលដែល Drain ត្រូវបានបង្កើតដំបូងប្រភព deque ត្រូវបានខ្លីដើម្បីធ្វើឱ្យប្រាកដថាគ្មានធាតុដែលមិនឯកសិទ្ធិឬផ្លាស់ទីពីធាតុដែលអាចចូលដំណើរការបានទាល់តែសោះប្រសិនបើអ្នកបំផ្លាញ Drain មិនដែលរត់។
        //
        //
        // Drain នឹងយកតម្លៃ ptr::read ចេញ។
        // នៅពេលបញ្ចប់ទិន្នន័យដែលនៅសល់នឹងត្រូវបានថតចម្លងត្រឡប់មកវិញដើម្បីបិទរន្ធហើយតម្លៃ head/tail នឹងត្រូវបានស្តារឡើងវិញយ៉ាងត្រឹមត្រូវ។
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // ធាតុរបស់ឌីសត្រូវបានចែកជាបីផ្នែក៖
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;ក្រុមហ៊ុន H= self.head;t=drain_tail;h=drain_head
        //
        // យើងរក្សាទុក drain_tail ថាជា self.head, និង drain_head និង self.head ជាផលិតផលក្រោយហើយនៅលើ Drain ។
        // នេះក៏កាត់ចេញអារេដែលមានប្រសិទ្ធភាពផងដែរប្រសិនបើ Drain លេចធ្លាយយើងបានភ្លេចអំពីតម្លៃដែលអាចផ្លាស់ប្តូរបានបន្ទាប់ពីការចាប់ផ្តើមនៃ drain ។
        //
        //
        //        ទីទី H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" អំពីតម្លៃបន្ទាប់ពីការចាប់ផ្តើមនៃ drain រហូតដល់បន្ទាប់ពី drain បានបញ្ចប់ហើយ Drain អ្នកហិនទ័រត្រូវបានដំណើរការ។
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // អ្វីដែលសំខាន់យើងគ្រាន់តែបង្កើតឯកសារយោងរួមពី `self` នៅទីនេះហើយអានពីវា។
                // យើងមិនសរសេរទៅ `self` ទេហើយក៏មិនយោងទៅឯកសារយោងដែលអាចផ្លាស់ប្តូរបានដែរ។
                // ដូច្នេះទ្រនិចឆៅដែលយើងបានបង្កើតខាងលើសម្រាប់ `deque` នៅតែមានសុពលភាព។
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// ជម្រះ `VecDeque`, យកចេញតម្លៃទាំងអស់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `VecDeque` មានធាតុស្មើនឹងតម្លៃដែលបានផ្តល់។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// ផ្តល់ឯកសារយោងទៅធាតុខាងមុខរឺ `None` ប្រសិនបើ `VecDeque` ទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// ផ្តល់នូវសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅធាតុខាងមុខឬ `None` ប្រសិនបើ `VecDeque` ទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// ផ្តល់នូវសេចក្តីយោងទៅធាតុខាងក្រោយរឺ `None` ប្រសិនបើ `VecDeque` ទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// ផ្តល់នូវសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅធាតុខាងក្រោយឬ `None` ប្រសិនបើ `VecDeque` ទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// យកធាតុដំបូងចេញហើយប្រគល់វាមកវិញឬ `None` ប្រសិនបើ `VecDeque` ទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// យកធាតុចុងក្រោយចេញពី `VecDeque` ហើយបញ្ជូនវាមកវិញឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// បញ្ចូលធាតុទៅនឹង `VecDeque` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// ដាក់ធាតុនៅខាងក្រោយ `VecDeque` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: យើងគួរតែពិចារណា `head == 0` មានន័យថា
        // តើ `self` ជាប់គ្នាទេ?
        self.tail <= self.head
    }

    /// យកធាតុចេញពីកន្លែងណាមួយនៅក្នុង `VecDeque` ហើយត្រឡប់វាមកវិញដោយជំនួសដោយធាតុទីមួយ។
    ///
    ///
    /// នេះមិនការពារការបញ្ជាទិញទេប៉ុន្តែគឺ *O*(1) ។
    ///
    /// ត្រឡប់ `None` ប្រសិនបើ `index` មិនមានព្រំដែន។
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// យកធាតុចេញពីកន្លែងណាមួយនៅក្នុង `VecDeque` ហើយត្រឡប់វាមកវិញដោយជំនួសជាមួយធាតុចុងក្រោយ។
    ///
    ///
    /// នេះមិនការពារការបញ្ជាទិញទេប៉ុន្តែគឺ *O*(1) ។
    ///
    /// ត្រឡប់ `None` ប្រសិនបើ `index` មិនមានព្រំដែន។
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// បញ្ចូលធាតុនៅ `index` ក្នុង `VecDeque` ផ្លាស់ប្តូរធាតុទាំងអស់ដោយសន្ទស្សន៍ធំជាងឬស្មើ `index` ឆ្ពោះទៅខាងក្រោយ។
    ///
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `index` ធំជាងប្រវែងរបស់ `VecDeque`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // ផ្លាស់ទីចំនួនធាតុតិចបំផុតនៅក្នុងសតិបណ្ដោះអាសន្នហើយបញ្ចូលវត្ថុដែលបានផ្តល់ឱ្យ
        //
        // ភាគច្រើន len/2 ធាតុ ១ នឹងត្រូវផ្លាស់ទី។ O(min(n, n-i))
        //
        // មានករណីសំខាន់ៗចំនួន ៣ គឺៈ
        //  ធាតុគឺជាប់គ្នា
        //      - ករណីពិសេសនៅពេលកន្ទុយគឺ ០ ធាតុមានលក្ខណៈមិនដាច់ហើយការបញ្ចូលគឺនៅក្នុងផ្នែកកន្ទុយធាតុគឺមិនមានភាពចាំបាច់ហើយការបញ្ចូលគឺស្ថិតនៅក្នុងផ្នែកក្បាល
        //
        //
        // សម្រាប់ករណីនីមួយៗមានពីរករណីទៀត៖
        //  បញ្ចូលគឺខិតទៅជិតកន្ទុយបញ្ចូលគឺខិតទៅជិតក្បាល
        //
        // កូនសោ: ក្រុមហ៊ុន H, self.head
        //      T, self.tail o, ធាតុមានសុពលភាព I, ធាតុបញ្ចូល A, ធាតុដែលគួរតែបន្ទាប់ពីចំនុចបញ្ចូល M, ចង្អុលបង្ហាញធាតុត្រូវបានផ្លាស់ប្តូរ
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [អូអូហូ។។។។។។។
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // ជាប់គ្នាបញ្ចូលកាន់តែជិតទៅនឹងកន្ទុយ:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           ថ
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // ជាប់គ្នាបញ្ចូលកាន់តែជិតទៅនឹងកន្ទុយហើយកន្ទុយគឺ ០៖
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // ផ្លាស់ប្តូរកន្ទុយរួចហើយដូច្នេះយើងគ្រាន់តែចម្លងធាតុ `index - 1` ប៉ុណ្ណោះ។
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ជាប់គ្នាបញ្ចូលខិតទៅជិតក្បាល:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             ថ
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // ដាច់ពីគ្នា, បញ្ចូលខិតទៅជិតកន្ទុយ, ផ្នែកកន្ទុយ:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // ដាច់ពីគ្នា, បញ្ចូលទៅជិតក្បាល, ផ្នែកកន្ទុយ:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // ចម្លងធាតុរហូតដល់ក្បាលថ្មី
                    self.copy(1, 0, self.head);

                    // ចម្លងធាតុចុងក្រោយទៅក្នុងកន្លែងទទេនៅខាងក្រោមសតិបណ្ដោះអាសន្ន
                    self.copy(0, self.cap() - 1, 1);

                    // ផ្លាស់ទីធាតុពី idx ទៅចុងបញ្ចប់ឆ្ពោះទៅមុខដោយមិនរាប់បញ្ចូលទាំងធាតុ
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // ដោយមិនចាំបាច់បញ្ចូលគឺខិតទៅជិតកន្ទុយផ្នែកក្បាលនិងស្ថិតនៅសូន្យនៃសន្ទស្សន៍បណ្តោះអាសន្នខាងក្នុង៖
                    //
                    //
                    //       អាយ។ អេ។ ធី
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // ចម្លងធាតុរហូតដល់កន្ទុយថ្មី
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ចម្លងធាតុចុងក្រោយទៅក្នុងកន្លែងទទេនៅខាងក្រោមសតិបណ្ដោះអាសន្ន
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // ដាច់ពីគ្នា, បញ្ចូលខិតទៅជិតកន្ទុយ, ផ្នែកក្បាល:
                    //
                    //             អាយ។ អេ។ ធី
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // ចម្លងធាតុរហូតដល់កន្ទុយថ្មី
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ចម្លងធាតុចុងក្រោយទៅក្នុងកន្លែងទទេនៅខាងក្រោមសតិបណ្ដោះអាសន្ន
                    self.copy(self.cap() - 1, 0, 1);

                    // ផ្លាស់ទីធាតុពី idx-1 ទៅចុងបញ្ចប់ឆ្ពោះទៅមុខដោយមិនរាប់បញ្ចូលទាំងធាតុ
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // ដាច់ពីគ្នា, បញ្ចូលទៅជិតក្បាល, ផ្នែកក្បាល:
                    //
                    //               អាយ។ អេ។ ធី
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // កន្ទុយប្រហែលជាត្រូវបានផ្លាស់ប្តូរដូច្នេះយើងចាំបាច់ត្រូវគណនាឡើងវិញ
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// យកនិងត្រឡប់ធាតុនៅ `index` ពី `VecDeque` ។
    /// ណាមួយដែលចុងបញ្ចប់ត្រូវខិតទៅជិតកន្លែងដកចេញនឹងត្រូវផ្លាស់ទៅបន្ទប់ហើយធាតុដែលរងផលប៉ះពាល់ទាំងអស់នឹងត្រូវផ្លាស់ទៅទីតាំងថ្មី។
    ///
    /// ត្រឡប់ `None` ប្រសិនបើ `index` មិនមានព្រំដែន។
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // មានករណីសំខាន់ៗចំនួន ៣ គឺៈ
        //  ធាតុគឺមិនទាក់ទងគ្នាធាតុគឺមិនដាច់ពីគ្នាហើយការដកយកចេញស្ថិតនៅផ្នែកកន្ទុយធាតុគឺមិនដាច់ពីគ្នាហើយការដកយកចេញស្ថិតនៅផ្នែកក្បាល
        //
        //      - ករណីពិសេសនៅពេលដែលធាតុមានលក្ខណៈជាប់គ្នាតាមបច្ចេកទេសប៉ុន្តែ self.head =០
        //
        // សម្រាប់ករណីនីមួយៗមានពីរករណីទៀត៖
        //  បញ្ចូលគឺខិតទៅជិតកន្ទុយបញ្ចូលគឺខិតទៅជិតក្បាល
        //
        // កូនសោ: ក្រុមហ៊ុន H, self.head
        //      T, self.tail o, ធាតុមានសុពលភាព x ធាតុត្រូវបានសម្គាល់សម្រាប់ការដក R, ចង្អុលបង្ហាញធាតុដែលកំពុងត្រូវបានដកចេញ M ធាតុចង្អុលបង្ហាញត្រូវបានផ្លាស់ប្តូរ
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // ជាប់គ្នា, យកខិតទៅជិតកន្ទុយ:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               ថ
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // ជាប់គ្នា, យកខិតទៅជិតក្បាល:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             ថ
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // ដាច់ដោយឡែក, យកខិតទៅជិតកន្ទុយ, ផ្នែកកន្ទុយ:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // ដាច់ដោយឡែក, យកខិតទៅជិតក្បាល, ផ្នែកក្បាល:
                    //
                    //               អរ
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // ដាច់ដោយឡែក, យកខិតទៅជិតក្បាល, ផ្នែកកន្ទុយ:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // ឬផ្នែកដែលមិនសំខាន់យកផ្នែកខាងក្រោយនៃក្បាលផ្នែកកន្ទុយចេញ៖
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         ថ
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // គូរនៅក្នុងធាតុនៅក្នុងផ្នែកកន្ទុយ
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // រារាំងការហូរចូល។
                    if self.head != 0 {
                        // ចម្លងធាតុទីមួយទៅក្នុងកន្លែងទទេ
                        self.copy(self.cap() - 1, 0, 1);

                        // ផ្លាស់ទីធាតុនៅក្នុងផ្នែកក្បាលថយក្រោយ
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // ដាច់ដោយឡែក, យកខិតទៅជិតកន្ទុយ, ផ្នែកក្បាល:
                    //
                    //           អរ
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // គូរនៅក្នុងធាតុរហូតដល់ idx
                    self.copy(1, 0, idx);

                    // ចម្លងធាតុចុងក្រោយទៅក្នុងកន្លែងទទេ
                    self.copy(0, self.cap() - 1, 1);

                    // ផ្លាស់ទីធាតុពីកន្ទុយទៅចុងទៅមុខដោយមិនរាប់បញ្ចូលធាតុចុងក្រោយ
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// បំបែក `VecDeque` ជាពីរនៅសន្ទស្សន៍ដែលបានផ្តល់ឱ្យ។
    ///
    /// ត្រឡប់ `VecDeque` ដែលបានបម្រុងទុកថ្មី។
    /// `self` មានធាតុ `[0, at)` ហើយ `VecDeque` ដែលត្រឡប់មកវិញមានផ្ទុកធាតុ `[at, len)` ។
    ///
    /// ចំណាំថាសមត្ថភាពរបស់ `self` មិនផ្លាស់ប្តូរទេ។
    ///
    /// ធាតុនៅលិបិក្រម 0 គឺជាផ្នែកខាងមុខនៃជួរ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `at > len` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` ស្ថិតនៅក្នុងពាក់កណ្តាលដំបូង។
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // គ្រាន់តែយកទាំងអស់នៃពាក់កណ្តាលទីពីរ។
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` ស្ថិតនៅក្នុងពាក់កណ្តាលទីពីរត្រូវការកត្តានៅក្នុងធាតុដែលយើងរំលងនៅពាក់កណ្តាលដំបូង។
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // សម្អាតកន្លែងចុងសតិបណ្ដោះអាសន្ន
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// ផ្លាស់ទីធាតុទាំងអស់នៃ `other` ទៅជា `self` ដោយទុកឱ្យ `other` ទទេ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើចំនួនធាតុថ្មីនៅក្នុងខ្លួនវាហួស `usize` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // ល្ងង់ខ្លៅ impl
        self.extend(other.drain(..));
    }

    /// រក្សាទុកតែធាតុដែលបានបញ្ជាក់ដោយអ្នកព្យាករណ៍។
    ///
    /// និយាយម្យ៉ាងទៀតដកធាតុទាំងអស់ `e` ចេញដែល `f(&e)` ត្រឡប់មិនពិត។
    /// វិធីសាស្រ្តនេះដំណើរការនៅនឹងកន្លែងទស្សនាធាតុនីមួយៗតាមលំដាប់ដើមហើយរក្សាលំដាប់នៃធាតុដែលបានរក្សាទុក។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// លំដាប់ពិតប្រាកដអាចមានប្រយោជន៍សម្រាប់តាមដានស្ថានភាពខាងក្រៅដូចជាសន្ទស្សន៍។
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // នេះអាច panic ឬបោះបង់
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // ទំហំសតិបណ្ដោះអាសន្នទ្វេដង។
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// កែប្រែ `VecDeque` នៅនឹងកន្លែងដូច្នេះ `len()` ស្មើនឹង `new_len` ដោយយកធាតុលើសពីខាងក្រោយឬដោយធាតុបន្ថែមដែលបង្កើតដោយការហៅ `generator` ទៅខាងក្រោយ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// រៀបចំកន្លែងផ្ទុកខាងក្នុងនៃឌីសនេះឡើងវិញដូច្នេះវាជាចំណិតជាប់គ្នាដែលបន្ទាប់មកត្រូវបានត្រឡប់មកវិញ។
    ///
    /// វិធីសាស្រ្តនេះមិនបានបម្រុងទុកនិងមិនផ្លាស់ប្តូរលំដាប់នៃធាតុបញ្ចូល។នៅពេលវាត្រឡប់ចំណែកដែលអាចផ្លាស់ប្តូរបាននេះអាចត្រូវបានប្រើដើម្បីតម្រៀបឌីស។
    ///
    /// នៅពេលដែលការផ្ទុកខាងក្នុងជាប់គ្នាវិធីសាស្រ្ត [`as_slices`] និង [`as_mut_slices`] នឹងត្រលប់មកវិញនូវមាតិកាទាំងមូលនៃ `VecDeque` ក្នុងមួយចំណែក ៗ ។
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// ការតម្រៀបមាតិកានៃឌីស។
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // តម្រៀប deque នេះ
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // តម្រៀបវាតាមលំដាប់បញ្ច្រាស
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// ទទួលបានការចូលដំណើរការមិនប្រែប្រួលទៅជាចំណែកជាប់គ្នាមួយ។
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // ឥឡូវនេះយើងអាចប្រាកដថា `slice` មានធាតុទាំងអស់នៃឌីសខណៈពេលដែលនៅតែមានការចូលដំណើរការមិនផ្លាស់ប្តូរទៅ `buf` ។
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // មានកន្លែងទំនេរគ្រប់គ្រាន់ដើម្បីចម្លងកន្ទុយក្នុងមួយផ្លូវមានន័យថាយើងប្តូរក្បាលទៅក្រោយហើយបន្ទាប់មកចម្លងកន្ទុយទៅទីតាំងត្រឹមត្រូវ។
            //
            //
            // from: DEFGH .... ABC
            // to: ABCDEFGH…។
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: បច្ចុប្បន្នយើងមិនពិចារណា .... ABCDEFGH
            // ជាប់គ្នាព្រោះ `head` អាចជា `0` ក្នុងករណីនេះ។
            // ខណៈពេលដែលយើងប្រហែលជាចង់ផ្លាស់ប្តូរវាមិនមែនជារឿងតូចតាចនោះទេខណៈដែលកន្លែងពីរបីរំពឹងថា `is_contiguous` មានន័យថាយើងគ្រាន់តែអាចកាត់បន្ថយការប្រើប្រាស់ `buf[tail..head]` ។
            //
            //

            // មានកន្លែងទំនេរគ្រប់គ្រាន់ដើម្បីចម្លងក្បាលក្នុងមួយទៅនេះមានន័យថាយើងប្តូរកន្ទុយទៅមុខហើយបន្ទាប់មកចម្លងក្បាលទៅទីតាំងត្រឹមត្រូវ។
            //
            //
            // from: FGH .... ABCDE
            // to: ... ABCDEFGH ។
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ឥតគិតថ្លៃគឺតូចជាងទាំងក្បាលនិងកន្ទុយ។ នេះមានន័យថាយើងត្រូវកាត់កន្ទុយនិងក្បាលឱ្យយឺត។
            //
            //
            // ពី: EFGHI ... ABCD ឬ HIJK.ABCDEFG
            // ជូនដល់៖ ABCDEFGHI…ឬ ABCDEFGHIJK ។
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // បញ្ហាទូទៅមើលទៅដូចជា GHIJKLM នេះ ... ABCDEF មុនពេលប្តូរ ABCDEFM ... GHIJKL បន្ទាប់ពីឆ្លងកាត់ការផ្លាស់ប្តូរ ABCDEFGHIJM ... KL, ប្តូររហូតដល់ edge ខាងឆ្វេងឈានដល់ហាងបណ្ដោះអាសន្ន
                //                  - បន្ទាប់មកចាប់ផ្តើមដំណើរការក្បួនដោះស្រាយឡើងវិញជាមួយនឹងហាងថ្មី (smaller) ពេលខ្លះហាងបណ្ដោះអាសន្នត្រូវបានទៅដល់នៅពេលដែល edge ខាងស្តាំគឺនៅចុងបញ្ចប់នៃសតិបណ្ដោះអាសន្ននេះមានន័យថាយើងបានបញ្ជាទិញត្រឹមត្រូវដោយមានការផ្លាស់ប្តូរតិច!
                //
                // E.g
                // EF..ABCD ABCDEF .. , បន្ទាប់ពីបួនបានផ្លាស់ប្តូរយើងបានបញ្ចប់
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// បង្វិលជួរជួរដេកទ្វេរដង `mid` ទៅខាងឆ្វេង។
    ///
    /// Equivalently,
    /// - បង្វិលធាតុ `mid` ទៅទីតាំងដំបូង។
    /// - ចាប់យកធាតុ `mid` ដំបូងហើយរុញវាដល់ទីបញ្ចប់។
    /// - បង្វិលកន្លែង `len() - mid` ទៅខាងស្តាំ។
    ///
    /// # Panics
    ///
    /// ប្រសិនបើ `mid` ធំជាង `len()` ។
    /// ចំណាំថា `mid == len()` ធ្វើ _not_ panic ហើយជាការបង្វិលគ្មានអ័ក្ស។
    ///
    /// # Complexity
    ///
    /// ចំណាយពេល `*O*(min(mid, len() - mid))` និងមិនមានកន្លែងទំនេរបន្ថែម។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// បង្វិលជួរជួរដេកទ្វេរដង `k` ទៅខាងស្តាំ។
    ///
    /// Equivalently,
    /// - បង្វិលធាតុទីមួយទៅទីតាំង `k` ។
    /// - ចាប់យកធាតុ `k` ចុងក្រោយហើយរុញវាទៅខាងមុខ។
    /// - បង្វិលកន្លែង `len() - k` ទៅខាងឆ្វេង។
    ///
    /// # Panics
    ///
    /// ប្រសិនបើ `k` ធំជាង `len()` ។
    /// ចំណាំថា `k == len()` ធ្វើ _not_ panic ហើយជាការបង្វិលគ្មានអ័ក្ស។
    ///
    /// # Complexity
    ///
    /// ចំណាយពេល `*O*(min(k, len() - k))` និងមិនមានកន្លែងទំនេរបន្ថែម។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // សុវត្ថិភាព: វិធីសាស្រ្តពីរខាងក្រោមតម្រូវឱ្យមានចំនួនទឹកប្រាក់បង្វិល
    // តិចជាងពាក់កណ្តាលប្រវែងនៃដីល្បាប់។
    //
    // `wrap_copy` តម្រូវឱ្យមាន `min(x, cap() - x) + copy_len <= cap()`, ប៉ុន្តែជាង `min` គឺមិនដែលមានច្រើនជាងពាក់កណ្តាលសមត្ថភាព, ដោយមិនគិតពី x, ដូច្នេះវាជាការល្អដើម្បីហៅនៅទីនេះព្រោះយើងកំពុងហៅជាមួយអ្វីដែលតិចជាងពាក់កណ្តាលប្រវែងដែលមិនលើសពីពាក់កណ្តាលសមត្ថភាព។
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// ប្រព័ន្ធគោលពីរស្វែងរកប្រភេទ `VecDeque` ដែលបានតម្រៀបសម្រាប់ធាតុដែលបានផ្តល់។
    ///
    /// ប្រសិនបើតម្លៃត្រូវបានរកឃើញបន្ទាប់មក [`Result::Ok`] ត្រូវបានត្រឡប់មកវិញដែលមានសន្ទស្សន៍នៃធាតុដែលត្រូវគ្នា។
    /// ប្រសិនបើមានការប្រកួតច្រើននោះការប្រកួតណាមួយអាចត្រូវបានប្រគល់ជូនវិញ។
    /// ប្រសិនបើតម្លៃមិនត្រូវបានរកឃើញនោះ [`Result::Err`] ត្រូវបានត្រឡប់មកវិញដែលមានលិបិក្រមដែលធាតុដែលត្រូវគ្នាអាចត្រូវបានបញ្ចូលខណៈពេលរក្សាលំដាប់ដែលបានតម្រៀប។
    ///
    ///
    /// # Examples
    ///
    /// រកមើលស៊េរីនៃធាតុបួន។
    /// ទីមួយត្រូវបានរកឃើញដោយមានជំហរដែលបានកំណត់តែមួយ។ទីពីរនិងទីបីរកមិនឃើញ។លេខបួនអាចផ្គូផ្គងទីតាំងណាមួយនៅក្នុង `[1, 4]` ។
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// ប្រសិនបើអ្នកចង់បញ្ចូលធាតុទៅ `VecDeque` X តម្រៀបខណៈពេលរក្សាលំដាប់តម្រៀប៖
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// ប្រព័ន្ធគោលពីរស្វែងរកប្រភេទ `VecDeque` ដែលបានតម្រៀបនេះជាមួយនឹងមុខងារប្រៀបធៀប។
    ///
    /// មុខងារប្រៀបធៀបគួរតែអនុវត្តលំដាប់ដែលស្របទៅនឹងការតម្រៀបនៃ `VecDeque` មូលដ្ឋានដោយត្រឡប់កូដបញ្ជាទិញដែលបង្ហាញថាតើអាគុយម៉ង់របស់វាគឺ `Less`, `Equal` ឬ `Greater` ជាងគោលដៅដែលចង់បាន។
    ///
    ///
    /// ប្រសិនបើតម្លៃត្រូវបានរកឃើញបន្ទាប់មក [`Result::Ok`] ត្រូវបានត្រឡប់មកវិញដែលមានសន្ទស្សន៍នៃធាតុដែលត្រូវគ្នា។ប្រសិនបើមានការប្រកួតច្រើននោះការប្រកួតណាមួយអាចត្រូវបានប្រគល់ជូនវិញ។
    /// ប្រសិនបើតម្លៃមិនត្រូវបានរកឃើញនោះ [`Result::Err`] ត្រូវបានត្រឡប់មកវិញដែលមានលិបិក្រមដែលធាតុដែលត្រូវគ្នាអាចត្រូវបានបញ្ចូលខណៈពេលរក្សាលំដាប់ដែលបានតម្រៀប។
    ///
    /// # Examples
    ///
    /// រកមើលស៊េរីនៃធាតុបួន។ទីមួយត្រូវបានរកឃើញដោយមានជំហរដែលបានកំណត់តែមួយ។ទីពីរនិងទីបីរកមិនឃើញ។លេខបួនអាចផ្គូផ្គងទីតាំងណាមួយនៅក្នុង `[1, 4]` ។
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// ប្រព័ន្ធគោលពីរស្វែងរកប្រភេទ `VecDeque` ដែលបានតម្រៀបនេះជាមួយនឹងមុខងារទាញយកកូនសោ។
    ///
    /// សន្មតថា `VecDeque` ត្រូវបានតម្រៀបតាមគន្លឹះឧទាហរណ៍ជាមួយ [`make_contiguous().sort_by_key()`](#method.make_contiguous) ដោយប្រើមុខងារទាញយកកូនសោដូចគ្នា។
    ///
    ///
    /// ប្រសិនបើតម្លៃត្រូវបានរកឃើញបន្ទាប់មក [`Result::Ok`] ត្រូវបានត្រឡប់មកវិញដែលមានសន្ទស្សន៍នៃធាតុដែលត្រូវគ្នា។
    /// ប្រសិនបើមានការប្រកួតច្រើននោះការប្រកួតណាមួយអាចត្រូវបានប្រគល់ជូនវិញ។
    /// ប្រសិនបើតម្លៃមិនត្រូវបានរកឃើញនោះ [`Result::Err`] ត្រូវបានត្រឡប់មកវិញដែលមានលិបិក្រមដែលធាតុដែលត្រូវគ្នាអាចត្រូវបានបញ្ចូលខណៈពេលរក្សាលំដាប់ដែលបានតម្រៀប។
    ///
    /// # Examples
    ///
    /// រកមើលស៊េរីនៃធាតុបួននៅក្នុងចំណែកនៃគូដែលបានតម្រៀបដោយធាតុទីពីររបស់ពួកគេ។
    /// ទីមួយត្រូវបានរកឃើញដោយមានជំហរដែលបានកំណត់តែមួយ។ទីពីរនិងទីបីរកមិនឃើញ។លេខបួនអាចផ្គូផ្គងទីតាំងណាមួយនៅក្នុង `[1, 4]` ។
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// កែប្រែ `VecDeque` នៅនឹងកន្លែងដូច្នេះ `len()` គឺស្មើនឹង new_len ដោយយកធាតុលើសពីខាងក្រោយឬដោយក្លូនបន្ថែមនៃ `value` ទៅខាងក្រោយ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// ត្រឡប់សន្ទស្សន៍ក្នុងសតិបណ្ដោះអាសន្នមូលដ្ឋានសម្រាប់សន្ទស្សន៍ធាតុឡូជីខលដែលបានផ្តល់។
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // ទំហំគឺតែងតែជាថាមពលនៃ ២
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// គណនាចំនួនធាតុដែលនៅសល់ដើម្បីអានក្នុងសតិបណ្ដោះអាសន្ន
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // ទំហំគឺតែងតែជាថាមពលនៃ ២
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // អាចបែងចែកជាបីផ្នែកជានិច្ចឧទាហរណ៍៖ ខ្លួនឯង៖ [a b c|d e f] ផ្នែកផ្សេងទៀត៖ ផ្នែកខាងមុខ [0 1 2 3|4 5] =3, ពាក់កណ្តាល=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // វាមិនអាចទៅរួចទេក្នុងការប្រើ Hash::hash_slice នៅលើចំណិតដែលបានវិលត្រឡប់ដោយវិធីសាស្រ្ត as-slices ព្រោះប្រវែងរបស់វាអាចមានលក្ខណៈខុសៗគ្នា។
        //
        //
        // ហាសហាគ្រាន់តែធានានូវភាពស្មើគ្នាចំពោះសំណុំនៃការហៅដូចគ្នាទៅនឹងវិធីសាស្ត្ររបស់វា។
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ប្រើប្រាស់ `VecDeque` ទៅក្នុងទ្រនាប់ទ្រនាប់ទ្រនាប់ដែលផ្តល់ធាតុតាមតម្លៃ។
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // មុខងារនេះគួរតែស្មើនឹងសីលធម៌នៃ
        //
        //      សម្រាប់ធាតុនៅក្នុង iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// បង្វែរ [`Vec<T>`] ទៅជា [`VecDeque<T>`] ។
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// នេះជៀសវាងការផ្លាស់ប្តូរកន្លែងដែលអាចធ្វើទៅបានប៉ុន្តែល័ក្ខខ័ណ្ឌដែលតឹងរឹងនិងអាចផ្លាស់ប្តូរហើយមិនគួរពឹងផ្អែកលើទេលុះត្រាតែ `Vec<T>` បានមកពី `From<VecDeque<T>>` ហើយមិនត្រូវបានគេកំណត់ទីតាំង។
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // មិនមានការបែងចែកជាក់ស្តែងសម្រាប់ ZST ដើម្បីព្រួយបារម្ភអំពីសមត្ថភាពនោះទេប៉ុន្តែ `VecDeque` មិនអាចដោះស្រាយប្រវែងដូចជា `Vec` បានទេ។
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // យើងត្រូវផ្លាស់ប្តូរទំហំប្រសិនបើសមត្ថភាពមិនមែនជាថាមពលពីរតូចពេកឬមិនមានទំហំទំនេរយ៉ាងហោចណាស់មួយ។
            // យើងធ្វើវាខណៈពេលដែលវានៅតែស្ថិតនៅក្នុង `Vec` ដូច្នេះធាតុនឹងធ្លាក់ចុះនៅលើ panic ។
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// បង្វែរ [`VecDeque<T>`] ទៅជា [`Vec<T>`] ។
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// នេះមិនចាំបាច់បែងចែកឡើងវិញទេប៉ុន្តែចាំបាច់ត្រូវធ្វើចលនាទិន្នន័យ *O*(*n*) ប្រសិនបើសតិបណ្ដោះអាសន្នមិនកើតឡើងនៅដើមនៃការបែងចែក។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // មួយនេះគឺ *O*(១) ។
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // មួយនេះត្រូវការរៀបចំទិន្នន័យឡើងវិញ។
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}