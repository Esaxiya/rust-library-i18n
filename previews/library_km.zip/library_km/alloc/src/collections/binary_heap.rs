//! ជួរអាទិភាពបានអនុវត្តជាមួយគំនរគោលពីរ។
//!
//! ការបញ្ចូលនិងការបញ្ចូលធាតុធំជាងគេមានពេលវេលាស្មុគស្មាញ *O*(log(*n*)) ។
//! ពិនិត្យមើលធាតុធំជាងគេគឺ *O*(១) ។ការបំលែង vector ទៅនឹងទ្រនាប់គោលពីរអាចត្រូវបានធ្វើនៅនឹងកន្លែងហើយមានភាពស្មុគស្មាញ *O*(*n*) ។
//! គំនរគោលពីរក៏អាចត្រូវបានបំលែងទៅជាកន្លែង vector ដែលបានតម្រៀបដែលអនុញ្ញាតឱ្យវាត្រូវបានប្រើសម្រាប់កន្លែង O *(* n *\* log(*n*))) ។
//!
//! # Examples
//!
//! នេះគឺជាឧទាហរណ៍ធំជាងដែលអនុវត្ត [Dijkstra's algorithm][dijkstra] ដើម្បីដោះស្រាយ [shortest path problem][sssp] នៅលើ [directed graph][dir_graph] ។
//!
//! វាបង្ហាញពីរបៀបប្រើ [`BinaryHeap`] ជាមួយប្រភេទផ្ទាល់ខ្លួន។
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // ជួរអាទិភាពអាស្រ័យលើ `Ord` ។
//! // អនុវត្ត trait យ៉ាងច្បាស់ដូច្នេះជួរក្លាយជាជួរតូចជំនួសឱ្យគំនរអតិបរមា។
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // សូមកត់សម្គាល់ថាយើងបង្វែរការបញ្ជាទិញតាមថ្លៃដើម។
//!         // ក្នុងករណីមានក្រវ៉ាត់ដែលយើងប្រៀបធៀបមុខតំណែងជំហាននេះគឺចាំបាច់ដើម្បីធ្វើឱ្យការអនុវត្ត `PartialEq` និង `Ord` ស្រប។
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` ត្រូវការអនុវត្តផងដែរ។
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ថ្នាំងនីមួយៗត្រូវបានតំណាងជា `usize` សម្រាប់ការអនុវត្តខ្លី។
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ក្បួនដោះស្រាយផ្លូវខ្លីបំផុតរបស់ Dijkstra ។
//!
//! // ចាប់ផ្តើមនៅ `start` ហើយប្រើ `dist` ដើម្បីតាមដានចម្ងាយខ្លីបំផុតទៅថ្នាំងនីមួយៗ។ការអនុវត្តនេះមិនមានប្រសិទ្ធភាពក្នុងការចងចាំទេព្រោះវាអាចទុកឱ្យមានលេខជាន់គ្នានៅក្នុងជួរ។
//! //
//! // វាក៏ប្រើ `usize::MAX` ជាតម្លៃបញ្ជូនសម្រាប់ការអនុវត្តសាមញ្ញ។
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [ថ្នាំង]=ចម្ងាយខ្លីបំផុតពី `start` ទៅ `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // យើងនៅ `start` ជាមួយនឹងការចំណាយសូន្យ
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // ពិនិត្យមើលព្រំដែនជាមួយថ្នាំងចំណាយទាបដំបូង (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // ម៉្យាងទៀតយើងអាចបន្តស្វែងរកផ្លូវខ្លីបំផុតទាំងអស់
//!         if position == goal { return Some(cost); }
//!
//!         // សំខាន់ដូចដែលយើងប្រហែលជាបានរកឃើញវិធីល្អប្រសើររួចទៅហើយ
//!         if cost > dist[position] { continue; }
//!
//!         // សម្រាប់ថ្នាំងនីមួយៗដែលយើងអាចទៅដល់សូមមើលថាតើយើងអាចរកផ្លូវដោយចំណាយទាបឆ្លងកាត់ថ្នាំងនេះទេ
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // បើដូច្នេះសូមបន្ថែមវានៅជួរមុខហើយបន្ត
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // ការសំរាកលំហែឥឡូវនេះយើងបានរកឃើញវិធីប្រសើរជាងមុន
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // គោលដៅមិនអាចទៅដល់បាន
//!     None
//! }
//!
//! fn main() {
//!     // នេះគឺជាក្រាហ្វដែលដឹកនាំយើងនឹងប្រើ។
//!     // លេខថ្នាំងត្រូវគ្នាទៅនឹងរដ្ឋផ្សេងៗគ្នាហើយទំងន់ edge តំណាងអោយថ្លៃដើមនៃការផ្លាស់ប្តូរពីថ្នាំងមួយទៅមួយទៀត។
//!     //
//!     // ចំណាំថាគែមគឺជាផ្លូវមួយ។
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v ១ ២ |២
//!     //          ០-----> ១-----> ៣---> ៤
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           ១០ ||
//!     //                   +---------------+
//!     //
//!     // ក្រាហ្វត្រូវបានតំណាងជាបញ្ជីភាពជិតស្និតដែលសន្ទស្សន៍នីមួយៗត្រូវនឹងតម្លៃថ្នាំងមានបញ្ជីគែមចេញ។
//!     // ជ្រើសរើសសម្រាប់ប្រសិទ្ធភាពរបស់វា។
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // ថ្នាំង ០
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // ថ្នាំង ១
//!         vec![Edge { node: 3, cost: 2 }],
//!         // ថ្នាំង ២
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // ថ្នាំង ៣
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // ថ្នាំង ៤
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// ជួរអាទិភាពបានអនុវត្តជាមួយគំនរគោលពីរ។
///
/// នេះនឹងជាគំនរអតិបរមា។
///
/// វាជាកំហុសតក្កវិជ្ជាសម្រាប់ធាតុដែលត្រូវបានកែប្រែតាមរបៀបដែលការតម្រៀបរបស់ធាតុទាក់ទងទៅនឹងធាតុផ្សេងទៀតដូចដែលបានកំណត់ដោយ `Ord` trait ផ្លាស់ប្តូរខណៈពេលដែលវាស្ថិតនៅក្នុងគំនរ។
///
/// នេះជាធម្មតាអាចធ្វើទៅបានតាមរយៈ `Cell`, `RefCell`, រដ្ឋសកល, I/O, ឬកូដគ្មានសុវត្ថិភាព។
/// ឥរិយាបថដែលបណ្តាលមកពីកំហុសតក្កវិជ្ជាមិនត្រូវបានបញ្ជាក់ទេប៉ុន្តែនឹងមិនបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
/// នេះអាចរួមបញ្ចូលទាំង panics លទ្ធផលមិនត្រឹមត្រូវការបោះបង់ការលេចធ្លាយសតិនិងការមិនបញ្ចប់។
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // ប្រភេទ inference អនុញ្ញាតឱ្យយើងលុបហត្ថលេខាប្រភេទជាក់លាក់មួយ (ដែលនឹងជា `BinaryHeap<i32>` ក្នុងឧទាហរណ៍នេះ) ។
/////
/// let mut heap = BinaryHeap::new();
///
/// // យើងអាចប្រើ peek ដើម្បីមើលធាតុបន្ទាប់នៅក្នុងគំនរ។
/// // ក្នុងករណីនេះមិនមានធាតុនៅក្នុងនោះនៅឡើយទេដូច្នេះយើងទទួលបានគ្មាន។
/// assert_eq!(heap.peek(), None);
///
/// // តោះបន្ថែមពិន្ទុខ្លះ ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // ឥឡូវនេះ peek បង្ហាញធាតុសំខាន់បំផុតនៅក្នុងគំនរ។
/// assert_eq!(heap.peek(), Some(&5));
///
/// // យើងអាចពិនិត្យមើលប្រវែងនៃគំនរ។
/// assert_eq!(heap.len(), 3);
///
/// // យើងអាចធ្វើឱ្យប៉ះពាល់ដល់វត្ថុនៅក្នុងគំនរទោះបីជាវាត្រូវបានគេត្រឡប់មកវិញតាមលំដាប់ចៃដន្យក៏ដោយ។
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // ប្រសិនបើយើងជំនួសពិន្ទុទាំងនេះពួកគេគួរតែត្រឡប់មកវិញតាមលំដាប់លំដោយ។
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // យើងអាចសំអាតគំនររបស់របរដែលនៅសេសសល់។
/// heap.clear();
///
/// // ហ៊ាឥឡូវនេះទទេ។
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// ទាំង `std::cmp::Reverse` ឬការអនុវត្ត `Ord` ផ្ទាល់ខ្លួនអាចត្រូវបានប្រើដើម្បីធ្វើឱ្យ `BinaryHeap` ជាខ្នាតតូច។
/// នេះធ្វើឱ្យ `heap.pop()` ត្រលប់មកវិញនូវតម្លៃតូចបំផុតជំនួសឱ្យអ្វីដែលអស្ចារ្យបំផុត។
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // តម្លៃរុំក្នុង `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // ប្រសិនបើយើងដាក់ពិន្ទុទាំងនេះឥឡូវនេះពួកគេគួរតែត្រលប់មកវិញតាមលំដាប់បញ្ច្រាស។
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # ភាពស្មុគស្មាញពេលវេលា
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// តម្លៃសម្រាប់ `push` គឺជាការចំណាយដែលរំពឹងទុក;ឯកសារវិធីសាស្រ្តផ្តល់នូវការវិភាគលម្អិតបន្ថែមទៀត។
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// រចនាសម្ព័ន្ធរុំសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានចំពោះធាតុធំបំផុតនៅលើ `BinaryHeap` ។
///
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`peek_mut`] នៅលើ [`BinaryHeap`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // សុវត្ថិភាព: PeekMut ត្រូវបានបង្កើតឡើងភ្លាមៗសម្រាប់គំនរមិនមែនទទេ។
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut ត្រូវបានបង្កើតឡើងភ្លាមៗសម្រាប់គំនរមិនមែនទទេ
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut ត្រូវបានបង្កើតឡើងភ្លាមៗសម្រាប់គំនរមិនមែនទទេ
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// យកតម្លៃដែលបានរកឃើញចេញពីគំនរហើយត្រឡប់វាវិញ។
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// បង្កើត `BinaryHeap<T>` ទទេ។
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// បង្កើត `BinaryHeap` ទទេជាគំនរអតិបរមា។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// បង្កើត `BinaryHeap` ទទេដែលមានសមត្ថភាពជាក់លាក់។
    /// ការនេះកំណត់ការចងចាំគ្រប់គ្រាន់សម្រាប់ធាតុ `capacity` ដូច្នេះ `BinaryHeap` មិនចាំបាច់ត្រូវបានកំណត់ទីតាំងរហូតដល់វាមានយ៉ាងហោចណាស់តម្លៃជាច្រើន។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// ត្រឡប់ឯកសារយោងដែលអាចផ្លាស់ប្តូរទៅធាតុធំបំផុតនៅក្នុងគំនរគោលពីរឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// Note: ប្រសិនបើតម្លៃ `PeekMut` ត្រូវបានលេចធ្លាយនោះគំនរអាចស្ថិតនៅក្នុងស្ថានភាពមិនស៊ីចង្វាក់គ្នា។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # ភាពស្មុគស្មាញពេលវេលា
    ///
    /// ប្រសិនបើធាតុត្រូវបានផ្លាស់ប្តូរបន្ទាប់មកភាពស្មុគស្មាញពេលវេលាដ៏អាក្រក់បំផុតគឺ *O*(log(*n*)) បើមិនដូច្នោះទេវាជា *O*(1) ។
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// យករបស់ល្អបំផុតចេញពីគំនរគោលពីរហើយយកវាមកវិញឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # ភាពស្មុគស្មាញពេលវេលា
    ///
    /// ថ្លៃដើមអាក្រក់បំផុតនៃ `pop` លើគំនរដែលមានធាតុ *n* គឺ *O*(log(*n*)) ។
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // សុវត្ថិភាព: !self.is_empty() មានន័យថា self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// រុញធាតុទៅក្នុងគំនរគោលពីរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # ភាពស្មុគស្មាញពេលវេលា
    ///
    /// តម្លៃដែលរំពឹងទុកនៃ `push` ជាមធ្យមទៅលើរាល់ការបញ្ជាទិញដែលអាចធ្វើទៅបាននៃធាតុដែលកំពុងត្រូវបានរុញហើយលើសពីចំនួនដ៏ច្រើនគ្រប់គ្រាន់នៃការរុញច្រានគឺ *O*(1) ។
    ///
    /// នេះគឺជាការចំណាយម៉ែត្រដែលមានអត្ថន័យបំផុតនៅពេលដែលរុញធាតុដែលមិនមាន * រួចហើយនៅក្នុងលំនាំដែលបានតម្រៀប។
    ///
    /// ភាពស្មុគស្មាញនៃពេលវេលាកាន់តែយ៉ាប់យ៉ឺនប្រសិនបើធាតុត្រូវបានជំរុញតាមលំដាប់ឡើង។
    /// ក្នុងករណីដ៏អាក្រក់បំផុតធាតុត្រូវបានជំរុញតាមលំដាប់តម្រៀបតាមលំដាប់លំដោយហើយថ្លៃរំលោះក្នុងមួយដងគឺ *O*(log(*n*)) ប្រឆាំងនឹងគំនរដែលមានផ្ទុកធាតុ *n*។
    ///
    /// ការចំណាយដ៏អាក្រក់បំផុតនៃការហៅទូរស័ព្ទតែមួយដងទៅនឹង `push` គឺ *O*(*n*) ។ករណីអាក្រក់បំផុតកើតឡើងនៅពេលសមត្ថភាពអស់កម្លាំងហើយត្រូវការទំហំ។
    /// ការចំណាយលើទំហំត្រូវបានគេតម្លើងតាមតួលេខមុន។
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // សុវត្ថិភាព: ដោយសារយើងបានរុញធាតុថ្មីវាមានន័យថា
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// ប្រើប្រាស់ `BinaryHeap` និងត្រឡប់ vector តាមលំដាប់ (ascending) ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // សុវត្ថិភាព: `end` ទៅពី `self.len() - 1` ទៅ 1 (រួមទាំង),
            //  ដូច្នេះវាតែងតែជាលិបិក្រមត្រឹមត្រូវក្នុងការចូលប្រើ។
            //  វាមានសុវត្ថិភាពក្នុងការចូលប្រើសន្ទស្សន៍ 0 (ឧទាហរណ៍ `ptr`) ពីព្រោះ
            //  ១ <=ចប់ <self.len() ដែលមានន័យថា self.len()>=២ ។
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // សុវត្ថិភាព: `end` ទៅពី `self.len() - 1` ទៅ 1 (រួមបញ្ចូលទាំងពីរ) ដូច្នេះ៖
            //  0 <១ <=ចប់ <=X០១X, ១ <X០២X ដែលមានន័យថា ០ <ចប់និងបញ្ចប់ <X០០X ។
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // ការអនុវត្តនៃការរអិលនិងរអិលថយក្រោយប្រើប្លុកដែលគ្មានសុវត្ថិភាពក្នុងគោលបំណងដើម្បីផ្លាស់ទីធាតុមួយចេញពី vector (ទុកនៅពីក្រោយរន្ធមួយ) ផ្លាស់ប្តូរនៅតាមបណ្តោយផ្សេងទៀតនិងផ្លាស់ទីធាតុដែលបានដកចេញត្រឡប់ទៅ vector នៅទីតាំងចុងក្រោយនៃប្រហោង។
    //
    // ប្រភេទ `Hole` ត្រូវបានប្រើដើម្បីតំណាងឱ្យរឿងនេះហើយត្រូវប្រាកដថារន្ធត្រូវបានបំពេញនៅចុងបញ្ចប់នៃវិសាលភាពរបស់វាសូម្បីតែនៅលើ panic ។
    // ការប្រើប្រាស់ប្រហោងកាត់បន្ថយកត្តាថេរបើប្រៀបធៀបទៅនឹងការប្រើប្រាស់ប្តូរដែលពាក់ព័ន្ធនឹងចលនាទ្វេដង។
    //
    //
    //
    //

    /// # Safety
    ///
    /// អ្នកទូរស័ព្ទត្រូវធានាថា `pos < self.len()` ។
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // យកតម្លៃនៅ `pos` ហើយបង្កើតប្រហោង។
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលធានាថាផ្លាក <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // សុវត្ថិភាព: hole.pos()> ចាប់ផ្តើម>=0 ដែលមានន័យថា hole.pos()> 0
            //  ដូច្នេះ hole.pos(), 1 មិនអាចដំណើរការបានទេ។
            //  នេះធានាថាមេ <hole.pos() ដូច្នេះវាជាលិបិក្រមត្រឹមត្រូវហើយ!= hole.pos() ។
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // សុវត្ថិភាព: ដូចគ្នានឹងខាងលើ
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// យកធាតុនៅ `pos` ហើយរំកិលចុះក្រោមចំណែកកូនរបស់វាធំ។
    ///
    ///
    /// # Safety
    ///
    /// អ្នកទូរស័ព្ទត្រូវធានាថា `pos < end <= self.len()` ។
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលធានាថា pos <end <= self.len() ។
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // រង្វិលជុំរាតត្បាត: កូន==2 * hole.pos() + 1 ។
        while child <= end.saturating_sub(2) {
            // ប្រៀបធៀបជាមួយកូនធំ ៗ ពីរនាក់ដែលមានសុវត្ថិភាព: កូន <ទីបញ្ចប់, ១ <X០១X និងកូន + ១ ចុងក្រោយ <=X០០X, ដូច្នេះពួកគេមានសន្ទស្សន៍ត្រឹមត្រូវ។
            //
            //  កូន==២ *X០១X + ១!=X០២X និងកូន + ១==២* X០៣X + ២!=X០០X ។
            // FIXME: 2 *hole.pos() + 1 ឬ 2* hole.pos() + 2 អាចលើសចំណុះប្រសិនបើ T ជា ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ប្រសិនបើយើងមានសណ្តាប់ធ្នាប់រួចហើយសូមបញ្ឈប់។
            // សុវត្ថិភាព: កូនឥឡូវជាកូនចាស់ឬកូនចាស់ +១
            //  យើងបានបង្ហាញរួចហើយថាទាំងពីរគឺ <self.len() និង!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // សុវត្ថិភាព: ដូចគ្នានឹងខាងលើ។
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // សុវត្ថិភាព: &&សៀគ្វីខ្លីដែលមានន័យថានៅក្នុង
        //  លក្ខខណ្ឌទី ២ វាជាការពិតរួចទៅហើយដែលកូន==ចប់ ១ <X០០X ។
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // សុវត្ថិភាព: កុមារត្រូវបានបង្ហាញឱ្យឃើញថាជាសន្ទស្សន៍ត្រឹមត្រូវហើយ
            //  កូន==២ * X០១X + ១!=X០០X ។
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// អ្នកទូរស័ព្ទត្រូវធានាថា `pos < self.len()` ។
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // សុវត្ថិភាព: pos <len ត្រូវបានធានាដោយអ្នកទូរស័ព្ទចូលនិង
        //  ជាក់ស្តែង len= self.len() <= self.len() ។
        unsafe { self.sift_down_range(pos, len) };
    }

    /// យកធាតុនៅ `pos` ហើយរំកិលវានៅខាងក្រោមគំនរបន្ទាប់មករំកិលវាទៅទីតាំងរបស់វា។
    ///
    ///
    /// Note: នេះលឿនជាងនៅពេលដែលធាតុត្រូវបានគេដឹងថាមានទំហំធំ/គួរតែខិតទៅជិតបាត។
    ///
    /// # Safety
    ///
    /// អ្នកទូរស័ព្ទត្រូវធានាថា `pos < self.len()` ។
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលធានាថាផ្លាក <self.len() ។
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // រង្វិលជុំរាតត្បាត: កូន==2 * hole.pos() + 1 ។
        while child <= end.saturating_sub(2) {
            // សុវត្ថិភាព: កុមារ <ទីបញ្ចប់, ១ <X០០X និង
            //  កូន + ១ ចុង <=X០០X ដូច្នេះពួកគេមានសន្ទស្សន៍ត្រឹមត្រូវ។
            //  កូន==២ *X០១X + ១!=X០២X និងកូន + ១==២* X០៣X + ២!=X០០X ។
            //
            // FIXME: 2 *hole.pos() + 1 ឬ 2* hole.pos() + 2 អាចលើសចំណុះប្រសិនបើ T ជា ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // សុវត្ថិភាព: ដូចគ្នានឹងខាងលើ
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // សុវត្ថិភាព: កូន==ចប់ ១ <X០០X ដូច្នេះវាជាសន្ទស្សន៍ត្រឹមត្រូវ
            //  និងកូន==2 * hole.pos() + 1!= hole.pos() ។
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // សុវត្ថិភាព: pos គឺជាទីតាំងនៅក្នុងរន្ធហើយត្រូវបានបង្ហាញឱ្យឃើញរួចហើយ
        //  ដើម្បីជាសន្ទស្សន៍ត្រឹមត្រូវ។
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // សុវត្ថិភាព: n ចាប់ផ្តើមពី self.len()/2 ហើយចុះទៅ 0 ។
            //  ករណីតែមួយគត់នៅពេល! (n <self.len()) គឺប្រសិនបើ self.len() ==0 ប៉ុន្តែវាត្រូវបានបដិសេធដោយលក្ខខណ្ឌរង្វិលជុំ។
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// ផ្លាស់ទីធាតុទាំងអស់នៃ `other` ទៅជា `self` ដោយទុកឱ្យ `other` ទទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` ចំណាយប្រតិបត្តិការ O(len1 + len2) និងការប្រៀបធៀបប្រហែល 2 *(len1 + len2) ក្នុងករណីអាក្រក់បំផុតខណៈពេល `extend` ប្រតិបត្តិការ O(len2* log(len1)) និងប្រហែល 1 *len2* log_2(len1) ប្រៀបធៀបក្នុងករណីអាក្រក់បំផុតដោយសន្មតថា len1>= len2 ។
        // សម្រាប់គំនរធំ ៗ ចំណុច crossover លែងដើរតាមហេតុផលនេះហើយត្រូវបានកំណត់ដោយអាណាចក្រ។
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// ត្រឡប់វត្ថុរំកិលដែលទៅយកធាតុតាមលំដាប់គំនរ។
    /// ធាតុដែលបានទាញយកត្រូវបានយកចេញពីគំនរដើម។
    /// ធាតុដែលនៅសេសសល់នឹងត្រូវបានយកចេញនៅពេលមានលំដាប់លំដោយ។
    ///
    /// Note:
    /// * `.drain_sorted()` គឺ *O*(*n*\*log(* n*)); យឺតជាង `.drain()` ច្រើន។
    ///   អ្នកគួរប្រើក្រោយសម្រាប់ករណីភាគច្រើន។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // យកធាតុទាំងអស់ចេញតាមលំដាប់លំដោយ
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// រក្សាទុកតែធាតុដែលបានបញ្ជាក់ដោយអ្នកព្យាករណ៍។
    ///
    /// និយាយម្យ៉ាងទៀតដកធាតុទាំងអស់ `e` ចេញដូចជា `f(&e)` ត្រឡប់ `false` ។
    /// ធាតុត្រូវបានទស្សនាតាមលំដាប់លំដោយ (និងមិនបានបញ្ជាក់) ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ទុកតែលេខគូ
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// ត្រឡប់អ្នកធ្វើទស្សនកិច្ចទស្សនារាល់តម្លៃទាំងអស់នៅក្នុងមូលដ្ឋាន vector តាមលំដាប់លំដោយ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // បោះពុម្ពលេខ ១ ២ ៣,៤ តាមលំដាប់លំដោយ
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// ត្រឡប់វត្ថុរំកិលដែលទៅយកធាតុតាមលំដាប់គំនរ។
    /// វិធីសាស្រ្តនេះប្រើប្រាស់គំនរដើម។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// ត្រឡប់របស់ធំបំផុតនៅក្នុងប្រអប់គោលពីរឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # ភាពស្មុគស្មាញពេលវេលា
    ///
    /// ថ្លៃដើមគឺ *O*(១) ក្នុងករណីអាក្រក់បំផុត។
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// ត្រឡប់ចំនួនធាតុដែលទ្រឹស្តីបទគោលពីរអាចកាន់កាប់បានដោយមិនចាំបាច់បែងចែក។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// រក្សាសមត្ថភាពអប្បបរមាសម្រាប់ធាតុបន្ថែមទៀត `additional` ដែលត្រូវបញ្ចូលក្នុង `BinaryHeap` ដែលបានផ្តល់ឱ្យ។
    /// មិនធ្វើអ្វីទេប្រសិនបើសមត្ថភាពគ្រប់គ្រាន់ហើយ។
    ///
    /// ចំណាំថាអ្នកបែងចែកអាចផ្តល់កន្លែងប្រមូលច្រើនជាងកន្លែងដែលវាស្នើសុំ។
    /// ដូច្នេះសមត្ថភាពមិនអាចពឹងផ្អែកបានតិចតួចទេ។
    /// ចូលចិត្ត [`reserve`] ប្រសិនបើការបញ្ចូល future ត្រូវបានរំពឹងទុក។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីហូរលើស `usize` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// រក្សាទុកសមត្ថភាពយ៉ាងហោចណាស់ធាតុ `additional` បន្ថែមទៀតដែលត្រូវបញ្ចូលក្នុង `BinaryHeap` ។
    /// ការប្រមូលផ្ដុំអាចមានកន្លែងទំនេរច្រើនដើម្បីចៀសវាងការផ្លាស់ទីលំនៅជាញឹកញាប់។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសមត្ថភាពថ្មីហូរលើស `usize` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// បោះបង់ចោលសមត្ថភាពបន្ថែមតាមដែលអាចធ្វើទៅបាន។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// បោះបង់ចោលសមត្ថភាពដែលមានព្រំដែនទាប។
    ///
    /// សមត្ថភាពនឹងនៅតែមានយ៉ាងហោចណាស់យ៉ាងហោចណាស់ទាំងប្រវែងនិងតម្លៃដែលបានផ្គត់ផ្គង់។
    ///
    ///
    /// ប្រសិនបើសមត្ថភាពបច្ចុប្បន្នតិចជាងដែនកំណត់ទាបនេះមិនមែនជាអាយភីទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// ប្រើប្រាស់ `BinaryHeap` និងត្រឡប់ vector មូលដ្ឋានតាមលំដាប់លំដោយ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // នឹងបោះពុម្ពតាមលំដាប់លំដោយខ្លះ
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// ត្រឡប់ប្រវែងនៃគំនរគោលពីរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// ពិនិត្យមើលថាតើគំនរគោលពីរទទេឬអត់។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// សំអាតគំនរគោលពីរ, ត្រឡប់អ្នករំកិលលើធាតុដែលបានដកចេញ។
    ///
    /// ធាតុត្រូវបានដកចេញតាមលំដាប់លំដោយ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ទម្លាក់ធាតុទាំងអស់ពីគំនរគោលពីរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// ប្រហោងតំណាងឱ្យប្រហោងក្នុងចំណែកពោលគឺសន្ទស្សន៍ដែលគ្មានតម្លៃត្រឹមត្រូវ (ព្រោះវាត្រូវបានផ្លាស់ពីឬចម្លង) ។
///
/// នៅក្នុងការធ្លាក់ចុះ, `Hole` នឹងស្តារចំណែកដោយបំពេញទីតាំងរន្ធជាមួយនឹងតម្លៃដែលត្រូវបានដកចេញពីដំបូង។
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// បង្កើត `Hole` ថ្មីនៅសន្ទស្សន៍ `pos` ។
    ///
    /// មិនមានសុវត្ថិភាពទេពីព្រោះ pos ត្រូវតែស្ថិតនៅក្នុងចំណែកទិន្នន័យ។
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SAFE: pos គួរតែស្ថិតនៅក្នុងចំណិត
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុដែលបានយកចេញ។
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// ត្រឡប់ឯកសារយោងទៅធាតុនៅ `index` ។
    ///
    /// មិនមានសុវត្ថិភាពទេពីព្រោះសន្ទស្សន៍ត្រូវតែស្ថិតនៅក្នុងចំណែកទិន្នន័យហើយមិនស្មើនឹងប្រកាស។
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// ផ្លាស់ទីរន្ធទៅទីតាំងថ្មី
    ///
    /// មិនមានសុវត្ថិភាពទេពីព្រោះសន្ទស្សន៍ត្រូវតែស្ថិតនៅក្នុងចំណែកទិន្នន័យហើយមិនស្មើនឹងប្រកាស។
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // បំពេញរន្ធម្តងទៀត
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// ឧបករណ៍រំកិលលើធាតុនៃ `BinaryHeap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយ [`BinaryHeap::iter()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) យកចេញនៅក្នុងការពេញចិត្តនៃ `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// ម្ចាស់ទ្រនាប់ដែលមានម្ចាស់លើធាតុនៃ `BinaryHeap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយ [`BinaryHeap::into_iter()`] (ផ្តល់ដោយ `IntoIterator` trait) ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// ឧបករណ៍វាស់ច្រោះលើធាតុនៃ `BinaryHeap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយ [`BinaryHeap::drain()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// ឧបករណ៍វាស់ច្រោះលើធាតុនៃ `BinaryHeap` ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយ [`BinaryHeap::drain_sorted()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// យកធាតុហ៊ាចេញតាមលំដាប់លំដោយ។
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// បំលែង `Vec<T>` ទៅជា `BinaryHeap<T>` ។
    ///
    /// ការបំលែងនេះកើតឡើងនៅនឹងកន្លែងហើយមានពេលវេលាស្មុគស្មាញ *O*(*n*) ។
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// បំលែង `BinaryHeap<T>` ទៅជា `Vec<T>` ។
    ///
    /// ការបំលែងនេះមិនតម្រូវឱ្យមានចលនាទិន្នន័យឬការបែងចែកទេហើយមានពេលវេលាស្មុគស្មាញ។
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// បង្កើតឧបករណ៍ប្រើប្រាស់ដែលមានន័យថាអ្នកផ្លាស់ប្តូរតម្លៃនីមួយៗចេញពីគំនរគោលពីរតាមលំដាប់លំដោយ។
    /// គំនរគោលពីរមិនអាចត្រូវបានប្រើបន្ទាប់ពីហៅវា។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // បោះពុម្ពលេខ ១ ២ ៣,៤ តាមលំដាប់លំដោយ
    /// for x in heap.into_iter() {
    ///     // x មានប្រភេទ i32 មិនមែន &i32 ទេ
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}