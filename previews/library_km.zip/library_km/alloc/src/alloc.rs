//! ការបែងចែកសតិ APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ទាំងនេះគឺជានិមិត្តសញ្ញាវេទមន្តដើម្បីហៅអ្នកបែងចែកសកល។rustc បង្កើតឱ្យពួកគេហៅ `__rg_alloc` ។ ល។
    // ប្រសិនបើមានគុណលក្ខណៈ `#[global_allocator]` (ពង្រីកកូដដែលបញ្ជាក់ថាម៉ាក្រូបង្កើតមុខងារទាំងនោះ) ឬហៅការអនុវត្តលំនាំដើមនៅក្នុង libstd (`__rdl_alloc` ។ ល។
    //
    // ក្នុង `library/std/src/alloc.rs`) បើមិនដូច្នេះទេ។
    // rustc fork នៃអិលអិលអេមអិមក៏មានករណីពិសេសផងដែរឈ្មោះមុខងារទាំងនេះដើម្បីអាចបង្កើនប្រសិទ្ធភាពដល់ពួកគេដូចជា `malloc`, `realloc` និង `free` រៀងៗខ្លួន។
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// អ្នកបែងចែកអង្គចងចាំសកល។
///
/// ប្រភេទនេះអនុវត្ត [`Allocator`] trait ដោយបញ្ជូនបន្តការហៅទៅអ្នកបែងចែកដែលបានចុះឈ្មោះជាមួយគុណលក្ខណៈ `#[global_allocator]` ប្រសិនបើមានមួយឬលំនាំដើមរបស់ `std` crate ។
///
///
/// Note: ខណៈពេលដែលប្រភេទនេះមិនស្ថិតស្ថេរមុខងារដែលវាផ្តល់ឱ្យអាចចូលប្រើបានតាមរយៈ [free functions in `alloc`](self#functions) ។
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// បែងចែកការចងចាំជាមួយអ្នកបែងចែកជាសកល។
///
/// មុខងារនេះបញ្ជូនបន្តទៅវិធីសាស្ត្រ [`GlobalAlloc::alloc`] របស់អ្នកបែងចែកដែលបានចុះឈ្មោះជាមួយគុណលក្ខណៈ `#[global_allocator]` ប្រសិនបើមានមួយឬលំនាំដើមរបស់ `std` crate ។
///
///
/// មុខងារនេះត្រូវបានគេរំពឹងថានឹងត្រូវបានបដិសេធនៅក្នុងការពេញចិត្តនៃវិធី `alloc` នៃប្រភេទ [`Global`] នៅពេលដែលវានិង [`Allocator`] trait មានស្ថេរភាព។
///
/// # Safety
///
/// មើល [`GlobalAlloc::alloc`] ។
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// ដោះស្រាយការចងចាំជាមួយអ្នកបែងចែកជាសកល។
///
/// មុខងារនេះបញ្ជូនបន្តទៅវិធីសាស្ត្រ [`GlobalAlloc::dealloc`] របស់អ្នកបែងចែកដែលបានចុះឈ្មោះជាមួយគុណលក្ខណៈ `#[global_allocator]` ប្រសិនបើមានមួយឬលំនាំដើមរបស់ `std` crate ។
///
///
/// មុខងារនេះត្រូវបានគេរំពឹងថានឹងត្រូវបានបដិសេធនៅក្នុងការពេញចិត្តនៃវិធី `dealloc` នៃប្រភេទ [`Global`] នៅពេលដែលវានិង [`Allocator`] trait មានស្ថេរភាព។
///
/// # Safety
///
/// មើល [`GlobalAlloc::dealloc`] ។
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// បែងចែកការចងចាំជាមួយអ្នកបែងចែកជាសកល។
///
/// មុខងារនេះបញ្ជូនបន្តទៅវិធីសាស្ត្រ [`GlobalAlloc::realloc`] របស់អ្នកបែងចែកដែលបានចុះឈ្មោះជាមួយគុណលក្ខណៈ `#[global_allocator]` ប្រសិនបើមានមួយឬលំនាំដើមរបស់ `std` crate ។
///
///
/// មុខងារនេះត្រូវបានគេរំពឹងថានឹងត្រូវបានបដិសេធនៅក្នុងការពេញចិត្តនៃវិធី `realloc` នៃប្រភេទ [`Global`] នៅពេលដែលវានិង [`Allocator`] trait មានស្ថេរភាព។
///
/// # Safety
///
/// មើល [`GlobalAlloc::realloc`] ។
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ចាត់ចែងការចងចាំសូន្យដំបូងជាមួយអ្នកបែងចែកសកល។
///
/// មុខងារនេះបញ្ជូនបន្តទៅវិធីសាស្ត្រ [`GlobalAlloc::alloc_zeroed`] របស់អ្នកបែងចែកដែលបានចុះឈ្មោះជាមួយគុណលក្ខណៈ `#[global_allocator]` ប្រសិនបើមានមួយឬលំនាំដើមរបស់ `std` crate ។
///
///
/// មុខងារនេះត្រូវបានគេរំពឹងថានឹងត្រូវបានបដិសេធនៅក្នុងការពេញចិត្តនៃវិធី `alloc_zeroed` នៃប្រភេទ [`Global`] នៅពេលដែលវានិង [`Allocator`] trait មានស្ថេរភាព។
///
/// # Safety
///
/// មើល [`GlobalAlloc::alloc_zeroed`] ។
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // សុវត្ថិភាព: `layout` មិនមានទំហំសូន្យទេ
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // សុវត្ថិភាព: ដូចគ្នានឹង `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // សុវត្ថិភាព: `new_size` គឺមិនមែនសូន្យព្រោះថា `old_size` ធំជាងឬស្មើ `new_size`
            // ដូចដែលបានទាមទារដោយលក្ខខណ្ឌសុវត្ថិភាព។លក្ខខណ្ឌផ្សេងទៀតត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ប្រហែលជាពិនិត្យរក `new_size >= old_layout.size()` ឬអ្វីដែលស្រដៀងគ្នា។
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // សុវត្ថិភាព: ពីព្រោះ `new_layout.size()` ត្រូវតែធំជាងឬស្មើ `old_size`,
            // ទាំងការបែងចែកសតិចាស់និងថ្មីមានសុពលភាពសម្រាប់ការអាននិងសរសេរសម្រាប់ `old_size` បៃ។
            // ដូចគ្នានេះផងដែរដោយសារតែការបែងចែកចាស់មិនទាន់ត្រូវបានដោះស្រាយវាមិនអាចត្រួតលើ `new_ptr` បានទេ។
            // ដូច្នេះការហៅទៅ `copy_nonoverlapping` គឺមានសុវត្ថិភាព។
            // កិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `dealloc` ត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // សុវត្ថិភាព: `layout` មិនមានទំហំសូន្យទេ
            // លក្ខខណ្ឌផ្សេងទៀតត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // សុវត្ថិភាព: គ្រប់លក្ខខណ្ឌទាំងអស់ត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // សុវត្ថិភាព: គ្រប់លក្ខខណ្ឌទាំងអស់ត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // សុវត្ថិភាព: លក្ខខណ្ឌត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // សុវត្ថិភាព: `new_size` គឺមិនមែនសូន្យ។លក្ខខណ្ឌផ្សេងទៀតត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ប្រហែលជាពិនិត្យរក `new_size <= old_layout.size()` ឬអ្វីដែលស្រដៀងគ្នា។
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // សុវត្ថិភាព: ពីព្រោះ `new_size` ត្រូវតែតូចជាងឬស្មើ `old_layout.size()`,
            // ទាំងការបែងចែកសតិចាស់និងថ្មីមានសុពលភាពសម្រាប់ការអាននិងសរសេរសម្រាប់ `new_size` បៃ។
            // ដូចគ្នានេះផងដែរដោយសារតែការបែងចែកចាស់មិនទាន់ត្រូវបានដោះស្រាយវាមិនអាចត្រួតលើ `new_ptr` បានទេ។
            // ដូច្នេះការហៅទៅ `copy_nonoverlapping` គឺមានសុវត្ថិភាព។
            // កិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `dealloc` ត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// អ្នកបែងចែកសម្រាប់អ្នកចង្អុលបង្ហាញតែមួយគត់។
// មុខងារនេះមិនត្រូវចុះខ្សោយឡើយ។ប្រសិនបើវាកើតឡើងនោះកូដ MIR នឹងបរាជ័យ។
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ហត្ថលេខានេះត្រូវតែដូចគ្នានឹង `Box` ដែរបើមិនដូច្នេះទេ ICE នឹងកើតឡើង។
// នៅពេលប៉ារ៉ាម៉ែត្របន្ថែមទៅ `Box` ត្រូវបានបន្ថែម (ដូចជា `A: Allocator`) នេះក៏ត្រូវបន្ថែមនៅទីនេះផងដែរ។
// ឧទាហរណ៍ប្រសិនបើ `Box` ត្រូវបានប្តូរទៅជា `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` មុខងារនេះត្រូវតែប្តូរទៅជា `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ផងដែរ។
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # អ្នកដោះស្រាយកំហុសក្នុងការបែងចែក

extern "Rust" {
    // នេះគឺជានិមិត្តសញ្ញាវេទមន្តដើម្បីហៅអ្នកដោះស្រាយការបែងចែកជាសកល។
    // rustc បង្កើតវាដើម្បីហៅ `__rg_oom` ប្រសិនបើមាន `#[alloc_error_handler]` ឬដើម្បីហៅការអនុវត្តលំនាំដើមខាងក្រោមបើមិនដូច្នេះទេ។
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// បញ្ឈប់កំហុសឬការបរាជ័យនៃការបែងចែកសតិ។
///
/// អ្នកទូរស័ព្ទចូលនៃការបែងចែកសតិ API ដែលមានបំណងចង់បោះបង់ការគណនាក្នុងការឆ្លើយតបទៅនឹងកំហុសនៃការបែងចែកត្រូវបានលើកទឹកចិត្តឱ្យហៅមុខងារនេះជាជាងហៅលេខ `panic!` ដោយផ្ទាល់ឬស្រដៀងគ្នា។
///
///
/// ឥរិយាបទលំនាំដើមនៃមុខងារនេះគឺការបោះពុម្ពសារទៅកំហុសស្តង់ដារនិងបញ្ឈប់ដំណើរការ។
/// វាអាចត្រូវបានជំនួសដោយ [`set_alloc_error_hook`] និង [`take_alloc_error_hook`] ។
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// សម្រាប់តេស្តបែងចែក `std::alloc::handle_alloc_error` អាចត្រូវបានប្រើដោយផ្ទាល់។
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // បានហៅតាមរយៈការបង្កើត `__rust_alloc_error_handler`

    // ប្រសិនបើគ្មាន `#[alloc_error_handler]` ទេ
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ប្រសិនបើមាន `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// ធ្វើឱ្យក្លូនមានឯកទេសទៅក្នុងការចងចាំដែលមិនបានត្រៀមទុកជាមុន។
/// ប្រើដោយ `Box::clone` និង `Rc`/`Arc::make_mut` ។
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ដោយបានបម្រុងទុក *ដំបូង* អាចអនុញ្ញាតឱ្យអ្នកធ្វើឱ្យប្រសើរបង្កើតតម្លៃក្លូននៅនឹងកន្លែងដោយរំលងមូលដ្ឋាននិងផ្លាស់ទី។
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // យើងតែងតែអាចថតចម្លងនៅកន្លែងដោយមិនចាំបាច់ទាក់ទងនឹងតម្លៃក្នុងស្រុក។
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}