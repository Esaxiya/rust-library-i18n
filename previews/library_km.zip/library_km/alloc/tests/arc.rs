use std::any::Any;
use std::cell::RefCell;
use std::cmp::PartialEq;
use std::iter::TrustedLen;
use std::mem;
use std::sync::{Arc, Weak};

#[test]
fn uninhabited() {
    enum Void {}
    let mut a = Weak::<Void>::new();
    a = a.clone();
    assert!(a.upgrade().is_none());

    let mut a: Weak<dyn Any> = a; // Unsizing
    a = a.clone();
    assert!(a.upgrade().is_none());
}

#[test]
fn slice() {
    let a: Arc<[u32; 3]> = Arc::new([3, 2, 1]);
    let a: Arc<[u32]> = a; // Unsizing
    let b: Arc<[u32]> = Arc::from(&[3, 2, 1][..]); // Conversion
    assert_eq!(a, b);

    // ធ្វើលំហាត់ប្រាណ is_dangling() ជាមួយឌីអេសអេស
    let mut a = Arc::downgrade(&a);
    a = a.clone();
    assert!(a.upgrade().is_some());
}

#[test]
fn trait_object() {
    let a: Arc<u32> = Arc::new(4);
    let a: Arc<dyn Any> = a; // Unsizing

    // ធ្វើលំហាត់ប្រាណ is_dangling() ជាមួយឌីអេសអេស
    let mut a = Arc::downgrade(&a);
    a = a.clone();
    assert!(a.upgrade().is_some());

    let mut b = Weak::<u32>::new();
    b = b.clone();
    assert!(b.upgrade().is_none());
    let mut b: Weak<dyn Any> = b; // Unsizing
    b = b.clone();
    assert!(b.upgrade().is_none());
}

#[test]
fn float_nan_ne() {
    let x = Arc::new(f32::NAN);
    assert!(x != x);
    assert!(!(x == x));
}

#[test]
fn partial_eq() {
    struct TestPEq(RefCell<usize>);
    impl PartialEq for TestPEq {
        fn eq(&self, other: &TestPEq) -> bool {
            *self.0.borrow_mut() += 1;
            *other.0.borrow_mut() += 1;
            true
        }
    }
    let x = Arc::new(TestPEq(RefCell::new(0)));
    assert!(x == x);
    assert!(!(x != x));
    assert_eq!(*x.0.borrow(), 4);
}

#[test]
fn eq() {
    #[derive(Eq)]
    struct TestEq(RefCell<usize>);
    impl PartialEq for TestEq {
        fn eq(&self, other: &TestEq) -> bool {
            *self.0.borrow_mut() += 1;
            *other.0.borrow_mut() += 1;
            true
        }
    }
    let x = Arc::new(TestEq(RefCell::new(0)));
    assert!(x == x);
    assert!(!(x != x));
    assert_eq!(*x.0.borrow(), 0);
}

// កូដសាកល្បងខាងក្រោមគឺដូចគ្នាបេះបិទទៅនឹងលេខ `rc.rs` ។
// ចំពោះការថែរក្សាបានល្អប្រសើរយើងកំណត់ឈ្មោះក្លែងក្លាយប្រភេទនេះ។
type Rc<T> = Arc<T>;

const SHARED_ITER_MAX: u16 = 100;

fn assert_trusted_len<I: TrustedLen>(_: &I) {}

#[test]
fn shared_from_iter_normal() {
    // អនុវត្តការអនុវត្តន៍មូលដ្ឋានសម្រាប់អ្នកដែលមិនមែនជាអ្នកគិតគូរ។
    {
        // `Filter` គឺមិនដែល `TrustedLen` ទេព្រោះយើងមិនដឹងថាតើធាតុប៉ុន្មាននឹងត្រូវរក្សាទុកទេ៖
        //
        let iter = (0..SHARED_ITER_MAX).filter(|x| x % 2 == 0).map(Box::new);

        // ការប្រមូលចូលទៅក្នុង `Vec<T>` ឬ `Rc<[T]>` មិនមានអ្វីប្លែកទេ៖
        let vec = iter.clone().collect::<Vec<_>>();
        let rc = iter.collect::<Rc<[_]>>();
        assert_eq!(&*vec, &*rc);

        // ក្លូនបន្តិចហើយទុកឱ្យវាជ្រុះ។
        {
            let _rc_2 = rc.clone();
            let _rc_3 = rc.clone();
            let _rc_4 = Rc::downgrade(&_rc_3);
        }
    } // ទម្លាក់អ្វីដែលមិននៅទីនេះ។
}

#[test]
fn shared_from_iter_trustedlen_normal() {
    // អនុវត្តការអនុវត្តន៍ `TrustedLen` ក្នុងកាលៈទេសៈធម្មតាដែល `size_hint()` ត្រូវគ្នា `(_, Some(exact_len))`.
    //
    {
        let iter = (0..SHARED_ITER_MAX).map(Box::new);
        assert_trusted_len(&iter);

        // ការប្រមូលចូលទៅក្នុង `Vec<T>` ឬ `Rc<[T]>` មិនមានអ្វីប្លែកទេ៖
        let vec = iter.clone().collect::<Vec<_>>();
        let rc = iter.collect::<Rc<[_]>>();
        assert_eq!(&*vec, &*rc);
        assert_eq!(mem::size_of::<Box<u16>>() * SHARED_ITER_MAX as usize, mem::size_of_val(&*rc));

        // ក្លូនបន្តិចហើយទុកឱ្យវាជ្រុះ។
        {
            let _rc_2 = rc.clone();
            let _rc_3 = rc.clone();
            let _rc_4 = Rc::downgrade(&_rc_3);
        }
    } // ទម្លាក់អ្វីដែលមិននៅទីនេះ។

    // សាកល្បងហ្ស៊ីមអេសដើម្បីធ្វើឱ្យប្រាកដថាវាត្រូវបានដោះស្រាយយ៉ាងល្អ។
    {
        let iter = (0..SHARED_ITER_MAX).map(drop);
        let vec = iter.clone().collect::<Vec<_>>();
        let rc = iter.collect::<Rc<[_]>>();
        assert_eq!(&*vec, &*rc);
        assert_eq!(0, mem::size_of_val(&*rc));
        {
            let _rc_2 = rc.clone();
            let _rc_3 = rc.clone();
            let _rc_4 = Rc::downgrade(&_rc_3);
        }
    }
}

#[test]
#[should_panic = "I've almost got 99 problems."]
fn shared_from_iter_trustedlen_panic() {
    // អនុវត្តការអនុវត្តន៍ `TrustedLen` នៅពេល `size_hint()` ផ្គូផ្គង `(_, Some(exact_len))` ប៉ុន្តែកន្លែងដែល `.next()` ធ្លាក់ចុះមុនការនិយាយចុងក្រោយ។
    //
    let iter = (0..SHARED_ITER_MAX).map(|val| match val {
        98 => panic!("I've almost got 99 problems."),
        _ => Box::new(val),
    });
    assert_trusted_len(&iter);
    let _ = iter.collect::<Rc<[_]>>();

    panic!("I am unreachable.");
}

#[test]
fn shared_from_iter_trustedlen_no_fuse() {
    // អនុវត្តអនុវត្ត `TrustedLen` ពេល `size_hint()` ផ្គូផ្គង `(_, Some(exact_len))` ប៉ុន្តែជាកន្លែងដែលការនិយាយឡើងវិញមិនមានឥរិយាបទក្នុងលក្ខណៈបាន fused មួយ។
    //
    struct Iter(std::vec::IntoIter<Option<Box<u8>>>);

    unsafe impl TrustedLen for Iter {}

    impl Iterator for Iter {
        fn size_hint(&self) -> (usize, Option<usize>) {
            (2, Some(2))
        }

        type Item = Box<u8>;

        fn next(&mut self) -> Option<Self::Item> {
            self.0.next().flatten()
        }
    }

    let vec = vec![Some(Box::new(42)), Some(Box::new(24)), None, Some(Box::new(12))];
    let iter = Iter(vec.into_iter());
    assert_trusted_len(&iter);
    assert_eq!(&[Box::new(42), Box::new(24)], &*iter.collect::<Rc<[_]>>());
}