// rsbegin.o និង rsend.o គឺជាអ្វីដែលគេហៅថា "compiler runtime startup objects" ។
// ពួកគេមានកូដដែលត្រូវការដើម្បីចាប់ផ្ដើមត្រឹមត្រូវពេលរត់ចងក្រង។
//
// នៅពេលដែលរូបភាពដែលអាចប្រតិបត្តិបានឬ dylib ត្រូវបានភ្ជាប់កូដដែលអ្នកប្រើនិងបណ្ណាល័យទាំងអស់គឺ "sandwiched" រវាងឯកសារទាំងពីរនេះវត្ថុ, ដូច្នេះកូដឬទិន្នន័យពី rsbegin.o ក្លាយជាលើកដំបូងនៅក្នុងផ្នែករៀងនៃរូបភាព, ចំណែកឯលេខកូដនិងទិន្នន័យពី rsend.o ក្លាយទៅជាអ្នកដែលចុងក្រោយ។
// បែបផែននេះអាចត្រូវបានប្រើដើម្បីដាក់និមិត្តសញ្ញានៅដើមឬនៅចុងបញ្ចប់នៃផ្នែកក៏ដូចជាបញ្ចូលបឋមកថាឬបាតកថាដែលត្រូវការ។
//
// ចំណាំថាចំណុចធាតុម៉ូឌុលពិតប្រាកដទីតាំងស្ថិតនៅក្នុងវត្ថុដែលបានពេលចាប់ផ្ដើមពេលរត់ C (ជាធម្មតាគេហៅថា `crtX.o`), ដែលបន្ទាប់មកសំអាងចាប់ផ្ដើម Callbacks នៃសមាសភាគពេលរត់ផ្សេងទៀត (ដែលបានចុះឈ្មោះតាមរយៈការនៅឡើយទេផ្នែករូបភាពពិសេសផ្សេងទៀត) ។
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // សម្គាល់ការចាប់ផ្តើមនៃផ្នែកជង់ដែលមិនភ្ជាប់ផ្នែកព័ត៌មាន
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // ទំហំមួយសម្រាប់ការរក្សាផ្ទៃក្នុងសៀវភៅរបស់ unwind ។
    // នេះត្រូវបានកំណត់ជា `struct object` ជា $ GCC/unwind-dw2-fde.h ។
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // ផ្តាច់ព័ត៌មានពី registration/deregistration ។
    // មើលឯកសារនៃ libpanic_unwind ។
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // ចុះឈ្មោះចុះបញ្ជីព័ត៌មានដែលមិនចង់បានស្តីពីការចាប់ផ្តើមម៉ូឌុល
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // មិនចុះបញ្ជីនៅពេលបិទ
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // ការចុះឈ្មោះតាមអ៊ិនធឺរណែត init/uninit ជាក់លាក់របស់ MinGW
    pub mod mingw_init {
        // វត្ថុពេលចាប់ផ្ដើម MinGW របស់ (crt0.o/dllcrt0.o) នឹងហៅផលិតជាសកលក្នុងផ្នែក .ctors និង .dtors នៅពេលចាប់ផ្ដើមនិងចេញ។
        // ក្នុងករណី DLLs នេះត្រូវបានធ្វើនៅពេលដែលឌីអេសអិលផ្ទុកនិងមិនផ្ទុក។
        //
        // linker នឹងតម្រៀបផ្នែកដែលធានាថា Callbacks របស់យើងដែលមានទីតាំងស្ថិតនៅចុងបញ្ចប់នៃបញ្ជីនេះ។
        // ចាប់តាំងពីអ្នកសាងសង់ត្រូវបានដំណើរការតាមលំដាប់បញ្ច្រាសនេះធានាថាការហៅត្រឡប់មកវិញរបស់យើងគឺជាមនុស្សដំបូងនិងចុងក្រោយដែលត្រូវបានសម្លាប់។
        //
        //

        #[link_section = ".ctors.65535"] // វេជ្ជបណ្ឌិត។ *: ការហៅត្រឡប់វិញចាប់ផ្តើមរបស់ស៊ី
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors *: ។ Callbacks បញ្ចប់គ
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}