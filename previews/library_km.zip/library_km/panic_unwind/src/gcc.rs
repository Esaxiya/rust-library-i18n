//! ការអនុវត្តន៍ panics គាំទ្រដោយ libgcc/libunwind (នៅក្នុងសំណុំបែបបទមួយចំនួន) ។
//!
//! ចំពោះសាវតាស្តីពីការដោះស្រាយករណីលើកលែងនិងការដាក់ជង់គ្នាសូមមើល "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) និងឯកសារភ្ជាប់ពីវា។
//! ទាំងនេះគឺជាការល្អអាន:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## សេចក្តីសង្ខេបខ្លី
//!
//! ការដោះស្រាយករណីលើកលែងកើតឡើងជាពីរដំណាក់កាលគឺដំណាក់កាលស្វែងរកនិងដំណាក់កាលសម្អាត។
//!
//! នៅក្នុងដំណាក់កាលទាំងពីរលែងមានបញ្ហាស៊ុមជង់បានដើរពីកំពូលទៅបាតដោយប្រើប្រាស់ទិន្នន័យពីផ្នែកធូររលុងស៊ុមជង់នៃម៉ូឌុលដែលបានដំណើរការបច្ចុប្បន្នរបស់ ("module" នៅទីនេះសំដៅទៅលើម៉ូឌុលមួយប្រព័ន្ធប្រតិបត្តិការពោលគឺជាការដែលអាចប្រតិបត្តិបានឬបណ្ណាល័យថាមវន្តមួយ) ។
//!
//!
//! សម្រាប់ស៊ុមជង់នីមួយៗវាទាក់ទងនឹង "personality routine" ដែលមានអាស័យដ្ឋានត្រូវបានរក្សាទុកនៅក្នុងផ្នែកព័ត៌មានដែលមិនចង់បាន។
//!
//! នៅក្នុងដំណាក់កាលស្វែងរកការងារនៃទម្លាប់បុគ្គលិកលក្ខណៈមួយនេះគឺដើម្បីពិនិត្យមើលវត្ថុករណីលើកលែងត្រូវបានបដិសេធចោលនិងដើម្បីសម្រេចថាតើវាគួរតែត្រូវចាប់បាននៅក្នុងស៊ុមជង់នោះ។នៅពេលស៊ុមកម្មវិធីដោះស្រាយត្រូវបានកំណត់អត្តសញ្ញាណ, តំណាក់កាលការសម្អាតចាប់ផ្តើម។
//!
//! នៅក្នុងដំណាក់កាលបោសសំអាតឧបករណ៍លាងចានបានអំពាវនាវដល់បុគ្គលិកលក្ខណៈនីមួយៗម្តងទៀត។
//! នៅពេលនេះវាសម្រេចចិត្តថាតើលេខកូដសម្អាតណាមួយ (ប្រសិនបើមាន) ចាំបាច់ត្រូវដំណើរការសម្រាប់ស៊ុមជង់បច្ចុប្បន្ន។ប្រសិនបើដូច្នេះវត្ថុបញ្ជាត្រូវបានផ្ទេរទៅ branch ពិសេសនៅក្នុងតួមុខងារគឺ "landing pad" ដែលហៅអ្នកបំផ្លាញបំផ្លាញការចងចាំ។ ល។
//! នៅចុងបញ្ចប់នៃបន្ទះចុះចត, ការត្រួតពិនិត្យត្រូវបានផ្ទេរមកវិញដើម្បី unwind និងបន្តដកចេញ។
//!
//! នៅពេលជង់បានចុះ unwound ទៅកម្រិតស៊ុមកម្មវិធីដោះស្រាយការឈប់ដកចេញនិងបុគ្គលិកលក្ខណៈចុងក្រោយនេះការផ្លាស់ប្តូរទម្រង់ការគ្រប់គ្រងទៅប្លុកផលនេសាទនេះ។
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// គ្រឿងសម្គាល់ថ្នាក់លើកលែងរបស់ Rust ។
// ការនេះត្រូវបានប្រើដោយទម្រង់បុគ្គលិកលក្ខណៈដើម្បីកំណត់ថាតើមានករណីលើកលែងត្រូវបានគ្រវែងដោយការរត់របស់ខ្លួនផ្ទាល់។
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ\0 RUST-អ្នកលក់ភាសា
    0x4d4f5a_00_52555354
}

// ចុះលេខសម្គាល់ត្រូវបានលើកពី TargetLowering::getExceptionPointerRegister() LLVM និង TargetLowering::getExceptionSelectorRegister() សម្រាប់ស្ថាបត្យកម្មគ្នា, បន្ទាប់មកគូសផែនទីទៅលេខបញ្ជីមនុស្សតឿតាមរយៈតុនិយមន័យការចុះបញ្ជី (ជាធម្មតា<arch>ចុះឈ្មោះក្នុងអ៊ិនធឺរណែត។ ស្វែងរក "DwarfRegNum") ។
//
// សូមមើលផងដែរ http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register ។
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // អេឡិចត្រូនិចអេចឌីអេច

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// លេខកូដខាងក្រោមគឺផ្អែកលើទម្លាប់បុគ្គលិកលក្ខណៈ C និង C++ របស់ GCC ។សម្រាប់ជាឯកសារយោងសូមមើល៖
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI ទម្លាប់បុគ្គលិកលក្ខណៈ។
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS ប្រើទម្រង់ការជំនួសជំនួសព្រោះវាប្រើការបង្រួម SjLj ។
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM នឹងដាននៅលើទម្លាប់បុគ្គលិកលក្ខណៈហៅរដ្ឋ==_US_VIRTUAL_UNWIND_FRAME ជាមួយ |_US_FORCE_UNWIND ។
                // ក្នុងករណីទាំងនោះយើងចង់បន្តជង់បន្តគ្នាបើមិនដូច្នោះទេដានទាំងអស់របស់យើងនឹងបញ្ចប់នៅ __rust_try
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // នេះ unwind សន្មត់ថា _Unwind_Context មនុស្សតឿដែលទទួលបានអ្វីដែលដូចជាមុខងារនិងព្រួញ LSDA, ទោះជាយ៉ាងណា ARM បាន EHABI ដាក់ពួកវាទៅក្នុងវត្ថុដែលជាករណីលើកលែងនោះ។
            // ដើម្បីរក្សាមុខងារដូចហត្ថលេខា _Unwind_GetLanguageSpecificData() ដែលយកតែព្រួញបរិបទទម្រង់ការបុគ្គលិកលក្ខណៈ GCC ទុកដាក់និងសន្សំព្រួញមួយដើម្បី exception_object នៅក្នុងបរិបទដោយប្រើទីតាំងបម្រុងទុកសម្រាប់របស់ ARM "scratch register" (r12) ។
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... វិធីសាស្រ្តមួយមានមូលដ្ឋានលើគោលការណ៍ជាច្រើនទៀតនឹងត្រូវបានផ្តល់នូវនិយមន័យពេញលេញនៃ _Unwind_Context របស់លោកនៅក្នុងការចង ARM របស់យើងនិងការប្រមូលយក libunwind ទិន្នន័យដែលត្រូវការពីទីនោះដោយផ្ទាល់ដោយឆ្លងកាត់មុខងារភាពឆបគ្នាមនុស្សតឿ។
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // EHABI តម្រូវឱ្យមានទម្លាប់បុគ្គលិកលក្ខណៈដើម្បីធ្វើបច្ចុប្បន្នភាពតម្លៃ SP នៅក្នុងឃ្លាំងសម្ងាត់នៃវត្ថុលើកលែង។
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // នៅលើ ARM EHABI ទម្លាប់បុគ្គលិកលក្ខណៈទទួលខុសត្រូវចំពោះការបង្រួមស៊ុមជង់តែមួយមុនពេលត្រឡប់មកវិញ (ARM EHABI Sec) ។
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // បានកំណត់ជា libgcc
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // ទម្លាប់បុគ្គលិកលក្ខណៈលំនាំដើមដែលត្រូវបានប្រើដោយផ្ទាល់នៅលើគោលដៅបំផុតនិងដោយប្រយោលនៅលើ Windows x86_64 តាមរយៈសេះ។
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // នៅលើគោលដៅ x86_64 MinGW យន្តការដកចេញនេះគឺទោះជាយ៉ាងណាទិន្នន័យកម្មវិធីដោះស្រាយសេះនេះលែងមានបញ្ហា (អាកា LSDA) ប្រើការអ៊ិនកូដ GCC-ឆបគ្នា។
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // ទម្លាប់បុគ្គលិកលក្ខណៈសម្រាប់ភាគច្រើននៃគោលដៅរបស់យើង។
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // អាសយដ្ឋានត្រឡប់មកវិញបានចង្អុលការបង្រៀនកន្លងមក 1 បៃហៅទូរស័ព្ទដែលអាចមាននៅក្នុងជួរ IP ដែលបន្ទាប់ក្នុងតារាងជួរ LSDA ។
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ស៊ុមចុះឈ្មោះ info unwind
//
// រូបភាពរបស់ម៉ូឌុលនីមួយៗមានផ្នែកព័ត៌មានដែលមិនភ្ជាប់ស៊ុម (ជាទូទៅ ".eh_frame") ។នៅពេលម៉ូឌុលគឺជាការ loaded/unloaded ចូលទៅក្នុងដំណើរការ, លែងមានបញ្ហាត្រូវតែត្រូវបានជូនដំណឹងអំពីទីតាំងនៃផ្នែកនៅក្នុងការចងចាំនេះ។វិធីសាស្រ្តនៃការសម្រេចថាការប្រែប្រួលដោយវេទិកានេះ។
// នៅថ្ងៃខ្លះ (ឧ, Linux) ធូររលុងអាចរកឃើញផ្នែក info លែងមានបញ្ហានៅលើខ្លួនវា (ដោយថាមវន្តរាប់ម៉ូឌុលត្រូវបានផ្ទុកបច្ចុប្បន្នតាមរយៈ dl_iterate_phdr() API and finding their ".eh_frame" sections) ហើយអ្នកខ្លះទៀតដូចជា Windows តម្រូវឱ្យម៉ូឌុលដើម្បីចុះឈ្មោះ info ធូររលុងរបស់ពួកគេផ្នែកយ៉ាងសកម្មតាមរយៈការ unwind API ។
//
//
// ម៉ូឌុលនេះកំណត់និមិត្តសញ្ញាពីរដែលត្រូវបានយោងហើយបានហៅពី rsbegin.rs ដើម្បីចុះឈ្មោះពរបស់យើងជាមួយពេលរត់ GCC ។
// ការអនុវត្តនៃការបង្រួមជង់គឺ (សម្រាប់ពេលនេះ) ពន្យាពេលទៅ libgcc_eh ទោះយ៉ាងណា Rust crates ប្រើចំនុចបញ្ចូល Rust ជាក់លាក់ទាំងនេះដើម្បីជៀសវាងការប៉ះទង្គិចសក្តានុពលជាមួយពេលវេលារត់ GCC ណាមួយ។
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}