//! លែងមានបញ្ហា panics សម្រាប់ Miri ។
use alloc::boxed::Box;
use core::any::Any;

// ប្រភេទនៃបន្ទុកដែលម៉ាស៊ីនម៉ីរីរីករាលដាលតាមរយៈការបង្រួបបង្រួមសម្រាប់យើង។
// ត្រូវមានទំហំទ្រនិច។
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri បានផ្តល់មុខងារខាងក្រៅដើម្បីចាប់ផ្តើមការដកចេញ។
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // បន្ទុកដែលយើងបញ្ជូនទៅ `miri_start_panic` ពិតជាអាគុយម៉ង់ដែលយើងទទួលបាននៅក្នុង `cleanup` ខាងក្រោម។
    // ដូច្នេះយើងគ្រាន់តែលើកវាម្តងដើម្បីទទួលបានអ្វីមួយដែលមានទំហំទ្រនិច។
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // រកឃើញមូលដ្ឋានគ្រឹះ `Box` ។
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}