//! ការអនុវត្ត panics តាមរយៈការដាក់ជង់
//!
//! crate អនុវត្តនេះគឺជាការមួយនៃការ panics ក្នុង Rust ដោយប្រើយន្តការដកចេញ "most native" ជង់នៃវេទិកានេះត្រូវបានចងក្រងសម្រាប់។
//! បច្ចុប្បន្ននេះត្រូវបានបែងចែកជាបីដាក់ធុង៖
//!
//! 1. គោលដៅ MSVC ប្រើ SEH នៅក្នុងឯកសារ `seh.rs` ។
//! 2. Emscripten ប្រើករណីលើកលែង C++ ក្នុងឯកសារ `emcc.rs` ។
//! 3. គោលដៅផ្សេងទៀតប្រើ libunwind/libgcc ក្នុងឯកសារ `gcc.rs` ។
//!
//! ឯកសារបន្ថែមអំពីការអនុវត្តនីមួយៗអាចរកបាននៅក្នុងម៉ូឌុលរៀងៗខ្លួន។
//!
//!

#![no_std]
#![unstable(feature = "panic_unwind", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![feature(core_intrinsics)]
#![feature(int_bits_const)]
#![feature(lang_items)]
#![feature(nll)]
#![feature(panic_unwind)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(unwind_attributes)]
#![feature(abi_thiscall)]
#![feature(rustc_attrs)]
#![feature(raw)]
#![panic_runtime]
#![feature(panic_runtime)]
// `real_imp` មិនត្រូវបានប្រើជាមួយមីរីដូច្នេះការព្រមានស្ងាត់ស្ងៀម។
#![cfg_attr(miri, allow(dead_code))]

use alloc::boxed::Box;
use core::any::Any;
use core::panic::BoxMeUp;

cfg_if::cfg_if! {
    if #[cfg(target_os = "emscripten")] {
        #[path = "emcc.rs"]
        mod real_imp;
    } else if #[cfg(target_os = "hermit")] {
        #[path = "hermit.rs"]
        mod real_imp;
    } else if #[cfg(target_env = "msvc")] {
        #[path = "seh.rs"]
        mod real_imp;
    } else if #[cfg(any(
        all(target_family = "windows", target_env = "gnu"),
        target_os = "psp",
        target_family = "unix",
        all(target_vendor = "fortanix", target_env = "sgx"),
    ))] {
        // វត្ថុចាប់ផ្តើមដំណើរការរបស់ Rust ពឹងផ្អែកលើនិមិត្តសញ្ញាទាំងនេះដូច្នេះធ្វើឱ្យវាក្លាយជាសាធារណៈ។
        #[cfg(all(target_os="windows", target_arch = "x86", target_env="gnu"))]
        pub use real_imp::eh_frame_registry::*;
        #[path = "gcc.rs"]
        mod real_imp;
    } else {
        // គោលដៅដែលមិនគាំទ្រការបង្រួបបង្រួម។
        // - arch=wasm32
        // - os=គ្មាន (គោលដៅ "bare metal")
        // - os=uefi
        // - nvptx64-nvidia-cuda
        // - arch=avr
        #[path = "dummy.rs"]
        mod real_imp;
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        // ប្រើពេលរត់មីរី។
        // យើងនៅតែត្រូវការផងដែរដើម្បីផ្ទុកពេលរត់ធម្មតាខាងលើជាការ rustc រំពឹងថាធាតុឡង់មួយចំនួនពីទីនោះនឹងត្រូវបានកំណត់។
        //
        #[path = "miri.rs"]
        mod imp;
    } else {
        // ប្រើពេលវេលារត់ពិត។
        use real_imp as imp;
    }
}

extern "C" {
    /// Handler នៅក្នុង libstd ហៅថានៅពេលវត្ថុ panic ត្រូវបានទម្លាក់នៅខាងក្រៅ `catch_unwind` ។
    ///
    fn __rust_drop_panic() -> !;

    /// Handler នៅក្នុង libstd ត្រូវបានគេហៅថានៅពេលដែលមានការលើកលែងពីបរទេស។
    fn __rust_foreign_exception() -> !;
}

mod dwarf;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(payload: *mut u8) -> *mut (dyn Any + Send + 'static) {
    Box::into_raw(imp::cleanup(payload))
}

// ចំណុចចូលសម្រាប់ការលើកលែងមួយ, គ្រាន់តែប្រតិភូទៅនឹងការអនុវត្តវេទិកាជាក់លាក់។
//
#[rustc_std_internal_symbol]
#[unwind(allowed)]
pub unsafe extern "C" fn __rust_start_panic(payload: *mut &mut dyn BoxMeUp) -> u32 {
    let payload = Box::from_raw((*payload).take_box());

    imp::panic(payload)
}