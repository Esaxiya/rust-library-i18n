//! ការបង្រួបបង្រួមសម្រាប់គោលដៅ * ឥសី។
//!
//! ឥលូវនេះយើងមិនគាំទ្ររឿងនេះទេដូច្នេះនេះគ្រាន់តែជាស្តុបប៉ុណ្ណោះ។

use alloc::boxed::Box;
use core::any::Any;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}