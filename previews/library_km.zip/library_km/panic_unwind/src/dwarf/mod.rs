//! ឧបករណ៍ប្រើប្រាស់សម្រាប់វិភាគស្ទ្រីមទិន្នន័យដែលបានអ៊ិនគ្រីប DWARF ។
//! សូមមើល <http://www.dwarfstd.org>, ស្តង់ដារ DWARF-4, ផ្នែកទី 7, "Data Representation"
//!

// ម៉ូឌុលនេះត្រូវបានប្រើដោយ x86_64-កុំព្យូទ័របង្អួច-gnu សម្រាប់ពេលឥឡូវនេះទេប៉ុន្តែយើងត្រូវការចងក្រងវាគ្រប់ទីកន្លែងដើម្បីតំរែតំរង់ជៀសវាង។
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // ស្ទ្រីមមនុស្សតឿត្រូវបានដាក់, ដូច្នេះ eg, u32 នឹងមិនចាំបាច់ត្រូវបានតម្រឹមនៅលើព្រំដែន 4 បៃ។
    // នេះអាចបណ្ដាលឱ្យមានបញ្ហានៅលើវេទិកាជាមួយនឹងតម្រូវការយ៉ាងតឹងរឹងតម្រឹម។
    // ដោយការរុំទិន្នន័យនៅក្នុងរចនាសម្ព័ន្ធ "packed" យើងកំពុងប្រាប់អ្នកខាងក្រោយឱ្យបង្កើតលេខកូដ "misalignment-safe" ។
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ការអ៊ិនកូដ ULEB128 និង SLEB128 ត្រូវបានកំណត់ក្នុងផ្នែកទី 7.6, "Variable Length Data" ។
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}