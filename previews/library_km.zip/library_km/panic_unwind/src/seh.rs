//! Windows SEH
//!
//! នៅថ្ងៃទី Windows (បច្ចុប្បន្នតែនៅលើ MSVC), ករណីលើកលែងលំនាំដើមយន្តការដោះស្រាយត្រូវដោះស្រាយ (SEH) Structured ករណីលើកលែង។
//! នេះគឺជាការខុសគ្នាខ្លាំងជាងការដោះស្រាយមនុស្សតឿដែលមានមូលដ្ឋានករណីលើកលែង (ឧ, តើមានអ្វីផ្សេងទៀតដែលប្រើប្រព័ន្ធប្រតិបត្តិការ unix) នៅក្នុងលក្ខខណ្ឌនៃការអន្ដរជាតិចងក្រងដូច្នេះ LLVM ត្រូវបានទាមទារឱ្យមានកិច្ចព្រមព្រៀងល្អមួយនៃការគាំទ្របន្ថែមសម្រាប់សេះ។
//!
//! ជាសង្ខេប, តើមានអ្វីកើតឡើងនៅទីនេះគឺ:
//!
//! 1. មុខងារ `panic` ហៅមុខងារ Windows ស្ដង់ដារ `_CxxThrowException` ទៅបោះ C++ -ដូចករណីលើកលែងដែលបង្កឱ្យដំណើរការដកចេញនេះ។
//! 2.
//! បន្ទះចុះចតទាំងអស់ដែលបានបង្កើតដោយកម្មវិធីចងក្រងប្រើមុខងារបុគ្គលិកលក្ខណៈ `__CxxFrameHandler3` មុខងារក្នុង CRT មួយនិងលេខកូដដកចេញនេះក្នុង Windows នឹងប្រើមុខងារបុគ្គលិកលក្ខណៈកូដនេះដើម្បីប្រតិបត្តិការសម្អាតទាំងអស់នៅលើជង់។
//!
//! 3. រាល់ការហៅទូរស័ព្ទដែលបង្កើតដោយអ្នកចងក្រងទៅ `invoke` មានបន្ទះចុះចតដែលបានកំណត់ជាការណែនាំ `cleanuppad` LLVM ដែលបង្ហាញពីការចាប់ផ្តើមនៃទម្លាប់នៃការសម្អាត។
//! បុគ្គលិកលក្ខណៈនេះ (នៅក្នុងជំហានទី 2 ដែលបានកំណត់ក្នុង CRT) គឺទទួលខុសត្រូវចំពោះការរត់ទម្រង់ការសម្អាតនេះ។
//! 4. ទីបំផុតលេខកូដ "catch" ក្នុងចាំបាច់ `try` (បានបង្កើតដោយការចងក្រង) ត្រូវបានប្រតិបត្តិនិងបង្ហាញពីការត្រួតពិនិត្យដែលគួរតែត្រឡប់មកវិញទៅ Rust ។
//! នេះត្រូវបានធ្វើឡើងតាមរយៈ `catchswitch` បូកនឹងការណែនាំ `catchpad` ក្នុងលក្ខខណ្ឌអិលអិលអិមអិលអិលអិលទីបំផុតត្រលប់មកវិញនូវការគ្រប់គ្រងធម្មតាទៅកម្មវិធីដោយមានការណែនាំ `catchret` ។
//!
//! ភាពខុសគ្នាពីការគ្រប់គ្រងជាក់លាក់មួយចំនួនលើកលែងតែ gcc ដែលមានមូលដ្ឋានគឺ:
//!
//! * Rust មិនមានមុខងារបុគ្គលិកលក្ខណៈផ្ទាល់ខ្លួនទេវាផ្ទុយទៅវិញ *ជានិច្ច*`__CxxFrameHandler3` ។លើសពីនេះទៀតគ្មានការច្រោះបន្ថែមត្រូវបានអនុវត្តទេដូច្នេះយើងបញ្ចប់ការចាប់យក C++ ណាដែលកើតឡើងដើម្បីមើលទៅដូចជាប្រភេទដែលយើងបោះចោល។
//! ចំណាំថាការបោះករណីលើកលែងមួយចូលទៅក្នុង Rust គឺជាឥរិយាបទដែលមិនបានកំណត់ទេដូច្នេះនេះគួរតែត្រូវផាកពិន័យ។
//! * យើងមានទិន្នន័យមួយចំនួនដើម្បីបញ្ជូនឆ្លងកាត់ព្រំដែនដែលមិនមានមនុស្សជាច្រើនជាពិសេស `Box<dyn Any + Send>` ។ដូចគ្នានឹងការលើកលែងមនុស្សតឿចំណុចចង្អុលទាំងពីរនេះត្រូវបានរក្សាទុកជាបន្ទុកនៅក្នុងករណីលើកលែងដោយខ្លួនវាផ្ទាល់។
//! នៅថ្ងៃទី MSVC, ទោះជាយ៉ាងណា, វាមានតម្រូវការសម្រាប់ការបែងចែកគំនរថ្មបន្ថែមនោះទេដោយសារជង់ការហៅត្រូវបានបម្រុងទុកខណៈពេលដែលមុខងារតម្រងត្រូវបានគេសម្លាប់។
//! នេះមានន័យថាការចង្អុលបង្ហាញនេះត្រូវបានអនុម័តដោយផ្ទាល់ទៅ `_CxxThrowException` ដែលបន្ទាប់មកត្រូវបានរកឃើញនៅក្នុងមុខងារតម្រងនឹងត្រូវបានសរសេរទៅក្នុងស៊ុមជង់នៃចាំបាច់ `try` ។
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // តម្រូវការនេះបានក្លាយទៅជាជម្រើសមួយដោយសារតែយើងបានចាប់ករណីលើកលែងដោយសេចក្ដីយោងនិងការរបស់វាត្រូវបានប្រតិបត្តិបំផ្លាញដោយ C++ ពេលវេលារត់។
    // នៅពេលដែលយើងយកប្រអប់ចេញពីករណីលើកលែងនោះយើងត្រូវចាកចេញពីករណីលើកលែងនៅក្នុងរដ្ឋដែលមានសុពលភាពសម្រាប់ការរត់របស់ខ្លួនដើម្បីបំផ្លាញពីរដងទម្លាក់ដោយគ្មានប្រអប់នេះ។
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// ដំបូងគេនិយមន័យប្រភេទក្រុមទាំងមូល។មាន oddities មួយចំនួនដែលជាក់លាក់នៅទីនេះវេទិកា, និងជាច្រើនដែលត្រូវបានចម្លងគ្រាន់តែទាំងស្រុងពី LLVM មួយ។គោលបំណងនៃការទាំងអស់នេះគឺដើម្បីអនុវត្តមុខងារដូចខាងក្រោមតាមរយៈការហៅ `panic` ទៅ `_CxxThrowException` មួយ។
//
// មុខងារនេះត្រូវការអំណះអំណាងពីរ។នេះជាលើកដំបូងគឺទ្រនិចកណ្ដុរទៅទិន្នន័យដែលយើងកំពុងឆ្លងកាត់នៅ, ដែលនៅក្នុងករណីនេះគឺវត្ថុ trait របស់យើង។ស្អាតងាយស្រួលរក!ទោះយ៉ាងណាបន្ទាប់គឺស្មុគស្មាញជាង។
// នេះគឺជាទស្សន៍ទ្រនិចទៅនឹងរចនាសម្ព័ន្ធ `_ThrowInfo` មួយហើយវាជាទូទៅត្រូវបានគ្រាន់តែមានគោលបំណងដើម្បីគ្រាន់តែរៀបរាប់អំពីករណីលើកលែងដែលកំពុងត្រូវបានបដិសេធចោល។
//
// បច្ចុប្បន្ននិយមន័យនៃប្រភេទនេះ [1] នេះគឺជាការមានរោមតិចតួចនិង oddity សំខាន់ (និងមានភាពខុសគ្នាពីអត្ថបទលើបណ្តាញ) ត្រូវបានថានៅលើ 32 ប៊ីតចង្អុលបង្ហាញនេះគឺជាការចង្អុលបង្ហាញប៉ុន្តែនៅលើ 64 ប៊ីតចង្អុលបង្ហាញមួយត្រូវបានបញ្ជាក់ជាអុហ្វសិត 32 ប៊ីតពី ជានិមិត្តរូប `__ImageBase` ។
//
// ម៉ាក្រូ `ptr_t` និង `ptr!` ក្នុងម៉ូឌុលដូចខាងក្រោមត្រូវបានប្រើដើម្បីបង្ហាញនេះ។
//
// ប្រភេទនិយមន័យនៃផ្ទាំងសិលាផងដែរខាងក្រោមនេះយ៉ាងជិតស្និទ្ធអ្វីដែល LLVM បញ្ចេញសម្រាប់ការតម្រៀបនៃប្រតិបត្តិការនេះ។ឧទាហរណ៍ប្រសិនបើអ្នកបានចងក្រង C នេះលេខកូដនៅលើ MSVC++ និងបញ្ចេញ LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ចាត់ទុកជាមោឃៈ foo() { rust_panic a = {0, 1};
//          បោះមួយ;}
//
// នោះជាអ្វីដែលយើងកំពុងធ្វើត្រាប់តាម។ភាគច្រើននៃតម្លៃថេរខាងក្រោមត្រូវបានចម្លងពីអិលអិលអិមអិម។
//
// នៅក្នុងករណីណា, រចនាសម្ព័ន្ធទាំងនេះត្រូវបានសាងសង់ទាំងអស់នៅក្នុងលក្ខណៈស្រដៀងគ្នាមួយហើយវាគ្រាន់តែបន្តិចបរិយាយសម្រាប់យើង។
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// ចំណាំថាយើងមានចេតនាមិនអើពើឈ្មោះច្បាប់ mangling នៅទីនេះ: យើងមិនចង់ C++ ដើម្បីអាចចាប់ Rust panics ដោយគ្រាន់តែប្រកាស `struct rust_panic` មួយ។
//
//
// នៅពេលដែលការកែប្រែ, ធ្វើឱ្យប្រាកដថាខ្សែអក្សរដែលផ្គូផ្គងនឹងប្រភេទឈ្មោះយ៉ាងពិតប្រាកដត្រូវបានប្រើក្នុង `compiler/rustc_codegen_llvm/src/intrinsic.rs` មួយនេះ។
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // នេះបាននាំមុខគេនៅទីនេះបៃ `\x01` ជាសញ្ញាគឺពិតជាដើម្បី LLVM ដើម្បីវេទមន្ត *មិនអនុវត្ត* ណាមួយផ្សេងទៀតដូចជាការខូចដោយមានតួអក្សរបុព្វបទ `_` ។
    //
    //
    // និមិត្តសញ្ញានេះគឺជាតុរប្យួរដែលប្រើដោយ `std::type_info` របស់ស៊ី ++ ។
    // វត្ថុនៃប្រភេទ `std::type_info` ប្រភេទពិពណ៌នាប្រភេទមានចង្អុលទៅតុនេះ។
    // ប្រភេទពិពណ៌នាត្រូវបានយោងដោយរចនាសម្ព័ន្ធ C++ EH ដែលបានកំណត់ខាងលើហើយដែលយើងសាងសង់ខាងក្រោម។
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// អ្នកពិពណ៌នាប្រភេទនេះត្រូវបានប្រើតែនៅពេលបោះចោលករណីលើកលែង។
// ការផលនេសាទមួយផ្នែកត្រូវបានគ្រប់គ្រងដោយចាំបាច់ព្យាយាមដែលបានបង្កើត TypeDescriptor របស់ខ្លួន។
//
// នេះគឺជាការល្អចាប់តាំងពីការប្រៀបធៀបជាមួយខ្សែការប្រើពេលរត់ MSVC លើឈ្មោះប្រភេទដើម្បី TypeDescriptors ប្រកួតជាជាងសមភាពស្សន៍ទ្រនិច។
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor បានប្រើប្រសិនបើកូដ C++ សំរេចចិត្តចាប់យកករណីលើកលែងហើយទម្លាក់វាដោយមិនផ្សព្វផ្សាយ។
// ការផលនេសាទជាផ្នែកមួយនៃចាំបាច់ព្យាយាមនឹងកំណត់ពាក្យដំបូងនៃវត្ថុករណីលើកលែងទៅ 0 ដូច្នេះវាត្រូវបានរំលងដោយបានបំផ្លាញ។
//
// ចំណាំថា x86 Windows ប្រើអនុសញ្ញាហៅ "thiscall" សម្រាប់មុខងារសមាជិក C++ ជំនួសឱ្យអនុសញ្ញាហៅ "C" លំនាំដើម។
//
// មុខងារ exception_copy ពិសេសបន្តិចនៅទីនេះ: វាត្រូវបានហៅមកប្រើដោយរត់ MSVC ក្រោមប្លុក try/catch និង panic ដែលយើងបានបង្កើតនៅទីនេះនឹងត្រូវបានប្រើជាលទ្ធផលនៃច្បាប់ចម្លងករណីលើកលែងនេះ។
//
// ការនេះត្រូវបានប្រើដោយ C++ ពេលរត់ដើម្បីគាំទ្រដល់ករណីលើកលែងចាប់យកជាមួយនឹងការ std::exception_ptr ដែលយើងមិនអាចជួយបានទេព្រោះប្រអប់<dyn Any>គឺមិនមែន clonable ។
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException ប្រតិបត្តិបានទាំងស្រុងនៅលើស៊ុមជង់នេះដូច្នេះវាមានតម្រូវការក្នុងការបើមិនដូច្នេះទេផ្ទេរ `data` ទៅគំនរថ្មនោះទេ។
    // យើងគ្រាន់តែឆ្លងកាត់ទ្រនិចទ្រនិចទៅនឹងមុខងារនេះ។
    //
    // ManuallyDrop នេះត្រូវបានត្រូវការនៅទីនេះតាំងពីយើងមិនចង់ការលើកលែងនឹងត្រូវទម្លាក់ចោលនៅពេលដកចេញ។
    // ផ្ទុយទៅវិញវានឹងត្រូវបានធ្លាក់ចុះដែលត្រូវបានហៅមកប្រើ exception_cleanup ដោយពេលរត់ C++ ។
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // នេះ ... មើលទៅដូចជាគួរឱ្យភ្ញាក់ផ្អើលហើយពិតជាគួរឱ្យទុកចិត្តណាស់។នៅលើ MSVC ៣២ ប៊ីតអ្នកចង្អុលបង្ហាញរវាងរចនាសម្ព័ន្ធទាំងនេះគឺគ្រាន់តែប៉ុណ្ណឹង។
    // ទោះយ៉ាងណានៅលើអេសវីអេសប៊ី ៦ ប៊ីតចង្អុលបង្ហាញរវាងរចនាសម្ព័ន្ធត្រូវបានបង្ហាញជាអុហ្វសិត ៣២ ប៊ីតពីអ៊ិច។
    //
    // ហេតុដូច្នេះហើយនៅលើអេសវីអេសប៊ីប៊ីត ៣២ យើងអាចប្រកាសចង្អុលបង្ហាញទាំងអស់នេះនៅក្នុង `ឋិតិវន្តខាងលើ។
    // នៅថ្ងៃទី 64 ប៊ីត MSVC, យើងនឹងមានដើម្បីបង្ហាញពីការដកនៃព្រួញនៅឋិតិវន្តដែល Rust មិនអនុញ្ញាតឱ្យនាពេលបច្ចុប្បន្ននេះដូច្នេះយើងមិនពិតជាអាចធ្វើបាន។
    //
    // រឿងដែលល្អបំផុតក្រោយ, បន្ទាប់មកគឺដើម្បីបំពេញនៅក្នុងរចនាសម្ព័ន្ធទាំងនេះនៅពេលរត់ (panicking មានរួចទៅហើយ "slow path" នេះទោះយ៉ាងណា) ។
    // ដូច្នេះនៅទីនេះយើងបកស្រាយឡើងវិញនូវវាលទ្រនិចទាំងអស់នេះជាចំនួនគត់ ៣២ ប៊ីតហើយបន្ទាប់មករក្សាទុកតម្លៃដែលពាក់ព័ន្ធទៅក្នុងនោះ (អាតូមិចនៅពេលដែល panics កំពុងកើតឡើង) ។
    //
    // បច្ចេកទេសពេលរត់ប្រហែលជានឹងធ្វើការអាន nonatomic នៃវាលទាំងនេះ, ប៉ុន្តែនៅក្នុងទ្រឹស្តីពួកគេមិនដែលបានអានខុស * * តម្លៃដូច្នេះវាមិនគួរជាអាក្រក់ពេក ...
    //
    // ក្នុងករណីណាមួយដែលយើងជាមូលដ្ឋានចាំបាច់ត្រូវធ្វើអ្វីមួយដូចនេះរហូតដល់ពេលដែលយើងអាចបង្ហាញពីប្រតិបត្ដិការបន្ថែមទៀតនៅក្នុងឋិតិវន្ត (ហើយយើងប្រហែលជាមិនអាច) ។
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // ការ payload NULL មួយនៅទីនេះមានន័យថាយើងបានទទួលនៅទីនេះបានមកពីការចាប់ (...) នៃ __rust_try នេះ។
    // វាកើតឡើងនៅពេលការលើកលែងបរទេសដែលមិនមែនជា Rust ត្រូវបានចាប់។
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// នេះត្រូវបានទាមទារដោយចងក្រងឱ្យមាន (ឧទាហរណ៍, វាជាធាតុឡង់), ប៉ុន្តែវាមិនបានហៅពិតដោយចងក្រងនេះដោយសារតែ __C_specific_handler ឬ _except_handler3 គឺជាមុខងារបុគ្គលិកលក្ខណៈដែលត្រូវបានប្រើជានិច្ច។
//
// ដូច្នេះនេះគ្រាន់តែជាស្តុបដែលបោះបង់ចោលប៉ុណ្ណោះ។
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}