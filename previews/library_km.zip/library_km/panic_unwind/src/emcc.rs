//! ការបង្រួបបង្រួមសម្រាប់គោលដៅ *emscripten*។
//!
//! ចំណែកឯការអនុវត្តការធូររលុងធម្មតា Rust សម្រាប់ Unix ការហៅទូរស័ព្ទចូលទៅក្នុងវេទិកានេះដោយផ្ទាល់ APIs libunwind នៅលើ Emscripten យើងជំនួសឱ្យហៅចូលទៅក្នុង C++ ដកចេញ APIs នេះ។
//! នេះគ្រាន់តែជាការចាំបាច់មួយចាប់តាំងពីពេលរត់ Emscripten តែងតែអនុវត្ត APIs ទាំងនោះហើយមិនបានអនុវត្ត libunwind ។
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// នេះត្រូវគ្នានឹងប្លង់នៃ std::type_info នៅក្នុង C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // នេះបាននាំមុខគេនៅទីនេះបៃ `\x01` ជាសញ្ញាគឺពិតជាដើម្បី LLVM ដើម្បីវេទមន្ត *មិនអនុវត្ត* ណាមួយផ្សេងទៀតដូចជាការខូចដោយមានតួអក្សរបុព្វបទ `_` ។
    //
    //
    // និមិត្តសញ្ញានេះគឺជាតុរប្យួរដែលប្រើដោយ `std::type_info` របស់ស៊ី ++ ។
    // វត្ថុនៃប្រភេទ `std::type_info` ប្រភេទពិពណ៌នាប្រភេទមានចង្អុលទៅតុនេះ។
    // ប្រភេទពិពណ៌នាត្រូវបានយោងដោយរចនាសម្ព័ន្ធ C++ EH ដែលបានកំណត់ខាងលើហើយដែលយើងសាងសង់ខាងក្រោម។
    //
    // ចំណាំថាទំហំពិតប្រាកដមានទំហំធំជាង ៣ ទំហំប៉ុន្តែយើងត្រូវការវ៉ែនតាដើម្បីចង្អុលទៅធាតុទី ៣ ។
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info សម្រាប់ថ្នាក់ច្រែះ
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // ជាធម្មតាយើងនឹងប្រើ .as_ptr().add(2) ប៉ុន្តែវាមិនដំណើរការទេនៅក្នុងបរិបទមួយ។
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // នេះមានចេតនាមិនប្រើគ្រោងការណ៍ឈ្មោះខូចធម្មតាដោយសារតែយើងមិនចង់ប្រើភាសា C++ ដើម្បីអាចផលិតឬចាប់ Rust panics ។
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // នេះគឺចាំបាច់ពីព្រោះកូដ C++ អាចចាប់យកការប្រតិបត្តិរបស់យើងជាមួយ std::exception_ptr ហើយបញ្ចូលវាម្តងទៀតច្រើនដងសូម្បីតែក្នុងខ្សែផ្សេងទៀត។
    //
    //
    caught: AtomicBool,

    // តម្រូវការនេះបានក្លាយទៅជាជម្រើសមួយដោយសារតែជីវិតរបស់វត្ថុខាងក្រោម C++ សញ្ញាន័យវិទ្យា: ពេល catch_unwind ផ្លាស់ទីប្រអប់ចេញពីករណីលើកលែងដែលវានៅតែត្រូវតែចាកចេញពីវត្ថុដែលបានលើកលែងតែនៅក្នុងស្ថានភាពត្រឹមត្រូវមួយដោយសារតែនៅតែមានរបស់ខ្លួនបំផ្លាញនឹងត្រូវបានហៅថាដោយ __cxa_end_catch ។
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try តាមពិតផ្តល់ឱ្យយើងនូវទ្រនិចមួយទៅរចនាសម្ព័ន្ធនេះ។
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // ដោយសារតែ cleanup() មិនត្រូវបានអនុញ្ញាតឱ្យ panic យើងគ្រាន់តែបោះបង់ចោលជំនួសវិញ។
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}