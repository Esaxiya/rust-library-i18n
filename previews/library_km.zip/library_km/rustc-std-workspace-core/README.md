# `rustc-std-workspace-core` crate

crate នេះជា Shim និងការទទេ crate ដែលគ្រាន់តែអាស្រ័យទៅលើ `libcore` និង reexports ទាំងអស់នៃមាតិការបស់វា។
crate គឺជាចំណុចកំពូលនៃការផ្តល់សិទ្ធិអំណាចដល់បណ្ណាល័យស្តង់ដារដើម្បីពឹងផ្អែកលើ crates ពី crates.io

Crates នៅលើ crates.io ថាការពឹងផ្អែកលើស្តង់ដាបណ្ណាល័យពឹងលើតម្រូវការ `rustc-std-workspace-core` crate ពី crates.io ដែលជាទទេ។

យើងប្រើ `[patch]` ដើម្បីបដិសេធវាទៅ crate នៅក្នុងឃ្លាំងនេះ។
ជាលទ្ធផល crates នៅលើ crates.io នឹងទាញភាពអាស្រ័យ edge ទៅ `libcore` ដែលជាកំណែដែលបានកំណត់នៅក្នុងឃ្លាំងនេះ។
នោះគួរតែគូរទាំងអស់គែមអាស្រ័យដើម្បីធានាឱ្យបាន Cargo កសាង crates ដោយជោគជ័យ!

ចំណាំថា crates នៅលើ crates.io ត្រូវការពឹងផ្អែកលើ crate នេះដែលមានឈ្មោះ `core` សម្រាប់អ្វីគ្រប់យ៉ាងដើម្បីធ្វើការងារបានត្រឹមត្រូវ។ដើម្បីធ្វើដូចដែលពួកគេអាចប្រើប្រាស់:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

តាមរយៈការប្រើប្រាស់គ្រាប់ចុច `package` នេះ crate ត្រូវបានប្ដូរឈ្មោះទៅជា `core` មានន័យថាវានឹងមើលទៅដូចជា

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

ពេល Cargo សំអាងចងក្រង, បំពេញការបង្គាប់ `extern crate core` ជាក់ច្បាស់ចាក់តាមកម្មវិធីចងក្រង។




