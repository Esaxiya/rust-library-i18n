use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // មីរីយឺតពេកហើយ
fn exact_sanity_test() {
    // ការធ្វើតេស្តនេះបានបញ្ចប់ឡើងកំពុងរត់អ្វីដែលខ្ញុំអាចសន្មត់តែមួយគត់គឺករណីប្រដាប់គ្រឹះមួយចំនួននៃមុខងារបណ្ណាល័យ `exp2`, បានកំណត់នៅក្នុងអ្វីដែលយើងកំពុងតែស៊ីពេលរត់ដោយការប្រើ។
    // នៅក្នុង VS ឆ្នាំ ២០១៣ មុខងារនេះច្បាស់ជាមានកំហុសមួយដែលការធ្វើតេស្តនេះត្រូវបានបរាជ័យនៅពេលភ្ជាប់ប៉ុន្តែជាមួយ VS 2015 កំហុសនេះត្រូវបានជួសជុលនៅពេលដែលដំណើរការបានល្អ។
    //
    // កំហុសហាក់ដូចជាមានភាពខុសគ្នានៅក្នុងតម្លៃត្រឡប់មកវិញនៃ `exp2(-1057)`, ដែលជាកន្លែងដែលនៅ VS 2013 វាត្រឡប់ពីរដងមួយដែលមានលំនាំប៊ីត 0x2 និងនៅ VS 2015 វាត្រឡប់ 0x20000 មួយ។
    //
    //
    // សំរាប់ពេលនេះគ្រាន់តែមិនអើពើនឹងការធ្វើតេស្តនេះទាំងស្រុងនៅលើ MSVC វាជាការធ្វើតេស្តនៅកន្លែងផ្សេងទោះយ៉ាងណាបានហើយយើងមិនចាប់អារម្មណ៍ក្នុងការធ្វើតេស្តការអនុវត្តទំនើបវេទិកាគ្នា exp2 ។
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}