use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // នេះមិនមែនជាផ្ទៃដែលមានស្ថេរភាពនោះទេប៉ុន្តែជួយរក្សា `?` ថោកនៅចន្លោះពួកវាទោះបីអិលអិលអិមអិមមិនតែងតែអាចទាញយកអត្ថប្រយោជន៍ពីវាឥឡូវនេះ។
    //
    // (គួរឱ្យស្តាយលទ្ធផលនិងជម្រើសគឺមិនជាប់លាប់, ដូច្នេះ ControlFlow មិនអាចផ្គូផ្គងទាំងពីរ។)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}