//! Note
//! ----
//! អ្នកប្រហែលជាកំពុងមើលឯកសារនេះពីព្រោះអ្នកកំពុងបន្ថែមការធ្វើតេស្ត (ឬអ្នកប្រហែលជាកំពុងរកមើលក្នុងករណីនោះហេ! នៅទីនោះ!) ។
//!
//! ឈុតសាកល្បងការនិយាយឡើងវិញត្រូវបានបំបែកទៅម៉ូឌុលធំពីរ, និងម៉ូឌុលទំហំតូចផ្សេងមួយចំនួន។ម៉ូឌុលធំពីរគឺ `adapters` និង `traits` ។
//!
//! `adapters` គឺសម្រាប់វិធីសាស្រ្តនៅលើ `Iterator` ថាការសម្របទិន្នន័យខាងក្នុងបម្រុងនេះថាតើវានឹងមានដោយបញ្ចេញបម្រុងមួយផ្សេងទៀតឬវិលត្រឡប់ធាតុមួយពីខាងក្នុងបម្រុងបន្ទាប់ពីការប្រតិបត្តិបិទមួយនៅលើធាតុនីមួយ។
//!
//!
//! `traits` គឺសម្រាប់ trait ដែលពង្រីក `Iterator` (និង `Iterator` trait ខ្លួនវាភាគច្រើនមានវិធីសាស្ត្រផ្សេងៗ) ។
//! សម្រាប់ផ្នែកច្រើនបំផុតប្រសិនបើការធ្វើតេស្តក្នុងការប្រើអាដាប់ធ័រ `traits` ជាក់លាក់មួយ, បន្ទាប់មកវាគួរតែត្រូវបានផ្លាស់ប្តូរទៅកាន់ឯកសារដែលការធ្វើតេស្តរបស់អាដាប់ធ័រថានៅក្នុង `adapters` ។
//!
//!
//!
//!
//!

mod adapters;
mod range;
mod sources;
mod traits;

use core::cell::Cell;
use core::convert::TryFrom;
use core::iter::*;

pub fn is_trusted_len<I: TrustedLen>(_: I) {}

#[test]
fn test_multi_iter() {
    let xs = [1, 2, 3, 4];
    let ys = [4, 3, 2, 1];
    assert!(xs.iter().eq(ys.iter().rev()));
    assert!(xs.iter().lt(xs.iter().skip(2)));
}

#[test]
fn test_counter_from_iter() {
    let it = (0..).step_by(5).take(10);
    let xs: Vec<isize> = FromIterator::from_iter(it);
    assert_eq!(xs, [0, 5, 10, 15, 20, 25, 30, 35, 40, 45]);
}

#[test]
fn test_functor_laws() {
    // identity:
    fn identity<T>(x: T) -> T {
        x
    }
    assert_eq!((0..10).map(identity).sum::<usize>(), (0..10).sum());

    // composition:
    fn f(x: usize) -> usize {
        x + 3
    }
    fn g(x: usize) -> usize {
        x * 2
    }
    fn h(x: usize) -> usize {
        g(f(x))
    }
    assert_eq!((0..10).map(f).map(g).sum::<usize>(), (0..10).map(h).sum());
}

#[test]
fn test_monad_laws_left_identity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        (0..10).map(move |y| x * y)
    }
    assert_eq!(once(42).flat_map(f.clone()).sum::<usize>(), f(42).sum());
}

#[test]
fn test_monad_laws_right_identity() {
    assert_eq!((0..10).flat_map(|x| once(x)).sum::<usize>(), (0..10).sum());
}

#[test]
fn test_monad_laws_associativity() {
    fn f(x: usize) -> impl Iterator<Item = usize> {
        0..x
    }
    fn g(x: usize) -> impl Iterator<Item = usize> {
        (0..x).rev()
    }
    assert_eq!(
        (0..10).flat_map(f).flat_map(g).sum::<usize>(),
        (0..10).flat_map(|x| f(x).flat_map(g)).sum::<usize>()
    );
}

#[test]
pub fn extend_for_unit() {
    let mut x = 0;
    {
        let iter = (0..5).map(|_| {
            x += 1;
        });
        ().extend(iter);
    }
    assert_eq!(x, 5);
}