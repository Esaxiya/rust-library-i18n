use core::task::Poll;

#[test]
fn poll_const() {
    // សាកល្បងថាវិធីសាស្រ្តនៃ `Poll` គឺអាចប្រើបាននៅក្នុងបរិបទ const មួយ

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}