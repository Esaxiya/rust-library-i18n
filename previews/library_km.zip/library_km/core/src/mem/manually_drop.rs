use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// រុំមួយដើម្បីចងក្រងពីការហៅទូរស័ព្ទដោយស្វ័យប្រវត្តិ inhibit ការបំផ្លាញ T`របស់`។
/// រុំនេះគឺ 0 ចំណាយ។
///
/// `ManuallyDrop<T>` គឺជាប្រធានបទត្រូវការបង្កើនប្រសិទ្ធិភាពប្លង់ដូចគ្នា `T` ។
/// ជាលទ្ធផលវាមានផលប៉ះពាល់ * * ទេនៅលើការសន្មត់ថាការចងក្រងធ្វើឱ្យអំពីមាតិការបស់វា។
/// ឧទាហរណ៍ការចាប់ផ្តើម `ManuallyDrop<&mut T>` ជាមួយ [`mem::zeroed`] គឺជាឥរិយាបទដែលមិនបានកំណត់។
/// ប្រសិនបើអ្នកត្រូវការដោះស្រាយទិន្នន័យដែលមិនបានគ្រោងទុកសូមប្រើ [`MaybeUninit<T>`] ជំនួសវិញ។
///
/// ចំណាំថាការចូលដំណើរការនៅក្នុង `ManuallyDrop<T>` តម្លៃមួយដែលមានសុវត្ថិភាព។
/// នេះមានន័យថា `ManuallyDrop<T>` ដែលមានមាតិកាត្រូវបានធ្លាក់ចុះតែមិនត្រូវបានប៉ះពាល់តាមរយៈ API ដែលមានសុវត្ថិភាពសាធារណៈ។
/// ឆ្លើយឆ្លងគ្នា `ManuallyDrop::drop` មិនមានសុវត្ថិភាពទេ។
///
/// # `ManuallyDrop` ការបញ្ជាទិញធ្លាក់ចុះហើយ។
///
/// Rust មានល្អដែលបានកំណត់ [drop order] នៃតម្លៃ។
/// ដើម្បីធ្វើឱ្យប្រាកដថាវាលឬអ្នកស្រុកត្រូវបានទម្លាក់តាមលំដាប់ជាក់លាក់សូមរៀបចំសេចក្តីប្រកាសឡើងវិញថាលំដាប់ទម្លាក់ជាក់លាក់គឺត្រឹមត្រូវ។
///
/// វាគឺជាការដែលអាចធ្វើបានក្នុងការប្រើ `ManuallyDrop` ធ្លាក់ចុះដើម្បីគ្រប់គ្រងការបញ្ជានោះទេតែនេះតម្រូវឱ្យមានកូដមិនមានសុវត្ថិភាពនិងជាការលំបាកក្នុងការធ្វើឱ្យបានត្រឹមត្រូវនៅក្នុងវត្តមាននៃដកចេញនោះទេ។
///
///
/// ឧទាហរណ៍ប្រសិនបើអ្នកចង់ធ្វើឱ្យប្រាកដថាវាលជាក់លាក់មួយត្រូវបានធ្លាក់ចុះបន្ទាប់ពីអ្នកដទៃទៀត, ធ្វើឱ្យវាវាលចុងក្រោយរបស់ struct មួយ:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` នឹងត្រូវបានធ្លាក់ចុះបន្ទាប់ពី `children` ។
///     // Rust ធានាថាវាលត្រូវបានធ្លាក់ចុះនៅក្នុងគោលបំណងនៃការប្រកាសនេះ។
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// រុំតម្លៃដែលត្រូវទម្លាក់ដោយដៃ។
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // អ្នកនៅតែអាចធ្វើប្រតិបត្តិការយ៉ាងមានសុវត្ថិភាពលើតម្លៃ
    /// assert_eq!(*x, "Hello");
    /// // ប៉ុន្តែ `Drop` នឹងមិនត្រូវបានរត់នៅទីនេះ
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// ដកស្រង់ចេញពីធុងតម្លៃនេះ `ManuallyDrop` ។
    ///
    /// នេះអនុញ្ញាតឱ្យតម្លៃត្រូវបានធ្លាក់ចុះជាថ្មីម្តងទៀត។
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // នេះទម្លាក់ `Box` ។
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// ត្រូវចំណាយពេលតម្លៃពីចេញធុង `ManuallyDrop<T>` នេះ។
    ///
    /// វិធីសាស្រ្តនេះត្រូវបានបម្រុងទុកជាចម្បងសម្រាប់ការផ្លាស់ប្តូរតម្លៃធ្លាក់ចុះ។
    /// ជំនួសឱ្យការប្រើ [`ManuallyDrop::drop`] ការទម្លាក់តម្លៃដោយដៃ, អ្នកអាចប្រើវិធីសាស្ត្រនេះដើម្បីទទួលយកតម្លៃនិងប្រើវាចង់បានទោះជាយ៉ាងណា។
    ///
    /// នៅពេលណាដែលអាចធ្វើទៅបានវាជាការចូលចិត្តក្នុងការប្រើ [`into_inner`][`ManuallyDrop::into_inner`] ជំនួសវិញដែលទប់ស្កាត់ការដែលស្ទួនមាតិកានៃ `ManuallyDrop<T>` នេះ។
    ///
    ///
    /// # Safety
    ///
    /// មុខងារនេះផ្លាស់ប្តូរភ្លាមៗនូវតម្លៃដែលមានដោយមិនការពារការប្រើប្រាស់បន្តទៀតដែលធ្វើឱ្យស្ថានភាពនៃកុងដង់នេះមិនផ្លាស់ប្តូរ។
    /// វាគឺជាការទទួលខុសត្រូវរបស់អ្នកដើម្បីធានាថា `ManuallyDrop` នេះមិនត្រូវបានប្រើជាថ្មីម្តងទៀត។
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // សុវត្ថិភាព: យើងកំពុងអានពីឯកសារយោងដែលត្រូវបានធានា
        // ដើម្បីជាការត្រឹមត្រូវសម្រាប់អាន។
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// ទម្លាក់ដោយដៃនូវតម្លៃដែលមាន។នេះពិតជាស្មើនឹងការហៅទូរស័ព្ទ [`ptr::drop_in_place`] ជាមួយនឹងព្រួញចង្អុលទៅតម្លៃដែលមាន។
    /// ដូច្នេះលើកលែងតែតម្លៃដែលមានគឺជារចនាសម្ព័ន្ធដែលបានរៀបចំហើយអ្នកបំផ្លាញនឹងត្រូវបានគេហៅថានៅកន្លែងដែលមិនផ្លាស់ប្តូរតម្លៃហើយដូច្នេះអាចត្រូវបានប្រើដើម្បីទម្លាក់ទិន្នន័យ [pinned] ដោយសុវត្ថិភាព។
    ///
    /// ប្រសិនបើអ្នកមានភាពជាម្ចាស់នៃតម្លៃដែលអ្នកអាចប្រើ [`ManuallyDrop::into_inner`] ជំនួសវិញ។
    ///
    /// # Safety
    ///
    /// មុខងារនេះរត់នៃតម្លៃដែលមានបំផ្លាញនេះ។
    /// ក្រៅពីការផ្លាស់ប្តូរដែលបានធ្វើដោយអ្នកបំផ្លាញខ្លួនឯងការចងចាំមិនត្រូវបានផ្លាស់ប្តូរទេហើយរហូតមកដល់ពេលនេះអ្នកចងក្រងមានការព្រួយបារម្ភនៅតែមានលំនាំបន្តិចបន្តួចដែលមានសុពលភាពសម្រាប់ប្រភេទ `T` ។
    ///
    ///
    /// ទោះជាយ៉ាងណាតម្លៃ "zombie" នេះមិនគួរត្រូវបានប៉ះពាល់ទៅនឹងលេខកូដសុវត្ថិភាពនិងមុខងារនេះមិនគួរត្រូវបានគេហៅថាច្រើនជាងម្តង។
    /// ដើម្បីប្រើតម្លៃមួយបន្ទាប់ពីវាត្រូវបានគេធ្លាក់ចុះឬការធ្លាក់ចុះតម្លៃច្រើនដងអាចបង្កឱ្យមានឥរិយាបថមិនបានកំណត់ (អាស្រ័យលើអ្វីដែល `drop` ធ្វើ) ។
    /// នេះជាធម្មតាត្រូវបានរារាំងដោយប្រព័ន្ធប្រភេទនោះទេតែអ្នកប្រើនៃ `ManuallyDrop` ត្រូវតែគាំទ្រការធានាទាំងនោះបានដោយគ្មានជំនួយពីចងក្រង។
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // សុវត្ថិភាព: យើងកំពុងទម្លាក់តម្លៃដែលបានចង្អុលបង្ហាញដោយសេចក្ដីយោង mutable មួយ
        // ដែលត្រូវបានធានាថាមានសុពលភាពសម្រាប់ការសរសេរ។
        // វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធ្វើឱ្យប្រាកដថា `slot` មិនត្រូវបានធ្លាក់ចុះជាថ្មីម្តងទៀត។
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}