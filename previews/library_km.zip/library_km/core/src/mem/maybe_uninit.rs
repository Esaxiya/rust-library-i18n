use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// ប្រភេទរុំមួយដើម្បីសាងសង់ករណី uninitiated នៃ `T` ។
///
/// # មិនផ្លាស់ប្ដូរការចាប់ផ្ដើម
///
/// កម្មវិធីចងក្រង, នៅក្នុងទូទៅ, សន្មត់ថាអថេរត្រូវបានចាប់ផ្ដើមមិនត្រឹមត្រូវនេះបើយោងតាមតម្រូវការនៃប្រភេទអថេរនេះ។ឧទាហរណ៍អថេរនៃប្រភេទឯកសារយោងមួយដែលត្រូវតែបានតម្រឹមនិងមិន NULL ។
/// នេះគឺជាការដែលមិនផ្លាស់ប្ដូរដែលត្រូវ *តែងតែ* ត្រូវបានតម្កើង, សូម្បីតែនៅក្នុងលេខកូដដែលគ្មានសុវត្ថិភាពមួយ។
/// ជាលទ្ធផលសូន្យចាប់ផ្ដើមអថេរនៃប្រភេទមួយដែលបណ្តាលអោយឆាប់រហ័សសេចក្ដីយោង [undefined behavior][ub] មិនថាជាឯកសារយោងដែលមិនធ្លាប់ត្រូវបានប្រើដើម្បីចូលដំណើរការគ្មានការចងចាំ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // ឥរិយាបទមិនបានកំណត់!⚠️
/// // លេខកូដដែលមានតំលៃស្មើជាមួយ `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // ឥរិយាបទមិនបានកំណត់!⚠️
/// ```
///
/// នេះត្រូវបានគេកេងប្រវ័ញ្ចតាមកម្មវិធីចងក្រងសម្រាប់ការបង្កើនប្រសិទ្ធិភាពជាច្រើនដូចជា eliding ត្រួតពិនិត្យពេលរត់និងធ្វើប្លង់ `enum` នេះ។
///
/// ស្រដៀងគ្នានេះដែរការចងចាំដែលមិនមានឯកសិទ្ធិទាំងស្រុងអាចមានមាតិកាណាមួយខណៈពេលដែល `bool` ត្រូវតែជា `true` ឬ `false` ជានិច្ច។ហេតុ, ការបង្កើត `bool` uninitialized គឺជាឥរិយាបទបានកំណត់:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // ឥរិយាបទមិនបានកំណត់!⚠️
/// // លេខកូដដែលមានតំលៃស្មើជាមួយ `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // ឥរិយាបទមិនបានកំណត់!⚠️
/// ```
///
/// លើសពីនេះទៅទៀតការចងចាំ uninitiated ពិសេសនៅក្នុងនោះវាមិនមានតម្លៃថេរ ("fixed" ន័យ "it won't change without being written to") ។អានបៃ uninitiated ដូចគ្នាច្រើនដងអាចផ្តល់នូវលទ្ធផលខុសគ្នា។
/// នេះធ្វើឱ្យវាកំណត់ឥរិយាបថមានទិន្នន័យ uninitiated ក្នុងអថេរសូម្បីតែប្រសិនបើអថេរដែលមានប្រភេទជាចំនួនគត់ដែលបើមិនដូច្នេះទេអាចកាន់លំនាំបន្តិច *ណាមួយ* ថេរ:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // ឥរិយាបទមិនបានកំណត់!⚠️
/// // លេខកូដដែលមានតំលៃស្មើជាមួយ `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // ឥរិយាបទមិនបានកំណត់!⚠️
/// ```
/// (សូមកត់សម្គាល់ថាច្បាប់ដែលនៅជុំវិញចំនួនគត់ uninitiated មិនត្រូវបានបញ្ចប់នៅឡើយទេប៉ុន្តែរហូតដល់ពួកគេមាន, វាគឺជាទីប្រឹក្សាដើម្បីជៀសវាងពួកគេ។)
///
/// នៅលើកំពូលនៃថា, ចងចាំថាប្រភេទភាគច្រើនមានផុសបន្ថែមទៀតលើសពីការគ្រាន់តែត្រូវបានចាត់ទុកចាប់ផ្ដើមនៅកម្រិតប្រភេទ។
/// ឧទាហរណ៍: [`Vec<T>`] 1 'បានចាប់ផ្ដើមត្រូវបានចាត់ទុក-ចាប់ផ្ដើម (ដែលស្ថិតក្រោមការអនុវត្តនាពេលបច្ចុប្បន្ននេះមិនមានការធានាស្ថេរភាពមួយ) ដោយសារតែតម្រូវការតែមួយគត់ដែលចងក្រងដឹងអំពីវានោះគឺថាទស្សន៍ទ្រនិចទិន្នន័យត្រូវតែមិនទទេ។
/// ការបង្កើត `Vec<T>` បែបនេះមិនបណ្តាលឱ្យ * ឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗនោះទេប៉ុន្តែវានឹងបង្កឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់ជាមួយនឹងប្រតិបត្តិការដែលមានសុវត្ថិភាពបំផុត (រួមទាំងការទម្លាក់វា) ។
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` បម្រើដើម្បីបើកលេខកូដដែលមិនមានសុវត្ថិភាពក្នុងការដោះស្រាយជាមួយនឹងទិន្នន័យ uninitiated ។
/// វាគឺជាសញ្ញាមួយសម្រាប់អ្នកចងក្រងដែលបង្ហាញថាទិន្នន័យនៅទីនេះប្រហែលជា *មិន* ត្រូវបានចាប់ផ្តើមទេ៖
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // បង្កើតឯកសារយោងដែលមិនមានលក្ខណៈច្បាស់លាស់។
/// // ចងក្រងទិន្នន័យដឹងថានៅក្នុង `MaybeUninit<T>` អាចនឹងមិនត្រឹមត្រូវហេតុដូចនេះហើយនេះមិនមែនជា UB បាន:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // កំណត់វាទៅតម្លៃត្រឹមត្រូវ។
/// unsafe { x.as_mut_ptr().write(&0); }
/// // ស្រង់ទិន្នន័យចាប់ផ្ដើម-នេះ *គឺត្រូវបានអនុញ្ញាតតែបន្ទាប់ពីបានត្រឹមត្រូវ `x`* ចាប់ផ្ដើម!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// អ្នកចងក្រងដឹងថាមិនធ្វើការសន្មតឬបង្កើនប្រសិទ្ធភាពណាមួយលើលេខកូដនេះទេ។
///
/// អ្នកអាចគិតថា `MaybeUninit<T>` ថាជាបន្តិចដូច `Option<T>` មួយប៉ុន្តែដោយគ្មានការណាមួយនៃការតាមដានពេលរត់និងដោយគ្មានការណាមួយនៃការត្រួតពិនិត្យសុវត្ថិភាព។
///
/// ## out-pointers
///
/// អ្នកអាចប្រើ `MaybeUninit<T>` ដើម្បីអនុវត្ត "out-pointers": ជំនួសឱ្យការវិលត្រឡប់ទិន្នន័យពីមុខងារមួយហុចវាព្រួញមួយដើម្បីការចងចាំ (uninitialized) មួយចំនួនដើម្បីដាក់លទ្ធផលទៅក្នុង។
/// វាអាចមានប្រយោជន៍នៅពេលដែលវាជាការសំខាន់សម្រាប់អ្នកទូរស័ព្ទចូលដើម្បីត្រួតពិនិត្យរបៀបសតិលទ្ធផលត្រូវបានរក្សាទុកនៅក្នុងត្រូវបានបម្រុងទុកសម្រាប់អ្នកហើយអ្នកចង់ជៀសវាងការផ្លាស់ទីដែលមិនចាំបាច់។
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` មិនចោលមាតិកាចាស់ដែលសំខាន់។
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // ឥឡូវនេះយើងដឹងថា `v` ត្រូវបានចាប់ផ្ដើម!នេះក៏ធ្វើឱ្យប្រាកដថា vector ត្រូវបានទម្លាក់ត្រឹមត្រូវ។
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## ការចាប់ផ្តើមអារេធាតុតាមធាតុ
///
/// `MaybeUninit<T>` អាចត្រូវបានប្រើដើម្បីចាប់ផ្តើមធាតុអារេធំមួយតាមធាតុ៖
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // បង្កើតអារេដែលមិនមានឯកសិទ្ធិនៃ `MaybeUninit` ។
///     // `assume_init` នេះគឺមានសុវត្ថិភាពដោយសារតែយើងត្រូវបានគេអះអាងថាជាប្រភេទដែលបានចាប់ផ្ដើមនៅទីនេះទៅនោះគឺ bunch នៃ `MaybeUninit`s ដែលមិនតម្រូវឱ្យមានការចាប់ផ្ដើម។
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // ទម្លាក់ `MaybeUninit` មិនធ្វើអ្វីទេ។
///     // ដូច្នេះការប្រើប្រាស់វត្ថុធាតុដើមកិច្ចការព្រួញជំនួស `ptr::write` មិនបណ្តាលឱ្យតម្លៃ uninitiated អាយុដែលនឹងត្រូវបានធ្លាក់ចុះ។
/////
///     // ដូចគ្នានេះផងដែរប្រសិនបើមាន panic ក្នុងអំឡុងពេលរង្វិលជុំនេះយើងមានការលេចធ្លាយនៃការចងចាំប៉ុន្តែមិនមានបញ្ហាសុវត្ថិភាពនៃការចងចាំទេ។
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // អ្វីគ្រប់យ៉ាងត្រូវបានចាប់ផ្តើម។
///     // បញ្ជូនអារេទៅប្រភេទដែលបានចាប់ផ្តើម។
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// អ្នកអាចធ្វើការជាមួយអារេចាប់ផ្ដើមផ្នែកខ្លះដែលអាចត្រូវបានរកឃើញនៅក្នុងកម្រិតទាប datastructures ។
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // បង្កើតអារេដែលមិនមានឯកសិទ្ធិនៃ `MaybeUninit` ។
/// // `assume_init` នេះគឺមានសុវត្ថិភាពដោយសារតែយើងត្រូវបានគេអះអាងថាជាប្រភេទដែលបានចាប់ផ្ដើមនៅទីនេះទៅនោះគឺ bunch នៃ `MaybeUninit`s ដែលមិនតម្រូវឱ្យមានការចាប់ផ្ដើម។
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // រាប់ចំនួនធាតុដែលយើងបានកំណត់។
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // សម្រាប់ធាតុគ្នានៅក្នុងអារេទម្លាក់ប្រសិនបើយើងបានបម្រុងទុកសម្រាប់វា។
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ចាប់ផ្ដើម struct ដោយវាលវាលមួយ
///
/// អ្នកអាចប្រើ `MaybeUninit<T>` និងម៉ាក្រូ [`std::ptr::addr_of_mut`] ដើម្បីចាប់ផ្ដើមវាល structs ដោយវាល:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // ការចាប់ផ្តើមវាល `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // ចាប់ផ្ដើមវាល `list` ប្រសិនបើមាន panic នៅទីនេះបន្ទាប់មក `String` ក្នុងការលេចធ្លាយវាល `name` ។
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // វាលទាំងអស់ត្រូវបានចាប់ផ្ដើមដូច្នេះយើងហៅ `assume_init` ដើម្បីទទួលបានការ Foo បានចាប់ផ្ដើម។
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ត្រូវបានធានាថាមានទំហំការតម្រឹមនិងអេប៊ីអាយដូចគ្នានឹង `T` ដែរ៖
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// ទោះជាយ៉ាងណាចងចាំថាជាប្រភេទ *មានឯកសារ*`MaybeUninit<T>` មួយគឺមិនចាំបាច់ប្លង់ដូចគ្នា;Rust មិនធានាជាទូទៅថាវាលនៃ `Foo<T>` មានលំដាប់ដូចគ្នានឹង `Foo<U>` ទោះបីជា `T` និង `U` មានទំហំនិងការតម្រឹមដូចគ្នា។
///
/// លើសពីនេះទៀតដោយសារតែតម្លៃបន្តិចណាមួយគឺមានសុពលភាពសម្រាប់ `MaybeUninit<T>` មួយចងក្រងមិនអាចអនុវត្តការបង្កើនប្រសិទ្ធភាព non-zero/niche-filling មានសក្តានុពលជាលទ្ធផលនៅក្នុងទំហំធំមួយ:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// ប្រសិនបើមាន `T` គឺអង្គការ FFI-មានសុវត្ថិភាព, បន្ទាប់មកដូច្នេះគឺ `MaybeUninit<T>` ។
///
/// ខណៈពេលដែល `MaybeUninit` គឺ `#[repr(transparent)]` (បង្ហាញថាវាធានានូវទំហំ, ការតម្រឹមនិង ABI ដូច `T`) វាមិន * ផ្លាស់ប្តូរអ្វីដែលគួរអោយកត់សំគាល់ពីមុននោះទេ។
/// `Option<T>` និង `Option<MaybeUninit<T>>` អាចនៅតែមានទំហំខុសគ្នាហើយប្រភេទដែលមានវាលប្រភេទ `T` អាចត្រូវបានដាក់ (និងទំហំ) ខុសគ្នាជាងប្រសិនបើវាលនោះគឺ `MaybeUninit<T>` ។
/// `MaybeUninit` គឺជាប្រភេទសហជីពនិង `#[repr(transparent)]` ស្តីពីសហជីពគឺមិនស្ថិតស្ថេរ (សូមមើល [the tracking issue](https://github.com/rust-lang/rust/issues/60405)) ។
/// លើសម៉ោង, ការធានាពិតប្រាកដនៃ `#[repr(transparent)]` នៅលើសហជីពអាចវិវឌ្ឍនិង `MaybeUninit` អាចឬមិនអាចនៅតែ `#[repr(transparent)]` ។
/// ដែលបាននិយាយថា `MaybeUninit<T>` នឹង * តែងតែធានាថាវាមានទំហំដូចគ្នាការតម្រឹមនិងអេអាយអាយដូចជា `T`;វាគ្រាន់តែថាមធ្យោបាយដែលប់ `MaybeUninit` ដែលធានាអាចវិវឌ្ឍ។
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ធាតុឡង់ដូច្នេះយើងអាចរុំប្រភេទផ្សេងទៀតនៅក្នុងវា។នេះគឺជាការមានប្រយោជន៍សម្រាប់ម៉ាស៊ីនភ្លើង។
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // មិនហៅទូរស័ព្ទ `T::clone()` យើងមិនអាចដឹងថាតើយើងត្រូវបានចាប់ផ្តើមគ្រប់គ្រាន់សម្រាប់ការនោះទេ។
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// បង្កើត `MaybeUninit<T>` ថ្មីមួយដែលមានតម្លៃដែលបានផ្ដល់ឱ្យបានចាប់ផ្ដើមនេះ។
    /// វាមានសុវត្ថិភាពក្នុងការហៅ [`assume_init`] លើតម្លៃត្រឡប់មកវិញនៃមុខងារនេះ។
    ///
    /// ចំណាំថាការទម្លាក់ `MaybeUninit<T>` នឹងមិនដែលហៅលេខកូដទម្លាក់របស់ T ទេ។
    /// វាគឺជាការទទួលខុសត្រូវរបស់អ្នកដើម្បីធ្វើឱ្យប្រាកដថា `T` ត្រូវបានទម្លាក់ប្រសិនបើវាត្រូវបានចាប់ផ្តើម។
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// បង្កើត `MaybeUninit<T>` ថ្មីនៅក្នុងរដ្ឋ uninitiated មួយ។
    ///
    /// ចំណាំថាការទម្លាក់ `MaybeUninit<T>` នឹងមិនដែលហៅលេខកូដទម្លាក់របស់ T ទេ។
    /// វាគឺជាការទទួលខុសត្រូវរបស់អ្នកដើម្បីធ្វើឱ្យប្រាកដថា `T` ត្រូវបានទម្លាក់ប្រសិនបើវាត្រូវបានចាប់ផ្តើម។
    ///
    /// សូមមើល [type-level documentation][MaybeUninit] សម្រាប់ឧទាហរណ៍មួយចំនួន។
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// បង្កើតអារេថ្មីនៃធាតុ `MaybeUninit<T>` ក្នុងរដ្ឋ uninitiated មួយ។
    ///
    /// Note: នៅក្នុងកំណែ future Rust វិធីសាស្រ្តនេះអាចក្លាយទៅជាវាក្យសម្ព័ន្ធដែលមិនចាំបាច់នៅពេលដែលអារេអនុញ្ញាតឱ្យ [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) ន័យត្រង់។
    ///
    /// ឧទាហរណ៍ខាងក្រោមបន្ទាប់មកអាចប្រើ `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ។
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// ត្រឡប់ជាចំណែក (អាចមានទំហំតូច) នៃទិន្នន័យដែលពិតជាបានអាន
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // សុវត្ថិភាព: មួយ uninitialized `[MaybeUninit<_>; LEN]` ត្រឹមត្រូវ។
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// បង្កើត `MaybeUninit<T>` ថ្មីនៅក្នុងស្ថានភាពដែលមិនមានឯកសិទ្ធិដោយសតិត្រូវបានបំពេញដោយ `0` បៃ។វាអាស្រ័យលើ `T` ដែលរួចទៅហើយធ្វើឱ្យថាតើសម្រាប់ការចាប់ផ្ដើមត្រឹមត្រូវ។
    ///
    /// ឧទាហរណ៍ `MaybeUninit<usize>::zeroed()` ត្រូវបានចាប់ផ្តើមប៉ុន្តែ `MaybeUninit<&'static i32>::zeroed()` មិនមែនដោយសារតែសេចក្តីយោងមិនត្រូវទុកជាមោឃៈ។
    ///
    /// ចំណាំថាការទម្លាក់ `MaybeUninit<T>` នឹងមិនដែលហៅលេខកូដទម្លាក់របស់ T ទេ។
    /// វាគឺជាការទទួលខុសត្រូវរបស់អ្នកដើម្បីធ្វើឱ្យប្រាកដថា `T` ត្រូវបានទម្លាក់ប្រសិនបើវាត្រូវបានចាប់ផ្តើម។
    ///
    /// # Example
    ///
    /// ការប្រើប្រាស់ត្រឹមត្រូវនៃមុខងារនេះ: ចាប់ផ្ដើម struct មួយជាមួយនឹងសូន្យដែលជាកន្លែងវាលទាំងអស់នៃ struct ដែលអាចកាន់បានបន្តិច-លំនាំ 0 ជាតម្លៃត្រឹមត្រូវ។
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *ការប្រើប្រាស់* អនុគមន៍នេះមិនត្រឹមត្រូវ: ការហៅទូរស័ព្ទ `x.zeroed().assume_init()` ពេល `0` មិនមែនជាប៊ីតគំរូត្រឹមត្រូវសម្រាប់ប្រភេទ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // នៅខាងក្នុងគូមួយដែលយើងបង្កើត `NotZero` ដែលមិនមានឌីសគ្រីមីណង់ត្រឹមត្រូវមួយ។
    /// // នេះគឺជាឥរិយាបទដែលមិនបានកំណត់។⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // សុវត្ថិភាព: `u.as_mut_ptr()` ចង្អុលទៅការចងចាំបានបម្រុងទុក។
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// កំណត់តម្លៃនៃ `MaybeUninit<T>` នេះ។
    /// វាសរសេរជាន់លើតម្លៃពីមុនណាមួយដោយគ្មានការទម្លាក់វា, ដូច្នេះត្រូវប្រុងប្រយ័ត្នមិនឱ្យប្រើប្រាស់ពីរដងនេះលុះត្រាតែអ្នកចង់រំលងការរត់ការបំផ្លាញ។
    ///
    /// ចំពោះភាពងាយស្រួលរបស់អ្នក, នេះត្រឡប់សេចក្តីយោង mutable ទៅ (ឥឡូវចាប់ផ្ដើមដោយសុវត្ថិភាព) មាតិកានៃ `self` ។
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // សុវត្ថិភាព: យើងគ្រាន់តែជាការចាប់ផ្ដើមតម្លៃនេះ។
        unsafe { self.assume_init_mut() }
    }

    /// ដាក់ទ្រនិចទៅតម្លៃដែលមាន។
    /// អានព្រួញនេះឬងាកវាទៅជាសេចក្ដីយោងគឺជាឥរិយាបទដែលមិនបានកំណត់ទេលុះត្រាតែ `MaybeUninit<T>` ត្រូវបានចាប់ផ្ដើម។
    /// សរសេរដើម្បីការចងចាំដែលព្រួញកនេះពិន្ទុ (non-transitively) ទៅគឺជាឥរិយាបទដែលមិនបានកំណត់ (លើកលែងតែនៅក្នុង `UnsafeCell<T>` មួយ) ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់ត្រឹមត្រូវនៃវិធីសាស្រ្តនេះ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // បង្កើតឯកសារយោងចូលទៅក្នុង `MaybeUninit<T>` ។នេះមិនអីទេពីព្រោះយើងបានចាប់ផ្តើមដំបូង។
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *ការប្រើប្រាស់វិធីសាស្រ្តមិនត្រឹមត្រូវ* នេះ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // យើងបានបង្កើតសេចក្ដីយោងទៅ uninitiated vector មួយ!នេះជាឥរិយាបទដែលមិនបានកំណត់។⚠️
    /// ```
    ///
    /// (សូមកត់សម្គាល់ថាច្បាប់នៅជុំវិញយោងទៅទិន្នន័យមិនត្រូវបានបញ្ចប់ uninitiated ឡើយទេប៉ុន្តែរហូតដល់ពួកគេមាន, វាគឺជាទីប្រឹក្សាដើម្បីជៀសវាងពួកគេ។)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` និង `ManuallyDrop` មាន `repr(transparent)` ទាំងពីរនេះដូច្នេះយើងអាចបោះព្រួញ។
        self as *const _ as *const T
    }

    /// ទទួលបានការទស្សន៍ទ្រនិច mutable ទៅតម្លៃដែលមាននេះ។
    /// អានព្រួញនេះឬងាកវាទៅជាសេចក្ដីយោងគឺជាឥរិយាបទដែលមិនបានកំណត់ទេលុះត្រាតែ `MaybeUninit<T>` ត្រូវបានចាប់ផ្ដើម។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់ត្រឹមត្រូវនៃវិធីសាស្រ្តនេះ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // បង្កើតឯកសារយោងចូលទៅក្នុង `MaybeUninit<Vec<u32>>` ។
    /// // នេះគឺជាការមិនអីទេដោយសារតែយើងបានចាប់ផ្ដើមវា។
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *ការប្រើប្រាស់វិធីសាស្រ្តមិនត្រឹមត្រូវ* នេះ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // យើងបានបង្កើតសេចក្ដីយោងទៅ uninitiated vector មួយ!នេះជាឥរិយាបទដែលមិនបានកំណត់។⚠️
    /// ```
    ///
    /// (សូមកត់សម្គាល់ថាច្បាប់នៅជុំវិញយោងទៅទិន្នន័យមិនត្រូវបានបញ្ចប់ uninitiated ឡើយទេប៉ុន្តែរហូតដល់ពួកគេមាន, វាគឺជាទីប្រឹក្សាដើម្បីជៀសវាងពួកគេ។)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` និង `ManuallyDrop` មាន `repr(transparent)` ទាំងពីរនេះដូច្នេះយើងអាចបោះព្រួញ។
        self as *mut _ as *mut T
    }

    /// ដកស្រង់តម្លៃចេញពីកុងដង់ `MaybeUninit<T>` ។នេះគឺជាវិធីដ៏ល្អដើម្បីធានាថាទិន្នន័យនឹងត្រូវបានធ្លាក់ចុះពីព្រោះលទ្ធផល `T` គឺអាស្រ័យលើការទម្លាក់ធម្មតា។
    ///
    /// # Safety
    ///
    /// វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថា `MaybeUninit<T>` នេះពិតជាស្ថិតនៅក្នុងស្ថានភាពផ្តួចផ្តើមមួយ។ការហៅនេះនៅពេលដែលមាតិកាត្រូវបានចាប់ផ្ដើមយ៉ាងពេញលេញមិនទាន់មូលហេតុឥរិយាបថមិនបានកំណត់ជាបន្ទាន់។
    /// [type-level documentation][inv] មានបន្ថែមទៀតអំពីដែលមិនផ្លាស់ប្ដូរការចាប់ផ្ដើមនេះ។
    ///
    /// [inv]: #initialization-invariant
    ///
    /// នៅលើកំពូលនៃថា, ចងចាំថាប្រភេទភាគច្រើនមានផុសបន្ថែមទៀតលើសពីការគ្រាន់តែត្រូវបានចាត់ទុកចាប់ផ្ដើមនៅកម្រិតប្រភេទ។
    /// ឧទាហរណ៍: [`Vec<T>`] 1 'បានចាប់ផ្ដើមត្រូវបានចាត់ទុក-ចាប់ផ្ដើម (ដែលស្ថិតក្រោមការអនុវត្តនាពេលបច្ចុប្បន្ននេះមិនមានការធានាស្ថេរភាពមួយ) ដោយសារតែតម្រូវការតែមួយគត់ដែលចងក្រងដឹងអំពីវានោះគឺថាទស្សន៍ទ្រនិចទិន្នន័យត្រូវតែមិនទទេ។
    ///
    /// ការបង្កើត `Vec<T>` បែបនេះមិនបណ្តាលឱ្យ * ឥរិយាបទដែលមិនបានកំណត់ភ្លាមៗនោះទេប៉ុន្តែវានឹងបង្កឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់ជាមួយនឹងប្រតិបត្តិការដែលមានសុវត្ថិភាពបំផុត (រួមទាំងការទម្លាក់វា) ។
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់ត្រឹមត្រូវនៃវិធីសាស្រ្តនេះ:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *ការប្រើប្រាស់វិធីសាស្រ្តមិនត្រឹមត្រូវ* នេះ:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` មិនទាន់បានចាប់ផ្តើមនៅឡើយទេដូច្នេះខ្សែចុងក្រោយនេះបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `self` ត្រូវបានចាប់ផ្តើម។
        // នេះមានន័យថា `self` ត្រូវតែជាវ៉ារ្យ៉ង់ `value` ។
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// អានតម្លៃពីធុង `MaybeUninit<T>` នេះ។លទ្ធផល `T` គឺស្ថិតនៅក្រោមការគ្រប់គ្រងនៃការទម្លាក់ធម្មតា។
    ///
    /// នៅពេលណាដែលអាចធ្វើទៅបានវាជាការប្រសើរក្នុងការប្រើ [`assume_init`] ជំនួសវិញដែលការពារការចម្លងមាតិការបស់ `MaybeUninit<T>` ។
    ///
    /// # Safety
    ///
    /// វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថា `MaybeUninit<T>` នេះពិតជាស្ថិតនៅក្នុងស្ថានភាពផ្តួចផ្តើមមួយ។ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
    /// [type-level documentation][inv] មានបន្ថែមទៀតអំពីដែលមិនផ្លាស់ប្ដូរការចាប់ផ្ដើមនេះ។
    ///
    /// លើសពីនេះទៅទៀតស្លឹកនេះច្បាប់ចម្លងនៃទិន្នន័យដូចគ្នានៅពីក្រោយក្នុង `MaybeUninit<T>` នេះ។
    /// នៅពេលដែលប្រើច្បាប់ចម្លងនៃទិន្នន័យ (ដោយហៅ `assume_init_read` ច្រើនដង, ឬជាលើកដំបូងហើយបន្ទាប់មកការហៅ `assume_init_read` [`assume_init`]) វាគឺជាការទទួលខុសត្រូវរបស់អ្នកដើម្បីធានាថាទិន្នន័យដែលអាចត្រូវបានស្ទួនពិត។
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់ត្រឹមត្រូវនៃវិធីសាស្រ្តនេះ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` គឺ `Copy` ដូច្នេះយើងអាចអានច្រើនដង។
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // ស្ទួនមានតម្លៃ `None` គឺមិនអីទេដូច្នេះយើងអាចអានច្រើនដង។
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *ការប្រើប្រាស់វិធីសាស្រ្តមិនត្រឹមត្រូវ* នេះ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ឥឡូវនេះយើងបានបង្កើតពីរច្បាប់ចម្លងនៃ vector ដូចគ្នានាំឱ្យមានការដោយឥតគិតថ្លៃទ្វេដង⚠️នៅពេលដែលពួកគេទាំងពីរបានធ្លាក់ចុះទទួលបាន!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `self` ត្រូវបានចាប់ផ្តើម។
        // ការអានពី `self.as_ptr()` មានសុវត្ថិភាពចាប់តាំងពី `self` គួរតែត្រូវបានចាប់ផ្តើម។
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// ការធ្លាក់ចុះតម្លៃដែលមាននៅនឹងកន្លែង។
    ///
    /// ប្រសិនបើអ្នកមានកម្មសិទ្ធិរបស់ `MaybeUninit` អ្នកអាចប្រើ [`assume_init`] ជំនួសវិញ។
    ///
    /// # Safety
    ///
    /// វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថា `MaybeUninit<T>` នេះពិតជាស្ថិតនៅក្នុងស្ថានភាពផ្តួចផ្តើមមួយ។ហៅវានៅពេលមាតិកាមិនទាន់ត្រូវបានចាប់ផ្តើមពេញលេញបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
    ///
    /// នៅលើកំពូលនៃថា, ផុសបន្ថែមទៀតទាំងអស់នៃប្រភេទ `T` ត្រូវតែពេញចិត្ត, ជាការអនុវត្ត `Drop` នៃ `T` (ឬសមាជិករបស់ខ្លួន) អាចពឹងផ្អែកលើនេះ។
    /// ឧទាហរណ៍: [`Vec<T>`] 1 'បានចាប់ផ្ដើមត្រូវបានចាត់ទុក-ចាប់ផ្ដើម (ដែលស្ថិតក្រោមការអនុវត្តនាពេលបច្ចុប្បន្ននេះមិនមានការធានាស្ថេរភាពមួយ) ដោយសារតែតម្រូវការតែមួយគត់ដែលចងក្រងដឹងអំពីវានោះគឺថាទស្សន៍ទ្រនិចទិន្នន័យត្រូវតែមិនទទេ។
    ///
    /// ទម្លាក់ដូច `Vec<T>` ទោះជាយ៉ាងណានឹងបង្កឱ្យមានឥរិយាបថមិនបានកំណត់។
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // សុវត្ថិភាព: ការធានាទូរស័ព្ទចូលត្រូវតែត្រូវបានចាប់ផ្ដើមដែល `self` និង
        // ពេញចិត្តផុសទាំងអស់នៃ `T` ។
        // ទម្លាក់តម្លៃនៅនឹងកន្លែងគឺមានសុវត្ថិភាពប្រសិនបើនោះជាករណី។
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// ទទួលបានឯកសារយោងរួមមួយចំពោះតម្លៃដែលមាន។
    ///
    /// វាអាចមានប្រយោជន៍នៅពេលដែលយើងចង់ចូលដំណើរការ `MaybeUninit` ដែលត្រូវបានចាប់ផ្ដើមប៉ុន្តែមិនមានភាពជាម្ចាស់នៃ `MaybeUninit` នេះ (ការការពារការប្រើប្រាស់ `.assume_init()`) នេះ។
    ///
    /// # Safety
    ///
    /// ការហៅនេះនៅពេលដែលមាតិកាត្រូវបានចាប់ផ្ដើមយ៉ាងពេញលេញមិនទាន់មូលហេតុឥរិយាបថមិនបានកំណត់វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថា `MaybeUninit<T>` នេះពិតជាស្ថិតនៅក្នុងស្ថានភាពផ្តួចផ្តើមមួយ។
    ///
    ///
    /// # Examples
    ///
    /// ### ការប្រើប្រាស់ត្រឹមត្រូវនៃវិធីសាស្រ្តនេះ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // ការផ្តួចផ្តើ `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ឥឡូវនេះថា `MaybeUninit<_>` របស់យើងត្រូវបានគេស្គាល់ថាត្រូវបានចាប់ផ្ដើមវាជាការមិនអីទេក្នុងការបង្កើតជាឯកសារយោងចែករំលែកជាមួយទៅវា:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // សុវត្ថិភាព: `x` ត្រូវបានចាប់ផ្តើម។
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### * * មិនត្រឹមត្រូវ usages នៃវិធីសាស្រ្តនេះ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // យើងបានបង្កើតសេចក្ដីយោងទៅ uninitiated vector មួយ!នេះជាឥរិយាបទដែលមិនបានកំណត់។⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // ចាប់ផ្តើម `MaybeUninit` ដោយប្រើ `Cell::set`៖
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // សេចក្ដីយោងទៅនឹងការ uninitiated `Cell<bool>`: UB បាន!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `self` ត្រូវបានចាប់ផ្តើម។
        // នេះមានន័យថា `self` ត្រូវតែជាវ៉ារ្យ៉ង់ `value` ។
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// ទទួលបានសេចក្តីយោង (unique) ដែលអាចផ្លាស់ប្តូរបានចំពោះតម្លៃដែលមាន។
    ///
    /// វាអាចមានប្រយោជន៍នៅពេលដែលយើងចង់ចូលដំណើរការ `MaybeUninit` ដែលត្រូវបានចាប់ផ្ដើមប៉ុន្តែមិនមានភាពជាម្ចាស់នៃ `MaybeUninit` នេះ (ការការពារការប្រើប្រាស់ `.assume_init()`) នេះ។
    ///
    /// # Safety
    ///
    /// ការហៅនេះនៅពេលដែលមាតិកាត្រូវបានចាប់ផ្ដើមយ៉ាងពេញលេញមិនទាន់មូលហេតុឥរិយាបថមិនបានកំណត់វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថា `MaybeUninit<T>` នេះពិតជាស្ថិតនៅក្នុងស្ថានភាពផ្តួចផ្តើមមួយ។
    /// ឧទាហរណ៍ `.assume_init_mut()` មិនអាចត្រូវបានប្រើដើម្បីចាប់ផ្ដើម `MaybeUninit` មួយ។
    ///
    /// # Examples
    ///
    /// ### ការប្រើប្រាស់ត្រឹមត្រូវនៃវិធីសាស្រ្តនេះ:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ផ្តើម *ទាំងអស់* បៃនៃសតិបណ្ដោះអាសន្នបញ្ចូល។
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // ការផ្តួចផ្តើ `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // ឥឡូវនេះយើងដឹងថា `buf` ត្រូវបានចាប់ផ្ដើមដូច្នេះយើងអាច `.assume_init()` វា។
    /// // ទោះជាយ៉ាងណា, ការប្រើ `.assume_init()` អាចបង្ក `memcpy` នៃបៃ 2048 ។
    /// // ដើម្បីអះអាងសតិបណ្ដោះអាសន្នរបស់យើងត្រូវបានចាប់ផ្តើមដោយគ្មានការចម្លងវាយើងធ្វើឱ្យប្រសើរឡើង `&mut MaybeUninit<[u8; 2048]>` ទៅ `&mut [u8; 2048]` មួយ:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // សុវត្ថិភាព: `buf` ត្រូវបានចាប់ផ្តើម។
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ឥឡូវនេះយើងអាចប្រើ `buf` ជាមួយចំណែកធម្មតា:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### * * មិនត្រឹមត្រូវ usages នៃវិធីសាស្រ្តនេះ:
    ///
    /// អ្នកមិនអាចប្រើ `.assume_init_mut()` ចាប់ផ្ដើមតម្លៃមួយ:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // យើងបានបង្កើតឯកសារយោង (mutable) ទៅនឹង `bool` ដែលមិនមានឯកសិទ្ធិ!
    ///     // នេះគឺជាឥរិយាបទដែលមិនបានកំណត់។⚠️
    /// }
    /// ```
    ///
    /// ឧទាហរណ៍អ្នកមិនអាចចូលទៅក្នុងសតិបណ្ដោះអាសន្ន [`Read`] uninitiated:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) សេចក្ដីយោងទៅនឹងការចងចាំ uninitiated!
    ///                             // នេះគឺជាឥរិយាបទដែលមិនបានកំណត់។
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ហើយអ្នកក៏មិនអាចប្រើការចូលមើលដោយផ្ទាល់ទៅនឹងការចាប់ផ្តើមជាបណ្តើរ ៗ ពីមួយកន្លែងទៅមួយកន្លែងដែរ៖
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) សេចក្ដីយោងទៅនឹងការចងចាំ uninitiated!
    ///                  // នេះគឺជាឥរិយាបទដែលមិនបានកំណត់។
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) សេចក្ដីយោងទៅនឹងការចងចាំ uninitiated!
    ///                  // នេះគឺជាឥរិយាបទដែលមិនបានកំណត់។
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): បច្ចុប្បន្នយើងពឹងផ្អែកលើខាងលើនេះត្រូវបានមិនត្រឹមត្រូវពោលគឺយើងមានសេចក្ដីយោងទៅទិន្នន័យ uninitiated (ឧទា, ក្នុង `libcore/fmt/float.rs`) ។
    // យើងគួរតែធ្វើឱ្យការសម្រេចចិត្តចុងក្រោយអំពីច្បាប់នេះមុនពេលដែលមានស្ថេរភាព។
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `self` ត្រូវបានចាប់ផ្តើម។
        // នេះមានន័យថា `self` ត្រូវតែជាវ៉ារ្យ៉ង់ `value` ។
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// ដកស្រង់តម្លៃចេញពីអារេធុង `MaybeUninit` ។
    ///
    /// # Safety
    ///
    /// វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថាធាតុទាំងអស់នៃអារេគឺនៅក្នុងរដ្ឋផ្តួចផ្តើមមួយ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // សុវត្ថិភាព: ឥឡូវមានសុវត្ថិភាពដូចដែលយើងទាំងអស់ធាតុចាប់ផ្ដើម
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * នេះជាការធានាអ្នកហៅថាធាតុទាំងអស់នៃអារេត្រូវបានចាប់ផ្ដើម
        // * `MaybeUninit<T>` និង T ត្រូវបានធានាថាមានប្លង់តែមួយ
        // * ប្រហែលជាយូអិនមិនធ្លាក់ចុះទេដូច្នេះមិនមានទ្វេដងទេដូច្នេះការផ្លាស់ប្តូរមានសុវត្ថិភាព
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// សន្មត់ថាធាតុត្រូវបានចាប់ផ្ដើមទទួលបានអត្ថប្រយោជន៍ដល់ពួកគេ។
    ///
    /// # Safety
    ///
    /// វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថាធាតុ `MaybeUninit<T>` ពិតជាមាននៅក្នុងស្ថានភាពផ្តួចផ្តើមមួយ។
    ///
    /// ការហៅនេះនៅពេលដែលមាតិកាត្រូវបានចាប់ផ្ដើមយ៉ាងពេញលេញមិនទាន់មូលហេតុឥរិយាបថមិនបានកំណត់។
    ///
    /// សូមមើល [`assume_init_ref`] សម្រាប់សេចក្តីលម្អិតបន្ថែមនិងឧទាហរណ៍។
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // សុវត្ថិភាព: ការបោះដុំទៅជា `*const [T]` គឺមានសុវត្ថិភាពពីព្រោះអ្នកទូរស័ព្ទចូលធានា
        // `slice` ត្រូវបានចាប់ផ្តើមហើយ `ម៉ាយប៊្រីននីនិត` ត្រូវបានធានាថាមានប្លង់ដូចគ្នានឹង `T` ដែរ។
        // ទស្សន៍ទ្រនិចត្រឹមត្រូវទទួលនេះគឺដើម្បីចាប់តាំងពីវាមានអង្គចងចាំដែលជាកម្មសិទ្ធិរបស់សំដៅលើដោយ `slice` ដែលជាឯកសារយោងមួយហើយដូច្នេះបានធានាឱ្យមានសុពលភាពសម្រាប់ការអាន។
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// សន្មតថាធាតុទាំងអស់ត្រូវបានចាប់ផ្តើមទទួលបានចំណែកដែលអាចផ្លាស់ប្តូរបាន។
    ///
    /// # Safety
    ///
    /// វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថាធាតុ `MaybeUninit<T>` ពិតជាមាននៅក្នុងស្ថានភាពផ្តួចផ្តើមមួយ។
    ///
    /// ការហៅនេះនៅពេលដែលមាតិកាត្រូវបានចាប់ផ្ដើមយ៉ាងពេញលេញមិនទាន់មូលហេតុឥរិយាបថមិនបានកំណត់។
    ///
    /// សូមមើល [`assume_init_mut`] សម្រាប់សេចក្តីលម្អិតបន្ថែមនិងឧទាហរណ៍។
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // សុវត្ថិភាព: ស្រដៀងនឹងកំណត់ត្រាសុវត្ថិភាពសម្រាប់ `slice_get_ref` ប៉ុន្តែយើងមាន
        // សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានដែលត្រូវបានធានាថាមានសុពលភាពសម្រាប់ការសរសេរផងដែរ។
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// ដាក់ទ្រនិចទៅធាតុទីមួយនៃអារេ។
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// ទទួលបានការទស្សន៍ទ្រនិច mutable ទៅធាតុដំបូងរបស់អារ៉េ។
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// ចម្លងធាតុដែលបានមកពី `src` ទៅ `this` ត្រឡប់សេចក្ដីយោង mutable ទៅមាតិកាឥឡូវ initalized នៃ `this` ។
    ///
    /// ប្រសិនបើមាន `T` មិនអនុវត្ត `Copy` ប្រើ [`write_slice_cloned`]
    ///
    /// នេះគឺស្រដៀងគ្នាទៅនឹង [`slice::copy_from_slice`] ។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើចំណិតទាំងពីរមានប្រវែងខុសគ្នា។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // សុវត្ថិភាព: យើងទើបតែបានចម្លងធាតុទាំងអស់នៃលីនទៅក្នុងសមត្ថភាពទំនេរ
    /// // ធាតុ src.len() ដំបូងនៃ vec មានសុពលភាពឥឡូវនេះ។
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // សុវត្ថិភាព: &[T] និង [MaybeUninit<T>] មានប្លង់តែមួយ
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // សុវត្ថិភាព: ធាតុដែលមានសុពលភាពទើបតែបានចម្លងទៅ `this` ដូច្នេះវាត្រូវបាន initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// ក្លូនធាតុពី `src` ទៅ `this`, ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានទៅមាតិកាបច្ចុប្បន្ននៃ `this` ។
    /// ធាតុរួចទៅហើយណាមួយនឹង initalized មិនត្រូវបានធ្លាក់ចុះ។
    ///
    /// ប្រសិនបើមាន `Copy` `T` ប់ការប្រើ [`write_slice`]
    ///
    /// នេះគឺស្រដៀងគ្នាទៅនឹង [`slice::clone_from_slice`] ប៉ុន្តែមិនទម្លាក់ធាតុដែលមានស្រាប់។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើចំណិតទាំងពីរមានប្រវែងខុសគ្នា, ឬប្រសិនបើការអនុវត្តន៍ `Clone` panics នេះ។
    ///
    /// ប្រសិនបើមាន panic មួយធាតុក្លូនរួចហើយនឹងត្រូវបានធ្លាក់ចុះ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // សុវត្ថិភាព: យើងទើបតែក្លូនធាតុទាំងអស់នៃលីនទៅក្នុងសមត្ថភាពទំនេរ
    /// // ធាតុ src.len() ដំបូងនៃ vec មានសុពលភាពឥឡូវនេះ។
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // មិនដូច copy_from_slice នេះមិនហៅ clone_from_slice នៅលើចំណែកនេះគឺដោយសារ `MaybeUninit<T: Clone>` មិនបានអនុវត្តការក្លូនឡើយ។
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // សុវត្ថិភាព: ចំណែកឆៅនេះនឹងមានតែវត្ថុចាប់ផ្ដើម
                // នោះហើយជាមូលហេតុដែលវាត្រូវបានអនុញ្ញាតឱ្យទម្លាក់វា។
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: យើងត្រូវកាត់វាឱ្យត្រង់ទៅប្រវែងដូចគ្នា
        // សម្រាប់ការត្រួតពិនិត្យព្រំដែនត្រូវបានធ្វើឱ្យប្រសើរឡើងហើយកម្មវិធីបង្កើនប្រសិទ្ធភាពនឹងបង្កើត memcpy សម្រាប់ករណីសាមញ្ញ (ឧទាហរណ៍ T= u8) ។
        //
        let len = this.len();
        let src = &src[..len];

        // យាមគឺត្រូវបានត្រូវការ b/c panic អាចកើតឡើងក្នុងអំឡុងពេលក្លូន
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // សុវត្ថិភាព: ធាតុដែលមានសុពលភាពទើបតែបានសរសេរទៅក្នុង `this` ដូច្នេះវាត្រូវបាន initalized
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}