//! មុខងារជាមូលដ្ឋានសម្រាប់ការដោះស្រាយជាមួយនឹងការចងចាំ។
//!
//! ម៉ូឌុលនេះមានអនុគមន៍សម្រាប់សួរទំហំនិងការតម្រឹមនៃប្រភេទ, ចាប់ផ្ដើមនិងការគណនាឯកសារចងចាំ។
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// ភាពជាម្ចាស់និងការ "forgets" ចំណាយពេលប្រមាណជាតម្លៃ **ដោយមិនចាំបាច់រត់របស់ខ្លួន** បំផ្លាញ។
///
/// ធនធានណាមួយដែលតម្លៃគ្រប់គ្រងដូចជាអង្គចងចាំហ៊ារឬឧបករណ៍ដោះស្រាយឯកសារនឹងស្ថិតស្ថេរជារៀងរហូតក្នុងស្ថានភាពដែលមិនអាចទៅដល់។ទោះយ៉ាងណាក៏ដោយវាមិនធានាថាការចង្អុលបង្ហាញការចងចាំនេះនឹងនៅតែមានសុពលភាពទេ។
///
/// * ប្រសិនបើអ្នកចង់លេចធ្លាយចងចាំ, មើលឃើញ [`Box::leak`] ។
/// * ប្រសិនបើអ្នកចង់ទទួលបានព្រួញចង្អុលទៅសតិសូមមើល [`Box::into_raw`] ។
/// * ប្រសិនបើអ្នកចង់េបះេចនៃតម្លៃមួយឱ្យបានត្រឹមត្រូវ, ការរត់របស់ខ្លួនបំផ្លាញសូមមើល [`mem::drop`] ។
///
/// # Safety
///
/// `forget` មិនត្រូវបានសម្គាល់ថាជា `unsafe` ដោយសារតែការធានាសុវត្ថិភាព Rust មិនរួមបញ្ចូលទាំងការធានាថានឹងរត់តែងតែបំផ្លាញមួយ។
/// ឧទាហរណ៍កម្មវិធីមួយដែលអាចបង្កើតវដ្តឯកសារយោងមួយដោយប្រើ [`Rc`][rc] ឬហៅ [`process::exit`][exit] ដើម្បីចាកចេញដោយគ្មានការរត់បំផ្លាញ។
/// ដូច្នេះអនុញ្ញាតឱ្យ `mem::forget` ពីកូដដែលមានសុវត្ថិភាពមិនផ្លាស់ប្តូរការធានាសុវត្ថិភាព Rust ជាមូលដ្ឋានរបស់។
///
/// ដែលបាននិយាយថាការលេចធ្លាយធនធានដូចជាការចងចាំឬវត្ថុ I/O ជាធម្មតាមិនចង់បាន។
/// តម្រូវការនេះបានកើតឡើងនៅក្នុងការប្រើករណីពិសេសមួយចំនួនសម្រាប់អង្គការ FFI ឬកូដមិនមានសុវត្ថិភាពនោះទេប៉ុន្តែសូម្បីតែបន្ទាប់មក, [`ManuallyDrop`] ត្រូវបានពេញចិត្តជាធម្មតា។
///
/// ដោយសារតែការភ្លេចតម្លៃត្រូវបានអនុញ្ញាតកូដ `unsafe` ណាមួយដែលអ្នកសរសេរត្រូវតែអនុញ្ញាតសម្រាប់លទ្ធភាពនេះ។អ្នកមិនអាចប្រគល់តម្លៃវិញបានទេហើយសង្ឃឹមថាអ្នកទូរស័ព្ទចូលនឹងត្រូវបំផ្លាញអ្នកបំផ្លាញ។
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// ការប្រើប្រាស់កាំរស្មីអ៊ិច `mem::forget` គឺដើម្បីចៀសវាងអ្នកបំផ្លាញតម្លៃដែលបានអនុវត្តដោយ `Drop` trait ។ឧទាហរណ៍នេះនឹងលេចធ្លាយ `File` មួយពោលគឺ
/// ទាមទារទំហំទំនេរដោយអថេរប៉ុន្តែកុំបិទធនធានប្រព័ន្ធដែលនៅខាងក្រោម៖
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// វាមានប្រយោជន៍នៅពេលភាពជាម្ចាស់នៃធនធានមូលដ្ឋានត្រូវបានផ្ទេរទៅលេខកូដក្រៅ Rust ឧទាហរណ៍ដោយបញ្ជូនឯកសារពិពណ៌នាឯកសារដើមទៅលេខកូដ C ។
///
/// # ទំនាក់ទំនងជាមួយ `ManuallyDrop`
///
/// ខណៈពេលដែល `mem::forget` អាចត្រូវបានប្រើដើម្បីផ្ទេរការចងចាំ * * ភាពជាម្ចាស់ការធ្វើដូច្នេះគឺជាកំហុសងាយ។
/// [`ManuallyDrop`] គួរតែត្រូវបានប្រើជំនួសវិញ។សូមពិចារណាឧទាហរណ៍កូដនេះ:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // បង្កើត `String` ដោយប្រើមាតិការបស់ `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // លេចធ្លាយ `v` ដោយសារតែការចងចាំរបស់ខ្លួនឥឡូវនេះត្រូវបានគ្រប់គ្រងដោយ `s`
/// mem::forget(v);  // កំហុស, v មិនត្រឹមត្រូវនិងមិនត្រូវបានអនុម័តទៅជាមុខងារមួយ
/// assert_eq!(s, "Az");
/// // `s` ត្រូវបានធ្លាក់ចុះនិងការចងចាំរបស់ខ្លួនទាំងស្រុង deallocated ។
/// ```
///
/// មានបញ្ហាពីរជាមួយនឹងឧទាហរណ៍ខាងលើគឺ:
///
/// * ប្រសិនបើកូដជាច្រើនទៀតត្រូវបានគេបន្ថែមរវាងការសាងសង់ `String` និង scripts ហៅរបស់ `mem::forget()`, panic មួយក្នុងរយៈពេលមួយដែលវានឹងបណ្តាលឱ្យការចងចាំដោយឥតគិតពីរដងដូចគ្នានេះដែរពីព្រោះបានដោះស្រាយដោយទាំងពីរត្រូវនិង `s` `v` ។
/// * បន្ទាប់ពីទូរស័ព្ទទៅ `v.as_mut_ptr()` ហើយបញ្ជូនកម្មសិទ្ធិទិន្នន័យទៅ `s` តម្លៃ `v` មិនត្រឹមត្រូវ។
/// សូម្បីតែនៅពេលដែលតម្លៃទើបតែត្រូវបានផ្លាស់ប្តូរទៅ `mem::forget` (ដែលមិនត្រួតពិនិត្យវាក៏ដោយក៏ប្រភេទខ្លះមានតម្រូវការតឹងរឹងលើតម្លៃរបស់ពួកគេដែលធ្វើឱ្យពួកគេមិនមានសុពលភាពនៅពេលព្យួររឺលែងជាម្ចាស់។
/// ការប្រើប្រាស់តម្លៃមិនត្រឹមត្រូវតាមមធ្យោបាយណាមួយរាប់បញ្ចូលទាំងការបញ្ជូនពួកគេឬបញ្ជូនពួកគេពីមុខងារវិញបង្កើតបានជាឥរិយាបទដែលមិនបានកំណត់ហើយអាចបំបែកការសន្មតដែលធ្វើឡើងដោយអ្នកចងក្រង។
///
/// ប្តូរទៅ `ManuallyDrop` ចៀសវាងបញ្ហាទាំងពីរ៖
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // មុនពេលដែលយើងចូលទៅក្នុងផ្នែកខ្លះេះ `v` វត្ថុធាតុដើមរបស់ខ្លួន, ធ្វើឱ្យប្រាកដថាវាមិនទទួលបានបានធ្លាក់ចុះ!
/////
/// let mut v = ManuallyDrop::new(v);
/// // ឥឡូវផ្តាច់ `v` ។ប្រតិបត្ដិការទាំងនេះមិនអាច panic ដូច្នេះវាអាចមិនមានការលេចធ្លាយមួយ។
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // ជាចុងក្រោយ, កសាង `String` មួយ។
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` ត្រូវបានធ្លាក់ចុះនិងការចងចាំរបស់ខ្លួនទាំងស្រុង deallocated ។
/// ```
///
/// `ManuallyDrop` ការពារដោយមិនគិតថ្លៃទ្វេដងពីព្រោះយើងបិទអ្នកបំផ្លាញ `v` មុនពេលធ្វើអ្វីផ្សេងទៀត។
/// `mem::forget()` មិនអនុញ្ញាតវាទេព្រោះវាស៊ីសេចក្តីប្រកែករបស់វាបង្ខំឱ្យយើងហៅវាតែបន្ទាប់ពីដកស្រង់អ្វីដែលយើងត្រូវការពី `v` ។
/// ទោះបីជា panic ត្រូវបានណែនាំរវាងការស្ថាបនា `ManuallyDrop` និងការបង្កើតខ្សែអក្សរ (ដែលមិនអាចកើតឡើងនៅក្នុងលេខកូដដូចដែលបានបង្ហាញក៏ដោយ) វានឹងបណ្តាលឱ្យលេចធ្លាយហើយមិនមែនឥតគិតថ្លៃទ្វេដងទេ។
/// និយាយម្យ៉ាងទៀត `ManuallyDrop` ធ្វើខុសនៅម្ខាងនៃការលេចធ្លាយជំនួសឱ្យការធ្វើខុសនៅផ្នែកម្ខាងនៃការធ្លាក់ចុះ។
///
/// ដូចគ្នានេះផងដែរ `ManuallyDrop` រារាំងយើងមិនឱ្យមាន "touch" `v` បន្ទាប់ពីផ្ទេរកម្មសិទ្ធិទៅ `s`-ជំហានចុងក្រោយនៃការធ្វើអន្តរកម្មជាមួយ `v` ដើម្បីបោះចោលវាដោយមិនដំណើរការអ្នកបំផ្លាញរបស់វាត្រូវបានជៀសវាងទាំងស្រុង។
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// ដូចជា [`forget`] ប៉ុន្តែក៏ទទួលយកតម្លៃដែលមិនបានបញ្ជាក់។
///
/// មុខងារនេះគ្រាន់តែជាស្នាមភ្លឺដែលត្រូវបានបម្រុងទុកនៅពេលដែលលក្ខណៈពិសេស `unsized_locals` មានស្ថេរភាព។
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// ត្រឡប់ទំហំនៃប្រភេទមួយគិតជាបៃ។
///
/// អ្វីដែលពិសេសជាងនេះទៅទៀតនេះគឺជាអុហ្វសិតក្នុងបៃរវាងធាតុបន្តបន្ទាប់គ្នាក្នុងអារេមួយដែលមានប្រភេទធាតុនោះរាប់បញ្ចូលទាំងការតម្រឹមជួរ។
///
/// ដូច្នេះសម្រាប់ប្រភេទ `T` និងប្រវែង `n`, `[T; n]` មានទំហំ `n * size_of::<T>()` ។
///
/// ជាទូទៅទំហំនៃប្រភេទមួយមិនមានស្ថេរភាពនៅទូទាំងការចងក្រងទេប៉ុន្តែប្រភេទជាក់លាក់ដូចជាបឋម។
///
/// តារាងខាងក្រោមផ្តល់ទំហំសម្រាប់បឋម។
///
/// ប្រភេទ |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |៨ u128 |16 i8 |1 i16 |2 i32 |4 i64 |៨ i128 |16 f32 |4 f64 |៨ សន្លឹក |៤
///
/// លើសពីនេះទៀត `usize` និង `isize` មានទំហំដូចគ្នា។
///
/// ប្រភេទ `*const T`, `&T`, `Box<T>`, `Option<&T>`, និង `Option<Box<T>>` សុទ្ធតែមានទំហំដូចគ្នា។
/// ប្រសិនបើ `T` ត្រូវបានកំណត់ទំហំគ្រប់ប្រភេទទាំងអស់មានទំហំប៉ុន `usize` ។
///
/// ភាពប្រែប្រួលនៃទ្រនិចមិនផ្លាស់ប្តូរទំហំរបស់វាទេ។ដូច្នេះ `&T` និង `&mut T` មានទំហំដូចគ្នា។
/// ដូចគ្នាសម្រាប់ `*const T` និង `* mut T` ។
///
/// # ទំហំនៃធាតុ `#[repr(C)]`
///
/// តំណាង `C` សម្រាប់ធាតុមានប្លង់ដែលបានកំណត់។
/// ជាមួយនឹងប្លង់នេះទំហំនៃធាតុក៏មានស្ថេរភាពដែរដរាបណាវាលទាំងអស់មានទំហំថេរ។
///
/// ## ទំហំនៃរចនាសម្ព័ន្ធ
///
/// សម្រាប់ `structs` ទំហំត្រូវបានកំណត់ដោយក្បួនដោះស្រាយខាងក្រោម។
///
/// សម្រាប់វាលនីមួយៗនៅក្នុងរចនាសម្ព័ន្ធដែលបានរៀបចំតាមលំដាប់ប្រកាស:
///
/// 1. បន្ថែមទំហំនៃវាល។
/// 2. បង្គត់ទំហំបច្ចុប្បន្នទៅពហុគុណជិតបំផុតនៃប្រអប់បន្ទាប់ [alignment] ។
///
/// ចុងបញ្ចប់ប្រមូលទំហំនៃរចនាសម្ព័ន្ធទៅនឹងពហុគុណជិតបំផុតនៃ [alignment] របស់វា។
/// ការតម្រឹមនៃរចនាសម្ព័ន្ធជាធម្មតាការតម្រឹមធំបំផុតនៃវាលទាំងអស់របស់វា;នេះអាចត្រូវបានផ្លាស់ប្តូរជាមួយនឹងការប្រើប្រាស់ `repr(align(N))` ។
///
/// មិនដូច `C` ទេរចនាសម្ព័ន្ធដែលមានទំហំសូន្យមិនត្រូវបានបង្គត់រហូតដល់ទំហំមួយបៃទេ។
///
/// ## ទំហំនៃ Enums
///
/// អ៊ីនធឺរណែតដែលមិនមានទិន្នន័យក្រៅពីអ្នករើសអើងមានទំហំដូចគ្នានឹងអ៊ីសអ៊ីននៅលើវេទិកាដែលពួកគេត្រូវបានគេចងក្រងឡើង។
///
/// ## ទំហំសហជីព
///
/// ទំហំនៃសហជីពគឺជាទំហំនៃវាលធំបំផុតរបស់វា។
///
/// មិនដូច `C` ទេសហជីពដែលមានទំហំសូន្យមិនត្រូវបានបង្គត់រហូតដល់ទំហំមួយបៃទេ។
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // ដំបូងនៅមួយចំនួន
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // អារេខ្លះ
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // សមភាពទំហំស្សន៍ទ្រនិច
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// ការប្រើប្រាស់ `#[repr(C)]` ។
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // ទំហំនៃវាលដំបូងគឺ 1 ដូច្នេះបន្ថែម 1 ដល់ទំហំ។ទំហំគឺ 1 ។
/// // តម្រឹមវាលទីពីរនេះគឺ 2 ដូច្នេះបន្ថែម 1 ទៅនឹងទំហំសម្រាប់ចន្លោះ។ទំហំគឺ 2 ។
/// // ទំហំនៃវាលទីពីរនេះគឺ 2 ដូច្នេះបន្ថែម 2 ទៅទំហំ។ទំហំគឺ ៤ ។
/// // ការតម្រឹមនៃវាលទីបីគឺ 1 ដូច្នេះបន្ថែម 0 ទៅទំហំសម្រាប់ចន្លោះ។ទំហំ 4 ។
/// // ទំហំនៃវាលទីបីគឺ 1 ដូច្នេះបន្ថែម 1 ទៅទំហំ។ទំហំគឺ 5 ។
/// // ជាចុងក្រោយ, ការតម្រឹមនៃ struct នេះគឺ 2 (ដោយសារតែការតម្រឹមធំបំផុតក្នុងចំណោមវាលរបស់វាគឺ 2) ដូច្នេះបន្ថែម 1 ទៅនឹងទំហំសម្រាប់ចន្លោះនេះ។
/// // ទំហំគឺ 6 ។
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // រចនាសម្ព័ន្ធ Tuple ធ្វើតាមច្បាប់ដូចគ្នា។
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // ចំណាំថាការតម្រង់ជួរវាលអាចបន្ថយទំហំ។
/// // យើងអាចដកសន្លឹកបៀរទាំងសងខាងចេញដោយដាក់ `third` មុន `second` ។
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // ទំហំសហភាពគឺជាទំហំនៃវាលធំបំផុតនេះ។
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// ត្រឡប់ទំហំចង្អុលទៅតម្លៃគិតជាបៃ។
///
/// ជាទូទៅវាដូចគ្នានឹង `size_of::<T>()` ដែរ។
/// ទោះយ៉ាងណាក៏ដោយនៅពេល `T` * មិនមានទំហំដែលត្រូវបានគេស្គាល់ជាផ្លូវការឧទាហរណ៍ឧទាហរណ៏ [`[T]`][slice] រឺ [trait object] បន្ទាប់មក `size_of_val` អាចត្រូវបានប្រើដើម្បីទទួលបានទំហំដែលត្រូវបានគេស្គាល់តាមលក្ខណៈឌីជីថល។
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // សុវត្ថិភាព: `val` គឺជាឯកសារយោងដូច្នេះវាជាទ្រនិចចង្អុលឆៅត្រឹមត្រូវ
    unsafe { intrinsics::size_of_val(val) }
}

/// ត្រឡប់ទំហំចង្អុលទៅតម្លៃគិតជាបៃ។
///
/// ជាទូទៅវាដូចគ្នានឹង `size_of::<T>()` ដែរ។ទោះយ៉ាងណាក៏ដោយនៅពេល `T` * មិនមានទំហំដែលត្រូវបានគេស្គាល់តាមច្បាប់ឧទាហរណ៍ឧទាហរណ៏ [`[T]`][slice] រឺ [trait object] បន្ទាប់មក `size_of_val_raw` អាចត្រូវបានប្រើដើម្បីទទួលបានទំហំដែលត្រូវបានគេស្គាល់តាមលក្ខណៈឌីជីថល។
///
/// # Safety
///
/// មុខងារនេះមានសុវត្ថភាពក្នុងការហៅទូរស័ព្ទប្រសិនបើលក្ខខណ្ឌខាងក្រោមមានៈ
///
/// - ប្រសិនបើ `T` គឺជា `Sized` មុខងារនេះគឺមានសុវត្ថិភាពក្នុងការហៅ។
/// - ប្រសិនបើកន្ទុយដែលមិនបានបញ្ជាក់របស់ `T` គឺ៖
///     - [slice] បន្ទាប់មកប្រវែងនៃកន្ទុយដាច់ត្រូវតែជាចំនួនគត់ដែលបានចាប់ផ្តើមហើយទំហំនៃ *តម្លៃទាំងមូល*(ប្រវែងកន្ទុយថាមវន្ត + បុព្វបទមានទំហំតាមស្ថិតិ) ត្រូវតែសមនឹង `isize` ។
///     - [trait object] បន្ទាប់មកផ្នែកតុរប្យួររបស់ចង្អុលត្រូវចង្អុលទៅតុត្រឹមត្រូវដែលទទួលបានដោយការបង្ខិតបង្ខំដែលមិនបានកំណត់ហើយទំហំនៃតម្លៃ *ទាំងមូល*(ប្រវែងកន្ទុយថាមវន្ត + បុព្វបទមានទំហំតាមស្ថិតិ) ត្រូវតែសមនឹង `isize` ។
///
///     - មួយ (unstable) [extern type] បន្ទាប់មកមុខងារនេះគឺតែងតែមានសុវត្ថិភាពក្នុងការហៅទូរស័ព្ទប៉ុន្តែ panic ឬបើមិនដូច្នេះអាចនឹងវិលត្រឡប់មកវិញតម្លៃខុសដែលជាប្លង់ប្រភេទខាងក្រៅត្រូវបានមិនស្គាល់។
///     នេះគឺជាឥរិយាបថដូចគ្នានឹង [`size_of_val`] លើឯកសារយោងទៅប្រភេទមួយដែលមានកន្ទុយប្រភេទខាងក្រៅ។
///     - បើមិនដូច្នោះទេវាមិនត្រូវបានអនុញ្ញាតឱ្យហៅមុខងារនេះទេ។
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែផ្តល់នូវទ្រនិចចង្អុលឆៅត្រឹមត្រូវ
    unsafe { intrinsics::size_of_val(val) }
}

/// ត្រឡប់ការតម្រឹមអប្បបរមាដែលចង់បានតាមតម្រូវការរបស់ប្រភេទមួយ។
///
/// រាល់ការយោងទៅលើតម្លៃនៃប្រភេទ `T` ត្រូវតែជាលេខគុណនៃលេខនេះ។
///
/// នេះគឺជាការតម្រឹមដែលត្រូវបានប្រើសម្រាប់រចនាសម្ព័ន្ធ។វាអាចតូចជាងការតម្រឹមដែលពេញចិត្ត។
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ត្រឡប់ការតម្រឹមអប្បបរមា [ABI] ដែលចង់បានតាមប្រភេទនៃតម្លៃដែល `val` ចង្អុលទៅ។
///
/// រាល់ការយោងទៅលើតម្លៃនៃប្រភេទ `T` ត្រូវតែជាលេខគុណនៃលេខនេះ។
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // សុវត្ថិភាព: val គឺជាឯកសារយោងដូច្នេះវាជាទ្រនិចចង្អុលឆៅត្រឹមត្រូវ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ត្រឡប់ការតម្រឹមអប្បបរមាដែលចង់បានតាមតម្រូវការរបស់ប្រភេទមួយ។
///
/// រាល់ការយោងទៅលើតម្លៃនៃប្រភេទ `T` ត្រូវតែជាលេខគុណនៃលេខនេះ។
///
/// នេះគឺជាការតម្រឹមដែលត្រូវបានប្រើសម្រាប់រចនាសម្ព័ន្ធ។វាអាចតូចជាងការតម្រឹមដែលពេញចិត្ត។
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// ត្រឡប់ការតម្រឹមអប្បបរមា [ABI] ដែលចង់បានតាមប្រភេទនៃតម្លៃដែល `val` ចង្អុលទៅ។
///
/// រាល់ការយោងទៅលើតម្លៃនៃប្រភេទ `T` ត្រូវតែជាលេខគុណនៃលេខនេះ។
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // សុវត្ថិភាព: val គឺជាឯកសារយោងដូច្នេះវាជាទ្រនិចចង្អុលឆៅត្រឹមត្រូវ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ត្រឡប់ការតម្រឹមអប្បបរមា [ABI] ដែលចង់បានតាមប្រភេទនៃតម្លៃដែល `val` ចង្អុលទៅ។
///
/// រាល់ការយោងទៅលើតម្លៃនៃប្រភេទ `T` ត្រូវតែជាលេខគុណនៃលេខនេះ។
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// មុខងារនេះមានសុវត្ថភាពក្នុងការហៅទូរស័ព្ទប្រសិនបើលក្ខខណ្ឌខាងក្រោមមានៈ
///
/// - ប្រសិនបើ `T` គឺជា `Sized` មុខងារនេះគឺមានសុវត្ថិភាពក្នុងការហៅ។
/// - ប្រសិនបើកន្ទុយដែលមិនបានបញ្ជាក់របស់ `T` គឺ៖
///     - [slice] បន្ទាប់មកប្រវែងនៃកន្ទុយដាច់ត្រូវតែជាចំនួនគត់ដែលបានចាប់ផ្តើមហើយទំហំនៃ *តម្លៃទាំងមូល*(ប្រវែងកន្ទុយថាមវន្ត + បុព្វបទមានទំហំតាមស្ថិតិ) ត្រូវតែសមនឹង `isize` ។
///     - [trait object] បន្ទាប់មកផ្នែកតុរប្យួររបស់ចង្អុលត្រូវចង្អុលទៅតុត្រឹមត្រូវដែលទទួលបានដោយការបង្ខិតបង្ខំដែលមិនបានកំណត់ហើយទំហំនៃតម្លៃ *ទាំងមូល*(ប្រវែងកន្ទុយថាមវន្ត + បុព្វបទមានទំហំតាមស្ថិតិ) ត្រូវតែសមនឹង `isize` ។
///
///     - មួយ (unstable) [extern type] បន្ទាប់មកមុខងារនេះគឺតែងតែមានសុវត្ថិភាពក្នុងការហៅទូរស័ព្ទប៉ុន្តែ panic ឬបើមិនដូច្នេះអាចនឹងវិលត្រឡប់មកវិញតម្លៃខុសដែលជាប្លង់ប្រភេទខាងក្រៅត្រូវបានមិនស្គាល់។
///     នេះគឺជាឥរិយាបថដូចគ្នានឹង [`align_of_val`] លើឯកសារយោងទៅប្រភេទមួយដែលមានកន្ទុយប្រភេទខាងក្រៅ។
///     - បើមិនដូច្នោះទេវាមិនត្រូវបានអនុញ្ញាតឱ្យហៅមុខងារនេះទេ។
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែផ្តល់នូវទ្រនិចចង្អុលឆៅត្រឹមត្រូវ
    unsafe { intrinsics::min_align_of_val(val) }
}

/// ត្រឡប់ `true` ប្រសិនបើទម្លាក់តម្លៃនៃប្រភេទ `T` សំខាន់។
///
/// នេះជាព័ត៌មានជំនួយបង្កើនប្រសិទ្ធិភាពហើយអាចត្រូវបានអនុវត្តដោយអភិរក្ស៖
/// វាអាចត្រឡប់ `true` សម្រាប់ប្រភេទដែលមិនត្រូវការទម្លាក់។
/// ក្នុងនាមជាការត្រឡប់ `true` តែងតែជាការអនុវត្តត្រឹមត្រូវនៃមុខងារនេះ។ទោះយ៉ាងណាក៏ដោយប្រសិនបើមុខងារនេះពិតជាត្រឡប់មកវិញ `false` បន្ទាប់មកអ្នកអាចប្រាកដថាការទម្លាក់ `T` មិនមានផលប៉ះពាល់ទេ។
///
/// ការអនុវត្តកម្រិតទាបនៃវត្ថុដូចជាការប្រមូលដែលត្រូវការទម្លាក់ទិន្នន័យរបស់ពួកគេដោយដៃគួរតែប្រើមុខងារនេះដើម្បីជៀសវាងការព្យាយាមមិនចាំបាច់ទម្លាក់មាតិការបស់ពួកគេនៅពេលពួកគេត្រូវបានបំផ្លាញ។
///
/// នេះប្រហែលជាមិនធ្វើឱ្យមានភាពខុសប្លែកគ្នានៅក្នុងការស្ថាបនាការចេញផ្សាយ (ដែលរង្វិលជុំដែលមិនមានផលប៉ះពាល់ត្រូវបានរកឃើញនិងលុបបំបាត់បានយ៉ាងងាយស្រួល) ប៉ុន្តែជារឿយៗជាជោគជ័យដ៏ធំមួយសម្រាប់ការបង្កើតកំហុស។
///
/// ចំណាំថា [`drop_in_place`] អនុវត្តការត្រួតពិនិត្យនេះរួចហើយដូច្នេះប្រសិនបើបន្ទុកការងាររបស់អ្នកអាចត្រូវបានកាត់បន្ថយទៅមួយចំនួនតូចនៃការហៅទូរស័ព្ទ [`drop_in_place`] ការប្រើនេះមិនចាំបាច់ទេ។
/// ជាពិសេសត្រូវកត់សំគាល់ថាអ្នកអាច [`drop_in_place`] មួយចំណែកហើយវានឹងធ្វើការត្រួតពិនិត្យតំរូវការសំរាប់តំលៃទាំងអស់។
///
/// ប្រភេទដូចជា Vec ដូច្នេះគ្រាន់តែ `drop_in_place(&mut self[..])` ដោយមិនប្រើ `needs_drop` យ៉ាងជាក់លាក់។
/// ប្រភេទដូចជា [`HashMap`] ផ្ទុយទៅវិញត្រូវទម្លាក់តម្លៃម្តងមួយៗហើយគួរតែប្រើ API នេះ។
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// នេះជាឧទាហរណ៍ពីរបៀបដែលការប្រមូលផ្តុំអាចប្រើ `needs_drop`៖
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // ទិន្នន័យនេះបានធ្លាក់ចុះ
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// ត្រឡប់តម្លៃនៃប្រភេទ `T` ដែលតំណាងដោយលំនាំបៃ-សូន្យទាំងអស់។
///
/// នេះមានន័យថាឧទាហរណ៍សន្លឹកបៃនៅក្នុង `(u8, u16)` មិនចាំបាច់សូន្យទេ។
///
/// មិនមានការធានាទេថាគំរូបៃសូន្យទាំងអស់តំណាងឱ្យតម្លៃត្រឹមត្រូវនៃប្រភេទ `T` ប្រភេទខ្លះ។
/// ឧទាហរណ៍គំរូបៃសូន្យទាំងអស់មិនមែនជាតម្លៃត្រឹមត្រូវសម្រាប់ប្រភេទឯកសារយោង (`&T`, `&mut T`) និងមុខងារចង្អុល។
/// ការប្រើប្រាស់ `zeroed` លើប្រភេទបែបនេះបណ្តាលឱ្យ [undefined behavior][ub] បន្ទាន់ព្រោះ [the Rust compiler assumes][inv] តែងតែមានតម្លៃត្រឹមត្រូវនៅក្នុងអថេរដែលវាចាត់ទុកថាបានចាប់ផ្តើម។
///
///
/// នេះមានឥទ្ធិពលដូចគ្នានឹង [`MaybeUninit::zeroed().assume_init()`][zeroed] ដែរ។
/// ពេលខ្លះវាមានប្រយោជន៍សម្រាប់អេហ្វអេអាយអាយប៉ុន្តែជាទូទៅគួរតែជៀសវាង។
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// ការប្រើប្រាស់ត្រឹមត្រូវនៃមុខងារនេះ: ការចាប់ផ្តើមចំនួនគត់ជាមួយសូន្យ។
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *ការប្រើប្រាស់មិនត្រឹមត្រូវ* នៃមុខងារនេះ៖ ការចាប់ផ្តើមសេចក្តីយោងជាមួយសូន្យ។
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // ឥរិយាបទមិនបានកំណត់!
/// let _y: fn() = unsafe { mem::zeroed() }; // ហើយម្តងទៀត!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាតម្លៃសូន្យទាំងអស់មានសុពលភាពសម្រាប់ `T` ។
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// ការត្រួតពិនិត្យការចាប់ផ្តើមនៃការចងចាំធម្មតារបស់ប៊ីបស៊ីសហ្សូហ្សូសហ្ស៊ីហ្សហ្ស៊ីដោយធ្វើពុតដើម្បីផលិតតម្លៃនៃប្រភេទ `T` ខណៈពេលដែលមិនធ្វើអ្វីទាំងអស់។
///
/// **មុខងារនេះត្រូវបានបដិសេធ** ប្រើ [`MaybeUninit<T>`] ជំនួសវិញ។
///
/// ហេតុផលសម្រាប់ការបដិសេធគឺមុខងារមិនអាចត្រូវបានប្រើត្រឹមត្រូវទេវាមានឥទ្ធិពលដូចគ្នានឹង [`MaybeUninit::uninit().assume_init()`][uninit] ដែរ។
///
/// ដូចដែល [`assume_init` documentation][assume_init] ពន្យល់ [the Rust compiler assumes][inv] ដែលតម្លៃត្រូវបានចាប់ផ្តើមយ៉ាងត្រឹមត្រូវ។
/// ជាផលវិបាកការហៅឧ
/// `mem::uninitialized::<bool>()` បណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់ភ្លាមៗសម្រាប់ការត្រលប់មកវិញនូវ `bool` ដែលមិនមែនជា `true` ឬ `false` ទេ។
/// អាក្រក់ជាងនេះទៅទៀតការចងចាំដោយមិនចាំបាច់ដូចជាអ្វីដែលត្រូវបានត្រលប់មកទីនេះវិញគឺពិសេសដែលអ្នកចងក្រងដឹងថាវាមិនមានតម្លៃថេរ។
/// នេះធ្វើឱ្យវាមានអាកប្បកិរិយាដែលមិនបានកំណត់ដើម្បីមានទិន្នន័យដែលមិនមានឯកសិទ្ធិនៅក្នុងអថេរទោះបីជាអថេរនោះមានប្រភេទចំនួនគត់ក៏ដោយ។
/// (សូមកត់សម្គាល់ថាច្បាប់ដែលនៅជុំវិញចំនួនគត់ uninitiated មិនត្រូវបានបញ្ចប់នៅឡើយទេប៉ុន្តែរហូតដល់ពួកគេមាន, វាគឺជាទីប្រឹក្សាដើម្បីជៀសវាងពួកគេ។)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាតម្លៃឯកតាគឺមានសុពលភាពសម្រាប់ `T` ។
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// ប្តូរតម្លៃនៅទីតាំងពីរដែលអាចផ្លាស់ប្តូរបានដោយមិនធ្វើឱ្យខូចទីតាំងណាមួយឡើយ។
///
/// * ប្រសិនបើអ្នកចង់ប្តូរជាមួយតម្លៃលំនាំដើមឬអត់ចេះសោះសូមមើល [`take`] ។
/// * ប្រសិនបើអ្នកចង់ប្តូរជាមួយតម្លៃដែលបានកន្លងផុតដោយប្រគល់តម្លៃចាស់សូមមើល [`replace`] ។
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // សុវត្ថិភាព: ចង្អុលបង្ហាញឆៅត្រូវបានបង្កើតចេញពីឯកសារយោងដែលអាចផ្លាស់ប្តូរបានប្រកបដោយសុវត្ថិភាពដែលអាចបំពេញបាន
    // ឧបសគ្គនៅលើ `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// ជំនួស `dest` ជាមួយនឹងតម្លៃលំនាំដើមនៃ `T` ត្រឡប់តម្លៃ `dest` មុន។
///
/// * ប្រសិនបើអ្នកចង់ជំនួសតម្លៃនៃអថេរពីរសូមមើល [`swap`] ។
/// * ប្រសិនបើអ្នកចង់ជំនួសដោយតម្លៃដែលបានឆ្លងកាត់ជំនួសឱ្យតម្លៃលំនាំដើមសូមមើល [`replace`] ។
///
/// # Examples
///
/// ឧទាហរណ៍សាមញ្ញ៖
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` អនុញ្ញាតឱ្យទទួលយកភាពជាម្ចាស់នៃវាលរចនាសម្ព័ន្ធដោយជំនួសវាដោយតម្លៃ "empty" ។
/// បើគ្មាន `take` ទេអ្នកអាចជួបបញ្ហាដូចខាងក្រោមៈ
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// ចំណាំថា `T` មិនចាំបាច់អនុវត្ត [`Clone`] ទេដូច្នេះវាមិនអាចសូម្បីតែក្លូននិងកំណត់ `self.buf` ឡើងវិញទេ។
/// ប៉ុន្តែ `take` អាចត្រូវបានប្រើដើម្បីផ្តាច់តម្លៃដើមនៃ `self.buf` ពី `self` ដែលអនុញ្ញាតឱ្យវាត្រឡប់មកវិញ:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// ផ្លាស់ទី `src` ទៅក្នុង `dest` ដែលបានយោងដោយត្រឡប់តម្លៃ `dest` មុន។
///
/// មិនត្រូវបានទម្លាក់តម្លៃទេ។
///
/// * ប្រសិនបើអ្នកចង់ជំនួសតម្លៃនៃអថេរពីរសូមមើល [`swap`] ។
/// * ប្រសិនបើអ្នកចង់ជំនួសដោយតម្លៃលំនាំដើមសូមមើល [`take`] ។
///
/// # Examples
///
/// ឧទាហរណ៍សាមញ្ញ៖
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` អនុញ្ញាតឱ្យការប្រើប្រាស់វាលរចនាសម្ព័ន្ធដោយជំនួសវាដោយតម្លៃផ្សេងទៀត។
/// បើគ្មាន `replace` ទេអ្នកអាចជួបបញ្ហាដូចខាងក្រោមៈ
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// ចំណាំថា `T` មិនចាំបាច់អនុវត្ត [`Clone`] ទេដូច្នេះយើងមិនអាចសូម្បីតែក្លូន `self.buf[i]` ដើម្បីចៀសវាងការផ្លាស់ប្តូរ។
/// ប៉ុន្តែ `replace` អាចត្រូវបានប្រើដើម្បីផ្តាច់តម្លៃដើមនៅសន្ទស្សន៍នោះពី `self` ដែលអនុញ្ញាតឱ្យវាត្រូវបានប្រគល់ជូនវិញ៖
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // សុវត្ថិភាព: យើងអានពី `dest` ប៉ុន្តែសរសេរ `src` ដោយផ្ទាល់ទៅក្នុងនោះបន្ទាប់មក
    // ដែលថាតម្លៃចាស់មិនត្រូវបានចម្លង។
    // គ្មានអ្វីត្រូវបានធ្លាក់ចុះហើយគ្មានអ្វីនៅទីនេះអាច panic ។
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// បោះចោលតម្លៃ។
///
/// នេះធ្វើដូច្នេះដោយហៅការអនុវត្តអាគុយម៉ង់ [`Drop`][drop] ។
///
/// នេះមិនមានប្រសិទ្ធិភាពអ្វីសម្រាប់ប្រភេទដែលអនុវត្ត `Copy`, ឧ
/// integers.
/// តម្លៃបែបនេះត្រូវបានថតចម្លងហើយ _then_ បានប្តូរទៅមុខងារដូច្នេះតម្លៃនៅតែបន្តបន្ទាប់ពីការហៅមុខងារនេះ។
///
///
/// មុខងារនេះមិនមែនជាមន្តអាគមទេ។វាត្រូវបានកំណត់ជាព្យញ្ជនៈ
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// ដោយសារតែ `_x` ត្រូវបានផ្លាស់ប្តូរទៅក្នុងមុខងារវាត្រូវបានទម្លាក់ដោយស្វ័យប្រវត្តិមុនពេលមុខងារត្រឡប់មកវិញ។
///
/// [drop]: Drop
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // យ៉ាងជាក់លាក់ធ្លាក់ចុះ vector នេះ
/// ```
///
/// ចាប់តាំងពី [`RefCell`] អនុវត្តច្បាប់ខ្ចីប្រាក់នៅពេលដំណើរការរួច `drop` អាចបញ្ចេញប្រាក់កម្ចី [`RefCell`]៖
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // លះបង់លើ mutable ខ្ចីរន្ធដោតនេះ
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// អាំងតេក្រាលនិងប្រភេទដទៃទៀតអនុវត្ត [`Copy`] មិនត្រូវបានប៉ះពាល់ដោយ `drop` ទេ។
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // ច្បាប់ចម្លងនៃ `x` ត្រូវបានផ្លាស់ទីនិងទម្លាក់
/// drop(y); // ច្បាប់ចម្លងនៃ `y` មួយត្រូវបានផ្លាស់ទីនិងបានធ្លាក់ចុះ
///
/// println!("x: {}, y: {}", x, y.0); // នៅទំនេរ
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// បកស្រាយ `src` ថាមានប្រភេទ `&U` ហើយបន្ទាប់មកអាន `src` ដោយមិនផ្លាស់ប្តូរតម្លៃដែលមាន។
///
/// មុខងារនេះនឹងសន្មតថាទ្រនិច `src` មានសុពលភាពសម្រាប់ [`size_of::<U>`][size_of] បៃដោយបញ្ជូន `&T` ទៅ `&U` ហើយបន្ទាប់មកអាន `&U` (លើកលែងតែថានេះត្រូវបានធ្វើតាមរបៀបត្រឹមត្រូវសូម្បីតែ `&U` ធ្វើឱ្យតម្រូវការតម្រឹមតឹងរ៉ឹងជាង `&T`) ។
/// វាក៏នឹងបង្កើតច្បាប់ចម្លងនៃតម្លៃដែលមានជំនួសឱ្យការផ្លាស់ប្តូរចេញពី `src` ។
///
/// វាមិនមែនជាកំហុសក្នុងការចងក្រងពេលវេលាទេប្រសិនបើ `T` និង `U` មានទំហំខុសៗគ្នាប៉ុន្តែវាត្រូវបានលើកទឹកចិត្តឱ្យប្រើតែមុខងារនេះដែល `T` និង `U` មានទំហំដូចគ្នា។មុខងារនេះកេះ [undefined behavior][ub] ប្រសិនបើ `U` ធំជាង `T` ។
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // ចម្លងទិន្នន័យពី 'foo_array' និងព្យាបាលវាដូច 'Foo' មួយ
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // កែប្រែទិន្នន័យដែលបានចម្លង
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // មាតិកានៃ 'foo_array' មិនគួរបានផ្លាស់ប្តូរ
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // ប្រសិនបើយូមានតម្រូវការតម្រឹមខ្ពស់ជាង src ប្រហែលជាមិនត្រូវបានតម្រឹមសមស្របទេ។
    if align_of::<U>() > align_of::<T>() {
        // សុវត្ថិភាព: `src` គឺជាឯកសារយោងដែលធានាថាអាចអានបាន។
        // អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាការបញ្ជូនពិតប្រាកដមានសុវត្ថិភាព។
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // សុវត្ថិភាព: `src` គឺជាឯកសារយោងដែលធានាថាអាចអានបាន។
        // យើងទើបតែពិនិត្យមើលថា `src as *const U` ត្រូវបានតម្រឹមត្រឹមត្រូវ។
        // អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាការបញ្ជូនពិតប្រាកដមានសុវត្ថិភាព។
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// ប្រភេទស្រអាប់តំណាងឱ្យការរើសអើងនៃអេណាម។
///
/// មើលមុខងារ [`discriminant`] នៅក្នុងម៉ូឌុលនេះសម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. ការអនុវត្តន៍ trait ទាំងនេះមិនអាចត្រូវបានគេយកមកប្រើនោះទេព្រោះយើងមិនចង់បានព្រំដែននៅលើ T ទេ។

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// ត្រឡប់តម្លៃពិសេសមួយដែលសម្គាល់វ៉ារ្យ៉ង់អង់ហ្ស៊ីមក្នុង `v` ។
///
/// ប្រសិនបើ `T` មិនមែនជាអង់ស៊ីមទេការហៅមុខងារនេះនឹងមិនបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់ទេប៉ុន្តែតម្លៃត្រឡប់មកវិញមិនត្រូវបានបញ្ជាក់ទេ។
///
///
/// # Stability
///
/// ការរើសអើងនៃបំរែបំរួលអេននីអាចផ្លាស់ប្តូរប្រសិនបើនិយមន័យអ៊ីនណូមផ្លាស់ប្តូរ
/// ការរើសអើងនៃវ៉ារ្យ៉ង់មួយចំនួននឹងមិនផ្លាស់ប្តូររវាងការចងក្រងជាមួយអ្នកតែងដូចគ្នាទេ។
///
/// # Examples
///
/// វាអាចត្រូវបានប្រើដើម្បីប្រៀបធៀបបណ្ណាល័យដែលផ្ទុកទិន្នន័យខណៈដែលមិនយកចិត្តទុកដាក់លើទិន្នន័យជាក់ស្តែង៖
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// ត្រឡប់ចំនួនបំរែបំរួលនៅក្នុងប្រភេទអ៊ីមអិល `T` ។
///
/// ប្រសិនបើ `T` មិនមែនជាអង់ស៊ីមទេការហៅមុខងារនេះនឹងមិនបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់ទេប៉ុន្តែតម្លៃត្រឡប់មកវិញមិនត្រូវបានបញ្ជាក់ទេ។
/// ដូចគ្នានេះដែរប្រសិនបើ `T` គឺជាអង់ហ្ស៊ីមដែលមានវ៉ារ្យ៉ង់ច្រើនជាង `usize::MAX` តម្លៃត្រឡប់មកវិញមិនត្រូវបានបញ្ជាក់ទេ។
/// វ៉ារ្យ៉ង់គ្មានមនុស្សរស់នៅនឹងត្រូវបានរាប់។
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}