#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// ការ `RawWaker` អនុញ្ញាតឱ្យ implementor នៃប្រតិបត្តិភារកិច្ចដើម្បីបង្កើត [`Waker`] ដែលផ្តល់នូវឥរិយាបថ wakeup តាមបំណង។
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// វាមានទស្សន៍ទ្រនិចទិន្នន័យនិង [virtual function pointer table (vtable)][vtable] ដែលប្ដូរឥរិយាបថនៃ `RawWaker` នេះ។
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// ទ្រនិចទិន្នន័យដែលអាចត្រូវបានប្រើដើម្បីរក្សាទុកទិន្នន័យតាមអំពើចិត្តតាមតម្រូវការរបស់អ្នកប្រតិបត្តិ។
    /// នេះអាចជាឧ
    /// ទ្រនិចដែលបានលុបប្រភេទទៅ `Arc` ដែលត្រូវបានផ្សារភ្ជាប់ជាមួយនឹងភារកិច្ច។
    /// តម្លៃនៃវាលនេះត្រូវបានបញ្ជូនទៅមុខងារទាំងអស់ដែលជាផ្នែកមួយនៃតុរប្យួរដែលជាប៉ារ៉ាម៉ែត្រដំបូង។
    ///
    data: *const (),
    /// តារាងព្រួញមុខងារនិម្មិតដែលបានប្ដូរឥរិយាបទនៃ waker នេះ។
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// បង្កើត `RawWaker` ថ្មីពីទ្រនិច `data` ដែលបានផ្តល់និង `vtable` ។
    ///
    /// ទ្រនិច `data` អាចត្រូវបានប្រើដើម្បីរក្សាទុកទិន្នន័យដែលបំពានតាមតម្រូវការរបស់អ្នកប្រតិបត្តិ។នេះអាចជាឧ
    /// ទ្រនិចដែលបានលុបប្រភេទទៅ `Arc` ដែលត្រូវបានផ្សារភ្ជាប់ជាមួយនឹងភារកិច្ច។
    /// តម្លៃនៃទ្រនិចនេះនឹងត្រូវបានបញ្ជូនទៅមុខងារទាំងអស់ដែលជាផ្នែកនៃ `vtable` ដែលជាប៉ារ៉ាម៉ែត្រដំបូង។
    ///
    /// `vtable` ប្តូរឥរិយាបថរបស់ `Waker` ដែលបង្កើតពី `RawWaker` ។
    /// សម្រាប់ប្រតិបត្តិការនីមួយៗនៅលើ `Waker` មុខងារដែលទាក់ទងនៅក្នុង `vtable` នៃមូលដ្ឋាន `RawWaker` នឹងត្រូវបានគេហៅថា។
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// តារាងព្រួញមុខងារមួយបាននិម្មិត (vtable) ដែលបញ្ជាក់ឥរិយាបថនៃ [`RawWaker`] មួយ។
///
/// ទ្រនិចដែលបានបញ្ជូនទៅមុខងារទាំងអស់នៅខាងក្នុងតុគឺទ្រនិច `data` ពីវត្ថុ [`RawWaker`] ព័ទ្ធជុំវិញ។
///
/// មុខងារនៅខាងក្នុងរចនាសម្ព័ន្ធនេះត្រូវបានបម្រុងទុកដើម្បីត្រូវបានគេហៅថានៅលើទ្រនិច `data` នៃវត្ថុ [`RawWaker`] ដែលបានសាងសង់ត្រឹមត្រូវពីខាងក្នុងការអនុវត្ត [`RawWaker`] ។
/// ការហៅមុខងារមួយក្នុងចំណោមមុខងារដែលមានដោយប្រើទ្រនិច `data` ផ្សេងទៀតនឹងបង្កឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// មុខងារនេះនឹងត្រូវបានគេហៅថានៅពេលក្លូន [`RawWaker`] ត្រូវបានក្លូនឧទាហរណ៍នៅពេលដែល [`Waker`] ដែល [`RawWaker`] ត្រូវបានផ្ទុកត្រូវបានក្លូន។
    ///
    /// ការអនុវត្តមុខងារនេះត្រូវតែរក្សាទុកធនធានទាំងអស់ដែលត្រូវការសម្រាប់ឧទាហរណ៍បន្ថែមនៃ [`RawWaker`] និងភារកិច្ចដែលជាប់ទាក់ទង។
    /// ការហៅ `wake` លទ្ធផល [`RawWaker`] នៅលើគួរតែមានលទ្ធផលនៅក្នុងការ wakeup ភារកិច្ចដូចគ្នានេះដែរដែលនឹងត្រូវបាន awoken ដោយ [`RawWaker`] ដើមមួយ។
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// មុខងារនេះនឹងត្រូវបានគេហៅថានៅពេល `wake` ត្រូវបានហៅនៅលើ [`Waker`] ។
    /// វាត្រូវតែភ្ញាក់ឡើងនូវភារកិច្ចដែលទាក់ទងនឹង [`RawWaker`] នេះ។
    ///
    /// ការអនុវត្តមុខងារនេះត្រូវតែធ្វើឱ្យប្រាកដថាដើម្បីបញ្ចេញធនធានណាមួយដែលត្រូវបានផ្សារភ្ជាប់ជាមួយនឹងឧទាហរណ៍នៃ [`RawWaker`] មួយនិងភារកិច្ចដែលជាប់ទាក់ទងនេះ។
    ///
    ///
    wake: unsafe fn(*const ()),

    /// មុខងារនេះនឹងត្រូវបានគេហៅថានៅពេល `wake_by_ref` ត្រូវបានហៅនៅលើ [`Waker`] ។
    /// វាត្រូវតែភ្ញាក់ឡើងនូវភារកិច្ចដែលទាក់ទងនឹង [`RawWaker`] នេះ។
    ///
    /// មុខងារនេះប្រហាក់ប្រហែលនឹង `wake` ប៉ុន្តែមិនត្រូវប្រើប្រាស់ទ្រនិចទិន្នន័យដែលបានផ្តល់ឱ្យនោះទេ។
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// មុខងារនេះត្រូវបានគេហៅថានៅពេលដែល [`RawWaker`] ត្រូវបានទម្លាក់។
    ///
    /// ការអនុវត្តមុខងារនេះត្រូវតែធ្វើឱ្យប្រាកដថាដើម្បីបញ្ចេញធនធានណាមួយដែលត្រូវបានផ្សារភ្ជាប់ជាមួយនឹងឧទាហរណ៍នៃ [`RawWaker`] មួយនិងភារកិច្ចដែលជាប់ទាក់ទងនេះ។
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// បង្កើត `RawWakerVTable` ថ្មីពីមុខងារ `clone`, `wake`, `wake_by_ref` និង `drop` ដែលបានផ្តល់។
    ///
    /// # `clone`
    ///
    /// មុខងារនេះនឹងត្រូវបានគេហៅថានៅពេលក្លូន [`RawWaker`] ត្រូវបានក្លូនឧទាហរណ៍នៅពេលដែល [`Waker`] ដែល [`RawWaker`] ត្រូវបានផ្ទុកត្រូវបានក្លូន។
    ///
    /// ការអនុវត្តមុខងារនេះត្រូវតែរក្សាទុកធនធានទាំងអស់ដែលត្រូវការសម្រាប់ឧទាហរណ៍បន្ថែមនៃ [`RawWaker`] និងភារកិច្ចដែលជាប់ទាក់ទង។
    /// ការហៅ `wake` លទ្ធផល [`RawWaker`] នៅលើគួរតែមានលទ្ធផលនៅក្នុងការ wakeup ភារកិច្ចដូចគ្នានេះដែរដែលនឹងត្រូវបាន awoken ដោយ [`RawWaker`] ដើមមួយ។
    ///
    /// # `wake`
    ///
    /// មុខងារនេះនឹងត្រូវបានគេហៅថានៅពេល `wake` ត្រូវបានហៅនៅលើ [`Waker`] ។
    /// វាត្រូវតែភ្ញាក់ឡើងនូវភារកិច្ចដែលទាក់ទងនឹង [`RawWaker`] នេះ។
    ///
    /// ការអនុវត្តមុខងារនេះត្រូវតែធ្វើឱ្យប្រាកដថាដើម្បីបញ្ចេញធនធានណាមួយដែលត្រូវបានផ្សារភ្ជាប់ជាមួយនឹងឧទាហរណ៍នៃ [`RawWaker`] មួយនិងភារកិច្ចដែលជាប់ទាក់ទងនេះ។
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// មុខងារនេះនឹងត្រូវបានគេហៅថានៅពេល `wake_by_ref` ត្រូវបានហៅនៅលើ [`Waker`] ។
    /// វាត្រូវតែភ្ញាក់ឡើងនូវភារកិច្ចដែលទាក់ទងនឹង [`RawWaker`] នេះ។
    ///
    /// មុខងារនេះប្រហាក់ប្រហែលនឹង `wake` ប៉ុន្តែមិនត្រូវប្រើប្រាស់ទ្រនិចទិន្នន័យដែលបានផ្តល់ឱ្យនោះទេ។
    ///
    /// # `drop`
    ///
    /// មុខងារនេះត្រូវបានគេហៅថានៅពេលដែល [`RawWaker`] ត្រូវបានទម្លាក់។
    ///
    /// ការអនុវត្តមុខងារនេះត្រូវតែធ្វើឱ្យប្រាកដថាដើម្បីបញ្ចេញធនធានណាមួយដែលត្រូវបានផ្សារភ្ជាប់ជាមួយនឹងឧទាហរណ៍នៃ [`RawWaker`] មួយនិងភារកិច្ចដែលជាប់ទាក់ទងនេះ។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` នៃភារកិច្ចអសមកាល។
///
/// បច្ចុប្បន្ននេះ `Context` បម្រើតែមួយគត់ដើម្បីផ្ដល់នូវការចូលដំណើរការទៅកាន់ `&Waker` ដែលអាចត្រូវបានប្រើដើម្បីភ្ញាក់ភារកិច្ចបច្ចុប្បន្ន។
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // ធានាថាយើង future-ភស្តុតាងប្រឆាំងនឹងការផ្លាស់ប្តូរដោយបង្ខំឱ្យអាយុកាលមិនប្រែប្រួល (អាយុកាលជំហរអាគុយម៉ង់គឺផ្ទុយគ្នាខណៈពេលដែលអាយុកាលវិលត្រឡប់គឺមានភាពមិនច្បាស់) ។
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// បង្កើត `Context` ថ្មីពី `&Waker` មួយ។
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// ត្រឡប់សេចក្តីយោងទៅ `Waker` សម្រាប់ភារកិច្ចបច្ចុប្បន្ន។
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// ការ `Waker` គឺចំណុចទាញសម្រាប់ភ្ញាក់ឡើងមួយដោយជូនដំណឹងដល់ភារកិច្ចរបស់ខ្លួនថាវាប្រតិបត្តិត្រៀមខ្លួនជាស្រេចដែលនឹងត្រូវបានជាការរត់មួយ។
///
/// ចំណុចទាញនេះ encapsulates ឧទាហរណ៍ [`RawWaker`] ដែលកំណត់ឥរិយាបថភ្ញាក់ដឹងខ្លួនប្រតិបត្តិជាក់លាក់។
///
///
/// អនុវត្ត [`Clone`], [`Send`], និង [`Sync`] ។
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// ភ្ញាក់ពីការងារដែលទាក់ទងនឹង `Waker` នេះ។
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // ការហៅឱ្យភ្ញាក់ដឹងខ្លួនពិតប្រាកដត្រូវបានផ្ទេរតាមរយៈការហៅមុខងារជាក់ស្តែងមួយទៅការអនុវត្តដែលត្រូវបានកំណត់ដោយអ្នកប្រតិបត្តិ។
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // កុំទូរស័ព្ទទៅ `drop`-អ្នករៀបចំនឹងត្រូវបានស៊ីដោយ `wake` ។
        crate::mem::forget(self);

        // សុវត្ថិភាព: នេះគឺមានសុវត្ថិភាពដោយសារតែ `Waker::from_raw` គឺជាវិធីតែមួយគត់
        // ដើម្បីចាប់ផ្តើម `wake` X និង `data` ដែល តម្រូវឲ្យ អ្នកប្រើប្រាស់ទទួលស្គាល់ថាកិច្ចសន្យារបស់ `RawWaker` ត្រូវបានតម្លើង។
        //
        unsafe { (wake)(data) };
    }

    /// ភ្ញាក់ពីការងារដែលទាក់ទងនឹង `Waker` នេះដោយមិនចាំបាច់ប្រើប្រាស់ `Waker` ។
    ///
    /// នេះគឺស្រដៀងគ្នាទៅនឹង `wake` ប៉ុន្តែអាចប្រហែលជាមានប្រសិទ្ធិភាពតិចជាងបន្តិចក្នុងករណីដែលមួយ `Waker` ជាកម្មសិទ្ធិគឺអាចរកបាន។
    /// វិធីសាស្ត្រនេះគួរតែត្រូវបានគេពេញចិត្តក្នុងការហៅទូរស័ព្ទទៅ `waker.clone().wake()` ។
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // ការហៅឱ្យភ្ញាក់ដឹងខ្លួនពិតប្រាកដត្រូវបានផ្ទេរតាមរយៈការហៅមុខងារជាក់ស្តែងមួយទៅការអនុវត្តដែលត្រូវបានកំណត់ដោយអ្នកប្រតិបត្តិ។
        //

        // សុវត្ថិភាព: សូមមើល `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `Waker` នេះនិង `Waker` ផ្សេងទៀតបានធ្វើឱ្យមានកិច្ចការដូចគ្នា។
    ///
    /// អនុគមន៍នេះធ្វើការនៅលើមូលដ្ឋានដែលល្អបំផុតកិច្ចខិតខំប្រឹងប្រែងនិងអាចវិលត្រឡប់មកវិញមិនពិតសូម្បីតែនៅពេលនេះ `Waker`s នឹងដាស់ភារកិច្ចដូចគ្នា។
    /// ទោះយ៉ាងណាក៏ដោយប្រសិនបើមុខងារនេះត្រឡប់មកវិញ `true` វាត្រូវបានធានាថា `វីនឃឺរនឹងភ្ញាក់ដឹងខ្លួនដូចគ្នា។
    ///
    /// មុខងារនេះត្រូវបានប្រើជាចម្បងសម្រាប់គោលបំណងបង្កើនប្រសិទ្ធភាព។
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// បង្កើត `Waker` ថ្មីពី [`RawWaker`] ។
    ///
    /// ឥរិយាបថរបស់ `Waker` ត្រឡប់មកវិញនេះត្រូវបានកំណត់ប្រសិនបើកិច្ចសន្យាដែលបានកំណត់នៅក្នុង [`RawWaker`] និង [`RawWakerVTable`] របស់ឯកសារមិនត្រូវបានគាំទ្រ។
    ///
    /// ដូច្នេះវិធីសាស្ត្រនេះមិនមានសុវត្ថិភាពទេ។
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // សុវត្ថិភាព: នេះគឺមានសុវត្ថិភាពដោយសារតែ `Waker::from_raw` គឺជាវិធីតែមួយគត់
            // ដើម្បីចាប់ផ្តើម `clone` និង `data` តម្រូវឱ្យអ្នកប្រើដើម្បីទទួលស្គាល់ថាកិច្ចសន្យានៃការ [`RawWaker`] ត្រូវបានតម្កល់។
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // សុវត្ថិភាព: នេះគឺមានសុវត្ថិភាពដោយសារតែ `Waker::from_raw` គឺជាវិធីតែមួយគត់
        // ដើម្បីចាប់ផ្តើម `drop` និង `data` តម្រូវឱ្យអ្នកប្រើដើម្បីទទួលស្គាល់ថាកិច្ចសន្យានៃការ `RawWaker` ត្រូវបានតម្កល់។
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}