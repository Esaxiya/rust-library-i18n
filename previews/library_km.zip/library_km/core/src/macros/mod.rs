#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // ពង្រីកដល់ `$crate::panic::panic_2015` ឬ `$crate::panic::panic_2021` អាស្រ័យលើការបោះពុម្ពផ្សាយរបស់អ្នកទូរស័ព្ទចូល។
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// អះអាងថាកន្សោមពីរគឺស្មើគ្នាទៅវិញទៅ (ដោយប្រើ [`PartialEq`]) ។
///
/// នៅថ្ងៃទី panic, ម៉ាក្រូនេះនឹងបោះពុម្ពតម្លៃនៃកន្សោមជាមួយតំណាងបំបាត់កំហុសរបស់ពួកគេ។
///
///
/// ដូច [`assert!`], ម៉ាក្រូនេះមានសំណុំបែបបទដែលជាលើកទីពីរ, ដែលជាកន្លែងដែលជាសារ panic ផ្ទាល់ខ្លួនអាចត្រូវបានផ្តល់ឱ្យ។
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // គោលការណ៍ណែនាំខាងក្រោមគឺជាចេតនា។
                    // បើគ្មានពួកគេ, រន្ធដោតជង់សម្រាប់ការខ្ចីគឺត្រូវបានចាប់ផ្ដើមសូម្បីតែមុនពេលដែលតម្លៃនេះត្រូវបានប្រៀបធៀប, នាំឱ្យមានការធ្លាក់ចុះគួរឱ្យកត់សម្គាល់យឺត។
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // គោលការណ៍ណែនាំខាងក្រោមគឺជាចេតនា។
                    // បើគ្មានពួកគេ, រន្ធដោតជង់សម្រាប់ការខ្ចីគឺត្រូវបានចាប់ផ្ដើមសូម្បីតែមុនពេលដែលតម្លៃនេះត្រូវបានប្រៀបធៀប, នាំឱ្យមានការធ្លាក់ចុះគួរឱ្យកត់សម្គាល់យឺត។
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// អះអាងថាកន្សោមពីរនេះគឺមិនស្មើគ្នា (ដោយប្រើ [`PartialEq`]) ។
///
/// នៅថ្ងៃទី panic, ម៉ាក្រូនេះនឹងបោះពុម្ពតម្លៃនៃកន្សោមជាមួយតំណាងបំបាត់កំហុសរបស់ពួកគេ។
///
///
/// ដូច [`assert!`], ម៉ាក្រូនេះមានសំណុំបែបបទដែលជាលើកទីពីរ, ដែលជាកន្លែងដែលជាសារ panic ផ្ទាល់ខ្លួនអាចត្រូវបានផ្តល់ឱ្យ។
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // គោលការណ៍ណែនាំខាងក្រោមគឺជាចេតនា។
                    // បើគ្មានពួកគេ, រន្ធដោតជង់សម្រាប់ការខ្ចីគឺត្រូវបានចាប់ផ្ដើមសូម្បីតែមុនពេលដែលតម្លៃនេះត្រូវបានប្រៀបធៀប, នាំឱ្យមានការធ្លាក់ចុះគួរឱ្យកត់សម្គាល់យឺត។
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // គោលការណ៍ណែនាំខាងក្រោមគឺជាចេតនា។
                    // បើគ្មានពួកគេ, រន្ធដោតជង់សម្រាប់ការខ្ចីគឺត្រូវបានចាប់ផ្ដើមសូម្បីតែមុនពេលដែលតម្លៃនេះត្រូវបានប្រៀបធៀប, នាំឱ្យមានការធ្លាក់ចុះគួរឱ្យកត់សម្គាល់យឺត។
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// បញ្ជាក់ថាកន្សោមប៊ូលីនគឺ `true` ពេលរត់។
///
/// នេះនឹងហៅម៉ាក្រូ [`panic!`] X ប្រសិនបើកន្សោមដែលបានផ្តល់មិនអាចត្រូវបានវាយតម្លៃទៅ `true` នៅពេលដំណើរការ។
///
/// ដូចជា [`assert!`] ម៉ាក្រូនេះក៏មានជំនាន់ទី ២ ដែរដែលសារ panic ផ្ទាល់ខ្លួនអាចត្រូវបានផ្តល់ជូន។
///
/// # Uses
///
/// មិនដូច [`assert!`] របាយការណ៍ `debug_assert!` ត្រូវបានអនុញ្ញាតតែនៅក្នុងការមិនបានធ្វើឱ្យប្រសើរបានកសាងដោយលំនាំដើម។
/// ការស្ថាបនាដែលបានធ្វើឱ្យប្រសើរនឹងមិនប្រតិបត្តិសេចក្តីថ្លែងការណ៍ `debug_assert!` ទេលុះត្រាតែ `-C debug-assertions` ត្រូវបានបញ្ជូនទៅអ្នកចងក្រង។
/// នេះធ្វើឱ្យមានប្រយោជន៍សម្រាប់ការត្រួតពិនិត្យ `debug_assert!` ដែលមានតម្លៃថ្លៃផងដែរដើម្បីឱ្យមានវត្តមាននៅក្នុងការចេញផ្សាយការស្ថាបនាប៉ុន្តែអាចប្រហែលជាមានប្រយោជន៍ក្នុងអំឡុងពេលការអភិវឌ្ឍ។
/// លទ្ធផលនៃការពង្រីក `debug_assert!` នេះត្រូវបានតែងតែជាប្រភេទធីក។
///
/// ការអះអាងដែលមិនបានធីកអនុញ្ញាតឱ្យអាននៅក្នុងកម្មវិធីមួយក្នុងការមិនជាប់លាប់រដ្ឋរក្សាការរត់ដែលអាចមានផលវិបាកដែលមិនរំពឹងទុកប៉ុន្តែមិនណែនាំ unsafety ដរាបណានេះកើតឡើងតែនៅក្នុងលេខកូដសុវត្ថិភាព។
///
/// ការចំណាយការសម្តែងនៃការអះអាង, ទោះជាយ៉ាងណាមិនត្រូវបានវាស់បាននៅក្នុងទូទៅ។
/// ការជំនួស [`assert!`] ជាមួយ `debug_assert!` ដូច្នេះត្រូវបានលើកទឹកចិត្តបន្ទាប់ពីការវាយតំលៃយ៉ាងហ្មត់ចត់ហើយសំខាន់ជាងនេះទៅទៀតមានតែនៅក្នុងលេខកូដសុវត្ថិភាពប៉ុណ្ណោះ!
///
/// # Examples
///
/// ```
/// // សារ panic សម្រាប់ការអះអាងទាំងនេះគឺជាគុណតម្លៃនៃកន្សោមដែលបានផ្តល់។
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // មុខងារសាមញ្ញណាស់
/// debug_assert!(some_expensive_computation());
///
/// // អះអាងជាមួយសារផ្ទាល់ខ្លួន
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// បញ្ជាក់ថាកន្សោមពីរគឺស្មើគ្នា។
///
/// នៅថ្ងៃទី panic, ម៉ាក្រូនេះនឹងបោះពុម្ពតម្លៃនៃកន្សោមជាមួយតំណាងបំបាត់កំហុសរបស់ពួកគេ។
///
/// មិនដូច [`assert_eq!`] របាយការណ៍ `debug_assert_eq!` ត្រូវបានអនុញ្ញាតតែនៅក្នុងការមិនបានធ្វើឱ្យប្រសើរបានកសាងដោយលំនាំដើម។
/// ការស្ថាបនាដែលបានធ្វើឱ្យប្រសើរនឹងមិនប្រតិបត្តិសេចក្តីថ្លែងការណ៍ `debug_assert_eq!` ទេលុះត្រាតែ `-C debug-assertions` ត្រូវបានបញ្ជូនទៅអ្នកចងក្រង។
/// នេះធ្វើឱ្យមានប្រយោជន៍សម្រាប់ការត្រួតពិនិត្យ `debug_assert_eq!` ដែលមានតម្លៃថ្លៃផងដែរដើម្បីឱ្យមានវត្តមាននៅក្នុងការចេញផ្សាយការស្ថាបនាប៉ុន្តែអាចប្រហែលជាមានប្រយោជន៍ក្នុងអំឡុងពេលការអភិវឌ្ឍ។
///
/// លទ្ធផលនៃការពង្រីក `debug_assert_eq!` នេះត្រូវបានតែងតែជាប្រភេទធីក។
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// អះអាងថាកន្សោមពីរមិនស្មើគ្នា។
///
/// នៅថ្ងៃទី panic, ម៉ាក្រូនេះនឹងបោះពុម្ពតម្លៃនៃកន្សោមជាមួយតំណាងបំបាត់កំហុសរបស់ពួកគេ។
///
/// មិនដូច [`assert_ne!`] របាយការណ៍ `debug_assert_ne!` ត្រូវបានអនុញ្ញាតតែនៅក្នុងការមិនបានធ្វើឱ្យប្រសើរបានកសាងដោយលំនាំដើម។
/// ការស្ថាបនាធ្វើឱ្យប្រសើរឡើងនឹងមិនប្រតិបត្តិសេចក្តីថ្លែងការណ៍ `debug_assert_ne!` ទេលុះត្រាតែ `-C debug-assertions` ត្រូវបានអនុម័តក្នុងការចងក្រង។
/// នេះធ្វើឱ្យមានប្រយោជន៍សម្រាប់ការត្រួតពិនិត្យ `debug_assert_ne!` ដែលមានតម្លៃថ្លៃផងដែរដើម្បីឱ្យមានវត្តមាននៅក្នុងការចេញផ្សាយការស្ថាបនាប៉ុន្តែអាចប្រហែលជាមានប្រយោជន៍ក្នុងអំឡុងពេលការអភិវឌ្ឍ។
///
/// លទ្ធផលនៃការពង្រីក `debug_assert_ne!` នេះត្រូវបានតែងតែជាប្រភេទធីក។
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// ត្រឡប់មកវិញថាតើការបញ្ចេញមតិដែលបានផ្ដល់ឱ្យត្រូវគ្នានឹងការណាមួយនៃលំនាំដែលបានផ្ដល់ឱ្យ។
///
/// ដូចជានៅក្នុងការបញ្ចេញមតិ `match`, លំនាំដែលអាចត្រូវបានអនុវត្តតាមស្រេចចិត្តដោយ `if` និងការបញ្ចេញមតិយាមមួយដែលមានការចូលដំណើរការទៅឈ្មោះចងភ្ជាប់ដោយលំនាំ។
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Unwraps លទ្ធផលឬការបន្តពូជកំហុសរបស់ខ្លួន។
///
/// ប្រតិបត្តិករ `?` ត្រូវបានបន្ថែមដើម្បីជំនួស `try!` និងគួរតែត្រូវបានប្រើជំនួសវិញ។
/// លើសពីនេះទៀត `try` គឺជាពាក្យបម្រុងក្នុង Rust ឆ្នាំ 2018, ដូច្នេះប្រសិនបើអ្នកត្រូវតែប្រើវាអ្នកនឹងត្រូវការប្រើ [raw-identifier syntax][ris] នេះ: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` ផ្គូផ្គង [`Result`] ដែលបានផ្តល់ឱ្យ។នៅក្នុងករណីនៃវ៉ារ្យ៉ង់ `Ok` ពាក្យនេះមានតម្លៃនៃតម្លៃរុំនេះ។
///
/// នៅក្នុងករណីនៃវ៉ារ្យ៉ង់ `Err` វាបានទៅយកកំហុសខាងក្នុង។`try!` បន្ទាប់មកធ្វើការបំលែងដោយប្រើ `From` ។
/// ការបម្លែងដោយស្វ័យប្រវត្តិនេះផ្ដល់ឱ្យនូវកំហុសឯកទេសនិងរវាងអ្នកដែលទូទៅបន្ថែមទៀត។
/// បន្ទាប់មកកំហុសជាលទ្ធផលត្រូវបានត្រឡប់ភ្លាម។
///
/// ដោយសារតែការត្រឡប់មកវិញដំបូង `try!` អាចត្រូវបានប្រើតែនៅក្នុងមុខងារដែលត្រឡប់ [`Result`] ប៉ុណ្ណោះ។
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // វិធីសាស្រ្តដែលពេញចិត្តនៃការវិលត្រឡប់កំហុសរហ័ស
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // វិធីសាស្ត្រមុននៃការវិលត្រឡប់មកវិញយ៉ាងរហ័សកំហុស
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // នេះគឺស្មើនឹង:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// សរសេរទិន្នន័យដែលបានធ្វើទ្រង់ទ្រាយទៅក្នុងសតិបណ្ដោះអាសន្នមួយ។
///
/// ម៉ាក្រូនេះបានទទួលយក 'writer' មួយខ្សែអក្សរទ្រង់ទ្រាយ, និងបញ្ជីនៃអាគុយម៉ង់មួយ។
/// អាគុយម៉ង់នឹងត្រូវបានធ្វើទ្រង់ទ្រាយតាមខ្សែអក្សរទ្រង់ទ្រាយដែលបានបញ្ជាក់ហើយលទ្ធផលនឹងត្រូវបានបញ្ជូនទៅក្បាលនេះ។
/// អ្នកនិពន្ធអាចមានតម្លៃណាមួយជាមួយនឹងវិធីសាស្ត្រ `write_fmt`;ជាទូទៅវាមកពីការអនុវត្តទាំង [`fmt::Write`] ឬ [`io::Write`] trait ។
/// បានត្រឡប់មកវិញអ្វីដែល `write_fmt` ម៉ាក្រូត្រឡប់មកវិញវិធីសាស្រ្ត!ជាទូទៅ [`fmt::Result`] ឬ [`io::Result`] ។
///
/// មើល [`std::fmt`] សម្រាប់ព័ត៌មានបន្ថែមអំពីវាក្យសម្ព័ន្ធខ្សែអក្សរទ្រង់ទ្រាយ។
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ម៉ូឌុលអាចនាំចូលទាំងពីរ `std::fmt::Write` និង `std::io::Write` និងការហៅ `write!` នៅលើវត្ថុដែលបានអនុវត្តទាំង, ជាវត្ថុមិនធម្មតាអនុវត្តទាំងពីរ។
///
/// ទោះជាយ៉ាងណា, ម៉ូឌុលត្រូវតែនាំចូល traits នេះមានលក្ខណៈសម្បត្តិគ្រប់គ្រាន់ដូច្នេះឈ្មោះរបស់ពួកគេធ្វើមិនបានការប៉ះទង្គិច:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // ប្រើ fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // ប្រើ io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: ម៉ាក្រូនេះអាចត្រូវបានប្រើនៅក្នុងការរៀបចំ `no_std` ផងដែរ។
/// នៅក្នុងការរៀបចំ `no_std` អ្នកទទួលខុសត្រូវចំពោះព័ត៌មានលម្អិតនៃការអនុវត្តសមាសធាតុ។
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// សរសេរទិន្នន័យដែលបានធ្វើទ្រង់ទ្រាយទៅក្នុងសតិបណ្ដោះអាសន្នដោយមានបន្ទាត់ថ្មីបន្ថែមមួយ។
///
/// នៅលើវេទិកាទាំងអស់, បន្ទាត់ថ្មីនេះគឺមានតួអក្សរបន្ទាត់ (`\n`/`U+000A`) តែម្នាក់ឯងចំណី (គ្មានបន្ថែមទៀតបញ្ជូនត្រឡប់ (`\r`/`U+000D`) ។
///
/// សម្រាប់ពបន្ថែមសូមមើល [`write!`] ។សម្រាប់ពលើរូបមន្តខ្សែអក្សរទ្រង់ទ្រាយ, មើលឃើញ [`std::fmt`] ។
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ម៉ូឌុលអាចនាំចូលទាំងពីរ `std::fmt::Write` និង `std::io::Write` និងការហៅ `write!` នៅលើវត្ថុដែលបានអនុវត្តទាំង, ជាវត្ថុមិនធម្មតាអនុវត្តទាំងពីរ។
/// ទោះជាយ៉ាងណា, ម៉ូឌុលត្រូវតែនាំចូល traits នេះមានលក្ខណៈសម្បត្តិគ្រប់គ្រាន់ដូច្នេះឈ្មោះរបស់ពួកគេធ្វើមិនបានការប៉ះទង្គិច:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // ប្រើ fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // ប្រើ io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// បង្ហាញថាលេខកូដមិនអាចទៅដល់។
///
/// វាមានប្រយោជន៍គ្រប់ពេលដែលអ្នកចងក្រងមិនអាចកំណត់ថាលេខកូដខ្លះមិនអាចទៅដល់។ឧទាហរណ៍:
///
/// * ផ្គូផ្គងអាវុធដោយមានលក្ខខណ្ឌយាម។
/// * រង្វិលជុំដែលជាថាមវន្តបញ្ចប់។
/// * ឧបករណ៍បំលែងដែលបញ្ចប់ដោយថាមវន្ត។
///
/// ប្រសិនបើការប្តេជ្ញាចិត្តថាលេខកូដមិនអាចទៅដល់បានបង្ហាញថាមិនត្រឹមត្រូវកម្មវិធីភ្លាមៗត្រូវបញ្ចប់ដោយ [`panic!`] X ។
///
/// នេះជាសមភាគីគ្មានសុវត្ថិភាពនៃម៉ាក្រូនេះគឺមានមុខងារ [`unreachable_unchecked`] ដែលនឹងបង្កឱ្យមានឥរិយាបថមិនបានបញ្ជាក់ប្រសិនបើលេខកូដត្រូវបានឈានដល់។
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ឆន្ទៈនេះតែងតែ [`panic!`] ។
///
/// # Examples
///
/// ផ្គូផ្គងអាវុធ:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // ចងក្រងកំហុសប្រសិនបើអ្នកបានអធិប្បាយចេញ
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // មួយនៃការអនុវត្តក្រីក្របំផុតនៃ x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// បង្ហាញថាលេខកូដមិនបានអនុវត្តដោយការភ័យខ្លាចជាមួយនឹងសារនៃ "not implemented" មួយ។
///
/// នេះអនុញ្ញាតឱ្យកូដរបស់អ្នកក្នុងការពិនិត្យប្រភេទដែលមានប្រយោជន៍ប្រសិនបើអ្នកត្រូវបានគេ prototyping ឬការអនុវត្តដែលតម្រូវឱ្យមានវិធីសាស្រ្ត trait ច្រើនដែលអ្នកធ្វើមិនបានទាំងអស់ផែនការប្រើប្រាស់នៃការ។
///
/// ភាពខុសគ្នារវាង `unimplemented!` និង [`todo!`] នោះគឺថាខណៈពេលដែល `todo!` ន័យជាចេតនានៃការអនុវត្តមុខងារនៅពេលក្រោយនិងសារគឺ "not yet implemented", `unimplemented!` ធ្វើឱ្យគ្មានការអះអាងបែបនេះ។
/// សាររបស់វាគឺ "not implemented" ។
/// IDEs មួយចំនួននឹងសម្គាល់ `ការងារត្រូវធ្វើ!` s ។
///
/// # Panics
///
/// ឆន្ទៈនេះតែងតែ [`panic!`] ទេព្រោះ `unimplemented!` គឺគ្រាន់តែជាហ្ក៍សម្រាប់ `panic!` ជាមួយថេរ, សារជាក់លាក់មួយ។
///
/// ដូច `panic!` ម៉ាក្រូនេះមានទម្រង់ទីពីរសម្រាប់បង្ហាញតម្លៃផ្ទាល់ខ្លួន។
///
/// # Examples
///
/// និយាយថាយើងមាន trait `Foo`៖
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// យើងចង់អនុវត្ត `Foo` សម្រាប់ 'MyStruct', ប៉ុន្តែសម្រាប់ហេតុផលមួយចំនួនវាធ្វើឱ្យតែយល់ដើម្បីអនុវត្តមុខងារ `bar()` ។
/// `baz()` និង `qux()` នឹងនៅតែត្រូវការដើម្បីត្រូវបានកំណត់នៅក្នុងការអនុវត្តរបស់យើងនៃការ `Foo` ប៉ុន្តែយើងអាចប្រើ `unimplemented!` នៅក្នុងការកំណត់របស់ពួកគេដើម្បីអនុញ្ញាតឱ្យកូដរបស់យើងដើម្បីចងក្រង។
///
/// យើងនៅតែចង់ឱ្យមានការបញ្ឈប់កម្មវិធីដែលកំពុងរត់របស់យើងប្រសិនបើមានវិធីសាស្រ្តមិនបានអនុវត្តត្រូវបានឈានដល់។
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // វាគ្មានន័យទេចំពោះ `baz` គឺជា `MyStruct` ដូច្នេះយើងមិនមានតក្កវិជ្ជានៅទីនេះទាល់តែសោះ។
/////
///         // ការនេះនឹងបង្ហាញ "thread 'main' panicked at 'not implemented'" ។
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // យើងមានតក្កមួយចំនួននៅទីនេះ, យើងអាចបន្ថែមសារទៅមិនបានអនុវត្ត!ដើម្បីបង្ហាញលុបចោលរបស់យើង។
///         // ការនេះនឹងបង្ហាញ: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// បង្ហាញថាលេខកូដមិនទាន់បានបញ្ចប់។
///
/// នេះអាចមានប្រយោជន៍ប្រសិនបើអ្នកត្រូវបានគេ prototyping និងត្រូវបានគ្រាន់តែសម្លឹងមើលទៅមាន typecheck កូដរបស់អ្នក។
///
/// ភាពខុសគ្នារវាង [`unimplemented!`] និង `todo!` នោះគឺថាខណៈពេលដែល `todo!` ន័យជាចេតនានៃការអនុវត្តមុខងារនៅពេលក្រោយនិងសារគឺ "not yet implemented", `unimplemented!` ធ្វើឱ្យគ្មានការអះអាងបែបនេះ។
/// សាររបស់វាគឺ "not implemented" ។
/// IDEs មួយចំនួននឹងសម្គាល់ `ការងារត្រូវធ្វើ!` s ។
///
/// # Panics
///
/// ឆន្ទៈនេះតែងតែ [`panic!`] ។
///
/// # Examples
///
/// នេះជាគំរូមួយចំនួននៅក្នុងការរីកចំរើនកូដមួយ។យើងមាន trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// យើងចង់អនុវត្ត `Foo` នៅលើមួយនៃប្រភេទរបស់យើងប៉ុន្តែយើងចង់ធ្វើការងារនៅលើគ្រាន់តែ `bar()` ដំបូង។ដើម្បីឱ្យកូដរបស់យើងចងក្រងយើងត្រូវអនុវត្ត `baz()` ដូច្នេះយើងអាចប្រើ `todo!`៖
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // ការអនុវត្តនៅទីនេះ
///     }
///
///     fn baz(&self) {
///         // កុំបារម្ភពីការអនុវត្ត baz() ឥឡូវនេះ
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // យើងមិនត្រូវបានសូម្បីតែការប្រើ baz(), ដូច្នេះនេះគឺជាការល្អ។
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// និយមន័យនៃម៉ាក្រូដែលមានស្រាប់។
///
/// ភាគច្រើននៃលក្ខណៈសម្បត្តិម៉ាក្រូ (ស្ថេរភាព, ភាពមើលឃើញ, ល) ត្រូវបានយកចេញពីកូដប្រភពនៅទីនេះដោយមានករណីលើកលែងនៃការពង្រីកការផ្លាស់ប្តូរធាតុចូលមុខងារចូលទៅក្នុងលទ្ធផលម៉ាក្រូមុខងារទាំងនោះត្រូវបានផ្តល់ឱ្យដោយកម្មវិធីចងក្រង។
///
///
pub(crate) mod builtin {

    /// មូលហេតុ compilation បរាជ័យដែលមានសារកំហុសដែលបានផ្ដល់ឱ្យនៅពេលដែលបានជួបប្រទះ។
    ///
    /// ម៉ាក្រូនេះគួរតែត្រូវបានប្រើនៅពេលដែលប្រើយុទ្ធសាស្រ្តរបស់ crate លក្ខខណ្ឌចងក្រងសារកំហុសក្នុងការផ្តល់នូវលក្ខខណ្ឌដែលមានការភាន់ច្រលំល្អប្រសើរសម្រាប់។
    ///
    /// វាជាសំណុំបែបបទដែលបានចងក្រងកម្រិតនៃ [`panic!`] ប៉ុន្តែការបញ្ចេញកំហុសកំឡុងពេលចងក្រង * * ជាជាងនៅពេលរត់ * *។
    ///
    /// # Examples
    ///
    /// ឧទាហរណ៍ពីរបែបនេះគឺមានម៉ាក្រូនិងបរិស្ថាន `#[cfg]` ។
    ///
    /// បញ្ចេញកំហុសអ្នកចងក្រងបានប្រសើរប្រសិនបើម៉ាក្រូត្រូវបានផ្ទេរតម្លៃមិនត្រឹមត្រូវ។
    /// បើគ្មាន branch ចុងក្រោយចងក្រងនៅតែបញ្ចេញកំហុសមួយប៉ុន្តែសារកំហុសនេះនឹងមិននិយាយពីតម្លៃដែលមានសុពលភាពពីរ។
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// កំហុសកម្មវិធីចងក្រងបញ្ចេញប្រសិនបើមួយនៃចំនួននៃលក្ខណៈពិសេសមួយគឺមិនអាចប្រើបាន។
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// សង់ប៉ារ៉ាម៉ែត្រសម្រាប់ការមានទ្រង់ទ្រាយជាខ្សែអក្សរម៉ាក្រូទៀត។
    ///
    /// នេះជាមុខងារម៉ាក្រូដោយការទទួលយកការធ្វើទ្រង់ទ្រាយព្យញ្ជនៈមួយខ្សែសម្រាប់អាគុយម៉ង់ដែលមាន `{}` បន្ថែមគ្នាបានអនុម័ត។
    /// `format_args!` រៀបចំប៉ារ៉ាម៉ែត្របន្ថែមដើម្បីធានាបាននូវទិន្នផលដែលអាចត្រូវបានបកស្រាយថាជាខ្សែអក្សរមួយនិងការចូលទៅក្នុងអាគុយម៉ង់ canonicalizes ប្រភេទតែមួយ។
    /// តម្លៃណាមួយដែលការអនុវត្ត [`Display`] trait អាចត្រូវបានបញ្ជូនទៅ `format_args!`, ដូចដែលអាចអនុវត្ត [`Debug`] ណាមួយត្រូវបានបញ្ជូនទៅ `{:?}` ក្នុងខ្សែការធ្វើទ្រង់ទ្រាយនោះ។
    ///
    ///
    /// ម៉ាក្រូនេះផលិតតម្លៃនៃប្រភេទ [`fmt::Arguments`] ។តម្លៃនេះអាចត្រូវបានបញ្ជូនទៅម៉ាក្រូដែលមាននៅក្នុងការសម្តែងការផ្លាស់ប្តូរសម្រាប់ [`std::fmt`] មានប្រយោជន៍។
    /// ការធ្វើទ្រង់ទ្រាយផ្សេងទៀតទាំងអស់ម៉ាក្រូ ([: ទ្រង់ទ្រាយ! `] [`write!`], [`println!`], ល) ត្រូវបាន proxied តាមរយៈការមួយនេះ។
    /// `format_args!`, មិនដូចម៉ាក្រូដែលបានមកពីវាចៀសវាងការបែងចែកហ៊ា។
    ///
    /// អ្នកអាចប្រើតម្លៃ [`fmt::Arguments`] ថា `format_args!` ត្រឡប់នៅក្នុងបរិបទ `Debug` និង `Display` ដូចដែលគេឃើញនៅខាងក្រោម។
    /// ឧទាហរណ៍ក៏បង្ហាញផងដែរថាទ្រង់ទ្រាយ `Debug` និង `Display` មានលក្ខណៈដូចគ្នា: ខ្សែអក្សរទ្រង់ទ្រាយបកប្រែនៅក្នុង `format_args!` ។
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// សម្រាប់ព័ត៌មានបន្ថែមសូមមើលឯកសារនៅក្នុង [`std::fmt`] ។
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ដូចគ្នា `format_args` ប៉ុន្តែលោកបានបន្ថែមបន្ទាត់ថ្មីនៅទីបញ្ចប់មួយ។
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// ត្រួតពិនិត្យអថេរបរិស្ថាននៅពេលចងក្រង។
    ///
    /// ម៉ាក្រូនេះនឹងពង្រីកទៅនឹងតម្លៃនៃអថេរបរិស្ថានដែលមានឈ្មោះនៅពេលចងក្រងនេះផ្តល់ទិន្នផលបញ្ចេញមតិនៃប្រភេទ `&'static str` មួយ។
    ///
    ///
    /// ប្រសិនបើអថេរបរិស្ថាននេះមិនត្រូវបានកំណត់, បន្ទាប់មកមានកំហុសចងក្រងមួយនឹងត្រូវបានបញ្ចេញ។
    /// ដើម្បីមិនបញ្ចេញកំហុសចងក្រងមួយប្រើម៉ាក្រូ [`option_env!`] ជំនួសវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// អ្នកអាចប្ដូរតាមបំណងសារកំហុសដោយឆ្លងកាត់ខ្សែអក្សរប៉ារ៉ាម៉ែត្រទីពីរដែលជា:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// ប្រសិនបើអថេរបរិស្ថាន `documentation` មិនត្រូវបានកំណត់អ្នកនឹងមានកំហុសដូចខាងក្រោមៈ
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ស្រេចចិត្តពិនិត្យមើលអថេរបរិស្ថានមួយនៅពេលចងក្រង។
    ///
    /// ប្រសិនបើអថេរបរិស្ថានដែលមានឈ្មោះគឺមានវត្តមាននៅពេលចងក្រងនេះនឹងពង្រីកចូលទៅក្នុងការបញ្ចេញមតិនៃប្រភេទ `Option<&'static str>` ដែលមានតម្លៃគឺ `Some` នៃតម្លៃនៃអថេរបរិស្ថាននេះ។
    /// ប្រសិនបើអថេរបរិស្ថានគឺមិនមានវត្តមាន, បន្ទាប់មកនេះនឹងពង្រីកទៅ `None` ។
    /// សូមមើល [`Option<T>`][Option] សម្រាប់ព័ត៌មានបន្ថែមអំពីប្រភេទនេះ។
    ///
    /// កំហុសពេលចងក្រងមិនត្រូវបានបញ្ចេញនៅពេលដែលប្រើម៉ាក្រូនេះបានឡើយដោយមិនគិតថាតើអថេរបរិស្ថាននេះគឺមានវត្តមានឬមិនបាន។
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ចូលទៅក្នុងគ្រឿងសម្គាល់អត្តសញ្ញាដាក់បន្តគ្នាមួយ។
    ///
    /// ម៉ាក្រូនេះយកលេខសម្គាល់ដែលបំបែកដោយសញ្ញាក្បៀសហើយសង្ខេបពួកវាទាំងអស់ទៅជាមួយដោយបង្ហាញកន្សោមដែលជាអត្តសញ្ញាណថ្មី។
    /// ចំណាំអនាម័យដែលធ្វើឱ្យវាដូចថាម៉ាក្រូនេះមិនអាចចាប់យកអថេរមូលដ្ឋាន។
    /// ដូចគ្នានេះផងដែរដូចជាច្បាប់ទូទៅមួយម៉ាក្រូត្រូវបានអនុញ្ញាតតែនៅក្នុងធាតុសេចក្តីថ្លែងការណ៍ឬទីតាំងបញ្ចេញមតិ។
    /// ថាមធ្យោបាយខណៈពេលដែលអ្នកអាចប្រើម៉ាក្រូនេះដើម្បីសំដៅទៅលើអថេរដែលមានស្រាប់មុខងារឬម៉ូឌុលល, អ្នកមិនអាចកំណត់ថ្មីមួយជាមួយវា។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // concat_idents fn! (ថ្មី, ភាពសប្បាយរីករាយឈ្មោះ) { }//មិនអាចប្រើបាននៅក្នុងវិធីនេះ!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// បញ្ចូលអក្សរសាស្ត្រទៅជាខ្សែអក្សរឋិតិវន្ត។
    ///
    /// ម៉ាក្រូនេះត្រូវចំណាយពេលចំនួននៃការលីត្របំបែកដោយសញ្ញាក្បៀសណាមួយ, ផ្តល់ទិន្នផលបញ្ចេញមតិនៃប្រភេទ `&'static str` ដែលតំណាងឱ្យទាំងអស់នៃលីត្រ concatenated ពីឆ្វេងទៅស្ដាំ។
    ///
    ///
    /// ចំនួនគត់និងចំណុចអណ្តែតទឹកត្រូវបាន literals ដើម្បី stringified ត្រូវ concatenated ។
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ពង្រីកលេខបន្ទាត់នៅលើដែលវាត្រូវបានគេយកមកប្រើ។
    ///
    /// ជាមួយ [`column!`] និង [`file!`] ម៉ាក្រូទាំងនេះផ្តល់ព័ត៌មានបំបាត់កំហុសសម្រាប់អ្នកអភិវឌ្ឍន៍អំពីទីតាំងនៅក្នុងប្រភព។
    ///
    /// កន្សោមពង្រីកមានប្រភេទ `u32` និងជាមូលដ្ឋាននៅទី 1, ដូច្នេះបន្ទាត់ដំបូងនៅក្នុងការវាយឯកសារដើម្បី 1, លើកទីពីរទៅ 2 ជាដើម
    /// នេះគឺស្របជាមួយសារកំហុសដោយអ្នកចងក្រងទូទៅឬអ្នកកែពេញនិយម។
    /// បន្ទាត់ត្រឡប់គឺ *មិនចាំបាច់* បន្ទាត់នៃការ scripts ហៅ `line!` ខ្លួនវាផ្ទាល់, ប៉ុន្តែជាការ scripts ហៅម៉ាក្រូដំបូងរហូតដល់ scripts ហៅរបស់ម៉ាក្រូ `line!` នេះ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// ពង្រីកទៅចំនួនជួរឈរនៅដែលវាត្រូវបានគេយកមកប្រើ។
    ///
    /// ជាមួយនឹងការ [`line!`] និង [`file!`] ម៉ាក្រូទាំងនេះផ្ដល់ពបំបាត់កំហុសសម្រាប់អ្នកអភិវឌ្ឍន៍អំពីទីតាំងដែលមាននៅក្នុងប្រភព។
    ///
    /// កន្សោមពង្រីកមានប្រភេទ `u32` និងជាមូលដ្ឋាននៅទី 1, ដូច្នេះជួរឈរដំបូងនៅក្នុងការវាយបន្ទាត់គ្នាទៅ 1, លើកទីពីរដើម្បី 2, ល
    /// នេះគឺស្របជាមួយសារកំហុសដោយអ្នកចងក្រងទូទៅឬអ្នកកែពេញនិយម។
    /// ជួរឈរត្រឡប់គឺ *មិនចាំបាច់* បន្ទាត់នៃការ scripts ហៅ `column!` ខ្លួនវាផ្ទាល់, ប៉ុន្តែជាការ scripts ហៅម៉ាក្រូដំបូងរហូតដល់ scripts ហៅរបស់ម៉ាក្រូ `column!` នេះ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// ពង្រីកទៅឈ្មោះឯកសារដែលវាត្រូវបានគេយកមកប្រើ។
    ///
    /// ជាមួយនឹងការ [`line!`] និង [`column!`] ម៉ាក្រូទាំងនេះផ្ដល់ពបំបាត់កំហុសសម្រាប់អ្នកអភិវឌ្ឍន៍អំពីទីតាំងដែលមាននៅក្នុងប្រភព។
    ///
    /// កន្សោមពង្រីកបានវាយ `&'static str` និងឯកសារដែលបានត្រឡប់មកវិញគឺមិន scripts ហៅនៃម៉ាក្រូ `file!` ខ្លួនវាផ្ទាល់, ប៉ុន្តែជាការ scripts ហៅម៉ាក្រូដំបូងរហូតដល់ scripts ហៅរបស់ម៉ាក្រូ `file!` នេះ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringifies អាគុយម៉ង់របស់វា។
    ///
    /// ម៉ាក្រូនេះនឹងទទួលបានការបញ្ចេញមតិនៃប្រភេទ `&'static str` ដែលជា stringification នៃការទាំងអស់ tokens នេះបានបញ្ជូនទៅម៉ាក្រូ។
    /// គ្មានការរឹតបន្តឹងត្រូវបានដាក់នៅលើវាក្យសម្ព័ន្ធនៃ scripts ហៅម៉ាក្រូខ្លួនវាផ្ទាល់។
    ///
    /// ចំណាំថាលទ្ធផលនៃការបញ្ចូល tokens បានពង្រីកដែលអាចផ្លាស់ប្តូរក្នុង future នេះ។អ្នកគួរតែប្រុងប្រយ័ត្នប្រសិនបើអ្នកពឹងផ្អែកលើលទ្ធផល។
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// រួមបញ្ចូលទាំងអ៊ិនកូដឯកសារជា UTF-8 ខ្សែអក្សរ។
    ///
    /// ឯកសារនេះមានទីតាំងស្ថិតនៅទាក់ទងទៅនឹងឯកសារបច្ចុប្បន្ន (ស្រដៀងទៅនឹងរបៀបម៉ូឌុលត្រូវបានរកឃើញ) ។
    /// ផ្លូវដែលបានផ្តល់ត្រូវបានបកប្រែនៅក្នុងវិធីវេទិកាជាក់លាក់មួយនៅពេលចងក្រង។
    /// ដូច្នេះ, ឧទាហរណ៍, scripts ហៅជាមួយនឹងការផ្លូវ Windows ដែលមានសញ្ញាមួយ `\` នឹងមិនត្រឹមត្រូវនៅលើ Unix ចងក្រង។
    ///
    ///
    /// ម៉ាក្រូនេះនឹងទទួលបានការបញ្ចេញមតិនៃប្រភេទ `&'static str` ដែលជាមាតិកានៃឯកសារ។
    ///
    /// # Examples
    ///
    /// សន្មតថាមានឯកសារពីរនៅក្នុងថតតែមួយដែលមានមាតិកាដូចខាងក្រោមៈ
    ///
    /// ឯកសារ 'spanish.in'៖
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ឯកសារ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// ការចងក្រង 'main.rs' ហើយដំណើរការគោលពីរលទ្ធផលនឹងបោះពុម្ព "adiós" ។
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// រួមបញ្ចូលទាំងឯកសារដែលជាសេចក្ដីយោងទៅអារេបៃទេ។
    ///
    /// ឯកសារនេះមានទីតាំងស្ថិតនៅទាក់ទងទៅនឹងឯកសារបច្ចុប្បន្ន (ស្រដៀងទៅនឹងរបៀបម៉ូឌុលត្រូវបានរកឃើញ) ។
    /// ផ្លូវដែលបានផ្តល់ត្រូវបានបកប្រែនៅក្នុងវិធីវេទិកាជាក់លាក់មួយនៅពេលចងក្រង។
    /// ដូច្នេះ, ឧទាហរណ៍, scripts ហៅជាមួយនឹងការផ្លូវ Windows ដែលមានសញ្ញាមួយ `\` នឹងមិនត្រឹមត្រូវនៅលើ Unix ចងក្រង។
    ///
    ///
    /// ម៉ាក្រូនេះនឹងទទួលបានការបញ្ចេញមតិនៃប្រភេទ `&'static [u8; N]` ដែលជាមាតិកានៃឯកសារ។
    ///
    /// # Examples
    ///
    /// សន្មតថាមានឯកសារពីរនៅក្នុងថតតែមួយដែលមានមាតិកាដូចខាងក្រោមៈ
    ///
    /// ឯកសារ 'spanish.in'៖
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ឯកសារ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// ការចងក្រង 'main.rs' ហើយដំណើរការគោលពីរលទ្ធផលនឹងបោះពុម្ព "adiós" ។
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ពង្រីកទៅខ្សែអក្សរដែលតំណាងឱ្យផ្លូវម៉ូឌុលបច្ចុប្បន្ន។
    ///
    /// ផ្លូវម៉ូឌុលបច្ចុប្បន្នអាចត្រូវបានគិតថាជាឋានានុក្រមនៃម៉ូឌុលនាំមុខគេត្រឡប់មកវិញបានរហូតដល់ទៅ crate root នេះ។
    /// សមាសភាគដំបូងនៃផ្លូវត្រឡប់មកវិញគឺជាឈ្មោះនៃ crate នេះបច្ចុប្បន្នកំពុងត្រូវបានចងក្រងឡើង។
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// វាយតម្លៃបន្សំប៊ូលីនការកំណត់រចនាសម្ព័ន្ធនៅទង់ជាតិនៃការចងក្រងម៉ោង។
    ///
    /// លើសពីនេះទៅគុណលក្ខណៈ `#[cfg]`, ម៉ាក្រូនេះត្រូវបានផ្ដល់ដើម្បីអនុញ្ញាតឱ្យការវាយតម្លៃកន្សោមប៊ូលីននៃទង់ជាតិកំណត់រចនាសម្ព័ន្ធ។
    /// ជាញឹកញាប់នេះនាំទៅកូដដែលបានចម្លងតិច។
    ///
    /// វាក្យសម្ព័ន្ធដែលបានផ្ដល់ឱ្យម៉ាក្រូនេះគឺវាក្យសម្ព័ន្ធដូចគ្នាជាគុណលក្ខណៈ [`cfg`] ។
    ///
    /// `cfg!`, មិនដូច `#[cfg]` ទេមិនដកចេញលេខកូដណាមួយទេហើយគ្រាន់តែវាយតម្លៃថាពិតឬមិនពិត។
    /// ឧទាហរណ៍ប្លុកទាំងអស់នៅក្នុងតម្រូវការបញ្ចេញមតិ if/else ដើម្បីឱ្យមានសុពលភាពពេល `cfg!` ត្រូវបានប្រើសម្រាប់ជំងឺនេះដោយមិនគិតពីអ្វីដែល `cfg!` ត្រូវបានវាយតម្លៃ។
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// លាក់ឯកសារជាកន្សោមឬធាតុយោងតាមបរិបទ។
    ///
    /// ឯកសារនេះមានទីតាំងស្ថិតនៅទាក់ទងទៅនឹងឯកសារបច្ចុប្បន្ន (ស្រដៀងទៅនឹងរបៀបម៉ូឌុលត្រូវបានរកឃើញ) ។ផ្លូវដែលបានផ្តល់ត្រូវបានបកស្រាយតាមរបៀបជាក់លាក់នៃវេទិកានៅពេលចងក្រង។
    /// ដូច្នេះ, ឧទាហរណ៍, scripts ហៅជាមួយនឹងការផ្លូវ Windows ដែលមានសញ្ញាមួយ `\` នឹងមិនត្រឹមត្រូវនៅលើ Unix ចងក្រង។
    ///
    /// ការប្រើម៉ាក្រូនេះជាញឹកញាប់គឺជាគំនិតអាក្រក់, ព្រោះប្រសិនបើឯកសារត្រូវបានញែកជាការបញ្ចេញមតិមួយ, វានឹងត្រូវបានដាក់ក្នុងកូដនៅជុំវិញនោះគ្មានអនាម័យ។
    /// នេះអាចមានលទ្ធផលក្នុងអថេរឬមុខងារខុសគ្នាពីអ្វីដែលត្រូវបានគេរំពឹងថានឹងបានប្រសិនបើឯកសារមិនមានអថេរឬមុខងារដែលមានឈ្មោះដូចគ្នាក្នុងឯកសារបច្ចុប្បន្ន។
    ///
    ///
    /// # Examples
    ///
    /// សន្មតថាមានឯកសារពីរនៅក្នុងថតតែមួយដែលមានមាតិកាដូចខាងក្រោមៈ
    ///
    /// ឯកសារ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ឯកសារ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// ចងក្រង 'main.rs' និងរត់គោលពីរលទ្ធផលនឹងបោះពុម្ព "🙈🙊🙉🙈🙊🙉" ។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// បញ្ជាក់ថាកន្សោមប៊ូលីនគឺ `true` ពេលរត់។
    ///
    /// នេះនឹងហៅម៉ាក្រូ [`panic!`] X ប្រសិនបើកន្សោមដែលបានផ្តល់មិនអាចត្រូវបានវាយតម្លៃទៅ `true` នៅពេលដំណើរការ។
    ///
    /// # Uses
    ///
    /// ការអះអាងតែងតែត្រូវបានធីកទាំងនៅក្នុងការបំបាត់កំហុសនិងការដោះលែងកសាងនិងមិនអាចត្រូវបានបិទ។
    /// សូមមើល [`debug_assert!`] សម្រាប់ការការពារអះអាងដែលមិនត្រូវបានអនុញ្ញាតនៅក្នុងការចេញផ្សាយកសាងដោយលំនាំដើម។
    ///
    /// លេខកូដដែលមិនមានសុវត្ថិភាពអាចពឹងផ្អែកលើ `assert!` ដើម្បីអនុវត្តការលុកលុយពេលដែលត្រូវបានរំលោភបំពានដែលអាចនាំឱ្យមានសុវត្ថិភាព។
    ///
    /// ការប្រើផ្សេងទៀតនៃករណីរួមមានការធ្វើតេស្តនិង `assert!` អនុវត្តផុសពេលរត់ក្នុងកូដសុវត្ថិភាព (ដែលមានការរំលោភបំពានមិនអាចមានលទ្ធផលក្នុងការ unsafety) ។
    ///
    ///
    /// # សារផ្ទាល់ខ្លួន
    ///
    /// ម៉ាក្រូនេះមានទម្រង់ជាលើកទីពីរជាមួយ, ដែលជាកន្លែងដែលជាសារ panic ផ្ទាល់ខ្លួនអាចត្រូវបានផ្តល់ឱ្យដោយមានឬគ្មានអាគុយម៉ង់សម្រាប់ធ្វើទ្រង់ទ្រាយ។
    /// សូមមើលសម្រាប់វាក្យសម្ព័ន្ធសម្រាប់ [`std::fmt`] បែបបទនេះ។
    /// កន្សោមដែលត្រូវបានប្រើជាអាគុយម៉ង់ទ្រង់ទ្រាយនឹងត្រូវបានវាយតម្លៃបានតែអះអាងបរាជ័យ។
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // សារ panic សម្រាប់ការអះអាងទាំងនេះគឺជាគុណតម្លៃនៃកន្សោមដែលបានផ្តល់។
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // មុខងារសាមញ្ញណាស់
    ///
    /// assert!(some_computation());
    ///
    /// // អះអាងជាមួយសារផ្ទាល់ខ្លួន
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ការជួបប្រជុំក្នុងតួ។
    ///
    /// សូមអាន [unstable book] សម្រាប់ការប្រើប្រាស់។
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM បែបក្នុងតួអង្គប្រជុំ។
    ///
    /// សូមអាន [unstable book] សម្រាប់ការប្រើប្រាស់។
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// ម៉ូឌុលកម្រិតក្នុងតួអង្គប្រជុំ។
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// ការបោះពុម្ពបានបញ្ជូន tokens ទៅក្នុងលទ្ធផលស្តង់ដារ។
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// អនុញ្ញាតឬមិនអនុញ្ញាតឱ្យប្រើសម្រាប់មុខងារ tracing បំបាត់កំហុសម៉ាក្រូផ្សេងទៀត។
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ម៉ាក្រូដែលត្រូវបានប្រើដើម្បីអនុវត្តគុណលក្ខណៈម៉ាក្រូដេរីវេ។
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ម៉ាក្រូគុណលក្ខណៈអនុវត្តទៅអនុគមន៍ដើម្បីប្រែក្លាយវាទៅជាការធ្វើតេស្តឯកតា។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// សន្មតថាម៉ាក្រូអនុវត្តទៅមុខងារមួយដើម្បីប្រែក្លាយវាទៅជាការធ្វើតេស្តគោល។
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// ការអនុវត្តមានលម្អិតនៃម៉ាក្រូ `#[test]` និង `#[bench]` ។
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// ម៉ាក្រូគុណលក្ខណៈអនុវត្តទៅឋិតិវន្តមួយដើម្បីចុះឈ្មោះជាមួយការបែងចែកវាជាសកល។
    ///
    /// សូមមើលផងដែរ [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ។
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// រក្សាធាតុដែលវាត្រូវបានអនុវត្តទៅបានប្រសិនបើផ្លូវអនុម័តគឺអាចចូលដំណើរការបាន, និងយកវាបើមិនដូច្នេះទេ។
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// ពង្រីក `#[cfg]` និង `#[cfg_attr]` ទាំងអស់គុណលក្ខណៈក្នុងបំណែកកូដវាត្រូវបានអនុវត្តទៅ។
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// ការអនុវត្តន៍នៃការមិនស្ថិតស្ថេរលម្អិតចងក្រង `rustc`, មិនប្រើ។
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// ការអនុវត្តន៍នៃការមិនស្ថិតស្ថេរលម្អិតចងក្រង `rustc`, មិនប្រើ។
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}