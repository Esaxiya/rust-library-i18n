//! កំហុសក្នុងការដោះស្រាយជាមួយប្រភេទ `Result` ។
//!
//! [`Result<T, E>`][`Result`] គឺជាប្រភេទដែលត្រូវបានប្រើសម្រាប់ការត្រឡប់និងការឃោសនាកំហុស។
//! វាគឺជាអង់ហ្ស៊ីមជាមួយវ៉ារ្យ៉ង់ [`Ok(T)`] ដែលតំណាងឱ្យភាពជោគជ័យនិងមានតំលៃហើយ [`Err(E)`] តំណាងអោយកំហុសនិងមានតំលៃកំហុស។
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! មុខងារត្រឡប់ [`Result`] នៅពេលមានកំហុសរំពឹងទុកនិងអាចរកឃើញវិញ។នៅក្នុង `std` crate [`Result`] ត្រូវបានគេប្រើច្រើនបំផុតសម្រាប់ [I/O](../../std/io/index.html) ។
//!
//! មុខងារធម្មតាត្រឡប់លេខ [`Result`] អាចត្រូវបានកំណត់និងប្រើដូចនោះ៖
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! ការផ្គូផ្គងគំរូលើ [`លទ្ធផល` គឺច្បាស់និងត្រង់សម្រាប់ករណីងាយៗប៉ុន្តែ [`Result`] ភ្ជាប់មកជាមួយវិធីសាស្ត្រងាយស្រួលមួយចំនួនដែលធ្វើឱ្យការធ្វើការជាមួយវាកាន់តែមានភាពជោគជ័យ។
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // វិធីសាស្រ្ត `is_ok` និង `is_err` ធ្វើអ្វីដែលពួកគេនិយាយ។
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` ស៊ី `Result` និងផលិតមួយផ្សេងទៀត។
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // ប្រើ `and_then` ដើម្បីបន្តការគណនា។
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // ប្រើ `or_else` ដើម្បីដោះស្រាយកំហុស។
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // ប្រើប្រាស់លទ្ធផលហើយប្រគល់មាតិកាមកវិញជាមួយ `unwrap` ។
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # លទ្ធផលត្រូវតែប្រើ
//!
//! បញ្ហាទូទៅជាមួយការប្រើប្រាស់តម្លៃត្រឡប់ដើម្បីចង្អុលបង្ហាញកំហុសគឺថាវាងាយស្រួលក្នុងការមិនអើពើនឹងតម្លៃត្រឡប់មកវិញដូច្នេះការខកខានមិនបានដោះស្រាយកំហុស។
//! [`Result`] ត្រូវបានពន្យល់ដោយមានគុណលក្ខណៈ `#[must_use]` ដែលនឹងបង្កឱ្យមានការចងក្រងការចេញព្រមាននៅពេលតម្លៃលទ្ធផលមួយដែលត្រូវបានមិនអើពើ។
//! នេះធ្វើឱ្យ [`Result`] មានប្រយោជន៍ជាពិសេសជាមួយមុខងារដែលអាចជួបប្រទះនឹងកំហុសប៉ុន្តែបើមិនដូច្នោះទេមិនត្រលប់មកវិញនូវតម្លៃដែលមានប្រយោជន៍ទេ។
//!
//! ពិចារណាវិធីសាស្ត្រ [`write_all`] ដែលបានកំណត់សម្រាប់ប្រភេទ I/O ដោយ [`Write`] trait:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: និយមន័យជាក់ស្តែងនៃ [`Write`] ប្រើ [`io::Result`] ដែលគ្រាន់តែជាសទិសន័យសម្រាប់ [`លទ្ធផល`] `<T,`[`io: :Error`]`>`។*
//!
//! វិធីសាស្រ្តនេះមិនផ្តល់តំលៃទេប៉ុន្តែការសរសេរអាចនឹងបរាជ័យ។វាចាំបាច់ណាស់ក្នុងការដោះស្រាយករណីកំហុសហើយ *កុំ* សរសេរអ្វីមួយដូចនេះ៖
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // ប្រសិនបើមានកំហុស `write_all` បន្ទាប់មកយើងនឹងមិនដឹងទេព្រោះតម្លៃត្រឡប់មកវិញមិនត្រូវបានអើពើ។
//! //
//! file.write_all(b"important message");
//! ```
//!
//! ប្រសិនបើអ្នក *សរសេរ* នៅក្នុង Rust អ្នកចងក្រងនឹងផ្តល់ការព្រមាន (តាមលំនាំដើមគ្រប់គ្រងដោយ `unused_must_use` lint) ។
//!
//! អ្នកអាចជំនួសប្រសិនបើអ្នកមិនចង់ដោះស្រាយកំហុសនោះគ្រាន់តែអះអាងជោគជ័យជាមួយ [`expect`] ។
//! ឆន្ទៈនេះ panic ប្រសិនបើការសរសេរបរាជ័យ, ការផ្តល់ជាសារបង្ហាញថាហេតុអ្វីបានជាមានប្រយោជន៍បន្តិច:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! អ្នកក៏អាចអះអាងជោគជ័យដែរ៖
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! ឬផ្សព្វផ្សាយកំហុសឡើងជង់ការហៅជាមួយ [`?`]៖
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # ប្រតិបត្តិករសញ្ញាសួរ, `?`
//!
//! នៅពេលសរសេរកូដដែលហៅមុខងារជាច្រើនដែលត្រឡប់ប្រភេទ [`Result`] ការដោះស្រាយកំហុសអាចធុញទ្រាន់។
//! ប្រតិបត្តិករសម្គាល់សំណួរគឺ [`?`] លាក់បាំងឡចំហាយមួយចំនួននៃកំហុសក្នុងការឃោសនាដែលបង្កើតជាការហៅចេញ។
//!
//! វាជំនួសនេះ:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // ការត្រឡប់មករកកំហុសដំបូង
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! ជាមួយនេះ៖
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // ការត្រឡប់មករកកំហុសដំបូង
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *វាកាន់តែប្រសើរ!*
//!
//! ការបញ្ចប់ការបញ្ចេញមតិជាមួយ [`?`] នឹងនាំឱ្យតម្លៃ ([`Ok`]) ទទួលបានជោគជ័យលើកលែងតែលទ្ធផលគឺ [`Err`] ក្នុងករណីនេះ [`Err`] ត្រូវបានត្រឡប់មកវិញឆាប់ៗពីមុខងារដែលព័ទ្ធជុំវិញ។
//!
//!
//! [`?`] អាចត្រូវបានប្រើតែនៅក្នុងមុខងារដែលត្រឡប់ [`Result`] ពីព្រោះការត្រឡប់មកវិញនៃ [`Err`] ដែលវាផ្តល់អោយ។
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` គឺជាប្រភេទមួយដែលតំណាងឱ្យភាពជោគជ័យ ([`Ok`]) ឬបរាជ័យ ([`Err`]) ។
///
/// សូមមើល [module documentation](self) សម្រាប់ព័ត៌មានលម្អិត។
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// មានផ្ទុកនូវតម្លៃជោគជ័យ
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// មានតម្លៃកំហុស
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// ប្រភេទការអនុវត្ត
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // សួរតម្លៃដែលមាន
    /////////////////////////////////////////////////////////////////////////

    /// ត្រឡប់ `true` ប្រសិនបើលទ្ធផលគឺ [`Ok`] ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// ត្រឡប់ `true` ប្រសិនបើលទ្ធផលគឺ [`Err`] ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// ត្រឡប់ `true` ប្រសិនបើលទ្ធផលជាតម្លៃ [`Ok`] ដែលមានតម្លៃដែលបានផ្តល់។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើលទ្ធផលជាតម្លៃ [`Err`] ដែលមានតម្លៃដែលបានផ្តល់។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // អាដាប់ទ័រសម្រាប់វ៉ារ្យ៉ង់នីមួយៗ
    /////////////////////////////////////////////////////////////////////////

    /// បំលែងពី `Result<T, E>` ទៅ [`Option<T>`] ។
    ///
    /// ផ្លាស់ប្រែចិត្តជឿ `self` ចូលទៅក្នុង [`Option<T>`] មួយប្រើប្រាស់ `self` និងការបោះចោលកំហុសប្រសិនបើមាន។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// បំលែងពី `Result<T, E>` ទៅ [`Option<E>`] ។
    ///
    /// ផ្លាស់ប្រែចិត្តជឿ `self` ចូលទៅក្នុង [`Option<E>`] មួយប្រើប្រាស់ `self` និងការបោះចោលតម្លៃទទួលបានជោគជ័យប្រសិនបើមាន។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // អាដាប់ទ័រសម្រាប់ធ្វើការជាមួយឯកសារយោង
    /////////////////////////////////////////////////////////////////////////

    /// បំលែងពី `&Result<T, E>` ទៅ `Result<&T, &E>` ។
    ///
    /// ផលិត `Result` ថ្មីដែលមានឯកសារយោងទៅនឹងច្បាប់ដើមទុកឯកសារដើមនៅកន្លែងដដែល។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// បំលែងពី `&mut Result<T, E>` ទៅ `Result<&mut T, &mut E>` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ការផ្លាស់ប្តូរតម្លៃដែលមាន
    /////////////////////////////////////////////////////////////////////////

    /// គូសផែនទី `Result<T, E>` ទៅ `Result<U, E>` ដោយអនុវត្តមុខងារទៅនឹងតម្លៃ [`Ok`] ដែលបន្សល់ទុកនូវតម្លៃ [`Err`] ។
    ///
    ///
    /// មុខងារនេះអាចត្រូវបានប្រើដើម្បីតែងលទ្ធផលនៃមុខងារពីរ។
    ///
    /// # Examples
    ///
    /// បោះពុម្ពលេខនៅលើខ្សែនីមួយៗនៃខ្សែគុណនឹងពីរ។
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// អនុវត្តមុខងារទៅតម្លៃដែលមាន (បើ [`Ok`]) ឬត្រឡប់លំនាំដើមដែលបានផ្តល់ (ប្រសិនបើ [`Err`]) ។
    ///
    /// អាគុយម៉ង់ដែលបានបញ្ជូនទៅ `map_or` ត្រូវបានវាយតម្លៃយ៉ាងអន្ទះអន្ទែង;ប្រសិនបើអ្នកកំពុងឆ្លងកាត់លទ្ធផលនៃការហៅមុខងារវាត្រូវបានគេណែនាំឱ្យប្រើ [`map_or_else`] ដែលត្រូវបានវាយតម្លៃយ៉ាងខ្ជិល។
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// គូសផែនទី `Result<T, E>` ទៅ `U` ដោយអនុវត្តមុខងារទៅនឹងតម្លៃ [`Ok`] ដែលមានឬមុខងារថយក្រោយចំពោះតម្លៃ [`Err`] ដែលមាន។
    ///
    ///
    /// មុខងារនេះអាចត្រូវបានប្រើដើម្បីស្រាយលទ្ធផលទទួលបានជោគជ័យខណៈពេលដោះស្រាយកំហុស។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// គូសផែនទី `Result<T, E>` ទៅ `Result<T, F>` ដោយអនុវត្តមុខងារទៅនឹងតម្លៃ [`Err`] ដែលបន្សល់ទុកនូវតម្លៃ [`Ok`] ។
    ///
    ///
    /// មុខងារនេះអាចត្រូវបានប្រើដើម្បីឆ្លងកាត់លទ្ធផលជោគជ័យខណៈពេលដោះស្រាយកំហុស។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // អ្នកសាងសង់ឧបករណ៍បំលែង
    /////////////////////////////////////////////////////////////////////////

    /// ត្រឡប់អ្នកត្រួតលើតម្លៃដែលអាចមាន។
    ///
    /// ទ្រនាប់ផ្តល់ទិន្នផលមួយប្រសិនបើលទ្ធផលគឺ [`Result::Ok`] បើមិនដូច្នេះទេមិនមានទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// ត្រឡប់ទ្រនិចនាឡិកាដែលអាចផ្លាស់ប្តូរបានលើតម្លៃដែលមាន។
    ///
    /// ទ្រនាប់ផ្តល់ទិន្នផលមួយប្រសិនបើលទ្ធផលគឺ [`Result::Ok`] បើមិនដូច្នេះទេមិនមានទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // ប្រតិបត្ដិប៊ូលីនលើគុណតម្លៃរំភើបនិងខ្ជិល
    /////////////////////////////////////////////////////////////////////////

    /// ត្រឡប់ `res` ប្រសិនបើលទ្ធផលគឺ [`Ok`] បើមិនដូច្នេះទេនឹងត្រឡប់តម្លៃ [`Err`] នៃ `self` ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// ហៅទូរស័ព្ទ `op` ប្រសិនបើលទ្ធផលគឺ [`Ok`] បើមិនដូច្នេះទេនឹងត្រឡប់តម្លៃ [`Err`] នៃ `self` ។
    ///
    ///
    /// មុខងារនេះអាចត្រូវបានប្រើសម្រាប់លំហូរការត្រួតពិនិត្យដោយផ្អែកលើតម្លៃ `Result` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// ត្រឡប់ `res` ប្រសិនបើលទ្ធផលគឺ [`Err`] បើមិនដូច្នេះទេនឹងត្រឡប់តម្លៃ [`Ok`] នៃ `self` ។
    ///
    /// អាគុយម៉ង់ដែលបានបញ្ជូនទៅ `or` ត្រូវបានវាយតម្លៃយ៉ាងអន្ទះអន្ទែង;ប្រសិនបើអ្នកកំពុងឆ្លងកាត់លទ្ធផលនៃការហៅមុខងារវាត្រូវបានគេណែនាំឱ្យប្រើ [`or_else`] ដែលត្រូវបានវាយតម្លៃយ៉ាងខ្ជិល។
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// អំពាវនាវឱ្យមាន `op` ប្រសិនបើលទ្ធផលគឺ [`Err`] បើមិនដូច្នេះទេត្រឡប់តម្លៃ [`Ok`] នៃ `self` ។
    ///
    ///
    /// មុខងារនេះអាចត្រូវបានប្រើសម្រាប់លំហូរត្រួតពិនិត្យដោយផ្អែកលើតម្លៃលទ្ធផល។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// ត្រឡប់តម្លៃ [`Ok`] ដែលមានឬលំនាំដើមដែលបានផ្តល់។
    ///
    /// អាគុយម៉ង់ដែលបានបញ្ជូនទៅ `unwrap_or` ត្រូវបានវាយតម្លៃយ៉ាងអន្ទះអន្ទែង;ប្រសិនបើអ្នកកំពុងឆ្លងកាត់លទ្ធផលនៃការហៅមុខងារវាត្រូវបានគេណែនាំឱ្យប្រើ [`unwrap_or_else`] ដែលត្រូវបានវាយតម្លៃយ៉ាងខ្ជិល។
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// ត្រឡប់តម្លៃ [`Ok`] ដែលមានឬគណនាវាពីការបិទ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// ត្រឡប់តម្លៃ [`Ok`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ដោយមិនចាំបាច់ពិនិត្យមើលថាតម្លៃមិនមែនជា [`Err`] ទេ។
    ///
    ///
    /// # Safety
    ///
    /// ការហៅវិធីសាស្ត្រនេះនៅលើអ៊ិចស៊ី [`Err`] គឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]*។
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // ឥរិយាបទមិនបានកំណត់!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// ត្រឡប់តម្លៃ [`Err`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ដោយមិនចាំបាច់ពិនិត្យមើលថាតម្លៃមិនមែនជា [`Ok`] ទេ។
    ///
    ///
    /// # Safety
    ///
    /// ការហៅវិធីសាស្ត្រនេះនៅលើអ៊ិចស៊ី [`Ok`] គឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]*។
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // ឥរិយាបទមិនបានកំណត់!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// ដៅផែនទី `Result<&T, E>` ទៅ `Result<T, E>` ដោយការចម្លងមាតិកានៃផ្នែក `Ok` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// ដៅផែនទី `Result<&mut T, E>` ទៅ `Result<T, E>` ដោយការចម្លងមាតិកានៃផ្នែក `Ok` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// គូសផែនទី `Result<&T, E>` ទៅ `Result<T, E>` ដោយក្លូនមាតិកានៃផ្នែក `Ok` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// គូសផែនទី `Result<&mut T, E>` ទៅ `Result<T, E>` ដោយក្លូនមាតិកានៃផ្នែក `Ok` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// ត្រឡប់តម្លៃ [`Ok`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃគឺជា [`Err`] ដែលមានសារ panic រួមទាំងសារដែលបានឆ្លងកាត់និងមាតិការបស់ [`Err`] ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// ត្រឡប់តម្លៃ [`Ok`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ។
    ///
    /// ដោយសារតែមុខងារនេះអាច panic ការប្រើប្រាស់ជាទូទៅត្រូវបានលើកទឹកចិត្ត។
    /// ផ្ទុយទៅវិញចិត្តប្រើផ្គូផ្គងលំនាំនិងដោះស្រាយករណី [`Err`] ជាក់លាក់ឬហៅ [`unwrap_or`], [`unwrap_or_else`] ឬ [`unwrap_or_default`] ។
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃ [`Err`] មួយជាមួយសារ panic បានផ្ដល់ដោយតម្លៃនេះ [`Err`] 's បានទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// ត្រឡប់តម្លៃ [`Err`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃគឺជា [`Ok`] ដែលមានសារ panic រួមទាំងសារដែលបានឆ្លងកាត់និងមាតិការបស់ [`Ok`] ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// ត្រឡប់តម្លៃ [`Err`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃគឺជា [`Ok`] ដែលមានសារ panic ផ្ទាល់ខ្លួនដែលផ្តល់ដោយតម្លៃរបស់ `` អូឃ្វីន។
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// ត្រឡប់តម្លៃ [`Ok`] ដែលមានឬលំនាំដើម
    ///
    /// អតិថិជនអាគុយម៉ង់ `self` បើ [`Ok`], ត្រឡប់តម្លៃដែលមានបាន, បើមិនដូច្នេះទេប្រសិនបើ [`Err`], ត្រឡប់តម្លៃលំនាំដើមសម្រាប់ប្រភេទនោះ។
    ///
    ///
    /// # Examples
    ///
    /// បម្លែងខ្សែអក្សរទៅជាចំនួនគត់ដោយបង្វែរខ្សែអក្សរដែលបានបង្កើតមិនត្រឹមត្រូវទៅជាលេខ ០ (តម្លៃលំនាំដើមសម្រាប់ចំនួនគត់) ។
    /// [`parse`] បម្លែងខ្សែអក្សរមួយទៅប្រភេទផ្សេងទៀតដែលអនុវត្ត [`FromStr`], ត្រឡប់ [`Err`] លើកំហុស។
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// ត្រឡប់តម្លៃដែលមានក្នុង [`Ok`] ប៉ុន្តែមិនដែល panics ។
    ///
    /// មិនដូច [`unwrap`] ទេវិធីសាស្ត្រនេះត្រូវបានគេដឹងថាមិនដែល panic លើប្រភេទលទ្ធផលដែលវាត្រូវបានអនុវត្ត។
    /// ដូច្នេះវាអាចត្រូវបានប្រើជំនួសឱ្យការថែរក្សាការពារដែលជា `unwrap` មួយដែលនឹងបរាជ័យដើម្បីចងក្រងប្រសិនបើប្រភេទកំហុសនៃការផ្លាស់ប្តូរត្រូវបាន `Result` ក្រោយមកមានកំហុសថាពិតជាអាចកើតមានឡើងបាន។
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// បំលែងពី `Result<T, E>` (ឬ `&Result<T, E>`) ទៅ `Result<&<T as Deref>::Target, &E>` ។
    ///
    /// Coerces វ៉ារ្យ៉ង់ [`Ok`] នៃ [`Result`] ដើមតាមរយៈ [`Deref`](crate::ops::Deref) ហើយត្រឡប់ [`Result`] ថ្មី។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// បំលែងពី `Result<T, E>` (ឬ `&mut Result<T, E>`) ទៅ `Result<&mut <T as DerefMut>::Target, &mut E>` ។
    ///
    /// Coerces វ៉ារ្យ៉ង់ [`Ok`] នៃ [`Result`] ដើមតាមរយៈ [`DerefMut`](crate::ops::DerefMut) ហើយត្រឡប់ [`Result`] ថ្មី។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// ប្តូរ `Result` នៃ `Option` ទៅជា `Option` នៃ `Result` ។
    ///
    /// `Ok(None)` នឹងត្រូវបានគូសទៅជា `None` ។
    /// `Ok(Some(_))` ហើយ `Err(_)` នឹងត្រូវបានគូសជា `Some(Ok(_))` និង `Some(Err(_))` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// បំលែងពី `Result<Result<T, E>, E>` ទៅ `Result<T, E>`
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// បំផ្លាញយកកម្រិតនៃការដាក់ខាងក្នុងមួយពេលមួយតែប៉ុណ្ណោះនៅលើ:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// ត្រឡប់តម្លៃ [`Ok`] ប្រសិនបើ `self` ជា `Ok` ហើយតម្លៃ [`Err`] ប្រសិនបើ `self` គឺ `Err` ។
    ///
    /// និយាយម៉្យាងទៀតមុខងារនេះត្រឡប់តម្លៃ (`T`) នៃ `Result<T, T>` ដោយមិនគិតថាលទ្ធផលនោះគឺ `Ok` ឬ `Err` ។
    ///
    /// វាអាចមានប្រយោជន៍នៅក្នុងការភ្ជាប់ជាមួយ APIs ដូចជា [`Atomic*::compare_exchange`] ឬ [`slice::binary_search`] ប៉ុន្តែបានតែក្នុងករណីដែលអ្នកមិនខ្វល់ប្រសិនបើលទ្ធផលនេះគឺ `Ok` ឬមិនបាន។
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// នេះគឺជាមុខងារដាច់ដោយឡែកដើម្បីកាត់បន្ថយទំហំកូដនៃវិធីសាស្រ្ត
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// ការអនុវត្ត Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ត្រឡប់ការប្រើប្រាស់លើតម្លៃដែលអាចមាន។
    ///
    /// ទ្រនាប់ផ្តល់ទិន្នផលមួយប្រសិនបើលទ្ធផលគឺ [`Result::Ok`] បើមិនដូច្នេះទេមិនមានទេ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// អ្នកវិភាគលទ្ធផល
/////////////////////////////////////////////////////////////////////////////

/// អ្នកត្រួតលើការយោងទៅវ៉ារ្យ៉ង់ [`Ok`] នៃ [`Result`] ។
///
/// ទ្រនាប់ផ្តល់ទិន្នផលមួយប្រសិនបើលទ្ធផលគឺ [`Ok`] បើមិនដូច្នេះទេមិនមានទេ។
///
/// បង្កើតដោយ [`Result::iter`] ។
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// ការរំកិលលើសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅនឹង [`Ok`] វ៉ារ្យ៉ង់នៃ [`Result`] ។
///
/// បង្កើតដោយ [`Result::iter_mut`] ។
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// អ្នកត្រួតត្រាលើតម្លៃនៅក្នុងវ៉ារ្យ៉ង់ [`Ok`] នៃ [`Result`] ។
///
/// ទ្រនាប់ផ្តល់ទិន្នផលមួយប្រសិនបើលទ្ធផលគឺ [`Ok`] បើមិនដូច្នេះទេមិនមានទេ។
///
/// រចនាសម្ព័ន្ធនេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ត្រ [`into_iter`] នៅលើ [`Result`] (ផ្តល់ដោយ [`IntoIterator`] trait) ។
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// យកធាតុនីមួយៗនៅក្នុង `Iterator`: ប្រសិនបើវាជា `Err` គ្មានធាតុបន្ថែមត្រូវបានគេយកទេហើយ `Err` ត្រូវបានត្រឡប់មកវិញ។
    /// មិនគួរមាន `Err` កើតឡើងកុងតឺន័រដែលមានតម្លៃរបស់ `Result` នីមួយៗត្រូវបានប្រគល់មកវិញ។
    ///
    /// នេះជាឧទាហរណ៍មួយដែលបង្កើនរាល់ចំនួនគត់ក្នុង vector, ពិនិត្យមើលការលើសចំណុះ៖
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// នេះជាឧទាហរណ៍មួយផ្សេងទៀតដែលព្យាយាមដកមួយចេញពីបញ្ជីចំនួនគត់ផ្សេងទៀតពេលនេះពិនិត្យរកមើលលំហូរដែលកំពុងដំណើរការ៖
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// នេះគឺជាបំរែបំរួលនៅលើឧទាហរណ៍មុនដែលបង្ហាញថាមិនមានធាតុបន្ថែមទៀតត្រូវបានយកពី `iter` បន្ទាប់ពី `Err` ដំបូងទេ។
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// ចាប់តាំងពីធាតុទីបីបណ្តាលឱ្យមានដំណើរការមិនមានធាតុបន្ថែមទៀតដូច្នេះតម្លៃចុងក្រោយនៃ `shared` គឺ 6 (= `3 + 2 + 1`) មិនមែន 16 ទេ។
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): នេះអាចត្រូវបានជំនួសដោយ Iterator::scan នៅពេលកំហុសប្រតិបត្តិការនេះត្រូវបានបិទ។
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}