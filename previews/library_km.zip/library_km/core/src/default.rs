//! នេះ `Default` trait សម្រាប់ប្រភេទដែលអាចមានតម្លៃលំនាំដើមដែលមានន័យ។

#![stable(feature = "rust1", since = "1.0.0")]

/// ការ trait សម្រាប់ផ្តល់ប្រភេទតម្លៃលំនាំដើមមានប្រយោជន៍។
///
/// ពេលខ្លះអ្នកចង់ធ្លាក់ចុះមកវិញទៅជាប្រភេទនៃតម្លៃលំនាំដើមមួយចំនួន, និងមិនខ្វល់ពីអ្វីដែលពិសេសដែលវាគឺជា។
/// នេះបានភ្ជាប់មកឡើងជាញឹកញាប់ជាមួយ `struct`s ដែលកំណត់សំណុំរបស់ជម្រើសមួយ:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// តើយើងអាចកំណត់តម្លៃលំនាំដើមខ្លះ?អ្នកអាចប្រើ `Default`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// ឥឡូវនេះអ្នកអាចទទួលបានទាំងអស់នៃតម្លៃលំនាំដើម។Rust អនុវត្ត `Default` សម្រាប់ប្រភេទផ្សេងៗគ្នា។
///
/// ប្រសិនបើអ្នកចង់បដិសេធជម្រើសជាក់លាក់មួយប៉ុន្តែនៅតែរក្សាលំនាំដើមផ្សេងទៀត៖
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// trait នេះអាចត្រូវបានប្រើជាមួយ `#[derive]` ប្រសិនបើទាំងអស់នៃវាលប្រភេទនេះអនុវត្ត `Default` ។
/// ពេល `derive`d វានឹងប្រើតម្លៃលំនាំដើមសម្រាប់ប្រភេទវាលរបស់គ្នា។
///
/// ## របៀបដែលខ្ញុំអាចអនុវត្ត `Default`?
///
/// ផ្តល់នូវការអនុវត្តសម្រាប់វិធីសាស្ត្រ `default()` ដែលត្រឡប់តម្លៃនៃប្រភេទរបស់អ្នកដែលគួរតែជាលំនាំដើម៖
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// ត្រឡប់ "default value" សម្រាប់ប្រភេទមួយ។
    ///
    /// តម្លៃលំនាំដើមជាញឹកញាប់ប្រភេទនៃតម្លៃដំបូងតម្លៃអត្តសញ្ញាណឬអ្វីផ្សេងទៀតដែលអាចធ្វើឱ្យយល់បានជាលំនាំដើមមួយចំនួន។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់តម្លៃលំនាំដើមដែលភ្ជាប់មកជាមួយ៖
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// ការធ្វើឱ្យខ្លួនរបស់អ្នក:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// ត្រឡប់តម្លៃលំនាំដើមនៃប្រភេទមួយយោងទៅតាម `Default` trait ។
///
/// ប្រភេទដែលត្រូវត្រឡប់មកវិញគឺទាបជាងបរិបទ។នេះស្មើនឹង `Default::default()` ប៉ុន្តែខ្លីជាងដើម្បីវាយ។
///
/// ឧទាហរណ៍:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// ទាញយកម៉ាក្រូហ្សែនបង្កើតហ្សែនហ្សិនហ្សិតហ្សិចហ្ស៊ុយ។
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }