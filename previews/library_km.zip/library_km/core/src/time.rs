#![stable(feature = "duration_core", since = "1.25.0")]

//! បរិមាណបណ្តោះអាសន្ន។
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // ការប្រកាសទាំងពីរគឺស្មើនឹង
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// ប្រភេទ `Duration` តំណាងឱ្យរយៈពេលដែលជាទូទៅត្រូវបានប្រើសម្រាប់ការអស់ពេលរបស់ប្រព័ន្ធ។
///
/// `Duration` នីមួយៗផ្សំឡើងដោយចំនួនវិនាទីទាំងមូលនិងផ្នែកប្រភាគដែលតំណាងដោយ nanoseconds ។
/// ប្រសិនបើប្រព័ន្ធមូលដ្ឋានមិនគាំទ្រកម្រិតភាពជាក់លាក់ nanoseconds, APIs ការចងអស់ពេលប្រព័ន្ធមួយនឹងជាធម្មតាជុំឡើងចំនួននៃ nanoseconds នេះ។
///
/// [`រយៈពេល`] អនុវត្ត traits ទូទៅជាច្រើនរួមមាន [`Add`], [`Sub`] និង [`ops`] traits ផ្សេងទៀត។វាអនុវត្ត [`Default`] ដោយត្រឡប់ `Duration` ប្រវែងសូន្យ។
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # ការធ្វើទ្រង់ទ្រាយតម្លៃ `Duration`
///
/// `Duration` ចេតនាមិនមាន impl `Display`, ដូចជាមានភាពខុសគ្នានៃវិធីដើម្បីមានរយៈពេលទ្រង់ទ្រាយនៃការពេលវេលាសម្រាប់ការអានរបស់មនុស្ស។
/// `Duration` ផ្តល់នូវ `Debug` impl ដែលបង្ហាញពីភាពត្រឹមត្រូវពេញលេញនៃតម្លៃ។
///
/// លទ្ធផល `Debug` ប្រើបច្ច័យដែលមិនមែនជា ASCII សម្រាប់ម៉ៃក្រូវិនាទី "µs" ។
/// ប្រសិនបើមានទិន្នផលកម្មវិធីរបស់អ្នកអាចបង្ហាញនៅក្នុងបរិបទដែលមិនអាចពឹងផ្អែកលើភាពឆបគ្នាយូនីកូដពេញលេញ, អ្នកប្រហែលជាចង់ធ្វើទ្រង់ទ្រាយវត្ថុដោយខ្លួនឯងឬ `Duration` ប្រើ crate មួយដើម្បីធ្វើដូច្នេះបាន។
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // ជានិច្ច 0 <=ណាណូ <NANOS_PER_SEC
}

impl Duration {
    /// រយៈពេលនៃមួយវិនាទី។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// រយៈពេលនៃការមិល្លីវិនាទីមួយ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// រយៈពេលនៃមីក្រូវ៉េវមួយ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// រយៈពេលនៃ nanosecond មួយ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// រយៈពេលនៃពេលវេលាសូន្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// រយៈពេលអតិបរមា។
    ///
    /// វាគឺស្មើនឹងរយៈពេល ៥៨៤.៩៤២.៤១៧.៣៥៥ ឆ្នាំ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// បង្កើត `Duration` ថ្មីពីចំនួនដែលបានបញ្ជាក់នៃវិនាទីទាំងមូលនិង nanoseconds បន្ថែម។
    ///
    /// ប្រសិនបើចំនួននៃ nanoseconds គឺធំជាង ១ ពាន់លាន (ចំនួននៃ nanoseconds ក្នុងមួយវិនាទី) នោះវានឹងបន្តទៅជាវិនាទីដែលបានផ្តល់។
    ///
    ///
    /// # Panics
    ///
    /// អ្នកសាងសង់នេះនឹង panic ប្រសិនបើការដឹកចេញពី nanoseconds ហៀរចេញនៅវិនាទីរាប់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// បង្កើត `Duration` ថ្មីពីចំនួនវិនាទីដែលបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// បង្កើត `Duration` ថ្មីពីចំនួនមីលីវិនាទីដែលបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// បង្កើត `Duration` ថ្មីពីចំនួនមីក្រូមីសដែលបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// បង្កើត `Duration` ថ្មីពីចំនួន nanoseconds ដែលបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// ត្រលប់មកវិញពិតប្រសិនបើ `Duration` នេះមិនមានពេល។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// ត្រឡប់ចំនួន _whole_ វិនាទីដែលផ្ទុកដោយ `Duration` នេះ។
    ///
    /// តម្លៃត្រឡប់មកវិញមិនបានរួមបញ្ចូលជាផ្នែកមួយ (nanosecond) នៃរយៈពេលនេះប្រភាគដែលអាចត្រូវបានទទួលដោយការប្រើ [`subsec_nanos`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// ដើម្បីកំណត់ចំនួនវិនាទីសរុបដែលតំណាងដោយ `Duration` សូមប្រើ `as_secs` រួមជាមួយ [`subsec_nanos`]៖
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// ត្រឡប់ផ្នែកប្រភាគនៃ `Duration` នេះគិតជាមិល្លីវិនាទីទាំងមូល។
    ///
    /// វិធីសាស្ត្រនេះមិន **មិន** ត្រឡប់រយៈពេលនៃរយៈពេលដែលតំណាងដោយមីលីវិនាទី។
    /// លេខត្រឡប់មកវិញតែងតែតំណាងឱ្យចំណែកប្រភាគនៃវិនាទី (ឧទាហរណ៍វាតិចជាងមួយពាន់) ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// ត្រឡប់ផ្នែកប្រភាគនៃ `Duration` នេះគិតជាមីក្រូវ៉េវទាំងមូល។
    ///
    /// វិធីសាស្រ្តនេះមិន **មិន** ត្រឡប់រយៈពេលនៃរយៈពេលដែលតំណាងដោយមីក្រូមីក្រូ។
    /// លេខត្រឡប់មកវិញតែងតែតំណាងឱ្យចំណែកប្រភាគនៃវិនាទី (ឧទាហរណ៍វាតិចជាងមួយលាន) ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// ត្រឡប់ផ្នែកប្រភាគនៃ `Duration` នេះក្នុង nanoseconds ។
    ///
    /// វិធីសាស្រ្តនេះមិន **មិន** ត្រឡប់រយៈពេលនៃរយៈពេលនៅពេលតំណាងដោយ nanoseconds ។
    /// លេខត្រឡប់មកវិញតែងតែតំណាងឱ្យចំណែកប្រភាគនៃវិនាទី (ឧទាហរណ៍វាតិចជាងមួយពាន់លាន) ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// ត្រឡប់ចំនួនមីលីវិនាទីទាំងមូលដែលមានដោយ `Duration` នេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// ត្រឡប់ចំនួនមីក្រូសូសសរុបទាំងអស់ដែលមានដោយលេខ `Duration` នេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// ត្រឡប់ចំនួន nanoseconds សរុបដែលមានដោយ `Duration` នេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// បានពិនិត្យបន្ថែម `Duration` ។
    /// គណនា `self + other` ត្រឡប់ [`None`] ប្រសិនបើលើសចំណុះកើតឡើង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ការបន្ថែមអានុភាព `Duration` ។
    /// គណនា `self + other` ត្រឡប់ [`Duration::MAX`] ប្រសិនបើលើសចំណុះកើតឡើង។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// គូសធីកដក `Duration` ។
    /// គណនា `self - other` ត្រឡប់ [`None`] ប្រសិនបើលទ្ធផលនឹងមានអវិជ្ជមានឬប្រសិនបើលើសចំណុះកើតឡើង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ដកដក `Duration` ។
    /// គណនា `self - other` ត្រឡប់ [`Duration::ZERO`] ប្រសិនបើលទ្ធផលនឹងមានអវិជ្ជមានឬប្រសិនបើលើសចំណុះកើតឡើង។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// ធីកគុណ `Duration` ។
    /// គណនា `self * other` ត្រឡប់ [`None`] ប្រសិនបើលើសចំណុះកើតឡើង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // គុណ nanoseconds ជា u64 ពីព្រោះវាមិនអាចហៀរចេញតាមវិធីនោះទេ។
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// អរគុណគុណ `Duration` ។
    /// កុំព្យូទ័រ `self * other` ត្រឡប់ [`Duration::MAX`] ប្រសិនបើមានការលើសចំណុះកើតឡើង។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// បានបែងចែកផ្នែក `Duration` ។
    /// គណនា `self / other` ត្រឡប់ [`None`] ប្រសិនបើ `other == 0` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ត្រឡប់ចំនួនវិនាទីដែលមានដោយ `Duration` នេះជា `f64` ។
    /// តម្លៃត្រឡប់ពិតជារួមបញ្ចូលផ្នែកប្រភាគ (nanosecond) នៃថិរវេលា។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// ត្រឡប់ចំនួនវិនាទីដែលមានដោយ `Duration` នេះជា `f32` ។
    /// តម្លៃត្រឡប់ពិតជារួមបញ្ចូលផ្នែកប្រភាគ (nanosecond) នៃថិរវេលា។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// បង្កើត `Duration` ថ្មីពីចំនួនវិនាទីដែលបានបញ្ជាក់ជា `f64` ។
    ///
    /// # Panics
    /// អ្នកបង្កើតនេះនឹង panic ប្រសិនបើ `secs` គឺមិនមានកំណត់, អវិជ្ជមានឬហូរ `Duration` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// បង្កើត `Duration` ថ្មីពីចំនួនវិនាទីដែលបានបញ្ជាក់ជា `f32` ។
    ///
    /// # Panics
    /// អ្នកបង្កើតនេះនឹង panic ប្រសិនបើ `secs` គឺមិនមានកំណត់, អវិជ្ជមានឬហូរ `Duration` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// គុណ `Duration` ដោយ `f64` ។
    /// # Panics
    /// វិធីសាស្រ្តនេះនឹង panic ប្រសិនបើលទ្ធផលគឺមិនមានកំណត់អវិជ្ជមានឬហូរ `Duration` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// គុណ `Duration` ដោយ `f32` ។
    /// # Panics
    /// វិធីសាស្រ្តនេះនឹង panic ប្រសិនបើលទ្ធផលគឺមិនមានកំណត់អវិជ្ជមានឬហូរ `Duration` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ចំណាំថាដោយសារតែកំហុសជុំលទ្ធផលគឺខុសគ្នាបន្តិចបន្តួចពី 8.478 និង 847800.0
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// ចែក `Duration` ដោយ `f64` ។
    /// # Panics
    /// វិធីសាស្រ្តនេះនឹង panic ប្រសិនបើលទ្ធផលគឺមិនមានកំណត់អវិជ្ជមានឬហូរ `Duration` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // ចំណាំថាការកាត់ខ្លីត្រូវបានប្រើមិនមែនជាការបង្គត់ទេ
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// ចែក `Duration` ដោយ `f32` ។
    /// # Panics
    /// វិធីសាស្រ្តនេះនឹង panic ប្រសិនបើលទ្ធផលគឺមិនមានកំណត់អវិជ្ជមានឬហូរ `Duration` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // ចំណាំថាដោយសារកំហុសបង្គត់លទ្ធផលគឺខុសគ្នាបន្តិចពី 0.859_872_611
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // ចំណាំថាការកាត់ខ្លីត្រូវបានប្រើមិនមែនជាការបង្គត់ទេ
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// ចែក `Duration` ដោយ `Duration` ហើយត្រឡប់ `f64` ។
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// ចែក `Duration` ដោយ `Duration` និងត្រឡប់ `f32` ។
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// ធ្វើទ្រង់ទ្រាយលេខអណ្តែតជាលេខទសភាគ។
        ///
        /// លេខត្រូវបានផ្តល់ជា `integer_part` និងផ្នែកប្រភាគ។
        /// តម្លៃនៃផ្នែកប្រភាគគឺ `fractional_part / divisor` ។
        /// ដូច្នេះ `integer_part` =3, `fractional_part` =12 និង `divisor` =100 តំណាងអោយលេខ `3.012` ។
        /// សូន្យនៅពីក្រោយត្រូវបានលុបចោល។
        ///
        /// `divisor` មិនត្រូវលើសពី ១០០_០០០_០០០ ។
        /// វាក៏គួរតែជាថាមពល ១០ ដែរអ្វីៗផ្សេងទៀតមិនមានន័យទេ។
        /// `fractional_part` ត្រូវតែតិចជាង `10 * divisor`!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // អ៊ិនកូដផ្នែកប្រភាគទៅជាសតិបណ្ដោះអាសន្ន។
            // សតិបណ្ដោះអាសន្នគ្រាន់តែកាន់ធាតុ ៩ ប៉ុណ្ណោះពីព្រោះ `fractional_part` ត្រូវតែតូចជាង ១០ ^ ៩ ។
            //
            // សតិបណ្ដោះអាសន្នត្រូវបានបញ្ចូលជាមួយលេខ '0' ដើម្បីធ្វើឱ្យលេខកូដខាងក្រោមកាន់តែងាយស្រួល។
            let mut buf = [b'0'; 9];

            // ខ្ទង់បន្ទាប់ត្រូវបានសរសេរនៅទីតាំងនេះ
            let mut pos = 0;

            // យើងបន្តសរសេរតួលេខទៅក្នុងសតិបណ្ដោះអាសន្នខណៈពេលដែលមានខ្ទង់មិនមែនលេខសូន្យហើយយើងមិនទាន់សរសេរតួលេខគ្រប់គ្រាន់ទេ។
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // សរសេរខ្ទង់ថ្មីចូលក្នុងអង្គចងចាំ
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // ប្រសិនបើមានភាពជាក់លាក់មួយដែល <9 ត្រូវបានបញ្ជាក់, អាចមានមិនសូន្យមួយចំនួនបានចាកចេញពីតួដែលមិនត្រូវបានសរសេរទៅក្នុងសតិបណ្ដោះអាសន្ននេះ។
            // ក្នុងករណីនោះយើងត្រូវអនុវត្តការបង្គត់ដើម្បីផ្គូផ្គងពាក្យគន្លឹះនៃការបោះពុម្ពលេខចំណុចអណ្តែតទឹកធម្មតា។
            // ទោះយ៉ាងណាក៏ដោយយើងគ្រាន់តែត្រូវការធ្វើការនៅពេលប្រមូលផ្តុំ។
            // វាកើតឡើងប្រសិនបើខ្ទង់ទីមួយនៃខ្ទង់ដែលនៅសល់គឺ>=៥ ។
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // ជុំទីឡើងចំនួនដែលមាននៅក្នុងសតិបណ្ដោះអាសន្ននេះ។
                // យើងឆ្លងកាត់សតិបណ្ដោះអាសន្នថយក្រោយហើយតាមដានរបស់យួរ។
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // ប្រសិនបើតួលេខនៅក្នុងសតិបណ្ដោះអាសន្នមិនមែនជា '9' ទេយើងគ្រាន់តែត្រូវការបង្កើនវាហើយអាចបញ្ឈប់នៅពេលនោះ (ដោយសារយើងមិនមានដឹកទំនិញទៀតទេ) ។
                    // បើមិនដូច្នោះទេយើងកំណត់វាទៅ '0' (overflow) ហើយបន្ត។
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // ប្រសិនបើយើងនៅតែមានសំណុំប៊ីតនោះមានន័យថាយើងកំណត់សតិបណ្ដោះអាសន្នទាំងមូលទៅ '០ ហើយត្រូវការបង្កើនផ្នែកចំនួនគត់។
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // កំណត់ចុងបញ្ចប់នៃសតិបណ្ដោះអាសន្ននេះ: ប្រសិនបើមានភាពជាក់លាក់ត្រូវបានកំណត់, យើងគ្រាន់តែប្រើជាតួលេខជាច្រើនមកពីសតិបណ្ដោះអាសន្ននេះ (កំណត់ទៅ 9) ។
            // ប្រសិនបើវាមិនត្រូវបានកំណត់យើងប្រើតែខ្ទង់ទាំងអស់រហូតដល់ខ្ទង់ចុងក្រោយដែលមិនមែនសូន្យ។
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // ប្រសិនបើយើងមិនបានបញ្ចេញលេខប្រភាគតែមួយទេហើយភាពជាក់លាក់មិនត្រូវបានកំណត់ចំពោះតម្លៃមិនមែនសូន្យយើងមិនបោះពុម្ពចំនុចគោលទេ។
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // សុវត្ថិភាព: យើងកំពុងសរសេរតែលេខ ASCII ទៅក្នុងសតិបណ្ដោះអាសន្នហើយវាបានកើតឡើង
                // បានចាប់ផ្តើមជាមួយ '០'s ដូច្នេះវាមាន UTF8 ត្រឹមត្រូវ។
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // ប្រសិនបើអ្នកប្រើស្នើសុំភាពជាក់លាក់> ៩ យើងដាប់លេខ ០ នៅចុងបញ្ចប់។
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // បោះពុម្ពសញ្ញា '+' នាំមុខប្រសិនបើស្នើសុំ
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}