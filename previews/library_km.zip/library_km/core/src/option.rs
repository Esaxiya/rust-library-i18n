//! តម្លៃជម្រើស។
//!
//! ប្រភេទ [`Option`] តំណាងឱ្យតម្លៃជម្រើសមួយ: រាល់ [`Option`] គឺទាំង [`Some`] និងមានតម្លៃឬ [`None`] ហើយមិនមាន។
//! [`Option`] ប្រភេទជារឿងធម្មតាណាស់នៅក្នុងកូដ Rust ព្រោះវាមានការប្រើប្រាស់មួយចំនួន៖
//!
//! * តម្លៃដំបូង
//! * តម្លៃត្រឡប់សម្រាប់មុខងារដែលមិនត្រូវបានកំណត់លើជួរបញ្ចូលទាំងមូលរបស់ពួកគេ (មុខងារដោយផ្នែក)
//! * តម្លៃត្រឡប់សម្រាប់ការរាយការណ៍បើមិនដូច្នេះទេកំហុសសាមញ្ញដែល [`None`] ត្រូវបានត្រឡប់ដោយមានកំហុស
//! * វាលរចនាសម្ព័ន្ធស្រេចចិត្ត
//! * វាលរចនាសម្ព័ន្ធដែលអាចត្រូវបានខ្ចីឬ "taken"
//! * អាគុយម៉ង់មុខងារស្រេចចិត្ត
//! * ចង្អុលបង្ហាញដែលមិនអាចដកខ្លួនបាន
//! * ដោះដូរអ្វីៗចេញពីស្ថានភាពពិបាក
//!
//! [`ជម្រើស`] ជាទូទៅត្រូវបានផ្គូផ្គងជាមួយនឹងការផ្គូរផ្គងលំនាំដើម្បីសួរពីវត្តមាននៃតម្លៃនិងចាត់វិធានការដែលតែងតែគិតដល់ករណី [`None`] ។
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // តម្លៃត្រឡប់នៃមុខងារគឺជាជម្រើសមួយ
//! let result = divide(2.0, 3.0);
//!
//! // លំនាំផ្គូផ្គងដើម្បីទាញយកតម្លៃ
//! match result {
//!     // ការបែងចែកមានសុពលភាព
//!     Some(x) => println!("Result: {}", x),
//!     // ការបែងចែកមិនត្រឹមត្រូវ
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: បង្ហាញពីរបៀបដែល `Option` ត្រូវបានប្រើក្នុងការអនុវត្តដោយមានវិធីសាស្រ្តជាច្រើន
//
//! # ជម្រើសនិងអ្នកចង្អុលបង្ហាញ (អ្នកចង្អុល "nullable")
//!
//! ប្រភេទទ្រនិចរបស់ Rust ត្រូវតែចង្អុលទៅទីតាំងត្រឹមត្រូវជានិច្ច។មិនមានឯកសារយោង "null" ទេ។ផ្ទុយទៅវិញ Rust មានអ្នកចង្អុលបង្ហាញ * ជាជម្រើសដូចជាប្រអប់ដែលជាកម្មសិទ្ធិរបស់ជម្រើស [`ជម្រើស`] `<` [`ប្រអប់<T>`]`>`។
//!
//! ឧទាហរណ៍ខាងក្រោមប្រើ [`Option`] ដើម្បីបង្កើតប្រអប់ស្រេចចិត្តនៃ [`i32`] ។
//! សូមកត់សម្គាល់ថាដើម្បីប្រើតម្លៃ [`i32`] ខាងក្នុងដំបូងមុខងារ `check_optional` ត្រូវការប្រើការផ្គូផ្គងលំនាំដើម្បីកំណត់ថាតើប្រអប់មានតម្លៃឬអត់ (មានន័យថាវាមានតម្លៃ [`Some(...)`][`Some`]) ឬមិនមែន ([`None`]) ។
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! Rust ធានាថានឹងបង្កើនប្រសិទ្ធភាពប្រភេទ `T` ដូចខាងក្រោមដែល [`Option<T>`] មានទំហំប៉ុន `T`៖
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` រចនាសម្ព័ន្ធនៅជុំវិញប្រភេទមួយនៃបញ្ជីនេះ។
//!
//! វាត្រូវបានធានាបន្ថែមទៀតថាសម្រាប់ករណីខាងលើមនុស្សម្នាក់អាច [`mem::transmute`] ពីតម្លៃដែលមានសុពលភាពទាំងអស់នៃ `T` ដល់ `Option<T>` និងពី `Some::<T>(_)` ទៅ `T` (ប៉ុន្តែការបញ្ជូន `None::<T>` ទៅ `T` គឺជាឥរិយាបទដែលមិនបានកំណត់) ។
//!
//! # Examples
//!
//! ការផ្គូផ្គងលំនាំមូលដ្ឋានលើ [`Option`]៖
//!
//! ```
//! let msg = Some("howdy");
//!
//! // យោងតាមខ្សែអក្សរដែលមាន
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // ដោះខ្សែដែលមានផ្ទុកបំផ្លាញជម្រើស
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! ចាប់ផ្តើមលទ្ធផលទៅ [`None`] មុនពេលរង្វិលជុំ៖
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // បញ្ជីទិន្នន័យដែលត្រូវស្វែងរក។
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // យើងនឹងស្វែងរកឈ្មោះរបស់សត្វដែលធំជាងគេប៉ុន្តែដើម្បីចាប់ផ្តើមយើងទើបតែទទួលបាន `None` ។
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // ឥឡូវយើងបានរកឃើញឈ្មោះសត្វធំ ៗ មួយចំនួន
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// ប្រភេទ `Option` ។មើល [the module level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// មិនមានតម្លៃ
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// តម្លៃខ្លះ `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// ប្រភេទការអនុវត្ត
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // សួរតម្លៃដែលមាន
    /////////////////////////////////////////////////////////////////////////

    /// ត្រឡប់ `true` ប្រសិនបើជម្រើសគឺជាតម្លៃ [`Some`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// ត្រឡប់ `true` ប្រសិនបើជម្រើសគឺជាតម្លៃ [`None`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// ត្រឡប់ `true` ប្រសិនបើជម្រើសគឺជាតម្លៃ [`Some`] ដែលមានតម្លៃដែលបានផ្តល់។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // អាដាប់ទ័រសម្រាប់ធ្វើការជាមួយឯកសារយោង
    /////////////////////////////////////////////////////////////////////////

    /// បំលែងពី `&Option<T>` ទៅ `Option<&T>` ។
    ///
    /// # Examples
    ///
    /// បម្លែងជម្រើស `ជម្រើស <` [`ខ្សែអក្សរ`] `>` ទៅជាជម្រើស `<` [`ប្រើ`] `>` ដោយរក្សាភាពដើម។
    /// វិធីសាស្ត្រ [`map`] យកអាគុយម៉ង់ `self` ដោយតម្លៃការប្រើប្រាស់ដើមដូច្នេះបច្ចេកទេសនេះប្រើ `as_ref` ដំបូងយក `Option` ទៅជាឯកសារយោងទៅតម្លៃខាងក្នុង។
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // ដំបូងបោះ `Option<String>` ទៅ `Option<&String>` ជាមួយ `as_ref` បន្ទាប់មកប្រើ *នោះ* ជាមួយ `map` ទុក `text` នៅលើជង់។
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// បំលែងពី `&mut Option<T>` ទៅ `Option<&mut T>` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// បំលែងពី [`ពិន៉]` <និងជម្រើស<T>> `ទៅ` ជម្រើស <`[` ពិន]] `<និងធី>>` ។
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // សុវត្ថិភាព: `x` ត្រូវបានធានាថាត្រូវបានខ្ទាស់ពីព្រោះវាមកពី `self`
        // ដែលត្រូវបានខ្ទាស់។
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// បំលែងពី [`ពិន`] `<និងជម្រើស<T>>`ទៅ`ជម្រើស <`[`ពិន]]`<&mut T>>` ។
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // សុវត្ថិភាព: `get_unchecked_mut` មិនដែលត្រូវបានប្រើដើម្បីផ្លាស់ទី `Option` នៅខាងក្នុង `self` ទេ។
        // `x` ត្រូវបានធានាថាត្រូវបានខ្ទាស់ពីព្រោះវាមកពី `self` ដែលត្រូវបានខ្ទាស់។
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // ការឈានដល់តម្លៃដែលមាន
    /////////////////////////////////////////////////////////////////////////

    /// ត្រឡប់តម្លៃ [`Some`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃគឺជា [`None`] ដែលមានសារ panic ផ្ទាល់ខ្លួនដែលផ្តល់ដោយ `msg` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// ត្រឡប់តម្លៃ [`Some`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ។
    ///
    /// ដោយសារតែមុខងារនេះអាច panic ការប្រើប្រាស់ជាទូទៅត្រូវបានលើកទឹកចិត្ត។
    /// ផ្ទុយទៅវិញចូលចិត្តប្រើការផ្គូផ្គងលំនាំនិងដោះស្រាយករណី [`None`] យ៉ាងច្បាស់ឬហៅទូរស័ព្ទ [`unwrap_or`], [`unwrap_or_else`], ឬ [`unwrap_or_default`] ។
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃខ្លួនឯងស្មើនឹង [`None`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// ត្រឡប់តម្លៃ [`Some`] ដែលមានឬលំនាំដើមដែលបានផ្តល់។
    ///
    /// អាគុយម៉ង់ដែលបានបញ្ជូនទៅ `unwrap_or` ត្រូវបានវាយតម្លៃយ៉ាងអន្ទះអន្ទែង;ប្រសិនបើអ្នកកំពុងឆ្លងកាត់លទ្ធផលនៃការហៅមុខងារវាត្រូវបានគេណែនាំឱ្យប្រើ [`unwrap_or_else`] ដែលត្រូវបានវាយតម្លៃយ៉ាងខ្ជិល។
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// ត្រឡប់តម្លៃ [`Some`] ដែលមានឬគណនាវាពីការបិទ។
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// ត្រឡប់តម្លៃ [`Some`] ដែលមាន, ប្រើប្រាស់តម្លៃ `self` ដោយមិនចាំបាច់ពិនិត្យមើលថាតម្លៃមិនមែន [`None`] ។
    ///
    ///
    /// # Safety
    ///
    /// ការហៅវិធីសាស្ត្រនេះនៅលើ [`None`] គឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]*។
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // ឥរិយាបទមិនបានកំណត់!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ការផ្លាស់ប្តូរតម្លៃដែលមាន
    /////////////////////////////////////////////////////////////////////////

    /// គូសផែនទី `Option<T>` ទៅ `Option<U>` ដោយអនុវត្តមុខងារទៅតម្លៃដែលមាន។
    ///
    /// # Examples
    ///
    /// បម្លែងជម្រើស `ជម្រើស <` [`ខ្សែអក្សរ`] `>` ទៅជាជម្រើស ```` ប្រើ `-` ដោយប្រើច្បាប់ដើម៖
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` យកខ្លួនឯង *តាមតំលៃ* ការប្រើប្រាស់ `maybe_some_string`
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// អនុវត្តមុខងារទៅតម្លៃដែលមាន (បើមាន) ឬត្រឡប់លំនាំដើមដែលបានផ្ដល់ (បើមិន) ។
    ///
    /// អាគុយម៉ង់ដែលបានបញ្ជូនទៅ `map_or` ត្រូវបានវាយតម្លៃយ៉ាងអន្ទះអន្ទែង;ប្រសិនបើអ្នកកំពុងឆ្លងកាត់លទ្ធផលនៃការហៅមុខងារវាត្រូវបានគេណែនាំឱ្យប្រើ [`map_or_else`] ដែលត្រូវបានវាយតម្លៃយ៉ាងខ្ជិល។
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// អនុវត្តមុខងារទៅតម្លៃដែលមាន (បើមាន) ឬគណនាលំនាំដើម (បើមិន) ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// បំលែង `Option<T>` ទៅជា [`Result<T, E>`] គូសផែនទី [`Some(v)`] ទៅ [`Ok(v)`] និង [`None`] ទៅ [`Err(err)`] ។
    ///
    /// អាគុយម៉ង់ដែលបានបញ្ជូនទៅ `ok_or` ត្រូវបានវាយតម្លៃយ៉ាងអន្ទះអន្ទែង;ប្រសិនបើអ្នកកំពុងឆ្លងកាត់លទ្ធផលនៃការហៅមុខងារវាត្រូវបានគេណែនាំឱ្យប្រើ [`ok_or_else`] ដែលត្រូវបានវាយតម្លៃយ៉ាងខ្ជិល។
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// បំលែង `Option<T>` ទៅជា [`Result<T, E>`] គូសផែនទី [`Some(v)`] ទៅ [`Ok(v)`] និង [`None`] ទៅ [`Err(err())`] ។
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// បញ្ចូល `value` ទៅក្នុងជម្រើសបន្ទាប់មកត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានទៅវា។
    ///
    /// ប្រសិនបើជម្រើសមានតម្លៃរួចហើយតម្លៃចាស់ត្រូវបានទម្លាក់។
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // សុវត្ថិភាព: កូដខាងលើគ្រាន់តែបំពេញជម្រើស
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // អ្នកសាងសង់ឧបករណ៍បំលែង
    /////////////////////////////////////////////////////////////////////////

    /// ត្រឡប់អ្នកត្រួតលើតម្លៃដែលអាចមាន។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// ត្រឡប់ទ្រនិចនាឡិកាដែលអាចផ្លាស់ប្តូរបានលើតម្លៃដែលមាន។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // ប្រតិបត្ដិប៊ូលីនលើគុណតម្លៃរំភើបនិងខ្ជិល
    /////////////////////////////////////////////////////////////////////////

    /// ត្រឡប់ [`None`] បើជម្រើស [`None`] បើមិនដូច្នេះទេត្រឡប់ `optb` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// ត្រឡប់ [`None`] ប្រសិនបើជម្រើសគឺ [`None`] បើមិនដូច្នេះទេហៅទូរស័ព្ទ `f` ជាមួយនឹងតម្លៃរុំហើយត្រឡប់លទ្ធផល។
    ///
    ///
    /// ភាសាខ្លះហៅថាប្រតិបត្ដិការនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// ត្រឡប់ [`None`] ប្រសិនបើជម្រើសគឺ [`None`] បើមិនដូច្នេះទេហៅទូរស័ព្ទ `predicate` ជាមួយតម្លៃរុំនិងត្រឡប់មកវិញ៖
    ///
    ///
    /// - [`Some(t)`] ប្រសិនបើ `predicate` ត្រឡប់ `true` (ដែល `t` គឺជាតម្លៃរុំ) និង
    /// - [`None`] បើ `predicate` ត្រឡប់ `false` ។
    ///
    /// មុខងារនេះដំណើរការស្រដៀងនឹង [`Iterator::filter()`] ដែរ។
    /// អ្នកអាចស្រម៉ៃថា `Option<T>` ជាអ្នកធ្វើចរន្តលើធាតុមួយឬសូន្យ។
    /// `filter()` អនុញ្ញាតឱ្យអ្នកសម្រេចចិត្តថាតើធាតុណាមួយត្រូវរក្សាទុក។
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// ត្រឡប់ជម្រើសប្រសិនបើវាមានតម្លៃបើមិនដូច្នេះទេត្រឡប់ `optb` ។
    ///
    /// អាគុយម៉ង់ដែលបានបញ្ជូនទៅ `or` ត្រូវបានវាយតម្លៃយ៉ាងអន្ទះអន្ទែង;ប្រសិនបើអ្នកកំពុងឆ្លងកាត់លទ្ធផលនៃការហៅមុខងារវាត្រូវបានគេណែនាំឱ្យប្រើ [`or_else`] ដែលត្រូវបានវាយតម្លៃយ៉ាងខ្ជិល។
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// ត្រឡប់ជម្រើសប្រសិនបើវាមានតម្លៃបើមិនដូច្នេះទេហៅទូរស័ព្ទ `f` ហើយត្រឡប់លទ្ធផល។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// ត្រឡប់ [`Some`] ប្រសិនបើពិតប្រាកដមួយនៃ `self`, `optb` គឺ [`Some`] បើមិនដូច្នេះទេត្រឡប់ [`None`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ប្រតិបត្ដិការដូចជាបញ្ចូលដើម្បីបញ្ចូលប្រសិនបើគ្មានហើយប្រគល់សេចក្តីយោង
    /////////////////////////////////////////////////////////////////////////

    /// បញ្ចូល `value` ទៅក្នុងជម្រើសប្រសិនបើវាជា [`None`] បន្ទាប់មកត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅតម្លៃដែលមាន។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// បញ្ចូលតម្លៃលំនាំដើមទៅក្នុងជម្រើសប្រសិនបើវាជា [`None`] បន្ទាប់មកត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅតម្លៃដែលមាន។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// បញ្ចូលតម្លៃដែលគណនាពី `f` ទៅក្នុងជម្រើសប្រសិនបើវាជា [`None`] បន្ទាប់មកត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅតម្លៃដែលមាន។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // សុវត្ថិភាព: វ៉ារ្យ៉ង់ `None` សម្រាប់ `self` នឹងត្រូវបានជំនួសដោយ `Some`
            // វ៉ារ្យ៉ង់នៅក្នុងកូដខាងលើ។
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// យកតម្លៃចេញពីជម្រើសដោយបន្សល់ទុកនូវ [`None`] X នៅកន្លែងរបស់វា។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// ជំនួសតម្លៃជាក់ស្តែងនៅក្នុងជម្រើសដោយតម្លៃដែលបានផ្តល់ជាប៉ារ៉ាម៉ែត្រត្រឡប់តម្លៃចាស់ប្រសិនបើមានបច្ចុប្បន្នដោយបន្សល់ទុកនូវ [`Some`] X នៅកន្លែងរបស់វាដោយមិនធ្វើឱ្យខូចទ្រង់ទ្រាយណាមួយឡើយ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// ហ្ស៊ីព `self` ជាមួយ `Option` ផ្សេងទៀត។
    ///
    /// ប្រសិនបើ `self` គឺ `Some(s)` និង `other` គឺជា `Some(o)` នោះវិធីសាស្ត្រនេះត្រលប់មកវិញ `Some((s, o))` ។
    /// បើមិនដូច្នោះទេ `None` ត្រូវបានត្រឡប់មកវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// ហ្ស៊ីព `self` និង `Option` មួយទៀតដែលមានមុខងារ `f` ។
    ///
    /// ប្រសិនបើ `self` គឺ `Some(s)` និង `other` គឺ `Some(o)` នោះវិធីសាស្ត្រនេះត្រលប់មកវិញ `Some(f(s, o))` ។
    /// បើមិនដូច្នោះទេ `None` ត្រូវបានត្រឡប់មកវិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// ផែនទី `Option<&T>` ទៅ `Option<T>` ដោយការចម្លងមាតិកានៃជម្រើស។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// ផែនទី `Option<&mut T>` ទៅ `Option<T>` ដោយការចម្លងមាតិកានៃជម្រើស។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// គូសផែនទី `Option<&T>` ទៅ `Option<T>` ដោយក្លូនមាតិកានៃជម្រើស។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// គូសផែនទី `Option<&mut T>` ទៅ `Option<T>` ដោយក្លូនមាតិកានៃជម្រើស។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// ប្រើប្រាស់ `self` ខណៈពេលដែលរំពឹងថា [`None`] និងមិនវិលត្រឡប់មកវិញ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃគឺជា [`Some`] ដែលមានសារ panic រួមទាំងសារដែលបានឆ្លងកាត់និងមាតិការបស់ [`Some`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // នេះនឹងមិន panic ទេពីព្រោះគ្រាប់ចុចទាំងអស់គឺមានតែមួយ។
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// ប្រើប្រាស់ `self` ខណៈពេលដែលរំពឹងថា [`None`] និងមិនវិលត្រឡប់មកវិញ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃគឺជា [`Some`] ដែលមានសារ panic ផ្ទាល់ខ្លួនដែលផ្តល់ដោយតម្លៃរបស់ `` ខ្លះ។
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // នេះនឹងមិន panic ទេពីព្រោះគ្រាប់ចុចទាំងអស់គឺមានតែមួយ។
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// ត្រឡប់តម្លៃ [`Some`] ដែលមានឬលំនាំដើម
    ///
    /// ប្រើអាគុយម៉ង់ `self` បន្ទាប់មកប្រសិនបើ [`Some`] ត្រឡប់តម្លៃដែលមានបើមិនដូច្នេះទេប្រសិនបើ [`None`] ត្រឡប់ [default value] សម្រាប់ប្រភេទនោះ។
    ///
    ///
    /// # Examples
    ///
    /// បម្លែងខ្សែអក្សរទៅជាចំនួនគត់ដោយបង្វែរខ្សែអក្សរដែលបានបង្កើតមិនត្រឹមត្រូវទៅជាលេខ ០ (តម្លៃលំនាំដើមសម្រាប់ចំនួនគត់) ។
    /// [`parse`] បម្លែងខ្សែអក្សរមួយទៅប្រភេទផ្សេងទៀតដែលអនុវត្ត [`FromStr`] ត្រឡប់ [`None`] ដោយមានកំហុស។
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// បំលែងពី `Option<T>` (ឬ `&Option<T>`) ទៅ `Option<&T::Target>` ។
    ///
    /// ស្លឹកជម្រើសដើមនៅនឹងកន្លែង, ការបង្កើតថ្មីមួយដោយយោងទៅដើមមួយ, លើសពីនេះទៀតតាមរយៈមាតិកាបង្ខំ [`Deref`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// បំលែងពី `Option<T>` (ឬ `&mut Option<T>`) ទៅ `Option<&mut T::Target>` ។
    ///
    /// ទុកកន្លែងដើម `Option` នៅកន្លែងបង្កើតថ្មីដែលមានឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅនឹងប្រភេទ `Deref::Target` របស់ផ្នែកខាងក្នុង។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// ប្តូរ `Option` នៃ [`Result`] ទៅជា [`Result`] នៃ `Option` ។
    ///
    /// [`None`] នឹងត្រូវបានផ្គូផ្គងទៅ [`អូឃ្យូ]` (`[` គ្មាន `]`) `។
    /// [`អ្នកខ្លះ`] `(` [`អូខេ]]` (_)) `និង [` ខ្លះ ```(` [`អឺរ`) `(_))` នឹងត្រូវបានគូសផែនទីទៅ [`អូកា`] `(`[`អ្នកខ្លះ`)`(_))`និង [`Err`] `(_)` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// នេះគឺជាមុខងារដាច់ដោយឡែកមួយដើម្បីកាត់បន្ថយទំហំកូដ .expect() ដោយខ្លួនឯង។
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// នេះគឺជាមុខងារដាច់ដោយឡែកមួយដើម្បីកាត់បន្ថយទំហំកូដ .expect_none() ដោយខ្លួនឯង។
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// ការអនុវត្ត Trait
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// ត្រឡប់ [`None`][Option::None] ។
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ត្រឡប់ការប្រើប្រាស់លើតម្លៃដែលអាចមាន។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// ចម្លង `val` ទៅក្នុង `Some` ថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// បំលែងពី `&Option<T>` ទៅ `Option<&T>` ។
    ///
    /// # Examples
    ///
    /// បម្លែងជម្រើស `ជម្រើស <` [`ខ្សែអក្សរ`] `>` ទៅជាជម្រើស `<` [`ប្រើ`] `>` ដោយរក្សាភាពដើម។
    /// វិធីសាស្ត្រ [`map`] យកអាគុយម៉ង់ `self` ដោយតម្លៃការប្រើប្រាស់ដើមដូច្នេះបច្ចេកទេសនេះប្រើ `as_ref` ដំបូងយក `Option` ទៅជាឯកសារយោងទៅតម្លៃខាងក្នុង។
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// បំលែងពី `&mut Option<T>` ទៅ `Option<&mut T>`
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ឧបករណ៍ជ្រើសរើសជំរើស
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// អ្នកត្រួតលើការយោងទៅវ៉ារ្យ៉ង់ [`Some`] នៃ [`Option`] ។
///
/// ទ្រនាប់ទ្រនាប់ផ្តល់នូវគុណតម្លៃមួយប្រសិនបើ [`Option`] គឺជា [`Some`] បើមិនដូច្នេះទេគ្មានទេ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយមុខងារ [`Option::iter`] ។
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// អ្នកនិយាយអំពីការយោងដែលអាចផ្លាស់ប្តូរបានចំពោះវ៉ាយ [`Some`] នៃ [`Option`] ។
///
/// ទ្រនាប់ទ្រនាប់ផ្តល់នូវគុណតម្លៃមួយប្រសិនបើ [`Option`] គឺជា [`Some`] បើមិនដូច្នេះទេគ្មានទេ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយមុខងារ [`Option::iter_mut`] ។
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// អ្នកត្រួតត្រាលើតម្លៃនៅក្នុងវ៉ារ្យ៉ង់ [`Some`] នៃ [`Option`] ។
///
/// ទ្រនាប់ទ្រនាប់ផ្តល់នូវគុណតម្លៃមួយប្រសិនបើ [`Option`] គឺជា [`Some`] បើមិនដូច្នេះទេគ្មានទេ។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយមុខងារ [`Option::into_iter`] ។
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// យកធាតុនីមួយៗនៅក្នុង [`Iterator`]: ប្រសិនបើវាជា [`None`][Option::None] គ្មានធាតុបន្ថែមត្រូវបានគេយកទេហើយ [`None`][Option::None] ត្រូវបានត្រឡប់មកវិញ។
    /// មិនគួរមាន [`None`][Option::None] កើតឡើងកុងតឺន័រដែលមានតម្លៃរបស់ [`Option`] នីមួយៗត្រូវបានប្រគល់មកវិញ។
    ///
    /// # Examples
    ///
    /// នេះគឺជាឧទាហរណ៍មួយដែលបង្កើនរាល់ចំនួនគត់ក្នុង vector ។
    /// យើងប្រើវ៉ារ្យ៉ង់ដែលបានត្រួតពិនិត្យនៃ `add` ដែលត្រឡប់ `None` នៅពេលការគណនានឹងនាំឱ្យមានការហៀរចេញ។
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// ដូចដែលអ្នកអាចឃើញវានឹងត្រលប់មកវិញនូវធាតុដែលរំពឹងទុកនិងមានសុពលភាព។
    ///
    /// នេះជាឧទាហរណ៍មួយផ្សេងទៀតដែលព្យាយាមដកមួយចេញពីបញ្ជីចំនួនគត់ផ្សេងទៀតពេលនេះពិនិត្យរកមើលលំហូរដែលកំពុងដំណើរការ៖
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// ដោយសារធាតុចុងក្រោយគឺសូន្យវានឹងហូរចុះ។ដូច្នេះតម្លៃលទ្ធផលគឺ `None` ។
    ///
    /// នេះគឺជាបំរែបំរួលនៅលើឧទាហរណ៍មុនដែលបង្ហាញថាមិនមានធាតុបន្ថែមទៀតត្រូវបានយកពី `iter` បន្ទាប់ពី `None` ដំបូងទេ។
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// ចាប់តាំងពីធាតុទីបីបណ្តាលឱ្យមានដំណើរការមិនមានធាតុបន្ថែមទៀតដូច្នេះតម្លៃចុងក្រោយនៃ `shared` គឺ 6 (= `3 + 2 + 1`) មិនមែន 16 ទេ។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): នេះអាចត្រូវបានជំនួសដោយ Iterator::scan នៅពេលកំហុសប្រតិបត្តិការនេះត្រូវបានបិទ។
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// ប្រភេទកំហុសដែលបណ្តាលមកពីការដាក់ពាក្យសុំប្រតិបត្តិករ (`?`) ទៅតម្លៃ `None` ។
/// ប្រសិនបើអ្នកចង់អនុញ្ញាតឱ្យ `x?` (ដែល `x` គឺជា `Option<T>`) ត្រូវបានបម្លែងទៅជាប្រភេទកំហុសរបស់អ្នកអ្នកអាចអនុវត្ត `impl From<NoneError>` សម្រាប់ `YourErrorType` ។
///
/// ក្នុងករណីនោះ `x?` នៅក្នុងមុខងារដែលត្រឡប់ `Result<_, YourErrorType>` នឹងបកប្រែតម្លៃ `None` ទៅជាលទ្ធផល `Err` ។
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// បំលែងពី `Option<Option<T>>` ទៅ `Option<T>`
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// បំផ្លាញយកកម្រិតនៃការដាក់ខាងក្នុងមួយពេលមួយតែប៉ុណ្ណោះនៅលើ:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}