use crate::{iter::FusedIterator, ops::Try};

/// ឧបករណ៍រំកិលដែលធ្វើម្តងទៀតដោយគ្មានទីបញ្ចប់។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយវិធីសាស្ដ្រ [`cycle`] លើ [`Iterator`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // អ្នកធ្វើវដ្ដគឺទទេរឺគ្មានកំណត់
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // ធ្វើឱ្យពេញលេញដល់ឧបករណ៍វាស់ចរន្ត។
        // នេះគឺចាំបាច់ពីព្រោះ `self.iter` អាចនឹងទទេសូម្បីតែ `self.orig` ក៏មិនមែន
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // បំពេញវដ្តពេញលេញដោយតាមដានថាតើទ្រនិចស៊ីក្លូទទេឬអត់។
        // យើងត្រូវត្រលប់ទៅដើមវិញក្នុងករណីមានអ្នកធ្វើចរន្តអគ្គិសនីដើម្បីការពាររង្វិលជុំដែលគ្មានកំណត់
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // គ្មានការបដិសេធ `fold` ទេពីព្រោះ `fold` មិនសមហេតុផលសម្រាប់ `Cycle` ទេហើយយើងមិនអាចធ្វើអ្វីប្រសើរជាងលំនាំដើមបានទេ។
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}