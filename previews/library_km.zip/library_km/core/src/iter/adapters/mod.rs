use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// trait នេះផ្តល់នូវការផ្លាស់ប្តូរការចូលទៅកាន់ដំណាក់កាលប្រភពនៅក្នុងបំពង់បំលែង-អាដាប់ធ័រក្រោមលក្ខខណ្ឌដែល
/// * ប្រភពតង់ស្យុង `S` ខ្លួនវាអនុវត្ត `SourceIter<Source = S>`
/// * នៅទីនោះគឺជាការអនុវត្តផ្ទេរនេះសម្រាប់ការ trait អាដាប់ធ័រគ្នានៅក្នុងបំពង់បង្ហូរប្រេងរវាងប្រភពនិងប្រើប្រាស់បំពង់បង្ហូរប្រេងនេះ។
///
/// នៅពេលដែលប្រភពជាម្ចាស់ struct បម្រុង (ធម្មតាគេហៅថា `IntoIter`) បន្ទាប់មកនេះអាចមានប្រយោជន៍សម្រាប់ឯកទេសប្រតិបត្តិ [`FromIterator`] ឬងើបឡើងវិញបន្ទាប់ពីធាតុដែលនៅសេសសល់ត្រូវបានបម្រុងហត់នឿយផ្នែកខ្លះ។
///
///
/// ចំណាំថាការប្រតិបត្តិមិនចាំបាច់មានការផ្តល់នូវការចូលដំណើរការទៅកាន់ប្រភពខាងក្នុងនៃបំពង់បង្ហូរឧស្ម័នបំផុតមួយ។អាដាប់ធ័រកម្រិតមធ្យមរបស់រដ្ឋអាចវាយតម្លៃផ្នែកមួយនៃបំពង់បង្ហូរប្រេងហើយលាតត្រដាងការផ្ទុកខាងក្នុងរបស់វាជាប្រភព។
///
/// trait មិនមានសុវត្ថិភាពនោះទេព្រោះនេះគឺត្រូវគាំទ្រលក្ខណៈសម្បត្តិអនុវត្តន៍សុវត្ថិភាពបន្ថែមទៀត។
/// សូមមើល [`as_inner`] សម្រាប់លម្អិត។
///
/// # Examples
///
/// កំពុងទៅយកប្រភពប្រើប្រាស់ដោយផ្នែកមួយ:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// ដំណាក់កាលប្រភពមួយនៅក្នុងបំពង់បង្ហូរប្រេង។
    type Source: Iterator;

    /// ទៅយកបំពង់បង្ហូរបម្រុងប្រភពមួយនេះ។
    ///
    /// # Safety
    ///
    /// ការប្រតិបត្តិនៃសេចក្តីយោងត្រូវតែវិលត្រឡប់មកវិញដូចគ្នាសម្រាប់ជីវិត mutable របស់ខ្លួន, លុះត្រាតែបានជំនួសដោយអ្នកទូរស័ព្ទចូល។
    /// អ្នកហៅទូរស័ព្ទចូលអាចជំនួសតែសេចក្តីយោងនៅពេលពួកគេបានបញ្ឈប់ការនិយាយឡើងវិញនិងទម្លាក់បំពង់បង្ហូរប្រេងបម្រុងបន្ទាប់ពីការទាញយកប្រភព។
    ///
    /// នេះមានន័យថា iterator អាដាប់ទ័រអាចពឹងផ្អែកលើប្រភពការផ្លាស់ប្តូរក្នុងអំឡុងពេលការនិយាយឡើងវិញមិនបានប៉ុន្តែពួកគេមិនអាចពឹងផ្អែកលើវានៅក្នុងប្រតិបត្តិការទម្លាក់របស់ពួកគេ។
    ///
    /// ការអនុវត្តវិធីសាស្ត្រនេះមានន័យថាអាដាប់ធ័របោះបង់ចោលការចូលប្រើប្រាស់ប្រភពឯកជនតែប៉ុណ្ណោះហើយអាចពឹងផ្អែកលើការធានាដែលធ្វើឡើងដោយផ្អែកលើប្រភេទអ្នកទទួលវិធីសាស្រ្តប៉ុណ្ណោះ។
    /// កង្វះនៃការចូលប្រើដែលបានដាក់កម្រិតក៏តម្រូវឱ្យអាដាប់ធ័រត្រូវតែគាំទ្រ API សាធារណៈរបស់ប្រភពទោះបីជាពួកគេមានសិទ្ធិចូលទៅខាងក្នុងរបស់វាក៏ដោយ។
    ///
    /// អ្នកទូរស័ព្ទចូលនៅក្នុងវេនត្រូវតែរំពឹងថានឹងប្រភពមាននៅក្នុងស្ថានភាពនោះគឺស្របជាមួយនឹងការ API សាធារណៈរបស់ខ្លួនចាប់តាំងពីអាដាប់ទ័រអង្គុយរវាងវានិងមានការចូលដំណើរការប្រភពដដែលនេះបានទេ។
    /// ជាពិសេសអាដាប់ធ័រមួយប្រហែលជាបានប្រើប្រាស់ធាតុច្រើនជាងចាំបាច់។
    ///
    /// គោលដៅរួមនៃតម្រូវការទាំងនេះគឺដើម្បីឱ្យអ្នកប្រើប្រាស់បំពង់បង្ហូរប្រេងប្រើប្រាស់
    /// * នៅសល់អ្វីដែលនៅក្នុងប្រភពបន្ទាប់ពីការនិយាយឡើងវិញបានបញ្ឈប់
    /// * អង្គចងចាំដែលបានក្លាយជាដែលមិនបានប្រើដោយការទៅមុខដែលជាកន្លែងបម្រុងប្រើប្រាស់
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// អាដាប់ធ័របម្រុងមួយដែលផលិតទិន្នផលដរាបណាមូលដ្ឋានបម្រុងផលិតតម្លៃ `Result::Ok` ។
///
///
/// ប្រសិនបើមានកំហុសត្រូវបានជួបប្រទះអ្នករំកិលឈប់ហើយកំហុសត្រូវបានរក្សាទុក។
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// ដំណើរការច្រំដែលដែលបានផ្តល់ឱ្យដូចជាប្រសិនបើវាជំរុញអោយ `T` ជំនួសឱ្យ `Result<T, _>` មួយ។
/// កំហុសណាមួយដែលនឹងបញ្ឈប់ការបម្រុងខាងក្នុងនិងលទ្ធផលរួមនឹងជាកំហុសមួយ។
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}