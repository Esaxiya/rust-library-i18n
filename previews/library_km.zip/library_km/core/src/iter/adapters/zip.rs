use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// បម្រុងមួយដែល iterates ការនិយាយឡើងវិញក្នុងពេលដំណាលគ្នាពីរនាក់ផ្សេងទៀត។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយ [`Iterator::zip`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // សន្ទស្សន៍, Len និង a_len ត្រូវបានប្រើតែដោយកំណែឯកទេសនៃការបង្ហាប់
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // សុវត្ថិភាព: `ZipImpl::__iterator_get_unchecked` មានសុវត្ថិភាពដូចគ្នា
        // តម្រូវការដែលជា `Iterator::__iterator_get_unchecked` ។
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// ឯកទេសហ្ស៊ីប trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // នេះមានតម្រូវការសុវត្ថិភាពដូចគ្នានឹង `Iterator::__iterator_get_unchecked`
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// impl ហ្ស៊ីបទូទៅ
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // លៃតម្រូវ a, b ទៅប្រវែងស្មើ
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // សុវត្ថិភាព: `i` មានទំហំតូចជាង `self.len`, ដូច្នេះតូចជាង `self.a.len()` និង `self.b.len()`
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // ផ្គូផ្គងសក្តានុពលផលប៉ះពាល់សុវត្ថិភាពមូលដ្ឋានបានអនុវត្តន៍: យើងគ្រាន់តែបានពិនិត្យថា `i` <`self.a.len()`
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // សុវត្ថិភាព: ការប្រើប្រាស់ `cmp::min` ដើម្បីគណនា `delta`
                // ធានាថា `end` តូចជាងឬស្មើ `self.len` ដូច្នេះ `i` ក៏តូចជាង `self.len` ដែរ។
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // សុវត្ថិភាព: ដូចគ្នានឹងខាងលើ។
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // លៃតម្រូវមួយខប្រវែងស្មើគ្នា, ធ្វើឱ្យប្រាកដថាមានតែការហៅជាលើកដំបូងនៃការ `next_back` ធ្វើនេះ, បើមិនដូច្នេះទេយើងនឹងបំបែកការដាក់កម្រិតលើការហៅទូរស័ព្ទទៅ `self.next_back()` បន្ទាប់ពីការហៅ `get_unchecked()` ។
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // សុវត្ថិភាព: `i` តូចជាងតម្លៃមុននៃ `self.len`,
            // ដែលតូចជាងឬស្មើ `self.a.len()` និង `self.b.len()`
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែគាំទ្រកិច្ចសន្យាសម្រាប់ `Iterator::__iterator_get_unchecked` នេះ។
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// ជ្រើសរើសផ្នែកខាងឆ្វេងនៃការបង្ហាប់បង្ហាប់ជា "source" ដែលអាចទាញយកបានវាទាមទារអោយមាន trait bounds អវិជ្ជមានដើម្បីអាចសាកល្បងទាំងពីរ
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // សុវត្ថិភាព: មុខងារមិនមានសុវត្ថិភាពបញ្ជូនបន្តទៅមុខងារគ្មានសុវត្ថិភាពដែលមានតំរូវការដូចគ្នា
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// មានកំណត់ចំពោះធាតុ៖ ចំលងតាំងពីអន្តរកម្មរវាងការប្រើប្រាស់ Zed របស់ TrustedRandomAccess និងការអនុវត្តន៍ការទម្លាក់ប្រភពគឺមិនច្បាស់។
//
// វិធីសាស្រ្តបន្ថែមត្រឡប់មកវិញចំនួនដងនៃប្រភពត្រូវបានជឿនលឿនឡូជីខល (ដោយគ្មានការហៅទូរស័ព្ទ next()) នឹងចាំបាច់ដើម្បីទម្លាក់ប្រភពដែលនៅសល់ឱ្យបានត្រឹមត្រូវ។
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // វាជាការមិនមានសុវត្ថិភាព * * ដើម្បីហៅទូរស័ព្ទទៅលើការនិយាយឡើងវិញដែលមាន FMT, ចាប់តាំងពីពេលដែលយើងចាប់ផ្តើម interact តពួកគេនៅក្នុងការចម្លែកមិនមានសុវត្ថិភាពមានសក្តានុពលរដ្ឋ។
        //
        f.debug_struct("Zip").finish()
    }
}

/// បម្រុងមួយដែលមានធាតុជាអាចចូលដំណើរការបានយ៉ាងមានប្រសិទ្ធិភាពចៃដន្យ-
///
/// # Safety
///
/// `size_hint` បម្រុងនេះត្រូវតែជាការពិតប្រាកដនិងមានតំលៃថោកដើម្បីហៅ។
///
/// `size` មិនអាចត្រូវបានបដិសេធ។
///
/// `<Self as Iterator>::__iterator_get_unchecked` ត្រូវតែមានសុវត្ថិភាពក្នុងការហៅទូរស័ព្ទប្រសិនបើមានលក្ខខណ្ឌដូចខាងក្រោម។
///
/// 1. `0 <= idx` និង `idx < self.size()` ។
/// 2. ប្រសិនបើមាន `self: !Clone` បន្ទាប់មក `get_unchecked` មិនត្រូវបានហៅជាមួយសន្ទស្សន៍ដូចគ្នានៅលើ `self` ច្រើនជាងមួយដង។
/// 3. បន្ទាប់ពី `self.get_unchecked(idx)` ត្រូវបានគេហៅថាបន្ទាប់មក `next_back` នឹងត្រូវបានហៅតែច្រើនដងបំផុត `self.size() - idx - 1` ប៉ុណ្ណោះ។
/// 4. បន្ទាប់ពី `get_unchecked` ត្រូវបានគេហៅថាបន្ទាប់មកមានតែវិធីសាស្ត្រដូចខាងក្រោមទេដែលនឹងត្រូវបានហៅនៅលើ `self`៖
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// លើសពីនេះទៀតផ្ដល់ឱ្យថាលក្ខខណ្ឌទាំងនេះត្រូវបានជួប, វាត្រូវតែធានាថា:
///
/// * វាមិនផ្លាស់ប្តូរតម្លៃដែលត្រឡប់មកពី `size_hint` ទេ
/// * វាត្រូវតែមានសុវត្ថិភាពក្នុងការហៅវិធីសាស្រ្តដែលបានរាយខាងលើនៅលើ `self` បន្ទាប់ពីការហៅ `get_unchecked`, សន្មតថា traits តម្រូវឱ្យត្រូវបានអនុវត្ត។
///
/// * វាត្រូវតែមានសុវត្ថិភាពក្នុងការធ្លាក់ចុះ `self` បន្ទាប់ពីការហៅ `get_unchecked` ។
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // វិធីសាស្រ្តងាយស្រួល។
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` ប្រសិនបើទទួលបានធាតុទ្រនាប់អាចមានផលប៉ះពាល់។
    /// ចងចាំថាត្រូវយកឧបករណ៍វាស់ខាងក្នុងចូលក្នុងគណនី។
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// ដូច `Iterator::__iterator_get_unchecked`, ប៉ុន្តែមិនតម្រូវឱ្យចងក្រងដើម្បីឱ្យដឹងថា `U: TrustedRandomAccess` ។
///
///
/// ## Safety
///
/// តម្រូវការដូចគ្នាហៅទូរស័ព្ទ `get_unchecked` ដោយផ្ទាល់។
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែគាំទ្រកិច្ចសន្យាសម្រាប់ `Iterator::__iterator_get_unchecked` នេះ។
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// ប្រសិនបើមាន `Self: TrustedRandomAccess`, វាត្រូវតែមានសុវត្ថិភាពក្នុងការហៅ `Iterator::__iterator_get_unchecked(self, index)` មួយ។
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែគាំទ្រកិច្ចសន្យាសម្រាប់ `Iterator::__iterator_get_unchecked` នេះ។
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}