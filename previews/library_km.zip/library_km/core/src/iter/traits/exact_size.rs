/// បម្រុងមួយដែលបានដឹងពីប្រវែងពិតប្រាកដរបស់ខ្លួន។
///
/// មនុស្សជាច្រើន [`អ្នកបកប្រែ] មិនដឹងថាតើវានឹងមានប៉ុន្មានដងទេប៉ុន្តែអ្នកខ្លះដឹង។
/// ប្រសិនបើការបម្រុងជាដឹងពីរបៀបជាច្រើនដងវាអាច iterate, ផ្តល់នូវការចូលដំណើរការទៅពដែលអាចមានប្រយោជន៍។
/// ឧទាហរណ៍ប្រសិនបើអ្នកចង់អន្តរកម្មថយក្រោយ, ការចាប់ផ្តើមល្អគឺដើម្បីដឹងថាកន្លែងដែលទីបញ្ចប់។
///
/// នៅពេលអនុវត្ត `ExactSizeIterator` អ្នកក៏ត្រូវអនុវត្ត [`Iterator`] ផងដែរ។
/// នៅពេលដែលការធ្វើដូច្នេះ, ការអនុវត្តន៍ [`Iterator::size_hint`] នេះ *ត្រូវតែ* ត្រឡប់ទំហំពិតប្រាកដនៃការនិយាយឡើងវិញ។
///
/// វិធីសាស្ត្រ [`len`] មានការអនុវត្តន៍តាមលំនាំដើមដូច្នេះអ្នកមិនគួរអនុវត្តវាទេ។
/// ទោះជាយ៉ាងណា, អ្នកប្រហែលជាអាចផ្ដល់នូវការអនុវត្តការសម្តែងច្រើនជាងលំនាំដើម, ដូច្នេះបដិសេធវានៅក្នុងករណីនេះធ្វើឱ្យយល់បាន។
///
///
/// ចំណាំថា trait នេះគឺជា trait មានសុវត្ថិភាពនិងជាបែបនេះ *មិនមែន* និង *មិនអាច* ធានាថាប្រវែងត្រឡប់មកវិញនេះគឺត្រឹមត្រូវ។
/// នេះមានន័យថាកូដ `unsafe`**មិនត្រូវ** ពឹងផ្អែកលើភាពត្រឹមត្រូវនៃ [`Iterator::size_hint`] នេះ។
/// នេះមិនស្ថិតស្ថេរនិងមិនមានសុវត្ថិភាព [`TrustedLen`](super::marker::TrustedLen) trait ផ្តល់នូវការធានាបន្ថែមទៀតនេះ។
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// // ជួរកំណត់មួយដែលដឹងច្បាស់អំពីរបៀបជាច្រើនដងវានឹង iterate
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// នៅក្នុង [module-level docs] យើងអនុវត្ត [`Iterator`], `Counter`.
/// សូមឱ្យយើងអនុវត្ត `ExactSizeIterator` សម្រាប់វាផងដែរ:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // យើងអាចគណនាបានយ៉ាងងាយស្រួលនៅសល់នៃការនិយាយឡើងវិញចំនួន។
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ហើយឥឡូវនេះយើងអាចប្រើវាបានហើយ!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// ត្រឡប់ប្រវែងពិតប្រាកដនៃការនិយាយឡើងវិញ។
    ///
    /// នេះធានាការអនុវត្តដែលបម្រុងនឹងវិលត្រឡប់មកវិញច្រើនជាងមួយដង `len()` តម្លៃ [`Some(T)`] ច្បាស់, មុនពេលវិលត្រឡប់ [`None`] ។
    ///
    /// វិធីសាស្រ្តនេះមានការអនុវត្តលំនាំដើម, ដូច្នេះអ្នកជាធម្មតាមិនគួរអនុវត្តវាដោយផ្ទាល់។
    /// ទោះយ៉ាងណាក៏ដោយប្រសិនបើអ្នកអាចផ្តល់នូវការអនុវត្តកាន់តែមានប្រសិទ្ធភាពអ្នកអាចធ្វើបាន។
    /// សូមមើលឯកសារ [trait-level] ឧទាហរណ៍មួយ។
    ///
    /// មុខងារនេះមានការធានាសុវត្ថិភាពដូចមុខងារ [`Iterator::size_hint`] ។
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // ជួរកំណត់មួយដែលដឹងច្បាស់អំពីរបៀបជាច្រើនដងវានឹង iterate
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ការអះអាងនេះគឺជាការការពារហួសហេតុពេកនោះទេប៉ុន្តែវាពិនិត្យមិនផ្លាស់ប្ដូរនេះ
        // ធានាដោយ trait ។
        // ប្រសិនបើមាន trait នេះជា rust-ផ្ទៃក្នុង, យើងអាចប្រើ debug_assert !;អះអាង!នឹងពិនិត្យមើលការប្រតិបត្តិរបស់អ្នកប្រើ Rust ទាំងអស់ផងដែរ។
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ត្រឡប់ `true` ប្រសិនបើការនិយាយឡើងវិញគឺទទេ។
    ///
    /// វិធីសាស្រ្តនេះមានការអនុវត្តតាមលំនាំដើមដោយប្រើ [`ExactSizeIterator::len()`] ដូច្នេះអ្នកមិនចាំបាច់អនុវត្តវាដោយខ្លួនឯងទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}