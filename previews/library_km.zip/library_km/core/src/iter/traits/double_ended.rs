use crate::ops::{ControlFlow, Try};

/// បម្រុងមួយដែលអាចផ្តល់ទិន្នផលបានមកពីចុងធាតុទាំងពីរ។
///
/// អ្វីមួយដែលអនុវត្ត `DoubleEndedIterator` មានសមត្ថភាពបន្ថែមទៀតនៅលើអ្វីមួយដែលអនុវត្ត [`Iterator`]: សមត្ថភាពផងដែរដើម្បីយក `Item`s ពីខាងក្រោយព្រមទាំងមុខ។
///
///
/// វាជាការសំខាន់ដើម្បីចំណាំថាទាំងពីរត្រឡប់មកវិញនិងការងារចេញនៅលើជួរដូចគ្នានេះដែរហើយធ្វើមិនបានឈើឆ្កាង: ការនិយាយឡើងវិញគឺមានជាងនៅពេលដែលពួកគេបានជួបប្រជុំគ្នានៅពាក់កណ្តាល។
///
/// ក្នុងរបៀបមួយស្រដៀងទៅពិធីការ [`Iterator`], នៅពេលដែល `DoubleEndedIterator` មួយត្រឡប់ [`None`] ពី [`next_back()`] មួយហៅវាថាជាថ្មីម្តងទៀតអាចឬមិនអាចមិនធ្លាប់ត្រឡប់ [`Some`] ម្តងទៀត។
/// [`next()`] និង [`next_back()`] អាចផ្លាស់ប្តូរបានសម្រាប់គោលបំណងនេះ។
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// យកជម្រើសចេញនិងត្រឡប់មកវិញធាតុពីចុងបញ្ចប់នៃការនិយាយឡើងវិញនេះ។
    ///
    /// ត្រឡប់ `None` នៅពេលដែលមិនមានធាតុបន្ថែមទៀត។
    ///
    /// ឯកសារ [trait-level] មានព័ត៌មានលំអិតបន្ថែម។
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// ធាតុបានស្នើដោយ: វិធីសាស្រ្ត DoubleEndedIterator`អាចខុសគ្នាពីអ្នកដែលបានស្នើឡើងដោយវិធីសាស្រ្ត [`Iterator`] 's:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// បុបម្រុងពីធាតុ `n` ដោយការត្រឡប់មកវិញនេះ។
    ///
    /// `advance_back_by` គឺជាកំណែបញ្ច្រាសនៃ [`advance_by`] ។វិធីសាស្រ្តនេះនឹងរំលងធាតុ `n` យ៉ាងអន្ទះអន្ទែងចាប់ផ្តើមពីខាងក្រោយដោយហៅទូរស័ព្ទ [`next_back`] រហូតដល់ `n` រហូតដល់ [`None`] ត្រូវបានជួប។
    ///
    /// `advance_back_by(n)` នឹងត្រឡប់ [`Ok(())`] ប្រសិនបើការនិយាយឡើងវិញបានដោយជោគជ័យដោយមានធាតុ `n` បុឬ [`Err(k)`] ប្រសិនបើ [`None`] ត្រូវបានជួបប្រទះ, ដែលជាកន្លែងដែល `k` គឺជាចំនួននៃធាតុបម្រុងនេះគឺមានកម្រិតខ្ពស់ដោយមុនពេលរត់ចេញពីធាតុ (ឧ
    /// ប្រវែងនៃការនិយាយ) ។
    /// ចំណាំថា `k` គឺតែងតែមានតិចជាង `n` ។
    ///
    /// ការហៅ `advance_back_by(0)` មិនប្រើប្រាស់ធាតុណាមួយហើយតែងតែត្រឡប់ [`Ok(())`] ។
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // តែ `&3` ត្រូវបានរំលង
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ត្រឡប់មកវិញ `ធាតុ n`th ពីចុងបញ្ចប់នៃការនិយាយឡើងវិញបាន។
    ///
    /// នេះគឺជាការសំខាន់ជាកំណែបញ្ច្រាសនៃ [`Iterator::nth()`] ។
    /// ទោះបីជាភាគច្រើនដូចប្រតិបត្ដិការបង្កើតលិបិក្រម, រាប់ចាប់ផ្តើមពីសូន្យ, ដូច្នេះ `nth_back(0)` ត្រឡប់តម្លៃដំបូងពីទីបញ្ចប់ `nth_back(1)` ទីពីរហើយដូច្នេះនៅលើ។
    ///
    ///
    /// ចំណាំថាធាតុទាំងអស់រវាងចុងនិងធាតុត្រឡប់មកវិញនឹងត្រូវបានប្រើប្រាស់, រួមទាំងធាតុបានត្រឡប់មកវិញនោះទេ។
    /// នេះជាមធ្យោបាយផងដែរថាការហៅទូរស័ព្ទ `nth_back(0)` ច្រើនដងនៅលើកន្លែងបម្រុងដូចគ្នានេះនឹងវិលត្រឡប់មកវិញធាតុផ្សេងគ្នា។
    ///
    /// `nth_back()` នឹងត្រឡប់ [`None`] ប្រសិនបើ `n` ធំជាងឬស្មើទៅនឹងប្រវែងនៃការនិយាយឡើងវិញបាន។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// ការហៅទូរស័ព្ទ `nth_back()` ច្រើនដងមិនរំកិលវាទេ៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// ការវិលត្រឡប់មក `None` ប្រសិនបើមានតិចជាងធាតុ `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// នេះគឺជាកំណែបញ្ច្រាសនៃ [`Iterator::try_fold()`]: វាត្រូវចំណាយពេលត្រឡប់មកវិញធាតុចាប់ផ្តើមពីការបម្រុងនេះ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ដោយសារតែវាខ្លី circuited ធាតុនៅសល់តែអាចប្រើបានតាមរយៈការនិយាយឡើងវិញ។
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// វិធីសាស្រ្តមួយដែលជួយកាត់បន្ថយការបម្រុងធាតុបម្រុងនេះដើម្បីតែមួយនោះតម្លៃចុងក្រោយ, ចាប់ផ្តើមពីក្រោយ។
    ///
    /// នេះគឺជាកំណែបញ្ច្រាសនៃ [`Iterator::fold()`]: វាត្រូវចំណាយពេលត្រឡប់មកវិញធាតុចាប់ផ្តើមពីការបម្រុងនេះ។
    ///
    /// `rfold()` ត្រូវការអាគុយម៉ង់ពីរ: តម្លៃដំបូងនិងការបិទដែលមានអាគុយម៉ង់ពីរ: 'accumulator' មួយ, និងធាតុមួយ។
    /// ការបិទនេះត្រឡប់តម្លៃដែល accumulator មួយនេះគួរតែមានសម្រាប់ការនិយាយឡើងវិញបន្ទាប់។
    ///
    /// តម្លៃដំបូងជាតម្លៃ accumulator មួយនេះនឹងមាននៅលើការហៅជាលើកដំបូង។
    ///
    /// បន្ទាប់ពីការដាក់ពាក្យសុំការបិទនេះទៅគ្រប់ធាតុនៃការនិយាយឡើងវិញ, `rfold()` ត្រឡប់ accumulator មួយនេះ។
    ///
    /// ប្រតិបត្ដិការនេះត្រូវបានគេហៅថាពេលខ្លះ 'reduce' ឬ 'inject' ។
    ///
    /// ការបត់គឺមានប្រយោជន៍នៅពេលអ្នកមានបណ្តុំរបស់អ្វីមួយហើយចង់បង្កើតតម្លៃតែមួយពីវា។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ផលបូកនៃគ្រប់ធាតុទាំងអស់នៃមួយ
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ឧទាហរណ៍នេះបង្កើតខ្សែអក្សរដោយចាប់ផ្តើមពីតម្លៃដំបូងនិងបន្តជាមួយធាតុនីមួយៗពីខាងក្រោយរហូតដល់ផ្នែកខាងមុខ៖
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// ស្វែងរកធាតុមួយនៃទ្រនាប់ពីខាងក្រោយដែលពេញចិត្តនឹងការប៉ាន់ស្មាន។
    ///
    /// `rfind()` យកការបិទដែលត្រឡប់ `true` ឬ `false` ។
    /// វាអនុវត្តការបិទនេះទៅធាតុនីមួយៗនៃឧបករណ៍ចាប់ផ្តើមនៅចុងបញ្ចប់ហើយប្រសិនបើមានណាមួយត្រឡប់មកវិញ `true` បន្ទាប់មក `rfind()` ត្រឡប់ [`Some(element)`] ។
    /// ប្រសិនបើពួកគេត្រឡប់មកវិញ `false` វាត្រលប់មកវិញ [`None`] ។
    ///
    /// `rfind()` គឺមានរយៈពេលខ្លី;នៅក្នុងពាក្យផ្សេងទៀត, វានឹងបញ្ឈប់ដំណើរការបានឆាប់ដូចជាការបិទនេះត្រឡប់ `true` ។
    ///
    /// ដោយសារតែ `rfind()` យកឯកសារយោងហើយអ្នកធ្វើវាច្រើនលើសេចក្តីយោងនេះនាំឱ្យមានស្ថានភាពច្របូកច្របល់ដែលអាគុយម៉ង់គឺជាសេចក្តីយោងទ្វេ។
    ///
    /// អ្នកអាចមើលឃើញឥទ្ធិពលនេះក្នុងឧទាហរណ៍ខាងក្រោមនេះដោយមាន `&&x` ។
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// ការបញ្ឈប់នៅ `true` ដំបូង:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // យើងនៅតែអាចប្រើ `iter` ដូចដែលមានធាតុច្រើនទៀត។
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}