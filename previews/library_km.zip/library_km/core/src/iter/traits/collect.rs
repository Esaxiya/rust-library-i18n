/// បម្លែងពី [`Iterator`] មួយ។
///
/// ដោយអនុវត្ត `FromIterator` សម្រាប់ប្រភេទជាអ្នកកំណត់របៀបដែលវានឹងត្រូវបានបង្កើតពីកន្លែងបម្រុងមួយ។
/// នេះគឺជារឿងធម្មតាសម្រាប់ប្រភេទដែលបានរៀបរាប់អំពីការប្រមូលផ្ដុំនៃប្រភេទមួយចំនួន។
///
/// [`FromIterator::from_iter()`] កម្រត្រូវបានហៅយ៉ាងច្បាស់ហើយត្រូវបានប្រើជំនួសវិធីសាស្ត្រ [`Iterator::collect()`] ។
///
/// សូមមើលឯកសារ [`Iterator::collect()`]'s សម្រាប់ឧទហរណ៍បន្ថែមទៀត។
///
/// សូមមើលផងដែរ: [`IntoIterator`].
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ការប្រើ [`Iterator::collect()`] ក្នុងការប្រើទាំងស្រុង `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// ការអនុវត្ត `FromIterator` សម្រាប់ប្រភេទរបស់អ្នក:
///
/// ```
/// use std::iter::FromIterator;
///
/// // ការប្រមូលគំរូ, នោះគ្រាន់តែជារុំលើវ៉េ<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ចូរផ្តល់វិធីសាស្រ្តខ្លះដល់យើងដូច្នេះយើងអាចបង្កើតវិធីមួយនិងបន្ថែមរបស់ផ្សេងៗ។
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ហើយយើងនឹងអនុវត្ត FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ឥឡូវនេះយើងអាចធ្វើឱ្យមានកន្លែងបម្រុងថ្មី ...
/// let iter = (0..5).into_iter();
///
/// // ... និងធ្វើឱ្យ MyCollection មួយចេញពីវា
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // ប្រមូលស្នាដៃផងដែរ!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// បង្កើតតម្លៃពីកន្លែងបម្រុងមួយ។
    ///
    /// មើល [module-level documentation] សម្រាប់ព័ត៌មានបន្ថែម។
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// ការបម្លែងទៅជា [`Iterator`] មួយ។
///
/// ដោយអនុវត្ត `IntoIterator` សម្រាប់ប្រភេទជាអ្នកកំណត់របៀបដែលវានឹងត្រូវបានបម្លែងទៅជាកន្លែងបម្រុងមួយ។
/// នេះគឺជារឿងធម្មតាសម្រាប់ប្រភេទដែលបានរៀបរាប់អំពីការប្រមូលផ្ដុំនៃប្រភេទមួយចំនួន។
///
/// ទទួលបានអត្ថប្រយោជន៍មួយនៃការអនុវត្ត `IntoIterator` គឺថាប្រភេទរបស់អ្នកនឹង [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) ។
///
///
/// សូមមើលផងដែរ: [`FromIterator`].
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// ការអនុវត្ត `IntoIterator` សម្រាប់ប្រភេទរបស់អ្នក:
///
/// ```
/// // ការប្រមូលគំរូ, នោះគ្រាន់តែជារុំលើវ៉េ<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ចូរផ្តល់វិធីសាស្រ្តខ្លះដល់យើងដូច្នេះយើងអាចបង្កើតវិធីមួយនិងបន្ថែមរបស់ផ្សេងៗ។
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ហើយយើងនឹងអនុវត្ត IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ឥឡូវនេះយើងអាចធ្វើឱ្យមានការប្រមូលថ្មី ...
/// let mut c = MyCollection::new();
///
/// // ... បន្ថែមវត្ថុមួយចំនួនទៅវា ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ហើយបន្ទាប់មកបានក្លាយ ... ទៅជាការនិយាយឡើងវិញជាមួយវា:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// វាជារឿងធម្មតាក្នុងការប្រើ `IntoIterator` ជាមួយ trait bound ។នេះអនុញ្ញាតឱ្យអ្នកបញ្ចូលប្រភេទការប្រមូលការផ្លាស់ប្តូរ, ដូច្នេះដរាបណាវានៅតែជាកន្លែងបម្រុងមួយ។
/// ព្រំដែនបន្ថែមអាចត្រូវបានបញ្ជាក់ដោយការរឹតបន្តឹង
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ប្រភេទនៃធាតុនេះត្រូវបាន iterated ជាង។
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ដែលប្រភេទនៃការបម្រុងបានជាយើងងាកនេះចូលទៅក្នុង?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// បង្កើតឧបករណ៍វាស់ស្ទង់ពីតម្លៃ។
    ///
    /// មើល [module-level documentation] សម្រាប់ព័ត៌មានបន្ថែម។
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// ពង្រីកការប្រមូលផ្ដុំមួយជាមួយនឹងមាតិការបស់បម្រុងមួយ។
///
/// ការនិយាយឡើងវិញផលិតស៊េរីនៃតម្លៃនិងការប្រមូលផងដែរត្រូវបានគេគិតថាជាស៊េរីនៃតម្លៃ។
/// នេះ `Extend` trait ផ្សារភ្ជាប់គម្លាតនេះអនុញ្ញាតឱ្យអ្នកដើម្បីពង្រីកការប្រមូលផ្ដុំមួយដោយរួមបញ្ចូលទាំងមាតិកានៃបម្រុងនោះ។
/// នៅពេលដែលពង្រីកការប្រមូលផ្តុំមួយជាមួយនឹងកូនសោដែលមានស្រាប់រួចទៅហើយ, ដែលត្រូវបានធ្វើឱ្យទាន់សម័យធាតុឬក្នុងករណីនៃការប្រមូលដែលអនុញ្ញាតឱ្យមានធាតុជាច្រើនជាមួយនឹងការគ្រាប់ចុចស្មើគ្នា, ដែលធាតុត្រូវបានបញ្ចូល។
///
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// // អ្នកអាចពង្រីកខ្សែអក្សរដែលមានតួអក្សរមួយចំនួន៖
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// អនុវត្ត `Extend`:
///
/// ```
/// // ការប្រមូលគំរូ, នោះគ្រាន់តែជារុំលើវ៉េ<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // ចូរផ្តល់វិធីសាស្រ្តខ្លះដល់យើងដូច្នេះយើងអាចបង្កើតវិធីមួយនិងបន្ថែមរបស់ផ្សេងៗ។
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ចាប់តាំងពីការ MyCollection មានបញ្ជីនៃ i32s មួយដែលយើងអនុវត្តពង្រីកសម្រាប់ i32
/// impl Extend<i32> for MyCollection {
///
///     // នេះគឺជាការងាយស្រួលបន្តិចជាមួយនឹងហត្ថលេខាប្រភេទបេតុង: យើងអាចហៅពង្រីកនៅលើអ្វីដែលអាចត្រូវបានប្រែក្លាយទៅជាការនិយាយឡើងវិញដែលបានផ្តល់ឱ្យយើងនូវ i32s មួយ។
///     // ដោយសារតែយើងត្រូវការ i32s ដាក់ចូលទៅក្នុង MyCollection ។
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // ការអនុវត្តនេះគឺជាការស្មុគស្មាញណាស់: រង្វិលជុំតាមរយៈការនិយាយឡើងវិញនិង add() ធាតុគ្នាដើម្បីខ្លួនយើង។
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // សូមពង្រីកការប្រមូលរបស់យើងជាមួយនឹងចំនួនបីបន្ថែមទៀត
/// c.extend(vec![1, 2, 3]);
///
/// // យើងបានបន្ថែមទៀតថាធាតុទាំងនេះទៅលើការបញ្ចប់
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ពង្រីកការប្រមូលផ្ដុំជាមួយនឹងមាតិការបស់អ្នកនិយាយ។
    ///
    /// នេះគឺជាវិធីសាស្ត្រដែលត្រូវការតែមួយគត់សម្រាប់ trait នេះឯកសារ [trait-level] មានព័ត៌មានលំអិតបន្ថែម។
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // អ្នកអាចពង្រីកខ្សែអក្សរដែលមានតួអក្សរមួយចំនួន៖
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// ពង្រីកបណ្តុំដែលមានធាតុតែមួយ។
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// សមត្ថភាពទុនបម្រុងនៅក្នុងសម្រាំងសម្រាប់ចំនួននៃធាតុបន្ថែមទៀត។
    ///
    /// ការអនុវត្តលំនាំដើមមិនមានអ្វីកើតឡើងទេ។
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}