// មិនអើពើ-តូច-filelength ឯកសារនេះស្ទើរតែទាំងស្រុងមាននិយមន័យនៃ `Iterator` នេះ។
// យើងមិនអាចបំបែកចូលទៅក្នុងឯកសារជាច្រើន។
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ចំណុចប្រទាក់សម្រាប់ដោះស្រាយជាមួយឧបករណ៍វាស់។
///
/// នេះគឺជាកន្លែងបម្រុង trait សំខាន់។
/// ចំពោះបន្ថែមអំពីគោលគំនិតនៃការនិយាយឡើងវិញជាទូទៅ, សូមមើល [module-level documentation] នេះ។
/// ជាពិសេសអ្នកអាចនឹងចង់ដឹងអំពីរបៀប [implement `Iterator`][impl] ។
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ប្រភេទនៃធាតុនេះត្រូវបាន iterated ជាង។
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// បុបម្រុងហើយត្រឡប់តម្លៃបន្ទាប់។
    ///
    /// ត្រឡប់ [`None`] នៅពេលការនិយាយឡើងវិញត្រូវបានបញ្ចប់។
    /// ការអនុវត្តបុគ្គលម្នាក់ៗអាចជ្រើសរើសដើម្បីបង្កើតឡើងវិញហើយដូច្នេះការហៅទូរស័ព្ទ `next()` ម្តងទៀតអាចនឹងមិនចាប់ផ្តើមវិលត្រឡប់មកវិញ [`Some(Item)`] ម្តងទៀតនៅចំណុចខ្លះ។
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ការហៅទៅ next() ត្រឡប់តម្លៃបន្ទាប់ ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... ហើយបន្ទាប់មកគ្មាននរណាម្នាក់នៅពេលដែលវាត្រូវបានបញ្ចប់។
    /// assert_eq!(None, iter.next());
    ///
    /// // ការហៅទូរស័ព្ទជាច្រើនទៀតអាចឬមិនអាចវិលត្រឡប់មកវិញ `None` ។នៅទីនេះពួកគេតែងតែនឹង។
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ត្រឡប់ព្រំដែននៅលើប្រវែងនៃការនិយាយឡើងវិញដែលនៅសេសសល់។
    ///
    /// ជាពិសេស `size_hint()` ត្រឡប់ tuple ដែលជាកន្លែងដែលធាតុដំបូងគឺការចងទាបនិងធាតុទីពីរគឺការចងខាងលើ។
    ///
    /// ពាក់កណ្តាលទីពីរនៃ tuple ដែលត្រូវបានត្រឡប់មកវិញគឺជា [`ជម្រើស`] `<` [`ប្រើប្រាស់`] `>` ។
    /// ការ [`None`] មធ្យោបាយមួយដែលមានត្រូវបានគេស្គាល់ទាំងគ្មាននៅទីនេះព្រំដែនខាងលើឬចងខាងលើគឺមានទំហំធំជាង [`usize`] ។
    ///
    /// # កំណត់ចំណាំអនុវត្តន៍
    ///
    /// វាមិនត្រូវបានអនុវត្តដែលថាទិន្នផលអនុវត្តបម្រុងមួយចំនួនបានប្រកាសនៃការធាតុ។ការ buggy ការនិយាយឡើងវិញអាចនឹងបានផលតិចជាងឬច្រើនជាងចងទាបជាងផ្នែកខាងលើនៃធាតុចង។
    ///
    /// `size_hint()` ត្រូវបានបម្រុងទុកជាចម្បងដើម្បីប្រើសម្រាប់ការបង្កើនប្រសិទ្ធិភាពត្រូវដូចជាការរក្សាទុកកន្លែងសម្រាប់ធាតុនៃការនិយាយឡើងវិញនោះទេប៉ុន្តែមិនត្រូវទុកចិត្តដើម្បីឧ, ការត្រួតពិនិត្យព្រំដែនលុបនៅក្នុងកូដគ្មានសុវត្ថិភាព។
    /// ជាការអនុវត្តន៍មិនត្រឹមត្រូវនៃ `size_hint()` មិនគួរនាំឱ្យមានការរំលោភសុវត្ថិភាពចងចាំ។
    ///
    /// ដែលបាននិយាយថាការអនុវត្តគួរតែផ្តល់នូវការប៉ាន់ស្មានត្រឹមត្រូវពីព្រោះបើមិនដូច្នេះទេវានឹងមានការរំលោភលើពិធីសាររបស់ trait ។
    ///
    /// ការអនុវត្តន៍លំនាំដើមត្រឡប់ `(0,` [`គ្មាន`] `)` ដែលត្រឹមត្រូវសម្រាប់អ្នកធ្វើវា។
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// ឧទាហរណ៍ស្មុគស្មាញ៖
    ///
    /// ```
    /// // លេខសូន្យដល់សូម្បីតែមកពីចំនួនដប់។
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // យើងអាចដូចគ្នាពីសូន្យទៅដប់ដង។
    /// // ដឹងថាវាប្រាំយ៉ាងពិតប្រាកដនឹងមិនអាចទៅរួចទេបើមិនប្រើ filter() ។
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // តោះបន្ថែមលេខប្រាំនាក់បន្ថែមទៀតជាមួយ chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ឥឡូវព្រំដែនទាំងពីរត្រូវបានកើនឡើងចំនួនប្រាំ
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// ត្រឡប់ `None` សម្រាប់ការភ្ជាប់ខាងលើ៖
    ///
    /// ```
    /// // មួយគ្មានព្រំដែន iterator ទៅខាងលើនិងចងទេដែលអាចធ្វើបានចងអតិបរមាទាបជាង
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// ប្រើប្រាស់បម្រុង, ការរាប់ចំនួននៃការនិយាយឡើងវិញនិងការវិលត្រឡប់មកវិញវា។
    ///
    /// វិធីសាស្រ្តនេះនឹងហៅម្តងហើយម្តងទៀតរហូតដល់ [`None`] [`next`] ត្រូវបានជួបប្រទះ, ការវិលត្រឡប់ចំនួនដងដែលវាបានឃើញ [`Some`] នេះ។
    /// ចំណាំថា [`next`] បានឱ្យគេហៅយ៉ាងហោចណាស់ម្តងបើទោះបីជាការនិយាយឡើងវិញមិនមានធាតុណាមួយឡើយ។
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ឥរិយាបថលើសចំណុះ
    ///
    /// វិធីសាស្រ្តនេះមិនការពារប្រឆាំងនឹងការហូរហៀរទេដូច្នេះការរាប់ធាតុរបស់វា៉ដែលមានច្រើនជាង [`usize::MAX`] អាចបង្កើតលទ្ធផលខុសឬ panics ។
    ///
    /// ប្រសិនបើមានការអះអាងបំបាត់កំហុសត្រូវបានអនុញ្ញាត panic មួយដែលត្រូវបានធានា។
    ///
    /// # Panics
    ///
    /// កម្លាំងមុខងារនេះ panic ប្រសិនបើការនិយាយឡើងវិញមានច្រើនជាងធាតុ [`usize::MAX`] ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// ប្រើប្រាស់បម្រុង, ការវិលត្រឡប់ធាតុចុងក្រោយ។
    ///
    /// វិធីសាស្រ្តនេះនឹងវាយតម្លៃឧបករណ៍ដដែលរហូតដល់វាត្រឡប់មកវិញ [`None`] ។
    /// ខណៈពេលដែលការធ្វើដូច្នេះវារក្សាដាននៃធាតុបច្ចុប្បន្ន។
    /// បន្ទាប់ពី [`None`] ត្រូវបានត្រឡប់មកវិញ `last()` បន្ទាប់មកនឹងត្រឡប់ធាតុចុងក្រោយដែលវាបានឃើញ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// បុ iterator ទៅដោយធាតុ `n` នេះ។
    ///
    /// វិធីសាស្រ្តនេះនឹងអន្ទះសារំលងធាតុ `n` ដោយការហៅទូរស័ព្ទឡើង [`next`] ទៅនឹងដង `n` រហូតដល់ [`None`] ត្រូវបានជួបប្រទះ។
    ///
    /// `advance_by(n)` នឹងត្រឡប់ [`Ok(())`][Ok] ប្រសិនបើការនិយាយឡើងវិញបានដោយជោគជ័យដោយមានធាតុ `n` បុឬ [`Err(k)`][Err] ប្រសិនបើ [`None`] ត្រូវបានជួបប្រទះ, ដែលជាកន្លែងដែល `k` គឺជាចំនួននៃធាតុបម្រុងនេះគឺមានកម្រិតខ្ពស់ដោយមុនពេលរត់ចេញពីធាតុ (ឧ
    /// ប្រវែងនៃការនិយាយ) ។
    /// ចំណាំថា `k` គឺតែងតែមានតិចជាង `n` ។
    ///
    /// ការហៅ `advance_by(0)` មិនប្រើប្រាស់ធាតុណាមួយទេហើយតែងតែត្រឡប់ [`Ok(())`][Ok] ។
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // តែ `&4` ត្រូវបានរំលង
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ត្រឡប់ធាតុ `ទី` របស់វា។
    ///
    /// ដូចប្រតិបត្តិការលិបិក្រមភាគច្រើនការរាប់ចាប់ផ្តើមពីសូន្យដូច្នេះ `nth(0)` ត្រឡប់តម្លៃទីមួយ `nth(1)` ទីពីរនិងបន្តបន្ទាប់។
    ///
    /// ចំណាំថាធាតុមុនទាំងអស់ព្រមទាំងធាតុបានត្រឡប់មកវិញនោះនឹងត្រូវបានប្រើប្រាស់ពីការនិយាយឡើងវិញ។
    /// មានន័យថាថាធាតុមុននឹងត្រូវបានបោះចោលនិងបានអំពាវនាវផងដែរថាច្រើនដងនៅលើ `nth(0)` ដូចគ្នានឹងបម្រុងត្រឡប់ធាតុផ្សេងគ្នា។
    ///
    ///
    /// `nth()` នឹងត្រឡប់ [`None`] ប្រសិនបើ `n` ធំជាងឬស្មើទៅនឹងប្រវែងនៃការនិយាយឡើងវិញបាន។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// ការហៅ `nth()` ច្រើនដងមិនខា iterator ទៅនេះ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// ការវិលត្រឡប់មក `None` ប្រសិនបើមានតិចជាងធាតុ `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// បង្កើតបម្រុងចាប់ផ្ដើមនៅចំណុចដូចគ្នាប៉ុន្តែការបោះជំហានទៅមុខតាមចំនួនដែលផ្ដល់នៅការនិយាយឡើងវិញជារៀងរាល់មួយ។
    ///
    /// ចំណាំ 1: ធាតុដំបូងនៃការនិយាយឡើងវិញនឹងតែងតែត្រូវបានត្រឡប់មកវិញដោយមិនគិតពីជំហានដែលបានផ្ដល់ឱ្យ។
    ///
    /// ចំណាំ 2: ពេលវេលាដែលធាតុមិនអើពើត្រូវបានទាញមិនត្រូវបានជួសជុលនេះ។
    /// `StepBy` ឥរិយាបទដូចលំដាប់ `next(), nth(step-1), nth(step-1),…` នោះទេប៉ុន្តែគឺជាការឥតគិតថ្លៃដើម្បីមានឥរិយាបទដូចលំដាប់
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// វិធីណាដែលត្រូវបានប្រើអាចផ្លាស់ប្តូរសម្រាប់ឧបករណ៍វាស់ស្ទង់ខ្លះសម្រាប់ហេតុផលនៃការអនុវត្ត។
    /// វិធីទី ២ នឹងជម្រុញ ឲ្យ អ្នកដំឡើងមុននិងអាចប្រើប្រាស់របស់របរច្រើនទៀត។
    ///
    /// `advance_n_and_return_first` គឺស្មើនឹង
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// វិធីសាស្រ្តនឹង panic ប្រសិនបើជំហានដែលបានផ្តល់គឺ `0` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// ត្រូវចំណាយពេលនិយាយឡើងវិញពីរនិងបង្កើតកន្លែងបម្រុងថ្មីទាំងនៅក្នុងលំដាប់។
    ///
    /// `chain()` នឹងត្រឡប់ឧបករណ៍វាស់ស្ទង់ថ្មីមួយដែលដំបូងនឹងវាយតម្លៃពីអ្នកធ្វើដំបូងហើយបន្ទាប់មកលើតម្លៃពីអ្នកលើកទីពីរ។
    ///
    /// នៅក្នុងពាក្យផ្សេងទៀត, វាភ្ជាប់ការនិយាយឡើងវិញពីររួមគ្នានៅក្នុងខ្សែសង្វាក់មួយ។🔗
    ///
    /// [`once`] ត្រូវបានប្រើជាទូទៅដើម្បីសម្របតម្លៃតែមួយទៅជាខ្សែសង្វាក់នៃការនិយាយឡើងវិញ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ចាប់តាំងពីអាគុយម៉ង់ទៅ `chain()` ប្រើ [`IntoIterator`] យើងអាចហុចអ្វីដែលអាចប្តូរទៅជា [`Iterator`] មិនមែនគ្រាន់តែ [`Iterator`] ខ្លួនវាទេ។
    /// ឧទាហរណ៍ slices (`&[T]`) អនុវត្ត [`IntoIterator`], ហើយដូច្នេះអាចត្រូវបានបញ្ជូនទៅ `chain()` ដោយផ្ទាល់:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ប្រសិនបើអ្នកធ្វើការជាមួយ Windows API, អ្នកប្រហែលជាចង់ផ្លាស់ [`OsStr`] ទៅ `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// "លេខកូដប្រៃសណីយ៍ឡើង 'ការនិយាយឡើងវិញពីរចូលទៅបម្រុងតែមួយនៃគូ។
    ///
    /// `zip()` ត្រឡប់មកវិញជាថ្មីដែលនឹងបម្រុង iterative ផ្សេងទៀតនៅលើដូចគ្នាពីរនាក់បានវិលត្រឡប់មក tuple មួយដែលជាធាតុដំបូងមកពីការនិយាយឡើងវិញជាលើកដំបូងហើយដែលជាធាតុទីពីរមកពីការនិយាយឡើងវិញជាលើកទីពីរ។
    ///
    ///
    /// និយាយម៉្យាងទៀតវារំកិលទ្រនាប់ទ្រនាប់ពីរបញ្ចូលគ្នាតែមួយទៅក្នុងតែមួយ។
    ///
    /// ប្រសិនបើអ្នកធ្វើវាត្រឡប់ [`None`], [`next`] ពីអ្នកតាក់តែង zipped នឹងត្រឡប់ [`None`] ។
    /// ប្រសិនបើមានការនិយាយឡើងវិញជាលើកដំបូងត្រឡប់ [`None`], `zip` នឹងសៀគ្វីខ្លីនិង `next` នឹងមិនត្រូវបានហៅនៅលើបម្រុងទីពីរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ចាប់តាំងពីការអាគុយម៉ង់ដើម្បី `zip()` ប្រើ [`IntoIterator`] យើងអាចហុចអ្វីដែលអាចត្រូវបានបម្លែងទៅជា [`Iterator`] មួយមិនមែនគ្រាន់តែ [`Iterator`] ខ្លួនវាមួយ។
    /// ឧទាហរណ៍ចំណិត (`&[T]`) អនុវត្ត [`IntoIterator`] ហើយដូច្នេះអាចត្រូវបានបញ្ជូនទៅ `zip()` ដោយផ្ទាល់:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ជាញឹកញាប់ត្រូវបានប្រើដើម្បីបង្ហាប់អ្នកបង្ហាប់គ្មានកំណត់ទៅជាអ្នកកំណត់។
    /// វាអាចដំណើរការបានព្រោះទីបំផុតឧបករណ៍វាស់ចរន្តនឹងត្រឡប់ [`None`] បញ្ចប់ខ្សែរ៉ូត។កំពុងបង្រួមជាមួយ `(0..)` អាចមើលច្រើនដូច [`enumerate`] មួយ:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// បង្កើតថ្មីដែលបានដាក់បម្រុងនៃ `separator` មួយច្បាប់ចម្លងរវាងធាតុដែលនៅជិតនៃការបម្រុងដើម។
    ///
    /// ក្នុងករណី `separator` មិនអនុវត្ត [`Clone`] ឬតម្រូវការដើម្បីត្រូវបានគណនារាល់ពេលដែលប្រើ [`intersperse_with`] ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // ធាតុដំបូងពី `a` ។
    /// assert_eq!(a.next(), Some(&100)); // អ្នកបំបែក។
    /// assert_eq!(a.next(), Some(&1));   // នេះជាធាតុបន្ទាប់ពីការ `a` ។
    /// assert_eq!(a.next(), Some(&100)); // អ្នកបំបែក។
    /// assert_eq!(a.next(), Some(&2));   // នេះកាលពី `a` ធាតុ។
    /// assert_eq!(a.next(), None);       // ការនិយាយឡើងវិញបានបញ្ចប់។
    /// ```
    ///
    /// `intersperse` អាចមានប្រយោជន៍ខ្លាំងណាស់ក្នុងការចូលរួមរបស់ធាតុបម្រុងធាតុទូទៅប្រើ:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// បង្កើតបម្រុងធាតុថ្មីដែលដាក់បានបង្កើតដោយ `separator` រវាងធាតុដែលនៅជិតនៃការបម្រុងដើម។
    ///
    /// ការបិទនឹងត្រូវបានគេហៅយ៉ាងច្បាស់រាល់ពេលដែលវត្ថុមួយត្រូវបានដាក់នៅចន្លោះធាតុពីរដែលនៅជាប់គ្នាពីឧបករណ៍វាស់មូលដ្ឋាន។
    /// ជាពិសេសការបិទមិនត្រូវបានគេហៅថាប្រសិនបើទ្រនាប់ទ្រទ្រង់ផ្តល់ទិន្នផលតិចជាងពីរហើយបន្ទាប់ពីធាតុចុងក្រោយត្រូវបានផ្តល់ជូន។
    ///
    ///
    /// ប្រសិនបើធាតុរបស់អ្នកធ្វើត្រាប់តាម [`Clone`] វាអាចប្រើ [`intersperse`] ងាយស្រួលជាង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // ធាតុដំបូងពី `v` ។
    /// assert_eq!(it.next(), Some(NotClone(99))); // អ្នកបំបែក។
    /// assert_eq!(it.next(), Some(NotClone(1)));  // ធាតុបន្ទាប់ពី `v` ។
    /// assert_eq!(it.next(), Some(NotClone(99))); // អ្នកបំបែក។
    /// assert_eq!(it.next(), Some(NotClone(2)));  // ធាតុចុងក្រោយពី `v` ។
    /// assert_eq!(it.next(), None);               // ការនិយាយឡើងវិញបានបញ្ចប់។
    /// ```
    ///
    /// `intersperse_with` អាចត្រូវបានប្រើនៅក្នុងស្ថានភាពដែលជាកន្លែងដែលសញ្ញាបំបែកដែលត្រូវការឱ្យត្រូវបានគណនា:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // ការបិទ mutably ខ្ចីបរិបទរបស់វាដើម្បីបង្កើតធាតុ។
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// ចំណាយពេលបិទនិងបង្កើតការហៅបិទដែលបម្រុងនៅលើធាតុគ្នានោះ។
    ///
    /// `map()` បំលែងបម្រុងមួយទៅមួយផ្សេងទៀតដោយមធ្យោបាយនៃអាគុយម៉ង់របស់វា:
    /// អ្វីដែលបានអនុវត្ត [`FnMut`] ។វាផលិតបម្រុងថ្មីដែលបានអំពាវនាវឱ្យបិទនៅលើធាតុនីមួយនៃការនិយាយឡើងវិញដើមនេះ។
    ///
    /// ប្រសិនបើអ្នកពូកែគិតតាមប្រភេទអ្នកអាចគិតពី `map()` ដូចនេះ៖
    /// ប្រសិនបើអ្នកមានកន្លែងបម្រុងដែលផ្ដល់ឱ្យអ្នកធាតុនៃប្រភេទមួយចំនួន `A` ហើយអ្នកចង់បម្រុងនៃប្រភេទមួយចំនួនផ្សេងទៀត `B` អ្នកអាចប្រើ `map()` ឆ្លងកាត់ការបិទដែលត្រូវចំណាយពេល `A` មួយនិងត្រឡប់ `B` មួយ។
    ///
    ///
    /// `map()` គឺប្រហាក់ប្រហែលនឹងរង្វិលជុំ [`for`] ។ទោះយ៉ាងណាក៏ដោយដោយសារ `map()` ខ្ជិលវាត្រូវបានគេប្រើបានល្អបំផុតនៅពេលអ្នកកំពុងធ្វើការជាមួយអ្នកប្រើផ្សេងទៀត។
    /// ប្រសិនបើអ្នកកំពុងធ្វើការតម្រៀបនៃ looping សម្រាប់ផលប៉ះពាល់មួយចំនួន, វាត្រូវបានគេចាត់ទុកថាជា idiomatic បន្ថែមទៀតដើម្បីប្រើ [`for`] ជាង `map()` ។
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ប្រសិនបើអ្នកកំពុងធ្វើការតម្រៀបនៃផលប៉ះពាល់មួយចំនួនចូលចិត្ត [`for`] ទៅ `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // កុំធ្វើដូចនេះ៖
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // វានឹងមិនប្រតិបត្តិដូចដែលវាគឺជាការខ្ជិល។Rust នឹងព្រមានអ្នកអំពីរឿងនេះ។
    ///
    /// // ផ្ទុយទៅវិញប្រើសម្រាប់:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// ហៅការបិទនៅលើធាតុនីមួយៗនៃឧបករណ៍វាស់ស្ទង់។
    ///
    /// នេះគឺស្មើនឹងប្រើរង្វិលជុំ [`for`] នៅលើការនិយាយឡើងវិញបើទោះជា `break` និង `continue` គឺមិនអាចធ្វើបានពីបិទមួយ។
    /// ជាទូទៅវាកាន់តែអសមត្ថភាពក្នុងការប្រើរង្វិលជុំ `for` ប៉ុន្តែ `for_each` អាចមើលឃើញកាន់តែច្បាស់នៅពេលដំណើរការធាតុនៅចុងបញ្ចប់នៃច្រវាក់ទ្រនាប់វែង។
    ///
    /// ក្នុងករណីខ្លះ `for_each` ក៏អាចលឿនជាងរង្វិលជុំដែរព្រោះវានឹងប្រើការនិយាយឡើងវិញនៅលើអាដាប់ទ័រដូចជា `Chain` ។
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// សម្រាប់ឧទាហរណ៍តូចមួយដែលជា `for` រង្វិលជុំអាចនឹងស្អាត, ប៉ុន្តែ `for_each` ចូលចិត្តអាចនឹងមានមុខងារដើម្បីរក្សារចនាប័ទ្មមួយជាមួយនឹងការនិយាយឡើងវិញទៀតហើយ:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// បង្កើតបម្រុងដែលប្រើបិទមួយដើម្បីកំណត់ថាតើធាតុមួយគួរតែត្រូវបានជំរុញអោយមានមួយ។
    ///
    /// ដែលបានផ្ដល់ឱ្យធាតុបិទនេះត្រូវតែវិលត្រឡប់មកវិញ `true` ឬ `false` មួយ។បានត្រឡប់បម្រុងនឹងទទួលបានតែធាតុដែលបិទត្រឡប់ពិត។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ដោយសារតែការបិទជិតដល់ `filter()` ត្រូវការអំណះអំណាងហើយអ្នកឆ្លើយឆ្លងជាច្រើននិយាយអំពីឯកសារយោងនេះនាំឱ្យមានស្ថានភាពច្របូកច្របល់ដែលប្រភេទនៃការបិទនេះជាសេចក្តីយោងទ្វេរដង៖
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // តម្រូវការពីរ * s បាន!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// វាជារឿងធម្មតាទៅជាការជំនួសឱ្យការប្រើ destructuring នៅលើអាគុយម៉ង់ដើម្បីដកហូតឆ្ងាយមួយ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // ទាំងពីរ&និង *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ឬទាំងពីរ:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // ពីរ &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// នៃស្រទាប់ទាំងនេះ។
    ///
    /// ចំណាំថា `iter.filter(f).next()` គឺស្មើនឹង `iter.find(f)` ។
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// បង្កើតឧបករណ៍វាស់ស្ទង់ដែលមានទាំងតម្រងនិងផែនទី។
    ///
    /// បានត្រឡប់ទិន្នផលតែមួយគត់ដែលបានបម្រុង `value` ដែលបិទការផ្គត់ផ្គង់ត្រឡប់ `Some(value)` ។
    ///
    /// `filter_map` អាចត្រូវបានប្រើដើម្បីធ្វើឱ្យច្រវាក់នៃ [`filter`] និង [`map`] សង្ខេបបន្ថែមទៀត។
    /// ឧទាហរណ៍ខាងក្រោមបង្ហាញពីរបៀប `map().filter().map()` មួយដែលអាចត្រូវបានខ្លីទៅជាការហៅមួយដើម្បី `filter_map` ។
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// នេះជាគំរូដូចគ្នានេះដែរប៉ុន្តែជាមួយនឹងការ [`filter`] និង [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// បង្កើតបម្រុងដែលបានផ្តល់ការរាប់ការនិយាយឡើងវិញបច្ចុប្បន្នព្រមទាំងតម្លៃបន្ទាប់មួយ។
    ///
    /// បម្រុងទិន្នផលត្រឡប់មកវិញគូ `(i, val)`, ដែលជាកន្លែងដែល `i` គឺជាសន្ទស្សន៍នៃការនិយាយឡើងវិញហើយនាពេលបច្ចុប្បន្ននេះគឺមានតម្លៃ `val` ត្រឡប់ដោយបម្រុងនេះបាន។
    ///
    ///
    /// `enumerate()` រក្សាចំនួនរបស់ខ្លួនជា [`usize`] មួយ។
    /// ប្រសិនបើអ្នកចង់ធ្វើការរាប់ចំនួនគត់ដោយមានទំហំផ្សេងគ្នា, មុខងារ [`zip`] ផ្តល់នូវមុខងារស្រដៀងគ្នា។
    ///
    /// # ឥរិយាបថលើសចំណុះ
    ///
    /// វិធីសាស្រ្តនេះបានធ្វើមិនមានការប្រុងប្រយ័ត្ននឹងការលើសចំណុះ, ដូច្នេះ enumerating ច្រើនជាងធាតុ [`usize::MAX`] ទាំងផលិតលទ្ធផលខុសឬ panics ។
    /// ប្រសិនបើមានការអះអាងបំបាត់កំហុសត្រូវបានអនុញ្ញាត panic មួយដែលត្រូវបានធានា។
    ///
    /// # Panics
    ///
    /// បានត្រឡប់បម្រុងអាច panic ប្រសិនបើសន្ទស្សន៍ដែលត្រូវបានត្រឡប់មកវិញនឹងហូរ [`usize`] មួយ។
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// បង្កើតឧបករណ៍វាស់ស្ទង់ដែលអាចប្រើ [`peek`] ដើម្បីរកមើលធាតុបន្ទាប់របស់វាដោយមិនប្រើវា។
    ///
    /// បន្ថែមវិធីសាស្រ្ត [`peek`] ការអះអាងជាថ្មីមួយ។សូមមើលឯកសាររបស់វាចំពោះបន្ថែម។
    ///
    /// ចំណាំថាមូលដ្ឋានបម្រុងគឺត្រូវបានកើនឡើងនៅតែត្រូវបានគេហៅថាពេល [`peek`] ជាលើកដំបូង: នៅក្នុងគោលបំណងដើម្បីយកធាតុបន្ទាប់ [`next`] ត្រូវបានគេហៅថានៅលើមូលដ្ឋានបម្រុងហេតុផលប៉ះពាល់ណាមួយ (ឧ
    ///
    /// អ្វីផ្សេងទៀតក្រៅពីការទាញយកតម្លៃបន្ទាប់) នៃវិធីសាស្ត្រ [`next`] នឹងកើតឡើង។
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() អនុញ្ញាតឱ្យយើងមើលឃើញចូលទៅក្នុង future នេះ
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // យើងអាច peek() ច្រើនដង, ការនិយាយឡើងវិញនឹងមិនជាមុន
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // បន្ទាប់ពីត្រូវបានបញ្ចប់ដោយសារឡើងវិញដូច្នេះគឺ peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// បង្កើតឧបករណ៍រំកិលមួយដែល [`រំលង`] របស់ធាតុដែលផ្អែកលើការទស្សន៍ទាយ។
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` យកការបិទជាអាគុយម៉ង់មួយ។វានឹងហៅការបិទនេះនៅលើធាតុនីមួយនៃការនិយាយឡើងវិញនិងការមិនអើពើធាតុរហូតដល់វាត្រឡប់ `false` ។
    ///
    /// បន្ទាប់ពី `false` ត្រូវបានត្រឡប់ការងារ `skip_while()`'s គឺមានជាង, និងនៅសល់នៃធាតុនេះត្រូវបានគេជំរុញអោយ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ដោយសារតែការបិទនេះបានកន្លងផុតទៅ `skip_while()` ចំណាយពេលយោងមួយ, និងការនិយាយឡើងវិញជាច្រើន iterate លើសេចក្តីយោង, នាំទៅជាស្ថានភាពនេះអាចធ្វើទៅបានយល់ច្រឡំ, ដែលជាកន្លែងដែលប្រភេទនៃអាគុយម៉ង់ការបិទនេះគឺជាសេចក្ដីយោងពីរដង:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // តម្រូវការពីរ * s បាន!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// បញ្ឈប់បន្ទាប់ពីការ `false` ដំបូង:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ខណៈពេលនេះនឹងត្រូវបានមិនពិត, ចាប់តាំងពីយើងបានទទួលរួចទៅហើយដែលមិនពិត, skip_while() មិនត្រូវបានប្រើណាមួយបន្ថែមទៀត
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// បង្កើត iterator ថាធាតុទិន្នផលដោយផ្អែកលើការព្យាករណ៍មួយ។
    ///
    /// `take_while()` ចំណាយពេលបិទជាអាគុយម៉ង់មួយ។វានឹងហៅការបិទនេះនៅលើធាតុនីមួយនៃការបម្រុងនិងបានផលធាតុខណៈពេលដែលវាត្រឡប់ `true` ។
    ///
    /// បន្ទាប់ពី `false` ត្រូវបានត្រឡប់ការងារ `take_while()`'s គឺមានជាង, និងនៅសល់នៃធាតុត្រូវបានមិនអើពើ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ដោយសារតែការបិទជិតដល់ `take_while()` ត្រូវការអំណះអំណាងហើយអ្នកឆ្លើយឆ្លងជាច្រើននិយាយអំពីឯកសារយោងនេះនាំឱ្យមានស្ថានភាពច្របូកច្របល់ដែលប្រភេទនៃការបិទនេះជាឯកសារយោងទ្វេ៖
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // តម្រូវការពីរ * s បាន!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// បញ្ឈប់បន្ទាប់ពីការ `false` ដំបូង:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // យើងមានធាតុជាច្រើនទៀតដែលតិចជាងសូន្យប៉ុន្តែដោយសារយើងមានក្លែងក្លាយរួចហើយ take_while() មិនត្រូវបានប្រើទៀតទេ
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ដោយសារតែ `take_while()` ត្រូវការដើម្បីទៅរកមើលនៅតម្លៃក្នុងលំដាប់នោះដើម្បីមើលថាតើវាគួរតែត្រូវបានរួមបញ្ចូលឬមិនប្រើប្រាស់ការនិយាយឡើងវិញនឹងឃើញថាវាត្រូវបានយកចេញ:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` នេះគឺមិនមានទៀតទេនៅទីនោះព្រោះវាត្រូវបានប្រើប្រាស់ក្នុងគោលបំណងដើម្បីមើលថាតើការនិយាយឡើងវិញគួរតែបញ្ឈប់ប៉ុន្តែមិនត្រូវបានដាក់ចូលទៅក្នុងការនិយាយឡើងវិញត្រឡប់មកវិញ។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// បង្កើត iterator ថាធាតុទិន្នផលទាំងពីរដោយផ្អែកលើការព្យាករណ៍និងជាផែនទីមួយ។
    ///
    /// `map_while()` ចំណាយពេលបិទជាអាគុយម៉ង់មួយ។
    /// វានឹងហៅការបិទនេះនៅលើធាតុនីមួយនៃការបម្រុងនិងបានផលធាតុខណៈពេលដែលវាត្រឡប់ [`Some(_)`][`Some`] ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// នេះជាឧទាហរណ៍ដូចគ្នាប៉ុន្តែជាមួយ [`take_while`] និង [`map`]៖
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// បញ្ឈប់បន្ទាប់ពី [`None`] ដំបូង៖
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // យើងមានធាតុជាច្រើនទៀតដែលអាចសមនៅក្នុង u32 (4, 5) ប៉ុន្តែ `map_while` ត្រឡប់មកវិញ `None` សម្រាប់ `-3` (ដូច `predicate` វិលត្រឡប់មកវិញ `None`) និង `collect` ឈប់នៅ `None` ដំបូងបានជួបប្រទះ។
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// ដោយសារតែ `map_while()` ត្រូវការពិនិត្យមើលតម្លៃដើម្បីអោយដឹងថាតើវាគួរតែត្រូវបានរាប់បញ្ចូលរឺមិនគួរប្រើការប្រើវានឹងឃើញថាវាត្រូវបានដកចេញ៖
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` នេះគឺមិនមានទៀតទេនៅទីនោះព្រោះវាត្រូវបានប្រើប្រាស់ក្នុងគោលបំណងដើម្បីមើលថាតើការនិយាយឡើងវិញគួរតែបញ្ឈប់ប៉ុន្តែមិនត្រូវបានដាក់ចូលទៅក្នុងការនិយាយឡើងវិញត្រឡប់មកវិញ។
    ///
    /// ចំណាំថាមិនដូច [`take_while`] ឧបករណ៍រំកិលនេះគឺ **មិន** ច្របូកច្របល់។
    /// វាត្រូវបានមិនបានបញ្ជាក់ផងដែរនេះជាការត្រឡប់មកវិញនូវអ្វីដែលបម្រុងបន្ទាប់ពី [`None`] ដំបូងត្រូវបានត្រឡប់មកវិញ។
    /// ប្រសិនបើអ្នកត្រូវបាន fused បម្រុងប្រើ [`fuse`] ។
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// បង្កើតឧបករណ៍រំកិលដែលរំលងធាតុ `n` ដំបូង។
    ///
    /// បន្ទាប់ពីពួកគេត្រូវបានប្រើប្រាស់, នៅសល់នៃធាតុនេះត្រូវបានគេជំរុញអោយ។
    /// ជាជាងការបដិសេធវិធីសាស្រ្តនេះដោយផ្ទាល់ជំនួសឱ្យបដិសេធវិធីសាស្រ្ត `nth` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// បង្កើតទិន្នផលធាតុដែលបម្រុងដំបូងរបស់ខ្លួនមួយ `n` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ត្រូវបានប្រើជាញឹកញាប់ជាមួយនឹងការបម្រុងគ្មានកំណត់ដើម្បីធ្វើឱ្យវា finite:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ប្រសិនបើតិចជាងធាតុ `n` អាចប្រើបានទេ `take` នឹងកំណត់ខ្លួនវាទៅនឹងទំហំនៃការបម្រុងមូលដ្ឋាននេះ:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// អាដាប់ធ័របម្រុងមួយដែលស្រដៀងគ្នាទៅនឹង [`fold`] ដែលទទួលបានរដ្ឋខាងក្នុងនិងផលិតបម្រុងថ្មី។
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` ត្រូវការអាគុយម៉ង់ពីរ: តម្លៃដំបូងដែលគ្រាប់ពូជរដ្ឋខាងក្នុងនិងបិទមានអាគុយម៉ង់ទាំងពីរជាលើកដំបូងជាសេចក្ដីយោង mutable ទៅរដ្ឋផ្ទៃក្នុងនិងទីពីរធាតុបម្រុងមួយ។
    ///
    /// ការបិទនេះអាចកំណត់ទៅរដ្ឋផ្ទៃក្នុងទៅរដ្ឋចំណែករវាងអន្តរកម្ម។
    ///
    /// នៅលើការនិយាយឡើងវិញ, ការបិទនេះនឹងត្រូវបានអនុវត្តទៅធាតុនីមួយនៃការបម្រុងនិងតម្លៃត្រឡប់ពីការបិទនេះ [`Option`] មួយត្រូវបានជំរុញអោយដោយការនិយាយឡើងវិញ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ធ្វើម្តងទៀតយើងនឹងគុណរដ្ឋដោយធាតុ
    ///     *state = *state * x;
    ///
    ///     // បន្ទាប់មកយើងនឹងផ្តល់លទ្ធផលអវិជ្ជមានដល់រដ្ឋ
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// បង្កើតបម្រុងថាធ្វើការដូចជាផែនទីមួយប៉ុន្តែ flattens រចនាសម្ព័នក្នុង។
    ///
    /// អាដាប់ធ័រ [`map`] គឺមានប្រយោជន៍ខ្លាំងណាស់, ប៉ុន្តែបានតែនៅពេលដែលអាគុយម៉ង់បិទផលិតតម្លៃ។
    /// ប្រសិនបើវាផលិតបម្រុងមួយជំនួសវិញ, មានស្រទាប់បន្ថែមនៃការដោយប្រយោល។
    /// `flat_map()` នឹងយកស្រទាប់បន្ថែមនេះចេញដោយខ្លួនឯង។
    ///
    /// អ្នកអាចគិតថា `flat_map(f)` ដែលជាសមមូល semantic នៃ [`map`] Ping, ហើយបន្ទាប់មក [`flatten`] ងដូចជានៅក្នុង `map(f).flatten()` ។
    ///
    /// វិធីមួយទៀតនៃការគិតអំពី `flat_map()`: [`map`] 's បានត្រឡប់មកវិញជាមួយធាតុដែលបានបិទសម្រាប់ធាតុគ្នានិងត្រឡប់មកវិញបម្រុងបិទ `flat_map()`'s ធាតុគ្នាមួយសម្រាប់។
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ត្រឡប់ឡៅតឿ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// បង្កើតរចនាសម្ព័ន្ធការបម្រុងដែល flattens មួយខាងក្នុង។
    ///
    /// វាមានប្រយោជន៍ពេលដែលអ្នកមាននៃការនិយាយឡើងវិញបម្រុងឬបម្រុងនៃអ្វីដែលអាចត្រូវបានប្រែក្លាយទៅជាការនិយាយឡើងវិញហើយអ្នកចង់យកចេញមួយកម្រិតនៃការដោយប្រយោល។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// គូសផែនទីហើយបន្ទាប់មករុញភ្ជាប់
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ត្រឡប់ឡៅតឿ
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// អ្នកអាចសរសេរឡើងវិញនេះនៅក្នុងលក្ខខណ្ឌនៃការ [`flat_map()`] ដែលចូលចិត្តក្នុងករណីចាប់តាំងពីវាមានន័យច្រើនជាងនេះយ៉ាងច្បាស់ចេតនា:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ត្រឡប់ឡៅតឿ
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// បំផ្លាញយកកម្រិតនៃការដាក់ខាងក្នុងមួយពេលមួយតែប៉ុណ្ណោះនៅលើ:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// នៅទីនេះយើងឃើញថា `flatten()` មិនដំណើរការរាងសំប៉ែត "deep" ទេ។
    /// ផ្ទុយទៅវិញមានតែមួយកម្រិតនៃសំណាញ់ត្រូវបានយកចេញ។នោះគឺជា, ប្រសិនបើអ្នក `flatten()` អារេបីវិមាត្រ, លទ្ធផលនេះនឹងមានពីរវិមាត្រនិងមិនមួយវិមាត្រ។
    /// ដើម្បីទទួលបានពីរចនាសម្ព័ន្ធមួយវិមាត្រមួយ, អ្នកមានដើម្បី `flatten()` ជាថ្មីម្តងទៀត។
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// បង្កើតដែលបានបញ្ចប់បន្ទាប់ពីការបម្រុងបាន [`None`] ដំបូងមួយ។
    ///
    /// បន្ទាប់ពីការបម្រុងមួយត្រឡប់ [`None`], ការហៅទូរស័ព្ទ future អាចឬមិនអាចបានផល [`Some(T)`] ម្តងទៀត។
    /// `fuse()` សម្របខ្លួនអ្នកធ្វើវាដោយធានាថាបន្ទាប់ពី [`None`] ត្រូវបានផ្តល់វានឹងត្រលប់មកវិញនូវ [`None`] ជារៀងរហូត។
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // បម្រុងដែលឆ្លាស់រវាងមួយចំនួននិងគ្មាន
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ប្រសិនបើវាជាការទោះបីជា, Some(i32), ផ្សេងទៀតគ្មាន
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // យើងអាចមើលឃើញរបស់យើងទៅវិញទៅមកដែលនឹងបម្រុង
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ទោះជាយ៉ាងណា, នៅពេលដែលយើង fuse វា ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // វានឹងតែងតែត្រឡប់ `None` បន្ទាប់ពីលើកដំបូង។
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ធ្វើអ្វីមួយជាមួយធាតុនីមួយៗនៃឧបករណ៍រំកិលឆ្លងកាត់តម្លៃ។
    ///
    /// នៅពេលប្រើទ្រនាប់ទ្រនាប់ជារឿយៗអ្នកនឹងភ្ជាប់វាជាមួយគ្នាជាច្រើន។
    /// ខណៈពេលកំពុងធ្វើការនៅលើកូដដូចនោះអ្នកប្រហែលជាចង់ធីកចេញពីអ្វីដែលកំពុងកើតឡើងនៅក្នុងផ្នែកជាច្រើននៅក្នុងបំពង់បង្ហូរប្រេងនេះ។ដើម្បីធ្វើដូចនោះ, បញ្ចូលហៅទៅ `inspect()` មួយ។
    ///
    /// វាជារឿងធម្មតាបន្ថែមទៀតសម្រាប់ `inspect()` នឹងត្រូវបានប្រើជាឧបករណ៍ជាងការបំបាត់កំហុសកូដចុងក្រោយមាននៅក្នុងអ្នកនោះទេប៉ុន្តែកម្មវិធីអាចស្វែងរកវាមានប្រយោជន៍នៅក្នុងស្ថានភាពមួយចំនួនពេលដែលកំហុសត្រូវចូលមុនពេលត្រូវបានបោះបង់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // លំដាប់បម្រុងនេះស្មុគស្មាញ។
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // អនុញ្ញាតឱ្យបន្ថែមការហៅទូរស័ព្ទ inspect() មួយចំនួនក្នុងការស៊ើបអង្កេតអ្វីដែលកើតឡើងជា
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// ការនេះនឹងបោះពុម្ព:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// កំហុសក្នុងការកាប់ឈើមុនពេលបោះបង់វា៖
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// ការនេះនឹងបោះពុម្ព:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ការខ្ចីប្រាក់បម្រុងមួយជាជាងការប្រើប្រាស់វា។
    ///
    /// នេះគឺជាការមានប្រយោជន៍ដើម្បីអនុញ្ញាតឱ្យមានការដាក់ពាក្យសុំអាដាប់ទ័របម្រុងខណៈពេលដែលនៅតែរក្សាភាពជាម្ចាស់នៃការនិយាយឡើងវិញដើម។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ប្រសិនបើយើងព្យាយាមប្រើវាម្តងទៀតវានឹងមិនដំណើរការទេ។
    /// // បន្ទាត់ដូចខាងក្រោមផ្តល់នូវ "កំហុស: ការប្រើប្រាស់នៃតម្លៃផ្លាស់ប្តូរ: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // សូមព្យាយាមម្តងទៀត
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // ជំនួសឱ្យយើងបន្ថែមក្នុង .by_ref() មួយ
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ឥឡូវនេះគឺគ្រាន់តែពិន័យ:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// បំលែងអ្នកធ្វើចលនាទៅជាបណ្តុំ។
    ///
    /// `collect()` អាចយកអ្វីនោះទេការនិយាយឡើងវិញនិងបានបើកវាចូលទៅក្នុងការប្រមូលពាក់ព័ន្ធ។
    /// នេះជាវិធីសាស្រ្តដែលមានអនុភាពក្នុងបណ្ណាល័យស្តង់ដារបានប្រើនៅក្នុងភាពខុសគ្នានៃបរិបទមួយ។
    ///
    /// លំនាំមូលដ្ឋានបំផុតដែល `collect()` ត្រូវបានប្រើគឺបង្វែរការប្រមូលមួយទៅជាមួយទៀត។
    /// អ្នកយកការប្រមូលផ្ដុំ, ការហៅ [`iter`] នៅលើវា, ធ្វើ bunch នៃការផ្លាស់ប្តូរហើយបន្ទាប់មក `collect()` នៅចុងបញ្ចប់។
    ///
    /// `collect()` អាចបង្កើតវត្ថុនៃប្រភេទដែលមិនប្រមូលធម្មតា។
    /// ឧទាហរណ៍ [`String`] មួយអាចត្រូវបានសាងសង់ឡើងពី [`char`] s បាន, និងការបម្រុងនៃធាតុ [`Result<T, E>`][`Result`] មួយដែលអាចត្រូវបានប្រមូលចូលទៅក្នុង `Result<Collection<T>, E>` ។
    ///
    /// សូមមើលឧទាហរណ៍ខាងក្រោមសម្រាប់ជាច្រើនទៀត។
    ///
    /// ដោយសារតែ `collect()` ជាអគ្គដូច្នេះវាអាចបណ្ដាលឱ្យមានបញ្ហាជាមួយប្រភេទ inference ។
    /// ដូច, `collect()` គឺមួយនៃការពីរបីដងនោះអ្នកនឹងឃើញវាក្យសម្ព័ន្ធដែលគេស្គាល់ថាជា 'turbofish' នេះ: `::<>`.
    /// នេះអាចជួយក្បួនដោះស្រាយ inference យល់យ៉ាងពិសេសដែលប្រមូលផ្ដុំអ្នកកំពុងព្យាយាមដើម្បីប្រមូលចូលទៅក្នុង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ចំណាំថាយើងត្រូវការ `: Vec<i32>` នៅផ្នែកខាងឆ្វេង។នេះគឺដោយសារតែយើងអាចប្រមូលចូលទៅក្នុងឧទាហរណ៍ [`VecDeque<T>`] ជំនួសវិញ:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// ដោយប្រើ 'turbofish' ជំនួសឱ្យការពន្យល់ `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ដោយសារតែ `collect()` គ្រាន់តែយកចិត្តទុកដាក់ចំពោះអ្វីដែលអ្នកកំពុងប្រមូលអ្នកនៅតែអាចប្រើព័ត៌មានជំនួយប្រភេទ `_` X ផ្នែកខ្លះដោយភាពច្របូកច្របល់៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ការប្រើ `collect()` ដើម្បីធ្វើឱ្យ [`String`] មួយ:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// ប្រសិនបើអ្នកមានបញ្ជី [`លទ្ធផល<T, E>`][`លទ្ធផល`s, អ្នកអាចប្រើ `collect()` ដើម្បីមើលថាតើពួកវាណាមួយបានបរាជ័យ:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ផ្តល់ឱ្យយើងនូវកំហុសដំបូង
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ផ្តល់ឱ្យយើងនូវបញ្ជីនៃចម្លើយ
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ប្រើប្រាស់បម្រុងមួយ, បង្កើតការប្រមូលពីរពីវា។
    ///
    /// ការព្យាករណ៍នេះបានអនុម័តដើម្បី `partition()` អាចត្រឡប់ `true` ឬ `false` ។
    /// `partition()` ត្រឡប់គូទាំងអស់នៃធាតុដែលវាត្រឡប់មកវិញ `true`, និងការទាំងអស់នៃធាតុដែលវាត្រឡប់មកវិញ `false` នេះ។
    ///
    ///
    /// សូមមើលផងដែរ [`is_partitioned()`] និង [`partition_in_place()`] ។
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// តម្រៀបធាតុអន្តរកម្មនេះ *នៅក្នុងកន្លែងនេះបើយោងតាមការព្យាករណ៍* បានផ្តល់ឱ្យដូចថាអស់អ្នកដែលវិលត្រឡប់មកវិញ `true` មុនទាំងអស់ដែលវិលត្រឡប់មកវិញ `false` ។
    ///
    /// ត្រឡប់ចំនួននៃធាតុ `true` ដែលបានរកឃើញ។
    ///
    /// លំដាប់នៃធាតុដែលត្រូវបានបែងចែកទាក់ទងមិនត្រូវបានរក្សា។
    ///
    /// សូមមើលផងដែរ [`is_partitioned()`] និង [`partition()`] ។
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // ភាគថាសនៅក្នុងកន្លែងរវាងគូនិងហាងឆេង
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: យើងគួរព្រួយបារម្ភអំពីការជន់រាប់បានដែរឬទេ?វិធីតែមួយគត់ដើម្បីមានច្រើនជាង
        // `usize::MAX` សេចក្តីយោង mutable គឺជាមួយនឹង ZSTs ដែលមិនមានប្រយោជន៍ដល់ភាគថាស ...

        // មុខងារទាំងនេះមានបិទ "factory" ដើម្បីចៀសវាងការទូទៅនៅក្នុង `Self` ។

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ម្តងហើយម្តងទៀតបានរកឃើញ `false` ប្ដូរវាដំបូងនិងចុងក្រោយនេះជាមួយ `true` ។
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// ពិនិត្យមើលប្រសិនបើធាតុនៃរឿងនេះបម្រុងយោងតាមការបែងចែកនោះត្រូវបានផ្ដល់ឱ្យ predicate នេះដូចថាអស់អ្នកដែលវិលត្រឡប់មកវិញ `true` មុនទាំងអស់ដែលវិលត្រឡប់មកវិញ `false` ។
    ///
    ///
    /// សូមមើលផងដែរ [`partition()`] និង [`partition_in_place()`] ។
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // ទាំងធាតុទាំងអស់សាកល្បង `true` ឬឃ្លាដំបូងដែលឈប់នៅ `false` ហើយយើងពិនិត្យមើលថាមានច្រើននោះទេធាតុ `true` បន្ទាប់ពីនោះ។
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// វិធីសាស្រ្តមួយដែលត្រូវបានអនុវត្តបម្រុងមុខងារមួយដែលវែងដូចដែលវាត្រឡប់ជោគជ័យក្នុងការផលិតតែមួយនោះតម្លៃចុងក្រោយ។
    ///
    /// `try_fold()` ត្រូវការអាគុយម៉ង់ពីរ: តម្លៃដំបូងនិងការបិទដែលមានអាគុយម៉ង់ពីរ: 'accumulator' មួយ, និងធាតុមួយ។
    /// ការបិទនេះបានត្រឡប់មកវិញដោយជោគជ័យទាំង, ជាមួយនឹងតម្លៃដែល accumulator មួយនេះគួរតែមានសម្រាប់ការនិយាយឡើងវិញបន្ទាប់ឬវាត្រឡប់ការបរាជ័យ, ជាមួយនឹងតម្លៃកំហុសដែលត្រូវបាន propagated ត្រឡប់ទៅអ្នកទូរស័ព្ទចូលភ្លាម (short-circuiting) នេះ។
    ///
    ///
    /// តម្លៃដំបូងជាតម្លៃ accumulator មួយនេះនឹងមាននៅលើការហៅជាលើកដំបូង។ប្រសិនបើមានការដាក់ពាក្យសុំការបិទនេះទទួលបានជោគជ័យប្រឆាំងនឹងរាល់ធាតុបម្រុងនោះ `try_fold()` ត្រឡប់ accumulator ចុងក្រោយជាការទទួលបានជោគជ័យ។
    ///
    /// ការបត់គឺមានប្រយោជន៍នៅពេលអ្នកមានបណ្តុំរបស់អ្វីមួយហើយចង់បង្កើតតម្លៃតែមួយពីវា។
    ///
    /// # កំណត់សំគាល់ចំពោះអ្នកអនុវត្ត
    ///
    /// មួយចំនួននៃវិធីសាស្រ្ត (forward) ឯទៀតមានការប្រតិបត្តិលំនាំដើមនៅក្នុងលក្ខខណ្ឌនៃការមួយនេះដូច្នេះព្យាយាមដើម្បីអនុវត្តការងារនេះឱ្យបានច្បាស់ប្រសិនបើវាអាចធ្វើអ្វីមួយដែលល្អប្រសើរជាងការអនុវត្តរង្វិលជុំ `for` លំនាំដើម។
    ///
    /// ជាពិសេសការព្យាយាមឱ្យមានការហៅនេះ `try_fold()` លើផ្នែកខាងក្នុងដែលបានមកពីបម្រុងនេះត្រូវបានផ្សំឡើង។
    /// ប្រសិនបើត្រូវការការហៅទូរស័ព្ទច្រើនដងនោះប្រតិបត្តិករ `?` អាចនឹងមានភាពងាយស្រួលក្នុងការធ្វើឱ្យតម្លៃតំរូវការកើនឡើងប៉ុន្តែត្រូវប្រយ័ត្ននឹងការលុកលុយណាដែលចាំបាច់ត្រូវតម្លើងមុនពេលត្រឡប់មកវិញ។
    /// នេះជាវិធីសាស្រ្ត `&mut self` ដូច្នេះការនិយាយឡើងវិញចាំបាច់ត្រូវតែអាចដំណើរការឡើងវិញបានបន្ទាប់ពីការវាយកំហុសមួយនៅទីនេះ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ផលបូកដែលបានត្រួតពិនិត្យនៃធាតុទាំងអស់នៃអារេ
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // ផលបូកនេះហៀរចេញនៅពេលបន្ថែមធាតុ ១០០
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ដោយសារតែវាខ្លី circuited ធាតុនៅសល់តែអាចប្រើបានតាមរយៈការនិយាយឡើងវិញ។
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// វិធីសាស្ត្ររំកិលដែលអនុវត្តមុខងារដែលអាចជឿទុកចិត្តបានចំពោះធាតុនីមួយៗនៅក្នុងឧបករណ៍ដដែលដោយឈប់នៅកំហុសដំបូងហើយត្រឡប់កំហុសនោះវិញ។
    ///
    ///
    /// នេះអាចត្រូវបានគិតថាជាទម្រង់បែបបទ fallible ឬជាការ [`for_each()`] គ្មានរដ្ឋនៃកំណែ [`try_fold()`] ។
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // វាខ្លី circuited ដូច្នេះធាតុនៅសល់តែមាននៅក្នុងការនិយាយឡើងវិញ:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// បោះបង់ចោលធាតុទាំងអស់ទៅជាអ្នកប្រមូលផ្តុំដោយអនុវត្តប្រតិបត្តិការមួយដោយប្រគល់លទ្ធផលចុងក្រោយ។
    ///
    /// `fold()` ត្រូវការអាគុយម៉ង់ពីរ: តម្លៃដំបូងនិងការបិទដែលមានអាគុយម៉ង់ពីរ: 'accumulator' មួយ, និងធាតុមួយ។
    /// ការបិទនេះត្រឡប់តម្លៃដែល accumulator មួយនេះគួរតែមានសម្រាប់ការនិយាយឡើងវិញបន្ទាប់។
    ///
    /// តម្លៃដំបូងជាតម្លៃ accumulator មួយនេះនឹងមាននៅលើការហៅជាលើកដំបូង។
    ///
    /// បនា្ទាប់ពីអនុវត្តការបិទនេះទៅគ្រប់ធាតុទាំងអស់នៃឧបករណ៍តំរែតំរង់ `fold()` ត្រឡប់អ្នកប្រមូល។
    ///
    /// ប្រតិបត្ដិការនេះត្រូវបានគេហៅថាពេលខ្លះ 'reduce' ឬ 'inject' ។
    ///
    /// ការបត់គឺមានប្រយោជន៍នៅពេលអ្នកមានបណ្តុំរបស់អ្វីមួយហើយចង់បង្កើតតម្លៃតែមួយពីវា។
    ///
    /// Note: `fold()`, និងវិធីសាស្រ្តស្រដៀងគ្នាដែលបានឆ្លងកាត់ការនិយាយឡើងវិញទាំងមូលមិនអាចបញ្ចប់សម្រាប់ការនិយាយឡើងវិញគ្មានដែនកំណត់, សូម្បីតែនៅលើ traits ដែលលទ្ធផលគឺជាការប្តេជ្ញាចិត្តនៅក្នុងពេលវេលាកំណត់។
    ///
    /// Note: [`reduce()`] អាចត្រូវបានប្រើដើម្បីប្រើធាតុដំបូងជាតម្លៃដំបូងប្រសិនបើប្រភេទ accumulator ធាតុនិងប្រភេទដូចគ្នានេះ។
    ///
    /// # កំណត់សំគាល់ចំពោះអ្នកអនុវត្ត
    ///
    /// មួយចំនួននៃវិធីសាស្រ្ត (forward) ឯទៀតមានការប្រតិបត្តិលំនាំដើមនៅក្នុងលក្ខខណ្ឌនៃការមួយនេះដូច្នេះព្យាយាមដើម្បីអនុវត្តការងារនេះឱ្យបានច្បាស់ប្រសិនបើវាអាចធ្វើអ្វីមួយដែលល្អប្រសើរជាងការអនុវត្តរង្វិលជុំ `for` លំនាំដើម។
    ///
    ///
    /// ជាពិសេសព្យាយាមឱ្យមានការហៅនេះ `fold()` លើផ្នែកខាងក្នុងដែលអ្នកតាក់តែងនេះត្រូវបានផ្សំឡើង។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // ផលបូកនៃគ្រប់ធាតុទាំងអស់នៃអារេនេះ
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// តោះដើរតាមជំហាននីមួយៗនៃការនិយាយឡើងវិញនៅទីនេះ៖
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// ដូច្នេះលទ្ធផលចុងក្រោយរបស់យើង `6`.
    ///
    /// វាជារឿងធម្មតាសម្រាប់មនុស្សដែលមិនបានប្រើការនិយាយឡើងវិញជាច្រើនដើម្បីប្រើរង្វិលជុំ `for` ជាមួយបញ្ជីនៃអ្វីមួយដើម្បីកសាងលទ្ធផល។អ្នកទាំងនោះអាចត្រូវបានប្រែក្លាយទៅ `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // សម្រាប់រង្វិលជុំ៖
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // ពួកគេដូចគ្នា
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// កាត់បន្ថយធាតុទៅមួយតែមួយដោយអនុវត្តម្តងហើយម្តងទៀតនូវប្រតិបត្តិការកាត់បន្ថយ។
    ///
    /// ប្រសិនបើទ្រនាប់វាទទេត្រឡប់ [`None`];បើមិនដូច្នេះទេលទ្ធផលនៃការកាត់បន្ថយការត្រឡប់មកនេះ។
    ///
    /// ចំពោះការនិយាយឡើងវិញជាមួយនឹងធាតុយ៉ាងហោចណាស់មួយ, នេះគឺដូចគ្នានឹង [`fold()`] ជាមួយធាតុដំបូងនៃការបម្រុងជាតម្លៃដំបូងបត់រាល់ធាតុជាបន្តបន្ទាប់ចូលទៅក្នុងវា។
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// ស្វែងរកតម្លៃអតិបរមា:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ធ្វើតេស្ត៍ប្រសិនបើគ្រប់ធាតុរបស់វាត្រូវគ្នានឹងការប៉ាន់ស្មាន។
    ///
    /// `all()` ចំណាយពេលបិទដែលត្រឡប់ `true` ឬ `false` មួយ។វាអនុវត្តការបិទទៅធាតុគ្នានៃការនិយាយឡើងវិញនេះហើយប្រសិនបើពួកគេទាំងអស់គ្នាវិលត្រឡប់មកវិញ `true` ទៅហើយដូច្នេះធ្វើ `all()` ។
    /// ប្រសិនបើពួកគេវិលត្រឡប់មកវិញ `false` របស់វាបានត្រឡប់ `false` ។
    ///
    /// `all()` សៀគ្វីខ្លី!នៅក្នុងពាក្យផ្សេងទៀត, វានឹងបញ្ឈប់ដំណើរការបានឆាប់តាមដែលវារកឃើញ `false` មួយដែលបានផ្ដល់ឱ្យថាបញ្ហាអ្វីផ្សេងទៀតដែលនឹងកើតឡើងនោះទេលទ្ធផលនឹង `false` ។
    ///
    ///
    /// អានបម្រុងទទេត្រឡប់ `true` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// ការបញ្ឈប់នៅ `false` ដំបូង:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // យើងនៅតែអាចប្រើ `iter` ដូចដែលមានធាតុច្រើនទៀត។
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ការធ្វើតេស្តបានប្រសិនបើធាតុណាមួយនៃការនិយាយឡើងវិញផ្គូផ្គងការព្យាករណ៍មួយ។
    ///
    /// `any()` ចំណាយពេលបិទដែលត្រឡប់ `true` ឬ `false` មួយ។វាអនុវត្តការបិទទៅធាតុគ្នានៃការនិយាយឡើងវិញនេះ, ហើយប្រសិនបើពួកគេវិលត្រឡប់មកវិញណាមួយដែល `true` ទៅហើយដូច្នេះធ្វើ `any()` ។
    /// ប្រសិនបើពួកគេត្រឡប់មកវិញ `false` វាត្រលប់មកវិញ `false` ។
    ///
    /// `any()` សៀគ្វីខ្លី!និយាយម៉្យាងទៀតវានឹងឈប់ដំណើរការភ្លាមៗនៅពេលវារកឃើញ `true` ដែលមិនថាមានអ្វីកើតឡើងក៏ដោយលទ្ធផលក៏នឹងក្លាយជា `true` ដែរ។
    ///
    ///
    /// អ្នកធ្វើចរន្តអគ្គិសនីទទេរត្រឡប់ `false` ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// ការបញ្ឈប់នៅ `true` ដំបូង:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // យើងនៅតែអាចប្រើ `iter` ដូចដែលមានធាតុច្រើនទៀត។
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ការស្វែងរកសម្រាប់ធាតុអន្តរកម្មមួយដែលបំពេញការព្យាករណ៍មួយ។
    ///
    /// `find()` យកការបិទដែលត្រឡប់ `true` ឬ `false` ។
    /// វាអនុវត្តការបិទទៅធាតុគ្នានៃការនិយាយឡើងវិញនេះ, ហើយប្រសិនបើពួកគេវិលត្រឡប់មកវិញណាមួយដែល `true` បន្ទាប់មក `find()` ត្រឡប់ [`Some(element)`] ។
    /// ប្រសិនបើពួកគេត្រឡប់មកវិញ `false` វាត្រលប់មកវិញ [`None`] ។
    ///
    /// `find()` គឺមានរយៈពេលខ្លី;នៅក្នុងពាក្យផ្សេងទៀត, វានឹងបញ្ឈប់ដំណើរការបានឆាប់ដូចជាការបិទនេះត្រឡប់ `true` ។
    ///
    /// ដោយសារតែ `find()` ត្រូវចំណាយពេលជាឯកសារយោងមួយ, និងការនិយាយឡើងវិញជាច្រើនដូចគ្នានៅលើសេចក្តីយោង, នាំទៅជាស្ថានភាពនេះមានការយល់ច្រឡំដែលជាកន្លែងដែលអាចធ្វើទៅបានគឺជាការអាគុយម៉ង់សេចក្ដីយោងពីរដង។
    ///
    /// អ្នកអាចមើលឃើញឥទ្ធិពលនេះក្នុងឧទាហរណ៍ខាងក្រោមនេះដោយមាន `&&x` ។
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// ការបញ្ឈប់នៅ `true` ដំបូង:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // យើងនៅតែអាចប្រើ `iter` ដូចដែលមានធាតុច្រើនទៀត។
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// ចំណាំថា `iter.find(f)` ស្មើនឹង `iter.filter(f).next()` ។
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// អនុវត្តមុខងារទៅឱ្យធាតុនៃការនិយាយឡើងវិញហើយត្រឡប់លទ្ធផលដែលមិនមាននរណាម្នាក់លើកដំបូង។
    ///
    ///
    /// `iter.find_map(f)` គឺស្មើនឹង `iter.filter_map(f).next()` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// អនុវត្តមុខងារទៅឱ្យធាតុនៃការនិយាយឡើងវិញហើយត្រឡប់លទ្ធផលពិតដំបូងឬកំហុសជាលើកដំបូង។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ស្វែងរកធាតុនៅក្នុងឧបករណ៍វាស់វេនត្រឡប់សន្ទស្សន៍របស់វា។
    ///
    /// `position()` យកការបិទដែលត្រឡប់ `true` ឬ `false` ។
    /// វាអនុវត្តការបិទទៅធាតុគ្នានៃការនិយាយឡើងវិញនេះ, ហើយប្រសិនបើពួកគេវិលត្រឡប់មកវិញមួយ `true` បន្ទាប់មក `position()` ត្រឡប់ [`Some(index)`] ។
    /// ប្រសិនបើទាំងអស់របស់ពួកគេត្រឡប់ `false` វាត្រឡប់ [`None`] ។
    ///
    /// `position()` គឺមានរយៈពេលខ្លី;និយាយម៉្យាងទៀតវានឹងបញ្ឈប់ដំណើរការភ្លាមៗនៅពេលវារកឃើញ `true` ។
    ///
    /// # ឥរិយាបថលើសចំណុះ
    ///
    /// វិធីសាស្រ្តនេះមិនការពារប្រឆាំងនឹងការហូរហៀរទេដូច្នេះប្រសិនបើមានធាតុដែលមិនផ្គូរផ្គងលើសពី [`usize::MAX`] វាអាចបង្កើតលទ្ធផលខុសឬ panics ។
    ///
    /// ប្រសិនបើមានការអះអាងបំបាត់កំហុសត្រូវបានអនុញ្ញាត panic មួយដែលត្រូវបានធានា។
    ///
    /// # Panics
    ///
    /// មុខងារនេះអាច panic ប្រសិនបើការបម្រុងមានច្រើនជាង `usize::MAX` ធាតុគ្មានការផ្គូផ្គង។
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// ការបញ្ឈប់នៅ `true` ដំបូង:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // យើងនៅតែអាចប្រើ `iter` ដូចដែលមានធាតុច្រើនទៀត។
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // សន្ទស្សន៍ត្រឡប់មកវិញអាស្រ័យលើរដ្ឋបម្រុង
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// ការស្វែងរកសម្រាប់ធាតុនៅក្នុងដងពីខាងស្ដាំមួយ, ការវិលត្រឡប់សន្ទស្សន៍របស់ខ្លួន។
    ///
    /// `rposition()` យកការបិទដែលត្រឡប់ `true` ឬ `false` ។
    /// វាអនុវត្តការបិទទៅធាតុគ្នានៃការនិយាយឡើងវិញដោយចាប់ផ្តើមពីចុងនេះហើយបើមួយនៃពួកគេត្រឡប់ `true` បន្ទាប់មក `rposition()` ត្រឡប់ [`Some(index)`] ។
    ///
    /// ប្រសិនបើទាំងអស់របស់ពួកគេត្រឡប់ `false` វាត្រឡប់ [`None`] ។
    ///
    /// `rposition()` គឺមានរយៈពេលខ្លី;និយាយម៉្យាងទៀតវានឹងបញ្ឈប់ដំណើរការភ្លាមៗនៅពេលវារកឃើញ `true` ។
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// ការបញ្ឈប់នៅ `true` ដំបូង:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // យើងនៅតែអាចប្រើ `iter` ដូចដែលមានធាតុច្រើនទៀត។
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // មិនចាំបាច់សម្រាប់ការលើសចំណុះមួយដែលពិនិត្យមើលនៅទីនេះដោយសារតែ `ExactSizeIterator` បង្កប់ន័យថាចំនួននៃការកាច់ធាតុចូលទៅក្នុង `usize` មួយ។
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ត្រឡប់ធាតុអតិបរមានៃបម្រុងមួយ។
    ///
    /// ប្រសិនបើធាតុជាច្រើនមានអតិបរិមាស្មើគ្នានោះធាតុចុងក្រោយត្រូវបានត្រឡប់មកវិញ។
    /// ប្រសិនបើការបម្រុងទទេ [`None`] ត្រូវបានត្រឡប់។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ត្រឡប់ធាតុអប្បបរមានៃឧបករណ៍វាស់ស្ទង់។
    ///
    /// ប្រសិនបើធាតុជាច្រើនអប្បបរមាស្មើភាពគ្នាជាធាតុដំបូងត្រូវបានត្រឡប់មកវិញ។
    /// ប្រសិនបើការបម្រុងទទេ [`None`] ត្រូវបានត្រឡប់។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// ត្រឡប់ធាតុដែលផ្តល់តម្លៃអតិបរមាពីមុខងារដែលបានបញ្ជាក់។
    ///
    ///
    /// ប្រសិនបើធាតុជាច្រើនមានអតិបរិមាស្មើគ្នានោះធាតុចុងក្រោយត្រូវបានត្រឡប់មកវិញ។
    /// ប្រសិនបើការបម្រុងទទេ [`None`] ត្រូវបានត្រឡប់។
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// ត្រឡប់ធាតុដែលផ្តល់តម្លៃអតិបរមាដោយគោរពទៅនឹងមុខងារការប្រៀបធៀបនេះបានបញ្ជាក់នោះទេ។
    ///
    ///
    /// ប្រសិនបើធាតុជាច្រើនមានអតិបរិមាស្មើគ្នានោះធាតុចុងក្រោយត្រូវបានត្រឡប់មកវិញ។
    /// ប្រសិនបើការបម្រុងទទេ [`None`] ត្រូវបានត្រឡប់។
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ត្រឡប់ធាតុដែលផ្តល់តម្លៃអប្បបរមាពីមុខងារដែលបានបញ្ជាក់។
    ///
    ///
    /// ប្រសិនបើធាតុជាច្រើនអប្បបរមាស្មើភាពគ្នាជាធាតុដំបូងត្រូវបានត្រឡប់មកវិញ។
    /// ប្រសិនបើការបម្រុងទទេ [`None`] ត្រូវបានត្រឡប់។
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// ត្រឡប់ធាតុដែលផ្តល់តម្លៃអប្បបរមាដោយគោរពទៅនឹងមុខងារការប្រៀបធៀបនេះបានបញ្ជាក់នោះទេ។
    ///
    ///
    /// ប្រសិនបើធាតុជាច្រើនអប្បបរមាស្មើភាពគ្នាជាធាតុដំបូងត្រូវបានត្រឡប់មកវិញ។
    /// ប្រសិនបើការបម្រុងទទេ [`None`] ត្រូវបានត្រឡប់។
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ដាក់បញ្ច្រាសទិសដៅបម្រុងមួយ។
    ///
    /// ជាធម្មតាការនិយាយឡើងវិញដូចគ្នាពីឆ្វេងទៅស្តាំ។
    /// បន្ទាប់ពីការប្រើ `rev()` ដែលជាកន្លែងបម្រុងនឹងជំនួសឱ្យអន្តរកម្មពីស្តាំទៅឆ្វេង។
    ///
    /// នេះគឺជាការអាចធ្វើទៅបានតែប៉ុណ្ណោះប្រសិនបើបម្រុងមានទីបញ្ចប់, ដូច្នេះ `rev()` ធ្វើការតែនៅលើ [`DoubleEndedIterator`] s បានទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// បម្លែងគូមួយដែលបម្រុងចូលទៅក្នុងធុងមួយគូ។
    ///
    /// `unzip()` ប្រើប្រាស់ជាកន្លែងបម្រុងទាំងមូលនៃគូផលិតប្រមូលពីរ: មួយពីធាតុខាងឆ្វេងនៃគូនិងមួយពីធាតុខាងស្ដាំ។
    ///
    ///
    /// នៅក្នុងមុខងារនេះគឺផ្ទុយពី [`zip`] ។
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// បង្កើតច្បាប់ចម្លងទាំងអស់ដែលបានបម្រុងនៃធាតុរបស់ខ្លួន។
    ///
    /// វាមានប្រយោជន៍ពេលដែលអ្នកមានបម្រុងនៅលើ `&T` មួយ, ប៉ុន្តែអ្នកត្រូវបម្រុងនៅលើ `T` មួយ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // ចំលងគឺដូចគ្នានឹង .map(|&x| x) ដែរ
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// បង្កើតបម្រុងដែល [`clone`] បានទាំងអស់នៃធាតុរបស់វា។
    ///
    /// វាមានប្រយោជន៍ពេលដែលអ្នកមានបម្រុងនៅលើ `&T` មួយ, ប៉ុន្តែអ្នកត្រូវបម្រុងនៅលើ `T` មួយ។
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // ក្លូនគឺដូចគ្នា .map(|&x| x) សម្រាប់ចំនួនគត់
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ធ្វើម្តងទៀតដោយមិនចេះចប់។
    ///
    /// ជំនួសឱ្យការបញ្ឈប់នៅ [`None`], ការនិយាយឡើងវិញនឹងចាប់ផ្តើមជាថ្មីម្តងទៀតជំនួសពីការចាប់ផ្តើមនេះ។បន្ទាប់ពី iterating ថ្មីម្តងទៀតវានឹងចាប់ផ្តើមនៅដើមម្តងទៀត។ហើយម្តងទៀត។
    /// ហើយម្តងទៀត។
    /// Forever.
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// សង្ខេបធាតុអន្តរកម្មមួយ។
    ///
    /// យកធាតុនីមួយៗបន្ថែមពួកវារួមគ្នាហើយត្រឡប់លទ្ធផល។
    ///
    /// ឧបករណ៍រំកិលទទេត្រឡប់តម្លៃសូន្យនៃប្រភេទ។
    ///
    /// # Panics
    ///
    /// នៅពេលដែលការហៅទូរស័ព្ទនិងប្រភេទចំនួនគត់ `sum()` មួយដែលត្រូវបានត្រឡប់មកវិញបុព្វកាល, វិធីសាស្រ្តនេះនឹង panic គណនាលើសចំណុះប្រសិនបើបំបាត់កំហុសត្រូវបានអះអាងនិងបានអនុញ្ញាត។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// ការនិយាយឡើងវិញនៅលើការនិយាយឡើងវិញទាំងមូលគុណធាតុទាំងអស់
    ///
    /// អានបម្រុងទទេត្រឡប់តម្លៃនៃការមួយប្រភេទនេះ។
    ///
    /// # Panics
    ///
    /// នៅពេលដែលការហៅទូរស័ព្ទនិងប្រភេទចំនួនគត់ `product()` មួយដែលត្រូវបានត្រឡប់មកវិញបុព្វកាល, វិធីសាស្រ្តនឹង panic គណនាលើសចំណុះប្រសិនបើបំបាត់កំហុសត្រូវបានអះអាងនិងបានអនុញ្ញាត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) បើប្រៀបធៀបធាតុនៃ [`Iterator`] នេះជាមួយអ្នកផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) បើប្រៀបធៀបធាតុនៃ [`Iterator`] ជាមួយនឹងអ្នកដែលផ្សេងទៀតនេះដោយគោរពទៅនឹងមុខងារការប្រៀបធៀបនេះបានបញ្ជាក់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) បើប្រៀបធៀបធាតុនៃ [`Iterator`] នេះជាមួយអ្នកផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) បើប្រៀបធៀបធាតុនៃ [`Iterator`] ជាមួយនឹងអ្នកដែលផ្សេងទៀតនេះដោយគោរពទៅនឹងមុខងារការប្រៀបធៀបនេះបានបញ្ជាក់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// កំណត់ប្រសិនបើធាតុនៃ [`Iterator`] នេះគឺស្មើទៅនឹងអ្នកផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// កំណត់ប្រសិនបើធាតុនៃ [`Iterator`] នេះគឺស្មើទៅនឹងអ្នកផ្សេងទៀតដោយគោរពទៅនឹងមុខងារសមភាពបញ្ជាក់។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// កំណត់ប្រសិនបើធាតុនៃ [`Iterator`] នេះគឺមិនស្មើគ្នាទៅនឹងអ្នកផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// កំណត់ប្រសិនបើធាតុនៃ [`Iterator`] នេះគឺ [lexicographically](Ord#lexicographical-comparison) តិចជាងអ្នកផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// កំណត់ថាតើធាតុនៃ [`Iterator`] នេះគឺ [lexicographically](Ord#lexicographical-comparison) តិចឬស្មើទៅនឹងធាតុផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// កំណត់ប្រសិនបើធាតុនៃ [`Iterator`] នេះគឺមានកាន់តែច្រើន [lexicographically](Ord#lexicographical-comparison) ជាងអ្នកដែលនៃផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// កំណត់ប្រសិនបើធាតុនៃ [`Iterator`] នេះគឺមានកាន់តែច្រើន [lexicographically](Ord#lexicographical-comparison) ជាងឬស្មើទៅនឹងអ្នកផ្សេងទៀត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ពិនិត្យមើលថាតើធាតុរបស់ឧបករណ៍រំកិលនេះត្រូវបានតម្រៀប។
    ///
    /// នោះគឺជា, សម្រាប់ធាតុគ្នា `a` របស់ខ្លួននិងធាតុខាងក្រោម `b`, `a <= b` ត្រូវមាន។ប្រសិនបើមានការនិយាយឡើងវិញផ្តល់ធាតុមួយយ៉ាងពិតប្រាកដសូន្យឬ `true` ត្រូវបានត្រឡប់។
    ///
    /// ចំណាំថាប្រសិនបើ `Self::Item` គឺគ្រាន់តែជា `PartialOrd` ប៉ុន្តែមិន `Ord`, និយមន័យខាងលើនេះបញ្ជាក់ថាអនុគមន៍នេះត្រឡប់ `false` បើធាតុណាមួយដែលមានពីរជាប់គ្នាមិនអាចប្រៀបធៀប។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// ពិនិត្យមើលប្រសិនបើធាតុនៃបម្រុងនេះត្រូវបានតម្រៀបដោយការប្រើមុខងារប្រៀបធៀបបានផ្តល់ឱ្យ។
    ///
    /// ជំនួសឱ្យការប្រើ `PartialOrd::partial_cmp` មុខងារនេះប្រើមុខងារ `compare` បានផ្ដល់ទៅឱ្យធាតុលំដាប់កំណត់ទាំងពីរនាក់នេះ។
    /// ក្រៅពីនោះ, វាជាការស្មើនឹង [`is_sorted`];មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// ពិនិត្យមើលប្រសិនបើធាតុនៃបម្រុងនេះត្រូវបានតម្រៀបដោយការប្រើមុខងារទាញយកគន្លឹះដែលបានផ្តល់ឱ្យ។
    ///
    /// ជំនួសឱ្យការប្រៀបធៀបធាតុបម្រុងដោយផ្ទាល់អនុគមន៍នេះបើប្រៀបធៀបកូនសោនៃធាតុនេះ, ដូចដែលបានកំណត់ដោយ `f` ។
    /// ក្រៅពីនោះ, វាជាការស្មើនឹង [`is_sorted`];មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// សូមមើល [TrustedRandomAccess]
    // ឈ្មោះមិនធម្មតាគឺដើម្បីចៀសវាងការប៉ះទង្គិចឈ្មោះក្នុងដំណោះស្រាយវិធីសាស្រ្តសូមមើល #76479 ។
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}