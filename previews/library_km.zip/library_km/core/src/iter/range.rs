use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// វត្ថុដែលមានសញ្ញាណនៃការស្នងតំណែង * **ប្រតិបត្តិការកាន់តំណែងមុននិង* មួយ។
///
/// ស្នង * * ប្រតិបត្ដិការផ្លាស់ទីឆ្ពោះទៅរកតម្លៃដែលប្រៀបធៀបកាន់តែច្រើន។
/// ប្រតិបត្តិការ * អ្នកកាន់តំណែងមុនផ្លាស់ប្តូរឆ្ពោះទៅរកតម្លៃដែលប្រៀបធៀបតិចជាង។
///
/// # Safety
///
/// trait នេះគឺជា `unsafe` ពីព្រោះការអនុវត្តរបស់វាត្រូវតែត្រឹមត្រូវសម្រាប់សុវត្ថិភាពនៃការអនុវត្ត `unsafe trait TrustedLen` ហើយលទ្ធផលនៃការប្រើប្រាស់ trait នេះអាចជឿទុកចិត្តបានដោយលេខកូដ `unsafe` ដើម្បីត្រឹមត្រូវនិងបំពេញកាតព្វកិច្ចដែលបានចុះបញ្ជី។
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// ត្រឡប់ចំនួននៃការស្នងតំណែង * * ជំហានដែលបានទាមទារដើម្បីទទួលបានពី `start` ទៅ `end` ។
    ///
    /// ត្រឡប់ `None` ប្រសិនបើចំនួននៃជំហាននេះនឹងហូរ `usize` (ឬគឺគ្មានដែនកំណត់, ឬប្រសិនបើ `end` នឹងមិនត្រូវបានឈានដល់) ។
    ///
    ///
    /// # Invariants
    ///
    /// សម្រាប់ `a`, `b`, និង `n`៖
    ///
    /// * `steps_between(&a, &b) == Some(n)` ប្រសិនបើនិងបានតែប្រសិនបើ `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` ប្រសិនបើ `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` តែប៉ុណ្ណោះប្រសិនបើ `a <= b`
    ///   * ផ្កាថ្ម៖ `steps_between(&a, &b) == Some(0)` ប្រសិនបើនិងលុះត្រាតែ `a == b`
    ///   * ចំណាំថា `a <= b` ធ្វើ _not_ បញ្ជាក់ `steps_between(&a, &b) != None`;
    ///     នេះគឺជាករណីនៅពេលដែលវានឹងតម្រូវឱ្យមានច្រើនជាងជំហាន `usize::MAX` ដើម្បីទទួលបានទៅ `b`
    /// * `steps_between(&a, &b) == None` ប្រសិនបើ `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// ត្រឡប់តម្លៃដែលនឹងទទួលបានដោយយក *អ្នកស្នង* នៃ `self` `count` ដង។
    ///
    /// ប្រសិនបើវាលើសចំណុះជួរនៃតម្លៃដែលគាំទ្រដោយ `Self` ត្រឡប់ `None` ។
    ///
    /// # Invariants
    ///
    /// សម្រាប់ `a` ណាមួយ `n` និង `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// សម្រាប់ `a`, `n`, និង `m` ដែល `n + m` មិនហៀរចេញ:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// សម្រាប់ `a` ណាមួយនិង `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// ត្រឡប់តម្លៃដែលនឹងទទួលបានដោយយក *អ្នកស្នង* នៃ `self` `count` ដង។
    ///
    /// ប្រសិនបើវាលើសចំណុះជួរនៃតម្លៃដែលគាំទ្រដោយ `Self` មុខងារនេះត្រូវបានអនុញ្ញាតឱ្យ panic រុំឬតិត្ថិភាព។
    ///
    /// អាកប្បកិរិយាដែលបានស្នើគឺដើម្បី panic នៅពេលដែលការអះអាងបំបាត់កំហុសត្រូវបានបើកនិងដើម្បីរុំឬ saturate បើមិនដូច្នេះទេ។
    ///
    /// លេខកូដដែលមិនមានសុវត្ថិភាពមិនគួរពឹងផ្អែកលើភាពត្រឹមត្រូវនៃឥរិយាបថបន្ទាប់ពីលើសចំណុះ។
    ///
    /// # Invariants
    ///
    /// សម្រាប់ `a` ណាមួយ `n` និង `m`, ដែលជាកន្លែងដែលហៀរហូរគ្មានបានកើតឡើង:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// សម្រាប់ `a` ណាមួយនិង `n`, ដែលជាកន្លែងដែលហៀរហូរគ្មានបានកើតឡើង:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// ត្រឡប់តម្លៃដែលនឹងទទួលបានដោយយក *អ្នកស្នង* នៃ `self` `count` ដង។
    ///
    /// # Safety
    ///
    /// វាគឺជាឥរិយាបទមិនបានកំណត់សម្រាប់ប្រតិបត្ដិការនេះដើម្បីហូរជួរតម្លៃដែលបានគាំទ្រដោយ `Self` នេះ។
    /// ប្រសិនបើអ្នកមិនអាចធានាថានេះនឹងមិនលើសចំណុះ, ប្រើ `forward` ឬ `forward_checked` ជំនួសវិញ។
    ///
    /// # Invariants
    ///
    /// សម្រាប់ `a` ណាមួយ:
    ///
    /// * ប្រសិនបើមានមាន `b` ដូចថា `b > a` វាមានសុវត្ថិភាពក្នុងការហៅ `Step::forward_unchecked(a, 1)`
    /// * ប្រសិនបើមាន `b`, `n` ដូចជា `steps_between(&a, &b) == Some(n)` វាមានសុវត្ថិភាពក្នុងការហៅទូរស័ព្ទ `Step::forward_unchecked(a, m)` សម្រាប់ `m <= n` ណាមួយ។
    ///
    ///
    /// សម្រាប់ `a` ណាមួយនិង `n`, ដែលជាកន្លែងដែលហៀរហូរគ្មានបានកើតឡើង:
    ///
    /// * `Step::forward_unchecked(a, n)` គឺស្មើនឹង `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// ត្រឡប់តម្លៃដែលនឹងទទួលបានដោយយក *អ្នកកាន់តំណែងមុន* នៃ `self` `count` ដង។
    ///
    /// ប្រសិនបើវាលើសចំណុះជួរនៃតម្លៃដែលគាំទ្រដោយ `Self` ត្រឡប់ `None` ។
    ///
    /// # Invariants
    ///
    /// សម្រាប់ `a` ណាមួយ `n` និង `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// សម្រាប់ `a` ណាមួយនិង `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// ត្រឡប់តម្លៃដែលនឹងទទួលបានដោយយក *អ្នកកាន់តំណែងមុន* នៃ `self` `count` ដង។
    ///
    /// ប្រសិនបើវាលើសចំណុះជួរនៃតម្លៃដែលគាំទ្រដោយ `Self` មុខងារនេះត្រូវបានអនុញ្ញាតឱ្យ panic រុំឬតិត្ថិភាព។
    ///
    /// អាកប្បកិរិយាដែលបានស្នើគឺដើម្បី panic នៅពេលដែលការអះអាងបំបាត់កំហុសត្រូវបានបើកនិងដើម្បីរុំឬ saturate បើមិនដូច្នេះទេ។
    ///
    /// លេខកូដដែលមិនមានសុវត្ថិភាពមិនគួរពឹងផ្អែកលើភាពត្រឹមត្រូវនៃឥរិយាបថបន្ទាប់ពីលើសចំណុះ។
    ///
    /// # Invariants
    ///
    /// សម្រាប់ `a` ណាមួយ `n` និង `m`, ដែលជាកន្លែងដែលហៀរហូរគ្មានបានកើតឡើង:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// សម្រាប់ `a` ណាមួយនិង `n`, ដែលជាកន្លែងដែលហៀរហូរគ្មានបានកើតឡើង:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// ត្រឡប់តម្លៃដែលនឹងទទួលបានដោយយក *អ្នកកាន់តំណែងមុន* នៃ `self` `count` ដង។
    ///
    /// # Safety
    ///
    /// វាគឺជាឥរិយាបទមិនបានកំណត់សម្រាប់ប្រតិបត្ដិការនេះដើម្បីហូរជួរតម្លៃដែលបានគាំទ្រដោយ `Self` នេះ។
    /// ប្រសិនបើអ្នកមិនអាចធានាថានេះនឹងមិនលើសចំណុះ, ប្រើ `backward` ឬ `backward_checked` ជំនួសវិញ។
    ///
    /// # Invariants
    ///
    /// សម្រាប់ `a` ណាមួយ:
    ///
    /// * ប្រសិនបើមានមាន `b` ដូចថា `b < a` វាមានសុវត្ថិភាពក្នុងការហៅ `Step::backward_unchecked(a, 1)`
    /// * ប្រសិនបើមានមាន `b`, `n` ដូចថា `steps_between(&b, &a) == Some(n)` វាមានសុវត្ថិភាពក្នុងការហៅ `Step::backward_unchecked(a, m)` សម្រាប់ `m <= n` ណាមួយ។
    ///
    ///
    /// សម្រាប់ `a` ណាមួយនិង `n`, ដែលជាកន្លែងដែលហៀរហូរគ្មានបានកើតឡើង:
    ///
    /// * `Step::backward_unchecked(a, n)` ស្មើនឹង `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// ទាំងនេះគឺនៅតែម៉ាក្រូដែលបានបង្កើតដោយសារតែចំនួនគត់ literals ការតាំងចិត្តមួយដើម្បីប្រភេទផ្សេងគ្នា។
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលមានដើម្បីធានាថា `start + n` លើសចំណុះមិន។
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលមានដើម្បីធានាថា `start - n` លើសចំណុះមិន។
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // នៅក្នុងការបំបាត់កំហុសកសាង, កេះ panic មួយនៅលើលើសចំណុះ។
            // នេះគួរតែបង្កើនប្រសិទ្ធភាពទាំងស្រុងនៅក្នុងការចេញផ្សាយកសាង។
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // តើរុំគណិតវិទ្យាដើម្បីអនុញ្ញាតឱ្យឧ `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // នៅក្នុងការបំបាត់កំហុសកសាង, កេះ panic មួយនៅលើលើសចំណុះ។
            // នេះគួរតែបង្កើនប្រសិទ្ធភាពទាំងស្រុងនៅក្នុងការចេញផ្សាយកសាង។
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // តើរុំគណិតវិទ្យាដើម្បីអនុញ្ញាតឱ្យឧ `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // នេះពឹងផ្អែកលើ $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // ប្រសិនបើមាន n ជានៅក្រៅជួរ, `unsigned_start + n` គឺពេក
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // ប្រសិនបើមាន n ជានៅក្រៅជួរ, `unsigned_start - n` គឺពេក
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // នេះពឹងផ្អែកលើ $i_narrower <=ប្រើប្រាស់
                        //
                        // ការខាសដើម្បីពង្រីកទំហំរបស់វាពង្រីកទទឹងប៉ុន្តែរក្សាសញ្ញា។
                        // ការប្រើប្រាស់ wrapping_sub ក្នុងចន្លោះ isize និងសម្ដែងក្នុងការ usize ដើម្បីគណនាភាពខុសគ្នាដែលអាចនឹងមិនសមនៅក្នុងជួរនៃ isize នេះ។
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // រុំករណីដូច `Step::forward(-120_i8, 200) == Some(80_i8)` ទោះបីជា 200 មិនមានជួរសម្រាប់ i8 ក៏ដោយ។
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // លើសពីនេះទៀត overflowed
                            }
                        }
                        // ប្រសិនបើ n នៅក្រៅជួរឧ
                        // u8, បន្ទាប់មកវាគឺមានទំហំធំជាងជួរទាំងមូលសម្រាប់ i8 គឺធំទូលាយដូច្នេះ `any_i8 + n` ចាំបាច់ហូរ i8 ។
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // រុំករណីដូច `Step::forward(-120_i8, 200) == Some(80_i8)` ទោះបីជា 200 មិនមានជួរសម្រាប់ i8 ក៏ដោយ។
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // ដកចំណុះ
                            }
                        }
                        // ប្រសិនបើ n នៅក្រៅជួរឧ
                        // u8, បន្ទាប់មកវាធំជាងជួរទាំងមូលសម្រាប់ i8 គឺធំដូច្នេះ `any_i8 - n` ចាំបាច់លើស i8 ។
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // ប្រសិនបើភាពខុសគ្នាធំពេកសម្រាប់ឧ
                            // i128, វាបានផងដែរនឹងត្រូវធំពេកសម្រាប់ usize ជាមួយប៊ីត។
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // សុវត្ថិភាព: res គឺជាជញ្ជីងយូនីកូដដែលត្រឹមត្រូវ
            // (ខាងក្រោម 0x110000 និងមិននៅក្នុង 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // សុវត្ថិភាព: res គឺជាជញ្ជីងយូនីកូដដែលត្រឹមត្រូវ
        // (ខាងក្រោម 0x110000 និងមិននៅក្នុង 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថានេះមិនលើសចំណុះ
        // ជួរនៃតម្លៃសម្រាប់តួអក្សរមួយ។
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថានេះមិនលើសចំណុះ
            // ជួរនៃតម្លៃសម្រាប់តួអក្សរមួយ។
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // សុវត្ថិភាព: ដោយសារតែកិច្ចសន្យាមុននេះត្រូវបានធានា
        // ដោយអ្នកទូរស័ព្ទចូលដើម្បីជាលេខសម្គាល់ត្រឹមត្រូវ។
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថានេះមិនលើសចំណុះ
        // ជួរនៃតម្លៃសម្រាប់តួអក្សរមួយ។
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថានេះមិនលើសចំណុះ
            // ជួរនៃតម្លៃសម្រាប់តួអក្សរមួយ។
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // សុវត្ថិភាព: ដោយសារតែកិច្ចសន្យាមុននេះត្រូវបានធានា
        // ដោយអ្នកទូរស័ព្ទចូលដើម្បីជាលេខសម្គាល់ត្រឹមត្រូវ។
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// ម៉ាក្រូទាំងនេះបង្កើត `ExactSizeIterator` បង្កប់សម្រាប់ប្រភេទផ្សេងៗគ្នា។
//
// * `ExactSizeIterator::len` ត្រូវបានទាមទារដើម្បីតែងតែវិលត្រឡប់មកវិញជាមួយ `usize` ពិតប្រាកដដូច្នេះជួរគ្មានអាចត្រូវបានយូរជាង `usize::MAX` ។
//
// * សម្រាប់ប្រភេទគត់ក្នុង `Range<_>` នេះគឺជាករណីសម្រាប់ប្រភេទតូចជាងឬជាធំទូលាយដូចជា `usize` នេះ។
//   សម្រាប់ប្រភេទគត់ក្នុង `RangeInclusive<_>` នេះគឺជាករណីសម្រាប់ប្រភេទ *យ៉ាងតឹងរ៉ឹងតូចជាង `usize` តាំងពី* ឧទានេះ
//   `(0..=u64::MAX).len()` នឹងមាន `u64::MAX + 1` ។
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // ទាំងនេះគឺជាការបញ្ចូលក្នុងហេតុផលខាងលើប៉ុន្តែការដកវាចេញនឹងក្លាយជាការផ្លាស់ប្តូរមួយដែលពួកគេមានស្ថេរភាពនៅក្នុង Rust 1.0.0 ។
    // ដូច្នេះឧទាហរណ៍
    // `(0..66_000_u32).len()` ឧទាហរណ៍នឹងចងក្រងដោយគ្មានកំហុសឬការព្រមាននៅលើប្រព័ន្ធប្រតិបត្តិការ 16 ប៊ីតនោះទេប៉ុន្តែបន្តផ្តល់នូវលទ្ធផលខុស។
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // ទាំងនេះគឺជាការបញ្ចូលក្នុងហេតុផលខាងលើប៉ុន្តែការដកវាចេញនឹងក្លាយជាការផ្លាស់ប្តូរមួយដែលពួកគេមានស្ថេរភាពនៅក្នុង Rust 1.26.0 ។
    // ដូច្នេះឧទាហរណ៍
    // `(0..=u16::MAX).len()` ឧទាហរណ៍នឹងចងក្រងដោយគ្មានកំហុសឬការព្រមាននៅលើប្រព័ន្ធប្រតិបត្តិការ 16 ប៊ីតនោះទេប៉ុន្តែបន្តផ្តល់នូវលទ្ធផលខុស។
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // បុរេលក្ខខណ្ឌគ្រាន់តែគូសធីក: សុវត្ថិភាព
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}