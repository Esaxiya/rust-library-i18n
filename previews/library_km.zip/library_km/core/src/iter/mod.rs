//! ការនិយាយឡើងវិញពីខាងក្រៅកម្មវិធីតែង។
//!
//! ប្រសិនបើអ្នកបានរកឃើញខ្លួនឯងជាមួយនឹងការប្រមូលផ្ដុំនៃប្រភេទមួយចំនួននិងត្រូវការជាចាំបាច់ដើម្បីអនុវត្តប្រតិបត្ដិការមួយនៅលើធាតុនៃការប្រមូលបាននិយាយថាអ្នកនឹងរត់យ៉ាងលឿនចូលទៅក្នុង 'iterators' ។
//! ការនិយាយឡើងវិញត្រូវបានប្រើយ៉ាងខ្លាំងក្នុងកូដ Rust idiomatic, ដូច្នេះវាមានតម្លៃក្លាយស៊ាំជាមួយពួកគេ។
//!
//! មុនពេលការពន្យល់ជាច្រើនទៀត, សូមនិយាយអំពីរបៀបម៉ូឌុលនេះត្រូវបានរៀបចំឡើង:
//!
//! # Organization
//!
//! ម៉ូឌុលនេះត្រូវបានរៀបចំយ៉ាងធំដោយប្រភេទ:
//!
//! * [Traits] នេះគឺជាផ្នែកស្នូល: traits ទាំងនេះកំណត់អ្វីដែលប្រភេទនៃការនិយាយឡើងវិញមាននិងអ្វីដែលអ្នកអាចធ្វើបានជាមួយពួកគេ។វិធីសាស្រ្តនៃ traits ទាំងនេះមានតម្លៃដាក់បន្ថែមមួយចំនួនពេលចូលទៅក្នុងការសិក្សា។
//! * [Functions] ផ្តល់នូវវិធីមានប្រយោជន៍មួយចំនួនដើម្បីបង្កើតទ្រនាប់ទ្រនាប់មូលដ្ឋានមួយចំនួន។
//! * [Structs] ជាញឹកញាប់គឺជាប្រភេទត្រឡប់មកវិញនៃវិធីសាស្រ្តផ្សេងគ្នានៅលើ traits របស់ម៉ូឌុលនេះ។ជាធម្មតាអ្នកនឹងចង់មើលនៅក្នុងវិធីសាស្រ្តដែលបង្កើតបាន `struct` ជាជាង `struct` ខ្លួនវាផ្ទាល់។
//! សម្រាប់លម្អិតបន្ថែមអំពីហេតុអ្វីបានជាសូមមើល '[អនុវត្តការនិយាយឡើងវិញ](#អនុវត្ត-បម្រុង) ។
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! នោះហើយជាវា!ជីកចូលទៅក្នុងការនិយាយឡើងវិញចូរ។
//!
//! # Iterator
//!
//! បេះដូងនិងព្រលឹងនៃម៉ូឌុលនេះគឺជា [`Iterator`] trait ។ស្នូលនៃ [`Iterator`] ដែលមើលទៅដូចនេះ:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! បម្រុងមួយមានវិធីសាស្រ្តមួយ [`next`] ដែលនៅពេលគេហៅថា, ត្រឡប់ជា [`Option`]`<Item>`។
//! [`next`] នឹងត្រឡប់ [`Some(Item)`] ដែលវែងដូចដែលមានធាតុ, ហើយនៅពេលដែលពួកគេទាំងអស់គ្នាបាន exhausted, នឹងត្រឡប់ `None` ដើម្បីចង្អុលបង្ហាញថាការនិយាយឡើងវិញត្រូវបានបញ្ចប់។
//! ការនិយាយឡើងវិញជាលក្ខណៈបុគ្គលអាចជ្រើសរើសដើម្បីបន្តការនិយាយឡើងវិញ, ហើយដូច្នេះការហៅ [`next`] ជាថ្មីម្តងទៀតអាចឬមិនអាចនៅទីបំផុតបានចាប់ផ្តើមវិលត្រឡប់មក [`Some(Item)`] ជាថ្មីម្តងទៀតនៅចំណុចមួយចំនួន (ឧទាហរណ៍សូមមើល [`TryIter`]) ។
//!
//!
//! និយមន័យការពេញលេញ [`Iterator`] 's បានរួមបញ្ចូលទាំងចំនួននៃវិធីសាស្រ្តផ្សេងទៀតផងដែរប៉ុន្តែពួកគេមានវិធីសាស្រ្តលំនាំដើម, បានកសាងឡើងនៅលើកំពូលនៃ [`next`] និងដូច្នេះអ្នកទទួលពួកគេដោយឥតគិតថ្លៃ។
//!
//! ការនិយាយឡើងវិញគឺជាអ្នកនិពន្ធទំនុកភ្លេងផងដែរហើយវាជារឿងធម្មតាទៅខ្សែសង្វាក់របស់ពួកគេរួមគ្នាក្នុងការធ្វើទម្រង់ស្មុគស្មាញបន្ថែមទៀតនៃដំណើរការ។សូមមើលផ្នែក [Adapters](#adapters) ខាងក្រោមសម្រាប់ព័ត៌មានលម្អិត។
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # ទម្រង់នៃការនិយាយឡើងវិញបី
//!
//! មានវិធីសាស្រ្តទូទៅចំនួនបីដែលអាចបង្កើតការនិយាយឡើងវិញពីការប្រមូលផ្ដុំមួយគឺ:
//!
//! * `iter()`, ដែល iterates ជាង `&T` ។
//! * `iter_mut()`, ដែលមានចំនួនលើស `&mut T` ។
//! * `into_iter()`, ដែល iterates ជាង `T` ។
//!
//! រឿងផ្សេងគ្នានៅក្នុងបណ្ណាល័យស្ដង់ដារអាចអនុវត្តមួយឬច្រើននៃការទាំងបីនេះ, ដែលជាកន្លែងដែលសមស្រប។
//!
//! # អនុវត្តការនិយាយឡើងវិញ
//!
//! បង្កើតបម្រុងផ្ទាល់ខ្លួនរបស់អ្នកជាមួយជាប់ពាក់ព័ន្ធនឹងជំហានពីរ: ការបង្កើត `struct` មួយទៅកាន់រដ្ឋបម្រុងនេះនិងបន្ទាប់មកអនុវត្ត [`Iterator`] សម្រាប់ `struct` នោះ។
//! នេះជាមូលហេតុដែលមានជាច្រើនដូច្នេះ: struct`s ក្នុងម៉ូឌុលនេះគឺមានម្នាក់សម្រាប់ iterator គ្នានិងអាដាប់ធ័របម្រុង។
//!
//! ចូរធ្វើឱ្យបម្រុងម្នាក់ឈ្មោះ `Counter` ដែលរាប់ពី `1` ទៅ `5`:
//!
//! ```
//! // ដំបូង struct នេះ:
//!
//! /// បម្រុងដែលរាប់ចំនួនពីមួយទៅប្រាំ
//! struct Counter {
//!     count: usize,
//! }
//!
//! // យើងចង់អោយការរាប់របស់យើងចាប់ផ្តើមនៅមួយដូច្នេះសូមបន្ថែមវិធីសាស្ត្រ new() ដើម្បីជួយ។
//! // នេះគឺជាការមិនចាំបាច់ណាស់ណាទេប៉ុន្តែគឺជាការងាយស្រួល។
//! // ចំណាំថាយើងចាប់ផ្តើម `count` នៅសូន្យ, យើងនឹងមើលឃើញហេតុអ្វីបានជានៅក្នុងការអនុវត្ត `next()`'s ខាងក្រោម។
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // បន្ទាប់មកយើងបានអនុវត្ត `Iterator` សម្រាប់ `Counter` របស់យើង:
//!
//! impl Iterator for Counter {
//!     // យើងនឹងត្រូវបានរាប់ជាមួយ usize
//!     type Item = usize;
//!
//!     // next() ជាវិធីសាស្រ្តដែលបានទាមទារតែប៉ុណ្ណោះ
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // បង្កើនចំនួនរបស់យើង។នេះគឺជាមូលហេតុដែលយើងបានចាប់ផ្តើមនៅសូន្យ។
//!         self.count += 1;
//!
//!         // ពិនិត្យមើលថាតើយើងបានបញ្ចប់ការរាប់ហើយឬនៅ។
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // ហើយឥឡូវនេះយើងអាចប្រើវាបានហើយ!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! ការហៅ [`next`] វិធីនេះទទួលបានច្រំដែល។Rust មានបង្កើតដែលអាចហៅ [`next`] នៅលើបម្រុងរបស់អ្នករហូតដល់វាឈានដល់ `None` មួយ។សូមចូលទៅលើថាក្រោយ។
//!
//! ចំណាំផងដែរថា `Iterator` ផ្ដល់នូវការអនុវត្តនៃវិធីសាស្រ្តលំនាំដើមដូចជាការ `nth` និង `fold` ដែលហៅ `next` ខាងក្នុង។
//! ទោះយ៉ាងណាក៏ដោយវាក៏អាចសរសេរការអនុវត្តតាមវិធីសាស្រ្តដូចជា `nth` និង `fold` ប្រសិនបើអ្នកធ្វើវាអាចគណនាពួកវាកាន់តែមានប្រសិទ្ធភាពដោយមិនចាំបាច់ហៅ `next` ។
//!
//! # `for` រង្វិលជុំនិង `IntoIterator`
//!
//! វាក្យសម្ព័ន្ធ `for` Rust រង្វិលជុំរបស់គឺពិតជាស្ករសម្រាប់ការនិយាយឡើងវិញ។នេះគឺជាឧទាហរណ៍មូលដ្ឋាននៃ `for`៖
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! នេះនឹងបោះពុម្ពលេខមួយដល់លេខប្រាំនីមួយៗនៅលើបន្ទាត់ផ្ទាល់របស់ពួកគេ។ប៉ុន្តែអ្នកនឹងសម្គាល់ឃើញអ្វីមួយនៅទីនេះ: យើងមិនហៅអ្វីនៅលើ vector របស់យើងដើម្បីផលិតបម្រុងមួយ។អ្វីដែលផ្តល់ឱ្យ?
//!
//! វាមាន trait នៅក្នុងបណ្ណាល័យស្ដង់ដារសម្រាប់ការបម្លែងអ្វីចូលទៅក្នុងបម្រុងមួយ: [`IntoIterator`].
//! trait នេះមានវិធីសាស្រ្តមួយ [`into_iter`] ដែលបានបម្លែងវត្ថុដែលអនុវត្ត [`IntoIterator`] ចូលទៅក្នុងបម្រុងមួយ។
//! តោះក្រឡេកមើលថារង្វិលជុំ `for` ជាថ្មីម្តងទៀតនិងអ្វីដែលអ្នកជឿចងក្រងវាចូលទៅក្នុង:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust លុបចោលជាតិស្ករទៅក្នុងៈ
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! ដំបូងយើងហៅ `into_iter()` លើតម្លៃ។បន្ទាប់មកយើងបានផ្គូផ្គងនៅលើការនិយាយឡើងវិញដែលបានត្រឡប់មកវិញហើយបានហៅ [`next`] ម្ដងហើយរហូតដល់យើងមើលឃើញ `None` មួយ។
//! នៅចំណុចដែលថាយើងបាន `break` ចេញពីរង្វិលជុំនិង interact តធ្វើយើងកំពុងតែ។
//!
//! មាននៅទីនេះបន្តិចច្បាស់បន្ថែមទៀត: បណ្ណាល័យស្ដង់ដារមានការអនុវត្តគួរឱ្យចាប់អារម្មណ៍នៃការ [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! នៅក្នុងពាក្យផ្សេងទៀតទាំងអស់ [`Iterator`] បានអនុវត្ត [`IntoIterator`] ដោយគ្រាន់តែវិលត្រឡប់មកវិញដោយខ្លួនឯង។នេះមានន័យថារឿងពីរ:
//!
//! 1. ប្រសិនបើអ្នកសរសេរអក្សរ [`Iterator`] អ្នកអាចប្រើវាជាមួយរង្វិលជុំ `for` ។
//! 2. ប្រសិនបើអ្នកកំពុងបង្កើតការប្រមូលផ្ដុំ, ការអនុវត្ត [`IntoIterator`] សម្រាប់វានឹងអនុញ្ញាតឱ្យការប្រមូលផ្ដុំរបស់អ្នកនឹងត្រូវបានប្រើជាមួយរង្វិលជុំ `for` ។
//!
//! # Iterating ដោយយោង
//!
//! ចាប់តាំងពីពេល [`into_iter()`] ចំណាយពេល `self` ដោយតម្លៃប្រើរង្វិលជុំ `for` ដើម្បីអន្តរកម្មលើការប្រមូលបំផ្លាញមួយដែលប្រមូល។ជារឿយៗអ្នកប្រហែលជាចង់និយាយអំពីការប្រមូលផ្តុំដោយមិនប្រើវា។
//! ផ្តល់ជូននូវវិធីសាស្រ្តក្នុងការប្រមូលជាច្រើនបានផ្តល់នូវការនិយាយឡើងវិញលើការដែលថាសេចក្តីយោង, conventionally បានហៅ `iter()` និង `iter_mut()` រៀង:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` នៅតែគ្រប់គ្រងដោយមុខងារនេះ។
//! ```
//!
//! ប្រសិនបើប្រភេទសម្រាំង `C` ផ្តល់ `iter()` វាក៏អនុវត្តតាម `IntoIterator` សម្រាប់ `&C` ផងដែរជាមួយនឹងការអនុវត្តដែលគ្រាន់តែហៅថា `iter()` ។
//! ដូចគ្នានេះដែរការប្រមូលផ្ដុំ `C` ដែលផ្តល់នូវ `iter_mut()` ជាទូទៅអនុវត្ត `IntoIterator` សម្រាប់ `&mut C` ដោយប្រគល់ទៅឱ្យ `iter_mut()` ។នេះអាចជួយឱ្យខ្លី:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // ដូចគ្នានឹង `values.iter_mut()` ដែរ
//!     *x += 1;
//! }
//! for x in &values { // ដូចគ្នានឹង `values.iter()` ដែរ
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! ខណៈពេលដែលការប្រមូលជាច្រើនផ្តល់ជូន `iter()` មិនមែនទាំងអស់ផ្តល់ជូន `iter_mut()` ទេ។
//! ឧទាហរណ៍ផ្លាស់ប្ដូរកូនសោ [`HashSet<T>`] ឬ [`HashMap<K, V>`] អាចដាក់ចូលទៅក្នុងរដ្ឋការប្រមូលប្រសិនបើមិនជាប់លាប់នេះ hashes ការផ្លាស់ប្តូរសំខាន់, ដូច្នេះការប្រមូលតែមួយគត់ដែលផ្តល់ជូន `iter()` ទាំងនេះ។
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! មុខងារដែលបានយក [`Iterator`] មួយផ្សេងទៀតនិងត្រឡប់ [`Iterator`] ត្រូវបានគេហៅជាញឹកញាប់ "អាដាប់ទ័របម្រុង", ដូចជាពួកគេមានទម្រង់បែបបទនៃ 'អាដាប់ធ័រមួយ
//! pattern'.
//!
//! អាដាប់ទ័រទ្រនាប់រួមមាន [`map`], [`take`], និង [`filter`] ។
//! សម្រាប់ព័ត៌មានបន្ថែមសូមមើលឯកសាររបស់ពួកគេ។
//!
//! ប្រសិនបើមានអាដាប់ធ័រ panics មួយកន្លែងបម្រុង, បម្រុងនឹងមាននៅក្នុងរដ្ឋមួយដែលមិនបានបញ្ជាក់ (ប៉ុន្តែមានសុវត្ថិភាពក្នុងការចងចាំ) ។
//! រដ្ឋនេះត្រូវបានគេផងដែរមិនត្រូវបានធានាឱ្យស្នាក់នៅដូចគ្នានេះដែរនៅទូទាំងកំណែនៃ Rust, ដូច្នេះអ្នកគួរតែជៀសវាងការពឹងផ្អែកលើតម្លៃពិតប្រាកដដែលបានត្រឡប់ដោយបម្រុងដែលបានភ័យស្លន់ស្លោមួយ។
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! ការនិយាយឡើងវិញ (និង [adapters](#adapters)) បម្រុងមាន * * ខ្ជិល។ នេះមានន័យថាគ្រាន់តែបង្កើត iterator មិន _do_ ជាច្រើនទាំងមូល។ គ្មានអ្វីកើតឡើងពិតជាបានរហូតដល់អ្នកហៅ [`next`] ។
//! ពេលខ្លះនេះគឺជាប្រភពនៃការភាន់ច្រលំនៅពេលបង្កើតទ្រនាប់ទ្រនាប់តែមួយគត់សម្រាប់ផលប៉ះពាល់របស់វា។
//! ឧទាហរណ៍វិធីសាស្ត្រ [`map`] ហៅការបិទលើធាតុនីមួយៗដែលវាមានៈ
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! ការនេះនឹងមិនត្រូវបានបោះពុម្ពតម្លៃណាមួយ, ដូចដែលយើងបានបង្កើតឡើងតែប៉ុណ្ណោះបម្រុងមួយជាជាងការប្រើប្រាស់វា។អ្នកចងក្រងនឹងព្រមានយើងអំពីឥរិយាបទប្រភេទនេះ៖
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! វិធីដើម្បីសរសេរ [`map`] idiomatic មួយសម្រាប់ផលប៉ះពាល់របស់ខ្លួនគឺដើម្បីប្រើរង្វិលជុំ `for` ឬហៅវិធីសាស្ដ្រ [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! វិធីទូទៅមួយផ្សេងទៀតដើម្បីវាយតម្លៃបម្រុងមួយគឺត្រូវប្រើវិធីសាស្រ្ត [`collect`] ដើម្បីផលិតជាការប្រមូលថ្មី។
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! ឧបករណ៍បំលែងមិនចាំបាច់មានកំណត់ទេ។ជាឧទាហរណ៍ជួរដែលបានបើកចំហគឺជាអ្នកតំរូវការគ្មានកំណត់៖
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! វាជារឿងធម្មតាក្នុងការប្រើអាដាប់ធ័របម្រុង [`take`] ដើម្បីបើកមួយទៅជាគ្មានដែនកំណត់បម្រុងមួយដែលមានកម្រិត:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! ការនេះនឹងបោះពុម្ពចំនួនដែល `0` តាមរយៈ `4`, នៅលើបន្ទាត់ផ្ទាល់របស់ពួកគេ។
//!
//! សូមចងចាំថាវិធីសាស្រ្តនៅលើឧបករណ៍វាស់គ្មានកំណត់សូម្បីតែលទ្ធផលដែលលទ្ធផលអាចត្រូវបានកំណត់គណិតវិទ្យាតាមពេលវេលាកំណត់ក៏មិនអាចបញ្ចប់បានដែរ។
//! ជាពិសេសវិធីសាស្រ្តដូចជាការ [`min`], ដែលនៅក្នុងករណីទូទៅតម្រូវឱ្យឆ្លងកាត់តំបន់នេះជារៀងរាល់ធាតុនៅក្នុងការនិយាយឡើងវិញគឺទំនងជាមិនទទួលបានជោគជ័យសម្រាប់ការដើម្បីត្រឡប់ណាមួយដែលគ្មានដែនកំណត់សារឡើងវិញ។
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // អូទេ!រង្វិលជុំមិនកំណត់!
//! // `ones.min()` បណ្តាលឱ្យរង្វិលជុំគ្មានកំណត់ដូច្នេះយើងនឹងមិនឈានដល់ចំណុចនេះទេ!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;