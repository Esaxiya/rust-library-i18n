use crate::{fmt, iter::FusedIterator};

/// បង្កើតថ្មីដែលធាតុបម្រុងគ្នាជាបន្តបន្ទាប់ដោយផ្អែកលើត្រូវបានគណនាមួយមុន។
///
/// ការនិយាយឡើងវិញចាប់ផ្តើមដោយធាតុដំបូងដែលបានផ្តល់ឱ្យ (ប្រសិនបើមាន) ហើយបានហៅការបិទ `FnMut(&T) -> Option<T>` ដែលបានផ្ដល់ឱ្យដើម្បីគណនាធាតុគ្នាស្នងតំណែង។
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // ប្រសិនបើមានមុខងារនេះបានវិលត្រឡប់មក `impl Iterator<Item=T>` វាអាចត្រូវបានផ្អែកលើ `unfold` និងមិនត្រូវការប្រភេទដែលខិតខំប្រឹងប្រែងមួយ។
    //
    // ទោះយ៉ាងណាការមានឈ្មោះប្រភេទ `Successors<T, F>` អនុញ្ញាតឱ្យវាក្លាយជា `Clone` នៅពេល `T` និង `F` ។
    Successors { next: first, succ }
}

/// ឧបករណ៍រំកិលថ្មីដែលធាតុបន្តបន្ទាប់នីមួយៗត្រូវបានគណនាផ្អែកលើធាតុមុន។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយមុខងារ [`iter::successors()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}