use crate::fmt;

/// បង្កើតថ្មីដែលនិយាយឡើងវិញបម្រុងការហៅបិទ `F: FnMut() -> Option<T>` គ្នាបានផ្តល់។
///
/// នេះអនុញ្ញាតឱ្យអ្នកបង្កើតផ្ទាល់ខ្លួនមួយដែលមានការបម្រុងឥរិយាបទណាមួយដោយមិនប្រើវាក្យសម្ព័ន្ធបរិយាយបន្ថែមទៀតនៃការបង្កើតប្រភេទដែលខិតខំប្រឹងប្រែងមួយនិងការអនុវត្ត [`Iterator`] trait សម្រាប់វា។
///
/// ចំណាំថា `FromFn` បម្រុងមិនបានធ្វើការស្មានអំពីឥរិយាបទនៃការបិទនេះហើយដូច្នេះអភិរក្សមិនអនុវត្ត [`FusedIterator`] ឬបដិសេធ [`Iterator::size_hint()`] ពី `(0, None)` លំនាំដើមរបស់ខ្លួន។
///
///
/// ការបិទនេះអាចប្រើចាប់យកនិងបរិស្ថានរបស់វាដើម្បីតាមដានរដ្ឋនៅទូទាំងអន្តរកម្ម។ដោយអាស្រ័យលើរបៀបដែលបម្រុងគឺត្រូវបានប្រើនេះអាចតម្រូវឱ្យមានការបញ្ជាក់ពាក្យគន្លឹះ [`move`] លើការបិទ។
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// ចូរឡើងវិញអនុវត្តការប្រឆាំងពី [module-level documentation] បម្រុង:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // បង្កើនចំនួនរបស់យើង។នេះគឺជាមូលហេតុដែលយើងបានចាប់ផ្តើមនៅសូន្យ។
///     count += 1;
///
///     // ពិនិត្យមើលថាតើយើងបានបញ្ចប់ការរាប់ហើយឬនៅ។
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// បម្រុងមួយដែលជាកន្លែងដែលការនិយាយឡើងវិញការហៅបិទ `F: FnMut() -> Option<T>` គ្នាបានផ្តល់។
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយមុខងារ [`iter::from_fn()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}