use crate::iter::{FusedIterator, TrustedLen};

/// បង្កើតថ្មីមួយដែលគ្មានទីបញ្ចប់បម្រុងធ្វើឡើងវិញធាតុតែមួយ។
///
/// មុខងារ `repeat()` តម្លៃតែមួយឡើងវិញម្ដងហើយម្ដងទៀត។
///
/// ការនិយាយឡើងវិញជាញឹកញាប់ក្រុម Infinite ដូច `repeat()` ជាមួយអាដាប់ទ័រត្រូវបានប្រើដូច [`Iterator::take()`] ក្នុងគោលបំណងដើម្បីធ្វើឱ្យពួកគេ finite ។
///
/// ប្រសិនបើមានធាតុអន្តរកម្មដែលអ្នកត្រូវការមិនបានអនុវត្ត `Clone` ឬប្រសិនបើអ្នកមិនចង់រក្សាធាតុម្តងហើយម្តងទៀតនៅក្នុងសតិ, អ្នកជំនួសវិញអាចប្រើមុខងារ [`repeat_with()`] ។
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::iter;
///
/// // លេខបួន ៤ នាក់៖
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // នៅសល់នៅតែបួន
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// នឹងកំណត់ជាមួយ [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // ថាឧទាហរណ៍ចុងក្រោយគឺបួនច្រើនពេក។តោះយើងមានតែបួនបួន។
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ហើយឥឡូវនេះយើងបានបញ្ចប់
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// បម្រុងមួយដែលធ្វើឡើងវិញធាតុជារៀងរហូត។
///
/// `struct` នេះត្រូវបានបង្កើតដោយអនុគមន៍ [`repeat()`] ។មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}