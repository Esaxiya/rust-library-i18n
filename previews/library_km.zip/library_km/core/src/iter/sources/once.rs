use crate::iter::{FusedIterator, TrustedLen};

/// បង្កើតទិន្នផលធាតុដែលបម្រុងមួយយ៉ាងច្បាស់នៅពេលដែលមួយ។
///
/// នេះត្រូវបានប្រើជាទូទៅដើម្បីសម្របតម្លៃតែមួយទៅជា [`chain()`] នៃប្រភេទនៃការនិយាយឡើងវិញ។
/// ប្រហែលជាអ្នកមានទ្រនាប់ដែលគ្របដណ្ដប់ស្ទើរតែទាំងអស់ប៉ុន្តែអ្នកត្រូវការករណីពិសេសបន្ថែម។
/// ប្រហែលជាអ្នកមានមុខងារមួយដែលដំណើរការលើវាប៉ុន្តែអ្នកត្រូវដំណើរការតែតម្លៃមួយប៉ុណ្ណោះ។
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::iter;
///
/// // មួយគឺចំនួនជាងគេ
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // គ្រាន់តែមួយ, នោះហើយជាអ្វីដែលយើងទទួលបាន
/// assert_eq!(None, one.next());
/// ```
///
/// ច្រវាក់រួមគ្នាជាមួយអ្នករំកិលមួយផ្សេងទៀត។
/// ឧបមាថាយើងចង់ iterate លើឯកសារនីមួយនៃការថត `.foo` ប៉ុណ្ណោះទេថែមឯកសារកំណត់រចនាសម្ព័ន្ធ,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // យើងត្រូវការដើម្បីបម្លែងពីកន្លែងបម្រុងនៃ DirEntry-s បានដើម្បីបម្រុងនៃ PathBufs ដូច្នេះយើងប្រើផែនទី
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ឥលូវនេះឧបករណ៍បំលែងរបស់យើងគឺសំរាប់ឯកសារកំណត់រចនាសម្ព័ន្ធរបស់យើង
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // ដាក់ច្រវាក់ទ្រនាប់ទ្រនាប់ទ្រនាប់ពីរបញ្ចូលគ្នាទៅជាឧបករណ៍ធ្វើចរន្តធំមួយ
/// let files = dirs.chain(config);
///
/// // នេះនឹងផ្តល់ឱ្យយើងទាំងអស់របស់ឯកសារនៅក្នុង .foo ព្រមទាំង .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// ឧបករណ៍រំកិលដែលផ្តល់ទិន្នផលធាតុមួយយ៉ាងពិតប្រាកដ។
///
/// `struct` នេះត្រូវបានបង្កើតដោយអនុគមន៍ [`once()`] ។សូមមើលឯកសាររបស់វាចំពោះបន្ថែមទៀត។
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}