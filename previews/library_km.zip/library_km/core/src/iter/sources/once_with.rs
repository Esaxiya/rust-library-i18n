use crate::iter::{FusedIterator, TrustedLen};

/// បង្កើត iterator ថា lazily បង្កើតតម្លៃមួយយ៉ាងពិតប្រាកដនៅពេលដែលបានផ្តល់ដោយហៅការបិទនេះ។
///
/// នេះត្រូវបានគេប្រើជាទូទៅដើម្បីសម្របខ្លួនម៉ាស៊ីនភ្លើងតម្លៃតែមួយចូលទៅក្នុង [`chain()`] នៃប្រភេទដទៃទៀតនៃការនិយាយឡើងវិញបាន។
/// ប្រហែលជាអ្នកមានទ្រនាប់ដែលគ្របដណ្ដប់ស្ទើរតែទាំងអស់ប៉ុន្តែអ្នកត្រូវការករណីពិសេសបន្ថែម។
/// ប្រហែលជាអ្នកមានមុខងារមួយដែលដំណើរការលើវាប៉ុន្តែអ្នកត្រូវដំណើរការតែតម្លៃមួយប៉ុណ្ណោះ។
///
/// មិនដូច [`once()`] ទេមុខងារនេះនឹងបង្កើតតម្លៃតាមសំណើរ។
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::iter;
///
/// // មួយគឺចំនួនជាងគេ
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // គ្រាន់តែមួយ, នោះហើយជាអ្វីដែលយើងទទួលបាន
/// assert_eq!(None, one.next());
/// ```
///
/// ច្រវាក់រួមគ្នាជាមួយអ្នករំកិលមួយផ្សេងទៀត។
/// ឧបមាថាយើងចង់ iterate លើឯកសារនីមួយនៃការថត `.foo` ប៉ុណ្ណោះទេថែមឯកសារកំណត់រចនាសម្ព័ន្ធ,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // យើងត្រូវការដើម្បីបម្លែងពីកន្លែងបម្រុងនៃ DirEntry-s បានដើម្បីបម្រុងនៃ PathBufs ដូច្នេះយើងប្រើផែនទី
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ឥលូវនេះឧបករណ៍បំលែងរបស់យើងគឺសំរាប់ឯកសារកំណត់រចនាសម្ព័ន្ធរបស់យើង
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // ដាក់ច្រវាក់ទ្រនាប់ទ្រនាប់ទ្រនាប់ពីរបញ្ចូលគ្នាទៅជាឧបករណ៍ធ្វើចរន្តធំមួយ
/// let files = dirs.chain(config);
///
/// // នេះនឹងផ្តល់ឱ្យយើងទាំងអស់របស់ឯកសារនៅក្នុង .foo ព្រមទាំង .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// មួយដែល yields បម្រុងធាតុតែមួយនៃប្រភេទ `A` ដោយអនុវត្តការបិទបានផ្តល់ `F: FnOnce() -> A` ។
///
///
/// `struct` នេះត្រូវបានបង្កើតឡើងដោយមុខងារ [`once_with()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}