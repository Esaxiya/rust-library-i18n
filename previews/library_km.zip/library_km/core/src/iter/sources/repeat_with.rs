use crate::iter::{FusedIterator, TrustedLen};

/// បង្កើតបម្រុងធាតុថ្មីមួយដែលធ្វើឡើងវិញនៃប្រភេទ `A` គ្មានទីបញ្ចប់ដោយអនុវត្តការបិទដែលបានផ្ដល់, ម្តងទៀត, `F: FnMut() -> A`.
///
/// មុខងារ `repeat_with()` ហៅអ្នកធ្វើម្តងហើយម្តងទៀត។
///
/// ការនិយាយឡើងវិញជាញឹកញាប់ក្រុម Infinite ដូច `repeat_with()` ជាមួយអាដាប់ទ័រត្រូវបានប្រើដូច [`Iterator::take()`] ក្នុងគោលបំណងដើម្បីធ្វើឱ្យពួកគេ finite ។
///
/// ប្រសិនបើប្រភេទធាតុនៃទ្រនាប់ដែលអ្នកត្រូវការឧបករណ៍ [`Clone`] ហើយវាមិនអីទេដើម្បីរក្សាធាតុប្រភពនៅក្នុងសតិអ្នកគួរតែប្រើមុខងារ [`repeat()`] ជំនួសវិញ។
///
///
/// បម្រុងផលិតដោយ `repeat_with()` គឺមិនមែនជា [`DoubleEndedIterator`] មួយ។
/// ប្រសិនបើអ្នកត្រូវការ `repeat_with()` ដើម្បីប្រគល់ [`DoubleEndedIterator`] សូមបើកបញ្ហា GitHub ពន្យល់អំពីករណីប្រើប្រាស់របស់អ្នក។
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::iter;
///
/// // សូមសន្មតថាយើងមានតម្លៃមួយចំនួននៃប្រភេទមួយដែលមិនមែនជា `Clone` ឬដែលមិនចង់មាននៅក្នុងការចងចាំគ្រាន់តែដោយសារតែវាមានតម្លៃថ្លៃ:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // តម្លៃពិសេសជារៀងរហូត:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// ការប្រើការផ្លាស់ប្តូរនិងការនឹងកំណត់:
///
/// ```rust
/// use std::iter;
///
/// // ពី zeroth ដើម្បីអំណាចទីបីនៃការទាំងពីរនេះ:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ហើយឥឡូវនេះយើងបានបញ្ចប់
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// ឧបករណ៍រំកិលដែលធ្វើម្តងទៀតនូវធាតុនៃប្រភេទ `A` មិនចេះចប់ដោយអនុវត្តការបិទ `F: FnMut() -> A` ដែលបានផ្តល់។
///
///
/// `struct` នេះត្រូវបានបង្កើតដោយអនុគមន៍ [`repeat_with()`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}