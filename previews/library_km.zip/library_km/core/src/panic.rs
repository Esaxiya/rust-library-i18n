//! ការគាំទ្រ Panic នៅក្នុងបណ្ណាល័យស្តង់ដារ។

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// រចនាសម្ព័ន្ធផ្តល់ព័ត៌មានអំពី panic ។
///
/// `PanicInfo` រចនាសម្ព័ន្ធត្រូវបានបញ្ជូនទៅ panic hook កំណត់ដោយមុខងារ [`set_hook`] ។
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// ត្រឡប់បន្ទុកដែលជាប់ទាក់ទងជាមួយ panic ។
    ///
    /// នេះនឹងជាទូទៅប៉ុន្តែមិនមែនជានិច្ចទេគឺជា `&'static str` ឬ [`String`] ។
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// ប្រសិនបើម៉ាក្រូ `panic!` ពី `core` crate (មិនមែនមកពី `std`) ត្រូវបានប្រើជាមួយខ្សែអក្សរធ្វើទ្រង់ទ្រាយនិងអាគុយម៉ង់បន្ថែមមួយចំនួនត្រឡប់សារនោះរួចរាល់ដើម្បីប្រើឧទាហរណ៍ជាមួយ [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// ត្រឡប់អំពីទីតាំងដែល panic ស្លោក, បើអាចរកបាន។
    ///
    /// វិធីសាស្រ្តនេះនឹងត្រឡប់ [`Some`] ជានិច្ចប៉ុន្តែនេះអាចផ្លាស់ប្តូរនៅក្នុងកំណែ future ។
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: ប្រសិនបើវាត្រូវបានផ្លាស់ប្តូរពេលខ្លះត្រឡប់ទៅគ្មានវិញ,
        // ដោះស្រាយករណីនោះក្នុង std::panicking::default_hook និង std::panicking::begin_panic_fmt ។
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: យើងមិនអាចប្រើ downcast_ref: :<String>() នៅទីនេះ
        // ចាប់តាំងពីខ្សែអក្សរគឺមិនអាចប្រើបាននៅក្នុង libcore!
        // បន្ទុកគឺខ្សែអក្សរនៅពេល `std::panic!` ត្រូវបានហៅដោយមានអាគុយម៉ង់ច្រើនប៉ុន្តែក្នុងករណីនោះសារក៏មានផងដែរ។
        //

        self.location.fmt(formatter)
    }
}

/// រចនាសម្ព័នដែលមានព័ត៌មានអំពីទីតាំងរបស់ហ្សហ្ស៊ីនភីស៊ីហ្សិច។
///
/// រចនាសម្ព័ន្ធនេះត្រូវបានបង្កើតឡើងដោយ [`PanicInfo::location()`] ។
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// ការប្រៀបធៀបសម្រាប់ភាពស្មើគ្នានិងការរៀបតាមលំដាប់លំដោយត្រូវបានធ្វើឡើងជាឯកសារជួរបន្ទាប់មកអាទិភាពជួរឈរ។
/// ឯកសារត្រូវបានប្រៀបធៀបជាខ្សែមិនមែន `Path` ទេដែលអាចមិននឹកស្មានដល់។
/// មើលឯកសារ [`ទីតាំង: : ឯកសារ`] សម្រាប់ការពិភាក្សាបន្ថែម។
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// ត្រឡប់ទីតាំងប្រភពរបស់អ្នកហៅទូរស័ព្ទនៃមុខងារនេះ។
    /// ប្រសិនបើអ្នកហៅមុខងារនោះត្រូវបានកត់ចំណាំនោះទីតាំងហៅរបស់វានឹងត្រូវបានបញ្ជូនត្រឡប់មកវិញហើយបន្តជង់ទៅការហៅដំបូងនៅក្នុងតួមុខងារដែលមិនបានតាមដាន។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// ត្រឡប់ [`Location`] ដែលវាត្រូវបានគេហៅថា។
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// ត្រឡប់ [`Location`] ពីក្នុងនិយមន័យមុខងារនេះ។
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // ដំណើរការមុខងារដែលមិនត្រូវបានគេប្រើនៅក្នុងទីតាំងផ្សេងគ្នាផ្តល់ឱ្យយើងនូវលទ្ធផលដូចគ្នា
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ដំណើរការមុខងារដែលបានតាមដាននៅក្នុងទីតាំងផ្សេងគ្នាបង្កើតតម្លៃខុសគ្នា
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// ត្រឡប់ឈ្មោះឯកសារប្រភពដែល panic មានដើមកំណើត។
    ///
    /// # `&str`, មិនមែន `&Path`
    ///
    /// ឈ្មោះដែលបានត្រឡប់មកវិញសំដៅទៅលើផ្លូវប្រភពមួយនៅលើប្រព័ន្ធចងក្រងប៉ុន្តែវាមិនមានសុពលភាពក្នុងការតំណាងវាដោយផ្ទាល់ជា `&Path` ទេ។
    /// លេខកូដដែលបានចងក្រងអាចដំណើរការលើប្រព័ន្ធផ្សេងគ្នាជាមួយនឹងការអនុវត្ត `Path` ខុសពីប្រព័ន្ធដែលផ្តល់មាតិកាហើយបណ្ណាល័យនេះបច្ចុប្បន្នមិនមានប្រភេទ "host path" ខុសគ្នាទេ។
    ///
    /// អាកប្បកិរិយាគួរឱ្យភ្ញាក់ផ្អើលបំផុតកើតឡើងនៅពេលឯកសារ "the same" អាចចូលបានតាមរយៈផ្លូវជាច្រើននៅក្នុងប្រព័ន្ធម៉ូឌុល (ជាទូទៅប្រើគុណលក្ខណៈ `#[path = "..."]` ឬស្រដៀងគ្នា) ដែលអាចបណ្តាលឱ្យអ្វីដែលហាក់ដូចជាកូដដូចគ្នានឹងត្រឡប់តម្លៃខុសគ្នាពីមុខងារនេះ។
    ///
    ///
    /// # Cross-compilation
    ///
    /// តម្លៃនេះមិនសមស្របសម្រាប់ការបញ្ជូនទៅ `Path::new` ឬអ្នកសាងសង់ស្រដៀងគ្នានៅពេលវេទិកាម៉ាស៊ីននិងវេទិកាគោលដៅខុសគ្នា។
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// ត្រឡប់លេខបន្ទាត់ដែល panic មានដើមកំណើត។
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// ត្រឡប់ជួរឈរដែល panic មានដើមកំណើត។
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// ផ្ទៃក្នុង trait ត្រូវបានប្រើដោយ libstd ដើម្បីបញ្ជូនទិន្នន័យពី libstd ទៅ `panic_unwind` និងពេលរត់ panic ផ្សេងទៀត។
/// មិនមានបំណងឱ្យមានស្ថេរភាពនៅពេលណាមួយឆាប់ៗកុំប្រើ។
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// ទទួលយកកម្មសិទ្ធិពេញលេញនៃមាតិកា។
    /// ប្រភេទត្រឡប់មកវិញគឺពិតជា `Box<dyn Any + Send>` ប៉ុន្តែយើងមិនអាចប្រើ `Box` នៅក្នុង libcore ទេ។
    ///
    /// បន្ទាប់ពីវិធីសាស្រ្តនេះត្រូវបានគេហៅថាមានតែតម្លៃដើមអត់ចេះសោះមួយចំនួនដែលត្រូវបានទុកចោលនៅក្នុង `self` ។
    /// ការហៅវិធីសាស្ត្រនេះពីរដងឬហៅទូរស័ព្ទ `get` បន្ទាប់ពីហៅវិធីសាស្ត្រនេះគឺជាកំហុសមួយ។
    ///
    /// អាគុយម៉ង់ត្រូវបានខ្ចីដោយសារតែ panic ពេលរត់ (`__rust_start_panic`) ទទួលបានតែ `dyn BoxMeUp` ប៉ុណ្ណោះ។
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// គ្រាន់តែខ្ចីមាតិកា។
    fn get(&mut self) -> &(dyn Any + Send);
}