//! ការគាំទ្រ hashing ដែលទូទៅ។
//!
//! ម៉ូឌុលនេះផ្តល់នូវវិធីទូទៅក្នុងការគណនា [hash] នៃតម្លៃ។
//! ហាស់ត្រូវបានប្រើភាគច្រើនបំផុតជាទូទៅជាមួយ [`HashMap`] និង [`HashSet`] ។
//!
//! [hash]: https://en.wikipedia.org/wiki/Hash_function
//! [`HashMap`]: ../../std/collections/struct.HashMap.html
//! [`HashSet`]: ../../std/collections/struct.HashSet.html
//!
//! វិធីសាមញ្ញបំផុតដើម្បីធ្វើឱ្យប្រភេទ hashable មួយគឺត្រូវប្រើ `#[derive(Hash)]`:
//!
//! # Examples
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! #[derive(Hash)]
//! struct Person {
//!     id: u32,
//!     name: String,
//!     phone: u64,
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert!(calculate_hash(&person1) != calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```
//!
//! ប្រសិនបើអ្នកត្រូវការការត្រួតពិនិត្យបន្ថែមទៀតអំពីរបៀបដែលតម្លៃត្រូវបានធ្វើឱ្យប្រសើរឡើងអ្នកត្រូវអនុវត្ត [`Hash`] trait៖
//!
//!
//! ```rust
//! use std::collections::hash_map::DefaultHasher;
//! use std::hash::{Hash, Hasher};
//!
//! struct Person {
//!     id: u32,
//!     # #[allow(dead_code)]
//!     name: String,
//!     phone: u64,
//! }
//!
//! impl Hash for Person {
//!     fn hash<H: Hasher>(&self, state: &mut H) {
//!         self.id.hash(state);
//!         self.phone.hash(state);
//!     }
//! }
//!
//! let person1 = Person {
//!     id: 5,
//!     name: "Janet".to_string(),
//!     phone: 555_666_7777,
//! };
//! let person2 = Person {
//!     id: 5,
//!     name: "Bob".to_string(),
//!     phone: 555_666_7777,
//! };
//!
//! assert_eq!(calculate_hash(&person1), calculate_hash(&person2));
//!
//! fn calculate_hash<T: Hash>(t: &T) -> u64 {
//!     let mut s = DefaultHasher::new();
//!     t.hash(&mut s);
//!     s.finish()
//! }
//! ```

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::marker;

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use self::sip::SipHasher;

#[unstable(feature = "hashmap_internals", issue = "none")]
#[allow(deprecated)]
#[doc(hidden)]
pub use self::sip::SipHasher13;

mod sip;

/// ប្រភេទដែលអាចដកបាន។
///
/// ប្រភេទនៃការអនុវត្ត `Hash` អាចក្លាយជា [`hash]] ជាមួយនឹងឧទាហរណ៍នៃ [`Hasher`] ។
///
/// ## អនុវត្ត `Hash`
///
/// អ្នកអាចទាញយក `Hash` ជាមួយ `#[derive(Hash)]` ប្រសិនបើវាលទាំងអស់អនុវត្ត `Hash` ។
/// នេះជាលទ្ធផលនឹងជាសញ្ញានៃតម្លៃដែលបានបញ្ចូលគ្នាពីការហៅទូរស័ព្ទ [`hash`] នេះនៅលើវាលគ្នា។
///
/// ```
/// #[derive(Hash)]
/// struct Rustacean {
///     name: String,
///     country: String,
/// }
/// ```
///
/// ប្រសិនបើអ្នកត្រូវការត្រួតពិនិត្យបន្ថែមលើរបៀបដែលត្រូវបាន hashed តម្លៃ, អ្នកអាចជាការពិតណាស់អនុវត្ត `Hash` trait ខ្លួនឯង:
///
/// ```
/// use std::hash::{Hash, Hasher};
///
/// struct Person {
///     id: u32,
///     name: String,
///     phone: u64,
/// }
///
/// impl Hash for Person {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         self.id.hash(state);
///         self.phone.hash(state);
///     }
/// }
/// ```
///
/// ## `Hash` និង `Eq`
///
/// នៅពេលអនុវត្តទាំង `Hash` និង [`Eq`] វាជាការសំខាន់ដែលទ្រព្យសម្បត្តិខាងក្រោមមានៈ
///
/// ```text
/// k1 == k2 -> hash(k1) == hash(k2)
/// ```
///
/// និយាយម៉្យាងទៀតប្រសិនបើកូនសោពីរស្មើគ្នានោះរបាំងរបស់ពួកគេក៏ត្រូវតែស្មើគ្នាដែរ។
/// [`HashMap`] និង [`HashSet`] ទាំងពីរពឹងផ្អែកលើឥរិយាបថនេះ។
///
/// អរគុណណាស់អ្នកមិនចាំបាច់ព្រួយបារម្ភអំពីការទ្រទ្រង់ទ្រព្យសម្បត្តិនេះនៅពេលទទួលបានទាំង [`Eq`] និង `Hash` ជាមួយ `#[derive(PartialEq, Eq, Hash)]` ។
///
///
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [`hash`]: Hash::hash
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hash {
    /// Feeds តម្លៃទៅ [`Hasher`] ដែលបានផ្ដល់ឱ្យនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// 7920.hash(&mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn hash<H: Hasher>(&self, state: &mut H);

    /// បញ្ចូលចំណែកមួយនៃប្រភេទនេះទៅក្នុង [`Hasher`] ដែលបានផ្តល់ឱ្យ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::{Hash, Hasher};
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let numbers = [6, 28, 496, 8128];
    /// Hash::hash_slice(&numbers, &mut hasher);
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "hash_slice", since = "1.3.0")]
    fn hash_slice<H: Hasher>(data: &[Self], state: &mut H)
    where
        Self: Sized,
    {
        for piece in data {
            piece.hash(state);
        }
    }
}

// ម៉ូឌុលដាច់ដោយឡែកដើម្បីបញ្ជាក់ម៉ាក្រូ `Hash` ពី prelude ដោយគ្មាន trait `Hash` ។
pub(crate) mod macros {
    /// ម៉ាក្រូដេរីវេបង្កើត impl នៃ trait `Hash` មួយ។
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Hash($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Hash;

/// trait សម្រាប់ធ្វើឱ្យស្ទ្រីមបណ្តែតតាមអំពើចិត្ត។
///
/// ករណី `Hasher` ធម្មតាតំណាងឱ្យរដ្ឋដែលត្រូវបានប្តូរខណៈពេលដែលការធ្វើឱ្យខូចទិន្នន័យ។
///
/// `Hasher` ផ្តល់នូវចំណុចប្រទាក់មូលដ្ឋានត្រឹមត្រូវសម្រាប់ការយកមកវិញនូវហាសដែលបានបង្កើត (ជាមួយ [`finish`]) និងការសរសេរលេខគត់ក៏ដូចជាចំណុះបៃទៅជាឧទាហរណ៍ (ជាមួយ [`write`] និង [`write_u8`] ។ ល។) ។
/// ភាគច្រើននៃពេលវេលា, ករណី `Hasher` ត្រូវបានប្រើនៅក្នុងការភ្ជាប់ជាមួយ [`Hash`] trait ។
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::Hasher;
///
/// let mut hasher = DefaultHasher::new();
///
/// hasher.write_u32(1989);
/// hasher.write_u8(11);
/// hasher.write_u8(9);
/// hasher.write(b"Huh?");
///
/// println!("Hash is {:x}!", hasher.finish());
/// ```
///
/// [`finish`]: Hasher::finish
/// [`write`]: Hasher::write
/// [`write_u8`]: Hasher::write_u8
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Hasher {
    /// ត្រឡប់តម្លៃហាសសម្រាប់តម្លៃដែលបានសរសេរមកទល់ពេលនេះ។
    ///
    /// បើទោះជាឈ្មោះរបស់ខ្លួន, វិធីសាស្រ្តនេះមិនបានកំណត់ឡើងវិញរដ្ឋផ្ទៃក្នុង hasher នេះ។
    /// បន្ថែម [`សរសេរ`] នឹងបន្តពីតម្លៃបច្ចុប្បន្ន។
    /// បើអ្នកត្រូវការដើម្បីចាប់ផ្តើមតម្លៃសញ្ញាមួយស្រស់, អ្នកនឹងមានដើម្បីបង្កើត hasher ថ្មី។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// hasher.write(b"Cool!");
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    ///
    /// [`write`]: Hasher::write
    #[stable(feature = "rust1", since = "1.0.0")]
    fn finish(&self) -> u64;

    /// សរសេរទិន្នន័យមួយចំនួនចូលទៅក្នុង `Hasher` នេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::DefaultHasher;
    /// use std::hash::Hasher;
    ///
    /// let mut hasher = DefaultHasher::new();
    /// let data = [0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef];
    ///
    /// hasher.write(&data);
    ///
    /// println!("Hash is {:x}!", hasher.finish());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write(&mut self, bytes: &[u8]);

    /// សរសេរ `u8` តែមួយទៅក្នុងឧបករណ៍នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u8(&mut self, i: u8) {
        self.write(&[i])
    }
    /// សរសេរ `u16` តែមួយចូលទៅក្នុង hasher នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u16(&mut self, i: u16) {
        self.write(&i.to_ne_bytes())
    }
    /// សរសេរ `u32` តែមួយទៅក្នុងឧបករណ៍នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u32(&mut self, i: u32) {
        self.write(&i.to_ne_bytes())
    }
    /// សរសេរ `u64` តែមួយចូលទៅក្នុង hasher នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_u64(&mut self, i: u64) {
        self.write(&i.to_ne_bytes())
    }
    /// សរសេរ `u128` តែមួយចូលទៅក្នុង hasher នេះ។
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_u128(&mut self, i: u128) {
        self.write(&i.to_ne_bytes())
    }
    /// សរសេរ `usize` តែមួយចូលទៅក្នុង hasher នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_usize(&mut self, i: usize) {
        self.write(&i.to_ne_bytes())
    }

    /// សរសេរ `i8` តែមួយទៅក្នុងឧបករណ៍នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i8(&mut self, i: i8) {
        self.write_u8(i as u8)
    }
    /// សរសេរ `i16` តែមួយចូលទៅក្នុង hasher នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i16(&mut self, i: i16) {
        self.write_u16(i as u16)
    }
    /// សរសេរ `i32` តែមួយចូលទៅក្នុង hasher នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i32(&mut self, i: i32) {
        self.write_u32(i as u32)
    }
    /// សរសេរ `i64` តែមួយទៅក្នុងឧបករណ៍នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_i64(&mut self, i: i64) {
        self.write_u64(i as u64)
    }
    /// សរសេរ `i128` តែមួយចូលទៅក្នុង hasher នេះ។
    #[inline]
    #[stable(feature = "i128", since = "1.26.0")]
    fn write_i128(&mut self, i: i128) {
        self.write_u128(i as u128)
    }
    /// សរសេរ `isize` តែមួយទៅក្នុងឧបករណ៍នេះ។
    #[inline]
    #[stable(feature = "hasher_write", since = "1.3.0")]
    fn write_isize(&mut self, i: isize) {
        self.write_usize(i as usize)
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<H: Hasher + ?Sized> Hasher for &mut H {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
}

/// trait សម្រាប់ការបង្កើត [`Hasher`] ។
///
/// ការ `BuildHasher` ត្រូវបានប្រើជាធម្មតា (ឧទាហរណ៍ដោយ [`HashMap`]) ដើម្បីបង្កើត [`Hasher`] សម្រាប់គន្លឹះគ្នាដូចដែលពួកគេត្រូវបាន hashed ឯករាជ្យពីគ្នាទៅវិញទៅមក, ចាប់តាំងពីការ [`Hasher`] បានមានរដ្ឋ។
///
///
/// សម្រាប់វត្ថុនីមួយៗនៃ `BuildHasher`, [`Hasher`] ដែលបង្កើតដោយ [`build_hasher`] គួរតែដូចគ្នាបេះបិទ។
/// នោះគឺប្រសិនបើស្ទ្រីមបៃដូចគ្នាត្រូវបានបញ្ចូលទៅក្នុងឧបករណ៍ចាប់នីមួយៗលទ្ធផលដូចគ្នានឹងត្រូវបានបង្កើតផងដែរ។
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::RandomState;
/// use std::hash::{BuildHasher, Hasher};
///
/// let s = RandomState::new();
/// let mut hasher_1 = s.build_hasher();
/// let mut hasher_2 = s.build_hasher();
///
/// hasher_1.write_u32(8128);
/// hasher_2.write_u32(8128);
///
/// assert_eq!(hasher_1.finish(), hasher_2.finish());
/// ```
///
/// [`build_hasher`]: BuildHasher::build_hasher
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub trait BuildHasher {
    /// ប្រភេទនៃអ្នកលាងដែលនឹងត្រូវបានបង្កើត។
    #[stable(since = "1.7.0", feature = "build_hasher")]
    type Hasher: Hasher;

    /// បង្កើត hasher ថ្មី។
    ///
    /// រាល់ការហៅទៅ `build_hasher` នៅលើឧទាហរណ៏តែមួយគួរតែផលិតដូចគ្នា [`Hasher`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::hash_map::RandomState;
    /// use std::hash::BuildHasher;
    ///
    /// let s = RandomState::new();
    /// let new_s = s.build_hasher();
    /// ```
    #[stable(since = "1.7.0", feature = "build_hasher")]
    fn build_hasher(&self) -> Self::Hasher;
}

/// ប្រើដើម្បីបង្កើតឧទាហរណ៍ [`BuildHasher`] លំនាំដើមសម្រាប់ប្រភេទដែលអនុវត្ត [`Hasher`] និង [`Default`] ។
///
/// `BuildHasherDefault<H>` អាចត្រូវបានប្រើនៅពេលប្រភេទ `H` អនុវត្ត [`Hasher`] និង [`Default`] ហើយអ្នកត្រូវការឧទាហរណ៍ [`BuildHasher`] ដែលត្រូវគ្នាប៉ុន្តែមិនត្រូវបានកំណត់ទេ។
///
///
/// `BuildHasherDefault` ណាមួយគឺ [zero-sized] ។វាអាចត្រូវបានបង្កើតឡើងដោយមាន [`default`][method.default] ។
/// នៅពេលប្រើ `BuildHasherDefault` ជាមួយ [`HashMap`] ឬ [`HashSet`] នេះមិនចាំបាច់ធ្វើទេពីព្រោះពួកគេអនុវត្តករណី [`Default`] សមស្របដោយខ្លួនឯង។
///
/// # Examples
///
/// ការប្រើប្រាស់ `BuildHasherDefault` ដើម្បីបញ្ជាក់ [`BuildHasher`] ផ្ទាល់ខ្លួន
/// [`HashMap`]:
///
/// ```
/// use std::collections::HashMap;
/// use std::hash::{BuildHasherDefault, Hasher};
///
/// #[derive(Default)]
/// struct MyHasher;
///
/// impl Hasher for MyHasher {
///     fn write(&mut self, bytes: &[u8]) {
///         // ក្បួនដោះស្រាយរបស់អ្នកមាននៅទីនេះ!
///        unimplemented!()
///     }
///
///     fn finish(&self) -> u64 {
///         // ក្បួនដោះស្រាយរបស់អ្នកមាននៅទីនេះ!
///         unimplemented!()
///     }
/// }
///
/// type MyBuildHasher = BuildHasherDefault<MyHasher>;
///
/// let hash_map = HashMap::<u32, u32, MyBuildHasher>::default();
/// ```
///
/// [method.default]: BuildHasherDefault::default
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
/// [`HashSet`]: ../../std/collections/struct.HashSet.html
/// [zero-sized]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#zero-sized-types-zsts
///
///
///
///
#[stable(since = "1.7.0", feature = "build_hasher")]
pub struct BuildHasherDefault<H>(marker::PhantomData<H>);

#[stable(since = "1.9.0", feature = "core_impl_debug")]
impl<H> fmt::Debug for BuildHasherDefault<H> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("BuildHasherDefault")
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H: Default + Hasher> BuildHasher for BuildHasherDefault<H> {
    type Hasher = H;

    fn build_hasher(&self) -> H {
        H::default()
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Clone for BuildHasherDefault<H> {
    fn clone(&self) -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.7.0", feature = "build_hasher")]
impl<H> Default for BuildHasherDefault<H> {
    fn default() -> BuildHasherDefault<H> {
        BuildHasherDefault(marker::PhantomData)
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> PartialEq for BuildHasherDefault<H> {
    fn eq(&self, _other: &BuildHasherDefault<H>) -> bool {
        true
    }
}

#[stable(since = "1.29.0", feature = "build_hasher_eq")]
impl<H> Eq for BuildHasherDefault<H> {}

mod impls {
    use crate::mem;
    use crate::slice;

    use super::*;

    macro_rules! impl_write {
        ($(($ty:ident, $meth:ident),)*) => {$(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for $ty {
                #[inline]
                fn hash<H: Hasher>(&self, state: &mut H) {
                    state.$meth(*self)
                }

                #[inline]
                fn hash_slice<H: Hasher>(data: &[$ty], state: &mut H) {
                    let newlen = data.len() * mem::size_of::<$ty>();
                    let ptr = data.as_ptr() as *const u8;
                    // សុវត្ថិភាព: `ptr` ត្រឹមត្រូវនិងតម្រឹមព្រោះម៉ាក្រូនេះត្រូវបានប្រើ
                    // សម្រាប់បុព្វកាលលេខដែលគ្មានចន្លោះ។
                    // នេះជាចំណែកថ្មីតែមួយគត់ដែលនៅទូទាំង `data` ទទឹកហើយត្រូវបានមិនដែល mutated, និងមានទំហំសរុបរបស់វាគឺដូចគ្នានឹង `data` ដើមដូច្នេះវាមិនអាចត្រូវបានជាង `isize::MAX` ។
                    //
                    state.write(unsafe { slice::from_raw_parts(ptr, newlen) })
                }
            }
        )*}
    }

    impl_write! {
        (u8, write_u8),
        (u16, write_u16),
        (u32, write_u32),
        (u64, write_u64),
        (usize, write_usize),
        (i8, write_i8),
        (i16, write_i16),
        (i32, write_i32),
        (i64, write_i64),
        (isize, write_isize),
        (u128, write_u128),
        (i128, write_i128),
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for bool {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u8(*self as u8)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for char {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write_u32(*self as u32)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Hash for str {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            state.write(self.as_bytes());
            state.write_u8(0xff)
        }
    }

    #[stable(feature = "never_hash", since = "1.29.0")]
    impl Hash for ! {
        #[inline]
        fn hash<H: Hasher>(&self, _: &mut H) {
            *self
        }
    }

    macro_rules! impl_hash_tuple {
        () => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Hash for () {
                #[inline]
                fn hash<H: Hasher>(&self, _state: &mut H) {}
            }
        );

        ( $($name:ident)+) => (
            #[stable(feature = "rust1", since = "1.0.0")]
            impl<$($name: Hash),+> Hash for ($($name,)+) where last_type!($($name,)+): ?Sized {
                #[allow(non_snake_case)]
                #[inline]
                fn hash<S: Hasher>(&self, state: &mut S) {
                    let ($(ref $name,)+) = *self;
                    $($name.hash(state);)+
                }
            }
        );
    }

    macro_rules! last_type {
        ($a:ident,) => { $a };
        ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
    }

    impl_hash_tuple! {}
    impl_hash_tuple! { A }
    impl_hash_tuple! { A B }
    impl_hash_tuple! { A B C }
    impl_hash_tuple! { A B C D }
    impl_hash_tuple! { A B C D E }
    impl_hash_tuple! { A B C D E F }
    impl_hash_tuple! { A B C D E F G }
    impl_hash_tuple! { A B C D E F G H }
    impl_hash_tuple! { A B C D E F G H I }
    impl_hash_tuple! { A B C D E F G H I J }
    impl_hash_tuple! { A B C D E F G H I J K }
    impl_hash_tuple! { A B C D E F G H I J K L }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: Hash> Hash for [T] {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            self.len().hash(state);
            Hash::hash_slice(self, state)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized + Hash> Hash for &mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            (**self).hash(state);
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *const T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // ព្រួញស្តើង
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ទ្រនិចជាតិខ្លាញ់សុវត្ថិភាព: យើងកំពុងចូលដំណើរការអង្គចងចាំដែលកាន់កាប់ដោយ `self` ដែលត្រូវបានធានាថាមានសុពលភាព។
                    // នេះសន្មតថាទ្រនាប់ខ្លាញ់អាចត្រូវបានតំណាងដោយ `(usize, usize)` ដែលមានសុវត្ថិភាពក្នុងការធ្វើនៅក្នុង `std` ព្រោះវាត្រូវបានដឹកជញ្ជូននិងរក្សាទុកឱ្យស៊ីគ្នាជាមួយនឹងការអនុវត្តចំណុចចង្អុលខ្លាញ់ក្នុង `rustc` ។
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Hash for *mut T {
        #[inline]
        fn hash<H: Hasher>(&self, state: &mut H) {
            #[cfg(not(bootstrap))]
            {
                let (address, metadata) = self.to_raw_parts();
                state.write_usize(address as usize);
                metadata.hash(state);
            }
            #[cfg(bootstrap)]
            {
                if mem::size_of::<Self>() == mem::size_of::<usize>() {
                    // ព្រួញស្តើង
                    state.write_usize(*self as *const () as usize);
                } else {
                    // ទ្រនិចជាតិខ្លាញ់សុវត្ថិភាព: យើងកំពុងចូលដំណើរការអង្គចងចាំដែលកាន់កាប់ដោយ `self` ដែលត្រូវបានធានាថាមានសុពលភាព។
                    // នេះសន្មតថាទ្រនាប់ខ្លាញ់អាចត្រូវបានតំណាងដោយ `(usize, usize)` ដែលមានសុវត្ថិភាពក្នុងការធ្វើនៅក្នុង `std` ព្រោះវាត្រូវបានដឹកជញ្ជូននិងរក្សាទុកឱ្យស៊ីគ្នាជាមួយនឹងការអនុវត្តចំណុចចង្អុលខ្លាញ់ក្នុង `rustc` ។
                    //
                    //
                    //
                    //
                    let (a, b) = unsafe { *(self as *const Self as *const (usize, usize)) };
                    state.write_usize(a);
                    state.write_usize(b);
                }
            }
        }
    }
}