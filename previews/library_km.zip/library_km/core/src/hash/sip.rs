//! ការអនុវត្តន៍ SipHash ។

#![allow(deprecated)] // ប្រភេទនៅក្នុងម៉ូឌុលនេះត្រូវបានបដិសេធ

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// ការអនុវត្ត SipHash ១-៣ ។
///
/// បច្ចុប្បន្ននេះគឺជាមុខងារ hashing លំនាំដើមត្រូវបានប្រើដោយបណ្ណាល័យស្តង់ដារ (ឧទាហរណ៍ `collections::HashMap` ប្រើវាតាមលំនាំដើម) ។
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// ការអនុវត្តនៃ SipHash 2-4 ។
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// ការអនុវត្តនៃ SipHash 2-4 ។
///
/// See: <https://131002.net/siphash/>
///
/// SipHash គឺជាមុខងារដែលមានគោលបំណងទូទៅ: វាដំណើរការក្នុងល្បឿនល្អ (ប្រកួតប្រជែងជាមួយ Spooky និង City) និងអនុញ្ញាតឱ្យ Xing X _keyed_ រឹងមាំ។
///
/// នេះអនុញ្ញាតឱ្យអ្នកចុចគ្រាប់ចុចតុសញ្ញារបស់អ្នកពី RNG ខ្លាំងដូចជា [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) ។
///
/// បើទោះបីជាក្បួនដោះស្រាយ SipHash ត្រូវបានចាត់ទុកថាជាខ្លាំងជាទូទៅវាមិនត្រូវបានបម្រុងទុកសម្រាប់គោលបំណងគ្រីបទាំងនេះ។
/// ដូច្នេះរាល់ការប្រើប្រាស់គ្រីបគ្រីបនៃការអនុវត្តនេះគឺ _strongly discouraged_ ។
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // តើមានប៉ុន្មានបៃដែលយើងបានដំណើរការ
    state: State,  // រដ្ឋសញ្ញា
    tail: u64,     // បៃដែលមិនបានដំណើរការ
    ntail: usize,  // តើមានមនុស្សប៉ុន្មានបៃកន្ទុយមានសុពលភាព
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2 និង v1, v3 បង្ហាញជាគូនៅក្នុងក្បួនដោះស្រាយហើយការអនុវត្តន៍ស៊ីមហាសនឹងប្រើ vectors នៃ v02 និង v13 ។
    //
    // ដោយដាក់ពួកគេនៅក្នុងលំដាប់ struct នេះចងក្រងអាចយកឡើងនៅលើការបង្កើនប្រសិទ្ធភាព simd គ្រាន់តែមួយចំនួនដោយខ្លួនវាផ្ទាល់។
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// ផ្ទុកចំនួនគត់នៃប្រភេទដែលអ្នកចង់បានពីស្ទ្រីមបៃក្នុងគោលបំណង LE ។
/// ប្រើ `copy_nonoverlapping` ដើម្បីអនុញ្ញាតឱ្យចងក្រងបង្កើតជាវិធីដែលមានប្រសិទ្ធិភាពបំផុតដើម្បីផ្ទុកវាអាចធ្វើទៅបាន unaligned ពីអាសយដ្ឋានមួយ។
///
///
/// ដោយសារតែមិនមានសុវត្ថិភាព: ការបង្កើតលិបិក្រមដែលមិនបានធីកនៅ i..i+size_of(int_ty)
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// ផ្ទុក u64 ដោយប្រើចំណែកបៃរហូតដល់ ៧ បៃ។
/// វាមើលទៅការហៅទូរស័ព្ទដេលមិនវាងវៃទេប៉ុន្តែ `copy_nonoverlapping` ដែលកើតមានឡើង (តាមរយៈ `load_int_le!`) ទាំងអស់ដែលបានជួសជុលទំហំនិងជៀសវាងការហៅ `memcpy` ដែលជាការល្អសម្រាប់ល្បឿន។
///
///
/// មិនមានសុវត្ថិភាពទេពីព្រោះ៖ មិនបានធីកលិបិក្រមនៅ start..start + len
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // សន្ទស្សន៍បៃបច្ចុប្បន្ន (ពីអិលអេសប៊ី) ក្នុងលទ្ធផល u64
    let mut out = 0;
    if i + 3 < len {
        // សុវត្ថិភាព: `i` មិនអាចច្រើនជាង `len` និងធានាទូរស័ព្ទចូលកត្តាចាំបាច់
        // ថាសន្ទស្សន៍ start..start បូកឡែននៅព្រំដែន។
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // សុវត្ថិភាព: ដូចគ្នានឹងខាងលើ។
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // សុវត្ថិភាព: ដូចគ្នានឹងខាងលើ។
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// បង្កើត `SipHasher` ថ្មីដែលមានកូនសោដំបូងពីរកំណត់ទៅ ០ ។
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// បង្កើត `SipHasher` ដែលត្រូវបានរំជួលដល់បិទបានផ្តល់គ្រាប់ចុចមួយ។
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// បង្កើត `SipHasher13` ថ្មីដែលមានកូនសោដំបូងពីរកំណត់ទៅ ០ ។
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// បង្កើត `SipHasher13` ដែលត្រូវបានរំជួលដល់បិទបានផ្តល់គ្រាប់ចុចមួយ។
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: មិនមានវិធីសាស្រ្តធ្វើឱ្យចំនួនគត់ (`សរសេរ-យូ *`, X០០X) ត្រូវបានកំណត់
    // សម្រាប់ប្រភេទនេះ។
    // យើងអាចបន្ថែមពួកវាចម្លងការអនុវត្តន៍ `short_write` ក្នុង librustc_data_structures/sip128.rs និងបន្ថែមវិធីសាស្ត្រ `write_u *`/`write_i*` ទៅ `SipHasher`, `SipHasher13` និង `DefaultHasher` ។
    //
    // ការនេះនឹងបង្កើនល្បឿនយ៉ាងខ្លាំងឡើង hashing ដែលចំនួនគត់ដោយ hashers នោះ, នៅក្នុងការចំណាយនៃការធ្លាក់ចុះបន្តិចនៅលើគោលការណ៍ល្បឿនចងក្រងមួយចំនួន។
    // សូមមើល #69152 សម្រាប់លម្អិត។
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // សុវត្ថិភាព: `cmp::min(length, needed)` ត្រូវបានធានាក្នុងការមិនត្រូវបានជាង `length`
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // កន្ទុយក្របីឥឡូវត្រូវបានហូរហើយដំណើរការធាតុបញ្ចូលថ្មី។
        let len = length - needed;
        let left = len & 0x7; // Len% 8

        let mut i = needed;
        while i < len - left {
            // សុវត្ថិភាព: ពីព្រោះ `len - left` គឺជាពហុគុណធំបំផុតក្នុងចំណោម ៨ ក្រោម
            // `len`, ហើយដោយសារតែ `i` ចាប់ផ្តើមនៅ `needed` ដែលជាកន្លែងដែល `len` គឺ `length - needed`, `i + 8` ត្រូវបានធានាឱ្យតិចជាងឬស្មើទៅនឹង `length` ។
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // សុវត្ថិភាព: `i` ឥឡូវគឺ `needed + len.div_euclid(8) * 8`,
        // ដូច្នេះ `i + left` = `needed + len` = `length`, ដែលតាមនិយមន័យស្មើនឹង `msg.len()` ។
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// បង្កើត `Hasher<S>` មួយជាមួយនឹងកូនសោដំបូងពីរកំណត់ទៅ 0 ។
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}