//! លេងសើចបន្តិចលើ IEEE 754 អណ្តែតវិជ្ជមាន។លេខអវិជ្ជមានមិនមែននិងមិនចាំបាច់ត្រូវបានដោះស្រាយទេ។
//! លេខចំណុចអណ្តែតទឹកធម្មតាមានតំណាងជា Canonical ដូចជា (fc, exp) ដូចជាតម្លៃគឺ ២ <sup>exp</sup> * (១ + X០០X ដែល N ជាចំនួនប៊ីត។
//!
//! សត្វមច្ឆាជាតិមានភាពខុសគ្នាបន្តិចបន្តួចនិងចំលែកប៉ុន្តែគោលការណ៍ដូចគ្នាត្រូវបានអនុវត្ត។
//!
//! ទោះយ៉ាងណានៅទីនេះយើងតំណាងឱ្យពួកគេដូចជា (sig, k) ដែលមាន f វិជ្ជមានដូចជាតម្លៃនោះគឺ f *
//! 2 <sup>អ៊ី</sup> ។ក្រៅពីការធ្វើឱ្យ "hidden bit" ច្បាស់ការផ្លាស់ប្តូរនិទស្សន្តដោយការផ្លាស់ប្តូរដែលគេហៅថា mantissa ។
//!
//! ដាក់វិធីមួយទៀតតាមធម្មតាអណ្តែតត្រូវបានសរសេរជា (1) ប៉ុន្តែនៅទីនេះពួកវាត្រូវបានសរសេរជា (2)៖
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! យើងហៅ (1) ជា **តំណាងប្រភាគ** និង (2) ជា **តំណាងអាំងតេក្រាល**។
//!
//! មុខងារជាច្រើននៅក្នុងម៉ូឌុលនេះដោះស្រាយតែលេខធម្មតាប៉ុណ្ណោះ។ទម្រង់ dec2flt ត្រូវបានអភិរក្សអភិរក្សយកផ្លូវយឺតដែលត្រឹមត្រូវជាសកល (អាល់ឡូជីអិម) សម្រាប់ចំនួនតូចនិងធំបំផុត។
//! ក្បួនដោះស្រាយនោះត្រូវការតែ next_float() ប៉ុណ្ណោះដែលគ្រប់គ្រង subnormals និងលេខសូន្យ។
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// ជំនួយការ trait ដើម្បីចៀសវាងការចម្លងលេខកូដបំលែងជាមូលដ្ឋានសម្រាប់ `f32` និង `f64` ។
///
/// សូមមើលសេចក្តីពន្យល់អំពីឯកសាររបស់ម៉ូឌុលមេសម្រាប់ហេតុផលដែលចាំបាច់។
///
/// គួរតែ **មិនធ្លាប់មាន** ត្រូវបានអនុវត្តសម្រាប់ប្រភេទផ្សេងទៀតឬត្រូវបានប្រើនៅខាងក្រៅម៉ូឌុល dec2flt ។
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// ប្រភេទប្រើដោយ `to_bits` និង `from_bits` ។
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// អនុវត្តការបញ្ជូនឆៅទៅចំនួនគត់។
    fn to_bits(self) -> Self::Bits;

    /// អនុវត្តការបញ្ជូនឆៅពីចំនួនគត់។
    fn from_bits(v: Self::Bits) -> Self;

    /// ត្រឡប់ប្រភេទដែលលេខនេះធ្លាក់ចូល។
    fn classify(self) -> FpCategory;

    /// ត្រឡប់ mantissa ស្វ័យគុណនិងចុះហត្ថលេខាជាចំនួនគត់។
    fn integer_decode(self) -> (u64, i16, i8);

    /// ឌិកូដអណ្តែត។
    fn unpack(self) -> Unpacked;

    /// ចាក់ចេញពីចំនួនគត់តូចមួយដែលអាចត្រូវបានតំណាងយ៉ាងពិតប្រាកដ។
    /// Panic ប្រសិនបើលេខគត់មិនអាចត្រូវបានតំណាងលេខកូដផ្សេងទៀតនៅក្នុងម៉ូឌុលនេះធ្វើឱ្យប្រាកដថាមិនអនុញ្ញាតឱ្យកើតឡើង។
    fn from_int(x: u64) -> Self;

    /// ទទួលបានតម្លៃ 10 <sup>អ៊ី</sup> ពីតារាងគណនាមុន។
    /// Panics សម្រាប់ `e >= CEIL_LOG5_OF_MAX_SIG` ។
    fn short_fast_pow10(e: usize) -> Self;

    /// អ្វីដែលឈ្មោះនិយាយ។
    /// វាងាយស្រួលក្នុងការដាក់កូដជាជាងការរត់ប្រសព្វគ្នាហើយសង្ឃឹមថាអិលអិលអិមថេរនឹងបត់វា។
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ការអភិរក្សត្រូវបានចងនៅលើខ្ទង់ទសភាគនៃខ្ទង់ចូលដែលមិនអាចផលិតបានលើសឬសូន្យរឺ
    /// subnormals ។និទស្សន្តទសភាគនៃតម្លៃធម្មតាអតិបរមាដូច្នេះឈ្មោះ។
    const MAX_NORMAL_DIGITS: usize;

    /// នៅពេលដែលខ្ទង់ទសភាគសំខាន់បំផុតមានតំលៃខ្ទង់ធំជាងលេខនេះគឺប្រាកដជាមានរាងមូលទៅនឹងភាពគ្មានទីបញ្ចប់។
    ///
    const INF_CUTOFF: i64;

    /// នៅពេលដែលខ្ទង់ទសភាគសំខាន់បំផុតមានតំលៃខ្ទង់តិចជាងនេះលេខប្រាកដជាមានរាងមូលដល់សូន្យ។
    ///
    const ZERO_CUTOFF: i64;

    /// ចំនួនប៊ីតក្នុងនិទស្សន្ត។
    const EXP_BITS: u8;

    /// ចំនួនប៊ីតនៅក្នុងន័យនិង *រួមទាំង* ប៊ីតដែលលាក់។
    const SIG_BITS: u8;

    /// ចំនួនប៊ីតនៅក្នុងន័យនិង *មិនរាប់បញ្ចូល* ប៊ីតដែលលាក់។
    const EXPLICIT_SIG_BITS: u8;

    /// និទស្សន្តផ្នែកច្បាប់អតិបរមាក្នុងការតំណាងប្រភាគ។
    const MAX_EXP: i16;

    /// និទស្សន្តផ្នែកច្បាប់អប្បបរមាក្នុងការតំណាងប្រភាគដោយមិនរាប់បញ្ចូលក្រុមតូចៗ។
    const MIN_EXP: i16;

    /// `MAX_EXP` សម្រាប់តំណាងអាំងតេក្រាលពោលគឺការផ្លាស់ប្តូរត្រូវបានអនុវត្ត។
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` អ៊ិនកូដ (ឧ។ ជាមួយអុហ្វសិត)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` សម្រាប់តំណាងអាំងតេក្រាលពោលគឺការផ្លាស់ប្តូរត្រូវបានអនុវត្ត។
    const MIN_EXP_INT: i16;

    /// និយមន័យធម្មតាអតិបរិមានិងជាតំណាងអាំងតេក្រាល។
    const MAX_SIG: u64;

    /// និយមន័យធម្មតាធម្មតាអប្បបរមានិងជាតំណាងអាំងតេក្រាល។
    const MIN_SIG: u64;
}

// ភាគច្រើនជាដំណោះស្រាយសម្រាប់ #34344 ។
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// ត្រឡប់ mantissa ស្វ័យគុណនិងចុះហត្ថលេខាជាចំនួនគត់។
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // ភាពលំអៀងហួសប្រមាណ + ការផ្លាស់ប្តូរ mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe មិនច្បាស់ទេថាតើ `as` មូលបានត្រឹមត្រូវនៅលើគ្រប់វេទិកាទាំងអស់។
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// ត្រឡប់ mantissa ស្វ័យគុណនិងចុះហត្ថលេខាជាចំនួនគត់។
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // ភាពលំអៀងហួសប្រមាណ + ការផ្លាស់ប្តូរ mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe មិនច្បាស់ទេថាតើ `as` មូលបានត្រឹមត្រូវនៅលើគ្រប់វេទិកាទាំងអស់។
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// បំលែង `Fp` ទៅជាប្រភេទអណ្តែតរបស់ម៉ាស៊ីនដែលជិតបំផុត។
/// មិនដោះស្រាយលទ្ធផលមិនធម្មតាទេ។
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f គឺ 64 ប៊ីតដូច្នេះលោក xe មានការផ្លាស់ប្តូរ mantissa នៃ 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// បង្គត់ខ្ទង់ 64 ប៊ីតនិងប៊ីត T::SIG_BITS ប៊ីតជាមួយកន្លះទៅគូ។
/// មិនដោះស្រាយលើសចំណុះ។
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // លៃតម្រូវការផ្លាស់ប្តូរ mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// បញ្ច្រាសនៃ `RawFloat::unpack()` សម្រាប់លេខធម្មតា។
/// Panics ប្រសិនបើអត្ថន័យនិងនិទស្សន្តមិនមានសុពលភាពសម្រាប់លេខធម្មតា។
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // យកប៊ីតលាក់
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // លៃតម្រូវនិទស្សន្តសម្រាប់ភាពលំអៀងនិទស្សន្តនិងការផ្លាស់ប្តូរ mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // ទុកលេខប៊ីតនៅ 0 ("+") លេខរបស់យើងគឺវិជ្ជមានទាំងអស់
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// សាងសង់មិនធម្មតា។Mantissa មួយនៃ ០ ត្រូវបានអនុញ្ញាតនិងសាងសង់សូន្យ។
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // និទស្សន្តអ៊ីនកូដគឺ ០, សញ្ញាប៊ីតគឺ ០ ដូច្នេះយើងគ្រាន់តែបកស្រាយប៊ីត។
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ប្រហាក់ប្រហែល bignum ជាមួយ Fp មួយ។មូលក្នុង 0.5 ULP ជាមួយកន្លះគូ។
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // យើងកាត់ចេញប៊ីតមុនពេលសន្ទស្សន៍ `start` មានន័យថាយើងប្តូរស្តាំដោយចំនួន `start` ដូច្នេះនេះក៏ជានិទស្សន្តដែលយើងត្រូវការ។
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // រង្វង់មូល (half-to-even) អាស្រ័យលើផ្នែកដែលបានកាត់ចេញ។
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// រកលេខអណ្តែតធំជាងគេតូចជាងអាគុយម៉ង់។
/// មិនដោះស្រាយផ្នែករងតូចៗសូន្យឬចរន្តក្រោម។
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// រកលេខអណ្តែតតូចជាងគេតូចជាងអាគុយម៉ង់។
// ប្រតិបត្ដិការនេះត្រូវបាន saturating ពោលគឺ next_float(inf) ==inf ។
// មិនដូចលេខកូដភាគច្រើននៅក្នុងម៉ូឌុលនេះមុខងារនេះពិតជាអាចគ្រប់គ្រងសូន្យអនុនិងអនុផលអាក្រក់។
// ទោះយ៉ាងណាក៏ដោយដូចជាកូដផ្សេងទៀតទាំងអស់នៅទីនេះវាមិនទាក់ទងជាមួយ NaN និងលេខអវិជ្ជមានទេ។
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // នេះមើលទៅដូចជាល្អពេកហើយប៉ុន្តែវាមានប្រសិទ្ធភាព។
        // 0.0 ត្រូវបានអ៊ិនកូដជាពាក្យសូន្យទាំងអស់។សត្វមច្ឆាមានទំហំ ០x០០០ ម ... មដែលម៉ែត្រគឺជាមន្ទ្រី។
        // ជាពិសេសភាពមិនធម្មតាតូចបំផុតគឺ ០x០…០១ និងធំជាងគេគឺ ០x០០០F…F ។
        // លេខធម្មតាតូចបំផុតគឺ ០x០០១០…០ ដូច្នេះករណីជ្រុងនេះក៏អាចដំណើរការបានដែរ។
        // ប្រសិនបើការកើនឡើងលើសចំណុះ mantissa នោះប៊ីតស្ពាន់ធ័របង្កើននិទស្សន្តដូចដែលយើងចង់បានហើយប៊ីតរបស់ប៊ីតរីសូន្យក្លាយជាលេខសូន្យ។
        // ដោយសារតែមហាសន្និបាតដែលលាក់កំបាំងនេះពិតជាអ្វីដែលយើងចង់បាន!
        // ទីបំផុត f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY ។
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}