//! មុខងារឧបករណ៍ប្រើប្រាស់សម្រាប់ការ bignums ដែលមិនយល់ច្រើនដើម្បីក្លាយជាវិធីសាស្រ្ត។

// FIXME ឈ្មោះម៉ូឌុលនេះជាអកុសលបន្តិចពីព្រោះម៉ូឌុលផ្សេងទៀតក៏នាំចូល `core::num` ផងដែរ។

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// សាកល្បងថាតើកាត់ចេញរាល់ប៊ីតតិចជាង `ones_place` ណែនាំកំហុសតូចជាងស្មើឬធំជាង 0.5 ULP ។
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // ប្រសិនបើប៊ីតដែលនៅសល់ទាំងអស់គឺសូន្យនោះវាជា= 0.5 ULP បើមិនដូច្នេះទេ> 0.5 ប្រសិនបើមិនមានប៊ីតទៀតទេ (ពាក់កណ្តាល _==០) នោះផ្នែកខាងក្រោមក៏ត្រឡប់ស្មើគ្នាដែរ។
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// បំលែងខ្សែអក្សរ ASCII ដែលមានតែខ្ទង់ទសភាគដល់លេខ `u64` ។
///
/// មិនអនុវត្តការត្រួតពិនិត្យសម្រាប់ការហូរហៀរឬតួអក្សរមិនត្រឹមត្រូវដូច្នេះប្រសិនបើអ្នកហៅទូរស័ព្ទមិនប្រុងប្រយ័ត្នលទ្ធផលគឺក្លែងក្លាយហើយអាច panic (ទោះបីជាវាមិនមែនជា `unsafe` ក៏ដោយ) ។
/// លើសពីនេះទៀតខ្សែរទទេត្រូវបានចាត់ទុកជាសូន្យ។
/// មុខងារនេះមានពីព្រោះ
///
/// 1. ការប្រើ `FromStr` លើ `&[u8]` ទាមទារ `from_utf8_unchecked` ដែលវាអាក្រក់ហើយ
/// 2. ការបញ្ចូលគ្នានូវលទ្ធផលនៃ `integral.parse()` និង `fractional.parse()` គឺស្មុគស្មាញជាងមុខងារទាំងមូលនេះ។
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// បំលែងខ្សែ ASCII មួយខ្ទង់ទៅជាអង្កាំ។
///
/// ដូច `from_str_unchecked` មុខងារនេះពឹងផ្អែកលើសេកដើម្បីស្មៅចេញមិនមែនជាតួលេខ។
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// ដោះក្រេបប៊ីតចូលទៅក្នុងចំនួនគត់ ៦៤ ប៊ីត។Panics ប្រសិនបើចំនួនធំពេក។
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// ដកស្រង់ជួរនៃប៊ីត។

/// សន្ទស្សន៍ ០ គឺតូចបំផុតហើយជួរគឺពាក់កណ្តាលបើកដូចធម្មតា។
/// Panics ប្រសិនបើត្រូវបានស្នើសុំឱ្យដកប៊ីតច្រើនជាងសមទៅនឹងប្រភេទត្រឡប់មកវិញ។
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}