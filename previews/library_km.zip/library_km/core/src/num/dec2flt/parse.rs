//! ការធ្វើឱ្យមានសុពលភាពនិងបំផ្លាញខ្សែអក្សរគោលនៃទម្រង់៖
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! និយាយម្យ៉ាងទៀតវាក្យសម្ព័ន្ធអណ្តែតទឹកស្តង់ដារដោយមានករណីលើកលែងពីរ: គ្មានសញ្ញានិងគ្មានការគ្រប់គ្រង "inf" និង "NaN" ។ទាំងនេះត្រូវបានគ្រប់គ្រងដោយមុខងារកម្មវិធីបញ្ជា (super::dec2flt) ។
//!
//! ទោះបីជាការទទួលស្គាល់ធាតុចូលត្រឹមត្រូវមានភាពងាយស្រួលក៏ដោយម៉ូឌុលនេះក៏ត្រូវបដិសេធនូវការប្រែប្រួលមិនត្រឹមត្រូវរាប់មិនអស់មិនដែល panic និងអនុវត្តការត្រួតពិនិត្យជាច្រើនដែលម៉ូឌុលផ្សេងទៀតពឹងផ្អែកមិន panic (ឬលើសចំណុះ) ។
//!
//! ដើម្បីធ្វើឱ្យបញ្ហាកាន់តែអាក្រក់អ្វីៗទាំងអស់ដែលកើតឡើងនៅក្នុងការបញ្ជូនតែមួយលើធាតុបញ្ចូល។
//! ដូច្នេះសូមប្រយ័ត្ននៅពេលកែប្រែអ្វីទាំងអស់ហើយពិនិត្យទ្វេដងជាមួយម៉ូឌុលផ្សេងទៀត។
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// ផ្នែកគួរឱ្យចាប់អារម្មណ៍នៃខ្សែលេខទសភាគ។
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// និទស្សន្តគោលត្រូវបានធានាថាមានតិចជាង ១៨ ខ្ទង់។
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// ពិនិត្យមើលថាតើខ្សែបញ្ចូលគឺជាលេខចំនុចអណ្តែតត្រឹមត្រូវហើយបើដូច្នោះមែនចូររកទីតាំងដែលមានចំណែកផ្នែកប្រភាគនិងនិទស្សន្តនៅក្នុងវា។
/// មិនដោះស្រាយសញ្ញា។
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // គ្មានលេខមុនពេល 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // យើងតម្រូវឱ្យមានយ៉ាងហោចណាស់មួយខ្ទង់មុនពេលឬក្រោយពេលចំនុច។
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // ដាក់ស្នាមប្រេះបន្ទាប់ពីផ្នែកប្រភាគ
            }
        }
        _ => Invalid, // ឃ្លាតឆ្ងាយឥតខ្សែបន្ទាប់ពីខ្សែអក្សរខ្ទង់ដំបូង
    }
}

/// ឆ្លាក់ខ្ទង់ទសភាគរហូតដល់តួអក្សរមិនមែនខ្ទង់ទីមួយ។
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// ការស្រង់ចេញបន្ថែមនិងការត្រួតពិនិត្យកំហុស។
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // ទុកចោលឥតបានការបន្ទាប់ពីនិទស្សន្ត
    }
    if number.is_empty() {
        return Invalid; // និទស្សន្តទទេ
    }
    // ត្រង់ចំណុចនេះយើងប្រាកដជាមានខ្សែរលេខត្រឹមត្រូវ។វាអាចវែងពេកក្នុងការដាក់ `i64` X ប៉ុន្តែប្រសិនបើវាធំនោះការបញ្ចូលគឺពិតជាសូន្យឬគ្មានកំណត់។
    // ដោយសារលេខសូន្យនីមួយៗនៃខ្ទង់ទសភាគគ្រាន់តែកែស្វ័យគុណដោយ +/-១ នៅ exp=១០ ^ ១៨ ការបញ្ចូលនឹងត្រូវមាន ១៧ អ៊ិច្សភេ X០០X នៃលេខសូន្យដើម្បីទទួលបានភាពជិតឆ្ងាយពីចំងាយ។
    //
    // នេះមិនមែនជាករណីប្រើប្រាស់ដែលយើងត្រូវការដើម្បីបំពេញតាមនោះទេ។
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}