//! បំលែងខ្សែលេខទសភាគទៅជា IEEE 754 លេខចំនុចអណ្តែតប្រព័ន្ធគោលពីរ។
//!
//! # សេចក្តីថ្លែងការណ៍បញ្ហា
//!
//! យើងត្រូវបានផ្តល់ខ្សែអក្សរគោលដូចជា `12.34e56` ។
//! ខ្សែនេះមានអាំងតេក្រាល (`12`) ប្រភាគ (`34`) និងផ្នែក (`56`) និទស្សន្ត។ផ្នែកទាំងអស់គឺស្រេចចិត្តនិងត្រូវបានបកប្រែថាសូន្យនៅពេលបាត់។
//!
//! យើងស្វែងរកលេខចំណុចអណ្តែត IEEE 754 ដែលនៅជិតនឹងតម្លៃពិតប្រាកដនៃខ្សែគោលដប់។
//! វាត្រូវបានគេដឹងថាខ្សែលេខទសភាគជាច្រើនមិនមានការបញ្ឈប់តំណាងនៅក្នុងគោលពីរទេដូច្នេះយើងបង្គត់ទៅអង្គភាព 0.5 នៅកន្លែងចុងក្រោយ (និយាយម្យ៉ាងទៀតក៏ដូចជាអាចធ្វើទៅបាន) ។
//! ក្រវ៉ាត់តម្លៃខ្ទង់ទសភាគយ៉ាងពិតប្រាកដពាក់កណ្តាលផ្លូវរវាងអណ្តែតពីរជាប់គ្នាត្រូវបានដោះស្រាយជាមួយនឹងយុទ្ធសាស្រ្តពាក់កណ្តាលទៅសូម្បីតែដែលត្រូវបានគេស្គាល់ផងដែរថាជាការបង្គត់របស់ធនាគារ។
//!
//! មិនចាំបាច់និយាយទេនេះពិតជាពិបាកណាស់ទាំងផ្នែកភាពស្មុគស្មាញនៃការអនុវត្តនិងទាក់ទងនឹងវដ្តស៊ីភីយូដែលត្រូវបានធ្វើឡើង។
//!
//! # Implementation
//!
//! ដំបូងយើងមិនអើពើនឹងសញ្ញា។ឬផ្ទុយទៅវិញយើងយកវាចេញនៅដំណាក់កាលដំបូងនៃដំណើរការបំលែងហើយអនុវត្តវាឡើងវិញនៅចុងបញ្ចប់។
//! នេះគឺត្រឹមត្រូវក្នុងករណី edge ទាំងអស់ចាប់តាំងពី IEEE អណ្តែតមានស៊ីមេទ្រីនៅជុំវិញសូន្យដោយធ្វើឱ្យអវិជ្ជមានមួយគ្រាន់តែត្រឡប់បន្តិច។
//!
//! បន្ទាប់មកយើងដកចេញនូវខ្ទង់ទសភាគដោយកែសំរួលស្វ័យគុណ: តាមពិត `12.34e56` ប្រែទៅជា `1234e54` ដែលយើងពណ៌នាជាមួយចំនួនគត់វិជ្ជមាន `f = 1234` និងចំនួនគត់ `e = 54` ។
//! ការតំណាង `(f, e)` ត្រូវបានប្រើដោយកូដស្ទើរតែទាំងអស់ដែលឆ្លងកាត់ដំណាក់កាលវិភាគ។
//!
//! បន្ទាប់មកយើងសាកល្បងខ្សែសង្វាក់វែងៗនៃករណីពិសេសដែលមានតម្លៃថ្លៃជាងមុនដោយប្រើលេខគត់ម៉ាស៊ីននិងលេខចំណុចអណ្តែតតូចដែលមានទំហំថេរ (ដំបូង `f32`/`f64` បន្ទាប់មកប្រភេទមួយដែលមាន ៦៤ ប៊ីតអត្ថន័យand, `Fp`) ។
//!
//! នៅពេលដែលទាំងអស់នេះបរាជ័យយើងខាំគ្រាប់កាំភ្លើងនិងងាកទៅរកក្បួនដោះស្រាយសាមញ្ញប៉ុន្តែយឺតណាស់ដែលពាក់ព័ន្ធនឹងការគណនា `f * 10^e` យ៉ាងពេញលេញនិងធ្វើការស្រាវជ្រាវដដែលៗសម្រាប់ការប៉ាន់ស្មានប្រហាក់ប្រហែល។
//!
//! ជាបឋមម៉ូឌុលនេះនិងកូន ៗ របស់វាអនុវត្តក្បួនដោះស្រាយដែលបានពិពណ៌នានៅក្នុង៖
//! "How to Read Floating Point Numbers Accurately" ដោយ William William
//! ខ្ញីនិងមានតាមអ៊ិនធរណេតៈ <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! លើសពីនេះទៀតមានមុខងារជំនួយជាច្រើនដែលត្រូវបានប្រើនៅក្នុងក្រដាសប៉ុន្តែមិនមាននៅក្នុង Rust (ឬយ៉ាងហោចណាស់នៅក្នុងស្នូល) ។
//! កំណែរបស់យើងមានភាពស្មុគស្មាញបន្ថែមទៀតដោយតំរូវការដើម្បីគ្រប់គ្រងការហៀរនិងហូរហៀរនិងការចង់ដោះស្រាយលេខមិនធម្មតា។
//! Bellerophon និង Algorithm R មានបញ្ហាជាមួយនឹងការហៀរហៀរទឹកហូរតូចៗនិងលំហូរ។
//! យើងប្តូរទៅរកវិធីដោះស្រាយអាល់ឡូជីធីអិម (ជាមួយនឹងការកែប្រែដែលបានពិពណ៌នានៅក្នុងផ្នែកទី ៨ នៃក្រដាស) ល្អមុនពេលធាតុចូលចូលទៅក្នុងតំបន់សំខាន់។
//!
//! ទិដ្ឋភាពមួយទៀតដែលត្រូវការការចាប់អារម្មណ៍គឺ ``រ៉ាហ្វលឡាតា`trait ដែលមុខងារស្ទើរតែទាំងអស់ត្រូវបានកំណត់ជាគំរូ។មនុស្សម្នាក់អាចគិតថាវាគ្រប់គ្រាន់ក្នុងការវិភាគទៅ `f64` ហើយបោះលទ្ធផលទៅ `f32` ។
//! ជាអកុសលនេះមិនមែនជាពិភពលោកដែលយើងរស់នៅទេហើយនេះមិនមានអ្វីដែលត្រូវធ្វើជាមួយការប្រើមូលដ្ឋានពីរឬពាក់កណ្តាលរហូតដល់ជុំទេ។
//!
//! ពិចារណាឧទាហរណ៍ពីរប្រភេទ `d2` និង `d4` តំណាងឱ្យប្រភេទមួយដែលមានខ្ទង់ទសភាគពីរខ្ទង់និងបួនខ្ទង់បួនខ្ទង់ហើយយក "0.01499" ធ្វើជាធាតុបញ្ចូល។តោះប្រើពាក់កណ្តាលជុំ។
//! ទៅដល់លេខខ្ទង់ ២ ខ្ទង់ដោយផ្ទាល់ផ្តល់ `0.01` ប៉ុន្តែប្រសិនបើយើងបង្គត់ដល់ ៤ ខ្ទង់ដំបូងយើងទទួលបាន `0.0150` ដែលបន្ទាប់មកត្រូវបានបង្គត់រហូតដល់ `0.02` ។
//! គោលការណ៍ដូចគ្នានេះត្រូវបានអនុវត្តចំពោះប្រតិបត្តិការផ្សេងទៀតផងដែរប្រសិនបើអ្នកចង់បានភាពត្រឹមត្រូវ 0.5 ULP អ្នកត្រូវធ្វើ *អ្វីគ្រប់យ៉ាងតាមភាពជាក់លាក់និងជុំ* យ៉ាងច្បាស់ម្តងនៅចុងបញ្ចប់ * ដោយពិចារណាលើប៊ីតដែលកាត់ចេញទាំងអស់ក្នុងពេលតែមួយ។
//!
//! FIXME: ទោះបីជាការចម្លងលេខកូដខ្លះចាំបាច់ក៏ដោយផ្នែកខ្លះនៃលេខកូដអាចត្រូវបានរឹបអូសជុំវិញដូចជាលេខកូដតិចត្រូវបានចម្លង។
//! ផ្នែកធំនៃក្បួនដោះស្រាយគឺឯករាជ្យនៃប្រភេទអណ្តែតទៅនឹងលទ្ធផលឬត្រូវការការចូលប្រើថេរមួយចំនួនដែលអាចត្រូវបានបញ្ជូនជាប៉ារ៉ាម៉ែត្រ។
//!
//! # Other
//!
//! ការបំលែងគួរតែមិនដែល * panic ។
//! មានការអះអាងនិង panics ច្បាស់លាស់នៅក្នុងលេខកូដប៉ុន្តែពួកគេមិនគួរត្រូវបានកេះហើយគ្រាន់តែជាការត្រួតពិនិត្យអនាម័យខាងក្នុងប៉ុណ្ណោះ។panics ណាមួយគួរតែត្រូវបានចាត់ទុកថាជាកំហុស។
//!
//! មានការធ្វើតេស្តឯកតាប៉ុន្តែពួកគេមិនមានលក្ខណៈគ្រប់គ្រាន់ក្នុងការធានាឱ្យបានត្រឹមត្រូវពួកគេគ្រាន់តែគ្របដណ្តប់ភាគរយតិចតួចនៃកំហុសដែលអាចកើតមាន។
//! ការធ្វើតេស្តិ៍ទូលំទូលាយជាងនេះមានទីតាំងនៅក្នុងថត `src/etc/test-float-parse` ជាអក្សរ Python ។
//!
//! កំណត់សំគាល់លើចំនួនអតិបរិមាដែលបានហៀរចេញ: ផ្នែកជាច្រើននៃឯកសារនេះអនុវត្តនព្វន្ធជាមួយនិទស្សន្តលេខ `e` ។
//! ជាបឋមយើងប្តូរចំណុចគោលនៅជុំវិញ៖ មុនខ្ទង់ទសភាគដំបូងបន្ទាប់ពីខ្ទង់ទសភាគចុងក្រោយហើយដូច្នេះ។នេះអាចហៀរចេញប្រសិនបើធ្វើដោយមិនប្រុងប្រយ័ត្ន។
//! យើងពឹងផ្អែកលើម៉ូឌុលចែកជាផ្នែកដើម្បីចែកចាយនិទស្សន្តតូចល្មមដែល "sufficient" មានន័យថា "such that the exponent +/- the number of decimal digits fits into a 64 bit integer" ។
//! និទស្សន្តធំ ៗ ត្រូវបានទទួលយកប៉ុន្តែយើងមិនធ្វើនព្វន្ធជាមួយពួកគេទេវាត្រូវបានប្រែក្លាយទៅជា {positive,negative} {zero,infinity} ភ្លាមៗ។
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// ទាំងពីរនេះមានការធ្វើតេស្តផ្ទាល់ខ្លួន។
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// បំលែងខ្សែអក្សរក្នុងគោល ១០ ទៅអណ្តែត។
            /// ព្រមទទួលនិទស្សន្តគោលដប់ជាជម្រើស។
            ///
            /// មុខងារនេះទទួលយកខ្សែដូចជា
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', ឬប្រហាក់ប្រហែល, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', ឬប្រហាក់ប្រហែល '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// ការនាំមុខនិងការដកឃ្លាបង្ហាញពីកំហុស។
            ///
            /// # Grammar
            ///
            /// ខ្សែអក្សរទាំងអស់ដែលប្រកាន់ខ្ជាប់នូវវេយ្យាករណ៍ [EBNF] ខាងក្រោមនឹងបណ្តាលឱ្យ [`Ok`] ត្រូវបានត្រលប់មកវិញ:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # កំហុសដែលគេស្គាល់
            ///
            /// ក្នុងស្ថានភាពខ្លះខ្សែមួយចំនួនដែលគួរតែបង្កើតអណ្តែតត្រឹមត្រូវជំនួសឱ្យមានកំហុស។
            /// សូមមើល [issue #31407] សម្រាប់ព័ត៌មានលម្អិត។
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, ខ្សែអក្សរមួយ
            ///
            /// # តម្លៃត្រឡប់
            ///
            /// `Err(ParseFloatError)` បើខ្សែអក្សរមិនតំណាងឱ្យលេខត្រឹមត្រូវ។
            /// បើមិនដូច្នោះទេ `Ok(n)` ដែល `n` គឺជាលេខអណ្តែតទឹកតំណាងដោយ `src` ។
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// កំហុសមួយដែលអាចត្រូវបានត្រឡប់មកវិញនៅពេលញែកអណ្តែត។
///
/// កំហុសនេះត្រូវបានប្រើជាប្រភេទកំហុសសម្រាប់ការអនុវត្ត [`FromStr`] សម្រាប់ [`f32`] និង [`f64`] ។
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// បំបែកខ្សែលេខគោលដប់ជាសញ្ញានិងនៅសល់ដោយមិនចាំបាច់ត្រួតពិនិត្យឬធ្វើឱ្យមានសុពលភាពលើអ្វីដែលនៅសល់។
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // ប្រសិនបើខ្សែមិនត្រឹមត្រូវយើងមិនដែលប្រើសញ្ញាទេដូច្នេះយើងមិនចាំបាច់ធ្វើឱ្យមានសុពលភាពនៅទីនេះទេ។
        _ => (Sign::Positive, s),
    }
}

/// បម្លែងខ្សែលេខគោលដប់ទៅជាលេខចំណុចអណ្តែត។
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// កម្លាំងពលកម្មសំខាន់សម្រាប់ការបំលែងខ្ទង់ទសភាគ-អណ្តែត៖ រៀបចំរាល់ដំណើរការដែលបានរៀបចំទុកមុននិងរកមើលថាតើក្បួនដោះស្រាយមួយណាដែលគួរធ្វើការបំលែងពិតប្រាកដ។
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift ចេញពីគោលដប់។
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 ត្រូវបានកំណត់ត្រឹម ១២៨០ ប៊ីតដែលប្រែជា ៣៨៥ ខ្ទង់ខ្ទង់។
    // ប្រសិនបើយើងលើសពីនេះយើងនឹងគាំងដូច្នេះយើងមានកំហុសមុនពេលចូលជិតពេក (ក្នុងរយៈពេល 10 10) ។
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // ឥលូវនិទស្សន្តពិតជាសមនឹង ១៦ ប៊ីតដែលត្រូវបានប្រើទូទាំងក្បួនដោះស្រាយសំខាន់ៗ។
    let e = e as i16;
    // FIXME ព្រំដែនទាំងនេះគឺមានលក្ខណៈអភិរក្ស។
    // ការវិភាគប្រុងប្រយ័ត្នជាងមុនអំពីរបៀបនៃការបរាជ័យរបស់ Bellerophon អាចអនុញ្ញាតឱ្យប្រើវាក្នុងករណីជាច្រើនសម្រាប់ការបង្កើនល្បឿនយ៉ាងខ្លាំង។
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// ដូចដែលបានសរសេរនេះធ្វើឱ្យប្រសើរឡើងយ៉ាងធ្ងន់ធ្ងរ (សូមមើល #27130 ទោះបីជាវាសំដៅទៅលើកូដចាស់នៃលេខកូដក៏ដោយ) ។
// `inline(always)` គឺជាដំណោះស្រាយសម្រាប់រឿងនោះ។
// មានតែវែបសាយការហៅទូរស័ព្ទចំនួនពីរប៉ុណ្ណោះហើយវាមិនធ្វើអោយលេខកូដកាន់តែយ៉ាប់យ៉ឺនឡើយ។

/// ខ្សែសូន្យនៅកន្លែងដែលអាចធ្វើទៅបានសូម្បីតែនៅពេលដែលនេះតម្រូវឱ្យមានការផ្លាស់ប្តូរនិទស្សន្ត
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // កាត់សូន្យទាំងនេះមិនផ្លាស់ប្តូរអ្វីទេប៉ុន្តែអាចបើកផ្លូវលឿន (<១៥ ខ្ទង់) ។
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // សំរួលលេខនៃទម្រង់ ០.០ ... x និង x ... ០.០ កែសំរួលស្វ័យគុណស្របតាម។
    // នេះប្រហែលជាមិនតែងតែជាការឈ្នះ (អាចរុញច្រានលេខមួយចំនួនចេញពីផ្លូវលឿន) ប៉ុន្តែវាធ្វើឱ្យផ្នែកផ្សេងទៀតមានភាពងាយស្រួល (ជាពិសេសការប៉ាន់ស្មានទំហំនៃតម្លៃ) ។
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// ត្រឡប់កំណាត់ខាងលើដែលកខ្វក់យ៉ាងរហ័សលើទំហំ (log10) នៃតម្លៃធំបំផុតដែល Algorithm R និង Algorithm M នឹងគណនានៅពេលធ្វើការលើលេខគោលដែលបានផ្តល់។
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // យើងមិនចាំបាច់ព្រួយបារម្ភច្រើនពេកទេអំពីការហៀរសំប៉ែតនៅទីនេះអរគុណដល់ trivial_cases() និងឧបករណ៍ញែកដែលត្រងយកធាតុចូលខ្លាំងបំផុតសម្រាប់យើង។
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // ក្នុងករណីអ៊ី>=០, ក្បួនដោះស្រាយទាំងពីរគណនាអំពី `f * 10^e` ។
        // ក្បួនដោះស្រាយ R ដំណើរការដើម្បីធ្វើការគណនាស្មុគស្មាញមួយចំនួនជាមួយនេះប៉ុន្តែយើងអាចព្រងើយកន្តើយចំពោះបញ្ហាខាងលើព្រោះវាក៏ជួយកាត់បន្ថយប្រភាគជាមុនដែរដូច្នេះយើងមានសតិបណ្ដោះអាសន្ននៅទីនោះ។
        //
        f_len + (e as u64)
    } else {
        // ប្រសិនបើ e <0, ក្បួនដោះស្រាយ R ធ្វើដូចគ្នានឹងដែរប៉ុន្តែ Algorithm M ខុសគ្នា៖
        // វាព្យាយាមរកលេខវិជ្ជមាន k ដែល `f << k / 10^e` គឺជាមធ្យោបាយដែលមាននៅក្នុងជួរ។
        // នេះនឹងមានលទ្ធផលប្រហែល `2^53 *f* 10^e` <`10^17 *f* 10^e` ។
        // ការបញ្ចូលមួយដែលបង្កឱ្យមានបញ្ហានេះគឺ 0.33 ... 33 (375 x 3) ។
        f_len + e.unsigned_abs() + 17
    }
}

/// រកឃើញលំហូរនិងលំហូរចូលជាក់ស្តែងដោយមិនចាំបាច់ក្រឡេកមើលខ្ទង់ទសភាគ។
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // មានលេខសូន្យប៉ុន្តែពួកគេត្រូវបានដកហូតដោយ simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // នេះគឺជាការប៉ាន់ប្រមាណប្រេងឆៅនៃ ceil(log10(the real value)) ។
    // យើងមិនចាំបាច់ព្រួយបារម្ភច្រើនពេកអំពីការហូរហៀរនៅទីនេះទេពីព្រោះប្រវែងបញ្ចូលតូចជាង (យ៉ាងហោចណាស់បើប្រៀបធៀបទៅនឹងលេខ ២ 64 ៦៤) ហើយញែកចែករួចហើយនូវនិទស្សន្តដែលតម្លៃដាច់ខាតធំជាង ១០ ^ ១៨ (ដែលនៅសល់តែ ១០ ^ ១៩ ខ្លី) ។ នៃ 2 ^ 64) ។
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}