//! ប្រភេទកំហុសសម្រាប់បំលែងទៅជាប្រភេទអាំងតេក្រាល។

use crate::convert::Infallible;
use crate::fmt;

/// ប្រភេទកំហុសបានត្រលប់មកវិញនៅពេលការប្តូរប្រភេទអាំងតេក្រាលដែលបានធីកបរាជ័យ។
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // ផ្គូផ្គងជាជាងការបង្ខិតបង្ខំដើម្បីធ្វើឱ្យប្រាកដថាកូដដូចជា `From<Infallible> for TryFromIntError` ខាងលើនឹងនៅតែដំណើរការនៅពេល `Infallible` ក្លាយជាឈ្មោះហៅក្រៅដល់ `!` ។
        //
        //
        match never {}
    }
}

/// កំហុសមួយដែលអាចត្រូវបានត្រឡប់នៅពេលញែកលេខគត់។
///
/// កំហុសនេះត្រូវបានប្រើជាប្រភេទកំហុសសម្រាប់មុខងារ `from_str_radix()` លើប្រភេទចំនួនគត់បឋមដូចជា [`i8::from_str_radix`] ។
///
/// # មូលហេតុដែលអាចកើតមាន
///
/// ក្នុងចំណោមមូលហេតុផ្សេងទៀត `ParseIntError` អាចត្រូវបានគេបោះចោលដោយសារតែការនាំមុខឬដកឃ្លានៅក្នុងខ្សែឧទាហរណ៍នៅពេលដែលទទួលបានពីការបញ្ចូលស្តង់ដារ។
///
/// ការប្រើវិធី [`str::trim()`] ធានាថាមិនមានចន្លោះទទេមុនពេលវិភាគ។
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// អ៊ីមដើម្បីផ្ទុកប្រភេទផ្សេងៗនៃកំហុសដែលអាចបណ្តាលឱ្យញែកលេខគត់បរាជ័យ។
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// តម្លៃកំពុងត្រូវបានវិភាគគឺទទេ។
    ///
    /// ក្នុងចំណោមមូលហេតុផ្សេងទៀតវ៉ារ្យ៉ង់នេះនឹងត្រូវបានសាងសង់នៅពេលញែកខ្សែរទទេ។
    Empty,
    /// មានតួលេខមិនត្រឹមត្រូវនៅក្នុងបរិបទរបស់វា។
    ///
    /// ក្នុងចំណោមបុព្វហេតុផ្សេងទៀតបំរែបំរួលនេះនឹងត្រូវបានសាងសង់នៅពេលដែលវិភាគខ្សែដែលមានឆកមិនមែនអេអេសស៊ីអេ។
    ///
    /// វ៉ារ្យ៉ង់នេះត្រូវបានសាងសង់ផងដែរនៅពេលដែល `+` ឬ `-` ត្រូវបានដាក់មិនត្រឹមត្រូវនៅក្នុងខ្សែអក្សរណាមួយដោយខ្លួនឯងឬពាក់កណ្តាលលេខ។
    ///
    ///
    InvalidDigit,
    /// ចំនួនគត់ធំពេកដើម្បីផ្ទុកក្នុងប្រភេទចំនួនគត់គោលដៅ។
    PosOverflow,
    /// ចំនួនគត់តូចពេកដើម្បីផ្ទុកក្នុងប្រភេទចំនួនគត់គោលដៅ។
    NegOverflow,
    /// តម្លៃគឺសូន្យ
    ///
    /// វ៉ារ្យ៉ង់នេះនឹងត្រូវបានបញ្ចេញនៅពេលខ្សែអក្សរញែកមានតម្លៃសូន្យដែលវានឹងខុសច្បាប់សម្រាប់ប្រភេទមិនមែនសូន្យ។
    ///
    Zero,
}

impl ParseIntError {
    /// បង្ហាញពីមូលហេតុលំអិតនៃការបែងចែកលេខបរាជ័យ។
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}