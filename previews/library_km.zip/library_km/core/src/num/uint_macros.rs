macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// តម្លៃតូចបំផុតដែលអាចត្រូវបានតំណាងដោយប្រភេទចំនួនគត់នេះ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// តម្លៃធំបំផុតដែលអាចត្រូវបានតំណាងដោយប្រភេទចំនួនគត់នេះ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// ទំហំនៃប្រភេទចំនួនគត់នេះជាប៊ីត។
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// បម្លែងចំណិតខ្សែអក្សរក្នុងមូលដ្ឋានដែលបានផ្តល់ទៅឱ្យចំនួនគត់។
        ///
        /// ខ្សែអក្សរត្រូវបានគេរំពឹងថាជាសញ្ញា `+` ស្រេចចិត្តអមដោយតួលេខ។
        ///
        /// ការនាំមុខនិងការដកឃ្លាបង្ហាញពីកំហុស។
        /// ខ្ទង់គឺជាសំណុំរងនៃតួអក្សរទាំងនេះអាស្រ័យលើ `radix`៖
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// មុខងារនេះ panics ប្រសិនបើ `radix` មិនស្ថិតនៅចន្លោះពី 2 ដល់ 36 ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// ត្រឡប់ចំនួននៃលេខមួយនៅក្នុងតំណាងគោលពីរនៃ `self` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// ត្រឡប់លេខសូន្យនៅក្នុងតំណាងគោលពីរនៃ `self` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// ត្រឡប់ចំនួនសូន្យនាំមុខក្នុងការតំណាងគោលពីរនៃ `self` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// ត្រឡប់ចំនួនសូន្យនៅពីក្រោយក្នុងការតំណាងគោលពីរនៃ `self` ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// ត្រឡប់ចំនួនឈានមុខគេក្នុងការតំណាងគោលពីរនៃ `self` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// ត្រឡប់ចំនួននៃការនៅពីក្រោយក្នុងការតំណាងគោលពីរនៃ `self` ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// ផ្លាស់ប្តូរប៊ីតទៅខាងឆ្វេងដោយចំនួនទឹកប្រាក់ដែលបានបញ្ជាក់ `n` រុំប៊ីតដែលកាត់ឱ្យខ្លីទៅចុងបញ្ចប់នៃចំនួនគត់លទ្ធផល។
        ///
        ///
        /// សូមកត់សម្គាល់ថានេះមិនមែនជាប្រតិបត្តិការដូចគ្នានឹងប្រតិបត្តិករផ្លាស់ប្តូរ `<<` ទេ!
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// ផ្លាស់ប្តូរប៊ីតទៅខាងស្តាំដោយចំនួនទឹកប្រាក់ដែលបានបញ្ជាក់ `n` រុំប៊ីតដែលកាត់ឱ្យខ្លីទៅដើមនៃចំនួនគត់លទ្ធផល។
        ///
        ///
        /// សូមកត់សម្គាល់ថានេះមិនមែនជាប្រតិបត្តិការដូចគ្នានឹងប្រតិបត្តិករផ្លាស់ប្តូរ `>>` ទេ!
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// បញ្ច្រាសលំដាប់បៃនៃចំនួនគត់។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// អនុញ្ញាតឱ្យ m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// ដាក់បញ្ច្រាសលំដាប់ប៊ីតនៅក្នុងចំនួនគត់។
        /// ប៊ីតសំខាន់បំផុតក្លាយជាប៊ីតសំខាន់បំផុត-ប៊ីតតូច-សំខាន់បំផុតក្លាយជាប៊ីតសំខាន់ទី ២ ។ ល។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// អនុញ្ញាតឱ្យ m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// បម្លែងចំនួនគត់ពី endian ធំទៅ endianness គោលដៅ។
        ///
        /// នៅលើ endian ធំនេះគឺជាការមិនមាន op ។
        /// នៅលើប៊ែនណេរីតូចបៃត្រូវបានដោះដូរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// បើ cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } ផ្សេងទៀត {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// បំលែងចំនួនគត់ពីឥន្ធិនតិចទៅជាការគាំទ្ររបស់គោលដៅ។
        ///
        /// នៅលើ endian តិចតួចនេះគឺជាការមិនមាន។
        /// នៅលើ endian ធំបៃត្រូវបានផ្លាស់ប្តូរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// បើ cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } ផ្សេងទៀត {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// បំលែង `self` ទៅអិដ្ឋិនធំពីការព្យាយាមរបស់គោលដៅ។
        ///
        /// នៅលើ endian ធំនេះគឺជាការមិនមាន op ។
        /// នៅលើប៊ែនណេរីតូចបៃត្រូវបានដោះដូរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// បើ cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ផ្សេងទៀត { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ឬមិនត្រូវ?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// បំលែង `self` ទៅ endian តិចតួចពីការគាំទ្រគោលដៅ។
        ///
        /// នៅលើ endian តិចតួចនេះគឺជាការមិនមាន។
        /// នៅលើ endian ធំបៃត្រូវបានផ្លាស់ប្តូរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// បើ cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ផ្សេងទៀត { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// បានពិនិត្យបន្ថែមចំនួនគត់។
        /// គណនា `self + rhs` ត្រឡប់ `None` ប្រសិនបើលើសចំណុះកើតឡើង។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// មិនបានធីកចំនួនបន្ថែម។ការគណនា `self + rhs` សន្មតថាការហូរហៀរមិនអាចកើតឡើងបានទេ។
        /// លទ្ធផលនេះនឹងមានអាកប្បកិរិយាដែលមិនបានកំណត់នៅពេល
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `unchecked_add` ។
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// សញ្ញាដកចំនួនគត់ដែលបានពិនិត្យ។
        /// គណនា `self - rhs` ត្រឡប់ `None` ប្រសិនបើលើសចំណុះកើតឡើង។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ការដកលេខគត់ដែលមិនបានធីក។ការគណនា `self - rhs` សន្មតថាការហូរហៀរមិនអាចកើតឡើងបានទេ។
        /// លទ្ធផលនេះនឹងមានអាកប្បកិរិយាដែលមិនបានកំណត់នៅពេល
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `unchecked_sub` ។
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// ធីកមេគុណចំនួនគត់។
        /// គណនា `self * rhs` ត្រឡប់ `None` ប្រសិនបើលើសចំណុះកើតឡើង។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// មិនធីកមេគុណគុណ។ការគណនា `self * rhs` សន្មតថាការហូរហៀរមិនអាចកើតឡើងបានទេ។
        /// លទ្ធផលនេះនឹងមានអាកប្បកិរិយាដែលមិនបានកំណត់នៅពេល
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `unchecked_mul` ។
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// បានពិនិត្យផ្នែកចំនួនគត់។
        /// គណនា `self / rhs` ត្រឡប់ `None` ប្រសិនបើ `rhs == 0` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // សុវត្ថិភាព: div ដោយសូន្យត្រូវបានគូសធីកខាងលើហើយប្រភេទដែលមិនទាន់ចុះហត្ថលេខាគ្មានប្រភេទផ្សេងទៀតទេ
                // របៀបបរាជ័យសម្រាប់ការបែងចែក
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// បានពិនិត្យផ្នែកអឺអឺក្លីដាន។
        /// គណនា `self.div_euclid(rhs)` ត្រឡប់ `None` ប្រសិនបើ `rhs == 0` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// បានត្រួតពិនិត្យចំនួនគត់ដែលនៅសល់។
        /// គណនា `self % rhs` ត្រឡប់ `None` ប្រសិនបើ `rhs == 0` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // សុវត្ថិភាព: div ដោយសូន្យត្រូវបានគូសធីកខាងលើហើយប្រភេទដែលមិនទាន់ចុះហត្ថលេខាគ្មានប្រភេទផ្សេងទៀតទេ
                // របៀបបរាជ័យសម្រាប់ការបែងចែក
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// បានពិនិត្យម៉ូឌីក្លូឌាម៉ូល។
        /// គណនា `self.rem_euclid(rhs)` ត្រឡប់ `None` ប្រសិនបើ `rhs == 0` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// បានពិនិត្យភាពអវិជ្ជមាន។គណនា `-self` ត្រឡប់ `None` លើកលែងតែ `ខ្លួនឯង==
        /// 0`.
        ///
        /// ចំណាំថាការធ្វើឱ្យអវិជ្ជមានដល់ចំនួនគត់វិជ្ជមាននឹងហៀរចេញ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// ពិនិត្យមើលការផ្លាស់ប្តូរខាងឆ្វេង។
        /// គណនា `self << rhs` ត្រឡប់ `None` ប្រសិនបើ `rhs` ធំជាងឬស្មើនឹងចំនួនប៊ីតក្នុង `self` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// បានពិនិត្យមើលការផ្លាស់ប្តូរស្តាំ។
        /// គណនា `self >> rhs` ត្រឡប់ `None` ប្រសិនបើ `rhs` ធំជាងឬស្មើនឹងចំនួនប៊ីតក្នុង `self` ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// និទស្សន្តបានពិនិត្យ។
        /// គណនា `self.pow(exp)` ត្រឡប់ `None` ប្រសិនបើលើសចំណុះកើតឡើង។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // ចាប់តាំងពី exp!=០, ទីបំផុត exp ត្រូវតែ ១ ។
            // ដោះស្រាយជាមួយនិទស្សន្តចុងក្រោយនៃនិទស្សន្តដាច់ដោយឡែកពីគ្នាចាប់តាំងពីការបោសមូលដ្ឋានបន្ទាប់មកមិនចាំបាច់ហើយអាចបណ្តាលឱ្យមានការហៀរចេញ។
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// ការបន្ថែមចំនួនគត់រោទ៍។
        /// គណនា `self + rhs`, saturating នៅព្រំដែនលេខជំនួសឱ្យការហូរហៀរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// ដកលេខគត់។
        /// គណនា `self - rhs`, saturating នៅព្រំដែនលេខជំនួសឱ្យការហូរហៀរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// មេគុណអាំងតេក្រាល។
        /// គណនា `self * rhs`, saturating នៅព្រំដែនលេខជំនួសឱ្យការហូរហៀរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// និទស្សន្តអាំងតេក្រាលចំនួនគត់។
        /// គណនា `self.pow(exp)`, saturating នៅព្រំដែនលេខជំនួសឱ្យការហូរហៀរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// រុំបន្ថែម (modular) ។
        /// គណនា `self + rhs` រុំជុំវិញព្រំដែននៃប្រភេទ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// រុំដក (modular) ។
        /// គណនា `self - rhs` រុំជុំវិញព្រំដែននៃប្រភេទ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// រុំគុណ (modular) ។
        /// គណនា `self * rhs` រុំជុំវិញព្រំដែននៃប្រភេទ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// សូមកត់សម្គាល់ថាឧទាហរណ៍នេះត្រូវបានចែករំលែករវាងប្រភេទចំនួនគត់។
        /// ដែលពន្យល់ពីមូលហេតុដែល `u8` ត្រូវបានប្រើនៅទីនេះ។
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// រុំផ្នែក (modular) ។ការគណនា `self / rhs` ។
        /// ការបែងចែកតាមប្រភេទដែលមិនទាន់ចុះហត្ថលេខាគឺគ្រាន់តែជាការបែងចែកធម្មតាប៉ុណ្ណោះ។
        /// មិនមានវិធីរុំអាចកើតឡើងបានទេ។
        /// មុខងារនេះមានដូច្នេះប្រតិបត្តិការទាំងអស់ត្រូវបានរាប់បញ្ចូលក្នុងប្រតិបត្តិការរុំ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// រុំផ្នែកអ៊ីអ៊ែក្លាដាន។ការគណនា `self.div_euclid(rhs)` ។
        /// ការបែងចែកតាមប្រភេទដែលមិនទាន់ចុះហត្ថលេខាគឺគ្រាន់តែជាការបែងចែកធម្មតាប៉ុណ្ណោះ។
        /// មិនមានវិធីរុំអាចកើតឡើងបានទេ។
        /// មុខងារនេះមានដូច្នេះប្រតិបត្តិការទាំងអស់ត្រូវបានរាប់បញ្ចូលក្នុងប្រតិបត្តិការរុំ។
        /// ចាប់តាំងពីសម្រាប់ចំនួនគត់វិជ្ជមានរាល់និយមន័យទូទៅនៃការបែងចែកគឺស្មើគ្នានេះគឺស្មើនឹង `self.wrapping_div(rhs)` ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// រុំនៅសល់ (modular) ។ការគណនា `self % rhs` ។
        /// ការគណនានៅសល់រុំនៅលើប្រភេទដែលមិនទាន់ចុះហត្ថលេខាគឺគ្រាន់តែជាការគណនានៅសល់ទៀងទាត់។
        ///
        /// មិនមានវិធីរុំអាចកើតឡើងបានទេ។
        /// មុខងារនេះមានដូច្នេះប្រតិបត្តិការទាំងអស់ត្រូវបានរាប់បញ្ចូលក្នុងប្រតិបត្តិការរុំ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// រុំ Euclidean modulo ។ការគណនា `self.rem_euclid(rhs)` ។
        /// ការគណនាម៉ូឌុលរុំលើប្រភេទដែលមិនបានចុះហត្ថលេខាគឺគ្រាន់តែជាការគណនានៅសល់ធម្មតាប៉ុណ្ណោះ។
        /// មិនមានវិធីរុំអាចកើតឡើងបានទេ។
        /// មុខងារនេះមានដូច្នេះប្រតិបត្តិការទាំងអស់ត្រូវបានរាប់បញ្ចូលក្នុងប្រតិបត្តិការរុំ។
        /// ចាប់តាំងពីសម្រាប់ចំនួនគត់វិជ្ជមានរាល់និយមន័យទូទៅនៃការបែងចែកគឺស្មើគ្នានេះគឺស្មើនឹង `self.wrapping_rem(rhs)` ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// រុំអវិជ្ជមាន (modular) ។
        /// គណនា `-self` រុំជុំវិញព្រំដែននៃប្រភេទ។
        ///
        /// ចាប់តាំងពីប្រភេទដែលមិនបានចុះហត្ថលេខាមិនមានភាពស្មើគ្នាអវិជ្ជមានកម្មវិធីទាំងអស់នៃមុខងារនេះនឹងរុំ (លើកលែងតែ `-0`) ។
        /// ចំពោះតម្លៃតូចជាងអតិបរមានៃប្រភេទដែលបានចុះហត្ថលេខាត្រូវគ្នាលទ្ធផលគឺដូចគ្នានឹងការបោះតម្លៃដែលបានចុះហត្ថលេខាដែលត្រូវគ្នា។
        ///
        /// តម្លៃធំជាងណាមួយស្មើនឹង `MAX + 1 - (val - MAX - 1)` ដែល `MAX` ជាចំនួនអតិបរមារបស់ប្រភេទដែលត្រូវគ្នា។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// សូមកត់សម្គាល់ថាឧទាហរណ៍នេះត្រូវបានចែករំលែករវាងប្រភេទចំនួនគត់។
        /// ដែលពន្យល់ពីមូលហេតុដែល `i8` ត្រូវបានប្រើនៅទីនេះ។
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// ការផ្លាស់ប្តូរប៊ីត Panic-ឥតគិតថ្លៃ;
        /// ផ្តល់ទិន្នផល `self << mask(rhs)`, ដែល `mask` យកប៊ីតលំដាប់ខ្ពស់នៃ `rhs` ដែលបណ្តាលឱ្យការផ្លាស់ប្តូរលើសពីកម្រិតប៊ីតនៃប្រភេទ។
        ///
        /// ចំណាំថានេះគឺ *មិន* ដូចគ្នានឹងការបង្វិលខាងឆ្វេងទេ។RHS នៃការផ្លាស់ប្តូរវេន-ឆ្វេងត្រូវបានដាក់កម្រិតទៅនឹងជួរនៃប្រភេទជាជាងប៊ីតដែលផ្លាស់ប្តូរចេញពី LHS កំពុងត្រូវបានត្រលប់ទៅចុងម្ខាងទៀត។
        /// ប្រភេទចំនួនគត់បឋមអនុវត្តមុខងារ [`rotate_left`](Self::rotate_left) ដែលអាចជាអ្វីដែលអ្នកចង់បានជំនួសវិញ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // សុវត្ថិភាព: ការបិទបាំងដោយប៊ីតនៃប្រភេទធានាថាយើងមិនផ្លាស់ប្តូរ
            // នៅក្រៅព្រំដែន
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// ការផ្លាស់ប្តូរប៊ីតហ្សែនដោយឥតគិតថ្លៃ-ហ្សែនផិ ន០Z;
        /// ផ្តល់ទិន្នផល `self >> mask(rhs)`, ដែល `mask` យកប៊ីតលំដាប់ខ្ពស់នៃ `rhs` ដែលបណ្តាលឱ្យការផ្លាស់ប្តូរលើសពីកម្រិតប៊ីតនៃប្រភេទ។
        ///
        /// ចំណាំថានេះគឺមិន * ដូចគ្នានឹងការបង្វិលខាងស្តាំ;RHS នៃការផ្លាស់ប្តូរវេនខាងស្តាំរុំត្រូវបានកំណត់ចំពោះជួរនៃប្រភេទជាជាងប៊ីតដែលផ្លាស់ចេញពី LHS កំពុងត្រូវបានត្រលប់ទៅចុងម្ខាងទៀត។
        /// ប្រភេទចំនួនគត់បឋមអនុវត្តមុខងារ [`rotate_right`](Self::rotate_right) ដែលអាចជាអ្វីដែលអ្នកចង់បានជំនួសវិញ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // សុវត្ថិភាព: ការបិទបាំងដោយប៊ីតនៃប្រភេទធានាថាយើងមិនផ្លាស់ប្តូរ
            // នៅក្រៅព្រំដែន
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// រុំនិទស្សន្ត (modular) X ។
        /// គណនា `self.pow(exp)` រុំជុំវិញព្រំដែននៃប្រភេទ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ចាប់តាំងពី exp!=០, ទីបំផុត exp ត្រូវតែ ១ ។
            // ដោះស្រាយជាមួយនិទស្សន្តចុងក្រោយនៃនិទស្សន្តដាច់ដោយឡែកពីគ្នាចាប់តាំងពីការបោសមូលដ្ឋានបន្ទាប់មកមិនចាំបាច់ហើយអាចបណ្តាលឱ្យមានការហៀរចេញ។
            //
            //
            acc.wrapping_mul(base)
        }

        /// គណនា `self` + `rhs`
        ///
        /// ត្រឡប់ការបន្ថែមនៃបូករួមជាមួយប៊ូលីនដែលចង្អុលបង្ហាញថាតើការហៀរចេញពីនព្វន្ធនឹងកើតឡើងដែរឬទេ។
        /// ប្រសិនបើការហៀរចេញនឹងកើតឡើងនោះតម្លៃរុំត្រូវបានត្រឡប់មកវិញ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// គណនា `self`, `rhs`
        ///
        /// ត្រឡប់ការដកនៃដករួមជាមួយប៊ូលីនចង្អុលបង្ហាញថាតើការហៀរលេខនព្វន្ធនឹងកើតឡើង។
        /// ប្រសិនបើការហៀរចេញនឹងកើតឡើងនោះតម្លៃរុំត្រូវបានត្រឡប់មកវិញ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// គណនាគុណ `self` និង `rhs` ។
        ///
        /// ត្រឡប់ធរណីមាត្រនៃមេគុណរួមជាមួយប៊ូលីនបង្ហាញថាតើការហៀរចេញនព្វន្ធនឹងកើតឡើងដែរឬទេ។
        /// ប្រសិនបើការហៀរចេញនឹងកើតឡើងនោះតម្លៃរុំត្រូវបានត្រឡប់មកវិញ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// សូមកត់សម្គាល់ថាឧទាហរណ៍នេះត្រូវបានចែករំលែករវាងប្រភេទចំនួនគត់។
        /// ដែលពន្យល់ពីមូលហេតុដែល `u32` ត្រូវបានប្រើនៅទីនេះ។
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// គណនាតួចែកនៅពេល `self` ចែកដោយ `rhs` ។
        ///
        /// ត្រឡប់នព្វន្តនៃតួចែករួមជាមួយប៊ូលីនចង្អុលថាតើការហូរចូលនព្វន្ធនឹងកើតឡើងឬអត់។
        /// ចំណាំថាសម្រាប់ចំនួនគត់ដែលមិនបានចុះហត្ថលេខាមិនមានលើសចំណុះទេដូច្នេះតម្លៃទីពីរគឺតែងតែជា `false` ។
        ///
        /// # Panics
        ///
        /// មុខងារនេះនឹង panic ប្រសិនបើ `rhs` គឺ 0 ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// គណនាផលចែកនៃការបែងចែកអឺអឺក្លាដ `self.div_euclid(rhs)` ។
        ///
        /// ត្រឡប់នព្វន្តនៃតួចែករួមជាមួយប៊ូលីនចង្អុលថាតើការហូរចូលនព្វន្ធនឹងកើតឡើងឬអត់។
        /// ចំណាំថាសម្រាប់ចំនួនគត់ដែលមិនបានចុះហត្ថលេខាមិនមានលើសចំណុះទេដូច្នេះតម្លៃទីពីរគឺតែងតែជា `false` ។
        /// ចាប់តាំងពីសម្រាប់ចំនួនគត់វិជ្ជមានរាល់និយមន័យទូទៅនៃការបែងចែកគឺស្មើគ្នានេះគឺស្មើនឹង `self.overflowing_div(rhs)` ។
        ///
        ///
        /// # Panics
        ///
        /// មុខងារនេះនឹង panic ប្រសិនបើ `rhs` គឺ 0 ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// គណនានៅសល់ពេល `self` ចែកនឹង `rhs` ។
        ///
        /// ត្រឡប់ចំនួនដែលនៅសល់បន្ទាប់ពីបែងចែកនឹងប៊ូលីនដែលចង្អុលបង្ហាញថាតើចំណុះនព្វន្ធនឹងកើតឡើងឬអត់។
        /// ចំណាំថាសម្រាប់ចំនួនគត់ដែលមិនបានចុះហត្ថលេខាមិនមានលើសចំណុះទេដូច្នេះតម្លៃទីពីរគឺតែងតែជា `false` ។
        ///
        /// # Panics
        ///
        /// មុខងារនេះនឹង panic ប្រសិនបើ `rhs` គឺ 0 ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// គណនាចំនួន `self.rem_euclid(rhs)` ដែលនៅសេសសល់ដូចជាការបែងចែកអឺរុដឌីន។
        ///
        /// ត្រឡប់ម៉ូឌុលមួយបន្ទាប់ពីចែកជាមួយប៊ូលីនចង្អុលបង្ហាញថាតើនព្វន្តហៀរចេញ។
        /// ចំណាំថាសម្រាប់ចំនួនគត់ដែលមិនបានចុះហត្ថលេខាមិនមានលើសចំណុះទេដូច្នេះតម្លៃទីពីរគឺតែងតែជា `false` ។
        /// ចាប់តាំងពីសម្រាប់ចំនួនគត់វិជ្ជមានរាល់និយមន័យទូទៅនៃការបែងចែកគឺស្មើគ្នាប្រតិបត្តិការនេះគឺស្មើនឹង `self.overflowing_rem(rhs)` ។
        ///
        ///
        /// # Panics
        ///
        /// មុខងារនេះនឹង panic ប្រសិនបើ `rhs` គឺ 0 ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ចរចាដោយខ្លួនឯងនៅក្នុងរបៀបដែលហៀរចេញ។
        ///
        /// ត្រឡប់ `!self + 1` ដោយប្រើប្រតិបត្តិការរុំដើម្បីប្រគល់តម្លៃដែលតំណាងឱ្យភាពអវិជ្ជមាននៃតម្លៃដែលមិនបានចុះហត្ថលេខានេះ។
        /// ចំណាំថាសម្រាប់គុណតម្លៃដែលមិនបានចុះហត្ថលេខាវិជ្ជមានតែងតែកើតឡើងប៉ុន្តែអវិជ្ជមាន ០ មិនហៀរចេញ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// ការផ្លាស់ប្តូរខ្លួនឯងនៅខាងឆ្វេងដោយប៊ីច `rhs` X ប៊ីត។
        ///
        /// ត្រឡប់ការផ្លាស់ប្តូរនៃការផ្លាស់ប្តូរដោយខ្លួនឯងរួមជាមួយប៊ូលីនដែលចង្អុលបង្ហាញថាតើតម្លៃផ្លាស់ប្តូរធំជាងឬស្មើនឹងចំនួនប៊ីត។
        /// ប្រសិនបើតម្លៃផ្លាស់ប្តូរធំពេកបន្ទាប់មកតម្លៃត្រូវបានបិទបាំង (N-1) ដែល N ជាចំនួនប៊ីតហើយបន្ទាប់មកតម្លៃនេះត្រូវបានប្រើដើម្បីអនុវត្តការផ្លាស់ប្តូរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// ផ្លាស់ប្តូរខ្លួនឯងដោយប៊ីត `rhs` ។
        ///
        /// ត្រឡប់ការផ្លាស់ប្តូរនៃការផ្លាស់ប្តូរដោយខ្លួនឯងរួមជាមួយប៊ូលីនដែលចង្អុលបង្ហាញថាតើតម្លៃផ្លាស់ប្តូរធំជាងឬស្មើនឹងចំនួនប៊ីត។
        /// ប្រសិនបើតម្លៃផ្លាស់ប្តូរធំពេកបន្ទាប់មកតម្លៃត្រូវបានបិទបាំង (N-1) ដែល N ជាចំនួនប៊ីតហើយបន្ទាប់មកតម្លៃនេះត្រូវបានប្រើដើម្បីអនុវត្តការផ្លាស់ប្តូរ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// បង្កើនខ្លួនឯងទៅនឹងថាមពលនៃ `exp` ដោយប្រើនិទស្សន្តដោយការគ្រហឹម។
        ///
        /// ត្រឡប់ស្វ័យគុណនៃនិទស្សន្តរួមជាមួយ bool ដែលបង្ហាញថាតើការហូរហៀរកើតឡើង។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (២១៧, ពិត));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // កោសកន្លែងសម្រាប់រក្សាទុកលទ្ធផលនៃការហៀរទឹកហូរ។
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ចាប់តាំងពី exp!=០, ទីបំផុត exp ត្រូវតែ ១ ។
            // ដោះស្រាយជាមួយនិទស្សន្តចុងក្រោយនៃនិទស្សន្តដាច់ដោយឡែកពីគ្នាចាប់តាំងពីការបោសមូលដ្ឋានបន្ទាប់មកមិនចាំបាច់ហើយអាចបណ្តាលឱ្យមានការហៀរចេញ។
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// បង្កើនខ្លួនឯងទៅនឹងថាមពលនៃ `exp` ដោយប្រើនិទស្សន្តដោយការគ្រហឹម។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ចាប់តាំងពី exp!=០, ទីបំផុត exp ត្រូវតែ ១ ។
            // ដោះស្រាយជាមួយនិទស្សន្តចុងក្រោយនៃនិទស្សន្តដាច់ដោយឡែកពីគ្នាចាប់តាំងពីការបោសមូលដ្ឋានបន្ទាប់មកមិនចាំបាច់ហើយអាចបណ្តាលឱ្យមានការហៀរចេញ។
            //
            //
            acc * base
        }

        /// អនុវត្តការបែងចែក Euclidean ។
        ///
        /// ចាប់តាំងពីសម្រាប់ចំនួនគត់វិជ្ជមានរាល់និយមន័យទូទៅនៃការបែងចែកគឺស្មើគ្នានេះពិតជាស្មើនឹង `self / rhs` ។
        ///
        ///
        /// # Panics
        ///
        /// មុខងារនេះនឹង panic ប្រសិនបើ `rhs` គឺ 0 ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// គណនាចំនួននៅសល់តិចបំផុតនៃ `self (mod rhs)` ។
        ///
        /// ចាប់តាំងពីសម្រាប់ចំនួនគត់វិជ្ជមានរាល់និយមន័យទូទៅនៃការបែងចែកគឺស្មើគ្នានេះគឺស្មើនឹង `self % rhs` ។
        ///
        ///
        /// # Panics
        ///
        /// មុខងារនេះនឹង panic ប្រសិនបើ `rhs` គឺ 0 ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// ត្រឡប់ `true` ប្រសិនបើនិងមានតែប្រសិនបើ `self == 2^k` សម្រាប់ `k` ខ្លះ។
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // ត្រឡប់មួយតូចជាងថាមពលបន្ទាប់នៃពីរ។
        // (សម្រាប់ថាមពល ៨.៨ បន្ទាប់នៃពីរគឺ ៨ អឺ ៨ និងសម្រាប់ ៦ អឺ ៨ វាគឺ ៨ អឺ ៨)
        //
        // 8u8.one_less_than_next_power_of_two() ==៧
        // 6u8.one_less_than_next_power_of_two() ==៧
        //
        // វិធីសាស្រ្តនេះមិនអាចហៀរចេញបានទេដូចជាករណី `next_power_of_two` ហៀរចេញវាជំនួសឱ្យការត្រឡប់មកវិញនូវតម្លៃអតិបរិមានៃប្រភេទហើយអាចត្រឡប់មកវិញលេខ 0 សម្រាប់លេខ 0 ។
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // សុវត្ថិភាព: ដោយសារតែ `p > 0` វាមិនអាចមានលេខសូន្យនាំមុខទាំងអស់ទេ។
            // នោះមានន័យថាការផ្លាស់ប្តូរតែងតែស្ថិតនៅក្នុងព្រំដែនហើយអ្នកកែច្នៃខ្លះ (ដូចជា intel pre-haswell) មានប្រសិទ្ធិភាពកាន់តែស៊ីជម្រៅនៅពេលដែលអាគុយម៉ង់មិនសូន្យ។
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// ត្រឡប់ថាមពលតូចបំផុតនៃពីរធំជាងឬស្មើ `self` ។
        ///
        /// នៅពេលតម្លៃត្រឡប់មកវិញហូរហៀរ (ឧទាហរណ៍ `self > (1 << (N-1))` សម្រាប់ប្រភេទ `uN`) វា panics នៅក្នុងរបៀបបំបាត់កំហុសហើយតម្លៃត្រឡប់មកវិញត្រូវបានរុំទៅ 0 នៅក្នុងរបៀបដោះលែង (ស្ថានភាពតែមួយគត់ដែលវិធីសាស្ត្រអាចត្រឡប់មកវិញ 0) ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// ត្រឡប់ថាមពលតូចបំផុតនៃពីរធំជាងឬស្មើ `n` ។
        /// ប្រសិនបើថាមពលបន្ទាប់នៃពីរគឺធំជាងតម្លៃអតិបរមារបស់ប្រភេទនោះ `None` ត្រូវបានត្រឡប់មកវិញបើមិនដូច្នោះទេថាមពលពីរត្រូវបានរុំដោយ `Some` ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// ត្រឡប់ថាមពលតូចបំផុតនៃពីរធំជាងឬស្មើ `n` ។
        /// ប្រសិនបើថាមពលបន្ទាប់នៃពីរគឺធំជាងតម្លៃអតិបរមារបស់ប្រភេទនោះតម្លៃត្រឡប់ត្រូវបានរុំទៅ `0` ។
        ///
        ///
        /// # Examples
        ///
        /// ការប្រើប្រាស់មូលដ្ឋាន៖
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// ត្រឡប់ការតំណាងសតិនៃចំនួនគត់នេះជាអារេបៃក្នុងលំដាប់ (network) បៃធំ។
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ត្រឡប់ការតំណាងសតិនៃចំនួនគត់នេះជាអារេបៃនៅក្នុងលំដាប់បៃដែលមានតិចតួច។
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// ត្រឡប់ការតំណាងសតិនៃចំនួនគត់នេះជាអារេបៃតាមលំដាប់បៃ។
        ///
        /// នៅពេលឧបករណ៍ប្រើប្រាស់ដើមរបស់វេទិកាគោលដៅត្រូវបានប្រើលេខកូដចល័តគួរតែប្រើ [`to_be_bytes`] ឬ [`to_le_bytes`] តាមដែលសមរម្យជំនួសវិញ។
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     បៃ, បើ cfg! (គោលដៅ _endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } ផ្សេងទៀត {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // សុវត្តិៈសំឡេងថេរពីព្រោះចំនួនគត់គឺជាទិន្នន័យដើមចាស់ធម្មតាដូច្នេះយើងអាចធ្វើបានជានិច្ច
        // បញ្ជូនពួកវាទៅអារេបៃ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // សុវត្ថិភាព: ចំនួនគត់គឺជាតាតាចាស់ចាស់ធម្មតាដូច្នេះយើងអាចបញ្ជូនវាទៅ
            // អារេបៃ
            unsafe { mem::transmute(self) }
        }

        /// ត្រឡប់ការតំណាងសតិនៃចំនួនគត់នេះជាអារេបៃតាមលំដាប់បៃ។
        ///
        ///
        /// [`to_ne_bytes`] គួរតែត្រូវបានពេញចិត្តជាងនេះនៅពេលណាដែលអាចធ្វើទៅបាន។
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// អនុញ្ញាតឱ្យបៃ= num.as_ne_bytes();
        /// assert_eq!(
        ///     បៃ, បើ cfg! (គោលដៅ _endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } ផ្សេងទៀត {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // សុវត្ថិភាព: ចំនួនគត់គឺជាតាតាចាស់ចាស់ធម្មតាដូច្នេះយើងអាចបញ្ជូនវាទៅ
            // អារេបៃ
            unsafe { &*(self as *const Self as *const _) }
        }

        /// បង្កើតតម្លៃចំនួនគត់ endian ដើមពីការតំណាងរបស់វាជាអារេបៃនៅក្នុង endian ធំ។
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ប្រើ std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ការបញ្ចូល=នៅសល់;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// បង្កើតតម្លៃចំនួនគត់ endian ដើមពីការតំណាងរបស់វាជាអារេបៃនៅក្នុង endian តិចតួច។
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ប្រើ std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ការបញ្ចូល=នៅសល់;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// បង្កើតតម្លៃចំនួនគត់ endian ដើមពីការតំណាងការចងចាំរបស់វាជាអារេបៃនៅក្នុង endianness ដើម។
        ///
        /// នៅពេលឧបករណ៍ប្រើប្រាស់ដើមរបស់វេទិកាគោលដៅត្រូវបានប្រើលេខកូដចល័តទំនងជាចង់ប្រើ [`from_be_bytes`] ឬ [`from_le_bytes`] ដែលសមរម្យជំនួសវិញ។
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } ផ្សេងទៀត {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// ប្រើ std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ការបញ្ចូល=នៅសល់;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // សុវត្តិៈសំឡេងថេរពីព្រោះចំនួនគត់គឺជាទិន្នន័យដើមចាស់ធម្មតាដូច្នេះយើងអាចធ្វើបានជានិច្ច
        // បញ្ជូនទៅពួកគេ
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // សុវត្ថិភាព: ចំនួនគត់គឺជាតាតាចាស់ចាស់ធម្មតាដូច្នេះយើងអាចបញ្ជូនទៅពួកគេជានិច្ច
            unsafe { mem::transmute(bytes) }
        }

        /// លេខកូដថ្មីគួរតែចូលចិត្តប្រើ
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ត្រឡប់តម្លៃតូចបំផុតដែលអាចត្រូវបានតំណាងដោយប្រភេទចំនួនគត់នេះ។
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// លេខកូដថ្មីគួរតែចូលចិត្តប្រើ
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ត្រឡប់តម្លៃធំបំផុតដែលអាចត្រូវបានតំណាងដោយប្រភេទចំនួនគត់នេះ។
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}