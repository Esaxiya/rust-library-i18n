//! ការអនុវត្តន៍ (bignum) ចំនួនជាក់លាក់តាមទំនើងចិត្ត។
//!
//! នេះត្រូវបានរចនាឡើងដើម្បីជៀសវាងការបែងចែកគំនរដោយចំណាយលើសតិជង់។
//! ប្រភេទ bignum ដែលត្រូវបានគេប្រើច្រើនជាងគេគឺ `Big32x40` ត្រូវបានកំណត់ដោយ 32 × 40=1,280 ប៊ីតហើយនឹងមានទំហំមេម៉ូរីចំនួន ១៦០ បៃ។
//! នេះគឺច្រើនជាងគ្រប់គ្រាន់សម្រាប់ការទាញយកតម្លៃដែលអាចធ្វើបានទាំងអស់ `f64` X ។
//!
//! ជាគោលការណ៍វាអាចទៅរួចដែលមានប្រភេទ bignum ច្រើនប្រភេទសម្រាប់ធាតុបញ្ចូលផ្សេងៗគ្នាប៉ុន្តែយើងមិនធ្វើដូច្នេះទេដើម្បីចៀសវាងការហើមពោះកូដ។
//!
//! ប៊ីចេងនិមួយៗនៅតែត្រូវបានតាមដានសម្រាប់ការប្រើប្រាស់ជាក់ស្តែងដូច្នេះជាធម្មតាវាមិនមានបញ្ហាទេ។
//!

// ម៉ូឌុលនេះគឺសម្រាប់តែ dec2flt និង flt2dec ប៉ុណ្ណោះហើយអាចប្រើបានជាសាធារណៈដោយសារតែកម្មវិធីស្នូល។
// វាមិនមានបំណងធ្វើឱ្យមានស្ថេរភាពទេ។
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// ប្រតិបត្ដិការនព្វន្ធទាមទារដោយ bignums ។
pub trait FullOps: Sized {
    /// ត្រឡប់ `(carry', v')` ដូចជា `carry' * 2^W + v' = self + other + carry` ដែល `W` គឺជាចំនួនប៊ីតនៅក្នុង `Self` ។
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// ត្រឡប់ `(carry', v')` ដូចជា `carry'*2^W + v' = self* other + carry` ដែល `W` គឺជាចំនួនប៊ីតនៅក្នុង `Self` ។
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// ត្រឡប់ `(carry', v')` ដូចជា `carry'*2^W + v' = self* other + other2 + carry` ដែល `W` គឺជាចំនួនប៊ីតនៅក្នុង `Self` ។
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// ត្រឡប់ `(quo, rem)` ដូចជា `borrow *2^W + self = quo* other + rem` និង `0 <= rem < other` ដែល `W` គឺជាចំនួនប៊ីតនៅក្នុង `Self` ។
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // នេះមិនអាចហៀរចេញបានទេ។លទ្ធផលគឺរវាង `0` និង `2 * 2^nbits - 1` ។
                    // FIXME: តើអិលអិមអិមអេសនឹងបង្កើនប្រសិទ្ធភាពនេះទៅជាអេឌីស៊ីឬស្រដៀងគ្នាទេ?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // នេះមិនអាចហៀរចេញបានទេ។
                    // លទ្ធផលគឺរវាង `0` និង `2^nbits * (2^nbits - 1)` ។
                    // FIXME: តើអិលអិមអិមអេសនឹងបង្កើនប្រសិទ្ធភាពនេះទៅជាអេឌីស៊ីឬស្រដៀងគ្នាទេ?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // នេះមិនអាចហៀរចេញបានទេ។
                    // លទ្ធផលគឺរវាង `0` និង `2^nbits * (2^nbits - 1)` ។
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // នេះមិនអាចហៀរចេញបានទេ។លទ្ធផលគឺរវាង `0` និង `other * (2^nbits - 1)` ។
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // សូមមើល RFC #521 សម្រាប់ដំណើរការនេះ។
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// តារាងអានុភាពដែលមាន ៥ តំណាងនៅក្នុងខ្ទង់។ជាពិសេសតម្លៃ {u8, u16, u32} ធំជាងគេដែលជាថាមពលប្រាំបូកនឹងនិទស្សន្តដែលត្រូវគ្នា។
/// ប្រើក្នុង `mul_pow5` ។
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// ចំនួនជង់បែងចែកតាមទំនើងចិត្ត-ភាពជាក់លាក់ (រហូតដល់កំរិតជាក់លាក់) ចំនួនគត់។
        ///
        /// នេះត្រូវបានគាំទ្រដោយអារេទំហំថេរនៃប្រភេទ ("digit") ដែលបានផ្តល់ឱ្យ។
        /// ខណៈពេលដែលអារេមិនមានទំហំធំ (ជាធម្មតារាប់រយបៃ) ការចម្លងវាដោយមិនប្រុងប្រយ័ត្នអាចបណ្តាលឱ្យមានការសម្តែង។
        ///
        /// ដូច្នេះនេះមិនមែនជាចេតនា `Copy` ទេ។
        ///
        /// ប្រតិបត្ដិការទាំងអស់ដែលអាចប្រើបានដើម្បី bignums panic នៅក្នុងករណីនៃការហូរហៀរ។
        /// អ្នកទូរស័ព្ទចូលទទួលខុសត្រូវក្នុងការប្រើប្រភេទប៊ីចេងធំល្មម។
        pub struct $name {
            /// មួយបូកនឹងអុហ្វសិតដល់អតិបរមា "digit" ក្នុងការប្រើប្រាស់។
            /// នេះមិនថយចុះទេដូច្នេះត្រូវដឹងពីលំដាប់នៃការគណនា។
            /// `base[size..]` គួរតែជាសូន្យ។
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` តំណាងឱ្យ `a + b *2^W + c* 2^(2W) + ...` ដែល `W` គឺជាចំនួនប៊ីតនៅក្នុងប្រភេទខ្ទង់។
            base: [$ty; $n],
        }

        impl $name {
            /// ធ្វើឱ្យ bignum ពីខ្ទង់មួយ។
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// ធ្វើឱ្យ bignum ពីតម្លៃ `u64` ។
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// ត្រឡប់ខ្ទង់ខាងក្នុងជាចំណិត `[a, b, c, ...]` ដូចជាតម្លៃលេខគឺ `a + b *2^W + c* 2^(2W) + ...` ដែល `W` ជាចំនួនប៊ីតក្នុងប្រភេទខ្ទង់។
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// ត្រឡប់ប៊ីត `i` ដែលលេខប៊ីតគឺតូចជាងគេ។
            /// និយាយម្យ៉ាងទៀតប៊ីតជាមួយនឹងទំងន់ `2^i` ។
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// ត្រឡប់ `true` ប្រសិនបើ bignum គឺសូន្យ។
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// ត្រឡប់ចំនួនប៊ីតចាំបាច់ដើម្បីតំណាងឱ្យតម្លៃនេះ។
            /// ចំណាំថាសូន្យត្រូវបានគេគិតថាត្រូវការ 0 ប៊ីត។
            pub fn bit_length(&self) -> usize {
                // រំលងតួរលេខសំខាន់បំផុតដែលជាសូន្យ។
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // មិនមានតួលេខមិនមែនសូន្យទេពោលគឺលេខគឺសូន្យ។
                    return 0;
                }
                // នេះអាចត្រូវបានធ្វើឱ្យប្រសើរជាមួយនឹង leading_zeros() និងការផ្លាស់ប្តូរបន្តិចបន្តួចប៉ុន្តែនោះប្រហែលជាមិនសមនឹងការរំខានទេ។
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// បន្ថែម `other` ទៅខ្លួនវាហើយត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// ដក `other` ពីខ្លួនវាហើយត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// គុណដោយខ្លួនវាផ្ទាល់ដោយ `other` មានខ្ទង់ខ្ទង់ហើយត្រឡប់មកវិញនូវឯកសារយោងដែលអាចផ្លាស់ប្តូរបាន។
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// គុណដោយខ្លួនវាផ្ទាល់ដោយ `2^bits` និងត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // ផ្លាស់ប្តូរដោយប៊ីត `digits * digitbits`
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // ផ្លាស់ប្តូរដោយប៊ីត `bits`
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. តួលេខ] គឺសូន្យមិនចាំបាច់ប្តូរទេ
                }

                self.size = sz;
                self
            }

            /// គុណដោយខ្លួនវាផ្ទាល់ដោយ `5^e` និងត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // មានលេខសូន្យនៅលើ 2 ^ n ហើយទំហំខ្ទង់ដែលទាក់ទងតែមួយគត់គឺមានថាមពលជាប់គ្នាពីរដូច្នេះនេះគឺជាលិបិក្រមសមល្អសម្រាប់តារាង។
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // គុណនឹងថាមពលតែមួយខ្ទង់ធំបំផុតតាមដែលអាចធ្វើទៅបាន ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... បន្ទាប់មកបញ្ចប់នៅសល់។
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// គុណខ្លួនវាដោយលេខដែលបានពិពណ៌នាដោយ `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` (ដែល `W` គឺជាចំនួនប៊ីតក្នុងប្រភេទខ្ទង់) ហើយត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // ទម្លាប់ផ្ទៃក្នុង។ដំណើរការល្អបំផុតនៅពេល aa.len() <= bb.len() ។
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// បែងចែកខ្លួនវាដោយ `other` ដែលមានទំហំខ្ទង់ហើយត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានរបស់ខ្លួន *និង* នៅសល់។
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// បែងចែកខ្លួនអ្នកដោយអ័រហ្គោមមួយផ្សេងទៀតសរសេរជាន់លើ `q` ជាមួយចំនួនចែកនិង `r` ជាមួយចំនួននៅសល់។
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // ការបែងចែកវែងវែងឆោតល្ងង់យឺត base-2 បានយកចេញពី
                // https://en.wikipedia.org/wiki/Division_algorithm
                // FIXME ប្រើមូលដ្ឋាន ($ty) ធំជាងមុនសម្រាប់ការបែងចែកវែង។
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // កំណត់ប៊ីត `i` នៃ q ទៅ ១ ។
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// ប្រភេទខ្ទង់សម្រាប់ `Big32x40` ។
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// មួយនេះត្រូវបានប្រើសម្រាប់តេស្តតែប៉ុណ្ណោះ។
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}