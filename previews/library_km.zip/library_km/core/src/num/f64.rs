//! ថេរជាក់លាក់ចំពោះប្រភេទចំណុចអណ្តែតទ្វេដែលមានភាពជាក់លាក់ `f64` ។
//!
//! *[See also the `f64` primitive type][f64].*
//!
//! លេខសំខាន់ៗតាមគណិតវិទ្យាត្រូវបានផ្តល់នៅក្នុងម៉ូឌុលរង `consts` ។
//!
//! ចំពោះថេរដែលបានកំណត់ដោយផ្ទាល់នៅក្នុងម៉ូឌុលនេះ (ខុសពីអ្វីដែលបានកំណត់នៅក្នុងម៉ូឌុលរង `consts`) លេខកូដថ្មីគួរតែប្រើជំនួសដែលបានកំណត់ដោយផ្ទាល់លើប្រភេទ `f64` ។
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// កាំឬមូលដ្ឋាននៃតំណាងផ្ទៃក្នុងនៃ `f64` ។
/// ប្រើ [`f64::RADIX`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f64::RADIX;
///
/// // វិធីដែលមានគោលបំណង
/// let r = f64::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f64`")]
pub const RADIX: u32 = f64::RADIX;

/// ចំនួនតួលេខសំខាន់នៅក្នុងមូលដ្ឋានទី ២ ។
/// ប្រើ [`f64::MANTISSA_DIGITS`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::MANTISSA_DIGITS;
///
/// // វិធីដែលមានគោលបំណង
/// let d = f64::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f64`"
)]
pub const MANTISSA_DIGITS: u32 = f64::MANTISSA_DIGITS;

/// ចំនួនប្រហាក់ប្រហែលនៃតួលេខសំខាន់នៅក្នុងមូលដ្ឋានទី ១០ ។
/// ប្រើ [`f64::DIGITS`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f64::DIGITS;
///
/// // វិធីដែលមានគោលបំណង
/// let d = f64::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f64`")]
pub const DIGITS: u32 = f64::DIGITS;

/// [Machine epsilon] តម្លៃសម្រាប់ `f64` ។
/// ប្រើ [`f64::EPSILON`] ជំនួសវិញ។
///
/// នេះគឺជាភាពខុសគ្នារវាង `1.0` និងលេខដែលអាចតំណាងធំជាងមុន។
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f64::EPSILON;
///
/// // វិធីដែលមានគោលបំណង
/// let e = f64::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f64`"
)]
pub const EPSILON: f64 = f64::EPSILON;

/// តម្លៃ `f64` X តូចបំផុត។
/// ប្រើ [`f64::MIN`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN;
///
/// // វិធីដែលមានគោលបំណង
/// let min = f64::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f64`")]
pub const MIN: f64 = f64::MIN;

/// តម្លៃ `f64` ធម្មតាវិជ្ជមានតូចបំផុត។
/// ប្រើ [`f64::MIN_POSITIVE`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_POSITIVE;
///
/// // វិធីដែលមានគោលបំណង
/// let min = f64::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f64`"
)]
pub const MIN_POSITIVE: f64 = f64::MIN_POSITIVE;

/// តម្លៃ `f64` ខ្នាតធំបំផុត។
/// ប្រើ [`f64::MAX`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX;
///
/// // វិធីដែលមានគោលបំណង
/// let max = f64::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f64`")]
pub const MAX: f64 = f64::MAX;

/// មួយធំជាងស្វ័យគុណអប្បបរមាដែលអាចមាននៃនិទស្សន្ត ២ ។
/// ប្រើ [`f64::MIN_EXP`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_EXP;
///
/// // វិធីដែលមានគោលបំណង
/// let min = f64::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f64`"
)]
pub const MIN_EXP: i32 = f64::MIN_EXP;

/// ថាមពលដែលអាចធ្វើបានអតិបរមា ២ និទស្សន្ត។
/// ប្រើ [`f64::MAX_EXP`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_EXP;
///
/// // វិធីដែលមានគោលបំណង
/// let max = f64::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f64`"
)]
pub const MAX_EXP: i32 = f64::MAX_EXP;

/// ថាមពលធម្មតាអប្បបរមាដែលអាចមាននៃនិទស្សន្ត ១០ ។
/// ប្រើ [`f64::MIN_10_EXP`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f64::MIN_10_EXP;
///
/// // វិធីដែលមានគោលបំណង
/// let min = f64::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f64`"
)]
pub const MIN_10_EXP: i32 = f64::MIN_10_EXP;

/// ថាមពលអតិបរមាដែលអាចធ្វើបាននៃនិទស្សន្ត ១០ ។
/// ប្រើ [`f64::MAX_10_EXP`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f64::MAX_10_EXP;
///
/// // វិធីដែលមានគោលបំណង
/// let max = f64::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f64`"
)]
pub const MAX_10_EXP: i32 = f64::MAX_10_EXP;

/// មិនមែនជាលេខ (NaN) ទេ។
/// ប្រើ [`f64::NAN`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f64::NAN;
///
/// // វិធីដែលមានគោលបំណង
/// let nan = f64::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f64`")]
pub const NAN: f64 = f64::NAN;

/// ក្រុមហ៊ុន Infinity (∞) ។
/// ប្រើ [`f64::INFINITY`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f64::INFINITY;
///
/// // វិធីដែលមានគោលបំណង
/// let inf = f64::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f64`"
)]
pub const INFINITY: f64 = f64::INFINITY;

/// អាត្ម័នអវិជ្ជមាន (−∞) ។
/// ប្រើ [`f64::NEG_INFINITY`] ជំនួសវិញ។
///
/// # Examples
///
/// ```rust
/// // វិធីដែលមិនសមរម្យ
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f64::NEG_INFINITY;
///
/// // វិធីដែលមានគោលបំណង
/// let ninf = f64::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f64`"
)]
pub const NEG_INFINITY: f64 = f64::NEG_INFINITY;

/// ថេរគណិតវិទ្យាមូលដ្ឋាន។
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ជំនួសដោយថេរគណិតវិទ្យាពី cmath ។

    /// (π) ថេររបស់ Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f64 = 3.14159265358979323846264338327950288_f64;

    /// រង្វង់ពេញថេរ (τ)
    ///
    /// ស្មើនឹង ២π ។
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f64 = 6.28318530717958647692528676655900577_f64;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f64 = 1.57079632679489661923132169163975144_f64;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f64 = 1.04719755119659774615421446109316763_f64;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f64 = 0.785398163397448309615660845819875721_f64;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f64 = 0.52359877559829887307710723054658381_f64;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f64 = 0.39269908169872415480783042290993786_f64;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f64 = 0.318309886183790671537767526745028724_f64;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f64 = 0.636619772367581343075535053490057448_f64;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f64 = 1.12837916709551257389615890312154517_f64;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f64 = 1.41421356237309504880168872420969808_f64;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f64 = 0.707106781186547524400844362104849039_f64;

    /// លេខអយល័រ (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f64 = 2.71828182845904523536028747135266250_f64;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f64 = 3.32192809488736234787031942948939018_f64;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f64 = 1.44269504088896340735992468100189214_f64;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f64 = 0.301029995663981195213738894724493027_f64;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f64 = 0.434294481903251827651128918916605082_f64;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f64 = 0.693147180559945309417232121458176568_f64;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f64 = 2.30258509299404568401799145468436421_f64;
}

#[lang = "f64"]
#[cfg(not(test))]
impl f64 {
    /// កាំឬមូលដ្ឋាននៃតំណាងផ្ទៃក្នុងនៃ `f64` ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// ចំនួនតួលេខសំខាន់នៅក្នុងមូលដ្ឋានទី ២ ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 53;
    /// ចំនួនប្រហាក់ប្រហែលនៃតួលេខសំខាន់នៅក្នុងមូលដ្ឋានទី ១០ ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 15;

    /// [Machine epsilon] តម្លៃសម្រាប់ `f64` ។
    ///
    /// នេះគឺជាភាពខុសគ្នារវាង `1.0` និងលេខដែលអាចតំណាងធំជាងមុន។
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f64 = 2.2204460492503131e-16_f64;

    /// តម្លៃ `f64` X តូចបំផុត។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f64 = -1.7976931348623157e+308_f64;
    /// តម្លៃ `f64` ធម្មតាវិជ្ជមានតូចបំផុត។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f64 = 2.2250738585072014e-308_f64;
    /// តម្លៃ `f64` ខ្នាតធំបំផុត។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f64 = 1.7976931348623157e+308_f64;

    /// មួយធំជាងស្វ័យគុណអប្បបរមាដែលអាចមាននៃនិទស្សន្ត ២ ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -1021;
    /// ថាមពលដែលអាចធ្វើបានអតិបរមា ២ និទស្សន្ត។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 1024;

    /// ថាមពលធម្មតាអប្បបរមាដែលអាចមាននៃនិទស្សន្ត ១០ ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -307;
    /// ថាមពលអតិបរមាដែលអាចធ្វើបាននៃនិទស្សន្ត ១០ ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 308;

    /// មិនមែនជាលេខ (NaN) ទេ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f64 = 0.0_f64 / 0.0_f64;
    /// ក្រុមហ៊ុន Infinity (∞) ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f64 = 1.0_f64 / 0.0_f64;
    /// អាត្ម័នអវិជ្ជមាន (−∞) ។
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f64 = -1.0_f64 / 0.0_f64;

    /// ត្រឡប់ `true` ប្រសិនបើតម្លៃនេះគឺ `NaN` ។
    ///
    /// ```
    /// let nan = f64::NAN;
    /// let f = 7.0_f64;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` គឺមិនអាចប្រើបានជាសាធារណៈនៅក្នុង libcore ដោយសារតែការព្រួយបារម្ភអំពីភាពចល័តដូច្នេះការអនុវត្តនេះគឺសម្រាប់ការប្រើប្រាស់ឯកជននៅខាងក្នុង។
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f64 {
        f64::from_bits(self.to_bits() & 0x7fff_ffff_ffff_ffff)
    }

    /// ត្រឡប់ `true` ប្រសិនបើតម្លៃនេះគឺជាភាពមិនពិតវិជ្ជមានឬផលប៉ះពាល់អវិជ្ជមាននិង `false` បើមិនដូច្នេះទេ។
    ///
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf = f64::INFINITY;
    /// let neg_inf = f64::NEG_INFINITY;
    /// let nan = f64::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// ត្រឡប់ `true` ប្រសិនបើលេខនេះគឺមិនកំណត់និង `NaN` ។
    ///
    /// ```
    /// let f = 7.0f64;
    /// let inf: f64 = f64::INFINITY;
    /// let neg_inf: f64 = f64::NEG_INFINITY;
    /// let nan: f64 = f64::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // មិនចាំបាច់ដោះស្រាយ NaN ដាច់ដោយឡែកទេ: ប្រសិនបើខ្លួនឯងជា NaN ការប្រៀបធៀបមិនពិតទេដូចអ្វីដែលចង់បាន។
        //
        self.abs_private() < Self::INFINITY
    }

    /// ត្រឡប់ `true` ប្រសិនបើលេខគឺ [subnormal] ។
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308_f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0_f64;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f64::NAN.is_subnormal());
    /// assert!(!f64::INFINITY.is_subnormal());
    /// // តម្លៃរវាង `0` និង `min` គឺមិនធម្មតា។
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// ត្រឡប់ `true` ប្រសិនបើលេខគឺមិនមែនសូន្យគ្មានកំណត់ [subnormal] ឬ `NaN` ។
    ///
    ///
    /// ```
    /// let min = f64::MIN_POSITIVE; // 2.2250738585072014e-308f64
    /// let max = f64::MAX;
    /// let lower_than_min = 1.0e-308_f64;
    /// let zero = 0.0f64;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f64::NAN.is_normal());
    /// assert!(!f64::INFINITY.is_normal());
    /// // តម្លៃរវាង `0` និង `min` គឺមិនធម្មតា។
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// ត្រឡប់ប្រភេទចំណុចអណ្តែតទឹកនៃលេខ។
    /// ប្រសិនបើទ្រព្យសម្បត្តិតែមួយនឹងត្រូវបានសាកល្បងជាទូទៅវាលឿនជាងក្នុងការប្រើព្យាករណ៍ជាក់លាក់ជំនួស។
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f64;
    /// let inf = f64::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u64 = 0x7ff0000000000000;
        const MAN_MASK: u64 = 0x000fffffffffffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `self` មានសញ្ញាវិជ្ជមានរួមទាំង `+0.0`, `NaN ដែលមានសញ្ញាវិជ្ជមាននិងវិជ្ជមាន។
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_positive")]
    #[inline]
    #[doc(hidden)]
    pub fn is_positive(self) -> bool {
        self.is_sign_positive()
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `self` មានសញ្ញាអវិជ្ជមានរួមទាំង `-0.0`, `NaN ជាមួយសញ្ញាប៊ីតអវិជ្ជមាននិងភាពមិនពិតអវិជ្ជមាន។
    ///
    ///
    /// ```
    /// let f = 7.0_f64;
    /// let g = -7.0_f64;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        self.to_bits() & 0x8000_0000_0000_0000 != 0
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.0.0", reason = "renamed to is_sign_negative")]
    #[inline]
    #[doc(hidden)]
    pub fn is_negative(self) -> bool {
        self.is_sign_negative()
    }

    /// យក X-X ពណ៌ចំរាស់នៃលេខ, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f64;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f64 {
        1.0 / self
    }

    /// បម្លែងរ៉ាដ្យង់ទៅដឺក្រេ។
    ///
    /// ```
    /// let angle = std::f64::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_degrees(self) -> f64 {
        // ការបែងចែកនៅទីនេះត្រូវបានបង្គត់យ៉ាងត្រឹមត្រូវដោយគោរពតាមតម្លៃពិតនៃ 180/π។
        // (វាខុសគ្នាពី f32 ដែលថេរត្រូវតែប្រើដើម្បីធានាលទ្ធផលមូលត្រឹមត្រូវ។)
        //
        self * (180.0f64 / consts::PI)
    }

    /// បម្លែងដឺក្រេទៅរ៉ាដ្យង់។
    ///
    /// ```
    /// let angle = 180.0_f64;
    ///
    /// let abs_difference = (angle.to_radians() - std::f64::consts::PI).abs();
    ///
    /// assert!(abs_difference < 1e-10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_radians(self) -> f64 {
        let value: f64 = consts::PI;
        self * (value / 180.0)
    }

    /// ត្រឡប់ចំនួនអតិបរមានៃចំនួនពីរ។
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// ប្រសិនបើអាគុយម៉ង់មួយក្នុងចំណោមអាគុយម៉ង់គឺ NaN បន្ទាប់មកអាគុយម៉ង់ផ្សេងទៀតត្រូវបានត្រឡប់មកវិញ។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f64) -> f64 {
        intrinsics::maxnumf64(self, other)
    }

    /// ត្រឡប់អប្បបរមានៃចំនួនពីរ។
    ///
    /// ```
    /// let x = 1.0_f64;
    /// let y = 2.0_f64;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// ប្រសិនបើអាគុយម៉ង់មួយក្នុងចំណោមអាគុយម៉ង់គឺ NaN បន្ទាប់មកអាគុយម៉ង់ផ្សេងទៀតត្រូវបានត្រឡប់មកវិញ។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f64) -> f64 {
        intrinsics::minnumf64(self, other)
    }

    /// បង្គត់ឆ្ពោះទៅរកសូន្យហើយបំលែងទៅជាប្រភេទចំនួនគត់បឋមណាមួយដែលសន្មតថាតម្លៃគឺសមនិងសមនឹងប្រភេទនោះ។
    ///
    ///
    /// ```
    /// let value = 4.6_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f64;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// តម្លៃត្រូវ៖
    ///
    /// * មិនមែន `NaN` ទេ
    /// * មិនមានកំណត់
    /// * ក្លាយជាអ្នកតំណាងនៅក្នុងប្រភេទត្រឡប់មកវិញ `Int` បន្ទាប់ពីកាត់ចេញផ្នែកប្រភាគរបស់វា
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `FloatToInt::to_int_unchecked` ។
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// ការបញ្ជូនឆៅទៅ `u64` ។
    ///
    /// បច្ចុប្បន្ននេះគឺដូចគ្នានឹង `transmute::<f64, u64>(self)` នៅលើវេទិកាទាំងអស់។
    ///
    /// សូមមើល `from_bits` សម្រាប់ការពិភាក្សាមួយចំនួនអំពីភាពចល័តនៃប្រតិបត្តិការនេះ (ស្ទើរតែគ្មានបញ្ហា) ។
    ///
    /// ចំណាំថាមុខងារនេះខុសពីការដេញ `as` ដែលព្យាយាមការពារតម្លៃ *លេខ* ហើយមិនមែនជាតម្លៃបន្តិចទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((1f64).to_bits() != 1f64 as u64); // to_bits() មិនកំពុងខាស!
    /// assert_eq!((12.5f64).to_bits(), 0x4029000000000000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u64 {
        // សុវត្ថិភាព: `u64` គឺជាប្រភេទទិន្នន័យចាស់ធម្មតាដូច្នេះយើងអាចបញ្ជូនវាទៅវាបាន
        unsafe { mem::transmute(self) }
    }

    /// ការបញ្ជូនឆៅពី `u64` ។
    ///
    /// បច្ចុប្បន្ននេះគឺដូចគ្នានឹង `transmute::<u64, f64>(v)` នៅលើវេទិកាទាំងអស់។
    /// វាប្រែថានេះគឺអាចចល័តបានមិនគួរឱ្យជឿសម្រាប់ហេតុផលពីរយ៉ាង:
    ///
    /// * អណ្តែតនិងអាយដិនមានភាពដូចគ្នាដូចគ្នានៅលើវេទិកាដែលគាំទ្រទាំងអស់។
    /// * IEEE-754 បញ្ជាក់យ៉ាងច្បាស់ពីប្លង់អណ្តែត។
    ///
    /// ទោះយ៉ាងណាមានចំនុចខ្វះចន្លោះមួយ: មុនពេលកំណែអាយអេសអាយ ៧៥៤ ឆ្នាំ ២០០៨ របៀបបកស្រាយប៊ែនសញ្ញាណាណូមិនបានបញ្ជាក់ច្បាស់ទេ។
    /// វេទិកាភាគច្រើន (គួរឱ្យកត់សម្គាល់ x86 និង ARM) បានជ្រើសរើសការបកស្រាយដែលត្រូវបានធ្វើឱ្យមានលក្ខណៈស្តង់ដារនៅឆ្នាំ 2008 ប៉ុន្តែមួយចំនួនមិនបាន (គួរកត់សំគាល់ MIPS) ។
    /// ជាលទ្ធផលរាល់សញ្ញាណាណូនៅលើ MIPS គឺ NaNs ស្ងាត់នៅលើ x86 និងច្រាសមកវិញ។
    ///
    /// ជាជាងការព្យាយាមដើម្បីការពារការឆ្លងវេទិកាដែលផ្តល់សញ្ញាការអនុវត្តិន៍នេះអនុញ្ញាតិឱ្យមានការអភិរក្សប៊ីត។
    /// នេះមានន័យថារាល់បន្ទុកដែលបានអ៊ិនគ្រីបនៅក្នុង NaNs នឹងត្រូវបានរក្សាទុកទោះបីជាលទ្ធផលនៃវិធីសាស្ត្រនេះត្រូវបានបញ្ជូនតាមបណ្តាញពីម៉ាស៊ីន x86 ទៅម៉ាស៊ីន MIPS ក៏ដោយ។
    ///
    ///
    /// ប្រសិនបើលទ្ធផលនៃវិធីសាស្រ្តនេះត្រូវបានរៀបចំឡើងដោយស្ថាបត្យកម្មតែមួយដែលផលិតវានោះមិនមានការព្រួយបារម្ភអំពីភាពអាចចល័តបានទេ។
    ///
    /// ប្រសិនបើការបញ្ចូលនេះមិនមែនជាអិនអិនទេនោះគ្មានការព្រួយបារម្ភអំពីភាពអាចចល័តបានឡើយ។
    ///
    /// ប្រសិនបើអ្នកមិនខ្វល់អំពីការផ្តល់សញ្ញា (ទំនងជា) នោះគ្មានការព្រួយបារម្ភអំពីភាពអាចចល័តបានឡើយ។
    ///
    /// ចំណាំថាមុខងារនេះខុសពីការដេញ `as` ដែលព្យាយាមការពារតម្លៃ *លេខ* ហើយមិនមែនជាតម្លៃបន្តិចទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f64::from_bits(0x4029000000000000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u64) -> Self {
        // សុវត្ថិភាព: `u64` គឺជាប្រភេទទិន្នន័យចាស់ធម្មតាដូច្នេះយើងអាចចម្លងពីវាបាន
        // វាបង្ហាញពីបញ្ហាសុវត្ថិភាពជាមួយទូរទស្សន៍អិន។ អិន។ អិន។ហូ!
        unsafe { mem::transmute(v) }
    }

    /// ត្រឡប់តំណាងការចងចាំនៃលេខអណ្តែតទឹកនេះជាអារេបៃនៅក្នុងលំដាប់ (network) បៃ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_be_bytes();
    /// assert_eq!(bytes, [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 8] {
        self.to_bits().to_be_bytes()
    }

    /// ត្រឡប់តំណាងការចងចាំនៃលេខអណ្តែតទឹកនេះជាអារេបៃនៅក្នុងលំដាប់បៃដែលតូច។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 8] {
        self.to_bits().to_le_bytes()
    }

    /// ត្រឡប់ការចងចាំតំណាងនៃលេខអណ្តែតនេះជាអារេបៃនៅក្នុងលំដាប់បៃ។
    ///
    /// នៅពេលឧបករណ៍ប្រើប្រាស់ដើមរបស់វេទិកាគោលដៅត្រូវបានប្រើលេខកូដចល័តគួរតែប្រើ [`to_be_bytes`] ឬ [`to_le_bytes`] តាមដែលសមរម្យជំនួសវិញ។
    ///
    ///
    /// [`to_be_bytes`]: f64::to_be_bytes
    /// [`to_le_bytes`]: f64::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f64.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 8] {
        self.to_bits().to_ne_bytes()
    }

    /// ត្រឡប់ការចងចាំតំណាងនៃលេខអណ្តែតនេះជាអារេបៃនៅក្នុងលំដាប់បៃ។
    ///
    ///
    /// [`to_ne_bytes`] គួរតែត្រូវបានពេញចិត្តជាងនេះនៅពេលណាដែលអាចធ្វើទៅបាន។
    ///
    /// [`to_ne_bytes`]: f64::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f64;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 8] {
        // សុវត្ថិភាព: `f64` គឺជាប្រភេទទិន្នន័យចាស់ធម្មតាដូច្នេះយើងអាចបញ្ជូនវាទៅវាបាន
        unsafe { &*(self as *const Self as *const _) }
    }

    /// បង្កើតតម្លៃចំណុចអណ្តែតពីការតំណាងរបស់វាជាអារេបៃនៅក្នុង endian ធំ។
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_be_bytes([0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_be_bytes(bytes))
    }

    /// បង្កើតតម្លៃចំណុចអណ្តែតពីការតំណាងរបស់វាជាអារេបៃនៅក្នុងពិភពននល។
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_le_bytes([0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_le_bytes(bytes))
    }

    /// បង្កើតតម្លៃអណ្តែតពីការតំណាងរបស់វាជាអារេបៃនៅក្នុងភាសាដើម។
    ///
    /// នៅពេលឧបករណ៍ប្រើប្រាស់ដើមរបស់វេទិកាគោលដៅត្រូវបានប្រើលេខកូដចល័តទំនងជាចង់ប្រើ [`from_be_bytes`] ឬ [`from_le_bytes`] ដែលសមរម្យជំនួសវិញ។
    ///
    ///
    /// [`from_be_bytes`]: f64::from_be_bytes
    /// [`from_le_bytes`]: f64::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f64::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x40, 0x29, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x29, 0x40]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 8]) -> Self {
        Self::from_bits(u64::from_ne_bytes(bytes))
    }

    /// ត្រឡប់ការបញ្ជាទិញរវាងខ្លួនឯងនិងតម្លៃផ្សេងទៀត។
    /// មិនដូចការប្រៀបធៀបផ្នែកស្តង់ដាររវាងលេខចំណុចអណ្តែតទេការប្រៀបធៀបនេះតែងតែបង្កើតលំដាប់ដោយអនុលោមតាមចំនួនសរុបដែលទាយទុកជាមុនដូចដែលបានកំណត់នៅក្នុងស្តង់ដារអណ្តែតទឹក IEEE 754 (កែប្រែឆ្នាំ ២០០៨) ។
    /// តម្លៃត្រូវបានតំរៀបតាមលំដាប់លំដោយ៖
    /// - NaN ស្ងាត់អវិជ្ជមាន
    /// - សញ្ញាអវិជ្ជមាន NaN
    /// - ភាពមិនចេះរីងស្ងួតអវិជ្ជមាន
    /// - លេខអវិជ្ជមាន
    /// - លេខមិនធម្មតាអវិជ្ជមាន
    /// - អវិជ្ជមានសូន្យ
    /// - សូន្យវិជ្ជមាន
    /// - លេខមិនធម្មតាវិជ្ជមាន
    /// - លេខវិជ្ជមាន
    /// - ភាពមិនចេះរីងស្ងួតវិជ្ជមាន
    /// - សញ្ញាវិជ្ជមាន NaN
    /// - NaN ស្ងប់ស្ងាត់វិជ្ជមាន
    ///
    /// ចំណាំថាមុខងារនេះមិនតែងតែឯកភាពជាមួយនឹងការអនុវត្ត [`PartialOrd`] និង [`PartialEq`] នៃ `f64` ទេ។ជាពិសេសពួកគេចាត់ទុកអវិជ្ជមាននិងវិជ្ជមានសូន្យស្មើខណៈពេលដែល `total_cmp` មិន។
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f64,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f64::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f64::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f64::INFINITY, f64::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i64;
        let mut right = other.to_bits() as i64;

        // ក្នុងករណីមានអវិជ្ជមានសូមបង្វែរប៊ីតទាំងអស់លើកលែងតែសញ្ញាដើម្បីសម្រេចប្លង់ស្រដៀងគ្នាជាចំនួនគត់បំពេញបន្ថែមពីរ
        //
        // ហេតុអ្វីបានជាការងារនេះ?IEEE ៧៥៤ អណ្តែតមានវាលបី៖
        // ចុះហត្ថលេខាប៊ីតអិចស្ប៉ូណង់ស្យែលនិងម៉ាស្ទ្រីស។សំណុំនៃអនុគមន៍អិចស្ប៉ូណង់ស្យែលនិង mantissa ទាំងមូលមានលក្ខណៈសម្បត្តិដែលតាមលំដាប់លំដោយបន្តិចរបស់ពួកគេគឺស្មើនឹងទំហំលេខដែលទំហំត្រូវបានកំណត់។
        // រ៉ិចទ័រមិនត្រូវបានកំណត់ជាធម្មតាលើគុណតំលៃណាអិនទេប៉ុន្តែអាយអឹមអាយ ៧៥៤ TotalOrder កំណត់តម្លៃ NaN ក៏ត្រូវធ្វើតាមលំដាប់បន្តិចដែរ។នេះនាំឱ្យមានការបញ្ជាទិញដែលបានពន្យល់នៅក្នុងសេចក្តីអត្ថាធិប្បាយ។
        // ទោះជាយ៉ាងណាក៏ដោយការតំណាងនៃរ៉ិចទ័រគឺដូចគ្នាសម្រាប់លេខអវិជ្ជមាននិងវិជ្ជមាន-មានតែប៊ីតនៃសញ្ញាប៉ុណ្ណោះដែលខុសគ្នា។
        // ដើម្បីប្រៀបធៀបអណ្តែតយ៉ាងងាយស្រួលជាលេខគត់ដែលបានចុះហត្ថលេខាយើងចាំបាច់ត្រូវបញ្ចោញប៊ីតអិចស្ប៉ូណង់ស្យែរក្នុងករណីលេខអវិជ្ជមាន។
        // យើងប្តូរលេខយ៉ាងមានប្រសិទ្ធភាពទៅជាទម្រង់ "two's complement" ។
        //
        // ដើម្បីធ្វើត្រាប់តាមយើងបង្កើតរបាំងនិង XOR ប្រឆាំងនឹងវា។
        // យើងគណនារបាំង "all-ones except for the sign bit" យ៉ាងងាយស្រួលពីតម្លៃដែលបានចុះហត្ថលេខាអវិជ្ជមាន៖ សញ្ញាផ្លាស់ប្តូរខាងស្តាំ-ពង្រីកចំនួនគត់ដូច្នេះយើង "fill" របាំងជាមួយប៊ីតសញ្ញាហើយបន្ទាប់មកប្តូរទៅជាហត្ថលេខាដើម្បីជំរុញមួយសូន្យបន្ថែមទៀត។
        //
        // នៅលើតម្លៃវិជ្ជមានរបាំងគឺជាសូន្យទាំងអស់ដូច្នេះវាមិនមែនជាអេច។
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 63) as u64) >> 1) as i64;
        right ^= (((right >> 63) as u64) >> 1) as i64;

        left.cmp(&right)
    }

    /// ដាក់កម្រិតតម្លៃទៅចន្លោះពេលជាក់លាក់មួយលើកលែងតែវាជា NaN ។
    ///
    /// ត្រឡប់ `max` ប្រសិនបើ `self` ធំជាង `max` ហើយ `min` ប្រសិនបើ `self` តិចជាង `min` ។
    /// បើមិនដូច្នោះទេវាត្រឡប់មកវិញ `self` ។
    ///
    /// ចំណាំថាមុខងារនេះត្រឡប់ NaN ប្រសិនបើតម្លៃដំបូងគឺ NaN ផងដែរ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `min > max`, `min` គឺជា NaN, ឬ `max` គឺ NaN ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f64).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f64).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f64).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f64::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f64, max: f64) -> f64 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}