//! និយមន័យនៃចំនួនគត់ដែលត្រូវបានគេដឹងថាមិនស្មើនឹងសូន្យ។

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// ចំនួនគត់ដែលត្រូវបានគេដឹងថាមិនស្មើនឹងសូន្យ។
            ///
            /// នេះអនុញ្ញាតឱ្យមានប្រសិទ្ធិភាពប្លង់សតិមួយចំនួន។
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// ប្រើ std::mem::size_of;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// បង្កើតមិនមែនសូន្យដោយមិនពិនិត្យមើលតម្លៃ។
                ///
                /// # Safety
                ///
                /// តម្លៃមិនត្រូវសូន្យទេ។
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // សុវត្ថិភាព: នេះត្រូវបានធានាថាមានសុវត្ថិភាពដោយអ្នកទូរស័ព្ទចូល។
                    unsafe { Self(n) }
                }

                /// បង្កើតសូន្យប្រសិនបើតម្លៃដែលបានផ្តល់មិនមែនសូន្យ។
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // សុវត្ថិភាព: យើងទើបតែពិនិត្យមើលថាមិនមាន `0` ទេ
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// ត្រឡប់តម្លៃជាប្រភេទបុព្វកាល។
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // សុវត្ថិភាព: ចាប់តាំងពី `self` និង `rhs` ទាំងពីរគឺ nonzero, the
                    // លទ្ធផលនៃការបន្តិច-ឬនឹងត្រូវបាន nonzero ។
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // សុវត្ថិភាព: ចាប់តាំងពី `self` គឺជា nonzero លទ្ធផលនៃឯកសារ
                    // bitwise-ឬនឹងត្រូវបាន nonzero ដោយមិនគិតពីតម្លៃនៃ `rhs` ។
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // សុវត្ថិភាព: ចាប់តាំងពី `rhs` គឺជា nonzero លទ្ធផលនៃឯកសារ
                    // bitwise-ឬនឹងត្រូវបាន nonzero ដោយមិនគិតពីតម្លៃនៃ `self` ។
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// ត្រឡប់ចំនួនសូន្យនាំមុខក្នុងការតំណាងគោលពីរនៃ `self` ។
                ///
                /// នៅលើស្ថាបត្យកម្មជាច្រើនមុខងារនេះអាចដំណើរការបានល្អជាង `leading_zeros()` លើប្រភេទចំនួនគត់មូលដ្ឋានព្រោះថាការដោះស្រាយពិសេសនៃលេខសូន្យអាចត្រូវបានជៀសវាង។
                ///
                /// # Examples
                ///
                /// ការប្រើប្រាស់មូលដ្ឋាន៖
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // សុវត្ថិភាព: ចាប់តាំងពី `self` មិនអាចសូន្យវាមានសុវត្ថិភាពក្នុងការហៅ ctlz_nonzero
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// ត្រឡប់ចំនួនសូន្យនៅពីក្រោយក្នុងការតំណាងគោលពីរនៃ `self` ។
                ///
                /// នៅលើស្ថាបត្យកម្មជាច្រើនមុខងារនេះអាចដំណើរការបានល្អជាង `trailing_zeros()` លើប្រភេទចំនួនគត់មូលដ្ឋានព្រោះថាការដោះស្រាយពិសេសនៃលេខសូន្យអាចត្រូវបានជៀសវាង។
                ///
                ///
                /// # Examples
                ///
                /// ការប្រើប្រាស់មូលដ្ឋាន៖
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // សុវត្ថិភាព: ចាប់តាំងពី `self` មិនអាចសូន្យវាមានសុវត្ថិភាពក្នុងការហៅ cttz_nonzero
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// ប្រតិបត្ដិការនេះឈានដល់ចំនុចសូន្យកាត់ផ្នែកណាមួយនៃលទ្ធផលពិតប្រាកដហើយមិនអាច panic ។
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // សុវត្ថិភាព: div ដោយសូន្យត្រូវបានធីកពីព្រោះ `other` គឺជា nonzero,
                    // ហើយ MIN/-1 ត្រូវបានពិនិត្យព្រោះ `self` គឺជា int ដែលមិនបានចុះហត្ថលេខា។
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// ប្រតិបត្តិការនេះពេញចិត្ត `n % d == n - (n / d) * d` ហើយមិនអាច panic ។
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // សុវត្ថិភាព: ដកដោយសូន្យគឺត្រូវបានពិនិត្យព្រោះ `other` គឺជាអ៊ីនធឺណេស,
                    // ហើយ MIN/-1 ត្រូវបានពិនិត្យព្រោះ `self` គឺជា int ដែលមិនបានចុះហត្ថលេខា។
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// ត្រឡប់ `true` ប្រសិនបើនិងមានតែប្រសិនបើ `self == (1 << k)` សម្រាប់ `k` ខ្លះ។
                ///
                /// នៅលើស្ថាបត្យកម្មជាច្រើនមុខងារនេះអាចដំណើរការបានល្អជាង `is_power_of_two()` លើប្រភេទចំនួនគត់មូលដ្ឋានព្រោះថាការដោះស្រាយពិសេសនៃលេខសូន្យអាចត្រូវបានជៀសវាង។
                ///
                ///
                /// # Examples
                ///
                /// ការប្រើប្រាស់មូលដ្ឋាន៖
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // LLVM 11 ធ្វើឱ្យ `unchecked_sub(x, 1) & x == 0` មានលក្ខណៈធម្មតាទៅនឹងការអនុវត្តដែលបានឃើញនៅទីនេះ។
                    // នៅលើគោលដៅ x86-64 មូលដ្ឋាននេះរក្សាទុក 3 សេចក្តីណែនាំសម្រាប់ការត្រួតពិនិត្យសូន្យ។
                    // នៅលើ x86_64 ជាមួយ BMI1, ការមិនមែន nonzero អនុញ្ញាតឱ្យវា codegen ទៅ `BLSR` ដែលរក្សាទុកការណែនាំបើប្រៀបធៀបទៅនឹងការអនុវត្ត `POPCNT` លើប្រភេទចំនួនគត់មូលដ្ឋាន។
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }