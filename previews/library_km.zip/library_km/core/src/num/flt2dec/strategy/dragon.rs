//! ការបកប្រែ Rust ស្ទើរតែដោយផ្ទាល់ (ប៉ុន្តែបានធ្វើឱ្យប្រសើរបន្តិច) នៃរូបភាពទី ៣ នៃ "ការបោះពុម្ពលេខអណ្តែតទឹកយ៉ាងលឿននិងត្រឹមត្រូវ" [^ ១] ។
//!
//!
//! [^1]: Burger, អឹមជីនិងឌីប៊ីប៊ីជី, ខេខេ ១៩៩៦ ។ បោះពុម្ពលេខអណ្តែតទឹក
//!   យ៉ាងឆាប់រហ័សនិងត្រឹមត្រូវ។SIGPLAN មិនមែនទេ។៣១, ៥ (ឧសភា ១៩៩៦), ១០៨-១១៦ ។

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// អារេដែលកំណត់ដោយ `ខ្ទង់` សម្រាប់ ១០ ^ (២ ^ ន)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// អាចប្រើបាននៅពេល `x < 16 * scale`;`scaleN` គួរតែជា `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ការអនុវត្តន៍របៀបខ្លីបំផុតសម្រាប់នាគ។
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // លេខ `v` ដើម្បីធ្វើទ្រង់ទ្រាយត្រូវបានដឹងថាជា៖
    // - ស្មើនឹង `mant * 2^exp`;
    // - មុនដោយ `(mant - 2 *minus)* 2^exp` នៅក្នុងប្រភេទដើម;និង
    // - តាមពីក្រោយដោយ `(mant + 2 *plus)* 2^exp` ជាប្រភេទដើម។
    //
    // ជាក់ស្តែង `minus` និង `plus` មិនអាចជាសូន្យទេ។(សម្រាប់ភាពមិនចេះរីងស្ងួតយើងប្រើតម្លៃក្រៅជួរ។) យើងក៏សន្មតថាយ៉ាងហោចណាស់មានខ្ទង់មួយត្រូវបានបង្កើតឡើងពោលគឺ `mant` ក៏មិនអាចសូន្យដែរ។
    //
    // នេះក៏មានន័យថាលេខណាមួយនៅចន្លោះ `low = (mant - minus)*2^exp` និង `high = (mant + plus)* 2^exp` នឹងតំរែតំរង់ទៅចំនួនចំនុចអណ្តែតពិតប្រាកដជាមួយនឹងការដាក់បញ្ចូលនៅពេលដែលម៉ាតសារីដើមគឺ (ឧទាហរណ៍ `!mant_was_odd`) ។
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` គឺ `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // ប៉ាន់ស្មាន `k_0` ពីធាតុដើមដែលពេញចិត្ត `10^(k_0-1) < high <= 10^(k_0+1)` ។
    // X0XX ពេញចិត្តនឹងការរឹតបន្តឹងត្រូវបានគណនានៅពេលក្រោយ។
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // បំលែង `{mant, plus, minus} * 2^exp` ទៅជាទម្រង់ប្រភាគដូច្នេះ៖
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // ចែក `mant` ដោយ `10^k` ។ឥឡូវ `scale / 10 < mant + plus <= scale * 10` ។
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // ជួសជុលនៅពេល `mant + plus > scale` (ឬ `>=`) ។
    // យើងមិនបានកែប្រែ `scale` ទេពីព្រោះយើងអាចរំលងគុណដំបូងជំនួស។
    // ឥឡូវ `scale < mant + plus <= scale * 10` ហើយយើងត្រៀមខ្លួនដើម្បីបង្កើតខ្ទង់។
    //
    // ចំណាំថា `d[0]`*អាច* ជាសូន្យនៅពេល `scale - plus < mant < scale` ។
    // ក្នុងករណីនេះលក្ខន្តិកៈមូល (`up` ខាងក្រោម) នឹងកើតឡើងភ្លាមៗ។
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ស្មើនឹងការធ្វើមាត្រដ្ឋាន `scale` ត្រឹម ១០
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ឃ្លាំងសម្ងាត់ `(2, 4, 8) * scale` សម្រាប់ជំនាន់ខ្ទង់។
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // កន្លែងដែលលេខ `d[0..n-1]` គឺជាខ្ទង់ដែលបានបង្កើតរហូតមកដល់ពេលនេះ:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (ដូច្នេះ `mant / scale < 10`) ដែល `d[i..j]` ខ្លីសម្រាប់ `ឃ [ខ្ញុំ] * 10 ^ (ជី) + ...
        // + d [j-1] * ១០ + X០០X ។

        // បង្កើតខ្ទង់មួយ៖ `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // នេះគឺជាការពិពណ៌នាសាមញ្ញនៃក្បួនដោះស្រាយនាគដែលបានកែប្រែ។
        // ដេរីវេមធ្យមនិងអាគុយម៉ង់ពេញលេញត្រូវបានលុបចោលដើម្បីភាពងាយស្រួល។
        //
        // ចាប់ផ្តើមជាមួយការលុបចោលដែលបានកែប្រែដូចដែលយើងបានធ្វើបច្ចុប្បន្នភាព `n`៖
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // សន្មតថា `d[0..n-1]` គឺជាការតំណាងខ្លីបំផុតរវាង `low` និង `high` មានន័យថា `d[0..n-1]` ពេញចិត្តទាំងពីរដូចខាងក្រោមប៉ុន្តែ `d[0..n-2]` មិន៖
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (ភាពចំរុះ៖ ខ្ទង់ជុំដល់ `v`);និង
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (ខ្ទង់ចុងក្រោយគឺត្រឹមត្រូវ) ។
        //
        // លក្ខខណ្ឌទី ២ ងាយស្រួលដល់ `2 * mant <= scale` ។
        // ដោះស្រាយការលុកលុយនៅក្នុងលក្ខខណ្ឌនៃ `mant`, `low` និង `high` ផ្តល់នូវកំណែសាមញ្ញនៃលក្ខខណ្ឌដំបូង: `-plus < mant < minus`.
        // ចាប់តាំងពី `-plus < 0 <= mant` យើងមានតំណាងខ្លីបំផុតត្រឹមត្រូវនៅពេល `mant < minus` និង `2 * mant <= scale` ។
        // (អតីតក្លាយជា `mant <= minus` នៅពេលដែល mantissa ដើមគឺ។)
        //
        // នៅពេលដែលទីពីរមិនកាន់ (`2 * mant> scale`) យើងត្រូវបង្កើនខ្ទង់ចុងក្រោយ។
        // នេះគឺគ្រប់គ្រាន់សម្រាប់ការស្តារលក្ខខណ្ឌនោះឡើងវិញ។ យើងដឹងរួចហើយថាជំនាន់ខ្ទង់ធានាដល់ `0 <= v / 10^(k-n) - d[0..n-1] < 1` ។
        // ក្នុងករណីនេះលក្ខខណ្ឌទីមួយក្លាយជា `-plus < mant - scale < minus` ។
        // ចាប់តាំងពី `mant < scale` បន្ទាប់ពីជំនាន់យើងមាន `scale < mant + plus` ។
        // (ម្តងទៀតវាក្លាយជា `scale <= mant + plus` នៅពេលដែល mantissa ដើមគឺ។)
        //
        // នៅក្នុងរយៈពេលខ្លី:
        // - បញ្ឈប់និងបង្គត់ `down` (រក្សាលេខដូចពេល `mant < minus` (ឬ `<=`) ។
        // - បញ្ឈប់និងមូល `up` (បង្កើនខ្ទង់ចុងក្រោយ) ពេល `scale < mant + plus` (ឬ `<=`) ។
        // - រក្សាការបង្កើតបើមិនដូច្នេះទេ។
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // យើងមានតំណាងខ្លីបំផុតបន្តទៅជុំទី

        // ស្តារការលុកលុយ។
        // នេះធ្វើឱ្យក្បួនដោះស្រាយតែងតែបញ្ចប់: `minus` និង `plus` តែងតែកើនឡើងប៉ុន្តែ `mant` ត្រូវបានច្រឹបម៉ូឌុល `scale` និង `scale` ត្រូវបានជួសជុល។
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // ការបង្គត់ឡើងកើតឡើងនៅពេលដែលខ្ញុំ) មានតែលក្ខខណ្ឌវិលជុំប៉ុណ្ណោះដែលត្រូវបានកេះឬ ii) លក្ខខណ្ឌទាំងពីរត្រូវបានកេះនិងស្មើការបំបែកការនិយមចូលចិត្តមូល។
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ប្រសិនបើការបង្គត់ឡើងផ្លាស់ប្តូរប្រវែងនិទស្សន្តក៏គួរតែផ្លាស់ប្តូរដែរ។
        // វាហាក់ដូចជាស្ថានភាពនេះពិបាកក្នុងការបំពេញ (មិនអាចទៅរួចទេ) ប៉ុន្តែយើងទើបតែមានសុវត្ថិភាពនិងជាប់លាប់នៅទីនេះ។
        //
        // សុវត្ថិភាព: យើងចាប់ផ្តើមការចងចាំខាងលើ។
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // សុវត្ថិភាព: យើងចាប់ផ្តើមការចងចាំខាងលើ។
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ការអនុវត្តន៍របៀបថេរនិងថេរសម្រាប់នាគ។
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // ប៉ាន់ស្មាន `k_0` ពីធាតុដើមដែលពេញចិត្ត `10^(k_0-1) < v <= 10^(k_0+1)` ។
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // ចែក `mant` ដោយ `10^k` ។ឥឡូវ `scale / 10 < mant <= scale * 10` ។
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // ជួសជុលនៅពេល `mant + plus >= scale` កន្លែង `plus / scale = 10^-buf.len() / 2` ។
    // ក្នុងគោលបំណងដើម្បីរក្សា bignum ទំហំថេរ, យើងពិតជាប្រើ `mant + floor(plus) >= scale` ។
    // យើងមិនបានកែប្រែ `scale` ទេពីព្រោះយើងអាចរំលងគុណដំបូងជំនួស។
    // ជាថ្មីម្តងទៀតជាមួយនឹងក្បួនដោះស្រាយខ្លីបំផុត, `d[0]` អាចជាសូន្យប៉ុន្តែនៅទីបំផុតនឹងត្រូវបានបង្គត់ឡើង។
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ស្មើនឹងការធ្វើមាត្រដ្ឋាន `scale` ត្រឹម ១០
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ប្រសិនបើយើងកំពុងធ្វើការជាមួយដែនកំណត់ខ្ទង់ចុងក្រោយយើងត្រូវកាត់បន្ថយសតិបណ្ដោះអាសន្នមុនពេលធ្វើការបង្ហាញជាក់ស្តែងដើម្បីចៀសវាងការបង្គត់ទ្វេ។
    //
    // ចំណាំថាយើងត្រូវតែពង្រីកសតិបណ្ដោះអាសន្នម្តងទៀតនៅពេលប្រមូលផ្តុំកើតឡើង!
    let mut len = if k < limit {
        // អូយយើងក៏មិនអាចផលិតលេខមួយខ្ទង់បានដែរ។
        // នេះអាចទៅរួចនៅពេលយើងនិយាយថាយើងមានអ្វីមួយដូចជា 9.5 ហើយវាត្រូវបានគេបង្គត់ដល់ ១០ ។
        // យើងត្រលប់មកវិញនូវសតិបណ្ដោះអាសន្នទទេដោយមានករណីលើកលែងនៃករណីជុំក្រោយដែលកើតឡើងនៅពេល `k == limit` ហើយត្រូវផលិតមួយខ្ទង់។
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // ឃ្លាំងសម្ងាត់ `(2, 4, 8) * scale` សម្រាប់ជំនាន់ខ្ទង់។
        // (វាអាចថ្លៃណាស់ដូច្នេះកុំគណនាវានៅពេលសតិបណ្ដោះអាសន្នទទេ។)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ខ្ទង់ខាងក្រោមគឺទាំងអស់សូន្យយើងឈប់នៅទីនេះធ្វើ *កុំ* ព្យាយាមអនុវត្តការបង្គត់!ផ្ទុយទៅវិញបំពេញខ្ទង់នៅសល់។
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // សុវត្ថិភាព: យើងចាប់ផ្តើមការចងចាំខាងលើ។
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // បង្គត់ឡើងបើយើងឈប់នៅពាក់កណ្តាលខ្ទង់បើតួរលេខខាងក្រោមមាន ៥០០០ ... សូមឆែកមើលខ្ទង់មុនហើយព្យាយាមបង្គត់រហូតដល់ (មានន័យថាចៀសវាងការបង្គត់នៅពេលខ្ទង់មុនគឺស្មើ) ។
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // សុវត្ថិភាព: `buf[len-1]` ត្រូវបានចាប់ផ្តើម។
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ប្រសិនបើការបង្គត់ឡើងផ្លាស់ប្តូរប្រវែងនិទស្សន្តក៏គួរតែផ្លាស់ប្តូរដែរ។
        // ប៉ុន្តែយើងត្រូវបានគេស្នើសុំអោយមានលេខថេរដូច្នេះកុំកែប្រែសតិបណ្ដោះអាសន្ន ...
        // សុវត្ថិភាព: យើងចាប់ផ្តើមការចងចាំខាងលើ។
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... លើកលែងតែយើងត្រូវបានស្នើសុំឱ្យមានភាពជាក់លាក់ថេរជំនួសវិញ។
            // យើងក៏ត្រូវពិនិត្យមើលផងដែរថាប្រសិនបើសតិបណ្ដោះអាសន្ននៅទទេនោះខ្ទង់បន្ថែមអាចត្រូវបានបន្ថែមតែនៅពេល `k == limit` (ករណី edge) ។
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // សុវត្ថិភាព: យើងចាប់ផ្តើមការចងចាំខាងលើ។
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}