/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// ខណៈពេលដែលវាត្រូវបានចងក្រងជាឯកសារយ៉ាងទូលំទូលាយនេះជាគោលការណ៍ឯកជនដែលត្រូវបានបង្ហាញជាសាធារណៈសម្រាប់ការសាកល្បង។
// កុំបង្ហាញពួកយើង។
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// ក្បួនដោះស្រាយជំនាន់ខ្ទង់។
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// ទំហំអប្បបរមានៃសតិបណ្ដោះអាសន្នចាំបាច់សម្រាប់របៀបខ្លីបំផុត។
///
/// វាមិនមែនជារឿងតូចតាចទេក្នុងការទាញយកប៉ុន្តែនេះគឺជាលេខមួយបូកនឹងចំនួនអតិបរិមានៃខ្ទង់ទសភាគដ៏សំខាន់ពីក្បួនដោះស្រាយទ្រង់ទ្រាយជាមួយនឹងលទ្ធផលខ្លីបំផុត។
///
/// រូបមន្តពិតប្រាកដគឺ `ceil(# bits in mantissa * log_10 2 + 1)` ។
pub const MAX_SIG_DIGITS: usize = 17;

/// នៅពេល `d` មានខ្ទង់ទសភាគបង្កើនខ្ទង់ចុងក្រោយនិងបន្តយកទំនិញ។
/// ត្រឡប់ខ្ទង់បន្ទាប់នៅពេលវាបណ្តាលឱ្យប្រវែងផ្លាស់ប្តូរ។
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] គឺជាលេខប្រាំបួនទាំងអស់
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 បង្គត់ដល់ ១០០០..០០០ ជាមួយនឹងនិទស្សន្តកើនឡើង
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // សតិបណ្ដោះអាសន្នទទេរឡើង (ចម្លែកបន្តិចប៉ុន្តែសមហេតុផល)
            Some(b'1')
        }
    }
}

/// ផ្នែកដែលមានទ្រង់ទ្រាយ។
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// ចំនួនលេខសូន្យ។
    Zero(usize),
    /// លេខព្យញ្ជនៈរហូតដល់ 5 ខ្ទង់។
    Num(u16),
    /// ច្បាប់ចម្លងនៃបៃដែលបានផ្តល់ឱ្យ។
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// ត្រឡប់ប្រវែងបៃពិតប្រាកដនៃផ្នែកដែលបានផ្តល់។
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// សរសេរផ្នែកមួយទៅក្នុងសតិបណ្ដោះអាសន្នដែលបានផ្គត់ផ្គង់។
    /// ត្រឡប់ចំនួនបៃសរសេរឬ `None` ប្រសិនបើសតិបណ្ដោះអាសន្នមិនគ្រប់គ្រាន់។
    /// (វានៅតែទុកបៃសរសេរដោយផ្នែកខ្លះក្នុងសតិបណ្ដោះអាសន្នកុំពឹងផ្អែកលើវា។)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// លទ្ធផលមានទ្រង់ទ្រាយដែលមានផ្នែកមួយឬច្រើន។
/// នេះអាចត្រូវបានសរសេរទៅសតិបណ្ដោះអាសន្នបៃឬបម្លែងទៅជាខ្សែអក្សរដែលបានបម្រុងទុក។
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// ចំណុះបៃតំណាងឱ្យសញ្ញាមួយទាំង `""`, `"-"` ឬ `"+"` ។
    pub sign: &'static str,
    /// ផ្នែកដែលបានធ្វើទ្រង់ទ្រាយត្រូវបង្ហាញបន្ទាប់ពីមានសញ្ញាសម្គាល់និងចន្លោះលេខសូន្យស្រេចចិត្ត។
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// ត្រឡប់ប្រវែងបៃពិតប្រាកដនៃលទ្ធផលដែលបានធ្វើទ្រង់ទ្រាយរួមគ្នា។
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// សរសេរគ្រប់ផ្នែកដែលមានទ្រង់ទ្រាយទាំងអស់ទៅក្នុងសតិបណ្ដោះអាសន្នដែលបានផ្គត់ផ្គង់។
    /// ត្រឡប់ចំនួនបៃសរសេរឬ `None` ប្រសិនបើសតិបណ្ដោះអាសន្នមិនគ្រប់គ្រាន់។
    /// (វានៅតែទុកបៃសរសេរដោយផ្នែកខ្លះក្នុងសតិបណ្ដោះអាសន្នកុំពឹងផ្អែកលើវា។)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// ទ្រង់ទ្រាយដែលបានផ្តល់ឱ្យលេខខ្ទង់ទសភាគ `0.<...buf...> * 10^exp` ទៅជាទំរង់ទសភាគដែលមានយ៉ាងហោចណាស់ចំនួនខ្ទង់ដែលបានផ្តល់។
///
/// លទ្ធផលត្រូវបានរក្សាទុកទៅក្នុងគ្រឿងបន្លាស់ដែលបានផ្គត់ផ្គង់ហើយផ្នែកនៃផ្នែកដែលបានសរសេរត្រូវបានត្រឡប់មកវិញ។
///
/// `frac_digits` អាចតិចជាងចំនួនតួរលេខប្រភាគនៅក្នុង `buf` ។
/// វានឹងត្រូវបានមិនអើពើហើយលេខពេញនឹងត្រូវបានបោះពុម្ព។វាត្រូវបានប្រើដើម្បីបោះពុម្ពសូន្យបន្ថែមបន្ទាប់ពីបានបង្ហាញលេខ។
/// ដូច្នេះ `frac_digits` នៃ 0 មានន័យថាវានឹងបោះពុម្ពតែតួលេខដែលបានផ្តល់ហើយគ្មានអ្វីផ្សេងទៀតទេ។
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // ប្រសិនបើមានការដាក់កម្រិតលើទីតាំងខ្ទង់ចុងក្រោយនោះ `buf` ត្រូវបានសន្មតថាទុកនៅខាងឆ្វេងជាមួយសូន្យនិម្មិត។
    // ចំនួនសូន្យនិម្មិត, `nzeroes`, ស្មើនឹង `max(0, exp + frac_digits - buf.len())`, ដូច្នេះទីតាំងនៃ `exp - buf.len() - nzeroes` ខ្ទង់ចុងក្រោយគឺមិនលើសពី `-frac_digits`:
    //
    //
    //                       |<-virtual->|
    //       | <----ប៊ូ----> |សូន្យ |exp
    //    0. ១ ២ ៣ ៤ ៥ ៦ ៧ ៨ ៩ X០០X X០១X X០២X x ១០
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` ត្រូវបានគណនាជាលក្ខណៈបុគ្គលសម្រាប់ករណីនីមួយៗដើម្បីជៀសវាងការហូរហៀរ។
    //

    if exp <= 0 {
        // ចំណុចទសភាគគឺមុនពេលបង្ហាញលេខ៖ [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..4` ។
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..3` ។
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // ចំណុចទសភាគគឺនៅខាងចុងតួលេខ៖ [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..4` ។
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..3` ។
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // ចំនុចទសភាគគឺបន្ទាប់ពីបានបង្ហាញលេខ៖ [1234][____0000] ឬ [1234][__][.][__] ។
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..4` ។
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..2` ។
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// ធ្វើទ្រង់ទ្រាយលេខ X ខ្ទង់ទសភាគដែលបានផ្ដល់ទៅជាទម្រង់អិចស្ប៉ូណង់ស្យ៉ែនយ៉ាងហោចណាស់ជាមួយចំនួនខ្ទង់សំខាន់ៗ។
///
/// នៅពេល `upper` ជា `true` និទស្សន្តនឹងត្រូវបានដាក់បុព្វបទដោយ `E`;បើមិនដូច្នោះទេនោះគឺ `e` ។
/// លទ្ធផលត្រូវបានរក្សាទុកទៅក្នុងគ្រឿងបន្លាស់ដែលបានផ្គត់ផ្គង់ហើយផ្នែកនៃផ្នែកដែលបានសរសេរត្រូវបានត្រឡប់មកវិញ។
///
/// `min_digits` អាចតិចជាងចំនួនតួរលេខជាក់ស្តែងក្នុង `buf` ។
/// វានឹងត្រូវបានមិនអើពើហើយលេខពេញនឹងត្រូវបានបោះពុម្ព។វាត្រូវបានប្រើដើម្បីបោះពុម្ពសូន្យបន្ថែមបន្ទាប់ពីបានបង្ហាញលេខ។
/// ដូច្នេះ `min_digits == 0` មានន័យថាវានឹងបោះពុម្ពតែតួលេខដែលបានផ្តល់ហើយគ្មានអ្វីផ្សេងទៀតទេ។
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // ជៀសវាងការហូរចេញនៅពេលផុតគឺ i16::MIN
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..n + 2` ។
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// ចុះហត្ថលេខាលើជម្រើសធ្វើទ្រង់ទ្រាយ។
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// បោះពុម្ព `-` សម្រាប់តែតម្លៃអវិជ្ជមានមិនមែនសូន្យ។
    Minus, // -inf -1 0 0 1 inf nan
    /// បោះពុម្ព `-` សម្រាប់តែតម្លៃអវិជ្ជមានណាមួយ (រួមទាំងលេខសូន្យអវិជ្ជមាន) ។
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// បោះពុម្ព `-` សម្រាប់តម្លៃអវិជ្ជមានមិនមែនសូន្យឬបើមិនដូច្នេះទេ `+` ។
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// បោះពុម្ព `-` សម្រាប់តម្លៃអវិជ្ជមានណាមួយ (រួមទាំងលេខសូន្យអវិជ្ជមាន) ឬបើមិនដូច្នេះទេ `+` ។
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// ត្រឡប់ខ្សែអក្សរបៃដែលត្រូវគ្នាទៅនឹងសញ្ញាដែលត្រូវធ្វើទ្រង់ទ្រាយ។
/// វាអាចជា `""`, `"+"` ឬ `"-"` ។
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// ធ្វើទ្រង់ទ្រាយលេខចំណុចអណ្តែតដែលបានផ្ដល់ទៅជាទម្រង់ទសភាគដែលមានលេខប្រភាគយ៉ាងហោចណាស់។
/// លទ្ធផលត្រូវបានរក្សាទុកទៅក្នុងគ្រឿងបន្លាស់ដែលបានផ្គត់ផ្គង់ខណៈពេលដែលប្រើសតិបណ្ដោះអាសន្នបៃជាកោស។
/// `upper` បច្ចុប្បន្នមិនត្រូវបានប្រើទេប៉ុន្តែទុកសម្រាប់ការសម្រេចចិត្ត future ដើម្បីផ្លាស់ប្តូរករណីនៃតម្លៃមិនកំណត់ពោលគឺ `inf` និង `nan` ។
///
/// ផ្នែកដំបូងដែលត្រូវបង្ហាញគឺ `Part::Sign` ជានិច្ច (ដែលអាចជាខ្សែរទទេប្រសិនបើគ្មានសញ្ញាត្រូវបានបង្ហាញ) ។
///
/// `format_shortest` គួរតែជាមុខងារជំនាន់ខ្ទង់។
/// វាគួរតែត្រឡប់ផ្នែកនៃសតិបណ្ដោះអាសន្នដែលវាបានចាប់ផ្តើម។
/// អ្នកប្រហែលជាចង់បាន `strategy::grisu::format_shortest` សម្រាប់រឿងនេះ។
///
/// `frac_digits` អាចតិចជាងចំនួនតួរលេខប្រភាគនៅក្នុង `v` ។
/// វានឹងត្រូវបានមិនអើពើហើយលេខពេញនឹងត្រូវបានបោះពុម្ព។វាត្រូវបានប្រើដើម្បីបោះពុម្ពសូន្យបន្ថែមបន្ទាប់ពីបានបង្ហាញលេខ។
/// ដូច្នេះ `frac_digits` នៃ 0 មានន័យថាវានឹងបោះពុម្ពតែតួលេខដែលបានផ្តល់ហើយគ្មានអ្វីផ្សេងទៀតទេ។
///
/// សតិបណ្ដោះអាសន្នបៃគួរមានយ៉ាងហោចណាស់ `MAX_SIG_DIGITS` បៃ។
/// គួរតែមានយ៉ាងហោចណាស់ ៤ ផ្នែកដែលអាចប្រើបានដោយសារតែករណីអាក្រក់បំផុតដូចជា `[+][0.][0000][2][0000]` ជាមួយ `frac_digits = 10` ។
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..2` ។
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// ធ្វើទ្រង់ទ្រាយលេខអណ្តែតដែលបានផ្តល់ទៅជាទំរង់ទសភាគឬទំរង់អិចស្ប៉ូណង់ស្យែលអាស្រ័យលើនិទស្សន្តលទ្ធផល។
/// លទ្ធផលត្រូវបានរក្សាទុកទៅក្នុងគ្រឿងបន្លាស់ដែលបានផ្គត់ផ្គង់ខណៈពេលដែលប្រើសតិបណ្ដោះអាសន្នបៃជាកោស។
/// `upper` ត្រូវបានប្រើដើម្បីកំណត់ករណីនៃតម្លៃមិនកំណត់ (`inf` និង `nan`) ឬករណីបុព្វបទនិទស្សន្ត (`e` ឬ `E`) ។
/// ផ្នែកដំបូងដែលត្រូវបង្ហាញគឺ `Part::Sign` ជានិច្ច (ដែលអាចជាខ្សែរទទេប្រសិនបើគ្មានសញ្ញាត្រូវបានបង្ហាញ) ។
///
/// `format_shortest` គួរតែជាមុខងារជំនាន់ខ្ទង់។
/// វាគួរតែត្រឡប់ផ្នែកនៃសតិបណ្ដោះអាសន្នដែលវាបានចាប់ផ្តើម។
/// អ្នកប្រហែលជាចង់បាន `strategy::grisu::format_shortest` សម្រាប់រឿងនេះ។
///
/// `dec_bounds` គឺជា XE Tuple `(lo, hi)` ដែលចំនួននេះត្រូវបានធ្វើទ្រង់ទ្រាយជាលេខទសភាគតែនៅពេល `10^lo <= V < 10^hi` ។
/// ចំណាំថានេះគឺជា *ជាក់ស្តែង*`V` ជំនួសឱ្យ `v` ជាក់ស្តែង!ដូច្នេះនិទស្សន្តដែលបានបោះពុម្ពក្នុងទម្រង់អិចស្ប៉ូណង់ស្យែលមិនអាចមាននៅក្នុងជួរនេះទេជៀសវាងការភាន់ច្រលំ
///
///
/// សតិបណ្ដោះអាសន្នបៃគួរមានយ៉ាងហោចណាស់ `MAX_SIG_DIGITS` បៃ។
/// គួរតែមានយ៉ាងហោចណាស់ 6 ផ្នែកដែលអាចប្រើបានដោយសារតែករណីដ៏អាក្រក់បំផុតដូចជា `[+][1][.][2345][e][-][6]` ។
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// ត្រឡប់ប្រហាក់ប្រហែលប្រេងឆៅ (ព្រំដែនខ្ពស់) សម្រាប់ទំហំសតិបណ្ដោះអាសន្នអតិបរមាដែលបានគណនាពីនិទស្សន្តដែលបានឌិកូដ។
///
/// ដែនកំណត់ពិតប្រាកដគឺ៖
///
/// - នៅពេល `exp < 0`, ប្រវែងអតិបរមាគឺ `ceil(log_10 (5^-exp * (2^64 - 1)))` ។
/// - នៅពេល `exp >= 0`, ប្រវែងអតិបរមាគឺ `ceil(log_10 (2^exp * (2^64 - 1)))` ។
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` គឺតិចជាង `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)` ដែលជាវេនតិចជាង `20 + (1 + exp* log_10 x)` ។
/// យើងប្រើអង្គហេតុដែល `log_10 2 < 5/16` និង `log_10 5 < 12/16` ដែលគ្រប់គ្រាន់សម្រាប់គោលបំណងរបស់យើង។
///
/// ហេតុអ្វីយើងត្រូវការវា?មុខងារ `format_exact` នឹងបំពេញសតិបណ្ដោះអាសន្នទាំងមូលលុះត្រាតែមានកំណត់ដោយការដាក់ខ្ទង់ចុងក្រោយប៉ុន្តែវាអាចថាចំនួនតួរលេខដែលបានស្នើសុំគឺគួរអោយអស់សំណើចណាស់ (និយាយថា ៣០,០០០ ខ្ទង់) ។
///
/// សតិបណ្ដោះអាសន្នភាគច្រើននឹងត្រូវបានបំពេញដោយសូន្យដូច្នេះយើងមិនចង់បម្រុងទុកសតិបណ្ដោះអាសន្នជាមុនទេ។
/// ដូច្នេះសម្រាប់អំណះអំណាងដែលបានផ្តល់ឱ្យ
/// ៨២៦ បៃនៃអង្គចងចាំគួរតែគ្រប់គ្រាន់សម្រាប់ `f64` ។ប្រៀបធៀបវាជាមួយលេខពិតប្រាកដសម្រាប់ករណីអាក្រក់បំផុត: 770 បៃ (នៅពេល `exp = -1074`) ។
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// ទ្រង់ទ្រាយដែលបានផ្តល់លេខចំណុចអណ្តែតទៅជាទម្រង់អិចស្ប៉ូណង់ស្យែលជាមួយចំនួនខ្ទង់សំខាន់ៗដែលបានផ្តល់។
/// លទ្ធផលត្រូវបានរក្សាទុកទៅក្នុងគ្រឿងបន្លាស់ដែលបានផ្គត់ផ្គង់ខណៈពេលដែលប្រើសតិបណ្ដោះអាសន្នបៃជាកោស។
/// `upper` ត្រូវបានប្រើដើម្បីកំណត់ករណីនៃបុព្វបទនិទស្សន្ត (`e` ឬ `E`) ។
/// ផ្នែកដំបូងដែលត្រូវបង្ហាញគឺ `Part::Sign` ជានិច្ច (ដែលអាចជាខ្សែរទទេប្រសិនបើគ្មានសញ្ញាត្រូវបានបង្ហាញ) ។
///
/// `format_exact` គួរតែជាមុខងារជំនាន់ខ្ទង់។
/// វាគួរតែត្រឡប់ផ្នែកនៃសតិបណ្ដោះអាសន្នដែលវាបានចាប់ផ្តើម។
/// អ្នកប្រហែលជាចង់បាន `strategy::grisu::format_exact` សម្រាប់រឿងនេះ។
///
/// សតិបណ្ដោះអាសន្នបៃគួរមានយ៉ាងហោចណាស់ `ndigits` បៃដរាបណា `ndigits` ធំណាស់ដូច្នេះមានតែលេខថេរនៃលេខដែលនឹងត្រូវសរសេរ។
/// (ចំណុចទាញសម្រាប់ `f64` គឺប្រហែល 800, ដូច្នេះ 1000 បៃគួរតែគ្រប់គ្រាន់។) គួរតែមានយ៉ាងហោចណាស់ 6 ផ្នែកដែលអាចប្រើបានដោយសារតែករណីដែលអាក្រក់បំផុតដូចជា `[+][1][.][2345][e][-][6]` ។
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..3` ។
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// ទ្រង់ទ្រាយដែលបានផ្តល់លេខចំណុចអណ្តែតទៅជាទំរង់ទសភាគដែលមានចំនួនប្រភាគដែលបានផ្តល់យ៉ាងពិតប្រាកដ។
/// លទ្ធផលត្រូវបានរក្សាទុកទៅក្នុងគ្រឿងបន្លាស់ដែលបានផ្គត់ផ្គង់ខណៈពេលដែលប្រើសតិបណ្ដោះអាសន្នបៃជាកោស។
/// `upper` បច្ចុប្បន្នមិនត្រូវបានប្រើទេប៉ុន្តែទុកសម្រាប់ការសម្រេចចិត្ត future ដើម្បីផ្លាស់ប្តូរករណីនៃតម្លៃមិនកំណត់ពោលគឺ `inf` និង `nan` ។
/// ផ្នែកដំបូងដែលត្រូវបង្ហាញគឺ `Part::Sign` ជានិច្ច (ដែលអាចជាខ្សែរទទេប្រសិនបើគ្មានសញ្ញាត្រូវបានបង្ហាញ) ។
///
/// `format_exact` គួរតែជាមុខងារជំនាន់ខ្ទង់។
/// វាគួរតែត្រឡប់ផ្នែកនៃសតិបណ្ដោះអាសន្នដែលវាបានចាប់ផ្តើម។
/// អ្នកប្រហែលជាចង់បាន `strategy::grisu::format_exact` សម្រាប់រឿងនេះ។
///
/// សតិបណ្ដោះអាសន្នបៃគួរតែគ្រប់គ្រាន់សម្រាប់លទ្ធផលលុះត្រាតែ `frac_digits` មានទំហំធំដូច្នេះមានតែលេខថេរនៃតួលេខនឹងត្រូវបានសរសេរ។
/// (ចំណុចទាញសម្រាប់ `f64` គឺប្រហែល 800 ហើយ 1000 បៃគួរតែគ្រប់គ្រាន់។) គួរតែមានយ៉ាងហោចណាស់ 4 ផ្នែកដែលអាចប្រើបានដោយសារតែករណីអាក្រក់បំផុតដូចជា `[+][0.][0000][2][0000]` ជាមួយ `frac_digits = 10` ។
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..2` ។
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // វាអាចទៅរួចដែលថា `frac_digits` មានទំហំធំគួរឱ្យអស់សំណើច។
            // `format_exact` នឹងបញ្ចប់ការបង្ហាញលេខមុនគេក្នុងករណីនេះព្រោះយើងត្រូវបានកំណត់យ៉ាងតឹងរ៉ឹងដោយ `maxlen` ។
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // ការរឹតត្បិតមិនអាចត្រូវបានឆ្លើយតបទេដូច្នេះនេះគួរតែបង្ហាញដូចជាសូន្យមិនថា `exp` គឺយ៉ាងណាទេ។
                // នេះមិនរាប់បញ្ចូលករណីដែលការរឹតត្បិតនេះត្រូវបានបំពេញបន្ទាប់ពីការជុំចុងក្រោយ។វាជាករណីធម្មតាជាមួយ `exp = limit + 1` ។
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..2` ។
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // សុវត្ថិភាព: យើងទើបតែចាប់ផ្តើមធាតុ `..1` ។
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}