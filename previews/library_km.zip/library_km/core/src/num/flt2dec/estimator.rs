//! អ្នកប៉ាន់ស្មាននិទស្សន្ត។

/// រក `k_0` ដូចជា `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)` ។
///
/// នេះត្រូវបានប្រើដើម្បីប្រហាក់ប្រហែល `k = ceil(log_10 (mant * 2^exp))`;
/// `k` ពិតគឺ `k_0` ឬ `k_0+1` ។
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits ប្រសិនបើ mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) ដូច្នេះនេះតែងតែមើលស្រាល (ឬជាក់លាក់) ប៉ុន្តែមិនច្រើនទេ។
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}