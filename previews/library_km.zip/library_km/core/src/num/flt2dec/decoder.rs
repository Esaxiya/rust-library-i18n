//! ឌិកូដតម្លៃទសភាគទៅជាផ្នែកនីមួយៗនិងជួរកំហុស។

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// តម្លៃកំណត់ដែលមិនទាន់ចុះហត្ថលេខាដែលបានចុះហត្ថលេខាដូចជា៖
///
/// - តម្លៃដើមស្មើនឹង `mant * 2^exp` ។
///
/// - លេខណាមួយពី `(mant - minus)*2^exp` ដល់ `(mant + plus)* 2^exp` នឹងបង្គត់ទៅតម្លៃដើម។
/// ជួរគឺរាប់បញ្ចូលតែនៅពេល `inclusive` គឺ `true` ប៉ុណ្ណោះ។
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// មាត្រដ្ឋានធ្វើមាត្រដ្ឋាន។
    pub mant: u64,
    /// ជួរកំហុសទាប។
    pub minus: u64,
    /// ជួរកំហុសខាងលើ។
    pub plus: u64,
    /// និទស្សន្តរួមនៅក្នុងគោល ២ ។
    pub exp: i16,
    /// ពិតនៅពេលជួរកំហុសគឺរាប់បញ្ចូល។
    ///
    /// នៅក្នុង IEEE 754 នេះគឺជាការពិតនៅពេលដែល mantissa ដើម។
    pub inclusive: bool,
}

/// តម្លៃដែលមិនទាន់ចុះហត្ថលេខា
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// ភាពមិនបរិសុទ្ធទាំងវិជ្ជមានឬអវិជ្ជមាន។
    Infinite,
    /// សូន្យទាំងវិជ្ជមានឬអវិជ្ជមាន។
    Zero,
    /// លេខកំណត់ដោយមានវាលដែលបានឌិកូដបន្ថែម។
    Finite(Decoded),
}

/// ប្រភេទចំណុចអណ្តែតដែលអាចជា `ឌិកូដលេខឃ។
pub trait DecodableFloat: RawFloat + Copy {
    /// តម្លៃធម្មតាអប្បបរមាអប្បបរមា។
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// ត្រឡប់សញ្ញា (ពិតនៅពេលអវិជ្ជមាន) និងតម្លៃ `FullDecoded` ពីលេខចំណុចអណ្តែតដែលបានផ្តល់។
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // អ្នកជិតខាង៖ (កន្ទក់ ២, ផុត)-(ម៉ែន, ផុត)-(ម៉ែត + ២, ផុត)
            // Float::integer_decode តែងតែការពារនិទស្សន្តដូច្នេះ mantissa ត្រូវបានធ្វើមាត្រដ្ឋានសម្រាប់អនុក្រុមតូចៗ។
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // អ្នកជិតខាង៖ (អតិបរមា, ផុត, ១)-(មីនតូច, ផុត)-(មីនតិច + ១, ផុត)
                // ដែលជាកន្លែងដែលអតិបរិមា=២, ១
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // អ្នកជិតខាង៖ (កន្ទេល ១ ផុតកំណត់)-(ម៉ែល, ផុត)-(ម៉ែន + ១, ផុត)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}