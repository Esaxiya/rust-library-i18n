//! ថេរសម្រាប់ប្រភេទចំនួនគត់ដែលបានចុះហត្ថលេខា ៣២ ប៊ីត។
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! លេខកូដថ្មីគួរតែប្រើថេរដែលជាប់ទាក់ទងដោយផ្ទាល់លើប្រភេទបុព្វកាល។

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }