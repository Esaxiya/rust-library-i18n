//! ថេរសម្រាប់ប្រភេទចំនួនគត់គ្មានការចុះបញ្ជី ៨ ប៊ីត។
//!
//! *[See also the `u8` primitive type][u8].*
//!
//! លេខកូដថ្មីគួរតែប្រើថេរដែលជាប់ទាក់ទងដោយផ្ទាល់លើប្រភេទបុព្វកាល។

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u8`"
)]

int_module! { u8 }