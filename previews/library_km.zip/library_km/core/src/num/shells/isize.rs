//! ថេរសម្រាប់ប្រភេទចំនួនគត់ដែលបានចុះហត្ថលេខាដោយទ្រនិច។
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! លេខកូដថ្មីគួរតែប្រើថេរដែលជាប់ទាក់ទងដោយផ្ទាល់លើប្រភេទបុព្វកាល។

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }