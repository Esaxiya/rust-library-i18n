//! ថេរសម្រាប់ប្រភេទចំនួនគត់ដែលមិនបានចុះបញ្ជី ១២៨ ប៊ីត។
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! លេខកូដថ្មីគួរតែប្រើថេរដែលជាប់ទាក់ទងដោយផ្ទាល់លើប្រភេទបុព្វកាល។

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }