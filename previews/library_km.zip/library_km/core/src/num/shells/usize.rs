//! ចំនួនថេរសម្រាប់ប្រភេទចំនួនគត់ដែលមិនត្រូវបានចុះហត្ថលេខាដោយទ្រនិច។
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! លេខកូដថ្មីគួរតែប្រើថេរដែលជាប់ទាក់ទងដោយផ្ទាល់លើប្រភេទបុព្វកាល។

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }