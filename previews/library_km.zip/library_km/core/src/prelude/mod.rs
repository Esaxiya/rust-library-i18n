//! libcore preclus
//!
//! ម៉ូឌុលនេះត្រូវបានបម្រុងទុកសម្រាប់អ្នកប្រើប្រាស់ libcore ដែលមិនភ្ជាប់ទៅនឹង libstd ផងដែរ។
//! ម៉ូឌុលនេះត្រូវបាននាំចូលតាមលំនាំដើមនៅពេល `#![no_std]` ត្រូវបានប្រើតាមរបៀបដូចគ្នានឹង prelude របស់បណ្ណាល័យស្តង់ដារ។
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// ស៊េរីឆ្នាំ 2015 នៃស្នូល prelude ។
///
/// មើល [module-level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ស៊េរីឆ្នាំ 2018 នៃស្នូល prelude ។
///
/// មើល [module-level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// ស៊េរីឆ្នាំ ២០២១ នៃស្នូល prelude ។
///
/// មើល [module-level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: បន្ថែមរបស់ជាច្រើនទៀត។
}