// ignore-tidy-filelength

//! ការគ្រប់គ្រងនិងរៀបចំដោយចំណិត។
//!
//! សម្រាប់ព័ត៌មានលម្អិតសូមមើល [`std::slice`] ។
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// ការអនុវត្តន៍អនុស្សាវរីយ៍ rust សុទ្ធដែលយកពីហ្សីនហ្ស័រហ្ស៊ីហ្សហ្ស៍
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// មុខងារនេះគឺបង្ហាញជាសាធារណៈតែប៉ុណ្ណោះពីព្រោះមិនមានវិធីផ្សេងទៀតដើម្បីដាក់តេស្តិ៍តេស្តិ៍យូធ្យូប។
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// ត្រឡប់ចំនួននៃធាតុនៅក្នុងចំណែក។
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // សុវត្ថិភាព: សំឡេងថេរពីព្រោះយើងបញ្ជូនវាលប្រវែងជាទំហំប្រើប្រាស់ (ដែលវាត្រូវតែមាន)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // សុវត្ថិភាព: នេះមានសុវត្ថិភាពពីព្រោះ `&[T]` និង `FatPtr<T>` មានប្លង់តែមួយ។
            // មានតែ `std` ប៉ុណ្ណោះដែលអាចធានាបាន។
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: ជំនួសដោយ `crate::ptr::metadata(self)` នៅពេលនោះថេរ។
            // ដូចដែលការសរសេរនេះបណ្តាលឱ្យមានកំហុស "Const-stable functions can only call other const-stable functions" ។
            //

            // សុវត្ថិភាព: ការទទួលបានតម្លៃពីសហជីព `PtrRepr` គឺមានសុវត្ថិភាពចាប់តាំងពី * const T
            // និង Ptr អ្នកចូលរួម<T>មានប្លង់ចងចាំដូចគ្នា។
            // មានតែ std ប៉ុណ្ណោះដែលអាចធានាបាន។
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើចំណិតមានប្រវែង 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ត្រឡប់ធាតុដំបូងនៃចំណិតឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ត្រឡប់ទ្រនិចដែលអាចប្តូរបានទៅធាតុដំបូងនៃចំណិតឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// ត្រឡប់ធាតុដំបូងនិងធាតុនៅសល់ទាំងអស់នៃចំណែកឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ត្រឡប់ធាតុដំបូងនិងធាតុនៅសល់ទាំងអស់នៃចំណែកឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// ត្រឡប់ធាតុចុងក្រោយនិងវត្ថុនៅសល់ទាំងអស់ឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ត្រឡប់ធាតុចុងក្រោយនិងវត្ថុនៅសល់ទាំងអស់ឬ `None` ប្រសិនបើវានៅទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// ត្រឡប់ធាតុចុងក្រោយនៃ slice ឬ `None` ប្រសិនបើវាគឺទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ត្រឡប់ទ្រនិចដែលអាចផ្លាស់ប្តូរបានទៅធាតុចុងក្រោយនៅក្នុងចំណែក។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// ត្រឡប់សេចក្តីយោងទៅធាតុមួយឬរងអាស្រ័យលើប្រភេទលិបិក្រម។
    ///
    /// - ប្រសិនបើបានផ្តល់ទីតាំងត្រឡប់សេចក្តីយោងទៅធាតុនៅទីតាំងនោះឬ `None` ប្រសិនបើនៅក្រៅព្រំដែន។
    ///
    /// - ប្រសិនបើបានផ្តល់ជួរ, ត្រឡប់ subslice ដែលត្រូវគ្នាទៅនឹងជួរនោះ, ឬ `None` ប្រសិនបើនៅក្រៅព្រំដែន។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានចំពោះធាតុរឺសំណុំរងអាស្រ័យលើប្រភេទលិបិក្រម (សូមមើល [`get`]) ឬ `None` ប្រសិនបើសន្ទស្សន៍នៅក្រៅព្រំដែន។
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// ត្រឡប់សេចក្ដីយោងទៅធាតុរឺសំណុំរងមួយដោយមិនចាំបាច់ពិនិត្យព្រំដែន។
    ///
    /// សម្រាប់ជម្រើសសុវត្ថិភាពសូមមើល [`get`] ។
    ///
    /// # Safety
    ///
    /// ការហៅវិធីសាស្ត្រនេះជាមួយសន្ទស្សន៍ក្រៅព្រំដែនគឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]* ទោះបីជាឯកសារយោងលទ្ធផលមិនត្រូវបានប្រើក៏ដោយ។
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែគាំទ្រភាគច្រើនបំផុតនៃតម្រូវការសុវត្ថិភាពសម្រាប់ `get_unchecked` នេះ;
        // ចំណែកគឺមិនអាចដោះស្រាយបានទេពីព្រោះ `self` គឺជាឯកសារយោងដែលមានសុវត្ថិភាព។
        // ទ្រនិចដែលបានត្រឡប់មកវិញមានសុវត្ថិភាពពីព្រោះការភ្ជាប់ `SliceIndex` ត្រូវតែធានាថាវាជា។
        unsafe { &*index.get_unchecked(self) }
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានចំពោះធាតុរឺការរងដោយមិនចាំបាច់ពិនិត្យព្រំដែន។
    ///
    /// សម្រាប់ជម្រើសសុវត្ថិភាពសូមមើល [`get_mut`] ។
    ///
    /// # Safety
    ///
    /// ការហៅវិធីសាស្ត្រនេះជាមួយសន្ទស្សន៍ក្រៅព្រំដែនគឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]* ទោះបីជាឯកសារយោងលទ្ធផលមិនត្រូវបានប្រើក៏ដោយ។
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែប្រកាន់ខ្ជាប់នូវតម្រូវការសុវត្ថិភាពសម្រាប់ `get_unchecked_mut`;
        // ចំណែកគឺមិនអាចដោះស្រាយបានទេពីព្រោះ `self` គឺជាឯកសារយោងដែលមានសុវត្ថិភាព។
        // ទ្រនិចដែលបានត្រឡប់មកវិញមានសុវត្ថិភាពពីព្រោះការភ្ជាប់ `SliceIndex` ត្រូវតែធានាថាវាជា។
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// ត្រឡប់ទ្រនិចឆៅទៅសតិបណ្ដោះអាសន្ន។
    ///
    /// អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាចំណិត outlives ព្រួញមុខងារនេះត្រឡប់មកវិញ, ឬផ្សេងទៀតវានឹងបញ្ចប់ឡើងដែលចង្អុលទៅកាន់សំរាម។
    ///
    /// អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាការចងចាំព្រួញពិន្ទុ (non-transitively) ទៅនឹងមិនត្រូវបានសរសេរទៅ (លើកលែងតែនៅក្នុង `UnsafeCell` មួយ) ដោយប្រើព្រួញនេះឬព្រួញណាមួយដែលបានមកពីវា។
    /// ប្រសិនបើអ្នកត្រូវការផ្លាស់ប្តូរមាតិកានៃចំណែកសូមប្រើ [`as_mut_ptr`] ។
    ///
    /// ការកែប្រែកុងតឺន័រដែលយោងដោយចំណិតនេះអាចបណ្តាលឱ្យសតិបណ្ដោះអាសន្នរបស់វាត្រូវបានផ្លាស់ប្តូរទីតាំងដែលអាចធ្វើឱ្យចង្អុលបង្ហាញវាមិនត្រឹមត្រូវ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// ត្រឡប់ទ្រនិចដែលអាចប្តូរបានដោយមិនមានសុវត្ថិភាពទៅសតិបណ្ដោះអាសន្ន។
    ///
    /// អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាចំណិត outlives ព្រួញមុខងារនេះត្រឡប់មកវិញ, ឬផ្សេងទៀតវានឹងបញ្ចប់ឡើងដែលចង្អុលទៅកាន់សំរាម។
    ///
    /// ការកែប្រែកុងតឺន័រដែលយោងដោយចំណិតនេះអាចបណ្តាលឱ្យសតិបណ្ដោះអាសន្នរបស់វាត្រូវបានផ្លាស់ប្តូរទីតាំងដែលអាចធ្វើឱ្យចង្អុលបង្ហាញវាមិនត្រឹមត្រូវ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// ត្រឡប់ចង្អុរឆៅពីរដែលលាតសន្ធឹងលើចំណិត។
    ///
    /// ជួរដែលបានត្រឡប់មកវិញគឺពាក់កណ្តាលបើកចំហដែលមានន័យថាចំណុចចុងចង្អុល *មួយអតីតកាល* ធាតុចុងក្រោយនៃចំណិត។
    /// វិធីនេះចំណែកទទេត្រូវបានតំណាងដោយចង្អុលពីរស្មើគ្នាហើយភាពខុសគ្នារវាងចង្អុលទាំងពីរតំណាងឱ្យទំហំនៃចំណិត។
    ///
    /// សូមមើល [`as_ptr`] សម្រាប់ការព្រមានអំពីការប្រើប្រាស់ចង្អុលទាំងនេះ។ទ្រនិចចុងតម្រូវឱ្យមានការប្រុងប្រយ័ត្នបន្ថែមព្រោះវាមិនចង្អុលបង្ហាញធាតុដែលត្រឹមត្រូវនៅក្នុងចំណិត។
    ///
    /// មុខងារនេះមានប្រយោជន៍សម្រាប់អន្តរកម្មជាមួយចំណុចប្រទាក់បរទេសដែលប្រើទ្រនិចចង្អុលពីរដើម្បីយោងទៅលើធាតុជាច្រើននៅក្នុងសតិក៏ដូចជាលក្ខណៈទូទៅនៅក្នុង C++ ។
    ///
    ///
    /// វាក៏មានប្រយោជន៍ផងដែរដើម្បីពិនិត្យមើលថាតើទ្រនិចចង្អុលទៅធាតុសំដៅទៅលើធាតុមួយនៃចំណិតនេះ:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // សុវត្ថិភាព: `add` នៅទីនេះមានសុវត្ថិភាពពីព្រោះ៖
        //
        //   - ទ្រនិចចង្អុលទាំងពីរគឺជាផ្នែកមួយនៃវត្ថុដូចគ្នាព្រោះការចង្អុលដោយផ្ទាល់លើវត្ថុក៏រាប់ដែរ។
        //
        //   - ទំហំនៃចំណិតមិនធំជាង isize::MAX បៃដូចដែលបានកត់សម្គាល់នៅទីនេះទេ។
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - មិនមានការរុំព័ទ្ធជុំវិញទេពីព្រោះចំណិតមិនរុំចុងបញ្ចប់នៃចន្លោះអាសយដ្ឋាន។
        //
        // សូមមើលឯកសាររបស់ pointer::add ។
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ត្រឡប់ចំណុចចង្អុលដែលអាចផ្លាស់ប្តូរបានពីរដែលមិនមានសុវត្ថិភាពដែលលាតសន្ធឹងលើចំណិត។
    ///
    /// ជួរដែលបានត្រឡប់មកវិញគឺពាក់កណ្តាលបើកចំហដែលមានន័យថាចំណុចចុងចង្អុល *មួយអតីតកាល* ធាតុចុងក្រោយនៃចំណិត។
    /// វិធីនេះចំណែកទទេត្រូវបានតំណាងដោយចង្អុលពីរស្មើគ្នាហើយភាពខុសគ្នារវាងចង្អុលទាំងពីរតំណាងឱ្យទំហំនៃចំណិត។
    ///
    /// សូមមើល [`as_mut_ptr`] សម្រាប់ការព្រមានអំពីការប្រើប្រាស់ចង្អុលទាំងនេះ។
    /// ទ្រនិចចុងតម្រូវឱ្យមានការប្រុងប្រយ័ត្នបន្ថែមព្រោះវាមិនចង្អុលបង្ហាញធាតុដែលត្រឹមត្រូវនៅក្នុងចំណិត។
    ///
    /// មុខងារនេះមានប្រយោជន៍សម្រាប់អន្តរកម្មជាមួយចំណុចប្រទាក់បរទេសដែលប្រើទ្រនិចចង្អុលពីរដើម្បីយោងទៅលើធាតុជាច្រើននៅក្នុងសតិក៏ដូចជាលក្ខណៈទូទៅនៅក្នុង C++ ។
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // សុវត្ថិភាព: សូមមើល as_ptr_range() ខាងលើសម្រាប់មូលហេតុដែល `add` នៅទីនេះមានសុវត្ថិភាព។
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// ផ្លាស់ប្តូរធាតុពីរនៅក្នុងចំណិត។
    ///
    /// # Arguments
    ///
    /// * a, សន្ទស្សន៍នៃធាតុទីមួយ
    /// * b, សន្ទស្សន៍នៃធាតុទីពីរ
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `a` ឬ `b` នៅក្រៅព្រំដែន។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // មិនអាចយកប្រាក់កម្ចីដែលអាចផ្លាស់ប្តូរបានពីរពី vector បានទេដូច្នេះសូមប្រើចង្អុលឆៅវិញ។
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // សុវត្ថិភាព: `pa` និង `pb` ត្រូវបានបង្កើតឡើងពីឯកសារយោងដែលអាចផ្លាស់ប្តូរបានដោយសុវត្ថិភាព
        // ទៅនឹងធាតុនៅក្នុងចំណែកហើយដូច្នេះត្រូវបានធានាថាត្រឹមត្រូវនិងតម្រឹម។
        // ចំណាំថាការចូលប្រើធាតុនៅពីក្រោយ `a` និង `b` ត្រូវបានពិនិត្យហើយនឹង panic នៅពេលដែលមិនមានព្រំដែន។
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// បញ្ច្រាសលំដាប់នៃធាតុនៅក្នុងចំណិតនៅកន្លែង។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // ចំពោះប្រភេទតូចៗបុគ្គលទាំងអស់អានក្នុងផ្លូវធម្មតាអនុវត្តមិនសូវល្អ។
        // យើងអាចធ្វើបានល្អប្រសើរជាងមុន, ដែលបានផ្ដល់ឱ្យប្រសិទ្ធិភាព unaligned load/store ដោយផ្ទុកជាបណ្តុំធំនិងការផ្លាស់ប្តូរបញ្ជីមួយ។
        //

        // តាមឧត្ដមគតិ LLVM នឹងធ្វើការនេះសម្រាប់យើងដូចដែលវាបានដឹងថាល្អប្រសើរជាងការដែលយើងបានធ្វើមិនថា unaligned អានមានប្រសិទ្ធិភាព (ចាប់តាំងពីការផ្លាស់ប្តូររវាងកំណែរបស់ ARM ដែលមានភាពខុសគ្នា, ឧទាហរណ៍) និងអ្វីដែលទំហំបណ្តុំល្អបំផុតនឹងត្រូវបាន។
        // ជាអកុសលដូចជាអិលអិលអិមអេស 4.0 (2017-05) វាគ្រាន់តែលុបរង្វិលជុំដូច្នេះយើងត្រូវធ្វើវាដោយខ្លួនឯង។
        // (សម្មតិកម្ម៖ ការបញ្ច្រាស់គឺមានបញ្ហាពីព្រោះភាគីអាចត្រូវបានតម្រឹមខុសគ្នា-នឹងមាននៅពេលដែលមានប្រវែងសេស-ដូច្នេះមិនមានវិធីនៃការបង្ហាញមុននិងក្រោយដើម្បីប្រើស៊ីមកាតដែលបានតម្រឹមពេញនៅកណ្តាលទេ។)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // ប្រើរូបវិទ្យា llvm.bswap ដើម្បីបញ្ច្រាស u8s នៅក្នុងការប្រើប្រាស់មួយ
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // សុវត្ថិភាព: មានអ្វីមួយចំនួនដើម្បីពិនិត្យមើលនៅទីនេះគឺ:
                //
                // - ចំណាំថា `chunk` គឺទាំង 4 ឬ 8 ដោយសារតែការត្រួតពិនិត្យ cfg ខាងលើ។ដូច្នេះ `chunk - 1` គឺវិជ្ជមាន។
                // - ការដាក់សន្ទស្សន៍ដែលមានសន្ទស្សន៍ `i` គឺល្អដូចការធានាការត្រួតពិនិត្យរង្វិលជុំ
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln` ។
                // - លិបិក្រមជាមួយសន្ទស្សន៍ `ln - i - chunk = ln - (i + chunk)` គឺល្អ៖
                //   - `i + chunk > 0` គឺជាការពិតតូចតាច។
                //   - ធានាការត្រួតពិនិត្យរង្វិលជុំ៖
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln` ដូច្នេះការដកមិនដំណើរការទេ។
                // - ការហៅទូរស័ព្ទ `read_unaligned` និង `write_unaligned` គឺល្អ៖
                //   - `pa` ចង្អុលទៅលិបិក្រម `i` ដែល `i < ln / 2 - (chunk - 1)` (សូមមើលខាងលើ) និង `pb` ចង្អុលទៅសន្ទស្សន៍ `ln - i - chunk` ដូច្នេះទាំងពីរគឺយ៉ាងហោចណាស់ `chunk` បៃច្រើនឆ្ងាយពីចុងបញ្ចប់ `self` ។
                //
                //   - អង្គចងចាំដែលបានចាប់ផ្តើមណាមួយមានសុពលភាព `usize` ។
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // ប្រើការបង្វិលដោយ 16 ដើម្បីបញ្ច្រាស់ u16s ក្នុង u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // សុវត្ថិភាព: មួយ unaligned u32 អាចត្រូវបានអានពី `i` ប្រសិនបើ `i + 1 < ln`
                // (ហើយជាក់ស្តែង `i < ln`) ពីព្រោះធាតុនីមួយៗគឺ ២ បៃហើយយើងកំពុងអាន ៤ ។
                //
                // `i + chunk - 1 < ln / 2` # ខណៈពេលដែលលក្ខខណ្ឌ
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // ដោយសារវាតិចជាងប្រវែងចែកនឹង ២ អ៊ីចឹងវាត្រូវតែស្ថិតនៅក្នុងព្រំដែន។
                //
                // នេះក៏មានន័យថាលក្ខខណ្ឌ `0 < i + chunk <= ln` ត្រូវបានគោរពជានិច្ចធានាថាទ្រនិច `pb` អាចត្រូវបានប្រើដោយសុវត្ថិភាព។
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // សុវត្ថិភាព: `i` គឺទាបជាងពាក់កណ្តាលនៃប្រវែងដូច្នេះ
            // ការចូលដំណើរការ `i` និង `ln - i - 1` មានសុវត្ថិភាព (`i` ចាប់ផ្តើមពី 0 ហើយនឹងមិនទៅឆ្ងាយជាង `ln / 2 - 1`) ។
            // លទ្ធផលចង្អុល `pa` និង `pb` គឺត្រឹមត្រូវនិងតម្រឹមហើយអាចអាននិងសរសេរទៅ។
            //
            //
            unsafe {
                // ដោះដូរមិនមានសុវត្ថិភាពដើម្បីជៀសវាងការត្រួតពិនិត្យព្រំដែនក្នុងការដោះដូរដោយសុវត្ថិភាព។
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// ត្រឡប់រមៀលលើចំណិត។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// ត្រឡប់ឧបករណ៍ដដែលដែលអនុញ្ញាតឱ្យកែប្រែតម្លៃនីមួយៗ។
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// ត្រឡប់អ្នកត្រួតត្រាលើ windows ដែលជាប់គ្នានៃប្រវែង `size` ។
    /// ការត្រួតស៊ីគ្នា windows ។
    /// ប្រសិនបើចំណិតខ្លីជាង `size` វានឹងមិនមានតម្លៃទេ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ប្រសិនបើចំណិតខ្លីជាង `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// ត្រឡប់អ្នកធ្វើវាលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមពីដំបូងនៃចំណិត។
    ///
    /// កំណាត់នេះមាន slices និងមិនត្រួតលើគ្នា។ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណិតទេនោះកំណាត់ចុងក្រោយនឹងមិនមានប្រវែង `chunk_size` ទេ។
    ///
    /// សូមមើល [`chunks_exact`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលត្រឡប់កំណាត់នៃធាតុ `chunk_size` ដែលតែងតែជាធាតុពិតនិង [`rchunks`] សម្រាប់ឧបករណ៍ដដែលប៉ុន្តែចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// ត្រឡប់អ្នកធ្វើវាលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមពីដំបូងនៃចំណិត។
    ///
    /// កំណាត់គឺជាចំណិតដែលអាចផ្លាស់ប្តូរបានហើយកុំជាន់គ្នា។ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណិតទេនោះកំណាត់ចុងក្រោយនឹងមិនមានប្រវែង `chunk_size` ទេ។
    ///
    /// សូមមើល [`chunks_exact_mut`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលត្រឡប់កំណាត់នៃធាតុ `chunk_size` ដែលតែងតែជាធាតុពិតនិង [`rchunks_mut`] សម្រាប់ឧបករណ៍ដដែលប៉ុន្តែចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// ត្រឡប់អ្នកធ្វើវាលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមពីដំបូងនៃចំណិត។
    ///
    /// កំណាត់ជាចំណិតហើយកុំជាន់គ្នា។
    /// ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណែកបន្ទាប់មកធាតុចុងក្រោយរហូតដល់ `chunk_size-1` នឹងត្រូវបានលុបចោលហើយអាចទាញយកពីមុខងារ `remainder` របស់អ្នកនិយាយ។
    ///
    ///
    /// ដោយសារតែកំណាត់នីមួយៗមានធាតុ `chunk_size` អ្នកចងក្រងជាញឹកញាប់អាចធ្វើឱ្យកូដលទ្ធផលប្រសើរជាងក្នុងករណី [`chunks`] ។
    ///
    /// សូមមើល [`chunks`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលក៏ត្រឡប់មកវិញនៅសល់ជាកំណាត់តូចជាងហើយ [`rchunks_exact`] សម្រាប់អ្នកដដែលប៉ុន្តែចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// ត្រឡប់អ្នកធ្វើវាលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមពីដំបូងនៃចំណិត។
    ///
    /// កំណាត់គឺជាចំណិតដែលអាចផ្លាស់ប្តូរបានហើយកុំជាន់គ្នា។
    /// ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណែកបន្ទាប់មកធាតុចុងក្រោយរហូតដល់ `chunk_size-1` នឹងត្រូវបានលុបចោលហើយអាចទាញយកពីមុខងារ `into_remainder` របស់អ្នកតាក់ស៊ី។
    ///
    ///
    /// ដោយសារតែកំណាត់នីមួយៗមានធាតុ `chunk_size` អ្នកចងក្រងជាញឹកញាប់អាចធ្វើឱ្យកូដលទ្ធផលប្រសើរជាងក្នុងករណី [`chunks_mut`] ។
    ///
    /// សូមមើល [`chunks_mut`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលក៏ត្រឡប់មកវិញនៅសល់ជាកំណាត់តូចជាងហើយ [`rchunks_exact_mut`] សម្រាប់អ្នកដដែលប៉ុន្តែចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// បែងចែកជាចំណែក ៗ នៃអារេ-ធាតុអារេដោយសន្មតថាមិនមាននៅសល់។
    ///
    ///
    /// # Safety
    ///
    /// នេះអាចត្រូវបានហៅតែពេលណា
    /// - ចំណិតនេះចែកជាកំណាត់ធាតុ `អិន` (X០០X) ។
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // សុវត្ថិភាព: កំណាត់ធាតុ ១ មិនដែលនៅសល់
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // សុវត្ថិភាព: ប្រវែងចំណិត (6) គឺជាពហុគុណនៃ ៣
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // ទាំងនេះអាចនឹងមិនមានសុពលភាព៖
    /// // អនុញ្ញាតឱ្យកំណាត់: &[[_;៥]]= slice.as_chunks_unchecked()//ប្រវែងកំណាត់មិនមែនជាចំនួន ៥ នៃកំណាត់ខ្លីៗទេ៖&[[_;0]]= slice.as_chunks_unchecked()//កំណាត់ប្រវែងសូន្យមិនត្រូវបានអនុញ្ញាតឡើយ
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // សុវត្ថិភាព: បុរេលក្ខខណ្ឌរបស់យើងគឺពិតជាអ្វីដែលត្រូវការដើម្បីហៅវា
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // សុវត្ថិភាព: យើងបោះធាតុ `new_len * N` មួយចំណែក
        // ចំណែកនៃ `new_len` កំណាត់ធាតុជាច្រើនដែលមានលក្ខណៈជា `N` ។
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// បំបែកចំណិតទៅជាចំណែកនៃអាល់-ធាតុអារេដោយចាប់ផ្តើមពីដំបូងនៃចំណិតហើយចំណែកដែលនៅសល់មានប្រវែងតិចជាង `N` ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `N` គឺ ០។ ការត្រួតពិនិត្យនេះប្រហែលជាត្រូវបានផ្លាស់ប្តូរទៅជាកំហុសពេលវេលាចងក្រងមុនពេលវិធីសាស្ត្រនេះមានស្ថេរភាព។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // សុវត្ថិភាព: យើងភ័យស្លន់ស្លោរួចទៅហើយសម្រាប់សូន្យហើយធានាដោយសំណង់
        // ថាប្រវែងនៃការជាវគឺច្រើននៃអិន។
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// បែងចែកជាចំណែក ៗ នៃអារេ-ធាតុអារេចាប់ផ្តើមពីចុងបញ្ចប់នៃចំណិតហើយចំណែកដែលនៅសល់មានប្រវែងតិចជាង `N` ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `N` គឺ ០។ ការត្រួតពិនិត្យនេះប្រហែលជាត្រូវបានផ្លាស់ប្តូរទៅជាកំហុសពេលវេលាចងក្រងមុនពេលវិធីសាស្ត្រនេះមានស្ថេរភាព។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // សុវត្ថិភាព: យើងភ័យស្លន់ស្លោរួចទៅហើយសម្រាប់សូន្យហើយធានាដោយសំណង់
        // ថាប្រវែងនៃការជាវគឺច្រើននៃអិន។
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// ត្រឡប់អ្នកធ្វើវាលើធាតុ `N` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមពីដំបូងនៃចំណិត។
    ///
    /// កំណាត់ជាឯកសារយោងអារេហើយកុំត្រួតគ្នា។
    /// ប្រសិនបើ `N` មិនបែងចែកប្រវែងនៃចំណែកបន្ទាប់មកធាតុចុងក្រោយរហូតដល់ `N-1` នឹងត្រូវបានលុបចោលហើយអាចទាញយកពីមុខងារ `remainder` របស់អ្នកនិយាយ។
    ///
    ///
    /// វិធីសាស្រ្តនេះគឺស្មើនឹងតម្លៃថេរនៃ [`chunks_exact`] ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `N` គឺ ០។ ការត្រួតពិនិត្យនេះប្រហែលជាត្រូវបានផ្លាស់ប្តូរទៅជាកំហុសពេលវេលាចងក្រងមុនពេលវិធីសាស្ត្រនេះមានស្ថេរភាព។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// បែងចែកជាចំណែក ៗ នៃអារេ-ធាតុអារេដោយសន្មតថាមិនមាននៅសល់។
    ///
    ///
    /// # Safety
    ///
    /// នេះអាចត្រូវបានហៅតែពេលណា
    /// - ចំណិតនេះចែកជាកំណាត់ធាតុ `អិន` (X០០X) ។
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // សុវត្ថិភាព: កំណាត់ធាតុ ១ មិនដែលនៅសល់
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // សុវត្ថិភាព: ប្រវែងចំណិត (6) គឺជាពហុគុណនៃ ៣
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // ទាំងនេះអាចនឹងមិនមានសុពលភាព៖
    /// // អនុញ្ញាតឱ្យកំណាត់: &[[_;៥]]= slice.as_chunks_unchecked_mut()//ប្រវែងកំណាត់មិនមែនជាចំនួន ៥ នៃកំណាត់ខ្លីៗទេ៖&[[_;0]]= slice.as_chunks_unchecked_mut()//កំណាត់ប្រវែងសូន្យមិនត្រូវបានអនុញ្ញាតឡើយ
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // សុវត្ថិភាព: បុរេលក្ខខណ្ឌរបស់យើងគឺពិតជាអ្វីដែលត្រូវការដើម្បីហៅវា
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // សុវត្ថិភាព: យើងបោះធាតុ `new_len * N` មួយចំណែក
        // ចំណែកនៃ `new_len` កំណាត់ធាតុជាច្រើនដែលមានលក្ខណៈជា `N` ។
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// បំបែកចំណិតទៅជាចំណែកនៃអាល់-ធាតុអារេដោយចាប់ផ្តើមពីដំបូងនៃចំណិតហើយចំណែកដែលនៅសល់មានប្រវែងតិចជាង `N` ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `N` គឺ ០។ ការត្រួតពិនិត្យនេះប្រហែលជាត្រូវបានផ្លាស់ប្តូរទៅជាកំហុសពេលវេលាចងក្រងមុនពេលវិធីសាស្ត្រនេះមានស្ថេរភាព។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // សុវត្ថិភាព: យើងភ័យស្លន់ស្លោរួចទៅហើយសម្រាប់សូន្យហើយធានាដោយសំណង់
        // ថាប្រវែងនៃការជាវគឺច្រើននៃអិន។
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// បែងចែកជាចំណែក ៗ នៃអារេ-ធាតុអារេចាប់ផ្តើមពីចុងបញ្ចប់នៃចំណិតហើយចំណែកដែលនៅសល់មានប្រវែងតិចជាង `N` ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `N` គឺ ០។ ការត្រួតពិនិត្យនេះប្រហែលជាត្រូវបានផ្លាស់ប្តូរទៅជាកំហុសពេលវេលាចងក្រងមុនពេលវិធីសាស្ត្រនេះមានស្ថេរភាព។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // សុវត្ថិភាព: យើងភ័យស្លន់ស្លោរួចទៅហើយសម្រាប់សូន្យហើយធានាដោយសំណង់
        // ថាប្រវែងនៃការជាវគឺច្រើននៃអិន។
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// ត្រឡប់អ្នកធ្វើវាលើធាតុ `N` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមពីដំបូងនៃចំណិត។
    ///
    /// កំណាត់នេះគឺសំដៅអារេ mutable និងមិនជាន់គ្នា។
    /// ប្រសិនបើ `N` មិនបែងចែកប្រវែងនៃចំណែកបន្ទាប់មកធាតុចុងក្រោយរហូតដល់ `N-1` នឹងត្រូវបានលុបចោលហើយអាចទាញយកពីមុខងារ `into_remainder` របស់អ្នកនិយាយ។
    ///
    ///
    /// វិធីសាស្រ្តនេះគឺស្មើនឹងតម្លៃថេរនៃ [`chunks_exact_mut`] ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `N` គឺ ០។ ការត្រួតពិនិត្យនេះប្រហែលជាត្រូវបានផ្លាស់ប្តូរទៅជាកំហុសពេលវេលាចងក្រងមុនពេលវិធីសាស្ត្រនេះមានស្ថេរភាព។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// ត្រឡប់ឧបករណ៍ត្រួតលើគ្នានៃធាតុត្រួតស៊ីគ្នា windows នៃ `N` នៃចំណិតមួយដោយចាប់ផ្តើមពីដំបូងនៃចំណិត។
    ///
    ///
    /// នេះគឺជាចំនួនពិតទូទៅនៃ [`windows`] ។
    ///
    /// ប្រសិនបើ `N` ធំជាងទំហំនៃចំណិតវានឹងត្រលប់មកវិញទេមិនមាន windows ទេ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `N` គឺ 0 ។
    /// ការត្រួតពិនិត្យនេះប្រហែលជាត្រូវបានផ្លាស់ប្តូរទៅជាកំហុសពេលវេលាចងក្រងមុនពេលវិធីសាស្ត្រនេះមានស្ថេរភាព។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// ត្រឡប់ឧបករណ៍រំកិលលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    /// កំណាត់នេះមាន slices និងមិនត្រួតលើគ្នា។ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណិតទេនោះកំណាត់ចុងក្រោយនឹងមិនមានប្រវែង `chunk_size` ទេ។
    ///
    /// សូមមើល [`rchunks_exact`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលត្រឡប់កំណាត់នៃធាតុ `chunk_size` ដែលតែងតែជាធាតុពិតនិង [`chunks`] សម្រាប់ឧបករណ៍ដដែលប៉ុន្តែចាប់ផ្តើមពីដំបូង។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// ត្រឡប់ឧបករណ៍រំកិលលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    /// កំណាត់គឺជាចំណិតដែលអាចផ្លាស់ប្តូរបានហើយកុំជាន់គ្នា។ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណិតទេនោះកំណាត់ចុងក្រោយនឹងមិនមានប្រវែង `chunk_size` ទេ។
    ///
    /// សូមមើល [`rchunks_exact_mut`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលត្រឡប់កំណាត់នៃធាតុ `chunk_size` ដែលតែងតែជាធាតុពិតនិង [`chunks_mut`] សម្រាប់ឧបករណ៍ដដែលប៉ុន្តែចាប់ផ្តើមពីដំបូង។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// ត្រឡប់ឧបករណ៍រំកិលលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    /// កំណាត់ជាចំណិតហើយកុំជាន់គ្នា។
    /// ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណែកបន្ទាប់មកធាតុចុងក្រោយរហូតដល់ `chunk_size-1` នឹងត្រូវបានលុបចោលហើយអាចទាញយកពីមុខងារ `remainder` របស់អ្នកនិយាយ។
    ///
    /// ដោយសារតែកំណាត់នីមួយៗមានធាតុ `chunk_size` អ្នកចងក្រងជាញឹកញាប់អាចធ្វើឱ្យកូដលទ្ធផលប្រសើរជាងក្នុងករណី [`chunks`] ។
    ///
    /// សូមមើល [`rchunks`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលក៏ត្រលប់មកវិញនូវចំនួនដែលនៅសល់ជាកំណាត់តូចជាងហើយ [`chunks_exact`] សម្រាប់ឧបករណ៍ដដែលប៉ុន្តែចាប់ផ្តើមនៅដើម។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// ត្រឡប់ឧបករណ៍រំកិលលើធាតុ `chunk_size` នៃចំណិត ៗ ក្នុងពេលតែមួយចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិត។
    ///
    /// កំណាត់គឺជាចំណិតដែលអាចផ្លាស់ប្តូរបានហើយកុំជាន់គ្នា។
    /// ប្រសិនបើ `chunk_size` មិនបែងចែកប្រវែងនៃចំណែកបន្ទាប់មកធាតុចុងក្រោយរហូតដល់ `chunk_size-1` នឹងត្រូវបានលុបចោលហើយអាចទាញយកពីមុខងារ `into_remainder` របស់អ្នកតាក់ស៊ី។
    ///
    /// ដោយសារតែកំណាត់នីមួយៗមានធាតុ `chunk_size` អ្នកចងក្រងជាញឹកញាប់អាចធ្វើឱ្យកូដលទ្ធផលប្រសើរជាងក្នុងករណី [`chunks_mut`] ។
    ///
    /// សូមមើល [`rchunks_mut`] សម្រាប់បំរែបំរួលនៃឧបករណ៍រំកិលនេះដែលក៏ត្រលប់មកវិញនូវចំនួនដែលនៅសល់ជាកំណាត់តូចជាងហើយ [`chunks_exact_mut`] សម្រាប់ឧបករណ៍ដដែលប៉ុន្តែចាប់ផ្តើមនៅដើម។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `chunk_size` គឺ 0 ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// ត្រឡប់អ្នកត្រួតលើចំណិតដែលបង្កើតការរត់មិនត្រួតគ្នានៃធាតុដោយប្រើការព្យាករណ៍ដើម្បីបំបែកពួកវា។
    ///
    /// ព្យាករណ៍ត្រូវបានគេហៅលើធាតុពីរដែលដើរតាមខ្លួនវាមានន័យថាអ្នកព្យាករណ៍ត្រូវបានគេហៅថា `slice[0]` និង `slice[1]` បន្ទាប់មកនៅលើ `slice[1]` និង `slice[2]` ជាដើម។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// វិធីសាស្រ្តនេះអាចត្រូវបានប្រើដើម្បីទាញយកអនុផ្នែកដែលបានតម្រៀប៖
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// ត្រឡប់ការរំកិលលើចំណិតដែលបង្កើតការផ្លាស់ប្តូរនៃការផ្លាស់ប្តូរនៃការត្រួតគ្នានៃធាតុដោយប្រើការព្យាករណ៍ដើម្បីបំបែកពួកវា។
    ///
    /// ព្យាករណ៍ត្រូវបានគេហៅលើធាតុពីរដែលដើរតាមខ្លួនវាមានន័យថាអ្នកព្យាករណ៍ត្រូវបានគេហៅថា `slice[0]` និង `slice[1]` បន្ទាប់មកនៅលើ `slice[1]` និង `slice[2]` ជាដើម។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// វិធីសាស្រ្តនេះអាចត្រូវបានប្រើដើម្បីទាញយកអនុផ្នែកដែលបានតម្រៀប៖
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// ចែកមួយចំណែក ៗ ជាពីរនៅសន្ទស្សន៍។
    ///
    /// ទីមួយនឹងមានសូចនាករទាំងអស់ពី `[0, mid)` (មិនរាប់បញ្ចូលលិបិក្រម `mid` ខ្លួនវា) និងទីពីរនឹងមានសូចនាករទាំងអស់ពី `[mid, len)` (មិនរាប់បញ្ចូលលិបិក្រម `len` ខ្លួនវាទេ) ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `mid > len` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // សុវត្ថិភាព: `[ptr; mid]` និង `[mid; len]` គឺនៅខាងក្នុង `self` ដែល
        // បំពេញតាមតម្រូវការរបស់ `from_raw_parts_mut` ។
        unsafe { self.split_at_unchecked(mid) }
    }

    /// ចែកចំណែកមួយដែលអាចផ្លាស់ប្តូរបានជាពីរនៅសន្ទស្សន៍។
    ///
    /// ទីមួយនឹងមានសូចនាករទាំងអស់ពី `[0, mid)` (មិនរាប់បញ្ចូលលិបិក្រម `mid` ខ្លួនវា) និងទីពីរនឹងមានសូចនាករទាំងអស់ពី `[mid, len)` (មិនរាប់បញ្ចូលលិបិក្រម `len` ខ្លួនវាទេ) ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `mid > len` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // សុវត្ថិភាព: `[ptr; mid]` និង `[mid; len]` គឺនៅខាងក្នុង `self` ដែល
        // បំពេញតាមតម្រូវការរបស់ `from_raw_parts_mut` ។
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// ចែកមួយចំណែក ៗ ជាពីរនៅលិបិក្រមមួយដោយមិនចាំបាច់ត្រួតពិនិត្យព្រំដែន។
    ///
    /// ទីមួយនឹងមានសូចនាករទាំងអស់ពី `[0, mid)` (មិនរាប់បញ្ចូលលិបិក្រម `mid` ខ្លួនវា) និងទីពីរនឹងមានសូចនាករទាំងអស់ពី `[mid, len)` (មិនរាប់បញ្ចូលលិបិក្រម `len` ខ្លួនវាទេ) ។
    ///
    ///
    /// សម្រាប់ជម្រើសសុវត្ថិភាពសូមមើល [`split_at`] ។
    ///
    /// # Safety
    ///
    /// ការហៅវិធីសាស្ត្រនេះជាមួយសន្ទស្សន៍ក្រៅព្រំដែនគឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]* ទោះបីជាឯកសារយោងលទ្ធផលមិនត្រូវបានប្រើក៏ដោយ។អ្នកទូរស័ព្ទត្រូវធានាថា `0 <= mid <= self.len()` ។
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវពិនិត្យមើលថាតើ `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// ចែកចំណែកមួយដែលអាចផ្លាស់ប្តូរបានជាពីរនៅលិបិក្រមមួយដោយមិនចាំបាច់ពិនិត្យព្រំដែន។
    ///
    /// ទីមួយនឹងមានសូចនាករទាំងអស់ពី `[0, mid)` (មិនរាប់បញ្ចូលលិបិក្រម `mid` ខ្លួនវា) និងទីពីរនឹងមានសូចនាករទាំងអស់ពី `[mid, len)` (មិនរាប់បញ្ចូលលិបិក្រម `len` ខ្លួនវាទេ) ។
    ///
    ///
    /// សម្រាប់ជម្រើសសុវត្ថិភាពសូមមើល [`split_at_mut`] ។
    ///
    /// # Safety
    ///
    /// ការហៅវិធីសាស្ត្រនេះជាមួយសន្ទស្សន៍ក្រៅព្រំដែនគឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]* ទោះបីជាឯកសារយោងលទ្ធផលមិនត្រូវបានប្រើក៏ដោយ។អ្នកទូរស័ព្ទត្រូវធានាថា `0 <= mid <= self.len()` ។
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវពិនិត្យមើលថាតើ `0 <= mid <= self.len()` ។
        //
        // `[ptr; mid]` និង `[mid; len]` មិនត្រូវបានត្រួតស៊ីគ្នាទេដូច្នេះការត្រលប់មកវិញនូវឯកសារយោងដែលអាចផ្លាស់ប្តូរបានគឺល្អ។
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// ត្រឡប់អ្នកត្រួតត្រាលើអនុផ្នែកដែលបំបែកដោយធាតុដែលត្រូវគ្នានឹង `pred` ។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ប្រសិនបើធាតុទីមួយត្រូវបានផ្គូរផ្គងបំណែកទទេនឹងក្លាយជាធាតុដំបូងដែលត្រូវបានត្រឡប់មកវិញដោយអ្នកតាក់តែង។
    /// ដូចគ្នានេះដែរប្រសិនបើមានធាតុចុងក្រោយនៅក្នុងចំណែកនេះត្រូវបានផ្គូផ្គង, ចំណែកទទេមួយនឹងក្លាយជាធាតុចុងក្រោយវិលត្រឡប់មកវិញដោយការនិយាយឡើងវិញ:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ប្រសិនបើធាតុដែលផ្គូរផ្គងពីរនៅជាប់គ្នាដោយផ្ទាល់បំណែកទទេមួយនឹងមាននៅចន្លោះពួកវា៖
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// ត្រឡប់អ្នកត្រួតត្រាលើអនុផ្នែកដែលអាចផ្លាស់ប្តូរបានបំបែកដោយធាតុដែលត្រូវគ្នានឹង `pred` ។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// ត្រឡប់អ្នកត្រួតត្រាលើអនុផ្នែកដែលបំបែកដោយធាតុដែលត្រូវគ្នានឹង `pred` ។
    /// ធាតុដែលត្រូវគ្នាត្រូវបានផ្ទុកនៅចុងបញ្ចប់នៃការរងមុនជាអ្នកបញ្ចប់។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ប្រសិនបើធាតុចុងក្រោយនៃចំណិតត្រូវបានផ្គូរផ្គងធាតុនោះនឹងត្រូវបានចាត់ទុកថាជាអ្នកបញ្ចប់នៃចំណិតខាងមុខ។
    ///
    /// ចំណិតនោះនឹងជាធាតុចុងក្រោយដែលបានវិលត្រឡប់ដោយអ្នកតាក់ស៊ី។
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// ត្រឡប់អ្នកត្រួតត្រាលើអនុផ្នែកដែលអាចផ្លាស់ប្តូរបានបំបែកដោយធាតុដែលត្រូវគ្នានឹង `pred` ។
    /// ធាតុដែលត្រូវគ្នាត្រូវបានផ្ទុកនៅក្នុងឧបករណ៍ភ្ជាប់មុនដែលជាឧបករណ៍កំណត់។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// ត្រឡប់ឧបករណ៍ត្រួតលើការរងដែលបំបែកដោយធាតុដែលផ្គូផ្គង `pred` ចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិតហើយធ្វើការថយក្រោយ។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ដូចគ្នានឹង `split()` ដែរប្រសិនបើធាតុទីមួយរឺចុងក្រោយត្រូវបានផ្គូរផ្គងបំណែកទទេនឹងក្លាយជាធាតុដំបូង (រឺចុងក្រោយ) ដែលបានវិលត្រឡប់ដោយអ្នកតាក់តែង។
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// ត្រឡប់ឧបករណ៍រំកិលលើអនុផ្នែកដែលអាចផ្លាស់ប្តូរបានបំបែកដោយធាតុដែលត្រូវគ្នានឹង `pred` ចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិតហើយធ្វើការថយក្រោយ។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// ត្រឡប់ការធ្វើម្តងទៀតលើបណ្តាញរងដែលបំបែកដោយធាតុដែលត្រូវគ្នានឹង `pred` ដែលបានកំណត់ចំពោះការត្រលប់មកវិញនូវវត្ថុ `n` ភាគច្រើន។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// ធាតុចុងក្រោយត្រឡប់មកវិញប្រសិនបើមាននឹងមានចំណែកដែលនៅសល់។
    ///
    /// # Examples
    ///
    /// បោះពុម្ពចំណិត ៗ ចែកគ្នាម្តងជាលេខដែលអាចចែកជា ៣ បាន (ឧទាហរណ៍ `[10, 40]`, `[20, 60, 50]`)៖
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// ត្រឡប់ការធ្វើម្តងទៀតលើបណ្តាញរងដែលបំបែកដោយធាតុដែលត្រូវគ្នានឹង `pred` ដែលបានកំណត់ចំពោះការត្រលប់មកវិញនូវវត្ថុ `n` ភាគច្រើន។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// ធាតុចុងក្រោយត្រឡប់មកវិញប្រសិនបើមាននឹងមានចំណែកដែលនៅសល់។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// ត្រឡប់ការធ្វើម្តងទៀតលើបណ្តាញរងដែលបំបែកដោយធាតុដែលផ្គូផ្គង `pred` បានកំណត់ចំពោះការត្រឡប់មកវិញនៅធាតុ `n` ភាគច្រើន។
    /// នេះចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិតហើយធ្វើការថយក្រោយ។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// ធាតុចុងក្រោយត្រឡប់មកវិញប្រសិនបើមាននឹងមានចំណែកដែលនៅសល់។
    ///
    /// # Examples
    ///
    /// បោះពុម្ពចំណិត ៗ ចែកគ្នាម្តងដោយចាប់ផ្តើមពីចុងបញ្ចប់ដោយលេខដែលអាចបែងចែកបានដោយលេខ ៣ (មានន័យថា `[50]`, `[10, 40, 30, 20]`)៖
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// ត្រឡប់ការធ្វើម្តងទៀតលើបណ្តាញរងដែលបំបែកដោយធាតុដែលផ្គូផ្គង `pred` បានកំណត់ចំពោះការត្រឡប់មកវិញនៅធាតុ `n` ភាគច្រើន។
    /// នេះចាប់ផ្តើមនៅចុងបញ្ចប់នៃចំណិតហើយធ្វើការថយក្រោយ។
    /// ធាតុដែលត្រូវគ្នាមិនមាននៅក្នុងសំណុំរងទេ។
    ///
    /// ធាតុចុងក្រោយត្រឡប់មកវិញប្រសិនបើមាននឹងមានចំណែកដែលនៅសល់។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// ត្រឡប់ `true` ប្រសិនបើចំណិតមានធាតុជាមួយតម្លៃដែលបានផ្តល់។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// ប្រសិនបើអ្នកមិនមាន `&T` ទេប៉ុន្តែមានតែ `&U` ប៉ុណ្ណោះដែល `T: Borrow<U>` (ឧ
    /// `ខ្សែអក្សរ: ខ្ចី<str>`) អ្នកអាចប្រើ `iter().any`៖
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // ចំណែកនៃ `String`
    /// assert!(v.iter().any(|e| e == "hello")); // ស្វែងរកជាមួយ `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `needle` គឺបុព្វបទនៃ slice មួយ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// ត្រឡប់ `true` ជានិច្ចប្រសិនបើ `needle` ជាចំណែកទទេ៖
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `needle` គឺជាបច្ច័យនៃចំណិត។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// ត្រឡប់ `true` ជានិច្ចប្រសិនបើ `needle` ជាចំណែកទទេ៖
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// ត្រឡប់សំណុំរងមួយដែលបុព្វបទបានយកចេញ។
    ///
    /// ប្រសិនបើការចាប់ផ្តើមជាមួយនឹងចំណែក `prefix` ត្រឡប់ subslice បន្ទាប់ពីបុព្វបទដែលបានរុំក្នុង `Some` ។
    /// ប្រសិនបើ `prefix` ទទេសូមត្រឡប់ចំណែកដើមវិញ។
    ///
    /// ប្រសិនបើចំណិតមិនចាប់ផ្តើមជាមួយ `prefix` ត្រឡប់ `None` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // មុខងារនេះនឹងត្រូវការសរសេរឡើងវិញប្រសិនបើពេលណា SlicePattern កាន់តែទំនើប។
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// ត្រឡប់អនុផ្នែកដែលមានបច្ច័យត្រូវបានដកចេញ។
    ///
    /// ប្រសិនបើចំណិតបញ្ចប់ដោយ `suffix` ត្រឡប់ការរងមុនពេលបច្ច័យដែលរុំដោយ `Some` ។
    /// ប្រសិនបើ `suffix` ទទេសូមត្រឡប់ចំណែកដើមវិញ។
    ///
    /// ប្រសិនបើចំណិតមិនបញ្ចប់ដោយ `suffix` ត្រឡប់ `None` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // មុខងារនេះនឹងត្រូវការសរសេរឡើងវិញប្រសិនបើពេលណា SlicePattern កាន់តែទំនើប។
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// ប្រព័ន្ធគោលពីរស្វែងរកចំណែកដែលបានបែងចែកនេះសម្រាប់ធាតុដែលបានផ្តល់។
    ///
    /// ប្រសិនបើតម្លៃត្រូវបានរកឃើញបន្ទាប់មក [`Result::Ok`] ត្រូវបានត្រឡប់មកវិញដែលមានសន្ទស្សន៍នៃធាតុដែលត្រូវគ្នា។
    /// ប្រសិនបើមានការប្រកួតច្រើននោះការប្រកួតណាមួយអាចត្រូវបានប្រគល់ជូនវិញ។
    /// ប្រសិនបើតម្លៃមិនត្រូវបានរកឃើញនោះ [`Result::Err`] ត្រូវបានត្រឡប់មកវិញដែលមានលិបិក្រមដែលធាតុដែលត្រូវគ្នាអាចត្រូវបានបញ្ចូលខណៈពេលរក្សាលំដាប់ដែលបានតម្រៀប។
    ///
    ///
    /// សូមមើលផងដែរ [`binary_search_by`], [`binary_search_by_key`], និង [`partition_point`] ។
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// រកមើលស៊េរីនៃធាតុបួន។
    /// ទីមួយត្រូវបានរកឃើញដោយមានជំហរដែលបានកំណត់តែមួយ។ទីពីរនិងទីបីរកមិនឃើញ។លេខបួនអាចផ្គូផ្គងទីតាំងណាមួយនៅក្នុង `[1, 4]` ។
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// ប្រសិនបើអ្នកចង់បញ្ចូលធាតុមួយទៅ vector ដែលបានតម្រៀបខណៈពេលរក្សាលំដាប់តម្រៀប៖
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ប្រព័ន្ធគោលពីរស្វែងរកចំណែកដែលបានបែងចែកនេះជាមួយនឹងមុខងារប្រៀបធៀប។
    ///
    /// មុខងារប្រៀបធៀបគួរតែអនុវត្តគោលបំណងស្របជាមួយនឹងការតម្រៀបលំដាប់របស់ចម្រៀកមូលដ្ឋាន, ការវិលត្រឡប់កូដលំដាប់មួយដែលបង្ហាញថាតើអាគុយម៉ង់របស់វាជា `Less`, `Equal` ឬ `Greater` គោលដៅដែលអ្នកចង់បានមួយ។
    ///
    ///
    /// ប្រសិនបើតម្លៃត្រូវបានរកឃើញបន្ទាប់មក [`Result::Ok`] ត្រូវបានត្រឡប់មកវិញដែលមានសន្ទស្សន៍នៃធាតុដែលត្រូវគ្នា។ប្រសិនបើមានការប្រកួតច្រើននោះការប្រកួតណាមួយអាចត្រូវបានប្រគល់ជូនវិញ។
    /// ប្រសិនបើតម្លៃមិនត្រូវបានរកឃើញនោះ [`Result::Err`] ត្រូវបានត្រឡប់មកវិញដែលមានលិបិក្រមដែលធាតុដែលត្រូវគ្នាអាចត្រូវបានបញ្ចូលខណៈពេលរក្សាលំដាប់ដែលបានតម្រៀប។
    ///
    /// សូមមើលផងដែរ [`binary_search`], [`binary_search_by_key`], និង [`partition_point`] ។
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// រកមើលស៊េរីនៃធាតុបួន។ទីមួយត្រូវបានរកឃើញដោយមានជំហរដែលបានកំណត់តែមួយ។ទីពីរនិងទីបីរកមិនឃើញ។លេខបួនអាចផ្គូផ្គងទីតាំងណាមួយនៅក្នុង `[1, 4]` ។
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // សុវត្ថិភាព: ការហៅត្រូវបានធ្វើឡើងដោយសុវត្ថិភាពដោយការលុកលុយខាងក្រោម៖
            // - `mid >= 0`
            // - `mid < size`: `mid` ត្រូវបានកំណត់ដោយ `[left; right)` ភ្ជាប់។
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // មូលហេតុដែលយើងប្រើលំហូរត្រួតពិនិត្យ if/else ជាជាងការផ្គូរផ្គងគឺដោយសារតែប្រតិបត្ដិការប្រៀបធៀបការប្រៀបធៀបដែលមានលក្ខណៈរសើប។
            //
            // នេះគឺជា x86 asm សំរាប់ u8៖ https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// ប្រព័ន្ធគោលពីរស្វែងរកចំណែកដែលបានបែងចែកនេះជាមួយនឹងមុខងារទាញយកដ៏សំខាន់។
    ///
    /// សន្មតថាចំណែកតូចត្រូវបានតម្រៀបតាមគន្លឹះឧទាហរណ៍ជាមួយ [`sort_by_key`] ដោយប្រើមុខងារទាញយកកូនសោដដែល។
    ///
    /// ប្រសិនបើតម្លៃត្រូវបានរកឃើញបន្ទាប់មក [`Result::Ok`] ត្រូវបានត្រឡប់មកវិញដែលមានសន្ទស្សន៍នៃធាតុដែលត្រូវគ្នា។
    /// ប្រសិនបើមានការប្រកួតច្រើននោះការប្រកួតណាមួយអាចត្រូវបានប្រគល់ជូនវិញ។
    /// ប្រសិនបើតម្លៃមិនត្រូវបានរកឃើញនោះ [`Result::Err`] ត្រូវបានត្រឡប់មកវិញដែលមានលិបិក្រមដែលធាតុដែលត្រូវគ្នាអាចត្រូវបានបញ្ចូលខណៈពេលរក្សាលំដាប់ដែលបានតម្រៀប។
    ///
    ///
    /// សូមមើលផងដែរ [`binary_search`], [`binary_search_by`], និង [`partition_point`] ។
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// រកមើលស៊េរីនៃធាតុបួននៅក្នុងចំណែកនៃគូដែលបានតម្រៀបដោយធាតុទីពីររបស់ពួកគេ។
    /// ទីមួយត្រូវបានរកឃើញដោយមានជំហរដែលបានកំណត់តែមួយ។ទីពីរនិងទីបីរកមិនឃើញ។លេខបួនអាចផ្គូផ្គងទីតាំងណាមួយនៅក្នុង `[1, 4]` ។
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links ត្រូវបានអនុញ្ញាតព្រោះ `slice::sort_by_key` ស្ថិតនៅក្នុង crate `alloc` ហើយដូចនេះមិនទាន់មាននៅឡើយទេនៅពេលសាងសង់ `core` ។
    //
    // តំណភ្ជាប់ទៅខ្សែទឹកខាងក្រោម crate: #74481 ។ចាប់តាំងពីការបឋមត្រូវបានចងក្រងជាឯកសារនៅក្នុង libstd (#73423) នេះមិនដែលនាំឱ្យមានតំណភ្ជាប់ដែលខូចនៅក្នុងការអនុវត្តទេ។
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// តម្រៀបចំណិត ៗ ប៉ុន្តែប្រហែលជាមិនរក្សាលំដាប់នៃធាតុស្មើគ្នាទេ។
    ///
    /// ប្រភេទនេះគឺមិនស្ថិតស្ថេរ (ពោលគឺអាចតម្រៀបធាតុស្មើ) នៅនឹងកន្លែង (ពោលគឺមិនបម្រុងទុក), និង *អើយ*(*n*\*log(* n*)) អាក្រក់បំផុតករណី។
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// ក្បួនដោះស្រាយបច្ចុប្បន្នគឺផ្អែកលើ [pattern-defeating quicksort][pdqsort] ដោយអ័រសុនផឺរដែលរួមបញ្ចូលគ្នានូវករណីមធ្យមដែលមានល្បឿនលឿនដោយចៃដន្យជាមួយនឹងករណីដ៏អាក្រក់បំផុតនៃហេបស្តុនខណៈពេលដែលសម្រេចបានពេលវេលាលីនេអ៊ែរនៅលើចំណិតជាមួយនឹងលំនាំជាក់លាក់។
    /// វាប្រើការចៃដន្យមួយចំនួនដើម្បីចៀសវាងករណីអន់ថយប៉ុន្តែជាមួយនឹងហ្សែនហ្សេហ្សេហ្ស៊ីថេរដើម្បីផ្តល់ឥរិយាបថកំណត់ជានិច្ច។
    ///
    /// ជាធម្មតាវាលឿនជាងការតម្រៀបមានស្ថេរភាពលើកលែងតែករណីពិសេសមួយចំនួនឧទាហរណ៍នៅពេលដែលចំណិតមានលំដាប់តម្រៀបបន្តគ្នាជាច្រើន។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// តម្រៀបចំណែកជាមួយមុខងារប្រៀបធៀបមួយប៉ុន្តែមិនអាចរក្សាបានលំដាប់នៃធាតុស្មើ។
    ///
    /// ប្រភេទនេះគឺមិនស្ថិតស្ថេរ (ពោលគឺអាចតម្រៀបធាតុស្មើ) នៅនឹងកន្លែង (ពោលគឺមិនបម្រុងទុក), និង *អើយ*(*n*\*log(* n*)) អាក្រក់បំផុតករណី។
    ///
    /// មុខងារប្រៀបធៀបត្រូវតែកំណត់លំដាប់សរុបសម្រាប់ធាតុនៅក្នុងចំណែក។ប្រសិនបើការបញ្ជាទិញមិនមានសរុបទេលំដាប់នៃធាតុមិនត្រូវបានបញ្ជាក់ទេ។ការបញ្ជាទិញគឺជាការបញ្ជាទិញសរុបប្រសិនបើវា (សម្រាប់ `a`, `b` និង `c` ទាំងអស់)៖
    ///
    /// * សរុបនិង antisymmetric: ពិតជាមួយនៃ `a < b`, `a == b` ឬ `a > b` ពិតហើយ
    /// * ការផ្លាស់ប្តូរ, `a < b` និង `b < c` បង្កប់ន័យ `a < c` ។ដូចគ្នាត្រូវតែកាន់ទាំង `==` និង `>` ។
    ///
    /// ឧទាហរណ៍ខណៈពេលដែល [`f64`] មិនអនុវត្ត [`Ord`] ព្រោះ `NaN != NaN` យើងអាចប្រើ `partial_cmp` ជាមុខងារតម្រៀបរបស់យើងនៅពេលដែលយើងដឹងថាចំណិតមិនមាន `NaN` ។
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// ក្បួនដោះស្រាយបច្ចុប្បន្នគឺផ្អែកលើ [pattern-defeating quicksort][pdqsort] ដោយអ័រសុនផឺរដែលរួមបញ្ចូលគ្នានូវករណីមធ្យមដែលមានល្បឿនលឿនដោយចៃដន្យជាមួយនឹងករណីដ៏អាក្រក់បំផុតនៃហេបស្តុនខណៈពេលដែលសម្រេចបានពេលវេលាលីនេអ៊ែរនៅលើចំណិតជាមួយនឹងលំនាំជាក់លាក់។
    /// វាប្រើការចៃដន្យមួយចំនួនដើម្បីចៀសវាងករណីអន់ថយប៉ុន្តែជាមួយនឹងហ្សែនហ្សេហ្សេហ្ស៊ីថេរដើម្បីផ្តល់ឥរិយាបថកំណត់ជានិច្ច។
    ///
    /// ជាធម្មតាវាលឿនជាងការតម្រៀបមានស្ថេរភាពលើកលែងតែករណីពិសេសមួយចំនួនឧទាហរណ៍នៅពេលដែលចំណិតមានលំដាប់តម្រៀបបន្តគ្នាជាច្រើន។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // តម្រៀបបញ្ច្រាស
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// តម្រៀបចំណិតដែលមានមុខងារទាញយកកូនសោរប៉ុន្តែអាចមិនរក្សាលំដាប់នៃធាតុស្មើគ្នា។
    ///
    /// ការតម្រៀបនេះគឺមិនស្ថិតស្ថេរ (មានន័យថាអាចតំរឹមធាតុស្មើគ្នា) នៅកន្លែង (មានន័យថាមិនបែងចែក) និង *O*(m\* * n *\* log(*n*))-ករណីអាក្រក់បំផុតដែលមុខងារសំខាន់គឺ *O*(*ម*) ។
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// ក្បួនដោះស្រាយបច្ចុប្បន្នគឺផ្អែកលើ [pattern-defeating quicksort][pdqsort] ដោយអ័រសុនផឺរដែលរួមបញ្ចូលគ្នានូវករណីមធ្យមដែលមានល្បឿនលឿនដោយចៃដន្យជាមួយនឹងករណីដ៏អាក្រក់បំផុតនៃហេបស្តុនខណៈពេលដែលសម្រេចបានពេលវេលាលីនេអ៊ែរនៅលើចំណិតជាមួយនឹងលំនាំជាក់លាក់។
    /// វាប្រើការចៃដន្យមួយចំនួនដើម្បីចៀសវាងករណីអន់ថយប៉ុន្តែជាមួយនឹងហ្សែនហ្សេហ្សេហ្ស៊ីថេរដើម្បីផ្តល់ឥរិយាបថកំណត់ជានិច្ច។
    ///
    /// ដោយសារតែយុទ្ធសាស្រ្តរបស់ត្រាស់ហៅសំខាន់របស់ខ្លួន [`sort_unstable_by_key`](#method.sort_unstable_by_key) គឺទំនងជាត្រូវបានយឺតជាង [`sort_by_cached_key`](#method.sort_by_cached_key) នៅក្នុងករណីដែលមុខងារសំខាន់គឺមានតម្លៃថ្លៃ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// តម្រៀបឡើងវិញនូវចំណែកដែលធាតុនៅ `index` ស្ថិតនៅទីតាំងតម្រៀបចុងក្រោយរបស់វា។
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// រៀបចំចំណិតឡើងវិញជាមួយមុខងារប្រៀបធៀបដូចជាធាតុនៅ `index` គឺស្ថិតនៅទីតាំងតម្រៀបចុងក្រោយរបស់វា។
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// រៀបចំចំណិតឡើងវិញជាមួយមុខងារទាញយកសំខាន់ៗដូចជាធាតុនៅ `index` គឺស្ថិតនៅទីតាំងតម្រៀបចុងក្រោយរបស់វា។
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// តម្រៀបឡើងវិញនូវចំណែកដែលធាតុនៅ `index` ស្ថិតនៅទីតាំងតម្រៀបចុងក្រោយរបស់វា។
    ///
    /// ការតំរែតំរង់នេះមានទ្រព្យសម្បត្តិបន្ថែមដែលតម្លៃណាមួយនៅទីតាំង `i < index` នឹងតូចជាងឬស្មើនឹងតម្លៃណាមួយនៅទីតាំង `j > index` ។
    /// លើសពីនេះទៀតការតំរែតំរង់នេះគឺមិនស្ថិតស្ថេរ (មានន័យថា
    /// ចំនួននៃធាតុស្មើគ្នាណាមួយអាចបញ្ចប់នៅទីតាំង `index`) នៅកន្លែងដែលមាន (ឧ
    /// មិនបម្រុងទុក) និង *O*(*n*) ករណីដែលអាក្រក់បំផុត។
    /// មុខងារនេះគឺជា/គេស្គាល់ថាជា "kth element" នៅក្នុងបណ្ណាល័យផ្សេងទៀត។
    /// វាត្រឡប់បីដងនៃតម្លៃដូចខាងក្រោម: ធាតុទាំងអស់តិចជាងមួយនៅសន្ទស្សន៍ដែលបានផ្តល់តម្លៃនៅសន្ទស្សន៍ដែលបានផ្តល់និងធាតុទាំងអស់ធំជាងមួយនៅសន្ទស្សន៍ដែលបានផ្តល់ឱ្យ។
    ///
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// នេះក្បួនដោះស្រាយនាពេលបច្ចុប្បន្នគឺមានមូលដ្ឋានលើផ្នែក quickselect នៃក្បួនដោះស្រាយ quicksort ដូចគ្នាដែលបានប្រើសម្រាប់ [`sort_unstable`] ។
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics នៅពេល `index >= len()` មានន័យថាវាតែងតែ panics នៅលើចំណិតទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // រកមេដ្យាន
    /// v.select_nth_unstable(2);
    ///
    /// // យើងត្រូវបានធានាថាចំណែកនឹងក្លាយជាផ្នែកមួយនៃចំណុចខាងក្រោមដោយផ្អែកលើវិធីដែលយើងតម្រៀបអំពីសន្ទស្សន៍ដែលបានបញ្ជាក់។
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// រៀបចំចំណិតឡើងវិញជាមួយមុខងារប្រៀបធៀបដូចជាធាតុនៅ `index` គឺស្ថិតនៅទីតាំងតម្រៀបចុងក្រោយរបស់វា។
    ///
    /// ការតំរែតំរង់នេះមានលក្ខណៈសម្បត្តិបន្ថែមដែលតម្លៃណាមួយនៅទីតាំង `i < index` នឹងតូចជាងឬស្មើនឹងតម្លៃណាមួយនៅទីតាំង `j > index` ដោយប្រើមុខងារប្រៀបធៀប។
    /// លើសពីនេះទៀតការតំរែតំរង់នេះគឺមិនស្ថិតស្ថេរ (មានន័យថាចំនួននៃធាតុស្មើគ្នាណាមួយអាចបញ្ចប់នៅទីតាំង `index`) កន្លែង (មានន័យថាមិនបែងចែក) និង *O*(*n*) ករណីដែលអាក្រក់បំផុត។
    /// មុខងារនេះត្រូវបានគេស្គាល់ថា "kth element" នៅក្នុងបណ្ណាល័យដទៃទៀត។
    /// វាត្រឡប់បីដងនៃតម្លៃដូចខាងក្រោម: ធាតុទាំងអស់តិចជាងមួយនៅសន្ទស្សន៍ដែលបានផ្តល់តម្លៃនៅសន្ទស្សន៍ដែលបានផ្តល់និងធាតុទាំងអស់ធំជាងមួយនៅសន្ទស្សន៍ដែលបានផ្តល់ដោយប្រើមុខងារប្រៀបធៀបដែលបានផ្តល់។
    ///
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// នេះក្បួនដោះស្រាយនាពេលបច្ចុប្បន្នគឺមានមូលដ្ឋានលើផ្នែក quickselect នៃក្បួនដោះស្រាយ quicksort ដូចគ្នាដែលបានប្រើសម្រាប់ [`sort_unstable`] ។
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics នៅពេល `index >= len()` មានន័យថាវាតែងតែ panics នៅលើចំណិតទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // រកមេដ្យានហាក់ដូចជាបំណែកត្រូវបានតម្រៀបតាមលំដាប់ចុះ។
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // យើងត្រូវបានធានាថាចំណែកនឹងក្លាយជាផ្នែកមួយនៃចំណុចខាងក្រោមដោយផ្អែកលើវិធីដែលយើងតម្រៀបអំពីសន្ទស្សន៍ដែលបានបញ្ជាក់។
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// រៀបចំចំណិតឡើងវិញជាមួយមុខងារទាញយកសំខាន់ៗដូចជាធាតុនៅ `index` គឺស្ថិតនៅទីតាំងតម្រៀបចុងក្រោយរបស់វា។
    ///
    /// តម្រៀបឡើងវិញនេះមានអចលនទ្រព្យបន្ថែមទៀតដែលមានតម្លៃណាមួយនៅទីតាំង `i < index` នឹងមានតិចជាងឬស្មើទៅនឹងតម្លៃដែលបានណាមួយនៅទីតាំងមួយ `j > index` ការប្រើមុខងារទាញយកគន្លឹះ។
    /// លើសពីនេះទៀតការតំរែតំរង់នេះគឺមិនស្ថិតស្ថេរ (មានន័យថាចំនួននៃធាតុស្មើគ្នាណាមួយអាចបញ្ចប់នៅទីតាំង `index`) កន្លែង (មានន័យថាមិនបែងចែក) និង *O*(*n*) ករណីដែលអាក្រក់បំផុត។
    /// មុខងារនេះត្រូវបានគេស្គាល់ថា "kth element" នៅក្នុងបណ្ណាល័យដទៃទៀត។
    /// វាត្រឡប់បីដងនៃតម្លៃដូចខាងក្រោម: ធាតុទាំងអស់តិចជាងមួយនៅសន្ទស្សន៍ដែលបានផ្តល់តម្លៃនៅសន្ទស្សន៍ដែលបានផ្តល់និងធាតុទាំងអស់ធំជាងមួយនៅសន្ទស្សន៍ដែលបានផ្តល់ឱ្យដោយប្រើមុខងារទាញយកគន្លឹះដែលបានផ្តល់។
    ///
    ///
    /// # ការអនុវត្តបច្ចុប្បន្ន
    ///
    /// នេះក្បួនដោះស្រាយនាពេលបច្ចុប្បន្នគឺមានមូលដ្ឋានលើផ្នែក quickselect នៃក្បួនដោះស្រាយ quicksort ដូចគ្នាដែលបានប្រើសម្រាប់ [`sort_unstable`] ។
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics នៅពេល `index >= len()` មានន័យថាវាតែងតែ panics នៅលើចំណិតទទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ត្រឡប់មេដ្យានហាក់ដូចជាអារេត្រូវបានតម្រៀបតាមតម្លៃដាច់ខាត។
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // យើងត្រូវបានធានាថាចំណែកនឹងក្លាយជាផ្នែកមួយនៃចំណុចខាងក្រោមដោយផ្អែកលើវិធីដែលយើងតម្រៀបអំពីសន្ទស្សន៍ដែលបានបញ្ជាក់។
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// ផ្លាស់ប្តូរធាតុដែលជាប់គ្នាទាំងអស់ជាបន្តបន្ទាប់ទៅចុងបញ្ចប់នៃចំណិតយោងទៅតាមការអនុវត្ត [`PartialEq`] trait ។
    ///
    ///
    /// ត្រឡប់ពីរចំណិត។ទីមួយមិនមានធាតុដដែលៗជាប់គ្នាទេ។
    /// លើកទីពីរនេះមានស្ទួនទាំងអស់នៅក្នុងការបញ្ជាទិញដែលបានបញ្ជាក់នោះទេ។
    ///
    /// ប្រសិនបើចំណិតត្រូវបានតម្រៀបនោះចំណែកដែលវិលត្រឡប់មកវិញដំបូងមិនមានលេខមួយស្ទួនទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// ផ្លាស់ទីទាំងអស់ប៉ុន្តែដំបូងនៃធាតុជាប់គ្នាទៅចុងបញ្ចប់នៃចំណិតដែលពេញចិត្តនឹងទំនាក់ទំនងសមភាពដែលបានផ្តល់ឱ្យ។
    ///
    /// ត្រឡប់ពីរចំណិត។ទីមួយមិនមានធាតុដដែលៗជាប់គ្នាទេ។
    /// លើកទីពីរនេះមានស្ទួនទាំងអស់នៅក្នុងការបញ្ជាទិញដែលបានបញ្ជាក់នោះទេ។
    ///
    /// មុខងារ `same_bucket` ត្រូវបានបញ្ជូនឯកសារយោងទៅធាតុពីរពីចំណិតហើយត្រូវកំណត់ថាតើធាតុប្រៀបធៀបស្មើគ្នា។
    /// ធាតុត្រូវបានឆ្លងកាត់តាមលំដាប់ផ្ទុយពីលំដាប់របស់ពួកគេនៅក្នុងចំណិតដូច្នេះប្រសិនបើ `same_bucket(a, b)` ត្រឡប់ `true` នោះ `a` ត្រូវបានផ្លាស់ទីនៅចុងបញ្ចប់នៃចំណិត។
    ///
    ///
    /// ប្រសិនបើចំណិតត្រូវបានតម្រៀបនោះចំណែកដែលវិលត្រឡប់មកវិញដំបូងមិនមានលេខមួយស្ទួនទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // ទោះបីជាយើងមានឯកសារយោងដែលអាចផ្លាស់ប្តូរបានទៅនឹង `self` ក៏ដោយយើងមិនអាចធ្វើការផ្លាស់ប្តូរ * តាមអំពើចិត្តបានឡើយ។ការហៅទូរស័ព្ទ `same_bucket` អាច panic ដូច្នេះយើងត្រូវតែធានាថាចំណែកតូចស្ថិតនៅក្នុងស្ថានភាពត្រឹមត្រូវគ្រប់ពេល។
        //
        // វិធីដែលយើងដោះស្រាយរឿងនេះគឺដោយប្រើស្វប;យើងនិយាយអំពីធាតុទាំងអស់ដោយផ្លាស់ប្តូរនៅពេលយើងទៅដូច្នេះនៅចុងបញ្ចប់ធាតុដែលយើងចង់រក្សាគឺនៅខាងមុខហើយអ្នកដែលយើងចង់បដិសេធគឺនៅខាងក្រោយ។
        // បន្ទាប់មកយើងអាចបំបែកចំណិត ៗ ។
        // ប្រតិបត្តិការនេះនៅតែជា `O(n)` ដដែល។
        //
        // ឧទាហរណ៍ៈយើងចាប់ផ្តើមនៅក្នុងរដ្ឋនេះដែល `r` តំណាងអោយ`បន្ទាប់`
        // អាន "និង `w` តំណាងឱ្យ" Next_write` ។
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // ការប្រៀបធៀប self[r] ប្រឆាំងនឹងខ្លួនវា [w-1] នេះមិនមែនស្ទួនគ្នាទេដូច្នេះយើងប្តូរ self[r] និង self[w] (គ្មានបែបផែនដូច r==w) ហើយបន្ទាប់មកបង្កើនទាំង r និង w ទុកអោយយើងដោយ៖
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // ប្រៀបធៀប self[r] ប្រឆាំងនឹងខ្លួនវា [w-1] តម្លៃនេះគឺស្ទួនដូច្នេះយើងបង្កើន `r` ប៉ុន្តែទុកអ្វីៗផ្សេងទៀតមិនផ្លាស់ប្តូរ៖
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // ប្រៀបធៀប self[r] ប្រឆាំងនឹងខ្លួនឯង [w-1] នេះមិនមែនជាស្ទួន, ដូច្នេះស្វប self[r] និង self[w] និងស្តាំជាមុននិង w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // មិនមែនស្ទួនគ្នាទេធ្វើឡើងវិញ៖
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // ស្ទួន, advance r. End នៃចំណែក។ពុះនៅ w ។
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // សុវត្ថិភាព: លក្ខខណ្ឌ `while` ធានា `next_read` និង `next_write`
        // តូចជាង `len` ដូច្នេះគឺនៅខាងក្នុង `self` ។
        // `prev_ptr_write` ចង្អុលទៅធាតុមួយមុនពេល `ptr_write` ប៉ុន្តែ `next_write` ចាប់ផ្តើមពីលេខ ១ ដូច្នេះ `prev_ptr_write` មិនតិចជាង ០ ហើយស្ថិតនៅខាងក្នុងចំណិត។
        // នេះបំពេញនូវតម្រូវការសម្រាប់ការដកហូត `ptr_read`, `prev_ptr_write` និង `ptr_write` និងសម្រាប់ការប្រើប្រាស់ `ptr.add(next_read)`, `ptr.add(next_write - 1)` និង `prev_ptr_write.offset(1)` ។
        //
        //
        // `next_write` វាក៏ត្រូវបានបង្កើនដែរក្នុងមួយរង្វិលជុំភាគច្រើនមានន័យថាគ្មានធាតុណាមួយត្រូវបានរំលងឡើយនៅពេលដែលវាចាំបាច់ត្រូវដោះដូរ។
        //
        // `ptr_read` និង `prev_ptr_write` មិនដែលចង្អុលទៅធាតុតែមួយទេ។នេះតម្រូវឱ្យ `&mut *ptr_read`, `&mut* prev_ptr_write` មានសុវត្ថិភាព។
        // ការពន្យល់គឺសាមញ្ញថា `next_read >= next_write` គឺតែងតែជាការពិតដូច្នេះ `next_read > next_write - 1` ក៏ដូចគ្នាដែរ។
        //
        //
        //
        //
        //
        unsafe {
            // ជៀសវាងការត្រួតពិនិត្យព្រំដែនដោយប្រើចង្អុលឆៅ។
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ផ្លាស់ទីទាំងអស់ប៉ុន្តែដំបូងនៃធាតុជាប់គ្នាទៅចុងបញ្ចប់នៃចំណិតដែលដោះស្រាយទៅកូនសោតែមួយ។
    ///
    ///
    /// ត្រឡប់ពីរចំណិត។ទីមួយមិនមានធាតុដដែលៗជាប់គ្នាទេ។
    /// លើកទីពីរនេះមានស្ទួនទាំងអស់នៅក្នុងការបញ្ជាទិញដែលបានបញ្ជាក់នោះទេ។
    ///
    /// ប្រសិនបើចំណិតត្រូវបានតម្រៀបនោះចំណែកដែលវិលត្រឡប់មកវិញដំបូងមិនមានលេខមួយស្ទួនទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// បង្វិលចំណែកនៅក្នុងកន្លែងដែលធាតុ `mid` ដំបូងនៃចំណិតផ្លាស់ទីទៅចុងបញ្ចប់ខណៈពេលដែលធាតុ `self.len() - mid` ចុងក្រោយផ្លាស់ទីទៅផ្នែកខាងមុខ។
    /// បន្ទាប់ពីហៅទូរស័ព្ទ `rotate_left`, ធាតុពីមុននៅសន្ទស្សន៍ `mid` នឹងក្លាយជាធាតុដំបូងនៅក្នុងចំណិត។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើ `mid` ធំជាងប្រវែងនៃចំណិត។ចំណាំថា `mid == self.len()` ធ្វើ _not_ panic ហើយជាការបង្វិលគ្មានអ័ក្ស។
    ///
    /// # Complexity
    ///
    /// ថតលីនេអ៊ែរ (ក្នុងពេលវេលា `self.len()`) ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// បង្វិល sublice៖
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // សុវត្ថិភាព: ជួរ `[p.add(mid) - mid, p.add(mid) + k)` គឺមិនសំខាន់
        // មានសុពលភាពសម្រាប់ការអាននិងសរសេរដូចដែលបានទាមទារដោយ `ptr_rotate` ។
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// បង្វិលចំណែកនៅក្នុងកន្លែងដែលធាតុ `self.len() - k` ដំបូងនៃចំណិតផ្លាស់ទីទៅចុងបញ្ចប់ខណៈពេលដែលធាតុ `k` ចុងក្រោយផ្លាស់ទីទៅផ្នែកខាងមុខ។
    /// បន្ទាប់ពីហៅទូរស័ព្ទ `rotate_right`, ធាតុពីមុននៅសន្ទស្សន៍ `self.len() - k` នឹងក្លាយជាធាតុដំបូងនៅក្នុងចំណិត។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើ `k` ធំជាងប្រវែងនៃចំណិត។ចំណាំថា `k == self.len()` ធ្វើ _not_ panic ហើយជាការបង្វិលគ្មានអ័ក្ស។
    ///
    /// # Complexity
    ///
    /// ថតលីនេអ៊ែរ (ក្នុងពេលវេលា `self.len()`) ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// បង្វិល sublice៖
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // សុវត្ថិភាព: ជួរ `[p.add(mid) - mid, p.add(mid) + k)` គឺមិនសំខាន់
        // មានសុពលភាពសម្រាប់ការអាននិងសរសេរដូចដែលបានទាមទារដោយ `ptr_rotate` ។
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// បំពេញ `self` ជាមួយធាតុដោយក្លូន `value` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// បំពេញ `self` ជាមួយធាតុត្រឡប់មកវិញដោយហៅការបិទម្តងហើយម្តងទៀត។
    ///
    /// វិធីសាស្ត្រនេះប្រើការបិទដើម្បីបង្កើតតម្លៃថ្មី។ប្រសិនបើអ្នកចង់បាន [`Clone`] តម្លៃដែលបានផ្តល់ឱ្យប្រើ [`fill`] ។
    /// ប្រសិនបើអ្នកចង់ប្រើ [`Default`] trait ដើម្បីបង្កើតតម្លៃអ្នកអាចហុច [`Default::default`] ជាអាគុយម៉ង់។
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// ចម្លងធាតុពី `src` ទៅជា `self` ។
    ///
    /// ប្រវែងនៃ `src` ត្រូវតែដូចគ្នានឹង `self` ។
    ///
    /// ប្រសិនបើ `T` អនុវត្ត `Copy` វាអាចអនុវត្តបានច្រើនក្នុងការប្រើប្រាស់ [`copy_from_slice`] ។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើចំណិតទាំងពីរមានប្រវែងខុសគ្នា។
    ///
    /// # Examples
    ///
    /// ការក្លូនធាតុពីរពីចំណិតទៅជាវត្ថុមួយទៀត៖
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ដោយសារតែចំណិតមានមានប្រវែងដូចគ្នានេះដែរយើង slice នេះប្រភពពីធាតុចំណែកបួននាក់ទៅពីរ។
    /// // វានឹង panic ប្រសិនបើយើងមិនធ្វើបែបនេះទេ។
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust អនុវត្តថាមានតែសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានដោយមិនមានឯកសារយោងដែលមិនអាចផ្លាស់ប្តូរបានទៅនឹងបំណែកទិន្នន័យណាមួយក្នុងវិសាលភាពជាក់លាក់ណាមួយ។
    /// ដោយសារតែនេះការប៉ុនប៉ងប្រើ `clone_from_slice` នៅលើចំណែកតែមួយនឹងនាំឱ្យមានការបរាជ័យក្នុងការចងក្រង:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ដើម្បីធ្វើការនៅជុំវិញនេះយើងអាចប្រើ [`split_at_mut`] ដើម្បីបង្កើតចំណិតតូចៗពីរដាច់ដោយឡែកពីគ្នា:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// ចម្លងធាតុទាំងអស់ពី `src` ទៅក្នុង `self` ដោយប្រើក្រដាសចងចាំ។
    ///
    /// ប្រវែងនៃ `src` ត្រូវតែដូចគ្នានឹង `self` ។
    ///
    /// ប្រសិនបើ `T` មិនអនុវត្ត `Copy` ប្រើ [`clone_from_slice`] ។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើចំណិតទាំងពីរមានប្រវែងខុសគ្នា។
    ///
    /// # Examples
    ///
    /// ចម្លងធាតុពីរពីចំណិតមួយទៅក្នុងមួយផ្សេងទៀត៖
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // ដោយសារតែចំណិតមានមានប្រវែងដូចគ្នានេះដែរយើង slice នេះប្រភពពីធាតុចំណែកបួននាក់ទៅពីរ។
    /// // វានឹង panic ប្រសិនបើយើងមិនធ្វើបែបនេះទេ។
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust អនុវត្តថាមានតែសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានដោយមិនមានឯកសារយោងដែលមិនអាចផ្លាស់ប្តូរបានទៅនឹងបំណែកទិន្នន័យណាមួយក្នុងវិសាលភាពជាក់លាក់ណាមួយ។
    /// ដោយសារតែនេះការប៉ុនប៉ងប្រើ `copy_from_slice` នៅលើចំណែកតែមួយនឹងនាំឱ្យមានការបរាជ័យក្នុងការចងក្រង:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ដើម្បីធ្វើការនៅជុំវិញនេះយើងអាចប្រើ [`split_at_mut`] ដើម្បីបង្កើតចំណិតតូចៗពីរដាច់ដោយឡែកពីគ្នា:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // ផ្លូវលេខកូដ panic ត្រូវបានដាក់ចូលទៅក្នុងមុខងារត្រជាក់ដើម្បីមិនឱ្យបណ្តាញហៅទូរស័ព្ទចេញ។
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // សុវត្ថិភាព: `self` មានសុពលភាពសម្រាប់ធាតុ `self.len()` តាមនិយមន័យហើយ `src` គឺ
        // គូសធីកមានប្រវែងដូចគ្នា។
        // ចំណិតមិនអាចត្រួតលើគ្នាបានទេពីព្រោះឯកសារយោងដែលអាចផ្លាស់ប្តូរបានគឺផ្តាច់មុខ។
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// ចម្លងធាតុពីផ្នែកមួយនៃចំណិតទៅផ្នែកផ្សេងទៀតនៃខ្លួនវាដោយប្រើអនុស្សាវរីយ៍។
    ///
    /// `src` គឺជាជួរនៅក្នុង `self` ដើម្បីចម្លងពី។
    /// `dest` គឺជាសន្ទស្សន៍ចាប់ផ្តើមនៃជួរនៅក្នុង `self` ដើម្បីចម្លងទៅដែលនឹងមានប្រវែងដូចគ្នានឹង `src` ដែរ។
    /// ជួរទាំងពីរអាចត្រួតលើគ្នា។
    /// ចុងបញ្ចប់នៃជួរទាំងពីរត្រូវតែតិចជាងឬស្មើ `self.len()` ។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើជួរទាំងលើសពីចុងបញ្ចប់នៃ slice នោះឬប្រសិនបើចុង `src` នេះគឺមុនពេលចាប់ផ្តើម។
    ///
    ///
    /// # Examples
    ///
    /// ការចម្លងបួនបៃក្នុងមួយចំណែក ៗ ៖
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // សុវត្ថិភាព: លក្ខខណ្ឌសម្រាប់ `ptr::copy` ត្រូវបានពិនិត្យទាំងអស់ខាងលើ
        // ដូចដែលមានសម្រាប់ `ptr::add` ។
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// ផ្លាស់ប្តូរធាតុទាំងអស់នៅក្នុង `self` ជាមួយធាតុនៅក្នុង `other` ។
    ///
    /// ប្រវែង `other` ត្រូវតែដូចគ្នានឹង `self` ដែរ។
    ///
    /// # Panics
    ///
    /// មុខងារនេះនឹង panic ប្រសិនបើចំណិតទាំងពីរមានប្រវែងខុសគ្នា។
    ///
    /// # Example
    ///
    /// ការផ្លាស់ប្តូរធាតុពីរនៅលើចំណិត ៗ ៈ
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust អនុវត្តថាមានតែសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានមួយទៅនឹងទិន្នន័យជាក់លាក់មួយនៅក្នុងវិសាលភាពជាក់លាក់មួយ។
    ///
    /// ដោយសារតែនេះការប៉ុនប៉ងប្រើ `swap_with_slice` នៅលើចំណែកតែមួយនឹងនាំឱ្យមានការបរាជ័យក្នុងការចងក្រង:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// ដើម្បីធ្វើការនៅជុំវិញនេះយើងអាចប្រើ [`split_at_mut`] ដើម្បីបង្កើតចំណិតតូចៗដែលអាចផ្លាស់ប្តូរបានពីរដាច់ដោយឡែកពីគ្នា:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // សុវត្ថិភាព: `self` មានសុពលភាពសម្រាប់ធាតុ `self.len()` តាមនិយមន័យហើយ `src` គឺ
        // គូសធីកមានប្រវែងដូចគ្នា។
        // ចំណិតមិនអាចត្រួតលើគ្នាបានទេពីព្រោះឯកសារយោងដែលអាចផ្លាស់ប្តូរបានគឺផ្តាច់មុខ។
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// មុខងារដើម្បីគណនាប្រវែងនៃពាក់កណ្តាលនិងចំណិតខាងក្រោយសម្រាប់ `align_to{,_mut}` ។
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // អ្វីដែលយើងធ្វើនឹងគឺជាតួលេខប្រហែល `rest` ច្រើននៃអ្វីដែលការចេញ `U`s យើងអាចដាក់នៅក្នុងចំនួនមួយទាបបំផុតនៃ`T`s ។
        //
        // ហើយចំនួនប៉ុន្មានដែលយើងត្រូវការសម្រាប់ "multiple" នីមួយៗ។
        //
        // ពិចារណាឧទាហរណ៍ T=u8 U=u16 ។បន្ទាប់មកយើងអាចដាក់យូយូនៅ ២ Ts ។សាមញ្ញ។
        // ឥឡូវពិចារណាឧទាហរណ៍ករណីដែល size_of: :<T>=១៦, ទំហំ_of::<U>=២៤ ។</u>
        // យើងអាចដាក់យើង ២ ជំនួសអោយរាល់ ៣ Ts នៅក្នុងចំណិត `rest` ។
        // បន្តិចទៀតដែលស្មុគស្មាញ។
        //
        // រូបមន្តដើម្បីគណនានេះគឺ៖
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // ពង្រីកនិងសាមញ្ញ៖
        //
        // Us=size_of: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // សំណាងព្រោះអ្វីៗទាំងអស់នេះត្រូវបានគេវាយតម្លៃថេរ ... ការសម្តែងនៅទីនេះមិនសំខាន់ទេ!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // ក្បួនដោះស្រាយរបស់យើងដង Stein នៅតែគួរតែធ្វើឱ្យ `const fn` នេះ (និងត្រឡប់ទៅក្បួនដោះស្រាយការហៅខ្លួនឯងប្រសិនបើយើងធ្វើ) ដោយសារតែពឹងផ្អែកលើ llvm ដើម្បី consteval ទាំងអស់នេះត្រូវបាន ... ល្អ, វាធ្វើឱ្យខ្ញុំមិនស្រួល។
            //
            //

            // សុវត្ថិភាព: `a` និង `b` ត្រូវបានពិនិត្យថាមិនមែនជាតម្លៃសូន្យ។
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // ដកកត្តាទាំងអស់ពី ២ ចេញពីខ
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // សុវត្ថិភាព: `b` ត្រូវបានពិនិត្យថាមិនមែនសូន្យ។
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ដោយមានចំណេះដឹងនេះយើងអាចដឹងថាតើយើងអាចសាកសមនឹងមនុស្សប៉ុន្មាននាក់!
        let us_len = self.len() / ts * us;
        // ហើយចំនួន T `s នឹងស្ថិតនៅក្នុងចន្លោះបន្ទាប់!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// transmute ចំណែកទៅនឹងចំណែកនៃប្រភេទមួយផ្សេងទៀត, ធានានូវការតម្រឹមនៃប្រភេទនេះត្រូវបានរក្សា។
    ///
    /// វិធីសាស្រ្តនេះបំបែកចំណិត ៗ ជាបីចំណែកផ្សេងៗគ្នា៖ បុព្វបទបង្រួមផ្នែកកណ្តាលនៃប្រភេទថ្មីនិងចំណិតបច្ច័យ។
    /// វិធីសាស្រ្តនេះអាចធ្វើឱ្យចំណិតពាក់កណ្តាលមានប្រវែងធំបំផុតដែលអាចធ្វើបានសម្រាប់ប្រភេទដែលបានផ្តល់និងចំណិតបញ្ចូលប៉ុន្តែមានតែការអនុវត្តក្បួនដោះស្រាយរបស់អ្នកប៉ុណ្ណោះដែលពឹងផ្អែកលើវាមិនមែនភាពត្រឹមត្រូវរបស់វាទេ។
    ///
    /// រាល់ទិន្នន័យបញ្ចូលទាំងអស់ត្រូវបានអនុញ្ញាតិឱ្យត្រឡប់ជាបុព្វបទឬចំណិតបច្ច័យ។
    ///
    /// វិធីសាស្រ្តនេះមិនមានគោលបំណងទេនៅពេលដែលធាតុបញ្ចូល `T` រឺធាតុទិន្នផល `U` មានទំហំសូន្យហើយនឹងត្រឡប់ចំណែកដើមវិញដោយមិនពុះអ្វីទាំងអស់។
    ///
    /// # Safety
    ///
    /// វិធីសាស្រ្តនេះគឺសំខាន់ `transmute` ដែលទាក់ទងទៅនឹងធាតុនៅក្នុងចំណែកកណ្តាលដែលបានត្រលប់មកវិញដូច្នេះចំណិតធម្មតាដែលទាក់ទងនឹង `transmute::<T, U>` ក៏អនុវត្តនៅទីនេះដែរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // ចំណាំថាមុខងារនេះភាគច្រើននឹងត្រូវបានវាយតម្លៃថេរ។
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ដោះស្រាយ ZSTs ពិសេសដែលមិនត្រូវដោះស្រាយវាទាល់តែសោះ។
            return (self, &[], &[]);
        }

        // ទីមួយរកចំនុចណាដែលយើងចែករវាងចំណិតទីមួយនិងខ្ទង់ទីពីរ។
        // ងាយស្រួលជាមួយ ptr.align_offset ។
        let ptr = self.as_ptr();
        // សុវត្ថិភាព: សូមមើលវិធីសាស្ត្រ `align_to_mut` សម្រាប់ការអត្ថាធិប្បាយអំពីសុវត្ថិភាពលម្អិត។
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // សុវត្ថិភាព: ឥឡូវនេះ `rest` ពិតជាត្រូវបានតម្រឹមដូច្នេះ `from_raw_parts` ខាងក្រោមមិនអីទេ
            // ចាប់តាំងពីអ្នកទូរស័ព្ទចូលធានាថាយើងអាចបញ្ជូន `T` ទៅ `U` ដោយសុវត្ថិភាព។
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// transmute ចំណែកទៅនឹងចំណែកនៃប្រភេទមួយផ្សេងទៀត, ធានានូវការតម្រឹមនៃប្រភេទនេះត្រូវបានរក្សា។
    ///
    /// វិធីសាស្រ្តនេះបំបែកចំណិត ៗ ជាបីចំណែកផ្សេងៗគ្នា៖ បុព្វបទបង្រួមផ្នែកកណ្តាលនៃប្រភេទថ្មីនិងចំណិតបច្ច័យ។
    /// វិធីសាស្រ្តនេះអាចធ្វើឱ្យចំណិតពាក់កណ្តាលមានប្រវែងធំបំផុតដែលអាចធ្វើបានសម្រាប់ប្រភេទដែលបានផ្តល់និងចំណិតបញ្ចូលប៉ុន្តែមានតែការអនុវត្តក្បួនដោះស្រាយរបស់អ្នកប៉ុណ្ណោះដែលពឹងផ្អែកលើវាមិនមែនភាពត្រឹមត្រូវរបស់វាទេ។
    ///
    /// រាល់ទិន្នន័យបញ្ចូលទាំងអស់ត្រូវបានអនុញ្ញាតិឱ្យត្រឡប់ជាបុព្វបទឬចំណិតបច្ច័យ។
    ///
    /// វិធីសាស្រ្តនេះមិនមានគោលបំណងទេនៅពេលដែលធាតុបញ្ចូល `T` រឺធាតុទិន្នផល `U` មានទំហំសូន្យហើយនឹងត្រឡប់ចំណែកដើមវិញដោយមិនពុះអ្វីទាំងអស់។
    ///
    /// # Safety
    ///
    /// វិធីសាស្រ្តនេះគឺសំខាន់ `transmute` ដែលទាក់ទងទៅនឹងធាតុនៅក្នុងចំណែកកណ្តាលដែលបានត្រលប់មកវិញដូច្នេះចំណិតធម្មតាដែលទាក់ទងនឹង `transmute::<T, U>` ក៏អនុវត្តនៅទីនេះដែរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // ចំណាំថាមុខងារនេះភាគច្រើននឹងត្រូវបានវាយតម្លៃថេរ។
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ដោះស្រាយ ZSTs ពិសេសដែលមិនត្រូវដោះស្រាយវាទាល់តែសោះ។
            return (self, &mut [], &mut []);
        }

        // ទីមួយរកចំនុចណាដែលយើងចែករវាងចំណិតទីមួយនិងខ្ទង់ទីពីរ។
        // ងាយស្រួលជាមួយ ptr.align_offset ។
        let ptr = self.as_ptr();
        // សុវត្ថិភាព: នៅទីនេះយើងកំពុងធានាថាយើងនឹងប្រើទ្រនិចចង្អុលតម្រឹមសម្រាប់យូសម្រាប់
        // នៅសល់នៃវិធីសាស្ត្រ។នេះត្រូវបានធ្វើដោយការបញ្ជូនទ្រនិចមួយទៅ [T] ដោយតម្រឹមទិសដៅសម្រាប់យូ។
        // `crate::ptr::align_offset` ត្រូវបានគេហៅថាមានទ្រនិចតម្រង់ជួរត្រឹមត្រូវនិងមានទ្រនិចត្រឹមត្រូវ `ptr` (វាបានមកពីឯកសារយោងទៅ `self`) និងមានទំហំដែលជាអនុភាពនៃថាមពលពីរ (ចាប់តាំងពីវាមកពីការតម្រឹមសម្រាប់យូ) ដោយពេញចិត្តចំពោះឧបសគ្គសុវត្ថិភាពរបស់វា។
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // យើងមិនអាចប្រើ `rest` ម្តងទៀតបន្ទាប់ពីនេះដែលនឹងធ្វើអោយឈ្មោះហៅក្រៅ `mut_ptr` របស់វាមានសុពលភាព!សុវត្ថិភាព: មើលយោបល់សម្រាប់ `align_to` ។
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// ពិនិត្យមើលថាតើធាតុនៃចំណិតនេះត្រូវបានតម្រៀប។
    ///
    /// នោះគឺជា, សម្រាប់ធាតុគ្នា `a` របស់ខ្លួននិងធាតុខាងក្រោម `b`, `a <= b` ត្រូវមាន។ប្រសិនបើចំណិតផ្តល់ទិន្នផលសូន្យឬធាតុមួយពិតប្រាកដនោះ `true` នឹងត្រលប់មកវិញ។
    ///
    /// ចំណាំថាប្រសិនបើ `Self::Item` គឺគ្រាន់តែជា `PartialOrd` ប៉ុន្តែមិន `Ord`, និយមន័យខាងលើនេះបញ្ជាក់ថាអនុគមន៍នេះត្រឡប់ `false` បើធាតុណាមួយដែលមានពីរជាប់គ្នាមិនអាចប្រៀបធៀប។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// ពិនិត្យមើលថាតើធាតុនៃចំណិតនេះត្រូវបានតម្រៀបដោយប្រើមុខងារប្រៀបធៀបដែលបានផ្តល់ឱ្យ។
    ///
    /// ជំនួសឱ្យការប្រើ `PartialOrd::partial_cmp` មុខងារនេះប្រើមុខងារ `compare` បានផ្ដល់ទៅឱ្យធាតុលំដាប់កំណត់ទាំងពីរនាក់នេះ។
    /// ក្រៅពីនោះ, វាជាការស្មើនឹង [`is_sorted`];មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// ពិនិត្យមើលប្រសិនបើធាតុនៃចម្រៀកនេះគឺត្រូវបានតម្រៀបដោយការប្រើមុខងារទាញយកគន្លឹះដែលបានផ្តល់ឱ្យ។
    ///
    /// ជំនួសឱ្យការប្រៀបធៀបធាតុរបស់ចំណិតដោយផ្ទាល់មុខងារនេះប្រៀបធៀបគ្រាប់ចុចនៃធាតុដែលត្រូវបានកំណត់ដោយ `f` ។
    /// ក្រៅពីនោះ, វាជាការស្មើនឹង [`is_sorted`];មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// ត្រឡប់លិបិក្រមនៃចំណុចភាគយោងតាមព្យាករណ៍ដែលបានផ្តល់ឱ្យ (សន្ទស្សន៍នៃធាតុទីមួយនៃភាគថាសទីពីរ) ។
    ///
    /// ចំណិតត្រូវបានគេសន្មតថាចែកចេញជាតាមការទស្សន៍ទាយដែលបានផ្តល់ឱ្យ។
    /// នេះមានន័យថាធាតុទាំងអស់ដែលព្យាករណ៍ត្រឡប់ជាការពិតគឺនៅដំណាក់កាលដំបូងហើយធាតុទាំងអស់ដែលព្យាករណ៍ត្រឡប់មិនពិតនៅចុងបញ្ចប់។
    ///
    /// ឧទាហរណ៍ [7, 15, 3, 5, 4, 12, 6] ត្រូវបានចែកជាផ្នែកក្រោមការប៉ាន់ស្មាន x% 2!=0 (លេខសេសទាំងអស់គឺនៅពេលចាប់ផ្តើមសូម្បីតែនៅចុងបញ្ចប់ក៏ដោយ) ។
    ///
    /// ប្រសិនបើចំណិតនេះមិនត្រូវបានបែងចែកជាលទ្ធផលលទ្ធផលត្រឡប់មកវិញគឺមិនត្រូវបានបញ្ជាក់និងគ្មានន័យទេព្រោះវិធីសាស្ត្រនេះអនុវត្តប្រភេទនៃការស្វែងរកគោលពីរ។
    ///
    /// សូមមើលផងដែរ [`binary_search`], [`binary_search_by`], និង [`binary_search_by_key`] ។
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // សុវត្ថិភាព: នៅពេល `left < right`, `left <= mid < right`.
            // ដូច្នេះ `left` តែងតែកើនឡើងហើយ `right` តែងតែថយចុះហើយវាទាំងពីរត្រូវបានជ្រើសរើស។ក្នុងករណីទាំងពីរ `left <= right` ពេញចិត្ត។ដូច្នេះប្រសិនបើ `left < right` នៅក្នុងជំហានមួយ `left <= right` ពេញចិត្តនឹងជំហានបន្ទាប់។
            //
            // ដូច្នេះដរាបណា `left != right`, `0 <= left < right <= len` ពេញចិត្តហើយប្រសិនបើករណីនេះ `0 <= mid < len` ក៏ពេញចិត្តដែរ។
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: យើងត្រូវកាត់វាឱ្យត្រង់ទៅប្រវែងដូចគ្នា
        // ដើម្បីធ្វើឱ្យវាកាន់តែងាយស្រួលសម្រាប់កម្មវិធីធ្វើឱ្យប្រសើរដើម្បីពង្រឹងការត្រួតពិនិត្យព្រំដែន។
        // ប៉ុន្តែដោយសារវាមិនអាចពឹងផ្អែកលើយើងក៏មានជំនាញជាក់លាក់សម្រាប់ T: ចម្លង។
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// បង្កើតចំណិតទទេ។
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// បង្កើតចំណិតទទេដែលអាចផ្លាស់ប្តូរបាន។
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// លំនាំនៅក្នុងចំណិតបច្ចុប្បន្នប្រើតែ `strip_prefix` និង `strip_suffix` ប៉ុណ្ណោះ។
/// នៅចំណុច future យើងសង្ឃឹមថានឹងធ្វើឱ្យ `core::str::Pattern` X ទូទៅ (ដែលនៅពេលសរសេរត្រូវបានកំណត់ត្រឹម `str`) ទៅចំណិតហើយបន្ទាប់មក trait នេះនឹងត្រូវជំនួសឬលុបចោល។
///
pub trait SlicePattern {
    /// ធាតុនៃ slice ត្រូវបានផ្គូផ្គងនៅលើ។
    type Item;

    /// បច្ចុប្បន្នអតិថិជនរបស់ `SlicePattern` ត្រូវការចំណែក។
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}