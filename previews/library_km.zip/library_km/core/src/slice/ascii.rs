//! ប្រតិបត្ដិការនៅលើ ASCII `[u8]` ។

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ពិនិត្យមើលថាតើបៃទាំងអស់នៅក្នុងចំណិតនេះស្ថិតនៅក្នុងជួរ ASCII ។
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// ពិនិត្យមើលថាចំណិតពីរគឺជាការប្រកួតរវាង ASCII-មិនស៊ីសង្វាក់គ្នា។
    ///
    /// ដូចគ្នានឹង `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ដែរប៉ុន្តែដោយគ្មានការបែងចែកនិងថតចម្លងតារាងពេលវេលា។
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// បម្លែងចំណិតនេះទៅជាអក្សរធំ ASCII ដែលស្មើនឹងកន្លែង។
    ///
    /// អក្សរ ASCII 'a' ទៅ 'z' ត្រូវបានគូសផែនទីទៅ 'A' ទៅ 'Z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីត្រឡប់តម្លៃអក្សរធំថ្មីដោយមិនចាំបាច់កែប្រែតម្លៃដែលមានស្រាប់សូមប្រើ [`to_ascii_uppercase`] ។
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// បំលែងចំណិតនេះទៅជាអក្សរតូច ASCII ដែលស្មើនឹងកន្លែង។
    ///
    /// អក្សរ ASCII 'A' ទៅ 'Z' ត្រូវបានគូសផែនទីទៅ 'a' ទៅ 'z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីត្រឡប់តម្លៃទាបថ្មីដោយមិនចាំបាច់កែប្រែរបស់ដែលមានស្រាប់សូមប្រើ [`to_ascii_lowercase`] ។
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// ត្រឡប់ `true` ប្រសិនបើបៃណាមួយនៅក្នុងពាក្យ `v` គឺមិនមែនជាអាយហ្គីជី (>=128) ។
/// Snarfed ពី `../str/mod.rs` ដែលធ្វើអ្វីដែលស្រដៀងគ្នាសម្រាប់សុពលភាព utf8 ។
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ការធ្វើតេស្តបានធ្វើឱ្យប្រសើរ ASCII ដែលនឹងប្រើប្រតិបត្តិការ usize នៅពេលវេលាមួយនៃប្រតិបត្តិការបៃជំនួសនៅពេលវេលាមួយ (នៅពេលដែលអាចធ្វើបាន) ។
///
/// ក្បួនដោះស្រាយដែលយើងប្រើនៅទីនេះគឺសាមញ្ញណាស់។ប្រសិនបើ `s` ខ្លីពេកយើងគ្រាន់តែពិនិត្យមើលបៃនីមួយៗហើយធ្វើវាជាមួយវា។បើមិនដូច្នេះទេ:
///
/// - អានពាក្យដំបូងដោយបន្ទុកមិនចុះសម្រុង។
/// - តម្រឹមទ្រនិចអានពាក្យជាបន្តបន្ទាប់រហូតដល់ចប់ដោយមានបន្ទុកតម្រឹម។
/// - អាន `usize` ចុងក្រោយពី `s` ជាមួយនឹងបន្ទុកដែលមិនមានការចុះសម្រុង។
///
/// ប្រសិនបើបន្ទុកណាមួយផលិតអ្វីមួយដែល `contains_nonascii` (above) ត្រលប់មកវិញពិតប្រាកដនោះយើងដឹងចម្លើយគឺមិនពិត។
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // ប្រសិនបើយើងមិនទទួលបានអ្វីពីការអនុវត្តពាក្យម្តង ៗ ទេសូមត្រឡប់ទៅផ្នែកខាងចុង។
    //
    // យើងក៏ធ្វើវាសម្រាប់ស្ថាបត្យកម្មដែល `size_of::<usize>()` មិនមានការតម្រឹមគ្រប់គ្រាន់សម្រាប់ `usize` ទេព្រោះវាជាករណី edge ដែលចម្លែក។
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // យើងតែងតែអានពាក្យដំបូងដែលមិនបានចុះបញ្ជីដែលមានន័យថា `align_offset` គឺ
    // ០ យើងនឹងអានតម្លៃដដែលម្តងទៀតសម្រាប់អានដែលបានតម្រឹម។
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // សុវត្ថិភាព: យើងផ្ទៀងផ្ទាត់ `len < USIZE_SIZE` ខាងលើ។
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // យើងបានពិនិត្យមើលចំណុចខាងលើនេះ។
    // ចំណាំថា `offset_to_aligned` គឺជា `align_offset` ឬ `USIZE_SIZE` ទាំងពីរត្រូវបានគូសធីកយ៉ាងច្បាស់ខាងលើ។
    //
    debug_assert!(offset_to_aligned <= len);

    // សុវត្ថិភាព: word_ptr គឺជាទំហំដែលបានតម្រឹមដែលត្រូវបានប្រើដើម្បីអានឯកសារ
    // កំណាត់កណ្តាលនៃចំណិត។
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` គឺជាសន្ទស្សន៍បៃនៃ `word_ptr` ដែលត្រូវបានប្រើសម្រាប់ការត្រួតពិនិត្យចុងរង្វិលជុំ។
    let mut byte_pos = offset_to_aligned;

    // Paranoia ពិនិត្យមើលអំពីការតម្រឹមពីព្រោះយើងហៀបនឹងធ្វើការផ្ទុកបន្ទុកដែលមិនមានការចុះសម្រុងគ្នា។
    // នៅក្នុងការអនុវត្តជាក់ស្តែងវាមិនអាចទៅរួចទេដែលរារាំងកំហុសក្នុង `align_offset` ទោះបីជាយ៉ាងណាក៏ដោយ។
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // អានពាក្យជាបន្តបន្ទាប់រហូតដល់ពាក្យដែលបានតម្រឹមចុងក្រោយដោយមិនរាប់បញ្ចូលពាក្យដែលបានតម្រឹមចុងក្រោយដោយខ្លួនវាដែលត្រូវធ្វើនៅក្នុងការត្រួតពិនិត្យកន្ទុយនៅពេលក្រោយដើម្បីធានាថាកន្ទុយតែងតែជាលេខ `usize` ភាគច្រើនបំផុតដើម្បីបន្ថែម branch `byte_pos == len` ។
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // ពិនិត្យសុខភាពថាការអានគឺស្ថិតនៅក្នុងព្រំដែន
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // ហើយថាការសន្មតរបស់យើងអំពី `byte_pos` កាន់។
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // សុវត្ថិភាព: យើងដឹងថា `word_ptr` ត្រូវបានតម្រឹមត្រឹមត្រូវ (ដោយសារតែ
        // `align_offset`) ហើយយើងដឹងថាយើងមានបៃគ្រប់គ្រាន់រវាង `word_ptr` និងចុងបញ្ចប់
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // សុវត្ថិភាព: យើងដឹងថា `byte_pos <= len - USIZE_SIZE` ដែលមានន័យថា
        // បន្ទាប់ពី `add` នេះ, `word_ptr` នឹងមានច្រើនបំផុតមួយអតីតកាល។
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // ការពិនិត្យសុខភាពដើម្បីធានាថាពិតជាមាននៅសល់តែ `usize` តែមួយគត់។
    // នេះគួរតែត្រូវបានធានាដោយលក្ខខណ្ឌរង្វិលជុំរបស់យើង។
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // សុវត្ថិភាព: នេះពឹងផ្អែកលើ `len >= USIZE_SIZE` ដែលយើងពិនិត្យមើលនៅពេលចាប់ផ្តើម។
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}