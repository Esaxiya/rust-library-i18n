//! ការតម្រៀបតាមចំណិត
//!
//! ម៉ូឌុលនេះមានក្បួនដោះស្រាយតម្រៀបផ្អែកលើការបង្កើតគំរូរហ័សរបស់អ័រសុនភីធឺដែលចេញផ្សាយនៅ៖ <https://github.com/orlp/pdqsort>
//!
//!
//! ការតម្រៀបមិនស្ថិតស្ថេរគឺឆបគ្នាជាមួយ libcore ពីព្រោះវាមិនបែងចែកការចងចាំមិនដូចការអនុវត្តតម្រៀបស្ថេរភាពរបស់យើងទេ។
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// នៅពេលដែលការធ្លាក់ចុះ, ច្បាប់ចម្លងពី `src` ចូលទៅក្នុង `dest` ។
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // សុវត្ថិភាព: នេះគឺជាថ្នាក់ជំនួយ។
        //          សូមយោងទៅលើការប្រើប្រាស់របស់វាសម្រាប់ភាពត្រឹមត្រូវ។
        //          ឧទាហរណ៍មួយត្រូវតែប្រាកដថា `src` និង `dst` មិនជាន់គ្នាតាមតម្រូវការរបស់ `ptr::copy_nonoverlapping` ។
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// ផ្លាស់ប្តូរធាតុទីមួយទៅស្តាំរហូតដល់វាជួបធាតុធំជាងឬស្មើ។
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // សុវត្ថិភាព: ប្រតិបត្តិការដែលមិនមានសុវត្ថិភាពនៅខាងក្រោមពាក់ព័ន្ធនឹងការបង្កើតលិបិក្រមដោយគ្មានការត្រួតពិនិត្យ (`get_unchecked` និង `get_unchecked_mut`)
    // និងថតចម្លងការចងចាំ (`ptr::copy_nonoverlapping`) ។
    //
    // ក។ការបង្កើតលិបិក្រម៖
    //  1. យើងពិនិត្យទំហំអារេទៅ>=២ ។
    //  2. រាល់ការធ្វើលិបិក្រមដែលយើងនឹងធ្វើគឺតែងតែរវាង {0 <= index < len} ភាគច្រើន។
    //
    // ខ។ការចម្លងការចងចាំ
    //  1. យើងកំពុងរកអ្នកចង្អុលបង្ហាញឯកសារយោងដែលធានាថាត្រឹមត្រូវ។
    //  2. ពួកគេមិនអាចត្រួតលើគ្នាបានទេពីព្រោះយើងទទួលបានចង្អុលបង្ហាញពីភាពខុសគ្នានៃចំណែក។
    //     គឺ `i` និង `i-1` ។
    //  3. ប្រសិនបើចំណិតត្រូវបានតម្រឹមត្រឹមត្រូវធាតុត្រូវបានតម្រឹមត្រឹមត្រូវ។
    //     វាគឺជាការទទួលខុសត្រូវរបស់អ្នកហៅទូរស័ព្ទដើម្បីប្រាកដថាចំណិតត្រូវបានតម្រឹមត្រឹមត្រូវ។
    //
    // សូមមើលមតិយោបល់ខាងក្រោមសម្រាប់ព័ត៌មានលម្អិតបន្ថែម។
    unsafe {
        // ប្រសិនបើធាតុពីរដំបូងគឺហួសសម័យ ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // អានធាតុទីមួយទៅជាអថេរដែលបានបែងចែកជាជង់។
            // ប្រសិនបើមានប្រតិបត្ដិការប្រៀបធៀបខាងក្រោមនេះ panics, `hole` នឹងទទួលបានធ្លាក់ចុះនិងដោយស្វ័យប្រវត្តិសរសេរត្រឡប់មកវិញចូលទៅក្នុងចំណិតធាតុ។
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // ផ្លាស់ទីធាតុទី i ទៅទីមួយទៅឆ្វេងដូច្នេះប្តូររន្ធទៅស្តាំ។
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ត្រូវបានទម្លាក់ហើយដូច្នេះចំលង `tmp` ទៅក្នុងរន្ធដែលនៅសេសសល់ក្នុង `v` ។
        }
    }
}

/// ការផ្លាស់ប្តូរធាតុចុងក្រោយទៅខាងឆ្វេងរហូតដល់វាបានជួបប្រទះធាតុតូចជាងឬស្មើបាន។
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // សុវត្ថិភាព: ប្រតិបត្តិការដែលមិនមានសុវត្ថិភាពនៅខាងក្រោមពាក់ព័ន្ធនឹងការបង្កើតលិបិក្រមដោយគ្មានការត្រួតពិនិត្យ (`get_unchecked` និង `get_unchecked_mut`)
    // និងថតចម្លងការចងចាំ (`ptr::copy_nonoverlapping`) ។
    //
    // ក។ការបង្កើតលិបិក្រម៖
    //  1. យើងពិនិត្យទំហំអារេទៅ>=២ ។
    //  2. រាល់ការធ្វើលិបិក្រមដែលយើងនឹងធ្វើគឺតែងតែរវាង `0 <= index < len-1` ភាគច្រើន។
    //
    // ខ។ការចម្លងការចងចាំ
    //  1. យើងកំពុងរកអ្នកចង្អុលបង្ហាញឯកសារយោងដែលធានាថាត្រឹមត្រូវ។
    //  2. ពួកគេមិនអាចត្រួតលើគ្នាបានទេពីព្រោះយើងទទួលបានចង្អុលបង្ហាញពីភាពខុសគ្នានៃចំណែក។
    //     គឺ `i` និង `i+1` ។
    //  3. ប្រសិនបើចំណិតត្រូវបានតម្រឹមត្រឹមត្រូវធាតុត្រូវបានតម្រឹមត្រឹមត្រូវ។
    //     វាគឺជាការទទួលខុសត្រូវរបស់អ្នកហៅទូរស័ព្ទដើម្បីប្រាកដថាចំណិតត្រូវបានតម្រឹមត្រឹមត្រូវ។
    //
    // សូមមើលមតិយោបល់ខាងក្រោមសម្រាប់ព័ត៌មានលម្អិតបន្ថែម។
    unsafe {
        // ប្រសិនបើធាតុពីរចុងក្រោយគឺហួសសម័យ ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // អានធាតុចុងក្រោយទៅជាអថេរបែងចែកតាមជង់។
            // ប្រសិនបើមានប្រតិបត្ដិការប្រៀបធៀបខាងក្រោមនេះ panics, `hole` នឹងទទួលបានធ្លាក់ចុះនិងដោយស្វ័យប្រវត្តិសរសេរត្រឡប់មកវិញចូលទៅក្នុងចំណិតធាតុ។
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // ផ្លាស់ទីធាតុទី i ទៅទីមួយទៅស្តាំដូច្នេះប្តូររន្ធទៅខាងឆ្វេង។
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` ត្រូវបានទម្លាក់ហើយដូច្នេះចំលង `tmp` ទៅក្នុងរន្ធដែលនៅសេសសល់ក្នុង `v` ។
        }
    }
}

/// តម្រៀបផ្នែកខ្លះដោយផ្លាស់ប្តូរធាតុក្រៅលំដាប់ជាច្រើនជុំវិញ។
///
/// ត្រឡប់ `true` ប្រសិនបើចំណិតត្រូវបានតម្រៀបនៅចុងបញ្ចប់។មុខងារនេះគឺ *O*(*n*) ដែលអាក្រក់បំផុត។
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // ចំនួនអតិបរមានៃគូក្រៅលំដាប់ដែលនៅជិតគ្នាដែលនឹងត្រូវផ្លាស់ប្តូរ។
    const MAX_STEPS: usize = 5;
    // ប្រសិនបើចំណិតខ្លីជាងនេះកុំប្តូរធាតុណាមួយ។
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // សុវត្ថិភាព: យើងបានធ្វើការត្រួតពិនិត្យយ៉ាងច្បាស់ជាមួយ `i < len` រួចហើយ។
        // ការធ្វើលិបិក្រមជាបន្តបន្ទាប់របស់យើងគឺមានតែនៅក្នុងជួរ `0 <= index < len` ប៉ុណ្ណោះ
        unsafe {
            // ស្វែងរកគូបន្ទាប់នៃធាតុក្រៅលំដាប់ដែលនៅជាប់គ្នា។
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // តើយើងបានធ្វើហើយឬនៅ?
        if i == len {
            return true;
        }

        // កុំផ្លាស់ប្តូរធាតុនៅលើអារេខ្លីដែលត្រូវចំណាយថ្លៃដើម។
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // ប្តូរគូដែលរកឃើញនៃធាតុ។នេះធ្វើឱ្យពួកគេស្ថិតក្នុងលំដាប់ត្រឹមត្រូវ។
        v.swap(i - 1, i);

        // ផ្លាស់ប្តូរធាតុតូចជាងមុនទៅខាងឆ្វេង។
        shift_tail(&mut v[..i], is_less);
        // ផ្លាស់ប្តូរធាតុធំជាងនៅខាងស្តាំ។
        shift_head(&mut v[i..], is_less);
    }

    // មិនបានគ្រប់គ្រងដើម្បីតម្រៀបចំណែកក្នុងចំនួនជំហានមានកំណត់។
    false
}

/// តម្រៀបចំណិត ៗ ដោយប្រើតម្រៀបបញ្ចូលដែលជាករណីអន់បំផុត *O*(*n*^ ២) ។
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// តម្រៀប `v` ដោយប្រើ heapsort ដែលធានាថា *O*(*n*\*log(* n*))-ជាករណីអាក្រក់បំផុត) ។
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // គំនរគោលពីរនេះគោរព `parent >= child` ដែលមិនចេះរីងស្ងួត។
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // កុមារ `node`៖
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // ជ្រើសរើសកូនដែលធំជាង។
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // បញ្ឈប់ប្រសិនបើការលុកលុយកាន់កាប់នៅ `node` ។
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // ប្តូរ `node` ជាមួយកូនធំ ៗ ផ្លាស់មួយជំហានទៅមុខហើយបន្តទៅមុខទៀត។
            v.swap(node, greater);
            node = greater;
        }
    };

    // កសាងគំនរតាមពេលវេលាលីនេអ៊ែរ។
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // ធាតុអតិបរិមាពីគំនរ។
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// ភាគថាស `v` ទៅជាធាតុតូចជាង `pivot` បន្ទាប់មកមានធាតុធំជាងឬស្មើ `pivot` ។
///
///
/// ត្រឡប់ចំនួនធាតុដែលតូចជាង `pivot` ។
///
/// ចែកភាគថាសត្រូវបានអនុវត្តប្លុកដោយប្លុកក្នុងគោលបំណងដើម្បីកាត់បន្ថយការចំណាយនៃ branching ប្រតិបត្តិការ។
/// គំនិតនេះត្រូវបានបង្ហាញនៅក្នុងក្រដាស [BlockQuicksort][pdf] ។
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ចំនួនធាតុនៅក្នុងប្លុកធម្មតា។
    const BLOCK: usize = 128;

    // ក្បួនដោះស្រាយការបែងចែកធ្វើឡើងវិញនូវជំហានដូចខាងក្រោមរហូតដល់ពេលបញ្ចប់៖
    //
    // 1. តាមដានប្លុកពីផ្នែកខាងឆ្វេងដើម្បីកំណត់ធាតុធំជាងឬស្មើទៅនឹងអ្នកជំនួយការ។
    // 2. តាមដានប្លុកពីជ្រុងខាងស្តាំដើម្បីកំណត់ធាតុតូចជាងអ្នកជំនួយការ។
    // 3. ផ្លាស់ប្តូរធាតុដែលបានកំណត់រវាងផ្នែកខាងឆ្វេងនិងខាងស្តាំ។
    //
    // យើងរក្សាទុកអថេរដូចខាងក្រោមសម្រាប់ប្លុកនៃធាតុមួយ:
    //
    // 1. `block` - ចំនួនធាតុនៅក្នុងប្លុក។
    // 2. `start` - ចាប់ផ្តើមទ្រនិចចូលទៅក្នុងអារេ `offsets` ។
    // 3. `end` - បញ្ចប់ទ្រនិចចូលទៅក្នុងអារេ `offsets` ។
    // 4. `អុហ្វសិត, សន្ទស្សន៍នៃធាតុក្រៅលំដាប់នៅក្នុងប្លុក។

    // ប្លុកបច្ចុប្បន្ននៅខាងឆ្វេង (ពី `l` ដល់ `l.add(block_l)`) ។
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // ប្លុកបច្ចុប្បន្ននៅផ្នែកខាងស្តាំ (ពី `r.sub(block_r)` to `r`) ។
    // សុវត្ថិភាព: ឯកសារសម្រាប់ .add() បញ្ជាក់យ៉ាងច្បាស់ថា `vec.as_ptr().add(vec.len())` គឺតែងតែមានសុវត្ថិភាព
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: នៅពេលដែលយើងទទួលបាន VLAs សូមព្យាយាមបង្កើតអារេមួយដែលមានប្រវែង `min(v.len(), 2 * ប្លុក) `ជាជាង
    // ជាងអារេទំហំថេរពីរនៃប្រវែង `BLOCK` ។VLAs អាចមានប្រសិទ្ធិភាពក្នុងការតំឡើងឃ្លាំងសម្ងាត់។

    // ត្រឡប់ចំនួនធាតុរវាងព្រួញ `l` (inclusive) និង `r` (exclusive) នេះ។
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // យើងត្រូវបានធ្វើរួចជាមួយការចែកភាគថាសដោយប្លុកនៅពេល `l` និង `r` ជិតគ្នា។
        // បន្ទាប់មកយើងបានធ្វើការងារមួយចំនួនបំណះឡើងដើម្បីចែកភាគថាសក្នុងធាតុនៅសល់នៅក្នុងរវាង។
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // ចំនួនធាតុដែលនៅសេសសល់ (នៅតែមិនប្រៀបធៀបនឹងអ្នកជំនួយការ) ។
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // លៃតម្រូវទំហំប្លុកដូច្នេះប្លុកខាងឆ្វេងនិងខាងស្តាំមិនជាន់គ្នាប៉ុន្តែត្រូវតម្រឹមយ៉ាងល្អឥតខ្ចោះដើម្បីគ្របដណ្ដប់លើគម្លាតដែលនៅសល់។
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // តាមដានធាតុ `block_l` ពីផ្នែកខាងឆ្វេង។
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // សុវត្ថិភាព: ការប្រតិបត្ដិការ unsafety ខាងក្រោមការប្រើប្រាស់ `offset` ការចូលរួមនេះ។
                //         យោងទៅតាមល័ក្ខខ័ណ្ឌដែលតំរូវដោយមុខងារនេះយើងបំពេញឱ្យពួកគេពីព្រោះ
                //         1. `offsets_l` ត្រូវបានបែងចែកជាជង់ហើយដូច្នេះចាត់ទុកវត្ថុដែលបានបម្រុងទុកដាច់ដោយឡែក។
                //         2. មុខងារ `is_less` ត្រឡប់ `bool` ។
                //            ការបោះ `bool` នឹងមិនដែលហួសចំណុះ `isize` ឡើយ។
                //         3. យើងបានធានាថា `block_l` នឹងក្លាយជា `<= BLOCK` ។
                //            លើសពីនេះទៀត `end_l` ត្រូវបានកំណត់ដំបូងទៅនឹងទ្រនិចដំបូងនៃ `offsets_` ដែលត្រូវបានប្រកាសនៅលើជង់។
                //            ដូច្នេះយើងដឹងថាសូម្បីតែក្នុងករណីដ៏អាក្រក់បំផុត (រាល់ការអញ្ជើញរបស់ `is_less` មិនពិតទេ) យើងនឹងត្រូវឆ្លងកាត់យ៉ាងហោចណាស់ ១ បៃ។
                //        ប្រតិបត្តិការដែលមិនមានសុវត្ថិភាពមួយទៀតនៅទីនេះគឺការដកហូត `elem` ។
                //        ទោះយ៉ាងណា `elem` ដំបូងឡើយគឺជាអ្នកចាប់ផ្តើមចង្អុលទៅចំណិតដែលតែងតែមានសុពលភាព។
                unsafe {
                    // ការប្រៀបធៀបសាខា។
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // តាមដានធាតុ `block_r` ពីផ្នែកខាងស្តាំ។
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // សុវត្ថិភាព: ការប្រតិបត្ដិការ unsafety ខាងក្រោមការប្រើប្រាស់ `offset` ការចូលរួមនេះ។
                //         យោងទៅតាមល័ក្ខខ័ណ្ឌដែលតំរូវដោយមុខងារនេះយើងបំពេញឱ្យពួកគេពីព្រោះ
                //         1. `offsets_r` ត្រូវបានបែងចែកជាជង់ហើយដូច្នេះចាត់ទុកវត្ថុដែលបានបម្រុងទុកដាច់ដោយឡែក។
                //         2. មុខងារ `is_less` ត្រឡប់ `bool` ។
                //            ការបោះ `bool` នឹងមិនដែលហួសចំណុះ `isize` ឡើយ។
                //         3. យើងបានធានាថា `block_r` នឹងក្លាយជា `<= BLOCK` ។
                //            លើសពីនេះទៀត `end_r` ត្រូវបានកំណត់ដំបូងទៅនឹងទ្រនិចដំបូងនៃ `offsets_` ដែលត្រូវបានប្រកាសនៅលើជង់។
                //            ដូច្នេះយើងដឹងថាសូម្បីតែក្នុងករណីដ៏អាក្រក់បំផុត (រាល់ការអញ្ជើញរបស់ `is_less` ត្រលប់មកវិញជាការពិត) យើងនឹងត្រូវឆ្លងកាត់តែ ១ បៃនៅចុងបញ្ចប់ប៉ុណ្ណោះ។
                //        ប្រតិបត្តិការដែលមិនមានសុវត្ថិភាពមួយទៀតនៅទីនេះគឺការដកហូត `elem` ។
                //        ទោះយ៉ាងណា `elem` ដំបូងគឺ `1 *sizeof(T)` ឆ្លងកាត់ចុងបញ្ចប់ហើយយើងបន្ថយវាដោយ `1* sizeof(T)` មុនពេលចូលប្រើវា។
                //        លើសពីនេះទៀត `block_r` ត្រូវបានគេអះអាងថាមានទំហំតូចជាង `BLOCK` ហើយដូច្នេះ `elem` នឹងត្រូវបានចង្អុលទៅចំណុចចាប់ផ្តើមដំបូង។
                unsafe {
                    // ការប្រៀបធៀបសាខា។
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // ចំនួនធាតុដែលគ្មានលំដាប់ដើម្បីប្តូររវាងផ្នែកខាងឆ្វេងនិងខាងស្តាំ។
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // ជំនួសឱ្យការផ្លាស់ប្តូរគូមួយនៅពេលនោះវាមានប្រសិទ្ធភាពជាងក្នុងការអនុញ្ញាតិឱ្យជិះកង់។
            // នេះមិនស្មើនឹងការដោះដូរដាច់ខាតទេប៉ុន្តែបង្កើតលទ្ធផលស្រដៀងគ្នាដោយប្រើប្រតិបត្តិការមេម៉ូរីតិច។
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // រាល់ធាតុដែលមិនមានលំដាប់នៅក្នុងប្លុកខាងឆ្វេងត្រូវបានផ្លាស់ប្តូរ។ផ្លាស់ទីទៅប្លុកបន្ទាប់។
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // រាល់ធាតុដែលមិនមានលំដាប់នៅក្នុងប្លុកខាងស្តាំត្រូវបានផ្លាស់ប្តូរ។ផ្លាស់ទីទៅប្លុកមុន។
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // អ្វីៗទាំងអស់ដែលនៅសល់នៅពេលនេះគឺមានតែមួយប្លុក (ទាំងខាងឆ្វេងឬខាងស្តាំ) ដែលមានធាតុក្រៅលំដាប់ដែលត្រូវការផ្លាស់ទី។
    // ធាតុដែលនៅសេសសល់បែបនេះអាចត្រូវបានផ្លាស់ប្តូរយ៉ាងសាមញ្ញរហូតដល់ទីបញ្ចប់នៅក្នុងប្លុករបស់ពួកគេ។
    //

    if start_l < end_l {
        // ប្លុកខាងឆ្វេងនៅសល់។
        // ផ្លាស់ទីធាតុក្រៅលំដាប់ដែលនៅសេសសល់ទៅផ្នែកខាងស្តាំ។
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // ប្លុកខាងស្តាំនៅសល់។
        // ផ្លាស់ទីធាតុក្រៅលំដាប់ដែលនៅសេសសល់ទៅខាងឆ្វេង។
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // មិនមានអ្វីផ្សេងទៀតដែលត្រូវធ្វើទេយើងបានធ្វើរួច។
        width(v.as_mut_ptr(), l)
    }
}

/// ភាគថាស `v` ទៅជាធាតុតូចជាង `v[pivot]` បន្ទាប់មកមានធាតុធំជាងឬស្មើ `v[pivot]` ។
///
///
/// ត្រឡប់ការសិក្សារបស់៖
///
/// 1. ចំនួនធាតុតូចជាង `v[pivot]` ។
/// 2. ពិតប្រសិនបើ `v` ត្រូវបានបែងចែករួចហើយ។
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // ដាក់ទ្រនិចនៅដើមចំណិត។
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // អានទ្រឹស្តីទៅជាអថេរបែងចែកតាមជង់ដើម្បីប្រសិទ្ធភាព។
        // ប្រសិនបើប្រតិបត្ដិការប្រៀបធៀបដូចខាងក្រោម panics នោះអ្នកជំនួយការទិន្នន័យនឹងត្រូវបានសរសេរដោយស្វ័យប្រវត្តិចូលទៅក្នុងចំណិត។
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // ស្វែងរកគូដំបូងនៃធាតុដែលមិនមានលំដាប់។
        let mut l = 0;
        let mut r = v.len();

        // សុវត្ថិភាព: សុវត្ថភាពនៅខាងក្រោមពាក់ព័ន្ធនឹងការធ្វើតារាងអារេ។
        // សម្រាប់ទីមួយ: យើងធ្វើការត្រួតពិនិត្យនៅទីនេះជាមួយ `l < r` រួចហើយ។
        // សម្រាប់លើកទីពីរ៖ ដំបូងយើងមាន `l == 0` និង `r == v.len()` ហើយយើងបានពិនិត្យមើលថា `l < r` នៅរាល់ប្រតិបត្តិការលិបិក្រម។
        //                     ពីទីនេះយើងដឹងថា `r` ត្រូវតែមានយ៉ាងហោចណាស់ `r == l` ដែលត្រូវបានបង្ហាញថាមានសុពលភាពពីលេខដំបូង។
        unsafe {
            // រកធាតុទីមួយធំជាងឬស្មើទៅនឹងអ្នកជំនួយការ។
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // រកធាតុចុងក្រោយដែលតូចជាងមុនដែលជាស្នូល។
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` ចេញពីវិសាលភាពហើយសរសេរអ្នកជំនួយការ (ដែលជាអថេរបែងចែកជាជង់) ត្រឡប់ទៅជាចំណែកដែលវាមានដើម។
        // ជំហាននេះមានសារៈសំខាន់ណាស់ក្នុងការធានាសុវត្ថិភាព!
        //
    };

    // ដាក់ទ្រនិចនៅចន្លោះភាគថាសទាំងពីរ។
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// ភាគថាស `v` ទៅជាធាតុស្មើនឹង `v[pivot]` អមដោយធាតុធំជាង `v[pivot]` ។
///
/// ត្រឡប់ចំនួនធាតុស្មើនឹងអ្នកជំនួយការទិន្នន័យ។
/// សន្មតថា `v` មិនមានធាតុតូចជាងអ្នកជំនួយការ។
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // ដាក់ទ្រនិចនៅដើមចំណិត។
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // អានទ្រឹស្តីទៅជាអថេរបែងចែកតាមជង់ដើម្បីប្រសិទ្ធភាព។
    // ប្រសិនបើប្រតិបត្ដិការប្រៀបធៀបដូចខាងក្រោម panics នោះអ្នកជំនួយការទិន្នន័យនឹងត្រូវបានសរសេរដោយស្វ័យប្រវត្តិចូលទៅក្នុងចំណិត។
    // សុវត្ថិភាព: ទ្រនិចនៅទីនេះមានសុពលភាពពីព្រោះវាទទួលបានពីឯកសារយោងមួយទៅចំណិតមួយ។
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // ឥឡូវចែកជាចំណែក ៗ ។
    let mut l = 0;
    let mut r = v.len();
    loop {
        // សុវត្ថិភាព: សុវត្ថភាពនៅខាងក្រោមពាក់ព័ន្ធនឹងការធ្វើតារាងអារេ។
        // សម្រាប់ទីមួយ: យើងធ្វើការត្រួតពិនិត្យនៅទីនេះជាមួយ `l < r` រួចហើយ។
        // សម្រាប់លើកទីពីរ៖ ដំបូងយើងមាន `l == 0` និង `r == v.len()` ហើយយើងបានពិនិត្យមើលថា `l < r` នៅរាល់ប្រតិបត្តិការលិបិក្រម។
        //                     ពីទីនេះយើងដឹងថា `r` ត្រូវតែមានយ៉ាងហោចណាស់ `r == l` ដែលត្រូវបានបង្ហាញថាមានសុពលភាពពីលេខដំបូង។
        unsafe {
            // រកធាតុទីមួយធំជាងអ្នកជំនួយការ។
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // រកឃើញធាតុចុងក្រោយស្មើទៅនឹងជំនួយការទិន្នន័យ។
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // តើយើងបានធ្វើហើយឬនៅ?
            if l >= r {
                break;
            }

            // ប្តូរគូដែលរកឃើញនៃធាតុដែលគ្មានលំដាប់។
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // យើងបានរកឃើញធាតុ `l` ស្មើនឹងឧបករណ៍ជំនួយ។បន្ថែមលេខ ១ ទៅក្នុងគណនីសម្រាប់អ្នកជំនួយការផ្ទាល់។
    l + 1

    // `_pivot_guard` ចេញពីវិសាលភាពហើយសរសេរអ្នកជំនួយការ (ដែលជាអថេរបែងចែកជាជង់) ត្រឡប់ទៅជាចំណែកដែលវាមានដើម។
    // ជំហាននេះមានសារៈសំខាន់ណាស់ក្នុងការធានាសុវត្ថិភាព!
}

/// បំបែកធាតុមួយចំនួននៅជុំវិញក្នុងការប៉ុនប៉ងដើម្បីបំបែកលំនាំដែលអាចបណ្តាលឱ្យមានភាគថាសអតុល្យភាពនៅក្នុងការពន្លឿន។
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // ម៉ាស៊ីនភ្លើងលេខ Pseudorandom ពីក្រដាស "Xorshift RNGs" ដោយ George Marsaglia ។
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // យកលេខចៃដន្យកែប្រែលេខនេះ។
        // លេខត្រូវនឹង `usize` ព្រោះ `len` មិនធំជាង `isize::MAX` ទេ។
        let modulus = len.next_power_of_two();

        // បេក្ខជនជំនួយការខ្លះនឹងស្ថិតនៅក្បែរសន្ទស្សន៍នេះ។ចូរចៃដន្យពួកគេ។
        let pos = len / 4 * 2;

        for i in 0..3 {
            // បង្កើតម៉ូឌុលលេខចៃដន្យ `len` ។
            // ទោះយ៉ាងណាក៏ដោយដើម្បីជៀសវាងប្រតិបត្តិការថ្លៃដើមដំបូងយើងយកម៉ូឌុលដែលមានថាមពលពីរហើយបន្ទាប់មកបន្ថយដោយ `len` រហូតដល់វាសមនឹងជួរ `[0, len - 1]` ។
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` ត្រូវបានធានាថាតិចជាង `2 * len` ។
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// ជ្រើសរើសអ្នកជំនួយការក្នុង `v` ហើយត្រឡប់លិបិក្រមនិង `true` ប្រសិនបើចំណែកទំនងជាត្រូវបានតម្រៀបរួចហើយ។
///
/// ធាតុនៅក្នុង `v` អាចត្រូវបានកំណត់ឡើងវិញនៅក្នុងដំណើរការ។
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // ប្រវែងអប្បបរមាដើម្បីជ្រើសរើសវិធីសាស្ត្រមេដ្យានមធ្យម។
    // ចំណិតខ្លីប្រើវិធីសាស្រ្តមធ្យម ៣ ។
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // ចំនួនអតិបរមានៃការប្តូរដែលអាចត្រូវបានអនុវត្តនៅក្នុងមុខងារនេះ។
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // សូចនាករបីនៅជិតដែលយើងនឹងជ្រើសរើសយកអ្នកជំនួយការ។
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // រាប់ចំនួនសរុបនៃការផ្លាស់ប្តូរដែលយើងរៀបនឹងធ្វើខណៈពេលកំពុងតម្រៀបសន្ទស្សន៍។
    let mut swaps = 0;

    if len >= 8 {
        // ប្តូរសន្ទស្សន៍ដូច្នេះ `v[a] <= v[b]` ។
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // ប្តូរសន្ទស្សន៍ដូច្នេះ `v[a] <= v[b] <= v[c]` ។
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // រកមេដ្យាន `v[a - 1], v[a], v[a + 1]` ហើយរក្សាទុកលិបិក្រមទៅជា `a` ។
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // ស្វែងរកមេដាយនៅតាមសង្កាត់ `a`, `b` និង `c` ។
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // ស្វែងរកមេដ្យានក្នុងចំណោម `a`, `b` និង `c` ។
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // ចំនួនអតិបរមានៃការប្តូរត្រូវបានអនុវត្ត។
        // ឱកាសគឺជាចំណែកកំពុងចុះឬភាគច្រើនកំពុងធ្លាក់ចុះដូច្នេះការត្រលប់មកវិញប្រហែលជានឹងជួយតម្រង់វាលឿនជាងមុន។
        v.reverse();
        (len - 1 - b, true)
    }
}

/// តម្រៀប `v` ម្តងហើយម្តងទៀត។
///
/// ប្រសិនបើចំណិតមានអ្នកកាន់តំណែងមុននៅក្នុងជួរដើមវាត្រូវបានបញ្ជាក់ជា `pred` ។
///
/// `limit` ជាចំនួននៃភាគថាសដែលមិនមានតុល្យភាពមុនពេលប្តូរទៅ `heapsort` ។
/// ប្រសិនបើសូន្យមុខងារនេះភ្លាមៗនឹងប្តូរទៅជាហ៊ាហ្វដ។
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // ចំណិតរហូតដល់ប្រវែងនេះត្រូវបានតម្រៀបដោយប្រើតម្រៀបបញ្ចូល។
    const MAX_INSERTION: usize = 20;

    // ពិតប្រសិនបើការបែងចែកចុងក្រោយមានតុល្យភាពសមហេតុផល។
    let mut was_balanced = true;
    // ពិតប្រសិនបើការបែងចែកចុងក្រោយមិនរលត់ធាតុ (ចំណែកត្រូវបានចែកជាស្រេច) ។
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // ចំណិតខ្លីបំផុតទទួលបានតម្រៀបដោយប្រើតម្រៀបបញ្ចូល។
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ប្រសិនបើមានជម្រើសអ្នកជំនួយការមិនល្អច្រើនពេកអ្នកគ្រាន់តែត្រឡប់ទៅជំហ៊ាន ៗ ដើម្បីធានាបាននូវករណីដ៏អាក្រក់បំផុត។
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // ប្រសិនបើការចែកភាគថាសចុងក្រោយមិនមានតុល្យភាពព្យាយាមបំបែកលំនាំនៅក្នុងចំណិត ៗ ដោយច្របាច់ធាតុមួយចំនួននៅជុំវិញ។
        // សង្ឃឹមថាយើងនឹងជ្រើសរើសយកគំរូជំនួយល្អជាងនេះនៅពេលនេះ។
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // ជ្រើសរើសអ្នកជំនួយការហើយព្យាយាមទាយថាតើចំណិតត្រូវបានតម្រៀបរួចហើយឬនៅ។
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // ប្រសិនបើការចែកភាគថាសចុងក្រោយមានតុល្យភាពត្រឹមត្រូវនិងមិនរុះរើធាតុហើយប្រសិនបើការជ្រើសរើសអ្នកទស្សន៍ទាយទាយថាបំណែកទំនងជាត្រូវបានតម្រៀបរួចហើយ ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // ព្យាយាមកំណត់អត្តសញ្ញាណធាតុក្រៅលំដាប់ជាច្រើនហើយប្តូរវាទៅទីតាំងត្រឹមត្រូវ។
            // ប្រសិនបើចំណិតបញ្ចប់ត្រូវបានតម្រៀបទាំងស្រុងយើងបានធ្វើរួច។
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // ប្រសិនបើអ្នកជំនួយការដែលបានជ្រើសរើសស្មើទៅនឹងអ្នកកាន់តំណែងមុនបន្ទាប់មកវាជាធាតុតូចជាងគេបំផុត។
        // ចែកភាគថាសចូលទៅក្នុងធាតុចំណែកស្មើទៅនិងធាតុធំជាងជំនួយការទិន្នន័យ។
        // ករណីនេះជាធម្មតាត្រូវបានគេវាយនៅពេលដែលចំណិតមានធាតុស្ទួនជាច្រើន។
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // បន្តតម្រៀបធាតុធំជាងស្នូលជំនួយ។
                v = &mut { v }[mid..];
                continue;
            }
        }

        // ចែកជាចំណែក ៗ ។
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // បំបែកចំណិត ៗ ទៅជា `left`, `pivot` និង `right` ។
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // គិលានុបដ្ឋាយិកាចូលទៅផ្នែកខាងខ្លីតែប៉ុណ្ណោះដើម្បីកាត់បន្ថយចំនួនសរុបនៃការហៅទូរស័ព្ទឡើងវិញនិងប្រើប្រាស់កន្លែងទំនេរតិច។
        // បន្ទាប់មកគ្រាន់តែបន្តជាមួយផ្នែកវែងជាងនេះ (នេះគឺស្រដៀងនឹងការហៅកន្ទុយឡើងវិញ) ។
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// តម្រៀប `v` ការប្រើ quicksort គំរូដែលត្រូវបានផ្តួលដែលជា *ឱ*(*n*\*log(* n*)) អាក្រក់បំផុតករណី។
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ការតម្រៀបមិនមានអាកប្បកិរិយាដែលមានអត្ថន័យលើប្រភេទដែលមានទំហំសូន្យទេ។
    if mem::size_of::<T>() == 0 {
        return;
    }

    // កំណត់ចំនួនភាគថាសដែលមិនមានតុល្យភាពដល់ `floor(log2(len)) + 1` ។
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // សម្រាប់ចំណិតនៃប្រវែងរហូតដល់ប្រវែងនេះប្រហែលជាលឿនជាងក្នុងការតម្រៀបពួកវា។
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // ជ្រើសរើសអ្នកជំនួយការ
        let (pivot, _) = choose_pivot(v, is_less);

        // ប្រសិនបើអ្នកជំនួយការដែលបានជ្រើសរើសស្មើទៅនឹងអ្នកកាន់តំណែងមុនបន្ទាប់មកវាជាធាតុតូចជាងគេបំផុត។
        // ចែកភាគថាសចូលទៅក្នុងធាតុចំណែកស្មើទៅនិងធាតុធំជាងជំនួយការទិន្នន័យ។
        // ករណីនេះជាធម្មតាត្រូវបានគេវាយនៅពេលដែលចំណិតមានធាតុស្ទួនជាច្រើន។
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // ប្រសិនបើយើងបានឆ្លងកាត់សន្ទស្សន៍របស់យើងនោះយើងល្អ។
                if mid > index {
                    return;
                }

                // បើមិនដូច្នោះទេបន្តការតម្រៀបធាតុធំជាងស្នូលជំនួយ។
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // បំបែកចំណិត ៗ ទៅជា `left`, `pivot` និង `right` ។
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // ប្រសិនបើពាក់កណ្តាល=សន្ទស្សន៍បន្ទាប់មកយើងបានធ្វើហើយចាប់តាំងពី partition() បានធានាថាធាតុទាំងអស់បន្ទាប់ពីពាក់កណ្តាលគឺធំជាងឬស្មើពាក់កណ្តាល។
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // ការតម្រៀបមិនមានអាកប្បកិរិយាដែលមានអត្ថន័យលើប្រភេទដែលមានទំហំសូន្យទេ។កុំធ្វើអ្វីទាំងអស់។
    } else if index == v.len() - 1 {
        // រកធាតុអតិបរិមាហើយដាក់វានៅទីតាំងចុងក្រោយនៃអារេ។
        // យើងឥតគិតថ្លៃប្រើ `unwrap()` នៅទីនេះពីព្រោះយើងដឹងថា v មិនត្រូវទទេទេ។
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // រកធាតុអប្បបរមាហើយដាក់វានៅទីតាំងដំបូងនៃអារេ។
        // យើងឥតគិតថ្លៃប្រើ `unwrap()` នៅទីនេះពីព្រោះយើងដឹងថា v មិនត្រូវទទេទេ។
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}