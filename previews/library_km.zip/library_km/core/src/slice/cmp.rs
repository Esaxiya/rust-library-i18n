//! ការប្រៀបធៀប traits សម្រាប់ `[T]` ។

use crate::cmp;
use crate::cmp::Ordering::{self, Greater, Less};
use crate::mem;

use super::from_raw_parts;
use super::memchr;

extern "C" {
    /// ការអនុវត្តការហៅទូរស័ព្ទបានផ្តល់នូវអនុស្សរណៈ។
    ///
    /// បកស្រាយទិន្នន័យជា u8 ។
    ///
    /// ត្រឡប់ 0 សម្រាប់ស្មើ <0 សម្រាប់តិចជាងនិង> 0 សម្រាប់ធំជាង។
    ///
    // FIXME(#32610): ប្រភេទត្រឡប់មកវិញគួរតែជា c_int
    fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> PartialEq<[B]> for [A]
where
    A: PartialEq<B>,
{
    fn eq(&self, other: &[B]) -> bool {
        SlicePartialEq::equal(self, other)
    }

    fn ne(&self, other: &[B]) -> bool {
        SlicePartialEq::not_equal(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for [T] {}

/// អនុវត្តការប្រៀបធៀបនៃ vectors [lexicographically](Ord#lexicographical-comparison) ។
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for [T] {
    fn cmp(&self, other: &[T]) -> Ordering {
        SliceOrd::compare(self, other)
    }
}

/// អនុវត្តការប្រៀបធៀបនៃ vectors [lexicographically](Ord#lexicographical-comparison) ។
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for [T] {
    fn partial_cmp(&self, other: &[T]) -> Option<Ordering> {
        SlicePartialOrd::partial_compare(self, other)
    }
}

#[doc(hidden)]
// trait កម្រិតមធ្យមសម្រាប់ជំនាញនៃផ្នែកខ្លះនៃអេច
trait SlicePartialEq<B> {
    fn equal(&self, other: &[B]) -> bool;

    fn not_equal(&self, other: &[B]) -> bool {
        !self.equal(other)
    }
}

// សមភាពទូទៅ
impl<A, B> SlicePartialEq<B> for [A]
where
    A: PartialEq<B>,
{
    default fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        self.iter().zip(other.iter()).all(|(x, y)| x == y)
    }
}

// ប្រើ Memcmp ដើម្បីភាពស្មើគ្នាតាមលំដាប់នៅពេលប្រភេទទាំងនោះអនុញ្ញាតិ
impl<A, B> SlicePartialEq<B> for [A]
where
    A: BytewiseEquality<B>,
{
    fn equal(&self, other: &[B]) -> bool {
        if self.len() != other.len() {
            return false;
        }

        // សុវត្ថិភាព: `self` និង `other` គឺជាឯកសារយោងហើយដូច្នេះត្រូវបានធានាថាមានសុពលភាព។
        // ចំណិតទាំងពីរត្រូវបានពិនិត្យថាមានទំហំដូចខាងលើ។
        unsafe {
            let size = mem::size_of_val(self);
            memcmp(self.as_ptr() as *const u8, other.as_ptr() as *const u8, size) == 0
        }
    }
}

#[doc(hidden)]
// trait កម្រិតមធ្យមសម្រាប់ជំនាញនៃផ្នែកខ្លះនៃអូល
trait SlicePartialOrd: Sized {
    fn partial_compare(left: &[Self], right: &[Self]) -> Option<Ordering>;
}

impl<A: PartialOrd> SlicePartialOrd for A {
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        let l = cmp::min(left.len(), right.len());

        // កាត់ទៅជួររង្វាស់រង្វិលជុំដើម្បីបើកការលុបបំបាត់ការត្រួតពិនិត្យដែលចងក្នុងកម្មវិធីចងក្រង
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].partial_cmp(&rhs[i]) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }

        left.len().partial_cmp(&right.len())
    }
}

// នេះគឺជាន័យដែលយើងចង់បាន។ជាអកុសលវាមិនសម។
// មើល `partial_ord_slice.rs` ។
/*
impl<A> SlicePartialOrd for A
where
    A: Ord,
{
    default fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}
*/

impl<A: AlwaysApplicableOrd> SlicePartialOrd for A {
    fn partial_compare(left: &[A], right: &[A]) -> Option<Ordering> {
        Some(SliceOrd::compare(left, right))
    }
}

#[rustc_specialization_trait]
trait AlwaysApplicableOrd: SliceOrd + Ord {}

macro_rules! always_applicable_ord {
    ($([$($p:tt)*] $t:ty,)*) => {
        $(impl<$($p)*> AlwaysApplicableOrd for $t {})*
    }
}

always_applicable_ord! {
    [] u8, [] u16, [] u32, [] u64, [] u128, [] usize,
    [] i8, [] i16, [] i32, [] i64, [] i128, [] isize,
    [] bool, [] char,
    [T: ?Sized] *const T, [T: ?Sized] *mut T,
    [T: AlwaysApplicableOrd] &T,
    [T: AlwaysApplicableOrd] &mut T,
    [T: AlwaysApplicableOrd] Option<T>,
}

#[doc(hidden)]
// trait កម្រិតមធ្យមសម្រាប់ជំនាញនៃអ័រដាប់ប៊ល
trait SliceOrd: Sized {
    fn compare(left: &[Self], right: &[Self]) -> Ordering;
}

impl<A: Ord> SliceOrd for A {
    default fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let l = cmp::min(left.len(), right.len());

        // កាត់ទៅជួររង្វាស់រង្វិលជុំដើម្បីបើកការលុបបំបាត់ការត្រួតពិនិត្យដែលចងក្នុងកម្មវិធីចងក្រង
        //
        let lhs = &left[..l];
        let rhs = &right[..l];

        for i in 0..l {
            match lhs[i].cmp(&rhs[i]) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }

        left.len().cmp(&right.len())
    }
}

// memcmp ប្រៀបធៀបលំដាប់បៃដែលមិនបានចុះហត្ថលេខាជាសូរស័ព្ទ។
// នេះត្រូវនឹងលំដាប់ដែលយើងចង់បានសម្រាប់ [u8] ប៉ុន្តែមិនមានអ្វីផ្សេងទៀតទេ (មិនសូម្បីតែ [i8]) ។
impl SliceOrd for u8 {
    #[inline]
    fn compare(left: &[Self], right: &[Self]) -> Ordering {
        let order =
            // សុវត្ថិភាព: `left` និង `right` គឺជាឯកសារយោងហើយដូច្នេះត្រូវបានធានាថាមានសុពលភាព។
            // យើងប្រើអប្បបរមានៃប្រវែងទាំងពីរដែលធានាថាតំបន់ទាំងពីរមានសុពលភាពសម្រាប់អានក្នុងចន្លោះពេលនោះ។
            //
            unsafe { memcmp(left.as_ptr(), right.as_ptr(), cmp::min(left.len(), right.len())) };
        if order == 0 {
            left.len().cmp(&right.len())
        } else if order < 0 {
            Less
        } else {
            Greater
        }
    }
}

// Hack ដើម្បីអនុញ្ញាតឱ្យមានជំនាញលើ `Eq` ទោះបីជា `Eq` មានវិធីសាស្ត្រក៏ដោយ។
#[rustc_unsafe_specialization_marker]
trait MarkerEq<T>: PartialEq<T> {}

impl<T: Eq> MarkerEq<T> for T {}

#[doc(hidden)]
/// Trait ត្រូវបានអនុវត្តសម្រាប់ប្រភេទដែលអាចត្រូវបានប្រៀបធៀបសម្រាប់ភាពស្មើគ្នាដោយប្រើតំណាងផ្ទុយគ្នារបស់ពួកគេ
///
#[rustc_specialization_trait]
trait BytewiseEquality<T>: MarkerEq<T> + Copy {}

macro_rules! impl_marker_for {
    ($traitname:ident, $($ty:ty)*) => {
        $(
            impl $traitname<$ty> for $ty { }
        )*
    }
}

impl_marker_for!(BytewiseEquality,
                 u8 i8 u16 i16 u32 i32 u64 i64 u128 i128 usize isize char bool);

pub(super) trait SliceContains: Sized {
    fn slice_contains(&self, x: &[Self]) -> bool;
}

impl<T> SliceContains for T
where
    T: PartialEq,
{
    default fn slice_contains(&self, x: &[Self]) -> bool {
        x.iter().any(|y| *y == *self)
    }
}

impl SliceContains for u8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        memchr::memchr(*self, x).is_some()
    }
}

impl SliceContains for i8 {
    #[inline]
    fn slice_contains(&self, x: &[Self]) -> bool {
        let byte = *self as u8;
        // សុវត្ថិភាព: `i8` និង `u8` មានប្លង់មេម៉ូរីដូចគ្នាដូច្នេះការបោះ `x.as_ptr()`
        // ដោយសារ `*const u8` មានសុវត្ថិភាព។
        // `x.as_ptr()` បានមកពីឯកសារយោងហើយដូច្នេះត្រូវបានធានាថាមានសុពលភាពសម្រាប់ការអានសម្រាប់ប្រវែងនៃ `x.len()` ដែលមិនអាចធំជាង `isize::MAX` ។
        // ចំណែកដែលវិលត្រឡប់មកវិញមិនដែលផ្លាស់ប្តូរទេ។
        let bytes: &[u8] = unsafe { from_raw_parts(x.as_ptr() as *const u8, x.len()) };
        memchr::memchr(byte, bytes).is_some()
    }
}