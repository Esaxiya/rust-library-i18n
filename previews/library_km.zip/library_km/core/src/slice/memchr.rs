// ការអនុវត្តដើមយកចេញពី rust-memchr ។
// រក្សាសិទ្ធិ 2015 Andrew Gallant, bluss និង Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// ការប្រើប្រាស់ truncation ។
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// ត្រឡប់ `true` ប្រសិនបើ `x` មានបៃសូន្យ។
///
/// ពី *រឿងប្រៀបធៀប*, ជេអរអែនឌ័រ៖
///
/// "គំនិតគឺដកមួយចេញពីបៃនីមួយៗហើយបន្ទាប់មករកមើលបៃដែលជាកន្លែងដែលខ្ចីបានផ្សព្វផ្សាយដល់វិធីដែលសំខាន់បំផុត។
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// ត្រឡប់សន្ទស្សន៍ទីមួយដែលត្រូវគ្នាទៅនឹងបៃ `x` ក្នុង `text` ។
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // ផ្លូវលឿនសម្រាប់ចំណិតតូចៗ
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ស្កេនតម្លៃបៃតែមួយដោយអានពាក្យចំនួន `usize` ចំនួនពីរក្នុងពេលតែមួយ។
    //
    // បំបែក `text` ជាបីផ្នែក
    // - ផ្នែកដំបូងដែលមិនបានព្រមព្រៀងគ្នាមុនពាក្យដែលបានតម្រឹមជាលើកដំបូងនៅក្នុងអត្ថបទ
    // - រាងកាយស្កេនដោយ ២ ពាក្យក្នុងពេលតែមួយ
    // - ផ្នែកដែលនៅសល់ចុងក្រោយ <២ ពាក្យ

    // ស្វែងរកព្រំដែនដែលបានតម្រឹម
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // ស្វែងរកតួនៃអត្ថបទ
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // សុវត្ថិភាព: ការប៉ាន់ស្មានរបស់ខណៈពេលដែលធានាចម្ងាយយ៉ាងហោចណាស់ ២ * usize_bytes
        // រវាងអុហ្វសិតនិងចុងបញ្ចប់នៃចំណិត។
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // បំបែកប្រសិនបើមានបៃត្រូវគ្នា
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // ស្វែងរកបៃបន្ទាប់ពីចំនុចដែលរង្វិលជុំរាងកាយឈប់។
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// ត្រឡប់សន្ទស្សន៍ចុងក្រោយដែលត្រូវគ្នានឹងបៃ `x` ក្នុង `text` ។
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ស្កេនតម្លៃបៃតែមួយដោយអានពាក្យចំនួន `usize` ចំនួនពីរក្នុងពេលតែមួយ។
    //
    // បំបែក `text` ជាបីផ្នែក៖
    // - កន្ទុយដែលមិនបានតម្រឹមបន្ទាប់ពីពាក្យចុងក្រោយតម្រឹមអាសយដ្ឋាននៅក្នុងអត្ថបទ,
    // - រាងកាយស្កេនដោយ ២ ពាក្យក្នុងពេលតែមួយ
    // - នៅសល់បៃដំបូង <ទំហំពាក្យ ២ ។
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // យើងហៅវាថាដើម្បីទទួលបានប្រវែងបុព្វបទនិងបច្ច័យ។
        // នៅកណ្តាលយើងតែងតែដំណើរការកំណាត់ពីរក្នុងពេលតែមួយ។
        // សុវត្ថិភាព: ការបញ្ជូន `[u8]` ទៅ `[usize]` មានសុវត្ថិភាពលើកលែងតែភាពខុសគ្នានៃទំហំដែលត្រូវបានគ្រប់គ្រងដោយ `align_to` ។
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // ស្វែងរកតួនៃអត្ថបទសូមប្រាកដថាយើងមិនឆ្លងកាត់ខ្នាតតូចទេ។
    // អុហ្វសិតតែងតែត្រូវបានតម្រឹមដូច្នេះគ្រាន់តែសាកល្បង `>` គឺគ្រប់គ្រាន់ហើយចៀសវាងការហូរចេញដែលអាចកើតមាន។
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // សុវត្ថិភាព: អុហ្វសិតចាប់ផ្តើមនៅអិល, អេចស៊ី, ដរាបណាវាធំជាង
        // min_aligned_offset (prefix.len()) ចម្ងាយដែលនៅសល់គឺយ៉ាងហោចណាស់ ២ * chunk_bytes ។
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // បំបែកប្រសិនបើមានបៃត្រូវគ្នា។
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // រកបៃមុនចំណុចដែលរង្វិលជុំរាងកាយឈប់។
    text[..offset].iter().rposition(|elt| *elt == x)
}