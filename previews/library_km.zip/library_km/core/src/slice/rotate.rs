// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// បង្វិលជួរ `[mid-left, mid+right)` ដូចជាធាតុនៅ `mid` ក្លាយជាធាតុដំបូង។ស្មើគ្នាបង្វិលធាតុជួរ `left` ទៅខាងឆ្វេងឬធាតុ `right` ទៅខាងស្តាំ។
///
/// # Safety
///
/// ជួរដែលបានបញ្ជាក់ត្រូវតែមានសុពលភាពសម្រាប់ការអាននិងការសរសេរ។
///
/// # Algorithm
///
/// ក្បួនដោះស្រាយទី ១ ត្រូវបានប្រើសម្រាប់តម្លៃតូចៗនៃ `left + right` ឬសម្រាប់ `T` ធំ។
/// ធាតុត្រូវបានផ្លាស់ប្តូរទៅទីតាំងចុងក្រោយរបស់ពួកគេម្តងក្នុងពេលតែមួយចាប់ផ្តើមពី `mid - left` ហើយឈានទៅមុខដោយ `right` ជំហានម៉ូឌុលម៉ូទ័រ `left + right` ដូចជាមានតែបណ្តោះអាសន្នតែមួយប៉ុណ្ណោះដែលត្រូវការ។
/// នៅទីបំផុតយើងត្រលប់មក `mid - left` វិញ។
/// ទោះយ៉ាងណាក៏ដោយប្រសិនបើ `gcd(left + right, right)` មិនមែន 1 នោះជំហានខាងលើបានរំលងពីលើធាតុ។
/// ឧទាហរណ៍:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// ជាសំណាងល្អចំនួននៃការរំលងលើធាតុរវាងធាតុដែលបានបញ្ចប់គឺតែងតែស្មើគ្នាដូច្នេះយើងគ្រាន់តែអាចទូទាត់ទីតាំងចាប់ផ្តើមរបស់យើងហើយធ្វើជុំបន្ថែមទៀត (ចំនួនសរុបនៃជុំគឺ `gcd(left + right, right)` value) ។
///
/// លទ្ធផលចុងក្រោយគឺថាធាតុទាំងអស់ត្រូវបានបញ្ចប់ម្តងហើយម្តងទៀត។
///
/// ក្បួនដោះស្រាយទី ២ ត្រូវបានប្រើប្រសិនបើ `left + right` មានទំហំធំប៉ុន្តែ `min(left, right)` តូចល្មមអាចដាក់លើសតិបណ្ដោះអាសន្ន។
/// ធាតុ `min(left, right)` ត្រូវបានចម្លងទៅសតិបណ្ដោះអាសន្ន `memmove` ត្រូវបានអនុវត្តទៅវត្ថុផ្សេងទៀតហើយធាតុនៅលើសតិបណ្ដោះអាសន្នត្រូវបានផ្លាស់ប្តូរទៅក្នុងរន្ធនៅផ្នែកម្ខាងនៃកន្លែងដែលវាមានប្រភពដើម។
///
/// ក្បួនដោះស្រាយដែលអាចត្រូវបានធ្វើឱ្យប្រសើរជាងរូបភាពខាងលើនៅពេលដែល `left + right` មានទំហំធំល្មម។
/// ក្បួនដោះស្រាយទី ១ អាចត្រូវបានបង្កើតដោយវ៉ាក់សាំងនិងការសម្តែងជុំជាច្រើនក្នុងពេលតែមួយប៉ុន្តែវាមានចំនួនជុំតិចពេករហូតដល់ `left + right` ធំសម្បើមហើយករណីដ៏អាក្រក់បំផុតនៃជុំតែមួយតែងតែមាន។
/// ផ្ទុយទៅវិញក្បួនដោះស្រាយទី ៣ ប្រើប្រាស់ការប្តូរធាតុ `min(left, right)` ម្តងហើយម្តងទៀតរហូតទាល់តែមានបញ្ហាវិលតូចជាង។
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// នៅពេល `left < right` ការប្តូរកើតឡើងពីខាងឆ្វេងជំនួសវិញ។
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ក្បួនដោះស្រាយខាងក្រោមអាចបរាជ័យប្រសិនបើករណីទាំងនេះមិនត្រូវបានពិនិត្យ
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // ក្បួនដោះស្រាយ 1 Microbenchmarks បានបង្ហាញថាការសម្តែងជាមធ្យមសម្រាប់ការផ្លាស់ប្តូរល្អប្រសើរជាងមុនទាំងអស់ចៃដន្យគឺរហូតដល់អំពីវិធីដែល `left + right == 32` នោះទេប៉ុន្តែការសម្រាកការសម្តែងករណីធ្ងន់ធ្ងរសូម្បីតែនៅជុំវិញ 16 ។
            // 24 ត្រូវបានជ្រើសរើសជាដីកណ្តាល។
            // ប្រសិនបើទំហំនៃ `T` ធំជាង 4 `usize`s នោះក្បួនដោះស្រាយនេះក៏ល្អជាងក្បួនដោះស្រាយផ្សេងទៀតដែរ។
            //
            //
            let x = unsafe { mid.sub(left) };
            // ការចាប់ផ្តើមនៃជុំទីមួយ
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` អាចត្រូវបានរកឃើញមុនពេលគណនាដោយ `gcd(left + right, right)` X ប៉ុន្តែវាលឿនជាងក្នុងការធ្វើរង្វិលជុំមួយដែលគណនា gcd ជាផលប៉ះពាល់បន្ទាប់មកធ្វើចំណែកដែលនៅសល់
            //
            //
            let mut gcd = right;
            // ការចង្អុលបង្ហាញបង្ហាញថាវាលឿនជាងមុនក្នុងការប្តូរទីតាំងទាំងអស់តាមរយៈការជំនួសការអានបណ្តោះអាសន្នម្តងរួចចម្លងទៅក្រោយហើយបន្ទាប់មកសរសេរបណ្តោះអាសន្ននៅចុងបញ្ចប់។
            // នេះអាចបណ្តាលមកពីការពិតដែលថាការប្តូរឬជំនួសកន្លែងប្រើឧបករណ៍ចងចាំប្រើតែអាសយដ្ឋានចងចាំមួយនៅក្នុងរង្វិលជុំជំនួសឱ្យការគ្រប់គ្រងពីរ។
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // ជំនួសឱ្យការបង្កើន `i` ហើយបន្ទាប់មកពិនិត្យមើលថាតើវានៅខាងក្រៅព្រំដែនយើងពិនិត្យមើលថាតើ `i` នឹងចេញទៅក្រៅព្រំដែននៅលើការកើនឡើងបន្ទាប់។
                // នេះការពារការរុំចំណុចរឺ `usize` ។
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ចុងបញ្ចប់នៃជុំទីមួយ
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // លក្ខខណ្ឌនេះត្រូវតែមាននៅទីនេះប្រសិនបើ `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // បញ្ចប់កំណាត់ជាមួយជុំបន្ថែមទៀត
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` មិនមែនជាប្រភេទសូន្យទេដូច្នេះវាមិនអីទេក្នុងការបែងចែកតាមទំហំរបស់វា។
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // ក្បួនដោះស្រាយទី ២ `[T; 0]` នៅទីនេះគឺដើម្បីធានាថានេះត្រូវបានតម្រឹមសមស្របសម្រាប់ T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // វិធីដោះស្រាយទី ៣ មានវិធីប្តូរថ្មីមួយដែលពាក់ព័ន្ធនឹងការរកកន្លែងប្តូរចុងក្រោយនៃក្បួនដោះស្រាយនេះហើយប្តូរដោយប្រើកំណាត់ចុងក្រោយជំនួសឱ្យការប្តូរកំណាត់ដែលនៅជិតៗដូចជាក្បួនដោះស្រាយនេះកំពុងធ្វើប៉ុន្តែវិធីនេះនៅតែលឿន។
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // ក្បួនដោះស្រាយទី ៣ `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}