//! ម៉ាក្រូត្រូវបានប្រើដោយឧបករណ៍រំអិល។

// ការតំរង់ជួរគឺ-ភាពស្មោះត្រង់និងភាពខុសគ្នាធ្វើឱ្យមានភាពខុសគ្នានៃការសម្តែង
macro_rules! is_empty {
    // វិធីដែលយើងអ៊ិនកូដប្រវែងរបស់ឧបករណ៍វាស់ហ្ស៊ីអេសអេសអេសមួយនេះមានប្រសិទ្ធភាពទាំង ZST និងមិនមែនហ្សីអេស។
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// ដើម្បីកម្ចាត់ការត្រួតពិនិត្យព្រំដែនមួយចំនួន (សូមមើល `position`) យើងគណនាប្រវែងតាមរបៀបដែលមិននឹកស្មានដល់។
// (សាកល្បងដោយ `codegen/slice-position-bounds-check` ។)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ពេលខ្លះយើងត្រូវបានប្រើនៅក្នុងប្លុកដែលគ្មានសុវត្ថិភាព

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // _cannot_ នេះប្រើ `unchecked_sub` ពីព្រោះយើងពឹងផ្អែកលើការរុំដើម្បីតំណាងឱ្យប្រវែងនៃឧបករណ៍កាត់ ZST វែង។
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // យើងដឹងថា `start <= end`, ដូច្នេះអាចធ្វើបានល្អប្រសើរជាង `offset_from`, ដែលត្រូវការដោះស្រាយនៅក្នុងការចុះហត្ថលេខា។
            // ដោយកំណត់ទង់សមស្របនៅទីនេះយើងអាចប្រាប់ LLVM នេះដែលជួយវាលុបចោលការត្រួតពិនិត្យព្រំដែន។
            // សុវត្ថិភាព: តាមប្រភេទរាតត្បាត, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // ដោយប្រាប់ LLVM ផងដែរថាចំនុចចង្អុលដាច់ពីគ្នាដោយចំនួនច្រើនជាក់លាក់នៃទំហំប្រភេទវាអាចបង្កើនប្រសិទ្ធភាព `len() == 0` ចុះដល់ `start == end` ជំនួសឱ្យ `(end - start) < size` ។
            //
            // សុវត្ថិភាព: តាមប្រភេទដែលមិនត្រូវគ្នាអ្នកចង្អុលត្រូវបានតម្រឹមដូច្នេះ
            //         ចំងាយរវាងពួកវាត្រូវតែមានចំនុចជាច្រើននៃទំហំចង្អុល
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// និយមន័យរួមនៃឧបករណ៍ភ្ជាប់ `Iter` X និង `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // ត្រឡប់ធាតុទីមួយហើយផ្លាស់ទីការចាប់ផ្តើមរបស់អ្នកបញ្ជូនបន្តទៅមុខដោយ 1 ។
        // ធ្វើអោយប្រសើរឡើងនូវដំណើរការល្អបើប្រៀបធៀបទៅនឹងមុខងារដែលបានតំរង់ជួរ។
        // វាមិនត្រូវទុកចោលទេ។
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // ត្រឡប់ធាតុចុងក្រោយហើយផ្លាស់ទីចុងបញ្ចប់នៃទ្រនិចនាឡិកាថយក្រោយដោយ 1 ។
        // ធ្វើអោយប្រសើរឡើងនូវដំណើរការល្អបើប្រៀបធៀបទៅនឹងមុខងារដែលបានតំរង់ជួរ។
        // វាមិនត្រូវទុកចោលទេ។
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // ធ្លាក់ចុះបម្រុងនៅពេល t ជា ZST ដោយចុងបញ្ចប់នៃការផ្លាស់ប្តូរនេះដោយថយក្រោយបម្រុងនោះ `n` ។
        // `n` មិនត្រូវលើសពី `self.len()` ។
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // មុខងារជំនួយសម្រាប់ការបង្កើតចំណិតពីឧបករណ៍រំកិល។
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // សុវត្ថិភាព: ឧបករណ៍រំកិលត្រូវបានបង្កើតឡើងពីចំណិតជាមួយនឹងទ្រនិច
                // `self.ptr` និងប្រវែង `len!(self)` ។
                // នេះធានាថារាល់តម្រូវការជាមុនសម្រាប់ `from_raw_parts` ត្រូវបានបំពេញ។
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // មុខងារអ្នកជំនួយការសម្រាប់ការផ្លាស់ប្តូរការចាប់ផ្តើមនៃការបញ្ជូនបន្តដោយធាតុ `offset`, ត្រឡប់ការចាប់ផ្តើមចាស់។
            //
            // មិនមានសុវត្ថិភាពទេពីព្រោះអុហ្វសិតមិនត្រូវលើសពី `self.len()` ទេ។
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // សុវត្ថិភាព: ធានាអ្នកទូរស័ព្ទចូលដែល `offset` មិនលើសពី `self.len()`,
                    // ដូច្នេះទ្រនិចថ្មីនេះគឺនៅខាងក្នុង `self` ហើយដូច្នេះត្រូវបានធានាថាមិនមែនជាមោឃៈទេ។
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // មុខងារជំនួយសម្រាប់ការផ្លាស់ប្តូរចុងបញ្ចប់នៃទ្រនាប់ក្រោយដោយធាតុ `offset` ត្រឡប់ចុងថ្មី។
            //
            // មិនមានសុវត្ថិភាពទេពីព្រោះអុហ្វសិតមិនត្រូវលើសពី `self.len()` ទេ។
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // សុវត្ថិភាព: ធានាអ្នកទូរស័ព្ទចូលដែល `offset` មិនលើសពី `self.len()`,
                    // ដែលត្រូវបានធានាមិនឱ្យលើសពី `isize` ។
                    // ដូចគ្នានេះផងដែរទ្រនិចលទ្ធផលគឺស្ថិតនៅក្នុងព្រំដែននៃ `slice` ដែលបំពេញនូវតម្រូវការផ្សេងទៀតសម្រាប់ `offset` ។
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // អាចត្រូវបានអនុវត្តជាមួយចំណិត, ប៉ុន្តែនេះជៀសវាងការត្រួតពិនិត្យព្រំដែន

                // សុវត្ថិភាព: ការហៅទូរស័ព្ទ `assume` មានសុវត្ថិភាពចាប់តាំងពីព្រួញចាប់ផ្តើម
                // ត្រូវតែមិនមែនជាមោឃៈហើយចំណិតដែលមិនមែនជាអេសអរអេសក៏ត្រូវតែមានទ្រនិចចង្អុលដែលមិនមែនជាមោឃដែរ។
                // ការហៅទៅ `next_unchecked!` គឺមានសុវត្ថិភាពចាប់តាំងពីយើងពិនិត្យមើលថាតើឧបករណ៍រំកិលទំនេរមុន។
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ឥឡូវនេះគឺទទេ។
                    if mem::size_of::<T>() == 0 {
                        // យើងត្រូវធ្វើវាតាមវិធីដែល `ptr` អាចនឹងមិនមានលេខ 0 ប៉ុន្តែ `end` អាច (ដោយសារតែការរុំ) ។
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // សុវត្ថិភាព: ទីបញ្ចប់មិនអាចជាលេខ ០ ប្រសិនបើ T មិនមែន ZST ព្រោះ ptr មិនមែន ០ និងចប់>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // សុវត្ថិភាព: យើងស្ថិតនៅក្នុងព្រំដែន។`post_inc_start` ធ្វើអ្វីដែលត្រឹមត្រូវសូម្បីតែសម្រាប់អេសអេសអេស។
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // យើងបដិសេធការអនុវត្តលំនាំដើមដែលប្រើ `try_fold` ពីព្រោះការអនុវត្តសាមញ្ញនេះបង្កើត LLVM IR តិចហើយលឿនជាងក្នុងការចងក្រង។
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // យើងបដិសេធការអនុវត្តលំនាំដើមដែលប្រើ `try_fold` ពីព្រោះការអនុវត្តសាមញ្ញនេះបង្កើត LLVM IR តិចហើយលឿនជាងក្នុងការចងក្រង។
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // យើងបដិសេធការអនុវត្តលំនាំដើមដែលប្រើ `try_fold` ពីព្រោះការអនុវត្តសាមញ្ញនេះបង្កើត LLVM IR តិចហើយលឿនជាងក្នុងការចងក្រង។
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // យើងបដិសេធការអនុវត្តលំនាំដើមដែលប្រើ `try_fold` ពីព្រោះការអនុវត្តសាមញ្ញនេះបង្កើត LLVM IR តិចហើយលឿនជាងក្នុងការចងក្រង។
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // យើងបដិសេធការអនុវត្តលំនាំដើមដែលប្រើ `try_fold` ពីព្រោះការអនុវត្តសាមញ្ញនេះបង្កើត LLVM IR តិចហើយលឿនជាងក្នុងការចងក្រង។
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // យើងបដិសេធការអនុវត្តលំនាំដើមដែលប្រើ `try_fold` ពីព្រោះការអនុវត្តសាមញ្ញនេះបង្កើត LLVM IR តិចហើយលឿនជាងក្នុងការចងក្រង។
            // ដូចគ្នានេះផងដែរ `assume` ជៀសវាងការត្រួតពិនិត្យព្រំដែន។
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // សុវត្ថិភាព: យើងត្រូវបានធានាឱ្យមាននៅក្នុងព្រំដែនដោយភាពខុសគ្នានៃរង្វិលជុំ:
                        // នៅពេល `i >= n`, `self.next()` ត្រឡប់ `None` ហើយរង្វិលជុំដាច់។
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // យើងបដិសេធការអនុវត្តលំនាំដើមដែលប្រើ `try_fold` ពីព្រោះការអនុវត្តសាមញ្ញនេះបង្កើត LLVM IR តិចហើយលឿនជាងក្នុងការចងក្រង។
            // ដូចគ្នានេះផងដែរ `assume` ជៀសវាងការត្រួតពិនិត្យព្រំដែន។
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // សុវត្ថិភាព: `i` ត្រូវតែទាបជាង `n` ចាប់តាំងពីវាចាប់ផ្តើមនៅ `n`
                        // ហើយកំពុងតែថយចុះ។
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `i` ស្ថិតនៅក្នុងព្រំដែន
                // ចំណិតមូលដ្ឋានដូច្នេះ `i` មិនអាចលើសចំណុះ `isize` ទេហើយឯកសារយោងត្រឡប់មកវិញត្រូវបានធានាថាយោងទៅលើធាតុនៃចំណិតហើយដូច្នេះធានាថាមានសុពលភាព។
                //
                // សូមកត់សម្គាល់ផងដែរថាអ្នកទូរស័ព្ទចូលក៏ធានាថាយើងមិនដែលត្រូវបានហៅជាមួយសន្ទស្សន៍ដដែលហើយមិនមានវិធីសាស្រ្តផ្សេងទៀតដែលត្រូវបានហៅនោះទេដូច្នេះវាមានសុពលភាពសម្រាប់ឯកសារយោងដែលអាចត្រឡប់វិញបានក្នុងករណីដែល
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // អាចត្រូវបានអនុវត្តជាមួយចំណិត, ប៉ុន្តែនេះជៀសវាងការត្រួតពិនិត្យព្រំដែន

                // សុវត្ថិភាព: ការហៅទូរស័ព្ទ `assume` មានសុវត្ថភាពចាប់តាំងពីព្រួញចង្អុលចាប់ផ្តើមមិនត្រូវ
                // ហើយចំណិតនៅលើមិនមែន ZST ត្រូវតែមានទ្រនិចចង្អុលដែលមិនមែនជាមោឃៈផងដែរ។
                // ការហៅទៅ `next_back_unchecked!` គឺមានសុវត្ថិភាពចាប់តាំងពីយើងពិនិត្យមើលថាតើឧបករណ៍រំកិលទំនេរមុន។
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ឥឡូវនេះគឺទទេ។
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // សុវត្ថិភាព: យើងស្ថិតនៅក្នុងព្រំដែន។`pre_dec_end` ធ្វើអ្វីដែលត្រឹមត្រូវសូម្បីតែសម្រាប់អេសអេសអេស។
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}