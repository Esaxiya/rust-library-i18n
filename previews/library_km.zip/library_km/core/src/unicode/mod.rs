#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// កំណែ [Unicode](http://www.unicode.org/) ដែលផ្នែកយូនីកូដនៃវិធីសាស្ត្រ `char` និង `str` ត្រូវបានផ្អែកលើ។
///
/// កំណែថ្មីនៃយូនីកូដត្រូវបានចេញផ្សាយទៀងទាត់និងជាបន្តបន្ទាប់វិធីសាស្រ្តទាំងអស់នៅក្នុងបណ្ណាល័យស្ដង់ដារអាស្រ័យលើយូនីកូដត្រូវបានធ្វើឱ្យទាន់សម័យ។
/// ដូច្នេះឥរិយាបថរបស់វិធីសាស្រ្ត `char` និង `str` មួយចំនួននិងតម្លៃនៃការផ្លាស់ប្តូរនេះជាថេរលើពេលវេលា។
/// នេះមិនមែន * ត្រូវបានគេចាត់ទុកថាជាការផ្លាស់ប្តូរបំបែកទេ។
///
/// គ្រោងការណ៍លេខរៀងកំណែត្រូវបានពន្យល់ជា [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ។
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// សម្រាប់ការប្រើប្រាស់នៅក្នុង liballoc មិនត្រូវបាននាំចេញឡើងវិញនៅក្នុង libstd ទេ។
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;