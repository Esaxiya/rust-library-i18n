#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! មាននិយមន័យរចនាសម្ព័ន្ធសម្រាប់ប្លង់នៃប្រភេទអ្នកចងក្រង។
//!
//! ពួកវាអាចត្រូវបានប្រើជាគោលដៅនៃការបញ្ជូនក្នុងកូដគ្មានសុវត្ថិភាពសម្រាប់រៀបចំតំណាងដើមដោយផ្ទាល់។
//!
//!
//! និយមន័យរបស់ពួកគេគួរតែត្រូវគ្នានឹង ABI ដែលបានកំណត់នៅក្នុង `rustc_middle::ty::layout` ។
//!

/// ការតំណាងនៃវត្ថុ trait ដូចជា `&dyn SomeTrait` ។
///
/// រចនាសម្ព័ន្ធនេះមានប្លង់ដូចគ្នានឹងប្រភេទដូចជា `&dyn SomeTrait` និង `Box<dyn AnotherTrait>` ។
///
/// `TraitObject` ត្រូវបានធានាដើម្បីផ្គូផ្គងប្លង់ប៉ុន្តែវាមិនមែនជាប្រភេទវត្ថុ trait (ឧទាហរណ៍វាលមិនអាចចូលដោយផ្ទាល់លើ `&dyn SomeTrait`) ហើយក៏មិនត្រួតត្រាប្លង់នោះដែរ (ការប្តូរនិយមន័យនឹងមិនផ្លាស់ប្តូរប្លង់នៃ `&dyn SomeTrait` ទេ) ។
///
/// វាត្រូវបានរចនាឡើងដើម្បីប្រើដោយកូដគ្មានសុវត្ថិភាពដែលត្រូវការរៀបចំព័ត៌មានលំអិតកម្រិតទាប។
///
/// មិនមានវិធីដើម្បីសំដៅទៅលើវត្ថុ trait ទាំងអស់ជាទូទៅទេដូច្នេះវិធីតែមួយគត់ដើម្បីបង្កើតតម្លៃនៃប្រភេទនេះគឺមានមុខងារដូចជា [`std::mem::transmute`][transmute] ។
/// ស្រដៀងគ្នានេះដែរវិធីតែមួយគត់ដើម្បីបង្កើតវត្ថុ trait ពិតពីតម្លៃ `TraitObject` គឺជាមួយ `transmute` ។
///
/// [transmute]: crate::intrinsics::transmute
///
/// ការសំយោគវត្ថុ trait ជាមួយនឹងប្រភេទដែលមិនត្រូវគ្នា-ជាកន្លែងដែលតុរប្យួរមិនត្រូវគ្នាទៅនឹងប្រភេទនៃតម្លៃដែលចំណុចចង្អុលទិន្នន័យ-ទំនងជានាំឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // ឧទាហរណ៍ trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // អនុញ្ញាតឱ្យអ្នកចងក្រងធ្វើវត្ថុ trait
/// let object: &dyn Foo = &value;
///
/// // រកមើលការតំណាងឆៅ
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // ទ្រនិចទិន្នន័យគឺជាអាសយដ្ឋានរបស់ `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // បង្កើតវត្ថុថ្មីដោយចង្អុលទៅ `i32` ផ្សេងដោយប្រយ័ត្នប្រយែងក្នុងការប្រើតុ `i32` ពី `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // វាគួរតែដំណើរការដូចជាយើងបានសាងសង់វត្ថុ trait ចេញពី `other_value` ដោយផ្ទាល់
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}