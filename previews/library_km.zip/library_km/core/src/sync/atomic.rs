//! ប្រភេទអាតូម
//!
//! ប្រភេទអាតូមផ្តល់នូវទំនាក់ទំនងរវាងការចងចាំនិងទំនាក់ទំនងរវាងខ្សែស្រឡាយនិងជាប្លុកនៃប្រភេទដំណាលគ្នាផ្សេងទៀត។
//!
//! ម៉ូឌុលនេះកំណត់កំណែអាតូមនៃចំនួនជ្រើសរើសប្រភេទបឋមរួមមាន [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] ។ ល។
//! ប្រភេទអាតូមបង្ហាញពីប្រតិបត្តិការដែលនៅពេលប្រើត្រឹមត្រូវធ្វើសមកាលកម្មរវាងខ្សែស្រឡាយ។
//!
//! វិធីសាស្រ្តនីមួយៗយក [`Ordering`] ដែលតំណាងឱ្យភាពខ្លាំងនៃរបាំងសតិសម្រាប់ប្រតិបត្តិការនោះ។ការបញ្ជាទិញទាំងនេះគឺដូចគ្នានឹង [C++20 atomic orderings][1] ដែរ។សម្រាប់ពបន្ថែមសូមមើល [nomicon][2] នេះ។
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! អថេរអាតូមមានសុវត្ថិភាពក្នុងការចែករំលែករវាងខ្សែស្រឡាយ (ពួកគេអនុវត្ត [`Sync`]) ប៉ុន្តែពួកគេខ្លួនឯងមិនបានផ្តល់នូវយន្តការសម្រាប់ចែករំលែកនិងធ្វើតាម [threading model](../../../std/thread/index.html#the-threading-model) នៃ Rust ទេ។
//!
//! វិធីទូទៅបំផុតដើម្បីចែករំលែកអថេរអាតូមិចគឺដាក់វាចូលទៅក្នុង [`Arc`][arc] (ទ្រនិចចែករំលែកដែលរាប់បញ្ចូលអាតូម) ។
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! ប្រភេទអាតូមអាចត្រូវបានរក្សាទុកក្នុងអថេរឋិតិវន្តដោយចាប់ផ្តើមប្រើថេរដំបូងដូចជា [`AtomicBool::new`] ។ឋិតិវន្តអាតូមជារឿយៗត្រូវបានប្រើសម្រាប់ការចាប់ផ្តើមជាសកលខ្ជិល។
//!
//! # Portability
//!
//! ប្រភេទអាតូមទាំងអស់នៅក្នុងម៉ូឌុលនេះត្រូវបានធានាថាជា [lock-free] ប្រសិនបើមាន។នេះមានន័យថាពួកគេមិនទទួលបានការ mutex សកល។ប្រភេទនិងប្រតិបត្ដិការអាតូមមិនត្រូវបានធានាថាមិនរងចាំឡើយ។
//! នេះមានន័យថាប្រតិបត្តិការដូចជា `fetch_or` អាចត្រូវបានអនុវត្តជាមួយនឹងរង្វាស់ប្រៀបធៀបនិងស្វប។
//!
//! ប្រតិបត្ដិការអាតូមិចអាចត្រូវបានអនុវត្តនៅស្រទាប់បង្រៀនជាមួយអាតូមដែលមានទំហំធំជាង។ឧទាហរណ៍វេទិកាខ្លះប្រើការណែនាំអាតូម ៤ បៃដើម្បីអនុវត្ត `AtomicI8` ។
//! ចំណាំថាការធ្វើត្រាប់តាមនេះមិនគួរមានឥទ្ធិពលលើភាពត្រឹមត្រូវនៃលេខកូដទេវាគ្រាន់តែជាអ្វីដែលត្រូវដឹង។
//!
//! ប្រភេទអាតូមនៅក្នុងម៉ូឌុលនេះប្រហែលជាមិនមាននៅលើវេទិកាទាំងអស់ទេ។ប្រភេទបរមាណូនៅទីនេះគឺមានទាំងអស់អាចប្រើបានយ៉ាងទូលំទូលាយ, ទោះជាយ៉ាងណា, ហើយជាទូទៅអាចត្រូវបានពឹងផ្អែកលើការដែលមានស្រាប់។ការលើកលែងគួរឱ្យកត់សម្គាល់មួយចំនួនគឺ៖
//!
//! * PowerPC និងវេទិកា MIPS ដែលមានចង្អុល 32 ប៊ីតមិនមានប្រភេទ `AtomicU64` ឬ `AtomicI64` ទេ។
//! * ARM វេទិកាដូចជា `armv5te` ដែលមិនមែនសម្រាប់ Linux ផ្តល់តែប្រតិបត្តិការ `load` និង `store` ហើយមិនគាំទ្រប្រតិបត្តិការប្រៀបធៀបនិងប្តូរ (CAS) ដូចជា `swap`, `fetch_add` ជាដើម។
//! លើសពីនេះទៀតនៅលើ Linux ប្រតិបត្តិការ CAS ទាំងនេះត្រូវបានអនុវត្តតាមរយៈ [operating system support] ដែលអាចនឹងមានការពិន័យលើការអនុវត្ត។
//! * ARM គោលដៅជាមួយ `thumbv6m` ផ្តល់តែប្រតិបត្តិការ `load` និង `store` ប៉ុណ្ណោះហើយមិនគាំទ្រប្រតិបត្តិការប្រៀបធៀបនិងប្តូរ (CAS) ដូចជា `swap`, `fetch_add` ជាដើម។
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! ចំណាំថាវេទិកា future អាចត្រូវបានបន្ថែមដែលមិនមានការគាំទ្រសម្រាប់ប្រតិបត្តិការអាតូមិចមួយចំនួន។លេខកូដចល័តអតិបរមានឹងចង់ប្រុងប្រយ័ត្នអំពីប្រភេទអាតូមណាដែលត្រូវបានប្រើ។
//! `AtomicUsize` និង `AtomicIsize` ជាទូទៅគឺអាចចល័តបានច្រើនបំផុតប៉ុន្តែសូម្បីតែពេលនោះក៏ដោយក៏វាមិនមាននៅគ្រប់ទីកន្លែងដែរ។
//! សម្រាប់ឯកសារយោងបណ្ណាល័យ `std` តម្រូវឱ្យមានអាតូមដែលមានទំហំទ្រនិចទោះបីជា `core` មិនក៏ដោយ។
//!
//! បច្ចុប្បន្នអ្នកត្រូវប្រើ `#[cfg(target_arch)]` ជាចម្បងដើម្បីចងក្រងតាមលក្ខខណ្ឌជាមួយអាតូមិច។មានមិនស្ថិតស្ថេរ `#[cfg(target_has_atomic)]` ផងដែរដែលអាចត្រូវបានស្ថេរភាពនៅក្នុង future គឺ។
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ការបង្វិលសាមញ្ញ៖
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // រង់ចាំខ្សែស្រឡាយផ្សេងទៀតដើម្បីដោះសោ
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! រក្សាការបន្តផ្ទាល់នៃខ្សែស្រឡាយបន្តផ្ទាល់៖
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// ប្រភេទប៊ូលីនដែលអាចចែករំលែករវាងខ្សែស្រឡាយដោយសុវត្ថិភាព។
///
/// ប្រភេទនេះមានតំណាងនៅក្នុងសតិដូចគ្នានឹង [`bool`] ដែរ។
///
/// **ចំណាំ**៖ ប្រភេទនេះអាចប្រើបានតែនៅលើវេទិការដែលគាំទ្រដល់បន្ទុកអាតូមនិងហាង `u8` X ប៉ុណ្ណោះ។
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// បង្កើត `AtomicBool` បានចាប់ផ្តើមទៅ `false` ។
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// ការផ្ញើត្រូវបានអនុវត្តជាក់ស្តែងសម្រាប់អាតូមិកប៊ល។
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ប្រភេទទ្រនិចឆៅដែលអាចចែករំលែករវាងខ្សែស្រឡាយដោយសុវត្ថិភាព។
///
/// ប្រភេទនេះមានតំណាងនៅក្នុងសតិដូចគ្នានឹង `*mut T` ដែរ។
///
/// **ចំណាំ**: ប្រភេទនេះគឺអាចប្រើបានតែនៅលើប្រព័ន្ធប្រតិបត្តិការដែលគាំទ្រផ្ទុកអាតូមនិងហាងលក់របស់ព្រួញ។
/// ទំហំរបស់វាអាស្រ័យលើទំហំគោលដៅរបស់ព្រួញ។
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// បង្កើតមោឃៈ `AtomicPtr<T>` ។
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ការបញ្ជាទិញអង្គចងចាំអាតូម
///
/// ការបញ្ជាទិញអង្គចងចាំបញ្ជាក់ពីវិធីប្រតិបត្តិការអាតូមធ្វើសមកាលកម្មសតិ។
/// នៅក្នុង [`Ordering::Relaxed`] ខ្សោយបំផុតរបស់វាមានតែការចងចាំដែលប៉ះដោយប្រតិបត្តិការដោយផ្ទាល់ត្រូវបានធ្វើសមកាលកម្ម។
/// ម៉្យាងទៀតឧបករណ៍ផ្ទុកផ្ទុកប្រតិបត្ដិការ [`Ordering::SeqCst`] ធ្វើសមកាលកម្មសតិផ្សេងទៀតខណៈពេលដែលរក្សាលំដាប់សរុបនៃប្រតិបត្តិការបែបនេះនៅទូទាំងខ្សែស្រឡាយទាំងអស់។
///
///
/// ការបញ្ជាទិញសតិរបស់ Rust គឺ [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) ។
///
/// សម្រាប់ពបន្ថែមសូមមើល [nomicon] នេះ។
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// គ្មានឧបសគ្គក្នុងការបញ្ជាទិញទេមានតែប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ។
    ///
    /// ត្រូវនឹង [`memory_order_relaxed`] ក្នុង C++ 20 ។
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// នៅពេលភ្ជាប់ជាមួយហាងរាល់ប្រតិបត្តិការមុន ៗ ត្រូវបានគេបញ្ជាទិញមុនពេលផ្ទុកតម្លៃណាមួយជាមួយនឹងការបញ្ជាទិញ [`Acquire`] (ឬខ្លាំងជាងនេះ) ។
    ///
    /// ជាពិសេសរាល់សំណេរមុន ៗ អាចមើលឃើញចំពោះខ្សែស្រឡាយទាំងអស់ដែលអនុវត្តការផ្ទុកតម្លៃ [`Acquire`] (ឬខ្លាំងជាងនេះ) ។
    ///
    /// សូមកត់សម្គាល់ថាការប្រើការបញ្ជាទិញនេះសម្រាប់ប្រតិបត្តិការដែលរួមបញ្ចូលបន្ទុកនិងហាងទំនិញនាំឱ្យមានប្រតិបត្តិការផ្ទុក [`Relaxed`]!
    ///
    /// ការបញ្ជាទិញនេះអាចអនុវត្តបានសម្រាប់ប្រតិបត្តិការដែលអាចដំណើរការហាងបាន។
    ///
    /// ត្រូវនឹង [`memory_order_release`] ក្នុង C++ 20 ។
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// នៅពេលភ្ជាប់ជាមួយបន្ទុកប្រសិនបើតម្លៃផ្ទុកត្រូវបានសរសេរដោយប្រតិបត្តិការហាងដែលមានលំដាប់ [`Release`] (ឬកាន់តែខ្លាំង) បន្ទាប់មកប្រតិបត្តិការជាបន្តបន្ទាប់ទាំងអស់ត្រូវបានបញ្ជាទិញបន្ទាប់ពីហាងនោះ។
    /// ជាពិសេសរាល់បន្ទុកជាបន្តបន្ទាប់នឹងឃើញទិន្នន័យសរសេរនៅចំពោះមុខហាង។
    ///
    /// សូមកត់សម្គាល់ថាការប្រើការបញ្ជាទិញនេះសម្រាប់ប្រតិបត្តិការដែលរួមបញ្ចូលបន្ទុកនិងហាងទំនិញនាំឱ្យមានប្រតិបត្តិការហាង [`Relaxed`]!
    ///
    /// ការបញ្ជាទិញនេះអាចអនុវត្តបានសម្រាប់ប្រតិបត្តិការដែលអាចផ្ទុកបន្ទុកបាន។
    ///
    /// ត្រូវនឹង [`memory_order_acquire`] ក្នុង C++ 20 ។
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// មានឥទ្ធិពលទាំង [`Acquire`] និង [`Release`] ជាមួយគ្នា៖
    /// សម្រាប់បន្ទុកវាប្រើលំដាប់ [`Acquire`] ។សម្រាប់ហាងវាប្រើលំដាប់ [`Release`] ។
    ///
    /// សូមកត់សម្គាល់ថាក្នុងករណី `compare_and_swap` វាអាចទៅរួចដែលប្រតិបត្តិការបញ្ចប់មិនដំណើរការហាងណាមួយទេហេតុដូច្នេះហើយវាទើបតែមានលំដាប់ [`Acquire`] ។
    ///
    /// ទោះយ៉ាងណា `AcqRel` នឹងមិនដែលអនុវត្តការចូលប្រើ [`Relaxed`] ទេ។
    ///
    /// ការបញ្ជាទិញនេះអាចអនុវត្តបានសម្រាប់ប្រតិបត្តិការដែលបញ្ចូលទាំងបន្ទុកនិងហាង។
    ///
    /// ត្រូវនឹង [`memory_order_acq_rel`] ក្នុង C++ 20 ។
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// ដូចជា [`Acquire`]/[`ចេញផ្សាយ`]/[`AcqRel`](សម្រាប់បន្ទុកផ្ទុកនិងប្រតិបត្តិការផ្ទុកទំនិញរៀងៗខ្លួន) ជាមួយនឹងការធានាបន្ថែមដែលខ្សែស្រឡាយទាំងអស់ឃើញប្រតិបត្ដិតាមលំដាប់លំដោយដូចគ្នា។ ។
    ///
    ///
    /// ត្រូវនឹង [`memory_order_seq_cst`] ក្នុង C++ 20 ។
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] បានចាប់ផ្តើមទៅ `false` ។
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// បង្កើត `AtomicBool` ថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅជាមូលដ្ឋាន [`bool`] ។
    ///
    /// នេះគឺជាការមានសុវត្ថិភាពដោយសារតែការធានាយោង mutable ថាគ្មានខ្សែស្រឡាយដទៃទៀតត្រូវបានចូលដំណើរការទិន្នន័យបរមាណូដែលស្របគ្នានោះដែរ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // សុវត្ថិភាព: ឯកសារយោងដែលអាចផ្លាស់ប្តូរបានធានានូវភាពជាម្ចាស់តែមួយគត់។
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// ទទួលបានអាតូមចូលទៅ `&mut bool` X ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // សុវត្ថិភាព: សេចក្ដីយោង mutable ធានាភាពជាម្ចាស់តែមួយគត់និង
        // ការតម្រឹមទាំង `bool` និង `Self` គឺ ១ ។
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// ប្រើប្រាស់អាតូមិចហើយត្រឡប់តម្លៃដែលមាន។
    ///
    /// នេះមានសុវត្ថិភាពពីព្រោះការឆ្លងកាត់ `self` ដោយតម្លៃធានាថាមិនមានខ្សែស្រឡាយផ្សេងទៀតចូលក្នុងទិន្នន័យអាតូមិកទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// ផ្ទុកតម្លៃពី bool ។
    ///
    /// `load` ត្រូវចំណាយពេលជាអាគុយម៉ង់ [`Ordering`] ដែលរៀបរាប់អំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// តម្លៃដែលអាចគឺ [`SeqCst`], [`Acquire`] និង [`Relaxed`] ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `order` គឺ [`Release`] ឬ [`AcqRel`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យណាមួយត្រូវបានរារាំងដោយអាតូមិចអាតូមិចនិងវត្ថុធាតុដើម
        // ទ្រនិចឆ្លងចូលមានសុពលភាពពីព្រោះយើងទទួលបានពីឯកសារយោង។
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// រក្សាទុកតម្លៃមួយទៅក្នុងហ្សីបប៊ល ០ ហ្ស។
    ///
    /// `store` ត្រូវចំណាយពេលជាអាគុយម៉ង់ [`Ordering`] ដែលរៀបរាប់អំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// តម្លៃដែលអាចមានគឺ [`SeqCst`], [`Release`] និង [`Relaxed`] ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `order` គឺ [`Acquire`] ឬ [`AcqRel`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យណាមួយត្រូវបានរារាំងដោយអាតូមិចអាតូមិចនិងវត្ថុធាតុដើម
        // ទ្រនិចឆ្លងចូលមានសុពលភាពពីព្រោះយើងទទួលបានពីឯកសារយោង។
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// រក្សាទុកតម្លៃមួយទៅក្នុង bool ដោយប្រគល់តម្លៃមុន។
    ///
    /// `swap` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
    /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
    ///
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// រក្សាទុកតម្លៃទៅក្នុង [`bool`] ប្រសិនបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
    ///
    /// តម្លៃត្រឡប់តែងតែជាតម្លៃមុន។ប្រសិនបើវាស្មើនឹង `current` បន្ទាប់មកតម្លៃត្រូវបានធ្វើបច្ចុប្បន្នភាព។
    ///
    /// `compare_and_swap` ក៏ត្រូវការអាគុយម៉ង់ [`Ordering`] ដែលពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// សូមកត់សម្គាល់ថាសូម្បីតែនៅពេលដែលប្រើ [`AcqRel`], ប្រតិបត្ដិការនេះអាចនឹងបរាជ័យហេតុដូចនេះហើយអនុវត្តការផ្ទុកគ្រាន់តែ `Acquire` ប៉ុន្តែមិនមានសញ្ញាន័យវិទ្យា `Release` ។
    /// ការប្រើ [`Acquire`] ធ្វើឱ្យហាងនេះជាផ្នែកមួយនៃការប្រតិបត្ដិការនេះប្រសិនបើវាកើតឡើង [`Relaxed`] និងការប្រើ [`Release`] ធ្វើឱ្យបន្ទុកផ្នែក [`Relaxed`] ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # ការធ្វើចំណាកស្រុកទៅ `compare_exchange` និង `compare_exchange_weak`
    ///
    /// `compare_and_swap` គឺស្មើនឹង `compare_exchange` ជាមួយផែនទីដូចខាងក្រោមសម្រាប់ការបញ្ជាទិញការចងចាំ:
    ///
    /// ដើម |ជោគជ័យ |ការបរាជ័យ
    /// -------- | ------- | -------
    /// បន្ធូរអារម្មណ៍ |បន្ធូរអារម្មណ៍ |ទទួលបានធូរស្បើយ |ទិញ |ទទួលបានការដោះលែង |ការចេញផ្សាយ |AcqRel បន្ធូរអារម្មណ៍ |AcqRel |ទទួលបាន SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ត្រូវបានអនុញ្ញាតឱ្យបរាជ័យយ៉ាងខ្លាំងសូម្បីតែការប្រៀបធៀបបានជោគជ័យដែលអនុញ្ញាតឱ្យអ្នកចងក្រងបង្កើតលេខកូដសន្និបាតកាន់តែប្រសើរនៅពេលប្រៀបធៀបនិងស្វបត្រូវបានប្រើក្នុងរង្វិលជុំ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// រក្សាទុកតម្លៃទៅក្នុង [`bool`] ប្រសិនបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
    ///
    /// តម្លៃត្រឡប់ជាលទ្ធផលបង្ហាញថាតើតម្លៃថ្មីត្រូវបានសរសេរនិងមានតម្លៃមុន។
    /// នៅលើភាពជោគជ័យតម្លៃនេះត្រូវបានធានាស្មើនឹង `current` ។
    ///
    /// `compare_exchange` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// `success` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការអាន-កែប្រែ-សរសេរដែលកើតឡើងប្រសិនបើការប្រៀបធៀបជាមួយ `current` ជោគជ័យ។
    /// `failure` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការបន្ទុកដែលកើតឡើងនៅពេលការប្រៀបធៀបបរាជ័យ។
    /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យ។
    ///
    /// ការបញ្ជាទិញបរាជ័យអាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// រក្សាទុកតម្លៃទៅក្នុង [`bool`] ប្រសិនបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
    ///
    /// មិនដូច [`AtomicBool::compare_exchange`] ទេមុខងារនេះត្រូវបានអនុញ្ញាតឱ្យបរាជ័យយ៉ាងឆាប់រហ័សសូម្បីតែការប្រៀបធៀបទទួលបានជោគជ័យដែលអាចបណ្តាលឱ្យកូដមានប្រសិទ្ធិភាពជាងនៅលើវេទិកាមួយចំនួន។
    ///
    /// តម្លៃត្រឡប់ជាលទ្ធផលបង្ហាញថាតើតម្លៃថ្មីត្រូវបានសរសេរនិងមានតម្លៃមុន។
    ///
    /// `compare_exchange_weak` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// `success` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការអាន-កែប្រែ-សរសេរដែលកើតឡើងប្រសិនបើការប្រៀបធៀបជាមួយ `current` ជោគជ័យ។
    /// `failure` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការបន្ទុកដែលកើតឡើងនៅពេលការប្រៀបធៀបបរាជ័យ។
    /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យ។
    /// ការបញ្ជាទិញបរាជ័យអាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ឡូជីខល "and" ជាមួយតម្លៃប៊ូលីន។
    ///
    /// អនុវត្តប្រតិបត្តិការឡូជីខល "and" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` ហើយកំណត់តម្លៃថ្មីទៅលទ្ធផល។
    ///
    /// ត្រឡប់តម្លៃមុន។
    ///
    /// `fetch_and` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
    /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
    ///
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// ឡូជីខល "nand" ជាមួយតម្លៃប៊ូលីន។
    ///
    /// អនុវត្តប្រតិបត្តិការឡូជីខល "nand" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` ហើយកំណត់តម្លៃថ្មីទៅលទ្ធផល។
    ///
    /// ត្រឡប់តម្លៃមុន។
    ///
    /// `fetch_nand` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
    /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
    ///
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // យើងមិនអាចប្រើអាតូមិចនៅទីនេះបានទេព្រោះវាអាចបណ្តាលឱ្យ bool មានតម្លៃមិនត្រឹមត្រូវ។
        // នេះកើតឡើងដោយសារប្រតិបត្ដិបរមាណូដែលត្រូវបានធ្វើជាមួយនឹងចំនួនគត់ 8 ប៊ីតខាងក្នុងដែលនឹងកំណត់ខាងលើ 7 ប៊ីត។
        //
        // ដូច្នេះយើងគ្រាន់តែប្រើ fetch_xor ឬប្តូរជំនួសវិញ។
        if val {
            // ! (x&ពិត)== !x យើងត្រូវតែដាក់បញ្ច្រាស bool ។
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&មិនពិត)==ពិតយើងត្រូវតែកំណត់ bool ទៅជាការពិត។
            //
            self.swap(true, order)
        }
    }

    /// ឡូជីខល "or" ជាមួយតម្លៃប៊ូលីន។
    ///
    /// អនុវត្តប្រតិបត្តិការឡូជីខល "or" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` ហើយកំណត់តម្លៃថ្មីទៅលទ្ធផល។
    ///
    /// ត្រឡប់តម្លៃមុន។
    ///
    /// `fetch_or` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
    /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
    ///
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// ឡូជីខល "xor" ជាមួយតម្លៃប៊ូលីន។
    ///
    /// អនុវត្តប្រតិបត្តិការឡូជីខល "xor" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` ហើយកំណត់តម្លៃថ្មីទៅលទ្ធផល។
    ///
    /// ត្រឡប់តម្លៃមុន។
    ///
    /// `fetch_xor` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
    /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
    ///
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// ត្រឡប់ទ្រនិចដែលអាចប្តូរបានទៅជា [`bool`] មូលដ្ឋាន។
    ///
    /// ការអានមិនមែនអាតូមអាននិងសរសេរលើចំនួនគត់លទ្ធផលអាចជាការប្រកួតប្រជែងទិន្នន័យ។
    /// វិធីសាស្ត្រនេះភាគច្រើនមានប្រយោជន៍សម្រាប់អេហ្វអេអាយអាយដែលហត្ថលេខាមុខងារអាចប្រើ `*mut bool` ជំនួសឱ្យ `&AtomicBool` ។
    ///
    /// ត្រឡប់ទ្រនិច `*mut` ពីឯកសារយោងដែលបានចែករំលែកទៅអាតូមនេះគឺមានសុវត្ថិភាពពីព្រោះប្រភេទអាតូមធ្វើការជាមួយការផ្លាស់ប្តូរផ្ទៃក្នុង។
    /// ការកែប្រែទាំងអស់នៃការផ្លាស់ប្តូរតម្លៃតាមរយៈសេចក្តីបរមាណូចែករំលែកហើយអាចធ្វើដូច្នេះបានដោយសុវត្ថិភាពដែលវែងដូចដែលពួកគេបានប្រើប្រតិបត្ដិបរមាណូ។
    /// ការប្រើណាមួយនៃវត្ថុធាតុដើមដែលត្រូវបានត្រឡប់ព្រួញមួយប្លុក `unsafe` តម្រូវឱ្យមាននិងនៅតែមានដើម្បីលើកកំពស់ការដាក់កម្រិតដូចគ្នានេះដែរ: ប្រតិបត្ដិការនៅលើវាត្រូវតែបរមាណូ។
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// រកតម្លៃហើយអនុវត្តមុខងារមួយទៅវាដែលត្រឡប់តម្លៃថ្មីស្រេចចិត្ត។ត្រឡប់ `Result` នៃ `Ok(previous_value)` ប្រសិនបើអនុគមន៍ដែលបានត្រឡប់មកវិញ `Some(_)`, ផ្សេងទៀត `Err(previous_value)` ។
    ///
    /// Note: នេះអាចហៅមុខងារច្រើនដងប្រសិនបើតម្លៃត្រូវបានផ្លាស់ប្តូរពីខ្សែស្រឡាយផ្សេងទៀតក្នុងពេលតែមួយដរាបណាមុខងារត្រឡប់ `Some(_)` ប៉ុន្តែមុខងារនឹងត្រូវបានអនុវត្តតែមួយដងគត់ចំពោះតម្លៃដែលបានរក្សាទុក។
    ///
    ///
    /// `fetch_update` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// ទីមួយពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ពេលប្រតិបត្តិការទទួលជោគជ័យខណៈពេលទីពីរពិពណ៌នាអំពីលំដាប់ដែលត្រូវការសម្រាប់បន្ទុក។
    /// ទាំងនេះត្រូវគ្នាទៅនឹងលំដាប់ជោគជ័យនិងបរាជ័យនៃ [`AtomicBool::compare_exchange`] រៀងៗខ្លួន។
    ///
    /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកមួយនៃប្រតិបត្តិការនេះ [`Relaxed`] និងការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យចុងក្រោយ។
    /// ការបញ្ជាទិញបន្ទុក (failed) អាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមនៅលើ `u8` ប៉ុណ្ណោះ។
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// បង្កើត `AtomicPtr` ថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅទ្រនិចមូលដ្ឋាន។
    ///
    /// នេះគឺជាការមានសុវត្ថិភាពដោយសារតែការធានាយោង mutable ថាគ្មានខ្សែស្រឡាយដទៃទៀតត្រូវបានចូលដំណើរការទិន្នន័យបរមាណូដែលស្របគ្នានោះដែរ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ទទួលបានអាតូមចូលទៅទ្រនិចចង្អុល។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ឯកសារយោងដែលអាចផ្លាស់ប្តូរបានធានានូវភាពជាម្ចាស់តែមួយគត់។
        //  - ការតម្រឹមនៃ `*mut T` និង `Self` នេះគឺដូចគ្នានៅលើគ្រប់វេទិកាទាំងអស់ដែលបានគាំទ្រដោយ rust, ជាការផ្ទៀងផ្ទាត់ខាងលើ។
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// ប្រើប្រាស់អាតូមិចហើយត្រឡប់តម្លៃដែលមាន។
    ///
    /// នេះមានសុវត្ថិភាពពីព្រោះការឆ្លងកាត់ `self` ដោយតម្លៃធានាថាមិនមានខ្សែស្រឡាយផ្សេងទៀតចូលក្នុងទិន្នន័យអាតូមិកទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// ផ្ទុកតម្លៃពីទ្រនិច។
    ///
    /// `load` ត្រូវចំណាយពេលជាអាគុយម៉ង់ [`Ordering`] ដែលរៀបរាប់អំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// តម្លៃដែលអាចគឺ [`SeqCst`], [`Acquire`] និង [`Relaxed`] ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `order` គឺ [`Release`] ឬ [`AcqRel`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// រក្សាទុកតម្លៃទៅព្រួញនេះ។
    ///
    /// `store` ត្រូវចំណាយពេលជាអាគុយម៉ង់ [`Ordering`] ដែលរៀបរាប់អំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// តម្លៃដែលអាចមានគឺ [`SeqCst`], [`Release`] និង [`Relaxed`] ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `order` គឺ [`Acquire`] ឬ [`AcqRel`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// រក្សាទុកតម្លៃទៅក្នុងទ្រនិចចង្អុលត្រឡប់តម្លៃមុន។
    ///
    /// `swap` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
    /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
    ///
    ///
    /// **Note:** វិធីសាស្រ្តនេះគឺអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រដល់ប្រតិបត្តិការអាតូមនៅលើចង្អុល។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// រក្សាទុកតម្លៃមួយទៅក្នុងទ្រនិចបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
    ///
    /// តម្លៃត្រឡប់តែងតែជាតម្លៃមុន។ប្រសិនបើវាស្មើនឹង `current` បន្ទាប់មកតម្លៃត្រូវបានធ្វើបច្ចុប្បន្នភាព។
    ///
    /// `compare_and_swap` ក៏ត្រូវការអាគុយម៉ង់ [`Ordering`] ដែលពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// សូមកត់សម្គាល់ថាសូម្បីតែនៅពេលដែលប្រើ [`AcqRel`], ប្រតិបត្ដិការនេះអាចនឹងបរាជ័យហេតុដូចនេះហើយអនុវត្តការផ្ទុកគ្រាន់តែ `Acquire` ប៉ុន្តែមិនមានសញ្ញាន័យវិទ្យា `Release` ។
    /// ការប្រើ [`Acquire`] ធ្វើឱ្យហាងនេះជាផ្នែកមួយនៃការប្រតិបត្ដិការនេះប្រសិនបើវាកើតឡើង [`Relaxed`] និងការប្រើ [`Release`] ធ្វើឱ្យបន្ទុកផ្នែក [`Relaxed`] ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះគឺអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រដល់ប្រតិបត្តិការអាតូមនៅលើចង្អុល។
    ///
    /// # ការធ្វើចំណាកស្រុកទៅ `compare_exchange` និង `compare_exchange_weak`
    ///
    /// `compare_and_swap` គឺស្មើនឹង `compare_exchange` ជាមួយផែនទីដូចខាងក្រោមសម្រាប់ការបញ្ជាទិញការចងចាំ:
    ///
    /// ដើម |ជោគជ័យ |ការបរាជ័យ
    /// -------- | ------- | -------
    /// បន្ធូរអារម្មណ៍ |បន្ធូរអារម្មណ៍ |ទទួលបានធូរស្បើយ |ទិញ |ទទួលបានការដោះលែង |ការចេញផ្សាយ |AcqRel បន្ធូរអារម្មណ៍ |AcqRel |ទទួលបាន SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` ត្រូវបានអនុញ្ញាតឱ្យបរាជ័យយ៉ាងខ្លាំងសូម្បីតែការប្រៀបធៀបបានជោគជ័យដែលអនុញ្ញាតឱ្យអ្នកចងក្រងបង្កើតលេខកូដសន្និបាតកាន់តែប្រសើរនៅពេលប្រៀបធៀបនិងស្វបត្រូវបានប្រើក្នុងរង្វិលជុំ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// រក្សាទុកតម្លៃមួយទៅក្នុងទ្រនិចបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
    ///
    /// តម្លៃត្រឡប់ជាលទ្ធផលបង្ហាញថាតើតម្លៃថ្មីត្រូវបានសរសេរនិងមានតម្លៃមុន។
    /// នៅលើភាពជោគជ័យតម្លៃនេះត្រូវបានធានាស្មើនឹង `current` ។
    ///
    /// `compare_exchange` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// `success` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការអាន-កែប្រែ-សរសេរដែលកើតឡើងប្រសិនបើការប្រៀបធៀបជាមួយ `current` ជោគជ័យ។
    /// `failure` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការបន្ទុកដែលកើតឡើងនៅពេលការប្រៀបធៀបបរាជ័យ។
    /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យ។
    ///
    /// ការបញ្ជាទិញបរាជ័យអាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះគឺអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រដល់ប្រតិបត្តិការអាតូមនៅលើចង្អុល។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// រក្សាទុកតម្លៃមួយទៅក្នុងទ្រនិចបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
    ///
    /// មិនដូច [`AtomicPtr::compare_exchange`] អនុគមន៍នេះត្រូវបានអនុញ្ញាតឱ្យបរាជ័យ spuriously សូម្បីតែនៅពេលប្រៀបធៀបទទួលបានជោគជ័យដែលអាចបណ្តាលនៅក្នុងកូដប្រសិទ្ធិភាពបន្ថែមទៀតនៅលើវេទិកាមួយចំនួន។
    ///
    /// តម្លៃត្រឡប់ជាលទ្ធផលបង្ហាញថាតើតម្លៃថ្មីត្រូវបានសរសេរនិងមានតម្លៃមុន។
    ///
    /// `compare_exchange_weak` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// `success` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការអាន-កែប្រែ-សរសេរដែលកើតឡើងប្រសិនបើការប្រៀបធៀបជាមួយ `current` ជោគជ័យ។
    /// `failure` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការបន្ទុកដែលកើតឡើងនៅពេលការប្រៀបធៀបបរាជ័យ។
    /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យ។
    /// ការបញ្ជាទិញបរាជ័យអាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះគឺអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រដល់ប្រតិបត្តិការអាតូមនៅលើចង្អុល។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // សុវត្ថិភាព: ផ្នែកខាងក្នុងនេះមិនមានសុវត្ថិភាពទេពីព្រោះវាដំណើរការលើទ្រនិចឆៅ
        // ប៉ុន្តែយើងដឹងថាសម្រាប់ប្រាកដថាទ្រនិចមានសុពលភាព (យើងគ្រាន់តែទទួលបានវាពី `UnsafeCell` មួយដែលយើងមានដោយសេចក្ដីយោង) និងប្រតិបត្ដិបរមាណូដែលខ្លួនវាបានអនុញ្ញាតឱ្យយើងប្រែប្រួលមាតិកា `UnsafeCell` ដោយសុវត្ថិភាព។
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// រកតម្លៃហើយអនុវត្តមុខងារមួយទៅវាដែលត្រឡប់តម្លៃថ្មីស្រេចចិត្ត។ត្រឡប់ `Result` នៃ `Ok(previous_value)` ប្រសិនបើអនុគមន៍ដែលបានត្រឡប់មកវិញ `Some(_)`, ផ្សេងទៀត `Err(previous_value)` ។
    ///
    /// Note: នេះអាចហៅមុខងារច្រើនដងប្រសិនបើតម្លៃត្រូវបានផ្លាស់ប្តូរពីខ្សែស្រឡាយផ្សេងទៀតក្នុងពេលតែមួយដរាបណាមុខងារត្រឡប់ `Some(_)` ប៉ុន្តែមុខងារនឹងត្រូវបានអនុវត្តតែមួយដងគត់ចំពោះតម្លៃដែលបានរក្សាទុក។
    ///
    ///
    /// `fetch_update` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
    /// ទីមួយពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ពេលប្រតិបត្តិការទទួលជោគជ័យខណៈពេលទីពីរពិពណ៌នាអំពីលំដាប់ដែលត្រូវការសម្រាប់បន្ទុក។
    /// ទាំងនេះត្រូវគ្នាទៅនឹងលំដាប់ជោគជ័យនិងបរាជ័យនៃ [`AtomicPtr::compare_exchange`] រៀងៗខ្លួន។
    ///
    /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកមួយនៃប្រតិបត្តិការនេះ [`Relaxed`] និងការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យចុងក្រោយ។
    /// ការបញ្ជាទិញបន្ទុក (failed) អាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
    ///
    /// **Note:** វិធីសាស្រ្តនេះគឺអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រដល់ប្រតិបត្តិការអាតូមនៅលើចង្អុល។
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// បំលែង `bool` ទៅជា `AtomicBool` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // ម៉ាក្រូនេះបញ្ចប់ដោយមិនប្រើលើស្ថាបត្យកម្មខ្លះ។
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// ប្រភេទចំនួនគត់ដែលអាចចែករំលែករវាងខ្សែស្រឡាយដោយសុវត្ថិភាព។
        ///
        /// ប្រភេទនេះមានដូចគ្នានេះដែរនៅក្នុងការចងចាំតំណាងប្រភេទចំនួនគត់ដែលជាមូលដ្ឋាន, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// សម្រាប់ព័ត៌មានបន្ថែមអំពីភាពខុសគ្នារវាងប្រភេទអាតូមិចនិងប្រភេទមិនមែនអាតូមិចក៏ដូចជាព័ត៌មានអំពីភាពចល័តនៃប្រភេទនេះសូមមើល [module-level documentation] ។
        ///
        ///
        /// **Note:** ប្រភេទនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្របន្ទុកអាតូមនិងហាងរបស់ [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// ចំនួនគត់អាតូមបានចាប់ផ្តើមទៅ `0` ។
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // ការផ្ញើត្រូវបានអនុវត្តយ៉ាងជាក់ស្តែង។
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// បង្កើតចំនួនគត់អាតូមថ្មី។
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅជាចំនួនគត់មូលដ្ឋាន។
            ///
            /// នេះគឺជាការមានសុវត្ថិភាពដោយសារតែការធានាយោង mutable ថាគ្មានខ្សែស្រឡាយដទៃទៀតត្រូវបានចូលដំណើរការទិន្នន័យបរមាណូដែលស្របគ្នានោះដែរ។
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =៥;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// អនុញ្ញាតឱ្យ mut មួយចំនួន_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// ! assert_eq (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ឯកសារយោងដែលអាចផ្លាស់ប្តូរបានធានានូវភាពជាម្ចាស់តែមួយគត់។
                //  - ការតម្រឹមរបស់ `$int_type` និង `Self` គឺដូចគ្នាដូចដែលបានសន្យាដោយ $cfg_align និងបានបញ្ជាក់ខាងលើ។
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// ប្រើប្រាស់អាតូមិចហើយត្រឡប់តម្លៃដែលមាន។
            ///
            /// នេះមានសុវត្ថិភាពពីព្រោះការឆ្លងកាត់ `self` ដោយតម្លៃធានាថាមិនមានខ្សែស្រឡាយផ្សេងទៀតចូលក្នុងទិន្នន័យអាតូមិកទេ។
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// ផ្ទុកតម្លៃពីចំនួនគត់អាតូម។
            ///
            /// `load` ត្រូវចំណាយពេលជាអាគុយម៉ង់ [`Ordering`] ដែលរៀបរាប់អំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
            /// តម្លៃដែលអាចគឺ [`SeqCst`], [`Acquire`] និង [`Relaxed`] ។
            ///
            /// # Panics
            ///
            /// Panics ប្រសិនបើ `order` គឺ [`Release`] ឬ [`AcqRel`] ។
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// រក្សាទុកតម្លៃមួយទៅក្នុងចំនួនគត់អាតូមិច។
            ///
            /// `store` ត្រូវចំណាយពេលជាអាគុយម៉ង់ [`Ordering`] ដែលរៀបរាប់អំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
            ///  តម្លៃដែលអាចមានគឺ [`SeqCst`], [`Release`] និង [`Relaxed`] ។
            ///
            /// # Panics
            ///
            /// Panics ប្រសិនបើ `order` គឺ [`Acquire`] ឬ [`AcqRel`] ។
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// រក្សាទុកតម្លៃមួយទៅក្នុងចំនួនគត់អាតូមដោយត្រឡប់តម្លៃមុន។
            ///
            /// `swap` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// រក្សាទុកតម្លៃមួយទៅក្នុងចំនួនគត់អាតូមប្រសិនបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
            ///
            /// តម្លៃត្រឡប់តែងតែជាតម្លៃមុន។ប្រសិនបើវាស្មើនឹង `current` បន្ទាប់មកតម្លៃត្រូវបានធ្វើបច្ចុប្បន្នភាព។
            ///
            /// `compare_and_swap` ក៏ត្រូវការអាគុយម៉ង់ [`Ordering`] ដែលពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
            /// សូមកត់សម្គាល់ថាសូម្បីតែនៅពេលដែលប្រើ [`AcqRel`], ប្រតិបត្ដិការនេះអាចនឹងបរាជ័យហេតុដូចនេះហើយអនុវត្តការផ្ទុកគ្រាន់តែ `Acquire` ប៉ុន្តែមិនមានសញ្ញាន័យវិទ្យា `Release` ។
            ///
            /// ការប្រើ [`Acquire`] ធ្វើឱ្យហាងនេះជាផ្នែកមួយនៃការប្រតិបត្ដិការនេះប្រសិនបើវាកើតឡើង [`Relaxed`] និងការប្រើ [`Release`] ធ្វើឱ្យបន្ទុកផ្នែក [`Relaxed`] ។
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # ការធ្វើចំណាកស្រុកទៅ `compare_exchange` និង `compare_exchange_weak`
            ///
            /// `compare_and_swap` គឺស្មើនឹង `compare_exchange` ជាមួយផែនទីដូចខាងក្រោមសម្រាប់ការបញ្ជាទិញការចងចាំ:
            ///
            /// ដើម |ជោគជ័យ |ការបរាជ័យ
            /// -------- | ------- | -------
            /// បន្ធូរអារម្មណ៍ |បន្ធូរអារម្មណ៍ |ទទួលបានធូរស្បើយ |ទិញ |ទទួលបានការដោះលែង |ការចេញផ្សាយ |AcqRel បន្ធូរអារម្មណ៍ |AcqRel |ទទួលបាន SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` ត្រូវបានអនុញ្ញាតឱ្យបរាជ័យយ៉ាងខ្លាំងសូម្បីតែការប្រៀបធៀបបានជោគជ័យដែលអនុញ្ញាតឱ្យអ្នកចងក្រងបង្កើតលេខកូដសន្និបាតកាន់តែប្រសើរនៅពេលប្រៀបធៀបនិងស្វបត្រូវបានប្រើក្នុងរង្វិលជុំ។
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// រក្សាទុកតម្លៃមួយទៅក្នុងចំនួនគត់អាតូមប្រសិនបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
            ///
            /// តម្លៃត្រឡប់ជាលទ្ធផលបង្ហាញថាតើតម្លៃថ្មីត្រូវបានសរសេរនិងមានតម្លៃមុន។
            /// នៅលើភាពជោគជ័យតម្លៃនេះត្រូវបានធានាស្មើនឹង `current` ។
            ///
            /// `compare_exchange` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
            /// `success` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការអាន-កែប្រែ-សរសេរដែលកើតឡើងប្រសិនបើការប្រៀបធៀបជាមួយ `current` ជោគជ័យ។
            /// `failure` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការបន្ទុកដែលកើតឡើងនៅពេលការប្រៀបធៀបបរាជ័យ។
            /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យ។
            ///
            /// ការបញ្ជាទិញបរាជ័យអាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// រក្សាទុកតម្លៃមួយទៅក្នុងចំនួនគត់អាតូមប្រសិនបើតម្លៃបច្ចុប្បន្នគឺដូចគ្នានឹងតម្លៃ `current` ។
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// មុខងារនេះត្រូវបានអនុញ្ញាតឱ្យបរាជ័យយ៉ាងឆាប់រហ័សសូម្បីតែការប្រៀបធៀបទទួលជោគជ័យដែលអាចបណ្តាលឱ្យកូដមានប្រសិទ្ធិភាពជាងនៅលើវេទិកាមួយចំនួន។
            /// តម្លៃត្រឡប់ជាលទ្ធផលបង្ហាញថាតើតម្លៃថ្មីត្រូវបានសរសេរនិងមានតម្លៃមុន។
            ///
            /// `compare_exchange_weak` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
            /// `success` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការអាន-កែប្រែ-សរសេរដែលកើតឡើងប្រសិនបើការប្រៀបធៀបជាមួយ `current` ជោគជ័យ។
            /// `failure` ពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ប្រតិបត្តិការបន្ទុកដែលកើតឡើងនៅពេលការប្រៀបធៀបបរាជ័យ។
            /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យ។
            ///
            /// ការបញ្ជាទិញបរាជ័យអាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// អនុញ្ញាតឱ្យ mut ចាស់= val.load(Ordering::Relaxed);
            /// loop {ទុកឱ្យថ្មី=ចាស់ * ២;
            ///     ផ្គូផ្គង val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// បន្ថែមទៅនឹងតម្លៃនាពេលបច្ចុប្បន្ននេះត្រឡប់តម្លៃមុន។
            ///
            /// ប្រតិបត្ដិការនេះគ្របដណ្តប់លើការហៀរចេញ។
            ///
            /// `fetch_add` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// ដកពីតម្លៃបច្ចុប្បន្នដែលបានវិលត្រឡប់តម្លៃមុន។
            ///
            /// ប្រតិបត្ដិការនេះគ្របដណ្តប់លើការហៀរចេញ។
            ///
            /// `fetch_sub` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" ជាមួយនឹងតម្លៃបច្ចុប្បន្ន។
            ///
            /// សម្តែងមួយ bitwise ប្រតិបត្ដិការ "and" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` និងបានកំណត់តម្លៃថ្មីទៅលទ្ធផល។
            ///
            /// ត្រឡប់តម្លៃមុន។
            ///
            /// `fetch_and` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" ជាមួយនឹងតម្លៃបច្ចុប្បន្ន។
            ///
            /// សម្តែងមួយ bitwise ប្រតិបត្ដិការ "nand" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` និងបានកំណត់តម្លៃថ្មីទៅលទ្ធផល។
            ///
            /// ត្រឡប់តម្លៃមុន។
            ///
            /// `fetch_nand` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" ជាមួយនឹងតម្លៃបច្ចុប្បន្ន។
            ///
            /// សម្តែងមួយ bitwise ប្រតិបត្ដិការ "or" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` និងបានកំណត់តម្លៃថ្មីទៅលទ្ធផល។
            ///
            /// ត្រឡប់តម្លៃមុន។
            ///
            /// `fetch_or` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" ជាមួយនឹងតម្លៃបច្ចុប្បន្ន។
            ///
            /// សម្តែងមួយ bitwise ប្រតិបត្ដិការ "xor" លើតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` និងបានកំណត់តម្លៃថ្មីទៅលទ្ធផល។
            ///
            /// ត្រឡប់តម្លៃមុន។
            ///
            /// `fetch_xor` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// រកតម្លៃហើយអនុវត្តមុខងារមួយទៅវាដែលត្រឡប់តម្លៃថ្មីស្រេចចិត្ត។ត្រឡប់ `Result` នៃ `Ok(previous_value)` ប្រសិនបើអនុគមន៍ដែលបានត្រឡប់មកវិញ `Some(_)`, ផ្សេងទៀត `Err(previous_value)` ។
            ///
            /// Note: នេះអាចហៅមុខងារច្រើនដងប្រសិនបើតម្លៃត្រូវបានផ្លាស់ប្តូរពីខ្សែស្រឡាយផ្សេងទៀតក្នុងពេលតែមួយដរាបណាមុខងារត្រឡប់ `Some(_)` ប៉ុន្តែមុខងារនឹងត្រូវបានអនុវត្តតែមួយដងគត់ចំពោះតម្លៃដែលបានរក្សាទុក។
            ///
            ///
            /// `fetch_update` យកអាគុយម៉ង់ [`Ordering`] ចំនួនពីរដើម្បីពិពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។
            /// ទីមួយពិពណ៌នាអំពីការបញ្ជាទិញដែលត្រូវការសម្រាប់ពេលប្រតិបត្តិការទទួលជោគជ័យខណៈពេលទីពីរពិពណ៌នាអំពីលំដាប់ដែលត្រូវការសម្រាប់បន្ទុក។ទាំងនេះត្រូវគ្នាទៅនឹងលំដាប់ជោគជ័យនិងបរាជ័យ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// ការប្រើប្រាស់ [`Acquire`] ជាការបញ្ជាទិញជោគជ័យធ្វើឱ្យផ្នែកមួយនៃប្រតិបត្តិការនេះ [`Relaxed`] និងការប្រើប្រាស់ [`Release`] ធ្វើឱ្យបន្ទុក [`Relaxed`] ទទួលបានជោគជ័យចុងក្រោយ។
            /// ការបញ្ជាទិញបន្ទុក (failed) អាចមានតែ [`SeqCst`], [`Acquire`] ឬ [`Relaxed`] ហើយត្រូវតែស្មើនឹងឬខ្សោយជាងលំដាប់ជោគជ័យ។
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq (x.fetch_update (រៀបតាមលំដាប់: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(7));
            /// assert_eq (x.fetch_update (រៀបតាមលំដាប់: : SeqCst, Ordering::SeqCst, |! x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// អតិបរមាជាមួយតម្លៃបច្ចុប្បន្ន។
            ///
            /// រកឃើញអតិបរមានៃតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` និងការកំណត់តម្លៃថ្មីទៅលទ្ធផល។
            ///
            /// ត្រឡប់តម្លៃមុន។
            ///
            /// `fetch_max` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// អនុញ្ញាតឱ្យរបារ=42;
            /// អនុញ្ញាតអតិបរិមា=foo.fetch_max (បារ, Ordering::SeqCst).max(bar);
            /// អះអាង! (អតិបរមា_foo==៤២);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// អប្បបរមាជាមួយតម្លៃបច្ចុប្បន្ន។
            ///
            /// រកអប្បបរមានៃតម្លៃបច្ចុប្បន្ននិងអាគុយម៉ង់ `val` ហើយកំណត់តម្លៃថ្មីទៅលទ្ធផល។
            ///
            /// ត្រឡប់តម្លៃមុន។
            ///
            /// `fetch_min` យកអាគុយម៉ង់ [`Ordering`] ដែលពណ៌នាអំពីលំដាប់សតិនៃប្រតិបត្តិការនេះ។របៀបនៃការបញ្ជាទិញទាំងអស់អាចធ្វើទៅបាន។
            /// ចំណាំថាការប្រើ [`Acquire`] ធ្វើឱ្យផ្នែកហាងនៃប្រតិបត្តិការនេះ [`Relaxed`] ហើយការប្រើប្រាស់ [`Release`] ធ្វើឱ្យផ្នែកផ្ទុក [`Relaxed`] ។
            ///
            ///
            /// **ចំណាំ**៖ វិធីសាស្ត្រនេះអាចប្រើបានតែនៅលើវេទិកាដែលគាំទ្រប្រតិបត្តិការអាតូមិចប៉ុណ្ណោះ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// អនុញ្ញាតឱ្យរបារ=12;
            /// អនុញ្ញាតឱ្យ min_foo=foo.fetch_min (បារ, Ordering::SeqCst).min(bar);
            /// អះអាង! (min_foo, ១២);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // សុវត្ថិភាព: ការប្រណាំងទិន្នន័យត្រូវបានរារាំងដោយការចូលបរមាណូ។
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// ត្រឡប់ទ្រនិចដែលអាចប្តូរបានទៅជាចំនួនគត់មូលដ្ឋាន។
            ///
            /// ការអានមិនមែនអាតូមអាននិងសរសេរលើចំនួនគត់លទ្ធផលអាចជាការប្រកួតប្រជែងទិន្នន័យ។
            /// វិធីសាស្ត្រនេះភាគច្រើនមានប្រយោជន៍សម្រាប់អេហ្វអេអាយអាយដែលហត្ថលេខាមុខងារអាចប្រើបាន
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// ត្រឡប់ទ្រនិច `*mut` ពីឯកសារយោងដែលបានចែករំលែកទៅអាតូមនេះគឺមានសុវត្ថិភាពពីព្រោះប្រភេទអាតូមធ្វើការជាមួយការផ្លាស់ប្តូរផ្ទៃក្នុង។
            /// ការកែប្រែទាំងអស់នៃការផ្លាស់ប្តូរតម្លៃតាមរយៈសេចក្តីបរមាណូចែករំលែកហើយអាចធ្វើដូច្នេះបានដោយសុវត្ថិភាពដែលវែងដូចដែលពួកគេបានប្រើប្រតិបត្ដិបរមាណូ។
            /// ការប្រើណាមួយនៃវត្ថុធាតុដើមដែលត្រូវបានត្រឡប់ព្រួញមួយប្លុក `unsafe` តម្រូវឱ្យមាននិងនៅតែមានដើម្បីលើកកំពស់ការដាក់កម្រិតដូចគ្នានេះដែរ: ប្រតិបត្ដិការនៅលើវាត្រូវតែបរមាណូ។
            ///
            ///
            /// # Examples
            ///
            /// `` `មិនអើពើ (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ខាងក្រៅ "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // សុវត្ថិភាព: សុវត្ថិភាពដរាបណា `my_atomic_op` គឺបរមាណូ។
            /// គ្មានសុវត្ថិភាព {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_store` ។
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_load` ។
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_swap` ។
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// ត្រឡប់តម្លៃមុន (ដូចជា __sync_fetch_and_add) ។
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_add` ។
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// ត្រឡប់តម្លៃមុន (ដូចជា __sync_fetch_and_sub) ។
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_sub` ។
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_compare_exchange` ។
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_compare_exchange_weak` ។
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// ត្រឡប់តម្លៃអតិបរមា (ការប្រៀបធៀបដែលបានចុះហត្ថលេខា)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// ត្រឡប់តម្លៃអប្បបរមា (ការប្រៀបធៀបដែលបានចុះហត្ថលេខា)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// ត្រឡប់តម្លៃអតិបរមា (ការប្រៀបធៀបដែលមិនបានចុះហត្ថលេខា)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// ត្រឡប់តម្លៃអប្បបរមា (ការប្រៀបធៀបមិនបានចុះហត្ថលេខា)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// របងបរមាណូ។
///
/// ដោយផ្អែកលើលំដាប់ដែលបានបញ្ជាក់របងការពារអ្នកចងក្រងនិងស៊ីភីយូពីការតំរែតំរង់ប្រភេទជាក់លាក់នៃប្រតិបត្តិការអង្គចងចាំនៅជុំវិញវា។
/// នោះបង្កើតសមកាលកម្ម-ជាមួយទំនាក់ទំនងរវាងវានិងប្រតិបត្តិការអាតូមឬរបងនៅក្នុងខ្សែស្រឡាយផ្សេងទៀត។
///
/// របង 'A' ដែលមាន (យ៉ាងហោចណាស់) [`Release`] តម្រៀបពាក្យគន្លឹះធ្វើសមកាលកម្មជាមួយរបង 'B' ជាមួយ (យ៉ាងហោចណាស់) វណ្ណយុត្តិ [`Acquire`] ប្រសិនបើនិងមានតែប្រសិនបើមានប្រតិបត្តិការ X និង Y ប្រតិបត្តិការទាំងពីរលើវត្ថុអាតូមិច 'M' ដូចជា A ត្រូវបានដាក់មុន X, Y ត្រូវបានធ្វើសមកាលកម្មមុនពេល B និង Y សង្កេតមើលការផ្លាស់ប្តូរទៅ M ។
/// នេះផ្តល់នូវការពឹងផ្អែកដែលកើតឡើងមុនពេលរវាង A និងខ។
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// ប្រតិបត្ដិការអាតូមជាមួយទ្រីនិច [`Release`] ឬ [`Acquire`] ក៏អាចធ្វើសមកាលកម្មជាមួយនឹងរបងផងដែរ។
///
/// របងដែលមានលំដាប់ [`SeqCst`] បន្ថែមទៅមានទាំងពីរសញ្ញាន័យវិទ្យា [`Acquire`] និង [`Release`] ការចូលរួមនៅក្នុងលំដាប់នៃកម្មវិធីជាសកលប្រតិបត្ដិការនិង/ឬរបង [`SeqCst`] ផ្សេងទៀត។
///
/// ទទួលយកការបញ្ជាទិញ [`Acquire`], [`Release`], [`AcqRel`] និង [`SeqCst`] ។
///
/// # Panics
///
/// Panics ប្រសិនបើ `order` គឺ [`Relaxed`] ។
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // ការដកចេញពីគ្នាទៅវិញទៅមកដែលមានមូលដ្ឋានលើការវិល។
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // រង់ចាំរហូតដល់តម្លៃចាស់គឺ `false` ។
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // របងនេះធ្វើសមកាលកម្មជាមួយនឹងហាងនៅ `unlock` ។
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // សុវត្ថិភាព: ការប្រើរបងអាតូមគឺមានសុវត្ថិភាព។
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// របងចងចាំចងក្រង។
///
/// `compiler_fence` មិនបញ្ចេញលេខកូដម៉ាស៊ីនណាមួយឡើយប៉ុន្តែកំណត់ប្រភេទមេម៉ូរីឡើងវិញដែលអ្នកចងក្រងត្រូវបានអនុញ្ញាតិអោយធ្វើ។ជាពិសេសដោយអាស្រ័យលើសញ្ញាន័យវិទ្យា [`Ordering`] ដែលបានផ្ដល់ឱ្យ, ចងក្រងអាចនឹងត្រូវបានផ្លាស់ប្តូរពីការដែលមិនបានអនុញ្ញាតឬការសរសេរពីការអានឬបន្ទាប់ពីការហៅមុនពេលទៅផ្នែកផ្សេងទៀតនៃការហៅទៅ `compiler_fence` នេះ។ចំណាំថាវាពិតជា **មិន** រារាំង *ផ្នែករឹង* ពីការធ្វើលំដាប់ឡើងវិញ។
///
/// នេះមិនមែនជាបញ្ហានៅក្នុងបរិបទមួយតែមួយជាខ្សែស្រឡាយប្រតិបត្តិ, ប៉ុន្តែនៅពេលដែលខ្សែស្រឡាយផ្សេងទៀតអាចកែប្រែការចងចាំនៅពេលដូចគ្នានេះដែរដំបូងនៅដូចជាការធ្វើសមកាលកម្មកាន់តែរឹងមាំគឺត្រូវបានទាមទារ [`fence`] ។
///
/// ការបញ្ជាទិញឡើងវិញត្រូវបានរារាំងដោយសូរស័ព្ទដែលមានលំដាប់ផ្សេងគ្នាគឺ៖
///
///  - ជាមួយ [`SeqCst`] គ្មានការបញ្ជាទិញឡើងវិញនូវការអាននិងសរសេរឆ្លងកាត់ចំណុចនេះត្រូវបានអនុញ្ញាតទេ។
///  - ជាមួយ [`Release`] មុនអាននិងសរសេរមិនអាចត្រូវបានផ្លាស់ប្តូរការសរសេរជាបន្តបន្ទាប់ទេ។
///  - ជាមួយ [`Acquire`] ការអាននិងសរសេរជាបន្តបន្ទាប់មិនអាចត្រូវបានផ្លាស់ប្តូរមុនការអានមុនបានទេ។
///  - ជាមួយ [`AcqRel`] វិធានទាំងពីរខាងលើត្រូវបានអនុវត្ត។
///
/// `compiler_fence` ជាទូទៅមានប្រយោជន៍សម្រាប់ការពារខ្សែស្រឡាយពីការប្រណាំង *ជាមួយខ្លួនវា*។នោះគឺប្រសិនបើមានខ្សែស្រឡាយដែលបានផ្តល់ឱ្យគឺត្រូវបានប្រតិបត្តិជាផ្នែកមួយនៃកូដហើយបន្ទាប់មកត្រូវបានរំខាន, និងការចាប់ផ្តើមប្រតិបត្តិការនៅកន្លែងផ្សេងទៀតជាកូដ (ខណៈពេលដែលនៅតែក្នុងខ្សែស្រឡាយដូចគ្នានេះនិងគំនិតនៅតែនៅលើស្នូលដូចគ្នា) ។នៅក្នុងកម្មវិធីប្រពៃណីវាអាចកើតឡើងតែនៅពេលដែលអ្នកដោះស្រាយសញ្ញាត្រូវបានចុះឈ្មោះ។
/// នៅក្នុងកូដកម្រិតទាបជាងនេះស្ថានភាពបែបនេះក៏អាចកើតឡើងផងដែរនៅពេលដោះស្រាយការរំខាននៅពេលអនុវត្តខ្សែស្រឡាយពណ៌បៃតងជាមួយនឹងការបញ្ចោញជាមុន។ ល។
/// អ្នកអានដែលចង់ដឹងចង់ឃើញត្រូវបានលើកទឹកចិត្តឱ្យអានការពិភាក្សារបស់ខឺណែល Linux នៃ [memory barriers] ។
///
/// # Panics
///
/// Panics ប្រសិនបើ `order` គឺ [`Relaxed`] ។
///
/// # Examples
///
/// បើគ្មាន `compiler_fence` ទេ `assert_eq!` នៅក្នុងលេខកូដខាងក្រោមមិនត្រូវបានធានាថានឹងទទួលជោគជ័យឡើយទោះបីមានអ្វីកើតឡើងក្នុងខ្សែតែមួយក៏ដោយ។
/// ដើម្បីមើលឃើញហេតុអ្វីបានជា, ចងចាំថាចងក្រងដោយឥតគិតថ្លៃដើម្បីប្ដូរហាងទៅ `IMPORTANT_VARIABLE` និង `IS_READ` ចាប់តាំងពីពួកគេមាន `Ordering::Relaxed` ទាំងពីរ។ប្រសិនបើវាមិន, និងកម្មវិធីដោះស្រាយការសញ្ញាត្រូវបានដកហូតបន្ទាប់ពីការធ្វើឱ្យទាន់សម័យ `IS_READY` បន្ទាប់មកដោះស្រាយសញ្ញានឹងឃើញ `IS_READY=1` ទេប៉ុន្តែ `IMPORTANT_VARIABLE=0` ។
/// ការប្រើប្រាស់វិធីដោះស្រាយ `compiler_fence` ស្ថានភាពនេះ។
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // រារាំងការសរសេរមុន ៗ ពីការផ្លាស់ប្តូរហួសពីចំនុចនេះ
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // សុវត្ថិភាព: ការប្រើរបងអាតូមគឺមានសុវត្ថិភាព។
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// ផ្តល់សញ្ញាដល់ខួរក្បាលថាវានៅខាងក្នុងរង្វិលជុំវិលដែលរវល់ ("សោវិល") ។
///
/// មុខងារនេះត្រូវបានបដិសេធនៅក្នុងការពេញចិត្តនៃ [`hint::spin_loop`] ។
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}