/// ប្រើសម្រាប់ប្រតិបត្តិការលិបិក្រម (`container[index]`) ក្នុងបរិបទដែលមិនអាចផ្លាស់ប្តូរបាន។
///
/// `container[index]` គឺពិតជាស្ករសំយោគសំរាប់ `*container.index(index)` តែនៅពេលប្រើជាតំលៃដែលមិនអាចផ្លាស់ប្តូរបាន។
/// ប្រសិនបើតម្លៃដែលអាចប្តូរបានត្រូវបានស្នើសុំនោះ [`IndexMut`] ត្រូវបានប្រើជំនួសវិញ។
/// នេះអនុញ្ញាតឱ្យវត្ថុល្អ ៗ ដូចជា `let value = v[index]` ប្រសិនបើប្រភេទ `value` អនុវត្ត [`Copy`] ។
///
/// # Examples
///
/// ឧទាហរណ៍ខាងក្រោមអនុវត្ត `Index` លើកុងដង់ `NucleotideCount` ដែលអាចអានបានដែលធ្វើឱ្យការរាប់បុគ្គលត្រូវបានទាញយកមកវិញជាមួយវាក្យសម្ព័ន្ធលិបិក្រម។
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// ប្រភេទត្រឡប់មកវិញបន្ទាប់ពីការធ្វើលិបិក្រម។
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// អនុវត្តប្រតិបត្តិការលិបិក្រម (`container[index]`) ។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// ប្រើសម្រាប់ប្រតិបត្តិការសន្ទស្សន៍ (`container[index]`) ក្នុងបរិបទដែលអាចផ្លាស់ប្តូរបាន។
///
/// `container[index]` គឺពិតជាស្ករសំយោគសំរាប់ `*container.index_mut(index)` តែនៅពេលប្រើជាតំលៃដែលអាចផ្លាស់ប្តូរបាន។
/// ប្រសិនបើតម្លៃដែលមិនអាចផ្លាស់ប្តូរបានត្រូវបានស្នើសុំនោះ [`Index`] trait ត្រូវបានប្រើជំនួសវិញ។
/// នេះអនុញ្ញាតឱ្យមានរបស់ល្អដូចជា `v[index] = value` ។
///
/// # Examples
///
/// ការអនុវត្តសាមញ្ញបំផុតនៃរចនាសម្ព័ន្ធ `Balance` ដែលមានពីរផ្នែកដែលនីមួយៗអាចត្រូវបានធ្វើលិបិក្រមទៅវិញទៅមកនិងមិនចេះរីងស្ងួត។
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // ក្នុងករណីនេះ `balance[Side::Right]` គឺជាស្ករសម្រាប់ `*balance.index(Side::Right)` ព្រោះយើងមានតែអាន*`balance[Side::Right]` ប៉ុណ្ណោះមិនសរសេរវាទេ។
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // ទោះយ៉ាងណាក៏ដោយក្នុងករណីនេះ `balance[Side::Left]` គឺជាស្ករសម្រាប់ `*balance.index_mut(Side::Left)` ចាប់តាំងពីយើងកំពុងសរសេរ `balance[Side::Left]` ។
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// អនុវត្តប្រតិបត្តិការប្តូរលិបិក្រម (`container[index]`) ។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}