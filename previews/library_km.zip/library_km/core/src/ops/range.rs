use crate::fmt;
use crate::hash::Hash;

/// ជួរមិនមានព្រំដែន (`..`) ។
///
/// `RangeFull` ត្រូវបានប្រើជាចម្បងជា [slicing index] ខ្លីរបស់វាគឺ `..` ។
/// វាមិនអាចប្រើជា [`Iterator`] បានទេព្រោះវាមិនមានចំណុចចាប់ផ្តើម។
///
/// # Examples
///
/// វាក្យសម្ព័ន្ធ `..` គឺជា `RangeFull`:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// វាមិនមានការអនុវត្ត [`IntoIterator`] ទេដូច្នេះអ្នកមិនអាចប្រើវានៅក្នុងរង្វិលជុំ `for` ដោយផ្ទាល់ទេ។
/// វានឹងមិនចងក្រងទេ៖
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// ប្រើជា [slicing index], `RangeFull` ផលិតអារេពេញលេញជាចំណែក។
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // នេះគឺជា `RangeFull`
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// ជួរ (half-open) ត្រូវបានដាក់បញ្ចូលនៅខាងក្រោមនិងផ្តាច់មុខលើ (`start..end`) ។
///
///
/// ជួរ `start..end` មានតំលៃទាំងអស់ជាមួយ `start <= x < end` ។
/// វាទទេប្រសិនបើ `start >= end` ។
///
/// # Examples
///
/// វាក្យសម្ព័ន្ធ `start..end` គឺជា `Range`:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // នេះគឺជា `Range`
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // មិនចម្លង-សូមមើល #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// ព្រំដែនទាបនៃជួរ (inclusive) ។
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// ព្រំដែនខាងលើនៃជួរ (exclusive) ។
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// ត្រឡប់ `true` ប្រសិនបើ `item` មាននៅក្នុងជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ត្រឡប់ `true` ប្រសិនបើជួរមិនមានធាតុ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// ជួរគឺទទេបើភាគីទាំងពីរមិនអាចប្រៀបផ្ទឹមបាន៖
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// ជួរត្រូវបានកំណត់រាប់បញ្ចូលនៅខាងក្រោម (`start..`) ប៉ុណ្ណោះ។
///
/// `RangeFrom` `start..` មានតំលៃទាំងអស់ជាមួយ `x >= start` ។
///
/// *ចំណាំ*៖ ការហៀរចេញក្នុងការអនុវត្ត [`Iterator`] (នៅពេលប្រភេទទិន្នន័យដែលមានដល់ចំនួនកំណត់របស់វា) ត្រូវបានអនុញ្ញាតិឱ្យ panic រុំឬតិត្ថិភាព។
/// អាកប្បកិរិយានេះត្រូវបានកំណត់ដោយការអនុវត្ត [`Step`] trait ។
/// ចំពោះចំនួនគត់បឋមនេះអនុវត្តតាមវិធានធម្មតានិងគោរពទម្រង់ត្រួតពិនិត្យលើសចំណុះ (panic នៅក្នុងការបំបាត់កំហុសរុំក្នុងការដោះលែង) ។
/// សូមកត់សម្គាល់ផងដែរថាការហៀរចេញកើតឡើងមុនពេលដែលអ្នកសន្មតថា: ការហូរហៀរកើតឡើងនៅក្នុងការហៅទៅ `next` ដែលផ្តល់នូវតម្លៃអតិបរមាព្រោះជួរត្រូវតែកំណត់ទៅរដ្ឋដើម្បីផ្តល់តម្លៃបន្ទាប់។
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// វាក្យសម្ព័ន្ធ `start..` គឺជា `RangeFrom`:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // នេះគឺជា `RangeFrom`
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // មិនចម្លង-សូមមើល #27186
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// ព្រំដែនទាបនៃជួរ (inclusive) ។
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// ត្រឡប់ `true` ប្រសិនបើ `item` មាននៅក្នុងជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// ជួរមួយត្រូវបានកំណត់ត្រឹមតែលើសពី (`..end`) ប៉ុណ្ណោះ។
///
/// `RangeTo` `..end` មានតំលៃទាំងអស់ជាមួយ `x < end` ។
/// វាមិនអាចប្រើជា [`Iterator`] បានទេព្រោះវាមិនមានចំណុចចាប់ផ្តើម។
///
/// # Examples
///
/// វាក្យសម្ព័ន្ធ `..end` គឺជា `RangeTo`:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// វាមិនមានការអនុវត្ត [`IntoIterator`] ទេដូច្នេះអ្នកមិនអាចប្រើវានៅក្នុងរង្វិលជុំ `for` ដោយផ្ទាល់ទេ។
/// វានឹងមិនចងក្រងទេ៖
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// នៅពេលប្រើជា [slicing index], `RangeTo` ផលិតចំណែកនៃធាតុអារេទាំងអស់មុនពេលសន្ទស្សន៍បង្ហាញដោយ `end` ។
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // នេះគឺជា `RangeTo`
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// ព្រំដែនខាងលើនៃជួរ (exclusive) ។
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// ត្រឡប់ `true` ប្រសិនបើ `item` មាននៅក្នុងជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// ជួរត្រូវបានកំណត់រាប់បញ្ចូលខាងក្រោមនិងខ្ពស់ជាង (`start..=end`) ។
///
/// `RangeInclusive` `start..=end` មានតំលៃទាំងអស់ជាមួយ `x >= start` និង `x <= end` ។វាទទេលុះត្រាតែ `start <= end` ។
///
/// ឧបករណ៍ដដែលនេះគឺ [fused] ប៉ុន្តែតម្លៃជាក់លាក់នៃ `start` និង `end` បន្ទាប់ពីការធ្វើឡើងវិញបានបញ្ចប់គឺ **មិនបានបញ្ជាក់** ក្រៅពី [`.is_empty()`] នឹងត្រឡប់ `true` វិញនៅពេលដែលគ្មានតម្លៃណាមួយនឹងត្រូវបានផលិត។
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// វាក្យសម្ព័ន្ធ `start..=end` គឺជា `RangeInclusive`:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // នេះគឺជា `RangeInclusive`
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // មិនចម្លង-សូមមើល #27186
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // ចំណាំថាវាលនៅទីនេះមិនមែនជាសាធារណៈដើម្បីអនុញ្ញាតឱ្យផ្លាស់ប្តូរតំណាងនៅក្នុង future;ជាពិសេសខណៈពេលដែលយើងអាចបង្ហាញ start/end យ៉ាងច្បាស់ការកែប្រែពួកវាដោយមិនផ្លាស់ប្តូរកន្លែងឯកជន (future/current) អាចនាំឱ្យមានអាកប្បកិរិយាមិនត្រឹមត្រូវដូច្នេះយើងមិនចង់គាំទ្ររបៀបនោះទេ។
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // វាលនេះគឺ៖
    //  - `false` នៅពេលសាងសង់
    //  - `false` នៅពេលដែលការនិយាយឡើងវិញបានផ្តល់នូវធាតុមួយហើយទ្រនាប់ទ្រនាប់មិនអស់កម្លាំងទេ
    //  - `true` នៅពេលដែលការនិយាយឡើងវិញត្រូវបានគេប្រើដើម្បីធ្វើអោយវាហួសកំរិត
    //
    // នេះត្រូវបានទាមទារដើម្បីគាំទ្រផ្នែកខ្លះនៃអេចនិងហាសដោយគ្មានការចងឬផ្នែកជំនាញ។
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// បង្កើតជួរបញ្ចូលថ្មី។ស្មើនឹងការសរសេរ `start..=end` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// ត្រឡប់ព្រំដែនទាបនៃជួរ (inclusive) ។
    ///
    /// នៅពេលប្រើជួរបញ្ចូលគ្នាសម្រាប់ការនិយាយឡើងវិញតម្លៃរបស់ `start()` និង [`end()`] មិនត្រូវបានបញ្ជាក់ទេបន្ទាប់ពីការបញ្ចប់បានបញ្ចប់។
    /// ដើម្បីកំណត់ថាតើជួរបញ្ចូលគឺទទេប្រើវិធីសាស្ត្រ [`is_empty()`] ជំនួសឱ្យការប្រៀបធៀប `start() > end()` ។
    ///
    /// Note: តម្លៃដែលបានត្រឡប់មកវិញដោយវិធីសាស្រ្តនេះមិនត្រូវបានបញ្ជាក់ទេបន្ទាប់ពីជួរត្រូវបានធ្វើឱ្យធុញទ្រាន់។
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// ត្រឡប់ព្រំដែនខាងលើនៃជួរ (inclusive) ។
    ///
    /// នៅពេលប្រើជួរបញ្ចូលគ្នាសម្រាប់ការនិយាយឡើងវិញតម្លៃរបស់ [`start()`] និង `end()` មិនត្រូវបានបញ្ជាក់ទេបន្ទាប់ពីការបញ្ចប់បានបញ្ចប់។
    /// ដើម្បីកំណត់ថាតើជួរបញ្ចូលគឺទទេប្រើវិធីសាស្ត្រ [`is_empty()`] ជំនួសឱ្យការប្រៀបធៀប `start() > end()` ។
    ///
    /// Note: តម្លៃដែលបានត្រឡប់មកវិញដោយវិធីសាស្រ្តនេះមិនត្រូវបានបញ្ជាក់ទេបន្ទាប់ពីជួរត្រូវបានធ្វើឱ្យធុញទ្រាន់។
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// ការបំផ្លាញ `RangeInclusive` ទៅជា (ព្រំដែនទាប, អក្សរ (inclusive) ខ្ពស់) ។
    ///
    /// Note: តម្លៃដែលបានត្រឡប់មកវិញដោយវិធីសាស្រ្តនេះមិនត្រូវបានបញ្ជាក់ទេបន្ទាប់ពីជួរត្រូវបានធ្វើឱ្យធុញទ្រាន់។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// បម្លែងទៅជា `Range` ផ្តាច់មុខសម្រាប់ការអនុវត្ត `SliceIndex` ។
    /// អ្នកទូរស័ព្ទចូលទទួលខុសត្រូវក្នុងការដោះស្រាយជាមួយនឹងអ៊ិច។
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // ប្រសិនបើយើងមិនអស់កម្លាំងទេយើងចង់បង្រួម `start..end + 1` ។
        // ប្រសិនបើយើងអស់កម្លាំងបន្ទាប់មកការរអិលជាមួយ `end + 1..end + 1` ផ្តល់ឱ្យយើងនូវជួរទទេដែលនៅតែជាប្រធានបទនៃការត្រួតពិនិត្យព្រំដែនសម្រាប់ចំណុចនោះ។
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// ត្រឡប់ `true` ប្រសិនបើ `item` មាននៅក្នុងជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// វិធីសាស្រ្តនេះតែងតែត្រឡប់ `false` បន្ទាប់ពីការនិយាយឡើងវិញបានចប់៖
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // តម្លៃវាលច្បាស់លាស់មិនត្រូវបានបញ្ជាក់នៅទីនេះទេ
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ត្រឡប់ `true` ប្រសិនបើជួរមិនមានធាតុ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// ជួរគឺទទេបើភាគីទាំងពីរមិនអាចប្រៀបផ្ទឹមបាន៖
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// វិធីសាស្រ្តនេះត្រឡប់ `true` បន្ទាប់ពីការនិយាយឡើងវិញបានបញ្ចប់៖
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // តម្លៃវាលច្បាស់លាស់មិនត្រូវបានបញ្ជាក់នៅទីនេះទេ
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// ជួរមួយត្រូវបានកំណត់រាប់បញ្ចូលលើសពី (`..=end`) ។
///
/// `RangeToInclusive` `..=end` មានតំលៃទាំងអស់ជាមួយ `x <= end` ។
/// វាមិនអាចប្រើជា [`Iterator`] បានទេព្រោះវាមិនមានចំណុចចាប់ផ្តើម។
///
/// # Examples
///
/// វាក្យសម្ព័ន្ធ `..=end` គឺជា `RangeToInclusive`:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// វាមិនមានការអនុវត្ត [`IntoIterator`] ទេដូច្នេះអ្នកមិនអាចប្រើវានៅក្នុងរង្វិលជុំ `for` ដោយផ្ទាល់ទេ។វានឹងមិនចងក្រងទេ៖
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// នៅពេលប្រើជា [slicing index], `RangeToInclusive` បង្កើតចំណែកនៃធាតុអារេទាំងអស់រហូតដល់និងរាប់បញ្ចូលទាំងសន្ទស្សន៍ដែលបង្ហាញដោយ `end` ។
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // នេះគឺជា `RangeToInclusive`
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// ព្រំដែនខាងលើនៃជួរ (inclusive)
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// ត្រឡប់ `true` ប្រសិនបើ `item` មាននៅក្នុងជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeTo រួមបញ្ចូល<Idx>មិនអាចបញ្ជាក់ពី <RangeTo<Idx>> ពីព្រោះការហៀរចេញនឹងអាចធ្វើទៅបានជាមួយ (..0).into()
//

/// ចំណុចបញ្ចប់នៃជួរនៃកូនសោ។
///
/// # Examples
///
/// `ព្រំដែនគឺជាចំណុចបញ្ចប់៖
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// ការប្រើប្រាស់ tuple នៃ `ព្រំដែន 'ជាអាគុយម៉ង់ចំពោះ [`BTreeMap::range`] ។
/// ចំណាំថាក្នុងករណីភាគច្រើនវាជាការប្រសើរក្នុងការប្រើវាក្យសម្ព័ន្ធជួរ (`1..5`) ជំនួសវិញ។
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// ព្រំដែនរួមបញ្ចូល។
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ព្រំដែនផ្តាច់មុខ។
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// ចំណុចបញ្ចប់គ្មានទីបញ្ចប់។បង្ហាញថាគ្មានទិសដៅក្នុងទិសដៅនេះទេ។
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// បំលែងពី `&Bound<T>` ទៅ `Bound<&T>` ។
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// បំលែងពី `&mut Bound<T>` ទៅ `Bound<&T>` ។
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// គូសផែនទី `Bound<&T>` ទៅ `Bound<T>` ដោយក្លូនមាតិកានៃព្រំដែន។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` ត្រូវបានអនុវត្តដោយប្រភេទជួរដែលភ្ជាប់មកជាមួយរបស់ Rust ផលិតដោយវាក្យសម្ព័ន្ធជួរដូចជា `..`, `a..`, `..b`, `..=c`, `d..e`, ឬ `f..=g` ។
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// ចាប់ផ្តើមចងសន្ទស្សន៍។
    ///
    /// ត្រឡប់តម្លៃចាប់ផ្តើមជា `Bound` ។
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// បញ្ចប់សន្ទស្សន៍។
    ///
    /// ត្រឡប់តម្លៃបញ្ចប់ជា `Bound` ។
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// ត្រឡប់ `true` ប្រសិនបើ `item` មាននៅក្នុងជួរ។
    ///
    /// # Examples
    ///
    /// ```
    /// អះអាង! ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// អះអាង! ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // នៅពេលដែលឧបករណ៍រំកិលហត់នឿយយើងច្រើនតែចាប់ផ្តើម==ចប់ប៉ុន្តែយើងចង់អោយជួរលេចចេញដោយគ្មានផ្ទុកអ្វីទាំងអស់។
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}