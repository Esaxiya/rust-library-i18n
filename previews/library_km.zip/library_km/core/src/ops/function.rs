/// កំណែនៃប្រតិបត្តិករហៅដែលយកអ្នកទទួលដែលមិនអាចផ្លាស់ប្តូរបាន។
///
/// វត្ថុនៃ `Fn` អាចត្រូវបានគេហៅថាម្តងហើយម្តងទៀតដោយគ្មានការផ្លាស់ប្តូរស្ថានភាព។
///
/// *trait (`Fn`) នេះមិនត្រូវច្រឡំជាមួយ [function pointers] (`fn`) ទេ។*
///
/// `Fn` ត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិដោយការបិទដែលមានតែសេចក្តីយោងដែលមិនអាចផ្លាស់ប្តូរបានចំពោះអថេរដែលបានចាប់យកឬមិនចាប់យកអ្វីទាំងអស់ក៏ដូចជា (safe) [function pointers] (ជាមួយសំភារៈមួយចំនួនសូមមើលឯកសាររបស់ពួកគេសម្រាប់ព័ត៌មានលម្អិត) ។
///
/// លើសពីនេះទៀតសម្រាប់ប្រភេទ `F` ណាមួយដែលអនុវត្ត `Fn`, `&F` អនុវត្ត `Fn` ផងដែរ។
///
/// ដោយសារទាំង [`FnMut`] និង [`FnOnce`] គឺជាគំរូនៃ `Fn` ឧទាហរណ៍ណាមួយនៃ `Fn` អាចត្រូវបានប្រើជាប៉ារ៉ាម៉ែត្រដែល [`FnMut`] ឬ [`FnOnce`] ត្រូវបានរំពឹងទុក។
///
/// ប្រើ `Fn` ជាការចងនៅពេលអ្នកចង់ទទួលយកប៉ារ៉ាម៉ែត្រនៃប្រភេទមុខងារនិងត្រូវហៅវាម្តងហើយម្តងទៀតនិងដោយមិនផ្លាស់ប្តូរស្ថានភាព (ឧទាហរណ៍នៅពេលហៅវាក្នុងពេលដំណាលគ្នា) ។
/// ប្រសិនបើអ្នកមិនត្រូវការតំរូវការតឹងរឹងបែបនេះទេសូមប្រើ [`FnMut`] ឬ [`FnOnce`] ជាព្រំដែន។
///
/// សូមមើល [chapter on closures in *The Rust Programming Language*][book] សម្រាប់ព័ត៌មានបន្ថែមអំពីប្រធានបទនេះ។
///
/// ចំណាំផងដែរគឺវាក្យសម្ព័ន្ធពិសេសសម្រាប់ `Fn` traits (ឧ
/// `Fn(usize, bool) -> usize`) ។អ្នកដែលចាប់អារម្មណ៍លើព័ត៌មានលម្អិតបច្ចេកទេសនៃបញ្ហានេះអាចយោងទៅលើ [the relevant section in the *Rustonomicon*][nomicon] ។
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ហៅការបិទ
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## ការប្រើប្រាស់ប៉ារ៉ាម៉ែត្រ `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ដូច្នេះ regex អាចជឿជាក់ថា `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// អនុវត្តប្រតិបត្តិការហៅ។
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// កំណែរបស់ប្រតិបត្តិករហៅដែលយកអ្នកទទួលដែលអាចប្តូរបាន។
///
/// វត្ថុនៃ `FnMut` អាចត្រូវបានគេហៅថាម្តងហើយម្តងទៀតហើយអាចផ្លាស់ប្តូរស្ថានភាព។
///
/// `FnMut` ត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិដោយការបិទដែលយកសេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅរកអថេរដែលបានចាប់យកក៏ដូចជាប្រភេទទាំងអស់ដែលអនុវត្ត [`Fn`] ឧទាហរណ៍ (safe) [function pointers] (ចាប់តាំងពី `FnMut` គឺជា supertrait of [`Fn`]) ។
/// លើសពីនេះទៀតសម្រាប់ប្រភេទ `F` ណាមួយដែលអនុវត្ត `FnMut`, `&mut F` អនុវត្ត `FnMut` ផងដែរ។
///
/// ចាប់តាំងពី [`FnOnce`] គឺជាគំរូនៃ `FnMut` វត្ថុណាមួយនៃ `FnMut` អាចត្រូវបានប្រើដែលជាកន្លែងដែល [`FnOnce`] ត្រូវបានរំពឹងទុកហើយចាប់តាំងពី [`Fn`] គឺជាអក្សររត់នៃ `FnMut` ឧទាហរណ៍ណាមួយនៃ [`Fn`] អាចត្រូវបានប្រើនៅកន្លែងដែល `FnMut` ត្រូវបានរំពឹងទុក។
///
/// ប្រើ `FnMut` ជាការចងនៅពេលអ្នកចង់ទទួលយកប៉ារ៉ាម៉ែត្រនៃប្រភេទមុខងារនិងត្រូវហៅវាម្តងហើយម្តងទៀតខណៈពេលដែលអនុញ្ញាតឱ្យវាផ្លាស់ប្តូរស្ថានភាព។
/// ប្រសិនបើអ្នកមិនចង់ឱ្យប៉ារ៉ាម៉ែត្រផ្លាស់ប្តូរស្ថានភាពប្រើ [`Fn`] ជាព្រំដែន;ប្រសិនបើអ្នកមិនចាំបាច់ហៅវាម្តងហើយម្តងទៀតសូមប្រើ [`FnOnce`] ។
///
/// សូមមើល [chapter on closures in *The Rust Programming Language*][book] សម្រាប់ព័ត៌មានបន្ថែមអំពីប្រធានបទនេះ។
///
/// ចំណាំផងដែរគឺវាក្យសម្ព័ន្ធពិសេសសម្រាប់ `Fn` traits (ឧ
/// `Fn(usize, bool) -> usize`) ។អ្នកដែលចាប់អារម្មណ៍លើព័ត៌មានលម្អិតបច្ចេកទេសនៃបញ្ហានេះអាចយោងទៅលើ [the relevant section in the *Rustonomicon*][nomicon] ។
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ការហៅការបិទការចាប់យកគ្នាទៅវិញទៅមក
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## ការប្រើប្រាស់ប៉ារ៉ាម៉ែត្រ `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ដូច្នេះ regex អាចជឿជាក់ថា `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// អនុវត្តប្រតិបត្តិការហៅ។
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// កំណែរបស់ប្រតិបត្តិករហៅដែលយកអ្នកទទួលតាមតម្លៃ។
///
/// ករណីនៃ `FnOnce` អាចត្រូវបានហៅប៉ុន្តែប្រហែលជាមិនអាចហៅច្រើនដងទេ។ដោយសារតែនេះ, ប្រសិនបើរឿងតែដឹងអំពីប្រភេទគឺថាវាអនុវត្ត `FnOnce`, វាអាចត្រូវបានហៅតែម្ដងប៉ុណ្ណោះ។
///
/// `FnOnce` ត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិដោយការបិទដែលអាចប្រើប្រាស់អថេរដែលបានចាប់យកក៏ដូចជាប្រភេទទាំងអស់ដែលអនុវត្ត [`FnMut`] ឧទាហរណ៍ (safe) [function pointers] (ចាប់តាំងពី `FnOnce` គឺជា supertrait of [`FnMut`]) ។
///
///
/// ដោយហេតុថាទាំង [`Fn`] និង [`FnMut`] គឺជាអនុផ្នែកនៃ `FnOnce`, វត្ថុណាមួយនៃ [`Fn`] ឬ [`FnMut`] អាចត្រូវបានប្រើនៅពេលដែល `FnOnce` ត្រូវបានរំពឹងទុក។
///
/// ប្រើ `FnOnce` ជាការចងនៅពេលអ្នកចង់ទទួលយកប៉ារ៉ាម៉ែត្រនៃប្រភេទដូចមុខងារហើយគ្រាន់តែត្រូវការហៅវាម្តង។
/// ប្រសិនបើអ្នកត្រូវការហៅប៉ារ៉ាម៉ែត្រម្តងហើយម្តងទៀតសូមប្រើ [`FnMut`] ជាព្រំដែន;ប្រសិនបើអ្នកក៏ត្រូវការវាមិនប្តូរស្ថានភាពប្រើ [`Fn`] ។
///
/// សូមមើល [chapter on closures in *The Rust Programming Language*][book] សម្រាប់ព័ត៌មានបន្ថែមអំពីប្រធានបទនេះ។
///
/// ចំណាំផងដែរគឺវាក្យសម្ព័ន្ធពិសេសសម្រាប់ `Fn` traits (ឧ
/// `Fn(usize, bool) -> usize`) ។អ្នកដែលចាប់អារម្មណ៍លើព័ត៌មានលម្អិតបច្ចេកទេសនៃបញ្ហានេះអាចយោងទៅលើ [the relevant section in the *Rustonomicon*][nomicon] ។
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ការប្រើប្រាស់ប៉ារ៉ាម៉ែត្រ `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` ប្រើប្រាស់អថេរដែលចាប់បានដូច្នេះវាមិនអាចដំណើរការបានច្រើនជាងម្តងទេ។
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // ព្យាយាមហៅ `func()` ជាថ្មីម្តងទៀតនឹងបោះកំហុស `use of moved value` សម្រាប់ `func` ។
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` មិនអាចត្រូវបានហៅនៅចំណុចនេះទៀតទេ
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // ដូច្នេះ regex អាចជឿជាក់ថា `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// ប្រភេទត្រឡប់មកវិញបន្ទាប់ពីប្រតិបត្តិករហៅត្រូវបានប្រើ។
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// អនុវត្តប្រតិបត្តិការហៅ។
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}