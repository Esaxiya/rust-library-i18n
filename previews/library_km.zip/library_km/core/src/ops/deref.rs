/// ត្រូវបានប្រើសម្រាប់ប្រតិបត្តិការដកហូតអសកម្មដូចជា `*v` ។
///
/// ក្រៅពីត្រូវបានប្រើសម្រាប់ប្រតិបត្តិការផ្តាច់ការជាក់ស្តែងជាមួយប្រតិបត្តិករ (unary) `*` នៅក្នុងបរិបទដែលមិនអាចផ្លាស់ប្តូរបាន `Deref` X ក៏ត្រូវបានប្រើដោយអ្នកចងក្រងក្នុងកាលៈទេសៈជាច្រើនផងដែរ។
/// យន្តការនេះមានឈ្មោះថា ['`Deref` coercion'][more] ។
/// នៅក្នុងបរិបទដែលអាចផ្លាស់ប្តូរបាន [`DerefMut`] ត្រូវបានប្រើ។
///
/// ការអនុវត្ត `Deref` សម្រាប់អ្នកចង្អុលឆ្លាតធ្វើឱ្យការចូលប្រើទិន្នន័យនៅពីក្រោយពួកគេមានភាពងាយស្រួលដែលជាមូលហេតុដែលពួកគេអនុវត្ត `Deref` ។
/// ម៉្យាងវិញទៀតច្បាប់ដែលទាក់ទងនឹង `Deref` និង [`DerefMut`] ត្រូវបានរចនាឡើងយ៉ាងពិសេសដើម្បីសម្រួលដល់អ្នកចង្អុលឆ្លាត។
/// ដោយសារតែបញ្ហានេះ ** `Deref` គួរតែត្រូវបានអនុវត្តសម្រាប់តែអ្នកចង្អុលឆ្លាតប៉ុណ្ណោះដើម្បីចៀសវាងការភាន់ច្រលំ។
///
/// សម្រាប់ហេតុផលស្រដៀងគ្នានេះដែរ **trait នេះមិនដែលបរាជ័យទេ**។ការខកខានក្នុងកំឡុងពេលដកហូតអាចមានការភ័ន្តច្រឡំខ្លាំងនៅពេល `Deref` ត្រូវបានគេហៅយ៉ាងច្បាស់។
///
/// # បន្ថែមលើការបង្ខិតបង្ខំ `Deref`
///
/// ប្រសិនបើ `T` អនុវត្ត `Deref<Target = U>` ហើយ `x` គឺជាតម្លៃនៃប្រភេទ `T` បន្ទាប់មក៖
///
/// * នៅក្នុងបរិបទដែលមិនអាចផ្លាស់ប្តូរបាន `*x` (ដែល `T` មិនមែនជាឯកសារយោងរឺក៏ទ្រនិចឆៅទេ) គឺស្មើនឹង `* Deref::deref(&x)` ។
/// * តម្លៃនៃប្រភេទ `&T` ត្រូវបានបង្ខំទៅនឹងតម្លៃនៃប្រភេទ `&U`
/// * `T` អនុវត្តជាក់ស្តែងវិធីសាស្រ្ត (immutable) ទាំងអស់នៃប្រភេទ `U` ។
///
/// សម្រាប់ព័ត៌មានលម្អិតសូមចូលទៅកាន់ [the chapter in *The Rust Programming Language*][book] ក៏ដូចជាផ្នែកយោងនៅលើ [the dereference operator][ref-deref-op], [method resolution] និង [type coercions] ។
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// រចនាសម្ព័ន្ធដែលមានវាលតែមួយដែលអាចចូលដំណើរការបានដោយការបដិសេធរចនាសម្ព័ន្ធ។
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// ប្រភេទលទ្ធផលបន្ទាប់ពីការបដិសេធ។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// សេចក្តីយោងតម្លៃ។
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// ត្រូវបានប្រើសម្រាប់ប្រតិបត្ដិការដកហូតបានដូចជានៅក្នុង `*v = 1;` ។
///
/// ក្រៅពីត្រូវបានប្រើសម្រាប់ប្រតិបត្តិការផ្តាច់ទំនាក់ទំនងជាក់ស្តែងជាមួយប្រតិបត្តិករ (unary) `*` ក្នុងបរិបទដែលអាចផ្លាស់ប្តូរបាន `DerefMut` X ក៏ត្រូវបានប្រើដោយអ្នកចងក្រងក្នុងកាលៈទេសៈជាច្រើនផងដែរ។
/// យន្តការនេះមានឈ្មោះថា ['`Deref` coercion'][more] ។
/// នៅក្នុងបរិបទដែលមិនអាចផ្លាស់ប្តូរបាន [`Deref`] ត្រូវបានប្រើ។
///
/// ការអនុវត្ត `DerefMut` សម្រាប់អ្នកចង្អុលឆ្លាតធ្វើឱ្យការផ្លាស់ប្តូរទិន្នន័យនៅពីក្រោយពួកគេមានភាពងាយស្រួលដែលជាមូលហេតុដែលពួកគេអនុវត្ត `DerefMut` ។
/// ម៉្យាងវិញទៀតច្បាប់ដែលទាក់ទងនឹង [`Deref`] និង `DerefMut` ត្រូវបានរចនាឡើងយ៉ាងពិសេសដើម្បីសម្រួលដល់អ្នកចង្អុលឆ្លាត។
/// ដោយសារតែបញ្ហានេះ ** `DerefMut` គួរតែត្រូវបានអនុវត្តសម្រាប់តែអ្នកចង្អុលឆ្លាតប៉ុណ្ណោះដើម្បីចៀសវាងការភាន់ច្រលំ។
///
/// សម្រាប់ហេតុផលស្រដៀងគ្នានេះដែរ **trait នេះមិនដែលបរាជ័យទេ**។ការខកខានក្នុងកំឡុងពេលដកហូតអាចមានការភ័ន្តច្រឡំខ្លាំងនៅពេល `DerefMut` ត្រូវបានគេហៅយ៉ាងច្បាស់។
///
/// # បន្ថែមលើការបង្ខិតបង្ខំ `Deref`
///
/// ប្រសិនបើ `T` អនុវត្ត `DerefMut<Target = U>` ហើយ `x` គឺជាតម្លៃនៃប្រភេទ `T` បន្ទាប់មក៖
///
/// * នៅក្នុងបរិបទដែលអាចផ្លាស់ប្តូរបាន `*x` (ដែល `T` មិនមែនជាឯកសារយោងរឺក៏ទ្រនិចឆៅទេ) គឺស្មើនឹង `* DerefMut::deref_mut(&mut x)` ។
/// * តម្លៃនៃប្រភេទ `&mut T` ត្រូវបានបង្ខំទៅនឹងតម្លៃនៃប្រភេទ `&mut U`
/// * `T` អនុវត្តជាក់ស្តែងវិធីសាស្រ្ត (mutable) ទាំងអស់នៃប្រភេទ `U` ។
///
/// សម្រាប់ព័ត៌មានលម្អិតសូមចូលទៅកាន់ [the chapter in *The Rust Programming Language*][book] ក៏ដូចជាផ្នែកយោងនៅលើ [the dereference operator][ref-deref-op], [method resolution] និង [type coercions] ។
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// រចនាសម្ព័ន្ធដែលមានវាលតែមួយដែលអាចផ្លាស់ប្តូរបានដោយការបដិសេធរចនាសម្ព័ន្ធ។
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// ដកហូតសិទ្ធិគ្នាទៅវិញទៅមក។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// បង្ហាញថារចនាសម្ព័ន្ធមួយអាចត្រូវបានប្រើជាអ្នកទទួលវិធីសាស្រ្តដោយមិនមានលក្ខណៈពិសេស `arbitrary_self_types` ។
///
/// នេះត្រូវបានអនុវត្តដោយប្រភេទទ្រនិច stdlib ដូចជា `Box<T>`, `Rc<T>`, `&T` និង `Pin<P>` ។
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}