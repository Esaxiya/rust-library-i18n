/// trait សម្រាប់ការកែប្រែឥរិយាបថរបស់ប្រតិបត្តិករ `?` ។
///
/// ប្រភេទមួយដែលអនុវត្ត `Try` គឺជាវិធីមួយដែលមានវិធីសាស្រ្តក្នុងការមើលវាទាក់ទងនឹងឌីហ្សុមឌីម៉ា success/failure ។
/// trait នេះអនុញ្ញាតឱ្យអ្នកទាញយកតម្លៃជោគជ័យឬបរាជ័យទាំងនោះចេញពីឧទាហរណ៍ដែលមានស្រាប់និងបង្កើតឧទាហរណ៍ថ្មីពីតម្លៃជោគជ័យឬបរាជ័យ។
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// ប្រភេទនៃតម្លៃនេះនៅពេលត្រូវបានគេមើលឃើញថាទទួលបានជោគជ័យ។
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// ប្រភេទនៃតម្លៃនេះនៅពេលត្រូវបានមើលឃើញថាបរាជ័យ។
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// អនុវត្តប្រតិបត្តិករ "?" ។ការត្រឡប់មកវិញនៃ `Ok(t)` មានន័យថាការប្រតិបត្តិគួរតែបន្តជាធម្មតាហើយលទ្ធផលនៃ `?` គឺជាតម្លៃ `t` ។
    /// ការត្រឡប់មកវិញនៃ `Err(e)` មានន័យថាការប្រតិបត្តិគួរតែ branch ទៅខាងក្នុងដែលព័ទ្ធជុំវិញ `catch` ឬត្រឡប់ពីមុខងារ។
    ///
    /// ប្រសិនបើលទ្ធផល `Err(e)` ត្រូវបានត្រឡប់មកវិញតម្លៃ `e` នឹងជា "wrapped" នៅក្នុងប្រភេទត្រឡប់មកវិញនៃវិសាលភាពព័ទ្ធជុំវិញ (ដែលខ្លួនវាត្រូវតែអនុវត្ត `Try`) ។
    ///
    /// ជាពិសេស, តម្លៃ `X::from_error(From::from(e))` ត្រូវបានត្រឡប់មកវិញ, ដែល `X` គឺជាប្រភេទត្រឡប់មកវិញនៃមុខងាររុំព័ទ្ធ។
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// រុំតម្លៃកំហុសដើម្បីបង្កើតលទ្ធផលសមាសធាតុ។
    /// ឧទាហរណ៍ `Result::Err(x)` និង `Result::from_error(x)` គឺស្មើ។
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// រុំតម្លៃយល់ព្រមដើម្បីបង្កើតលទ្ធផលសមាសធាតុ។
    /// ឧទាហរណ៍ `Result::Ok(x)` និង `Result::from_ok(x)` គឺស្មើ។
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}