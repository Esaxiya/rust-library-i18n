//! ប្រតិបត្តិករផ្ទុកលើសទម្ងន់។
//!
//! អនុវត្ត traits ទាំងនេះអនុញ្ញាតឱ្យអ្នកផ្ទុកលើសពីប្រតិបត្តិករជាក់លាក់។
//!
//! មួយចំនួននៃ traits ត្រូវបាននាំចូលដោយ prelude ដូច្នេះពួកគេមាននៅក្នុងគ្រប់កម្មវិធី Rust ។មានតែប្រតិបត្តិករដែលគាំទ្រដោយ traits ប៉ុណ្ណោះដែលអាចផ្ទុកលើសទម្ងន់។
//! ឧទាហរណ៍ប្រតិបត្តិករបន្ថែម (`+`) អាចផ្ទុកលើសចំណុះតាមរយៈ [`Add`] trait ប៉ុន្តែចាប់តាំងពីអ្នកចាត់ចែងកិច្ចការ (`=`) មិនមានការគាំទ្រ trait ទេគ្មានវិធីផ្ទុកលើសចំណុះរបស់វាទេ។
//! លើសពីនេះទៀតម៉ូឌុលនេះមិនផ្តល់នូវយន្តការណាមួយដើម្បីបង្កើតប្រតិបត្តិករថ្មីទេ។
//! ប្រសិនបើប្រតិបត្តិករផ្ទុកលើសចំណុះឬទំនៀមទម្លាប់ផ្ទាល់ខ្លួនត្រូវបានទាមទារអ្នកគួរតែមើលទៅម៉ាក្រូឬអ្នកចងក្រងកម្មវិធីជំនួយដើម្បីពង្រីកវាក្យសម្ព័ន្ធ Rust ។
//!
//! ការអនុវត្តប្រតិបត្តិករ traits គួរតែមិនមានការភ្ញាក់ផ្អើលនៅក្នុងបរិបទរៀងៗខ្លួនដោយចងចាំពីអត្ថន័យធម្មតានិង [operator precedence] ។
//! ឧទាហរណ៍នៅពេលអនុវត្ត [`Mul`] ប្រតិបត្តិការគួរតែមានភាពប្រហាក់ប្រហែលខ្លះទៅនឹងគុណ (និងចែករំលែកទ្រព្យសម្បត្តិដែលរំពឹងទុកដូចជាការផ្សារភ្ជាប់) ។
//!
//! ចំណាំថាប្រតិបត្តិករខ្លីសៀគ្វី `&&` និង `||` ពោលគឺពួកគេវាយតម្លៃតែល្ខោនទីពីររបស់ពួកគេប្រសិនបើវាចូលរួមក្នុងលទ្ធផល។ចាប់តាំងពីឥរិយាបថនេះគឺជាការមិនប្រតិបត្តិដោយ traits, `&&` និង `||` មិនត្រូវបានគាំទ្រជាអ្នកប្រតិបត្តិករផ្ទុកលើសចំណុះ។
//!
//! ប្រតិបត្តិករជាច្រើនយកតម្លៃល្ខោនរបស់ពួកគេតាមតម្លៃ។នៅក្នុងបរិបទដែលមិនមែនជាទូទៅពាក់ព័ន្ធនឹងសាងសង់ឡើងនៅក្នុងប្រភេទនេះជាធម្មតាគឺមិនមែនជាបញ្ហា។
//! ទោះជាយ៉ាងណាក៏ដោយការប្រើប្រតិបត្តិករទាំងនេះតាមកូដទូទៅទាមទារការយកចិត្តទុកដាក់ប្រសិនបើតម្លៃត្រូវប្រើឡើងវិញផ្ទុយពីការអនុញ្ញាតឱ្យប្រតិបត្តិករប្រើប្រាស់វា។ជម្រើសមួយគឺត្រូវប្រើ [`clone`] ម្តងម្កាល។
//! ជម្រើសមួយទៀតគឺត្រូវពឹងផ្អែកលើប្រភេទដែលពាក់ព័ន្ធនឹងការផ្តល់ប្រតិបត្តិករបន្ថែមសម្រាប់សេចក្តីយោង។
//! ឧទាហរណ៍សម្រាប់ប្រភេទ `T` ដែលកំណត់ដោយអ្នកប្រើដែលត្រូវបានគេសន្មត់ថាគាំទ្រដល់ការបន្ថែមវាប្រហែលជាល្អដែលមានទាំង `T` និង `&T` អនុវត្ត traits [`Add<T>`][`Add`] និង [`Add<&T>`][`Add`] ដូច្នេះកូដទូទៅអាចត្រូវបានសរសេរដោយគ្មានការក្លូនដែលមិនចាំបាច់។
//!
//!
//! # Examples
//!
//! ឧទាហរណ៍នេះបង្កើតរចនាសម្ព័ន្ធ `Point` ដែលអនុវត្ត [`Add`] និង [`Sub`] ហើយបន្ទាប់មកបង្ហាញបន្ថែមនិងដក `point` ពីរ។
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! មើលឯកសារសម្រាប់ trait នីមួយៗសម្រាប់ការអនុវត្តឧទាហរណ៍។
//!
//! [`Fn`], [`FnMut`] និង [`FnOnce`] traits ត្រូវបានអនុវត្តតាមប្រភេទដែលអាចត្រូវបានហៅដូចមុខងារ។ចំណាំថា [`Fn`] យក `&self`, [`FnMut`] យក `&mut self` និង [`FnOnce`] យក `self` ។
//! ទាំងនេះត្រូវគ្នាទៅនឹងវិធីសាស្រ្តបីប្រភេទដែលអាចត្រូវបានហៅតាមឧទាហរណ៍៖ ការហៅដោយសេចក្តីយោងការហៅដោយសេចក្តីយោងនិងការហៅដោយតម្លៃ។
//! ការប្រើប្រាស់ទូទៅបំផុតនៃ traits ទាំងនេះគឺដើរតួជាមុខងារកម្រិតខ្ពស់ដែលយកមុខងារឬបិទជាអំណះអំណាង។
//!
//! យក [`Fn`] ជាប៉ារ៉ាម៉ែត្រ៖
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! យក [`FnMut`] ជាប៉ារ៉ាម៉ែត្រ៖
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! យក [`FnOnce`] ជាប៉ារ៉ាម៉ែត្រ៖
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` ប្រើប្រាស់អថេរដែលចាប់បានដូច្នេះវាមិនអាចដំណើរការបានច្រើនជាងម្តងទេ
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // ការប៉ុនប៉ងដើម្បីអំពាវនាវ `func()` ម្តងទៀតនឹងបោះកំហុស `use of moved value` សម្រាប់ `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` មិនអាចត្រូវបានហៅនៅចំណុចនេះទៀតទេ
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;