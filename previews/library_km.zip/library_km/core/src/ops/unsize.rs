use crate::marker::Unsize;

/// Trait ដែលបង្ហាញថានេះជាព្រួញមួយឬរុំសម្រាប់មួយ, ដែលជាកន្លែងដែល unsizing អាចត្រូវបានអនុវត្តនៅលើ pointee នេះ។
///
/// សូមមើល [DST coercion RFC][dst-coerce] និង [the nomicon entry on coercion][nomicon-coerce] សម្រាប់ព័ត៌មានលម្អិត។
///
/// ចំពោះប្រភេទទ្រនិចដែលមានភ្ជាប់ចង្អុលបង្ហាញទៅ `T` នឹងបង្ខំឱ្យចង្អុលទៅ `U` ប្រសិនបើ `T: Unsize<U>` ដោយបំលែងពីទ្រនិចស្គមទៅជាទ្រនិចខ្លាញ់។
///
/// សម្រាប់ប្រភេទផ្ទាល់ខ្លួនការបង្ខិតបង្ខំនៅទីនេះដំណើរការដោយការបង្ខំ `Foo<T>` ដល់ `Foo<U>` ដែលបានផ្តល់ឱ្យការបញ្ជាក់នៃ `CoerceUnsized<Foo<U>> for Foo<T>` មាន។
/// ការបញ្ជាក់បែបនេះអាចត្រូវបានសរសេរប្រសិនបើ `Foo<T>` មានតែវាលមិន phantomdata តែមួយប៉ុណ្ណោះដែលពាក់ព័ន្ធនឹង `T` ។
/// ប្រសិនបើប្រភេទនៃវាលនោះគឺ `Bar<T>` នោះការអនុវត្ត `CoerceUnsized<Bar<U>> for Bar<T>` ត្រូវតែមាន។
/// ការបង្ខិតបង្ខំនឹងដំណើរការដោយបង្ខំវាល `Bar<T>` ទៅជា `Bar<U>` ហើយបំពេញកន្លែងដែលនៅសល់ពី `Foo<T>` ដើម្បីបង្កើត `Foo<U>` ។
/// ការធ្វើបែបនេះនឹងខួងទៅកន្លែងចង្អុលហើយបង្ខំវា។
///
/// ជាទូទៅសម្រាប់អ្នកចង្អុលឆ្លាតអ្នកនឹងអនុវត្ត `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` ជាមួយនឹង `?Sized` ភ្ជាប់នៅលើ `T` ដោយខ្លួនឯង។
/// សម្រាប់ប្រភេទរុំដែលភ្ជាប់ `T` ដោយផ្ទាល់ដូចជា `Cell<T>` និង `RefCell<T>` អ្នកអាចអនុវត្ត `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` ដោយផ្ទាល់។
///
/// នេះនឹងអនុញ្ញាតឱ្យមានការបង្ខិតបង្ខំនៃប្រភេទដូចជា `Cell<Box<T>>` ដំណើរការ។
///
/// [`Unsize`][unsize] ត្រូវបានប្រើដើម្បីសម្គាល់ប្រភេទដែលអាចត្រូវបានបង្ខំទៅ DST ប្រសិនបើនៅពីក្រោយអ្នកចង្អុល។វាត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិដោយអ្នកចងក្រង។
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut យូ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut យូ
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// វាត្រូវបានប្រើសម្រាប់សុវត្ថិភាពវត្ថុដើម្បីពិនិត្យមើលថាប្រភេទរបស់អ្នកទទួលអាចត្រូវបានបញ្ជូនទៅ។
///
/// ការអនុវត្តឧទាហរណ៍នៃ trait៖
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut យូ
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}