//! ធុងដែលអាចបំលែងបាន។
//!
//! សុវត្ថិភាពនៃការចងចាំ Rust ត្រូវបានផ្អែកលើច្បាប់មួយនេះ: ផ្ដល់ឱ្យវត្ថុ `T` មួយ, វាគឺអាចធ្វើទៅបានតែមួយគត់ដើម្បីមានមួយដូចខាងក្រោម:
//!
//! - មានសេចក្តីយោងជាច្រើនដែល (`&T`) ដើម្បីអាចកែប្រែវត្ថុ (ដែលគេស្គាល់ផងដែរថាជាឈ្មោះក្លែងក្លាយ ** **) ។
//! - មានសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានមួយ (`&mut T`) ចំពោះវត្ថុ (ត្រូវបានគេស្គាល់ថាជា **ភាពអាចផ្លាស់ប្តូរបាន**) ។
//!
//! នេះត្រូវបានអនុវត្តដោយចងក្រង Rust ។ទោះយ៉ាងណាក៏ដោយមានស្ថានភាពដែលច្បាប់នេះមិនអាចបត់បែនបានគ្រប់គ្រាន់។ពេលខ្លះវាតម្រូវឱ្យមានឯកសារយោងជាច្រើនទៅវត្ថុមួយហើយប្តូរវាម្តងទៀត។
//!
//! កុងតឺន័រដែលអាចផ្លាស់ប្តូរបានអាចរកបានដើម្បីអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរគ្នាតាមរបៀបដែលអាចគ្រប់គ្រងបានសូម្បីតែវត្តមាននៃការប្តូរឈ្មោះក្លែងក្លាយ។ទាំង [`Cell<T>`] និង [`RefCell<T>`] អនុញ្ញាតឱ្យធ្វើបែបនេះតាមខ្សែតែមួយ។
//! ទោះជាយ៉ាងណា, មិន `Cell<T>` ឬ `RefCell<T>` មានសុវត្ថិភាពខ្សែស្រឡាយ (ដែលពួកគេមិនបានអនុវត្ត [`Sync`]) ។
//! ប្រសិនបើអ្នកត្រូវការធ្វើសម្មតិកម្មនិងការផ្លាស់ប្តូររវាងខ្សែស្រឡាយច្រើនវាអាចប្រើប្រភេទ [`Mutex<T>`], [`RwLock<T>`] ឬ [`atomic`] ។
//!
//! តម្លៃនៃប្រភេទ `Cell<T>` និង `RefCell<T>` អាចត្រូវបានផ្លាស់ប្តូរតាមរយៈសេចក្តីយោងដែលបានចែករំលែក (ឧ
//! ប្រភេទ `&T` ទូទៅ) ចំណែកប្រភេទ Rust ភាគច្រើនអាចបំលែងបានតែតាមរយៈសេចក្តីយោង (`&mut T`) តែមួយគត់។
//! យើងនិយាយថា `Cell<T>` និង `RefCell<T>` ផ្តល់នូវភាពអាចផ្លាស់ប្តូរផ្នែកខាងក្នុងបានផ្ទុយពីប្រភេទ Rust ធម្មតាដែលបង្ហាញពីការផ្លាស់ប្តូរតំណពូជ។
//!
//! ប្រភេទដៃចូលមកក្នុងលក្ខណៈពីរ: `Cell<T>` និង `RefCell<T>` ។`Cell<T>` អនុវត្តបំរែបំរួលផ្នែកខាងក្នុងដោយការផ្លាស់ប្តូរតម្លៃនៅក្នុងនិងក្រៅនៃ `Cell<T>` ។
//! ដើម្បីប្រើសេចក្តីយោងជំនួសឱ្យតម្លៃមួយត្រូវតែប្រើប្រភេទ `RefCell<T>`, ទទួលបានការចាក់សោការសរសេរមុនពេលផ្លាស់ប្ដូរ។`Cell<T>` ផ្តល់នូវវិធីសាស្រ្តក្នុងការទាញយកនិងផ្លាស់ប្តូរតម្លៃខាងក្នុងបច្ចុប្បន្ន៖
//!
//!  - សម្រាប់ប្រភេទដែលអនុវត្ត [`Copy`] វិធីសាស្ត្រ [`get`](Cell::get) ទាញយកតម្លៃផ្ទៃខាងក្នុងបច្ចុប្បន្ន។
//!  - សម្រាប់ប្រភេទដែលអនុវត្ត [`Default`] វិធីសាស្ត្រ [`take`](Cell::take) ជំនួសតម្លៃបច្ចុប្បន្នជាមួយ [`Default::default()`] មហាផ្ទៃនិងត្រឡប់តម្លៃជំនួស។
//!  - សម្រាប់គ្រប់ប្រភេទវិធី [`replace`](Cell::replace) ជំនួសតម្លៃខាងក្នុងបច្ចុប្បន្ននិងត្រឡប់តម្លៃដែលបានជំនួសវិញហើយវិធីសាស្ត្រ [`into_inner`](Cell::into_inner) ស៊ីស៊ី `Cell<T>` ហើយត្រឡប់តម្លៃខាងក្នុង។
//!  លើសពីនេះទៀតវិធីសាស្ត្រ [`set`](Cell::set) ជំនួសតម្លៃខាងក្នុងដោយទម្លាក់តម្លៃដែលបានជំនួស។
//!
//! `RefCell<T>` ប្រើជីវិត Rust ដើម្បីអនុវត្ត "ការខ្ចីប្រាក់ថាមវន្ត" ដំណើរការដែលនរណាម្នាក់អាចអះអាងជាបណ្តោះអាសន្ន, ផ្តាច់មុខ, ការចូលដំណើរការ mutable ទៅតម្លៃខាងក្នុងមួយ។
//! ការខ្ចីប្រាក់សម្រាប់ `RefCell<T>`s បានត្រូវគេតាមដាននៅពេលរត់", មិនដូចប្រភេទឯកសារយោងដែលមានដើមកំណើត Rust ដែលត្រូវបានតាមដានទាំងស្រុងឋិតិវន្ត, នៅពេលចងក្រង។
//! ដោយសារតែការខ្ចី `RefCell<T>` មានលក្ខណៈថាមវន្តវាអាចទៅរួចក្នុងការព្យាយាមខ្ចីប្រាក់ដែលបានខ្ចីរួចហើយ។នៅពេលរឿងនេះកើតឡើងវាមានលទ្ធផលជាខ្សែស្រឡាយ panic ។
//!
//! # ពេលណាត្រូវជ្រើសរើសភាពប្រែប្រួលផ្នែកខាងក្នុង
//!
//! ភាពប្រែប្រួលនៃមរតកដែលមានជាទូទៅដែលមនុស្សម្នាក់ត្រូវតែមានសិទ្ធិពិសេសក្នុងការផ្លាស់ប្តូរតម្លៃគឺជាធាតុសំខាន់មួយនៃភាសាដែលអាចឱ្យ Rust វែកញែកយ៉ាងខ្លាំងអំពីការប្តូរឈ្មោះទ្រនិចការពារស្ថិតិកំហុស។
//! ដោយសារតែនោះភាពអាចផ្លាស់ប្តូរបានពីមរតកត្រូវបានគេពេញចិត្តហើយការផ្លាស់ប្តូរផ្នែកខាងក្នុងគឺជាអ្វីមួយនៃមធ្យោបាយចុងក្រោយ។
//! ចាប់តាំងពីការផ្លាស់ប្តូរប្រភេទកោសិកាអនុញ្ញាតឱ្យជាកន្លែងដែលវានឹងត្រូវបានអនុញ្ញាតទេទោះបីជា, មានឱកាសនៅពេលដែល mutability មហាផ្ទៃអាចនឹងសមរម្យឬសូម្បីតែ *ត្រូវតែ* ត្រូវបានប្រើ, ឧ
//!
//! * ការណែនាំអំពីភាពប្រែប្រួលដែលអាចផ្លាស់ប្តូរបាន
//! * សេចក្តីលម្អិតនៃការអនុវត្តវិធីសាស្រ្តដែលមិនអាចផ្លាស់ប្តូរបាន-ឡូជីខល។
//! * ការផ្លាស់ប្តូរការអនុវត្តនៃ [`Clone`] ។
//!
//! ## ការណែនាំអំពីភាពប្រែប្រួលដែលអាចផ្លាស់ប្តូរបាន
//!
//! ប្រភេទព្រួញឆ្លាតចែករំលែកជាច្រើនរួមទាំង [`Rc<T>`] និង [`Arc<T>`], ផ្តល់នូវឧបករណ៍ផ្ទុកដែលអាចត្រូវបានចែករំលែករវាងអ្នកនិងក្លូនភាគីច្រើន។
//! ដោយសារតែតម្លៃដែលមានអាចនឹងមានពហុគុណពួកគេអាចខ្ចីបានតែជាមួយ `&` មិនមែន `&mut` ទេ។
//! បើគ្មានកោសិកាវាមិនអាចទៅរួចទេក្នុងការផ្លាស់ប្តូរទិន្នន័យនៅខាងក្នុងនៃចំនុចចង្អុលទាំងនេះ។
//!
//! វាជារឿងធម្មតាណាស់បន្ទាប់មកទៅដាក់ `RefCell<T>` ខាងក្នុងប្រភេទមួយដែលបានចែករំលែកទៅ mutability ព្រួញ reintroduce:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // បង្កើតប្លុកថ្មីដើម្បីកំណត់វិសាលភាពនៃថាមវន្តខ្ចីនេះ
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // ចំណាំថាប្រសិនបើយើងមិនបានអនុញ្ញាតឱ្យមុនរបស់ឃ្លាំងសម្ងាត់ខ្ចីដែលធ្លាក់ចេញពីវិសាលភាពបន្ទាប់មកនឹងធ្វើឱ្យជាបន្តបន្ទាប់ខ្ចីអំបោះថាមវន្ត panic ។
//!     //
//!     // នេះជាគ្រោះថ្នាក់ធំនៃការប្រើ `RefCell` ។
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ចំណាំថាឧទាហរណ៍នេះប្រើ `Rc<T>` ហើយមិនមែន `Arc<T>` ទេ។`RefCell<T>`s បានគឺសម្រាប់តែខ្សែស្រឡាយសេណារីយ៉ូ។ពិចារណាប្រើ [`RwLock<T>`] ឬ [`Mutex<T>`] ប្រសិនបើអ្នកត្រូវការការផ្លាស់ប្តូរគ្នាទៅវិញទៅមកក្នុងស្ថានភាពពហុខ្សែ។
//!
//! ## សេចក្តីលម្អិតនៃការអនុវត្តវិធីសាស្រ្តដែលមិនអាចផ្លាស់ប្តូរបាន-ឡូជីខល
//!
//! ជួនកាលវាអាចជាការចង់មិនបង្ហាញនៅក្នុង API ដែលមានការផ្លាស់ប្តូរកើតឡើង "under the hood" ។
//! នេះប្រហែលជាដោយសារតែតក្កប្រតិបត្តិការនេះមិនអាចកែប្រែបានទេប៉ុន្តែឧឃ្លាំងសម្ងាត់កងកម្លាំងអនុវត្តដើម្បីអនុវត្តការផ្លាស់ប្តូរនេះ!ឬដោយសារតែអ្នកត្រូវតែផ្តល់ការងារផ្លាស់ប្តូរដើម្បីអនុវត្តវិធីសាស្រ្ត trait ដើមឡើយដែលត្រូវបានកំណត់ដើម្បីយក `&self` ។
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ការគណនាថ្លៃ ៗ ទៅទីនេះ
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## ការផ្លាស់ប្តូរការអនុវត្តនៃ `Clone`
//!
//! នេះគ្រាន់តែជាករណីពិសេសមួយប៉ុន្តែជារឿងធម្មតានៃរឿងមុន ៗ ៖ លាក់ភាពប្រែប្រួលសម្រាប់ប្រតិបត្ដិការដែលមើលទៅមិនអាចផ្លាស់ប្តូរបាន។
//! វិធីសាស្ត្រ [`clone`](Clone::clone) ត្រូវបានគេរំពឹងថានឹងមិនផ្លាស់ប្តូរតម្លៃប្រភពហើយត្រូវបានប្រកាសថាយក `&self` មិនមែន `&mut self` ទេ។
//! ដូច្នេះការផ្លាស់ប្តូរណាមួយដែលកើតឡើងតាមវិធី `clone` ត្រូវតែប្រើប្រភេទកោសិកា។
//! ឧទាហរណ៍ [`Rc<T>`] រក្សាចំនួនឯកសារយោងរបស់វានៅក្នុង `Cell<T>` ។
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// ទីតាំងចងចាំដែលអាចផ្លាស់ប្តូរបាន។
///
/// # Examples
///
/// នៅក្នុងឧទាហរណ៍នេះអ្នកអាចមើលឃើញថាការផ្លាស់ប្តូរនៅក្នុងអនុញ្ញាតឱ្យ `Cell<T>` មួយ struct មិនចេះប្រែប្រួល។
/// និយាយម្យ៉ាងទៀតវាអាចឱ្យ "interior mutability" ។
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // កំហុស៖ `my_struct` គឺមិនអាចផ្លាស់ប្តូរបាន
/// // my_struct.regular_field =NEW_VALUE;
///
/// // ការងារ៖ ទោះបី `my_struct` មិនអាចផ្លាស់ប្តូរបានក៏ដោយ `special_field` គឺជា `Cell` ។
/// // ដែលអាចត្រូវបានផ្លាស់ប្តូរជានិច្ច
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// មើល [module-level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// បង្កើត `Cell<T>` មួយដែលមានតម្លៃ `Default` សំរាប់ T ។
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// បង្កើត `Cell` ថ្មីដែលមានតម្លៃដែលបានផ្តល់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// កំណត់តម្លៃដែលមាន។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// ប្តូរតម្លៃនៃក្រឡាពីរ។
    /// ភាពខុសគ្នាជាមួយ `std::mem::swap` គឺថាមុខងារនេះមិនត្រូវការសេចក្តីយោង `&mut` ទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // សុវត្ថិភាព: នេះអាចមានគ្រោះថ្នាក់ប្រសិនបើត្រូវបានគេហៅថាមកពីខ្សែស្រឡាយដាច់ដោយឡែកប៉ុន្តែ `Cell`
        // គឺ `!Sync` ដូច្នេះវានឹងមិនកើតឡើងទេ។
        // នេះក៏នឹងមិនធ្វើឱ្យមានចំនុចមិនត្រឹមត្រូវដែរពីព្រោះ `Cell` ប្រាកដថាគ្មានអ្វីផ្សេងទៀតនឹងចង្អុលទៅលើកោសិការទាំងនេះទេ។
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// ជំនួសតម្លៃដែលមានជាមួយ `val` ហើយត្រឡប់តម្លៃដែលមានចាស់វិញ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // សុវត្ថិភាព: វាអាចបណ្តាលឱ្យមានការប្រណាំងទិន្នន័យប្រសិនបើត្រូវបានគេហៅថាមកពីខ្សែស្រឡាយដាច់ដោយឡែក។
        // ប៉ុន្តែ `Cell` គឺ `!Sync` ដូច្នេះវានឹងមិនកើតឡើង។
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// ដកតម្លៃ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// ត្រឡប់ច្បាប់ចម្លងនៃតម្លៃដែលមាន។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // សុវត្ថិភាព: វាអាចបណ្តាលឱ្យមានការប្រណាំងទិន្នន័យប្រសិនបើត្រូវបានគេហៅថាមកពីខ្សែស្រឡាយដាច់ដោយឡែក។
        // ប៉ុន្តែ `Cell` គឺ `!Sync` ដូច្នេះវានឹងមិនកើតឡើង។
        unsafe { *self.value.get() }
    }

    /// ធ្វើបច្ចុប្បន្នភាពតម្លៃដែលមានដោយប្រើមុខងារហើយត្រឡប់តម្លៃថ្មី។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// ត្រឡប់ទ្រនិចឆៅទៅទិន្នន័យមូលដ្ឋានក្នុងក្រឡានេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅទិន្នន័យមូលដ្ឋាន។
    ///
    /// ការហៅនេះខ្ចី `Cell` mutably (នៅចងក្រងម៉ោង) ដែលធានាថាយើងមានសេចក្ដីយោងតែប៉ុណ្ណោះ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// ត្រឡប់ `&Cell<T>` ពី `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // សុវត្ថិភាព: `&mut` ធានាបាននូវការចូលប្រើតែមួយគត់។
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// យកតម្លៃនៃកោសិកាទុក `Default::default()` នៅកន្លែងរបស់វា។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// ត្រឡប់ `&[Cell<T>]` ពី `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // សុវត្ថិភាព: `Cell<T>` មានប្លង់មេម៉ូរីដូចគ្នា `T` ។
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// ទីតាំងនៃការចងចាំដែលអាចផ្លាស់ប្តូរបានជាមួយនឹងច្បាប់ខ្ចីប្រាក់ដែលបានពិនិត្យតាមបែបថាមវន្ត
///
/// មើល [module-level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// កំហុសមួយបានត្រឡប់មកវិញដោយ [`RefCell::try_borrow`] ។
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// កំហុសមួយបានត្រឡប់ដោយ [`RefCell::try_borrow_mut`] ។
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// តម្លៃវិជ្ជមានតំណាងឱ្យចំនួននៃ `Ref` សកម្ម។តម្លៃអវិជ្ជមានតំណាងឱ្យចំនួននៃ `RefMut` សកម្ម។
// ច្រើន `RefMut`s តែប៉ុណ្ណោះអាចត្រូវបានសកម្មនៅពេលតែមួយប្រសិនបើពួកគេយោងទៅខុសគ្នា, សមាសភាគ nonoverlapping នៃ `RefCell` មួយ (ឧជួរផ្សេងគ្នានៃអត្ថប្រយោជន៍មួយ) ។
//
// `Ref` និង `RefMut` គឺជាពាក្យពីរនៅក្នុងទំហំទាំងពីរ, ហើយដូច្នេះមាននឹងទំនងជាមិនត្រូវបានគ្រប់គ្រាន់ `ឬ` RefMut`s Ref`s នៅជីវិតពាក់កណ្តាលការលើសចំណុះនៃជួរ `usize` ។
// ដូច្នេះ `BorrowFlag` មួយនឹងប្រហែលជាមិនលើសឬខ្វះ។
// ទោះយ៉ាងណានេះមិនមែនជាការធានាទេព្រោះកម្មវិធីរោគសាស្ត្រអាចបង្កើតម្តងហើយម្តងទៀត mem::forget `Ref`s ឬ`RefMut`s ។
// ដូច្នេះលេខកូដទាំងអស់ត្រូវពិនិត្យឱ្យបានច្បាស់សម្រាប់ការហូរហៀរនិងហូរហៀរដើម្បីចៀសវាងការមិនមានសុវត្ថិភាពឬយ៉ាងហោចណាស់មានឥរិយាបទត្រឹមត្រូវក្នុងករណីដែលការហូរហៀរឬហូរហៀរកើតឡើង (ឧទាហរណ៍សូមមើល BorrowRef::new) ។
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// បង្កើត `RefCell` ថ្មីដែលមាន `value` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// ប្រើប្រាស់ `RefCell` ត្រឡប់តម្លៃរុំនេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // ចាប់តាំងពីមុខងារនេះត្រូវចំណាយពេល `self` (`RefCell` នេះ) ដោយតម្លៃចងក្រងឋិតិវន្តផ្ទៀងផ្ទាត់ថាវាមិនត្រូវបានខ្ចីនាពេលបច្ចុប្បន្ន។
        //
        self.value.into_inner()
    }

    /// ជំនួសតម្លៃរុំជាមួយនឹងការថ្មីមួយត្រឡប់តម្លៃដែលមានអាយុដោយគ្មាន deinitializing មួយដែរ។
    ///
    ///
    /// មុខងារនេះត្រូវនឹង [`std::mem::replace`](../mem/fn.replace.html) ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃបច្ចុប្បន្នត្រូវបានខ្ចី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// ជំនួសតម្លៃរុំដោយវត្ថុថ្មីដែលគណនាពី `f` ត្រឡប់តម្លៃចាស់ដោយមិនធ្វើឱ្យខូចតម្លៃណាមួយឡើយ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃបច្ចុប្បន្នត្រូវបានខ្ចី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// ប្តូរតម្លៃរុំ `self` ជាមួយនឹងតម្លៃរុំ `other` ដោយមិនធ្វើឱ្យខូចតម្លៃណាមួយឡើយ។
    ///
    ///
    /// មុខងារនេះត្រូវនឹង [`std::mem::swap`](../mem/fn.swap.html) ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// ខ្ចីតម្លៃរុំមិនចេះចប់។
    ///
    /// ប្រាក់កម្ចីមានរយៈពេលរហូតដល់ `Ref` ត្រឡប់មកវិញដែលនៅសល់ពីវិសាលភាព។
    /// ការខ្ចីប្រាក់មិនចេះប្រែប្រួលច្រើនអាចត្រូវបានយកចេញនៅពេលដូចគ្នានេះ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃបច្ចុប្បន្នត្រូវបានខ្ចីទៅវិញទៅមក។
    /// ចំពោះការដែលមិនមានភ័យខ្លាចវ៉ារ្យ៉ង់, ប្រើ [`try_borrow`](#method.try_borrow) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// ឧទាហរណ៍នៃ panic៖
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// អាចកែប្រែបានខ្ចីតម្លៃរុំ, ការវិលត្រឡប់កំហុសមួយប្រសិនបើតម្លៃត្រូវបានខ្ចី mutably បច្ចុប្បន្ន។
    ///
    ///
    /// ប្រាក់កម្ចីមានរយៈពេលរហូតដល់ `Ref` ត្រឡប់មកវិញដែលនៅសល់ពីវិសាលភាព។
    /// ការខ្ចីប្រាក់មិនចេះប្រែប្រួលច្រើនអាចត្រូវបានយកចេញនៅពេលដូចគ្នានេះ។
    ///
    /// នេះជាវ៉ារ្យ៉ង់មិនមែនជាការភ័យខ្លាចនៃការ [`borrow`](#method.borrow) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // សុវត្ថិភាព: `BorrowRef` ធានាថាមានតែការចូលដំណើរការមិនប្រែប្រួល
            // ទៅតម្លៃខណៈពេលខ្ចី។
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Mutably ខ្ចីតម្លៃរុំនេះ។
    ///
    /// ប្រាក់កម្ចីមានរយៈពេលរហូតដល់ `RefMut` ដែលបានត្រឡប់មកវិញឬទាំងអស់ `RefMut derived ដែលទទួលបានពីវិសាលភាពនៃការចាកចេញ។
    ///
    /// តម្លៃមិនអាចខ្ចីបានទេខណៈពេលដែលប្រាក់កម្ចីនេះសកម្ម។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃបច្ចុប្បន្នត្រូវបានខ្ចី។
    /// ចំពោះវ៉ារ្យ៉ង់ដែលមិនភាន់ច្រឡំប្រើ [`try_borrow_mut`](#method.try_borrow_mut) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// ឧទាហរណ៍នៃ panic៖
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// ខ្ចីតម្លៃរុំគ្នាទៅវិញទៅមកដោយត្រឡប់កំហុសបើតម្លៃបច្ចុប្បន្នត្រូវបានខ្ចី។
    ///
    ///
    /// ប្រាក់កម្ចីមានរយៈពេលរហូតដល់ `RefMut` ដែលបានត្រឡប់មកវិញឬទាំងអស់ `RefMut derived ដែលទទួលបានពីវិសាលភាពនៃការចាកចេញ។
    /// តម្លៃមិនអាចខ្ចីបានទេខណៈពេលដែលប្រាក់កម្ចីនេះសកម្ម។
    ///
    /// នេះជាវ៉ារ្យ៉ង់មិនមែនជាការភ័យខ្លាចនៃការ [`borrow_mut`](#method.borrow_mut) ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // សុវត្ថិភាព: `BorrowRef` ធានានូវការចូលប្រើតែមួយគត់។
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// ត្រឡប់ទ្រនិចឆៅទៅទិន្នន័យមូលដ្ឋានក្នុងក្រឡានេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅទិន្នន័យមូលដ្ឋាន។
    ///
    /// ការហៅនេះខ្ចី `RefCell` mutably (នៅចងក្រងម៉ោង) ដូច្នេះមានភាពចាំបាច់សម្រាប់ការត្រួតពិនិត្យថាមវន្តទេ។
    ///
    /// ទោះជាយ៉ាងណាត្រូវប្រុងប្រយ័ត្ន: វិធីសាស្រ្តនេះរំពឹងថា `self` ដើម្បីជា mutable ដែលជាទូទៅមិនមែនជាករណីនៅពេលប្រើ `RefCell` មួយ។
    ///
    /// សូមក្រឡេកមើលវិធីសាស្ត្រ [`borrow_mut`] ជំនួសប្រសិនបើ `self` មិនអាចផ្លាស់ប្តូរបាន។
    ///
    /// ដូចគ្នានេះផងដែរ, សូមត្រូវដឹងថាវិធីសាស្រ្តនេះគឺគ្រាន់តែសម្រាប់កាលៈទេសៈពិសេសនិងជាធម្មតាមិនជាអ្វីដែលអ្នកចង់បាន។
    /// ក្នុងករណីមានការសង្ស័យសូមប្រើ [`borrow_mut`] ជំនួសវិញ។
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// មិនធ្វើការផលប៉ះពាល់នៃការលេចធ្លាយនៅលើឆ្មាំរដ្ឋនៃ `RefCell` បានខ្ចី។
    ///
    /// ការហៅនេះគឺស្រដៀងនឹង [`get_mut`] ប៉ុន្តែមានជំនាញជាង។
    /// វាខ្ចី `RefCell` ទៅវិញទៅមកដើម្បីធានាថាមិនមានការខ្ចីហើយបន្ទាប់មកកំណត់ប្រាក់កម្ចីដែលបានចែករំលែកបន្តតាមដានរបស់រដ្ឋ។
    /// នេះគឺជាការពាក់ព័ន្ធប្រសិនបើអ្នកខ្ចីមួយចំនួន `Ref` ឬ `RefMut` ត្រូវបានលេចធ្លាយ។
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// អាចកែប្រែបានខ្ចីតម្លៃរុំ, ការវិលត្រឡប់កំហុសមួយប្រសិនបើតម្លៃត្រូវបានខ្ចី mutably បច្ចុប្បន្ន។
    ///
    /// # Safety
    ///
    /// មិនដូច `RefCell::borrow` ទេវិធីសាស្ត្រនេះមិនមានសុវត្ថិភាពទេព្រោះវាមិនផ្តល់ជូន `Ref` ទេដូច្នេះទុកទង់ខ្ចីនៅដដែល។
    /// Mutably ខ្ចី `RefCell` ខណៈពេលដែលត្រឡប់ដោយយោងវិធីសាស្រ្តនេះគឺនៅរស់គឺជាឥរិយាបទបានកំណត់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // សុវត្ថិភាព: យើងពិនិត្យមើលថាឥឡូវនេះគ្មាននរណាម្នាក់កំពុងសរសេរយ៉ាងសកម្មទេប៉ុន្តែវាគឺជា
            // ការទទួលខុសត្រូវរបស់អ្នកហៅទូរស័ព្ទដើម្បីធានាថាគ្មាននរណាម្នាក់សរសេររហូតដល់ឯកសារយោងដែលបានត្រឡប់មកវិញលែងប្រើទៀតទេ។
            // ដូចគ្នានេះផងដែរ `self.value.get()` សំដៅទៅលើតម្លៃដែលជាកម្មសិទ្ធិរបស់ `self` ហើយដូច្នេះត្រូវបានធានាថាមានសុពលភាពពេញមួយជីវិតរបស់ `self` ។
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// យកតម្លៃខ្ចប់ទុក `Default::default()` នៅកន្លែងរបស់វា។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃបច្ចុប្បន្នត្រូវបានខ្ចី។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃបច្ចុប្បន្នត្រូវបានខ្ចីទៅវិញទៅមក។
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// បង្កើត `RefCell<T>` មួយដែលមានតម្លៃ `Default` សំរាប់ T ។
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics ប្រសិនបើតម្លៃនៅក្នុង `RefCell` បច្ចុប្បន្នត្រូវបានខ្ចី។
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // incrementing អាចនាំឱ្យមានខ្ចីតម្លៃមិនអាន (<=0) នៅក្នុងករណីទាំងនេះ:
            // 1. វាគឺជា <0 ពោលគឺមានត្រូវបានសរសេរខ្ចី, ដូច្នេះយើងមិនអាចអនុញ្ញាតឱ្យមានដោយសារតែការអានខ្ចីច្បាប់ក្លែងក្លាយឯកសារយោង Rust របស់
            // 2.
            // វាគឺជា isize::MAX (ចំនួនប្រាក់កម្ចីអានច្រើនបំផុត) ហើយវាបានហូរចូលទៅក្នុង isize::MIN (ចំនួនអតិបរិមានៃការខ្ចីសរសេរ) ដូច្នេះយើងមិនអាចអនុញ្ញាតិអោយខ្ចីអានបន្ថែមបានទេពីព្រោះទំហំដីមិនអាចតំណាងឱ្យការខ្ចីអានច្រើនទេ (នេះអាចកើតឡើងបានប្រសិនបើ អ្នក mem::forget ច្រើនជាងចំនួនថេរតូចមួយនៃ `Ref`s, ដែលមិនមែនជាការអនុវត្តល្អ)
            //
            //
            //
            //
            None
        } else {
            // ការបង្កើនប្រាក់កម្ចីអាចបណ្តាលឱ្យមានតម្លៃអាន (> ០) ក្នុងករណីទាំងនេះ៖
            // 1. វាគឺ=០ មានន័យថាវាមិនត្រូវបានគេខ្ចីហើយយើងកំពុងខ្ចីអានដំបូងគេ
            // 2. វាគឺ> 0 និង <isize::MAX ពោលគឺ
            // មានប្រាក់កម្ចីអានហើយទំហំតូចល្មមអាចតំណាងឱ្យខ្ចីអានបានមួយបន្ថែមទៀត
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // ចាប់តាំងពីឯកសារយោងនេះមានយើងដឹងថាទង់ខ្ចីគឺជាការខ្ចីអាន។
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // បងា្ករការប្រឆាំងពីការខ្ចីទៅជាពោរពេញសរសេរមួយខ្ចី។
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// រុំសេចក្តីយោងដែលបានខ្ចីទៅតម្លៃនៅក្នុងប្រអប់ `RefCell` ។
/// ប្រភេទរុំសម្រាប់តម្លៃខ្ចីដែលមិនចេះរីងស្ងួតពី `RefCell<T>` ។
///
/// មើល [module-level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// ថតចម្លងលេខ `Ref` ។
    ///
    /// `RefCell` នេះត្រូវបានខ្ចីមិនអាចកែប្រែបានរួចទៅហើយ, ដូច្នេះនេះមិនអាចបរាជ័យ។
    ///
    /// នេះគឺជាមុខងារដែលត្រូវប្រើជា `Ref::clone(...)` ។
    /// ការអនុវត្តវិធីសាស្រ្តមួយឬ `Clone` ជ្រៀតជ្រែកជាមួយនឹងការរីករាលដាលនៃ `r.borrow().clone()` ការប្រើដើម្បីក្លូនមាតិកានៃ `RefCell` មួយ។
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// បង្កើត `Ref` ថ្មីសម្រាប់សមាសធាតុនៃទិន្នន័យដែលបានខ្ចី។
    ///
    /// `RefCell` នេះត្រូវបានខ្ចីមិនអាចកែប្រែបានរួចទៅហើយ, ដូច្នេះនេះមិនអាចបរាជ័យ។
    ///
    /// នេះគឺជាមុខងារដែលជាប់ទាក់ទងមួយដែលត្រូវការឱ្យត្រូវបានប្រើជា `Ref::map(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// បង្កើត `Ref` ថ្មីសម្រាប់សមាសធាតុជាជម្រើសនៃទិន្នន័យដែលបានខ្ចី។
    /// ឆ្មាំដើមត្រូវបានត្រឡប់ជាអ្នក `Err(..)` មួយប្រសិនបើមានការបិទត្រឡប់ `None` ។
    ///
    /// `RefCell` នេះត្រូវបានខ្ចីមិនអាចកែប្រែបានរួចទៅហើយ, ដូច្នេះនេះមិនអាចបរាជ័យ។
    ///
    /// នេះគឺជាមុខងារដែលជាប់ទាក់ទងមួយដែលត្រូវការឱ្យត្រូវបានប្រើជា `Ref::filter_map(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// ពុះ `Ref` ចូលទៅក្នុងច្រើន `Ref`s សម្រាប់សមាសភាគផ្សេងគ្នានៃទិន្នន័យខ្ចី។
    ///
    /// `RefCell` នេះត្រូវបានខ្ចីមិនអាចកែប្រែបានរួចទៅហើយ, ដូច្នេះនេះមិនអាចបរាជ័យ។
    ///
    /// នេះគឺជាមុខងារដែលជាប់ទាក់ទងមួយដែលត្រូវការឱ្យត្រូវបានប្រើជា `Ref::map_split(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// បម្លែងទៅជាសេចក្ដីយោងទៅកាន់មូលដ្ឋានទិន្នន័យមួយ។
    ///
    /// `RefCell` មូលដ្ឋានមិនអាចត្រូវបានខ្ចីពីគ្នាម្តងទៀតទេហើយវានឹងលេចចេញជាលក្ខណៈខ្ចីរួចទៅហើយ។
    ///
    /// វាមិនល្អទេក្នុងការលេចធ្លាយច្រើនជាងចំនួនថេរនៃឯកសារយោង។
    /// `RefCell` នេះអាចត្រូវបានខ្ចីអាចកែប្រែបានជាថ្មីម្តងទៀតប្រសិនបើមានតែមួយចំនួនតូចនៃការលេចធ្លាយបានកើតឡើងនៅក្នុងការសរុប។
    ///
    /// នេះគឺជាមុខងារដែលជាប់ទាក់ទងមួយដែលត្រូវការឱ្យត្រូវបានប្រើជា `Ref::leak(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // ដោយភ្លេច Ref នេះយើងធានាថាការប្រឆាំងនៅក្នុងការខ្ចីមិនអាច RefCell ត្រឡប់ទៅមិនបានប្រើចូលទៅក្នុងរយៈពេលពេញមួយជីវិតរបស់ `'b` នេះ។
        // កំណត់ស្ថានភាពតាមដានយោងឡើងវិញនឹងតម្រូវឱ្យមានសេចក្តីយោងតែមួយគត់ចំពោះ RefCell ដែលបានខ្ចី។
        // មិនមានឯកសារយោងដែលអាចផ្លាស់ប្តូរបានពីកោសិកាដើមទេ។
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// បង្កើត `RefMut` ថ្មីសម្រាប់សមាសធាតុនៃទិន្នន័យដែលបានខ្ចីឧទាហរណ៍វ៉ារ្យ៉ង់អង់ស៊ីម។
    ///
    /// `RefCell` នេះត្រូវបានខ្ចី mutably រួចទៅហើយ, ដូច្នេះនេះមិនអាចបរាជ័យ។
    ///
    /// នេះគឺជាមុខងារដែលជាប់ទាក់ទងមួយដែលត្រូវការឱ្យត្រូវបានប្រើជា `RefMut::map(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ជួសជុលប្រាក់កម្ចី-ពិនិត្យ
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// ធ្វើឱ្យ `RefMut` ថ្មីសម្រាប់សមាសភាគស្រេចចិត្តនៃទិន្នន័យខ្ចី។
    /// ឆ្មាំដើមត្រូវបានត្រឡប់ជាអ្នក `Err(..)` មួយប្រសិនបើមានការបិទត្រឡប់ `None` ។
    ///
    /// `RefCell` នេះត្រូវបានខ្ចី mutably រួចទៅហើយ, ដូច្នេះនេះមិនអាចបរាជ័យ។
    ///
    /// នេះគឺជាមុខងារដែលត្រូវប្រើជា `RefMut::filter_map(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ជួសជុលប្រាក់កម្ចី-ពិនិត្យ
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // សុវត្ថិភាព: មុខងារទទួលបាននៅលើសេចក្ដីយោងផ្តាច់មុខសម្រាប់រយៈពេល
        // នៃការហៅរបស់ខ្លួនតាមរយៈ `orig` និងទ្រនិចគឺគ្រាន់តែដោះយោងនៅខាងក្នុងនៃការហៅមុខងារនេះមិនអនុញ្ញាតឱ្យសេចក្ដីយោងផ្តាច់មុខក្នុងការរត់គេចខ្លួន។
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // សុវត្ថិភាព: ដូចគ្នានឹងខាងលើ។
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// បំបែក `RefMut` ទៅជាច្រើន `RefMut` សម្រាប់សមាសធាតុផ្សេងៗគ្នានៃទិន្នន័យដែលបានខ្ចី។
    ///
    /// `RefCell` មូលដ្ឋាននឹងនៅតែត្រូវបានខ្ចីរហូតទាល់តែអ្នកទាំងពីរបានត្រលប់មកវិញ។
    ///
    /// `RefCell` នេះត្រូវបានខ្ចី mutably រួចទៅហើយ, ដូច្នេះនេះមិនអាចបរាជ័យ។
    ///
    /// នេះគឺជាមុខងារដែលត្រូវប្រើជា `RefMut::map_split(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// បម្លែងទៅជាឯកសារយោង mutable ទៅមូលដ្ឋានទិន្នន័យ។
    ///
    /// មូលដ្ឋាន `RefCell` មិនអាចត្រូវបានខ្ចីពីជាថ្មីម្តងទៀតហើយនឹងតែងតែលេចឡើងរួចទៅហើយបានខ្ចី mutably, ធ្វើឱ្យសេចក្តីយោងត្រឡប់មកវិញតែមួយគត់ដើម្បីមហាផ្ទៃ។
    ///
    ///
    /// នេះគឺជាមុខងារដែលត្រូវប្រើជា `RefMut::leak(...)` ។
    /// វិធីសាស្រ្តមួយដែលអាចនឹងបង្អាក់ជាមួយវិធីសាស្រ្តនៃឈ្មោះដូចគ្នានៅលើមាតិកានៃ `RefCell` ត្រូវបានប្រើតាមរយៈ `Deref` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // ដោយបំភ្លេច BorrowRefMut នេះយើងធានាថាអ្នកខ្ចីប្រាក់នៅក្នុង RefCell មិនអាចត្រលប់ទៅប្រើប្រាស់វិញក្នុងរយៈពេល `'b` ពេញមួយជីវិត។
        // កំណត់ស្ថានភាពតាមដានយោងឡើងវិញនឹងតម្រូវឱ្យមានសេចក្តីយោងតែមួយគត់ចំពោះ RefCell ដែលបានខ្ចី។
        // មិនមានឯកសារយោងបន្ថែមទៀតអាចត្រូវបានបង្កើតចេញពីកោសិកាដើមក្នុងជីវិតនោះទេដែលធ្វើឱ្យបច្ចុប្បន្នខ្ចីជាឯកសារយោងតែមួយគត់សម្រាប់អាយុកាលនៅសល់។
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: មិនដូច BorrowRefMut::clone ទេថ្មីត្រូវបានគេហៅថាដើម្បីបង្កើតដំបូង
        // ឯកសារយោងដែលអាចផ្លាស់ប្តូរបានហើយដូច្នេះបច្ចុប្បន្ននេះមិនមានសេចក្តីយោងដែលមានស្រាប់ទេ។
        // ដូច្នេះខណៈពេលដែលការបង្កើនក្លូននេះ refcount mutable, យើងនៅទីនេះយ៉ាងជាក់លាក់តែមួយគត់ដែលអនុញ្ញាតឱ្យនឹងទៅមិនបានប្រើពីមិនបានប្រើ 1 ។
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // ក្លូន `BorrowRefMut` មួយ។
    //
    // នេះគឺជាការត្រឹមត្រូវតែនៅពេលដែល `BorrowRefMut` គ្នាត្រូវបានប្រើដើម្បីតាមដានជាសេចក្ដីយោងទៅនឹងការខុសគ្នា mutable, ជួរ nonoverlapping នៃវត្ថុដើម។
    //
    // នេះមិនមែននៅក្នុង impl ក្លូនដូច្នេះកូដដែលមិនបានហៅនេះទាំងស្រុង។
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // រារាំងអ្នកខ្ចីប្រាក់កុំអោយហូរចូល។
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// ប្រភេទរុំសម្រាប់តម្លៃដែលអាចខ្ចីបានពី `RefCell<T>` ។
///
/// មើល [module-level documentation](self) សម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// ស្នូលបុព្វកាលសម្រាប់ mutability មហាផ្ទៃនៅ Rust ។
///
/// ប្រសិនបើអ្នកមានឯកសារយោង `&T` បន្ទាប់មកជាធម្មតានៅក្នុង Rust អ្នកចងក្រងអនុវត្តការបង្កើនប្រសិទ្ធភាពដោយផ្អែកលើចំណេះដឹងដែល `&T` ចង្អុលទៅទិន្នន័យដែលមិនអាចផ្លាស់ប្តូរបាន។ទិន្នន័យដែលបានផ្លាស់ប្ដូរឧទាហរណ៍តាមរយៈឈ្មោះក្លែងក្លាយមួយឬដោយ transmuting `&T` មួយចូលទៅក្នុង `&mut T` មួយដែលត្រូវបានចាត់ទុកថាជាឥរិយាបទមិនបានកំណត់។
/// `UnsafeCell<T>` opts ចេញពីការធានាមិនអាចកែប្រែបានសម្រាប់ `&T`: សេចក្តីយោងដែលបានចែករំលែក `&UnsafeCell<T>` អាចចង្អុលទៅទិន្នន័យដែលត្រូវបាន mutated ។នេះត្រូវបានគេហៅថា "interior mutability" ។
///
/// គ្រប់ប្រភេទដទៃទៀតដែលអនុញ្ញាតឱ្យ mutability ផ្ទៃក្នុងដូចជា `Cell<T>` និង `RefCell<T>` ខាងប្រើ `UnsafeCell` ដើម្បីរុំទិន្នន័យរបស់ពួកគេ។
///
/// ចំណាំថាមានតែការធានាដែលមិនអាចផ្លាស់ប្តូរបានសម្រាប់ឯកសារយោងរួមត្រូវបានប៉ះពាល់ដោយ `UnsafeCell` ។ការធានាតែមួយគត់សម្រាប់ឯកសារយោងដែលអាចផ្លាស់ប្តូរបានគឺមិនប៉ះពាល់ទេ។មិនមានវិធីស្របច្បាប់ក្នុងការទទួលបានឈ្មោះហៅក្រៅ `&mut` មិនមានសូម្បីតែ `UnsafeCell<T>` ។
///
/// `UnsafeCell` API ខ្លួនវាគឺមានលក្ខណៈបច្ចេកទេសសាមញ្ញ: [`.get()`] ផ្តល់ឱ្យអ្នកនូវទ្រនិច `*mut T` ទៅមាតិការបស់វា។វាមានរហូតដល់ _you_ ជាអ្នករចនាអរូបីដើម្បីប្រើទ្រនិចចង្អុលឆៅត្រឹមត្រូវ។
///
/// [`.get()`]: `UnsafeCell::get`
///
/// ច្បាប់ដាក់ឈ្មោះក្លែងក្លាយរបស់ Rust មានលក្ខណៈប្រែប្រួលខ្លះៗប៉ុន្តែចំណុចសំខាន់ៗមិនមានភាពចម្រូងចម្រាសទេ៖
///
/// - ប្រសិនបើអ្នកបង្កើតឯកសារយោងដែលមានសុវត្ថិភាពជាមួយអាយ `'a` ពេញមួយជីវិត (ទាំងឯកសារយោង `&T` ឬ `&mut T`) ដែលអាចចូលដំណើរការបានដោយកូដសុវត្ថិភាព (ឧទាហរណ៍ដោយសារតែអ្នកបានប្រគល់វាមកវិញ) នោះអ្នកមិនត្រូវចូលប្រើទិន្នន័យតាមវិធីណាដែលផ្ទុយនឹងឯកសារយោងសម្រាប់នៅសល់។ នៃ `'a` ។
/// ឧទាហរណ៍មធ្យោបាយនេះថាប្រសិនបើអ្នកយក `*mut T` ពី `UnsafeCell<T>` មួយហើយបោះវាទៅ `&T` មួយបន្ទាប់មកទិន្នន័យនៅក្នុង `T` ត្រូវតែនៅតែមិនអាចកែប្រែបាន (សំណល់ទិន្នន័យ `UnsafeCell` ណាមួយដែលរកឃើញនៅក្នុង `T` ពិតណាស់) រហូតដល់មួយជីវិតរបស់សេចក្ដីយោងដែលបានផុតកំណត់។
/// ស្រដៀងគ្នានេះដែរប្រសិនបើអ្នកបង្កើតឯកសារយោង `&mut T` ដែលត្រូវបានបញ្ចេញទៅលេខកូដសុវត្ថិភាពបន្ទាប់មកអ្នកមិនត្រូវចូលប្រើទិន្នន័យក្នុង `UnsafeCell` ទេរហូតដល់សេចក្តីយោងនោះផុតកំណត់។
///
/// - គ្រប់ពេលវេលាអ្នកត្រូវតែជៀសវាងការប្រណាំងទិន្នន័យ។ប្រសិនបើមានខ្សែស្រលាយច្រើនមានការចូលដំណើរការទៅកាន់ `UnsafeCell` ដូចគ្នា, បន្ទាប់មកសរសេរណាមួយត្រូវតែមានការត្រឹមត្រូវដែលកើតឡើងមុនពេលទាក់ទងនឹងការចូលដំណើរការទាំងអស់ផ្សេងទៀត (ឬប្រើអាតូម) ។
///
/// ដើម្បីជួយជាមួយនឹងការរចនាត្រឹមត្រូវ, សេណារីយ៉ូខាងក្រោមនេះត្រូវប្រកាសជាក់លាក់ច្បាប់សម្រាប់កូដខ្សែស្រឡាយតែមួយ:
///
/// 1. យោង `&T` អាចត្រូវបានចេញផ្សាយកូដសុវត្ថិភាពនិងមានវាអាចសហការជាមួយមានសេចក្តីយោង `&T` ផ្សេងទៀតប៉ុន្តែមិននៅជាមួយ `&mut T` មួយ
///
/// 2. ឯកសារយោង `&mut T` អាចនឹងត្រូវបានបញ្ចេញទៅលេខកូដដែលមានសុវត្ថិភាពដោយមិនមាន `&mut T` និង `&T` នៅជាប់ជាមួយវាឡើយ។`&mut T` ត្រូវតែមានតែមួយគត់។
///
/// ចំណាំថាខណៈពេលដែលការផ្លាស់ប្តូរមាតិកានៃ `&UnsafeCell<T>` (សូម្បីតែខណៈពេលដែល `&UnsafeCell<T>` ផ្សេងទៀតហៅឈ្មោះកោសិកា) មិនអីទេ (បានផ្តល់ឱ្យអ្នកនូវការលុកលុយខាងលើវិធីផ្សេងទៀត) វានៅតែជាឥរិយាបទដែលមិនទាន់កំណត់ដើម្បីឱ្យមានឈ្មោះហៅក្រៅ `&mut UnsafeCell<T>` ច្រើន។
/// នោះគឺ `UnsafeCell` គឺជារុំដែលត្រូវបានរចនាឡើងដើម្បីឱ្យមានអន្តរកម្មពិសេសជាមួយ _shared_ accesses (_i.e._ តាមរយៈឯកសារយោង `&UnsafeCell<_>`);នៅទីនោះគឺជាមន្តអាគមអ្វីទាំងអស់នៅពេលដែលការដោះស្រាយជាមួយនឹង _exclusive_ accesses (_e.g._ តាមរយៈ `&mut UnsafeCell<_>` មួយ): មិនមានកោសិកាឬតម្លៃរុំនេះអាចនឹងត្រូវមានឈ្មោះក្លែងក្លាយសម្រាប់រយៈពេលនៃការដែលបានខ្ចី `&mut` ។
///
/// នេះត្រូវបានបង្ហាញដោយឧបករណ៍ភ្ជាប់ [`.get_mut()`] ដែលជា _safe_ getter ដែលផ្តល់ទិន្នផល `&mut T` ។
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// នេះជាឧទាហរណ៍មួយដែលបង្ហាញពីវិធីផ្លាស់ប្តូរមាតិការបស់ `UnsafeCell<_>` យ៉ាងត្រឹមត្រូវទោះបីជាមានឯកសារយោងជាច្រើនដែលហៅក្រៅក្រឡាក៏ដោយ។
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ទទួលបានសេចក្តីយោងជាច្រើន/ស្របពេល/ចែករំលែកទៅ `x` ដូចគ្នា។
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // សុវត្ថិភាព: នៅក្នុងវិសាលភាពនេះមិនមានឯកសារយោងផ្សេងទៀតទៅនឹងមាតិការបស់ `x`
///     // ដូច្នេះរបស់យើងគឺមានប្រសិទ្ធិភាពតែមួយគត់។
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- ខ្ចី-+
///     *p1_exclusive += 27; // |
/// } // <---------- មិនអាចទៅហួសពីចំណុចនេះ -------------------+
///
/// unsafe {
///     // សុវត្ថិភាព៖ ក្នុងវិសាលភាពនេះគ្មាននរណាម្នាក់រំពឹងថានឹងអាចចូលប្រើប្រាស់មាតិកា `x` បានទេ។
///     // ដូច្នេះយើងអាចមានសិទ្ធិចូលដំណើរការចែករំលែកច្រើនស្របគ្នានោះដែរ។
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// ឧទាហរណ៍ដូចខាងក្រោមបង្ហាញពីការពិតដែលថាការចូលដំណើរការផ្តាច់មុខក្នុងការ `UnsafeCell<T>` មួយបញ្ជាក់ការចូលដំណើរការផ្តាច់មុខទៅ `T` របស់ខ្លួន:
///
/// ```rust
/// #![forbid(unsafe_code)] // ជាមួយនឹងការចូលដំណើរការផ្តាច់មុខ,
///                         // `UnsafeCell` គឺជារុំមិនមានតម្លាភាពដូច្នេះមិនចាំបាច់ប្រើ `unsafe` នៅទីនេះទេ។
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // ទទួលបានឯកសារយោងតែមួយគត់ចងក្រង-ពេលបានគូសធីកដើម្បី `x` ។
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // ជាមួយនឹងសេចក្ដីយោងផ្តាច់មុខ, យើងអាចប្រែប្រួលមាតិកាដោយឥតគិតថ្លៃ។
/// *p_unique.get_mut() = 0;
/// // ឬស្មើគ្នា៖
/// x = UnsafeCell::new(0);
///
/// // នៅពេលយើងជាម្ចាស់តម្លៃយើងអាចទាញយកមាតិកាដោយឥតគិតថ្លៃ។
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// សាងសង់វត្ថុថ្មីនៃ `UnsafeCell` ដែលនឹងរុំតម្លៃដែលបានបញ្ជាក់។
    ///
    ///
    /// រាល់ការទទួលបាននូវតម្លៃខាងក្នុងតាមរយៈវិធីសាស្រ្តគឺ `unsafe` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// ដកតម្លៃ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// ដាក់ទ្រនិចដែលអាចប្តូរបានទៅតម្លៃរុំ។
    ///
    /// នេះអាចត្រូវបានបោះទៅទ្រនិចចង្អុលណាមួយ។
    /// ធានាបានថាការចូលដំណើរការនេះគឺមានតែមួយគត់ (គ្មានសេចក្តីយោងសកម្ម mutable ឬមិនបាន) នៅពេលដែលខាសទៅ `&mut T` និងធានាថាមិនមានការផ្លាស់ប្តូរឬឈ្មោះក្លែងក្លាយ mutable នឹងនៅលើនៅពេលដែលខាសទៅ `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // យើងគ្រាន់តែអាចបោះព្រួញពី `UnsafeCell<T>` ទៅ `T` ដោយសារតែ #[repr(transparent)] ។
        // នេះរំខានស្ថានភាពពិសេស libstd របស់មានការធានាសម្រាប់កូដអ្នកប្រើដែលនេះនឹងធ្វើការនៅក្នុងកំណែ future នៃការចងក្រងទេ!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// ត្រឡប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរទៅទិន្នន័យមូលដ្ឋាន។
    ///
    /// ការហៅនេះខ្ចី `UnsafeCell` ទៅវិញទៅមក (នៅពេលចងក្រងពេលវេលា) ដែលធានាថាយើងមានឯកសារយោងតែមួយគត់។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// ដាក់ទ្រនិចដែលអាចប្តូរបានទៅតម្លៃរុំ។
    /// ភាពខុសគ្នាចំពោះ [`get`] គឺមុខងារនេះទទួលយកទ្រនិចឆៅដែលមានប្រយោជន៍ដើម្បីជៀសវាងការបង្កើតឯកសារយោងបណ្តោះអាសន្ន។
    ///
    /// លទ្ធផលនេះអាចត្រូវបានបោះទៅឱ្យព្រួញនៃប្រភេទណាមួយ។
    /// ធានាបានថាការចូលដំណើរការនេះគឺមានតែមួយគត់ (សេចក្តីយោងសកម្មទេ mutable ឬមិនបាន) នៅពេលដែលខាសទៅ `&mut T` និងធានាថាមិនមានការផ្លាស់ប្តូរឬឈ្មោះក្លែងក្លាយ mutable នឹងនៅលើនៅពេលដែលខាសទៅ `&T` ។
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// ការចាប់ផ្តើមជាបណ្តើរ ៗ នៃ `UnsafeCell` តម្រូវឱ្យមាន `raw_get` ខណៈការហៅទូរស័ព្ទ `get` នឹងតម្រូវឱ្យមានការបង្កើតឯកសារយោងទៅទិន្នន័យដែលមិនមានឯកសិទ្ធិ:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // យើងគ្រាន់តែអាចបោះព្រួញពី `UnsafeCell<T>` ទៅ `T` ដោយសារតែ #[repr(transparent)] ។
        // នេះរំខានស្ថានភាពពិសេស libstd របស់មានការធានាសម្រាប់កូដអ្នកប្រើដែលនេះនឹងធ្វើការនៅក្នុងកំណែ future នៃការចងក្រងទេ!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// បង្កើត `UnsafeCell` ដែលមានតម្លៃ `Default` សំរាប់ T ។
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}