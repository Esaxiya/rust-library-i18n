use crate::iter::FromIterator;

/// បង្រួមធាតុឯកតាទាំងអស់ពីឧបករណ៍រំកិលទៅជារបស់មួយ។
///
/// វាមានប្រយោជន៍ច្រើននៅពេលផ្សំជាមួយការអរូបីកម្រិតខ្ពស់ដូចជាប្រមូលទៅ `Result<(), E>` X ដែលអ្នកគ្រាន់តែយកចិត្តទុកដាក់ចំពោះកំហុស៖
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}