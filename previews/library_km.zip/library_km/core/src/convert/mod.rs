//! Traits សម្រាប់បំលែងរវាងប្រភេទ។
//!
//! traits នៅក្នុងម៉ូឌុលនេះផ្ដល់នូវវិធីដើម្បីបម្លែងពីប្រភេទមួយទៅប្រភេទផ្សេងទៀត។
//! trait នីមួយៗមានគោលបំណងខុសគ្នា៖
//!
//! - អនុវត្តការបម្លែងនៅសម្រាប់ [`AsRef`] trait មានតំលៃថោកសេចក្ដីយោងទៅឯកសារយោង
//! - អនុវត្ត [`AsMut`] trait សម្រាប់ការផ្លាស់ប្តូរដែលអាចផ្លាស់ប្តូរបាននិងមានតំលៃថោក
//! - អនុវត្ត [`From`] trait សម្រាប់ការប្រើប្រាស់ការផ្លាស់ប្តូរតម្លៃទៅតម្លៃ
//! - អនុវត្ត [`Into`] trait សម្រាប់ប្រើប្រាស់ឱ្យមានការសន្ទនាតម្លៃទៅតម្លៃទៅនឹងប្រភេទនៅក្រៅ crate បច្ចុប្បន្ន
//! - [`TryFrom`] និង [`TryInto`] traits មានឥរិយាបទដូចជា [`From`] និង [`Into`] ប៉ុន្តែគួរតែត្រូវបានអនុវត្តនៅពេលការបំលែងអាចបរាជ័យ។
//!
//! traits ក្នុងម៉ូឌុលនេះជាញឹកញាប់ត្រូវបានប្រើជា trait bounds សម្រាប់តួនាទីតាមប្រភេទដូចថាចំពោះអំណះអំណាងរបស់ប្រភេទជាច្រើនត្រូវបានគាំទ្រ។មើលឯកសាររបស់ trait នីមួយៗឧទាហរណ៍។
//!
//! ក្នុងនាមជាអ្នកនិពន្ធបណ្ណាល័យ, អ្នកគួរតែចូលចិត្តការអនុវត្ត [`From<T>`][`From`] ឬ [`TryFrom<T>`][`TryFrom`] ជាជាង [`Into<U>`][`Into`] ឬ [`TryInto<U>`][`TryInto`], ជាការ [`From`] និងការផ្តល់នូវភាពបត់បែនកាន់តែច្រើន [`TryFrom`] និងផ្តល់ជូននូវការអនុវត្ត [`Into`] ឬ [`TryInto`] ដែលមានតំលៃស្មើដោយឥតគិតថ្លៃ, សូមអរគុណទៅអនុវត្តភួយមួយក្នុងបណ្ណាល័យស្តង់ដារ។
//! ពេលដែលផ្ដោតសំខាន់ទៅកំណែមុនពេល Rust 1.41 មួយវាអាចជាការចាំបាច់ដើម្បីអនុវត្ត [`Into`] ឬ [`TryInto`] ដោយផ្ទាល់នៅពេលដែលការបម្លែងទៅប្រភេទនៅក្រៅ crate បច្ចុប្បន្ន។
//!
//! # ទូទៅអនុវត្ត
//!
//! - [`AsRef`] និង [`AsMut`] ដោយស្វ័យប្រវត្តិ dereference ប្រសិនបើប្រភេទខាងក្នុងគឺយោង
//! - [`From`]`<U>សម្រាប់ T` បង្កប់ន័យ [`Into`]`</u><T><U>សម្រាប់លោក U</u>
//! - [`TryFrom`]`<U>សម្រាប់ T` អនុវត្ត [`TryInto`]`</u><T><U>សម្រាប់ U`</u>
//! - [`From`] និង [`Into`] មានការបត់បែន, មធ្យោបាយដែលថាការគ្រប់ប្រភេទអាច `into` ខ្លួនគេនិង `from` ដោយខ្លួនឯង
//!
//! សូមមើល trait នីមួយៗសម្រាប់ឧទាហរណ៍នៃការប្រើប្រាស់។
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// មុខងារអត្តសញ្ញាណ។
///
/// រឿងពីរមានសារៈសំខាន់ក្នុងការកំណត់ចំណាំអំពីមុខងារនេះ:
///
/// - វាមិនមែនតែងតែស្មើនឹងបិទដូច `|x| x`, ចាប់តាំងពីការបិទនេះអាចបង្ខំ `x` ទៅក្នុងប្រភេទផ្សេងគ្នា។
///
/// - វាផ្លាស់ទីទៅបញ្ចូល `x` បានអនុម័តមុខងារនេះ។
///
/// ខណៈពេលដែលវាហាក់ដូចជាចម្លែកដែលមានមុខងារដែលទើបតែត្រឡប់ការបញ្ចូលមានការប្រើប្រាស់គួរឱ្យចាប់អារម្មណ៍មួយចំនួន។
///
///
/// # Examples
///
/// ការប្រើប្រាស់ `identity` មិនធ្វើអ្វីនៅក្នុងលំដាប់នៃមុខងារផ្សេងទៀតគួរឱ្យចាប់អារម្មណ៍:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // ចូរធ្វើពុតថាការបន្ថែមមួយគឺជាមុខងារគួរឱ្យចាប់អារម្មណ៍។
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// ដោយប្រើ `identity` ជាករណីមួយក្នុងមូលដ្ឋាន "do nothing" លក្ខខណ្ឌមួយ:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // តើគួរឱ្យចាប់អារម្មណ៍ជាច្រើនទៀត ... វត្ថុ
///
/// let _results = do_stuff(42);
/// ```
///
/// ការប្រើ `identity` ដើម្បីរក្សា `Some` វ៉ារ្យ៉ង់អន្តរកម្មដែលជាការ `Option<T>` មួយ:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// ត្រូវបានប្រើដើម្បីធ្វើការបំលែងឯកសារយោងទៅជាឯកសារយោង។
///
/// trait នេះគឺស្រដៀងនឹង [`AsMut`] ដែលត្រូវបានប្រើសម្រាប់បំលែងរវាងឯកសារយោងដែលអាចផ្លាស់ប្តូរបាន។
/// ប្រសិនបើអ្នកត្រូវការដើម្បីធ្វើការបំប្លែងថ្លៃវាជាការល្អប្រសើរជាងមុនដើម្បីអនុវត្ត [`From`] ជាមួយនឹងប្រភេទ `&T` ឬសរសេរមុខងារផ្ទាល់ខ្លួនមួយ។
///
/// `AsRef` មានហត្ថលេខាដូចគ្នានឹង [`Borrow`] ដែរប៉ុន្តែ [`Borrow`] គឺខុសគ្នាត្រង់ចំណុចមួយចំនួន៖
///
/// - មិនដូច `AsRef` ទេ [`Borrow`] មានភួយមួយសម្រាប់ `T` ហើយអាចត្រូវបានប្រើដើម្បីទទួលយកឯកសារយោងឬតម្លៃ។
/// - [`Borrow`] ក៏តម្រូវឱ្យមាន [`Hash`], [`Eq`] និង [`Ord`] សម្រាប់តម្លៃខ្ចីគឺស្មើនឹងតម្លៃនៃកម្មសិទ្ធិ។
/// ចំពោះហេតុផលនេះ, ប្រសិនបើអ្នកចង់ខ្ចីគ្រាន់តែជាវាលតែមួយនៃ struct មួយដែលអ្នកអាចអនុវត្ត `AsRef` ប៉ុន្តែមិន [`Borrow`] ។
///
/// **Note: trait នេះមិនត្រូវបរាជ័យឡើយ ** ។ប្រសិនបើការបំលែងអាចបរាជ័យសូមប្រើវិធីសាស្រ្តឧទ្ទិសដែលត្រឡប់ជា [`Option<T>`] ឬ [`Result<T, E>`] ។
///
/// # ទូទៅអនុវត្ត
///
/// - `AsRef` ដោយស្វ័យប្រវត្តិប្រសិនបើប្រភេទ dereferences ផ្នែកខាងក្នុងជាសេចក្ដីយោងឬសេចក្ដីយោង mutable (ឧទាហរណ៍: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// ដោយប្រើ trait bounds យើងអាចទទួលយកអាគុយម៉ង់នៃប្រភេទផ្សេងគ្នាដែលវែងដូចដែលពួកគេអាចត្រូវបានបម្លែងទៅជាប្រភេទដែលបានបញ្ជាក់ `T` ។
///
/// ឧទាហរណ៍: ការបង្កើតមុខងារទូទៅដែលត្រូវចំណាយពេល `AsRef<str>` មួយយើងបង្ហាញថាយើងចង់ទទួលយកសេចក្តីយោងទាំងអស់ដែលអាចត្រូវបានបម្លែងទៅ [`&str`] ជាអាគុយម៉ង់។
/// ចាប់តាំងពីអ្នកទាំងពីរ [`String`] និង [`&str`] អនុវត្ត `AsRef<str>` យើងអាចទទួលយកបានទាំងជាអាគុយម៉ង់បញ្ចូល។
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// ដំណើរការការបម្លែង។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// ប្រើដើម្បីធ្វើការបំលែងឯកសារយោងដែលអាចផ្លាស់ប្តូរបាននិងមានតំលៃថោក។
///
/// trait នេះគឺស្រដៀងគ្នាទៅនឹង [`AsRef`] ប៉ុន្តែត្រូវបានគេប្រើសម្រាប់ការបម្លែងរវាងសេចក្តីយោង mutable ។
/// ប្រសិនបើអ្នកត្រូវធ្វើការបម្លែងតម្លៃខ្ពស់វាជាការប្រសើរក្នុងការអនុវត្ត [`From`] ជាមួយប្រភេទ `&mut T` ឬសរសេរមុខងារផ្ទាល់ខ្លួន។
///
/// **Note: trait នេះមិនត្រូវបរាជ័យឡើយ ** ។ប្រសិនបើការបំលែងអាចបរាជ័យសូមប្រើវិធីសាស្រ្តឧទ្ទិសដែលត្រឡប់ជា [`Option<T>`] ឬ [`Result<T, E>`] ។
///
/// # ទូទៅអនុវត្ត
///
/// - `AsMut` សេចក្តីយោងស្វ័យប្រវត្តិប្រសិនបើប្រភេទខាងក្នុងគឺជាឯកសារយោងដែលអាចផ្លាស់ប្តូរបាន (ឧទាហរណ៍៖ `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// ដោយប្រើ `AsMut` ជាការ trait bound សម្រាប់មុខងារទូទៅយើងអាចទទួលយកសេចក្តីយោង mutable ទាំងអស់ដែលអាចត្រូវបានបម្លែងទៅវាយ `&mut T` ។
/// ដោយសារតែ [`Box<T>`] អនុវត្ត `AsMut<T>` យើងអាចសរសេរមុខងារ `add_one` ដែលយកអាគុយម៉ង់ទាំងអស់ដែលអាចប្តូរទៅជា `&mut u64` ។
/// ដោយសារតែ [`Box<T>`] អនុវត្ត `AsMut<T>`, `add_one` ទទួលយកអាគុយម៉ង់នៃប្រភេទ `&mut Box<u64>` ផងដែរ:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// ដំណើរការការបម្លែង។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// ការបម្លែងតម្លៃទៅតម្លៃដែលប្រើប្រាស់តម្លៃបញ្ចូល។ផ្ទុយពី [`From`] ។
///
/// មួយគួរតែជៀសវាងអនុវត្ត [`Into`] និងអនុវត្ត [`From`] ជំនួសវិញ។
/// ការអនុវត្ត [`From`] ផ្តល់ជូនដោយស្វ័យប្រវត្តិជាមួយនឹងការអនុវត្ត [`Into`] អរគុណចំពោះការអនុវត្តភួយនៅក្នុងបណ្ណាល័យស្តង់ដារ។
///
/// ចូលចិត្តការប្រើ [`Into`] លើ [`From`] ពេលបញ្ជាក់ trait bounds លើមុខងារទូទៅដើម្បីធានាថាប្រភេទដែលអនុវត្ត [`Into`] តែមួយគត់ដែលអាចត្រូវបានប្រើផងដែរ។
///
/// **Note: trait នេះមិនត្រូវបរាជ័យ ** ។ប្រសិនបើមានការបម្លែងអាចបរាជ័យ, ប្រើ [`TryInto`] ។
///
/// # ទូទៅអនុវត្ត
///
/// - [`ពី`] `<T>សម្រាប់ U` មានន័យថា `Into<U> for T`
/// - [`Into`] ជាការបត់បែន, ដែលមានន័យថា `Into<T> for T` ត្រូវបានអនុវត្ត
///
/// # ការអនុវត្ត [`Into`] សម្រាប់ការបម្លែងទៅប្រភេទខាងក្រៅក្នុងកំណែចាស់នៃ Rust
///
/// មុនពេល Rust 1.41, ប្រសិនបើប្រភេទទិសដៅមិនមែនជាផ្នែកមួយនៃ crate បច្ចុប្បន្ននោះអ្នកមិនអាចអនុវត្ត [`From`] ដោយផ្ទាល់ទេ។
/// ឧទាហរណ៍យកកូដនេះ:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// ការនេះនឹងបរាជ័យដើម្បីចងក្រងនៅក្នុងកំណែចាស់នៃភាសានេះដោយសារតែច្បាប់កំព្រា Rust ធ្លាប់ជាតឹងរឹងជាងនេះបន្តិច។
/// ដើម្បីចៀសវាងការនេះអ្នកអាចអនុវត្ត [`Into`] ដោយផ្ទាល់៖
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// វាជាការសំខាន់ក្នុងការយល់ថា [`Into`] មិនផ្តល់នូវការអនុវត្ត [`From`] (ដូច [`From`] ធ្វើការជាមួយ [`Into`]) ។
/// ដូច្នេះអ្នកគួរតែព្យាយាមដើម្បីអនុវត្ត [`From`] ហើយបន្ទាប់មកធ្លាក់ចុះមកវិញដើម្បី [`Into`] ប្រសិនបើ [`From`] មិនអាចត្រូវបានអនុវត្ត។
///
/// # Examples
///
/// [`String`] ការអនុវត្តន៍ [`ចូលទៅក្នុង]` <`[` វ៉ិចទ័រ] `<` [`u៨`] `>>
///
/// នៅក្នុងគោលបំណងដើម្បីបង្ហាញថាយើងចង់បានមុខងារជាទូទៅដើម្បីយកអាគុយម៉ង់ទាំងអស់ដែលអាចត្រូវបានបម្លែងទៅជាប្រភេទដែលបានបញ្ជាក់ `T` យើងអាចប្រើ trait bound នៃ [`Into`]`<T>`។
///
/// ឧទាហរណ៍: មុខងារ `is_hello` នេះត្រូវការអាគុយម៉ង់ទាំងអស់ដែលអាចត្រូវបានបម្លែងទៅជា [`Vec`]`<`[`u8`] `>` ។
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// ដំណើរការការបម្លែង។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// ត្រូវបានប្រើដើម្បីធ្វើការបម្លែងតម្លៃទៅតម្លៃខណៈពេលដែលការប្រើប្រាស់តម្លៃបញ្ចូល។វាគឺជាច្រាស់នៃ [`Into`] ។
///
/// មនុស្សម្នាក់ដែលតែងតែគួរចង់អនុវត្ត `From` លើ [`Into`] ដោយសារតែការអនុវត្តដោយស្វ័យប្រវត្តិមួយដែលបានផ្តល់នូវការ `From` ជាមួយការអនុវត្តន៍នៃ [`Into`] អរគុណចំពោះការអនុវត្តភួយក្នុងបណ្ណាល័យស្តង់ដារ។
///
///
/// អនុវត្តតែ [`Into`] នៅពេលកំណត់គោលដៅមុន Rust 1.41 ហើយបំលែងទៅជាប្រភេទខាងក្រៅ crate បច្ចុប្បន្ន។
/// `From` គឺមិនអាចធ្វើការសន្ទនាទាំងប្រភេទកំណែមុនដោយសារតែក្នុងច្បាប់កំព្រា Rust ការរបស់។
/// សូមមើល [`Into`] សម្រាប់ព័ត៌មានលម្អិត។
///
/// ចូលចិត្តការប្រើ [`Into`] ជាងការប្រើ `From` ពេលបញ្ជាក់ trait bounds លើមុខងារទូទៅ។
/// វិធីនេះប្រភេទដែលអនុវត្តដោយផ្ទាល់ [`Into`] អាចត្រូវបានប្រើជាអាគុយម៉ង់ផងដែរ។
///
/// `From` នេះគឺមានប្រយោជន៍ខ្លាំងណាស់ផងដែរនៅពេលសម្តែងការដោះស្រាយកំហុស។នៅពេលស្ថាបនាអនុគមន៍មួយដែលមានសមត្ថភាពនៃការបរាជ័យមួយប្រភេទត្រឡប់មកវិញជាទូទៅនឹងមានសំណុំបែបបទ `Result<T, E>` នេះ។
/// កំហុស `From` trait អក្សរកាត់ការដោះស្រាយដោយអនុញ្ញាតឱ្យអនុគមន៍ដើម្បីត្រឡប់ប្រភេទកំហុសតែមួយដែលបានដាក់ប្រភេទកំហុសច្រើន។សូមមើលផ្នែក "Examples" និង [the book][book] សម្រាប់សេចក្តីលម្អិតបន្ថែម។
///
/// **Note: trait នេះមិនត្រូវបរាជ័យឡើយ ** ។ប្រសិនបើការបំលែងអាចបរាជ័យសូមប្រើ [`TryFrom`] ។
///
/// # ទូទៅអនុវត្ត
///
/// - `From<T> for U` បង្កប់ន័យ [`ចូលទៅក្នុង]` <U>សម្រាប់ធី `</u>
/// - `From` ជាការបត់បែន, ដែលមានន័យថា `From<T> for T` ត្រូវបានអនុវត្ត
///
/// # Examples
///
/// [`String`] ប់ `From<&str>`:
///
/// ការបម្លែងជាក់លាក់ពី `&str` ទៅជាខ្សែអក្សរត្រូវបានធ្វើដូចខាងក្រោម:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// ខណៈពេលដែលការអនុវត្តការដោះស្រាយកំហុសវាជាញឹកញាប់មានប្រយោជន៍ក្នុងការអនុវត្ត `From` សម្រាប់ប្រភេទកំហុសផ្ទាល់ខ្លួនរបស់អ្នក។
/// ដោយបម្លែងប្រភេទកំហុសមូលដ្ឋានទៅនឹងប្រភេទកំហុសផ្ទាល់ខ្លួនរបស់យើងផ្ទាល់ថា encapsulates ប្រភេទកំហុសជាមូលដ្ឋានយើងអាចត្រឡប់ប្រភេទកំហុសតែមួយដោយមិនបាត់បង់អំពីមូលហេតុនេះ។
/// ប្រតិបត្តិករ '?' បម្លែងប្រភេទកំហុសមូលដ្ឋានទៅនឹងប្រភេទកំហុសផ្ទាល់ខ្លួនរបស់យើងដោយស្វ័យប្រវត្តិដោយការហៅទូរស័ព្ទ `Into<CliError>::into` ដែលត្រូវបានផ្តល់ដោយស្វ័យប្រវត្តិនៅពេលដែលការអនុវត្ត `From` ។
/// ចងក្រងបន្ទាប់មកសន្និដ្ឋានដែលការអនុវត្តនៃ `Into` គួរត្រូវបានប្រើ។
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// ដំណើរការការបម្លែង។
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// ការប៉ុនប៉ងបំលែងថាមពលដែលស៊ី `self` ដែលអាចឬមិនថ្លៃ។
///
/// អ្នកនិពន្ធបណ្ណាល័យគួរជាធម្មតាមិនអនុវត្ត trait នេះដោយផ្ទាល់ទេប៉ុន្តែគួរចង់អនុវត្ត [`TryFrom`] trait ដែលផ្តល់នូវភាពបត់បែនកាន់តែច្រើននិងផ្ដល់នូវការអនុវត្ត `TryInto` តំលៃស្មើដោយឥតគិតថ្លៃ, សូមអរគុណទៅអនុវត្តភួយមួយក្នុងបណ្ណាល័យស្តង់ដារ។
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីបញ្ហានេះសូមមើលឯកសារសម្រាប់ [`Into`] ។
///
/// # អនុវត្ត `TryInto`
///
/// នេះទទួលរងការរឹតបន្តឹងដូចគ្នានិងហេតុផលជាការអនុវត្ត [`Into`] នៅទីនោះសម្រាប់សេចក្ដីលម្អិត។
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// ប្រភេទត្រឡប់មកវិញនៅក្នុងព្រឹត្តិការណ៍នៃកំហុសការបម្លែងមួយ។
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ដំណើរការការបម្លែង។
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// សាមញ្ញនិងការបម្លែងប្រភេទដែលមានសុវត្ថិភាពដែលអាចបរាជ័យនៅក្នុងវិធីមួយដែលបានគ្រប់គ្រងក្រោមកាលៈទេសៈមួយចំនួន។វាជាចំរាស់នៃ [`TryInto`] នេះ។
///
/// នេះមានប្រយោជន៍ពេលអ្នកកំពុងធ្វើការបម្លែងប្រភេទដែលមិនសំខាន់អាចទទួលបានជោគជ័យនោះទេប៉ុន្តែអាចនឹងត្រូវដោះស្រាយពិសេស។
/// ឧទាហរណ៍មានគឺជាវិធីដើម្បីបម្លែងទៅក្នុង [`i32`] [`i64`] ដោយប្រើ [`From`] trait មួយ, ដោយសារ [`i64`] មួយអាចមានតម្លៃដែល [`i32`] មួយដែលមិនអាចតំណាងឱ្យហើយដូច្នេះការបម្លែងនេះនឹងបាត់បង់ទិន្នន័យឡើយ។
///
/// នេះអាចត្រូវបានដោះស្រាយដោយ truncating [`i64`] ដើម្បី [`i32`] មួយ (សំខាន់ផ្តល់ [`i64`] 's បានតម្លៃសំណល់ [`i32::MAX`]) ឬដោយគ្រាន់តែវិលត្រឡប់មក [`i32::MAX`] ឬដោយវិធីសាស្រ្តមួយចំនួនផ្សេងទៀត។
/// នេះ [`From`] trait គឺត្រូវបានបម្រុងទុកសម្រាប់ការផ្លាស់ប្រែចិត្ដល្អឥតខ្ចោះដូច្នេះ `TryFrom` trait ប្រាប់អ្នកសរសេរកម្មវិធីមួយប្រភេទនៅពេលដែលការផ្លាស់ប្រែចិត្តជឿទៅអាក្រក់និងអាចធ្វើឱ្យពួកគេសម្រេចចិត្តអំពីរបៀបដែលអនុញ្ញាតឱ្យការដោះស្រាយវា។
///
/// # ទូទៅអនុវត្ត
///
/// - `TryFrom<T> for U` បង្កប់ន័យ [`ទ្រីនីថូន]` <U>សម្រាប់ធី `</u>
/// - [`try_from`] ជាការបត់បែន, ដែលមានន័យថា `TryFrom<T> for T` ត្រូវបានអនុវត្តនិងមិនអាចបរាជ័យ-ប្រភេទ `Error` ដែលជាប់ទាក់ទងសម្រាប់ការហៅទូរស័ព្ទ `T::try_from()` លើតម្លៃរបស់ប្រភេទ `T` គឺ [`Infallible`] ។
/// នៅពេលប្រភេទ [`!`] មានស្ថេរភាព [`Infallible`] និង [`!`] នឹងស្មើនឹង។
///
/// `TryFrom<T>` អាចត្រូវបានអនុវត្តដូចខាងក្រោម:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// ដូចដែលបានរៀបរាប់មា [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // ស្ងាត់កាត់ឱ្យខ្លី `big_number`, តម្រូវឱ្យមានការរកឃើញនិងការដោះស្រាយបន្ទាប់ពីការពិត truncation នេះ។
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // ត្រឡប់កំហុសពីព្រោះ `big_number` ធំពេកមិនសមនឹង `i32` ។
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // ត្រឡប់ `Ok(3)` ។
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// ប្រភេទត្រឡប់មកវិញនៅក្នុងព្រឹត្តិការណ៍នៃកំហុសការបម្លែងមួយ។
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// ដំណើរការការបម្លែង។
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// អនុវត្តទូទៅ
////////////////////////////////////////////////////////////////////////////////

// ដូចជាលើកលើ
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// ក្នុងនាមជាអ្នកការលើកលើ &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ជំនួស impls ខាងលើសម្រាប់ការនិង/មុតជាមួយដូចខាងក្រោមទូទៅបន្ថែមទៀតមួយ&:
// // ក្នុងនាមជាអ្នកការលើកលើ Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>> លោក U: ទំហំ> AsRef <U>សម្រាប់ D, {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// ការលើក AsMut ជាង &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ជំនួស impl ខាងលើសម្រាប់ &mut ជាមួយដូចខាងក្រោមទូទៅបន្ថែមទៀតមួយ:
// // ការលើក AsMut ជាង DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>> លោក U: ទំហំ> AsMut <U>សម្រាប់ D, {fn as_mut(&mut self)-> &mut លោក U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// ពីបង្កប់ន័យទៅក្នុង
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// ពី (ហើយដូច្នេះទៅ) គឺជាការបត់បែន
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **កំណត់សំគាល់ស្ថេរភាព៖** ការបញ្ជាក់នេះមិនទាន់មាននៅឡើយទេប៉ុន្តែយើងគឺជា "reserving space" ដើម្បីបន្ថែមវានៅក្នុង future ។
/// សូមមើល [rust-lang/rust#64715][#64715] សម្រាប់លម្អិត។
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): ធ្វើការជួសជុលមូលដ្ឋានលើគោលការណ៍ជំនួសវិញ។
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom មានន័យថា TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// ផ្លាស់សាសនារាល់គ្នាមានស្មើទៅនឹងការផ្លាស់ប្រែចិត្ដ semantic មួយប្រភេទមានកំហុស fallible មួយដែលគ្មានមនុស្សនៅ។
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS បេតុង
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ប្រភេទកំហុសគ្មានកំហុស
////////////////////////////////////////////////////////////////////////////////

/// ប្រភេទកំហុសសម្រាប់កំហុសដែលមិនអាចកើតឡើង។
///
/// ចាប់តាំងពីពេលនេះមាន enum វ៉ារ្យ៉ង់នោះទេ, តម្លៃនៃប្រភេទនេះពិតជាមានមិនអាច។
/// វាអាចមានប្រយោជន៍សំរាប់ API ទូទៅដែលប្រើ [`Result`] និងកំណត់ប្រភេទកំហុសដើម្បីបញ្ជាក់ថាលទ្ធផលគឺតែងតែជា [`Ok`] ។
///
/// ឧទាហរណ៍ [`TryFrom`] trait (ការបម្លែងដែលត្រឡប់មកវិញ [`Result`] ក) មានការអនុវត្តភួយមួយសម្រាប់គ្រប់ប្រភេទជាកន្លែងដែលការអនុវត្ត [`Into`] បញ្ច្រាសហើយ។
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # ភាពឆបគ្នា Future
///
/// អង់ស៊ីមនេះមានតួនាទីដូចគ្នានឹង [the `!`“never”type][never] ដែរដែលមិនស្ថិតស្ថេរនៅក្នុងកំណែ Rust ។
/// ពេល `!` មានស្ថិរភាពយើងមានគម្រោងដើម្បីធ្វើឱ្យ `Infallible` ប្រភេទឈ្មោះក្លែងក្លាយមួយដើម្បីវា:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... ហើយនៅទីបំផុតរួញរានឹង `Infallible` ។
///
/// ទោះយ៉ាងណាក៏ដោយមានករណីមួយដែលវាក្យសម្ព័ន្ធ `!` អាចត្រូវបានប្រើមុនពេល `!` ត្រូវបានធ្វើឱ្យមានស្ថេរភាពជាប្រភេទពេញទំហឹង: នៅក្នុងទីតាំងនៃប្រភេទត្រឡប់មកវិញនៃមុខងារ។
/// ជាពិសេសវាគឺអាចធ្វើទៅបានសម្រាប់ប្រភេទការអនុវត្តមុខងារពីរផ្សេងគ្នាព្រួញ:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// ជាមួយនឹងការ `Infallible` ត្រូវបាន enum មួយ, លេខកូដនេះគឺជាការត្រឹមត្រូវ។
/// ទោះយ៉ាងណានៅពេល `Infallible` ក្លាយជាឈ្មោះហៅក្រៅចំពោះ never type នោះពាក្យ`impl`s ទាំងពីរនឹងចាប់ផ្តើមត្រួតលើគ្នាហើយដូច្នេះវានឹងមិនត្រូវបានអនុញ្ញាតិអោយប្រើដោយច្បាប់ trait ។
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}