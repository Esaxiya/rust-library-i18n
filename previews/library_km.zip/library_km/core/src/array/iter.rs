//! កំណត់ឧបករណ៍វាស់ម្ចាស់កម្មសិទ្ធិ `IntoIter` សម្រាប់អារេ។

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// តម្លៃ [array] iterator ។
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// នេះគឺជាអារេដែលយើងកំពុងធ្វើឱ្យប្រសើរឡើង។
    ///
    /// ធាតុដែលមានសន្ទស្សន៍ `i` ដែលជាកន្លែងដែល `alive.start <= i < alive.end` មិនត្រូវបានផលទេនិងមានធាតុអារេមានសុពលភាព។
    /// ធាតុដែលមានសូចនាករ `i < alive.start` ឬ `i >= alive.end` ត្រូវបានផ្តល់ជូនរួចហើយហើយមិនត្រូវចូលប្រើទៀតទេ!ធាតុដែលបានស្លាប់ទាំងនោះអាចស្ថិតនៅក្នុងស្ថានភាពមិនមានលក្ខណៈពេញលេញ!
    ///
    ///
    /// ដូច្នេះអាណាព្យាបាលគឺ៖
    /// - `data[alive]` គឺនៅរស់ (មានន័យថាមានធាតុត្រឹមត្រូវ)
    /// - `data[..alive.start]` និង `data[alive.end..]` បានស្លាប់ (ពោលគឺធាតុត្រូវបានអានរួចហើយតែមិនត្រូវប៉ះពាល់ទៀតទេ!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// ធាតុក្នុង `data` ដែលមិនទាន់បានផលទេ។
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// បង្កើតឧបករណ៍ថ្មីមួយទៀតលើ `array` ដែលបានផ្តល់ឱ្យ។
    ///
    /// *ចំណាំ*៖ វិធីសាស្ត្រនេះអាចត្រូវបានបដិសេធនៅក្នុងហ្សុមហ្វឺហ្សូហ្ស៊ីហ្សហ្ស៊ីហ្ស៊ីបន្ទាប់ពី [`IntoIterator` is implemented for arrays][array-into-iter] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // ប្រភេទនៃ `value` គឺជា `i32` នៅទីនេះជំនួសឱ្យ `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // សុវត្ថិភាព: ការចម្លងនៅទីនេះពិតជាមានសុវត្ថិភាព។ឯកសារនៃ `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ត្រូវបានធានាថាមានទំហំនិងការតម្រឹមដូចគ្នា
        // > ដូចជា `T` ។
        //
        // ឯកសារសូម្បីតែបង្ហាញពីការបញ្ជូនពីអារេ `MaybeUninit<T>` ទៅអារេ `T` ។
        //
        //
        // ជាមួយនោះការចាប់ផ្តើមនេះបំពេញការលុកលុយ។

        // FIXME(LukasKalbertodt): ពិតជាប្រើ `mem::transmute` នៅទីនេះ, នៅពេលដែលវាធ្វើការជាមួយជំនាន់ const:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // រហូតមកដល់ពេលនេះយើងអាចប្រើ `mem::transmute_copy` ដើម្បីបង្កើតច្បាប់ចម្លងបន្តិចជាប្រភេទផ្សេងគ្នាបន្ទាប់មកភ្លេច `array` ដើម្បីកុំអោយវាធ្លាក់ចុះ។
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// ត្រឡប់ចំណែកដែលមិនអាចផ្លាស់ប្តូរបាននៃធាតុទាំងអស់ដែលមិនទាន់ត្រូវបានផ្តល់ផលនៅឡើយ។
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // សុវត្ថិភាព: យើងដឹងថាធាតុទាំងអស់នៅក្នុង `alive` ត្រូវបានចាប់ផ្តើមយ៉ាងត្រឹមត្រូវ។
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// ត្រឡប់ចំណែកដែលអាចផ្លាស់ប្តូរបាននៃធាតុទាំងអស់ដែលមិនទាន់ត្រូវបានផ្តល់ផលនៅឡើយ។
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // សុវត្ថិភាព: យើងដឹងថាធាតុទាំងអស់នៅក្នុង `alive` ត្រូវបានចាប់ផ្តើមយ៉ាងត្រឹមត្រូវ។
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // យកសន្ទស្សន៍បន្ទាប់ពីខាងមុខ។
        //
        // ការកើនឡើង `alive.start` ដោយ 1 រក្សាភាពមិនស៊ីចង្វាក់គ្នាទាក់ទងនឹង `alive` ។
        // ទោះយ៉ាងណាក៏ដោយដោយសារតែការផ្លាស់ប្តូរនេះក្នុងរយៈពេលខ្លីតំបន់រស់រានមានជីវិតមិនមែន `data[alive]` ទៀតទេប៉ុន្តែ `data[idx..alive.end]` ។
        //
        self.alive.next().map(|idx| {
            // អានធាតុពីអារេ។
            // សុវត្ថិភាព: `idx` គឺជាលិបិក្រមមួយទៅក្នុងអតីតតំបន់ "alive" នៃ
            // អារេ។ការអានធាតុនេះមានន័យថា `data[idx]` ត្រូវបានគេចាត់ទុកថាស្លាប់ឥឡូវនេះ (ឧទាហរណ៍កុំប៉ះ) ។
            // ដោយសារតែ `idx` គឺជាការចាប់ផ្តើមនៃតំបន់ដែលមានភាពរស់រវើកឥឡូវនេះតំបន់ដែលមានជីវិតគឺ `data[alive]` ជាថ្មីម្តងទៀតដោយបានស្តារឡើងវិញនូវរាល់ការលុកលុយ។
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // ទទួលបានសន្ទស្សន៍ក្រោយពីត្រឡប់មកវិញនោះទេ។
        //
        // ការថយចុះ `alive.end` 1 រក្សាមិនផ្លាស់ប្ដូរទាក់ទងនឹង `alive` នេះ។
        // ទោះយ៉ាងណាក៏ដោយដោយសារតែការផ្លាស់ប្តូរនេះក្នុងរយៈពេលខ្លីតំបន់រស់រានមានជីវិតមិនមែន `data[alive]` ទៀតទេប៉ុន្តែ `data[alive.start..=idx]` ។
        //
        self.alive.next_back().map(|idx| {
            // អានធាតុពីអារេ។
            // សុវត្ថិភាព: `idx` គឺជាលិបិក្រមមួយទៅក្នុងអតីតតំបន់ "alive" នៃ
            // អារេ។ការអានធាតុនេះមានន័យថា `data[idx]` ត្រូវបានគេចាត់ទុកថាស្លាប់ឥឡូវនេះ (ឧទាហរណ៍កុំប៉ះ) ។
            // ដោយសារតែ `idx` គឺជាចុងបញ្ចប់នៃតំបន់ដែលមានភាពរស់រវើកនោះតំបន់រស់រានមានជីវិតឥឡូវនេះ `data[alive]` ជាថ្មីម្តងទៀតដោយបានស្តារឡើងវិញនូវរាល់ការលុកលុយ។
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // សុវត្ថិភាព: នេះគឺមានសុវត្ថិភាព: `as_mut_slice` ត្រឡប់ពិតជាអនុចិត
        // នៃធាតុដែលមិនត្រូវបានផ្លាស់ប្តូរចេញនៅឡើយទេហើយដែលនៅតែត្រូវបានធ្លាក់ចុះ។
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // នឹងមិនដំណើរការដោយសារតែការដែលមិនផ្លាស់ប្ដូរនេះ `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// អ្នកធ្វើរបាយការណ៍ពិតជារាយការណ៍ពីប្រវែងត្រឹមត្រូវ។
// ចំនួនធាតុ "alive" (ដែលនឹងនៅតែផ្តល់ជូន) គឺជាប្រវែងនៃជួរ `alive` ។
// ជួរនេះត្រូវបាន decremented មានប្រវែងទាំងក្នុង `next` ឬ `next_back` ។
// វាតែងតែត្រូវបានកាត់បន្ថយដោយលេខ 1 ក្នុងវិធីសាស្រ្តទាំងនោះប៉ុន្តែមានតែក្នុងករណីដែល `Some(_)` ត្រូវបានត្រឡប់មកវិញ។
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // ចំណាំយើងពិតជាមិនចាំបាច់ត្រូវគ្នានឹងជួរដែលនៅរស់ដូចគ្នាទេដូច្នេះយើងគ្រាន់តែអាចក្លូនទៅក្នុងអុហ្វសិត 0 ដោយមិនគិតពី `self` ។
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // ក្លូនធាតុដែលនៅរស់ទាំងអស់។
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // សរសេរក្លូនមួយចូលទៅក្នុងអារេថ្មី, បន្ទាប់មកធ្វើឱ្យទាន់សម័យជួរនៅរស់របស់ខ្លួន។
            // ប្រសិនបើក្លូន panics យើងនឹងទម្លាក់ធាតុមុន ៗ យ៉ាងត្រឹមត្រូវ។
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // បោះពុម្ពតែធាតុដែលមិនបានផលទេ: យើងមិនអាចចូលដំណើរការធាតុជំរុញអោយមានទៀតទេ។
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}