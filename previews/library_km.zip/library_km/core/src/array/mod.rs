//! ការអនុវត្តនូវអ្វីដែលដូចជា `Eq` សម្រាប់ប្រវែងថេររៀបចំរហូតដល់ប្រវែងជាក់លាក់។
//! នៅទីបំផុតយើងគួរតែអាចធ្វើឱ្យមានប្រវែងជាទូទៅ។
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// បំលែងសេចក្តីយោងទៅ `T` ទៅជាសេចក្តីយោងទៅអារេនៃប្រវែង ១ (ដោយមិនចាំបាច់ចម្លង) ។
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // សុវត្ថិភាព: ការបំលែង `&T` ទៅ `&[T; 1]` គឺល្អ។
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// បម្លែងសេចក្ដីយោង mutable ដើម្បី `T` ចូលទៅក្នុងសេចក្ដីយោង mutable មួយដើម្បីអារេនៃប្រវែង 1 (ដោយគ្មានការចម្លង) ។
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // សុវត្ថិភាព: ការបំលែង `&mut T` ទៅ `&mut [T; 1]` គឺល្អ។
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// ឧបករណ៍ប្រើប្រាស់ trait អនុវត្តតែនៅលើអារេនៃទំហំថេរ
///
/// trait នេះអាចត្រូវបានប្រើដើម្បីអនុវត្ត traits ផ្សេងទៀតលើអារេដែលមានទំហំថេរដោយមិនបង្កឱ្យមានការហើមពោះទិន្នន័យមេតាតាតាច្រើនទេ។
///
/// trait ត្រូវបានសម្គាល់ថាមិនមានសុវត្ថិភាពដើម្បីដាក់កម្រិតដល់អ្នកអនុវត្តចំពោះអារេទំហំថេរ។
/// អ្នកប្រើ trait នេះអាចសន្មតថាអ្នកអនុវត្តមានប្លង់ពិតប្រាកដនៅក្នុងសតិនៃអារេទំហំថេរ (ឧទាហរណ៍សម្រាប់ការចាប់ផ្តើមគ្មានសុវត្ថិភាព) ។
///
///
/// ចំណាំថា traits [`AsRef`] និងផ្ដល់វិធីសាស្ត្រស្រដៀងគ្នា [`AsMut`] ប្រភេទដែលអាចឱ្យមានការមិនត្រូវបានជួសជុលទំហំអារេ។
/// អ្នកអនុវត្តគួរតែចូលចិត្ត traits ជំនួសវិញ។
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// បម្លែងអារេទៅចំណែកមិនអាចកែប្រែបាន
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// បំលែងអារេទៅជាចំណែកដែលអាចផ្លាស់ប្តូរបាន
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// ប្រភេទកំហុសបានត្រលប់មកវិញនៅពេលការប្តូរពីចំណែកមួយទៅអារេបរាជ័យ។
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // សុវត្ថិភាព: អីទេព្រោះយើងគ្រាន់តែបានពិនិត្យថាកាច់ប្រវែង
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // សុវត្ថិភាព: អីទេព្រោះយើងគ្រាន់តែបានពិនិត្យថាកាច់ប្រវែង
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: ចំនុចខ្លះដែលមិនសូវសំខាន់ត្រូវបានលុបចោលដើម្បីកាត់បន្ថយការហើមពោះ
// __impl_slice_eq2!__impl_slice_eq2 { [A; $N], &'b [B; $N] }! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// ប្រៀបធៀបនៃអារេ [lexicographically](Ord#lexicographical-comparison) អនុវត្ត។
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// នេះ impls លំនាំដើមមិនអាចត្រូវបានធ្វើដោយមានទូទៅ const ដោយសារតែ `[T; 0]` មិនតម្រូវឱ្យមានលំនាំដើមនឹងត្រូវបានអនុវត្ត, និងមានប្លុក impl ផ្សេងគ្នាសម្រាប់លេខផ្សេងគ្នាគឺមិនត្រូវបានគាំទ្រនៅឡើយទេ។
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// ត្រឡប់អារេនៃទំហំដូចគ្នានឹង `self` ដែលមុខងារ `f` អនុវត្តទៅធាតុនីមួយៗតាមលំដាប់លំដោយ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // សុវត្ថិភាព: យើងដឹងច្បាស់ថានេះបម្រុងនឹងទទួលបានយ៉ាងពិតប្រាកដ `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// "លេខកូដប្រៃសណីយ៍ឡើង 'អារេទាំងពីរចូលទៅក្នុងអារេមួយនៃគូ។
    ///
    /// `zip()` ត្រឡប់អារេមួយថ្មីដែលជាកន្លែងដែលធាតុជារៀងរាល់គឺ tuple មួយដែលជាធាតុដំបូងមកពីអារេដំបូងនិងធាតុទីពីរមកពីអារេទីពីរ។
    ///
    /// និយាយម៉្យាងទៀតវាដាក់អារេពីរជាមួយគ្នាចូលទៅក្នុងតែមួយ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // សុវត្ថិភាព: យើងដឹងច្បាស់ថានេះបម្រុងនឹងទទួលបានយ៉ាងពិតប្រាកដ `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// ត្រឡប់អារេចំណែកដែលមានទាំងមូល។ស្មើនឹង `&s[..]` ។
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// ត្រឡប់ចំណែកដែលអាចផ្លាស់ប្តូរបានដែលមានអារេទាំងមូល។
    /// ស្មើនឹង `&mut s[..]` ។
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ខ្ចីធាតុគ្នានិងត្រឡប់អារេនៃសេចក្តីយោងដែលមានទំហំដូចគ្នា `self` មួយ។
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// វិធីសាស្រ្តនេះមានប្រយោជន៍ជាពិសេសប្រសិនបើរួមបញ្ចូលជាមួយវិធីសាស្រ្តផ្សេងទៀតដូចជា [`map`](#method.map) ។
    /// វិធីនេះអ្នកអាចចៀសវាងការផ្លាស់ប្តូរអារេដើមប្រសិនបើធាតុរបស់វាមិនមែន `Copy` ។
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // យើងនៅតែអាចចូលដំណើរការអារេដើម: វាមិនត្រូវបានផ្លាស់ប្តូរ។
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // សុវត្ថិភាព: យើងដឹងច្បាស់ថានេះបម្រុងនឹងទទួលបានយ៉ាងពិតប្រាកដ `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// បញ្ចោញធាតុនីមួយៗទៅគ្នាទៅវិញទៅមកហើយបញ្ជូនមកវិញនូវអារេយោងដែលអាចប្តូរបានដែលមានទំហំប៉ុន `self` ។
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // សុវត្ថិភាព: យើងដឹងច្បាស់ថានេះបម្រុងនឹងទទួលបានយ៉ាងពិតប្រាកដ `N`
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// ធាតុទាញ `N` ពី `iter` និងត្រឡប់មកវិញពួកគេដូចជាអារេមួយ។
/// ប្រសិនបើទ្រនាប់ផ្តល់ទិន្នផលតិចជាង `N` មុខងារនេះបង្ហាញឥរិយាបថដែលមិនបានកំណត់។
///
///
/// សូមមើល [`collect_into_array`] សម្រាប់ព័ត៌មានបន្ថែម។
///
/// # Safety
///
/// វាគឺមានរហូតដល់អ្នកទូរស័ព្ទចូលដើម្បីធានាថា `iter` ធាតុយ៉ាងហោចណាស់ផ្តល់នៅ `N` ។
/// ការរំលោភលើលក្ខខណ្ឌនេះបណ្តាលឱ្យមានអាកប្បកិរិយាដែលមិនបានកំណត់។
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: `TrustedLen` នៅទីនេះគឺជាការពិសោធន៍មួយចំនួន។នេះគ្រាន់តែជាអា
    // មុខងារផ្ទៃក្នុង, ដូច្នេះមានអារម្មណ៍ថាមានសេរីភាពក្នុងការយកចេញប្រសិនបើការចងនេះប្រែទៅជាគំនិតអាក្រក់។
    // ក្នុងករណីដែលថា, ចងចាំផងដែរក្នុងការយក `debug_assert!` ចងទាបដូចខាងក្រោម!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // សុវត្ថិភាព: គ្របដណ្តប់ដោយកិច្ចសន្យាមុខងារ។
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// ធាតុទាញ `N` ពី `iter` និងត្រឡប់មកវិញពួកគេដូចជាអារេមួយ។ប្រសិនបើមានការនិយាយឡើងវិញទិន្នផលតិចជាងធាតុ `N`, `None` ត្រូវបានត្រឡប់និងធាតុរួចទៅហើយទាំងអស់ត្រូវបានជំរុញអោយធ្លាក់ចុះ។
///
/// ដោយសារឧបករណ៍រំកិលត្រូវបានឆ្លងកាត់ជាឯកសារយោងដែលអាចផ្លាស់ប្តូរបានហើយមុខងារនេះហៅថា `next` នៅដង `N` ភាគច្រើនវានៅតែត្រូវបានប្រើដើម្បីយកមកវិញនូវរបស់ដែលនៅសល់។
///
///
/// ប្រសិនបើមាន `iter.next()` panicks ធាតុទាំងអស់ជំរុញអោយមានរួចទៅហើយដោយបម្រុងត្រូវបានធ្លាក់ចុះ។
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // សុវត្ថិភាព: អារេទទេមួយតែងតែត្រូវបានរស់នៅនិងគ្មានការលុបចោលសុពលភាព។
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // សុវត្ថិភាព: ចំណិតឆៅនេះនឹងមានតែវត្ថុដែលចាប់ផ្តើមដំបូងប៉ុណ្ណោះ។
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // សុវត្ថិភាព: `guard.initialized` ចាប់ផ្តើមនៅ 0 ត្រូវបានកើនឡើងមួយនៅក្នុងការ
        // រង្វិលជុំនិងរង្វិលជុំត្រូវបានបញ្ឈប់នៅពេលវាទៅដល់ N (ដែលជា `array.len()`) ។
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // ពិនិត្យមើលថាតើអារេទាំងមូលត្រូវបានចាប់ផ្តើម។
        if guard.initialized == N {
            mem::forget(guard);

            // សុវត្ថិភាព: លក្ខខណ្ឌខាងលើអះអាងថាធាតុទាំងអស់មាន
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // នេះអាចទៅដល់បានលុះត្រាតែឧបករណ៍វាស់ចរន្តអគ្គិសនីហត់នឿយមុនពេល `guard.initialized` ឈានដល់ `N` ។
    //
    // សូមកត់សម្គាល់ផងដែរថា `guard` ត្រូវបានទម្លាក់នៅទីនេះដោយទម្លាក់ធាតុដែលបានចាប់ផ្តើមរួចហើយ។
    None
}