//! នេះគឺជាការមួយដែលត្រូវបានគេប្រើម៉ូឌុលផ្ទៃក្នុងដោយ ifmt បាន!ពេលរត់។រចនាសម្ព័ន្ធទាំងនេះត្រូវបានបញ្ចេញទៅក្នុងអារេខ្សែអក្សរទ្រង់ទ្រាយឋិតិវន្តនាំមុខនៃពេលវេលា precompile ។
//!
//! និយមន័យទាំងនេះគឺស្រដៀងគ្នាទៅនឹងសមមូល `ct` របស់ពួកគេ, ប៉ុន្តែខុសគ្នានៅក្នុងនោះទាំងនេះអាចត្រូវបានបម្រុងទុកដែលត្រូវបានធ្វើឱ្យប្រសើរឡើងនិងឋិតិវន្តបន្តិចសម្រាប់ពេលរត់
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// តម្រឹមអាចធ្វើទៅបានដែលអាចត្រូវបានស្នើសុំជាផ្នែកមួយនៃការធ្វើទ្រង់ទ្រាយដែលជាសារាចរ។
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// ការចង្អុលបង្ហាញថាមាតិកាគួរត្រូវបានតម្រឹមឆ្វេង។
    Left,
    /// ការចង្អុលបង្ហាញថាមាតិកាគួរត្រូវបានតម្រឹមខាងស្តាំ។
    Right,
    /// ការចង្អុលបង្ហាញថាមាតិកាគួរតែមានការកណ្តាលបក្សសម្ព័ន្ធ។
    Center,
    /// មិនមានការស្នើតំរឹមគ្នាទេ។
    Unknown,
}

/// ប្រើដោយអ្នកបញ្ជាក់ [width](https://doc.rust-lang.org/std/fmt/#width) និង [precision](https://doc.rust-lang.org/std/fmt/#precision) ។
#[derive(Copy, Clone)]
pub enum Count {
    /// បញ្ជាក់ជាមួយចំនួនព្យញ្ជនៈ, រក្សាទុកតម្លៃ
    Is(usize),
    /// បញ្ជាក់ដោយប្រើវាក្យសម្ព័ន្ធ `$` និង `*`, រក្សាទុកសន្ទស្សន៍ចូលទៅក្នុង `args` នេះ
    Param(usize),
    /// មិនបានបញ្ជាក់
    Implied,
}