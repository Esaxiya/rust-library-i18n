//! ឧបករណ៍ប្រើប្រាស់សម្រាប់ការធ្វើទ្រង់ទ្រាយនិងខ្សែអក្សរបោះពុម្ព។

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// តម្រឹមអាចធ្វើទៅបានត្រឡប់ដោយ `Formatter::align`
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ការចង្អុលបង្ហាញថាមាតិកាគួរត្រូវបានតម្រឹមឆ្វេង។
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ការចង្អុលបង្ហាញថាមាតិកាគួរត្រូវបានតម្រឹមខាងស្តាំ។
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ការចង្អុលបង្ហាញថាមាតិកាគួរតែមានការកណ្តាលបក្សសម្ព័ន្ធ។
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ប្រភេទត្រឡប់មកវិញដោយវិធីសាស្រ្តធ្វើទ្រង់ទ្រាយ។
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// ប្រភេទកំហុសដែលត្រូវបានត្រឡប់ពីការធ្វើទ្រង់ទ្រាយរបស់សារមួយចូលទៅក្នុងស្ទ្រីមមួយ។
///
/// ប្រភេទនេះមិនគាំទ្រការបញ្ជូនកំហុសក្រៅពីកំហុសដែលបានកើតឡើង។
/// ពបន្ថែមណាមួយត្រូវតែត្រូវបានរៀបចំនឹងត្រូវបានបញ្ជូនតាមរយៈមធ្យោបាយមួយចំនួនផ្សេងទៀត។
///
/// រឿងសំខាន់ដែលត្រូវចងចាំគឺថាប្រភេទ `fmt::Error` មិនគួរច្រឡំជាមួយ [`std::io::Error`] ឬ [`std::error::Error`] ដែលអ្នកក៏អាចមានវិសាលភាពដែរ។
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// ការ trait ការធ្វើទ្រង់ទ្រាយសម្រាប់ការសរសេរឬការទទួលយកចូលទៅក្នុងសតិបណ្ដោះអាសន្នយូនីកូដ-ឬស្ទឹង។
///
/// trait នេះទទួលយកតែទិន្នន័យអ៊ិនគ្រីប UTF-8 and ប៉ុណ្ណោះហើយមិនមែន [flushable] ទេ។
/// ប្រសិនបើអ្នកគ្រាន់តែចង់ទទួលយកយូនីកូដហើយអ្នកមិនចាំបាច់ហូរទេអ្នកគួរតែអនុវត្ត trait នេះ។
/// បើមិនដូច្នេះទេអ្នកគួរតែអនុវត្ត [`std::io::Write`] ។
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// សរសេរចំណែកខ្សែអក្សរមួយទៅជាអ្នកនិពន្ធនេះ, ការវិលត្រឡប់ថាតើការសរសេរទទួលបានជោគជ័យ។
    ///
    /// វិធីសាស្រ្តនេះអាចទទួលជោគជ័យបានលុះត្រាតែខ្សែអក្សរទាំងមូលត្រូវបានសរសេរដោយជោគជ័យហើយវិធីសាស្ត្រនេះនឹងមិនត្រលប់មកវិញទេរហូតដល់ទិន្នន័យទាំងអស់ត្រូវបានសរសេរឬមានកំហុសកើតឡើង។
    ///
    ///
    /// # Errors
    ///
    /// មុខងារនេះនឹងត្រឡប់ឧទាហរណ៍នៃ [`Error`] លើកំហុស។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// សរសេរ [`char`] X ចូលទៅក្នុងអ្នកនិពន្ធនេះដោយត្រឡប់មកវិញថាតើការសរសេរនេះទទួលជោគជ័យឬអត់។
    ///
    /// [`char`] តែមួយអាចត្រូវបានអ៊ិនកូដច្រើនជាងបៃ។
    /// វិធីសាស្រ្តនេះទទួលបានជោគជ័យប្រសិនបើអ្នកគ្រាន់តែអាចលំដាប់បៃទាំងមូលត្រូវបានសរសេរដោយជោគជ័យនិងវិធីសាស្រ្តនេះនឹងមិនវិលត្រឡប់មកវិញរហូតដល់ទិន្នន័យទាំងអស់ត្រូវបានសរសេរឬកំហុសមួយបានកើតឡើង។
    ///
    ///
    /// # Errors
    ///
    /// មុខងារនេះនឹងត្រឡប់ឧទាហរណ៍នៃ [`Error`] លើកំហុស។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// កាវបិទសម្រាប់ការប្រើប្រាស់ម៉ាក្រូ [`write!`] ជាមួយអ្នកអនុវត្ត trait នេះ។
    ///
    /// វិធីសាស្រ្តនេះគួរតែជាទូទៅមិនត្រូវបានហៅដោយដៃ, ប៉ុន្តែជាតាមរយៈម៉ាក្រូ [`write!`] ខ្លួនវាផ្ទាល់។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ការកំណត់រចនាសម្ព័ន្ធសម្រាប់ការធ្វើទ្រង់ទ្រាយ។
///
/// ការ `Formatter` តំណាងឱ្យជម្រើសដែលទាក់ទងទៅនឹងការធ្វើទ្រង់ទ្រាយជាច្រើន។
/// អ្នកប្រើមិនសាងសង់ `ហ្វ្រីប៊ែល` ផ្ទាល់ទេ។សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានទៅឯកសារយោងមួយត្រូវបានបញ្ជូនទៅវិធីសាស្ត្រ `fmt` នៃការធ្វើទ្រង់ទ្រាយ traits ទាំងអស់ដូចជា [`Debug`] និង [`Display`] ។
///
///
/// ដើម្បីធ្វើអន្តរកម្មជាមួយ `Formatter` មួយ, អ្នកនឹងហៅវិធីសាស្រ្តជាច្រើនដើម្បីផ្លាស់ប្តូរជម្រើសផ្សេងគ្នាដែលទាក់ទងទៅនឹងការធ្វើទ្រង់ទ្រាយដែលបាន។
/// ឧទាហរណ៍សូមមើលឯកសារនៃវិធីសាស្រ្តដែលបានកំណត់នៅលើ `Formatter` ខាងក្រោម។
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// អាគុយម៉ង់គឺជាការសំខាន់ជាមួយមុខងារធ្វើទ្រង់ទ្រាយឱ្យប្រសើរបានអនុវត្តដោយផ្នែកស្មើនឹង `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` ។

extern "C" {
    type Opaque;
}

/// រចនាសម្ព័ន្ធនេះតំណាងឱ្យ "argument" ទូទៅដែលត្រូវបានយកដោយក្រុមគ្រួសារ Xprintf នៃមុខងារ។វាមានមុខងារដើម្បីធ្វើទ្រង់ទ្រាយតម្លៃដែលបានផ្តល់។
/// នៅពេលចងក្រងវាត្រូវបានធានាថាមុខងារនិងតម្លៃមានប្រភេទត្រឹមត្រូវហើយបន្ទាប់មករចនាសម្ព័ន្ធនេះត្រូវបានប្រើដើម្បីបញ្ចូលអំណះអំណាងទៅនឹងប្រភេទមួយ។
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// នេះធានានូវតម្លៃថេរតែមួយសម្រាប់ទ្រនិចមុខងារដែលភ្ជាប់ជាមួយ indices/counts នៅក្នុងហេដ្ឋារចនាសម្ព័ន្ធទ្រង់ទ្រាយ។
//
// ចំណាំថាមុខងារដែលបានកំណត់ជាបែបមួយដែលនឹងមិនត្រូវបានត្រឹមត្រូវជាអនុគមន៍តែងតែត្រូវបានដាក់ស្លាក unnamed_addr ជាមួយបច្ចុប្បន្នបន្ថយទៅ LLVM IR ដូច្នេះអាសយដ្ឋានរបស់ពួកគេមិនត្រូវបានចាត់ទុកថាសំខាន់ដើម្បី LLVM និងជាដូចតួ as_usize នេះអាចត្រូវបានគេ miscompiled ។
//
// នៅក្នុងការអនុវត្ត, យើងមិនហៅ as_usize លើការមិន usize មានទិន្នន័យ (ដូចជាបញ្ហានៃជំនាន់ឋិតិវន្តនៃអាគុយម៉ង់ធ្វើទ្រង់ទ្រាយមួយ), ដូច្នេះនេះគឺគ្រាន់តែជាការពិនិត្យបន្ថែមទៀត។
//
// យើងចង់ធានាថាទ្រនិចមុខងារនៅ `USIZE_MARKER` មានអាសយដ្ឋានត្រូវគ្នា *មានតែ* ចំពោះមុខងារដែលយក `&usize` ជាអាគុយម៉ង់ដំបូងរបស់ពួកគេ។
// នេះ read_volatile នៅទីនេះធានាថាយើងអាចធ្វើបានត្រៀមខ្លួនជាស្រេចដោយសុវត្ថិភាពចេញពីឯកសារយោងអនុម័ត usize មួយហើយថាអាសយដ្ឋាននេះមិនមានចំណុចមួយដែលមិនបានទទួលយកមុខងារ usize ។
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // សុវត្ថិភាព: ptr គឺជាឯកសារយោង
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // សុវត្ថិភាព: `mem::transmute(x)` មានសុវត្ថិភាពពីព្រោះ
        //     1. `&'b T` រក្សាអាយុកាលរបស់វាដែលមានប្រភពដើម `'b` X (ដើម្បីកុំអោយមានអាយុកាលគ្មានព្រំដែន)
        //     2.
        //     `&'b T` ហើយ `&'b Opaque` មានប្លង់មេម៉ូរីដូចគ្នា (នៅពេល `T` គឺ `Sized` ដូចនៅទីនេះដែរ) `mem::transmute(f)` មានសុវត្ថិភាពព្រោះ `fn(&T, &mut Formatter<'_>) -> Result` និង `fn(&Opaque, &mut Formatter<'_>) -> Result` មាន ABI ដូចគ្នា (ដរាបណា `T` គឺ `Sized`)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // សុវត្ថិភាព៖ វាល `formatter` ត្រូវបានកំណត់ត្រឹម USIZE_MARKER ប្រសិនបើ
            // តម្លៃនេះគឺ usize, ដូច្នេះនេះគឺជាការមានសុវត្ថិភាព
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ទង់ដែលអាចប្រើបាននៅក្នុងទ្រង់ទ្រាយ v1 នៃ format_args
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// នៅពេលដែលប្រើម៉ាក្រូ format_args! () អនុគមន៍នេះត្រូវបានប្រើដើម្បីបង្កើតរចនាសម្ព័ន្ធអាគុយម៉ង់។
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// មុខងារនេះត្រូវបានប្រើដើម្បីបញ្ជាក់ប៉ារ៉ាម៉ែត្រទ្រង់ទ្រាយមិនស្តង់ដារ។
    /// អារេ `pieces` ត្រូវតែយ៉ាងហោចណាស់ដែលវែងដូចដែល `fmt` ដើម្បីសាងសង់រចនាសម្ព័ន្ធអាគុយម៉ង់ត្រឹមត្រូវ។
    /// ដូចគ្នានេះផងដែរ `Count` ណាមួយនៅក្នុង `fmt` ដែលជា `CountIsParam` ឬ `CountIsNextParam` ត្រូវតែចង្អុលទៅអាគុយម៉ង់ដែលបង្កើតជាមួយ `argumentusize` ។
    ///
    /// ទោះយ៉ាងណាក៏ដោយការខកខានមិនបានធ្វើដូច្នេះមិនបង្កឱ្យមានសុវត្ថិភាពទេប៉ុន្តែនឹងមិនអើពើ។
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ប៉ាន់ស្មានប្រវែងនៃអត្ថបទដែលមានទ្រង់ទ្រាយ។
    ///
    /// នេះត្រូវបានបម្រុងទុកនឹងត្រូវប្រើសម្រាប់ការកំណត់សមត្ថភាព `String` ដំបូងពេលប្រើ `format!` ។
    /// Note: នេះគឺជាការមិនទាបឬចងខាងលើ។
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // ប្រសិនបើខ្សែអក្សរទ្រង់ទ្រាយចាប់ផ្តើមដោយអាគុយម៉ង់សូមកុំធ្វើអាជីវកម្មអ្វីទាំងអស់លើកលែងតែប្រវែងនៃបំណែកមានសារៈសំខាន់។
            //
            //
            0
        } else {
            // មានអំណះអំណាងខ្លះដូច្នេះការជំរុញបន្ថែមណាមួយនឹងត្រូវកំណត់ទីតាំង។
            //
            // ដើម្បីចៀសវាងបញ្ហានេះយើងមានសមត្ថភាពនៅទី "pre-doubling" X នៅទីនេះ។
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// រចនាសម្ព័ន្ធនេះតំណាងឱ្យកំណែ precompiled ដោយសុវត្ថិភាពនៃខ្សែអក្សរទ្រង់ទ្រាយនិងអាគុយម៉ង់របស់ខ្លួន។
/// នេះមិនអាចត្រូវបានបង្កើតនៅពេលរត់ដោយសារតែវាមិនអាចត្រូវបានធ្វើដោយសុវត្ថិភាពដូច្នេះមិនមានផលិតត្រូវបានផ្តល់និងវាលមានឯកជនដើម្បីការពារការកែប្រែ។
///
///
/// ម៉ាក្រូ [`format_args!`] នឹងបង្កើតដោយសុវត្ថិភាពឧទាហរណ៍នៃរចនាសម្ព័ន្ធនេះ។
/// ម៉ាក្រូធ្វើឱ្យខ្សែអក្សរមានសុពលភាពនៅពេលចងក្រងម៉ោងដូច្នេះការប្រើប្រាស់មុខងារ [`write()`] និង [`format()`] អាចត្រូវបានអនុវត្តដោយសុវត្ថិភាព។
///
/// អ្នកអាចប្រើ `Arguments<'a>` ដែល [`format_args!`] ត្រឡប់នៅក្នុងបរិបទ `Debug` និង `Display` ដូចដែលគេឃើញនៅខាងក្រោម។
/// ឧទាហរណ៍ក៏បង្ហាញផងដែរថាទ្រង់ទ្រាយ `Debug` និង `Display` មានលក្ខណៈដូចគ្នា: ខ្សែអក្សរទ្រង់ទ្រាយបកប្រែនៅក្នុង `format_args!` ។
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // បំណែកខ្សែអក្សរទ្រង់ទ្រាយដើម្បីបោះពុម្ព។
    pieces: &'a [&'static str],

    // លក្ខណៈពិសេសកន្លែងដាក់ឬ `None` ប្រសិនបើមានលក្ខណៈពិសេសទាំងអស់នេះគឺជាលំនាំដើម (ដូចក្នុង "{}{}") ។
    fmt: Option<&'a [rt::v1::Argument]>,

    // អាគុយម៉ង់ថាមវន្តសម្រាប់ការកែខៃដើម្បីត្រូវបាន interleaved ជាមួយនឹងបំណែកខ្សែអក្សរ។
    // (រាល់អំណះអំណាងត្រូវបានបន្តដោយបំណែកខ្សែអក្សរមួយ។)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ទទួលបានខ្សែអក្សរដែលបានធ្វើទ្រង់ទ្រាយនោះប្រសិនបើវាមានអាគុយម៉ង់ដែលត្រូវបានធ្វើទ្រង់ទ្រាយទេ។
    ///
    /// នេះអាចត្រូវបានប្រើដើម្បីជៀសវាងការបែងចែកក្នុងករណីតូចតាចបំផុត។
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` គួរធ្វើទ្រង់ទ្រាយលទ្ធផលនៅក្នុងអ្នកសរសេរកម្មវិធី-មុខបរិបទបំបាត់កំហុស។
///
/// និយាយជាទូទៅ, អ្នកគួរតែគ្រាន់តែអនុវត្ត `derive` មួយ `Debug` ។
///
/// នៅពេលប្រើជាមួយឧបករណ៍កំណត់ទ្រង់ទ្រាយឆ្លាស់ `#?` លទ្ធផលត្រូវបានបោះពុម្ពយ៉ាងស្អាត។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// trait នេះអាចត្រូវបានប្រើជាមួយ `#[derive]` ប្រសិនបើវាលទាំងអស់អនុវត្ត `Debug` ។
/// ពេល `derive`d សម្រាប់ structs វានឹងប្រើឈ្មោះរបស់ `struct` បន្ទាប់មក `{`, បន្ទាប់មកជាបញ្ជីបំបែកដោយសញ្ញាក្បៀសគ្នាឈ្មោះវាលនិងតម្លៃ `Debug` បន្ទាប់មក `}` នេះ។
/// សម្រាប់ `អេននី` វានឹងប្រើឈ្មោះបំរែបំរួលហើយបើអាចប្រើបាន `(` បន្ទាប់មកតម្លៃ `Debug` នៃវាលបន្ទាប់មក `)` ។
///
/// # Stability
///
/// ទ្រង់ទ្រាយ `Debug` បានចេញមកគឺមិនមានស្ថេរភាព, ហើយដូច្នេះអាចផ្លាស់ប្តូរជាមួយនឹងកំណែ future Rust ។
/// លើសពីនេះទៀតការប្រតិបត្តិ `Debug` នៃប្រភេទដែលផ្តល់ដោយបណ្ណាល័យស្តង់ដារ (`libstd`, `libcore`, `liballoc`, ល) គឺមិនមានស្ថេរភាព, និងអាចផ្លាស់ប្តូរជាមួយនឹងកំណែ future Rust ។
///
///
/// # Examples
///
/// អត្ថប្រយោជន៍ទាក់ទងនឹងការអនុវត្តន៍មួយ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// ដោយដៃការអនុវត្ត:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// មានវិធីសាស្រ្តមួយចំនួននៅលើ struct ជំនួយដើម្បីជួយអ្នក [`Formatter`] ប្រតិបត្តិសៀវភៅដៃជាមួយដូចជា [`debug_struct`] មាន។
///
/// `Debug` ការអនុវត្តន៍ដោយប្រើទាំង `derive` ឬ API របស់អ្នកបង្កើតកំហុសនៅលើ [`Formatter`] គាំទ្រការបោះពុម្ពស្អាតដោយប្រើទង់ជំនួស៖ `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// ការបោះពុម្ពស្អាតជាមួយ `#?`៖
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// ម៉ូឌុលដាច់ដោយឡែកដើម្បី reexport ម៉ាក្រូ `Debug` ពី prelude ដោយគ្មាន trait `Debug` ។
pub(crate) mod macros {
    /// ម៉ាក្រូដេរីវេបង្កើត impl នៃ trait `Debug` មួយ។
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ធ្វើទ្រង់ទ្រាយ trait សំរាប់ទំរង់ទទេ។ `{}`.
///
/// `Display` ស្រដៀងគ្នាទៅនឹង [`Debug`] គឺទេប៉ុន្តែ `Display` ទិន្នផលគឺសម្រាប់ប្រឈមមុខនឹងអ្នកប្រើ, ហើយដូច្នេះមិនអាចត្រូវបានចេញមក។
///
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការអនុវត្ត `Display` លើប្រភេទមួយ:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// នេះ `Octal` trait គួរធ្វើទ្រង់ទ្រាយទិន្នផលរបស់ខ្លួនដែលជាចំនួននៅក្នុង base-8 មួយ។
///
/// ចំពោះចំនួនគត់ដែលបានចុះហត្ថលេខាបឋម (`i8` ទៅ `i128`, និង `isize`) តម្លៃអវិជ្ជមានត្រូវបានធ្វើទ្រង់ទ្រាយជាតំណាងបំពេញបន្ថែមរបស់ទាំងពីរ។
///
///
/// ទង់ជំនួសគឺ `#` បន្ថែមអក្សរ `0o` នៅពីមុខលទ្ធផល។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋានជាមួយ `i32`:
///
/// ```
/// let x = 42; // 42 គឺ '52' គិតជាគោល
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ការអនុវត្ត `Octal` លើប្រភេទមួយ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // ប្រតិភូទៅការអនុវត្តរបស់អាយ .៣២
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait គួរតែធ្វើទ្រង់ទ្រាយលទ្ធផលជាលេខគោលពីរ។
///
/// ចំពោះចំនួនគត់បានចុះហត្ថលេខាលើបុព្វកាល ([`i8`] ទៅ [`i128`] និង [`isize`]), តម្លៃអវិជ្ជមានត្រូវបានធ្វើទ្រង់ទ្រាយជាតំណាងរបស់ពីរបំពេញបន្ថែម។
///
///
/// ទង់ជំនួសគឺ `#` បន្ថែមអក្សរ `0b` នៅពីមុខលទ្ធផល។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋានជាមួយ [`i32`]:
///
/// ```
/// let x = 42; // លេខ ៤២ គឺ '101010' នៅក្នុងប្រព័ន្ធគោលពីរ
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ការអនុវត្ត `Binary` លើប្រភេទមួយ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // ប្រតិភូទៅការអនុវត្តរបស់អាយ .៣២
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// នេះ `LowerHex` trait គួរធ្វើទ្រង់ទ្រាយលទ្ធផលរបស់វាជាចំនួនគោលដប់ប្រាំមួយក្នុងមួយជាមួយនឹង `a` តាមរយៈ `f` ក្នុងករណីទាបជាង។
///
/// ចំពោះចំនួនគត់ដែលបានចុះហត្ថលេខាបឋម (`i8` ទៅ `i128`, និង `isize`) តម្លៃអវិជ្ជមានត្រូវបានធ្វើទ្រង់ទ្រាយជាតំណាងបំពេញបន្ថែមរបស់ទាំងពីរ។
///
///
/// ទង់ជំនួសគឺ `#` បន្ថែមអក្សរ `0x` នៅពីមុខលទ្ធផល។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋានជាមួយ `i32`:
///
/// ```
/// let x = 42; // 42 គឺ '2a' គោលដប់ប្រាំមួយ
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// អនុវត្ត `LowerHex` លើប្រភេទ៖
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // ប្រតិភូទៅការអនុវត្តរបស់អាយ .៣២
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait គួរតែធ្វើទ្រង់ទ្រាយលទ្ធផលជាលេខគិតជាលេខគោលដប់ប្រាំមួយដែលមាន `A` ដល់ `F` ក្នុងករណីធំ។
///
/// ចំពោះចំនួនគត់ដែលបានចុះហត្ថលេខាបឋម (`i8` ទៅ `i128`, និង `isize`) តម្លៃអវិជ្ជមានត្រូវបានធ្វើទ្រង់ទ្រាយជាតំណាងបំពេញបន្ថែមរបស់ទាំងពីរ។
///
///
/// ទង់ជំនួសគឺ `#` បន្ថែមអក្សរ `0x` នៅពីមុខលទ្ធផល។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋានជាមួយ `i32`:
///
/// ```
/// let x = 42; // ៤២ គឺ '2A' គិតជាគោលដប់ប្រាំមួយ
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// អនុវត្ត `UpperHex` លើប្រភេទ៖
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // ប្រតិភូទៅការអនុវត្តរបស់អាយ .៣២
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait គួរតែធ្វើទ្រង់ទ្រាយលទ្ធផលរបស់វាជាទីតាំងចងចាំ។
/// នេះត្រូវបានបង្ហាញថាជាប្រព័ន្ធគោលដប់ប្រាំមួយជាទូទៅ។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋានជាមួយ `&i32`:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // នេះផលិតអ្វីមួយដូចជា '0x7f06092ac6d0'
/// ```
///
/// អនុវត្ត `Pointer` លើប្រភេទ៖
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // ការប្រើ `as` ដើម្បីបម្លែងទៅ `*const T` មួយដែលអនុវត្តព្រួញដែលយើងអាចប្រើបាន
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// នេះ `LowerExp` trait គួរធ្វើទ្រង់ទ្រាយទិន្នផលរបស់ខ្លួននៅក្នុងការកំណត់នៃវិទ្យាសាស្ត្រនឹងការថយចុះករណី `e` ។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការប្រើប្រាស់ជាមូលដ្ឋានជាមួយ `f64`:
///
/// ```
/// let x = 42.0; // 42.0 គឺ '4.2e1' ក្នុងការកំណត់នៃវិទ្យាសាស្ត្រ
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ការអនុវត្ត `LowerExp` លើប្រភេទមួយ:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // ប្រតិភូទៅការអនុវត្តរបស់ f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait គួរតែធ្វើទ្រង់ទ្រាយលទ្ធផលរបស់ខ្លួននៅក្នុងសញ្ញាណវិទ្យាសាស្ត្រជាមួយនឹងអក្សរធំ `E` ។
///
/// សម្រាប់ព័ត៌មានបន្ថែមអំពីការធ្វើទ្រង់ទ្រាយសូមមើល [the module-level documentation][module] ។
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ការប្រើប្រាស់ជាមូលដ្ឋានជាមួយ `f64`:
///
/// ```
/// let x = 42.0; // 42.0 គឺ '4.2E1' ក្នុងការកំណត់វិទ្យាសាស្ត្រ
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// អនុវត្ត `UpperExp` លើប្រភេទ៖
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // ប្រតិភូទៅការអនុវត្តរបស់ f64
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// ធ្វើទ្រង់ទ្រាយតម្លៃដោយប្រើទម្រង់ដែលបានផ្តល់។
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// មុខងារ `write` ចំណាយពេលស្ទ្រីមលទ្ធផលមួយនិង struct `Arguments` ដែលអាចត្រូវបាន precompiled ជាមួយម៉ាក្រូ `format_args!` ។
///
///
/// អាគុយម៉ង់នឹងត្រូវបានធ្វើទ្រង់ទ្រាយយោងទៅតាមខ្សែអក្សរដែលបានបញ្ជាក់ទ្រង់ទ្រាយទៅក្នុងស្ទ្រីមទិន្នផលដែលបានផ្តល់។
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// សូមចំណាំថាការប្រើប្រាស់ [`write!`] អាចជាការប្រសើរ។ឧទាហរណ៍ៈ
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // យើងអាចប្រើប៉ារ៉ាម៉ែត្រទ្រង់ទ្រាយដើមសម្រាប់អាគុយម៉ង់ទាំងអស់។
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ប្រភេទទាំងអស់មានអាគុយម៉ង់ដែលត្រូវគ្នាដែលត្រូវបានបន្តដោយដុំខ្សែអក្សរមួយ។
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // សុវត្ថិភាព: អាគុយម៉ង់និង args.args មកពីអាគុយម៉ង់ដូចគ្នានេះ,
                // ដែលធានាលិបិក្រមគឺតែងតែមាននៅក្នុងព្រំដែន។
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // អាចមានដុំខ្សែអក្សរសាកល្បងតែមួយគត់ដែលបានចាកចេញ។
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // សុវត្ថិភាព: អាគុយម៉ង់និងអាគុយម៉ង់បានមកពីអាគុយម៉ង់ដូចគ្នា,
    // ដែលធានាលិបិក្រមគឺតែងតែមាននៅក្នុងព្រំដែន។
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // ទាញយកអំណះអំណាងត្រឹមត្រូវ
    debug_assert!(arg.position < args.len());
    // សុវត្ថិភាព: អាគុយម៉ង់និងអាគុយម៉ង់បានមកពីអាគុយម៉ង់ដូចគ្នា,
    // ដែលធានានូវសន្ទស្សន៍របស់វាគឺស្ថិតនៅក្នុងព្រំដែន។
    let value = unsafe { args.get_unchecked(arg.position) };

    // បន្ទាប់មកធ្វើការបោះពុម្ពមួយចំនួន
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // សុវត្តិៈការជជែកវែកញែកនិងអាគុយម៉ង់កើតចេញពីអាគុយម៉ង់តែមួយ
            // ដែលធានាលិបិក្រមនេះគឺតែងតែនៅក្នុងព្រំដែន។
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// ទ្រនាប់បន្ទាប់ពីចុងបញ្ចប់នៃអ្វីមួយ។ត្រឡប់ដោយ `Formatter::padding` ។
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// សរសេរផ្ទាំងប្រកាសនេះ។
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // យើងចង់ផ្លាស់ប្តូរនេះ
            buf: wrap(self.buf),

            // និងអភិរក្សទាំងនេះ
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // វិធីសាស្រ្តជំនួយត្រូវបានប្រើសម្រាប់ចន្លោះនិងការធ្វើទ្រង់ទ្រាយអាគុយម៉ង់ដំណើរការទ្រង់ទ្រាយ traits ដែលថាទាំងអស់អាចប្រើ។
    //

    /// ដំណើរការចន្លោះត្រឹមត្រូវសម្រាប់ចំនួនគត់ដែលត្រូវបានបញ្ចេញចូលទៅក្នុង Str ដែរមួយ។
    /// Str ដែរនេះ *មិនគួរ* មានសញ្ញាសម្រាប់ចំនួនគត់ដែលនឹងត្រូវបានបន្ថែមដោយវិធីសាស្រ្តនេះ។
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, ថាតើចំនួនគត់ដើមគឺទាំងវិជ្ជមានឬសូន្យ។
    /// * បុព្វបទប្រសិនបើតួអក្សរ '#' ត្រូវបានផ្តល់ឱ្យ (Alternate) នេះគឺជាបុព្វបទដែលដាក់នៅចំពោះមុខលេខ។
    ///
    /// * buf, អារេបៃដែលចំនួនត្រូវបានគេធ្វើទ្រង់ទ្រាយ
    ///
    /// មុខងារនេះនឹងមានចំនួនត្រឹមត្រូវសម្រាប់ទង់ដែលបានផ្ដល់ព្រមទាំងទទឹងអប្បបរមា។
    /// វានឹងមិនគិតពីភាពជាក់លាក់ទេ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // យើងត្រូវដក "-" ចេញពីលទ្ធផលលេខ។
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // សរសេរសញ្ញានេះប្រសិនបើវាមាន, ហើយបន្ទាប់មកបុព្វបទបើវាត្រូវបានដាក់ស្នើ
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // វាល `width` គឺមានច្រើននៃប៉ារ៉ាម៉ែត្រ `min-width` នៅចំណុចនេះ។
        match self.width {
            // បើសិនជាមិនតម្រូវឱ្យមានមានប្រវែងអប្បបរមាបន្ទាប់មកយើងគ្រាន់តែអាចសរសេរបៃ។
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ពិនិត្យមើលថាតើយើងមានទទឹងអប្បបរមាប្រសិនបើអញ្ចឹងអញ្ចឹងយើងក៏អាចសរសេរបៃបានដែរ។
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // សញ្ញានិងបុព្វបទទៅមុនចន្លោះប្រសិនបើតួអក្សរបំពេញគឺសូន្យ
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // បើមិនដូច្នោះទេទីសំគាល់និងបុព្វបទទៅបន្ទាប់ពីចន្លោះ
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// មុខងារនេះត្រូវកាត់ជាខ្សែហើយបញ្ចេញវាទៅក្នុងសតិបណ្ដោះអាសន្នបន្ទាប់ពីអនុវត្តទង់ទ្រង់ទ្រាយដែលបានបញ្ជាក់។
    /// ទង់ជាតិនេះត្រូវបានទទួលស្គាល់សម្រាប់ខ្សែអក្សរទូទៅគឺ:
    ///
    /// * ទទឹងទទឹងអប្បបរមានៃអ្វីដើម្បីបញ្ចេញ
    /// * fill/align - អ្វីដែលត្រូវបានបញ្ចេញនិងកន្លែងដែលត្រូវបញ្ចេញវាប្រសិនបើខ្សែអក្សរដែលបានផ្ដល់នឹងតម្រូវឱ្យមាន padded
    /// * ភាពជាក់លាក់, ប្រវែងអតិបរមាដើម្បីបញ្ចេញខ្សែអក្សរដែលបានកាត់ឱ្យខ្លីបើវាជាការបានយូរជាងប្រវែងនេះ
    ///
    /// គួរកត់សម្គាល់ថាមុខងារនេះមិនអើពើនឹងប៉ារ៉ាម៉ែត្រ `flag` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // ធ្វើឱ្យប្រាកដថាមានផ្លូវឆ្ពោះទៅមុខលឿន
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // វាល `precision` អាចត្រូវបានបកប្រែជា `max-width` មួយសម្រាប់ខ្សែអក្សរដែលកំពុងត្រូវបានធ្វើទ្រង់ទ្រាយ។
        //
        let s = if let Some(max) = self.precision {
            // ប្រសិនបើខ្សែអក្សររបស់យើងគឺយូរជាងថាភាពជាក់លាក់, បន្ទាប់មកយើងត្រូវតែមាន truncation ។
            // ទោះជាយ៉ាងណាទង់ផ្សេងទៀតដូចជា `fill`, `width` និង `align` ត្រូវតែធ្វើជានិច្ច។
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // LLVM នៅទីនេះមិនអាចបង្ហាញថា `..i` នឹងមិន panic `&s[..i]` ទេប៉ុន្តែយើងដឹងថាវាមិនអាច panic បានទេ។
                // ប្រើ `get` + `unwrap_or` ដើម្បីចៀសវាង `unsafe` ហើយបើមិនដូច្នេះទេមិនត្រូវបញ្ចេញលេខកូដដែលទាក់ទងនឹងហ្សីនភីស៊ីធីហ្សេនៅទីនេះទេ។
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // វាល `width` គឺមានច្រើននៃប៉ារ៉ាម៉ែត្រ `min-width` នៅចំណុចនេះ។
        match self.width {
            // ប្រសិនបើយើងស្ថិតនៅក្រោមប្រវែងអតិបរមាហើយមិនមានតម្រូវការប្រវែងអប្បបរមាទេនោះយើងគ្រាន់តែអាចបញ្ចេញខ្សែ
            //
            None => self.buf.write_str(s),
            // ប្រសិនបើយើងស្ថិតនៅក្រោមទទឹងអតិបរិមាសូមពិនិត្យមើលថាតើយើងមានទទឹងអប្បបរមាដែរឬអត់ប្រសិនបើដូច្នេះវាងាយស្រួលដូចជាគ្រាន់តែបញ្ចេញខ្សែអក្សរប៉ុណ្ណោះ។
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // ប្រសិនបើយើងស្ថិតនៅក្រោមទទឹងអតិបរមានិងទទឹងអប្បបរមាបន្ទាប់មកបំពេញទទឹងអប្បបរមាជាមួយនឹងខ្សែអក្សរដែលបានបញ្ជាក់ + ការតម្រឹមមួយចំនួន។
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// សរសេរមុនចន្លោះនិងត្រឡប់ក្រោយចន្លោះមិនចុល។
    /// អ្នកទូរស័ព្ទចូលទទួលខុសត្រូវក្នុងការធានាការបិទខ្ទង់ក្រោយត្រូវបានសរសេរបន្ទាប់ពីរឿងដែលត្រូវបានដាក់នៅលើតុ។
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// យកផ្នែកដែលមានទ្រង់ទ្រាយនិងអនុវត្តទ្រនាប់។
    /// សន្មតថាអ្នកទូរស័ព្ទចូលបានប្រគល់គ្រឿងបន្លាស់រួចហើយជាមួយនឹងភាពជាក់លាក់ដែលត្រូវការដូច្នេះ `self.precision` អាចត្រូវបានគេមិនអើពើ។
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // ចំពោះផ្ទាំងក្រដាសសូន្យដែលយើងដឹងយើងធ្វើសញ្ញាដំបូងហើយធ្វើដូចជាយើងគ្មានសញ្ញាតាំងពីដំបូងមក។
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ទីសំគាល់តែងតែទៅមុន
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // យកស្លាកនេះចេញពីផ្នែកធ្វើទ្រង់ទ្រាយ
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // ផ្នែកដែលនៅសល់ឆ្លងកាត់ដំណើរការធម្មតា។
            let len = formatted.len();
            let ret = if width <= len {
                // គ្មានចន្លោះ
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // នេះជាករណីទូទៅហើយយើងដើរផ្លូវកាត់
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // សុវត្ថិភាព: នេះត្រូវបានប្រើសម្រាប់ `flt2dec::Part::Num` និង `flt2dec::Part::Copy` ។
            // វាមានសុវត្ថិភាពដើម្បីប្រើសម្រាប់ការ `flt2dec::Part::Num` តាំងពីតួអក្សរជារៀងរាល់ `c` គឺរវាង `b'0'` និង `b'9'` ដែលមានន័យថា `s` មានសុពលភាព UTF-8 ។
            // វាក៏ប្រហែលជាមានសុវត្ថិភាពក្នុងការអនុវត្តដើម្បីប្រើសម្រាប់ `flt2dec::Part::Copy(buf)` ចាប់តាំងពី `buf` គួរតែជា ASCII ធម្មតាប៉ុន្តែវាអាចទៅរួចសម្រាប់នរណាម្នាក់ដែលផ្តល់តម្លៃមិនល្អសម្រាប់ `buf` ទៅក្នុង `flt2dec::to_shortest_str` ចាប់តាំងពីវាជាមុខងារសាធារណៈ។
            //
            // FIXME: កំណត់ថាតើនេះអាចមានលទ្ធផលក្នុងការ UB បាន។
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 សូន្យ
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// សរសេរទិន្នន័យមួយចំនួនទៅសតិបណ្ដោះអាសន្នដែលមាននៅក្នុងទំរង់នេះ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // នេះគឺស្មើនឹង:
    ///         // សរសេរ! (បង្កើត, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// សរសេរពទ្រង់ទ្រាយខ្លះចូលទៅក្នុងឧទាហរណ៍នេះ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ទង់សម្រាប់ការធ្វើទ្រង់ទ្រាយ
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// តួអក្សរត្រូវបានប្រើជា 'fill' នៅពេលមានការតម្រឹម។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // យើងបានកំណត់ការតម្រឹមទៅស្តាំជាមួយ ">" នេះ។
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// ទង់ជាតិបង្ហាញថាអ្វីដែលសំណុំបែបបទនៃការតម្រឹមត្រូវបានគេស្នើរសុំ។
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// ទទឹងចំនួនគត់ដែលបានបញ្ជាក់ជាជម្រើសដែលលទ្ធផលគួរមាន។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // ប្រសិនបើយើងទទួលបានទទឹងយើងប្រើវា
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // បើមិនដូច្នោះទេយើងធ្វើពិសេសអ្វីសោះ
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// ភាពជាក់លាក់ដែលបានបញ្ជាក់ជាជម្រើសសម្រាប់ប្រភេទលេខ។
    /// ជាជម្រើសទទឹងអតិបរមាសម្រាប់ប្រភេទខ្សែ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // ប្រសិនបើយើងទទួលបានភាពជាក់លាក់យើងប្រើវា។
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // បើមិនដូច្នោះទេយើងនឹងកំណត់ជាលេខ ២ ។
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// កំណត់ថាតើទង់ `+` ត្រូវបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// កំណត់ប្រសិនបើទង់ `-` ត្រូវបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // តើអ្នកចង់បានសញ្ញាដកទេ?មានមួយ!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// កំណត់ថាតើទង់ `#` ត្រូវបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// កំណត់ថាតើទង់ `0` ត្រូវបានបញ្ជាក់។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // យើងមិនអើពើនឹងជម្រើសរបស់ទម្រង់។
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: សំរេចថា API សាធារណៈអ្វីដែលយើងចង់បានសំរាប់ទង់ទាំងពីរនេះ។
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// បង្កើតសាងសង់ [`DebugStruct`] បានរចនាឡើងដើម្បីជួយក្នុងការបង្កើតការប្រតិបត្តិ [`fmt::Debug`] សម្រាប់ structs ។
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// បង្កើតអ្នកសាងសង់ `DebugTuple` ដែលត្រូវបានរចនាឡើងដើម្បីជួយបង្កើតការអនុវត្តន៍ `fmt::Debug` សម្រាប់រចនាសម្ព័ន្ធ tuple ។
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// បង្កើតសាងសង់ `DebugList` បានរចនាឡើងដើម្បីជួយក្នុងការបង្កើតការប្រតិបត្តិ `fmt::Debug` សម្រាប់បញ្ជីដូចរចនាសម្ព័ន្ធ។
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// បង្កើតសាងសង់ `DebugSet` បានរចនាឡើងដើម្បីជួយក្នុងការបង្កើតការប្រតិបត្តិ `fmt::Debug` សម្រាប់សំណុំដូចរចនាសម្ព័ន្ធ។
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// នៅក្នុងឧទាហរណ៍ស្មុគ្រស្មាញជាងនេះយើងប្រើ [`format_args!`] និង `.debug_set()` ដើម្បីកសាងបញ្ជីនៃអាវុធប្រកួតមួយ:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// បង្កើតអ្នកសាងសង់ `DebugMap` ដែលត្រូវបានរចនាឡើងដើម្បីជួយបង្កើតការអនុវត្តន៍ `fmt::Debug` សម្រាប់រចនាសម្ព័ន្ធដូចផែនទី។
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// ការប្រតិបត្តិនៃការធ្វើទ្រង់ទ្រាយ traits នេះស្នូល

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // ប្រសិនបើមានតម្រូវការតួអក្សរគេចចេញ, ការរាយការណ៍មកទល់ពេលនេះនិងជាថុងហ្វាសរសេររំលងផ្សេងទៀត
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // ទង់ជំនួសត្រូវបានព្យាបាលដោយ LowerHex រួចហើយថាជាពិសេស-វាបង្ហាញថាតើត្រូវដាក់បុព្វបទជាមួយ 0x ។
        // យើងប្រើវាដើម្បីធ្វើការចេញថាតើឬមិនសូន្យពង្រីក, ហើយបន្ទាប់មកកំណត់វាដោយគ្មានលក្ខខណ្ឌដើម្បីទទួលបានបុព្វបទ។
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// ការអនុវត្ត Display/Debug សម្រាប់ប្រភេទស្នូលផ្សេងៗ

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell នេះត្រូវបានខ្ចី mutably ដូច្នេះយើងមិនអាចសម្លឹងមើលតម្លៃរបស់វានៅទីនេះ។
                // បង្ហាញកន្លែងដាក់ជំនួស។
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// ប្រសិនបើអ្នករំពឹងថានឹងមានការធ្វើតេស្តដើម្បីឱ្យមាននៅទីនេះមើលទៅជំនួសវិញនៅឯកសារ core/tests/fmt.rs, វាជាច្រើនមានភាពងាយស្រួលជាងការបង្កើតទាំងអស់នៃរចនាសម្ព័ន្ធ rt::Piece នៅទីនេះ។
//
// ការធ្វើតេស្តនៅមានការបែងចែក crate នេះសម្រាប់អ្នកដែលបែងចែកតម្រូវការផងដែរ។