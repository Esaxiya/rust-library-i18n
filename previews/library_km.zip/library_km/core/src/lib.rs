//! # បណ្ណាល័យ Rust ស្នូល
//!
//! បណ្ណាល័យស្នូល Rust គឺជាមូលដ្ឋានគ្រឹះដែលមិនមានភាពអាស្រ័យ [^ ឥតគិតថ្លៃ] របស់ [The Rust Standard Library](../std/index.html) ។
//! វាគឺជាកាវបិទដែលអាចចល័តបានរវាងភាសានិងបណ្ណាល័យរបស់វាដោយកំណត់នូវប្លុកអាគារខាងក្នុងនិងបឋមនៃលេខកូដ Rust ទាំងអស់។
//!
//! វាភ្ជាប់ទៅនឹងបណ្ណាល័យដែលមិនមានខ្សែទឹកខាងលើគ្មានបណ្ណាល័យប្រព័ន្ធនិងបណ្ណាល័យទេ។
//!
//! [^free]: Strictly និយាយមាននិមិត្តសញ្ញាមួយចំនួនដែលត្រូវការប៉ុន្តែ
//!          ពួកគេមិនចាំបាច់ជានិច្ចទេ។
//!
//! បណ្ណាល័យស្នូលនេះគឺ * * តិចតួចបំផុត: វាគឺជាការមិនបានសូម្បីតែដឹងអំពីការបែងចែកគំនរឬធ្វើវាបានផ្ដល់នូវការយល់ស្របឬ I/O ។
//! រឿងទាំងនេះតម្រូវឱ្យមានការធ្វើសមាហរណកម្មវេទិកា, និងបណ្ណាល័យនេះគឺជាវេទិកា-មិនជឿលើព្រះ។
//!
//! # របៀបប្រើបណ្ណាល័យស្នូល
//!
//! សូមកត់សម្គាល់ថាព័ត៌មានលម្អិតទាំងអស់នេះបច្ចុប្បន្នមិនត្រូវបានចាត់ទុកថាមានស្ថេរភាពទេ។
//!
//!
//!
// FIXME: បំពេញឱ្យខ្ញុំនូវព័ត៌មានលម្អិតបន្ថែមទៀតនៅពេលចំណុចប្រទាក់ដោះស្រាយ
//! បណ្ណាល័យនេះត្រូវបានសាងសង់ឡើងនៅលើការសន្មត់នៃនិមិត្តសញ្ញាដែលមានស្រាប់មួយចំនួន:
//!
//! * `memcpy`, `memcmp`, `memset`, ទាំងនេះគឺជាទម្លាប់នៃការចងចាំសំខាន់ៗដែលជារឿយៗត្រូវបានបង្កើតដោយអិលអិលអិម។
//! លើសពីនេះទៀតបណ្ណាល័យនេះអាចធ្វើឱ្យការហៅទូរស័ព្ទជាក់លាក់ទៅក្នុងមុខងារទាំងនេះ។
//! ហត្ថលេខារបស់ពួកគេត្រូវដូចគ្នាដូចដែលរកឃើញនៅក្នុងគ
//!   មុខងារទាំងនេះជារឿយៗត្រូវបានផ្តល់ជូនដោយប្រព័ន្ធ libc ប្រព័ន្ធប៉ុន្តែក៏អាចត្រូវបានផ្តល់ជូនដោយ [compiler-builtins crate](https://crates.io/crates/compiler_builtins) ផងដែរ។
//!
//!
//! * `rust_begin_panic` - មុខងារនេះត្រូវការអាគុយម៉ង់ចំនួនបួន `fmt::Arguments` មួយ `&'static str` មួយនិងពីរ `u32` នេះ។
//! អាគុយម៉ង់ទាំងបួននេះកំណត់សារ panic ឯកសារដែល panic ត្រូវបានគេហៅហើយបន្ទាត់និងជួរឈរនៅខាងក្នុងឯកសារ។
//! វាគឺមានរហូតដល់អតិថិជនរបស់បណ្ណាល័យស្នូលនេះដើម្បីកំណត់មុខងារ panic នេះ;វាត្រូវបានទាមទារដើម្បីមិនត្រឡប់មកវិញ។
//! នេះតម្រូវឱ្យមានគុណលក្ខណៈ `lang` មានឈ្មោះ `panic_impl` ។
//!
//! * `rust_eh_personality` - ត្រូវបានប្រើដោយយន្ដការបរាជ័យនៃការចងក្រង។
//! នេះត្រូវបានផ្គូផ្គងជាញឹកញាប់ដើម្បីមុខងារបុគ្គលិកលក្ខណៈ GCC ប៉ុន្តែ crates ដែលមិនបង្កឱ្យមាន panic មួយដែលអាចត្រូវបានធានាថាមុខងារនេះត្រូវបានមិនដែលហៅ។
//! គុណលក្ខណៈ `lang` ត្រូវបានគេហៅថា `eh_personality` ។
//!
//!
//!

// ចាប់តាំងពីពេល libcore កំណត់ធាតុឡង់មូលដ្ឋានជាច្រើន, ការធ្វើតេស្តទាំងអស់ដែលរស់នៅក្នុង crate ដាច់ដោយឡែកមួយ libcoretest ដើម្បីជៀសវាងបញ្ហាចម្លែក។
//
// នៅទីនេះយើងយ៉ាងជាក់លាក់#[cfg]-out crate ទាំងមូលនេះពេលសាកល្បង។
// ប្រសិនបើយើងមិនធ្វើបែបនេះទេទាំងវត្ថុបុរាណនៃតេស្តដែលបានបង្កើតនិងធាតុភ្ជាប់ដែលបានភ្ជាប់ (ដែលរួមបញ្ចូលទាំងការបញ្ជូនបន្តគ្នា) នឹងកំណត់ទាំងពីរនៃធាតុឡង់ដូចគ្នាហើយនេះនឹងបណ្តាលឱ្យមានកំហុស E0152 "found duplicate lang item" ។
//
// សូមមើលការពិភាក្សានៅក្នុង #50466 សម្រាប់សេចក្តីលម្អិត។
//
// cfg នេះនឹងមិនប៉ះពាល់ដល់ការធ្វើតេស្តឯកសារ។
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // សូមមើល #65860
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: មិនចាំបាច់ជាសាធារណៈ
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// ទាញក្នុង `core_arch` crate ដោយផ្ទាល់ទៅក្នុង libcore ។មាតិកានៃ `core_arch` គឺមាននៅក្នុងឃ្លាំងផ្សេងគ្នា: rust-lang/stdarch.
//
// `core_arch` អាស្រ័យលើ libcore ទេប៉ុន្តែមាតិកានៃម៉ូឌុលនេះត្រូវបានបង្កើតឡើងនៅក្នុងរបៀបមួយដែលទាញវាដោយផ្ទាល់នៅទីនេះធ្វើការដូចថា crate ប្រើ crate នេះជា libcore របស់ខ្លួន។
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: ចំណារពន្យល់នេះគួរតែត្រូវបានប្តូរទៅជា rust-lang/stdarch បន្ទាប់ពីការប៉ះទង្គិចគ្នា
// បានបញ្ចូលគ្នា។បច្ចុប្បន្នវាមិនអាចទេព្រោះចាប់ផ្ដើមដែលបរាជ័យបានជាអ្នក lint បានកំណត់នៅឡើយទេមិនទាន់បាន។
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;