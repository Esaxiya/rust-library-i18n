//! ប្រតិបត្ដិការនៅលើខ្សែអក្សរនិងតួអក្សរ ASCII ។
//!
//! ប្រតិបត្ដិខ្សែរភាគច្រើននៅក្នុង Rust ធ្វើសកម្មភាពលើខ្សែ UTF-8 ។
//! ទោះយ៉ាងណាក៏ដោយពេលខ្លះវាសមហេតុផលជាងមុនដើម្បីពិចារណាតែសំណុំតួអក្សរ ASCII សម្រាប់ប្រតិបត្តិការជាក់លាក់។
//!
//! មុខងារ [`escape_default`] ផ្តល់នូវការរំកិលលើបៃនៃកំណែដែលបានគេចចេញពីតួអក្សរដែលបានផ្តល់ឱ្យ។
//!
//!

#![stable(feature = "core_ascii", since = "1.26.0")]

use crate::fmt;
use crate::iter::FusedIterator;
use crate::ops::Range;
use crate::str::from_utf8_unchecked;

/// អ្នកនិយាយអំពីការរត់គេចពីបៃ។
///
/// `struct` នេះត្រូវបានបង្កើតដោយអនុគមន៍ [`escape_default`] ។
/// មើលឯកសាររបស់វាសម្រាប់ព័ត៌មានបន្ថែម។
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct EscapeDefault {
    range: Range<usize>,
    data: [u8; 4],
}

/// ត្រឡប់ឧបករណ៍រំកិលដែលផលិតកំណែ `u8` ដែលរត់គេចខ្លួន។
///
/// លំនាំដើមត្រូវបានជ្រើសរើសដោយភាពលំអៀងទៅរកការផលិតអក្សរសាស្ត្រដែលស្របច្បាប់ក្នុងភាសាផ្សេងៗគ្នារួមមាន C++ 11 និងភាសា C-family ស្រដៀងគ្នា។
/// ច្បាប់ពិតប្រាកដគឺ៖
///
/// * ផ្ទាំងត្រូវបានគេចខ្លួនជា `\t` ។
/// * ការដឹកត្រឡប់មកវិញត្រូវបានរត់គេចខ្លួនជា `\r` ។
/// * ខ្សែចំណីត្រូវបានរត់គេចខ្លួនជា `\n` ។
/// * សម្រង់ទោលត្រូវបានរត់គេចខ្លួនជា `\'` ។
/// * សម្រង់ពីរដងត្រូវបានរត់គេចខ្លួនខណៈដែល `\"` ។
/// * Backslash ត្រូវបានរត់គេចខ្លួនជា `\\` ។
/// * តួអក្សរណាមួយនៅក្នុងជួរ 'អាចបោះពុម្ពបាន ASCII' `0x20` .. `0x7e` បញ្ចូលមិនត្រូវបានគេចខ្លួនទេ។
/// * កាតផ្សេងទៀតត្រូវបានផ្តល់ឱ្យរត់គេចខ្លួននៃទម្រង់ '\xNN' ។
/// * ការរត់គេចយូនីកូដមិនត្រូវបានបង្កើតដោយមុខងារនេះទេ។
///
/// # Examples
///
/// ```
/// use std::ascii;
///
/// let escaped = ascii::escape_default(b'0').next().unwrap();
/// assert_eq!(b'0', escaped);
///
/// let mut escaped = ascii::escape_default(b'\t');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b't', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\r');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'r', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\n');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'n', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\'');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\'', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'"');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'"', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\\');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'\\', escaped.next().unwrap());
///
/// let mut escaped = ascii::escape_default(b'\x9d');
///
/// assert_eq!(b'\\', escaped.next().unwrap());
/// assert_eq!(b'x', escaped.next().unwrap());
/// assert_eq!(b'9', escaped.next().unwrap());
/// assert_eq!(b'd', escaped.next().unwrap());
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn escape_default(c: u8) -> EscapeDefault {
    let (data, len) = match c {
        b'\t' => ([b'\\', b't', 0, 0], 2),
        b'\r' => ([b'\\', b'r', 0, 0], 2),
        b'\n' => ([b'\\', b'n', 0, 0], 2),
        b'\\' => ([b'\\', b'\\', 0, 0], 2),
        b'\'' => ([b'\\', b'\'', 0, 0], 2),
        b'"' => ([b'\\', b'"', 0, 0], 2),
        b'\x20'..=b'\x7e' => ([c, 0, 0, 0], 1),
        _ => ([b'\\', b'x', hexify(c >> 4), hexify(c & 0xf)], 4),
    };

    return EscapeDefault { range: 0..len, data };

    fn hexify(b: u8) -> u8 {
        match b {
            0..=9 => b'0' + b,
            _ => b'a' + b - 10,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Iterator for EscapeDefault {
    type Item = u8;
    fn next(&mut self) -> Option<u8> {
        self.range.next().map(|i| self.data[i])
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.range.size_hint()
    }
    fn last(mut self) -> Option<u8> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl DoubleEndedIterator for EscapeDefault {
    fn next_back(&mut self) -> Option<u8> {
        self.range.next_back().map(|i| self.data[i])
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ExactSizeIterator for EscapeDefault {}
#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for EscapeDefault {}

#[stable(feature = "ascii_escape_display", since = "1.39.0")]
impl fmt::Display for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // សុវត្ថិភាព: អីទេព្រោះ `escape_default` បានបង្កើតឡើងតែទិន្នន័យ utf-8 ត្រឹមត្រូវ
        f.write_str(unsafe { from_utf8_unchecked(&self.data[self.range.clone()]) })
    }
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for EscapeDefault {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("EscapeDefault { .. }")
    }
}