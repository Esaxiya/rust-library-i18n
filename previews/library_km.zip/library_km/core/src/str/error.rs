//! កំណត់ប្រភេទកំហុស utf8 ។

use crate::fmt;

/// កំហុសដែលអាចកើតឡើងនៅពេលដែលព្យាយាមបកស្រាយលំដាប់នៃ [`u8`] ជាខ្សែអក្សរ។
///
/// ឧទាហរណ៍មុខងារមុខងារនិងវិធីសាស្រ្តគ្រួសារ `from_utf8` សម្រាប់ទាំង [`ខ្សែអក្សរ] និងនិង` `ប្រើវិធីកំហុសនេះ។
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// វិធីសាស្រ្តនៃប្រភេទកំហុសនេះអាចត្រូវបានប្រើដើម្បីបង្កើតមុខងារស្រដៀងនឹង `String::from_utf8_lossy` ដោយមិនចាំបាច់បែងចែកសតិហ៊ាតៈ
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// ត្រឡប់លិបិក្រមនៅក្នុងខ្សែអក្សរដែលបានផ្តល់រហូតដល់ UTF-8 ដែលមានសុពលភាពត្រូវបានផ្ទៀងផ្ទាត់។
    ///
    /// វាគឺជាសន្ទស្សន៍អតិបរមាដែល `from_utf8(&input[..index])` នឹងត្រឡប់ `Ok(_)` ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::str;
    ///
    /// // បៃមិនត្រឹមត្រូវមួយចំនួននៅក្នុងហ្សុនហ្សេវីហ្សហ្សិនហ្សហ្ស៊ីហ្ស
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 ត្រឡប់ Utf8Error មួយ
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // បៃទី ២ មិនមានសុពលភាពនៅទីនេះទេ
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// ផ្តល់ព័បន្ថែមអំពីការបរាជ័យនេះ:
    ///
    /// * `None`: ចុងបញ្ចប់នៃការបញ្ចូលត្រូវបានទៅដល់ដោយមិនរំពឹងទុក។
    ///   `self.valid_up_to()` គឺពី ១ ដល់ ៣ បៃពីចុងបញ្ចូល។
    ///   ប្រសិនបើស្ទ្រីមបៃ (ដូចជាឯកសារឬរន្ធបណ្តាញ) កំពុងត្រូវបានដោះលេខកូដបន្ថែមនេះអាចជា `char` ត្រឹមត្រូវដែលលំដាប់ UTF-8 បៃកំពុងពង្រីកកំណាត់ជាច្រើន។
    ///
    ///
    /// * `Some(len)`: បានជួបប្រទះបៃដែលមិនបានរំពឹងទុក។
    ///   ប្រវែងដែលបានផ្តល់គឺថាលំដាប់បៃមិនត្រឹមត្រូវដែលចាប់ផ្តើមនៅសន្ទស្សន៍ដែលបានផ្តល់ដោយ `valid_up_to()` ។
    ///   ការឌិកូដគួរតែបន្តបន្ទាប់ពីលំដាប់នោះ (បន្ទាប់ពីបញ្ចូល [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) ក្នុងករណីបាត់បង់ការឌិកូដ។
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// កំហុសមួយបានកើតឡើងនៅពេលញែក `bool` ដោយប្រើ [`from_str`] បរាជ័យ
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}