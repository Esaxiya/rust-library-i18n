//! ប្រតិបត្តិការទាក់ទងនឹងសុពលភាព UTF-8 ។

use crate::mem;

use super::Utf8Error;

/// ត្រឡប់អ្នកប្រមូលលេខកូដដំបូងសម្រាប់បៃដំបូង។
/// នេះជាលើកដំបូងគឺជាបៃពិសេសគ្រាន់តែចង់បាត 5 ប៊ីតសម្រាប់ទទឹង 2, 4 ប៊ីតសម្រាប់ទទឹង 3, និង 3 ប៊ីតសម្រាប់ទទឹង 4 ។
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// ត្រឡប់តម្លៃ `ch` ដែលបានធ្វើបច្ចុប្បន្នភាពជាមួយបៃ `byte` បន្ត។
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// ពិនិត្យមើលថាតើបៃគឺជាបៃបន្ត UTF-8 (ពោលគឺការចាប់ផ្តើមជាមួយនឹងការប៊ីតនេះ `10`) ។
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// អានចំណុចកូដបន្ទាប់ពីឧបករណ៍វាស់វង់បៃ (សន្មតថាការអ៊ិនកូដដូច UTF-8) ។
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // ឌិកូដ UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // ករណីម៉ាយប៊េតដើរតាមឌិកូដពីបន្សំបៃចេញពីៈ [[[x y] z] w]
    //
    // NOTE: ការអនុវត្តគឺប្រកាន់អក្សរតូចធំទៅនឹងការបង្កើតពិតប្រាកដនៅទីនេះ
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] ករណី
        // ប៊ីតទី ៥ ក្នុង 0xE0 .. 0xEF តែងតែច្បាស់ដូច្នេះ `init` នៅតែមានសុពលភាពដដែល
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] ករណីប្រើតែ ៣ ប៊ីតទាបនៃ `init`
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// អានចំណុចលេខកូដចុងក្រោយចេញពីបម្រុងបៃ (សន្មត់ថាជា UTF-8-ដូចជាអ៊ិនកូដ) ។
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // ឌិកូដ UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // ករណី Multibyte ធ្វើតាមឌិកូដពីការបូកបញ្ចូលបៃចេញពី៖ [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// ប្រើកាត់ឱ្យខ្លីដើម្បីឱ្យសមនឹង u64 ទៅជាការប្រើប្រាស់
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// ត្រឡប់ `true` ប្រសិនបើបៃណាមួយនៅក្នុងពាក្យ `x` គឺមិនមែនជាអាយហ្គីជី (>=128) ។
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// តាមរយៈការត្រួតពិនិត្យ `v` យាងថាវាជាលំដាប់ UTF-8 ត្រឹមត្រូវ, ការវិលត្រឡប់ `Ok(())` ក្នុងករណីនោះឬប្រសិនបើវាគឺជាការមិនត្រឹមត្រូវ, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // យើងត្រូវការទិន្នន័យប៉ុន្តែមិនមានកំហុសទេ!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // ការអ៊ិនកូដ ២ បៃគឺសំរាប់តំរុយកូដ\u {0080} ទៅ\u {07ff} ដំបូង C2 80 ចុងក្រោយឌីអេហ្វអេហ្វអេអេ
            // ការអ៊ិនកូដ ៣ បៃគឺសម្រាប់ចំណុចកូដ\u {០៨០០} ដល់\u {ffff} ដំបូង E0 A0 ៨០ ចុងក្រោយអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេចអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វអេហ្វ។
            // ការអ៊ិនកូដ 4 បៃគឺសម្រាប់ codepoint\ប៉ុន្មាន {0 ទៅ 1000}{\ប៉ុន្មាន ff F0 10ff} 90 80 80 ដំបូងចុងក្រោយ F4 8F បំបៅកូនដោយទឹកដោះម្តាយបំបៅកូនដោយទឹកដោះម្តាយ
            //
            // ប្រើវាក្យសម្ព័ន្ធ UTF-8 ពី RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8 កន្ទុយ UTF8-3= %xE0% xA0-បំបៅកូនដោយទឹកដោះម្តាយ UTF8 កន្ទុយ/% xE1-EC នេះ 2( UTF8-tail )/%xED% x80-9F UTF8 កន្ទុយ/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // ករណី Ascii ព្យាយាមរំលងទៅមុខយ៉ាងលឿន។
            // នៅពេលដែលទ្រនិចត្រូវបានតម្រឹមសូមអានពាក្យចំនួន ២ ពាក្យក្នុងការនិយាយម្តងទៀតរហូតដល់យើងរកឃើញពាក្យមួយដែលមានបៃដែលមិនមែនជាបៃ។
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // សុវត្ថិភាព: ចាប់តាំងពី `align - index` និង `ascii_block_size` គឺ
                    // គុណ `usize_bytes`, `block = ptr.add(index)` តែងតែតម្រឹមជាមួយ `usize` ដូច្នេះវាមានសុវត្ថិភាពក្នុងការបដិសេធទាំង `block` និង `block.offset(1)` ។
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // បំបែកប្រសិនបើមានបៃដែលមិនមែនជាអ៊ីស្តាស្យា
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // ជំហានពីចំណុចដែលរង្វិលជុំពាក្យនេះឈប់
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// ដែលបានផ្តល់ឱ្យបៃដំបូងកំណត់ចំនួនបៃនៅក្នុងតួអក្សរ UTF-8 នេះ។
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// របាំងនៃប៊ីតតម្លៃនៃបៃបន្ត។
const CONT_MASK: u8 = 0b0011_1111;
/// តម្លៃនៃប៊ីតស្លាក (របាំងស្លាកគឺ !CONT_MASK) នៃបៃបន្ត។
const TAG_CONT_U8: u8 = 0b1000_0000;

// កាត់ប្រវែង `&str` ដល់ប្រវែងភាគច្រើនស្មើនឹង `max` ត្រឡប់ `true` ប្រសិនបើវាត្រូវបានកាត់ឱ្យខ្លីហើយខ្សែអក្សរថ្មី។
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}