//! API លំនាំខ្សែអក្សរ។
//!
//! Pattern API ផ្តល់នូវយន្តការទូទៅសម្រាប់ការប្រើប្រាស់ប្រភេទគំរូផ្សេងៗគ្នានៅពេលស្វែងរកតាមខ្សែអក្សរ។
//!
//! សម្រាប់ព័ត៌មានលម្អិតសូមមើល traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] និង [`DoubleEndedSearcher`] ។
//!
//! ទោះបីជា API នេះមិនស្ថិតស្ថេរក៏ដោយវាត្រូវបានលាតត្រដាងតាមរយៈ API ថេរនៅលើប្រភេទ [`str`] ។
//!
//! # Examples
//!
//! [`Pattern`] គឺ [implemented][pattern-impls] ក្នុងស្ថេរភាពសម្រាប់ [`&str`][`str`] API របស់, [`char`], slices នៃ [`char`] និងមុខងារនិងការបិទការអនុវត្ត `FnMut(char) -> bool` ។
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // លំនាំសាក
//! assert_eq!(s.find('n'), Some(2));
//! // ចំណែកនៃលំនាំគំនូសតាង
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // លំនាំបិទ
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// លំនាំខ្សែអក្សរមួយ។
///
/// ការ `Pattern<'a>` សម្តែងថាប្រភេទការអនុវត្តនេះអាចត្រូវបានប្រើជាលំនាំខ្សែអក្សរមួយសម្រាប់ស្វែងរកក្នុង [`&'a str`][str] មួយ។
///
/// ឧទាហរណ៍ទាំង `'a'` និង `"aa"` គឺជាលំនាំដែលត្រូវនឹងសន្ទស្សន៍ `1` ក្នុងខ្សែអក្សរ `"baaaab"` ។
///
/// trait ខ្លួនវាបានដើរតួនាទីជាសាងសង់សម្រាប់ប្រភេទ [`Searcher`] ជាប់ទាក់ទងដែលបានធ្វើការងារពិតប្រាកដនៃការស្វែងរកការកើតឡើងនៃលំនាំក្នុងខ្សែអក្សរមួយ។
///
///
/// អាស្រ័យលើប្រភេទនៃលំនាំឥរិយាបថនៃវិធីសាស្រ្តដូចជា [`str::find`] និង [`str::contains`] អាចផ្លាស់ប្តូរបាន។
/// តារាងខាងក្រោមពិពណ៌នាអំពីអាកប្បកិរិយាមួយចំនួន។
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// អ្នកស្វែងរកដែលទាក់ទងសម្រាប់គំរូនេះ
    type Searcher: Searcher<'a>;

    /// សាងសង់អ្នកស្វែងរកដែលភ្ជាប់ពី `self` និង `haystack` ដើម្បីស្វែងរក។
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// ពិនិត្យមើលថាតើលំនាំត្រូវគ្នានៅកន្លែងណាដែលមានចលនា
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// ពិនិត្យមើលថាតើលំនាំត្រូវគ្នានៅផ្នែកខាងមុខនៃ haystack ដែរឬទេ
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// ពិនិត្យមើលថាតើគំរូដែលត្រូវគ្នានឹងត្រឡប់មកវិញនៃគំនរចំបើងនៅនេះ
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// យកលំនាំចេញពីផ្នែកខាងមុខនៃ haystack ប្រសិនបើវាត្រូវគ្នា។
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // សុវត្ថិភាព: `Searcher` ត្រូវបានគេដឹងថាត្រូវបង្ហាញសន្ទស្សន៍ត្រឹមត្រូវ។
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// យកលំនាំចេញពីខាងក្រោយនៃ haystack ប្រសិនបើវាត្រូវគ្នា។
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // សុវត្ថិភាព: `Searcher` ត្រូវបានគេដឹងថាត្រូវបង្ហាញសន្ទស្សន៍ត្រឹមត្រូវ។
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// លទ្ធផលនៃការហៅទូរស័ព្ទ [`Searcher::next()`] ឬ [`ReverseSearcher::next_back()`] ។
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// កន្សោមដែលការប្រកួតរបស់លំនាំនេះត្រូវបានគេរកឃើញនៅ `haystack[a..b]` ។
    ///
    Match(usize, usize),
    /// បង្ហាញថា `haystack[a..b]` ត្រូវបានច្រានចោលដែលជាការផ្គូផ្គងគំរូដែលអាចកើតមាន។
    ///
    /// ចំណាំថាវាអាចមានច្រើនជាងមួយ `Reject` រវាង `ផ្គូផ្គង` ពីរមិនមានតំរូវការសំរាប់ពួកវាត្រូវបានបញ្ចូលទៅក្នុងមួយទេ។
    ///
    ///
    Reject(usize, usize),
    /// សម្តែងថារាល់បៃនៃ haystack ត្រូវបានទៅទស្សនា, បញ្ចប់ការនិយាយឡើងវិញ។
    ///
    Done,
}

/// អ្នកស្វែងរកគំរូខ្សែអក្សរ។
///
/// trait នេះផ្តល់នូវវិធីសាស្រ្តសម្រាប់ការស្វែងរកការផ្គូផ្គងដែលមិនត្រួតគ្នានៃលំនាំដែលចាប់ផ្តើមពីផ្នែកខាងមុខ (left) នៃខ្សែអក្សរ។
///
/// វានឹងត្រូវបានអនុវត្តដោយប្រភេទ `Searcher` ប្រភេទ [`Pattern`] trait ដែលជាប់ទាក់ទង។
///
/// trait ត្រូវបានសម្គាល់ថាមិនមានសុវត្ថិភាពពីព្រោះសូចនាករដែលត្រឡប់មកវិញដោយវិធីសាស្ត្រ [`next()`][Searcher::next] ត្រូវបានគេតម្រូវឱ្យកុហកនៅលើព្រំដែន utf8 ដែលមានសុពលភាពនៅក្នុងផ្លូវហៃ។
/// វាអាចឱ្យអ្នកប្រើប្រាស់ trait អាចកាត់ខ្សែរក្រាលដោយគ្មានការពិនិត្យពេលរត់បន្ថែម។
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter សម្រាប់ខ្សែអក្សរមូលដ្ឋានដែលត្រូវស្វែងរក
    ///
    /// នឹងត្រលប់មកវិញនូវ [`&str`][str] ដដែល។
    fn haystack(&self) -> &'a str;

    /// អនុវត្តជំហានស្វែងរកបន្ទាប់ចាប់ផ្តើមពីខាងមុខ។
    ///
    /// - ត្រឡប់ [`Match(a, b)`][SearchStep::Match] ប្រសិនបើ `haystack[a..b]` ត្រូវនឹងលំនាំ។
    /// - ត្រឡប់ [`Reject(a, b)`][SearchStep::Reject] ប្រសិនបើ `haystack[a..b]` មិនអាចផ្គូផ្គងលំនាំសូម្បីតែផ្នែកខ្លះក៏ដោយ។
    /// - ត្រឡប់ [`Done`][SearchStep::Done] ប្រសិនបើបៃនៃ haystack ត្រូវបានទៅទស្សនា។
    ///
    /// ចរន្តនៃតម្លៃ [`Match`][SearchStep::Match] និង [`Reject`][SearchStep::Reject] ឡើងដល់ [`Done`][SearchStep::Done] នឹងមានជួរលិបិក្រមដែលនៅជិតគ្នាដោយមិនត្រួតគ្នាគ្របលើកំពូលភ្នំទាំងមូលហើយដាក់នៅលើព្រំដែន utf8 ។
    ///
    ///
    /// លទ្ធផល [`Match`][SearchStep::Match] ត្រូវការមានលំនាំដែលត្រូវគ្នាទាំងមូលទោះយ៉ាងណាលទ្ធផល [`Reject`][SearchStep::Reject] អាចត្រូវបានបំបែកទៅជាបំណែកដែលនៅជិតគ្នាជាច្រើន។ជួរទាំងពីរអាចមានប្រវែងសូន្យ។
    ///
    /// ឧទាហរណ៍គំរូ `"aaa"` និង haystack `"cbaaaaab"` អាចបង្កើតស្ទ្រីម
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// រកលទ្ធផល [`Match`][SearchStep::Match] បន្ទាប់។មើល [`next()`][Searcher::next] ។
    ///
    /// មិនដូច [`next()`][Searcher::next] ទេមិនមានការធានាថាជួរត្រឡប់មកវិញនៃរឿងនេះទេហើយ [`next_reject`][Searcher::next_reject] នឹងត្រួតស៊ីគ្នា។
    /// នេះនឹងត្រឡប់ `(start_match, end_match)` ដែល start_match គឺជាលិបិក្រមនៃកន្លែងដែលការប្រកួតចាប់ផ្តើមហើយ end_match គឺជាលិបិក្រមបន្ទាប់ពីចប់ការប្រកួត។
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// រកលទ្ធផល [`Reject`][SearchStep::Reject] បន្ទាប់។មើល [`next()`][Searcher::next] និង [`next_match()`][Searcher::next_match] ។
    ///
    /// មិនដូច [`next()`][Searcher::next] ទេមិនមានការធានាថាជួរត្រឡប់មកវិញនៃរឿងនេះទេហើយ [`next_match`][Searcher::next_match] នឹងត្រួតស៊ីគ្នា។
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// អ្នកស្វែងរកបញ្ច្រាសសម្រាប់លំនាំខ្សែអក្សរ។
///
/// trait នេះផ្តល់នូវវិធីសាស្រ្តសម្រាប់ការស្វែងរកការផ្គូផ្គងដែលមិនត្រួតគ្នានៃលំនាំដែលចាប់ផ្តើមពីផ្នែកខាងក្រោយ (right) នៃខ្សែអក្សរ។
///
/// វានឹងត្រូវបានអនុវត្តដោយប្រភេទ [`Searcher`] ប្រភេទ [`Pattern`] trait ដែលជាប់ទាក់ទងប្រសិនបើលំនាំគាំទ្រការស្វែងរកវាពីខាងក្រោយ។
///
///
/// ជួរសន្ទស្សន៍នេះបានត្រឡប់ដោយ trait នេះមិនត្រូវបានទាមទារដើម្បីផ្គូផ្គងយ៉ាងច្បាស់ថាអ្នកដែលនៃការស្វែងរកទៅមុខនៅក្នុងការបញ្ច្រាស។
///
/// សម្រាប់ហេតុផលដែល trait នេះត្រូវបានសម្គាល់មិនមានសុវត្ថិភាពសូមមើលពួកគេមេ trait [`Searcher`] ។
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// អនុវត្តជំហានស្វែងរកបន្ទាប់ចាប់ផ្តើមពីខាងក្រោយ។
    ///
    /// - ត្រឡប់ [`Match(a, b)`][SearchStep::Match] ប្រសិនបើ `haystack[a..b]` ត្រូវនឹងលំនាំ។
    /// - ត្រឡប់ [`Reject(a, b)`][SearchStep::Reject] ប្រសិនបើ `haystack[a..b]` មិនអាចផ្គូផ្គងលំនាំសូម្បីតែផ្នែកខ្លះក៏ដោយ។
    /// - ត្រឡប់ [`Done`][SearchStep::Done] ប្រសិនបើបៃនៃ haystack ត្រូវបានទៅទស្សនា
    ///
    /// ចរន្តនៃតម្លៃ [`Match`][SearchStep::Match] និង [`Reject`][SearchStep::Reject] ឡើងដល់ [`Done`][SearchStep::Done] នឹងមានជួរលិបិក្រមដែលនៅជិតគ្នាដោយមិនត្រួតគ្នាគ្របលើកំពូលភ្នំទាំងមូលហើយដាក់នៅលើព្រំដែន utf8 ។
    ///
    ///
    /// លទ្ធផល [`Match`][SearchStep::Match] ត្រូវការមានលំនាំដែលត្រូវគ្នាទាំងមូលទោះយ៉ាងណាលទ្ធផល [`Reject`][SearchStep::Reject] អាចត្រូវបានបំបែកទៅជាបំណែកដែលនៅជិតគ្នាជាច្រើន។ជួរទាំងពីរអាចមានប្រវែងសូន្យ។
    ///
    /// ឧទាហរណ៍គំរូ `"aaa"` និង haystack `"cbaaaaab"` អាចបង្កើតស្ទ្រីម `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// រកលទ្ធផល [`Match`][SearchStep::Match] បន្ទាប់។
    /// មើល [`next_back()`][ReverseSearcher::next_back] ។
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// រកលទ្ធផល [`Reject`][SearchStep::Reject] បន្ទាប់។
    /// មើល [`next_back()`][ReverseSearcher::next_back] ។
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// សញ្ញាសម្គាល់ trait ដើម្បីបញ្ជាក់ថា [`ReverseSearcher`] អាចត្រូវបានប្រើសម្រាប់ការអនុវត្ត [`DoubleEndedIterator`] ។
///
/// ចំពោះបញ្ហានេះការបញ្ជាក់ពី [`Searcher`] និង [`ReverseSearcher`] ត្រូវអនុវត្តតាមលក្ខខណ្ឌទាំងនេះ៖
///
/// - លទ្ធផលទាំងអស់នៃ `next()` ត្រូវការដូចគ្នាបេះបិទនឹងលទ្ធផលនៃ `next_back()` តាមលំដាប់បញ្ច្រាស។
/// - `next()` និង `next_back()` តម្រូវការដើម្បីមានឥរិយាបទជាពីរចុងនៃជួរនៃតម្លៃមួយ, នោះគឺពួកគេមិនអាច "walk past each other" ។
///
/// # Examples
///
/// `char::Searcher` គឺជា `DoubleEndedSearcher` ពីព្រោះការស្វែងរក [`char`] គ្រាន់តែតម្រូវឱ្យក្រឡេកមើលម្តងមួយៗដែលមានលក្ខណៈដូចគ្នាពីចុងទាំងពីរ។
///
/// `(&str)::Searcher` មិនមែនជា `DoubleEndedSearcher` ទេពីព្រោះលំនាំ `"aa"` នៅក្នុងស្ទ្រីមហៃថ៍ `"aaa"` ត្រូវគ្នានឹង `"[aa]a"` ឬ `"a[aa]"` អាស្រ័យលើផ្នែកណាដែលវាត្រូវបានស្វែងរក។
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// យកគំរូសម្រាប់សាក
/////////////////////////////////////////////////////////////////////////////

/// ប្រភេទដែលទាក់ទងសម្រាប់ `<char as Pattern<'a>>::Searcher` ។
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // ការរាតត្បាតសុវត្ថិភាព: `finger`/`finger_back` ត្រូវតែជាសន្ទស្សន៍ utf8 បៃសុពលភាពនៃ `haystack` ភាពមិនចេះរីងស្ងួតនេះអាចត្រូវបានបំបែក *ក្នុង* Next_match និង Next_match_back ទោះយ៉ាងណាពួកគេត្រូវចេញដោយប្រើម្រាមដៃលើព្រំដែនចំណុចកូដមានសុពលភាព។
    //
    //
    /// `finger` គឺជាសន្ទស្សន៍បៃនៃការស្វែងរកទៅមុខ។
    /// ស្រមៃថាវាមានមុនបៃនៅសន្ទស្សន៍របស់វាពោលគឺ
    /// `haystack[finger]` គឺជាបៃដំបូងនៃចំណិតដែលយើងត្រូវត្រួតពិនិត្យក្នុងពេលស្វែងរក
    ///
    finger: usize,
    /// `finger_back` គឺជាសន្ទស្សន៍បៃនៃការស្វែងរកបញ្ច្រាស។
    /// ស្រមៃថាវាមានបន្ទាប់ពីបៃនៅសន្ទស្សន៍របស់វាពោលគឺ
    /// haystack [finger_back, 1] គឺជាបៃចុងក្រោយនៃចំណិតដែលយើងត្រូវតែត្រួតពិនិត្យកំឡុងពេលស្វែងរកបន្ត (ហើយដូច្នេះបៃដំបូងត្រូវបានត្រួតពិនិត្យនៅពេលហៅទូរស័ព្ទ next_back()) ។
    ///
    finger_back: usize,
    /// តួអក្សរដែលត្រូវបានស្វែងរក
    needle: char,

    // ការរាតត្បាតសុវត្ថិភាព: `utf8_size` ត្រូវតែតិចជាង 5
    /// ចំនួនបៃ `needle` បានកើតឡើងនៅពេលដែលបានអ៊ិនកូដនៅក្នុង utf8 ។
    utf8_size: usize,
    /// ច្បាប់ចម្លងលេខ utf8 នៃ `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // សុវត្ថិភាព: ១-៤ ធានានូវសុវត្ថិភាព `get_unchecked`
        // 1. `self.finger` និង `self.finger_back` ត្រូវបានរក្សាទុកនៅលើព្រំដែនយូនីកូដ (នេះគឺមិនច្បាស់)
        // 2. `self.finger >= 0` ចាប់តាំងពីវាចាប់ផ្តើមនៅលេខ 0 ហើយមានតែការកើនឡើងប៉ុណ្ណោះ
        // 3. `self.finger < self.finger_back` ពីព្រោះបើមិនដូច្នេះទេតួអក្សរដែលបាន `iter` នឹងវិលត្រឡប់មក `SearchStep::Done`
        // 4.
        // `self.finger` មកមុនពេលបញ្ចប់នៃការប្រណាំងនេះពីព្រោះ `self.finger_back` ចាប់ផ្តើមនៅចុងបញ្ចប់ហើយមានតែការថយចុះប៉ុណ្ណោះ
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // បន្ថែមអុហ្វសិតបៃនៃតួអក្សរបច្ចុប្បន្នដោយគ្មានការអ៊ិនកូដជា utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // ទទួលបាន haystack បន្ទាប់ពីបានរកឃើញតួអក្សរចុងក្រោយ
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // បៃចុងក្រោយនៃម្ជុលដែលបានអ៊ិនកូដ utf8 សុវត្ថិភាព: យើងមានដែលមិនធ្លាប់មាននោះគឺ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // ម្រាមដៃថ្មីគឺជាលិបិក្រមនៃបៃដែលយើងបានរកឃើញបូកមួយចាប់តាំងពីយើងទន្ទេញសម្រាប់បៃចុងក្រោយនៃតួអក្សរ។
                //
                // ចំណាំថានេះមិនតែងតែផ្តល់ឱ្យយើងនូវព្រំដែននៅលើព្រំដែន UTF8 ទេ។
                // ប្រសិនបើយើង * មិនបានរកឃើញចរិកលក្ខណៈរបស់យើងទេយើងប្រហែលជាបានធ្វើលិបិក្រមទៅនឹងបៃដែលមិនមែនជាចុងក្រោយនៃតួអក្សរ ៣ បៃរឺ ៤ បៃ។
                // យើងមិនគ្រាន់តែរំលងទៅបៃដែលចាប់ផ្តើមមានសុពលភាពបន្ទាប់ទេពីព្រោះតួអក្សរដូចជាꁁ (U + A041 YI SYLLABLE PA) utf-8 `EA 81 81` នឹងអោយយើងរកឃើញបៃទី ២ នៅពេលរកលេខ ៣ ។
                //
                //
                // ទោះយ៉ាងណាក៏ដោយនេះមិនអីទេ។
                // ខណៈពេលដែលយើងមានភាពលេចធ្លោដែល self.finger ស្ថិតនៅលើព្រំដែន UTF8 ការលុកលុយមិនពឹងផ្អែកលើវិធីសាស្រ្តនេះទេ (វាពឹងផ្អែកលើ CharSearcher::next()) ។
                //
                // យើងគ្រាន់តែចេញពីវិធីសាស្ត្រនេះនៅពេលយើងទៅដល់ចុងបញ្ចប់នៃខ្សែអក្សរឬប្រសិនបើយើងរកឃើញអ្វីមួយ។នៅពេលដែលយើងរកឃើញអ្វីមួយ `finger` នឹងត្រូវបានកំណត់ទៅជាព្រំដែន UTF8 ។
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // រកមិនឃើញអ្វីចេញ
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // អនុញ្ញាតឱ្យប្រធានបទបន្ទាប់ប្រើការអនុវត្តន៍តាមលំនាំដើមពីសៀរភឺរហ្ស៍ហ្សេតហ្សហ្ស៊ី
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // សុវត្ថិភាព: មើលយោបល់សម្រាប់ next() ខាងលើ
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // ដកអុហ្វសិតបៃនៃតួអក្សរបច្ចុប្បន្នដោយគ្មានការអ៊ិនកូដជា utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // ធ្វើឱ្យស្ទ្រីមហៃឡើងប៉ុន្តែមិនរាប់បញ្ចូលតួអក្សរចុងក្រោយដែលបានស្វែងរក
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // បៃចុងក្រោយនៃម្ជុលដែលបានអ៊ិនកូដ utf8 សុវត្ថិភាព: យើងមានដែលមិនធ្លាប់មាននោះគឺ `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // យើងបានស្វែងរកចំណែកតូចមួយដែលត្រូវបានទូទាត់ដោយ self.finger បន្ថែម self.finger ដើម្បីទាញយកមកវិញនូវសន្ទស្សន៍ដើម
                //
                let index = self.finger + index;
                // memrchr នឹងត្រឡប់សន្ទស្សន៍បៃដែលយើងចង់រក។
                // ក្នុងករណីដែលមានតួអក្សរ ASCII នេះយើងពិតជាចង់អោយម្រាមដៃថ្មីរបស់យើងក្លាយជា ("after" ដែលត្រូវបានរកឃើញនៅក្នុងគំរូនៃការនិយាយឡើងវិញ) ។
                //
                // ចំពោះគំនូសតាង multibyte យើងត្រូវរំលងដោយចំនួនបៃដែលពួកគេមានច្រើនជាងអេសស៊ីអាយ
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // រំកិលម្រាមដៃទៅមុនពេលរកឃើញតួអក្សរ (ឧ។ នៅសន្ទស្សន៍ចាប់ផ្តើម)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // យើងមិនអាចប្រើ finger_back=សន្ទស្សន៍ទំហំ + ១ នៅទីនេះទេ។
                // ប្រសិនបើយើងបានរកឃើញតួអក្សរចុងក្រោយនៃតួអក្សរដែលមានទំហំខុសគ្នា (ឬបៃកណ្តាលនៃតួអក្សរខុសគ្នា) យើងត្រូវបាច់ម្រាមដៃថយក្រោយចុះដល់ `index` ។
                // ស្រដៀងគ្នានេះដែរធ្វើឱ្យ `finger_back` មានសក្តានុពលលែងស្ថិតនៅលើព្រំប្រទល់ទៀតប៉ុន្តែនេះមិនអីទេពីព្រោះយើងចាកចេញពីមុខងារនេះនៅលើព្រំដែនឬនៅពេលដែលការស្វែងរកត្រូវបានស្វែងរកទាំងស្រុង។
                //
                //
                // មិនដូច next_match នេះមិនមានបញ្ហានៃការបៃម្តងហើយម្តងទៀតនៅ utf-8 នេះដោយសារតែយើងបានស្វែងរកជាច្រើនគេសម្រាប់បៃចុងក្រោយនេះហើយយើងអាចបានតែបានរកឃើញបៃចុងក្រោយនៅពេលដែលស្វែងរកនៅក្នុងការបញ្ច្រាស។
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // រកមិនឃើញអ្វីចេញ
                return None;
            }
        }
    }

    // អនុញ្ញាតឱ្យបន្ទាប់_reject_backប្រើការអនុវត្តលំនាំដើមពី Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// ស្វែងរកគំនូសតាងដែលស្មើនឹង [`char`] ដែលបានផ្តល់ឱ្យ។
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// យកតំរុយសំរាប់ម៉ាស៊ីនចំរុះ MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ប្រៀបធៀបប្រវែងនៃគំនូសខាងក្នុងបៃខាងក្នុងដើម្បីរកប្រវែងនៃឆ្នាំងសាកបច្ចុប្បន្ន
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // ប្រៀបធៀបប្រវែងនៃគំនូសខាងក្នុងបៃខាងក្នុងដើម្បីរកប្រវែងនៃឆ្នាំងសាកបច្ចុប្បន្ន
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// យកគំរូតាមសម្រាប់ [char]
/////////////////////////////////////////////////////////////////////////////

// Todo: ផ្លាស់ប្តូរ/ដកចេញដោយសារតែភាពមិនច្បាស់នៅក្នុងអត្ថន័យ។

/// ប្រភេទដែលទាក់ទងសម្រាប់ `<&[char] as Pattern<'a>>::Searcher` ។
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// ស្វែងរកគំនូសតាងដែលមានចំនួនស្មើនឹងអក្សរកាត់ណាមួយនៃចំណែក។
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// គំរូសម្រាប់អេហ្វ: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// ប្រភេទដែលទាក់ទងសម្រាប់ `<F as Pattern<'a>>::Searcher` ។
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// ស្វែងរកសម្រាប់ [`char`] ដែលត្រូវនឹងការទស្សន៍ទាយដែលបានផ្តល់។
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// យកតំរុយសំរាប់&&str
/////////////////////////////////////////////////////////////////////////////

/// ប្រតិភូទៅ `&str` impl ។
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// យកតំរុយសំរាប់ &str
/////////////////////////////////////////////////////////////////////////////

/// ការមិនស្វែងរកការបែងចែកខ្សែរង។
///
/// នឹងដោះស្រាយ `""` លំនាំជាការវិលត្រឡប់ការប្រកួតទទេនៅព្រំដែនតួអក្សរនីមួយៗ។
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// ពិនិត្យមើលថាតើលំនាំត្រូវគ្នានៅផ្នែកខាងមុខនៃ haystack ដែរឬទេ។
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// យកលំនាំចេញពីផ្នែកខាងមុខនៃ haystack ប្រសិនបើវាត្រូវគ្នា។
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // សុវត្ថិភាព: បុព្វបទទើបតែត្រូវបានផ្ទៀងផ្ទាត់ថាមាន។
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// ពិនិត្យមើលថាតើលំនាំត្រូវគ្នានៅខាងក្រោយហៃស្តុប។
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// យកលំនាំចេញពីខាងក្រោយនៃ haystack ប្រសិនបើវាត្រូវគ្នា។
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // សុវត្ថិភាព: បច្ច័យទើបតែត្រូវបានផ្ទៀងផ្ទាត់ថាមាន។
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// អ្នកស្វែងរកខ្សែផ្លូវពីរផ្លូវ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// ប្រភេទដែលទាក់ទងសម្រាប់ `<&str as Pattern<'a>>::Searcher` ។
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // ម្ជុលទទេបដិសេធរាល់ char និងផ្គូផ្គងខ្សែអក្សរទទេទាំងអស់រវាងពួកវា
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher ផលិត *សុពលភាពការប្រកួត* សន្ទស្សន៍ដែលបានបំបែកនៅព្រំដែនតួអក្សរដែលវែងដូចដែលវាមិនផ្គូផ្គងត្រឹមត្រូវនិងស្នឹមចមថានិងម្ជុលមានសុពលភាព UTF-8 *បដិសេធ* ពីក្បួនដោះស្រាយនេះអាចនឹងធ្លាក់ចុះនៅលើសន្ទស្សន៍ទេប៉ុន្តែយើងនឹងដើរឱ្យពួកគេដោយដៃទៅព្រំដែនតួអក្សរបន្ទាប់ ដូច្នេះពួកគេមានសុវត្ថិភាព utf-8 ។
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // រំលងទៅព្រំប្រទល់ជាប់
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ការសរសេរចេញករណី `true` និង `false` ដើម្បីលើកទឹកចិត្តចងក្រងទៅពីរជំនាញខាងករណីដោយឡែកពីគ្នា។
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // រំលងទៅព្រំប្រទល់ជាប់
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // សរសេរចេញ `true` និង `false` ដូច `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// ស្ថានភាពផ្ទៃក្នុងនៃក្បួនដោះស្រាយនៃការស្វែងរកខ្សែផ្លូវពីរផ្លូវ។
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// សន្ទស្សន៍កត្តាសំខាន់
    crit_pos: usize,
    /// សន្ទស្សន៍កត្តាសំខាន់សម្រាប់ម្ជុលបញ្ច្រាស
    crit_pos_back: usize,
    period: usize,
    /// `byteset` គឺជាផ្នែកបន្ថែមមួយ (មិនមែនជាផ្នែកនៃវិធីដោះស្រាយតាមវិធីពីរទេ) ។
    /// វាជាប្រភេទ "fingerprint" ៦៤ ប៊ីតដែលប៊ីត `j` នីមួយៗត្រូវគ្នាទៅនឹង (បៃនិង ៦៣)==ចមាននៅក្នុងម្ជុល។
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// លិបិក្រមទៅជាម្ជុលមុនពេលដែលយើងបានផ្គូរផ្គងរួចហើយ
    memory: usize,
    /// លិបិក្រមទៅជាម្ជុលបន្ទាប់ពីនោះយើងបានផ្គូរផ្គងរួចហើយ
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ការពន្យល់ដែលអាចអានបានជាពិសេសអំពីអ្វីដែលកំពុងកើតឡើងនៅទីនេះអាចរកបាននៅក្នុងសៀវភៅ X របស់ X CroXore និង Rytter, ch, ១៣ ។
        // ជាពិសេសមើលលេខកូដសម្រាប់ "Algorithm CP" នៅលើទំ។
        // 323.
        //
        // តើនឹងមានអ្វីនៅលើគឺយើងមានកត្តាសំខាន់មួយចំនួន (u, v) នៃម្ជុលនោះហើយយើងចង់កំណត់ថាតើប៉ុន្មានគឺបច្ច័យនៃការជួបនិង [.. រយៈពេល] មួយ។
        // ប្រសិនបើវាគឺយើងប្រើ "Algorithm CP1" ។
        // បើមិនដូច្នោះទេយើងប្រើ "Algorithm CP2" ដែលត្រូវបានធ្វើឱ្យប្រសើរសម្រាប់រយៈពេលដែលម្ជុលមានទំហំធំ។
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // ករណីរយៈពេលខ្លី-រយៈពេលពិតប្រាកដត្រូវបានគណនាជាកត្តាសំខាន់មួយដាច់ដោយឡែកសម្រាប់ម្ជុលបញ្ច្រាស X=u 'V' ដែលជាកន្លែងដែល | V '|<period(x) ។
            //
            // នេះត្រូវបានពន្លឿនដោយកំឡុងពេលដែលត្រូវបានគេស្គាល់រួចហើយ។
            // ចំណាំថាករណីដូចជា X= "acba" មួយដែលអាចនឹងត្រូវបានដាក់ជាកត្តាយ៉ាងច្បាស់ខ្សែប្រយុទ្ធ (crit_pos=1 រយៈពេល=3) ខណៈពេលដែលកំពុងត្រូវបានដាក់ជាកត្តានឹងរយៈពេលប្រហាក់ប្រហែលក្នុងការបញ្ច្រាស់ (crit_pos=2, រយៈពេល=2) ។
            // យើងប្រើកត្តាបញ្ច្រាសដែលបានផ្តល់ប៉ុន្តែរក្សារយៈពេលជាក់លាក់។
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ករណីរយៈពេលវែង-យើងមានប្រហាក់ប្រហែលទៅនឹងរយៈពេលពិតហើយកុំប្រើការទន្ទេញចាំ។
            //
            //
            // ប្រហាក់ប្រហែលនឹងរយៈពេលដោយភ្ជាប់ទាបជាង max(|u|, |v|) + 1 ។
            // កត្តាសំខាន់មានប្រសិទ្ធិភាពក្នុងការប្រើទាំងការស្វែងរកទៅមុខនិងបញ្ច្រាស។
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // តម្លៃអត់ចេះសោះដើម្បីបញ្ជាក់ថារយៈពេលនេះវែង
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // មួយនៃគំនិតសំខាន់នៃផ្លូវពីរដែលយើង factorize ជាការចាក់ម្ជុលចូលទៅក្នុងខ្សែការពារពីរ (u, v) និងចាប់ផ្តើមព្យាយាមស្វែងរកក្នុងគំនរចំបើងដែលបានជួបដោយស្កែឆ្វេងទៅស្តាំ។
    // ប្រសិនបើ v ត្រូវគ្នាយើងព្យាយាមផ្គូផ្គង u ដោយស្កេនពីឆ្វេងទៅស្តាំ។
    // តើយើងអាចលោតនៅពេលដែលយើងជួបប្រទះភាពមិនត្រូវគ្នានេះគឺមានមូលដ្ឋានទាំងអស់នៅលើការពិតដែលថា (u, v) ជាកត្តាសំខាន់សម្រាប់ម្ជុលនេះ។
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` ប្រើ `self.position` ជាទស្សន៍ទ្រនិចរបស់វា
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // សូមពិនិត្យមើលថាយើងមានបន្ទប់ដើម្បីស្វែងរកនៅក្នុងទីតាំង + + needle_last មិនអាចលើសចំណុះប្រសិនបើយើងសន្មត់ចំណិតត្រូវបានហ៊ុមព័ទ្ធដោយជួរ isize នេះ។
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // រំលងយ៉ាងលឿនដោយផ្នែកធំ ៗ ដែលមិនទាក់ទងនឹងផ្នែករងរបស់យើង
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // ពិនិត្យមើលថាតើផ្នែកខាងស្តាំនៃម្ជុលត្រូវគ្នាដែរឬទេ
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // ពិនិត្យមើលថាតើផ្នែកខាងឆ្វេងនៃម្ជុលត្រូវគ្នាឬអត់
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // យើងបានរកឃើញការប្រកួតមួយហើយ!
            let match_pos = self.position;

            // Note: បន្ថែម self.period ជំនួសឱ្យ needle.len() ដើម្បីឱ្យមានការប្រកួតត្រួតគ្នា
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // កំណត់ទៅ needle.len(), self.period សម្រាប់ការប្រកួតត្រួតគ្នា
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // ខាងក្រោមគំនិតក្នុងការ `next()` ។
    //
    // និយមន័យគឺស៊ីមេទ្រីដែលមាន period(x) = period(reverse(x)) និង local_period(u, v) = local_period(reverse(v), reverse(u)) ដូច្នេះប្រសិនបើ (u, v) គឺជាកត្តាសំខាន់ដូច្នេះ (reverse(v), reverse(u)).
    //
    //
    // សម្រាប់ករណីបញ្ច្រាសយើងបានគណនាកត្តាសំខាន់ x=u 'v' (វាល `crit_pos_back`) ។យើងត្រូវការ | u |<period(x) សម្រាប់ករណីបញ្ជូនបន្តហើយដូច្នេះ | v '|<period(x) សម្រាប់បញ្ច្រាស។
    //
    // ដើម្បីស្វែងរកនៅក្នុងបញ្ច្រាស់តាមរយៈគំនរចំបើងយើងបានស្វែងរកមុខតាមរយៈគំនរចំបើងដែលត្រឡប់ជាមួយម្ជុលបញ្ច្រាសផ្គូផ្គងដំបូង u 'ហើយបន្ទាប់មកជួប។
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` ប្រើ `self.end` ជាទស្សន៍ទ្រនិចរបស់វា-ដូច្នេះ `next()` និង `next_back()` គឺឯករាជ្យ។
        //
        let old_end = self.end;
        'search: loop {
            // ពិនិត្យមើលថាយើងមានបន្ទប់ដើម្បីស្វែងរកនៅចុងបញ្ចប់ needle.len() នឹងរុំព័ទ្ធនៅពេលដែលមិនមានបន្ទប់ទៀតប៉ុន្តែដោយសារតែការកាត់ប្រវែងមានកំណត់វាមិនអាចរុំព័ទ្ធជុំវិញបានទេ។
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // រំលងយ៉ាងលឿនដោយផ្នែកធំ ៗ ដែលមិនទាក់ទងនឹងផ្នែករងរបស់យើង
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // ពិនិត្យមើលថាតើផ្នែកខាងឆ្វេងនៃម្ជុលត្រូវគ្នាឬអត់
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // ពិនិត្យមើលថាតើផ្នែកខាងស្តាំនៃម្ជុលត្រូវគ្នាដែរឬទេ
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // យើងបានរកឃើញការប្រកួតមួយហើយ!
            let match_pos = self.end - needle.len();
            // Note: អនុ self.period ជំនួសឱ្យ needle.len() ត្រួតឱ្យមានការប្រកួត
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // គណនាបច្ច័យអតិបរមានៃ `arr` ។
    //
    // បច្ច័យអតិបរិមាគឺជាកត្តាសំខាន់ដែលអាចកើតមាន (u, v) នៃ `arr` ។
    //
    // ត្រឡប់ (`i`, `p`) ដែល `i` គឺជាសន្ទស្សន៍ចាប់ផ្តើមនៃ v និង `p` គឺជាកំឡុងពេលនៃ v ។
    //
    // `order_greater` កំនត់ថាតើការបញ្ជាទិញលាភគឺ `<` រឺ `>` ។
    // ការបញ្ជាទិញទាំងពីរត្រូវតែគណនា-ការបញ្ជាទិញជាមួយ `i` ធំបំផុតផ្តល់នូវកត្តាសំខាន់។
    //
    //
    // ចំពោះករណីដែលមានរយៈពេលវែងរយៈពេលនៃលទ្ធផលគឺមិនពិតប្រាកដ (វាខ្លីពេក) ។
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // ត្រូវនឹងខ្ញុំក្នុងក្រដាស
        let mut right = 1; // ត្រូវនឹង J ក្នុងក្រដាស
        let mut offset = 0; // ត្រូវនឹង k ក្នុងក្រដាសប៉ុន្តែចាប់ផ្តើមពីលេខ ០
        // ដើម្បីផ្គូផ្គងលិបិក្រមដែលមានមូលដ្ឋាន 0 ។
        let mut period = 1; // ត្រូវនឹងភីក្នុងក្រដាស

        while let Some(&a) = arr.get(right + offset) {
            // `left` នឹងមានតំលៃនៅពេល `right` គឺ។
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // បច្ច័យគឺតូចជាងហើយរយៈពេលគឺបុព្វបទទាំងមូល។
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ជាមុនតាមរយៈពាក្យដដែលៗនៃរយៈពេលបច្ចុប្បន្ន។
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // បច្ច័យធំជាងមុនចាប់ផ្តើមពីទីតាំងបច្ចុប្បន្ន។
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // គណនាបច្ច័យអតិបរិមានៃការបញ្ច្រាសនៃ `arr` ។
    //
    // បច្ច័យអតិបរិមាគឺជាកត្តាសំខាន់ដែលអាចកើតមាន (u ', v') នៃ `arr` ។
    //
    // ត្រឡប់ `i` ដែល `i` គឺជាសន្ទស្សន៍ចាប់ផ្តើមនៃ v 'ពីខាងក្រោយ;
    // ត្រឡប់មកវិញភ្លាមៗនៅពេលដែលរយៈពេល `known_period` ឈានដល់។
    //
    // `order_greater` កំនត់ថាតើការបញ្ជាទិញលាភគឺ `<` រឺ `>` ។
    // ការបញ្ជាទិញទាំងពីរត្រូវតែគណនា-ការបញ្ជាទិញជាមួយ `i` ធំបំផុតផ្តល់នូវកត្តាសំខាន់។
    //
    //
    // ចំពោះករណីដែលមានរយៈពេលវែងរយៈពេលនៃលទ្ធផលគឺមិនពិតប្រាកដ (វាខ្លីពេក) ។
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // ត្រូវនឹងខ្ញុំក្នុងក្រដាស
        let mut right = 1; // ត្រូវនឹង J ក្នុងក្រដាស
        let mut offset = 0; // ត្រូវនឹង k ក្នុងក្រដាសប៉ុន្តែចាប់ផ្តើមពីលេខ ០
        // ដើម្បីផ្គូផ្គងលិបិក្រមដែលមានមូលដ្ឋាន 0 ។
        let mut period = 1; // ត្រូវនឹងភីក្នុងក្រដាស
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // បច្ច័យគឺតូចជាងហើយរយៈពេលគឺបុព្វបទទាំងមូល។
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // ជាមុនតាមរយៈពាក្យដដែលៗនៃរយៈពេលបច្ចុប្បន្ន។
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // បច្ច័យធំជាងមុនចាប់ផ្តើមពីទីតាំងបច្ចុប្បន្ន។
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy អនុញ្ញាតឱ្យក្បួនដោះស្រាយរំលងទាំងការមិនប្រកួតជាយ៉ាងឆាប់រហ័សតាមដែលអាចធ្វើបានឬដើម្បីធ្វើការនៅក្នុងរបៀបដែលវានឹងបញ្ចេញបដិសេធទំនាក់ទំនងយ៉ាងឆាប់រហ័ស។
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// រំលងដើម្បីផ្គូផ្គងចន្លោះពេលឱ្យបានលឿនបំផុត
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// ច្រានចោលការបដិសេធជាទៀងទាត់
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}