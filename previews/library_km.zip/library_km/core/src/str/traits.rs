//! ការអនុវត្ត Trait សម្រាប់ `str` ។

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// អនុវត្តលំដាប់នៃខ្សែអក្សរ។
///
/// ខ្សែត្រូវបានបញ្ជាទិញ [lexicographically](Ord#lexicographical-comparison) តាមតម្លៃបៃរបស់ពួកគេ។
/// វាបញ្ជាទិញចំណុចកូដយូនីកូដដោយផ្អែកលើទីតាំងរបស់ពួកគេនៅក្នុងតារាងកូដ។
/// នេះមិនចាំបាច់ដូចគ្នានឹងការបញ្ជាទិញ "alphabetical" ទេដែលប្រែប្រួលតាមភាសានិងមូលដ្ឋាន។
/// ការតម្រៀបខ្សែអក្សរនេះបើយោងតាមស្តង់ដារបានទទួលយកការទាមទារឱ្យមានវប្បធ-ទិន្នន័យមូលដ្ឋានជាក់លាក់នោះគឺនៅក្រៅវិសាលភាពនៃប្រភេទ `str` នេះ។
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// អនុវត្តការប្រៀបធៀបប្រតិបត្តិការលើខ្សែ។
///
/// ខ្សែអក្សរត្រូវបានប្រៀបធៀប [lexicographically](Ord#lexicographical-comparison) ដោយតម្លៃបៃរបស់ពួកគេ។
/// នេះប្រៀបធៀបចំណុចកូដយូនីកូដផ្អែកលើទីតាំងរបស់ពួកគេនៅក្នុងតារាងកូដ។
/// នេះមិនចាំបាច់ដូចគ្នានឹងការបញ្ជាទិញ "alphabetical" ទេដែលប្រែប្រួលតាមភាសានិងមូលដ្ឋាន។
/// ការប្រៀបធៀបខ្សែរយោងទៅតាមស្តង់ដារដែលទទួលយកតាមវប្បធម៌តម្រូវឱ្យមានទិន្នន័យជាក់លាក់ក្នុងស្រុកដែលនៅខាងក្រៅវិសាលភាពនៃប្រភេទ `str` ។
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// អនុវត្តការកាត់ខ្សែរភ្ជាប់ជាមួយវាក្យសម្ព័ន្ធ `&self[..]` ឬ `&mut self[..]` ។
///
/// ត្រឡប់ចំណែកនៃខ្សែអក្សរទាំងមូលពោលគឺត្រឡប់ `&self` ឬ `&mut self` ។ស្មើនឹង `និងខ្លួនឯង [0 ..
/// len] `ឬ`&mut ខ្លួនឯង [0 ។
/// len]`.
/// មិនដូចប្រតិបត្តិការលិបិក្រមផ្សេងទៀតទេនេះមិនអាច panic បានទេ។
///
/// ប្រតិបត្ដិការនេះគឺជាការ *ឱ*(1) ។
///
/// មុនពេល 1.20.0 ប្រតិបត្តិការលិបិក្រមទាំងនេះនៅតែត្រូវបានគាំទ្រដោយការអនុវត្តផ្ទាល់នៃ `Index` និង `IndexMut` ។
///
/// ស្មើនឹង `&self[0 .. len]` ឬ `&mut self[0 .. len]` ។
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// អនុវត្តការកាត់ខ្សែរភ្ជាប់ជាមួយវាក្យសម្ព័ន្ធ `&self[begin .. end]` ឬ `&mut self[begin .. end]` ។
///
/// ត្រឡប់ចំណែកនៃខ្សែដែលបានផ្ដល់ពីជួរបៃ [`ចាប់ផ្តើម`, `end`) ។
///
/// ប្រតិបត្ដិការនេះគឺជាការ *ឱ*(1) ។
///
/// មុនពេល 1.20.0 ប្រតិបត្តិការលិបិក្រមទាំងនេះនៅតែត្រូវបានគាំទ្រដោយការអនុវត្តផ្ទាល់នៃ `Index` និង `IndexMut` ។
///
/// # Panics
///
/// Panics ប្រសិនបើ `begin` ឬ `end` មិនចង្អុលបង្ហាញពីអុហ្វសិតប៊ូតចាប់ផ្តើមនៃតួអក្សរ (ដូចដែលបានកំណត់ដោយ `is_char_boundary`) ប្រសិនបើ `begin > end` ឬប្រសិនបើ `end > len` ។
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ទាំងនេះនឹង panic៖
/// // បៃ ២ ស្ថិតក្នុង `ö`៖
/// // &s [2 ..3];
///
/// // បៃ ៨ ស្ថិតក្នុង `老`&s [១ ..
/// // 8];
///
/// // បៃ ១០០ នៅខាងក្រៅខ្សែអក្សរ&[៣ ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // សុវត្ថិភាព: ទើបតែបានគូសធីកថា `start` និង `end` ស្ថិតនៅលើព្រំប្រទល់សាក,
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            // យើងក៏បានពិនិត្យព្រំប្រទល់ char ដូច្នេះនេះជា UTF-8 ត្រឹមត្រូវ។
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // សុវត្ថិភាព: គ្រាន់តែបានពិនិត្យថា `start` និង `end` គឺនៅលើព្រំដែនតួអក្សរមួយ។
            // យើងដឹងថាទ្រនិចគឺប្លែកពីព្រោះយើងទទួលបានពី `slice` ។
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលធានាថា `self` ស្ថិតនៅក្នុងព្រំដែន `slice`
        // ដែលបំពេញលក្ខខណ្ឌទាំងអស់សម្រាប់ `add` ។
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // សុវត្ថិភាព: មើលឃើញមតិយោបល់សម្រាប់ `get_unchecked` ។
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary ត្រួតពិនិត្យថាលិបិក្រមគឺស្ថិតនៅក្នុង [0, .len()] មិនអាចប្រើ `get` ដូចខាងលើបានទេព្រោះមានបញ្ហាអិលអិល។
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // សុវត្ថិភាព: ទើបតែបានគូសធីកថា `start` និង `end` ស្ថិតនៅលើព្រំប្រទល់សាក,
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// អនុវត្តការកាត់ខ្សែរភ្ជាប់ជាមួយវាក្យសម្ព័ន្ធ `&self[.. end]` ឬ `&mut self[.. end]` ។
///
/// ត្រឡប់ចំណែកនៃខ្សែដែលបានផ្ដល់ពីជួរបៃ [`0`, X០០X) ។
/// ស្មើនឹង `&self[0 .. end]` ឬ `&mut self[0 .. end]` ។
///
/// ប្រតិបត្ដិការនេះគឺជាការ *ឱ*(1) ។
///
/// មុនពេល 1.20.0 ប្រតិបត្តិការលិបិក្រមទាំងនេះនៅតែត្រូវបានគាំទ្រដោយការអនុវត្តផ្ទាល់នៃ `Index` និង `IndexMut` ។
///
/// # Panics
///
/// Panics ប្រសិនបើ `end` មិនចង្អុលទៅអុហ្វសិតបៃបានចាប់ផ្តើមមួយនៃតួអក្សរ (ដូចដែលបានកំណត់ដោយ `is_char_boundary`) ឬប្រសិនបើ `end > len` ។
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // សុវត្ថិភាព: គ្រាន់តែបានពិនិត្យថា `end` char គឺនៅលើព្រំដែនមួយ
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // សុវត្ថិភាព: គ្រាន់តែបានពិនិត្យថា `end` char គឺនៅលើព្រំដែនមួយ
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // សុវត្ថិភាព: គ្រាន់តែបានពិនិត្យថា `end` char គឺនៅលើព្រំដែនមួយ
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// អនុវត្តការកាត់ខ្សែរភ្ជាប់ជាមួយវាក្យសម្ព័ន្ធ `&self[begin ..]` ឬ `&mut self[begin ..]` ។
///
/// ត្រឡប់ចំណែកនៃខ្សែដែលបានផ្ដល់ពីជួរបៃ [`ចាប់ផ្តើម`, `len`) ។ស្មើនឹង `ខ្លួនឯង [ចាប់ផ្តើម ..
/// Len] `ឬ`&មុតដោយខ្លួនឯង [ចាប់ផ្តើម ..
/// len]`.
///
/// ប្រតិបត្ដិការនេះគឺជាការ *ឱ*(1) ។
///
/// មុនពេល 1.20.0 ប្រតិបត្តិការលិបិក្រមទាំងនេះនៅតែត្រូវបានគាំទ្រដោយការអនុវត្តផ្ទាល់នៃ `Index` និង `IndexMut` ។
///
/// # Panics
///
/// Panics ប្រសិនបើ `begin` មិនចង្អុលទៅអុហ្វសិតបៃនៃតួអក្សរ (ដូចដែលបានកំណត់ដោយ `is_char_boundary`) ឬប្រសិនបើ `begin > len` ។
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // សុវត្ថិភាព: គ្រាន់តែបានពិនិត្យថា `start` char គឺនៅលើព្រំដែនមួយ
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // សុវត្ថិភាព: គ្រាន់តែបានពិនិត្យថា `start` char គឺនៅលើព្រំដែនមួយ
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលធានាថា `self` ស្ថិតនៅក្នុងព្រំដែន `slice`
        // ដែលបំពេញលក្ខខណ្ឌទាំងអស់សម្រាប់ `add` ។
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // សុវត្ថិភាព: ដូចគ្នាបេះបិទទៅនឹង `get_unchecked` ។
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // សុវត្ថិភាព: គ្រាន់តែបានពិនិត្យថា `start` char គឺនៅលើព្រំដែនមួយ
            // ហើយយើងត្រូវឆ្លងកាត់នៅក្នុងសេចក្ដីយោងមានសុវត្ថិភាពមួយ, ដូច្នេះតម្លៃត្រឡប់នេះផងដែរនឹងមានមួយ។
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// អនុវត្តជាមួយ slice ខ្សែអក្សររងឬ `&mut self[begin ..= end]` វាក្យសម្ព័ន្ធដែល `&self[begin ..= end]` ។
///
/// ត្រឡប់ខ្សែអក្សរដែលបានផ្ដល់ចំណែកនៃជួរពីនេះ [`begin`, `end`] មួយបៃ។ស្មើនឹង `&self [begin .. end + 1]` ឬ `&mut self[begin .. end + 1]` លើកលែងតែ `end` មានតម្លៃអតិបរមាសំរាប់ `usize` ។
///
/// ប្រតិបត្ដិការនេះគឺជាការ *ឱ*(1) ។
///
/// # Panics
///
/// Panics ប្រសិនបើ `begin` មិនចង្អុលទៅបៃបានចាប់ផ្តើមអុហ្វសិតនៃតួអក្សរមួយ (ដូចដែលបានកំណត់ដោយ `is_char_boundary`), ប្រសិនបើ `end` មិនមានចំណុចដើម្បីបៃបញ្ចប់អុហ្វសិតនៃតួអក្សរមួយ (`end + 1` គឺទាំងបៃបានចាប់ផ្តើមអុហ្វសិតឬស្មើ `len`), ប្រសិនបើ `begin > end` ឬប្រសិនបើ `end >= len` ។
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked` ។
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked_mut` ។
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// អនុវត្តការកាត់ខ្សែរភ្ជាប់ជាមួយវាក្យសម្ព័ន្ធ `&self[..= end]` ឬ `&mut self[..= end]` ។
///
/// ត្រឡប់ខ្សែអក្សរដែលបានផ្ដល់ចំណែកនៃជួរពីនេះ [0, `end`] មួយបៃ។
/// ស្មើនឹង `&self [0 .. end + 1]` លើកលែងតែ `end` មានតម្លៃអតិបរមាសម្រាប់ `usize` ។
///
/// ប្រតិបត្ដិការនេះគឺជាការ *ឱ*(1) ។
///
/// # Panics
///
/// Panics ប្រសិនបើ `end` មិនចង្អុលបង្ហាញអុហ្វសិតបញ្ចប់នៃតួអក្សរ (`end + 1` គឺជាអុហ្វសិតប៊ូតចាប់ផ្តើមដូចដែលបានកំណត់ដោយ `is_char_boundary` ឬស្មើនឹង `len`) ឬប្រសិនបើ `end >= len` ។
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked` ។
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked_mut` ។
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// ញែកតម្លៃពីខ្សែអក្សរ
///
/// វិធី [`from_str`] `របស់ស្ទ្រីហ្វគឺត្រូវបានប្រើជាញឹកញាប់តាមវិធីសាស្រ្ត [`parse`] របស់` `។
/// មើលឯកសារ [`ញែក` សម្រាប់ឧទាហរណ៍។
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` មិនមានប៉ារ៉ាម៉ែត្រពេញមួយជីវិតហើយដូច្នេះអ្នកអាចញែកបានតែប្រភេទដែលមិនមានប៉ារ៉ាម៉ែត្រពេញមួយជីវិតប៉ុណ្ណោះ។
///
/// និយាយម៉្យាងទៀតអ្នកអាចញែក `i32` ជាមួយ `FromStr` ប៉ុន្តែមិនមែន `&i32` ទេ។
/// អ្នកអាចញែករចនាសម្ព័ន្ធដែលមាន `i32` ប៉ុន្តែមិនមានមួយដែលផ្ទុក `&i32` ទេ។
///
/// # Examples
///
/// ការអនុវត្តមូលដ្ឋាននៃ `FromStr` លើឧទាហរណ៍ប្រភេទ `Point`៖
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// កំហុសដែលទាក់ទងអាចត្រឡប់មកពីការញែក។
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// លាក់ខ្សែអក្សរ `s` ដើម្បីត្រឡប់តម្លៃនៃប្រភេទនេះ។
    ///
    /// ប្រសិនបើបានញែកជោគជ័យត្រឡប់តម្លៃនៅក្នុង [`Ok`] បើមិនដូច្នេះទេនៅពេលដែលខ្សែអក្សរបានធ្វើទ្រង់ទ្រាយត្រឡប់មកវិញឈឺជាក់លាក់មួយដើម្បីនៅក្នុងកំហុសនេះ [`Err`] ។
    /// ប្រភេទកំហុសគឺជាក់លាក់ចំពោះការអនុវត្ត trait ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋានជាមួយ [`i32`], ប្រភេទមួយដែលអនុវត្ត `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// ញែក `bool` ពីខ្សែអក្សរ។
    ///
    /// ផ្តល់លទ្ធផល `Result<bool, ParseBoolError>` ព្រោះ `s` អាចរឺមិនអាចនិយាយបាន។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// ចំណាំក្នុងករណីជាច្រើនវិធីសាស្ត្រ `.parse()` នៅលើ `str` គឺត្រឹមត្រូវជាង។
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}