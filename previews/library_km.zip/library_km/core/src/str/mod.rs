//! ឧបាយកលខ្សែអក្សរ។
//!
//! សម្រាប់ព័ត៌មានលម្អិតសូមមើលម៉ូឌុល [`std::str`] ។
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. នៅក្រៅព្រំដែន
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. ចាប់ផ្តើម <=ចប់
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. ព្រំដែនតួអក្សរ
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // រកឃើញតួអក្សរ
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` ត្រូវតែតិចជាងលីននិងព្រំប្រទល់ដែន
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// ត្រឡប់ប្រវែង `self` ។
    ///
    /// ប្រវែងនេះគិតជាបៃមិនមែនជាផ្នូរទេ។
    /// និយាយម៉្យាងទៀតវាប្រហែលជាមិនមែនជាអ្វីដែលមនុស្សម្នាក់គិតពីប្រវែងនៃខ្សែនោះទេ។
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // ពុម្ពអក្សរក្បូរក្បាច់ f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `self` មានប្រវែងសូន្យបៃ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ពិនិត្យថា `បៃសន្ទស្សន៍ទី ៨ បៃជាបៃដំបូងក្នុងលំដាប់លេខកូដ UTF-8 ឬចុងខ្សែអក្សរ។
    ///
    ///
    /// ការចាប់ផ្តើមនិងចុងបញ្ចប់នៃខ្សែអក្សរ (នៅពេល `សន្ទស្សន៍== self.len()`) ត្រូវបានគេចាត់ទុកថាជាព្រំដែន។
    ///
    /// ត្រឡប់ `false` ប្រសិនបើ `index` ធំជាង `self.len()` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // ការចាប់ផ្តើមនៃការ `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // បៃទីពីរនៃ `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // បៃទីបីនៃ `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // ០ និងឡេនតែងតែយល់ព្រម។
        // សាកល្បងសម្រាប់លេខ ០ យ៉ាងជាក់លាក់ដើម្បីឱ្យវាអាចបង្កើនប្រសិទ្ធភាពឆែកបានយ៉ាងងាយហើយរំលងការអានទិន្នន័យខ្សែសម្រាប់ករណីនោះ។
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // នេះជាវេទមន្តបន្តិចស្មើនឹង៖ ខ <១២៨ ||b>=១៩២
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// បម្លែងខ្សែអក្សរមួយទៅជាចំណែកតូចៗ។
    /// ដើម្បីបំលែងចំណែកបៃត្រឡប់ទៅជាចំណែកខ្សែអក្សរសូមប្រើមុខងារ [`from_utf8`] ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // សុវត្ថិភាព: const សំឡេងពីព្រោះយើងចម្លងពីរប្រភេទជាមួយប្លង់តែមួយ
        unsafe { mem::transmute(self) }
    }

    /// បំលែងចំណែកខ្សែអក្សរដែលអាចបំលែងបានទៅជាចំណែកបៃដែលអាចផ្លាស់ប្តូរបាន។
    ///
    /// # Safety
    ///
    /// អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាខ្លឹមសារនៃចំណិតមានសុពលភាព UTF-8 មុនពេលប្រាក់កម្ចីចប់ហើយ `str` មូលដ្ឋានត្រូវបានប្រើ។
    ///
    ///
    /// ការប្រើប្រាស់ `str` ដែលមាតិកាមិនមានសុពលភាព UTF-8 គឺជាឥរិយាបទដែលមិនបានកំណត់។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // សុវត្ថិភាព: ការសម្ដែងពី `&str` ដល់ `&[u8]` គឺមានសុវត្ថិភាពចាប់តាំងពី `str`
        // មានប្លង់ដូចគ្នានឹង `&[u8]` (មានតែ libstd ប៉ុណ្ណោះដែលអាចធានាបាន) ។
        // ការដកទ្រនិចចង្អុលមានសុវត្ថិភាពពីព្រោះវាបានមកពីឯកសារយោងដែលអាចផ្លាស់ប្តូរបានដែលធានាថាមានសុពលភាពសម្រាប់ការសរសេរ។
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// បំលែងចំណែកខ្សែអក្សរទៅជាទ្រនិចឆៅ។
    ///
    /// ក្នុងនាមជាចំណិតខ្សែអក្សរគឺជាចំណែកបៃ, ចង្អុលទ្រនិចចង្អុលទៅ [`u8`] ។
    /// ទ្រនិចនេះនឹងចង្អុលទៅបៃដំបូងនៃចំណិតខ្សែអក្សរ។
    ///
    /// អ្នកទូរស័ព្ទចូលត្រូវតែធានាថាព្រួញកណ្តុរដែលវិលត្រឡប់មកវិញមិនដែលត្រូវបានគេសរសេរទៅ។
    /// ប្រសិនបើអ្នកត្រូវការផ្លាស់ប្តូរមាតិកានៃចំណែកនៃខ្សែអក្សរសូមប្រើ [`as_mut_ptr`] ។
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// បំលែងចំណែកខ្សែអក្សរដែលអាចបំលែងបានទៅជាទ្រនិចឆៅ។
    ///
    /// ក្នុងនាមជាចំណិតខ្សែអក្សរគឺជាចំណែកបៃ, ចង្អុលទ្រនិចចង្អុលទៅ [`u8`] ។
    /// ទ្រនិចនេះនឹងចង្អុលទៅបៃដំបូងនៃចំណិតខ្សែអក្សរ។
    ///
    /// វាគឺជាការទទួលខុសត្រូវរបស់អ្នកដើម្បីធ្វើឱ្យប្រាកដថាការកាត់ខ្សែអក្សរត្រូវបានកែប្រែតាមរបៀបដែលវានៅតែមានសុពលភាព UTF-8 ។
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// ត្រឡប់អនុផ្នែក `str` X ។
    ///
    /// នេះជាជំរើសដែលមិនគួរអោយភ័យស្លន់ស្លោចំពោះការធ្វើលិបិក្រម `str` ។
    /// ត្រឡប់ [`None`] នៅពេលដែលប្រតិបត្តិការធ្វើលិបិក្រមសមមូលនឹង panic ។
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // សន្ទស្សន៍មិនមែននៅលើព្រំដែនលំដាប់ UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // នៅក្រៅព្រំដែន
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// ត្រឡប់អនុផ្នែកដែលអាចប្តូរបាននៃ `str` ។
    ///
    /// នេះជាជំរើសដែលមិនគួរអោយភ័យស្លន់ស្លោចំពោះការធ្វើលិបិក្រម `str` ។
    /// ត្រឡប់ [`None`] នៅពេលដែលប្រតិបត្តិការធ្វើលិបិក្រមសមមូលនឹង panic ។
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // ប្រវែងត្រឹមត្រូវ
    /// assert!(v.get_mut(0..5).is_some());
    /// // នៅក្រៅព្រំដែន
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// ត្រឡប់ទំហំរងដែលមិនបានត្រួតពិនិត្យនៃ `str` ។
    ///
    /// នេះគឺជាជំរើសដែលមិនត្រូវបានធីកដើម្បីធ្វើលិបិក្រម `str` ។
    ///
    /// # Safety
    ///
    /// អ្នកហៅទូរស័ព្ទនៃមុខងារនេះទទួលខុសត្រូវថាល័ក្ខខ័ណ្ឌទាំងនេះត្រូវបានពេញចិត្ត:
    ///
    /// * សន្ទស្សន៍ចាប់ផ្តើមមិនត្រូវលើសពីសន្ទស្សន៍បញ្ចប់ឡើយ។
    /// * សន្ទស្សន៍ត្រូវតែស្ថិតនៅក្នុងព្រំដែននៃចំណែកដើម។
    /// * សន្ទស្សន៍ត្រូវតែស្ថិតនៅលើព្រំដែនលំដាប់ UTF-8 ។
    ///
    /// ការបរាជ័យនោះចំណែកខ្សែអក្សរត្រឡប់មកវិញប្រហែលជាមានការចងចាំមិនត្រឹមត្រូវឬបំពានមិនប្រែប្រួលទាក់ទងដោយប្រភេទ `str` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked`;
        // ចំណែកគឺមិនអាចដោះស្រាយបានទេពីព្រោះ `self` គឺជាឯកសារយោងដែលមានសុវត្ថិភាព។
        // ទ្រនិចដែលបានត្រឡប់មកវិញមានសុវត្ថិភាពពីព្រោះការភ្ជាប់ `SliceIndex` ត្រូវតែធានាថាវាជា។
        unsafe { &*i.get_unchecked(self) }
    }

    /// ត្រឡប់ផ្នែករងដែលមិនអាចឆែកបានរបស់ `str` ។
    ///
    /// នេះគឺជាជំរើសដែលមិនត្រូវបានធីកដើម្បីធ្វើលិបិក្រម `str` ។
    ///
    /// # Safety
    ///
    /// អ្នកហៅទូរស័ព្ទនៃមុខងារនេះទទួលខុសត្រូវថាល័ក្ខខ័ណ្ឌទាំងនេះត្រូវបានពេញចិត្ត:
    ///
    /// * សន្ទស្សន៍ចាប់ផ្តើមមិនត្រូវលើសពីសន្ទស្សន៍បញ្ចប់ឡើយ។
    /// * សន្ទស្សន៍ត្រូវតែស្ថិតនៅក្នុងព្រំដែននៃចំណែកដើម។
    /// * សន្ទស្សន៍ត្រូវតែស្ថិតនៅលើព្រំដែនលំដាប់ UTF-8 ។
    ///
    /// ការបរាជ័យនោះចំណែកខ្សែអក្សរត្រឡប់មកវិញប្រហែលជាមានការចងចាំមិនត្រឹមត្រូវឬបំពានមិនប្រែប្រួលទាក់ទងដោយប្រភេទ `str` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked_mut`;
        // ចំណែកគឺមិនអាចដោះស្រាយបានទេពីព្រោះ `self` គឺជាឯកសារយោងដែលមានសុវត្ថិភាព។
        // ទ្រនិចដែលបានត្រឡប់មកវិញមានសុវត្ថិភាពពីព្រោះការភ្ជាប់ `SliceIndex` ត្រូវតែធានាថាវាជា។
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// បង្កើតកំណាត់ខ្សែពីចំណែកខ្សែមួយទៀតដោយឆ្លងកាត់ការត្រួតពិនិត្យសុវត្ថិភាព។
    ///
    /// នេះជាទូទៅមិនត្រូវបានណែនាំទេសូមប្រើដោយប្រុងប្រយ័ត្ន!សម្រាប់ជម្រើសសុវត្ថិភាពសូមមើល [`str`] និង [`Index`] ។
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// ចំណែកថ្មីនេះទៅពី `begin` ទៅ `end` រួមបញ្ចូលទាំង `begin` ប៉ុន្តែមិនរាប់បញ្ចូល `end` ។
    ///
    /// ដើម្បីទទួលបានខ្សែអក្សរដែលអាចផ្លាស់ប្តូរបានជំនួសសូមមើលវិធីសាស្ត្រ [`slice_mut_unchecked`] ។
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// អ្នកទូរស័ព្ទចូលនៃមុខងារនេះទទួលខុសត្រូវថាលក្ខខ័ណ្ឌចំនួន ៣ ត្រូវបានគេពេញចិត្ត៖
    ///
    /// * `begin` មិនត្រូវលើសពី `end` ។
    /// * `begin` និង `end` ត្រូវតែជាជំហរបៃនៅក្នុងជួរខ្សែអក្សរ។
    /// * `begin` និង `end` ត្រូវតែស្ថិតនៅលើព្រំដែនលំដាប់ UTF-8 ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked`;
        // ចំណែកគឺមិនអាចដោះស្រាយបានទេពីព្រោះ `self` គឺជាឯកសារយោងដែលមានសុវត្ថិភាព។
        // ទ្រនិចដែលបានត្រឡប់មកវិញមានសុវត្ថិភាពពីព្រោះការភ្ជាប់ `SliceIndex` ត្រូវតែធានាថាវាជា។
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// បង្កើតកំណាត់ខ្សែពីចំណែកខ្សែមួយទៀតដោយឆ្លងកាត់ការត្រួតពិនិត្យសុវត្ថិភាព។
    /// នេះជាទូទៅមិនបានផ្តល់អនុសាសន៍ត្រូវបានប្រើប្រាស់ដោយប្រុងប្រយ័ត្ន!សម្រាប់ជម្រើសសុវត្ថិភាពសូមមើល [`str`] និង [`IndexMut`] ។
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// ចំណែកថ្មីនេះទៅពី `begin` ទៅ `end` រួមបញ្ចូលទាំង `begin` ប៉ុន្តែមិនរាប់បញ្ចូល `end` ។
    ///
    /// ដើម្បីទទួលបានខ្សែអក្សរដែលមិនអាចផ្លាស់ប្តូរបានជំនួសសូមមើលវិធីសាស្ត្រ [`slice_unchecked`] ។
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// អ្នកទូរស័ព្ទចូលនៃមុខងារនេះទទួលខុសត្រូវថាលក្ខខ័ណ្ឌចំនួន ៣ ត្រូវបានគេពេញចិត្ត៖
    ///
    /// * `begin` មិនត្រូវលើសពី `end` ។
    /// * `begin` និង `end` ត្រូវតែជាជំហរបៃនៅក្នុងជួរខ្សែអក្សរ។
    /// * `begin` និង `end` ត្រូវតែស្ថិតនៅលើព្រំដែនលំដាប់ UTF-8 ។
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `get_unchecked_mut`;
        // ចំណែកគឺមិនអាចដោះស្រាយបានទេពីព្រោះ `self` គឺជាឯកសារយោងដែលមានសុវត្ថិភាព។
        // ទ្រនិចដែលបានត្រឡប់មកវិញមានសុវត្ថិភាពពីព្រោះការភ្ជាប់ `SliceIndex` ត្រូវតែធានាថាវាជា។
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// ចែកខ្សែអក្សរមួយទៅជាពីរនៅលិបិក្រមមួយ។
    ///
    /// អាគុយម៉ង់ `mid` គួរតែជាអុហ្វសិតបៃពីការចាប់ផ្តើមនៃខ្សែ។
    /// វាក៏ត្រូវតែស្ថិតនៅលើព្រំដែននៃចំនុចកូដ UTF-8 ផងដែរ។
    ///
    /// ចំណិតទាំងពីរត្រលប់មកវិញពីការចាប់ផ្តើមកាត់ខ្សែអក្សរទៅជា `mid` និងពី `mid` ដល់ចុងបញ្ចប់នៃការកាត់ខ្សែអក្សរ។
    ///
    /// ដើម្បីទទួលបានចំណិតខ្សែអក្សរដែលអាចប្តូរបានជំនួសសូមមើលវិធីសាស្ត្រ [`split_at_mut`] ។
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `mid` មិនស្ថិតនៅលើព្រំដែនចំនុចកូដ UTF-8 ឬប្រសិនបើវាហួសចុងបញ្ចប់នៃចំនុចកូដចុងក្រោយនៃការកាត់ខ្សែអក្សរ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary ត្រួតពិនិត្យថាសន្ទស្សន៍ស្ថិតនៅក្នុង [0, .len()]
        if self.is_char_boundary(mid) {
            // សុវត្ថិភាព: ទើបតែពិនិត្យមើលថា `mid` ស្ថិតនៅលើព្រំប្រទល់សាក។
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ចែកខ្សែអក្សរដែលអាចផ្លាស់ប្តូរបានមួយទៅជាពីរនៅសន្ទស្សន៍មួយ។
    ///
    /// អាគុយម៉ង់ `mid` គួរតែជាអុហ្វសិតបៃពីការចាប់ផ្តើមនៃខ្សែ។
    /// វាក៏ត្រូវតែស្ថិតនៅលើព្រំដែននៃចំនុចកូដ UTF-8 ផងដែរ។
    ///
    /// ចំណិតទាំងពីរត្រលប់មកវិញពីការចាប់ផ្តើមកាត់ខ្សែអក្សរទៅជា `mid` និងពី `mid` ដល់ចុងបញ្ចប់នៃការកាត់ខ្សែអក្សរ។
    ///
    /// ដើម្បីទទួលបានចំណិតខ្សែអក្សរដែលមិនអាចផ្លាស់ប្តូរបានសូមមើលវិធីសាស្ត្រ [`split_at`] ។
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `mid` មិនស្ថិតនៅលើព្រំដែនចំនុចកូដ UTF-8 ឬប្រសិនបើវាហួសចុងបញ្ចប់នៃចំនុចកូដចុងក្រោយនៃការកាត់ខ្សែអក្សរ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary ត្រួតពិនិត្យថាសន្ទស្សន៍ស្ថិតនៅក្នុង [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // សុវត្ថិភាព: ទើបតែពិនិត្យមើលថា `mid` ស្ថិតនៅលើព្រំប្រទល់សាក។
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// ត្រឡប់អ្នកត្រួតត្រាលើ [`char`] នៃចំណិតខ្សែអក្សរ។
    ///
    /// ជាការកាត់ខ្សែអក្សរមាន UTF-8 ត្រឹមត្រូវយើងអាចកាត់តាមខ្សែអក្សរលេខ [`char`] ។
    /// វិធីសាស្រ្តនេះត្រឡប់បែបនេះបម្រុងមួយ។
    ///
    /// វាជាការសំខាន់ដែលត្រូវចងចាំថា [`char`] តំណាងឱ្យគុណតម្លៃ Scalar យូនីកូដហើយប្រហែលជាមិនត្រូវនឹងគំនិតរបស់អ្នកថា 'character' គឺជាអ្វី។
    ///
    /// ភាពច្របូកច្របល់លើចង្កោមក្រួសអាចជាអ្វីដែលអ្នកចង់បាន។
    /// មុខងារនេះមិនត្រូវបានផ្តល់ជូនដោយបណ្ណាល័យស្តង់ដាររបស់ Rust ទេសូមពិនិត្យមើល crates.io ជំនួសវិញ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// សូមចាំថា [`char`] ប្រហែលជាមិនត្រូវគ្នានឹងវិចារណញាណរបស់អ្នកអំពីតួអក្សរ៖
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // មិនមែន 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// ត្រឡប់អ្នកត្រួតត្រាលើ [`char`] នៃចំណែកខ្សែអក្សរនិងទីតាំងរបស់ពួកគេ។
    ///
    /// ជាការកាត់ខ្សែអក្សរមាន UTF-8 ត្រឹមត្រូវយើងអាចកាត់តាមខ្សែអក្សរលេខ [`char`] ។
    /// វិធីសាស្រ្តនេះត្រលប់មកវិញនូវអ្នកធ្វើចរន្តនៃទាំងពីរនេះក៏ដូចជាមុខតំណែងបៃរបស់ពួកគេ។
    ///
    /// ទ្រនាប់ទ្រនាប់ផ្តល់ទិន្នផល។ទីតាំងគឺទីមួយ [`char`] ស្ថិតនៅលំដាប់ទីពីរ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// សូមចាំថា [`char`] ប្រហែលជាមិនត្រូវគ្នានឹងវិចារណញាណរបស់អ្នកអំពីតួអក្សរ៖
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // មិន (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // កត់សំគាល់លេខ ៣ នៅទីនេះតួអក្សរចុងក្រោយយកពីរបៃ
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// ការរំកិលលើបៃនៃចំណែកតូចនៃខ្សែអក្សរ។
    ///
    /// ជា slice ខ្សែអក្សរមួយមានលំដាប់នៃបៃយើងអាចដូចគ្នាតាមរយៈចំណែកខ្សែអក្សរមួយដោយបៃ។
    /// វិធីសាស្រ្តនេះត្រឡប់បែបនេះបម្រុងមួយ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// ពុះជាចំណែក ៗ ជាខ្សែ ៗ ដោយដកឃ្លា។
    ///
    /// ការនិយាយឡើងវិញបានវិលត្រឡប់មកខ្សែអក្សរនឹងវិលមកចំណិតចំណិតដែលមានអនុ slice នៃខ្សែអក្សរដើមដែលបំបែកដោយចំនួនទឹកប្រាក់នៃការចន្លោះទាំងអស់។
    ///
    ///
    /// 'Whitespace' ត្រូវបានកំណត់ដោយយោងតាមល័ក្ខខ័ណ្ឌនៃយូនីកូដស៊ីធីអេចអេចអេចអរអេសធីអេសអេចធី `White_Space` X ។
    /// ប្រសិនបើអ្នកចង់បំបែកនៅលើចន្លោះ ASCII ជំនួសវិញសូមប្រើ [`split_ascii_whitespace`] ។
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// គ្រប់ចន្លោះទាំងអស់ត្រូវបានពិចារណា៖
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// បំបែកចំណែកខ្សែអក្សរដោយដកឃ្លា ASCII ។
    ///
    /// ការនិយាយឡើងវិញបានវិលត្រឡប់មកខ្សែអក្សរនឹងវិលមកចំណិតចំណិតដែលមានអនុ slice នៃខ្សែអក្សរដើមដែលបំបែកដោយចន្លោះ ASCII នេះបរិមាណនៃការណាមួយ។
    ///
    ///
    /// ដើម្បីបំបែកដោយយូនីកូដ `Whitespace` ជំនួសវិញសូមប្រើ [`split_whitespace`] ។
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// គ្រប់ប្រភេទនៃ ASCII whitespace ត្រូវបានពិចារណា៖
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// ឧបករណ៍រំកិលលើខ្សែនៃខ្សែដូចជាខ្សែអក្សរ។
    ///
    /// ខ្សែត្រូវបានបញ្ចប់ដោយខ្សែថ្មី (`\n`) ឬការបញ្ជូនរទេះត្រឡប់មកវិញជាមួយខ្សែចំណី (`\r\n`) ។
    ///
    /// ការបញ្ចប់ខ្សែចុងក្រោយគឺស្រេចចិត្ត។
    /// ខ្សែអក្សរដែលបញ្ចប់ដោយការបញ្ចប់ខ្សែចុងក្រោយនឹងត្រឡប់ជាខ្សែដូចគ្នានឹងខ្សែអក្សរដូចគ្នាបេះបិទដោយគ្មានការបញ្ចប់ខ្សែចុងក្រោយ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// ការបញ្ចប់ខ្សែចុងក្រោយមិនចាំបាច់ទេ៖
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// ឧបករណ៍រំកិលលើខ្សែនៃខ្សែ។
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// ត្រឡប់ឧបករណ៍ដដែលនៃ `u16` លើខ្សែអក្សរដែលបានអ៊ិនកូដជា UTF-16 ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// ត្រឡប់ `true` ប្រសិនបើលំនាំដែលបានផ្តល់ផ្គូផ្គងនឹងចំណែកតូចនៃចំណែកខ្សែអក្សរនេះ។
    ///
    /// ត្រឡប់ `false` ប្រសិនបើវាមិន។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// ត្រឡប់ `true` ប្រសិនបើលំនាំដែលបានផ្តល់ត្រូវគ្នានឹងបុព្វបទនៃចំណិតខ្សែអក្សរនេះ។
    ///
    /// ត្រឡប់ `false` ប្រសិនបើវាមិន។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// ត្រឡប់ `true` ប្រសិនបើលំនាំដែលបានផ្តល់ផ្គូផ្គងបច្ច័យនៃការកាត់ខ្សែអក្សរនេះ។
    ///
    /// ត្រឡប់ `false` ប្រសិនបើវាមិន។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// ត្រឡប់សន្ទស្សន៍បៃនៃតួអក្សរទីមួយនៃចំណិតខ្សែអក្សរនេះដែលត្រូវនឹងលំនាំ។
    ///
    /// ត្រឡប់ [`None`] ប្រសិនបើលំនាំមិនត្រូវគ្នា។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// លំនាំស្មុគស្មាញបន្ថែមទៀតដោយប្រើរចនាប័ទ្មគ្មានចំណុចនិងការបិទ៖
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// រកលំនាំមិនឃើញ៖
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// ត្រឡប់សន្ទស្សន៍បៃសម្រាប់តួអក្សរទីមួយនៃការផ្គូផ្គងស្តាំបំផុតនៃលំនាំក្នុងចំណែកខ្សែអក្សរនេះ។
    ///
    /// ត្រឡប់ [`None`] ប្រសិនបើលំនាំមិនត្រូវគ្នា។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// លំនាំស្មុគស្មាញបន្ថែមទៀតជាមួយនឹងបិទ:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// រកលំនាំមិនឃើញ៖
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// ឧបករណ៍រំកិលលើខ្សែអក្សរតូចៗនៃខ្សែអក្សរនេះបំបែកដោយតួអក្សរដែលត្រូវគ្នានឹងលំនាំ។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// ឧបករណ៍ធ្វើចរន្តវិលត្រឡប់នឹងក្លាយជា [`DoubleEndedIterator`] ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសហើយការស្វែងរក forward/reverse ផ្តល់នូវធាតុដូចគ្នា។
    /// នេះជាការពិតសម្រាប់ឧទាហរណ៍ [`char`] ប៉ុន្តែមិនមែនសម្រាប់ `&str` ទេ។
    ///
    /// ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសប៉ុន្តែលទ្ធផលរបស់វាអាចខុសគ្នាពីការស្វែងរកទៅមុខវិធីសាស្ត្រ [`rsplit`] អាចត្រូវបានប្រើ។
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// បើលំនាំជាគំនូសតាងជាចំណែក ៗ បំបែកលើការកើតឡើងនៃតួអក្សរនីមួយៗ៖
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// លំនាំស្មុគស្មាញជាងនេះដោយប្រើការបិទ៖
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// ប្រសិនបើខ្សែមួយមានឧបករណ៍បំបែកជាប់គ្នាច្រើនអ្នកនឹងបញ្ចប់ដោយខ្សែរទទេនៅក្នុងលទ្ធផល៖
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// សញ្ញាបំបែកជាប់គ្នាត្រូវបានបំបែកដោយខ្សែរទទេ។
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// ការបំបែកនៅដើមឬចុងបញ្ចប់នៃខ្សែអក្សរត្រូវបានអ្នកជិតខាងដោយខ្សែរទទេ។
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// នៅពេលខ្សែអក្សរទទេគឺត្រូវបានប្រើជាអ្នកបំបែកវាបានបំបែកតួអក្សរទាំងអស់នៅក្នុងខ្សែអក្សររួមជាមួយការចាប់ផ្តើមនិងចុងបញ្ចប់នៃខ្សែអក្សរ។
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// សញ្ញាបំបែកដែលជាប់គ្នាអាចនាំឱ្យមានឥរិយាបថគួរឱ្យភ្ញាក់ផ្អើលនៅពេលដែលដកឃ្លាត្រូវបានប្រើជាអ្នកបំបែក។លេខកូដនេះត្រឹមត្រូវ៖
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// វាពិតជាផ្តល់អោយអ្នកនូវៈ
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// ប្រើ [`split_whitespace`] សម្រាប់ឥរិយាបថនេះ។
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// ឧបករណ៍រំកិលលើខ្សែអក្សរតូចៗនៃខ្សែអក្សរនេះបំបែកដោយតួអក្សរដែលត្រូវគ្នានឹងលំនាំ។
    /// ភាពខុសគ្នាពីឧបករណ៍វាស់ស្ទង់ផលិតដោយ `split` នៅក្នុងនោះ `split_inclusive` ទុកផ្នែកដែលត្រូវគ្នាជាអ្នកបញ្ចប់នៃផ្នែករង។
    ///
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// ប្រសិនបើធាតុចុងក្រោយនៃខ្សែអក្សរត្រូវបានផ្គូរផ្គងធាតុនោះនឹងត្រូវបានចាត់ទុកថាជាស្ថានីយនៃខ្សែរងខាងមុខ។
    /// ឧបករណ៍ជំនួសនោះនឹងជាធាតុចុងក្រោយដែលបានវិលត្រឡប់ដោយអ្នកតាក់ស៊ី។
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// ឧបករណ៍រំកិលលើខ្សែអក្សរតូចៗនៃខ្សែអក្សរដែលបានបែងចែកដែលបំបែកដោយតួអក្សរដែលផ្គូផ្គងនឹងលំនាំហើយផ្តល់លទ្ធផលតាមលំដាប់បញ្ច្រាស។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// បានត្រឡប់បម្រុងតម្រូវឱ្យថាលំនាំគាំទ្រការស្វែងរកបញ្ច្រាសហើយវានឹងក្លាយជា [`DoubleEndedIterator`] មួយប្រសិនបើមានការស្វែងរក forward/reverse ផ្តល់ធាតុដូចគ្នា។
    ///
    ///
    /// សម្រាប់ការធ្វើចលនាពីខាងមុខវិធី [`split`] អាចត្រូវបានប្រើ។
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// លំនាំស្មុគស្មាញជាងនេះដោយប្រើការបិទ៖
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// ឧបករណ៍រំកិលលើខ្សែអក្សរតូចៗនៃខ្សែអក្សរដែលបានបែងចែកដែលបំបែកដោយតួអក្សរត្រូវគ្នានឹងលំនាំ។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// ស្មើនឹង [`split`] លើកលែងតែខ្សែអក្សរខាងក្រោមត្រូវបានរំលងប្រសិនបើនៅទទេ។
    ///
    /// [`split`]: str::split
    ///
    /// វិធីសាស្រ្តនេះអាចត្រូវបានប្រើសម្រាប់ទិន្នន័យខ្សែដែលជា _terminated_ ជាជាង _separated_ ដោយលំនាំ។
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// ឧបករណ៍ធ្វើចរន្តវិលត្រឡប់នឹងក្លាយជា [`DoubleEndedIterator`] ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសហើយការស្វែងរក forward/reverse ផ្តល់នូវធាតុដូចគ្នា។
    /// នេះជាការពិតសម្រាប់ឧទាហរណ៍ [`char`] ប៉ុន្តែមិនមែនសម្រាប់ `&str` ទេ។
    ///
    /// ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសប៉ុន្តែលទ្ធផលរបស់វាអាចខុសគ្នាពីការស្វែងរកទៅមុខវិធីសាស្ត្រ [`rsplit_terminator`] អាចត្រូវបានប្រើ។
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// ឧបករណ៍រំកិលលើផ្នែករងនៃ `self` ដែលបំបែកដោយតួអក្សរដែលត្រូវគ្នានឹងលំនាំនិងផ្តល់លទ្ធផលតាមលំដាប់បញ្ច្រាស។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// ស្មើនឹង [`split`] លើកលែងតែខ្សែអក្សរខាងក្រោមត្រូវបានរំលងប្រសិនបើនៅទទេ។
    ///
    /// [`split`]: str::split
    ///
    /// វិធីសាស្រ្តនេះអាចត្រូវបានប្រើសម្រាប់ទិន្នន័យខ្សែដែលជា _terminated_ ជាជាង _separated_ ដោយលំនាំ។
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// អ្នកវិលត្រឡប់ដែលបានត្រឡប់មកវិញតម្រូវឱ្យលំនាំគាំទ្រដល់ការស្វែងរកបញ្ច្រាសហើយវានឹងត្រូវបញ្ចប់ទ្វេដងប្រសិនបើការស្វែងរក forward/reverse ផ្តល់នូវធាតុដូចគ្នា។
    ///
    ///
    /// សម្រាប់ការធ្វើចលនាពីខាងមុខវិធី [`split_terminator`] អាចត្រូវបានប្រើ។
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// iterator ទៅលើខ្សែអក្សររងនៃចម្រៀកខ្សែអក្សរដែលបានផ្ដល់ឱ្យ, ដែលបំបែកដោយលំនាំមួយ, បានដាក់កម្រិតទៅការវិលត្រឡប់មកធាតុ `n` ច្រើនបំផុតនៅ។
    ///
    /// ប្រសិនបើខ្សែអក្សររង `n` ត្រូវបានត្រឡប់មកវិញនោះខ្សែចុងក្រោយ (ខ្សែ `n`th) នឹងមានខ្សែអក្សរដែលនៅសល់។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// ឧបករណ៍បង្វិលត្រឡប់មកវិញនឹងមិនត្រូវបានបញ្ចប់ទ្វេដងទេព្រោះវាមិនមានប្រសិទ្ធភាពក្នុងការគាំទ្រ។
    ///
    /// ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសវិធីសាស្ត្រ [`rsplitn`] អាចត្រូវបានប្រើ។
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// លំនាំស្មុគស្មាញជាងនេះដោយប្រើការបិទ៖
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// ឧបករណ៍រំកិលលើផ្នែករងនៃចំណិតខ្សែអក្សរនេះបំបែកដោយលំនាំចាប់ផ្តើមពីចុងបញ្ចប់នៃខ្សែអក្សរដែលបានដាក់កម្រិតចំពោះការវិលត្រឡប់វិញនូវវត្ថុ `n` ភាគច្រើន។
    ///
    ///
    /// ប្រសិនបើខ្សែអក្សររង `n` ត្រូវបានត្រឡប់មកវិញនោះខ្សែចុងក្រោយ (ខ្សែ `n`th) នឹងមានខ្សែអក្សរដែលនៅសល់។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// ឧបករណ៍បង្វិលត្រឡប់មកវិញនឹងមិនត្រូវបានបញ្ចប់ទ្វេដងទេព្រោះវាមិនមានប្រសិទ្ធភាពក្នុងការគាំទ្រ។
    ///
    /// សម្រាប់ការពុះចេញពីផ្នែកខាងមុខវិធីសាស្ត្រ [`splitn`] អាចត្រូវបានប្រើ។
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// លំនាំស្មុគស្មាញជាងនេះដោយប្រើការបិទ៖
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// បំបែកខ្សែអក្សរលើការកើតឡើងដំបូងនៃសញ្ញាកំណត់ព្រំដែនដែលបានបញ្ជាក់ហើយត្រឡប់បុព្វបទមុនពេលកំណត់ព្រំដែននិងបច្ច័យបន្ទាប់ពីអ្នកកំណត់ព្រំដែន។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// បំបែកខ្សែអក្សរនៅលើសញ្ញាកំណត់ព្រំដែនកើតឡើងចុងក្រោយនៃការត្រឡប់មកវិញបានបញ្ជាក់និងការកំណត់ព្រំដែននិងមុនពេលដាក់បុព្វបទបច្ច័យបន្ទាប់ពីសញ្ញាកំណត់ព្រំដែន។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// អ្នកនិយាយអំពីការផ្គូផ្គង dismoint នៃលំនាំមួយនៅក្នុងចំណែកនៃខ្សែអក្សរដែលបានផ្តល់។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// ឧបករណ៍ធ្វើចរន្តវិលត្រឡប់នឹងក្លាយជា [`DoubleEndedIterator`] ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសហើយការស្វែងរក forward/reverse ផ្តល់នូវធាតុដូចគ្នា។
    /// នេះជាការពិតសម្រាប់ឧទាហរណ៍ [`char`] ប៉ុន្តែមិនមែនសម្រាប់ `&str` ទេ។
    ///
    /// បើអ្នកមានគំរូនេះអនុញ្ញាតឱ្យការស្វែងរកបញ្ច្រាសប៉ុន្តែលទ្ធផលរបស់វាអាចនឹងខុសគ្នាពីការស្វែងរកមុខជាវិធីសាស្រ្ត [`rmatches`] អាចត្រូវបានប្រើ។
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// បម្រុងជាងមួយផ្គូផ្គង disjointed លំនាំមួយនៅក្នុងចំណែកខ្សែអក្សរនេះរួចផុតនៅក្នុងលំដាប់បញ្ច្រាស។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// បានត្រឡប់បម្រុងតម្រូវឱ្យថាលំនាំគាំទ្រការស្វែងរកបញ្ច្រាសហើយវានឹងក្លាយជា [`DoubleEndedIterator`] មួយប្រសិនបើមានការស្វែងរក forward/reverse ផ្តល់ធាតុដូចគ្នា។
    ///
    ///
    /// សម្រាប់ការធ្វើចលនាពីខាងមុខវិធីសាស្រ្ត [`matches`] អាចត្រូវបានប្រើ។
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// iterator ទៅលើការប្រកួតលំនាំនៅក្នុង disjointed ខ្សែអក្សរចម្រៀកនេះព្រមទាំងលិបិក្រមដែលការប្រកួតចាប់ផ្តើមនៅ។
    ///
    /// សម្រាប់ការប្រកួតនៃ `pat` ក្នុង `self` ដែលត្រួតគ្នាមានតែសូចនាករដែលត្រូវគ្នានឹងការប្រកួតដំបូងប៉ុណ្ណោះដែលត្រូវបានប្រគល់ជូន។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// ឧបករណ៍ធ្វើចរន្តវិលត្រឡប់នឹងក្លាយជា [`DoubleEndedIterator`] ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសហើយការស្វែងរក forward/reverse ផ្តល់នូវធាតុដូចគ្នា។
    /// នេះជាការពិតសម្រាប់ឧទាហរណ៍ [`char`] ប៉ុន្តែមិនមែនសម្រាប់ `&str` ទេ។
    ///
    /// ប្រសិនបើលំនាំអនុញ្ញាតឱ្យមានការស្វែងរកបញ្ច្រាសប៉ុន្តែលទ្ធផលរបស់វាអាចខុសគ្នាពីការស្វែងរកទៅមុខវិធីសាស្ត្រ [`rmatch_indices`] អាចត្រូវបានប្រើ។
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // មានតែ `aba` ដំបូងប៉ុណ្ណោះ
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// អ្នកនិយាយអំពីការផ្គូរផ្គងនៃលំនាំក្នុង `self` ផ្តល់លទ្ធផលតាមលំដាប់បញ្ច្រាសរួមជាមួយសន្ទស្សន៍នៃការប្រកួត។
    ///
    /// សម្រាប់ការប្រកួតនៃ `pat` ក្នុង `self` ដែលត្រួតគ្នាមានតែសូចនាករដែលត្រូវគ្នានឹងការប្រកួតចុងក្រោយត្រូវបានប្រគល់ជូនវិញ។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # អាកប្បកិរិយារបស់អ្នកបកប្រែ
    ///
    /// បានត្រឡប់បម្រុងតម្រូវឱ្យថាលំនាំគាំទ្រការស្វែងរកបញ្ច្រាសហើយវានឹងក្លាយជា [`DoubleEndedIterator`] មួយប្រសិនបើមានការស្វែងរក forward/reverse ផ្តល់ធាតុដូចគ្នា។
    ///
    ///
    /// សម្រាប់ការធ្វើចលនាពីខាងមុខវិធី [`match_indices`] អាចត្រូវបានប្រើ។
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // មានតែ `aba` ចុងក្រោយប៉ុណ្ណោះ
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរមួយដែលដកឃ្លានាំមុខនិងក្រោយ។
    ///
    /// 'Whitespace' ត្រូវបានកំណត់ដោយយោងតាមល័ក្ខខ័ណ្ឌនៃយូនីកូដស៊ីធីអេចអេចអេចអរអេសធីអេសអេចធី `White_Space` X ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរមួយដែលមានដកឃ្លានាំមុខ។
    ///
    /// 'Whitespace' ត្រូវបានកំណត់ដោយយោងតាមល័ក្ខខ័ណ្ឌនៃយូនីកូដស៊ីធីអេចអេចអេចអរអេសធីអេសអេចធី `White_Space` X ។
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// `start` នៅក្នុងបរិបទនេះមានន័យថាទីតាំងដំបូងនៃខ្សែបៃនោះ។សម្រាប់ភាសាពីឆ្វេងទៅស្តាំដូចជាអង់គ្លេសឬរុស្ស៊ីនេះនឹងជាផ្នែកខាងឆ្វេងហើយសម្រាប់ភាសាពីឆ្វេងទៅស្តាំដូចជាភាសាអារ៉ាប់ឬហេប្រ៊ូនេះគឺជាផ្នែកខាងស្តាំ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរដែលដកឃ្លាចេញ។
    ///
    /// 'Whitespace' ត្រូវបានកំណត់ដោយយោងតាមល័ក្ខខ័ណ្ឌនៃយូនីកូដស៊ីធីអេចអេចអេចអរអេសធីអេសអេចធី `White_Space` X ។
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// `end` នៅក្នុងបរិបទនេះមានន័យថាទីតាំងចុងក្រោយនៃខ្សែបៃនោះ។សម្រាប់ភាសាឆ្វេងទៅស្តាំដូចជាភាសាអង់គ្លេសឬរុស្ស៊ីនេះនឹងមានផ្នែកខាងស្ដាំនិងសម្រាប់ភាសាពីស្ដាំទៅឆ្វេងឬដូចភាសាអារ៉ាប់ភាសាហេប្រឺថានេះនឹងក្លាយជាផ្នែកខាងឆ្វេង។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរមួយដែលមានដកឃ្លានាំមុខ។
    ///
    /// 'Whitespace' ត្រូវបានកំណត់ដោយយោងតាមល័ក្ខខ័ណ្ឌនៃយូនីកូដស៊ីធីអេចអេចអេចអរអេសធីអេសអេចធី `White_Space` X ។
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// 'Left' នៅក្នុងបរិបទនេះមានន័យថាទីតាំងដំបូងនៃខ្សែបៃនោះ។សម្រាប់ភាសាដូចជាអារ៉ាប់ឬហេប្រ៊ូដែល "ពីឆ្វេងទៅស្តាំ" ជាជាង "ពីឆ្វេងទៅស្តាំ" នេះនឹងជាផ្នែក _right_ មិនមែនខាងឆ្វេងទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរដែលដកឃ្លាចេញ។
    ///
    /// 'Whitespace' ត្រូវបានកំណត់ដោយយោងតាមល័ក្ខខ័ណ្ឌនៃយូនីកូដស៊ីធីអេចអេចអេចអរអេសធីអេសអេចធី `White_Space` X ។
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// 'Right' នៅក្នុងបរិបទនេះមានន័យថាទីតាំងចុងក្រោយនៃខ្សែបៃនោះ។សម្រាប់ភាសាដូចជាភាសាហេប្រឺដែលអារ៉ាប់ឬមាន "ស្តាំទៅឆ្វេង" ជាជាង "ឆ្វេងទៅស្តាំ" នេះនឹងក្លាយជាផ្នែកខាង _left_, មិនត្រឹមត្រូវនោះទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរដែលមានបុព្វបទនិងបច្ច័យទាំងអស់ដែលត្រូវគ្នានឹងលំនាំដែលបានដកចេញម្តងហើយម្តងទៀត។
    ///
    /// [pattern] អាចជា [`char`] មួយចំណែកនៃ [`char`] s ឬមុខងារឬការបិទដែលកំណត់ថាតើតួអក្សរត្រូវគ្នា។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// លំនាំស្មុគស្មាញជាងនេះដោយប្រើការបិទ៖
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // ចងចាំការប្រកួតដែលត្រូវបានគេស្គាល់ដំបូងកែវានៅខាងក្រោមប្រសិនបើ
            // ការប្រកួតចុងក្រោយគឺខុសគ្នា
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // សុវត្ថិភាព: `Searcher` ត្រូវបានគេដឹងថាត្រូវបង្ហាញសន្ទស្សន៍ត្រឹមត្រូវ។
        unsafe { self.get_unchecked(i..j) }
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរជាមួយបុព្វបទទាំងអស់ដែលត្រូវគ្នានឹងលំនាំដែលបានដកចេញម្តងហើយម្តងទៀត។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// `start` នៅក្នុងបរិបទនេះមានន័យថាទីតាំងដំបូងនៃខ្សែបៃនោះ។សម្រាប់ភាសាពីឆ្វេងទៅស្តាំដូចជាអង់គ្លេសឬរុស្ស៊ីនេះនឹងជាផ្នែកខាងឆ្វេងហើយសម្រាប់ភាសាពីឆ្វេងទៅស្តាំដូចជាភាសាអារ៉ាប់ឬហេប្រ៊ូនេះគឺជាផ្នែកខាងស្តាំ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // សុវត្ថិភាព: `Searcher` ត្រូវបានគេដឹងថាត្រូវបង្ហាញសន្ទស្សន៍ត្រឹមត្រូវ។
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរជាមួយបុព្វបទដែលបានដកចេញ។
    ///
    /// ប្រសិនបើខ្សែអក្សរចាប់ផ្តើមជាមួយលំនាំ `prefix` ត្រឡប់មកវិញត្រឡប់រងបន្ទាប់ពីបុព្វបទរុំក្នុង `Some` ។
    /// មិនដូច `trim_start_matches` ទេវិធីសាស្ត្រនេះដកបុព្វបទចេញម្តង។
    ///
    /// ប្រសិនបើខ្សែអក្សរមិនចាប់ផ្ដើមដោយ `prefix` ត្រឡប់ `None` ។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរជាមួយបច្ច័យត្រូវបានដកចេញ។
    ///
    /// ប្រសិនបើខ្សែអក្សរបញ្ចប់ដោយលំនាំ `suffix` ត្រឡប់ខ្សែរងមុនបច្ច័យរុំក្នុង `Some` ។
    /// មិនដូច `trim_end_matches` ទេវិធីសាស្ត្រនេះដកបច្ច័យចេញម្តង។
    ///
    /// ប្រសិនបើខ្សែអក្សរមិនបានបញ្ចប់ជាមួយនឹងការ `suffix` ត្រឡប់ `None` ។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរជាមួយបច្ច័យទាំងអស់ដែលត្រូវគ្នានឹងលំនាំដែលបានដកចេញម្តងហើយម្តងទៀត។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// `end` នៅក្នុងបរិបទនេះមានន័យថាទីតាំងចុងក្រោយនៃខ្សែបៃនោះ។សម្រាប់ភាសាឆ្វេងទៅស្តាំដូចជាភាសាអង់គ្លេសឬរុស្ស៊ីនេះនឹងមានផ្នែកខាងស្ដាំនិងសម្រាប់ភាសាពីស្ដាំទៅឆ្វេងឬដូចភាសាអារ៉ាប់ភាសាហេប្រឺថានេះនឹងក្លាយជាផ្នែកខាងឆ្វេង។
    ///
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// លំនាំស្មុគស្មាញជាងនេះដោយប្រើការបិទ៖
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // សុវត្ថិភាព: `Searcher` ត្រូវបានគេដឹងថាត្រូវបង្ហាញសន្ទស្សន៍ត្រឹមត្រូវ។
        unsafe { self.get_unchecked(0..j) }
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរជាមួយបុព្វបទទាំងអស់ដែលត្រូវគ្នានឹងលំនាំដែលបានដកចេញម្តងហើយម្តងទៀត។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// 'Left' នៅក្នុងបរិបទនេះមានន័យថាទីតាំងដំបូងនៃខ្សែបៃនោះ។សម្រាប់ភាសាដូចជាអារ៉ាប់ឬហេប្រ៊ូដែល "ពីឆ្វេងទៅស្តាំ" ជាជាង "ពីឆ្វេងទៅស្តាំ" នេះនឹងជាផ្នែក _right_ មិនមែនខាងឆ្វេងទេ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// ត្រឡប់ចំណែកខ្សែអក្សរជាមួយបច្ច័យទាំងអស់ដែលត្រូវគ្នានឹងលំនាំដែលបានដកចេញម្តងហើយម្តងទៀត។
    ///
    /// [pattern] អាចជា `&str`, [`char`], ចំណែកមួយនៃ [`char`] s ឬមុខងារឬបិទដែលកំណត់ប្រសិនបើការប្រកួតតួអក្សរមួយ។
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # ទិសដៅអត្ថបទ
    ///
    /// ខ្សែអក្សរគឺជាលំដាប់បៃ។
    /// 'Right' នៅក្នុងបរិបទនេះមានន័យថាទីតាំងចុងក្រោយនៃខ្សែបៃនោះ។សម្រាប់ភាសាដូចជាភាសាហេប្រឺដែលអារ៉ាប់ឬមាន "ស្តាំទៅឆ្វេង" ជាជាង "ឆ្វេងទៅស្តាំ" នេះនឹងក្លាយជាផ្នែកខាង _left_, មិនត្រឹមត្រូវនោះទេ។
    ///
    ///
    /// # Examples
    ///
    /// លំនាំសាមញ្ញ៖
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// លំនាំស្មុគស្មាញជាងនេះដោយប្រើការបិទ៖
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// ញាត់ខ្សែអក្សរនេះទៅជាប្រភេទមួយផ្សេងទៀត។
    ///
    /// ដោយសារតែ `parse` មានលក្ខណៈទូទៅដូច្នេះវាអាចបណ្តាលឱ្យមានបញ្ហាទាក់ទងនឹងប្រភេទ។
    /// ដូច្នេះ `parse` គឺជាផ្នែកមួយនៃពីរបីដងដែលអ្នកនឹងឃើញវាក្យសម្ព័ន្ធដែលត្រូវបានគេស្គាល់ថាជា 'turbofish'៖ `::<>`.
    ///
    /// វាជួយអោយក្បួនដោះស្រាយការយល់ដឹងជាពិសេសប្រភេទណាដែលអ្នកព្យាយាមញែក។
    ///
    /// `parse` អាចញែកចូលទៅក្នុងប្រភេទដែលបានអនុវត្ត [`FromStr`] trait ណាមួយ។
    ///

    /// # Errors
    ///
    /// នឹងត្រឡប់ [`Err`] ប្រសិនបើមិនអាចបែងចែកចំណែកខ្សែនេះជាប្រភេទដែលចង់បាន។
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// ការប្រើប្រាស់ 'turbofish' ជំនួសឱ្យការកត់សំគាល់ `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// បរាជ័យក្នុងការញែក៖
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// ពិនិត្យមើលថាតើតួអក្សរទាំងអស់នៅក្នុងខ្សែអក្សរនេះស្ថិតនៅក្នុងជួរ ASCII ។
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // យើងអាចព្យាបាលបៃគ្នាជាតួអក្សរនៅទីនេះ: តួអក្សរច្រើនបៃទាំងអស់ចាប់ផ្តើមជាមួយបៃនោះគឺមិនមែននៅក្នុងជួរ ascii ដូច្នេះយើងនឹងបញ្ឈប់នៅទីនោះរួចទៅហើយ។
        //
        //
        self.as_bytes().is_ascii()
    }

    /// ពិនិត្យមើលថាមានខ្សែអក្សរពីរគឺជាករណីអាក្រក់ប្រកួត ASCII ។
    ///
    /// ដូចគ្នានឹង `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ដែរប៉ុន្តែដោយគ្មានការបែងចែកនិងថតចម្លងតារាងពេលវេលា។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// បំលែងខ្សែអក្សរនេះទៅជាអក្សរធំ ASCII ដែលស្មើនឹងកន្លែង។
    ///
    /// អក្សរ ASCII 'a' ទៅ 'z' ត្រូវបានគូសផែនទីទៅ 'A' ទៅ 'Z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីត្រឡប់តម្លៃអក្សរធំថ្មីដោយមិនចាំបាច់កែប្រែតម្លៃដែលមានស្រាប់សូមប្រើ [`to_ascii_uppercase()`] ។
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // សុវត្ថិភាព: សុវត្ថិភាពពីព្រោះយើងចម្លងពីរប្រភេទជាមួយប្លង់តែមួយ។
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// បំលែងខ្សែអក្សរនេះទៅជាអក្សរតូច ASCII ដែលស្មើនឹងកន្លែង។
    ///
    /// អក្សរ ASCII 'A' ទៅ 'Z' ត្រូវបានគូសផែនទីទៅ 'a' ទៅ 'z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីត្រឡប់តម្លៃទាបថ្មីដោយមិនចាំបាច់កែប្រែរបស់ដែលមានស្រាប់សូមប្រើ [`to_ascii_lowercase()`] ។
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // សុវត្ថិភាព: សុវត្ថិភាពពីព្រោះយើងចម្លងពីរប្រភេទជាមួយប្លង់តែមួយ។
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// ត្រឡប់ឧបករណ៍រំកិលមួយដែលគេចផុតពីឆនំនីមួយៗក្នុង `self` ជាមួយ [`char::escape_debug`] ។
    ///
    ///
    /// Note: មានតែកន្លែងតំរែតំរែតំរង់ដែលចាប់ផ្តើមខ្សែអក្សរនឹងត្រូវបានរួចខ្លួន។
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// ត្រឡប់ឧបករណ៍រំកិលមួយដែលគេចផុតពីឆនំនីមួយៗក្នុង `self` ជាមួយ [`char::escape_default`] ។
    ///
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// ត្រឡប់ឧបករណ៍រំកិលមួយដែលគេចផុតពីឆនំនីមួយៗក្នុង `self` ជាមួយ [`char::escape_unicode`] ។
    ///
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// បង្កើតខ្សែអក្សរទទេ
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// បង្កើតខ្សែអក្សរដែលអាចបំលែងបាន
    #[inline]
    fn default() -> Self {
        // សុវត្ថិភាព: ខ្សែរទទេគឺត្រឹមត្រូវ UTF-8 ។
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// ប្រភេទ fn ដែលអាចក្លូនបាន
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // សុវត្ថិភាព: មិនមានសុវត្ថិភាព
        unsafe { from_utf8_unchecked(bytes) }
    };
}