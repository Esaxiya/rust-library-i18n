#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// ផ្តល់ប្រភេទទិន្នន័យមេតាទ្រនិចនៃប្រភេទចង្អុលទៅប្រភេទណាមួយ។
///
/// # ទិន្នន័យមេតាចង្អុល
///
/// ប្រភេទទ្រនិចឆៅនិងប្រភេទឯកសារយោងក្នុង Rust អាចគិតថាត្រូវបានផលិតជាពីរផ្នែក៖
/// ទ្រនិចទិន្នន័យដែលមានអាស័យដ្ឋានសតិនៃតម្លៃនិងទិន្នន័យមេតាមួយចំនួន។
///
/// សម្រាប់ប្រភេទដែលមានទំហំតាមបែបស្ថិតិ (ដែលអនុវត្ត `Sized` traits) ក៏ដូចជាសម្រាប់ប្រភេទ `extern`, ចង្អុលត្រូវបានគេនិយាយថា`ស្តើង`៖ ទិន្នន័យមេតាមានទំហំសូន្យហើយប្រភេទរបស់វាគឺ `()` ។
///
///
/// អ្នកចង្អុលទៅ [dynamically-sized types][dst] ត្រូវបានគេនិយាយថា`ធំ` ឬ`ធាត់` ពួកគេមានទិន្នន័យមេតាដែលមិនមានទំហំសូន្យ៖
///
/// * សម្រាប់រចនាសម្ព័ន្ធដែលមានវាលចុងក្រោយគឺ DST ទិន្នន័យមេតាតាគឺជាទិន្នន័យមេតាសម្រាប់វាលចុងក្រោយ
/// * សម្រាប់ប្រភេទ `str`, ទិន្នន័យមេតាគឺជាប្រវែងគិតជាបៃជា `usize`
/// * សម្រាប់ប្រភេទចំណិតដូចជា `[T]`, ទិន្នន័យមេតាគឺជាប្រវែងនៅក្នុងធាតុដែលជា `usize`
/// * សម្រាប់វត្ថុ trait ដូចជា `dyn SomeTrait`, ទិន្នន័យមេតាគឺ [`DynMetadata<Self>`][DynMetadata] (ឧទាហរណ៍ `DynMetadata<dyn SomeTrait>`)
///
/// នៅក្នុងភាសា future ភាសា Rust អាចទទួលបានប្រភេទថ្មីដែលមានទិន្នន័យមេតាខុសៗគ្នា។
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # រថយន្តម៉ាក `Pointee` trait
///
/// ចំនុចរបស់ trait គឺប្រភេទ `Metadata` ដែលមានជាប់ទាក់ទងគឺ `()` រឺ `usize` រឺ `DynMetadata<_>` ដូចបានរៀបរាប់ខាងលើ។
/// វាត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិសម្រាប់គ្រប់ប្រភេទ។
/// វាអាចត្រូវបានសន្មតថាត្រូវបានអនុវត្តក្នុងបរិបទទូទៅសូម្បីតែគ្មានព្រំដែនដែលត្រូវគ្នា។
///
/// # Usage
///
/// ព្រួញឆៅអាចត្រូវបាន decomposed ចូលទៅក្នុងអាស័យដ្ឋានទិន្នន័យនិងទិន្នន័យមេតានឹងវិធីសាស្រ្តសមាសភាគពួកគេ [`to_raw_parts`] ។
///
/// ម៉្យាងទៀតមេតាតាតាតែមួយអាចត្រូវបានដកស្រង់ជាមួយមុខងារ [`metadata`] ។
/// ឯកសារយោងមួយអាចត្រូវបានបញ្ជូនទៅ [`metadata`] ហើយត្រូវបានបង្ខំយ៉ាងជាក់លាក់។
///
/// ទ្រនិច (possibly-wide) អាចត្រូវបានដាក់បញ្ចូលឡើងវិញពីអាសយដ្ឋាននិងទិន្នន័យមេតារបស់វាជាមួយ [`from_raw_parts`] ឬ [`from_raw_parts_mut`] ។
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// ប្រភេទសម្រាប់ទិន្នន័យមេតាក្នុងចង្អុលបង្ហាញនិងយោងទៅ `Self` ។
    #[lang = "metadata_type"]
    // NOTE: រក្សាទុក trait bounds ក្នុង `static_assert_expected_bounds_for_metadata`
    //
    // ក្នុង `library/core/src/ptr/metadata.rs` ធ្វើសមកាលកម្មជាមួយអ្នកនៅទីនេះ៖
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// អ្នកចង្អុលបង្ហាញប្រភេទដែលអនុវត្តឈ្មោះហៅក្រៅ trait គឺ`ស្គម` ។
///
/// នេះរួមបញ្ចូលទាំងប្រភេទស្ថិតិ-`Sized` និងប្រភេទ `extern` ។
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: កុំធ្វើឱ្យវាមានស្ថេរភាពមុនពេលឈ្មោះហៅក្រៅ trait មានស្ថេរភាពនៅក្នុងភាសា?
pub trait Thin = Pointee<Metadata = ()>;

/// ដកស្រង់សមាសធាតុទិន្នន័យមេតានៃទ្រនិច។
///
/// តម្លៃនៃប្រភេទ `*mut T`, `&T`, ឬ `&mut T` អាចត្រូវបានបញ្ជូនដោយផ្ទាល់ទៅមុខងារនេះខណៈដែលពួកគេបង្ខំយ៉ាងខ្លាំងចំពោះ `* const T` ។
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // សុវត្ថិភាព: ការទទួលបានតម្លៃពីសហជីព `PtrRepr` គឺមានសុវត្ថិភាពចាប់តាំងពី * const T
    // និង Ptr អ្នកចូលរួម<T>មានប្លង់ចងចាំដូចគ្នា។
    // មានតែ std ប៉ុណ្ណោះដែលអាចធានាបាន។
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// បង្កើតទំរង់ទ្រនិចឆៅ (possibly-wide) ពីអាសយដ្ឋានទិន្នន័យនិងទិន្នន័យមេតា។
///
/// មុខងារនេះមានសុវត្ថិភាពប៉ុន្តែទ្រនិចដែលបានត្រឡប់មកវិញគឺមិនមានសុវត្ថិភាពក្នុងការបដិសេធនោះទេ។
/// សម្រាប់ចំណិតសូមមើលឯកសារនៃ [`slice::from_raw_parts`] សម្រាប់តម្រូវការសុវត្ថិភាព។
/// ចំពោះវត្ថុ trait ទិន្នន័យមេតាតាតាត្រូវតែចេញពីទ្រនិចមួយទៅប្រភេទដែលមានមូលដ្ឋានដូចគ្នា។
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // សុវត្ថិភាព: ការទទួលបានតម្លៃពីសហជីព `PtrRepr` គឺមានសុវត្ថិភាពចាប់តាំងពី * const T
    // និង Ptr អ្នកចូលរួម<T>មានប្លង់ចងចាំដូចគ្នា។
    // មានតែ std ប៉ុណ្ណោះដែលអាចធានាបាន។
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// អនុវត្តមុខងារដូចគ្នានឹង [`from_raw_parts`] លើកលែងតែទ្រនិច `*mut` ឆៅត្រូវបានត្រឡប់ផ្ទុយពីទ្រនិច `* const` ឆៅ។
///
///
/// សូមមើលឯកសាររបស់ [`from_raw_parts`] សម្រាប់ព័ត៌មានលម្អិត។
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // សុវត្ថិភាព: ការទទួលបានតម្លៃពីសហជីព `PtrRepr` គឺមានសុវត្ថិភាពចាប់តាំងពី * const T
    // និង Ptr អ្នកចូលរួម<T>មានប្លង់ចងចាំដូចគ្នា។
    // មានតែ std ប៉ុណ្ណោះដែលអាចធានាបាន។
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// សៀវភៅដៃត្រូវការជាចាំបាច់ដើម្បីចៀសវាង `T: Copy` X ភ្ជាប់។
impl<T: ?Sized> Copy for PtrComponents<T> {}

// សៀវភៅដៃត្រូវការជាចាំបាច់ដើម្បីចៀសវាង `T: Clone` X ភ្ជាប់។
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// ទិន្នន័យមេតាសម្រាប់ប្រភេទវត្ថុ `Dyn = dyn SomeTrait` trait ។
///
/// វាគឺជាព្រួញចង្អុលទៅតុ (តុហៅនិម្មិត) ដែលតំណាងឱ្យព័ត៌មានចាំបាច់ទាំងអស់ដើម្បីរៀបចំប្រភេទបេតុងដែលបានរក្សាទុកនៅខាងក្នុងវត្ថុ trait ។
/// ភាពគួរឱ្យកត់សម្គាល់ដែលវាមាន៖
///
/// * ទំហំប្រភេទ
/// * តម្រឹមប្រភេទ
/// * ទ្រនិចចង្អុលទៅប្រភេទ `drop_in_place` ប្រភេទ (អាចជាទិន្នន័យគ្មានទិន្នន័យចាស់)
/// * ចង្អុលបង្ហាញវិធីសាស្រ្តទាំងអស់សម្រាប់ការអនុវត្តប្រភេទនៃ trait
///
/// ចំណាំថាបីដំបូងគឺពិសេសព្រោះវាចាំបាច់ក្នុងការបែងចែកទម្លាក់និងចែកចាយវត្ថុណា trait ណាមួយ។
///
/// អាចដាក់ឈ្មោះរចនាសម្ព័ន្ធនេះជាមួយប៉ារ៉ាម៉ែត្រប្រភេទដែលមិនមែនជាវត្ថុ `dyn` trait (ឧទាហរណ៍ `DynMetadata<u64>`) ប៉ុន្តែមិនទទួលបានតម្លៃដែលមានអត្ថន័យនៃរចនាសម្ព័ន្ធនោះទេ។
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// បុព្វបទទូទៅនៃ vtables ទាំងអស់។វាត្រូវបានបន្តដោយឧបករណ៍ចង្អុលមុខងារសម្រាប់វិធីសាស្រ្ត trait ។
///
/// ព័ត៌មានលម្អិតនៃការអនុវត្តឯកជនរបស់ `DynMetadata::size_of` ។ ល។
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ត្រឡប់ទំហំនៃប្រភេទដែលទាក់ទងនឹងតុដេកនេះ។
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ត្រឡប់ការតម្រឹមនៃប្រភេទដែលទាក់ទងនឹងតុរប្យួរនេះ។
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// ត្រឡប់ទំហំនិងតម្រឹមជាមួយគ្នាជា `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // សុវត្ថិភាព: អ្នកចងក្រងបានបំលែងតុរប្យួរនេះសម្រាប់ប្រភេទ Rust
        // ត្រូវបានគេដឹងថាមានប្លង់ត្រឹមត្រូវ។និទានដូចគ្នាដូចនៅក្នុង `Layout::for_value` ។
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// សៀវភៅដៃត្រូវការជាចាំបាច់ដើម្បីចៀសវាងព្រំដែន `Dyn: $Trait` ។

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}