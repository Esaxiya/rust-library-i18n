use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// រុំព័ទ្ធជុំវិញ `*mut T` មិនឆៅដែលបង្ហាញថាភោគីនៃភួយនេះជាម្ចាស់កម្មសិទ្ធិ។
/// មានប្រយោជន៍សម្រាប់ការបង្កើតអរូបីដូចជា `Box<T>`, `Vec<T>`, `String` និង `HashMap<K, V>` ។
///
/// មិនដូច `*mut T` ទេ `Unique<T>` មានឥរិយាបទ "as if" វាជាឧទាហរណ៍នៃ `T` ។
/// វាអនុវត្ត `Send`/`Sync` ប្រសិនបើ `T` គឺ `Send`/`Sync` ។
/// វាក៏បញ្ជាក់អំពីប្រភេទនៃការធានាឈ្មោះក្លែងក្លាយដ៏រឹងមាំដែលឧទាហរណ៍នៃ `T` អាចរំពឹងថាៈ
/// ឯកសារយោងនៃទ្រនិចមិនគួរត្រូវបានកែប្រែទេបើគ្មានផ្លូវតែមួយគត់ចំពោះភាពជាម្ចាស់របស់វា។
///
/// ប្រសិនបើអ្នកមិនច្បាស់លាស់ថាតើវាជាការត្រឹមត្រូវក្នុងការប្រើ `Unique` សម្រាប់គោលបំណងរបស់, ពិចារណាប្រើ `NonNull` ដែលមានសញ្ញាន័យវិទ្យាខ្សោយ។
///
///
/// មិនដូច `*mut T` ទេទ្រនិចត្រូវតែមិនមែនជាមោឃៈទោះបីជាទ្រនិចមិនដែលត្រូវបានគេបដិសេធក៏ដោយ។
/// នេះគឺដើម្បីឱ្យអ៊ីនធឺរណែតអាចប្រើតម្លៃដែលហាមឃាត់នេះជាការរើសអើង-`Option<Unique<T>>` មានទំហំប៉ុន `Unique<T>` ។
/// ទោះយ៉ាងណាទ្រនិចអាចនៅតែគាំងប្រសិនបើវាមិនត្រូវបានបញ្ជាក់។
///
/// មិនដូច `*mut T` ទេ `Unique<T>` គឺ covariant ជាង `T` ។
/// នេះគួរតែត្រឹមត្រូវសម្រាប់ប្រភេទណាដែលគោរពតាមតម្រូវការហៅក្រៅរបស់តែមួយគត់។
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: សញ្ញាសម្គាល់នេះមិនមានផលវិបាកចំពោះភាពខុសគ្នាទេប៉ុន្តែចាំបាច់
    // សម្រាប់ការធ្លាក់ចុះដើម្បីយល់ថាយើងជាម្ចាស់នៃ `T` ឡូជីខល។
    //
    // សម្រាប់ព័ត៌មានលម្អិតសូមមើល៖
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ចង្អុលគឺ `Send` ប្រសិនបើ `T` ជា `Send` ពីព្រោះទិន្នន័យដែលពួកគេយោងមិនមានភាពលំអៀង។
/// សូមកត់សម្គាល់ថាភាពខុសគ្នានៃភាពមិនពិតនេះគឺមិនត្រូវបានអនុវត្តដោយប្រព័ន្ធប្រភេទឡើយ។អរូបីដោយប្រើ `Unique` ត្រូវតែអនុវត្តវា។
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ចង្អុលគឺ `Sync` ប្រសិនបើ `T` ជា `Sync` ព្រោះទិន្នន័យដែលពួកគេយោងមិនមានភាពលំអៀង។
/// សូមកត់សម្គាល់ថាភាពខុសគ្នានៃភាពមិនពិតនេះគឺមិនត្រូវបានអនុវត្តដោយប្រព័ន្ធប្រភេទឡើយ។អរូបីដោយប្រើ `Unique` ត្រូវតែអនុវត្តវា។
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// បង្កើត `Unique` ថ្មីមួយដែលកំពុងតែញាប់ញ័រប៉ុន្តែមានរាងសមល្អ។
    ///
    /// វាមានប្រយោជន៍សម្រាប់ការចាប់ផ្តើមប្រភេទដែលបែងចែកយ៉ាងខ្ជិលដូចជា `Vec::new` ។
    ///
    /// ចំណាំថាតម្លៃទ្រនិចអាចតំណាងឱ្យព្រួញកណ្តុរដែលមានសុពលភាពដល់ `T` ដែលមានន័យថានេះមិនត្រូវបានប្រើជាតម្លៃអក្សរ "not yet initialized" ទេ។
    /// ប្រភេទដែលត្រូវតាមដានការបម្រុងទុក lazily ដោយមធ្យោបាយការចាប់ផ្ដើមមួយចំនួនផ្សេងទៀត។
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // សុវត្ថិភាព: mem::align_of() ត្រឡប់ទ្រនិចចង្អុលមិនត្រឹមត្រូវ។នេះ
        // លក្ខខណ្ឌក្នុងការហៅ new_unchecked() ត្រូវបានគោរព។
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// បង្កើត `Unique` ថ្មី។
    ///
    /// # Safety
    ///
    /// `ptr` ត្រូវតែមិនមែនជាមោឃៈ។
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `ptr` មិនមែនជាមោឃៈ។
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// បង្កើត `Unique` ថ្មីប្រសិនបើ `ptr` មិនមែនជាមោឃៈ។
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // សុវត្ថិភាព: ទ្រនិចត្រូវបានត្រួតពិនិត្យរួចហើយហើយមិនត្រូវបានទុកជាមោឃៈ។
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// ទិញទ្រនិច `*mut` មូលដ្ឋាន។
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// សេចក្តីយោងមាតិកា។
    ///
    /// អាយុកាលលទ្ធផលត្រូវបានចងភ្ជាប់ទៅនឹងខ្លួនវាដូច្នេះឥរិយាបថ "as if" វាពិតជាឧទាហរណ៍នៃ T ដែលត្រូវបានខ្ចី។
    /// ប្រសិនបើអាយុកាលវែងជាង (unbound) ត្រូវការប្រើ `&*my_ptr.as_ptr()` ។
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថា `self` បំពេញបានទាំងអស់
        // តម្រូវការសម្រាប់សេចក្តីយោងមួយ។
        unsafe { &*self.as_ptr() }
    }

    /// ដកហូតមាតិកាវិញ។
    ///
    /// អាយុកាលលទ្ធផលត្រូវបានចងភ្ជាប់ទៅនឹងខ្លួនវាដូច្នេះឥរិយាបថ "as if" វាពិតជាឧទាហរណ៍នៃ T ដែលត្រូវបានខ្ចី។
    /// ប្រសិនបើអាយុកាលវែងជាង (unbound) ត្រូវការប្រើ `&mut *my_ptr.as_ptr()` ។
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថា `self` បំពេញបានទាំងអស់
        // តម្រូវការសម្រាប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
        unsafe { &mut *self.as_ptr() }
    }

    /// បោះទៅទ្រនិចនៃប្រភេទមួយផ្សេងទៀត។
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // សុវត្ថិភាព: Unique::new_unchecked() បង្កើតថ្មីនិងតម្រូវការថ្មី
        // ទ្រនិចដែលបានផ្តល់ឱ្យមិនត្រូវទុកជាមោឃៈ។
        // ដោយហេតុថាយើងកំពុងឆ្លងកាត់ខ្លួនឯងជាទ្រនិចមួយវាមិនអាចត្រូវបានទុកចោលទេ។
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // សុវត្ថិភាព: ឯកសារយោងដែលអាចផ្លាស់ប្តូរបានមិនអាចទុកជាមោឃៈបានទេ
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}