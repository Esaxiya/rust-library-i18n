use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` ប៉ុន្តែមិនមែនសូន្យនិង covariant ។
///
/// នេះជារឿងត្រឹមត្រូវដែលត្រូវប្រើនៅពេលសាងសង់រចនាសម្ព័ន្ធទិន្នន័យដោយប្រើចង្អុលបង្ហាញប៉ុន្តែនៅទីបំផុតមានគ្រោះថ្នាក់ក្នុងការប្រើប្រាស់ដោយសារតែលក្ខណៈសម្បត្តិបន្ថែមរបស់វា។ប្រសិនបើអ្នកមិនប្រាកដថាអ្នកគួរតែប្រើ `NonNull<T>` គ្រាន់តែប្រើ `*mut T`!
///
/// មិនដូច `*mut T`, ព្រួញតែងតែត្រូវតែមិនទទេ, បើទោះបីជាទស្សន៍ទ្រនិចត្រូវបានមិន dereferenced ។នេះគឺដើម្បីឱ្យអ៊ីនធឺរណែតអាចប្រើតម្លៃដែលហាមឃាត់នេះជាការរើសអើង-`Option<NonNull<T>>` មានទំហំប៉ុន `* mut T` ។
/// ទោះយ៉ាងណាទ្រនិចអាចនៅតែគាំងប្រសិនបើវាមិនត្រូវបានបញ្ជាក់។
///
/// មិនដូច `*mut T` ទេ `NonNull<T>` ត្រូវបានគេជ្រើសរើសឱ្យក្លាយជាអ្នកariantជាង `T` ។នេះធ្វើឱ្យវាអាចប្រើ `NonNull<T>` នៅពេលសាងសង់ប្រភេទ covariant ប៉ុន្តែណែនាំពីហានិភ័យនៃការមិនត្រឹមត្រូវប្រសិនបើប្រើក្នុងប្រភេទមួយដែលមិនគួរអោយជឿ។
/// (ជម្រើសផ្ទុយត្រូវបានបង្កើតឡើងសម្រាប់ `*mut T` ទោះបីជាបច្ចេកទេសមិនត្រឹមត្រូវអាចបណ្តាលមកពីការហៅមុខងារមិនមានសុវត្ថិភាពក៏ដោយ។)
///
/// Covariance គឺត្រឹមត្រូវសម្រាប់ការអរូបីដែលមានសុវត្ថិភាពបំផុតដូចជា `Box`, `Rc`, `Arc`, `Vec` និង `LinkedList` ។នេះជាករណីព្រោះពួកគេផ្តល់នូវ API សាធារណៈដែលអនុវត្តតាមវិធានដែលអាចផ្លាស់ប្តូរបានរបស់ XOR ធម្មតានៃ Rust ។
///
/// ប្រសិនបើប្រភេទរបស់អ្នកមិនអាចមានភាពរឹងមាំបានដោយសុវត្ថិភាពអ្នកត្រូវតែធានាថាវាមានវាលបន្ថែមមួយចំនួនដើម្បីផ្តល់នូវភាពមិនធម្មតា។ជារឿយៗវាលនេះនឹងក្លាយជាប្រភេទ [`PhantomData`] ដូចជា `PhantomData<Cell<T>>` ឬ `PhantomData<&'a mut T>` ។
///
/// ចំណាំថា `NonNull<T>` មានឧទាហរណ៍ `From` សម្រាប់ `&T` ។ទោះយ៉ាងណានេះមិនផ្លាស់ប្តូរការពិតដែលថាការផ្លាស់ប្តូរតាមរយៈ (ទ្រនិចដែលទទួលបានពីក) សេចក្តីយោងដែលបានចែករំលែកគឺជាឥរិយាបទដែលមិនបានកំណត់ទេលុះត្រាតែការផ្លាស់ប្តូរកើតឡើងនៅក្នុង [`UnsafeCell<T>`] ។ការបង្កើតសេចក្តីយោងដែលអាចផ្លាស់ប្តូរបានពីឯកសារយោងដែលបានចែករំលែក។
///
/// នៅពេលប្រើឧទាហរណ៍ `From` ដោយគ្មាន `UnsafeCell<T>` វាជាការទទួលខុសត្រូវរបស់អ្នកដើម្បីធានាថា `as_mut` មិនដែលត្រូវបានគេហៅហើយ `as_ptr` មិនដែលត្រូវបានប្រើសម្រាប់ការផ្លាស់ប្តូរទេ។
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ចង្អុរមិនមែន `Send` ទេពីព្រោះទិន្នន័យដែលពួកគេយោងអាចត្រូវបានដាក់ឈ្មោះក្លែងក្លាយ។
// NB, ការបញ្ជាក់នេះមិនចាំបាច់ទេប៉ុន្តែគួរតែផ្តល់សារកំហុសប្រសើរជាងមុន។
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ចង្អុរមិនមែន `Sync` ទេពីព្រោះទិន្នន័យដែលពួកគេយោងអាចត្រូវបានដាក់ឈ្មោះក្លែងក្លាយ។
// NB, ការបញ្ជាក់នេះមិនចាំបាច់ទេប៉ុន្តែគួរតែផ្តល់សារកំហុសប្រសើរជាងមុន។
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// បង្កើត `NonNull` ថ្មីមួយដែលកំពុងតែញាប់ញ័រប៉ុន្តែមានរាងសមល្អ។
    ///
    /// វាមានប្រយោជន៍សម្រាប់ការចាប់ផ្តើមប្រភេទដែលបែងចែកយ៉ាងខ្ជិលដូចជា `Vec::new` ។
    ///
    /// ចំណាំថាតម្លៃទ្រនិចអាចតំណាងឱ្យព្រួញកណ្តុរដែលមានសុពលភាពដល់ `T` ដែលមានន័យថានេះមិនត្រូវបានប្រើជាតម្លៃអក្សរ "not yet initialized" ទេ។
    /// ប្រភេទដែលត្រូវតាមដានការបម្រុងទុក lazily ដោយមធ្យោបាយការចាប់ផ្ដើមមួយចំនួនផ្សេងទៀត។
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // សុវត្ថិភាព: mem::align_of() ត្រឡប់ទំហំមិនមែនសូន្យដែលត្រូវបានគេបោះចោល
        // ទៅមួយ * mut T ។
        // ដូច្នេះ `ptr` មិនត្រូវទុកជាមោឃៈទេហើយលក្ខខណ្ឌសម្រាប់ការហៅទូរស័ព្ទ new_unchecked() ត្រូវបានគោរព។
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// ត្រឡប់សេចក្តីយោងដែលបានចែករំលែកទៅតម្លៃ។ផ្ទុយពី [`as_ref`] នេះមិនតម្រូវឱ្យតម្លៃចាប់ផ្តើមទេ។
    ///
    /// សម្រាប់សមភាគីដែលអាចផ្លាស់ប្តូរបានសូមមើល [`as_uninit_mut`] ។
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// នៅពេលហៅវិធីសាស្ត្រនេះអ្នកត្រូវធានាថាទាំងអស់ដូចខាងក្រោម៖
    ///
    /// * ទ្រនិចត្រូវតែត្រូវបានតម្រឹមត្រឹមត្រូវ។
    ///
    /// * វាត្រូវតែជា "dereferencable" ក្នុងន័យដែលបានកំណត់ក្នុង [the module documentation] ។
    ///
    /// * អ្នកត្រូវតែអនុវត្តនៃច្បាប់ក្លែងក្លាយ Rust របស់លោកចាប់តាំងពីការវិលត្រឡប់មកវិញនោះ `'a` ជីវិតត្រូវបានជ្រើសរើសតាមអំពើចិត្តនិងមិនចាំបាច់ឆ្លុះបញ្ចាំងពីជីវិតពិតប្រាកដនៃទិន្នន័យ។
    ///
    ///   ជាពិសេសសម្រាប់រយៈពេលនៃជីវិតនេះការចងចាំទ្រនិចចង្អុលមិនត្រូវបានផ្លាស់ប្តូរ (លើកលែងតែខាងក្នុង `UnsafeCell`) ។
    ///
    /// វាត្រូវបានអនុវត្តទោះបីជាលទ្ធផលនៃវិធីសាស្ត្រនេះមិនត្រូវបានប្រើក៏ដោយ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថា `self` បំពេញបានទាំងអស់
        // តម្រូវការសម្រាប់សេចក្តីយោងមួយ។
        unsafe { &*self.cast().as_ptr() }
    }

    /// ត្រឡប់សេចក្តីយោងតែមួយគត់ចំពោះតម្លៃ។ផ្ទុយពី [`as_mut`] នេះមិនតម្រូវឱ្យតម្លៃចាប់ផ្តើមទេ។
    ///
    /// សម្រាប់សមភាគីរួមសូមមើល [`as_uninit_ref`] ។
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// នៅពេលហៅវិធីសាស្ត្រនេះអ្នកត្រូវធានាថាទាំងអស់ដូចខាងក្រោម៖
    ///
    /// * ទ្រនិចត្រូវតែត្រូវបានតម្រឹមត្រឹមត្រូវ។
    ///
    /// * វាត្រូវតែជា "dereferencable" ក្នុងន័យដែលបានកំណត់ក្នុង [the module documentation] ។
    ///
    /// * អ្នកត្រូវតែអនុវត្តនៃច្បាប់ក្លែងក្លាយ Rust របស់លោកចាប់តាំងពីការវិលត្រឡប់មកវិញនោះ `'a` ជីវិតត្រូវបានជ្រើសរើសតាមអំពើចិត្តនិងមិនចាំបាច់ឆ្លុះបញ្ចាំងពីជីវិតពិតប្រាកដនៃទិន្នន័យ។
    ///
    ///   ជាពិសេសក្នុងរយៈពេលមួយជីវិតនេះការចងចាំទ្រនិចចង្អុលមិនត្រូវចូល (អានឬសរសេរ) តាមរយៈទ្រនិចផ្សេងទៀតទេ។
    ///
    /// វាត្រូវបានអនុវត្តទោះបីជាលទ្ធផលនៃវិធីសាស្ត្រនេះមិនត្រូវបានប្រើក៏ដោយ!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថា `self` បំពេញបានទាំងអស់
        // តម្រូវការសម្រាប់សេចក្តីយោងមួយ។
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// បង្កើត `NonNull` ថ្មី។
    ///
    /// # Safety
    ///
    /// `ptr` ត្រូវតែមិនមែនជាមោឃៈ។
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `ptr` មិនមែនជាមោឃៈ។
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// បង្កើត `NonNull` ថ្មីប្រសិនបើ `ptr` មិនមែនជាមោឃៈ។
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // សុវត្ថិភាព: ទ្រនិចត្រូវបានពិនិត្យរួចហើយហើយមិនត្រូវបានទុកចោលទេ
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// អនុវត្តមុខងារដូចគ្នា [`std::ptr::from_raw_parts`] លើកលែងតែថាទស្សន៍ទ្រនិច `NonNull` ត្រូវបានត្រឡប់ជាការប្រឆាំងទៅនឹងព្រួញ `*const` ឆៅ។
    ///
    ///
    /// សូមមើលឯកសាររបស់ [`std::ptr::from_raw_parts`] សម្រាប់ព័ត៌មានលម្អិត។
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // សុវត្ថិភាព: លទ្ធផលនៃ `ptr::from::raw_parts_mut` គឺមិនមែនជាមោឃៈទេពីព្រោះ `data_address` គឺ។
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// បំបែកទ្រនិចចង្អុល (ធំទូលាយ) ទៅជាអាសយដ្ឋាននិងសមាសធាតុទិន្នន័យមេតាតា។
    ///
    /// ទ្រនិចអាចត្រូវបានបង្កើតឡើងវិញនៅពេលក្រោយជាមួយ [`NonNull::from_raw_parts`] ។
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// ទិញទ្រនិច `*mut` មូលដ្ឋាន។
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ត្រឡប់សេចក្តីយោងដែលបានចែករំលែកទៅតម្លៃ។ប្រសិនបើតម្លៃអាចមិនត្រូវបានធ្វើអាជីវកម្មនោះ [`as_uninit_ref`] ត្រូវតែប្រើជំនួសវិញ។
    ///
    /// សម្រាប់សមភាគីដែលអាចផ្លាស់ប្តូរបានសូមមើល [`as_mut`] ។
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// នៅពេលហៅវិធីសាស្ត្រនេះអ្នកត្រូវធានាថាទាំងអស់ដូចខាងក្រោម៖
    ///
    /// * ទ្រនិចត្រូវតែត្រូវបានតម្រឹមត្រឹមត្រូវ។
    ///
    /// * វាត្រូវតែជា "dereferencable" ក្នុងន័យដែលបានកំណត់ក្នុង [the module documentation] ។
    ///
    /// * ទ្រនិចត្រូវចង្អុលទៅឧទាហរណ៍ដំបូងនៃ `T` ។
    ///
    /// * អ្នកត្រូវតែអនុវត្តនៃច្បាប់ក្លែងក្លាយ Rust របស់លោកចាប់តាំងពីការវិលត្រឡប់មកវិញនោះ `'a` ជីវិតត្រូវបានជ្រើសរើសតាមអំពើចិត្តនិងមិនចាំបាច់ឆ្លុះបញ្ចាំងពីជីវិតពិតប្រាកដនៃទិន្នន័យ។
    ///
    ///   ជាពិសេសសម្រាប់រយៈពេលនៃជីវិតនេះការចងចាំទ្រនិចចង្អុលមិនត្រូវបានផ្លាស់ប្តូរ (លើកលែងតែខាងក្នុង `UnsafeCell`) ។
    ///
    /// វាត្រូវបានអនុវត្តទោះបីជាលទ្ធផលនៃវិធីសាស្ត្រនេះមិនត្រូវបានប្រើក៏ដោយ!
    /// (ផ្នែកអំពីការចាប់ផ្តើមមិនទាន់ត្រូវបានសម្រេចចិត្តពេញលេញនៅឡើយទេប៉ុន្តែរហូតមកដល់ពេលនេះវិធីសាស្រ្តសុវត្ថិភាពតែមួយគត់គឺត្រូវធានាថាពួកវាត្រូវបានចាប់ផ្តើម។)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថា `self` បំពេញបានទាំងអស់
        // តម្រូវការសម្រាប់សេចក្តីយោងមួយ។
        unsafe { &*self.as_ptr() }
    }

    /// ត្រឡប់សេចក្តីយោងតែមួយគត់ចំពោះតម្លៃ។ប្រសិនបើតម្លៃអាចមិនត្រូវបានធ្វើអាជីវកម្មនោះ [`as_uninit_mut`] ត្រូវតែប្រើជំនួសវិញ។
    ///
    /// សម្រាប់សមភាគីរួមសូមមើល [`as_ref`] ។
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// នៅពេលហៅវិធីសាស្ត្រនេះអ្នកត្រូវធានាថាទាំងអស់ដូចខាងក្រោម៖
    ///
    /// * ទ្រនិចត្រូវតែត្រូវបានតម្រឹមត្រឹមត្រូវ។
    ///
    /// * វាត្រូវតែជា "dereferencable" ក្នុងន័យដែលបានកំណត់ក្នុង [the module documentation] ។
    ///
    /// * ទ្រនិចត្រូវចង្អុលទៅឧទាហរណ៍ដំបូងនៃ `T` ។
    ///
    /// * អ្នកត្រូវតែអនុវត្តនៃច្បាប់ក្លែងក្លាយ Rust របស់លោកចាប់តាំងពីការវិលត្រឡប់មកវិញនោះ `'a` ជីវិតត្រូវបានជ្រើសរើសតាមអំពើចិត្តនិងមិនចាំបាច់ឆ្លុះបញ្ចាំងពីជីវិតពិតប្រាកដនៃទិន្នន័យ។
    ///
    ///   ជាពិសេសក្នុងរយៈពេលមួយជីវិតនេះការចងចាំទ្រនិចចង្អុលមិនត្រូវចូល (អានឬសរសេរ) តាមរយៈទ្រនិចផ្សេងទៀតទេ។
    ///
    /// វាត្រូវបានអនុវត្តទោះបីជាលទ្ធផលនៃវិធីសាស្ត្រនេះមិនត្រូវបានប្រើក៏ដោយ!
    /// (ផ្នែកអំពីការចាប់ផ្តើមមិនទាន់ត្រូវបានសម្រេចចិត្តពេញលេញនៅឡើយទេប៉ុន្តែរហូតមកដល់ពេលនេះវិធីសាស្រ្តសុវត្ថិភាពតែមួយគត់គឺត្រូវធានាថាពួកវាត្រូវបានចាប់ផ្តើម។)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថា `self` បំពេញបានទាំងអស់
        // តម្រូវការសម្រាប់សេចក្តីយោងដែលអាចផ្លាស់ប្តូរបាន។
        unsafe { &mut *self.as_ptr() }
    }

    /// បោះទៅទ្រនិចនៃប្រភេទមួយផ្សេងទៀត។
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // សុវត្ថិភាព: `self` គឺជាចំណុច `NonNull` ដែលជាចាំបាច់មិនទទេ
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// បង្កើតចំណិតឆៅដែលគ្មានស្នាមពីទ្រនិចស្តើងនិងប្រវែង។
    ///
    /// អាគុយម៉ង់ `len` គឺជាចំនួននៃធាតុ ** មិនមែនជាចំនួនបៃទេ។
    ///
    /// មុខងារនេះមានសុវត្ថិភាពប៉ុន្តែការបដិសេធតម្លៃត្រឡប់មកវិញគឺមិនមានសុវត្ថិភាពទេ។
    /// សូមមើលឯកសារ [`slice::from_raw_parts`] សម្រាប់តម្រូវការសុវត្ថិភាព។
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // បង្កើតព្រួញកណ្តៀរមួយពេលចាប់ផ្តើមជាមួយទ្រនិចទៅធាតុទីមួយ
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (ចំណាំថាឧទាហរណ៍នេះបង្ហាញដោយប្រើវិធីសាស្រ្តសិប្បនិម្មិតប៉ុន្តែ `សូមអោយចំណិត= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // សុវត្ថិភាព: `data` គឺជាទ្រនិច `NonNull` ដែលចាំបាច់មិនមែនជាមោឃៈ
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// ត្រឡប់ប្រវែងនៃចំណិតឆៅមិនទទេ។
    ///
    /// តម្លៃត្រឡប់មកវិញគឺជាចំនួននៃធាតុ ** ** មិនមែនជាចំនួនបៃនេះ។
    ///
    /// មុខងារនេះមានសុវត្ថិភាពសូម្បីតែចំណិតឆៅដែលមិនមែនជាមោឃៈមិនអាចត្រូវបានគេបែងចែកជាចំណិត ៗ ទេពីព្រោះទ្រនិចមិនមានអាសយដ្ឋានត្រឹមត្រូវ។
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// ត្រឡប់ទ្រនិចមិនទទេទៅសតិបណ្ដោះអាសន្ន។
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // សុវត្ថិភាព: យើងដឹងថា `self` មិនមែនជាមោឃៈទេ។
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// ត្រឡប់ទ្រនិចឆៅទៅសតិបណ្ដោះអាសន្ន។
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ត្រឡប់សេចក្តីយោងដែលបានចែករំលែកទៅចំណែកនៃតម្លៃដែលមិនមានការចូលរួម។ផ្ទុយពី [`as_ref`] នេះមិនតម្រូវឱ្យតម្លៃចាប់ផ្តើមទេ។
    ///
    /// សម្រាប់សមភាគីដែលអាចផ្លាស់ប្តូរបានសូមមើល [`as_uninit_slice_mut`] ។
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// នៅពេលហៅវិធីសាស្ត្រនេះអ្នកត្រូវធានាថាទាំងអស់ដូចខាងក្រោម៖
    ///
    /// * ទ្រនិចត្រូវតែជា [valid] សម្រាប់អានសម្រាប់ `ptr.len() * mem::size_of::<T>()` បៃច្រើនហើយវាត្រូវតម្រឹមអោយបានត្រឹមត្រូវ។នេះមានន័យថា៖
    ///
    ///     * ជួរនៃការចងចាំទាំងមូលនៃចំណិតនេះត្រូវតែមាននៅក្នុងវត្ថុដែលបានបម្រុងទុកតែមួយ!
    ///       ចំណិតមិនអាចមានរយៈពេលទូទាំងវត្ថុដែលបានបម្រុងទុកច្រើន។
    ///
    ///     * ទ្រនិចត្រូវតែត្រូវបានតម្រឹមសូម្បីតែចំណិតប្រវែងសូន្យ។
    ///     ហេតុផលមួយសម្រាប់បញ្ហានេះគឺថាការបង្កើនប្រសិទ្ធភាពប្លង់អេណាមអាចពឹងផ្អែកលើឯកសារយោង (រាប់បញ្ចូលទាំងចំណិតនៃប្រវែងណាមួយ) ដែលត្រូវបានតម្រឹមនិងមិនទុកដើម្បីសម្គាល់ពួកវាពីទិន្នន័យផ្សេងទៀត។
    ///
    ///     អ្នកអាចទទួលបានទ្រនិចមួយដែលអាចប្រើបានជា `data` សម្រាប់ចំណិតប្រវែងសូន្យដោយប្រើ [`NonNull::dangling()`] ។
    ///
    /// * ទំហំ `ptr.len() * mem::size_of::<T>()` សរុបនៃចំណែកត្រូវតែមិនធំជាង `isize::MAX` ។
    ///   សូមមើលឯកសារសុវត្ថិភាពរបស់ [`pointer::offset`] ។
    ///
    /// * អ្នកត្រូវតែអនុវត្តនៃច្បាប់ក្លែងក្លាយ Rust របស់លោកចាប់តាំងពីការវិលត្រឡប់មកវិញនោះ `'a` ជីវិតត្រូវបានជ្រើសរើសតាមអំពើចិត្តនិងមិនចាំបាច់ឆ្លុះបញ្ចាំងពីជីវិតពិតប្រាកដនៃទិន្នន័យ។
    ///   ជាពិសេសសម្រាប់រយៈពេលនៃជីវិតនេះការចងចាំទ្រនិចចង្អុលមិនត្រូវបានផ្លាស់ប្តូរ (លើកលែងតែខាងក្នុង `UnsafeCell`) ។
    ///
    /// វាត្រូវបានអនុវត្តទោះបីជាលទ្ធផលនៃវិធីសាស្ត្រនេះមិនត្រូវបានប្រើក៏ដោយ!
    ///
    /// សូមមើលផងដែរ [`slice::from_raw_parts`] ។
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `as_uninit_slice` ។
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ត្រឡប់ឯកសារយោងតែមួយគត់ចំពោះតម្លៃដែលមិនអាចយកជាការបាន។ផ្ទុយពី [`as_mut`] នេះមិនតម្រូវឱ្យតម្លៃចាប់ផ្តើមទេ។
    ///
    /// សម្រាប់សមភាគីរួមសូមមើល [`as_uninit_slice`] ។
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// នៅពេលហៅវិធីសាស្ត្រនេះអ្នកត្រូវធានាថាទាំងអស់ដូចខាងក្រោម៖
    ///
    /// * ទ្រនិចត្រូវតែជា [valid] សម្រាប់អាននិងសរសេរសម្រាប់ `ptr.len() * mem::size_of::<T>()` បៃច្រើនហើយវាត្រូវតម្រឹមអោយបានត្រឹមត្រូវ។នេះមានន័យថា៖
    ///
    ///     * ជួរនៃការចងចាំទាំងមូលនៃចំណិតនេះត្រូវតែមាននៅក្នុងវត្ថុដែលបានបម្រុងទុកតែមួយ!
    ///       ចំណិតមិនអាចមានរយៈពេលទូទាំងវត្ថុដែលបានបម្រុងទុកច្រើន។
    ///
    ///     * ទ្រនិចត្រូវតែត្រូវបានតម្រឹមសូម្បីតែចំណិតប្រវែងសូន្យ។
    ///     ហេតុផលមួយសម្រាប់បញ្ហានេះគឺថាការបង្កើនប្រសិទ្ធភាពប្លង់អេណាមអាចពឹងផ្អែកលើឯកសារយោង (រាប់បញ្ចូលទាំងចំណិតនៃប្រវែងណាមួយ) ដែលត្រូវបានតម្រឹមនិងមិនទុកដើម្បីសម្គាល់ពួកវាពីទិន្នន័យផ្សេងទៀត។
    ///
    ///     អ្នកអាចទទួលបានទ្រនិចមួយដែលអាចប្រើបានជា `data` សម្រាប់ចំណិតប្រវែងសូន្យដោយប្រើ [`NonNull::dangling()`] ។
    ///
    /// * ទំហំ `ptr.len() * mem::size_of::<T>()` សរុបនៃចំណែកត្រូវតែមិនធំជាង `isize::MAX` ។
    ///   សូមមើលឯកសារសុវត្ថិភាពរបស់ [`pointer::offset`] ។
    ///
    /// * អ្នកត្រូវតែអនុវត្តនៃច្បាប់ក្លែងក្លាយ Rust របស់លោកចាប់តាំងពីការវិលត្រឡប់មកវិញនោះ `'a` ជីវិតត្រូវបានជ្រើសរើសតាមអំពើចិត្តនិងមិនចាំបាច់ឆ្លុះបញ្ចាំងពីជីវិតពិតប្រាកដនៃទិន្នន័យ។
    ///   ជាពិសេសក្នុងរយៈពេលមួយជីវិតនេះការចងចាំទ្រនិចចង្អុលមិនត្រូវចូល (អានឬសរសេរ) តាមរយៈទ្រនិចផ្សេងទៀតទេ។
    ///
    /// វាត្រូវបានអនុវត្តទោះបីជាលទ្ធផលនៃវិធីសាស្ត្រនេះមិនត្រូវបានប្រើក៏ដោយ!
    ///
    /// សូមមើលផងដែរ [`slice::from_raw_parts_mut`] ។
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // នេះមានសុវត្ថិភាពព្រោះថា `memory` មានសុពលភាពសំរាប់ការអាននិងសរសេរសំរាប់ `memory.len()` បៃច្រើន។
    /// // ចំណាំថាការហៅទូរស័ព្ទ `memory.as_mut()` មិនត្រូវបានអនុញ្ញាតនៅទីនេះទេព្រោះមាតិកាអាចត្រូវបានគេមិនឯកភាព។
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `as_uninit_slice_mut` ។
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// ត្រឡប់ទ្រនិចឆៅទៅធាតុឬវត្ថុរងដោយមិនចាំបាច់ពិនិត្យព្រំដែន។
    ///
    /// ការហៅវិធីសាស្ត្រនេះជាមួយសន្ទស្សន៍ក្រៅព្រំដែនឬនៅពេលដែល `self` មិនត្រូវបានបដិសេធគឺ *[អាកប្បកិរិយាដែលមិនបានកំណត់]* ទោះបីជាទ្រនិចលទ្ធផលមិនត្រូវបានប្រើក៏ដោយ។
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលធានាថា `self` គឺមិនអាចបដិសេធបាននិង `index` នៅក្នុងព្រំដែន។
        // ជាលទ្ធផលទ្រនិចលទ្ធផលមិនអាចជា NULL ទេ។
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // សុវត្ថិភាព: ទ្រនិចពិសេសមួយមិនអាចត្រូវទុកជាមោឃៈបានទេដូច្នេះលក្ខខណ្ឌសម្រាប់
        // new_unchecked() ត្រូវបានគោរព។
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // សុវត្ថិភាព: ឯកសារយោងដែលអាចផ្លាស់ប្តូរបានមិនអាចទុកជាមោឃៈបានទេ។
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // សុវត្ថិភាព: យោងមិនអាចទទេដូច្នេះលក្ខខណ្ឌសម្រាប់
        // new_unchecked() ត្រូវបានគោរព។
        unsafe { NonNull { pointer: reference as *const T } }
    }
}