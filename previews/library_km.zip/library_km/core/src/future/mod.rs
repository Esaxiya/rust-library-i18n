#![stable(feature = "futures_api", since = "1.36.0")]

//! តម្លៃអសមកាល។

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ប្រភេទនេះត្រូវការពីព្រោះ
///
/// ក) លក់មិនអាចអនុវត្ត `for<'a, 'b> Generator<&'a mut Context<'b>>` ដូច្នេះយើងត្រូវការអនុម័តព្រួញឆៅ (សូមមើល <https://github.com/rust-lang/rust/issues/68923>) ។
///
/// ខ) ចង្អុលបង្ហាញឆៅនិង `NonNull` មិនមែន `Send` ឬ `Sync` ទេដូច្នេះវានឹងធ្វើឱ្យ future non-Send/Sync តែមួយដូចគ្នាហើយយើងក៏មិនចង់បានដែរ។
///
/// វាសម្រួល HIR ការបន្ថយ `.await` ។
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// រុំម៉ាស៊ីនភ្លើងនៅ future មួយ។
///
/// មុខងារនេះត្រឡប់ `GenFuture` នៅក្រោមប៉ុន្តែលាក់វានៅក្នុង `impl Trait` ដើម្បីផ្តល់សារកំហុសប្រសើរជាងមុន (`impl Future` ជាជាង `GenFuture<[closure.....]>`) ។
///
// នេះគឺជា `const` ដើម្បីចៀសវាងកំហុសបន្ថែមបន្ទាប់ពីយើងងើបពី `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // យើងពឹងផ្អែកលើការពិតដែលថា async/await futures អាចផ្លាស់ប្តូរបានក្នុងគោលបំណងដើម្បីបង្កើតប្រាក់កម្ចីយោងដោយខ្លួនឯងនៅក្នុងម៉ាស៊ីនបង្កើតមូលដ្ឋាន។
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // សុវត្ថិភាព: សុវត្ថិភាពពីព្រោះយើងជា !Unpin + !Drop ហើយនេះគ្រាន់តែជាការព្យាករវាលប៉ុណ្ណោះ។
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // បន្តម៉ាស៊ីនភ្លើងដោយបង្វែរ `&mut Context` ទៅជាទ្រនិចឆៅ `NonNull` ។
            // `.await` ការកាត់បន្ថយនេះនឹងបោះដោយសុវត្ថិភាពត្រឡប់ទៅ `&mut Context` មួយ។
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែធានាថា `cx.0` គឺជាព្រួញចង្អុលត្រឹមត្រូវ
    // ថាការបំពេញតម្រូវការទាំងអស់សម្រាប់ជាឯកសារយោង mutable មួយ។
    unsafe { &mut *cx.0.as_ptr().cast() }
}