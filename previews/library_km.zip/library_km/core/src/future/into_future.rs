use crate::future::Future;

/// ការបម្លែងទៅជា `Future` មួយ។
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// ទិន្នផលដែល future នេះនឹងផលិតលើការបញ្ចប់។
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// ដែលប្រភេទនៃការ future បានជាយើងងាកនេះចូលទៅក្នុង?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// បង្កើត future ពីតម្លៃ។
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}