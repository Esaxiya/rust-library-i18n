//! ម៉ូឌុលនេះបង្ហាញពីប្រភេទបឋមដើម្បីអនុញ្ញាតឱ្យការប្រើប្រាស់ដែលមិនត្រូវបានស្រមោលដោយប្រភេទដែលបានប្រកាសផ្សេងទៀត។
//!
//! ជាទូទៅវាមានប្រយោជន៍តែក្នុងលេខកូដដែលបង្កើតម៉ាក្រូប៉ុណ្ណោះ។
//!
//! ឧទាហរណ៏នៃការនេះគឺនៅពេលដែលការបង្កើតរចនាសម្ព័ន្ធថ្មីមួយនិង impl សម្រាប់វា:
//!
//! ```rust,compile_fail
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!
//! ចំណាំថា `SOME_PROPERTY` ថេរដែលជាប់ទាក់ទងនឹងមិនចងក្រងទេព្រោះប្រភេទ `bool` របស់វាសំដៅទៅលើរចនាសម្ព័ន្ធជាជាងប្រភេទ bool ដំបូង។
//!
//!
//! ការអនុវត្តត្រឹមត្រូវអាចមើលទៅដូចជាៈ
//!
//! ```rust
//! # #[allow(non_camel_case_types)]
//! pub struct bool;
//!
//! impl QueryId for bool {
//!     const SOME_PROPERTY: core::primitive::bool = true;
//! }
//!
//! # trait QueryId { const SOME_PROPERTY: core::primitive::bool; }
//! ```
//!

#[stable(feature = "core_primitive", since = "1.43.0")]
pub use bool;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use char;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use f64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use i8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use isize;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use str;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u128;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u16;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u32;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u64;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use u8;
#[stable(feature = "core_primitive", since = "1.43.0")]
pub use usize;