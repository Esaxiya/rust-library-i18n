#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! ឧបករណ៍ប្រើប្រាស់ដែលទាក់ទងទៅនឹងមុខងារការចង (FFI) បរទេសចំណុចប្រទាក់។

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// ស្មើនឹងប្រភេទ `void` របស់ C ពេលប្រើជា [pointer] មួយ។
///
/// នៅក្នុងខ្លឹមសារ `*const c_void` គឺស្មើនឹង `const void*` របស់ X និង `*mut c_void` គឺស្មើនឹង `void*` X របស់ស៊ី។
/// ដែលបាននិយាយថានេះមិនមែន * ដូចគ្នានឹងប្រភេទត្រឡប់ `void` របស់ស៊ីដែលជាប្រភេទ `()` របស់ Rust ។
///
/// ដើម្បីធ្វើជាគំរូព្រួញទៅនឹងប្រភេទស្រអាប់នៅអង្គការ FFI, រហូតដល់ `extern type` មានស្ថិរភាព, វាត្រូវបានផ្ដល់អនុសាសន៍ឱ្យប្រើរុំ newtype នៅជុំវិញអារេបៃទទេ។
///
/// សូមមើល [Nomicon] សម្រាប់ព័ត៌មានលម្អិត។
///
/// មួយអាចប្រើ `std::os::raw::c_void` ប្រសិនបើពួកគេចង់គាំទ្រអ្នកចងក្រង Rust ចាស់ចុះដល់ 1.1.0 ។
/// បន្ទាប់ពី Rust 1.30.0 វាត្រូវបាននាំចេញឡើងវិញតាមនិយមន័យនេះ។
/// សម្រាប់ពបន្ថែមសូមអាន [RFC 2521] ។
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB សម្រាប់ការទទួលស្គាល់ប្រភេទ LLVM ព្រួញទុកជាមោឃៈហើយដោយបានផ្នែកបន្ថែមដូច malloc() មុខងារយើងត្រូវមានវាតំណាងថាជា i8 * នៅ bitcode LLVM ។
// enum បានប្រើនៅទីនេះធានានេះនិងការពារប្រើប្រាស់ខុសនៃប្រភេទ "raw" ដោយគ្រាន់តែមានវ៉ារ្យ៉ង់ឯកជន។
// យើងត្រូវការវ៉ារ្យ៉ង់ពីរពីព្រោះអ្នកចងក្រងត្អូញត្អែរអំពីគុណលក្ខណៈ repr បើមិនដូច្នេះទេហើយយើងត្រូវការវ៉ារ្យ៉ង់យ៉ាងហោចណាស់មួយបើមិនដូច្នេះទេអ៊ីណុកនឹងមិនមានមនុស្សរស់នៅហើយយ៉ាងហោចណាស់ការចង្អុលបង្ហាញអំពីចំនុចនេះអាចជា UB ។
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// ការអនុវត្តជាមូលដ្ឋាននៃ `va_list` មួយ។
// ឈ្មោះនេះគឺ WIP ដោយប្រើ `VaListImpl` សម្រាប់ពេលឥឡូវនេះ។
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // មិនច្បាស់ជាង `'f` ដូច្នេះវត្ថុ `VaListImpl<'f>` នីមួយៗត្រូវបានផ្សារភ្ជាប់ទៅនឹងតំបន់នៃមុខងារដែលវាត្រូវបានកំណត់
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ការអនុវត្តប្រចាំក្រុមហ៊ុន ABI Research របស់ `va_list` មួយ។
/// សូមមើល [AArch64 Procedure Call Standard] សម្រាប់សេចក្ដីលម្អិតបន្ថែម។
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ការអនុវត្តប្រចាំក្រុមហ៊ុន ABI Research របស់ `va_list` មួយ។
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ការអនុវត្តប្រចាំក្រុមហ៊ុន ABI Research របស់ `va_list` មួយ។
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// កន្សែងរុំសម្រាប់ `va_list` មួយ
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// បំលែង `VaListImpl` ទៅជា `VaList` ដែលជាប្រព័ន្ធគោលពីរដែលឆបគ្នាជាមួយ X's `va_list` ។
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// បំលែង `VaListImpl` ទៅជា `VaList` ដែលជាប្រព័ន្ធគោលពីរដែលឆបគ្នាជាមួយ X's `va_list` ។
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// នេះ VaArgSafe trait ត្រូវការឱ្យត្រូវបានប្រើនៅក្នុងចំណុចប្រទាក់សាធារណៈ, ទោះជាយ៉ាងណា trait ខ្លួនវាមិនត្រូវបានអនុញ្ញាតឱ្យប្រើនៅខាងក្រៅម៉ូឌុលនេះ។
// អនុញ្ញាតឱ្យអ្នកប្រើដើម្បីអនុវត្ត trait សម្រាប់ប្រភេទថ្មី (ដោយហេតុនេះអនុញ្ញាតឱ្យចាំបាច់ va_arg ដែលត្រូវបានប្រើនៅលើប្រភេទថ្មីមួយ) ទំនងជាបង្កឱ្យមានឥរិយាបទមិនបានកំណត់។
//
// FIXME(dlrobertson): ដើម្បីប្រើ VaArgSafe trait នៅក្នុងចំណុចប្រទាក់សាធារណៈប៉ុន្តែក៏ធានាថាវាមិនអាចត្រូវបានប្រើនៅកន្លែងផ្សេងទៀត trait ត្រូវការជាសាធារណៈនៅក្នុងម៉ូឌុលឯកជន។
// នៅពេលដែលប្រព័ន្ធអេហ្វអេហ្វអេហ្វអេស ២១៤៥ ត្រូវបានគេយកទៅអនុវត្តដើម្បីកែលម្អវា
//
//
//
//
mod sealed_trait {
    /// Trait ដែលអនុញ្ញាតឱ្យប្រភេទដែលបានអនុញ្ញាតដែលត្រូវប្រើជាមួយ [super::VaListImpl::arg] ។
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// ឆ្ពោះទៅរកអាគុយម៉ង់បន្ទាប់។
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `va_arg` ។
        unsafe { va_arg(self) }
    }

    /// ថតចម្លង `va_list` នៅទីតាំងបច្ចុប្បន្ន។
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // សុវត្ថិភាព: អ្នកហៅទូរស័ព្ទត្រូវតែគោរពកិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `va_end` ។
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // សុវត្ថិភាព: យើងសរសេរទៅ `MaybeUninit` ដូច្នេះវាត្រូវបានចាប់ផ្តើមហើយ `assume_init` គឺស្របច្បាប់
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ការនេះគួរតែហៅ `va_end`, ប៉ុន្តែមិនមានវិធីស្អាត
        // ធានាថា `drop` តែងតែត្រូវបានបញ្ចូលទៅក្នុងទូរស័ព្ទរបស់អ្នកដូច្នេះ `va_end` នឹងត្រូវបានហៅដោយផ្ទាល់ពីមុខងារដូចគ្នានឹង `va_copy` ដែលត្រូវគ្នា។
        // `man va_end` រដ្ឋដែលគតម្រូវឱ្យនេះនិងជាមូលដ្ឋានខាងក្រោមសញ្ញាន័យវិទ្យា LLVM C, ដូច្នេះយើងត្រូវការដើម្បីធ្វើឱ្យប្រាកដថា `va_end` តែងតែត្រូវបានគេហៅថាពីមុខងារដូចគ្នា `va_copy` ។
        //
        // សម្រាប់ព័ត៌មានលម្អិត see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // វាដំណើរការសម្រាប់ពេលនេះចាប់តាំងពី `va_end` គឺជាឧបករណ៍គ្មានគោលដៅនៅលើគោលដៅអិលអេអិមអិមបច្ចុប្បន្នទាំងអស់។
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// បំផ្លាញ arglist `ap` បន្ទាប់ពីការចាប់ផ្ដើមជាមួយ `va_start` ឬ `va_copy` ។
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ចម្លងទីតាំងបច្ចុប្បន្ននៃអាគុយម៉ង់ `src` ទៅកាន់អាគុយម៉ង់ `dst` ។
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// ផ្ទុកអាគុយម៉ង់ប្រភេទ `T` ពី `va_list` `ap` និងបង្កើនអាគុយម៉ង់ `ap` ចង្អុលទៅ។
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}