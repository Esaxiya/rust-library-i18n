//! ការបែងចែកសតិ APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// កំហុស `AllocError` បង្ហាញពីការបរាជ័យក្នុងការបែងចែកមួយដែលអាចមានដោយសារតែការអស់កម្លាំងធនធានឬដើម្បីអ្វីមួយនៅពេលដែលរួមបញ្ចូលគ្នារវាងខុសអាគុយម៉ង់បញ្ចូលដែលបានផ្ដល់ឱ្យដោយមានការបែងចែកនេះ។
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (យើងត្រូវការនេះសម្រាប់ impl ខ្សែទឹកខាងក្រោមនៃកំហុស trait)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// ការអនុវត្ត `Allocator` អាចបែងចែករីកលូតលាស់បង្រួមនិងចែកចាយទិន្នន័យតាមអំពើចិត្តដែលបានពិពណ៌នាតាមរយៈ [`Layout`][] ។
///
/// `Allocator` ត្រូវបានរចនាឡើងដើម្បីត្រូវបានអនុវត្តនៅលើ ZSTs ឯកសារយោងឬចង្អុលបង្ហាញឆ្លាតវៃពីព្រោះមានអ្នកបែងចែកដូចជា `MyAlloc([u8; N])` មិនអាចរើចេញបានទេបើគ្មានការធ្វើបច្ចុប្បន្នភាពចំណុចចង្អុលទៅអង្គចងចាំដែលបានបម្រុងទុក
///
/// មិនដូច [`GlobalAlloc`][], ការបែងចែកសូន្យមានទំហំត្រូវបានអនុញ្ញាតក្នុង `Allocator` ។
/// ប្រសិនបើការបែងចែកមូលដ្ឋានមិនគាំទ្រនេះ (ដូច jemalloc) ឬត្រឡប់ព្រួញទទេមួយ (ដូចជា `libc::malloc`) នេះត្រូវតែត្រូវចាប់បានដោយការអនុវត្តន៍។
///
/// ### បានបម្រុងទុកសតិបច្ចុប្បន្ន
///
/// វិធីសាស្រ្តមួយចំនួនទាមទារឱ្យប្លុកសតិមួយ *បច្ចុប្បន្នត្រូវបានគេបែងចែក* តាមរយៈអ្នកបែងចែក។នេះមានន័យថា:
///
/// * អាសយដ្ឋានចាប់ផ្តើមសម្រាប់ប្លុកការចងចាំដែលកាលពីមុនត្រូវបានត្រឡប់មកវិញដោយ [`allocate`], [`grow`] ឬ [`shrink`] និង
///
/// * ប្លុកសតិមិនត្រូវបាន deallocated ជាបន្តបន្ទាប់, ដែលជាកន្លែងដែលប្លុកត្រូវបាន deallocated ដោយផ្ទាល់ដោយត្រូវបានអនុម័តដើម្បី [`deallocate`] ឬត្រូវបានផ្លាស់ប្តូរដោយត្រូវបានអនុម័តដើម្បី [`grow`] ឬ [`shrink`] ដែលត្រឡប់ `Ok` ។
///
/// ប្រសិនបើ `grow` ឬ `shrink` បានត្រឡប់ `Err` នោះទ្រនិចដែលបានឆ្លងកាត់នៅតែមានសុពលភាព។
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### សមនឹងការចងចាំ
///
/// វិធីសាស្រ្តមួយចំនួនតម្រូវឱ្យមានប្លង់មួយ *សម* ប្លុកសតិ។
/// អ្វីដែលវាមានន័យសម្រាប់ប្លង់ទៅ "fit" ប្លុកសតិមានន័យថា (ឬប្រហាក់ប្រហែលសម្រាប់ប្លុកសតិដល់ "fit" ប្លង់) គឺថាល័ក្ខខ័ណ្ឌដូចខាងក្រោមត្រូវតែមាន៖
///
/// * ប្លុកត្រូវតែត្រូវបានបម្រុងទុកជាមួយការតម្រឹមដូចគ្នានឹង [`layout.align()`] និង
///
/// * [`layout.size()`] ដែលបានផ្តល់ត្រូវតែស្ថិតនៅក្នុងជួរ `min ..= max` កន្លែង៖
///   - `min` គឺជាទំហំនៃប្លង់ដែលបានប្រើច្រើនបំផុតក្នុងការបម្រុងទុកពេលថ្មីប្លុកនេះ, និង
///   - `max` គឺជាទំហំពិតប្រាកដចុងក្រោយបំផុតបានវិលត្រឡប់មកពី [`allocate`], [`grow`] ឬ [`shrink`] ។
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * ប្លុកការចងចាំត្រឡប់មកពីការបែងចែកមួយត្រូវតែចង្អុលទៅការចងចាំនិងរក្សាសុពលភាពសុពលភាពរហូតដល់ឧទាហរណ៍និងការរបស់ពួកគេទាំងអស់នៃការក្លូនរបស់ខ្លួនត្រូវបានធ្លាក់ចុះនោះទេ
///
/// * ក្លូនឬផ្លាស់ប្តូរអ្នកបែងចែកមិនត្រូវធ្វើឱ្យប្លុកសតិដែលមានសុពលភាពត្រលប់ពីអ្នកបែងចែកនេះទេ។អ្នកបែងចែកក្លូនត្រូវមានឥរិយាបទដូចអ្នកបែងចែកដូចគ្នានិង
///
/// * ទ្រនិចណាមួយទៅនឹងប្លុកមេម៉ូរីដែលជា [*currently allocated*] អាចត្រូវបានបញ្ជូនទៅវិធីសាស្រ្តផ្សេងទៀតរបស់អ្នកបែងចែក។
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// ការប៉ុនប៉ងដើម្បីបម្រុងទុកប្លុករបស់សតិនេះ។
    ///
    /// នៅលើការទទួលបានជោគជ័យត្រឡប់ [`NonNull<[u8]>`][NonNull] មួយបានជួបទំហំនិងការតម្រឹមការធានានៃការ `layout` ។
    ///
    /// ប្លុកដែលបានត្រឡប់មកវិញអាចមានទំហំធំជាងការបញ្ជាក់ដោយ `layout.size()` ហើយអាចឬមិនមានមាតិការបស់វាត្រូវបានចាប់ផ្តើម។
    ///
    /// # Errors
    ///
    /// ការត្រឡប់ `Err` បង្ហាញថាអង្គចងចាំអស់កម្លាំងហើយ `layout` មិនបំពេញតាមទំហំរបស់អ្នកបែងចែកឬឧបសគ្គតម្រឹម។
    ///
    /// ការប្រតិបត្តិត្រូវបានលើកទឹកចិត្តឱ្យវិលត្រឡប់មកវិញនៅលើការអស់កម្លាំងការចងចាំ `Err` ជាងការភ័យខ្លាចឬជាបោះបង់ប៉ុន្តែនេះមិនមែនជាតម្រូវការយ៉ាងតឹងរឹង។
    /// (ជាពិសេសៈវាជាការស្របច្បាប់ * ដើម្បីអនុវត្ត trait នេះនៅលើបណ្ណាល័យបែងចែកមូលដ្ឋានដែលបានបញ្ឈប់ការអស់កម្លាំងសតិ។)
    ///
    /// អតិថិជនដែលមានបំណងបោះបង់ចោលការគណនាក្នុងការឆ្លើយតបទៅនឹងកំហុសនៃការបែងចែកត្រូវបានលើកទឹកចិត្តឱ្យហៅមុខងារ [`handle_alloc_error`] ជាជាងការហៅដោយផ្ទាល់ `panic!` ឬស្រដៀងគ្នា។
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// អាកប្បកិរិយាដូចជា `allocate` ប៉ុន្តែក៏ធានាថាការចងចាំត្រឡប់មកវិញត្រូវបានចាប់ផ្តើមដោយសូន្យ។
    ///
    /// # Errors
    ///
    /// ការត្រឡប់ `Err` បង្ហាញថាអង្គចងចាំអស់កម្លាំងហើយ `layout` មិនបំពេញតាមទំហំរបស់អ្នកបែងចែកឬឧបសគ្គតម្រឹម។
    ///
    /// ការប្រតិបត្តិត្រូវបានលើកទឹកចិត្តឱ្យវិលត្រឡប់មកវិញនៅលើការអស់កម្លាំងការចងចាំ `Err` ជាងការភ័យខ្លាចឬជាបោះបង់ប៉ុន្តែនេះមិនមែនជាតម្រូវការយ៉ាងតឹងរឹង។
    /// (ជាពិសេសៈវាជាការស្របច្បាប់ * ដើម្បីអនុវត្ត trait នេះនៅលើបណ្ណាល័យបែងចែកមូលដ្ឋានដែលបានបញ្ឈប់ការអស់កម្លាំងសតិ។)
    ///
    /// អតិថិជនដែលមានបំណងបោះបង់ចោលការគណនាក្នុងការឆ្លើយតបទៅនឹងកំហុសនៃការបែងចែកត្រូវបានលើកទឹកចិត្តឱ្យហៅមុខងារ [`handle_alloc_error`] ជាជាងការហៅដោយផ្ទាល់ `panic!` ឬស្រដៀងគ្នា។
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // សុវត្ថិភាព: `alloc` ត្រឡប់ប្លុកសតិត្រឹមត្រូវ
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// ចែកចាយអង្គចងចាំដែលយោងដោយ `ptr` ។
    ///
    /// # Safety
    ///
    /// * `ptr` ត្រូវតែបញ្ជាក់ប្លុករបស់សតិ [*currently allocated*] តាមរយៈការបែងចែកនេះនិង
    /// * `layout` ត្រូវតែ [*fit*] ដែលរារាំងសតិ។
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// ការប៉ុនប៉ងដើម្បីពង្រីកប្លុកសតិ។
    ///
    /// ត្រឡប់ [`NonNull<[u8]>`][NonNull] ថ្មីដែលមានទ្រនិចនិងទំហំពិតប្រាកដនៃអង្គចងចាំដែលបានបម្រុងទុក។ទ្រនិចគឺសមស្របសម្រាប់ការកាន់ទិន្នន័យដែលពិពណ៌នាដោយ `new_layout` ។
    /// ដើម្បីសម្រេចគោលបំណងនេះការបែងចែកនេះអាចពង្រីកការបែងចែកដែលបានយោងដោយ `ptr` ឱ្យសមទៅនឹងប្លង់ថ្មី។
    ///
    /// ប្រសិនបើនេះត្រឡប់ `Ok`, បន្ទាប់មកបានភាពជាម្ចាស់នៃប្លុកសតិដែលបានយោងដោយ `ptr` ត្រូវបានបញ្ជូនទៅការបែងចែកនេះ។
    /// ការចងចាំអាចឬមិនអាចត្រូវបានដោះលែងឱ្យមានសេរីភាព, និងគួរតែត្រូវបានចាត់ទុកជាមិនអាចប្រើបានលុះត្រាតែវាត្រូវបានផ្ទេរទៅអ្នកទូរស័ព្ទចូលជាថ្មីម្តងទៀតតាមរយៈការត្រឡប់តម្លៃនៃវិធីសាស្រ្តនេះ។
    ///
    /// ប្រសិនបើមានវិធីសាស្រ្តនេះត្រឡប់ `Err` កម្មសិទ្ធិបន្ទាប់មកនៃប្លុកសតិមិនត្រូវបានផ្ទេរទៅឱ្យបែងចែកនេះនិងមាតិការបស់ប្លុកសតិគឺ unaltered ។
    ///
    /// # Safety
    ///
    /// * `ptr` ត្រូវតែបញ្ជាក់ប្លុករបស់សតិ [*currently allocated*] មួយតាមរយៈការបែងចែកនេះ។
    /// * `old_layout` ត្រូវតែ [*fit*] ថាប្លុករបស់សតិ (អាគុយម៉ង់ `new_layout` តម្រូវមិនសមនឹងវា។) ។
    /// * `new_layout.size()` ត្រូវតែធំជាងឬស្មើ `old_layout.size()` ។
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ត្រឡប់ `Err` ប្រសិនបើប្លង់ថ្មីមិនត្រូវនឹងទំហំរបស់អ្នកបែងចែកនិងឧបសគ្គតម្រឹមរបស់អ្នកបែងចែកឬប្រសិនបើរីកលូតលាស់បើមិនដូច្នេះទេនឹងបរាជ័យ។
    ///
    /// ការប្រតិបត្តិត្រូវបានលើកទឹកចិត្តឱ្យវិលត្រឡប់មកវិញនៅលើការអស់កម្លាំងការចងចាំ `Err` ជាងការភ័យខ្លាចឬជាបោះបង់ប៉ុន្តែនេះមិនមែនជាតម្រូវការយ៉ាងតឹងរឹង។
    /// (ជាពិសេសៈវាជាការស្របច្បាប់ * ដើម្បីអនុវត្ត trait នេះនៅលើបណ្ណាល័យបែងចែកមូលដ្ឋានដែលបានបញ្ឈប់ការអស់កម្លាំងសតិ។)
    ///
    /// អតិថិជនដែលមានបំណងបោះបង់ចោលការគណនាក្នុងការឆ្លើយតបទៅនឹងកំហុសនៃការបែងចែកត្រូវបានលើកទឹកចិត្តឱ្យហៅមុខងារ [`handle_alloc_error`] ជាជាងការហៅដោយផ្ទាល់ `panic!` ឬស្រដៀងគ្នា។
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // សុវត្ថិភាព: ដោយសារតែ `new_layout.size()` ត្រូវតែធំជាងឬស្មើ
        // `old_layout.size()`, ទាំងការបែងចែកសតិចាស់និងថ្មីមានសុពលភាពសម្រាប់ការអាននិងសរសេរសម្រាប់ `old_layout.size()` បៃ។
        // ដូចគ្នានេះផងដែរដោយសារតែការបែងចែកចាស់មិនទាន់ត្រូវបានដោះស្រាយវាមិនអាចត្រួតលើ `new_ptr` បានទេ។
        // ដូច្នេះការហៅទៅ `copy_nonoverlapping` គឺមានសុវត្ថិភាព។
        // កិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `dealloc` ត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// អាកប្បកិរិយាដូចជា `grow` ប៉ុន្តែក៏ធានាថាមាតិកាថ្មីត្រូវបានកំណត់ទៅសូន្យមុនពេលត្រូវបានត្រឡប់មកវិញ។
    ///
    /// បណ្តុំមេម៉ូរីនឹងមានផ្ទុកនូវខ្លឹមសារដូចខាងក្រោមបន្ទាប់ពីទទួលបានជោគជ័យ
    /// `grow_zeroed`:
    ///   * បៃ `0..old_layout.size()` ត្រូវបានបម្រុងទុកពីការបែងចែកដើម។
    ///   * បៃ `old_layout.size()..old_size` នឹងត្រូវបានរក្សាទុកឬដាក់សូន្យអាស្រ័យលើការអនុវត្តអ្នកបែងចែក។
    ///   `old_size` សំដៅទៅលើទំហំនៃប្លុកសតិមុនពេលការហៅ `grow_zeroed` ដែលអាចមានទំហំធំជាងទំហំដែលត្រូវបានស្នើរសុំពីដំបូងនៅពេលដែលវាត្រូវបានគេផ្តល់នេះ។
    ///   * បៃ `old_size..new_size` ត្រូវបានផ្ដោតអារម្មណ៍។`new_size` សំដៅទៅលើទំហំនៃប្លុកសតិត្រឡប់ដោយការហៅ `grow_zeroed` នេះ។
    ///
    /// # Safety
    ///
    /// * `ptr` ត្រូវតែបញ្ជាក់ប្លុករបស់សតិ [*currently allocated*] មួយតាមរយៈការបែងចែកនេះ។
    /// * `old_layout` ត្រូវតែ [*fit*] ថាប្លុករបស់សតិ (អាគុយម៉ង់ `new_layout` តម្រូវមិនសមនឹងវា។) ។
    /// * `new_layout.size()` ត្រូវតែធំជាងឬស្មើ `old_layout.size()` ។
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ត្រឡប់ `Err` ប្រសិនបើប្លង់ថ្មីមិនត្រូវនឹងទំហំរបស់អ្នកបែងចែកនិងឧបសគ្គតម្រឹមរបស់អ្នកបែងចែកឬប្រសិនបើរីកលូតលាស់បើមិនដូច្នេះទេនឹងបរាជ័យ។
    ///
    /// ការប្រតិបត្តិត្រូវបានលើកទឹកចិត្តឱ្យវិលត្រឡប់មកវិញនៅលើការអស់កម្លាំងការចងចាំ `Err` ជាងការភ័យខ្លាចឬជាបោះបង់ប៉ុន្តែនេះមិនមែនជាតម្រូវការយ៉ាងតឹងរឹង។
    /// (ជាពិសេសៈវាជាការស្របច្បាប់ * ដើម្បីអនុវត្ត trait នេះនៅលើបណ្ណាល័យបែងចែកមូលដ្ឋានដែលបានបញ្ឈប់ការអស់កម្លាំងសតិ។)
    ///
    /// អតិថិជនដែលមានបំណងបោះបង់ចោលការគណនាក្នុងការឆ្លើយតបទៅនឹងកំហុសនៃការបែងចែកត្រូវបានលើកទឹកចិត្តឱ្យហៅមុខងារ [`handle_alloc_error`] ជាជាងការហៅដោយផ្ទាល់ `panic!` ឬស្រដៀងគ្នា។
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // សុវត្ថិភាព: ដោយសារតែ `new_layout.size()` ត្រូវតែធំជាងឬស្មើ
        // `old_layout.size()`, ទាំងការបែងចែកសតិចាស់និងថ្មីមានសុពលភាពសម្រាប់ការអាននិងសរសេរសម្រាប់ `old_layout.size()` បៃ។
        // ដូចគ្នានេះផងដែរដោយសារតែការបែងចែកចាស់មិនទាន់ត្រូវបានដោះស្រាយវាមិនអាចត្រួតលើ `new_ptr` បានទេ។
        // ដូច្នេះការហៅទៅ `copy_nonoverlapping` គឺមានសុវត្ថិភាព។
        // កិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `dealloc` ត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// ការប៉ុនប៉ងបង្រួមប្លុកសតិ។
    ///
    /// ត្រឡប់ [`NonNull<[u8]>`][NonNull] ថ្មីដែលមានទ្រនិចនិងទំហំពិតប្រាកដនៃអង្គចងចាំដែលបានបម្រុងទុក។ទ្រនិចគឺសមស្របសម្រាប់ការកាន់ទិន្នន័យដែលពិពណ៌នាដោយ `new_layout` ។
    /// ដើម្បីសម្រេចកិច្ចការនេះអ្នកបែងចែកអាចបង្រួមការបែងចែកដែលបានបញ្ជាក់ដោយ `ptr` ឱ្យសមនឹងប្លង់ថ្មី។
    ///
    /// ប្រសិនបើនេះត្រឡប់ `Ok`, បន្ទាប់មកបានភាពជាម្ចាស់នៃប្លុកសតិដែលបានយោងដោយ `ptr` ត្រូវបានបញ្ជូនទៅការបែងចែកនេះ។
    /// ការចងចាំអាចឬមិនអាចត្រូវបានដោះលែងឱ្យមានសេរីភាព, និងគួរតែត្រូវបានចាត់ទុកជាមិនអាចប្រើបានលុះត្រាតែវាត្រូវបានផ្ទេរទៅអ្នកទូរស័ព្ទចូលជាថ្មីម្តងទៀតតាមរយៈការត្រឡប់តម្លៃនៃវិធីសាស្រ្តនេះ។
    ///
    /// ប្រសិនបើមានវិធីសាស្រ្តនេះត្រឡប់ `Err` កម្មសិទ្ធិបន្ទាប់មកនៃប្លុកសតិមិនត្រូវបានផ្ទេរទៅឱ្យបែងចែកនេះនិងមាតិការបស់ប្លុកសតិគឺ unaltered ។
    ///
    /// # Safety
    ///
    /// * `ptr` ត្រូវតែបញ្ជាក់ប្លុករបស់សតិ [*currently allocated*] មួយតាមរយៈការបែងចែកនេះ។
    /// * `old_layout` ត្រូវតែ [*fit*] ថាប្លុករបស់សតិ (អាគុយម៉ង់ `new_layout` តម្រូវមិនសមនឹងវា។) ។
    /// * `new_layout.size()` ត្រូវតែតូចជាងឬស្មើ `old_layout.size()` ។
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// ត្រឡប់ `Err` ប្រសិនបើប្លង់ថ្មីមិនត្រូវនឹងទំហំរបស់អ្នកបែងចែកនិងឧបសគ្គតម្រឹមរបស់អ្នកបែងចែកឬបើបង្រួមបើមិនដូច្នេះទេបរាជ័យ។
    ///
    /// ការប្រតិបត្តិត្រូវបានលើកទឹកចិត្តឱ្យវិលត្រឡប់មកវិញនៅលើការអស់កម្លាំងការចងចាំ `Err` ជាងការភ័យខ្លាចឬជាបោះបង់ប៉ុន្តែនេះមិនមែនជាតម្រូវការយ៉ាងតឹងរឹង។
    /// (ជាពិសេសៈវាជាការស្របច្បាប់ * ដើម្បីអនុវត្ត trait នេះនៅលើបណ្ណាល័យបែងចែកមូលដ្ឋានដែលបានបញ្ឈប់ការអស់កម្លាំងសតិ។)
    ///
    /// អតិថិជនដែលមានបំណងបោះបង់ចោលការគណនាក្នុងការឆ្លើយតបទៅនឹងកំហុសនៃការបែងចែកត្រូវបានលើកទឹកចិត្តឱ្យហៅមុខងារ [`handle_alloc_error`] ជាជាងការហៅដោយផ្ទាល់ `panic!` ឬស្រដៀងគ្នា។
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // សុវត្ថិភាព: ពីព្រោះ `new_layout.size()` ត្រូវតែទាបជាងឬស្មើ
        // `old_layout.size()`, ទាំងការបែងចែកសតិចាស់និងថ្មីមានសុពលភាពសម្រាប់ការអាននិងសរសេរសម្រាប់ `new_layout.size()` បៃ។
        // ដូចគ្នានេះផងដែរដោយសារតែការបែងចែកចាស់មិនទាន់ត្រូវបានដោះស្រាយវាមិនអាចត្រួតលើ `new_ptr` បានទេ។
        // ដូច្នេះការហៅទៅ `copy_nonoverlapping` គឺមានសុវត្ថិភាព។
        // កិច្ចសន្យាសុវត្ថិភាពសម្រាប់ `dealloc` ត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// បង្កើតអាដាប់ទ័រ "by reference" សម្រាប់ឧទាហរណ៍នៃ `Allocator` នេះ។
    ///
    /// អាដាប់ធ័រត្រឡប់មកវិញអនុវត្ត `Allocator` ហើយជាធម្មតានឹងខ្ចីនេះ។
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}