use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// ខណៈពេលដែលមុខងារនេះត្រូវបានប្រើនៅមួយកន្លែងនិងការអនុវត្តន៍របស់ខ្លួនអាចត្រូវបាន inlined ការព្យាយាមពីមុនដើម្បីធ្វើដូច្នេះបាន rustc យឺតបានបង្កើតឡើង:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// ប្លង់នៃប្លុកនៃការចងចាំ។
///
/// ឧទាហរណ៍នៃ `Layout` ពិពណ៌នាអំពីប្លង់ជាក់លាក់នៃអង្គចងចាំ។
/// អ្នកបង្កើត `Layout` ឡើងជាធាតុបញ្ចូលដើម្បីផ្តល់ដល់អ្នកបែងចែក។
///
/// ប្លង់ទាំងអស់មានទំហំពាក់ព័ន្ធនិងការតម្រឹមស្វ័យគុណ ២ ។
///
/// (ចំណាំថាប្លង់គឺមិន * តម្រូវឱ្យមានទំហំមិនមែនសូន្យនោះទេទោះបីជា `GlobalAlloc` តម្រូវថារាល់ការស្នើសុំសតិមិនមានទំហំសូន្យក៏ដោយ។
/// អ្នកទូរស័ព្ទចូលត្រូវតែធានាឱ្យបានទាំងថាលក្ខខណ្ឌដូចនេះគឺត្រូវបានជួបប្រជុំគ្នា, ពួកអ្នកវិនិយោគទុនការប្រើជាក់លាក់ជាមួយនឹងតម្រូវការមានសភាពយារធ្លាក់ឬប្រើចំណុចប្រទាក់ `Allocator` អត់ឱនកាន់តែច្រើន។)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // ទំហំនៃប្លុកដែលបានស្នើសុំនៃការចងចាំ, វាស់ជាបៃ។
    size_: usize,

    // តម្រឹមនៃប្លុកដែលបានស្នើសុំនៃការចងចាំ, វាស់ជាបៃ។
    // យើងធានាថានេះគឺតែងតែជាអំណាចនៃពីរនាក់, ដោយសារតែដូច `posix_memalign` របស់ API របស់វាហើយវាតម្រូវឱ្យមានជាឧបសគ្គសមហេតុផលគឺដើម្បីប្រើប្រាស់នៅលើផលិតប្លង់។
    //
    //
    // (ទោះយ៉ាងណាក៏ដោយយើងមិនតម្រូវឱ្យមានការតំរឹមប្រហាក់ប្រហែល `តម្រឹម>=X០០X ទេ
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// សង់ `Layout` ពី `size` និង `align` ដែលបានផ្តល់ឬត្រឡប់ `LayoutError` ប្រសិនបើមានលក្ខខណ្ឌដូចខាងក្រោមមិនត្រូវបានបំពេញ៖
    ///
    /// * `align` មិនត្រូវសូន្យ
    ///
    /// * `align` ត្រូវតែជាអំណាចពីរ
    ///
    /// * `size`, នៅពេលដែលបង្គត់ឡើងទៅពហុគុណជិតបំផុតនៃ `align`, មិនត្រូវលើសចំណុះ (ពោលគឺតម្លៃមានរាងមូលត្រូវតែតិចជាងឬស្មើទៅនឹង `usize::MAX`) ។
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (អំណាចនៃពីរបង្កប់ន័យតម្រឹម!=០)

        // ទំហំមូលគឺ៖
        //   size_rounded_up=(ទំហំ + តម្រឹម ១)&! (តម្រឹម ១);
        //
        // យើងដឹងពីអ្វីដែលបានរៀបរាប់ខាងលើ!=០ ។
        // ប្រសិនបើបន្ថែម (តម្រឹមទី ១) មិនហៀរទឹកទេដូច្នេះការប្រមូលផ្តុំជុំនឹងល្អ។
        //
        // ផ្ទុយទៅវិញ&-masking ជាមួយ! (តម្រឹម ១) នឹងដកតែប៊ីតលំដាប់ទាបប៉ុណ្ណោះ។
        // ដូច្នេះប្រសិនបើកើតឡើងជាមួយនឹងលើសចំណុះបូកនេះ&-mask មិនអាចដកគ្រប់គ្រាន់ដើម្បីមិនធ្វើលើសចំណុះនោះ។
        //
        //
        // ខាងលើនេះបញ្ជាក់ថាការពិនិត្យមើលការបូកសរុបគឺចាំបាច់និងគ្រប់គ្រាន់។
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // សុវត្ថិភាព: លក្ខខណ្ឌសម្រាប់ `from_size_align_unchecked` បានហើយ
        // គូសធីកខាងលើ។
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// បង្កើតប្លង់មួយដោយឆ្លងកាត់ការត្រួតពិនិត្យទាំងអស់។
    ///
    /// # Safety
    ///
    /// មុខងារនេះមិនមានសុវត្ថិភាពទេព្រោះវាមិនបានបញ្ជាក់ពីលក្ខខណ្ឌមុនពី [`Layout::from_size_align`] ទេ។
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាឱ្យបានថា `align` គឺធំជាងសូន្យ។
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ទំហំអប្បបរមាគិតជាបៃសម្រាប់ប្លុកសតិនៃប្លង់នេះ។
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ការតម្រឹមបៃអប្បបរមាសម្រាប់ប្លុកសតិនៃប្លង់នេះ។
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// សង់ `Layout` មួយសមរម្យសម្រាប់តម្លៃនៃប្រភេទកាន់មួយ `T` ។
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // សុវត្ថិភាព: ការតំរឹមត្រូវបានធានាដោយ Rust ថាជាថាមពលពីរនិង
        // បន្សំទំហំ + + តម្រឹមត្រូវបានធានាដើម្បីឱ្យសមនៅក្នុងចន្លោះអាសយដ្ឋានរបស់យើង។
        // ជាលទ្ធផលអ្នកបង្កើតមិនបានធីកយកប្រើនៅទីនេះដើម្បីជៀសវាងការបញ្ចូលកូដដែល panics ប្រសិនបើវាមិនត្រូវបានធ្វើឱ្យប្រសើរផងដែរគ្រប់គ្រាន់។
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ផលិតប្លង់ពិពណ៌នាអំពីកំណត់ត្រាដែលអាចត្រូវបានប្រើដើម្បីបម្រុងទុករចនាសម្ព័ន្ធខាងក្រោយសម្រាប់ `T` (ដែលអាចជាប្រភេទ trait ឬប្រភេទផ្សេងទៀតដែលមិនត្រូវបានគេស្គាល់ដូចជាចំណិត) ។
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // សុវត្ថិភាព: សូមមើលហេតុផលនៅក្នុង `new` សម្រាប់មូលហេតុដែលការប្រើប្រាស់វ៉ារ្យ៉ង់គ្មានសុវត្ថិភាព
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// ផលិតប្លង់ពិពណ៌នាអំពីកំណត់ត្រាដែលអាចត្រូវបានប្រើដើម្បីបម្រុងទុករចនាសម្ព័ន្ធខាងក្រោយសម្រាប់ `T` (ដែលអាចជាប្រភេទ trait ឬប្រភេទផ្សេងទៀតដែលមិនត្រូវបានគេស្គាល់ដូចជាចំណិត) ។
    ///
    /// # Safety
    ///
    /// មុខងារនេះមានសុវត្ថភាពក្នុងការហៅទូរស័ព្ទប្រសិនបើលក្ខខណ្ឌខាងក្រោមមានៈ
    ///
    /// - ប្រសិនបើ `T` គឺជា `Sized` មុខងារនេះគឺមានសុវត្ថិភាពក្នុងការហៅ។
    /// - ប្រសិនបើកន្ទុយដែលមិនបានបញ្ជាក់របស់ `T` គឺ៖
    ///     - [slice] បន្ទាប់មកប្រវែងនៃកន្ទុយដាច់ត្រូវតែជាចំនួនគត់ដែលត្រូវគ្នានិងទំហំនៃ *តម្លៃទាំងមូល*(ប្រវែងកន្ទុយថាមវន្ត + បុព្វបទមានទំហំតាមស្ថិតិ) ត្រូវតែសមនឹង `isize` ។
    ///     - [trait object] បន្ទាប់មកផ្នែកតុរប្យួរនៃទ្រនិចត្រូវចង្អុលទៅតុត្រឹមត្រូវសម្រាប់ប្រភេទ `T` ដែលទទួលបានដោយការដាក់បញ្ចូលមិនត្រឹមត្រូវហើយទំហំនៃតម្លៃ *ទាំងមូល*(ប្រវែងកន្ទុយថាមវន្ត + បុព្វបទមានទំហំតាមស្ថិតិ) ត្រូវតែសមនឹង `isize` ។
    ///
    ///     - មួយ (unstable) [extern type] បន្ទាប់មកមុខងារនេះគឺតែងតែមានសុវត្ថិភាពក្នុងការហៅទូរស័ព្ទប៉ុន្តែ panic ឬបើមិនដូច្នេះអាចនឹងវិលត្រឡប់មកវិញតម្លៃខុសដែលជាប្លង់ប្រភេទខាងក្រៅត្រូវបានមិនស្គាល់។
    ///     នេះជាឥរិយាបទដូចគ្នា [`Layout::for_value`] លើសេចក្ដីយោងទៅប្រភេទកន្ទុយខាងក្រៅមួយ។
    ///     - បើមិនដូច្នោះទេវាមិនត្រូវបានអនុញ្ញាតឱ្យហៅមុខងារនេះទេ។
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // សុវត្ថិភាព: យើងឆ្លងកាត់តម្រូវការជាមុននៃមុខងារទាំងនេះទៅអ្នកទូរស័ព្ទចូល
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // សុវត្ថិភាព: សូមមើលហេតុផលនៅក្នុង `new` សម្រាប់មូលហេតុដែលការប្រើប្រាស់វ៉ារ្យ៉ង់គ្មានសុវត្ថិភាព
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// បង្កើត `NonNull` មួយដែលកំពុងញាប់ញ័រប៉ុន្តែត្រូវបានតម្រឹមយ៉ាងល្អសម្រាប់ប្លង់នេះ។
    ///
    /// ចំណាំថាតម្លៃនេះមានសក្តានុពលអាចនឹងព្រួញដែលមានទស្សន៍ទ្រនិចដែលមានសុពលភាពតំណាងដែលមានន័យថាត្រូវតែមិនត្រូវបានប្រើនេះជាតម្លៃ "not yet initialized" មួយពេទ្យ។
    /// ប្រភេទដែលត្រូវតាមដានការបម្រុងទុក lazily ដោយមធ្យោបាយការចាប់ផ្ដើមមួយចំនួនផ្សេងទៀត។
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // សុវត្ថិភាព: តម្រឹមត្រូវបានធានាថាមិនមែនសូន្យ
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// បង្កើតប្លង់ដែលអធិប្បាយអំពីកំណត់ត្រាដែលអាចកាន់ប្លង់តម្លៃថាជា `self` ដូចគ្នានេះមួយ, ប៉ុន្តែនោះផងដែរត្រូវបានតម្រឹមទៅតម្រឹម `align` (បានវាស់គិតជាបៃ) ។
    ///
    ///
    /// ប្រសិនបើ `self` ឆ្លើយតបនឹងការតម្រឹមតាមវេជ្ជបញ្ជារួចហើយត្រឡប់ `self` ។
    ///
    /// ចំណាំថាវិធីសាស្រ្តនេះមិនបន្ថែមចន្លោះណាមួយទៅនឹងទំហំទូទៅទេដោយមិនគិតថាប្លង់ដែលបានត្រឡប់មកវិញមានការតម្រឹមខុសគ្នាទេ។
    /// និយាយម្យ៉ាងទៀតប្រសិនបើ `K` មានទំហំ 16 នោះ `K.align_to(32)` នឹងនៅតែ * នៅតែមានទំហំ 16 ដដែល។
    ///
    /// ត្រឡប់កំហុសប្រសិនបើការរួមបញ្ចូលគ្នានៃ `self.size()` និង `align` ដែលបានផ្តល់ឱ្យរំលោភលើលក្ខខណ្ឌដែលបានរាយនៅក្នុង [`Layout::from_size_align`] ។
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// ត្រឡប់ចំនួនចន្លោះដែលយើងត្រូវបញ្ចូលបន្ទាប់ពី `self` ដើម្បីធានាថាអាសយដ្ឋានខាងក្រោមនឹងពេញចិត្ត `align` (វាស់ជាបៃ) ។
    ///
    /// ឧទាហរណ៍ប្រសិនបើ `self.size()` មានលេខ 9 នោះ `self.padding_needed_for(4)` ត្រឡប់ 3 ពីព្រោះនោះជាចំនួនបៃអប្បបរមានៃសន្លឹកដែលត្រូវការដើម្បីទទួលបានអាស័យដ្ឋាន 4 ជួរ (សន្មតថាប្លុកសតិដែលត្រូវគ្នាចាប់ផ្តើមនៅអាសយដ្ឋានតម្រឹម 4) ។
    ///
    ///
    /// តម្លៃត្រឡប់នៃមុខងារនេះគ្មានន័យទេប្រសិនបើ `align` មិនមែនជាថាមពលនៃពីរ។
    ///
    /// ចំណាំថាឧបករណ៍ប្រើប្រាស់នៃតម្លៃដែលបានត្រឡប់មកវិញនោះតម្រូវឱ្យមានការ `align` ត្រូវបានតិចជាងឬស្មើទៅនឹងការតម្រឹមនៃអាសយដ្ឋានចាប់ផ្តើមការត្រៀមបម្រុងទុកសម្រាប់ប្លុករបស់សតិនេះទាំងមូល។វិធីមួយដើម្បីបំពេញឧបសគ្គនេះគឺដើម្បីធានា `align <= self.align()` ។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // តម្លៃមូលគឺ៖
        //   len_rounded_up=(តម្រឹម Len + 1)&(តម្រឹម 1)!
        // ហើយបន្ទាប់មកយើងត្រលប់មកវិញនូវភាពខុសគ្នា `len_rounded_up - len`.
        //
        // យើងប្រើនព្វន្ធម៉ូឌុលពាសពេញ៖
        //
        // 1. តម្រឹមត្រូវបានធានាថាជា> ០ ដូច្នេះការតំរឹម ១ តែងតែមានសុពលភាព។
        //
        // 2.
        // `len + align - 1` អាចហៀរចេញដោយភាគច្រើន `align - 1` ដូច្នេះអេម៉ាម៉ាជាមួយ `!(align - 1)` នឹងធានាថាក្នុងករណីដែលលើសចំណុះ `len_rounded_up` ខ្លួនវានឹងមាន 0 ។
        //
        //    ដូច្នេះចន្លោះត្រឡប់មកវិញ, នៅពេលដែលបានបន្ថែមទៅ `len` ទិន្នផល 0 ដែលតូចតាចតម្រឹម `align` ការពេញចិត្ត។
        //
        // (ជាការពិតណាស់ការព្យាយាមក្នុងការបម្រុងទុកប្លុករបស់សតិដែលមានទំហំនិងលើសចំណុះចន្លោះក្នុងលក្ខណៈខាងលើនេះគួរបង្កឱ្យមានការបែងចែកនេះដើម្បីផលកំហុសមួយទេ។)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// បង្កើតប្លង់ដោយបង្គត់ទំហំនៃប្លង់នេះឡើងដើម្បីជាច្រើននៃការតម្រឹមប្លង់នោះមួយ។
    ///
    ///
    /// នេះស្មើនឹងការបន្ថែមលទ្ធផលនៃ `padding_needed_for` ទៅទំហំបច្ចុប្បន្ននៃប្លង់។
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // នេះមិនអាចហៀរចេញបានទេ។ដកស្រង់ចេញពីភាពមិនធម្មតានៃប្លង់៖
        // > `size`, នៅពេលដែលបង្គត់ឡើងទៅពហុគុណជិតបំផុតនៃ `align`,
        // > មិនត្រូវហៀរចេញ (ឧ។ តម្លៃមូលត្រូវតែតិចជាង
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// បង្កើតប្លង់ពិពណ៌នាអំពីកំណត់ត្រាសម្រាប់ករណី `n` នៃ `self` ដែលមានទំហំទ្រនាប់សមស្របរវាងចន្លោះនីមួយៗដើម្បីធានាថាវត្ថុនីមួយៗត្រូវបានផ្តល់ទំហំនិងការតម្រឹមរបស់វា។
    /// នៅលើភាពជោគជ័យត្រឡប់ `(k, offs)` ដែល `k` គឺជាប្លង់នៃអារេហើយ `offs` គឺជាចំងាយរវាងការចាប់ផ្តើមនៃធាតុនីមួយៗនៅក្នុងអារេ។
    ///
    /// នៅលើការលើសចំណុះនព្វន្ធត្រឡប់ `LayoutError` ។
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // នេះមិនអាចហៀរចេញបានទេ។ដកស្រង់ចេញពីភាពមិនធម្មតានៃប្លង់៖
        // > `size`, នៅពេលដែលបង្គត់ឡើងទៅពហុគុណជិតបំផុតនៃ `align`,
        // > មិនត្រូវហៀរចេញ (ឧ។ តម្លៃមូលត្រូវតែតិចជាង
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // សុវត្ថិភាព: self.align ត្រូវបានគេស្គាល់រួចហើយដើម្បីឱ្យមានសុពលភាពនិង alloc_size បាន
        // padded រួចទៅហើយ។
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// បង្កើតប្លង់ពិពណ៌នាអំពីកំណត់ត្រាសម្រាប់ `self` អមដោយ `next` រួមទាំងទ្រនាប់ដែលចាំបាច់ដើម្បីធានាថា `next` នឹងត្រូវបានតម្រឹមត្រឹមត្រូវប៉ុន្តែ *គ្មានចន្លោះទ្រនាប់* ទេ។
    ///
    /// ដើម្បីផ្គូផ្គងប្លង់តំណាងស៊ីអ៊ិច `repr(C)` អ្នកគួរតែហៅ `pad_to_align` បន្ទាប់ពីពង្រីកប្លង់ជាមួយគ្រប់វាល។
    /// (មានវិធីដើម្បីផ្គូផ្គងលំនាំដើម Rust ប្លង់តំណាងទេគឺ `repr(Rust)`, as it is unspecified.)
    ///
    /// ចំណាំថាការតម្រឹមប្លង់លទ្ធផលនឹងជាចំនួនអតិបរិមានៃ `self` និង `next` ដើម្បីធានាការតម្រឹមផ្នែកទាំងពីរ។
    ///
    /// ត្រឡប់ `Ok((k, offset))` ដែល `k` គឺជាប្លង់នៃកំណត់ត្រាដែលបានតគ្នានិង `offset` គឺជាទីតាំងដែលទាក់ទងជាបៃនៃការចាប់ផ្តើមនៃ `next` ដែលបានបង្កប់នៅក្នុងកំណត់ត្រាដែលបានសន្និដ្ឋាន (សន្មតថាកំណត់ត្រាខ្លួនវាចាប់ផ្តើមនៅអុហ្វសិត 0) ។
    ///
    ///
    /// នៅលើការលើសចំណុះនព្វន្ធត្រឡប់ `LayoutError` ។
    ///
    /// # Examples
    ///
    /// ដើម្បីគណនាប្លង់នៃរចនាសម្ព័ន្ធ `#[repr(C)]` និងអុហ្វសិតនៃវាលពីប្លង់របស់វា។
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // កុំភ្លេចបញ្ចប់ជាមួយ `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // សាកល្បងថាវាដំណើរការ
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// បង្កើតប្លង់ពិពណ៌នាអំពីកំណត់ត្រាសម្រាប់ករណី `n` នៃ `self` ដោយគ្មានចន្លោះរវាងវត្ថុនីមួយៗ។
    ///
    /// ចំណាំថាមិនដូច `repeat`, `repeat_packed` មិនធានាថាករណីម្តងហើយម្តងទៀតនៃ `self` នឹងត្រូវបានតម្រឹមឱ្យបានត្រឹមត្រូវបើទោះបីជាឧទាហរណ៍ដែលបានផ្ដល់ `self` ត្រូវបានតម្រឹមត្រឹមត្រូវ។
    /// នៅក្នុងពាក្យផ្សេងទៀតប្រសិនបើប្លង់ត្រឡប់ដោយ `repeat_packed` ត្រូវបានប្រើដើម្បីបម្រុងទុកអារេមួយ, វាមិនត្រូវបានធានាថាធាតុទាំងអស់នៅក្នុងអារេដែលនឹងត្រូវបានតម្រឹមត្រឹមត្រូវ។
    ///
    /// នៅលើការលើសចំណុះនព្វន្ធត្រឡប់ `LayoutError` ។
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// បង្កើតប្លង់ដែលពិពណ៌នាអំពីកំណត់ត្រាសម្រាប់ `self` អមដោយ `next` ដោយគ្មានចន្លោះបន្ថែមទៀតរវាងពីរ។
    /// ដោយសារមិនមានការបញ្ចូលទ្រនាប់ភ្ជាប់ទេការតម្រឹមរបស់ `next` គឺមិនពាក់ព័ន្ធហើយមិនត្រូវបានដាក់បញ្ចូល *ទាល់តែសោះ* ទៅក្នុងប្លង់លទ្ធផល។
    ///
    ///
    /// នៅលើការលើសចំណុះនព្វន្ធត្រឡប់ `LayoutError` ។
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// បង្កើតប្លង់ពិពណ៌នាអំពីកំណត់ត្រាសម្រាប់ `[T; n]` ។
    ///
    /// នៅលើការលើសចំណុះនព្វន្ធត្រឡប់ `LayoutError` ។
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// ប៉ារ៉ាម៉ែត្រដែលបានផ្ដល់ឱ្យ `Layout::from_size_align` ឬអ្នកបង្កើត `Layout` មួយចំនួនផ្សេងទៀតមិនបានបំពេញឧបសគ្គបានចងក្រងជាឯកសាររបស់ខ្លួន។
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (យើងត្រូវការនេះសម្រាប់ impl ខ្សែទឹកខាងក្រោមនៃកំហុស trait)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}