//! ការផ្លាស់ប្តូរតួអក្សរ។

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// បម្លែង `u32` ដើម្បី `char` មួយ។
///
/// ចំណាំថា [`char`] ទាំងអស់មានសុពលភាព [`u32`] ហើយអាចត្រូវបានបោះទៅមួយ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ទោះយ៉ាងណាការបញ្ច្រាសគឺមិនពិតទេ៖ មិនត្រឹមត្រូវទេ [`u32`] ទាំងអស់គឺត្រឹមត្រូវ [`char`] ។
/// `from_u32()` នឹងត្រឡប់ `None` ប្រសិនបើការបញ្ចូលមិនមែនជាតម្លៃត្រឹមត្រូវសម្រាប់ [`char`] ។
///
/// ចំពោះកំណែគ្មានសុវត្ថិភាពនៃមុខងារនេះដែលមិនអើពើនឹងការត្រួតពិនិត្យទាំងនេះសូមមើល [`from_u32_unchecked`] ។
///
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// ការវិលត្រឡប់មក `None` ពេលបញ្ចូលគឺមិនមែនជា [`char`] ត្រឹមត្រូវ:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// បំលែង `u32` ទៅ `char` ដោយមិនអើពើសុពលភាព។
///
/// ចំណាំថា [`char`] ទាំងអស់មានសុពលភាព [`u32`] ហើយអាចត្រូវបានបោះទៅមួយ
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// ទោះយ៉ាងណាការបញ្ច្រាសគឺមិនពិតទេ៖ មិនត្រឹមត្រូវទេ [`u32`] ទាំងអស់គឺត្រឹមត្រូវ [`char`] ។
/// `from_u32_unchecked()` នឹងមិនអើពើនេះ, ហើយបោះទៅ [`char`] ដឹងអ្វីសោះ, អាចធ្វើទៅបានបង្កើតមិនត្រឹមត្រូវមួយ។
///
///
/// # Safety
///
/// មុខងារនេះមិនមានសុវត្ថិភាពទេព្រោះវាអាចបង្កើតតម្លៃ `char` មិនត្រឹមត្រូវ។
///
/// សម្រាប់កំណែដែលមានសុវត្ថិភាពនៃមុខងារនេះសូមមើលមុខងារ [`from_u32`] ។
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // សុវត្ថិភាព: អ្នកទូរស័ព្ទចូលត្រូវតែធានាថា `i` គឺជាតម្លៃសាកត្រឹមត្រូវ។
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// បំលែង [`char`] ទៅជា [`u32`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// បំលែង [`char`] ទៅជា [`u64`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // ឆនំត្រូវបានបោះទៅតម្លៃនៃចំណុចកូដបន្ទាប់មកសូន្យដល់ ៦៤ ប៊ីត។
        // មើល [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// បំលែង [`char`] ទៅជា [`u128`] ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // char ត្រូវបានបោះទៅតម្លៃនៃចំនុចកូដបន្ទាប់មកសូន្យដល់ ១២៨ ប៊ីត។
        // មើល [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// ផែនទីបៃក្នុង 0x00=0xFF ទៅ .. ដែលមានលេខកូដចំណុច `char` តម្លៃដូចគ្នានេះដែរដែលមាននៅក្នុងការ U + 0000 + + ..=00FF មួយលោក U ។
///
/// យូនីកូដត្រូវបានរចនាឡើងដូច្នេះវាអាចឌិកូដបៃជាមួយនឹងការអ៊ិនកូដតួអក្សរដែល IANA ហៅថា ISO-8859-1 ។
/// ការអ៊ិនកូដនេះគឺត្រូវគ្នាជាមួយ ASCII ។
///
/// ចំណាំថានេះគឺខុសគ្នាពី ISO/IEC 8859-1 អាកា
/// ISO 8859-1 (ដោយសហសញ្ញាតិចមួយ), ដែលទុក "blanks" តម្លៃបៃមួយចំនួនដែលមិនត្រូវបានផ្ដល់ទៅឱ្យតួអក្សរណាមួយ។
/// អាយអេសអូ-៨៨៥៩-១ (អាយ។ អេ។ អេ។ អេន។ អេន) ប្រគល់ឱ្យពួកគេនូវលេខកូដ C0 និង C1
///
/// ចំណាំថានេះក៏ * ខុសគ្នាពីវីនដូ-១២៥២ អាកដែរ
/// លេខកូដទំព័រ ១២៥២ ដែលជាអក្សរតូចធំ ISO/IEC ៨៨៥៩-១ ដែលផ្តល់ចន្លោះទទេ (មិនមែនទាំងអស់) ចំពោះការដាក់វណ្ណយុត្តិនិងតួអក្សរឡាតាំងផ្សេងៗ។
///
/// ដើម្បីច្រឡំរឿងបន្ថែមទៀត [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1`, និង `windows-1252` សុទ្ធតែជាឈ្មោះក្លែងក្លាយសម្រាប់ប្រព័ន្ធវីនដូ ១២៥២ ដែលបំពេញចន្លោះទទេដែលនៅសល់ជាមួយលេខកូដបញ្ជា C0 និង C1 ដែលត្រូវគ្នា។
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// បម្លែង [`u8`] ចូលទៅក្នុង [`char`] មួយ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// កំហុសដែលអាចត្រូវបានត្រឡប់នៅពេលញែក char ។
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // សុវត្ថិភាព: គូសធីកវាជាតម្លៃយូនីកូដផ្នែកច្បាប់
            Ok(unsafe { transmute(i) })
        }
    }
}

/// ប្រភេទកំហុសបានត្រឡប់ពេលការបម្លែងពី u32 ទៅតួអក្សរបរាជ័យ។
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// បម្លែងខ្ទង់ក្នុងគោលស្មើដែលបានផ្តល់ទៅឱ្យ `char` មួយ។
///
/// មួយពេលខ្លះត្រូវនៅទីនេះ 'radix' គេហៅថា 'base' មួយផងដែរ។
/// កាំនៃលេខពីរបង្ហាញលេខគោលពីរកាំដប់ដប់គោលដប់និងដប់ប្រាំមួយដប់ប្រាំមួយគុណលេខគោលដប់ប្រាំមួយដើម្បីផ្តល់តម្លៃរួមមួយចំនួន។
///
/// រ៉ាឌីកាល់ដែលបំពានត្រូវបានគាំទ្រ។
///
/// `from_digit()` នឹងត្រឡប់ `None` ប្រសិនបើមានការបញ្ចូលគឺមិនខ្ទង់ក្នុងគោលស្មើដែលបានផ្តល់ឱ្យនោះទេ។
///
/// # Panics
///
/// Panics ប្រសិនបើបានផ្តល់ជាកាំធំជាង ៣៦ ។
///
/// # Examples
///
/// ការប្រើប្រាស់មូលដ្ឋាន៖
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // លេខ ១១ ជាខ្ទង់តែមួយនៅក្នុងគោល ១៦
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// ការវិលត្រឡប់មក `None` ពេលបញ្ចូលគឺមិនខ្ទង់មួយ:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// ឆ្លងកាត់ជាគោលស្មើធំបណ្តាលឱ្យ panic មួយ:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}