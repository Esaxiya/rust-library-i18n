//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// ចំណុចកូដដែលមានសុពលភាពខ្ពស់បំផុតដែល `char` អាចមាន។
    ///
    /// `char` គឺជា [Unicode Scalar Value] ដែលមានន័យថាវាគឺជា [Code Point] ប៉ុន្តែមានតែនៅក្នុងជួរជាក់លាក់ប៉ុណ្ណោះ។
    /// `MAX` គឺជាលេខកូដដែលមានសុពលភាពខ្ពស់បំផុតដែលជា [Unicode Scalar Value] ត្រឹមត្រូវ។
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () ត្រូវបានប្រើក្នុងយូនីកូដដើម្បីតំណាងឱ្យការឌិកូដកំហុស។
    ///
    /// វាអាចកើតមានឡើងជាឧទាហរណ៍នៅពេលដែលបានផ្តល់ឱ្យបង្កើត UTF-8 ឈឺទៅ [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy) បៃ។
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// កំណែ [Unicode](http://www.unicode.org/) ដែលផ្នែកយូនីកូដនៃវិធីសាស្ត្រ `char` និង `str` ត្រូវបានផ្អែកលើ។
    ///
    /// កំណែថ្មីនៃយូនីកូដត្រូវបានចេញផ្សាយទៀងទាត់និងជាបន្តបន្ទាប់វិធីសាស្រ្តទាំងអស់នៅក្នុងបណ្ណាល័យស្ដង់ដារអាស្រ័យលើយូនីកូដត្រូវបានធ្វើឱ្យទាន់សម័យ។
    /// ដូច្នេះឥរិយាបថរបស់វិធីសាស្រ្ត `char` និង `str` មួយចំនួននិងតម្លៃនៃការផ្លាស់ប្តូរនេះជាថេរលើពេលវេលា។
    /// នេះមិនមែន * ត្រូវបានគេចាត់ទុកថាជាការផ្លាស់ប្តូរបំបែកទេ។
    ///
    /// គ្រោងការណ៍លេខរៀងកំណែត្រូវបានពន្យល់ជា [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ។
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// បង្កើត iterator ទៅលើ UTF-16 នេះបានអ៊ិនកូដពិន្ទុកូដនៅក្នុង `iter` ត្រឡប់ពាក្យកាត់ដែលមិនមែនគូដែលជា `Err`s ។
    ///
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// ឧបករណ៍ឌិកូដដែលបាត់បង់អាចទទួលបានដោយជំនួសលទ្ធផល `Err` ជាមួយនឹងតួអក្សរជំនួស៖
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// បម្លែង `u32` ដើម្បី `char` មួយ។
    ///
    /// ចំណាំថា `សាកទាំងអស់មានសុពលភាព [` u32 `] ហើយអាចត្រូវបានបោះទៅមួយ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ទោះយ៉ាងណាការបញ្ច្រាសនេះមិនមែនជាការពិតទេ៖ មិនមែនទាំងអស់ [`u32`] មានសុពលភាពទេ។
    /// `from_u32()` នឹងត្រឡប់ `None` ប្រសិនបើការបញ្ចូលមិនមែនជាតម្លៃត្រឹមត្រូវសម្រាប់ `char` ។
    ///
    /// ចំពោះកំណែគ្មានសុវត្ថិភាពនៃមុខងារនេះដែលមិនអើពើនឹងការត្រួតពិនិត្យទាំងនេះសូមមើល [`from_u32_unchecked`] ។
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ត្រឡប់ `None` ពេលបញ្ចូលមិនមែនជា `char` ត្រឹមត្រូវ៖
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// បំលែង `u32` ទៅ `char` ដោយមិនអើពើសុពលភាព។
    ///
    /// ចំណាំថា `សាកទាំងអស់មានសុពលភាព [` u32 `] ហើយអាចត្រូវបានបោះទៅមួយ
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// ទោះយ៉ាងណាការបញ្ច្រាសនេះមិនមែនជាការពិតទេ៖ មិនមែនទាំងអស់ [`u32`] មានសុពលភាពទេ។
    /// `from_u32_unchecked()` នឹងមិនអើពើនឹងនេះហើយបោះចោលទៅជា `char` ដោយអាចបង្កើតជាលេខដែលមិនត្រឹមត្រូវ។
    ///
    ///
    /// # Safety
    ///
    /// មុខងារនេះមិនមានសុវត្ថិភាពទេព្រោះវាអាចបង្កើតតម្លៃ `char` មិនត្រឹមត្រូវ។
    ///
    /// សម្រាប់កំណែដែលមានសុវត្ថិភាពនៃមុខងារនេះសូមមើលមុខងារ [`from_u32`] ។
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // សុវត្ថិភាព: កិច្ចសន្យាសុវត្ថិភាពត្រូវតែត្រូវបានគាំទ្រដោយអ្នកទូរស័ព្ទចូល។
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// បម្លែងខ្ទង់ក្នុងគោលស្មើដែលបានផ្តល់ទៅឱ្យ `char` មួយ។
    ///
    /// មួយពេលខ្លះត្រូវនៅទីនេះ 'radix' គេហៅថា 'base' មួយផងដែរ។
    /// កាំនៃលេខពីរបង្ហាញលេខគោលពីរកាំដប់ដប់គោលដប់និងដប់ប្រាំមួយដប់ប្រាំមួយគុណលេខគោលដប់ប្រាំមួយដើម្បីផ្តល់តម្លៃរួមមួយចំនួន។
    ///
    /// រ៉ាឌីកាល់ដែលបំពានត្រូវបានគាំទ្រ។
    ///
    /// `from_digit()` នឹងត្រឡប់ `None` ប្រសិនបើមានការបញ្ចូលគឺមិនខ្ទង់ក្នុងគោលស្មើដែលបានផ្តល់ឱ្យនោះទេ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើបានផ្តល់ជាកាំធំជាង ៣៦ ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // លេខ ១១ ជាខ្ទង់តែមួយនៅក្នុងគោល ១៦
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ការវិលត្រឡប់មក `None` ពេលបញ្ចូលគឺមិនខ្ទង់មួយ:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ឆ្លងកាត់ជាគោលស្មើធំបណ្តាលឱ្យ panic មួយ:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// ពិនិត្យមើលថាតើ `char` គឺជាខ្ទង់នៅក្នុងកាំដែលបានផ្តល់ឱ្យ។
    ///
    /// មួយពេលខ្លះត្រូវនៅទីនេះ 'radix' គេហៅថា 'base' មួយផងដែរ។
    /// កាំនៃលេខពីរបង្ហាញលេខគោលពីរកាំដប់ដប់គោលដប់និងដប់ប្រាំមួយដប់ប្រាំមួយគុណលេខគោលដប់ប្រាំមួយដើម្បីផ្តល់តម្លៃរួមមួយចំនួន។
    ///
    /// រ៉ាឌីកាល់ដែលបំពានត្រូវបានគាំទ្រ។
    ///
    /// បើប្រៀបធៀបទៅនឹង [`is_numeric()`] មុខងារនេះស្គាល់តែតួអក្សរ `0-9`, `a-z` និង `A-Z` ប៉ុណ្ណោះ។
    ///
    /// 'Digit' ត្រូវបានកំណត់ត្រឹមតែជាតួអក្សរដូចខាងក្រោម៖
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// សម្រាប់ការយល់ដឹងកាន់តែទូលំទូលាយអំពី 'digit' សូមមើល [`is_numeric()`] ។
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើបានផ្តល់ជាកាំធំជាង ៣៦ ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ឆ្លងកាត់ជាគោលស្មើធំបណ្តាលឱ្យ panic មួយ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// បម្លែង `char` មួយទៅខ្ទង់ក្នុងគោលស្មើដែលបានផ្តល់ឱ្យនោះទេ។
    ///
    /// មួយពេលខ្លះត្រូវនៅទីនេះ 'radix' គេហៅថា 'base' មួយផងដែរ។
    /// កាំនៃលេខពីរបង្ហាញលេខគោលពីរកាំដប់ដប់គោលដប់និងដប់ប្រាំមួយដប់ប្រាំមួយគុណលេខគោលដប់ប្រាំមួយដើម្បីផ្តល់តម្លៃរួមមួយចំនួន។
    ///
    /// រ៉ាឌីកាល់ដែលបំពានត្រូវបានគាំទ្រ។
    ///
    /// 'Digit' ត្រូវបានកំណត់ត្រឹមតែជាតួអក្សរដូចខាងក្រោម៖
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// ត្រឡប់ `None` ប្រសិនបើ `char` មិនយោងលើខ្ទង់នៅក្នុងកាំដែលបានផ្តល់ឱ្យ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើបានផ្តល់ជាកាំធំជាង ៣៦ ។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ការឆ្លងកាត់លទ្ធផលមិនខ្ទង់ក្នុងការបរាជ័យ៖
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ឆ្លងកាត់ជាគោលស្មើធំបណ្តាលឱ្យ panic មួយ:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // លេខកូដត្រូវបានបំបែកនៅទីនេះដើម្បីកែលម្អល្បឿនប្រតិបត្តិសម្រាប់ករណីដែល `radix` ថេរនិង ១០ ឬតូចជាងនេះ
        //
        let val = if likely(radix <= 10) {
            // ប្រសិនបើមិនមានខ្ទង់មួយកាន់តែច្រើនចំនួនជាងគោលស្មើនឹងត្រូវបានបង្កើត។
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// ត្រឡប់ទ្រនិចបង្ហាញដែលផ្តល់លទ្ធផលនៃការរត់គេចខ្លួនយូនីកូដជាតួអក្សរ `សាក` ។
    ///
    /// ការនេះនឹងគេចតួអក្សរជាមួយវាក្យសម្ព័ន្ធ Rust នៃ `\u{NNNNNN}` ទម្រង់បែបបទដែលជាកន្លែងដែល `NNNNNN` គឺជាតំណាងប្រព័ន្ធគោលដប់ប្រាំមួយ។
    ///
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // រឺ ing-1 ធានាថាសំរាប់ c==0 លេខកូដគណនាថាលេខមួយខ្ទង់គួរតែត្រូវបានព្រីនហើយ (ដែលដូចគ្នា) ចៀសវៀងពីការហូរ (៣១, ៣២)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // សន្ទស្សន៍នៃខ្ទង់គោលដប់ប្រាំមួយសំខាន់បំផុត
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// កំណែ `escape_debug` ដែលអាចពង្រីកបានដែលអាចអនុញ្ញាតឱ្យជៀសផុតពីចំនុចបន្ថែមនៃហ្គីបផល។
    /// នេះអនុញ្ញាតឱ្យពួកយើងដើម្បីធ្វើទ្រង់ទ្រាយតួអក្សរដែលដូចជាការល្អប្រសើរជាងមុននៅពេលដែលសញ្ញាគ្មានគម្លាតមាននៅពេលចាប់ផ្ដើមពួកគេនៃខ្សែអក្សរមួយ។
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ត្រឡប់ទ្រនិចបង្ហាញដែលផ្តល់នូវកូដរត់គេចខ្លួនតាមព្យញ្ជនៈនៃតួអក្សរដូចជា `សាក` ។
    ///
    /// ការនេះនឹងគេចតួអក្សរស្រដៀងគ្នាទៅនឹងការប្រតិបត្តិ `Debug` នៃ `str` ឬ `char` នេះ។
    ///
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ត្រឡប់ទ្រនិចបង្ហាញដែលផ្តល់នូវកូដរត់គេចខ្លួនតាមព្យញ្ជនៈនៃតួអក្សរដូចជា `សាក` ។
    ///
    /// លំនាំដើមត្រូវបានជ្រើសរើសដោយភាពលំអៀងទៅរកការផលិតអក្សរសាស្ត្រដែលស្របច្បាប់ក្នុងភាសាផ្សេងៗគ្នារួមមាន C++ 11 និងភាសា C-family ស្រដៀងគ្នា។
    /// ច្បាប់ពិតប្រាកដគឺ៖
    ///
    /// * ផ្ទាំងត្រូវបានគេចខ្លួនជា `\t` ។
    /// * ការដឹកត្រឡប់មកវិញត្រូវបានរត់គេចខ្លួនជា `\r` ។
    /// * ខ្សែចំណីត្រូវបានរត់គេចខ្លួនជា `\n` ។
    /// * សម្រង់ទោលត្រូវបានរត់គេចខ្លួនជា `\'` ។
    /// * សម្រង់ពីរដងត្រូវបានរត់គេចខ្លួនខណៈដែល `\"` ។
    /// * Backslash ត្រូវបានរត់គេចខ្លួនជា `\\` ។
    /// * តួអក្សរណាមួយនៅក្នុងជួរ 'អាចបោះពុម្ពបាន ASCII' `0x20` .. `0x7e` បញ្ចូលមិនត្រូវបានគេចខ្លួនទេ។
    /// * តួអក្សរផ្សេងទៀតទាំងអស់ត្រូវបានផ្តល់ការរត់គេចយូនីកូដ;សូមមើល [`escape_unicode`] ។
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// ត្រឡប់ចំនួនបៃ `char` នេះនឹងត្រូវការប្រសិនបើបានអ៊ិនកូដជា UTF-8 ។
    ///
    /// ចំនួនបៃនោះតែងតែស្ថិតនៅចន្លោះពី ១ និង ៤ ដែលរាប់បញ្ចូល។
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// ប្រភេទ `&str` ធានាថាមាតិការបស់វាគឺ UTF-8 ហើយដូច្នេះយើងអាចប្រៀបធៀបប្រវែងរបស់វាប្រសិនបើចំណុចកូដនីមួយៗត្រូវបានតំណាងជា `char` vs នៅក្នុង `&str` ខ្លួនវាផ្ទាល់៖
    ///
    ///
    /// ```
    /// // ដូចជាគំនូសតាង
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // ទាំងពីរអាចត្រូវបានតំណាងជាបីបៃ
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ជាការ &str មួយទាំងពីរនេះត្រូវបានអ៊ិនកូដ UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // យើងអាចមើលឃើញថាពួកគេបានទទួលយកប្រាំមួយបៃសរុប ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ដូចគ្នានឹង &str ដែរ
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// ត្រឡប់ចំនួន 16 ប៊ីតគ្រឿងកូដ `char` នេះនឹងត្រូវការប្រសិនបើបានអ៊ិនកូដ UTF-16 នេះ។
    ///
    ///
    /// សូមមើលឯកសារសម្រាប់ [`len_utf8()`] សម្រាប់ការពន្យល់បន្ថែមទៀតនៃគំនិតនេះ។
    /// មុខងារនេះគឺជាកញ្ចក់មួយ, ប៉ុន្តែសម្រាប់ UTF-16 ជំនួសឱ្យ UTF-8 ។
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// អ៊ិនកូដតួអក្សរនេះជា UTF-8 ទៅក្នុងសតិបណ្ដោះអាសន្នបៃដែលបានផ្តល់ហើយបន្ទាប់មកត្រឡប់ទំហំរងនៃអង្គចងចាំដែលមានតួអក្សរដែលបានអ៊ិនកូដ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសតិបណ្ដោះអាសន្នមិនធំល្មម។
    /// សតិបណ្ដោះអាសន្ននៃប្រវែងបួនមានទំហំធំល្មមអាចអ៊ិនកូដ `char` ណាមួយ។
    ///
    /// # Examples
    ///
    /// ទាំងនៅក្នុងឧទាហរណ៍ទាំងនេះ 'ß' ត្រូវចំណាយពេលពីរទៅអ៊ិនកូដបៃ។
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// សតិបណ្ដោះអាសន្នដែលតូចពេក៖
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // សុវត្ថិភាព: `char` មិនមែនជាការពពោះជំនួសទេដូច្នេះនេះជា UTF-8 ត្រឹមត្រូវ។
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// អ៊ិនកូដតួអក្សរនេះជា UTF-16 ទៅក្នុងសតិបណ្ដោះអាសន្ន `u16` ដែលបានផ្តល់ហើយបន្ទាប់មកត្រឡប់មកជាបន្ទុកនៃអង្គចងចាំដែលមានតួអក្សរដែលបានអ៊ិនកូដ។
    ///
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើសតិបណ្ដោះអាសន្នមិនធំល្មម។
    /// សតិបណ្ដោះអាសន្ននៃប្រវែង ២ មានទំហំធំល្មមអាចអ៊ិនកូដ `char` ណាមួយ។
    ///
    /// # Examples
    ///
    /// នៅក្នុងឧទាហរណ៍ទាំងពីរនេះ '𝕊' យកពីរ `u16`s ដើម្បីអ៊ិនកូដ។
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// សតិបណ្ដោះអាសន្នដែលតូចពេក៖
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះមានលក្ខណសម្បត្តិ `Alphabetic` ។
    ///
    /// `Alphabetic` ត្រូវបានពិពណ៌នានៅក្នុងជំពូកទី ៤ (លក្ខណៈសម្បត្តិលក្ខណៈ) នៃ [Unicode Standard] និងបានបញ្ជាក់នៅក្នុង [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ។
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ស្នេហាមានច្រើនយ៉ាងតែវាមិនមែនជាអក្ខរក្រមទេ
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះមានលក្ខណសម្បត្តិ `Lowercase` ។
    ///
    /// `Lowercase` ត្រូវបានពិពណ៌នានៅក្នុងជំពូកទី ៤ (លក្ខណៈសម្បត្តិលក្ខណៈ) នៃ [Unicode Standard] និងបានបញ្ជាក់នៅក្នុង [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ។
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // ស្គ្រីបនិងវណ្ណយុត្តផ្សេងៗរបស់ចិនមិនមានករណីទេដូច្នេះហើយ៖
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះមានលក្ខណសម្បត្តិ `Uppercase` ។
    ///
    /// `Uppercase` ត្រូវបានពិពណ៌នានៅក្នុងជំពូកទី ៤ (លក្ខណៈសម្បត្តិលក្ខណៈ) នៃ [Unicode Standard] និងបានបញ្ជាក់នៅក្នុង [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ។
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // ស្គ្រីបនិងវណ្ណយុត្តផ្សេងៗរបស់ចិនមិនមានករណីទេដូច្នេះហើយ៖
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះមានទ្រព្យសម្បត្តិ `White_Space` ។
    ///
    /// `White_Space` ត្រូវបានបញ្ជាក់នៅក្នុង [Unicode Character Database][ucd] [`PropList.txt`] ។
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // ចន្លោះមិនបំបែក
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះពេញចិត្តទាំង [`is_alphabetic()`] ឬ [`is_numeric()`] ។
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះមានប្រភេទទូទៅសម្រាប់កូដត្រួតពិនិត្យ។
    ///
    /// លេខកូដត្រួតពិនិត្យ (ចំណុចកូដដែលមានប្រភេទទូទៅនៃ `Cc`) ត្រូវបានពិពណ៌នានៅក្នុងជំពូកទី ៤ (លក្ខណៈសម្បត្តិរបស់តួអក្សរ) នៃ [Unicode Standard] និងបានបញ្ជាក់នៅក្នុង [Unicode Character Database][ucd] [`UnicodeData.txt`] ។
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// // U + 009C, ស្ថានីយ STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះមានលក្ខណសម្បត្តិ `Grapheme_Extend` ។
    ///
    /// `Grapheme_Extend` គឺត្រូវបានរៀបរាប់នៅក្នុង [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] និងបានបញ្ជាក់នៅក្នុង [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ។
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// ត្រឡប់ `true` ប្រសិនបើ `char` នេះមានមួយនៃប្រភេទទូទៅសម្រាប់លេខ។
    ///
    /// ប្រភេទទូទៅសម្រាប់លេខ (ខ្ទង់ទសភាគសម្រាប់ `Nd`, `Nl` សម្រាប់តួអក្សរដូចលិខិតលេខនិង `No` សម្រាប់តួអក្សរលេខផ្សេងទៀត) ត្រូវបានបញ្ជាក់នៅក្នុង [Unicode Character Database][ucd] [`UnicodeData.txt`] ។
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// ការប្រើប្រាស់មូលដ្ឋាន៖
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ត្រឡប់មកវិញបម្រុងទិន្នផលផែនទីដែលតូចនេះជាការ `char` ច្រើនជាងមួយមួយឬ
    /// `char`s.
    ///
    /// ប្រសិនបើ `char` នេះមិនមានផែនទីតូចទេនោះទ្រនាប់ដដែលផ្តល់លទ្ធផលស្មើ `char` ។
    ///
    /// ប្រសិនបើ `char` នេះមានផែនទីតូចមួយទៅមួយបានផ្តល់ឱ្យដោយ [Unicode Character Database][ucd] [`UnicodeData.txt`] វានឹងផ្តល់លទ្ធផលដល់ `char` ។
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ប្រសិនបើ `char` នេះតម្រូវឱ្យមានការពិចារណាពិសេស (ឧទាហរណ៏ `សាកច្រើន) ទ្រនាប់ទ្រនាប់ផ្តល់លទ្ធផល` សាក `ដែលផ្តល់ដោយ [`SpecialCasing.txt`] ។
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ប្រតិបត្តិការនេះដំណើរការដោយគ្មានលក្ខខណ្ឌដោយមិនមានជាការគូសផែនទីជាងកាត់ដេរ។នោះគឺការប្រែចិត្តជឿឯករាជ្យពីបរិបទនិងភាសា។
    ///
    /// នៅក្នុង [Unicode Standard] ជំពូកទី ៤ (លក្ខណៈសម្បត្តិលក្ខណៈ) ពិភាក្សាអំពីការគូសផែនទីករណីទូទៅនិងជំពូក ៣ (Conformance) ពិភាក្សាអំពីក្បួនដោះស្រាយលំនាំដើមសម្រាប់បំលែងករណី។
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // ពេលខ្លះលទ្ធផលគឺច្រើនជាងមួយតួអក្សរ៖
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // តួអក្សរដែលមិនមានទាំងអក្សរធំនិងអក្សរតូចបំលែងទៅជាខ្លួនឯង។
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ត្រឡប់ទ្រនិចបង្ហាញដែលផ្តល់លទ្ធផលនៃការគូសផែនទីធំនៃ `char` នេះមួយឬច្រើន
    /// `char`s.
    ///
    /// ប្រសិនបើ `char` នេះមិនមានផែនទីធំនោះទ្រនាប់ដដែលផ្តល់ទិន្នផល `char` ដូចគ្នា។
    ///
    /// ប្រសិនបើ `char` នេះមានផែនទីអក្សរធំពីមួយទៅមួយផ្តល់ឱ្យដោយ [Unicode Character Database][ucd] [`UnicodeData.txt`] វានឹងផ្តល់លទ្ធផល `char` X ។
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ប្រសិនបើ `char` នេះតម្រូវឱ្យមានការពិចារណាពិសេស (ឧទាហរណ៏ `សាកច្រើន) ទ្រនាប់ទ្រនាប់ផ្តល់លទ្ធផល` សាក `ដែលផ្តល់ដោយ [`SpecialCasing.txt`] ។
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ប្រតិបត្តិការនេះដំណើរការដោយគ្មានលក្ខខណ្ឌដោយមិនមានជាការគូសផែនទីជាងកាត់ដេរ។នោះគឺការប្រែចិត្តជឿឯករាជ្យពីបរិបទនិងភាសា។
    ///
    /// នៅក្នុង [Unicode Standard] ជំពូកទី ៤ (លក្ខណៈសម្បត្តិលក្ខណៈ) ពិភាក្សាអំពីការគូសផែនទីករណីទូទៅនិងជំពូក ៣ (Conformance) ពិភាក្សាអំពីក្បួនដោះស្រាយលំនាំដើមសម្រាប់បំលែងករណី។
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ក្នុងនាមជាអ្នកធ្វើវារ៖
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// ការប្រើប្រាស់ `println!` ផ្ទាល់៖
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// ទាំងពីរគឺស្មើនឹង៖
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// ការប្រើប្រាស់ `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // ពេលខ្លះលទ្ធផលគឺច្រើនជាងមួយតួអក្សរ៖
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // តួអក្សរដែលមិនមានទាំងអក្សរធំនិងអក្សរតូចបំលែងទៅជាខ្លួនឯង។
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # ចំណាំនៅលើមូលដ្ឋាន
    ///
    /// នៅក្នុងភាសាទួរគីសមមូល 'i' នៅឡាតាំងមានទម្រង់ប្រាំជំនួសឱ្យពីរ៖
    ///
    /// * 'Dotless': ខ្ញុំ/ıពេលខ្លះសរសេរï
    /// * 'Dotted': İ/ខ្ញុំ
    ///
    /// ចំណាំថាតូចចំនុច 'i' គឺដូចគ្នាឡាតាំង។ហេតុនេះហើយបានជា:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// តម្លៃនៃ `upper_i` នៅទីនេះពឹងផ្អែកលើភាសារបស់អត្ថបទនេះ: ប្រសិនបើយើងមាននៅក្នុង `en-US` វាគួរតែ `"I"` ប៉ុន្តែប្រសិនបើយើងមាននៅក្នុង `tr_TR` វាគួរតែ `"İ"` ។
    /// `to_uppercase()` មិនគិតពីរឿងនេះទេដូច្នេះហើយ៖
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// កាន់ភាសាផ្សេងៗ។
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺនៅក្នុងជួរ ASCII ។
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// បង្កើតច្បាប់ចម្លងនៃតម្លៃក្នុងករណីអក្សរធំ ASCII ។
    ///
    /// អក្សរ ASCII 'a' ទៅ 'z' ត្រូវបានគូសផែនទីទៅ 'A' ទៅ 'Z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីជាអក្សរធំតម្លៃនៅនឹងកន្លែងប្រើ [`make_ascii_uppercase()`] ។
    ///
    /// ដើម្បីជាអក្សរធំតួអក្សរ ASCII បន្ថែមពីលើការដែលមិនមែនជា ASCII តួអក្សរដែលប្រើ [`to_uppercase()`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ធ្វើការចម្លងតម្លៃទាបដែលមានតំលៃស្មើជា ASCII ករណីរបស់ខ្លួន។
    ///
    /// អក្សរ ASCII 'A' ទៅ 'Z' ត្រូវបានគូសផែនទីទៅ 'a' ទៅ 'z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ទៅជាអក្សរតូចតម្លៃនៅនឹងកន្លែងប្រើ [`make_ascii_lowercase()`] ។
    ///
    /// ទៅជាតួអក្សរតូច ASCII បន្ថែមពីលើការដែលមិនមែនជា ASCII តួអក្សរដែលប្រើ [`to_lowercase()`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// ពិនិត្យមើលថាមានតម្លៃពីរគឺជាករណីអាក្រក់ប្រកួត ASCII ។
    ///
    /// ស្មើនឹង `to_ascii_lowercase(a) == to_ascii_lowercase(b)` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// បម្លែងប្រភេទទៅជា ASCII ករណីខាងលើនៅក្នុងសមមូលកន្លែងនេះ។
    ///
    /// អក្សរ ASCII 'a' ទៅ 'z' ត្រូវបានគូសផែនទីទៅ 'A' ទៅ 'Z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីត្រឡប់តម្លៃអក្សរធំថ្មីដោយមិនចាំបាច់កែប្រែតម្លៃដែលមានស្រាប់សូមប្រើ [`to_ascii_uppercase()`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// បំលែងប្រភេទនេះទៅជាអក្សរតូច ASCII ដែលសមមូលនឹងកន្លែង។
    ///
    /// អក្សរ ASCII 'A' ទៅ 'Z' ត្រូវបានគូសផែនទីទៅ 'a' ទៅ 'z' ប៉ុន្តែអក្សរមិនមែន ASCII មិនផ្លាស់ប្តូរទេ។
    ///
    /// ដើម្បីត្រឡប់តម្លៃទាបថ្មីដោយមិនចាំបាច់កែប្រែរបស់ដែលមានស្រាប់សូមប្រើ [`to_ascii_lowercase()`] ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺមានតួអក្សរអក្ខរក្រម ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ឬ
    /// - U + 0061 'a' ..=U + 007A 'z' ។
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺជា ASCII អក្សរធំតួអក្សរមួយ:
    /// U + 0041 'A' ..=U + 005A 'Z' ។
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺជាតួអក្សរ ASCII នេះ:
    /// U + 0061 'a' ..=U + 007A 'z' ។
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺជាតួអក្សរក្រមលេខ ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' ឬ
    /// - U + 0061 'a' ..=U + 007A 'z', ឬ
    /// - U + 0030 '0' ..=U + 0039 '9' ។
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// ពិនិត្យមើលថាតើតម្លៃគឺជាខ្ទង់ទសភាគ ASCII៖
    /// U + 0030 '0' ..=U + 0039 '9' ។
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺជាតួលេខប្រព័ន្ធគោលដប់ប្រាំមួយ ASCII នេះ:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9' ឬ
    /// - U + 0041 'A' ..=U + 0046 'F', ឬ
    /// - U + 0061 'a' ..=U + 0066 'f' ។
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// ពិនិត្យមើលថាតើតម្លៃគឺជាតួអក្សរវណ្ណយុត្តិ ASCII៖
    ///
    /// - U + 0021 + + ..=អ៊ូ 002F `! " # $ % & ' ( ) * + , - . /` ឬ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @` ឬ
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, ឬ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺជាតួអក្សរ ASCII ក្រាហ្វិក:
    /// U + 0021 '!' ..=U + 007E '~' ។
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// ពិនិត្យមើលប្រសិនបើតម្លៃនេះគឺជាតួអក្សរដកឃ្លា ASCII:
    /// U + 0020 SPACE, U + 0009 HORIZONTAL TAB, U + 000A LINE FEED, U + 000C FORM FEED, ឬ U + 000D CARRIAGE RETURN ។
    ///
    /// Rust ប្រើ [definition of ASCII whitespace][infra-aw] នេះ WhatWG ហ៊ុន Infra ស្តង់ដានេះ។មាននិយមន័យជាច្រើនផ្សេងទៀតក្នុងការប្រើប្រាស់ធំទូលាយ។
    /// ឧទាហរណ៍ [the POSIX locale][pct] រួមបញ្ចូល U + ថេបដែលជា 000B VERTICAL ដូចជាតួអក្សរខាងលើបានយ៉ាងល្អទាំងអស់នោះទេប៉ុន្តែមកពី specification-ដូចគ្នាខ្លាំងណាស់ [ក្បួនលំនាំដើមសម្រាប់ "field splitting" ក្នុង Bourne shell][bfs] បានចាត់ទុក * * SPACE តែផ្ដេកថេបនិង LINE FEED ជាចន្លោះ។
    ///
    ///
    /// ប្រសិនបើអ្នកកំពុងសរសេរកម្មវិធីដែលនឹងដំណើរការទំរង់ឯកសារដែលមានស្រាប់សូមពិនិត្យមើលថាតើនិយមន័យនៃទំរង់បែបផែននោះមុនពេលប្រើមុខងារនេះ។
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// ពិនិត្យមើលថាតើតម្លៃជាតួអក្សរបញ្ជា ASCII៖
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, ឬ U + 007F DELETE ។
    /// ចំណាំថាតួអក្សរដកឃ្លា ASCII ភាគច្រើនគឺជាតួអក្សរត្រួតពិនិត្យប៉ុន្តែ SPACE មិនមែនទេ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// អ៊ិនកូដតម្លៃជាវត្ថុធាតុដើមដែលជា UTF-8 u32 ចូលទៅក្នុងសតិបណ្ដោះអាសន្នបៃដែលបានផ្តល់, ហើយបន្ទាប់មកត្រឡប់ subslice នៃសតិបណ្ដោះអាសន្នដែលមានតួអក្សរដែលបានអ៊ិនកូដនេះ។
///
///
/// មិនដូច `char::encode_utf8` ទេវិធីសាស្ត្រនេះក៏ដោះស្រាយលេខកូដនៅក្នុងជួរពន្យាពេលផងដែរ។
/// (ការបង្កើត `char` ក្នុងជួរពពោះជំនួសគេនោះគឺ UB បាន) ។ លទ្ធផលគឺត្រឹមត្រូវ [generalized UTF-8] ប៉ុន្តែ UTF-8 មិនត្រឹមត្រូវ។
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics ប្រសិនបើសតិបណ្ដោះអាសន្នមិនធំល្មម។
/// សតិបណ្ដោះអាសន្ននៃប្រវែងបួនមានទំហំធំល្មមអាចអ៊ិនកូដ `char` ណាមួយ។
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// អ៊ិនកូដតម្លៃ u32 ឆៅជា UTF-16 ទៅក្នុងសតិបណ្ដោះអាសន្ន `u16` ដែលបានផ្តល់ហើយបន្ទាប់មកត្រឡប់ទំហំរងនៃសតិបណ្ដោះអាសន្នដែលមានតួអក្សរដែលបានអ៊ិនកូដ។
///
///
/// មិនដូច `char::encode_utf16` ទេវិធីសាស្ត្រនេះក៏ដោះស្រាយលេខកូដនៅក្នុងជួរពន្យាពេលផងដែរ។
/// (ការបង្កើត `char` នៅក្នុងជួរពន្យាពេលគឺ UB ។)
///
/// # Panics
///
/// Panics ប្រសិនបើសតិបណ្ដោះអាសន្នមិនធំល្មម។
/// សតិបណ្ដោះអាសន្ននៃប្រវែង ២ មានទំហំធំល្មមអាចអ៊ិនកូដ `char` ណាមួយ។
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // សុវត្ថិភាព: ការត្រួតពិនិត្យគ្នាមានដៃថាតើគ្រប់គ្រាន់ដើម្បីសរសេរប៊ីតចូលទៅក្នុង
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP ធ្លាក់តាមរយៈ
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // យន្ដហោះបន្ថែមបំបែកជាការពពោះជំនួស។
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}