//! traits បឋមនិងប្រភេទតំណាងឱ្យលក្ខណៈសម្បត្តិមូលដ្ឋាននៃប្រភេទ។
//!
//! ប្រភេទ Rust អាចត្រូវបានចាត់ថ្នាក់នៅក្នុងវិធីមានប្រយោជន៍ផ្សេងបើយោងតាមលក្ខណៈសម្បត្តិចាំបាច់របស់ពួកគេ។
//! ចំណាត់ថ្នាក់ទាំងនេះត្រូវបានតំណាងឱ្យ traits ។
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ប្រភេទដែលអាចត្រូវបានផ្ទេរនៅទូទាំងព្រំដែនខ្សែស្រឡាយ។
///
/// trait នេះត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិនៅពេលអ្នកចងក្រងកំណត់ថាវាសមស្រប។
///
/// ឧទាហរណ៍នៃប្រភេទដែលមិនមែនជា `Send` មួយគឺព្រួញយោងរាប់ [`rc::Rc`][`Rc`] ។
/// ប្រសិនបើខ្សែស្រឡាយពីរព្យាយាមក្លូន [`Rc`] ចង្អុលទៅតម្លៃដែលបានរាប់យោងដូចគ្នាពួកគេអាចព្យាយាមធ្វើបច្ចុប្បន្នភាពចំនួនយោងក្នុងពេលតែមួយដែលជា [undefined behavior][ub] ពីព្រោះ [`Rc`] មិនប្រើប្រតិបត្តិការអាតូមិចទេ។
///
/// បងប្អូនជីដូនមួយរបស់ខ្លួន [`sync::Arc`][arc] ធ្វើប្រតិបត្ដិការបរមាណូប្រើ (ការចំណាយមួយចំនួនកើតឡើង) ហើយដូច្នេះគឺ `Send` ។
///
/// សូមមើល [the Nomicon](../../nomicon/send-and-sync.html) សម្រាប់ព័ត៌មានលម្អិត។
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// ប្រភេទដែលមានទំហំថេរមួយដែលគេស្គាល់ថានៅពេលចងក្រង។
///
/// ប៉ារ៉ាម៉ែត្រប្រភេទទាំងអស់មានព្រំប្រទល់ជាប់នៃ `Sized` ។វាក្យសម្ព័ន្ធពិសេស `?Sized` អាចត្រូវបានប្រើដើម្បីយកចេញនេះបានចងប្រសិនបើវាមិនសមរម្យ។
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//កំហុស: ទំហំមិនត្រូវបានអនុវត្តសម្រាប់ [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ករណីលើកលែងមួយគឺប្រភេទ `Self` ដែលមិនច្បាស់នៃ trait ។
/// ការ trait មិនមានជាក់ច្បាស់ `Sized` ចងដូចជានេះគឺជាការឆបគ្នាជាមួយ [វត្ថុ trait] ជាកន្លែងដែលតាមនិយមន័យ trait នេះត្រូវការដើម្បីធ្វើការជាមួយនឹង implementor ដែលអាចធ្វើបានទាំងអស់, ហើយដូច្នេះអាចនឹងមានទំហំណាមួយ។
///
///
/// ទោះបីជា Rust នឹងអនុញ្ញាតឱ្យអ្នកចង `Sized` ទៅ trait អ្នកនឹងមិនអាចប្រើវាដើម្បីបង្កើតវត្ថុ trait នៅពេលក្រោយ:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // អនុញ្ញាតឱ្យ y: របារ &dyn = &Impl;//កំហុស: ការ trait មិនអាចត្រូវបាន `Bar` ចូលទៅក្នុងវត្ថុមួយដែលធ្វើឡើង
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // សម្រាប់លំនាំដើម, ឧទាហរណ៍, ដែលតម្រូវឱ្យ `[T]: !Default` ក្លាយ evaluatable
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// ប្រភេទដែលអាច "unsized" ទៅប្រភេទថាមវន្តមានទំហំមួយ។
///
/// ឧទាហរណ៍វាយអារេដែលមានទំហំ `[i8; 2]` អនុវត្ត `Unsize<[i8]>` និង `Unsize<dyn fmt::Debug>` ។
///
/// ប្រតិបត្តិការទាំងអស់នៃការ `Unsize` ត្រូវបានផ្តល់ឱ្យដោយស្វ័យប្រវត្តិដោយកម្មវិធីចងក្រង។
///
/// `Unsize` ត្រូវបានអនុវត្តសម្រាប់:
///
/// - `[T; N]` គឺ `Unsize<[T]>`
/// - `T` គឺ `Unsize<dyn Trait>` ពេល `T: Trait`
/// - `Foo<..., T, ...>` គឺ `Unsize<Foo<..., U, ...>>` ប្រសិនបើ៖
///   - `T: Unsize<U>`
///   - foo គឺ struct មួយ
///   - មានតែវាលចុងក្រោយរបស់ `Foo` មានប្រភេទពាក់ព័ន្ធនឹង `T` មួយ
///   - `T` មិនមែនជាផ្នែកមួយនៃប្រភេទនៃវាលណាមួយផ្សេងទៀត
///   - `Bar<T>: Unsize<Bar<U>>`, ប្រសិនបើវាលចុងក្រោយរបស់ `Foo` មានប្រភេទ `Bar<T>`
///
/// `Unsize` ត្រូវបានប្រើរួមជាមួយ [`ops::CoerceUnsized`] ដើម្បីអនុញ្ញាតឱ្យកុងតឺន័រ "user-defined" ដូចជា [`Rc`] មានផ្ទុកប្រភេទឌីណាមិក។
/// សូមមើល [DST coercion RFC][RFC982] និង [the nomicon entry on coercion][nomicon-coerce] សម្រាប់សេចក្តីលម្អិតបន្ថែម។
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// ត្រូវការ trait សម្រាប់ប្រើនៅក្នុងការប្រកួតថេរលំនាំ។
///
/// ប្រភេទណាមួយដែលបង្កើត `PartialEq` អនុវត្ត trait នេះដោយស្វ័យប្រវត្តិ * ដោយមិនគិតពីថាតើប្រភេទប្រភេទរបស់វាអនុវត្ត `Eq` ។
///
/// ប្រសិនបើមានធាតុ `const` មានប្រភេទមួយចំនួនដែលមិនបានអនុវត្ត trait នេះនោះថាប្រភេទទាំង (1.) មិនអនុវត្ត `PartialEq` (ដែលមានន័យថាថេរវានឹងមិនផ្ដល់នូវវិធីសាស្រ្តប្រៀបធៀបនោះដែលជំនាន់កូដសន្មត់ថាគឺអាចរកបាន) ឬ (2.) វាប់ *របស់ខ្លួនផ្ទាល់* កំណែនៃ `PartialEq` (ដែលយើងសន្មត់មិនអនុលោមទៅប្រៀបធៀបរចនាសម្ព័ន្ធ-សមភាព) ។
///
///
/// នៅក្នុងសេណារីយ៉ូទាំងពីរខាងលើយើងបដិសេធការប្រើប្រាស់ថេរក្នុងការប្រកួតគំរូ។
///
/// សូមមើលផងដែរ [structural match RFC][RFC1445] និងការលើកទឹកចិត្តការធ្វើចំណាកស្រុកដែលបាន [issue 63438] រចនាគុណលក្ខណៈ-ពីមូលដ្ឋាន trait នេះ។
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// ត្រូវការ trait សម្រាប់ប្រើនៅក្នុងការប្រកួតថេរលំនាំ។
///
/// ប្រភេទណាមួយដែលបង្កើត `Eq` អនុវត្ត trait នេះដោយស្វ័យប្រវត្តិ * ដោយមិនគិតពីថាតើប៉ារ៉ាម៉ែត្រប្រភេទរបស់វាអនុវត្ត `Eq` ។
///
/// នេះជាការ hack ធ្វើការនៅជុំវិញដែនកំណត់មួយនៅក្នុងប្រព័ន្ធប្រភេទរបស់យើង។
///
/// # Background
///
/// យើងចង់តម្រូវឱ្យមានប្រភេទនៃការដែលត្រូវបានប្រើនៅក្នុងការប្រកួតលំនាំមានគុណលក្ខណៈ `#[derive(PartialEq, Eq)]` ។
///
/// ល្អបំផុតជាច្រើនទៀតនៅក្នុងពិភពមួយដែលយើងអាចពិនិត្យមើលតម្រូវការថាគ្រាន់តែពិនិត្យមើលថាដោយប្រភេទមាទាំងដែលបានផ្ដល់ *និង `StructuralPartialEq` trait នេះ `Eq` trait*។
/// ទោះជាយ៉ាងណា, អ្នកអាចមាន ADTs ថា *ធ្វើ*`derive(PartialEq, Eq)`, ហើយជាករណីដែលយើងចង់ចងក្រងដើម្បីទទួលយក, និងនៅឡើយទេប្រភេទថេររបស់បរាជ័យដើម្បីអនុវត្ត `Eq` ។
///
/// ឧទាហរណ៍ករណីដូចនេះ៖
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (បញ្ហាក្នុងកូដខាងលើនេះគឺថា `Wrap<fn(&())>` មិនប្រតិបត្តិ `PartialEq` ឬ `Eq` ដោយសារតែ `សម្រាប់ <ថា"> fn(&'a _)` does not implement those traits.)
///
/// ដូច្នេះយើងមិនអាចពឹងផ្អែកលើការពិនិត្យរឿងឆោតល្ងង់សម្រាប់ `StructuralPartialEq` និងតែ `Eq` ។
///
/// ជាការ hack ទៅធ្វើការនៅជុំវិញនេះយើងប្រើពីរដាច់ដោយឡែក traits ចាក់បញ្ចូលដោយគ្នានៃដេរីវេពីរ (`#[derive(PartialEq)]` និង `#[derive(Eq)]`) និងពិនិត្យថាពួកគេទាំងពីរមានវត្តមានជាផ្នែកមួយនៃការប្រកួតត្រួតពិនិត្យរចនាសម្ព័ន្ធ។
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ប្រភេទដែលមានតម្លៃអាចត្រូវបានចម្លងដោយគ្រាន់តែចម្លងប៊ីត។
///
/// តាមលំនាំដើមការចងអថេរមាន 'ផ្លាស់ទីវណ្ណយុត្តិ' ។ក្នុងន័យផ្សេងទៀត:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` បានផ្លាស់ប្តូរទៅជា `y` ហើយដូច្នេះមិនអាចត្រូវបានប្រើទេ
///
/// // println! ("{: ?}", x);//កំហុស: ការប្រើប្រាស់នៃតម្លៃរំជួល
/// ```
///
/// ទោះយ៉ាងណាក៏ដោយប្រសិនបើប្រភេទមួយអនុវត្ត `Copy` ជំនួសវាមាន 'copy semantics':
///
/// ```
/// // យើងអាចទាញយកការអនុវត្ត `Copy` ។
/// // `Clone` គឺត្រូវបានទាមទារផងដែរ, វាជាការ supertrait នៃ `Copy` មួយ។
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` គឺជាច្បាប់ចម្លងនៃ `x` មួយ
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// វាជាការសំខាន់ក្នុងការសំគាល់ថានៅក្នុងឧទាហរណ៍ទាំងពីរនេះមានភាពខុសគ្នាតែមួយគត់គឺថាតើអ្នកត្រូវបានអនុញ្ញាតឱ្យចូលដំណើរការ `x` បន្ទាប់ពីកិច្ចការនោះ។
/// នៅក្រោមក្រណាត់ទាំងការចម្លងនិងចលនាអាចបណ្តាលឱ្យប៊ីតត្រូវបានចម្លងនៅក្នុងសតិទោះបីជាពេលខ្លះវាត្រូវបានធ្វើឱ្យប្រសើរក៏ដោយ។
///
/// ## របៀបដែលខ្ញុំអាចអនុវត្ត `Copy`?
///
/// មានវិធីពីរដើម្បីអនុវត្ត `Copy` លើប្រភេទរបស់អ្នក។សាមញ្ញបំផុតគឺត្រូវប្រើ `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// អ្នកក៏អាចអនុវត្ត `Copy` និង `Clone` ដោយដៃ:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// មានភាពខុសគ្នារវាងអ្នកទាំងពីរតូចគឺ: យុទ្ធសាស្រ្ត `derive` នឹងដាក់ `Copy` មួយចងនៅលើប៉ារ៉ាម៉ែត្រប្រភេទដែលមិនចង់បានជានិច្ច។
///
/// ## ភាពខុសគ្នារវាង `Copy` និង `Clone` ជាអ្វី?
///
/// ច្បាប់ចម្លងកើតឡើងទាំងស្រុងឧទាហរណ៍ជាផ្នែកមួយនៃកិច្ចការ `y = x` មួយ។ឥរិយាបថរបស់ `Copy` មិនអាចផ្ទុកលើសទម្ងន់បានទេ។វាតែងតែជាច្បាប់ចំលងដ៏សាមញ្ញមួយ។
///
/// ការក្លូនគឺជាសកម្មភាពជាក់ស្តែងគឺ `x.clone()` ។ការអនុវត្តន៍ [`Clone`] នេះអាចផ្តល់នូវឥរិយាបទជាក់លាក់ណាមួយប្រភេទដែលចាំបាច់ដើម្បីស្ទួនតម្លៃដោយសុវត្ថិភាព។
/// ឧទាហរណ៍ការអនុវត្តនៃការ [`Clone`] សម្រាប់ [`String`] ត្រូវការដើម្បីចម្លងទៅចំណុចខ្សែអក្សរសតិបណ្ដោះអាសន្នក្នុងគំនរថ្មនោះ។
/// ច្បាប់ចម្លង bitwise នៃតម្លៃ [`String`] សាមញ្ញគ្រាន់តែនឹងថតចម្លងស្សន៍ទ្រនិចដែលនាំឱ្យមានការពីរដងដោយឥតគិតចុះបន្ទាត់។
/// ចំពោះហេតុផលនេះ, [`String`] គឺ [`Clone`] ប៉ុន្តែមិន `Copy` ។
///
/// [`Clone`] គឺជារូបគំរូនៃ `Copy` ដូច្នេះអ្វីគ្រប់យ៉ាងដែលជា `Copy` ក៏ត្រូវតែអនុវត្ត [`Clone`] ផងដែរ។
/// បើប្រភេទគឺជាការបន្ទាប់មកអនុវត្ត [`Clone`] `Copy` របស់ខ្លួននៅតែត្រូវការឱ្យវិលត្រឡប់មកវិញ `*self` (សូមមើលឧទាហរណ៍ខាងលើ) ។
///
/// ## នៅពេលដែលអាចទូលបង្គំមាន `Copy` ប្រភេទ?
///
/// ប្រភេទមួយអាចអនុវត្ត `Copy` ប្រសិនបើសមាសធាតុទាំងអស់របស់វាអនុវត្ត `Copy` ។ឧទាហរណ៍រចនាសម្ព័ន្ធនេះអាចជា `Copy`៖
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// រចនាសម្ព័ន្ធមួយអាចជា `Copy` ហើយ [`i32`] គឺ `Copy` ដូច្នេះ `Point` មានសិទ្ធិក្លាយជា `Copy` ។
/// ដោយផ្ទុយ, ពិចារណា
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// struct `PointList` នេះមិនអាចអនុវត្ត `Copy` ដោយសារតែ [`Vec<T>`] គឺមិនមែន `Copy` ។ប្រសិនបើយើងព្យាយាមទាញយកមួយដែលអនុវត្ត `Copy` យើងនឹងទទួលបានកំហុសមួយ:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// សេចក្តីយោងដែលបានចែករំលែកផងដែរ `Copy` (`&T`) ដូច្នេះប្រភេទអាចជា `Copy`, សូម្បីតែនៅពេលដែលវាផ្ទុកទំនិញសេចក្តីយោងនៃប្រភេទ `T` ដែលមាន *មិនបាន*`Copy` ចែករំលែក។
/// សូមពិចារណា struct ដូចខាងក្រោមដែលអាចអនុវត្ត `Copy` ព្រោះវាទទួលបានតែមួយ *សេចក្ដីយោងដែលបានចែករំលែក* ដើម្បីប្រភេទដែលមិនមែនជា `Copy` ពីខាងលើយើង `PointList`:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## នៅពេល *មិនអាច* ជីវិតខ្ញុំត្រូវ `Copy` ប្រភេទ?
///
/// ប្រភេទមួយចំនួនមិនអាចត្រូវបានចម្លងដោយសុវត្ថិភាពទេ។ឧទាហរណ៍ចម្លង `&mut T` នឹងបង្កើតឯកសារយោង mutable ឈ្មោះក្លែងក្លាយ។
/// ការថតចម្លង [`String`] នឹងចម្លងការទទួលខុសត្រូវសម្រាប់ការគ្រប់គ្រងសតិបណ្ដោះអាសន្នរបស់ `` ដែលនាំឱ្យមានសេរីភាពទ្វេដង។
///
/// Generalizing ករណីក្រោយ, ប្រភេទណាមួយដែលមិនអនុវត្ត [`Drop`] អាចមាន `Copy` ដោយសារតែវាត្រូវបានគ្រប់គ្រងធនធានមួយចំនួនក្រៅ [`size_of::<T>`] របស់ខ្លួនផ្ទាល់បៃ។
///
/// ប្រសិនបើអ្នកព្យាយាមអនុវត្ត `Copy` នៅលើរចនាសម្ព័ន្ធឬអង់ហ្ស៊ីមដែលផ្ទុកទិន្នន័យមិន `ខ្ពូ` អ្នកនឹងទទួលបានកំហុស [E0204] ។
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## តើពេលណា *គួរតែ* ប្រភេទរបស់ខ្ញុំគឺ `Copy`?
///
/// និយាយជាទូទៅ, បើប្រភេទរបស់អ្នក _can_ អនុវត្ត `Copy`, វាគួរ។
/// រក្សាទុកក្នុងចិត្តថាការអនុវត្ត `Copy` ជាផ្នែកមួយនៃការ API សាធារណៈនៃប្រភេទរបស់អ្នក។
/// បើប្រភេទអាចក្លាយជាការមិន `Copy` ក្នុង future នេះវាអាចនឹងមានការប្រុងប្រយ័ត្នដើម្បីលុបការអនុវត្តន៍ `Copy` ឥឡូវនេះដើម្បីជៀសវាងការផ្លាស់ប្តូរ API ដែលបំបែក។
///
/// ## អ្នកអនុវត្តបន្ថែម
///
/// ក្នុងការបន្ថែមទៅ [implementors listed below][impls] ប្រភេទដូចខាងក្រោមផងដែរអនុវត្ត `Copy`:
///
/// * ប្រភេទធាតុអនុគមន៍ (ពោលគឺប្រភេទខុសគ្នាដែលបានកំណត់សម្រាប់មុខងារគ្នា)
/// * ប្រភេទទ្រនិចមុខងារ (ឧ។ `fn() -> i32`)
/// * ប្រភេទអារេសម្រាប់ទំហំទាំងអស់ប្រសិនបើប្រភេទធាតុអនុវត្ត `Copy` (ឧ `[i32; 123456]`)
/// * ប្រភេទ Tuple ប្រសិនបើសមាសធាតុនីមួយៗអនុវត្ត `Copy` (ឧទាហរណ៍ `()`, `(i32, bool)`)
/// * ប្រភេទការបិទប្រសិនបើពួកគេចាប់យកគ្មានតម្លៃពីបរិស្ថានឬប្រសិនបើតម្លៃដែលបានចាប់យកទាំងអស់អនុវត្ត `Copy` ដូចជាខ្លួនឯងផ្ទាល់។
///   ចំណាំថាអថេរដែលបានចាប់យកដោយសេចក្តីយោងដែលបានចែករំលែកតែងតែអនុវត្ត `Copy` (បើទោះបីជាសេចក្ដីយោងមិនមាន) ខណៈពេលអថេរដែលបានចាប់យកដោយសេចក្តីយោង mutable មិនអនុវត្ត `Copy` ។
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) នេះអនុញ្ញាតឱ្យចម្លងប្រភេទដែលមិនអនុវត្ត `Copy` ដោយសារតែមិនមានព្រំដែនពេញមួយជីវិត (ការថតចម្លង `A<'_>` នៅពេលមានតែ `A<'static>: Copy` និង `A<'_>: Clone`) ។
// យើងមានគុណលក្ខណៈនេះនៅទីនេះសម្រាប់ពេលឥឡូវនេះដោយសារតែមានជំនាញដែលមានស្រាប់មួយចំនួននៅលើការពិតដែលមានរួចទៅហើយ `Copy` ក្នុងបណ្ណាល័យខ្នាតគំរូហើយមានវិធីដើម្បីឱ្យមានដោយសុវត្ថិភាពឥរិយាបថនេះឥឡូវនេះទេ។
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// ទាញយកម៉ាក្រូហ្សែនបង្កើតហ្សែនហ្សិនហ្សិតហ្សិចហ្ស៊ុយ។
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ប្រភេទដែលវាមានសុវត្ថិភាពក្នុងការខ្សែស្រលាយចំណែកសេចក្តីយោងរវាង។
///
/// trait នេះត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិនៅពេលអ្នកចងក្រងកំណត់ថាវាសមស្រប។
///
/// និយមន័យច្បាស់លាស់គឺៈប្រភេទ `T` គឺ [`Sync`] ប្រសិនបើហើយលុះត្រាតែ `&T` គឺ [`Send`] ។
/// នៅក្នុងពាក្យផ្សេងទៀតប្រសិនបើមានគឺជាលទ្ធភាពនៃការ [undefined behavior][ub] ទេ (រួមទាំងការប្រណាំងទិន្នន័យ) នៅពេលដែលឆ្លងកាត់សេចក្តីយោង `&T` រវាងខ្សែស្រលាយ។
///
/// ជាមួយនឹងរំពឹងថានឹងមានប្រភេទបុព្វកាលដូច [`u8`] និង [`f64`] មាន [`Sync`] ទាំងអស់ហើយដូច្នេះគឺជាប្រភេទសាមញ្ញដែលមានសរុបពួកគេដូចជា tuple structs និង enum ។
/// ឧទហរណ៍បន្ថែមទៀតនៃប្រភេទ [`Sync`] មូលដ្ឋានរួមមានប្រភេទ "immutable" ដូច `&T`, និងអ្នកដែលមានលក្ខណៈសាមញ្ញបានទទួលឥទ្ធិពល mutability ដូចជា [`Box<T>`][box], [`Vec<T>`][vec] និងប្រភេទការប្រមូលភាគច្រើនផ្សេងទៀត។
///
/// (ប៉ារ៉ាម៉ែត្រទូទៅត្រូវតែមានការ [`Sync`] សម្រាប់ធុងរបស់ពួកគេក្លាយទៅជា [`Sync`] ។)
///
/// លទ្ធផលគួរឱ្យភ្ញាក់ផ្អើលមួយបានបន្តិចនៃនិយមន័យនេះគឺថា `&mut T` គឺ `Sync` (ប្រសិនបើ `T` គឺ `Sync`) ទោះបីជាវាហាក់ដូចជាថាអាចនឹងផ្តល់នូវការផ្លាស់ប្តូរ unsynchronized ។
/// ល្បិចនេះគឺថាជាឯកសារយោងនៅពីក្រោយសេចក្ដីយោង mutable ចែករំលែកមួយ (ដែលជា `& &mut T`) ក្លាយទៅជាបានតែអាន, ដូចជាប្រសិនបើវាត្រូវបាន `& &T` មួយ។
/// ហេតុនេះគឺមានហានិភ័យនៃការប្រណាំងទិន្នន័យទេ។
///
/// ប្រភេទដែលមិនមែនជា `Sync` គឺជាប្រភេទដែលមាន "interior mutability" ក្នុងទំរង់មិនមានខ្សែស្រឡាយដូចជា [`Cell`][cell] និង [`RefCell`][refcell] ។
/// ប្រភេទទាំងនេះអនុញ្ញាតឱ្យមានការផ្លាស់ប្តូរមាតិការបស់ពួកគេសូម្បីតែតាមរយៈឯកសារយោងដែលមិនអាចផ្លាស់ប្តូរបាននិងចែករំលែក។
/// ឧទាហរណ៍វិធីសាស្រ្ត `set` លើ [`Cell<T>`][cell] ចំណាយពេល `&self` ដូច្នេះវាតម្រូវឱ្យមានតែសេចក្តីយោងដែលបានចែករំលែក [`&Cell<T>`][cell] ។
/// វិធីសាស្ត្រមិនធ្វើសមកាលកម្មដូច្នេះ [`Cell`][cell] មិនអាចជា `Sync` ទេ។
///
/// ឧទាហរណ៏មួយទៀតនៃប្រភេទដែលមិនមែនជា `សៃដិនគឺទ្រនិចរាប់រាប់យោង។
/// ដែលបានផ្ដល់ឱ្យជាឯកសារយោងណាមួយ [`&Rc<T>`][rc], អ្នកអាចក្លូនមួយ [`Rc<T>`][rc] ថ្មី, កែប្រែចំនួនយោងនៅក្នុងវិធីដែលមិនមែនជាអាតូមិក។
///
/// ក្នុងករណីដែលមនុស្សម្នាក់ត្រូវការការផ្លាស់ប្តូរផ្នែកខាងក្នុងដែលមានសុវត្ថិភាពនិងមានខ្សែស្រឡាយ Rust ផ្តល់ជូន [atomic data types] ក៏ដូចជាការចាក់សោយ៉ាងច្បាស់តាមរយៈ [`sync::Mutex`][mutex] និង [`sync::RwLock`][rwlock] ។
/// ប្រភេទទាំងនេះធានាថាការផ្លាស់ប្តូរណាមួយដែលមិនអាចបណ្តាលឱ្យការប្រណាំងទិន្នន័យ, ហេតុប្រភេទនេះគឺ `Sync` ។
/// ដូចគ្នានេះដែរ [`sync::Arc`][arc] ផ្តល់នូវអាណាឡូកដែលមានសុវត្ថិភាពនៃខ្សែស្រឡាយ [`Rc`][rc] ។
///
/// ប្រភេទណាមួយជាមួយនឹង mutability មហាផ្ទៃផងដែរត្រូវតែប្រើរុំ [`cell::UnsafeCell`][unsafecell] ជុំវិញ value(s) ដែលអាចត្រូវបានចែករំលែកតាមរយៈសេចក្តីយោង mutated មួយ។
/// បរាជ័យក្នុងការធ្វើនេះគឺ [undefined behavior][ub] ។
/// ឧទាហរណ៍ [`transmute`][transmute]-ing ពី `&T` ទៅ `&mut T` មិនត្រឹមត្រូវ។
///
/// សូមមើល [the Nomicon][nomicon-send-and-sync] សម្រាប់លម្អិតបន្ថែមអំពី `Sync` ។
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): នៅពេលដែលការគាំទ្រដើម្បីបន្ថែមកំណត់ចំណាំនៅក្នុងដី `rustc_on_unimplemented` នៅក្នុងបេតាហើយវាត្រូវបានពង្រីកដើម្បីពិនិត្យមើលថាតើការបិទនៅកន្លែងណានៅក្នុងខ្សែសង្វាក់តំរូវការសូមពង្រីកវាដូចជា (#48534)៖
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// សូន្យទំហំប្រភេទបានប្រើដើម្បីសម្គាល់អ្វីដែល "act like" ពួកគេជាម្ចាស់ `T` មួយ។
///
/// បន្ថែមវាល `PhantomData<T>` ទៅប្រភេទរបស់អ្នកប្រាប់ថាប្រភេទរបស់អ្នកបានចងក្រងជាការទោះបីជាវាដើរតួនាទីផ្ទុកតម្លៃនៃប្រភេទ `T` មួយ, ទោះបីជាវាមិនមែនជាពិតជា។
/// ព័ត៌មាននេះត្រូវបានប្រើនៅពេលគណនាលក្ខណៈសម្បត្តិសុវត្ថិភាពជាក់លាក់។
///
/// ចំពោះការពន្យល់បន្ថែមទៀតនៅក្នុងជម្រៅនៃរបៀបប្រើ `PhantomData<T>` សូមមើល [the Nomicon](../../nomicon/phantom-data.html) ។
///
/// # កំណត់ចំណាំ ha
///
/// ទោះបីជាពួកគេទាំងពីរមានឈ្មោះគួរឱ្យខ្លាចក៏ដោយ `PhantomData` និង 'phantom ប្រភេទ' មានទំនាក់ទំនងគ្នាប៉ុន្តែមិនដូចគ្នាទេ។ប៉ារ៉ាម៉ែត្រប្រភេទខ្មោចមួយគឺគ្រាន់តែជាប៉ារ៉ាម៉ែត្រប្រភេទមួយដែលត្រូវបានមិនដែលបានប្រើ។
/// ក្នុង Rust នេះជាញឹកញាប់បណ្តាលឱ្យចងក្រងត្អូញត្អែរហើយដំណោះស្រាយនេះគឺដើម្បីបន្ថែមការប្រើ "dummy" ដោយវិធីនៃ `PhantomData` ។
///
/// # Examples
///
/// ## មិនប្រើប៉ារ៉ាម៉ែត្រជីវិត
///
/// ប្រហែលជាភាគច្រើនបំផុតដែលប្រើជាទូទៅករណីសម្រាប់ `PhantomData` គឺ struct ដែលមានប៉ារ៉ាម៉ែត្រជីវិតមួយដែលមិនបានប្រើជាធម្មតាជាផ្នែកមួយនៃកូដដែលគ្មានសុវត្ថិភាពមួយចំនួន។
/// ឧទាហរណ៍នៅទីនេះគឺ struct មួយ `Slice` ដែលមានព្រួញពីរនៃប្រភេទ `*const T`, សន្មតចង្អុលចូលទៅក្នុងកន្លែងណាមួយនៅអារេមួយ:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// ចេតនាគឺថាទិន្នន័យមូលដ្ឋានគឺមានសុពលភាពសម្រាប់ `'a` ពេញមួយជីវិតដូច្នេះ `Slice` មិនគួរហួសពី `'a` ទេ។
/// ទោះយ៉ាងណាចេតនាមិនត្រូវបានសម្តែងនេះមាននៅក្នុងកូដនេះចាប់តាំងពីមានការប្រើប្រាស់នៃជីវិត `'a` នោះទេហេតុដូចនេះហើយវាមិនត្រូវបានជម្រះអ្វីដែលទិន្នន័យដែលវាអនុវត្តទៅ។
/// យើងអាចកែបញ្ហានេះដោយប្រាប់ចងក្រងដើម្បីធ្វើសកម្មភាព *ដូចជាប្រសិនបើ* ការ struct `Slice` មានផ្ទុកសេចក្ដីយោង `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// នេះនៅក្នុងវេនតម្រូវឱ្យចំណារពន្យល់ `T: 'a` នេះបានបញ្ជាក់ថាសេចក្តីយោងណាមួយក្នុង `T` មានសុពលភាពពេញមួយជីវិត `'a` នេះ។
///
/// នៅពេលចាប់ផ្តើម `Slice` អ្នកគ្រាន់តែផ្តល់តម្លៃ `PhantomData` សម្រាប់វាល `phantom`៖
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ប៉ារ៉ាម៉ែត្រប្រភេទដែលមិនប្រើ
///
/// ពេលខ្លះវាកើតឡើងថាអ្នកមានប៉ារ៉ាម៉ែត្រប្រភេទដែលមិនប្រើដែលបង្ហាញអ្វីដែលប្រភេទនៃទិន្នន័យ struct គឺជាការ "tied" ទៅ, ទោះបីជាទិន្នន័យដែលត្រូវបានមិនបានរកឃើញពិតជានៅក្នុង struct ខ្លួនវាផ្ទាល់។
/// នេះគឺជាឧទាហរណ៍មួយដែលជាកន្លែងដែលការនេះកើតឡើងជាមួយ [FFI] មួយ។
/// នេះជាចំណុចទាញការប្រើចំណុចប្រទាក់បរទេសនៃប្រភេទ `*mut ()` ដើម្បីយោងទៅតម្លៃ Rust នៃប្រភេទផ្សេងគ្នា។
/// យើងបានតាមដានប្រភេទ Rust ដោយប្រើប៉ារ៉ាម៉ែត្រប្រភេទខ្មោចនៅលើ struct `ExternalResource` ដែលរុំចំណុចទាញមួយ។
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ភាពជាម្ចាស់និងពិនិត្យទម្លាក់
///
/// លោកបានបន្ថែមវាលនៃប្រភេទ `PhantomData<T>` បង្ហាញថាប្រភេទរបស់អ្នកជាម្ចាស់នៃប្រភេទ `T` ទិន្នន័យ។នេះនៅក្នុងវេនបានបញ្ជាក់ថានៅពេលដែលប្រភេទរបស់អ្នកត្រូវបានធ្លាក់ចុះនោះវាអាចនឹងធ្លាក់ចុះមួយឬច្រើនករណីនៃប្រភេទ `T` នេះ។
/// នេះមានអានុភាពលើការវិភាគ [drop check] បានចងក្រង Rust នេះ។
///
/// ប្រសិនបើមាន struct របស់អ្នកមិនជាការពិត *ផ្ទាល់* ទិន្នន័យរបស់ប្រភេទ `T` នេះវាជាការប្រសើរក្នុងការប្រើប្រភេទឯកសារយោងដូចជា `PhantomData<&'a T>` (ideally) ឬ `PhantomData<*const T>` (ប្រសិនបើមិនមានជីវិតត្រូវបានអនុវត្ត), ដូច្នេះដូចជាមិនមែនដើម្បីចង្អុលបង្ហាញភាពជាម្ចាស់។
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// ចងក្រង-ផ្ទៃក្នុង trait ប្រើដើម្បីបង្ហាញប្រភេទនៃការរើសអើង enum នេះ។
///
/// trait នេះត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិសម្រាប់គ្រប់ប្រភេទនិងមិនបន្ថែមការធានាណាមួយដើម្បី [`mem::Discriminant`] ។
/// វាគឺជាឥរិយាបទដែលមិនបានកំណត់ ** ** ដើម្បី transmute រវាង `DiscriminantKind::Discriminant` និង `mem::Discriminant` ។
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// ប្រភេទនៃឌីសគ្រីមីណង់ដែលត្រូវតែបំពេញ trait bounds ទាមទារដោយ `mem::Discriminant` ។
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// ចងក្រង-ផ្ទៃក្នុង trait បានប្រើដើម្បីកំណត់ថាតើប្រភេទណាមួយខាងក្នុងមាន `UnsafeCell` ប៉ុន្តែមិនបានតាមរយៈការមិនផ្ទាល់មួយ។
///
/// នេះប៉ះពាល់ដល់ឧទាហរណ៍ថាតើ `static` នៃប្រភេទដែលត្រូវបានដាក់នៅក្នុងការចងចាំបានតែអានអង្គចងចាំឋិតិវន្តឋិតិវន្តឬសរសេរបាន។
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// ប្រភេទដែលអាចត្រូវបានផ្លាស់ទីដោយសុវត្ថិភាពក្រោយពីត្រូវបានខ្ទាស់។
///
/// Rust ខ្លួនវាមានសញ្ញាណនៃប្រភេទអចលនវត្ថុនោះទេហើយចាត់ទុកផ្លាស់ទី (ឧទាហរណ៍តាមរយៈកិច្ចការឬ [`mem::replace`]) ដើម្បីតែងតែមានសុវត្ថិភាព។
///
/// ប្រភេទ [`Pin`][Pin] ត្រូវបានប្រើជំនួសដើម្បីការពារផ្លាស់ទីតាមរយៈប្រព័ន្ធប្រភេទ។ចង្អុរ `P<T>` រុំក្នុងប្រដាប់រុំ [`Pin<P<T>>`][Pin] មិនអាចរើចេញពីបានទេ។
/// សូមមើលឯកសារ [`pin` module] សម្រាប់ព័ត៌មានបន្ថែមអំពីការភ្ជាប់។
///
/// អនុវត្ត `Unpin` trait សម្រាប់ `T` ដកការរឹតបន្តឹងនៃការ pinning បិទប្រភេទដែលបន្ទាប់មកអនុញ្ញាតឱ្យផ្លាស់ប្តូរចេញពី [`Pin<P<T>>`][Pin] `T` ជាមួយមុខងារដូចជា [`mem::replace`] នេះ។
///
///
/// `Unpin` មានផលវិបាកទាំងអស់សម្រាប់ទិន្នន័យដែលមិនបានខ្ទាស់ទេ។
/// ជាពិសេស [`mem::replace`] សប្បាយរីករាយផ្លាស់ទីទិន្នន័យ `!Unpin` (វាធ្វើការសម្រាប់ `&mut T` ណាមួយមិនមែនគ្រាន់តែនៅពេលដែល `T: Unpin`) ។
/// ទោះជាយ៉ាងណា, អ្នកមិនអាចប្រើ [`mem::replace`] លើទិន្នន័យដែលបានរុំនៅក្នុង [`Pin<P<T>>`][Pin] មួយព្រោះអ្នកមិនអាចទទួលបាន `&mut T` ដែលអ្នកត្រូវការសម្រាប់ការនោះហើយដែលជា * * ធ្វើឱ្យប្រព័ន្ធអ្វីដែលនេះ។
///
/// ដូច្នេះនេះ, ឧទាហរណ៍, អាចត្រូវបានធ្វើតែនៅលើប្រភេទការអនុវត្ត `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // យើងត្រូវការឯកសារយោងដែលអាចផ្លាស់ប្តូរបានដើម្បីហៅទូរស័ព្ទ `mem::replace` ។
/// // យើងអាចទទួលបានឯកសារយោងបែបនេះដោយ (implicitly) ហៅ `Pin::deref_mut` ប៉ុន្តែវាអាចទៅរួចព្រោះ `String` អនុវត្ត `Unpin` ។
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// trait នេះត្រូវបានអនុវត្តដោយស្វ័យប្រវត្តិសម្រាប់ស្ទើរតែរៀងរាល់ប្រភេទ។
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// ប្រភេទសញ្ញាសម្គាល់មួយដែលមិនអនុវត្ត `Unpin` ។
///
/// បើប្រភេទមួយមាន `PhantomPinned` វានឹងមិនត្រូវបានអនុវត្ត `Unpin` ដោយលំនាំដើម។
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// ការប្រតិបត្តិនៃ `Copy` សម្រាប់ប្រភេទបុព្វកាល។
///
/// ការប្រតិបត្តិដែលមិនអាចត្រូវបានរៀបរាប់នៅក្នុង Rust ត្រូវបានអនុវត្តនៅក្នុង `traits::SelectionContext::copy_clone_conditions()` ក្នុង `rustc_trait_selection` ។
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// សេចក្តីយោងដែលបានចែករំលែកអាចត្រូវបានចម្លងទេតែសេចក្តីយោង mutable មិនអាច * *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}