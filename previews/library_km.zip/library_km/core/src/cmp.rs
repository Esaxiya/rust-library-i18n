//! មុខងារសម្រាប់ការតម្រៀបនិងការប្រៀបធៀប។
//!
//! ម៉ូឌុលនេះមានឧបករណ៍ជាច្រើនសម្រាប់ការបញ្ជានិងការប្រៀបធៀបតម្លៃ។សរុបមក:
//!
//! * [`Eq`] និង [`PartialEq`] គឺ traits ដែលអនុញ្ញាតឱ្យអ្នកកំណត់សមភាពសរុបនិងដោយផ្នែករវាងតម្លៃរៀងៗខ្លួន។
//! ការអនុវត្តពួកវា overloads ប្រតិបត្តិករ `==` និង `!=` ។
//! * [`Ord`] និង [`PartialOrd`] គឺ traits ដែលអនុញ្ញាតឱ្យអ្នកកំណត់លំដាប់សរុបនិងផ្នែករវាងតម្លៃរៀងៗខ្លួន។
//!
//! អនុវត្តពួកវាលើសបន្ទុកប្រតិបត្តិករ `<`, `<=`, `>` និង `>=` ។
//! * [`Ordering`] គឺបានត្រឡប់ដោយ enum មុខងារសំខាន់នៃ [`Ord`] និង [`PartialOrd`] មួយនិងរៀបរាប់អំពីលំដាប់មួយ។
//! * [`Reverse`] គឺ struct ដែលអនុញ្ញាតឱ្យអ្នកយ៉ាងងាយស្រួលបញ្ច្រាសលំដាប់មួយ។
//! * [`max`] និង [`min`] គឺជាមុខងារដែលបង្កើតចេញពី [`Ord`] និងអនុញ្ញាតឱ្យអ្នករកឃើញតម្លៃអតិបរមាឬអប្បបរមា។
//!
//! សម្រាប់សេចក្តីលម្អិតបន្ថែមសូមមើលឯកសាររៀងនៃធាតុគ្នានៅក្នុងបញ្ជី។
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait សម្រាប់ការប្រៀបធៀបសមភាពដែលជា [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ។
///
/// trait នេះអនុញ្ញាតឱ្យមានភាពស្មើគ្នាដោយផ្នែកសម្រាប់ប្រភេទដែលមិនមានទំនាក់ទំនងស្មើគ្នាពេញលេញ។
/// ឧទាហរណ៍នៅក្នុងលេខអណ្តែតលេខ `NaN != NaN` ដូច្នេះប្រភេទចំណុចអណ្តែតអនុវត្ត `PartialEq` ប៉ុន្តែមិនមែន [`trait@Eq`] ទេ។
///
/// ជាផ្លូវការសមភាពត្រូវតែមាន (សម្រាប់ `a`, `b`, `c` នៃប្រភេទ `A`, `B`, `C`)៖
///
/// - **ស៊ីមេទ្រី**៖ បើ `A: PartialEq<B>` និង `B: PartialEq<A>` ពេលនោះ **`a==b` បង្កប់ន័យ `b==a`**;និង
///
/// - **ការផ្លាស់ប្តូរ**៖ ប្រសិនបើ `A: PartialEq<B>` និង `B: PartialEq<C>` និង `A:
///   ផ្នែកអ៊ី<C>`បន្ទាប់មក` b `== **មួយនិង `b == c` បង្កប់ន័យ` មួយ==c`**។
///
/// ចំណាំថា impls `B: PartialEq<A>` (symmetric) និង `A: PartialEq<C>` (transitive) មិនត្រូវបានបង្ខំឱ្យមានតម្រូវការទាំងនេះត្រូវបានអនុវត្តនោះទេប៉ុន្តែពួកគេមិនទាន់មាននៅពេលណា។
///
/// ## Derivable
///
/// trait នេះអាចត្រូវបានប្រើជាមួយ `#[derive]` ។នៅពេលដែលទាញយក `នៅលើរចនាសម្ព័ន្ធ, ឧទាហរណ៍ពីរគឺស្មើគ្នាប្រសិនបើវាលទាំងអស់គឺស្មើនិងមិនស្មើប្រសិនបើវាលណាមួយមិនស្មើគ្នា។នៅពេល`ទាញយក` នៅលើអ៊ីនធឺរវ៉ារ្យ៉ង់នីមួយៗគឺស្មើនឹងខ្លួនវាហើយមិនស្មើនឹងវ៉ារ្យ៉ង់ផ្សេងទៀតទេ។
///
/// ## តើខ្ញុំអាចអនុវត្ត `PartialEq` យ៉ាងដូចម្តេច?
///
/// `PartialEq` តម្រូវឱ្យអនុវត្តវិធីសាស្ត្រ [`eq`] តែប៉ុណ្ណោះ។[`ne`] ត្រូវបានកំណត់នៅក្នុងលក្ខខណ្ឌរបស់វាតាមលំនាំដើម។ការអនុវត្តដោយដៃណាមួយនៃ [`ne`]*ត្រូវតែ* គោរពតាមច្បាប់ដែល [`eq`] គឺជាការដាក់បញ្ច្រាសយ៉ាងតឹងរឹងនៃ [`ne`];នោះគឺ `!(a == b)` ប្រសិនបើ `a != b` ។
///
/// ប្រតិបត្តិនៃ `PartialEq`, [`PartialOrd`] និង [`Ord`]*ត្រូវតែ* យល់ស្របជាមួយគ្នា។វាជាការងាយស្រួលក្នុងការធ្វើឱ្យពួកគេមិនយល់ស្របដោយចៃដន្យដោយអត្ថប្រយោជន៍ទាក់ទងនឹងការមួយចំនួននៃ traits និងការអនុវត្តផ្សេងទៀតដោយដៃ។
///
/// ការអនុវត្តឧទាហរណ៍សម្រាប់ដែនមួយដែលសៀវភៅពីរត្រូវបានចាត់ទុកថាជាសៀវភៅតែមួយប្រសិនបើ ISBN របស់ពួកគេត្រូវគ្នាទោះបីទ្រង់ទ្រាយខុសគ្នាក៏ដោយ។
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## តើខ្ញុំអាចប្រៀបធៀបប្រភេទពីរផ្សេងគ្នា?
///
/// ប្រភេទអ្នកអាចប្រៀបធៀបជាមួយនឹងត្រូវបានគ្រប់គ្រងដោយ: ប៉ារ៉ាម៉ែត្រប្រភេទ PartialEq` នេះ។
/// ឧទាហរណ៍តោះបង្កើនកូដមុនបន្តិច៖
///
/// ```
/// // ការអនុវត្តឩបករណ៍<BookFormat>==<BookFormat>ការប្រៀបធៀប
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // អនុវត្ត<Book>==<BookFormat>ការប្រៀបធៀប
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // អនុវត្ត<BookFormat>==<Book>ការប្រៀបធៀប
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// ដោយការផ្លាស់ប្តូរ `impl PartialEq for Book` ទៅ `impl PartialEq<BookFormat> for Book` យើងអនុញ្ញាតឱ្យ `BookFormat` ត្រូវបានប្រៀបធៀបជាមួយ `សៀវភៅ` ។
///
/// ប្រៀបធៀបដូចមួយខាងលើដែលមិនអើពើវាលមួយចំនួននៃការ struct នេះអាចមានះថាក់។វាអាចនាំឱ្យមានការរំលោភបំពានដោយអចេតនានៃតម្រូវការសម្រាប់ទំនាក់ទំនងស្មើភាពគ្នាដោយផ្នែក។
/// ឧទាហរណ៍ប្រសិនបើយើងទុកការអនុវត្តន៍ខាងលើនៃ `PartialEq<Book>` សម្រាប់ `BookFormat` និងបន្ថែមការអនុវត្ត `PartialEq<Book>` សម្រាប់ `Book` (តាមរយៈ `#[derive]` មួយឬតាមរយៈការអនុវត្តដោយដៃពីគំរូដំបូង) នោះលទ្ធផលនឹងបំពានលើការផ្លាស់ប្តូរ:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// វិធីសាស្រ្តនេះសាកល្បងតម្លៃ `self` និង `other` ស្មើនិងត្រូវបានប្រើដោយ `==` ។
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// វិធីសាស្រ្តនេះសាកល្បងសម្រាប់ `!=` ។
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// ម៉ាក្រូដេរីវេបង្កើត impl នៃ trait `PartialEq` មួយ។
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait សម្រាប់ការប្រៀបធៀបសមភាពដែលជា [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) ។
///
/// នេះមានន័យថាបន្ថែមពីលើ `a == b` និង `a != b` កំពុងដាក់បញ្ច្រាសយ៉ាងតឹងរ៉ឹងសមភាពត្រូវតែ (សម្រាប់ `a`, `b` និង `c`)៖
///
/// - reflexive: `a == a`;
/// - ស៊ីមេទ្រី: `a == b` មានន័យថា `b == a`;និង
/// - ការផ្លាស់ប្តូរ: `a == b` និង `b == c` បង្កប់ន័យ `a == c` ។
///
/// ទ្រព្យសម្បត្តិនេះមិនអាចត្រូវបានត្រួតពិនិត្យដោយអ្នកចងក្រងទេហើយដូច្នេះ `Eq` បង្កប់ន័យ [`PartialEq`] ហើយមិនមានវិធីបន្ថែមទេ។
///
/// ## Derivable
///
/// trait នេះអាចប្រើជាមួយ `#[derive]` ។
/// ពេល `derive`d, ព្រោះ `Eq` មានវិធីសាស្រ្តបន្ថែមទៀតទេ, វាត្រូវបានជូនដំណឹងតែចងក្រងថានេះគឺជាទំនាក់ទំនងស្មើជាជាងទំនាក់ទំនងស្មើមួយផ្នែក។
///
/// ចំណាំថាយុទ្ធសាស្រ្ត `derive` តម្រូវឱ្យមានវាលទាំងអស់គឺ `Eq` ដែលមិនតែងតែចង់បាន។
///
/// ## របៀបដែលខ្ញុំអាចអនុវត្ត `Eq`?
///
/// ប្រសិនបើអ្នកមិនអាចប្រើយុទ្ធសាស្រ្ត `derive` សូមបញ្ជាក់ថាប្រភេទរបស់អ្នកអនុវត្ត `Eq` ដែលមិនមានវិធីសាស្រ្តៈ
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // វិធីសាស្រ្តនេះត្រូវបានប្រើតែម្នាក់ឯងដោយ#[អត្ថប្រយោជន៍ទាក់ទង] ដើម្បីអះអាងថារាល់សមាសភាគនៃប្រភេទដែលមា#[អត្ថប្រយោជន៍ទាក់ទង] ខ្លួនវាផ្ទាល់, មធ្យោបាយហេដ្ឋារចនាសម្ព័ន្ធឧបករណ៍ហិរញ្ញវត្ថុបច្ចុប្បន្ននេះដោយមិនធ្វើការអះអាងលើ trait ប្រើវិធីសាស្រ្តនេះគឺជិតមិនអាចទៅរួចទេ។
    //
    //
    // ការនេះគួរតែមិនត្រូវបានអនុវត្តដោយដៃ។
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// ទាញយកម៉ាក្រូហ្សែនបង្កើតហ្សែនហ្សិនហ្សិតហ្សិចហ្ស៊ុយ។
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: struct នេះត្រូវបានប្រើតែម្នាក់ឯងដោយ#[ឩបករណ៍] ទៅ
// អះអាងថារាល់សមាសធាតុនៃប្រភេទមួយអនុវត្ត Eq ។
//
// រចនាសម្ព័ន្ធនេះមិនគួរបង្ហាញនៅក្នុងលេខកូដអ្នកប្រើប្រាស់ឡើយ។
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// អាន `Ordering` គឺជាលទ្ធផលនៃការប្រៀបធៀបរវាងតម្លៃពីរមួយ។
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// លំដាប់ដែលជាកន្លែងដែលតម្លៃបើធៀបមួយគឺតិចជាងមួយផ្សេងទៀត។
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// ការបញ្ជាទិញនៅកន្លែងដែលតម្លៃប្រៀបធៀបស្មើនឹងមួយទៀត។
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// ការបញ្ជាទិញនៅកន្លែងដែលតម្លៃប្រៀបធៀបធំជាងមួយផ្សេងទៀត។
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ត្រឡប់ `true` បើសិនជាលំដាប់គឺជាបំរែ `Equal` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ត្រឡប់ `true` ប្រសិនបើការបញ្ជាទិញមិនមែនជាវ៉ារ្យ៉ង់ `Equal` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ត្រឡប់ `true` បើសិនជាលំដាប់គឺជាបំរែ `Less` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ត្រឡប់ `true` ប្រសិនបើការតម្រៀបជាវ៉ារ្យ៉ង់ `Greater` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ត្រឡប់ `true` ប្រសិនបើការបញ្ជាទិញគឺទាំងវ៉ារ្យ៉ង់ `Less` ឬ `Equal` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ត្រឡប់ `true` បើសិនជាលំដាប់គឺមានទាំងវ៉ារ្យ៉ង់ `Greater` ឬ `Equal` ។
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// បញ្ច្រាស `Ordering` ។
    ///
    /// * `Less` ក្លាយជា `Greater` ។
    /// * `Greater` ក្លាយជា `Less` ។
    /// * `Equal` ក្លាយជា `Equal` ។
    ///
    /// # Examples
    ///
    /// ឥរិយាបថមូលដ្ឋាន៖
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// វិធីសាស្រ្តនេះអាចត្រូវបានប្រើដើម្បីបញ្ច្រាសការប្រៀបធៀបៈ
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // តម្រៀបអារេពីធំបំផុតទៅតូចបំផុត។
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// ដាក់ខ្សែសង្វាក់ពីរបញ្ជាទិញ។
    ///
    /// ត្រឡប់ `self` នៅពេលដែលវាមិនមែន `Equal` ។បើមិនដូច្នោះទេត្រឡប់ `other` ។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// ដាក់ខ្សែសង្វាក់តាមលំដាប់ដែលមានមុខងារដែលបានផ្តល់ឱ្យ។
    ///
    /// ត្រឡប់ `self` នៅពេលដែលវាមិនមែនជា `Equal` ។
    /// បើមិនដូច្នោះទេហៅទូរស័ព្ទ `f` ហើយត្រឡប់លទ្ធផល។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// struct ជំនួយសម្រាប់លំដាប់បញ្ច្រាស។
///
/// struct នេះជាជំនួយមួយដែលនឹងត្រូវបានប្រើជាមួយមុខងារដូច [`Vec::sort_by_key`] និងអាចត្រូវបានប្រើដើម្បីផ្លាស់ប្តូរការបញ្ជាទិញជាផ្នែកមួយនៃគន្លឹះសំខាន់មួយ។
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait សម្រាប់ប្រភេទដែលបង្កើត [total order](https://en.wikipedia.org/wiki/Total_order) មួយ។
///
/// ការបញ្ជាទិញគឺជាការបញ្ជាទិញសរុបប្រសិនបើវា (សម្រាប់ `a`, `b` និង `c` ទាំងអស់)៖
///
/// - សរុបនិង asymmetric: ពិតជាមួយនៃ `a < b`, `a == b` ឬ `a > b` គឺជាការពិត;និង
/// - ការផ្លាស់ប្តូរ, `a < b` និង `b < c` បង្កប់ន័យ `a < c` ។ដូចគ្នាត្រូវតែកាន់ទាំង `==` និង `>` ។
///
/// ## Derivable
///
/// trait នេះអាចប្រើជាមួយ `#[derive]` ។
/// ពេល `derive`d លើ structs វានឹងបង្កើតបានជាលំដាប់ [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ផ្អែកលើលំដាប់កំពូលដើម្បីប្រកាសបាតនៃសមាជិក struct នេះ។
///
/// ពេល `derive`d នៅលើ enum វ៉ារ្យ៉ង់ត្រូវបានបញ្ជាដោយគោលបំណងឌីសគ្រីមីណង់ពីកំពូលទៅបាតរបស់ពួកគេ។
///
/// ## ការប្រៀបធៀបខាងអក្សរសាស្ត្រ
///
/// ការប្រៀបធៀបសូរស័ព្ទគឺជាប្រតិបត្ដិការជាមួយនឹងលក្ខណៈសម្បត្តិដូចខាងក្រោមៈ
///  - លំដាប់ពីរនាក់ត្រូវបានប្រៀបធៀបធាតុធាតុ។
///  - ធាតុមិនត្រូវគ្នាដំបូងកំណត់ថាតើលំដាប់មួយណាដែលមានលក្ខណៈសូរស័ព្ទតិចឬធំជាងលេខផ្សេងទៀត។
///  - ប្រសិនបើមានលំដាប់មួយគឺបុព្វបទនៃការមួយផ្សេងទៀត, លំដាប់ខ្លីគឺស្ដីតិចជាងផ្សេងទៀត។
///  - ប្រសិនបើលំដាប់ពីរមានធាតុស្មើនិងមានប្រវែងដូចគ្នានោះលំដាប់នីមួយៗមានលក្ខណៈសូរស័ព្ទស្របគ្នា។
///  - មួយលំដាប់ទទេគឺស្ដីតិចជាងលំដាប់មិនទទេណាមួយ។
///  - លំដាប់ទទេពីរមានលក្ខណៈសូរស័ព្ទស្របគ្នា។
///
/// ## តើខ្ញុំអាចអនុវត្ត `Ord` យ៉ាងដូចម្តេច?
///
/// `Ord` តម្រូវឱ្យមានប្រភេទក៏ជា [`PartialOrd`] និង [`Eq`] (ដែលត្រូវការ [`PartialEq`]) ។
///
/// បន្ទាប់មកអ្នកត្រូវកំណត់ការអនុវត្តសម្រាប់ [`cmp`] ។អ្នកប្រហែលជាយល់ថាមានប្រយោជន៍ក្នុងការប្រើ [`cmp`] នៅលើវាលប្រភេទរបស់អ្នក។
///
/// ការអនុវត្ត [`PartialEq`], [`PartialOrd`], និង `Ord`*ត្រូវតែ* ព្រមព្រៀងគ្នា។
/// នោះគឺ `a.cmp(b) == Ordering::Equal` ប្រសិនបើនិងមានតែប្រសិនបើ `a == b` និង `Some(a.cmp(b)) == a.partial_cmp(b)` សម្រាប់ `a` និង `b` ទាំងអស់។
/// វាងាយស្រួលក្នុងការធ្វើឱ្យពួកគេមិនយល់ស្របដោយចៃដន្យដោយទទួលបាន traits និងអនុវត្តអ្នកដទៃដោយដៃ។
///
/// នេះជាឧទាហរណ៍មួយដែលអ្នកចង់តម្រៀបមនុស្សតាមកំពស់ដោយមិនយកចិត្តទុកដាក់លើ `id` និង `name`៖
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// វិធីសាស្រ្តនេះត្រឡប់ [`Ordering`] រវាង `self` និង `other` មួយ។
    ///
    /// ដោយអនុសញ្ញា, `self.cmp(&other)` ត្រឡប់លំដាប់ដែលផ្គូផ្គងនឹងកន្សោម `self <operator> other` បើពិត។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// បើប្រៀបធៀបទៅនិងត្រឡប់អតិបរមានៃតម្លៃពីរ។
    ///
    /// ត្រឡប់អាគុយម៉ង់ទីពីរប្រសិនបើការប្រៀបធៀបកំណត់ឱ្យពួកគេស្មើ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// បើប្រៀបធៀបទៅនិងត្រឡប់អប្បបរមានៃតម្លៃពីរ។
    ///
    /// ត្រឡប់អាគុយម៉ង់ដំបូងបើសិនជាប្រៀបធៀបជាអ្នកកំណត់ឱ្យពួកគេក្លាយស្មើគ្នា។
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// រឹតបន្តឹងតម្លៃទៅចន្លោះពេលជាក់លាក់មួយ។
    ///
    /// ត្រឡប់ `max` ប្រសិនបើ `self` ធំជាង `max` ហើយ `min` ប្រសិនបើ `self` តិចជាង `min` ។
    /// បើមិនដូច្នោះទេវាត្រឡប់មកវិញ `self` ។
    ///
    /// # Panics
    ///
    /// Panics ប្រសិនបើ `min > max` ។
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// ម៉ាក្រូដេរីវេបង្កើត impl នៃ trait `Ord` មួយ។
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait សម្រាប់តម្លៃដែលអាចត្រូវបានប្រៀបធៀបសម្រាប់តម្រៀបលំដាប់។
///
/// ការប្រៀបធៀបត្រូវតែពេញចិត្តសម្រាប់ `a`, `b` និង `c` ទាំងអស់៖
///
/// - asymmetry: ប្រសិនបើ `a < b` បន្ទាប់មក `!(a > b)` ក៏ដូចជា `a > b` ដែលបដិសេធ `!(a < b)`;និង
/// - ការឆ្លងកាត់: `a < b` និង `b < c` បង្កប់ន័យ `a < c` ។ដូចគ្នាត្រូវតែកាន់ទាំង `==` និង `>` ។
///
/// ចំណាំថាតម្រូវការទាំងនេះមានន័យថា trait ខ្លួនវាត្រូវតែត្រូវបានអនុវត្តស៊ីមេទ្រីនិងផ្លាស់ប្តូរ: ប្រសិនបើ `T: PartialOrd<U>` និង `U: PartialOrd<V>` បន្ទាប់មក `U: PartialOrd<T>` និង `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// trait នេះអាចប្រើជាមួយ `#[derive]` ។នៅពេលដែលទាញយកពីរចនាសម្ព័ន្ធវានឹងបង្កើតលំដាប់សូរស័ព្ទដោយផ្អែកលើលំដាប់ប្រកាសពីកំពូលទៅបាតរបស់សមាជិករបស់រចនាសម្ព័ន្ធ។
/// ពេល `derive`d នៅលើ enum វ៉ារ្យ៉ង់ត្រូវបានបញ្ជាដោយគោលបំណងឌីសគ្រីមីណង់ពីកំពូលទៅបាតរបស់ពួកគេ។
///
/// ## តើខ្ញុំអាចអនុវត្ត `PartialOrd` យ៉ាងដូចម្តេច?
///
/// `PartialOrd` តម្រូវឱ្យមានការអនុវត្តវិធីសាស្ត្រ [`partial_cmp`] ជាមួយវិធីផ្សេងទៀតដែលត្រូវបានបង្កើតពីការប្រតិបត្តិតាមលំនាំដើម។
///
/// ទោះជាយ៉ាងណាវានៅតែអាចធ្វើទៅបានដើម្បីអនុវត្តអ្នកផ្សេងទៀតដោយឡែកពីគ្នាសម្រាប់ប្រភេទដែលមិនមានការបញ្ជាទិញសរុប។
/// ឧទាហរណ៍សម្រាប់អណ្តែតទឹកចំនួនដែលចំណុច `NaN < 0 == false` និង `NaN >= 0 == false` (Cf.
/// ផ្នែក IEEE 754-2008 ផ្នែក 5.11) ។
///
/// `PartialOrd` តម្រូវឱ្យទៅជាប្រភេទរបស់អ្នក [`PartialEq`] ។
///
/// ការអនុវត្ត [`PartialEq`], `PartialOrd`, និង [`Ord`]*ត្រូវតែ* ព្រមព្រៀងគ្នា។
/// វាងាយស្រួលក្នុងការធ្វើឱ្យពួកគេមិនយល់ស្របដោយចៃដន្យដោយទទួលបាន traits និងអនុវត្តអ្នកដទៃដោយដៃ។
///
/// បើប្រភេទរបស់អ្នកគឺ [`Ord`], អ្នកអាចអនុវត្ត [`partial_cmp`] ដោយប្រើ [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// អ្នកអាចរកឃើញថាវាមានប្រយោជន៍ក្នុងការប្រើនៅលើវាលប្រភេទ [`partial_cmp`] របស់អ្នក។
/// នេះគឺជាឧទាហរណ៍នៃប្រភេទ `Person` ដែលមានវាលអណ្តែតទឹក `height` ដែលជាវាលតែមួយគត់ដែលត្រូវបានប្រើសម្រាប់ការតម្រៀប៖
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// វិធីសាស្ត្រនេះត្រឡប់ការបញ្ជាទិញរវាងតម្លៃ `self` និង `other` ប្រសិនបើមាន។
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// នៅពេលដែលការប្រៀបធៀបគឺមិនអាចទៅរួចនោះទេ:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// វិធីសាស្រ្តនេះសាកល្បងតិចជាង (សម្រាប់ `self` និង `other`) និងត្រូវបានប្រើដោយប្រតិបត្តិករ `<` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// វិធីសាស្រ្តនេះធ្វើតេស្តតិចជាងឬស្មើ (សម្រាប់ `self` និង `other`) ហើយត្រូវបានប្រើដោយប្រតិបត្តិករ `<=` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// វិធីសាស្រ្តនេះសាកល្បងធំជាង (សម្រាប់ `self` និង `other`) និងត្រូវបានប្រើដោយប្រតិបត្តិករ `>` ។
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// វិធីសាស្ត្រនេះធ្វើតេស្តធំជាងឬស្មើ (សម្រាប់ `self` និង `other`) ហើយត្រូវបានប្រើដោយប្រតិបត្តិករ `>=` ។
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// ទាញយកម៉ាក្រូហ្សែនបង្កើតហ្សែនហ្សិនហ្សិតហ្សិចហ្ស៊ុយ។
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// បើប្រៀបធៀបទៅនិងត្រឡប់អប្បបរមានៃតម្លៃពីរ។
///
/// ត្រឡប់អាគុយម៉ង់ដំបូងបើសិនជាប្រៀបធៀបជាអ្នកកំណត់ឱ្យពួកគេក្លាយស្មើគ្នា។
///
/// ប្រើឈ្មោះក្លែងក្លាយទៅ [`Ord::min`] ។
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// ត្រឡប់អប្បបរមានៃតម្លៃពីរទាក់ទងនឹងមុខងារប្រៀបធៀបដែលបានបញ្ជាក់។
///
/// ត្រឡប់អាគុយម៉ង់ដំបូងបើសិនជាប្រៀបធៀបជាអ្នកកំណត់ឱ្យពួកគេក្លាយស្មើគ្នា។
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// ត្រឡប់ធាតុដែលផ្តល់តម្លៃអប្បបរមាពីមុខងារដែលបានបញ្ជាក់។
///
/// ត្រឡប់អាគុយម៉ង់ដំបូងបើសិនជាប្រៀបធៀបជាអ្នកកំណត់ឱ្យពួកគេក្លាយស្មើគ្នា។
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// បើប្រៀបធៀបទៅនិងត្រឡប់អតិបរមានៃតម្លៃពីរ។
///
/// ត្រឡប់អាគុយម៉ង់ទីពីរប្រសិនបើការប្រៀបធៀបកំណត់ឱ្យពួកគេស្មើ។
///
/// ប្រើឈ្មោះក្លែងក្លាយទៅ [`Ord::max`] ។
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// ត្រឡប់តម្លៃអតិបរមាចំនួនពីរដោយគោរពមុខងារប្រៀបធៀបដែលបានបញ្ជាក់។
///
/// ត្រឡប់អាគុយម៉ង់ទីពីរប្រសិនបើការប្រៀបធៀបកំណត់ឱ្យពួកគេស្មើ។
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// ត្រឡប់ធាតុដែលផ្តល់តម្លៃអតិបរមាពីមុខងារដែលបានបញ្ជាក់។
///
/// ត្រឡប់អាគុយម៉ង់ទីពីរប្រសិនបើការប្រៀបធៀបកំណត់ឱ្យពួកគេស្មើ។
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// ការប្រតិបត្តិនៃផ្នែកខ្លះអេច, អេច, ផ្នែកខ្លះអ័រនិងអ័រដាប់សំរាប់ប្រភេទបឋម
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // លំដាប់មាននៅទីនេះគឺមានសារៈសំខាន់ក្នុងការបង្កើតការជួបប្រជុំគ្នាល្អប្រសើរបន្ថែមទៀត។
                    // សូមមើល <https://github.com/rust-lang/rust/issues/63758> សម្រាប់ព័ត៌មានបន្ថែម។
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // ការខាសទៅ i8's និងបំលែងភាពខុសគ្នាទៅនឹងការបញ្ជាទិញបង្កើតការជួបប្រជុំគ្នាកាន់តែប្រសើរ។
            //
            // សូមមើល <https://github.com/rust-lang/rust/issues/66780> តមានបន្ថែម។
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // សុវត្ថិភាព: bool ជាការ i8 ត្រឡប់ 0 ឬ 1, ដូច្នេះភាពខុសគ្នានេះមិនអាចមានអ្វីផ្សេងទៀត
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // ព្រួញ&

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}