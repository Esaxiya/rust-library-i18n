//! `Clone` trait សម្រាប់ប្រភេទដែលមិនអាចត្រូវបាន "ចម្លង" យ៉ាងច្បាស់។
//!
//! នៅក្នុង Rust ប្រភេទសាមញ្ញមួយចំនួនគឺ "implicitly copyable" ហើយនៅពេលអ្នកចាត់តាំងឬហុចវាជាអាគុយម៉ង់អ្នកទទួលនឹងទទួលបានច្បាប់ចម្លងដោយទុកតម្លៃដើមនៅនឹងកន្លែង។
//! ប្រភេទទាំងនេះមិនតម្រូវឱ្យមានការបែងចែកដើម្បីថតចម្លងនិងមិនមានអ្នកបញ្ចប់ (មានន័យថាពួកគេមិនមានប្រអប់ផ្ទាល់ខ្លួនឬអនុវត្ត [`Drop`]) ដូច្នេះអ្នកចងក្រងចាត់ទុកថាពួកគេចម្លងតម្លៃថោកនិងមានសុវត្ថិភាព។
//!
//! សម្រាប់ប្រភេទផ្សេងទៀតជាច្បាប់ចម្លងត្រូវតែត្រូវបានធ្វើឡើងយ៉ាងជាក់លាក់ដោយអនុសញ្ញាការអនុវត្ត [`Clone`] trait និងបានហៅវិធីសាស្រ្ត [`clone`] ។
//!
//! [`clone`]: Clone::clone
//!
//! ឧទាហរណ៍ការប្រើប្រាស់មូលដ្ឋាន៖
//!
//! ```
//! let s = String::new(); // ប្រភេទខ្សែអក្សរក្លូនក្លូន
//! let copy = s.clone(); // ដូច្នេះយើងអាចក្លូនវា
//! ```
//!
//! ដើម្បីអនុវត្តក្លូន trait យ៉ាងងាយស្រួលអ្នកក៏អាចប្រើ `#[derive(Clone)]` ផងដែរ។ឧទាហរណ៍ៈ
//!
//! ```
//! #[derive(Clone)] // យើងបន្ថែមក្លូន trait ដើម្បី struct Morpheus
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ហើយឥឡូវនេះយើងអាចក្លូនវា!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait ទូទៅសម្រាប់សមត្ថភាពចម្លងវត្ថុមួយយ៉ាងជាក់លាក់។
///
/// ខុសពី [`Copy`] ក្នុង [`Copy`] នោះគឺខ្លាំងណាស់និងមានតំលៃថោកជាក់ច្បាស់ខណៈពេលដែល `Clone` គឺតែងតែជាក់លាក់និងអាចឬមិនអាចមានតម្លៃថ្លៃ។
/// ដើម្បីអនុវត្តចរិតទាំងនេះ Rust មិនអនុញ្ញាតឱ្យអ្នកអនុវត្ត [`Copy`] ទេប៉ុន្តែអ្នកអាចបំពេញបន្ថែម `Clone` និងដំណើរការកូដតាមអំពើចិត្ត។
///
/// ចាប់តាំងពីពេល `Clone` គឺច្រើនជាង [`Copy`], អ្នកអាចធ្វើឱ្យដោយស្វ័យប្រវត្តិមានអ្វី [`Copy`] ក្លាយ `Clone` ផងដែរ។
///
/// ## Derivable
///
/// trait នេះអាចប្រើជាមួយ `#[derive]` ប្រសិនបើវាលទាំងអស់ជា `Clone` ។នេះ `ការអនុវត្ត derive`d នៃការហៅ [`clone`] នៅលើ [`Clone`] វាលគ្នា។
///
/// [`clone`]: Clone::clone
///
/// ចំពោះការ struct ទូទៅ, `#[derive]` អនុវត្ត `Clone` លក្ខខណ្ឌដោយបន្ថែមប៉ារ៉ាម៉ែត្រចង `Clone` នៅលើទូទៅ។
///
/// ```
/// // `derive` អនុវត្តក្លូនសម្រាប់ការអាន<T>នៅពេលដែល T គឺជាក្លូន។
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## តើខ្ញុំអាចអនុវត្ត `Clone` យ៉ាងដូចម្តេច?
///
/// ប្រភេទដែលមាន [`Copy`] គួរតែមានការអនុវត្តមិនសំខាន់នៃ `Clone` ។ជាផ្លូវការបន្ថែមទៀត៖
/// ប្រសិនបើ `T: Copy`, `x: T`, និង `y: &T` នោះ `let x = y.clone();` គឺស្មើនឹង `let x = *y;` ។
/// សៀវភៅណែនាំគួរតែមានការអនុវត្តការប្រុងប្រយ័ត្នក្នុងការលើកកំពស់មិនផ្លាស់ប្ដូរនេះ;ទោះយ៉ាងណាកូដដែលមិនមានសុវត្ថិភាពមិនត្រូវពឹងផ្អែកលើវាដើម្បីធានាបាននូវសុវត្ថិភាពនៃការចងចាំ។
///
/// ឧទាហរណ៍មួយគឺរចនាសម្ព័ន្ធទូទៅដែលមានទ្រនិចមុខងារ។ក្នុងករណីនេះការអនុវត្តន៍ `Clone` មិនអាចជា `derive`d ប៉ុន្តែអាចត្រូវបានអនុវត្តជា:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## អ្នកអនុវត្តបន្ថែម
///
/// បន្ថែមលើ [implementors listed below][impls] ប្រភេទដូចខាងក្រោមក៏អនុវត្ត `Clone` ដែរ៖
///
/// * ប្រភេទធាតុអនុគមន៍ (ពោលគឺប្រភេទខុសគ្នាដែលបានកំណត់សម្រាប់មុខងារគ្នា)
/// * ប្រភេទទ្រនិចមុខងារ (ឧ។ `fn() -> i32`)
/// * ប្រភេទអារេសម្រាប់ទំហំទាំងអស់ប្រសិនបើប្រភេទធាតុក៏អនុវត្ត `Clone` (ឧទាហរណ៍ `[i32; 123456]`)
/// * ប្រភេទ tuple ប្រសិនបើសមាសភាគគ្នាអនុវត្ត `Clone` (ឧ `()`, `(i32, bool)`)
/// * ប្រភេទការបិទប្រសិនបើពួកគេចាប់យកគ្មានតម្លៃពីបរិស្ថានឬប្រសិនបើតម្លៃដែលបានចាប់យកទាំងអស់អនុវត្ត `Clone` ដូចជាខ្លួនឯងផ្ទាល់។
///   ចំណាំថាអថេរដែលបានចាប់យកដោយសេចក្តីយោងដែលបានចែករំលែកតែងតែអនុវត្ត `Clone` (បើទោះបីជាសេចក្ដីយោងមិនមាន) ខណៈពេលអថេរដែលបានចាប់យកដោយសេចក្តីយោង mutable មិនអនុវត្ត `Clone` ។
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// ត្រឡប់ច្បាប់ចម្លងនៃតម្លៃ។
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ក្លូនអនុវត្ត
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// អនុវត្តការប្រគល់ច្បាប់ចម្លងពី `source` ។
    ///
    /// `a.clone_from(&b)` គឺស្មើនឹង `a = b.clone()` នៅក្នុងមុខងារប៉ុន្តែអាចត្រូវបានបដិសេធក្នុងការប្រើប្រាស់ធនធានរបស់ `a` ដើម្បីជៀសវាងការបែងចែកដែលមិនចាំបាច់។
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// ទាញយកម៉ាក្រូហ្សែនបង្កើតហ្សែនហ្សិនហ្សិតហ្សិចហ្ស៊ុយ។
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): structs ទាំងនេះត្រូវបានប្រើតែម្នាក់ឯងដោយ#[ដេរីវេ] ដើម្បីអះអាងថារាល់សមាសភាគនៃប្រភេទដែលមាក្លូនឬចម្លង។
//
//
// រចនាសម្ព័ន្ធទាំងនេះមិនគួរបង្ហាញនៅក្នុងលេខកូដអ្នកប្រើប្រាស់ឡើយ។
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// ការប្រតិបត្តិនៃ `Clone` សម្រាប់ប្រភេទបុព្វកាល។
///
/// ការប្រតិបត្តិដែលមិនអាចត្រូវបានរៀបរាប់នៅក្នុង Rust ត្រូវបានអនុវត្តនៅក្នុង `traits::SelectionContext::copy_clone_conditions()` ក្នុង `rustc_trait_selection` ។
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// សេចក្តីយោងចែករំលែកអាចត្រូវបានក្លូនទេតែសេចក្តីយោង mutable មិនអាច * *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// សេចក្តីយោងចែករំលែកអាចត្រូវបានក្លូនទេតែសេចក្តីយោង mutable មិនអាច * *!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}