//! ការគាំទ្រ Panic សម្រាប់ libcore
//!
//! បណ្ណាល័យស្នូលមិនអាចកំណត់ការភ័យស្លន់ស្លោបានទេប៉ុន្តែវាត្រូវប្រកាស * ភ័យស្លន់ស្លោ។
//! នេះមានន័យថាមុខងារនៅខាងក្នុងនៃ libcore ត្រូវបានអនុញ្ញាតិអោយប្រើ panic ប៉ុន្តែដើម្បីអោយវាមានប្រយោជន៏ crate ដែលនៅខាងលើត្រូវតែកំនត់នូវភាពភ័យស្លន់ស្លោសំរាប់ libcore ប្រើប្រាស់។
//! ចំណុចប្រទាក់បច្ចុប្បន្នសម្រាប់ការភ័យស្លន់ស្លោគឺ៖
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! និយមន័យនេះអនុញ្ញាតឱ្យមានការភិតភ័យជាមួយនឹងសារទូទៅណាមួយប៉ុន្តែវាមិនអនុញ្ញាតឱ្យបរាជ័យជាមួយនឹងតម្លៃ `Box<Any>` ទេ។
//! (`PanicInfo` គ្រាន់តែមាន `&(dyn Any + Send)` ប៉ុណ្ណោះដែលយើងបំពេញនូវចំនុចអត់ចេះសោះនៅក្នុង `PanicInfo: : internal_constructor` ។) ហេតុផលសម្រាប់នេះគឺថា libcore មិនត្រូវបានអនុញ្ញាតឱ្យបម្រុងទុក។
//!
//!
//! ម៉ូឌុលនេះមានមុខងារភ័យស្លន់ស្លោពីរបីផ្សេងទៀតប៉ុន្តែទាំងនេះគ្រាន់តែជាធាតុចាំបាច់សម្រាប់អ្នកចងក្រង។panics ទាំងអស់ត្រូវបានដំណើរការតាមរយៈមុខងារមួយនេះ។
//! និមិត្តសញ្ញាពិតប្រាកដត្រូវបានប្រកាសតាមរយៈគុណលក្ខណៈ `#[panic_handler]` ។
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ការអនុវត្តមូលដ្ឋានម៉ាក្រូ `panic!` X ម៉ាក្រេសនៅពេលគ្មានការធ្វើទ្រង់ទ្រាយ។
#[cold]
// មិនត្រូវចូលបន្ទាត់ឡើយលើកលែងតែភាពភ័យស្លន់ស្លោដើម្បីជៀសវាងការហើមពោះនៅតាមកន្លែងហៅទូរស័ព្ទតាមដែលអាចធ្វើទៅបាន
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ត្រូវការដោយ codegen សម្រាប់ panic លើការហូរហៀរនិងស្ថានីយ `Assert` MIR ផ្សេងទៀត
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ប្រើ Arguments::new_v1 ជំនួស format_args! ("{}", expr) ដើម្បីកាត់បន្ថយសក្តានុពលនៃទំហំ។
    // format_args!ម៉ាក្រូប្រើ str's X trait ដើម្បីសរសេរ expr ដែលហៅថា Formatter::pad ដែលត្រូវតែផ្ទុកខ្សែអក្សរខ្លីនិងទ្រនាប់ (ទោះបីជាគ្មានប្រើនៅទីនេះក៏ដោយ) ។
    //
    // ការប្រើប្រាស់ Arguments::new_v1 អាចអនុញ្ញាតិអោយអ្នកចងក្រងលុប Formatter::pad ចេញពីប្រព័ន្ធគោលពីរនៃទិន្នផលដោយសន្សំសំចៃថាមពលបានពីរបីគីប។
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // ត្រូវការសម្រាប់ panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // ត្រូវការដោយ codegen សំរាប់ panic លើការចូលប្រើ OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ការអនុវត្តមូលដ្ឋានម៉ាក្រូ `panic!` X ម៉ាក្រេសនៅពេលធ្វើទ្រង់ទ្រាយត្រូវបានប្រើ។
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ចំណាំមុខងារនេះមិនដែលឆ្លងកាត់ព្រំដែនរបស់អេហ្វអេអាយ។វាជាការហៅ Rust-to-Rust ដែលត្រូវបានដោះស្រាយចំពោះមុខងារ `#[panic_handler]` ។
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // សុវត្ថិភាព: `panic_impl` ត្រូវបានកំណត់ដោយកូដ Rust ដែលមានសុវត្ថិភាពហើយដូច្នេះមានសុវត្ថិភាពក្នុងការហៅចេញ។
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// មុខងារផ្ទៃក្នុងសម្រាប់ម៉ាក្រូ `assert_eq!` និង `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}