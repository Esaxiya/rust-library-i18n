#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// មើល [`prefetch`](fn._prefetch.html) ។
pub const _PREFETCH_READ: i32 = 0;

/// មើល [`prefetch`](fn._prefetch.html) ។
pub const _PREFETCH_WRITE: i32 = 1;

/// មើល [`prefetch`](fn._prefetch.html) ។
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// មើល [`prefetch`](fn._prefetch.html) ។
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// មើល [`prefetch`](fn._prefetch.html) ។
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// មើល [`prefetch`](fn._prefetch.html) ។
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// ទាញយកបន្ទាត់ឃ្លាំងដែលមានអាសយដ្ឋាន `p` ដោយប្រើ `rw` និង `locality` ដែលបានផ្តល់ឱ្យ។
///
/// `rw` ត្រូវតែជាផ្នែកមួយនៃ:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): Prefetch នេះត្រូវបានរៀបចំសម្រាប់ការអាន។
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): prefetch កំពុងរៀបចំសម្រាប់ការសរសេរមួយ។
///
/// `locality` ត្រូវតែជាផ្នែកមួយនៃៈ
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): ស្ទ្រីមឬការស្វែងរកដែលមិនមែនជាបណ្តោះអាសន្នសម្រាប់ទិន្នន័យដែលត្រូវបានប្រើតែម្តង។
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): ទៅរកឃ្លាំងសម្ងាត់កម្រិតទី ៣ ។
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): ទៅយកចូលទៅក្នុងកម្រិតទី 2 ឃ្លាំងសម្ងាត់។
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): ទៅយកចូលទៅក្នុងកម្រិតទី 1 ឃ្លាំងសម្ងាត់។
///
/// នេះជាការណែនាំការចងចាំទុកមើលបង្ហាញសញ្ញាដល់ប្រព័ន្ធអង្គចងចាំដែលបានចូលដំណើរការចងចាំពីអាសយដ្ឋានដែលបានបញ្ជាក់មួយដែលទំនងជានឹងកើតមានឡើងនៅក្បែរ future ។
/// ប្រព័ន្ធការចងចាំនេះអាចឆ្លើយតបដោយការទទួលយកសកម្មភាពដែលត្រូវបានរំពឹងថានឹងបង្កើនល្បឿនការចូលប្រើសតិនេះពេលដែលពួកគេកើតមានឡើងដូចជាការផ្ទុកជាមុនអាសយដ្ឋានដែលបានបញ្ជាក់ទៅក្នុងឃ្លាំងសម្ងាត់មួយឬច្រើន។
///
/// ដោយសារតែសញ្ញាទាំងនេះគឺមានតែគន្លឹះ, វាជាការត្រឹមត្រូវសម្រាប់ស៊ីភីយូជាក់លាក់មួយក្នុងការព្យាបាលការណែនាំជាមុនណាមួយឬទាំងអស់ជារៀលមួយ។
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // យើងប្រើ instrinsic `llvm.prefetch` ជាមួយ `cache type` =1 (ឃ្លាំងសម្ងាត់ទិន្នន័យ) ។
    // `rw` និង `strategy` ត្រូវបានផ្អែកលើប៉ារ៉ាម៉ែត្រមុខងារ។
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}