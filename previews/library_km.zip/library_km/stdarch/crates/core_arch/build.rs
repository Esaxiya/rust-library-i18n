use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // ត្រូវបានប្រើដើម្បីប្រាប់ចំណារពន្យល់ `#[assert_instr]` របស់យើងដែលថាការធ្វើស៊ែរឌីជីថលទាំងអស់អាចប្រើដើម្បីសាកល្បងលេខកូដរបស់ពួកគេពីព្រោះខ្លះត្រូវបានដាក់នៅពីក្រោយ `-Ctarget-feature=+unimplemented-simd128` បន្ថែមដែលមិនមានសមមូលនៅក្នុង `#[target_feature]` ឥឡូវនេះ។
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}