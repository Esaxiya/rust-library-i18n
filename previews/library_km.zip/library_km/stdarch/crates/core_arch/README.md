`core::arch` - ស្ថាបត្យកម្មបណ្ណាល័យពិសេសរបស់សាជីវកម្ម Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

ម៉ូឌុល `core::arch` អនុវត្តតាមស្ថាបត្យកម្មដែលពឹងផ្អែកលើស្ថាបត្យកម្ម (ឧទាហរណ៍ស៊ីមឌី) ។

# Usage 

`core::arch` មានជាផ្នែកមួយនៃ `libcore` ហើយវាត្រូវបាននាំចេញឡើងវិញដោយ `libstd` ។ចូលចិត្តប្រើវាតាមរយៈ `core::arch` ឬ `std::arch` ជាងតាមរយៈ crate នេះ។
លក្ខណៈពិសេសមិនស្ថិតស្ថេរជាញឹកញាប់មាននៅក្នុង Rust ពេលយប់តាមរយៈ `feature(stdsimd)` នេះ។

ការប្រើ `core::arch` តាមរយៈ crate នេះតម្រូវឱ្យមានពេលយប់ Rust ហើយវាអាចធ្វើបាន (ហើយទេ) បំបែកជាញឹកញាប់។តែនៅក្នុងករណីដែលអ្នកគួរតែពិចារណាប្រើវាតាមរយៈ crate នេះគឺ:

* ប្រសិនបើអ្នកត្រូវចងក្រងឡើងវិញដោយខ្លួនអ្នក `core::arch` ឧ, ជាមួយនឹងលក្ខណៈពិសេសជាពិសេសគោលដៅដែលបានអនុញ្ញាតដែលមិនត្រូវបានអនុញ្ញាតសម្រាប់ `libcore`/`libstd` ។
Note: ប្រសិនបើអ្នកត្រូវចងក្រងឡើងវិញសម្រាប់គោលដៅវាមិនស្តង់ដារសូមចូលចិត្តប្រើប្រាស់ `xargo` ឡើងវិញចងក្រងនិងជាការសមរម្យជំនួសឱ្យ `libcore`/`libstd` ការប្រើ crate នេះ។
  
* ដោយប្រើលក្ខណៈពិសេសមួយចំនួនដែលអាចនឹងមិនអាចនៅពីក្រោយដែលមានលក្ខណៈពិសេសមិនស្ថិតស្ថេរ Rust ។យើងបានព្យាយាមដើម្បីរក្សាទាំងនេះទៅអប្បបរមា។
ប្រសិនបើអ្នកត្រូវការប្រើលក្ខណៈពិសេសទាំងនេះសូមបើកបញ្ហាមួយដូច្នេះថាយើងអាចបង្ហាញពួកគេនៅពេលយប់ Rust ហើយអ្នកអាចប្រើពួកវាចេញពីទីនោះ។

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` ត្រូវបានចែកចាយជាចម្បងតាមលក្ខខណ្ឌនៃអាជ្ញាប័ណ្ណ MIT និងអាជ្ញាប័ណ្ណ Apache (កំណែ 2.0) ជាមួយនឹងផ្នែកដែលគ្របដណ្តប់ដោយអាជ្ញាប័ណ្ណដូច BSD ផ្សេងៗ។

សូមមើលអាជ្ញាប័ណ្ណ-APACHE និងអាជ្ញាប័ណ្ណ-MIT ដែលសម្រាប់លម្អិត។

# Contribution

ប្រសិនបើអ្នកបញ្ជាក់យ៉ាងច្បាស់បើមិនដូច្នោះទេរាល់ការចូលរួមវិភាគទានដែលបានដាក់ស្នើដោយចេតនាសម្រាប់ការដាក់បញ្ចូល `core_arch` X ដោយអ្នកដែលបានកំណត់នៅក្នុងអាជ្ញាប័ណ្ណ Apache-2.0 នឹងត្រូវទទួលបានអាជ្ញាប័ណ្ណពីរដូចខាងលើដោយគ្មានលក្ខខណ្ឌបន្ថែម។


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












