use crate::Span;

/// អង់ស៊ីមតំណាងឱ្យកម្រិតរោគវិនិច្ឆ័យ។
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Copy, Clone, Debug)]
#[non_exhaustive]
pub enum Level {
    /// កំហុសមួយ។
    Error,
    /// ការព្រមាន។
    Warning,
    /// កំណត់ចំណាំមួយ។
    Note,
    /// សារជំនួយ។
    Help,
}

/// Trait អនុវត្តតាមប្រភេទដែលអាចបំលែងជាសំណុំ `អេស្បាញ។
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub trait MultiSpan {
    /// បំលែង `self` ទៅជា `Vec<Span>` ។
    fn into_spans(self) -> Vec<Span>;
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Span {
    fn into_spans(self) -> Vec<Span> {
        vec![self]
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl MultiSpan for Vec<Span> {
    fn into_spans(self) -> Vec<Span> {
        self
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> MultiSpan for &'a [Span] {
    fn into_spans(self) -> Vec<Span> {
        self.to_vec()
    }
}

/// រចនាសម្ព័នដែលតំណាងឱ្យសាររោគវិនិច្ឆ័យនិងសារកុមារដែលជាប់ទាក់ទង។
///
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
#[derive(Clone, Debug)]
pub struct Diagnostic {
    level: Level,
    message: String,
    spans: Vec<Span>,
    children: Vec<Diagnostic>,
}

macro_rules! diagnostic_child_methods {
    ($spanned:ident, $regular:ident, $level:expr) => {
        /// បន្ថែមសាររោគវិនិច្ឆ័យកុមារថ្មីទៅ `self` ជាមួយនឹងកម្រិតដែលបានកំណត់ដោយឈ្មោះវិធីសាស្រ្តនេះជាមួយ `spans` និង `message` ដែលបានផ្តល់ឱ្យ។
        ///
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $spanned<S, T>(mut self, spans: S, message: T) -> Diagnostic
        where
            S: MultiSpan,
            T: Into<String>,
        {
            self.children.push(Diagnostic::spanned(spans, $level, message));
            self
        }

        /// បន្ថែមសាររោគវិនិច្ឆ័យកុមារថ្មីទៅ `self` ជាមួយនឹងកម្រិតដែលបានកំណត់ដោយឈ្មោះវិធីសាស្រ្តនេះជាមួយ `message` ដែលបានផ្តល់ឱ្យ។
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $regular<T: Into<String>>(mut self, message: T) -> Diagnostic {
            self.children.push(Diagnostic::new($level, message));
            self
        }
    };
}

/// ឧបករណ៍បំលែងលើការធ្វើរោគវិនិច្ឆ័យរបស់កុមារនៃអេចអេសអេច `Diagnostic` X ។
#[derive(Debug, Clone)]
#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub struct Children<'a>(std::slice::Iter<'a, Diagnostic>);

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl<'a> Iterator for Children<'a> {
    type Item = &'a Diagnostic;

    fn next(&mut self) -> Option<Self::Item> {
        self.0.next()
    }
}

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
impl Diagnostic {
    /// បង្កើតការធ្វើរោគវិនិច្ឆ័យថ្មីជាមួយ `level` និង `message` ដែលបានផ្តល់ឱ្យ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn new<T: Into<String>>(level: Level, message: T) -> Diagnostic {
        Diagnostic { level, message: message.into(), spans: vec![], children: vec![] }
    }

    /// បង្កើតថ្មីមួយជាមួយ `level` ធ្វើរោគវិនិច្ឆ័យនិង `message` ចង្អុលផ្តល់ទៅឱ្យសំណុំដែលបានផ្តល់ឱ្យនៃ `spans` ។
    ///
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spanned<S, T>(spans: S, level: Level, message: T) -> Diagnostic
    where
        S: MultiSpan,
        T: Into<String>,
    {
        Diagnostic { level, message: message.into(), spans: spans.into_spans(), children: vec![] }
    }

    diagnostic_child_methods!(span_error, error, Level::Error);
    diagnostic_child_methods!(span_warning, warning, Level::Warning);
    diagnostic_child_methods!(span_note, note, Level::Note);
    diagnostic_child_methods!(span_help, help, Level::Help);

    /// ត្រឡប់ការធ្វើរោគវិនិច្ឆ័យ `level` សម្រាប់ `self` ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn level(&self) -> Level {
        self.level
    }

    /// កំណត់កម្រិតក្នុង `self` ដើម្បី `level` ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_level(&mut self, level: Level) {
        self.level = level;
    }

    /// ត្រឡប់សារជា `self` ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn message(&self) -> &str {
        &self.message
    }

    /// កំណត់សារក្នុង `self` ទៅ `message` ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_message<T: Into<String>>(&mut self, message: T) {
        self.message = message.into();
    }

    /// ត្រឡប់ `Span`s ក្នុង `self` ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn spans(&self) -> &[Span] {
        &self.spans
    }

    /// កំណត់ `អេស្បាញក្នុង `self` ទៅ `spans` ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn set_spans<S: MultiSpan>(&mut self, spans: S) {
        self.spans = spans.into_spans();
    }

    /// ត្រឡប់ iterator ទៅលើការវិនិច្ឆ័កូនរបស់ `self` មួយ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn children(&self) -> Children<'_> {
        Children(self.children.iter())
    }

    /// បញ្ចេញរោគវិនិច្ឆ័យ។
    #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
    pub fn emit(self) {
        fn to_internal(spans: Vec<Span>) -> crate::bridge::client::MultiSpan {
            let mut multi_span = crate::bridge::client::MultiSpan::new();
            for span in spans {
                multi_span.push(span.0);
            }
            multi_span
        }

        let mut diag = crate::bridge::client::Diagnostic::new(
            self.level,
            &self.message[..],
            to_internal(self.spans),
        );
        for c in self.children {
            diag.sub(c.level, &c.message[..], to_internal(c.spans));
        }
        diag.emit();
    }
}