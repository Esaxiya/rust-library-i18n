//! បណ្ណាល័យគាំទ្រសម្រាប់អ្នកនិពន្ធម៉ាក្រូនៅពេលកំណត់ម៉ាក្រូថ្មី។
//!
//! បណ្ណាល័យនេះបានផ្ដល់ដោយការចែកចាយតាមស្តង់ដា, ផ្តល់នូវប្រភេទនៃការប្រើប្រាស់នៅក្នុងចំណុចប្រទាក់ម៉ាក្រូដែលបានកំណត់និយមន័យដូចជាមុខងារនីតិវិធីដូចម៉ាក្រូ `#[proc_macro]`, គុណលក្ខណៈម៉ាក្រូ `#[proc_macro_attribute]` និងឩបករណ៍ផ្ទាល់ខ្លួន#attributes`[proc_macro_derive]`នេះ។
//!
//!
//! មើល [the book] សម្រាប់ព័ត៌មានបន្ថែម។
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// កំណត់ថាតើ proc_macro ត្រូវបានធ្វើឱ្យអាចចូលដំណើរការបានចំពោះកម្មវិធីដែលកំពុងដំណើរការបច្ចុប្បន្ន។
///
/// Proc_macro crate ត្រូវបានបម្រុងទុកសម្រាប់ប្រើប្រាស់ក្នុងការអនុវត្តម៉ាក្រូនីតិវិធីប៉ុណ្ណោះ។មុខងារទាំងអស់នៅក្នុង crate panic នេះប្រសិនបើត្រូវបានហៅពីខាងក្រៅនៃម៉ាក្រូនីតិវិធីដូចជាមកពីស្គ្រីបកសាងឬការធ្វើតេស្តឬប្រព័ន្ធគោលពីរ Rust អង្គភាពធម្មតា។
///
/// ជាមួយនឹងការពិចារណាសម្រាប់បណ្ណាល័យ Rust ដែលត្រូវបានរចនាឡើងដើម្បីគាំទ្រនិងប្រើប្រាស់ម៉ាក្រូទាំងពីរមិនមែនជាករណីម៉ាក្រូ, `proc_macro::is_available()` ផ្តល់នូវវិធីដែលមិនមានភ័យខ្លាចក្នុងការរកឃើញថាតើហេដ្ឋារចនាសម្ព័ន្ធដែលត្រូវការដើម្បីប្រើ API របស់ proc_macro គឺអាចរកបានបច្ចុប្បន្ន។
/// ត្រឡប់ជាការពិតប្រសិនបើត្រូវបានហៅពីខាងក្នុងនៃម៉ាក្រូនីតិវិធី, មិនពិតប្រសិនបើត្រូវបានហៅពីគោលពីរផ្សេងទៀត។
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ប្រភេទចម្បងដែលបានផ្ដល់ដោយ crate នេះតំណាងឱ្យការស្ទ្រីមអរូបីនៃ tokens, ឬ, ជាពិសេសច្រើនជាងនេះ, លំដាប់នៃដើមឈើ token មួយ។
/// ប្រភេទនេះផ្ដល់នូវចំណុចប្រទាក់សម្រាប់ iterating ជាងដើមឈើទាំងនោះ token និង, ផ្ទុយទៅវិញ, ការប្រមូលចំនួននៃដើមឈើ token មួយចូលទៅក្នុងស្ទ្រីមមួយ។
///
///
/// នេះគឺជាការបញ្ចូលនិងលទ្ធផលនៃនិយមន័យ `#[proc_macro]`, `#[proc_macro_attribute]` និង `#[proc_macro_derive]` ។
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// កំហុសបានត្រឡប់មកពី `TokenStream::from_str` ។
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// ត្រឡប់ `TokenStream` ទទេដែលគ្មានដើមឈើ token ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ពិនិត្យមើលថាតើ `TokenStream` នេះទទេ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// ការព្យាយាមដើម្បីបំបែកខ្សែអក្សរដែលបានចូលទៅក្នុង tokens និងការញែក tokens ទាំងនោះទៅក្នុងស្ទ្រីម token ។
/// អាចបរាជ័យសម្រាប់ហេតុផលមួយចំនួន, ឧទាហរណ៍, ប្រសិនបើខ្សែអក្សរមានអ្នកកំណត់ព្រំដែនដែលគ្មានតុល្យភាពឬតួអក្សរដែលមិនមានស្រាប់នៅក្នុងភាសា។
///
/// tokens ទាំងអស់នៅក្នុងស្ទ្រីមញែកទទួលបានទំហំ `Span::call_site()` ។
///
/// NOTE: កំហុសមួយចំនួនអាចបណ្តាលជំនួសឱ្យការវិលត្រឡប់ panics `LexError` ។យើងរក្សាសិទ្ធិក្នុងការផ្លាស់ប្តូរកំហុសទាំងនេះទៅជា `LexError` នៅពេលក្រោយ។
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// អិនប៊ី, ស្ពានផ្តល់តែ `to_string`, អនុវត្ត `fmt::Display` ដោយផ្អែកលើវា (បញ្ច្រាសនៃទំនាក់ទំនងធម្មតារវាងអ្នកទាំងពីរ) ។
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// បោះពុម្ពស្ទ្រីម token ជាខ្សែអក្សរដែលត្រូវបានសន្មត់ថានឹងត្រឡប់មកវិញចូលទៅក្នុងការប្តូ losslessly ស្ទ្រីម token ដូចគ្នា (មានទទឹកសំណល់) លើកលែងតែអាចធ្វើទៅបាន: TokenTree::Group`s ជាមួយព្រំដែន `Delimiter::None` និងព្យញ្ជនៈលេខអវិជ្ជមាន។
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// បោះពុម្ព token នៅក្នុងសំណុំបែបបទមួយដែលងាយស្រួលសម្រាប់ការបំបាត់កំហុស។
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// បង្កើតស្ទ្រីម token ដែលមានមែកធាង token តែមួយ។
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// ប្រមូលដើមឈើ token មួយចំនួនចូលទៅក្នុងស្ទ្រីមតែមួយ។
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// ប្រតិបត្តិការ "flattening" នៅលើស្ទ្រីម token ប្រមូលដើមឈើ token ពីស្ទ្រីម token ជាច្រើនចូលទៅក្នុងស្ទ្រីមតែមួយ។
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) ប្រើការអនុវត្ត if/when ដែលអាចធ្វើទៅបាន។
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ព័ត៌មានលម្អិតនៃការអនុវត្តជាសាធារណៈសម្រាប់ប្រភេទ `TokenStream` ដូចជាឧបករណ៍វាស់ចរន្ត។
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// អ្នកធ្វើបាបលើថូថិនធេ ``
    /// ការនិយាយឡើងវិញនេះគឺ "shallow", ឧ, ការនិយាយឡើងវិញមិនបានចូលទៅក្នុងក្រុមដែលបានកំណត់ព្រំដែន recurse និងត្រឡប់មកវិញក្រុមទាំងមូលជាដើមឈើ token ។
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` ទទួលយកការបំពាន tokens និងពង្រីកចូលទៅក្នុង `TokenStream` មួយដែលអធិប្បាយអំពីបញ្ចូល។
/// ឧទាហរណ៍ `quote!(a + b)` នឹងផលិតកន្សោមមួយដែលនៅពេលវាយតំលៃសាងសង់ `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// ការដកយកឯកសារត្រូវបានធ្វើរួចជាមួយ `$` ហើយដំណើរការដោយយកលេខសម្គាល់តែមួយជាពាក្យដែលគ្មានគុណប្រយោជន៍។
/// ដើម្បីដកស្រង់ `$` ខ្លួនវាប្រើ `$$` ។
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// តំបន់នៃកូដប្រភពរួមជាមួយព័ត៌មានពង្រីកម៉ាក្រូ។
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// បង្កើត `Diagnostic` ថ្មីជាមួយ `message` ដែលបានផ្តល់ឱ្យនៅចន្លោះ `self` ។
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// រយៈពេលតាំងចិត្ដថានៅតំបន់និយមន័យម៉ាក្រូ។
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// រយៈពេលនៃការហៅម៉ាក្រូនីតិវិធីបច្ចុប្បន្ន។
    /// គ្រឿងសម្គាល់ដែលបានបង្កើតឡើងដោយមានរយៈពេលនេះនឹងត្រូវបានដោះស្រាយជាការបានប្រសិនបើពួកគេត្រូវបានសរសេរដោយផ្ទាល់នៅទីតាំងម៉ាក្រូហៅ (ហៅតំបន់បណ្តាញអនាម័យ) និងលេខកូដផ្សេងទៀតនៅកន្លែងការហៅម៉ាក្រូនឹងអាចយោងទៅពួកគេផងដែរ។
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// រយៈពេលដែលតំណាងឱ្យអនាម័យ `macro_rules`, ហើយពេលខ្លះការដោះស្រាយនៅតំបន់នោះម៉ាក្រូនិយមន័យ (អថេរមូលដ្ឋាន, ស្លាក, `$crate`) និងពេលខ្លះនៅកន្លែងការហៅម៉ាក្រូ (អ្វីផ្សេងទៀត) ។
    ///
    /// ទីតាំងចន្លោះត្រូវបានយកចេញពីកន្លែងហៅចូល។
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ឯកសារប្រភពដើមដែលចំនុចនេះចង្អុលបង្ហាញ។
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` សម្រាប់ tokens ក្នុងការពង្រីកម៉ាក្រូពីមុនដែល `self` ត្រូវបានបង្កើតមកពីប្រសិនបើមាន។
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// វិសាលភាពសម្រាប់កូដប្រភពដើមដែល `self` ត្រូវបានបង្កើតចេញពី។
    /// ប្រសិនបើមាន `Span` នេះមិនត្រូវបានបង្កើតពីការពង្រីកម៉ាក្រូផ្សេងទៀតបន្ទាប់មកត្រឡប់មកវិញនេះគឺមានតម្លៃដូចគ្នាជា `*self` ។
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ទទួលបាន line/column ចាប់ផ្តើមនៅក្នុងឯកសារប្រភពសម្រាប់ទំហំនេះ។
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// ទទួលបាន line/column បញ្ចប់នៅក្នុងឯកសារប្រភពសម្រាប់ទំហំនេះ។
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// បង្កើតវិសាលភាពថ្មីដែលរួមបញ្ចូល `self` និង `other` ។
    ///
    /// ត្រឡប់ `None` ប្រសិនបើ `self` និង `other` មកពីឯកសារផ្សេងៗគ្នា។
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// បង្កើតរយៈពេលថ្មីជាមួយព line/column ដូចគ្នា `self` ប៉ុន្តែថានិមិត្តសញ្ញាដូចជាទោះបី Resolve នៅ `other` វាបាន។
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// បង្កើតវិសាលភាពថ្មីដែលមានអាកប្បកិរិយាដោះស្រាយឈ្មោះដូចគ្នានឹង `self` ប៉ុន្តែជាមួយព័ត៌មាន line/column នៃ `other` ។
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// ប្រៀបធៀបទៅនឹងវិសាលភាពដើម្បីមើលថាតើពួកគេស្មើគ្នា។
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ត្រឡប់អត្ថបទប្រភពខាងក្រោយចន្លោះ។
    /// នេះការពារកូដប្រភពដើមរួមទាំងចន្លោះនិងយោបល់។
    /// វាត្រលប់មកវិញនូវលទ្ធផលប្រសិនបើចន្លោះត្រូវនឹងលេខកូដប្រភពពិត។
    ///
    /// Note: លទ្ធផលដែលអាចធ្វើការអង្កេតនៃម៉ាក្រូមួយគួរពឹងផ្អែកតែលើ tokens និងមិននៅលើអត្ថបទប្រភពនេះ។
    ///
    /// លទ្ធផលនៃមុខងារនេះគឺជាកិច្ចខិតខំប្រឹងប្រែងដ៏ល្អបំផុតដែលត្រូវបានប្រើសម្រាប់តែរោគវិនិច្ឆ័យប៉ុណ្ណោះ។
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ព្រីនធ័រក្នុងទំរង់មួយដែលងាយស្រួលសំរាប់ការបំបាត់កំហុស។
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// មួយគូបន្ទាត់ជួរឈរដែលតំណាងឱ្យការចាប់ផ្តើមឬចុងបញ្ចប់នៃ `Span` មួយ។
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// បន្ទាត់ 1 លិបិក្រមនៅក្នុងឯកសារប្រភពនៅលើដែលចាប់ផ្តើមឬមិនសូវចេះចុង (inclusive) ។
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// ជួរឈរ 0-លិបិក្រម (ក្នុងតួអក្សរ UTF-8) នៅក្នុងឯកសារប្រភពនៅលើដែលចាប់ផ្តើមឬមិនសូវចេះចុង (inclusive) ។
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// ឯកសារប្រភពនៃ `Span` ដែលបានផ្តល់ឱ្យ។
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ទទួលបានផ្លូវទៅឯកសារប្រភពនេះ។
    ///
    /// ### Note
    /// ប្រសិនបើមានរយៈពេលកូដដែលបានភ្ជាប់ជា `SourceFile` នេះត្រូវបានបង្កើតដោយម៉ាក្រូខាងក្រៅ, ម៉ាក្រូនេះ, នេះប្រហែលជាមិនអាចជាផ្លូវពិតប្រាកដនៅលើប្រព័ន្ធឯកសារ។
    /// ប្រើ [`is_real`] ដើម្បីពិនិត្យមើល។
    ///
    /// ចំណាំផងដែរបើទោះជា `is_real` ដែលត្រឡប់ `true`, បើ `--remap-path-prefix` បានឆ្លងបន្ទាត់ពាក្យបញ្ជាផ្លូវខណៈដែលបានផ្ដល់ឱ្យមិនអាចជាការពិតជាការត្រឹមត្រូវ។
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ត្រឡប់ `true` ប្រសិនបើមានឯកសារប្រភពនេះគឺជាឯកសារប្រភពពិតប្រាកដនិងមិនបានបង្កើតដោយពង្រីកម៉ាក្រូខាងក្រៅបាន។
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // នេះគឺជាការ hack បានរហូតដល់ត្រូវបានប្រតិបត្តិទទឹក intercrate ហើយយើងអាចមានឯកសារប្រភពពិតប្រាកដសម្រាប់ម៉ាក្រូបង្កើតនៅក្នុងទទឹកខាងក្រៅ។
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// តែមួយ token ឬលំដាប់កំណត់នៃដើមឈើ token (ឧ `[1, (), ..]`) ។
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// ស្ទ្រីម token ព័ទ្ធជុំវិញដោយអ្នកកំណត់ដង្កៀប។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// អ្នកកំណត់អត្តសញ្ញាណ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// តួអក្សរវណ្ណយុត្តតែមួយ (`+`, `,`, `$` ។ ល។) ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// អក្សរព្យញ្ជនៈ (`'a'`), ខ្សែអក្សរ (`"hello"`), លេខ (`2.3`), ល។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// ត្រឡប់រយៈពេលរបស់មែកធាងនេះប្រគល់ទៅវិធីសាស្រ្តនៃការ token ដែលមាន `span` ឬស្ទ្រីមកំណត់ការមួយ។
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// កំណត់ពេលវេលាសម្រាប់តែមានតែ token * ប៉ុណ្ណោះ។
    ///
    /// ចំណាំថាប្រសិនបើ token នេះគឺជាបន្ទាប់មកវិធីសាស្រ្ត `Group` នឹងមិនកំណត់រចនាសម្ព័ន្ធនេះរយៈពេលនៃនីមួយនៃ tokens ផ្ទៃក្នុងនេះគ្រាន់តែនឹងផ្ទេរទៅកាន់វិធីសាស្រ្ត `set_span` នៃវ៉ារ្យ៉ង់គ្នា។
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// បោះពុម្ពមែកធាង token ក្នុងទម្រង់ងាយស្រួលសម្រាប់ការបំបាត់កំហុស។
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ទាំងអស់នេះមានឈ្មោះនៅក្នុងប្រភេទ struct ក្នុងការបំបាត់កំហុសចេញមកនេះដូច្នេះមិនខ្វល់ជាមួយនឹងស្រទាប់បន្ថែមនៃការប្រយោល
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// អិនប៊ី, ស្ពានផ្តល់តែ `to_string`, អនុវត្ត `fmt::Display` ដោយផ្អែកលើវា (បញ្ច្រាសនៃទំនាក់ទំនងធម្មតារវាងអ្នកទាំងពីរ) ។
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// បោះពុម្ពដើម token ជាខ្សែអក្សរដែលត្រូវបានសន្មត់ថានឹងត្រឡប់មកវិញចូលទៅក្នុងការប្តូ losslessly ដើមឈើ token ដូចគ្នា (មានទទឹកសំណល់) លើកលែងតែអាចធ្វើទៅបាន: TokenTree::Group`s ជាមួយព្រំដែន `Delimiter::None` និងព្យញ្ជនៈលេខអវិជ្ជមាន។
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ស្ទ្រីម token កំណត់ព្រំដែន។
///
/// `Group` ខាងក្នុងមានផ្ទុក `TokenStream` ដែលព័ទ្ធជុំវិញដោយ `ឌីឌីមឺរីសឺរ។
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// ពិពណ៌នាអំពីរបៀបដែលលំដាប់នៃដើមឈើ token ត្រូវបានកំណត់ព្រំដែន។
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// អ្នកកំណត់ព្រំដែនជាក់លាក់ដែលឧទាហរណ៍អាចលេចឡើងនៅជុំវិញ tokens ដែលមកពី "macro variable" `$var` ។
    /// វាមានសារៈសំខាន់ណាស់ក្នុងការថែរក្សាអាទិភាពប្រតិបត្តិករក្នុងករណីដូចជា `$var * 3` ដែល `$var` គឺ `1 + 2` ។
    /// អ្នកកំណត់ព្រំដែនទាំងស្រុង roundtrip មិនអាចរស់បានស្ទ្រីម token មួយតាមរយៈខ្សែអក្សរមួយ។
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// បង្កើត `Group` ថ្មីជាមួយអ្នកកំណត់ព្រំដែនដែលបានផ្ដល់ឱ្យនិងស្ទ្រីម token ។
    ///
    /// អ្នកបង្កើតនេះនឹងកំណត់រយៈពេលសម្រាប់ក្រុមដើម្បី `Span::call_site()` នេះ។
    /// ដើម្បីផ្លាស់ប្តូរវិសាលភាពអ្នកអាចប្រើវិធីសាស្ត្រ `set_span` ខាងក្រោម។
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// ត្រឡប់អ្នកកំណត់ព្រំដែននៃ `Group` នេះ
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ត្រឡប់មកវិញ `TokenStream` នៃ tokens ដែលត្រូវបានកំណត់ក្នុង `Group` នេះ។
    ///
    /// ចំណាំថាការស្ទ្រីម token វិលត្រឡប់មកវិញមិនរួមបញ្ចូលអ្នកកំណត់ព្រំដែនដែលបានវិលត្រឡប់មកខាងលើ។
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// ត្រឡប់ចន្លោះសម្រាប់អ្នកកំណត់ព្រំដែននៃស្ទ្រីម token នេះលាតសន្ធឹងលើ `Group` ទាំងមូល។
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ត្រឡប់ចន្លោះដែលចង្អុលទៅសញ្ញាកំណត់ព្រំដែននៃក្រុមនេះ។
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ត្រឡប់រយៈពេលដែលចង្អុលទៅសញ្ញាកំណត់ព្រំដែនបិទនៃក្រុមនេះ។
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// តំរែតំរែតំរង់សំរាប់អ្នកកំណត់ព្រំដែនក្រុម `នេះប៉ុន្តែមិនមែន tokens ខាងក្នុងទេ។
    ///
    /// វិធីសាស្រ្តនេះនឹង ** ** កំណត់រយៈពេលមិនអស់ទាំង tokens នៃការឆ្លងកាត់ដោយផ្ទៃក្រុមនេះនោះទេប៉ុន្តែផ្ទុយទៅវិញវានឹងកំណត់តែការកំណត់ព្រំដែន tokens អាយុនេះនៅកម្រិត `Group` នេះ។
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// អិនប៊ី, ស្ពានផ្តល់តែ `to_string`, អនុវត្ត `fmt::Display` ដោយផ្អែកលើវា (បញ្ច្រាសនៃទំនាក់ទំនងធម្មតារវាងអ្នកទាំងពីរ) ។
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// បោះពុម្ពក្រុមជាខ្សែអក្សរដែលគួរត្រូវបានត្រឡប់មកវិញចូលទៅក្នុងក្រុមប្តូ losslessly ដូចគ្នា (មានទទឹកសំណល់) មួយលើកលែងតែអាចធ្វើទៅបាន: TokenTree::Group`s ដោយមានកំណត់ព្រំដែន `Delimiter::None` ។
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// អាន `Punct` ជាតួអក្សរវណ្ណយុត្តមួយតែដូច `+`, `-` ឬ `#` ។
///
/// ប្រតិបត្តិករពហុតួអក្សរដូចជា `+=` ត្រូវបានតំណាងថាជាករណីពីរនៃ `Punct` មានទម្រង់ផ្សេងគ្នានៃ `Spacing` ត្រឡប់មកវិញ។
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// ថាតើ `Punct` ត្រូវបានអនុវត្តភ្លាមៗដោយ `Punct` ផ្សេងទៀតឬបន្តដោយ token ឬចន្លោះពណ៌ស។
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ឧ, `+` គឺ `Alone` ក្នុង `+ =`, `+ident` ឬ `+()` ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ឧទាហរណ៍ `+` គឺ `Joint` ក្នុង `+=` ឬ `'#` ។
    /// លើសពីនេះទៀតសម្រង់ទោល `'` អាចចូលរួមជាមួយអត្តសញ្ញាដើម្បី `'ident` ទម្រង់បែបបទជីវិត។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// បង្កើត `Punct` ថ្មីពីតួអក្សរដែលផ្ដល់និងគម្លាត។
    /// អាគុយម៉ង់ `ch` ត្រូវតែតួអក្សរវណ្ណយុត្តមួយដែលត្រឹមត្រូវបានអនុញ្ញាតដោយភាសានេះ, បើមិនដូច្នេះទេអនុគមន៍នឹង panic ។
    ///
    /// បានត្រឡប់ `Punct` នឹងមានរយៈពេលលំនាំដើមនៃ `Span::call_site()` ដែលអាចត្រូវបានកំណត់រចនាសម្ព័ន្ធបន្ថែមទៀតជាមួយនឹងវិធីសាស្រ្ត `set_span` ខាងក្រោម។
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// ត្រឡប់តម្លៃនៃតួអក្សរវណ្ណយុត្តនេះជា `char` នេះ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// ត្រឡប់មកវិញគម្លាតនៃតួអក្សរវណ្ណយុត្តនេះបង្ហាញថាតើវាត្រូវបានតាមពីក្រោយភ្លាមដោយ `Punct` ផ្សេងទៀតនៅក្នុងស្ទ្រីម token ដូច្នេះពួកគេអាចមានសក្តានុពលត្រូវបានរួមបញ្ចូលគ្នាទៅជាប្រតិបត្តិករពហុតួអក្សរ (`Joint`) ឬវាត្រូវបានបន្តដោយការ token ឬចន្លោះ (`Alone`) ដូច្នេះប្រតិបត្តិករនេះមានការពិតមួយចំនួនផ្សេងទៀត បានបញ្ចប់។
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ត្រឡប់ចន្លោះសម្រាប់តួអក្សរវណ្ណយុត្តិនេះ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// កំណត់រចនាសម្ព័ន្ធរយៈពេលសម្រាប់តួអក្សរវណ្ណយុត្តនេះ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// អិនប៊ី, ស្ពានផ្តល់តែ `to_string`, អនុវត្ត `fmt::Display` ដោយផ្អែកលើវា (បញ្ច្រាសនៃទំនាក់ទំនងធម្មតារវាងអ្នកទាំងពីរ) ។
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ព្រីនតួអក្សរវណ្ណយុត្តិជាខ្សែអក្សរដែលគួរបំលែងទៅជាតួអក្សរតែមួយ។
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ឧបករណ៍សម្គាល់អត្តសញ្ញាណ (`ident`) ។
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// បង្កើត `Ident` ថ្មីជាមួយ `string` ក៏ដូចជា `span` ដែលបានបញ្ជាក់។
    /// អាគុយម៉ង់ `string` ត្រូវតែជាគ្រឿងសម្គាល់ត្រឹមត្រូវដែលអនុញ្ញាតដោយភាសា (រួមទាំងពាក្យគន្លឹះឧទាហរណ៍ `self` ឬ `fn`) ។បើមិនដូច្នេះទេអនុគមន៍នឹង panic ។
    ///
    /// ចំណាំថា `span`, បច្ចុប្បន្ននេះនៅក្នុង rustc, កំណត់រចនាសម្ព័ន្ធពអនាម័យសម្រាប់ការកំណត់អត្តសញ្ញាណនេះ។
    ///
    /// រហូតមកដល់ពេលនេះ `Span::call_site()` បានជ្រើសរើសយ៉ាងច្បាស់ទៅនឹងអនាម័យ "call-site" មានន័យថាអ្នកកំណត់អត្តសញ្ញាណដែលបានបង្កើតជាមួយចន្លោះនេះនឹងត្រូវបានដោះស្រាយដូចជាពួកគេត្រូវបានសរសេរដោយផ្ទាល់នៅទីតាំងនៃការហៅម៉ាក្រូហើយលេខកូដផ្សេងទៀតនៅឯកន្លែងហៅម៉ាក្រូនឹងអាចយោងទៅ។ ពួកគេផងដែរ។
    ///
    ///
    /// ក្រោយមកទៀតដូច `Span::def_site()` ទទឹកនឹងអនុញ្ញាតឱ្យទៅជាន័យថាអនាម័យ "definition-site" បង្កើតឡើងដោយមានរយៈពេលអត្តសញ្ញានេះនឹងត្រូវបានដោះស្រាយនៅទីតាំងនៃនិយមន័យម៉ាក្រូនិងលេខកូដផ្សេងទៀតនៅតំបន់ហៅម៉ាក្រូនឹងមិនអាចសំដៅទៅលើពួកគេមិនចូលរួមក្នុង។
    ///
    /// ដោយសារតែសារៈសំខាន់បច្ចុប្បន្ននៃអនាម័យអ្នកបង្កើតនេះមិនដូច tokens ផ្សេងទៀតនឹងត្រូវបានតម្រូវឱ្យ `Span` បានបញ្ជាក់នៅក្នុងសំណង់។
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// ដូចគ្នា `Ident::new` ទេប៉ុន្តែបង្កើតជាគ្រឿងសម្គាល់ឆៅ (`r#ident`) ។
    /// អាគុយម៉ង់ `string` គឺជាគ្រឿងសម្គាល់ត្រឹមត្រូវដែលអនុញ្ញាតដោយភាសា (រួមទាំងពាក្យគន្លឹះឧទាហរណ៍ `fn`) ។
    /// ពាក្យគន្លឹះដែលអាចប្រើបាននៅក្នុងផ្នែកផ្លូវ (ឧទាហរណ៍
    /// `self`, `super`) មិនត្រូវបានគាំទ្រហើយនឹងបង្កឱ្យមាន panic ។
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// ត្រឡប់រយៈពេល `Ident` នេះរួមបញ្ចូលខ្សែអក្សរទាំងមូលវិលត្រឡប់មកវិញដោយ [`to_string`](Self::to_string) ។
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// កំណត់រយៈពេលនៃការ `Ident` នេះអាចធ្វើទៅបានផ្លាស់ប្តូរបរិបទអនាម័យរបស់ខ្លួន។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// អិនប៊ី, ស្ពានផ្តល់តែ `to_string`, អនុវត្ត `fmt::Display` ដោយផ្អែកលើវា (បញ្ច្រាសនៃទំនាក់ទំនងធម្មតារវាងអ្នកទាំងពីរ) ។
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ព្រីនកំណត់អត្តសញ្ញាណជាខ្សែអក្សរដែលគួរបំលែងទៅជាអ្នកកំណត់អត្តសញ្ញាណដដែល។
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// ខ្សែអក្សរអក្សរ (`"hello"`), ខ្សែអក្សរបៃ (`b"hello"`), តួអក្សរ (`'a'`), តួអក្សរបៃ (`b'a'`), ចំនួនគត់ឬលេខចំណុចអណ្តែតដោយមានឬគ្មានបច្ច័យ (`1`, `1u8`, `2.3`, `2.3f32`) ។
///
/// ដូច `true` ប៊ូលីន literals និង `false` មិនមែនជារបស់នៅទីនេះពួកគេគឺជា `Ident`s ។
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// បង្កើតចំនួនគត់បច្ច័យថ្មីតាមព្យញ្ជនៈជាមួយនឹងតម្លៃដែលបានបញ្ជាក់។
        ///
        /// មុខងារនេះនឹងបង្កើតចំនួនគត់ដែលជាកន្លែងដែលដូច `1u32` តម្លៃចំនួនគត់មួយដែលបានបញ្ជាក់គឺជាផ្នែកដំបូងនៃ token និងសំខាន់មួយនេះត្រូវបានដាក់បច្ច័យផងដែរនៅចុងបញ្ចប់។
        /// ព្យញ្ជនៈបង្កើតឡើងពីលេខអវិជ្ជមានមិនអាចរស់បានតាមរយៈការធ្វើដំណើរជុំឬខ្សែអក្សរនិង `TokenStream` អាចត្រូវបានខូចចូលទៅក្នុង tokens ពីរ (`-` និងព្យញ្ជនៈវិជ្ជមាន) ។
        ///
        ///
        /// ព្យញ្ជនៈដែលបានបង្កើតតាមរយៈវិធីសាស្ត្រនេះមានចន្លោះ `Span::call_site()` តាមលំនាំដើមដែលអាចត្រូវបានតំឡើងតាមវិធី `set_span` ខាងក្រោម។
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// បង្កើតព្យញ្ជនៈចំនួនគត់ unsuffixed ថ្មីមួយដែលមានតម្លៃដែលបានបញ្ជាក់។
        ///
        /// មុខងារនេះនឹងបង្កើតចំនួនគត់ដូចជា `1` ដែលតម្លៃចំនួនគត់ដែលបានបញ្ជាក់គឺជាផ្នែកដំបូងនៃ token ។
        /// គ្មានបច្ច័យណាមួយត្រូវបានបញ្ជាក់នៅលើ token នេះទេមានន័យថាការអំពាវនាវដូចជា `Literal::i8_unsuffixed(1)` គឺស្មើនឹង `Literal::u32_unsuffixed(1)` ។
        /// ព្យញ្ជនៈបង្កើតឡើងពីលេខអវិជ្ជមានមិនអាចរស់បាន rountrips តាមរយៈ `TokenStream` ឬខ្សែអក្សរអាចត្រូវបានខូចនិងការចូលទៅក្នុង tokens ពីរ (`-` និងព្យញ្ជនៈវិជ្ជមាន) ។
        ///
        ///
        /// ព្យញ្ជនៈដែលបានបង្កើតតាមរយៈវិធីសាស្ត្រនេះមានចន្លោះ `Span::call_site()` តាមលំនាំដើមដែលអាចត្រូវបានតំឡើងតាមវិធី `set_span` ខាងក្រោម។
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// បង្កើតចំណុចអណ្តែតទឹកដែលមិនត្រូវបានពិពណ៌នាថ្មី។
    ///
    /// អ្នកសាងសង់នេះគឺប្រហាក់ប្រហែលនឹង `Literal::i8_unsuffixed` ដែលតម្លៃអណ្តែតត្រូវបានបញ្ចេញដោយផ្ទាល់ទៅក្នុង token ប៉ុន្តែគ្មានបច្ច័យត្រូវបានប្រើទេដូច្នេះវាអាចត្រូវបានសន្និដ្ឋានថាជា `f64` នៅពេលក្រោយក្នុងកម្មវិធីចងក្រង។
    ///
    /// ព្យញ្ជនៈបង្កើតឡើងពីលេខអវិជ្ជមានមិនអាចរស់បាន rountrips តាមរយៈ `TokenStream` ឬខ្សែអក្សរអាចត្រូវបានខូចនិងការចូលទៅក្នុង tokens ពីរ (`-` និងព្យញ្ជនៈវិជ្ជមាន) ។
    ///
    /// # Panics
    ///
    /// មុខងារនេះតម្រូវឱ្យទសភាគដែលបានបញ្ជាក់គឺកំណត់ឧទាហរណ៍ប្រសិនបើវាគឺ infinity ឬ Nan មុខងារនេះនឹង panic ។
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// បង្កើតចំណុចអណ្តែតអក្សរកាត់ថ្មី។
    ///
    /// អ្នកបង្កើតនេះនឹងបង្កើតមែនទែនដូច `1.0f32` មួយដែលជាកន្លែងដែលតម្លៃដែលបានបញ្ជាក់គឺជាផ្នែកមួយនៃការ token បាននាំមុខនិងបច្ច័យនៃការគឺ `f32` token នេះ។
    /// token នេះនឹងតែងតែត្រូវបានសន្និដ្ឋានថាត្រូវបាន `f32` ក្នុងការចងក្រងនេះ។
    /// ព្យញ្ជនៈបង្កើតឡើងពីលេខអវិជ្ជមានមិនអាចរស់បាន rountrips តាមរយៈ `TokenStream` ឬខ្សែអក្សរអាចត្រូវបានខូចនិងការចូលទៅក្នុង tokens ពីរ (`-` និងព្យញ្ជនៈវិជ្ជមាន) ។
    ///
    ///
    /// # Panics
    ///
    /// មុខងារនេះតម្រូវឱ្យទសភាគដែលបានបញ្ជាក់គឺកំណត់ឧទាហរណ៍ប្រសិនបើវាគឺ infinity ឬ Nan មុខងារនេះនឹង panic ។
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// បង្កើតចំណុចអណ្តែតទឹកដែលមិនត្រូវបានពិពណ៌នាថ្មី។
    ///
    /// អ្នកសាងសង់នេះគឺប្រហាក់ប្រហែលនឹង `Literal::i8_unsuffixed` ដែលតម្លៃអណ្តែតត្រូវបានបញ្ចេញដោយផ្ទាល់ទៅក្នុង token ប៉ុន្តែគ្មានបច្ច័យត្រូវបានប្រើទេដូច្នេះវាអាចត្រូវបានសន្និដ្ឋានថាជា `f64` នៅពេលក្រោយក្នុងកម្មវិធីចងក្រង។
    ///
    /// ព្យញ្ជនៈបង្កើតឡើងពីលេខអវិជ្ជមានមិនអាចរស់បាន rountrips តាមរយៈ `TokenStream` ឬខ្សែអក្សរអាចត្រូវបានខូចនិងការចូលទៅក្នុង tokens ពីរ (`-` និងព្យញ្ជនៈវិជ្ជមាន) ។
    ///
    /// # Panics
    ///
    /// មុខងារនេះតម្រូវឱ្យទសភាគដែលបានបញ្ជាក់គឺកំណត់ឧទាហរណ៍ប្រសិនបើវាគឺ infinity ឬ Nan មុខងារនេះនឹង panic ។
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// បង្កើតចំណុចអណ្តែតអក្សរកាត់ថ្មី។
    ///
    /// អ្នកបង្កើតនេះនឹងបង្កើតមែនទែនដូច `1.0f64` មួយដែលជាកន្លែងដែលតម្លៃដែលបានបញ្ជាក់គឺជាផ្នែកមួយនៃការ token បាននាំមុខនិងបច្ច័យនៃការគឺ `f64` token នេះ។
    /// token នេះតែងតែត្រូវបានគេសន្និដ្ឋានថាជា `f64` នៅក្នុងអ្នកចងក្រង។
    /// ព្យញ្ជនៈបង្កើតឡើងពីលេខអវិជ្ជមានមិនអាចរស់បាន rountrips តាមរយៈ `TokenStream` ឬខ្សែអក្សរអាចត្រូវបានខូចនិងការចូលទៅក្នុង tokens ពីរ (`-` និងព្យញ្ជនៈវិជ្ជមាន) ។
    ///
    ///
    /// # Panics
    ///
    /// មុខងារនេះតម្រូវឱ្យទសភាគដែលបានបញ្ជាក់គឺកំណត់ឧទាហរណ៍ប្រសិនបើវាគឺ infinity ឬ Nan មុខងារនេះនឹង panic ។
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// ខ្សែអក្សរព្យញ្ជនៈ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// ព្យញ្ជនៈតួអក្សរ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// អក្សរបៃតាមព្យញ្ជនៈ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ត្រឡប់ចន្លោះដែលព័ទ្ធជុំវិញតាមព្យញ្ជនៈនេះ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// កំណត់ពេលវេលាទាក់ទងនឹងព្យញ្ជនៈនេះ។
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// ត្រឡប់ `Span` ដែលជាសំណុំរងនៃ `self.span()` មានតែប្រភពបៃក្នុងជួរ `range` មួយ។
    /// ត្រឡប់ `None` ប្រសិនបើចន្លោះដែលត្រូវបានកាត់គឺនៅខាងក្រៅព្រំដែននៃ `self` ។
    ///
    // FIXME(SergioBenitez): ពិនិត្យមើលថាបៃជួរចាប់ផ្តើមនិងបញ្ចប់នៅព្រំដែន UTF-8 នៃប្រភព។
    // បើមិនដូច្នោះទេវាទំនងជាថា panic នឹងកើតឡើងនៅកន្លែងផ្សេងទៀតនៅពេលអត្ថបទប្រភពត្រូវបានបោះពុម្ព។
    // FIXME(SergioBenitez): មានគឺជាវិធីសម្រាប់អ្នកប្រើដើម្បីដឹងថាអ្វីដែល `self.span()` ផែនទីទៅពិតជាដូច្នេះវិធីសាស្រ្តនេះអាចត្រូវបានហៅតែនាពេលបច្ចុប្បន្ននេះដោយគ្មានការពិចារណាទេ។
    // ឧទាហរណ៍ `to_string()` សម្រាប់តួអក្សរ 'c' ត្រឡប់ "'\u{63}'";មានគឺជាវិធីសម្រាប់អ្នកប្រើដើម្បីដឹងថាតើអត្ថបទប្រភពនេះគឺ 'c' ឬថាតើវាជាការ '\u{63}' ទេ។
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) អ្វីដែល akin ទៅ `Option::cloned`, ប៉ុន្តែសម្រាប់ `Bound<&T>` ។
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// អិនប៊ី, ស្ពានផ្តល់តែ `to_string`, អនុវត្ត `fmt::Display` ដោយផ្អែកលើវា (បញ្ច្រាសនៃទំនាក់ទំនងធម្មតារវាងអ្នកទាំងពីរ) ។
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// បោះពុម្ពពិតជាខ្សែអក្សរដែលគួរត្រូវបានត្រឡប់មកវិញចូលទៅក្នុងព្យញ្ជនៈប្តូ losslessly ដូចគ្នា (លើកលែងតែសម្រាប់ការប្រកួតជុំធ្វើទៅបានសម្រាប់ចំណុច literals អណ្តែតទឹក) មួយ។
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// បានតាមដានការចូលប្រើអថេរបរិស្ថាន។
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ទាញយកអថេរបរិស្ថាននិងបន្ថែមវាដើម្បីបង្កើតព័ត៌មានភាពអាស្រ័យ។
    /// ប្រព័ន្ធសាងសង់ប្រតិបត្តិការចងក្រងនឹងដឹងថាត្រូវបានចូលដំណើរការអថេរក្នុងអំឡុងពេលការចងក្រងនិងការនឹងអាចដំណើរការសាងសង់នៅពេលដែលតម្លៃនៃអថេរដែលបានផ្លាស់ប្តូរ។
    ///
    /// ក្រៅពីភាពអាស្រ័យតាមដានមុខងារនេះគួរតែស្មើនឹង `env::var` ពីបណ្ណាល័យស្តង់ដារលើកលែងតែអាគុយម៉ង់ត្រូវតែ UTF-8 ។
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}