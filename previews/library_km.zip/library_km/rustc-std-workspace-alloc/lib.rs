#![feature(no_core)]
#![no_core]

// សូមមើល rustc-std-workspace-core សម្រាប់មូលហេតុដែល crate ត្រូវការ។

// ប្តូរឈ្មោះ crate ដើម្បីជៀសវាងការប៉ះទង្គិចជាមួយម៉ូឌុលការបែងចែកនា liballoc ។
extern crate alloc as foo;

pub use foo::*;