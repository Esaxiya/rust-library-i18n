//! traits primittivi u tipi li jirrappreżentaw proprjetajiet bażiċi tat-tipi.
//!
//! It-tipi Rust jistgħu jiġu kklassifikati f'diversi modi utli skont il-proprjetajiet intrinsiċi tagħhom.
//! Dawn il-klassifikazzjonijiet huma rappreżentati bħala traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tipi li jistgħu jiġu ttrasferiti bejn il-konfini tal-ħajt.
///
/// Dan trait jiġi implimentat awtomatikament meta l-kompilatur jiddetermina li huwa xieraq.
///
/// Eżempju ta 'tip mhux "Ibgħat" huwa l-indikatur ta' l-għadd ta 'referenzi [`rc::Rc`][`Rc`].
/// Jekk żewġ ħjut jippruvaw jikklonaw [`Rc`] li jindikaw l-istess valur magħdud bir-referenza, jistgħu jippruvaw jaġġornaw l-għadd tar-referenza fl-istess ħin, li huwa [undefined behavior][ub] għax [`Rc`] ma jużax operazzjonijiet atomiċi.
///
/// Il-kuġin tiegħu [`sync::Arc`][arc] juża operazzjonijiet atomiċi (li jġarrab xi overhead) u għalhekk huwa `Send`.
///
/// Ara [the Nomicon](../../nomicon/send-and-sync.html) għal aktar dettalji.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tipi b'daqs kostanti magħruf fil-ħin tal-kompilazzjoni.
///
/// Il-parametri kollha tat-tip għandhom limitu impliċitu ta `Sized`.Is-sintassi speċjali `?Sized` tista 'tintuża biex tneħħi dan il-limitu jekk mhux xieraq.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // strutt FooUse(Foo<[i32]>);//żball: Daqs mhux implimentat għal [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// L-eċċezzjoni waħda hija t-tip impliċitu `Self` ta 'trait.
/// trait m'għandux `Sized` impliċitu marbut għax dan huwa inkompatibbli ma '[oġġett trait] fejn, b'definizzjoni, iż-trait jeħtieġ jaħdem ma' l-implimentaturi kollha possibbli, u għalhekk jista 'jkun ta' kull daqs.
///
///
/// Għalkemm Rust iħallik torbot `Sized` ma 'trait, ma tkunx tista' tużah biex tifforma oġġett trait aktar tard:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // ejja y: &dyn Bar= &Impl;//żball: iż-trait `Bar` ma jistax isir oġġett
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // għal Default, pereżempju, li jeħtieġ li `[T]: !Default` ikun evalwabbli
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tipi li jistgħu jkunu "unsized" għal tip ta 'daqs dinamiku.
///
/// Pereżempju, it-tip ta 'array ta' daqs `[i8; 2]` jimplimenta `Unsize<[i8]>` u `Unsize<dyn fmt::Debug>`.
///
/// L-implimentazzjonijiet kollha ta `Unsize` huma pprovduti awtomatikament mill-kompilatur.
///
/// `Unsize` hija implimentata għal:
///
/// - `[T; N]` huwa `Unsize<[T]>`
/// - `T` huwa `Unsize<dyn Trait>` meta `T: Trait`
/// - `Foo<..., T, ...>` huwa `Unsize<Foo<..., U, ...>>` jekk:
///   - `T: Unsize<U>`
///   - Foo huwa struttura
///   - L-aħħar qasam ta `Foo` biss għandu tip li jinvolvi `T`
///   - `T` mhix parti mit-tip ta 'kwalunkwe qasam ieħor
///   - `Bar<T>: Unsize<Bar<U>>`, jekk l-aħħar qasam ta `Foo` għandu tip `Bar<T>`
///
/// `Unsize` jintuża flimkien ma [`ops::CoerceUnsized`] biex il-kontenituri "user-defined" bħal [`Rc`] jitħallew ikollhom tipi ta' daqs dinamiku.
/// Ara [DST coercion RFC][RFC982] u [the nomicon entry on coercion][nomicon-coerce] għal aktar dettalji.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// trait meħtieġ għall-kostanti użati fil-logħbiet tal-mudell.
///
/// Kull tip li joħroġ `PartialEq` jimplimenta awtomatikament dan trait,*irrispettivament* minn jekk il-parametri tat-tip tiegħu jimplimentawx `Eq`.
///
/// Jekk oġġett `const` fih xi tip li ma jimplimentax dan trait, allura dak it-tip jew (1.) ma jimplimentax `PartialEq` (li jfisser li l-kostanti ma jipprovdix dak il-metodu ta 'tqabbil, liema ġenerazzjoni ta' kodiċi jassumi li huwa disponibbli), jew (2.) jimplimenta *tiegħu stess* verżjoni ta `PartialEq` (li nassumu li ma tikkonformax ma' paragun strutturali-ugwaljanza).
///
///
/// Fi kwalunkwe miż-żewġ xenarji ta 'hawn fuq, aħna nirrifjutaw l-użu ta' kostanti bħal din fi tqabbil ta 'mudell.
///
/// Ara wkoll ix-[structural match RFC][RFC1445], u [issue 63438] li mmotivaw il-migrazzjoni minn disinn ibbażat fuq l-attributi għal dan iż-trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// trait meħtieġ għall-kostanti użati fil-logħbiet tal-mudell.
///
/// Kull tip li joħroġ `Eq` jimplimenta awtomatikament dan trait,*irrispettivament* minn jekk il-parametri tat-tip tiegħu jimplimentawx `Eq`.
///
/// Din hija hack biex taħdem madwar limitazzjoni fis-sistema tat-tip tagħna.
///
/// # Background
///
/// Irridu nirrikjedu li t-tipi ta 'kostijiet użati fil-logħbiet tal-mudelli jkollhom l-attribut `#[derive(PartialEq, Eq)]`.
///
/// F'dinja aktar ideali, nistgħu niċċekkjaw dak ir-rekwiżit billi niċċekkjaw biss li t-tip mogħti jimplimenta kemm ix-`StructuralPartialEq` trait *kif ukoll* ix-`Eq` trait.
/// Madankollu, jista 'jkollok ADTs li *jagħmlu*`derive(PartialEq, Eq)`, u tkun każ li rridu li l-kompilatur jaċċetta, u madankollu t-tip tal-kostanti jonqos milli jimplimenta `Eq`.
///
/// Jiġifieri, każ bħal dan:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Il-problema fil-kodiċi ta 'hawn fuq hija li `Wrap<fn(&())>` ma jimplimentax `PartialEq`, u lanqas `Eq`, għax "għal <" a> fn(&'a _)` does not implement those traits.)
///
/// Għalhekk, ma nistgħux niddependu fuq kontroll inġenwu għal `StructuralPartialEq` u sempliċi `Eq`.
///
/// Bħala hack biex taħdem madwar dan, nużaw żewġ traits separati injettati minn kull wieħed mit-tnejn joħorġu (`#[derive(PartialEq)]` u `#[derive(Eq)]`) u niċċekkjaw li t-tnejn li huma huma preżenti bħala parti mill-iċċekkjar tal-logħbiet strutturali.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tipi li l-valuri tagħhom jistgħu jiġu duplikati sempliċement billi jiġu kkupjati bits.
///
/// B'default, irbit varjabbli għandu 'semantika ta' moviment. 'Fi kliem ieħor:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` mexa f `y`, u għalhekk ma jistax jintuża
///
/// // println! ("{: ?}", x);//żball: użu tal-valur imċaqlaq
/// ```
///
/// Madankollu, jekk tip jimplimenta `Copy`, minflok għandu 'kopja tas-semantika':
///
/// ```
/// // Nistgħu niksbu implimentazzjoni `Copy`.
/// // `Clone` hija meħtieġa wkoll, peress li hija supertrait ta `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` hija kopja ta `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Huwa importanti li wieħed jinnota li f'dawn iż-żewġ eżempji, l-unika differenza hija jekk intix permess li taċċessa `x` wara l-assenjazzjoni.
/// Taħt il-barnuża, kemm kopja kif ukoll ċaqliq jistgħu jirriżultaw f'bits li jiġu kkupjati fil-memorja, għalkemm xi kultant dan jiġi ottimizzat bogħod.
///
/// ## Kif nista 'nimplimenta `Copy`?
///
/// Hemm żewġ modi kif timplimenta `Copy` fuq it-tip tiegħek.L-aktar sempliċi hija li tuża `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Tista 'wkoll timplimenta `Copy` u `Clone` manwalment:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Hemm differenza żgħira bejn it-tnejn: l-istrateġija `derive` tqiegħed ukoll `Copy` marbut mal-parametri tat-tip, li mhux dejjem mixtieq.
///
/// ## X'inhi d-differenza bejn `Copy` u `Clone`?
///
/// Kopji jiġru impliċitament, pereżempju bħala parti minn assenjazzjoni `y = x`.L-imġieba ta `Copy` mhix mgħobbija żżejjed;hija dejjem kopja daqsxejn sempliċi.
///
/// Il-klonazzjoni hija azzjoni espliċita, `x.clone()`.L-implimentazzjoni ta [`Clone`] tista' tipprovdi kull imġieba tat-tip speċifika meħtieġa biex tiddupplika valuri mingħajr periklu.
/// Pereżempju, l-implimentazzjoni ta [`Clone`] għal [`String`] teħtieġ li tikkopja l-buffer tal-korda bil-ponta fil-borġ.
/// Kopja sempliċi bit-bit tal-valuri [`String`] sempliċement tikkopja l-pointer, li twassal għal free double 'l isfel mil-linja.
/// Għal din ir-raġuni, [`String`] huwa [`Clone`] iżda mhux `Copy`.
///
/// [`Clone`] huwa supertrait ta `Copy`, allura dak kollu li hu `Copy` għandu jimplimenta wkoll [`Clone`].
/// Jekk tip huwa `Copy` allura l-implimentazzjoni [`Clone`] tiegħu teħtieġ biss li tirritorna `*self` (ara l-eżempju hawn fuq).
///
/// ## Meta t-tip tiegħi jista 'jkun `Copy`?
///
/// Tip jista 'jimplimenta `Copy` jekk il-komponenti kollha tiegħu jimplimentaw `Copy`.Pereżempju, din l-istruttura tista 'tkun `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struttura tista 'tkun `Copy`, u [`i32`] hija `Copy`, għalhekk `Point` huwa eliġibbli li jkun `Copy`.
/// B'kuntrast, ikkunsidra
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// L-istruttura `PointList` ma tistax timplimenta `Copy`, għax [`Vec<T>`] mhix `Copy`.Jekk nippruvaw niksbu implimentazzjoni `Copy`, ikollna żball:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Referenzi maqsuma (`&T`) huma wkoll `Copy`, allura tip jista 'jkun `Copy`, anke meta jkollu referenzi maqsuma ta' tipi `T` li *mhumiex*`Copy`.
/// Ikkunsidra l-istruttura li ġejja, li tista 'timplimenta `Copy`, minħabba li għandha biss *referenza komuni* għat-tip `PointList` tagħna mhux "Kopja" minn fuq:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Meta *ma jistax* it-tip tiegħi jkun `Copy`?
///
/// Xi tipi ma jistgħux jiġu kkupjati b'mod sigur.Pereżempju, l-ikkupjar ta `&mut T` joħloq referenza aljabbli li tista' tinbidel.
/// L-ikkupjar ta [`String`] jidduplika r-responsabbiltà għall-immaniġġjar tal-buffer ta' ['String`], li jwassal għal free doppju.
///
/// Ġeneralizzazzjoni tal-każ tal-aħħar, kwalunkwe tip li jimplimenta [`Drop`] ma jistax ikun `Copy`, għax qed jimmaniġġja xi riżorsa minbarra l-bytes [`size_of::<T>`] tiegħu stess.
///
/// Jekk tipprova timplimenta `Copy` fuq struttura jew enum li jkun fih dejta mhux "Kopja", ikollok l-iżball [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Meta *għandu* t-tip tiegħi jkun `Copy`?
///
/// Ġeneralment, jekk it-tip _can_ tiegħek jimplimenta `Copy`, għandu.
/// Żomm f'moħħok, iżda, li l-implimentazzjoni ta `Copy` hija parti mill-API pubblika tat-tip tiegħek.
/// Jekk it-tip jista 'jsir mhux "Kopja" fiż-future, jista' jkun prudenti li tħalli barra l-implimentazzjoni `Copy` issa, biex tevita bidla fl-API li tkisser.
///
/// ## Implimentaturi addizzjonali
///
/// Minbarra x-[implementors listed below][impls], it-tipi li ġejjin jimplimentaw ukoll `Copy`:
///
/// * Tipi ta 'oġġett ta' funzjoni (jiġifieri, it-tipi distinti definiti għal kull funzjoni)
/// * Tipi ta 'pointer tal-funzjoni (eż., `fn() -> i32`)
/// * Tipi ta 'matriċi, għad-daqsijiet kollha, jekk it-tip ta' oġġett jimplimenta wkoll `Copy` (eż., `[i32; 123456]`)
/// * Tipi ta 'tupli, jekk kull komponent jimplimenta wkoll `Copy` (eż., `()`, `(i32, bool)`)
/// * Tipi ta 'għeluq, jekk ma jaqbdu l-ebda valur mill-ambjent jew jekk dawn il-valuri kollha maqbuda jimplimentaw `Copy` huma stess.
///   Innota li l-varjabbli maqbuda b'referenza maqsuma dejjem jimplimentaw `Copy` (anke jekk ir-referent ma jagħmilx), filwaqt li l-varjabbli maqbuda b'referenza li tista 'tinbidel qatt ma jimplimentaw `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Dan jippermetti l-ikkupjar ta 'tip li ma jimplimentax `Copy` minħabba limiti ta' ħajja mhux sodisfatti (ikkupjar `A<'_>` meta `A<'static>: Copy` u `A<'_>: Clone` biss).
// Għandna dan l-attribut hawn għalissa biss għax hemm pjuttost ftit speċjalizzazzjonijiet eżistenti fuq `Copy` li diġà jeżistu fil-librerija standard, u m'hemm l-ebda mod biex ikollok din l-imġieba b'mod sigur issa.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Iġbed makro li jiġġenera impl ta 'trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tipi li għalihom huwa sikur li taqsam referenzi bejn ħjut.
///
/// Dan trait jiġi implimentat awtomatikament meta l-kompilatur jiddetermina li huwa xieraq.
///
/// Id-definizzjoni preċiża hija: tip `T` huwa [`Sync`] jekk u biss jekk `&T` huwa [`Send`].
/// Fi kliem ieħor, jekk m'hemm l-ebda possibbiltà ta [undefined behavior][ub] (inklużi t-tiġrijiet tad-dejta) meta tgħaddi referenzi `&T` bejn il-ħjut.
///
/// Kif wieħed jistenna, tipi primittivi bħal [`u8`] u [`f64`] huma kollha [`Sync`], u għalhekk huma tipi aggregati sempliċi li fihom, bħal tuples, structs u enums.
/// Aktar eżempji ta 'tipi bażiċi ta' [`Sync`] jinkludu tipi "immutable" bħal `&T`, u dawk b'mutabilità sempliċi li tintiret, bħal [`Box<T>`][box], [`Vec<T>`][vec] u ħafna tipi oħra ta 'ġbir.
///
/// (Il-parametri ġeneriċi għandhom ikunu [`Sync`] biex il-kontenitur tagħhom ikun [`Sync`].)
///
/// Konsegwenza kemmxejn sorprendenti tad-definizzjoni hija li `&mut T` huwa `Sync` (jekk `T` huwa `Sync`) anke jekk jidher li jista 'jipprovdi mutazzjoni mhux sinkronizzata.
/// Il-trick huwa li referenza li tista 'tinbidel wara referenza kondiviża (jiġifieri, `& &mut T`) issir read-only, bħallikieku kienet `& &T`.
/// Għalhekk m'hemm l-ebda riskju ta 'tiġrija tad-dejta.
///
/// Tipi li mhumiex `Sync` huma dawk li għandhom "interior mutability" f'forma mhux sikura għall-ħajt, bħal [`Cell`][cell] u [`RefCell`][refcell].
/// Dawn it-tipi jippermettu mutazzjoni tal-kontenut tagħhom anke permezz ta 'referenza immutabbli u maqsuma.
/// Pereżempju l-metodu `set` fuq [`Cell<T>`][cell] jieħu `&self`, u għalhekk jeħtieġ biss referenza komuni [`&Cell<T>`][cell].
/// Il-metodu ma jwettaq l-ebda sinkronizzazzjoni, għalhekk [`Cell`][cell] ma jistax ikun `Sync`.
///
/// Eżempju ieħor ta 'tip mhux "Sync" huwa l-indikatur ta' l-għadd ta 'referenzi [`Rc`][rc].
/// Minħabba kwalunkwe referenza [`&Rc<T>`][rc], tista 'tikklona [`Rc<T>`][rc] ġdid, billi timmodifika l-għadd ta' referenza b'mod mhux atomiku.
///
/// Għal każijiet meta wieħed jeħtieġ mutabilità interna bla periklu għall-ħajt, Rust jipprovdi [atomic data types], kif ukoll qfil espliċitu permezz ta [`sync::Mutex`][mutex] u [`sync::RwLock`][rwlock].
/// Dawn it-tipi jiżguraw li kwalunkwe mutazzjoni ma tistax tikkawża ġirjiet tad-dejta, għalhekk it-tipi huma `Sync`.
/// Bl-istess mod, [`sync::Arc`][arc] jipprovdi analogu ta [`Rc`][rc] bla periklu għall-ħajt.
///
/// Kwalunkwe tip b'mutabilità interna għandu wkoll juża t-tgeżwir [`cell::UnsafeCell`][unsafecell] madwar ix-value(s) li jista 'jkun immutat permezz ta' referenza kondiviża.
/// Jekk tonqos milli tagħmel dan huwa [undefined behavior][ub].
/// Pereżempju, [`transmute`][transmute]-ing minn `&T` sa `&mut T` mhix valida.
///
/// Ara [the Nomicon][nomicon-send-and-sync] għal aktar dettalji dwar `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ladarba ssostni biex iżżid noti f'artijiet `rustc_on_unimplemented` f'beta, u ġie estiż biex tivverifika jekk għeluq hux kullimkien fil-katina ta 'ħtiġijiet, estendih bħala tali (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Tip ta 'daqs żero użat biex jimmarka affarijiet li "act like" għandhom `T`.
///
/// Iż-żieda ta 'qasam `PhantomData<T>` mat-tip tiegħek tgħid lill-kompilatur li t-tip tiegħek jaġixxi bħallikieku jaħżen valur tat-tip `T`, għalkemm verament ma jagħmilx.
/// Din l-informazzjoni tintuża meta jiġu kkalkulati ċerti proprjetajiet ta 'sigurtà.
///
/// Għal spjegazzjoni aktar fil-fond ta 'kif tuża `PhantomData<T>`, jekk jogħġbok ara [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Nota tal-biża '👻👻👻
///
/// Għalkemm it-tnejn għandhom ismijiet tal-biża ', `PhantomData` u' tipi fantażmi 'huma relatati, iżda mhux identiċi.Parametru tat-tip fantażma huwa sempliċement parametru tat-tip li qatt ma jintuża.
/// F'Rust, dan ħafna drabi jikkawża li l-kompilatur jilmenta, u s-soluzzjoni hija li żżid użu ta "dummy" permezz ta' `PhantomData`.
///
/// # Examples
///
/// ## Parametri tal-ħajja mhux użati
///
/// Forsi l-iktar każ ta 'użu komuni għal `PhantomData` huwa struttura li għandha parametru tal-ħajja mhux użat, tipikament bħala parti minn xi kodiċi mhux sikur.
/// Pereżempju, hawn hija struttura `Slice` li għandha żewġ indikaturi tat-tip `*const T`, preżumibbilment tipponta lejn array x'imkien:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// L-intenzjoni hija li d-dejta sottostanti hija valida biss għall-ħajja `'a`, allura `Slice` m'għandux jgħix lil `'a`.
/// Madankollu, din l-intenzjoni mhix espressa fil-kodiċi, peress li m'hemm l-ebda użu tal-ħajja `'a` u għalhekk mhuwiex ċar għal liema dejta tapplika.
/// Nistgħu nikkoreġu dan billi ngħidu lill-kompilatur biex jaġixxi *bħallikieku* l-istruttura `Slice` kien fiha referenza `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Min-naħa tiegħu dan jeħtieġ ukoll l-annotazzjoni `T: 'a`, li tindika li kwalunkwe referenza f `T` hija valida matul il-ħajja kollha ta `'a`.
///
/// Meta tibda inizjalment `Slice` inti sempliċement tipprovdi l-valur `PhantomData` għall-qasam `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Parametri tat-tip mhux użati
///
/// Xi drabi jiġri li jkollok parametri tat-tip mhux użati li jindikaw għal liema tip ta 'dejta hija struct "tied", anke jekk dik id-data fil-fatt ma tinstabx fl-istruttura nnifisha.
/// Hawn hu eżempju fejn dan jinħoloq b [FFI].
/// L-interface barrani juża manki tat-tip `*mut ()` biex jirreferi għal valuri Rust ta 'tipi differenti.
/// Aħna nsegwu t-tip Rust billi nużaw parametru tat-tip fantażma fuq l-istruttura `ExternalResource` li tgeżwer manku.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Sjieda u l-kontroll tal-waqgħa
///
/// Iż-żieda ta 'qasam tat-tip `PhantomData<T>` tindika li t-tip tiegħek għandu data tat-tip `T`.Dan imbagħad jimplika li meta t-tip tiegħek jitwaqqa ', jista' jwaqqa 'każ wieħed jew aktar tat-tip `T`.
/// Dan għandu effett fuq l-analiżi [drop check] tal-kompilatur Rust.
///
/// Jekk l-istruttura tiegħek fil-fatt *m'għandhiex* id-dejta tat-tip `T`, huwa aħjar li tuża tip ta 'referenza, bħal `PhantomData<&'a T>` (ideally) jew `PhantomData<*const T>` (jekk ma tapplikax ħajja), sabiex ma tindikax is-sjieda.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// trait intern tal-kompilatur użat biex jindika t-tip ta 'enum discriminants.
///
/// Dan trait huwa implimentat awtomatikament għal kull tip u ma jżid l-ebda garanzija ma [`mem::Discriminant`].
/// Hija **imġieba mhux definita** li tibdel bejn `DiscriminantKind::Discriminant` u `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// It-tip tad-diskriminanti, li għandu jissodisfa l-trait bounds meħtieġa minn `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// trait intern tal-kompilatur użat biex jiddetermina jekk tip fihx `UnsafeCell` internament, iżda mhux permezz ta 'indirezzjoni.
///
/// Dan jaffettwa, pereżempju, jekk `static` ta 'dak it-tip jitqiegħedx f'memorja statika li tinqara biss jew f'memorja statika li tista' tinkiteb.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tipi li jistgħu jiġu mċaqalqa mingħajr periklu wara li jkunu ġew ippinjati.
///
/// Rust innifsu m'għandu l-ebda kunċett ta 'tipi immobbli, u jqis li ċ-ċaqliq (eż., Permezz ta' assenjazzjoni jew [`mem::replace`]) huwa dejjem sikur.
///
/// It-tip [`Pin`][Pin] jintuża minflok biex jipprevjeni ċaqliq permezz tas-sistema tat-tip.L-indikaturi `P<T>` imgeżwer fit-tgeżwir [`Pin<P<T>>`][Pin] ma jistgħux jiġu mċaqalqa minn barra.
/// Ara d-dokumentazzjoni [`pin` module] għal aktar informazzjoni dwar il-pinning.
///
/// L-implimentazzjoni ta `Unpin` trait għal `T` tneħħi r-restrizzjonijiet ta' pinning off-tip, li mbagħad tippermetti li `T` jiġi mċaqlaq minn [`Pin<P<T>>`][Pin] b'funzjonijiet bħal [`mem::replace`].
///
///
/// `Unpin` m'għandha l-ebda konsegwenza għal dejta mhux ippinjata.
/// B'mod partikolari, [`mem::replace`] kuntentament iċċaqlaq id-dejta `!Unpin` (jaħdem għal kwalunkwe `&mut T`, mhux biss meta `T: Unpin`).
/// Madankollu, ma tistax tuża [`mem::replace`] fuq dejta mgeżwra ġewwa [`Pin<P<T>>`][Pin] għax ma tistax tikseb ix-`&mut T` li għandek bżonn għal dan, u *dak* huwa dak li jagħmel din is-sistema taħdem.
///
/// Allura dan, pereżempju, jista 'jsir biss fuq tipi li jimplimentaw `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Għandna bżonn referenza li tista 'tinbidel biex insejħu `mem::replace`.
/// // Nistgħu niksbu referenza bħal din billi (implicitly) jinvoka `Pin::deref_mut`, iżda dan huwa possibbli biss għax `String` jimplimenta `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Dan trait huwa implimentat awtomatikament għal kważi kull tip.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Tip ta 'markatur li ma jimplimentax `Unpin`.
///
/// Jekk tip fih `PhantomPinned`, ma jimplimentax `Unpin` awtomatikament.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implimentazzjonijiet ta `Copy` għal tipi primittivi.
///
/// Implimentazzjonijiet li ma jistgħux jiġu deskritti f'Rust huma implimentati f `traits::SelectionContext::copy_clone_conditions()` f `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Referenzi kondiviżi jistgħu jiġu kkupjati, iżda referenzi li jistgħu jinbidlu *ma jistgħux*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}