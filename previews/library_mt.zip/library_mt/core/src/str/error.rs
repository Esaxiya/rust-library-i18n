//! Jiddefinixxi t-tip ta 'żball utf8.

use crate::fmt;

/// Żbalji li jistgħu jseħħu meta tipprova tinterpreta sekwenza ta [`u8`] bħala sekwenza.
///
/// Bħala tali, il-familja ta 'funzjonijiet u metodi `from_utf8` kemm għal [`String`] s kif ukoll għal [`&str`] s jagħmlu użu minn dan l-iżball, pereżempju.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Il-metodi ta 'dan it-tip ta' żball jistgħu jintużaw biex joħolqu funzjonalità simili għal `String::from_utf8_lossy` mingħajr ma talloka memorja heap:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Jirritorna l-indiċi fis-sekwenza mogħtija sa liema UTF-8 validu ġie vverifikat.
    ///
    /// Huwa l-indiċi massimu tali li `from_utf8(&input[..index])` jirritorna `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::str;
    ///
    /// // xi bytes invalidi, f'vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 jirritorna Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // it-tieni byte mhux validu hawn
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Jipprovdi aktar informazzjoni dwar il-falliment:
    ///
    /// * `None`: it-tmiem tad-dħul intlaħaq bla mistenni.
    ///   `self.valid_up_to()` huwa 1 sa 3 bytes mit-tmiem tal-input.
    ///   Jekk fluss ta 'byte (bħal fajl jew sokit tan-netwerk) qed jiġi dekodifikat b'mod inkrementali, dan jista' jkun `char` validu li s-sekwenza ta 'byte UTF-8 tiegħu hija mifruxa fuq bosta biċċiet.
    ///
    ///
    /// * `Some(len)`: kien hemm byte mhux mistenni.
    ///   It-tul ipprovdut huwa dak tas-sekwenza tal-byte invalida li tibda fl-indiċi mogħti minn `valid_up_to()`.
    ///   Id-dekodifikazzjoni għandha terġa 'tibda wara dik is-sekwenza (wara li ddaħħal [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) f'każ ta' dekodifikazzjoni lossy.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Jirritorna żball meta jiġi analizzat `bool` bl-użu ta [`from_str`] jonqos
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}