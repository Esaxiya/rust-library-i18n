//! Implimentazzjonijiet Trait għal `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Timplimenta l-ordni tal-kordi.
///
/// Il-kordi huma ordnati [lexicographically](Ord#lexicographical-comparison) bil-valuri tal-byte tagħhom.
/// Dan jordna punti tal-kodiċi Unicode bbażati fuq il-pożizzjonijiet tagħhom fil-mapep tal-kodiċi.
/// Dan mhux neċessarjament l-istess bħall-ordni "alphabetical", li tvarja skont il-lingwa u l-lokalità.
/// L-issortjar tal-kordi skont standards aċċettati kulturalment teħtieġ dejta speċifika għall-lokal li hija barra mill-ambitu tat-tip `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Timplimenta operazzjonijiet ta 'tqabbil fuq kordi.
///
/// Il-kordi huma mqabbla [lexicographically](Ord#lexicographical-comparison) bil-valuri tal-byte tagħhom.
/// Dan iqabbel il-punti tal-kodiċi Unicode bbażati fuq il-pożizzjonijiet tagħhom fil-mapep tal-kodiċi.
/// Dan mhux neċessarjament l-istess bħall-ordni "alphabetical", li tvarja skont il-lingwa u l-lokalità.
/// It-tqabbil ta 'kordi skond standards aċċettati kulturalment jirrikjedi data speċifika għall-lokal li hija barra mill-ambitu tat-tip `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Timplimenta slicing tas-substring bis-sintassi `&self[..]` jew `&mut self[..]`.
///
/// Jirritorna porzjon tas-sekwenza kollha, jiġifieri, jirritorna `&self` jew `&mut self`.Ekwivalenti għal `&self [0 ..
/// len] `jew`&mut self [0 ..
/// len]`.
/// B'differenza minn operazzjonijiet oħra ta 'indiċjar, dan qatt ma jista' panic.
///
/// Din l-operazzjoni hija *O*(1).
///
/// Qabel 1.20.0, dawn l-operazzjonijiet ta 'indiċjar kienu għadhom appoġġati minn implimentazzjoni diretta ta' `Index` u `IndexMut`.
///
/// Ekwivalenti għal `&self[0 .. len]` jew `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Timplimenta slicing tas-substring bis-sintassi `&self[begin .. end]` jew `&mut self[begin .. end]`.
///
/// Jirritorna porzjon tas-sekwenza mogħtija mill-firxa tal-byte [`tibda`, `end`).
///
/// Din l-operazzjoni hija *O*(1).
///
/// Qabel 1.20.0, dawn l-operazzjonijiet ta 'indiċjar kienu għadhom appoġġati minn implimentazzjoni diretta ta' `Index` u `IndexMut`.
///
/// # Panics
///
/// Panics jekk `begin` jew `end` ma jindikax l-offset tal-byte tal-bidu ta 'karattru (kif definit minn `is_char_boundary`), jekk `begin > end`, jew jekk `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // dawn se panic:
/// // byte 2 jinsab fi `ö`:
/// // &s [2 ..3];
///
/// // byte 8 jinsab fi `老`&s [1 ..
/// // 8];
///
/// // byte 100 huwa barra s-sekwenza&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURTÀ: ikkontrollajt biss li `start` u `end` huma fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            // Aħna ċċekkjajna wkoll il-konfini tal-karattri, allura dan huwa UTF-8 validu.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURTÀ: ikkontrollajt biss li `start` u `end` huma fuq konfini char.
            // Nafu li l-indikatur huwa uniku għax irċevejnih minn `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURTÀ: min iċempel jiggarantixxi li `self` huwa fil-limiti ta `slice`
        // li jissodisfa l-kundizzjonijiet kollha għal `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURTÀ: ara l-kummenti għal `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary jiċċekkja li l-indiċi jinsab f '[0, .len()] ma jistax jerġa' juża `get` bħal hawn fuq, minħabba inkwiet NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIGURTÀ: ikkontrollajt biss li `start` u `end` huma fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Timplimenta slicing tas-substring bis-sintassi `&self[.. end]` jew `&mut self[.. end]`.
///
/// Jirritorna porzjon tas-sekwenza mogħtija mill-firxa tal-byte [`0`, `end`).
/// Ekwivalenti għal `&self[0 .. end]` jew `&mut self[0 .. end]`.
///
/// Din l-operazzjoni hija *O*(1).
///
/// Qabel 1.20.0, dawn l-operazzjonijiet ta 'indiċjar kienu għadhom appoġġati minn implimentazzjoni diretta ta' `Index` u `IndexMut`.
///
/// # Panics
///
/// Panics jekk `end` ma jindikax l-offset tal-byte tal-bidu ta 'karattru (kif definit minn `is_char_boundary`), jew jekk `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURTÀ: għadek kif ivverifikajt li `end` huwa fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIGURTÀ: għadek kif ivverifikajt li `end` huwa fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SIGURTÀ: għadek kif ivverifikajt li `end` huwa fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Timplimenta slicing tas-substring bis-sintassi `&self[begin ..]` jew `&mut self[begin ..]`.
///
/// Jirritorna porzjon tas-sekwenza mogħtija mill-firxa tal-byte [`tibda`, `len`).Ekwivalenti għal `&self [tibda ..
/// len] `jew`&mut self [tibda ..
/// len]`.
///
/// Din l-operazzjoni hija *O*(1).
///
/// Qabel 1.20.0, dawn l-operazzjonijiet ta 'indiċjar kienu għadhom appoġġati minn implimentazzjoni diretta ta' `Index` u `IndexMut`.
///
/// # Panics
///
/// Panics jekk `begin` ma jindikax l-offset tal-byte tal-bidu ta 'karattru (kif definit minn `is_char_boundary`), jew jekk `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURTÀ: għadek kif ivverifikajt li `start` huwa fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIGURTÀ: għadek kif ivverifikajt li `start` huwa fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIGURTÀ: min iċempel jiggarantixxi li `self` huwa fil-limiti ta `slice`
        // li jissodisfa l-kundizzjonijiet kollha għal `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIGURTÀ: identika għal `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SIGURTÀ: għadek kif ivverifikajt li `start` huwa fuq konfini char,
            // u qed ngħaddu f'referenza sikura, allura l-valur tar-ritorn se jkun ukoll wieħed.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Timplimenta slicing tas-substring bis-sintassi `&self[begin ..= end]` jew `&mut self[begin ..= end]`.
///
/// Jirritorna porzjon tas-sekwenza mogħtija mill-firxa tal-byte [`begin`, `end`].Ekwivalenti għal `&self [begin .. end + 1]` jew `&mut self[begin .. end + 1]`, ħlief jekk `end` għandu l-valur massimu għal `usize`.
///
/// Din l-operazzjoni hija *O*(1).
///
/// # Panics
///
/// Panics jekk `begin` ma jindikax l-offset tal-byte tal-bidu ta 'karattru (kif definit minn `is_char_boundary`), jekk `end` ma jindikax l-offset tal-byte tat-tmiem ta' karattru (`end + 1` huwa offset tal-byte tal-bidu jew ugwali għal `len`), jekk `begin > end`, jew jekk `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Timplimenta slicing tas-substring bis-sintassi `&self[..= end]` jew `&mut self[..= end]`.
///
/// Jirritorna porzjon tas-sekwenza mogħtija mill-firxa tal-byte [0, `end`].
/// Ekwivalenti għal `&self [0 .. end + 1]`, ħlief jekk `end` għandu l-valur massimu għal `usize`.
///
/// Din l-operazzjoni hija *O*(1).
///
/// # Panics
///
/// Panics jekk `end` ma jindikax it-tmiem tal-byte offset ta 'karattru (`end + 1` huwa jew offset tal-byte tal-bidu kif definit minn `is_char_boundary`, jew ugwali għal `len`), jew jekk `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Analizza valur minn sekwenza
///
/// Il-metodu [`from_str`] ta '' FromStr 'spiss jintuża b'mod impliċitu, permezz tal-metodu [`parse`] ta' ['str`].
/// Ara d-dokumentazzjoni ta '[`parse`] għal eżempji.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` m'għandux parametru tal-ħajja, u allura tista 'biss analizza tipi li ma fihomx parametru tal-ħajja huma stess.
///
/// Fi kliem ieħor, tista 'tqis `i32` ma' `FromStr`, iżda mhux `&i32`.
/// Tista 'analizza struttura li fiha `i32`, iżda mhux waħda li fiha `&i32`.
///
/// # Examples
///
/// Implimentazzjoni bażika ta `FromStr` fuq eżempju tat-tip `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// L-iżball assoċjat li jista 'jiġi rritornat mill-analiżi.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizza sekwenza `s` biex tirritorna valur ta 'dan it-tip.
    ///
    /// Jekk l-analiżi tirnexxi, irritorna l-valur ġewwa [`Ok`], inkella meta s-sekwenza tkun ifformattjata ħażin irritorna żball speċifiku għal ġewwa [`Err`].
    /// It-tip ta 'żball huwa speċifiku għall-implimentazzjoni taż-trait.
    ///
    /// # Examples
    ///
    /// Użu bażiku b [`i32`], tip li jimplimenta `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse `bool` minn sekwenza.
    ///
    /// Jirrendi `Result<bool, ParseBoolError>`, għax `s` jista 'jew ma jistax ikun fil-fatt parseable.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Innota, f'ħafna każijiet, il-metodu `.parse()` fuq `str` huwa aktar xieraq.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}