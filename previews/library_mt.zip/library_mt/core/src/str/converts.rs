//! Modi kif toħloq `str` minn porzjon ta 'bytes.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Ikkonverti porzjon ta 'bytes għal porzjon ta' sekwenza.
///
/// String porzjon ([`&str`]) huwa magħmul minn bytes ([`u8`]), u porzjon byte ([`&[u8]`][byteslice]) huwa magħmul minn bytes, għalhekk din il-funzjoni tikkonverti bejn it-tnejn.
/// Mhux il-flieli kollha tal-byte huma flieli tas-sekwenza validi, madankollu: [`&str`] jirrikjedi li hija UTF-8 valida.
/// `from_utf8()` jiċċekkja biex jiżgura li l-bytes huma UTF-8 validi, u mbagħad jagħmel il-konverżjoni.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Jekk inti żgur li l-porzjon tal-byte huwa UTF-8 validu, u ma tridx iġġarrab l-ispiża ġenerali tal-kontroll tal-validità, hemm verżjoni mhux sigura ta 'din il-funzjoni, [`from_utf8_unchecked`], li għandha l-istess imġieba imma taqbeż il-kontroll.
///
///
/// Jekk għandek bżonn `String` minflok `&str`, ikkunsidra [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Minħabba li tista 'talloka munzell `[u8; N]`, u tista' tieħu [`&[u8]`][byteslice] minnha, din il-funzjoni hija mod wieħed kif ikollok sekwenza allokata f'pila.Hemm eżempju ta 'dan fit-taqsima tal-eżempji hawn taħt.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Jirritorna `Err` jekk il-porzjon mhuwiex UTF-8 b'deskrizzjoni dwar għaliex il-porzjon ipprovdut mhuwiex UTF-8.
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::str;
///
/// // xi bytes, f'vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Nafu li dawn il-bytes huma validi, allura uża biss `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Bytes mhux korretti:
///
/// ```
/// use std::str;
///
/// // xi bytes invalidi, f'vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Ara d-dokumenti għal [`Utf8Error`] għal aktar dettalji dwar it-tipi ta 'żbalji li jistgħu jiġu rritornati.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // xi bytes, f'firxa allokata f'munzelli
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Nafu li dawn il-bytes huma validi, allura uża biss `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURTÀ: Għaddejt biss il-validazzjoni.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Ikkonverti porzjon li jista 'jinbidel ta' bytes għal porzjon ta 'sekwenza li jista' jinbidel.
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" bħala vector li jista 'jinbidel
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Peress li nafu li dawn il-bytes huma validi, nistgħu nużaw `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Bytes mhux korretti:
///
/// ```
/// use std::str;
///
/// // Xi bytes invalidi f'vector li jista 'jinbidel
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Ara d-dokumenti għal [`Utf8Error`] għal aktar dettalji dwar it-tipi ta 'żbalji li jistgħu jiġu rritornati.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIGURTÀ: Għaddejt biss il-validazzjoni.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Ikkonverti porzjon ta 'bytes għal porzjon ta' sekwenza mingħajr ma tiċċekkja li s-sekwenza fiha UTF-8 validu.
///
/// Ara l-verżjoni sikura, [`from_utf8`], għal aktar informazzjoni.
///
/// # Safety
///
/// Din il-funzjoni mhix sigura għax ma tiċċekkjax li l-bytes mgħoddija lilha huma UTF-8 validi.
/// Jekk din il-limitazzjoni tinkiser, tirriżulta mġieba mhux definita, billi l-bqija ta 'Rust tassumi li [`&str`] s huma UTF-8 validi.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::str;
///
/// // xi bytes, f'vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SIGURTÀ: min iċempel għandu jiggarantixxi li l-bytes `v` huma UTF-8 validi.
    // Jiddependi wkoll fuq `&str` u `&[u8]` li għandhom l-istess tqassim.
    unsafe { mem::transmute(v) }
}

/// Ikkonverti porzjon ta 'bytes għal porzjon ta' sekwenza mingħajr ma tiċċekkja li s-sekwenza fiha UTF-8 validu;verżjoni li tista 'tinbidel.
///
///
/// Ara l-verżjoni immutabbli, [`from_utf8_unchecked()`] għal aktar informazzjoni.
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SIGURTÀ: min iċempel għandu jiggarantixxi li l-bytes `v`
    // huma UTF-8 validi, għalhekk il-kast għal `*mut str` huwa sigur.
    // Ukoll, id-dereferenza tal-pointer hija sigura għaliex dak il-pointer ġej minn referenza li hija garantita li tkun valida għall-kitbiet.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}