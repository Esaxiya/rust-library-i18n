//! Is-sekwenza Pattern API.
//!
//! L-API tal-Mudell jipprovdi mekkaniżmu ġeneriku għall-użu ta 'tipi ta' mudelli differenti meta tfittex permezz ta 'sekwenza.
//!
//! Għal aktar dettalji, ara l-traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], u [`DoubleEndedSearcher`].
//!
//! Għalkemm din l-API hija instabbli, hija esposta permezz ta 'APIs stabbli fuq it-tip [`str`].
//!
//! # Examples
//!
//! [`Pattern`] huwa [implemented][pattern-impls] fl-API stabbli għal [`&str`][`str`], [`char`], flieli ta [`char`], u funzjonijiet u għeluq li jimplimentaw `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // mudell char
//! assert_eq!(s.find('n'), Some(2));
//! // porzjon tal-mudell tal-karattri
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // mudell ta 'għeluq
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Mudell ta 'spag.
///
/// `Pattern<'a>` jesprimi li t-tip ta 'implimentazzjoni jista' jintuża bħala mudell ta 'sekwenza għal tiftix f [`&'a str`][str].
///
/// Pereżempju, kemm `'a'` kif ukoll `"aa"` huma mudelli li jaqblu fl-indiċi `1` fis-sekwenza `"baaaab"`.
///
/// Iż-trait innifsu jaġixxi bħala bennej għal tip [`Searcher`] assoċjat, li jagħmel ix-xogħol attwali li jsib okkorrenzi tal-mudell f'qabel.
///
///
/// Skond it-tip tal-mudell, l-imġieba ta 'metodi bħal [`str::find`] u [`str::contains`] tista' tinbidel.
/// It-tabella hawn taħt tiddeskrivi wħud minn dawk l-imgieba.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Tiftix assoċjat għal dan il-mudell
    type Searcher: Searcher<'a>;

    /// Jibni lil min ifittex assoċjat minn `self` u `haystack` biex ifittex fih.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Jiċċekkja jekk il-mudell jaqbilx ma 'kullimkien fil-haystack
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Jiċċekkja jekk il-mudell jaqbilx fuq quddiem tal-haystack
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Jiċċekkja jekk il-mudell jaqbilx fuq wara tal-haystack
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Neħħi l-mudell minn quddiem il-haystack, jekk jaqbel.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SIGURTÀ: `Searcher` huwa magħruf li jirritorna indiċi validi.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Tneħħi l-mudell minn wara l-haystack, jekk jaqbel.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SIGURTÀ: `Searcher` huwa magħruf li jirritorna indiċi validi.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Riżultat ta 'sejħa għal [`Searcher::next()`] jew [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Jesprimi li tqabbil tal-mudell instab f `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Jesprimi li `haystack[a..b]` ġie rrifjutat bħala tqabbil possibbli tal-mudell.
    ///
    /// Innota li jista 'jkun hemm aktar minn `Reject` wieħed bejn żewġ' Match`es, m'hemm l-ebda ħtieġa biex dawn jiġu kkombinati f'waħda.
    ///
    ///
    Reject(usize, usize),
    /// Jesprimi li kull byte tal-haystack żar, u temmet l-iterazzjoni.
    ///
    Done,
}

/// Fittex għal mudell ta 'sekwenza.
///
/// Dan trait jipprovdi metodi għat-tiftix ta 'logħbiet li ma jikkoinċidux ta' mudell li jibda mix-(left) ta 'quddiem ta' sekwenza.
///
/// Se jkun implimentat minn tipi `Searcher` assoċjati ta [`Pattern`] trait.
///
/// Iż-trait huwa mmarkat bħala mhux sikur minħabba li l-indiċi rritornati mill-metodi [`next()`][Searcher::next] huma meħtieġa li jkunu fuq limiti utf8 validi fil-haystack.
/// Dan jippermetti lill-konsumaturi ta 'dan iż-trait jaqtgħu l-haystack mingħajr verifiki addizzjonali ta' runtime.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter għas-sekwenza sottostanti li trid tiġi mfittxija fiha
    ///
    /// Dejjem jirritorna l-istess [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Twettaq il-pass tat-tfittxija li jmiss billi tibda minn quddiem.
    ///
    /// - Jirritorna [`Match(a, b)`][SearchStep::Match] jekk `haystack[a..b]` jaqbel mal-mudell.
    /// - Jirritorna [`Reject(a, b)`][SearchStep::Reject] jekk `haystack[a..b]` ma jistax jaqbel mal-mudell, anke parzjalment.
    /// - Jirritorna [`Done`][SearchStep::Done] jekk kull byte tal-haystack ġie viżitat.
    ///
    /// Il-fluss ta 'valuri [`Match`][SearchStep::Match] u [`Reject`][SearchStep::Reject] sa [`Done`][SearchStep::Done] se jkun fih firxiet ta' indiċi li huma biswit, li ma jikkoinċidux, li jkopru l-haystack kollu, u li jistabbilixxu fuq fruntieri utf8.
    ///
    ///
    /// Riżultat [`Match`][SearchStep::Match] jeħtieġ li jkun fih il-mudell imqabbel kollu, madankollu r-riżultati [`Reject`][SearchStep::Reject] jistgħu jinqasmu f'bosta frammenti arbitrarji biswit.Iż-żewġ firxiet jista 'jkollhom tul żero.
    ///
    /// Bħala eżempju, il-mudell `"aaa"` u l-haystack `"cbaaaaab"` jistgħu jipproduċu n-nixxiegħa
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Issib ir-riżultat [`Match`][SearchStep::Match] li jmiss.Ara [`next()`][Searcher::next].
    ///
    /// B'differenza minn [`next()`][Searcher::next], m'hemm l-ebda garanzija li l-firxiet ritornati ta 'dan u [`next_reject`][Searcher::next_reject] se jikkoinċidu.
    /// Dan jirritorna `(start_match, end_match)`, fejn start_match huwa l-indiċi ta 'fejn tibda l-partita, u end_match huwa l-indiċi wara t-tmiem tal-partita.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Issib ir-riżultat [`Reject`][SearchStep::Reject] li jmiss.Ara [`next()`][Searcher::next] u [`next_match()`][Searcher::next_match].
    ///
    /// B'differenza minn [`next()`][Searcher::next], m'hemm l-ebda garanzija li l-firxiet ritornati ta 'dan u [`next_match`][Searcher::next_match] se jikkoinċidu.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Tiftix bil-maqlub għal mudell ta 'sekwenza.
///
/// Dan trait jipprovdi metodi għat-tiftix ta 'logħbiet li ma jikkoinċidux ta' mudell li jibda mix-(right) ta 'wara ta' sekwenza.
///
/// Se jkun implimentat minn tipi [`Searcher`] assoċjati ta [`Pattern`] trait jekk il-mudell jappoġġja t-tfittxija tiegħu minn wara.
///
///
/// Il-firxiet tal-indiċi rritornati minn dan trait mhumiex meħtieġa biex jaqblu eżattament ma 'dawk tat-tfittxija bil-quddiem b'lura.
///
/// Għar-raġuni għaliex dan trait huwa mmarkat bħala mhux sikur, arahom ġenitur trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Twettaq il-pass tat-tfittxija li jmiss billi tibda minn wara.
    ///
    /// - Jirritorna [`Match(a, b)`][SearchStep::Match] jekk `haystack[a..b]` jaqbel mal-mudell.
    /// - Jirritorna [`Reject(a, b)`][SearchStep::Reject] jekk `haystack[a..b]` ma jistax jaqbel mal-mudell, anke parzjalment.
    /// - Jirritorna [`Done`][SearchStep::Done] jekk kull byte tal-haystack ġie viżitat
    ///
    /// Il-fluss ta 'valuri [`Match`][SearchStep::Match] u [`Reject`][SearchStep::Reject] sa [`Done`][SearchStep::Done] se jkun fih firxiet ta' indiċi li huma biswit, li ma jikkoinċidux, li jkopru l-haystack kollu, u li jistabbilixxu fuq fruntieri utf8.
    ///
    ///
    /// Riżultat [`Match`][SearchStep::Match] jeħtieġ li jkun fih il-mudell imqabbel kollu, madankollu r-riżultati [`Reject`][SearchStep::Reject] jistgħu jinqasmu f'bosta frammenti arbitrarji biswit.Iż-żewġ firxiet jista 'jkollhom tul żero.
    ///
    /// Bħala eżempju, il-mudell `"aaa"` u l-haystack `"cbaaaaab"` jistgħu jipproduċu n-nixxiegħa `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Isib ir-riżultat [`Match`][SearchStep::Match] li jmiss.
    /// Ara [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Isib ir-riżultat [`Reject`][SearchStep::Reject] li jmiss.
    /// Ara [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// Markatur trait biex jesprimi li [`ReverseSearcher`] jista 'jintuża għal implimentazzjoni [`DoubleEndedIterator`].
///
/// Għal dan, l-impl ta [`Searcher`] u [`ReverseSearcher`] għandhom isegwu dawn il-kundizzjonijiet:
///
/// - Ir-riżultati kollha ta `next()` għandhom ikunu identiċi għar-riżultati ta' `next_back()` f'ordni inversa.
/// - `next()` u `next_back()` għandhom jaġixxu bħala ż-żewġt itruf ta 'firxa ta' valuri, jiġifieri ma jistgħux "walk past each other".
///
/// # Examples
///
/// `char::Searcher` hija `DoubleEndedSearcher` għax it-tfittxija għal [`char`] teħtieġ biss tħares lejn waħda kull darba, li ġġib l-istess miż-żewġt itruf.
///
/// `(&str)::Searcher` mhix `DoubleEndedSearcher` minħabba li l-mudell `"aa"` fil-haystack `"aaa"` jaqbel jew ma `"[aa]a"` jew `"a[aa]"`, jiddependi minn liema naħa huwa mfittex.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl għall-karattru
/////////////////////////////////////////////////////////////////////////////

/// Tip assoċjat għal `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // invariant tas-sigurtà: `finger`/`finger_back` għandu jkun indiċi validu tal-byte utf8 ta `haystack` Dan l-invariant jista' jinkiser *fi* next_match u next_match_back, madankollu għandhom joħorġu bis-swaba 'fuq il-limiti validi tal-punt tal-kodiċi.
    //
    //
    /// `finger` huwa l-indiċi tal-byte kurrenti tat-tfittxija bil-quddiem.
    /// Immaġina li teżisti qabel il-byte fl-indiċi tagħha, jiġifieri
    /// `haystack[finger]` hija l-ewwel byte tal-porzjon li rridu nispezzjonaw waqt it-tiftix 'il quddiem
    ///
    finger: usize,
    /// `finger_back` huwa l-indiċi tal-byte kurrenti tat-tfittxija b'lura.
    /// Immaġina li teżisti wara l-byte fl-indiċi tagħha, jiġifieri
    /// haystack [finger_back, 1] huwa l-aħħar byte tal-porzjon li rridu nispezzjonaw waqt it-tiftix 'il quddiem (u għalhekk l-ewwel byte li għandu jiġi spezzjonat meta nċemplu next_back()).
    ///
    finger_back: usize,
    /// Il-karattru li qed jiġi mfittex
    needle: char,

    // invariant tas-sigurtà: `utf8_size` għandu jkun inqas minn 5
    /// In-numru ta 'bytes `needle` jieħu meta kkodifikat f utf8.
    utf8_size: usize,
    /// Kopja kodifikata utf8 tax-`needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SIGURTÀ: 1-4 tiggarantixxi s-sigurtà ta `get_unchecked`
        // 1. `self.finger` u `self.finger_back` jinżammu fuq fruntieri unicode (dan ma jvarjax)
        // 2. `self.finger >= 0` peress li jibda f'0 u jiżdied biss
        // 3. `self.finger < self.finger_back` għax inkella l-karattru `iter` jirritorna `SearchStep::Done`
        // 4.
        // `self.finger` jiġi qabel it-tmiem tal-haystack għax `self.finger_back` jibda fl-aħħar u jonqos biss
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // żid byte offset tal-karattru kurrenti mingħajr ma terġa 'tikkodifika bħala utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // ġib il-haystack wara l-aħħar karattru misjub
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // l-aħħar byte tal-labra kkodifikata utf8 SIGURTÀ: għandna invariant li `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Is-saba 'l-ġdid huwa l-indiċi tal-byte li sibna, flimkien ma' wieħed, peress li aħna memchr'd għall-aħħar byte tal-karattru.
                //
                // Innota li dan mhux dejjem jagħtina subgħajna fuq konfini UTF8.
                // Jekk *ma* sibniex il-karattru tagħna jista 'jkun li indiċjajna għall-aħħar byte ta' karattru ta '3-byte jew 4-byte.
                // Ma nistgħux sempliċement naqbżu għall-byte tal-bidu validu li jmiss għax karattru bħal ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` ikollna dejjem insibu t-tieni byte meta nfittxu t-tielet.
                //
                //
                // Madankollu, dan huwa kompletament tajjeb.
                // Filwaqt li għandna l-invariant li self.finger huwa fuq konfini UTF8, dan l-invariant mhuwiex invokat f'dan il-metodu (huwa invokat f CharSearcher::next()).
                //
                // Aħna noħorġu minn dan il-metodu biss meta naslu fit-tarf tas-sekwenza, jew jekk insibu xi ħaġa.Meta nsibu xi ħaġa l-`finger` se jkun issettjat għal konfini UTF8.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ma sibt xejn, ħarġa
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // ħalli next_reject juża l-implimentazzjoni awtomatika minn Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SIGURTÀ: ara l-kumment għal next() hawn fuq
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // naqqas l-offset tal-byte tal-karattru kurrenti mingħajr ma terġa 'tikkodifika bħala utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // ġib il-haystack sa imma ma tinkludix l-aħħar karattru mfittex
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // l-aħħar byte tal-labra kkodifikata utf8 SIGURTÀ: għandna invariant li `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // aħna fittixna porzjon li kien ikkumpensat minn self.finger, żid self.finger biex tirkupra l-indiċi oriġinali
                //
                let index = self.finger + index;
                // memrchr jirritorna l-indiċi tal-byte li nixtiequ nsibu.
                // Fil-każ ta 'karattru ASCII, dan huwa tassew fejn nixtiequ saba' l-ġdid tagħna li jkun ("after" il-karattru misjub fil-paradigma ta 'iterazzjoni inversa).
                //
                // Għal karattri multibyte rridu naqbżu bin-numru ta 'aktar bytes li għandhom minn ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // imxi saba 'qabel il-karattru misjub (jiġifieri, fl-indiċi tal-bidu tiegħu)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Ma nistgħux nużaw finger_back=index, daqs + 1 hawn.
                // Jekk sibna l-aħħar karattru ta 'karattru ta' daqs differenti (jew il-byte tan-nofs ta 'karattru differenti) għandna nħabbtu s-swaba' lura sa `index`.
                // Dan bl-istess mod jagħmel lil `finger_back` il-potenzjal li ma jibqax fuq fruntiera, iżda dan huwa OK peress li aħna noħorġu minn din il-funzjoni fuq fruntiera jew meta l-ħaxxar ikun ġie mfittex kompletament.
                //
                //
                // B'differenza next_match dan m'għandux il-problema ta 'bytes ripetuti f utf-8 għaliex qed infittxu l-aħħar byte, u nistgħu nsibu l-aħħar byte biss meta nfittxu bil-maqlub.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ma sibt xejn, ħarġa
                return None;
            }
        }
    }

    // ħalli next_reject_back juża l-implimentazzjoni awtomatika minn Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Tiftix għal karattri li huma ugwali għal [`char`] partikolari.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Implikat għal tgeżwir MultiCharEq
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Qabbel it-tulijiet tal-iteratur tal-porzjon tal-byte intern biex issib it-tul tal-karattru kurrenti
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Qabbel it-tulijiet tal-iteratur tal-porzjon tal-byte intern biex issib it-tul tal-karattru kurrenti
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl għal&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Ibdel/Neħħi minħabba ambigwità fit-tifsira.

/// Tip assoċjat għal `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Tiftix għal karattri li huma ugwali għal kwalunkwe [karattri] fis-slice.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl għal F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Tip assoċjat għal `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Tiftix għal [`char`] s li jaqblu mal-predikat mogħti.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl għal&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegati għall-impl. `&str`
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl għal &str
/////////////////////////////////////////////////////////////////////////////

/// Tiftix ta 'substring li ma jallokax.
///
/// Se jimmaniġġja l-mudell `""` bħala li jirritorna logħbiet vojta f'kull konfini tal-karattru.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Jiċċekkja jekk il-mudell jaqbilx fuq quddiem tal-haystack.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Neħħi l-mudell minn quddiem il-haystack, jekk jaqbel.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SIGURTÀ: il-prefiss kien verifikat biss li jeżisti.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Jiċċekkja jekk il-mudell jaqbilx fuq wara tal-haystack.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Tneħħi l-mudell minn wara l-haystack, jekk jaqbel.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SIGURTÀ: is-suffiss kien verifikat biss li jeżisti.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// Tfittxija ta 'substring b'żewġ direzzjonijiet
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Tip assoċjat għal `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // labra vojta tirrifjuta kull karattru u taqbel ma 'kull sekwenza vojta bejniethom
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher jipproduċi indiċi *Match* validu li jinqasam fil-konfini tal-karatterizzati sakemm jikkoreġi t-tqabbil u li l-haystack u l-labra huma validi UTF-8 *Irrifjuta* mill-algoritmu jista 'jaqa' fuq kwalunkwe indiċi, imma aħna nimxuhom manwalment sal-limitu tal-karattru li jmiss, sabiex ikunu sikuri utf-8.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // aqbeż għall-konfini tal-karattri li jmiss
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ikteb il-każijiet `true` u `false` biex tħeġġeġ lill-kompilatur jispeċjalizza ż-żewġ każijiet separatament.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // aqbeż għall-konfini tal-karattri li jmiss
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // ikteb `true` u `false`, bħal `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// L-istat intern tal-algoritmu ta 'tfittxija ta' substring b'żewġ direzzjonijiet.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// indiċi ta 'fatturizzazzjoni kritika
    crit_pos: usize,
    /// indiċi ta 'fatturizzazzjoni kritika għal labra maqluba
    crit_pos_back: usize,
    period: usize,
    /// `byteset` hija estensjoni (mhux parti mill-algoritmu b'żewġ direzzjonijiet);
    /// huwa "fingerprint" 64-bit fejn kull sett bit `j` jikkorrispondi għal (byte&63)==j preżenti fil-labra.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// indiċi f'labra li qabel aħna diġà qbiżna
    memory: usize,
    /// indiċi fil-labra u wara aħna diġà qbiżna
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // Spjegazzjoni li tinqara b'mod partikolari ta 'x'inhu għaddej hawn tista' tinstab fil-ktieb "Text Algorithms" ta 'Crochemore u Rytter, kap 13.
        // Speċifikament ara l-kodiċi għal "Algorithm CP" fuq p.
        // 323.
        //
        // Dak li għaddej huwa li għandna xi fatturizzazzjoni kritika (u, v) tal-labra, u rridu niddeterminaw jekk u hix suffiss ta '&v [.. perjodu].
        // Jekk hu hekk, nużaw "Algorithm CP1".
        // Inkella nużaw "Algorithm CP2", li huwa ottimizzat għal meta l-perjodu tal-labra huwa kbir.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // każ ta 'perjodu qasir-il-perjodu huwa eżatt ikkalkula fatturizzazzjoni kritika separata għall-labra maqluba x=u' v 'fejn | v' |<period(x).
            //
            // Dan jitħaffef billi l-perjodu jkun magħruf diġà.
            // Innota li każ bħal x= "acba" jista 'jkun ikkalkulat eżattament' il quddiem (crit_pos=1, perjodu=3) waqt li jkun ikkalkulat b'perjodu approssimattiv bil-maqlub (crit_pos=2, perjodu=2).
            // Aħna nużaw il-fatturizzazzjoni inversa mogħtija imma nżommu l-perjodu eżatt.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // każ ta 'perjodu twil-għandna approssimazzjoni għall-perjodu attwali, u ma nużawx il-memorizzazzjoni.
            //
            //
            // Approssima l-perjodu bil-limitu baxx max(|u|, |v|) + 1.
            // Il-fatturizzazzjoni kritika hija effiċjenti biex tintuża kemm għat-tfittxija bil-quddiem kif ukoll għar-rivers.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Valur finta biex ifisser li l-perjodu huwa twil
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // Waħda mill-ideat ewlenin ta 'Two-Way hija li niffatturizzaw il-labra f'żewġ nofsijiet, (u, v), u nibdew nippruvaw insibu v fil-haystack billi niskennjaw mix-xellug għal-lemin.
    // Jekk v taqbel, nippruvaw inqabblu u billi niskennjaw mil-lemin għax-xellug.
    // Kemm nistgħu naqbżu meta niltaqgħu ma 'diskrepanza hija kollha bbażata fuq il-fatt li (u, v) hija fatturizzazzjoni kritika għall-labra.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` juża `self.position` bħala l-cursor tiegħu
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Iċċekkja li għandna spazju biex infittxu fil-pożizzjoni + labra_last ma tistax tfur jekk nassumu li flieli huma delimitati mill-firxa ta 'isize.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Aqbeż malajr minn porzjonijiet kbar mhux relatati mas-substring tagħna
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Ara jekk il-parti t-tajba tal-labra taqbilx
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Ara jekk il-parti tax-xellug tal-labra taqbilx
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Sibna taqbila!
            let match_pos = self.position;

            // Note: żid self.period minflok needle.len() biex ikollok logħbiet li jikkoinċidu
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // issettjat għal needle.len(), self.period għal logħbiet li jikkoinċidu
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Isegwi l-ideat f `next()`.
    //
    // Id-definizzjonijiet huma simetriċi, b period(x) = period(reverse(x)) u local_period(u, v) = local_period(reverse(v), reverse(u)), allura jekk (u, v) huwa fatturizzazzjoni kritika, hekk ukoll (reverse(v), reverse(u)).
    //
    //
    // Għall-każ bil-maqlub ikkalkulajna fattorizzazzjoni kritika x=u 'v' (qasam `crit_pos_back`).Għandna bżonn | u |<period(x) għall-każ bil-quddiem u għalhekk | v '|<period(x) għar-rivers.
    //
    // Biex tfittex bil-maqlub mill-haystack, aħna nfittxu 'l quddiem permezz ta' haystack maqlub b'labra maqluba, li taqbel l-ewwel u 'u mbagħad v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` juża `self.end` bħala l-cursor tiegħu-sabiex `next()` u `next_back()` ikunu indipendenti.
        //
        let old_end = self.end;
        'search: loop {
            // Iċċekkja li għandna spazju biex infittxu fl-aħħar, needle.len() se jdawwar meta ma jkunx hemm iktar spazju, iżda minħabba l-limiti tat-tul tal-porzjon qatt ma jista 'jdawwar it-triq kollha lura fit-tul tal-haystack.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Aqbeż malajr minn porzjonijiet kbar mhux relatati mas-substring tagħna
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Ara jekk il-parti tax-xellug tal-labra taqbilx
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Ara jekk il-parti t-tajba tal-labra taqbilx
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Sibna taqbila!
            let match_pos = self.end - needle.len();
            // Note: sub self.period minflok needle.len() biex ikollok logħbiet li jikkoinċidu
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Ikkalkula s-suffiss massimu ta `arr`.
    //
    // Is-suffiss massimu huwa fatturizzazzjoni kritika possibbli (u, v) ta `arr`.
    //
    // Jirritorna ("i", `p`) fejn `i` huwa l-indiċi tal-bidu ta 'v u `p` huwa l-perjodu ta' v.
    //
    // `order_greater` jiddetermina jekk l-ordni lessikali hix `<` jew `>`.
    // Iż-żewġ ordnijiet għandhom jiġu kkalkulati-l-ordni bl-akbar `i` tagħti fatturazzjoni kritika.
    //
    //
    // Għal każijiet ta 'perjodu twil, il-perjodu li jirriżulta mhuwiex eżatt (huwa qasir wisq).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Jikkorrispondi għal i fil-karta
        let mut right = 1; // Jikkorrispondi għal j fil-karta
        let mut offset = 0; // Jikkorrispondi għal k fil-karta, iżda jibda minn 0
        // biex taqbel ma 'indiċjar ibbażat fuq 0.
        let mut period = 1; // Jikkorrispondi għal p fil-karta

        while let Some(&a) = arr.get(right + offset) {
            // `left` se jkun ġewwa meta jkun `right`.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Is-suffiss huwa iżgħar, il-perjodu huwa prefiss sħiħ s'issa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avvanza permezz tar-ripetizzjoni tal-perjodu kurrenti.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Is-suffiss huwa akbar, ibda mill-ġdid mill-post attwali.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Ikkalkula s-suffiss massimu tal-parti ta 'wara ta' `arr`.
    //
    // Is-suffiss massimu huwa fatturizzazzjoni kritika possibbli (u ', v') ta `arr`.
    //
    // Jirritorna `i` fejn `i` huwa l-indiċi tal-bidu ta 'v', minn wara;
    // jirritorna immedjatament meta jintlaħaq perjodu ta `known_period`.
    //
    // `order_greater` jiddetermina jekk l-ordni lessikali hix `<` jew `>`.
    // Iż-żewġ ordnijiet għandhom jiġu kkalkulati-l-ordni bl-akbar `i` tagħti fatturazzjoni kritika.
    //
    //
    // Għal każijiet ta 'perjodu twil, il-perjodu li jirriżulta mhuwiex eżatt (huwa qasir wisq).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Jikkorrispondi għal i fil-karta
        let mut right = 1; // Jikkorrispondi għal j fil-karta
        let mut offset = 0; // Jikkorrispondi għal k fil-karta, iżda jibda minn 0
        // biex taqbel ma 'indiċjar ibbażat fuq 0.
        let mut period = 1; // Jikkorrispondi għal p fil-karta
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Is-suffiss huwa iżgħar, il-perjodu huwa prefiss sħiħ s'issa.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Avvanza permezz tar-ripetizzjoni tal-perjodu kurrenti.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Is-suffiss huwa akbar, ibda mill-ġdid mill-post attwali.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy jippermetti lill-algoritmu li jew jaqbeż in-non-logħbiet malajr kemm jista 'jkun, jew biex jaħdem b'mod li jarmi Jirrifjuta relattivament malajr.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Aqbeż biex taqbel ma 'l-intervalli kemm jista' jkun malajr
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emetti Tirrifjuta regolarment
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}