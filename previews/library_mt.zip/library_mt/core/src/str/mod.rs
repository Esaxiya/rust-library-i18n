//! Manipulazzjoni tal-kordi.
//!
//! Għal aktar dettalji, ara l-modulu [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. barra mill-limiti
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. tibda <=tmiem
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. konfini tal-karattru
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // sib il-karattru
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` għandu jkun inqas minn len u konfini char
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Jirritorna t-tul ta `self`.
    ///
    /// Dan it-tul huwa f'bytes, mhux [`char`] s jew grafemi.
    /// Fi kliem ieħor, jista 'ma jkunx dak li bniedem jikkunsidra t-tul tas-sekwenza.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Jirritorna `true` jekk `self` għandu tul ta 'żero bytes.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Jiċċekkja li l-'indiċi`-th byte huwa l-ewwel byte f'sekwenza ta 'punti tal-kodiċi UTF-8 jew it-tarf tas-sekwenza.
    ///
    ///
    /// Il-bidu u t-tmiem tas-sekwenza (meta `index== self.len()`) huma kkunsidrati bħala konfini.
    ///
    /// Jirritorna `false` jekk `index` huwa akbar minn `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // bidu ta `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // it-tieni byte ta `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // it-tielet byte ta `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 u len huma dejjem ok.
        // Ittestja għal 0 b'mod espliċitu sabiex tkun tista 'ttejjeb il-verifika faċilment u aqbeż id-dejta tas-sekwenza tal-qari għal dak il-każ.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Din hija bit magic ekwivalenti għal: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Ikkonverti porzjon ta 'sekwenza għal porzjon ta' byte.
    /// Biex tikkonverti l-porzjon tal-byte lura fi porzjon ta 'sekwenza, uża l-funzjoni [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SIGURTÀ: ħoss kostanti għax aħna nbiddlu żewġ tipi bl-istess tqassim
        unsafe { mem::transmute(self) }
    }

    /// Ikkonverti porzjon ta 'sekwenza li tista' tinbidel għal porzjon ta 'byte li jista' jinbidel.
    ///
    /// # Safety
    ///
    /// Min iċempel għandu jiżgura li l-kontenut tal-porzjon huwa UTF-8 validu qabel ma jintemm is-self u jintuża l-`str` sottostanti.
    ///
    ///
    /// L-użu ta `str` li l-kontenut tiegħu mhuwiex validu UTF-8 huwa mġieba mhux definita.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SIGURTÀ: il-kast minn `&str` għal `&[u8]` huwa sigur minn `str`
        // għandu l-istess tqassim bħal `&[u8]` (il-libstd biss jista 'jagħmel din il-garanzija).
        // Id-dereferenza tal-pointer hija sigura peress li ġejja minn referenza li tista 'tinbidel li hija garantita li tkun valida għall-kitbiet.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Ikkonverti porzjon ta 'sekwenza għal pointer nej.
    ///
    /// Peress li l-flieli tas-sekwenza huma porzjon ta 'bytes, il-pointer nej jindika [`u8`].
    /// Dan il-pointer se jkun qed jindika l-ewwel byte tal-porzjon tas-sekwenza.
    ///
    /// Min iċempel għandu jiżgura li l-indikatur li jintbagħat lura qatt ma jinkiteb lilu.
    /// Jekk għandek bżonn tibdel il-kontenut tal-porzjon tas-sekwenza, uża [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Ikkonverti porzjon ta 'sekwenza li tista' tinbidel għal pointer nej.
    ///
    /// Peress li l-flieli tas-sekwenza huma porzjon ta 'bytes, il-pointer nej jindika [`u8`].
    /// Dan il-pointer se jkun qed jindika l-ewwel byte tal-porzjon tas-sekwenza.
    ///
    /// Hija r-responsabbiltà tiegħek li tiżgura li l-porzjon tas-sekwenza jiġi modifikat biss b'mod li jibqa 'validu UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Jirritorna subslice ta `str`.
    ///
    /// Din hija l-alternattiva mingħajr paniku għall-indiċjar tax-`str`.
    /// Jirritorna [`None`] kull meta operazzjoni ta 'indiċjar ekwivalenti tkun panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indiċi mhux fuq il-konfini tas-sekwenza UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // barra mill-limiti
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Jirritorna subslice mutabbli ta `str`.
    ///
    /// Din hija l-alternattiva mingħajr paniku għall-indiċjar tax-`str`.
    /// Jirritorna [`None`] kull meta operazzjoni ta 'indiċjar ekwivalenti tkun panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // tul korrett
    /// assert!(v.get_mut(0..5).is_some());
    /// // barra mill-limiti
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Jirritorna subslice mhux ikkontrollat ta `str`.
    ///
    /// Din hija l-alternattiva mhux kontrollata għall-indiċjar tax-`str`.
    ///
    /// # Safety
    ///
    /// Dawk li jċemplu din il-funzjoni huma responsabbli li dawn il-prekundizzjonijiet jiġu sodisfatti:
    ///
    /// * L-indiċi tal-bidu m'għandux jaqbeż l-indiċi tat-tmiem;
    /// * L-indiċijiet għandhom ikunu fil-limiti tal-porzjon oriġinali;
    /// * L-indiċi għandhom ikunu fuq il-konfini tas-sekwenza UTF-8.
    ///
    /// Fin-nuqqas ta 'dan, il-porzjon ta' sekwenza ritornata jista 'jirreferi għal memorja invalida jew jikser l-invariants ikkomunikati bit-tip `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked`;
        // il-porzjon huwa dereferenzjabbli minħabba li `self` hija referenza sigura.
        // Il-pointer mibgħut lura huwa sigur minħabba li l-impls ta `SliceIndex` għandhom jiggarantixxu li huwa.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Jirritorna subslice mutabbli u mhux ivverifikat ta `str`.
    ///
    /// Din hija l-alternattiva mhux kontrollata għall-indiċjar tax-`str`.
    ///
    /// # Safety
    ///
    /// Dawk li jċemplu din il-funzjoni huma responsabbli li dawn il-prekundizzjonijiet jiġu sodisfatti:
    ///
    /// * L-indiċi tal-bidu m'għandux jaqbeż l-indiċi tat-tmiem;
    /// * L-indiċijiet għandhom ikunu fil-limiti tal-porzjon oriġinali;
    /// * L-indiċi għandhom ikunu fuq il-konfini tas-sekwenza UTF-8.
    ///
    /// Fin-nuqqas ta 'dan, il-porzjon ta' sekwenza ritornata jista 'jirreferi għal memorja invalida jew jikser l-invariants ikkomunikati bit-tip `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked_mut`;
        // il-porzjon huwa dereferenzjabbli minħabba li `self` hija referenza sigura.
        // Il-pointer mibgħut lura huwa sigur minħabba li l-impls ta `SliceIndex` għandhom jiggarantixxu li huwa.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Toħloq porzjon ta 'sekwenza minn porzjon ta' sekwenza ieħor, billi tevita l-kontrolli tas-sigurtà.
    ///
    /// Dan ġeneralment mhux irrakkomandat, uża b'kawtela!Għal alternattiva sigura ara [`str`] u [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Din il-biċċa l-ġdida tmur minn `begin` għal `end`, inkluż `begin` iżda eskluża `end`.
    ///
    /// Biex tikseb porzjon ta 'sekwenza li tista' tinbidel minflok, ara l-metodu [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Dawk li jċemplu din il-funzjoni huma responsabbli li jiġu sodisfatti tliet prekundizzjonijiet:
    ///
    /// * `begin` m'għandux jeċċedi `end`.
    /// * `begin` u `end` għandhom ikunu pożizzjonijiet ta 'byte fi ħdan il-porzjon ta' sekwenza.
    /// * `begin` u `end` għandhom ikunu fuq il-konfini tas-sekwenza UTF-8.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked`;
        // il-porzjon huwa dereferenzjabbli minħabba li `self` hija referenza sigura.
        // Il-pointer mibgħut lura huwa sigur minħabba li l-impls ta `SliceIndex` għandhom jiggarantixxu li huwa.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Toħloq porzjon ta 'sekwenza minn porzjon ta' sekwenza ieħor, billi tevita l-kontrolli tas-sigurtà.
    /// Dan ġeneralment mhux irrakkomandat, uża b'kawtela!Għal alternattiva sigura ara [`str`] u [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Din il-biċċa l-ġdida tmur minn `begin` għal `end`, inkluż `begin` iżda eskluża `end`.
    ///
    /// Biex tikseb porzjon ta 'sekwenza immutabbli minflok, ara l-metodu [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Dawk li jċemplu din il-funzjoni huma responsabbli li jiġu sodisfatti tliet prekundizzjonijiet:
    ///
    /// * `begin` m'għandux jeċċedi `end`.
    /// * `begin` u `end` għandhom ikunu pożizzjonijiet ta 'byte fi ħdan il-porzjon ta' sekwenza.
    /// * `begin` u `end` għandhom ikunu fuq il-konfini tas-sekwenza UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `get_unchecked_mut`;
        // il-porzjon huwa dereferenzjabbli minħabba li `self` hija referenza sigura.
        // Il-pointer mibgħut lura huwa sigur minħabba li l-impls ta `SliceIndex` għandhom jiggarantixxu li huwa.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Aqsam porzjon ta 'sekwenza waħda fi tnejn f'indiċi.
    ///
    /// L-argument, `mid`, għandu jkun offset tal-byte mill-bidu tas-sekwenza.
    /// Għandu jkun ukoll fuq il-konfini ta 'punt tal-kodiċi UTF-8.
    ///
    /// Iż-żewġ flieli rritornati jmorru mill-bidu tal-porzjon tas-sekwenza għal `mid`, u minn `mid` sat-tarf tas-sekwenza.
    ///
    /// Biex tikseb flieli ta 'sekwenza li jistgħu jinbidlu minflok, ara l-metodu [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics jekk `mid` mhuwiex fuq limitu tal-punt tal-kodiċi UTF-8, jew jekk għadda mit-tmiem tal-aħħar punt tal-kodiċi tal-porzjon tas-sekwenza.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary jiċċekkja li l-indiċi jinsab f '[0, .len()]
        if self.is_char_boundary(mid) {
            // SIGURTÀ: għadek kif ivverifikajt li `mid` jinsab fuq konfini char.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Aqsam porzjon ta 'sekwenza waħda li tista' tinbidel fi tnejn f'indiċi.
    ///
    /// L-argument, `mid`, għandu jkun offset tal-byte mill-bidu tas-sekwenza.
    /// Għandu jkun ukoll fuq il-konfini ta 'punt tal-kodiċi UTF-8.
    ///
    /// Iż-żewġ flieli rritornati jmorru mill-bidu tal-porzjon tas-sekwenza għal `mid`, u minn `mid` sat-tarf tas-sekwenza.
    ///
    /// Biex tikseb flieli ta 'sekwenza immutabbli minflok, ara l-metodu [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics jekk `mid` mhuwiex fuq limitu tal-punt tal-kodiċi UTF-8, jew jekk għadda mit-tmiem tal-aħħar punt tal-kodiċi tal-porzjon tas-sekwenza.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary jiċċekkja li l-indiċi jinsab f '[0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SIGURTÀ: għadek kif ivverifikajt li `mid` jinsab fuq konfini char.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Jirritorna iteratur fuq il-[`char`] s ta 'porzjon ta' sekwenza.
    ///
    /// Peress li porzjon ta 'sekwenza jikkonsisti f UTF-8 validu, nistgħu nirrepetu permezz ta' porzjon ta 'sekwenza minn [`char`].
    /// Dan il-metodu jirritorna iteratur bħal dan.
    ///
    /// Huwa importanti li tiftakar li [`char`] jirrappreżenta Valur Skalar Unicode, u jista 'ma jaqbilx mal-idea tiegħek ta' x'inhu 'character'.
    ///
    /// Iterazzjoni fuq raggruppamenti tal-grafema tista 'tkun dak li attwalment trid.
    /// Din il-funzjonalità mhix provduta mill-librerija standard ta 'Rust, iċċekkja crates.io minflok.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Ftakar, [`char`] s jistgħu ma jaqblux mal-intwizzjoni tiegħek dwar il-karattri:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // mhux 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Jirritorna iteratur fuq il-[`char`] s ta 'porzjon ta' sekwenza, u l-pożizzjonijiet tagħhom.
    ///
    /// Peress li porzjon ta 'sekwenza jikkonsisti f UTF-8 validu, nistgħu nirrepetu permezz ta' porzjon ta 'sekwenza minn [`char`].
    /// Dan il-metodu jirritorna iteratur ta 'dawn [il-karattri], kif ukoll il-pożizzjonijiet tal-byte tagħhom.
    ///
    /// L-iteratur jagħti tuples.Il-pożizzjoni hija l-ewwel, ix-[`char`] hija t-tieni.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Ftakar, [`char`] s jistgħu ma jaqblux mal-intwizzjoni tiegħek dwar il-karattri:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // mhux (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // innota t-3 hawn, l-aħħar karattru ħa żewġ bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Iteratur fuq il-bytes ta 'porzjon ta' sekwenza.
    ///
    /// Hekk kif porzjon ta 'sekwenza jikkonsisti f'sekwenza ta' bytes, nistgħu nterrjaw minn porzjon ta 'sekwenza b'byte.
    /// Dan il-metodu jirritorna iteratur bħal dan.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Jaqsam porzjon ta 'sekwenza mill-ispazju vojt.
    ///
    /// L-iteratur mibgħut lura jagħti lura slices ta 'sekwenza li huma sub-slices tal-porzjon ta' sekwenza oriġinali, separati bi kwalunkwe ammont ta 'spazju vojt.
    ///
    ///
    /// 'Whitespace' huwa definit skont it-termini tal-Propjetà Ewlenija Derivata Unicode `White_Space`.
    /// Jekk minflok trid taqsam biss fuq spazji bojod ASCII, uża [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Kull tip ta 'spazju abjad huwa kkunsidrat:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Jaqsam porzjon ta 'sekwenza mill-ispazju vojt ASCII.
    ///
    /// L-iteratur mibgħut lura jirritorna slices tas-sekwenza li huma sub-slices tas-slice tas-sekwenza oriġinali, separati bi kwalunkwe ammont ta 'spazju vojt ASCII.
    ///
    ///
    /// Biex tinqasam b'Unicode `Whitespace` minflok, uża [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// It-tipi kollha ta `spazji bojod ASCII huma kkunsidrati:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Iteratur fuq il-linji ta 'sekwenza, bħala flieli tas-sekwenza.
    ///
    /// Il-linji jintemmu jew b'linja ġdida (`\n`) jew ritorn bil-karrozza b'linja li tgħaddi (`\r\n`).
    ///
    /// L-aħħar linja li tintemm mhix obbligatorja.
    /// String li jispiċċa b'linja finali li tispiċċa tirritorna l-istess linji bħal sekwenza mod ieħor identika mingħajr linja finali li tispiċċa.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// It-tmiem tal-linja finali mhux meħtieġ:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Iteratur fuq il-linji ta 'sekwenza.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Jirritorna iteratur ta `u16` fuq is-sekwenza kkodifikata bħala UTF-16.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Jirritorna `true` jekk il-mudell mogħti jaqbel ma 'sub-porzjon ta' din il-porzjon ta 'sekwenza.
    ///
    /// Jirritorna `false` jekk le.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Jirritorna `true` jekk il-mudell mogħti jaqbel ma 'prefiss ta' din il-porzjon ta 'sekwenza.
    ///
    /// Jirritorna `false` jekk le.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Jirritorna `true` jekk il-mudell mogħti jaqbel ma 'suffiss ta' din il-porzjon ta 'sekwenza.
    ///
    /// Jirritorna `false` jekk le.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Jirritorna l-indiċi tal-byte tal-ewwel karattru ta 'din il-porzjon ta' sekwenza li taqbel mal-mudell.
    ///
    /// Jirritorna [`None`] jekk il-mudell ma jaqbilx.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Mudelli aktar kumplessi li jużaw stil u għeluq mingħajr punt:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ma ssibx il-mudell:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Jirritorna l-indiċi tal-byte għall-ewwel karattru tal-iktar taqbila tal-lemin tal-mudell f'din il-porzjon ta 'sekwenza.
    ///
    /// Jirritorna [`None`] jekk il-mudell ma jaqbilx.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Mudelli aktar kumplessi b'għeluq:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ma ssibx il-mudell:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iteratur fuq subkordi ta 'din il-porzjon ta' sekwenza, separati minn karattri mqabbla ma 'mudell.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jkun [`DoubleEndedIterator`] jekk il-mudell jippermetti tfittxija bil-maqlub u t-tfittxija forward/reverse tagħti l-istess elementi.
    /// Dan jgħodd għal, eż., [`char`], iżda mhux għal `&str`.
    ///
    /// Jekk il-mudell jippermetti tfittxija bil-maqlub iżda r-riżultati tiegħu jistgħu jkunu differenti minn tfittxija bil-quddiem, jista 'jintuża l-metodu [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Jekk il-mudell huwa porzjon ta 'karattri, maqsum fuq kull okkorrenza ta' xi wieħed mill-karattri:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Mudell aktar kumpless, bl-użu ta 'għeluq:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Jekk sekwenza fiha separaturi kontigwi multipli, tispiċċa b'kordi vojta fl-output:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Separaturi kontigwi huma separati bis-sekwenza vojta.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separaturi fil-bidu jew fit-tmiem ta 'sekwenza huma mdawra minn kordi vojta.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Meta s-sekwenza vojta tintuża bħala separatur, tifred kull karattru fis-sekwenza, flimkien mal-bidu u t-tmiem tas-sekwenza.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Separaturi kontigwi jistgħu jwasslu għal imġieba possibbilment sorprendenti meta l-ispazju vojt jintuża bħala s-separatur.Dan il-kodiċi huwa korrett:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ jagħtik:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Uża [`split_whitespace`] għal din l-imġieba.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iteratur fuq subkordi ta 'din il-porzjon ta' sekwenza, separati minn karattri mqabbla ma 'mudell.
    /// Differenti mill-iteratur prodott minn `split` f'dak `split_inclusive` iħalli l-parti mqabbla bħala t-terminatur tas-subkordi.
    ///
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Jekk l-aħħar element tas-sekwenza jkun imqabbel, dak l-element jiġi kkunsidrat bħala t-terminatur tas-sub-sekwenza preċedenti.
    /// Dik is-substring se tkun l-aħħar oġġett mibgħut lura mill-iteratur.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iteratur fuq substrings tal-porzjon ta 'sekwenza mogħtija, separati b'karattri mqabbla ma' mudell u mogħtija f'ordni inversa.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jeħtieġ li d-disinn jappoġġja tfittxija bil-maqlub, u tkun [`DoubleEndedIterator`] jekk tfittxija forward/reverse tagħti l-istess elementi.
    ///
    ///
    /// Għal iterazzjoni minn quddiem, jista 'jintuża l-metodu [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Mudell aktar kumpless, bl-użu ta 'għeluq:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iteratur fuq substrings tal-porzjon ta 'sekwenza mogħtija, separati minn karattri mqabbla ma' mudell.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekwivalenti għal [`split`], ħlief li s-substring ta 'wara tinqabeż jekk tkun vojta.
    ///
    /// [`split`]: str::split
    ///
    /// Dan il-metodu jista 'jintuża għal dejta ta' sekwenza li hija _terminated_, minflok _separated_ b'disinn.
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jkun [`DoubleEndedIterator`] jekk il-mudell jippermetti tfittxija bil-maqlub u t-tfittxija forward/reverse tagħti l-istess elementi.
    /// Dan jgħodd għal, eż., [`char`], iżda mhux għal `&str`.
    ///
    /// Jekk il-mudell jippermetti tfittxija bil-maqlub iżda r-riżultati tiegħu jistgħu jkunu differenti minn tfittxija bil-quddiem, jista 'jintuża l-metodu [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iteratur fuq subkordi ta `self`, separati minn karattri mqabbla ma' mudell u mogħtija f'ordni inversa.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Ekwivalenti għal [`split`], ħlief li s-substring ta 'wara tinqabeż jekk tkun vojta.
    ///
    /// [`split`]: str::split
    ///
    /// Dan il-metodu jista 'jintuża għal dejta ta' sekwenza li hija _terminated_, minflok _separated_ b'disinn.
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jeħtieġ li l-mudell isostni tfittxija bil-maqlub, u jkun spiċċa darbtejn jekk tfittxija forward/reverse tagħti l-istess elementi.
    ///
    ///
    /// Għal iterazzjoni minn quddiem, jista 'jintuża l-metodu [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Iteratur fuq substrings tal-porzjon ta 'sekwenza mogħtija, separati b'disinn, ristrett biex jirritorna l-iktar oġġetti `n`.
    ///
    /// Jekk jiġu rritornati s-substrings `n`, l-aħħar substring (in-`n`th substring) ikun fiha l-bqija tas-sekwenza.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura mhux se jkun doppju, minħabba li mhuwiex effiċjenti biex jiġi appoġġjat.
    ///
    /// Jekk il-mudell jippermetti tfittxija bil-maqlub, jista 'jintuża l-metodu [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Mudell aktar kumpless, bl-użu ta 'għeluq:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iteratur fuq subkordi ta 'din il-porzjon ta' sekwenza, separata b'disinn, li tibda mit-tarf tas-sekwenza, ristretta biex tirritorna l-iktar oġġetti `n`.
    ///
    ///
    /// Jekk jiġu rritornati s-substrings `n`, l-aħħar substring (in-`n`th substring) ikun fiha l-bqija tas-sekwenza.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura mhux se jkun doppju, minħabba li mhuwiex effiċjenti biex jiġi appoġġjat.
    ///
    /// Għall-qsim minn quddiem, jista 'jintuża l-metodu [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Mudell aktar kumpless, bl-użu ta 'għeluq:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Aqsam is-sekwenza fuq l-ewwel okkorrenza tad-delimitatur speċifikat u tirritorna l-prefiss qabel id-delimitatur u s-suffiss wara d-delimitatur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Aqsam is-sekwenza fuq l-aħħar okkorrenza tad-delimitatur speċifikat u tirritorna l-prefiss qabel id-delimitatur u s-suffiss wara d-delimitatur.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Iteratur fuq il-logħbiet disjoint ta 'mudell fil-porzjon ta' sekwenza mogħtija.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jkun [`DoubleEndedIterator`] jekk il-mudell jippermetti tfittxija bil-maqlub u t-tfittxija forward/reverse tagħti l-istess elementi.
    /// Dan jgħodd għal, eż., [`char`], iżda mhux għal `&str`.
    ///
    /// Jekk il-mudell jippermetti tfittxija bil-maqlub iżda r-riżultati tiegħu jistgħu jkunu differenti minn tfittxija bil-quddiem, jista 'jintuża l-metodu [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Iteratur fuq il-logħbiet disjoint ta 'mudell fi ħdan din il-porzjon ta' sekwenza, ħareġ f'ordni inversa.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jeħtieġ li d-disinn jappoġġja tfittxija bil-maqlub, u tkun [`DoubleEndedIterator`] jekk tfittxija forward/reverse tagħti l-istess elementi.
    ///
    ///
    /// Għal iterazzjoni minn quddiem, jista 'jintuża l-metodu [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iteratur fuq il-logħbiet disjoint ta 'mudell fi ħdan din il-porzjon ta' sekwenza kif ukoll l-indiċi li fih tibda l-logħba.
    ///
    /// Għal logħbiet ta `pat` fi ħdan `self` li jikkoinċidu, jiġu rritornati biss l-indiċi li jikkorrispondu għall-ewwel logħba.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jkun [`DoubleEndedIterator`] jekk il-mudell jippermetti tfittxija bil-maqlub u t-tfittxija forward/reverse tagħti l-istess elementi.
    /// Dan jgħodd għal, eż., [`char`], iżda mhux għal `&str`.
    ///
    /// Jekk il-mudell jippermetti tfittxija bil-maqlub iżda r-riżultati tiegħu jistgħu jkunu differenti minn tfittxija bil-quddiem, jista 'jintuża l-metodu [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // l-ewwel `aba` biss
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Iteratur fuq il-logħbiet disjoint ta 'mudell fi `self`, ħareġ f'ordni inversa flimkien ma' l-indiċi tal-logħba.
    ///
    /// Għal logħbiet ta `pat` fi ħdan `self` li jikkoinċidu, jiġu rritornati biss l-indiċi li jikkorrispondu għall-aħħar logħba.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Imġieba iteratorja
    ///
    /// L-iteratur mibgħut lura jeħtieġ li d-disinn jappoġġja tfittxija bil-maqlub, u tkun [`DoubleEndedIterator`] jekk tfittxija forward/reverse tagħti l-istess elementi.
    ///
    ///
    /// Għal iterazzjoni minn quddiem, jista 'jintuża l-metodu [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // l-aħħar `aba` biss
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Jirritorna porzjon ta 'sekwenza bl-ispazju vojt ewlieni u ta' wara jitneħħa.
    ///
    /// 'Whitespace' huwa definit skont it-termini tal-Propjetà Ewlenija Derivata Unicode `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Jirritorna porzjon ta 'sekwenza bl-ispazju ewlieni mneħħi.
    ///
    /// 'Whitespace' huwa definit skont it-termini tal-Propjetà Ewlenija Derivata Unicode `White_Space`.
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// `start` f'dan il-kuntest tfisser l-ewwel pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa mix-xellug għal-lemin bħall-Ingliż jew ir-Russu, din tkun in-naħa tax-xellug, u għal-lemin għax-xellug bħall-Għarbi jew l-Ebrajk, din tkun in-naħa tal-lemin.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Jirritorna porzjon ta 'sekwenza bl-ispazju vojt imneħħi.
    ///
    /// 'Whitespace' huwa definit skont it-termini tal-Propjetà Ewlenija Derivata Unicode `White_Space`.
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// `end` f'dan il-kuntest tfisser l-aħħar pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa mix-xellug għal-lemin bħall-Ingliż jew ir-Russu, din tkun in-naħa tal-lemin, u għal-lemin għax-xellug bħall-Għarbi jew l-Ebrajk, din tkun in-naħa tax-xellug.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Jirritorna porzjon ta 'sekwenza bl-ispazju ewlieni mneħħi.
    ///
    /// 'Whitespace' huwa definit skont it-termini tal-Propjetà Ewlenija Derivata Unicode `White_Space`.
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// 'Left' f'dan il-kuntest tfisser l-ewwel pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa bħall-Għarbi jew l-Ebrajk li huma 'mil-lemin għax-xellug' minflok 'mix-xellug għal-lemin', din tkun in-naħa _right_, mhux ix-xellug.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Jirritorna porzjon ta 'sekwenza bl-ispazju vojt imneħħi.
    ///
    /// 'Whitespace' huwa definit skont it-termini tal-Propjetà Ewlenija Derivata Unicode `White_Space`.
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// 'Right' f'dan il-kuntest tfisser l-aħħar pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa bħall-Għarbi jew l-Ebrajk li huma 'mil-lemin għax-xellug' minflok 'mix-xellug għal-lemin', din tkun in-naħa _left_, mhux il-lemin.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Jirritorna porzjon ta 'sekwenza bil-prefissi u s-suffissi kollha li jaqblu ma' mudell imneħħi ripetutament.
    ///
    /// Ix-[pattern] jista 'jkun [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Mudell aktar kumpless, bl-użu ta 'għeluq:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Ftakar l-ewwel logħba magħrufa, ikkoreġiha hawn taħt jekk
            // l-aħħar partita hija differenti
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIGURTÀ: `Searcher` huwa magħruf li jirritorna indiċi validi.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Jirritorna porzjon ta 'sekwenza bil-prefissi kollha li jaqblu ma' mudell imneħħi ripetutament.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// `start` f'dan il-kuntest tfisser l-ewwel pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa mix-xellug għal-lemin bħall-Ingliż jew ir-Russu, din tkun in-naħa tax-xellug, u għal-lemin għax-xellug bħall-Għarbi jew l-Ebrajk, din tkun in-naħa tal-lemin.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SIGURTÀ: `Searcher` huwa magħruf li jirritorna indiċi validi.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Jirritorna porzjon ta 'sekwenza bil-prefiss imneħħi.
    ///
    /// Jekk is-sekwenza tibda bil-mudell `prefix`, tirritorna s-sekwenza wara l-prefiss, imgeżwer f `Some`.
    /// B'differenza minn `trim_start_matches`, dan il-metodu jneħħi l-prefiss eżattament darba.
    ///
    /// Jekk is-sekwenza ma tibdiex b `prefix`, tirritorna `None`.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Jirritorna porzjon ta 'sekwenza bis-suffiss imneħħi.
    ///
    /// Jekk is-sekwenza tispiċċa bid-disinn `suffix`, tirritorna s-substring qabel is-suffiss, imgeżwer f `Some`.
    /// B'differenza minn `trim_end_matches`, dan il-metodu jneħħi s-suffiss eżattament darba.
    ///
    /// Jekk is-sekwenza ma tispiċċax b `suffix`, tirritorna `None`.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Jirritorna porzjon ta 'sekwenza bis-suffissi kollha li jaqblu ma' mudell imneħħi ripetutament.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// `end` f'dan il-kuntest tfisser l-aħħar pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa mix-xellug għal-lemin bħall-Ingliż jew ir-Russu, din tkun in-naħa tal-lemin, u għal-lemin għax-xellug bħall-Għarbi jew l-Ebrajk, din tkun in-naħa tax-xellug.
    ///
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Mudell aktar kumpless, bl-użu ta 'għeluq:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIGURTÀ: `Searcher` huwa magħruf li jirritorna indiċi validi.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Jirritorna porzjon ta 'sekwenza bil-prefissi kollha li jaqblu ma' mudell imneħħi ripetutament.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// 'Left' f'dan il-kuntest tfisser l-ewwel pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa bħall-Għarbi jew l-Ebrajk li huma 'mil-lemin għax-xellug' minflok 'mix-xellug għal-lemin', din tkun in-naħa _right_, mhux ix-xellug.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Jirritorna porzjon ta 'sekwenza bis-suffissi kollha li jaqblu ma' mudell imneħħi ripetutament.
    ///
    /// Ix-[pattern] jista 'jkun `&str`, [`char`], porzjon ta' [`char`] s, jew funzjoni jew għeluq li jiddetermina jekk karattru jaqbilx.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Id-direzzjonalità tat-test
    ///
    /// String hija sekwenza ta 'bytes.
    /// 'Right' f'dan il-kuntest tfisser l-aħħar pożizzjoni ta 'dik is-sekwenza tal-byte;għal lingwa bħall-Għarbi jew l-Ebrajk li huma 'mil-lemin għax-xellug' minflok 'mix-xellug għal-lemin', din tkun in-naħa _left_, mhux il-lemin.
    ///
    ///
    /// # Examples
    ///
    /// Mudelli sempliċi:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Mudell aktar kumpless, bl-użu ta 'għeluq:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parses din il-porzjon ta 'sekwenza f'tip ieħor.
    ///
    /// Minħabba li `parse` huwa tant ġenerali, jista 'jikkawża problemi b'inferenza tat-tip.
    /// Bħala tali, `parse` hija waħda mill-ftit drabi li tara s-sintassi magħrufa bl-imħabba bħala 'turbofish': `::<>`.
    ///
    /// Dan jgħin lill-algoritmu ta 'inferenza jifhem speċifikament f'liema tip qed tipprova tidħol.
    ///
    /// `parse` tista 'tidħol fi kwalunkwe tip li timplimenta [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Irritorna [`Err`] jekk ma jkunx possibbli li din il-porzjon ta 'sekwenza tiġi analizzata fit-tip mixtieq.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Użu bażiku
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Uża l-'turbofish' minflok tinnota `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Fin-nuqqas ta 'parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Jiċċekkja jekk il-karattri kollha f'din is-sekwenza humiex fil-medda ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Nistgħu nittrattaw kull byte bħala karattru hawnhekk: il-karattri multibyte kollha jibdew b'byte li mhuwiex fil-medda ta 'ascii, allura aħna nieqfu hemm diġà.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Jiċċekkja li żewġ kordi huma taqbila sensittiva għall-każijiet ASCII.
    ///
    /// L-istess bħal `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, iżda mingħajr ma talloka u tikkopja temporanji.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Ikkonverti din is-sekwenza għall-ekwivalenti ASCII tagħha f'ittri kbar fil-post.
    ///
    /// Ittri ASCII 'a' sa 'z' huma mmappjati għal 'A' sa 'Z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tirritorna valur superjuri ġdid mingħajr ma timmodifika dak eżistenti, uża [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SIGURTÀ: sikur għax aħna nbiddlu żewġ tipi bl-istess tqassim.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Ikkonverti din is-sekwenza għall-ekwivalenti ASCII tagħha f'ittri żgħar fil-post.
    ///
    /// Ittri ASCII 'A' sa 'Z' huma mmappjati għal 'a' sa 'z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tirritorna valur ġdid b'ittri żgħar mingħajr ma timmodifika dak eżistenti, uża [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SIGURTÀ: sikur għax aħna nbiddlu żewġ tipi bl-istess tqassim.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Irritorna iteratur li jaħrab minn kull karattru f `self` b [`char::escape_debug`].
    ///
    ///
    /// Note: il-punti tal-kodiċi grafemi estiżi biss li jibdew is-sekwenza jiġu maħruba.
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Irritorna iteratur li jaħrab minn kull karattru f `self` b [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Irritorna iteratur li jaħrab minn kull karattru f `self` b [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Toħloq str vojta
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Joħloq str mutabbli vojta
    #[inline]
    fn default() -> Self {
        // SIGURTÀ: Is-sekwenza vojta hija UTF-8 valida.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Tip ta 'fn li jista' jissemma, ikklonjat
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SIGURTÀ: mhux sigur
        unsafe { from_utf8_unchecked(bytes) }
    };
}