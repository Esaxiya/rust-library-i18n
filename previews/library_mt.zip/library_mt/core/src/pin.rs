//! Tipi li jillimitaw id-dejta għall-post tagħha fil-memorja.
//!
//! Xi drabi huwa utli li jkollok oġġetti li huma garantiti li ma jiċċaqalqux, fis-sens li t-tqegħid tagħhom fil-memorja ma jinbidilx, u għalhekk jista 'jkun invokat.
//! Eżempju ewlieni ta 'xenarju bħal dan ikun il-bini ta' strutturi awtoreferenzali, billi ċċaqlaq oġġett b'indikaturi għalih innifsu jinvalidahom, li jistgħu jikkawżaw imġieba mhux definita.
//!
//! F'livell għoli, [`Pin<P>`] jiżgura li l-pointee ta 'kwalunkwe tip pointer `P` għandu post stabbli fil-memorja, li jfisser li ma jistax jiġi mċaqlaq x'imkien ieħor u l-memorja tiegħu ma tistax tiġi allokata qabel ma titwaqqa'.Aħna ngħidu li l-pointee huwa "pinned".L-affarijiet isiru aktar sottili meta jiġu diskussi tipi li jikkombinaw ippinjat ma 'dejta mhux ippinjat;[see below](#projections-and-structural-pinning) għal aktar dettalji.
//!
//! B'default, it-tipi kollha f'Rust huma mobbli.
//! Rust jippermetti li tgħaddi t-tipi kollha b'valur, u tipi komuni ta 'smart-pointer bħal [`Box<T>`] u `&mut T` jippermettu li tissostitwixxi u tmexxi l-valuri li fihom: tista' toħroġ minn [`Box<T>`], jew tista 'tuża [`mem::swap`].
//! [`Pin<P>`] jgeżwer pointer tat-tip `P`, allura [`Pin`]`<`[`Box`] `<T>>`jaħdem bħal regolari
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Kaxxa`] `<T>>`jitwaqqa ', hekk ukoll il-kontenut tagħha, u l-memorja tinżel
//!
//! deallocated.Bl-istess mod, ["Pin"] "<&mut T>" huwa simili ħafna għal `&mut T`.Madankollu, [`Pin<P>`] ma jħallix lill-klijenti fil-fatt jiksbu [`Box<T>`] jew `&mut T` għal dejta mwaħħla, li jimplika li ma tistax tuża operazzjonijiet bħal [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` jeħtieġ `&mut T`, imma ma nistgħux niksbuh.
//!     // Aħna mwaħħla, ma nistgħux npartu l-kontenut ta 'dawn ir-referenzi.
//!     // Nistgħu nużaw `Pin::get_unchecked_mut`, iżda dan mhuwiex sikur għal raġuni:
//!     // m`aħniex permessi nużawha biex inġorru affarijiet barra mix-`Pin`.
//! }
//! ```
//!
//! Ta 'min itenni li [`Pin<P>`] ma *jbiddilx* il-fatt li kompilatur Rust iqis it-tipi kollha mobbli.[`mem::swap`] jibqa 'jissejjaħ għal kwalunkwe `T`.Minflok, [`Pin<P>`] jipprevjeni ċerti valuri * (indikati minn indikaturi mgeżwra f [`Pin<P>`]) milli jiġu mċaqalqa billi jagħmilha impossibbli li tissejjaħ metodi li jeħtieġu `&mut T` fuqhom (bħal [`mem::swap`]).
//!
//! [`Pin<P>`] jista 'jintuża biex jitgeżwer kwalunkwe pointer tat-tip `P`, u bħala tali jinteraġixxi ma' [`Deref`] u [`DerefMut`].[`Pin<P>`] fejn `P: Deref` għandu jkun ikkunsidrat bħala "`P`-style pointer" għal `P::Target` ippinjat-allura, [`Pin`]`<`[`Kaxxa`] `<T>>`huwa pointer propjetà għal `T` ippinjat, u [`Pin`] `<` [`Rc`]`<T>>`huwa indikatur magħdud b'referenza għal `T` ippinjat.
//! Għall-korrettezza, [`Pin<P>`] jiddependi fuq l-implimentazzjonijiet ta [`Deref`] u [`DerefMut`] biex ma jiċċaqalqux mill-parametru `self` tagħhom, u qatt jirritornaw biss pointer għal data pinned meta jissejħu fuq pointer pinned.
//!
//! # `Unpin`
//!
//! Ħafna tipi huma dejjem mobbli b'mod liberu, anke meta jkunu mwaħħla, għax ma jiddependux fuq li jkollhom indirizz stabbli.Dan jinkludi t-tipi bażiċi kollha (bħal [`bool`], [`i32`], u referenzi) kif ukoll tipi li jikkonsistu biss minn dawn it-tipi.Tipi li ma jimpurtahomx mill-pinning jimplimentaw ix-[`Unpin`] auto-trait, li jikkanċella l-effett ta [`Pin<P>`].
//! Għal `T: Unpin`, [`Pin`]`<`[`Kaxxa`] `<T>>`u [`Box<T>`] jiffunzjonaw b'mod identiku, bħalma jagħmlu [`Pin`] `<&mut T>` u `&mut T`.
//!
//! Innota li l-pinning u [`Unpin`] jaffettwaw biss it-tip bil-ponta `P::Target`, mhux il-pointer tip `P` innifsu li kien imgeżwer f [`Pin<P>`].Pereżempju, jekk [`Box<T>`] huwiex [`Unpin`] jew le m'għandu l-ebda effett fuq l-imġieba ta '[`Pin`]`<`[`Kaxxa`] `<T>>`(hawnhekk, `T` huwa t-tip bil-ponta).
//!
//! # Eżempju: strutt awtoreferenzjali
//!
//! Qabel ma nidħlu f'aktar dettalji biex nispjegaw il-garanziji u l-għażliet assoċjati ma `Pin<T>`, niddiskutu xi eżempji dwar kif jista' jintuża.
//! Ħossok liberu li [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Din hija struttura awtoreferenzjali minħabba li l-kamp tal-porzjon jindika l-qasam tad-dejta.
//! // Ma nistgħux ninfurmaw lill-kompilatur dwar dan b'referenza normali, billi dan il-mudell ma jistax jiġi deskritt bir-regoli tas-self tas-soltu.
//! //
//! // Minflok nużaw pointer mhux maħdum, għalkemm wieħed li huwa magħruf li mhux null, kif nafu li qed jipponta lejn is-sekwenza.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Biex niżguraw li d-dejta ma tiċċaqlaqx meta terġa 'lura l-funzjoni, aħna npoġġuha fil-borġ fejn tibqa' għall-ħajja ta 'l-oġġett, u l-uniku mod biex taċċessaha jkun permezz ta' pointer għaliha.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // aħna noħolqu l-pointer ladarba d-data tkun f'postha inkella tkun diġà ċċaqalqet qabel ma nibdew
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // nafu li dan huwa sigur għax il-modifika ta 'qasam ma tiċċaqlaqx l-istruttura kollha
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Il-pointer għandu jindika l-post it-tajjeb, sakemm l-istruttura ma tkunx imxiet.
//! //
//! // Sadanittant, aħna liberi li nimxu l-indikatur.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Peress li t-tip tagħna ma jimplimentax Unpin, dan jonqos milli jiġbor:
//! // let mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Eżempju: lista intrużiva marbuta darbtejn
//!
//! F`lista intrużiva marbuta darbtejn, il-kollezzjoni fil-fatt ma tallokax il-memorja għall-elementi nnifisha.
//! L-allokazzjoni hija kkontrollata mill-klijenti, u l-elementi jistgħu jgħixu fuq qafas ta 'munzell li jgħix iqsar minn dak li tagħmel il-ġabra.
//!
//! Biex dan ix-xogħol jaħdem, kull element għandu indikazzjonijiet lejn il-predeċessur u s-suċċessur tiegħu fil-lista.L-elementi jistgħu jiġu miżjuda biss meta jkunu mwaħħlin, għax iċ-ċaqliq tal-elementi madwar jinvalida l-indikaturi.Barra minn hekk, l-implimentazzjoni [`Drop`] ta 'element ta' lista marbuta se tgħaqqad l-indikaturi tal-predeċessur u s-suċċessur tagħha biex tneħħi lilha nnifisha mil-lista.
//!
//! B`mod kruċjali, irridu nkunu nistgħu niddependu fuq li jissejjaħ [`drop`].Jekk element jista 'jiġi allokat mill-ġdid jew inkella invalidat mingħajr ma tissejjaħ [`drop`], l-indikaturi fih mill-elementi ġirien tiegħu jsiru invalidi, u dan jikser l-istruttura tad-dejta.
//!
//! Għalhekk, il-pinning jiġi wkoll ma 'garanzija relatata ma' ['drop'].
//!
//! # `Drop` guarantee
//!
//! L-iskop tal-pinning huwa li tkun tista 'tistrieħ fuq it-tqegħid ta' xi dejta fil-memorja.
//! Biex dan jaħdem, mhux biss iċ-ċaqliq tad-dejta huwa ristrett;it-tqassim mill-ġdid, l-użu mill-ġdid, jew inkella jinvalida l-memorja użata biex tinħażen id-dejta huwa ristrett ukoll.
//! Konkretament, għal data pinned għandek iżżomm l-invariant li *l-memorja tagħha ma tiġix invalidata jew użata mill-ġdid mill-mument li titwaħħal sa meta [`drop`] jissejjaħ*.Darba biss [`drop`] jirritorna jew panics, il-memorja tista 'terġa' tintuża.
//!
//! Il-memorja tista 'tkun "invalidated" permezz ta' deallocation, iżda wkoll billi tissostitwixxi [`Some(v)`] b [`None`], jew billi ċċempel lil [`Vec::set_len`] għal "kill" xi elementi barra minn vector.Jista 'jerġa' jiġi użat billi tuża [`ptr::write`] biex tissostitwixxih mingħajr ma ċċempel lid-distruttur l-ewwel.Xejn minn dan mhu permess għal dejta ippinjat mingħajr ma ċċempel lil [`drop`].
//!
//! Dan huwa eżattament it-tip ta 'garanzija li l-lista marbuta intrużiva mit-taqsima preċedenti teħtieġ li taħdem sew.
//!
//! Innota li din il-garanzija *ma* tfissirx li l-memorja ma tnixxix!Għadu kompletament tajjeb li qatt ma ċċempel lil [`drop`] fuq element ippinjat (eż., Xorta tista 'ċċempel lil [`mem::forget`] fuq [`Pin`]`<`[`Kaxxa`] `<T>>").Fl-eżempju tal-lista marbuta darbtejn, dak l-element jibqa 'biss fil-lista.Madankollu ma tistax teħles jew tuża mill-ġdid il-ħażna *mingħajr ma ċċempel [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Jekk it-tip tiegħek juża pinning (bħaż-żewġ eżempji ta 'hawn fuq), għandek toqgħod attent meta timplimenta [`Drop`].Il-funzjoni [`drop`] tieħu `&mut self`, iżda din tissejjaħ *anke jekk it-tip tiegħek kien ippinjat qabel*!Huwa bħallikieku l-kompilatur jissejjaħ awtomatikament [`Pin::get_unchecked_mut`].
//!
//! Dan qatt ma jista 'jikkawża problema f'kodiċi sikur għax l-implimentazzjoni ta' tip li jiddependi fuq l-ippinjar teħtieġ kodiċi mhux sigur, imma kun af li tiddeċiedi li tagħmel użu mill-pinning fit-tip tiegħek (per eżempju billi timplimenta xi operazzjoni fuq [`Pin`]`<&Self>`jew [`Pin`] `<&mut Self>`) għandu konsegwenzi għall-implimentazzjoni ta [`Drop`] tiegħek ukoll: jekk element tat-tip tiegħek seta' jkun ippinjat, trid tittratta lil [`Drop`] bħala impliċitament li tieħu [`Pin`]`<&mut Awto>`.
//!
//!
//! Pereżempju, tista 'timplimenta `Drop` kif ġej:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` huwa tajjeb għax nafu li dan il-valur qatt ma jerġa 'jintuża wara li twaqqa'.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Il-kodiċi tal-waqgħa attwali imur hawn.
//!         }
//!     }
//! }
//! ```
//!
//! Il-funzjoni `inner_drop` għandha t-tip li [`drop`]*għandu* jkollu, allura dan jiżgura li ma tużax aċċidentalment `self`/`this` b'mod li jkun f'kunflitt mal-pinning.
//!
//! Barra minn hekk, jekk it-tip tiegħek huwa `#[repr(packed)]`, il-kompilatur awtomatikament iċċaqlaq l-oqsma biex ikun jista 'jwaqqa'.Jista 'anke jagħmel dan għal oqsma li jinzertaw allinjati biżżejjed.Bħala konsegwenza, ma tistax tuża pinning b'tip `#[repr(packed)]`.
//!
//! # Projezzjonijiet u Pinning Strutturali
//!
//! Meta taħdem bi strutts ippinjati, tqum il-mistoqsija kif wieħed jista 'jaċċessa l-oqsma ta' dik struct f'metodu li jieħu biss [`Pin`]`<&mut Struct>`.
//! L-approċċ tas-soltu huwa li tikteb metodi helper (l-hekk imsejħa *projezzjonijiet*) li jibdlu [`Pin`]`<&mut Struct>`f'referenza għall-qasam, imma x'tip għandu jkollha dik ir-referenza?Huwa [`Pin`]`<&mut Field>`jew `&mut Field`?
//! L-istess mistoqsija tqum bl-oqsma ta `enum`, u wkoll meta tikkunsidra tipi container/wrapper bħal [`Vec<T>`], [`Box<T>`], jew [`RefCell<T>`].
//! (Din il-mistoqsija tapplika kemm għal referenzi li jistgħu jinbidlu kif ukoll għal referenzi komuni, aħna nużaw biss il-każ l-aktar komuni ta 'referenzi li jistgħu jinbidlu hawnhekk bħala illustrazzjoni.)
//!
//! Jirriżulta li fil-fatt huwa f'idejn l-awtur tal-istruttura tad-dejta li jiddeċiedi jekk il-projezzjoni pinned għal qasam partikolari tibdilx [`Pin`]`<&mut Struct>`fi [`Pin`] `<&mut Field>` jew `&mut Field`.Madankollu hemm xi restrizzjonijiet, u l-iktar restrizzjoni importanti hija l-konsistenza *:
//! kull qasam jista 'jkun *jew* proġettat għal referenza ippinjat,*jew* jitneħħa l-pinning bħala parti mill-projezzjoni.
//! Jekk it-tnejn isiru għall-istess qasam, x'aktarx ma jkunx tajjeb!
//!
//! Bħala l-awtur ta 'struttura tad-dejta int tiddeċiedi għal kull qasam jekk tippingax "propagates" ma' dan il-qasam jew le.
//! Pinning li jinfirex jissejjaħ ukoll "structural", minħabba li jsegwi l-istruttura tat-tip.
//! Fis-subtaqsimiet li ġejjin, niddeskrivu l-kunsiderazzjonijiet li għandhom isiru għaż-żewġ għażliet.
//!
//! ## Pinning *mhuwiex* strutturali għal `field`
//!
//! Jista 'jidher kontro-intuwittiv li l-qasam ta' strutt ippinjat jista 'ma jkunx ippinjat, imma dik hija attwalment l-eħfef għażla: jekk ["Pin"] "<&mut Field>` qatt ma jinħoloq, xejn ma jista' jmur ħażin!Allura, jekk tiddeċiedi li xi qasam m'għandux pinning strutturali, kull ma għandek tiżgura huwa li qatt ma toħloq referenza pinned għal dak il-field.
//!
//! Oqsma mingħajr pinning strutturali jista 'jkollhom metodu ta' projezzjoni li jdawwar ['Pin'] `<&mut Struct>` f `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dan huwa tajjeb għax `field` qatt ma huwa kkunsidrat ippinjat.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Tista 'wkoll `impl Unpin for Struct`*anke jekk* it-tip ta' `field` mhuwiex [`Unpin`].Dak li jaħseb dak it-tip dwar il-pinning mhuwiex rilevanti meta qatt ma jinħoloq l-ebda [`Pin`]`<&mut Field>`.
//!
//! ## Pinning *huwa* strutturali għal `field`
//!
//! L-għażla l-oħra hija li tiddeċiedi li l-pinning huwa "structural" għal `field`, li jfisser li jekk l-istruttura hija mwaħħla allura l-qasam huwa wkoll.
//!
//! Dan jippermetti li tikteb projezzjoni li toħloq [`Pin`]`<&Mut Field>`, u b'hekk naraw li l-field huwa pinned:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dan huwa tajjeb għax `field` huwa mwaħħal meta `self` huwa.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Madankollu, il-pinning strutturali jiġi ma 'ftit rekwiżiti żejda:
//!
//! 1. L-istruttura għandha tkun [`Unpin`] biss jekk l-oqsma strutturali kollha huma [`Unpin`].Dan huwa l-inadempjenza, iżda [`Unpin`] huwa trait sikur, għalhekk bħala l-awtur tal-istruttura hija r-responsabbiltà tiegħek *mhux* li żżid xi ħaġa bħal `impl<T> Unpin for Struct<T>`.
//! (Innota li ż-żieda ta 'operazzjoni ta' projezzjoni tirrikjedi kodiċi mhux sikur, allura l-fatt li [`Unpin`] huwa trait sikur ma jiksirx il-prinċipju li għandek tinkwieta biss dwar kwalunkwe minn dan jekk tuża 'mhux sikur'.)
//! 2. Id-distruttur tal-istruttura m'għandux iċċaqlaq l-oqsma strutturali mill-argument tiegħu.Dan huwa l-punt eżatt li tqajjem fix-[previous section][drop-impl]: `drop` jieħu `&mut self`, iżda l-istruttura (u għalhekk l-oqsma tagħha) setgħu ġew ippinjati qabel.
//!     Int trid tiggarantixxi li ma tiċċaqlaqx qasam fl-implimentazzjoni [`Drop`] tiegħek.
//!     B'mod partikolari, kif spjegat qabel, dan ifisser li l-istruttura tiegħek m'għandhiex *tkun*`#[repr(packed)]`.
//!     Ara dik it-taqsima għal kif tikteb [`drop`] b'tali mod li l-kompilatur jista 'jgħinek ma tiksirx aċċidentalment il-pinning.
//! 3. Int trid tkun ċert li tiddefendi x-[`Drop` guarantee][drop-guarantee]:
//!     ladarba l-istruttura tiegħek tkun imwaħħla, il-memorja li fiha l-kontenut ma tinkitebx mill-ġdid jew titqassam mingħajr ma ssejjaħ lid-distrutturi tal-kontenut.
//!     Dan jista 'jkun diffiċli, kif jixhed [`VecDeque<T>`]: id-distruttur ta' [`VecDeque<T>`] jista 'jonqos milli jsejjaħ lil [`drop`] fuq l-elementi kollha jekk wieħed mid-distrutturi panics.Dan jikser il-garanzija [`Drop`], minħabba li jista 'jwassal għal elementi li jiġu allokati mill-ġdid mingħajr ma jissejjaħ id-distruttur tagħhom.([`VecDeque<T>`] m'għandux projezzjonijiet ta 'pinning, allura dan ma jikkawżax nuqqas ta' ħoss.)
//! 4. M'għandekx toffri operazzjonijiet oħra li jistgħu jwasslu biex id-dejta titmexxa barra mill-oqsma strutturali meta t-tip tiegħek ikun ippinjat.Pereżempju, jekk l-istruttura fiha [`Option<T>`] u hemm operazzjoni simili għal "take" bit-tip `fn(Pin<&mut Struct<T>>) -> Option<T>`, dik l-operazzjoni tista 'tintuża biex iċċaqlaq `T` minn `Struct<T>` ippinjat-li jfisser li l-pinning ma jistax ikun strutturali għall-għalqa li żżomm din dejta.
//!
//!     Għal eżempju aktar kumpless ta 'ċaqliq ta' dejta minn tip ippinjat, immaġina jekk [`RefCell<T>`] kellux metodu `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Imbagħad nistgħu nagħmlu dan li ġej:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dan huwa katastrofiku, dan ifisser li l-ewwel nistgħu niskopru l-kontenut tax-[`RefCell<T>`] (billi nużaw `RefCell::get_pin_mut`) u mbagħad nimxu dak il-kontenut billi nużaw ir-referenza li tista 'tinbidel li ksibna aktar tard.
//!
//! ## Examples
//!
//! Għal tip bħal [`Vec<T>`], iż-żewġ possibbiltajiet (pinning strutturali jew le) jagħmlu sens.
//! [`Vec<T>`] b'qafla strutturali jista 'jkollu metodi `get_pin`/`get_pin_mut` biex jikseb referenzi pinned għal elementi.Madankollu, jista '*ma* jippermettix li ssejjaħ [`pop`][Vec::pop] fuq [`Vec<T>`] ippinjat għax dak iċċaqlaq il-kontenut (strutturalment ippinjat)!Lanqas ma jista 'jippermetti [`push`][Vec::push], li jista' jalloka mill-ġdid u b'hekk iċċaqlaq ukoll il-kontenut.
//!
//! [`Vec<T>`] mingħajr pinning strutturali jista `impl<T> Unpin for Vec<T>`, għax il-kontenut qatt ma jkun ippinjat u x-[`Vec<T>`] innifsu huwa tajjeb li jiġi mċaqlaq ukoll.
//! F'dak il-punt il-pinning m'għandu l-ebda effett fuq iż-vector.
//!
//! Fil-librerija standard, it-tipi ta 'pointer ġeneralment m'għandhomx pinning strutturali, u għalhekk ma joffrux projezzjonijiet ta' pinning.Dan hu għaliex `Box<T>: Unpin` għandu għal `T` kollu.
//! Jagħmel sens li tagħmel dan għal tipi ta 'pointer, għax iċ-ċaqliq ta' `Box<T>` ma jiċċaqlaqx fil-fatt ix-`T`: ix-[`Box<T>`] jista 'jkun mobbli liberament (magħruf ukoll bħala `Unpin`) anke jekk ix-`T` mhuwiex.Fil-fatt, anke [`Pin`]`<`[`Kaxxa`] `<T>>`u [`Pin`] `<&mut T>` huma dejjem [`Unpin`] infushom, għall-istess raġuni: il-kontenuti tagħhom (ix-`T`) huma mdaħħla, iżda l-indikaturi nfushom jistgħu jiġu mċaqalqa mingħajr ma jċaqalqu d-dejta mwaħħla.
//! Kemm għal [`Box<T>`] kif ukoll [`Pin`]`<`[`Box`] `<T>>", jekk il-kontenut huwiex ippinjat huwa kompletament indipendenti minn jekk il-pointer huwiex ippinjat, li jfisser li l-pinning mhuwiex * strutturali.
//!
//! Meta timplimenta kombinatur [`Future`], ġeneralment ikollok bżonn pinning strutturali għaż-futures imbejta, peress li għandek bżonn tikseb referenzi pinned għalihom biex issejjaħ [`poll`].
//! Imma jekk il-kombinatur tiegħek fih xi dejta oħra li m'għandhiex għalfejn tkun ippinjat, tista 'tagħmel dawk l-oqsma mhux strutturali u għalhekk ikollok aċċess liberu għalihom b'referenza li tista' tinbidel anke meta jkollok biss [`Pin`]`<&mut Self>`(bħal bħal fl-implimentazzjoni [`poll`] tiegħek stess).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Pointer ippinjat.
///
/// Dan huwa tgeżwir madwar tip ta 'pointer li jagħmel dak il-pointer "pin" il-valur tiegħu f'postu, u jipprevjeni li l-valur referenzjat minn dak il-pointer jiġi mċaqlaq sakemm ma jimplimentax [`Unpin`].
///
///
/// *Ara d-dokumentazzjoni [`pin` module] għal spjegazzjoni tal-pinning.*
///
/// [`pin` module]: self
///
// Note: ix-`Clone` joħroġ hawn taħt jikkawża nuqqas ta 'saħħa peress li huwa possibbli li tiġi implimentata
// `Clone` għal referenzi li jistgħu jinbidlu.
// Ara <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> għal aktar dettalji.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// L-implimentazzjonijiet li ġejjin mhumiex derivati sabiex jiġu evitati kwistjonijiet ta 'solidità.
// `&self.pointer` m'għandux ikun aċċessibbli għal implimentazzjonijiet trait mhux ta 'fiduċja.
//
// Ara <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> għal aktar dettalji.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Ibni `Pin<P>` ġdid madwar pointer għal xi dejta ta 'tip li timplimenta [`Unpin`].
    ///
    /// B'differenza minn `Pin::new_unchecked`, dan il-metodu huwa sigur minħabba li l-pointer `P` jirreferenzja għal tip [`Unpin`], li jħassar il-garanziji tal-pinning.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SIGURTÀ: il-valur indikat huwa `Unpin`, u għalhekk m'għandux ħtiġijiet
        // madwar pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Ħoll dan ix-`Pin<P>` jirritorna l-pointer sottostanti.
    ///
    /// Dan jirrikjedi li d-dejta ġewwa dan ix-`Pin` tkun [`Unpin`] sabiex inkunu nistgħu ninjoraw l-invarjanti tal-pinning meta nħalluha.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Ibni `Pin<P>` ġdid madwar referenza għal xi dejta ta 'tip li tista' timplimenta `Unpin` jew le.
    ///
    /// Jekk `pointer` tiddeferenzja għal tip `Unpin`, minflok għandu jintuża `Pin::new`.
    ///
    /// # Safety
    ///
    /// Dan il-kostruttur mhuwiex sikur għax ma nistgħux niggarantixxu li d-dejta indikata minn `pointer` tkun ippinjat, li jfisser li d-dejta ma tiċċaqlaqx jew il-ħażna tagħha tiġi invalidata sakemm titwaqqa '.
    /// Jekk ix-`Pin<P>` mibni ma jiggarantixxix li d-dejta li tindika `P` hija pinnjata, dak huwa ksur tal-kuntratt API u jista 'jwassal għal imġieba mhux definita f'operazzjonijiet (safe) aktar tard.
    ///
    /// Billi tuża dan il-metodu, qed tagħmel promise dwar l-implimentazzjonijiet `P::Deref` u `P::DerefMut`, jekk jeżistu.
    /// L-iktar importanti, m'għandhomx joħorġu mill-argumenti `self` tagħhom: `Pin::as_mut` u `Pin::as_ref` se jsejħu `DerefMut::deref_mut` u `Deref::deref`*fuq il-pointer ippinjat* u jistennew li dawn il-metodi jħarsu l-invariants tal-pinning.
    /// Barra minn hekk, billi ċċempel dan il-metodu tagħmel promise li d-dereferenzi ta 'referenza `P` ma jerġgħux jitneħħew barra;b'mod partikolari, m'għandux ikun possibbli li tinkiseb `&mut P::Target` u mbagħad titlaq minn dik ir-referenza (billi tuża, per eżempju [`mem::swap`]).
    ///
    ///
    /// Pereżempju, li ssejjaħ `Pin::new_unchecked` fuq `&'a mut T` mhuwiex sikur għax waqt li tkun kapaċi tpoġġiha għall-ħajja mogħtija `'a`, m'għandek l-ebda kontroll fuq jekk tinżammx ippinjat ladarba `'a` jintemm:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dan għandu jfisser li l-pointee `a` qatt ma jista 'jerġa' jiċċaqlaq.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // L-indirizz ta `a` inbidel għall-islott tal-munzell ta' 'b', allura `a` ġie mċaqlaq għalkemm aħna qabel ippinnawh!Aħna ksurna l-kuntratt tal-pinning API.
    /////
    /// }
    /// ```
    ///
    /// Valur, ladarba jkun ippinjat, għandu jibqa 'ippinjat għal dejjem (sakemm it-tip tiegħu ma jimplimentax `Unpin`).
    ///
    /// Bl-istess mod, li ssejjaħ `Pin::new_unchecked` fuq `Rc<T>` mhuwiex sigur minħabba li jista 'jkun hemm psewdonimi għall-istess dejta li mhumiex soġġetti għar-restrizzjonijiet tal-pinning:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dan għandu jfisser li l-pointee qatt ma jista 'jerġa' jiċċaqlaq.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Issa, jekk `x` kienet l-unika referenza, għandna referenza li tista 'tinbidel għad-dejta li ħejna hawn fuq, li nistgħu nużaw biex nimxuha kif rajna fl-eżempju ta' qabel.
    ///     // Aħna ksurna l-kuntratt tal-pinning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Tikseb referenza kondiviża pinned minn dan il-pointer ippinjat.
    ///
    /// Dan huwa metodu ġeneriku biex tmur minn `&Pin<Pointer<T>>` għal `Pin<&T>`.
    /// Huwa sigur għax, bħala parti mill-kuntratt ta `Pin::new_unchecked`, il-pointee ma jistax jiċċaqlaq wara li jkun inħoloq `Pin<Pointer<T>>`.
    ///
    /// "Malicious" l-implimentazzjonijiet ta `Pointer::Deref` huma bl-istess mod esklużi mill-kuntratt ta' `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SIGURTÀ: ara d-dokumentazzjoni dwar din il-funzjoni
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Ħoll dan ix-`Pin<P>` jirritorna l-pointer sottostanti.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura.Int trid tiggarantixxi li inti tkompli tittratta l-pointer `P` kif ippinjat wara li ċċempel din il-funzjoni, sabiex l-invariants fuq it-tip `Pin` ikunu jistgħu jintlaqgħu.
    /// Jekk il-kodiċi li juża l-`P` li jirriżulta ma jkomplix iżomm l-invariants tal-pinning dak huwa ksur tal-kuntratt API u jista 'jwassal għal imġieba mhux definita f'operazzjonijiet (safe) aktar tard.
    ///
    ///
    /// Jekk id-dejta sottostanti hija [`Unpin`], minflok għandu jintuża [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Tikseb referenza mutabbli pinned minn dan il-pointer ippinjat.
    ///
    /// Dan huwa metodu ġeneriku biex tmur minn `&mut Pin<Pointer<T>>` għal `Pin<&mut T>`.
    /// Huwa sigur għax, bħala parti mill-kuntratt ta `Pin::new_unchecked`, il-pointee ma jistax jiċċaqlaq wara li jkun inħoloq `Pin<Pointer<T>>`.
    ///
    /// "Malicious" l-implimentazzjonijiet ta `Pointer::DerefMut` huma bl-istess mod esklużi mill-kuntratt ta' `Pin::new_unchecked`.
    ///
    /// Dan il-metodu huwa utli meta tagħmel sejħiet multipli għal funzjonijiet li jikkunsmaw it-tip ippinjat.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // agħmel xi ħaġa
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` tikkonsma `self`, allura terġa 'tieħu l-`Pin<&mut Self>` permezz ta' `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SIGURTÀ: ara d-dokumentazzjoni dwar din il-funzjoni
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Jassenja valur ġdid lill-memorja wara r-referenza mwaħħla.
    ///
    /// Dan jissostitwixxi d-dejta mwaħħla, iżda din hija tajba: id-distruttur tiegħu jitmexxa qabel ma jinkiteb fuqha, u għalhekk ma tinkiser l-ebda garanzija ta 'pinning.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Jibni pin ġdid billi jimmappja l-valur intern.
    ///
    /// Pereżempju, jekk int xtaqt tikseb `Pin` ta 'qasam ta' xi ħaġa, tista 'tuża dan biex tikseb aċċess għal dak il-qasam f'linja waħda ta' kodiċi.
    /// Madankollu, hemm diversi gotchas ma 'dawn ix-"pinning projections";
    /// ara d-dokumentazzjoni [`pin` module] għal aktar dettalji dwar dak is-suġġett.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura.
    /// Int trid tiggarantixxi li d-dejta li tirritorna ma tiċċaqlaqx sakemm il-valur tal-argument ma jiċċaqlaqx (pereżempju, għax huwa wieħed mill-oqsma ta 'dak il-valur), u wkoll li ma toħroġx mill-argument li tirċievi biex il-funzjoni interna.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SIGURTÀ: il-kuntratt ta 'sigurtà għal `new_unchecked` għandu jkun
        // milqugħ minn min iċempel.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Iġib referenza kondiviża minn pin.
    ///
    /// Dan huwa sigur għax mhuwiex possibbli li toħroġ minn referenza kondiviża.
    /// Jista 'jidher li hawn kwistjoni hawnhekk dwar il-mutabilità interna: fil-fatt,*huwa* possibbli li tmexxi `T` minn `&RefCell<T>`.
    /// Madankollu, din mhix problema sakemm ma teżistix ukoll `Pin<&T>` li tipponta lejn l-istess dejta, u `RefCell<T>` ma jħallikx toħloq referenza pinned għall-kontenut tagħha.
    ///
    /// Ara d-diskussjoni fuq ["pinning projections"] għal aktar dettalji.
    ///
    /// Note: `Pin` jimplimenta wkoll `Deref` għall-mira, li tista 'tintuża biex taċċessa l-valur intern.
    /// Madankollu, `Deref` jipprovdi biss referenza li tgħix sakemm tissellef ix-`Pin`, mhux il-ħajja tax-`Pin` innifisha.
    /// Dan il-metodu jippermetti li ddawwar ix-`Pin` f'referenza bl-istess ħajja bħall-`Pin` oriġinali.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ikkonverti dan ix-`Pin<&mut T>` f `Pin<&T>` bl-istess ħajja.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Tikseb referenza li tista 'tinbidel għad-dejta ġewwa dan ix-`Pin`.
    ///
    /// Dan jirrikjedi li d-dejta ġewwa dan ix-`Pin` hija `Unpin`.
    ///
    /// Note: `Pin` jimplimenta wkoll `DerefMut` għad-dejta, li tista 'tintuża biex taċċessa l-valur intern.
    /// Madankollu, `DerefMut` jipprovdi biss referenza li tgħix sakemm tissellef ix-`Pin`, mhux il-ħajja tax-`Pin` innifisha.
    ///
    /// Dan il-metodu jippermetti li ddawwar ix-`Pin` f'referenza bl-istess ħajja bħall-`Pin` oriġinali.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Tikseb referenza li tista 'tinbidel għad-dejta ġewwa dan ix-`Pin`.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura.
    /// Int trid tiggarantixxi li qatt m'int se toħroġ id-dejta mir-referenza li tista 'tinbidel li tirċievi meta ssejjaħ din il-funzjoni, sabiex l-invariants fuq it-tip `Pin` ikunu jistgħu jintlaqgħu.
    ///
    ///
    /// Jekk id-dejta sottostanti hija `Unpin`, minflok għandu jintuża `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Ibni pin ġdid billi timmarka l-valur intern.
    ///
    /// Pereżempju, jekk int xtaqt tikseb `Pin` ta 'qasam ta' xi ħaġa, tista 'tuża dan biex tikseb aċċess għal dak il-qasam f'linja waħda ta' kodiċi.
    /// Madankollu, hemm diversi gotchas ma 'dawn ix-"pinning projections";
    /// ara d-dokumentazzjoni [`pin` module] għal aktar dettalji dwar dak is-suġġett.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura.
    /// Int trid tiggarantixxi li d-dejta li tirritorna ma tiċċaqlaqx sakemm il-valur tal-argument ma jiċċaqlaqx (pereżempju, għax huwa wieħed mill-oqsma ta 'dak il-valur), u wkoll li ma toħroġx mill-argument li tirċievi biex il-funzjoni interna.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SIGURTÀ: min iċempel huwa responsabbli biex ma jiċċaqlaqx
        // valur minn din ir-referenza.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SIGURTÀ: billi l-valur ta `this` huwa garantit li ma għandux
        // ġiet imċaqilqa, din is-sejħa għal `new_unchecked` hija sigura.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Ikseb referenza ippinjat minn referenza statika.
    ///
    /// Dan huwa sigur, għax `T` huwa misluf għall-ħajja ta `'static`, li ma tispiċċa qatt.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SIGURTÀ: Is-self statiku jiggarantixxi li d-dejta ma tkunx
        // moved/invalidated sakemm jinżel (li qatt mhu).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Ikseb referenza li tista 'tinbidel ippinjat minn referenza statika li tista' tinbidel.
    ///
    /// Dan huwa sigur, għax `T` huwa misluf għall-ħajja ta `'static`, li ma tispiċċa qatt.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SIGURTÀ: Is-self statiku jiggarantixxi li d-dejta ma tkunx
        // moved/invalidated sakemm jinżel (li qatt mhu).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: dan ifisser li kull impl ta `CoerceUnsized` li jippermetti sfurzar minn
// tip li jimplika `Deref<Target=impl !Unpin>` għal tip li jimplika `Deref<Target=Unpin>` mhuwiex sod.
// Kwalunkwe impl bħal dan probabbilment ma jkunx tajjeb għal raġunijiet oħra, għalkemm, għalhekk għandna bżonn noqogħdu attenti biex ma nħallux tali impls jinżlu f'std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}