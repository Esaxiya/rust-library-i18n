#![stable(feature = "core_hint", since = "1.27.0")]

//! Ħjiel lill-kompilatur li jaffettwa kif il-kodiċi għandu jkun emess jew ottimizzat.
//! Ħjiel jista 'jkun ħin tal-kumpilazzjoni jew runtime.

use crate::intrinsics;

/// Jinforma lill-kompilatur li dan il-punt fil-kodiċi ma jistax jintlaħaq, u jippermetti aktar ottimizzazzjonijiet.
///
/// # Safety
///
/// Li tilħaq din il-funzjoni huwa kompletament *imġieba mhux definita*(UB).B'mod partikolari, il-kompilatur jassumi li l-UB kollha m'għandhom qatt iseħħu, u għalhekk se jelimina l-fergħat kollha li jilħqu sejħa lil `unreachable_unchecked()`.
///
/// Bħall-każijiet kollha ta `UB, jekk din is-suppożizzjoni tirriżulta ħażina, jiġifieri, is-sejħa `unreachable_unchecked()` hija fil-fatt aċċessibbli fost il-fluss ta` kontroll possibbli kollu, il-kompilatur japplika l-istrateġija ta `ottimizzazzjoni ħażina, u xi kultant jista` anke jikkorrompi kodiċi apparentement mhux relatat, u jikkawża biex tiddibaggja l-problemi.
///
///
/// Uża din il-funzjoni biss meta tkun tista 'tipprova li l-kodiċi qatt mhu se jsejjaħlu.
/// Inkella, ikkunsidra li tuża l-makro [`unreachable!`], li ma tippermettix ottimizzazzjonijiet iżda se panic meta tkun eżegwita.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` huwa dejjem pożittiv (mhux żero), għalhekk `checked_div` qatt ma jirritorna `None`.
/////
///     // Għalhekk, l-inkella branch ma tistax tintlaħaq.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SIGURTÀ: il-kuntratt ta 'sigurtà għal `intrinsics::unreachable` għandu
    // tkun milqugħa minn min iċempel.
    unsafe { intrinsics::unreachable() }
}

/// Tarmi struzzjoni fuq il-magna biex tindika lill-proċessur li qed jaħdem fi spin-loop busy-wait ("spin lock").
///
/// Malli jirċievi s-sinjal spin-loop il-proċessur jista 'jtejjeb l-imġieba tiegħu billi, pereżempju, jiffranka l-enerġija jew jaqleb il-ħjut hyper.
///
/// Din il-funzjoni hija differenti minn [`thread::yield_now`] li tirrendi direttament għall-iskedar tas-sistema, filwaqt li `spin_loop` ma jinteraġixxix mas-sistema operattiva.
///
/// Każ ta 'użu komuni għal `spin_loop` qed jimplimenta għażil ottimist imdawwar f'linja CAS f'primittivi ta' sinkronizzazzjoni.
/// Biex jiġu evitati problemi bħall-inverżjoni tal-prijorità, huwa rrakkomandat bil-qawwa li l-ispin loop jintemm wara ammont finit ta 'iterazzjonijiet u ssir syscall ta' mblukkar xieraq.
///
///
/// **Nota**: Fuq pjattaformi li ma jappoġġjawx ir-riċeviment ta 'spin-loop ideat din il-funzjoni ma tagħmel xejn.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Valur atomiku kondiviż li l-ħjut se jużaw biex jikkoordinaw
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Fi thread ta 'sfond aħna eventwalment nissettjaw il-valur
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Agħmel ftit xogħol, imbagħad agħmel il-valur ħaj
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Lura fuq il-ħajt attwali tagħna, nistennew li jiġi stabbilit il-valur
/// while !live.load(Ordering::Acquire) {
///     // L-ispin loop huwa ħjiel għas-CPU li qed nistennew, imma probabbilment mhux għal żmien twil ħafna
/////
///     hint::spin_loop();
/// }
///
/// // Il-valur issa huwa stabbilit
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SIGURTÀ: l-attr `cfg` jiżgura li aħna nagħmlu dan biss fuq miri x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SIGURTÀ: l-attr `cfg` jiżgura li aħna nagħmlu dan biss fuq miri x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SIGURTÀ: l-attr `cfg` jiżgura li aħna nagħmlu dan biss fuq miri aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SIGURTÀ: ix-`cfg` attr jiżgura li aħna nagħmlu dan biss fuq il-miri tad-driegħ
            // b'appoġġ għall-karatteristika v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Funzjoni ta 'identità li *__ tagħti ħjiel __* lill-kompilatur biex tkun massimament pessimista dwar dak li `black_box` jista' jagħmel.
///
/// B'differenza għal [`std::convert::identity`], kompilatur Rust huwa mħeġġeġ jassumi li `black_box` jista 'juża `dummy` fi kwalunkwe mod validu possibbli li l-kodiċi Rust huwa permess mingħajr ma tintroduċi imġieba mhux definita fil-kodiċi li jsejjaħ.
///
/// Din il-proprjetà tagħmel `black_box` utli għall-kitba ta 'kodiċi li fih mhumiex mixtieqa ċerti ottimizzazzjonijiet, bħal punti ta' riferiment.
///
/// Innota madankollu, li `black_box` huwa pprovdut biss (u jista 'jkun biss) fuq bażi "best-effort".Il-punt sa fejn jista 'jimblokka l-ottimizzazzjonijiet jista' jvarja skont il-pjattaforma u l-backend tal-code-gen użati.
/// Il-programmi ma jistgħux jiddependu fuq `black_box` għal *korrettezza* bl-ebda mod.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Għandna bżonn "use" l-argument b'xi mod LLVM ma jistax jintroduċi, u fuq miri li jsostnuh nistgħu tipikament nisfruttaw assemblaġġ inline biex nagħmlu dan.
    // L-interpretazzjoni ta 'LLVM ta' assemblaġġ inline hija li hija, ukoll, kaxxa sewda.
    // Din mhijiex l-ikbar implimentazzjoni peress li probabbilment tiddioptimizza aktar milli rridu, imma s'issa hija tajba biżżejjed.
    //
    //

    #[cfg(not(miri))] // Dan huwa biss ħjiel, allura huwa tajjeb li taqbeż f'Miri.
    // SIGURTÀ: l-assemblaġġ inline huwa no-op.
    unsafe {
        // FIXME: Ma tistax tuża `asm!` għax ma tappoġġjax MIPS u arkitetturi oħra.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}