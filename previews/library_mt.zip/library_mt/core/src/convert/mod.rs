//! Traits għal konverżjonijiet bejn tipi.
//!
//! Iż-traits f'dan il-modulu jipprovdu mod biex tikkonverti minn tip wieħed għal tip ieħor.
//! Kull trait iservi skop differenti:
//!
//! - Implimenta l-[`AsRef`] trait għal konverżjonijiet irħas ta 'referenza għal referenza
//! - Implimenta [`AsMut`] trait għal konverżjonijiet irħas li jistgħu jinbidlu għal oħra
//! - Implimenta l-[`From`] trait biex tikkonsma konverżjonijiet ta 'valur għal valur
//! - Implimenta [`Into`] trait biex tikkonsma konverżjonijiet ta 'valur għal valur għal tipi barra ż-crate kurrenti
//! - Ix-[`TryFrom`] u [`TryInto`] traits iġibu ruħhom bħal [`From`] u [`Into`], iżda għandhom jiġu implimentati meta l-konverżjoni tista 'tfalli.
//!
//! Iż-traits f'dan il-modulu spiss jintużaw bħala trait bounds għal funzjonijiet ġeneriċi tali li għal argumenti ta 'tipi multipli huma appoġġjati.Ara d-dokumentazzjoni ta 'kull trait għal eżempji.
//!
//! Bħala awtur tal-librerija, għandek dejjem tippreferi timplimenta [`From<T>`][`From`] jew [`TryFrom<T>`][`TryFrom`] minflok [`Into<U>`][`Into`] jew [`TryInto<U>`][`TryInto`], billi [`From`] u [`TryFrom`] jipprovdu flessibilità akbar u joffru implimentazzjonijiet ekwivalenti ta [`Into`] jew [`TryInto`] b`xejn, grazzi għal implimentazzjoni kutra fil-librerija standard.
//! Meta tkun immirata verżjoni qabel Rust 1.41, jista 'jkun meħtieġ li timplimenta [`Into`] jew [`TryInto`] direttament meta taqleb għal tip barra ż-crate kurrenti.
//!
//! # Implimentazzjonijiet Ġeneriċi
//!
//! - [`AsRef`] u [`AsMut`] awtoreferenza jekk it-tip ta 'ġewwa huwa referenza
//! - ["Minn"] "<U>għal T" timplika [`Ġo ']"</u><T><U>għal U`</u>
//! - [`TryFrom`]`<U>għal T` jimplika [`TryInto`]`</u><T><U>għal U`</u>
//! - [`From`] u [`Into`] huma riflessivi, li jfisser li t-tipi kollha jistgħu `into` infushom u `from` infushom
//!
//! Ara kull trait għal eżempji ta 'użu.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Il-funzjoni tal-identità.
///
/// Żewġ affarijiet huma importanti li wieħed jinnota dwar din il-funzjoni:
///
/// - Mhux dejjem ekwivalenti għal għeluq bħal `|x| x`, peress li l-għeluq jista 'jġiegħel lil `x` f'tip differenti.
///
/// - Huwa jċaqlaq id-dħul `x` mgħoddi għall-funzjoni.
///
/// Filwaqt li jista 'jidher stramb li jkollok funzjoni li tirritorna biss l-input lura, hemm xi użi interessanti.
///
///
/// # Examples
///
/// L-użu ta `identity` biex ma tagħmel xejn f'sekwenza ta' funzjonijiet oħra interessanti:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ejja nippretendu li ż-żieda ta 'waħda hija funzjoni interessanti.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// L-użu ta `identity` bħala każ bażi "do nothing" f'kondizzjoni:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Agħmel aktar affarijiet interessanti ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Uża `identity` biex iżżomm il-varjanti `Some` ta 'iteratur ta' `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Użat biex tagħmel konverżjoni rħisa minn referenza għal referenza.
///
/// Dan trait huwa simili għal [`AsMut`] li jintuża għall-konverżjoni bejn referenzi li jistgħu jinbidlu.
/// Jekk għandek bżonn tagħmel konverżjoni għalja huwa aħjar li timplimenta [`From`] b'tip `&T` jew tikteb funzjoni tad-dwana.
///
/// `AsRef` għandu l-istess firma bħal [`Borrow`], iżda [`Borrow`] huwa differenti fi ftit aspetti:
///
/// - B'differenza minn `AsRef`, [`Borrow`] għandu blanket impl għal kwalunkwe `T`, u jista 'jintuża biex jaċċetta jew referenza jew valur.
/// - [`Borrow`] teħtieġ ukoll li [`Hash`], [`Eq`] u [`Ord`] għall-valur misluf huma ekwivalenti għal dawk tal-valur tal-proprjetà.
/// Għal din ir-raġuni, jekk trid tissellef qasam wieħed biss ta 'struttura tista' timplimenta `AsRef`, iżda mhux [`Borrow`].
///
/// **Note: Dan trait m'għandux ifalli **.Jekk il-konverżjoni tista 'tfalli, uża metodu dedikat li jirritorna [`Option<T>`] jew [`Result<T, E>`].
///
/// # Implimentazzjonijiet Ġeneriċi
///
/// - `AsRef` awtodereferenzi jekk it-tip ta 'ġewwa huwa referenza jew referenza li tista' tinbidel (eż: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Bl-użu ta 'trait bounds nistgħu naċċettaw argumenti ta' tipi differenti sakemm jistgħu jiġu kkonvertiti għat-tip speċifikat `T`.
///
/// Pereżempju: Billi noħolqu funzjoni ġenerika li tieħu `AsRef<str>` aħna nesprimu li rridu naċċettaw ir-referenzi kollha li jistgħu jiġu kkonvertiti għal [`&str`] bħala argument.
/// Peress li kemm [`String`] kif ukoll [`&str`] jimplimentaw `AsRef<str>` nistgħu naċċettaw it-tnejn bħala argument ta 'input.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Twettaq il-konverżjoni.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Użat biex issir konverżjoni rħisa ta 'referenza li tista' tinbidel għal oħra.
///
/// Dan trait huwa simili għal [`AsRef`] iżda jintuża għall-konverżjoni bejn referenzi li jistgħu jinbidlu.
/// Jekk għandek bżonn tagħmel konverżjoni għalja huwa aħjar li timplimenta [`From`] b'tip `&mut T` jew tikteb funzjoni tad-dwana.
///
/// **Note: Dan trait m'għandux ifalli **.Jekk il-konverżjoni tista 'tfalli, uża metodu dedikat li jirritorna [`Option<T>`] jew [`Result<T, E>`].
///
/// # Implimentazzjonijiet Ġeneriċi
///
/// - `AsMut` awto-dereferenzi jekk it-tip ta 'ġewwa huwa referenza li tista' tinbidel (eż: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Meta nużaw `AsMut` bħala trait bound għal funzjoni ġenerika nistgħu naċċettaw ir-referenzi kollha li jistgħu jinbidlu li jistgħu jiġu kkonvertiti għal tip `&mut T`.
/// Minħabba li [`Box<T>`] jimplimenta `AsMut<T>` nistgħu niktbu funzjoni `add_one` li tieħu l-argumenti kollha li jistgħu jiġu kkonvertiti għal `&mut u64`.
/// Minħabba li [`Box<T>`] jimplimenta `AsMut<T>`, `add_one` jaċċetta wkoll argumenti tat-tip `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Twettaq il-konverżjoni.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Konverżjoni tal-valur għall-valur li tikkonsma l-valur tal-input.L-oppost ta [`From`].
///
/// Wieħed għandu jevita li jimplimenta [`Into`] u jimplimenta minflok [`From`].
/// L-implimentazzjoni ta [`From`] tipprovdi awtomatikament waħda b'implimentazzjoni ta' [`Into`] grazzi għall-implimentazzjoni tal-kutra fil-librerija standard.
///
/// Ippreferi tuża [`Into`] fuq [`From`] meta tispeċifika trait bounds fuq funzjoni ġenerika biex tiżgura li tipi li jimplimentaw biss [`Into`] jistgħu jintużaw ukoll.
///
/// **Note: Dan trait m'għandux ifalli **.Jekk il-konverżjoni tista 'tfalli, uża [`TryInto`].
///
/// # Implimentazzjonijiet Ġeneriċi
///
/// - ['Minn'] `<T>għal U` jimplika `Into<U> for T`
/// - [`Into`] huwa riflessiv, li jfisser li `Into<T> for T` huwa implimentat
///
/// # Implimentazzjoni ta [`Into`] għal konverżjonijiet għal tipi esterni f'verżjonijiet qodma ta' Rust
///
/// Qabel Rust 1.41, jekk it-tip ta 'destinazzjoni ma kienx parti miż-crate kurrenti allura ma tkunx tista' timplimenta [`From`] direttament.
/// Pereżempju, ħu dan il-kodiċi:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Dan jonqos milli jikkompila f'verżjonijiet anzjani tal-lingwa minħabba li r-regoli orfni ta 'Rust kienu xi ftit iktar stretti.
/// Biex tevita dan, tista 'timplimenta [`Into`] direttament:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Huwa importanti li tifhem li [`Into`] ma jipprovdix implimentazzjoni [`From`] (bħal ma jagħmel [`From`] ma [`Into`]).
/// Għalhekk, għandek dejjem tipprova timplimenta [`From`] u mbagħad taqa 'lura għal [`Into`] jekk [`From`] ma jistax jiġi implimentat.
///
/// # Examples
///
/// [`String`] timplimenta [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Sabiex nesprimu li rridu funzjoni ġenerika tieħu l-argumenti kollha li jistgħu jiġu kkonvertiti għal tip speċifikat `T`, nistgħu nużaw trait bound ta '[`Into`]`<T>".
///
/// Pereżempju: Il-funzjoni `is_hello` tieħu l-argumenti kollha li jistgħu jiġu kkonvertiti f '[`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Twettaq il-konverżjoni.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Użat biex tagħmel konverżjonijiet tal-valur għall-valur waqt li tikkonsma l-valur tal-input.Huwa r-reċiproku ta [`Into`].
///
/// Wieħed għandu dejjem jippreferi jimplimenta `From` fuq [`Into`] għax l-implimentazzjoni ta `From` tipprovdi awtomatikament waħda b'implimentazzjoni ta' [`Into`] grazzi għall-implimentazzjoni kutra fil-librerija standard.
///
///
/// Implimenta [`Into`] biss meta timmira verżjoni qabel Rust 1.41 u tikkonverti għal tip barra ż-crate kurrenti.
/// `From` ma kienx kapaċi jagħmel dawn it-tipi ta 'konverżjonijiet f'verżjonijiet preċedenti minħabba r-regoli orfni ta' Rust.
/// Ara [`Into`] għal aktar dettalji.
///
/// Ippreferi tuża [`Into`] milli tuża `From` meta tispeċifika trait bounds fuq funzjoni ġenerika.
/// Dan il-mod, tipi li jimplimentaw direttament [`Into`] jistgħu jintużaw ukoll bħala argumenti.
///
/// Ix-`From` huwa wkoll utli ħafna meta jsir immaniġġjar tal-iżbalji.Meta tkun qed tinbena funzjoni li kapaċi tfalli, it-tip ta 'ritorn ġeneralment ikun tal-forma `Result<T, E>`.
/// Ix-`From` trait jissimplifika l-immaniġġjar tal-iżbalji billi jippermetti li funzjoni tirritorna tip ta 'żball wieħed li jiġbor fih tipi ta' żbalji multipli.Ara t-taqsima "Examples" u [the book][book] għal aktar dettalji.
///
/// **Note: Dan trait m'għandux ifalli **.Jekk il-konverżjoni tista 'tfalli, uża [`TryFrom`].
///
/// # Implimentazzjonijiet Ġeneriċi
///
/// - `From<T> for U` jimplika ["Ġo"] "<U>għal T"</u>
/// - `From` huwa riflessiv, li jfisser li `From<T> for T` huwa implimentat
///
/// # Examples
///
/// [`String`] timplimenta `From<&str>`:
///
/// Konverżjoni espliċita minn `&str` għal String issir kif ġej:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Waqt li twettaq l-immaniġġjar ta 'l-iżbalji ħafna drabi huwa utli li timplimenta `From` għat-tip ta' żball tiegħek stess.
/// Billi nikkonvertu t-tipi ta 'żball sottostanti għat-tip ta' żball personalizzat tagħna stess li jiġbor it-tip ta 'żball sottostanti, nistgħu nirritornaw tip ta' żball wieħed mingħajr ma nitilfu l-informazzjoni dwar il-kawża sottostanti.
/// L-operatur '?' awtomatikament jikkonverti t-tip ta 'żball sottostanti għat-tip ta' żball tad-dwana tagħna billi ċċempel lil `Into<CliError>::into` li huwa pprovdut awtomatikament meta jimplimenta `From`.
/// Il-kompilatur imbagħad jiddeduċi liema implimentazzjoni ta `Into` għandha tintuża.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Twettaq il-konverżjoni.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Tentattiv ta 'konverżjoni li jikkonsma `self`, li jista' jkun jew le.
///
/// L-awturi tal-librerija normalment m'għandhomx jimplimentaw direttament dan iż-trait, iżda għandhom jippreferu jimplimentaw ix-[`TryFrom`] trait, li joffri flessibilità akbar u jipprovdi implimentazzjoni ekwivalenti ta `TryInto` b'xejn, grazzi għal implimentazzjoni blanket fil-librerija standard.
/// Għal aktar informazzjoni dwar dan, ara d-dokumentazzjoni għal [`Into`].
///
/// # Implimentazzjoni ta `TryInto`
///
/// Dan ibati l-istess restrizzjonijiet u raġunament bħall-implimentazzjoni ta [`Into`], ara hemm għad-dettalji.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// It-tip irritorna fil-każ ta 'żball ta' konverżjoni.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Twettaq il-konverżjoni.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Konverżjonijiet tat-tip sempliċi u sikuri li jistgħu jfallu b'mod kontrollat taħt xi ċirkostanzi.Huwa r-reċiproku ta [`TryInto`].
///
/// Dan huwa utli meta tkun qed tagħmel konverżjoni tat-tip li tista 'tirnexxi b'mod trivjali iżda jista' jkollha bżonn ukoll trattament speċjali.
/// Pereżempju, m'hemm l-ebda mod biex tikkonverti [`i64`] f [`i32`] billi tuża [`From`] trait, għax [`i64`] jista 'jkun fih valur li [`i32`] ma jistax jirrappreżenta u allura l-konverżjoni titlef id-dejta.
///
/// Dan jista 'jiġi mmaniġġjat billi tinqata' l-[`i64`] għal [`i32`] (essenzjalment tagħti l-valur tal-modulu ta '[`i64`] [`i32::MAX`]) jew billi sempliċement tirritorna [`i32::MAX`], jew b'xi metodu ieħor.
/// Ix-[`From`] trait huwa maħsub għal konverżjonijiet perfetti, għalhekk ix-`TryFrom` trait jinforma lill-programmatur meta konverżjoni tat-tip tista 'tmur ħażin u tħallihom jiddeċiedu kif jimmaniġġjawha.
///
/// # Implimentazzjonijiet Ġeneriċi
///
/// - `TryFrom<T> for U` jimplika [`TryInto`]`<U>għal T`</u>
/// - [`try_from`] huwa riflessiv, li jfisser li `TryFrom<T> for T` huwa implimentat u ma jistax ifalli-it-tip `Error` assoċjat biex issejjaħ `T::try_from()` fuq valur tat-tip `T` huwa [`Infallible`].
/// Meta t-tip [`!`] ikun stabbilizzat [`Infallible`] u [`!`] ikunu ekwivalenti.
///
/// `TryFrom<T>` jistgħu jiġu implimentati kif ġej:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kif deskritt, [`i32`] jimplimenta `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Ittaqqab is-silenzju `big_number`, teħtieġ l-iskoperta u l-immaniġġjar tat-tronk wara l-fatt.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Jirritorna żball minħabba li `big_number` huwa kbir wisq biex joqgħod f `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Jirritorna `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// It-tip irritorna fil-każ ta 'żball ta' konverżjoni.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Twettaq il-konverżjoni.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS ĠENERIĊI
////////////////////////////////////////////////////////////////////////////////

// Bħala lifts over&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Bħala lifts fuq &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): ibdel l-impls ta 'hawn fuq għal&/&mut b'waħda aktar ġenerali li ġejja:
// // Bħala lifts fuq Deref
// jimplika <D: ?Sized + Deref<Target: AsRef<U>>, U:? Daqs> AsRef <U>għal D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut jerfa 'fuq &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): ibdel l-impl ta 'hawn fuq għal &mut b'dan li ġej aktar ġenerali:
// // AsMut jerfa 'fuq DerefMut
// jimplika <D: ?Sized + Deref<Target: AsMut<U>>, U:? Daqs> AsMut <U>għal D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Minn jimplika Ġo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Minn (u għalhekk Into) huwa riflessiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Nota ta 'Stabbiltà:** Dan l-impl għadu ma jeżistix, imma aħna "reserving space" biex inżiduh fiż-future.
/// Ara [rust-lang/rust#64715][#64715] għad-dettalji.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): minflok tagħmel soluzzjoni ta 'prinċipju.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom jimplika TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Konverżjonijiet infallibbli huma semantikament ekwivalenti għal konverżjonijiet fallibbli b'tip ta 'żball diżabitat.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// IMPLS KONKRETI
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// IT-TIP TA 'ŻBALL MINGĦAJR ERROR
////////////////////////////////////////////////////////////////////////////////

/// It-tip ta 'żball għal żbalji li qatt ma jistgħu jseħħu.
///
/// Peress li din l-enum m'għandhiex varjant, valur ta 'dan it-tip qatt ma jista' jeżisti fil-fatt.
/// Dan jista 'jkun utli għal APIs ġeneriċi li jużaw [`Result`] u parametrizzaw it-tip ta' żball, biex jindikaw li r-riżultat huwa dejjem [`Ok`].
///
/// Pereżempju, ix-[`TryFrom`] trait (konverżjoni li tirritorna [`Result`]) għandha implimentazzjoni blanket għat-tipi kollha fejn teżisti implimentazzjoni reverse [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Kompatibilità Future
///
/// Dan l-enum għandu l-istess rwol bħal [the `!`“never”type][never], li huwa instabbli f'din il-verżjoni ta 'Rust.
/// Meta `!` jiġi stabbilizzat, aħna nippjanaw li nagħmlu `Infallible` tip ta 'psewdonimu għalih:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... u eventwalment jiddekora `Infallible`.
///
/// Madankollu hemm każ wieħed fejn is-sintassi `!` tista 'tintuża qabel ma `!` tiġi stabbilizzata bħala tip sħiħ: fil-pożizzjoni tat-tip ta' ritorn ta 'funzjoni.
/// Speċifikament, huma implimentazzjonijiet possibbli għal żewġ tipi differenti ta 'pointer tal-funzjoni:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Billi `Infallible` huwa enum, dan il-kodiċi huwa validu.
/// Madankollu meta `Infallible` isir psewdonimu għaż-never type, iż-żewġ `impl`s jibdew jikkoinċidu u għalhekk ma jitħallewx bir-regoli ta 'koerenza trait tal-lingwa.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}