use crate::iter::FromIterator;

/// Tiġarraf l-oġġetti kollha tal-unità minn iteratur f'waħda.
///
/// Dan huwa aktar utli meta kkombinat ma 'estrazzjonijiet ta' livell ogħla, bħal ġbir għal `Result<(), E>` fejn jimpurtak biss mill-iżbalji:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}