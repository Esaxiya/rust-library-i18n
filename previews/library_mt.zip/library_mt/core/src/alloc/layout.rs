use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Filwaqt li din il-funzjoni tintuża f'post wieħed u l-implimentazzjoni tagħha tista 'tkun enfasizzata, l-attentati preċedenti biex jagħmlu dan għamlu rustc aktar bil-mod:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Tqassim ta 'blokka ta' memorja.
///
/// Eżempju ta `Layout` jiddeskrivi tqassim partikolari tal-memorja.
/// Tibni `Layout` bħala input biex tagħti lil allokatur.
///
/// It-taqsimiet kollha għandhom daqs assoċjat u allinjament ta 'qawwa ta' tnejn.
///
/// (Innota li t-taqsimiet *mhumiex* meħtieġa li jkollhom daqs mhux żero, anke jekk `GlobalAlloc` jeħtieġ li t-talbiet kollha tal-memorja jkunu ta 'daqs mhux żero.
/// Min iċempel għandu jew jiżgura li kundizzjonijiet bħal dawn jintlaħqu, juża allokaturi speċifiċi b'rekwiżiti laxki, jew juża l-interface `Allocator` aktar klementi.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // daqs tal-blokka tal-memorja mitluba, imkejla f'bytes.
    size_: usize,

    // allinjament tal-blokka tal-memorja mitluba, imkejla f'bytes.
    // aħna niżguraw li din hija dejjem qawwa ta 'tnejn, minħabba li API bħal `posix_memalign` jeħtieġuha u hija restrizzjoni raġonevoli li timponi fuq kostrutturi ta' Layout.
    //
    //
    // (Madankollu, aħna ma nirrikjedux b'mod analogu `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Jibni `Layout` minn `size` u `align` partikolari, jew jirritorna `LayoutError` jekk xi waħda mill-kundizzjonijiet li ġejjin ma tintlaħaqx:
    ///
    /// * `align` m'għandux ikun żero,
    ///
    /// * `align` għandu jkun qawwa ta 'tnejn,
    ///
    /// * `size`, meta mqarreb lejn l-eqreb multiplu ta `align`, m'għandux ifur (jiġifieri, il-valur arrotondat għandu jkun inqas minn jew ugwali għal `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (qawwa ta 'tnejn timplika allinjament!=0.)

        // Id-daqs aġġustat huwa:
        //   size_rounded_up=(daqs + allinja, 1)&! (allinja, 1);
        //
        // Nafu minn fuq dak l-allinjament!=0.
        // Jekk iż-żieda (allinjament, 1) ma tfurx, allura l-arrotondament 'il fuq ikun tajjeb.
        //
        // Bil-maqlub,&-masking with! (Align, 1) inaqqas biss il-bits ta 'ordni baxxa.
        // Għalhekk jekk is-overflow iseħħ bis-somma, il-maskra&ma tistax tnaqqas biżżejjed biex tneħħi dak il-overflow.
        //
        //
        // Hawn fuq jimplika li l-iċċekkjar għall-overflow summation huwa kemm meħtieġ u suffiċjenti.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SIGURTÀ: il-kundizzjonijiet għal `from_size_align_unchecked` kienu
        // iċċekkjat hawn fuq.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Toħloq tqassim, billi tevita l-kontrolli kollha.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura peress li ma tivverifikax il-prekundizzjonijiet minn [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SIGURTÀ: min iċempel għandu jiżgura li `align` huwa akbar minn żero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Id-daqs minimu f'bytes għal blokka tal-memorja ta 'dan it-tqassim.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// L-allinjament minimu tal-byte għal blokka tal-memorja ta 'dan it-tqassim.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Jibni `Layout` adattat biex iżomm valur ta 'tip `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SIGURTÀ: l-allinjament huwa garantit minn Rust li jkun qawwa ta 'tnejn u
        // il-kombo daqs + allinjament huwa garantit li joqgħod fl-ispazju tal-indirizzi tagħna.
        // Bħala riżultat uża l-kostruttur mhux ivverifikat hawn biex tevita li ddaħħal kodiċi li panics jekk ma jkunx ottimizzat tajjeb biżżejjed.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Jipproduċi tqassim li jiddeskrivi rekord li jista 'jintuża biex jalloka struttura ta' rinforz għal `T` (li jista 'jkun trait jew tip ieħor mhux daqs bħal porzjon).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIGURTÀ: ara r-raġunament f `new` għalfejn dan qed juża l-varjant mhux sikur
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Jipproduċi tqassim li jiddeskrivi rekord li jista 'jintuża biex jalloka struttura ta' rinforz għal `T` (li jista 'jkun trait jew tip ieħor mhux daqs bħal porzjon).
    ///
    /// # Safety
    ///
    /// Din il-funzjoni tista 'tissejjaħ mingħajr periklu biss jekk jgħoddu l-kundizzjonijiet li ġejjin:
    ///
    /// - Jekk `T` huwa `Sized`, din il-funzjoni hija dejjem sikura biex tissejjaħ.
    /// - Jekk id-denb mhux daqs ta `T` huwa:
    ///     - a [slice], allura t-tul tad-denb tal-porzjon għandu jkun numru sħiħ intializzat, u d-daqs tal-*valur sħiħ*(tul dinamiku tad-denb + prefiss ta 'daqs statiku) għandu joqgħod f `isize`.
    ///     - a [trait object], allura l-parti vtable tal-pointer għandha tipponta lejn vtable valida għat-tip `T` akkwistata minn koerżjoni mingħajr daqs, u d-daqs tal-*valur sħiħ*(tul dinamiku tad-denb + prefiss ta 'daqs statiku) għandu joqgħod f `isize`.
    ///
    ///     - (unstable) [extern type], allura din il-funzjoni hija dejjem sikura biex tissejjaħ, iżda tista 'panic jew inkella tirritorna l-valur ħażin, billi t-tqassim tat-tip estern mhuwiex magħruf.
    ///     Din hija l-istess imġieba bħal [`Layout::for_value`] fuq referenza għal denb tat-tip estern.
    ///     - inkella, b'mod konservattiv mhux permess li tissejjaħ din il-funzjoni.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SIGURTÀ: ngħaddu l-prerekwiżiti ta 'dawn il-funzjonijiet lil min iċempel
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIGURTÀ: ara r-raġunament f `new` għalfejn dan qed juża l-varjant mhux sikur
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Joħloq `NonNull` li huwa mdendlin, iżda allinjat tajjeb għal dan it-Tqassim.
    ///
    /// Innota li l-valur tal-pointer jista 'potenzjalment jirrappreżenta pointer validu, li jfisser li dan m'għandux jintuża bħala valur sentinella "not yet initialized".
    /// Tipi li jallokaw b'mod għażżien għandhom isegwu l-inizjalizzazzjoni b'xi mezzi oħra.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SIGURTÀ: l-allinjament huwa garantit li mhux żero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Joħloq tqassim li jiddeskrivi r-rekord li jista 'jkollu valur ta' l-istess tqassim bħal `self`, iżda li huwa wkoll allinjat ma 'l-allinjament `align` (imkejjel f'bytes).
    ///
    ///
    /// Jekk `self` diġà jissodisfa l-allinjament preskritt, allura jirritorna `self`.
    ///
    /// Innota li dan il-metodu ma jżid l-ebda ikkuttunar mad-daqs ġenerali, irrispettivament minn jekk it-tqassim mibgħut lura għandux allinjament differenti.
    /// Fi kliem ieħor, jekk `K` għandu daqs 16, `K.align_to(32)`*xorta* jkollu daqs 16.
    ///
    /// Jirritorna żball jekk il-kombinazzjoni ta `self.size()` u `align` mogħtija tikser il-kundizzjonijiet elenkati f [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Jirritorna l-ammont ta 'padding li rridu ndaħħlu wara `self` biex niżguraw li l-indirizz li ġej jissodisfa lil `align` (imkejjel f'bytes).
    ///
    /// eż., jekk `self.size()` huwa 9, allura `self.padding_needed_for(4)` jirritorna 3, għax dak huwa n-numru minimu ta 'bytes ta' padding meħtieġ biex jinkiseb indirizz 4-allinjat (jekk wieħed jassumi li l-blokka tal-memorja korrispondenti tibda f'indirizz 4-allinjat).
    ///
    ///
    /// Il-valur ta 'ritorn ta' din il-funzjoni m'għandux tifsira jekk `align` mhuwiex qawwa ta 'tnejn.
    ///
    /// Innota li l-utilità tal-valur ritornat teħtieġ li `align` ikun inqas minn jew ugwali għall-allinjament tal-indirizz tal-bidu għall-blokka allokata kollha tal-memorja.Mod wieħed biex tissodisfa din il-limitazzjoni huwa li tiżgura `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Il-valur aġġustat huwa:
        //   len_rounded_up=(len + allinja, 1)&! (allinja, 1);
        // u mbagħad nirritornaw id-differenza tal-ikkuttunar: `len_rounded_up - len`.
        //
        // Aħna nużaw aritmetika modulari matul:
        //
        // 1. align huwa garantit li jkun> 0, allura align, 1 huwa dejjem validu.
        //
        // 2.
        // `len + align - 1` tista 'tifwir sa mhux aktar minn `align - 1`, allura l-maskra&b `!(align - 1)` tiżgura li fil-każ ta' tifwir, `len_rounded_up` innifsu jkun 0.
        //
        //    Għalhekk l-ikkuttunar ritornat, meta miżjud ma `len`, jagħti 0, li jissodisfa trivjalment l-allinjament `align`.
        //
        // (Dażgur, tentattivi biex jiġu allokati blokki ta 'memorja li d-daqs u l-ikkuttunar tagħhom joħorġu bil-mod ta' hawn fuq għandhom jikkawżaw li l-allokatur jagħti żball xorta waħda.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Joħloq tqassim billi jdawwar id-daqs ta 'dan it-tqassim sa multiplu tal-allinjament tat-tqassim.
    ///
    ///
    /// Dan huwa ekwivalenti għaż-żieda tar-riżultat ta `padding_needed_for` mad-daqs attwali tat-tqassim.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Dan ma jistax ifur.Jikkwota mill-invariant ta 'Layout:
        // > `size`, meta mqarreb lejn l-eqreb multiplu ta `align`,
        // > m'għandux ifur (jiġifieri, il-valur arrotondat għandu jkun inqas minn
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Joħloq tqassim li jiddeskrivi r-rekord għal istanzi `n` ta `self`, b'ammont xieraq ta' padding bejn kull wieħed biex jiżgura li kull istanza tingħata d-daqs u l-allinjament mitlub tagħha.
    /// Wara suċċess, jirritorna `(k, offs)` fejn `k` huwa t-tqassim tal-firxa u `offs` hija d-distanza bejn il-bidu ta 'kull element fil-firxa.
    ///
    /// Mal-overflow aritmetiku, jirritorna `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Dan ma jistax ifur.Jikkwota mill-invariant ta 'Layout:
        // > `size`, meta mqarreb lejn l-eqreb multiplu ta `align`,
        // > m'għandux ifur (jiġifieri, il-valur arrotondat għandu jkun inqas minn
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SIGURTÀ: self.align huwa diġà magħruf li huwa validu u alloc_size kien
        // ikkuttunat diġà.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Joħloq tqassim li jiddeskrivi r-rekord għal `self` segwit minn `next`, inkluż kwalunkwe padding neċessarju biex jiġi żgurat li `next` ikun allinjat sewwa, imma *l-ebda padding ta 'wara*.
    ///
    /// Sabiex tqabbel it-tqassim tar-rappreżentazzjoni C `repr(C)`, għandek ċempel lil `pad_to_align` wara li testendi t-tqassim bl-oqsma kollha.
    /// (M'hemm l-ebda mod biex taqbel mat-tqassim ta 'rappreżentazzjoni 0Rust default `repr(Rust)`, as it is unspecified.)
    ///
    /// Innota li l-allinjament tat-tqassim li jirriżulta jkun il-massimu ta 'dawk ta' `self` u `next`, sabiex jiġi żgurat l-allinjament taż-żewġ partijiet.
    ///
    /// Jirritorna `Ok((k, offset))`, fejn `k` huwa tqassim tar-rekord konkatenat u `offset` huwa l-post relattiv, f'bytes, tal-bidu tax-`next` inkorporat fir-rekord konkatenat (jekk wieħed jassumi li r-rekord innifsu jibda fl-offset 0).
    ///
    ///
    /// Mal-overflow aritmetiku, jirritorna `LayoutError`.
    ///
    /// # Examples
    ///
    /// Biex tikkalkula t-tqassim ta 'struttura `#[repr(C)]` u t-tpaċija tal-oqsma mit-taqsimiet tal-oqsma tagħha:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ftakar biex tiffinalizza b `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // ittestja li taħdem
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Joħloq tqassim li jiddeskrivi r-rekord għall-istanzi `n` ta `self`, mingħajr ebda padding bejn kull istanza.
    ///
    /// Innota li, għall-kuntrarju ta `repeat`, `repeat_packed` ma jiggarantixxix li l-istanzi ripetuti ta' `self` ikunu allinjati sewwa, anke jekk istanza partikolari ta `self` tkun allinjata sewwa.
    /// Fi kliem ieħor, jekk it-tqassim mibgħut lura minn `repeat_packed` jintuża biex jalloka array, mhuwiex garantit li l-elementi kollha fil-array ikunu allinjati sewwa.
    ///
    /// Mal-overflow aritmetiku, jirritorna `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Joħloq tqassim li jiddeskrivi r-rekord għal `self` segwit minn `next` mingħajr ebda padding addizzjonali bejn it-tnejn.
    /// Peress li l-ebda padding ma huwa mdaħħal, l-allinjament ta `next` huwa irrilevanti, u mhu inkorporat *xejn* fit-tqassim li jirriżulta.
    ///
    ///
    /// Mal-overflow aritmetiku, jirritorna `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Joħloq tqassim li jiddeskrivi r-rekord għal `[T; n]`.
    ///
    /// Mal-overflow aritmetiku, jirritorna `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Il-parametri mogħtija lil `Layout::from_size_align` jew xi kostruttur ieħor `Layout` ma jissodisfawx il-limitazzjonijiet dokumentati tiegħu.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (għandna bżonn dan għal impl downstream ta 'trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}