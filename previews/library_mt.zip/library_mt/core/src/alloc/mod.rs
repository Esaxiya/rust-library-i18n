//! APIs tal-allokazzjoni tal-memorja

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// L-iżball `AllocError` jindika falliment ta 'allokazzjoni li jista' jkun dovut għall-eżawriment tar-riżorsi jew għal xi ħaġa ħażina meta tgħaqqad l-argumenti ta 'input mogħtija ma' dan l-allokatur.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (għandna bżonn dan għal impl downstream ta 'trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Implimentazzjoni ta `Allocator` tista' talloka, tikber, tiċkien, u tqassam blokki arbitrarji ta 'dejta deskritti permezz ta' [`Layout`][].
///
/// `Allocator` huwa ddisinjat biex jiġi implimentat fuq ZSTs, referenzi, jew indikaturi intelliġenti minħabba li jkollu allokatur bħal `MyAlloc([u8; N])` ma jistax jiġi mċaqlaq, mingħajr ma jiġu aġġornati l-indikaturi għall-memorja allokata.
///
/// B'differenza minn [`GlobalAlloc`][], allokazzjonijiet ta 'daqs żero huma permessi f `Allocator`.
/// Jekk allokatur sottostanti ma jappoġġjax dan (bħal jemalloc) jew jirritorna pointer null (bħal `libc::malloc`), dan għandu jinqabad mill-implimentazzjoni.
///
/// ### Memorja allokata bħalissa
///
/// Uħud mill-metodi jeħtieġu li blokka tal-memorja tkun *attwalment allokata* permezz ta 'allokatur.Dan ifisser li:
///
/// * l-indirizz tal-bidu għal dik il-blokka tal-memorja kien preċedentement mibgħut lura minn [`allocate`], [`grow`], jew [`shrink`], u
///
/// * il-blokka tal-memorja ma ġietx sussegwentement allokata mill-ġdid, fejn il-blokki jew jiġu allokati direttament billi jiġu mgħoddija lil [`deallocate`] jew inbidlu billi ġew mgħoddija lil [`grow`] jew [`shrink`] li jirritorna `Ok`.
///
/// Jekk `grow` jew `shrink` irritornaw `Err`, il-pointer mgħoddi jibqa 'validu.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Armar tal-memorja
///
/// Uħud mill-metodi jeħtieġu li tqassim *joqgħod* blokka tal-memorja.
/// Xi tfisser għal tqassim għal "fit" blokka tal-memorja tfisser (jew b'mod ekwivalenti, għal blokka tal-memorja għal "fit" tqassim) huwa li l-kundizzjonijiet li ġejjin għandhom ikollhom:
///
/// * Il-blokka għandha tkun allokata bl-istess allinjament bħal [`layout.align()`], u
///
/// * Ix-[`layout.size()`] ipprovdut għandu jaqa 'fil-firxa `min ..= max`, fejn:
///   - `min` huwa d-daqs tat-tqassim użat l-aktar reċentement biex jalloka l-blokka, u
///   - `max` huwa l-aħħar daqs attwali ritornat minn [`allocate`], [`grow`], jew [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Blokki tal-memorja ritornati minn allokatur għandhom jindikaw memorja valida u jżommu l-validità tagħhom sakemm l-istanza u l-kloni kollha tagħha jitwaqqgħu,
///
/// * il-klonazzjoni jew iċ-ċaqliq tal-allokatur m'għandux jinvalida blokki tal-memorja rritornati minn dan l-allokatur.Allokatur ikklonjat għandu jġib ruħu bħall-istess allokatur, u
///
/// * kwalunkwe indikatur għal blokka tal-memorja li huwa [*currently allocated*] jista 'jiġi mgħoddi lil kwalunkwe metodu ieħor tal-allokatur.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Tentattivi biex talloka blokka ta 'memorja.
    ///
    /// Wara suċċess, jirritorna [`NonNull<[u8]>`][NonNull] li jilħaq id-daqs u l-allinjament tal-garanziji ta `layout`.
    ///
    /// Il-blokka rritornata jista 'jkollha daqs ikbar minn dak speċifikat minn `layout.size()`, u jista' jkollha l-kontenut tagħha inizjalizzat jew le.
    ///
    /// # Errors
    ///
    /// Ir-ritorn ta `Err` jindika li jew il-memorja hija eżawrita jew `layout` ma tissodisfax id-daqs tal-allokatur jew ir-restrizzjonijiet tal-allinjament.
    ///
    /// Implimentazzjonijiet huma mħeġġa jirritornaw `Err` fuq l-eżawriment tal-memorja minflok paniku jew abort, iżda dan mhuwiex rekwiżit strett.
    /// (Speċifikament: huwa *legali* li timplimenta dan iż-trait fuq librerija ta 'allokazzjoni indiġena sottostanti li tabbortja meta teżawrixxi l-memorja.)
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'allokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Iġib ruħu bħal `allocate`, iżda jiżgura wkoll li l-memorja rritornata tkun inizjalizzata żero.
    ///
    /// # Errors
    ///
    /// Ir-ritorn ta `Err` jindika li jew il-memorja hija eżawrita jew `layout` ma tissodisfax id-daqs tal-allokatur jew ir-restrizzjonijiet tal-allinjament.
    ///
    /// Implimentazzjonijiet huma mħeġġa jirritornaw `Err` fuq l-eżawriment tal-memorja minflok paniku jew abort, iżda dan mhuwiex rekwiżit strett.
    /// (Speċifikament: huwa *legali* li timplimenta dan iż-trait fuq librerija ta 'allokazzjoni indiġena sottostanti li tabbortja meta teżawrixxi l-memorja.)
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'allokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SIGURTÀ: `alloc` jirritorna blokka tal-memorja valida
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Iqassam il-memorja referenzjata minn `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` għandha tindika blokka ta 'memorja [*currently allocated*] permezz ta' dan l-allokatur, u
    /// * `layout` trid [*fit*] dik il-blokka tal-memorja.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Tentattivi biex testendi l-blokka tal-memorja.
    ///
    /// Jirritorna [`NonNull<[u8]>`][NonNull] ġdid li jkun fih pointer u d-daqs attwali tal-memorja allokata.Il-pointer huwa adattat biex iżomm dejta deskritta minn `new_layout`.
    /// Biex twettaq dan, l-allokatur jista 'jestendi l-allokazzjoni referenzjata minn `ptr` biex taqbel mat-tqassim il-ġdid.
    ///
    /// Jekk dan jirritorna `Ok`, allura s-sjieda tal-blokka tal-memorja referenzjata minn `ptr` ġiet trasferita lil dan l-allokatur.
    /// Il-memorja tista 'tkun ġiet meħlusa jew le, u għandha titqies li ma tistax tintuża sakemm ma ġietx ittrasferita lura lil min iċempel mill-ġdid permezz tal-valur ta' ritorn ta 'dan il-metodu.
    ///
    /// Jekk dan il-metodu jirritorna `Err`, allura s-sjieda tal-blokka tal-memorja ma ġietx trasferita għal dan l-allokatur, u l-kontenut tal-blokka tal-memorja ma jinbidilx.
    ///
    /// # Safety
    ///
    /// * `ptr` għandha tindika blokka ta 'memorja [*currently allocated*] permezz ta' dan l-allokatur.
    /// * `old_layout` għandu [*fit*] dak il-blokka tal-memorja (L-argument `new_layout` m'għandux għalfejn joqgħod miegħu.).
    /// * `new_layout.size()` għandu jkun akbar minn jew ugwali għal `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Jirritorna `Err` jekk it-tqassim il-ġdid ma jissodisfax id-daqs tal-allokatur u r-restrizzjonijiet tal-allinjament tal-allokatur, jew jekk jikber mod ieħor ifalli.
    ///
    /// Implimentazzjonijiet huma mħeġġa jirritornaw `Err` fuq l-eżawriment tal-memorja minflok paniku jew abort, iżda dan mhuwiex rekwiżit strett.
    /// (Speċifikament: huwa *legali* li timplimenta dan iż-trait fuq librerija ta 'allokazzjoni indiġena sottostanti li tabbortja meta teżawrixxi l-memorja.)
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'allokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURTÀ: għax `new_layout.size()` għandu jkun akbar minn jew ugwali għal
        // `old_layout.size()`, kemm l-allokazzjoni tal-memorja l-qadima kif ukoll dik ġdida huma validi għal qari u kitbiet għal bytes `old_layout.size()`.
        // Ukoll, minħabba li l-allokazzjoni l-qadima kienet għadha ma ġietx allokata mill-ġdid, ma tistax tirkeb fuq `new_ptr`.
        // Għalhekk, is-sejħa għal `copy_nonoverlapping` hija sigura.
        // Il-kuntratt tas-sigurtà għal `dealloc` għandu jintlaqa 'minn min iċempel.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Iġib ruħu bħal `grow`, iżda jiżgura wkoll li l-kontenuti l-ġodda huma ssettjati għal żero qabel ma jiġu rritornati.
    ///
    /// Il-blokka tal-memorja jkun fiha l-kontenut li ġej wara sejħa b'suċċess lil
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` huma ppreservati mill-allokazzjoni oriġinali.
    ///   * Il-Bytes `old_layout.size()..old_size` jew se jiġu ppreservati jew zeroed, skont l-implimentazzjoni tal-allokatur.
    ///   `old_size` tirreferi għad-daqs tal-blokka tal-memorja qabel is-sejħa `grow_zeroed`, li jista 'jkun akbar mid-daqs li kien oriġinarjament mitlub meta ġiet allokata.
    ///   * Bytes `old_size..new_size` huma zeroed.`new_size` jirreferi għad-daqs tal-blokka tal-memorja rritornata mis-sejħa `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` għandha tindika blokka ta 'memorja [*currently allocated*] permezz ta' dan l-allokatur.
    /// * `old_layout` għandu [*fit*] dak il-blokka tal-memorja (L-argument `new_layout` m'għandux għalfejn joqgħod miegħu.).
    /// * `new_layout.size()` għandu jkun akbar minn jew ugwali għal `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Jirritorna `Err` jekk it-tqassim il-ġdid ma jissodisfax id-daqs tal-allokatur u r-restrizzjonijiet tal-allinjament tal-allokatur, jew jekk jikber mod ieħor ifalli.
    ///
    /// Implimentazzjonijiet huma mħeġġa jirritornaw `Err` fuq l-eżawriment tal-memorja minflok paniku jew abort, iżda dan mhuwiex rekwiżit strett.
    /// (Speċifikament: huwa *legali* li timplimenta dan iż-trait fuq librerija ta 'allokazzjoni indiġena sottostanti li tabbortja meta teżawrixxi l-memorja.)
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'allokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SIGURTÀ: għax `new_layout.size()` għandu jkun akbar minn jew ugwali għal
        // `old_layout.size()`, kemm l-allokazzjoni tal-memorja l-qadima kif ukoll dik ġdida huma validi għal qari u kitbiet għal bytes `old_layout.size()`.
        // Ukoll, minħabba li l-allokazzjoni l-qadima kienet għadha ma ġietx allokata mill-ġdid, ma tistax tirkeb fuq `new_ptr`.
        // Għalhekk, is-sejħa għal `copy_nonoverlapping` hija sigura.
        // Il-kuntratt tas-sigurtà għal `dealloc` għandu jintlaqa 'minn min iċempel.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Tentattivi biex tiċkien il-blokka tal-memorja.
    ///
    /// Jirritorna [`NonNull<[u8]>`][NonNull] ġdid li jkun fih pointer u d-daqs attwali tal-memorja allokata.Il-pointer huwa adattat biex iżomm dejta deskritta minn `new_layout`.
    /// Biex twettaq dan, l-allokatur jista 'jnaqqas l-allokazzjoni msemmija minn `ptr` biex taqbel mat-tqassim il-ġdid.
    ///
    /// Jekk dan jirritorna `Ok`, allura s-sjieda tal-blokka tal-memorja referenzjata minn `ptr` ġiet trasferita lil dan l-allokatur.
    /// Il-memorja tista 'tkun ġiet meħlusa jew le, u għandha titqies li ma tistax tintuża sakemm ma ġietx ittrasferita lura lil min iċempel mill-ġdid permezz tal-valur ta' ritorn ta 'dan il-metodu.
    ///
    /// Jekk dan il-metodu jirritorna `Err`, allura s-sjieda tal-blokka tal-memorja ma ġietx trasferita għal dan l-allokatur, u l-kontenut tal-blokka tal-memorja ma jinbidilx.
    ///
    /// # Safety
    ///
    /// * `ptr` għandha tindika blokka ta 'memorja [*currently allocated*] permezz ta' dan l-allokatur.
    /// * `old_layout` għandu [*fit*] dak il-blokka tal-memorja (L-argument `new_layout` m'għandux għalfejn joqgħod miegħu.).
    /// * `new_layout.size()` għandu jkun iżgħar minn jew ugwali għal `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Jirritorna `Err` jekk it-tqassim il-ġdid ma jissodisfax id-daqs tal-allokatur u r-restrizzjonijiet tal-allinjament tal-allokatur, jew jekk jonqos mod ieħor ifalli.
    ///
    /// Implimentazzjonijiet huma mħeġġa jirritornaw `Err` fuq l-eżawriment tal-memorja minflok paniku jew abort, iżda dan mhuwiex rekwiżit strett.
    /// (Speċifikament: huwa *legali* li timplimenta dan iż-trait fuq librerija ta 'allokazzjoni indiġena sottostanti li tabbortja meta teżawrixxi l-memorja.)
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'allokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIGURTÀ: għax `new_layout.size()` għandu jkun inqas minn jew daqs
        // `old_layout.size()`, kemm l-allokazzjoni tal-memorja l-qadima kif ukoll dik ġdida huma validi għal qari u kitbiet għal bytes `new_layout.size()`.
        // Ukoll, minħabba li l-allokazzjoni l-qadima kienet għadha ma ġietx allokata mill-ġdid, ma tistax tirkeb fuq `new_ptr`.
        // Għalhekk, is-sejħa għal `copy_nonoverlapping` hija sigura.
        // Il-kuntratt tas-sigurtà għal `dealloc` għandu jintlaqa 'minn min iċempel.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Joħloq adapter "by reference" għal din l-istanza ta `Allocator`.
    ///
    /// L-adapter mibgħut lura jimplimenta wkoll `Allocator` u sempliċement jissellef dan.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SIGURTÀ: il-kuntratt tas-sigurtà għandu jintlaqa 'minn min iċempel
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURTÀ: il-kuntratt tas-sigurtà għandu jintlaqa 'minn min iċempel
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURTÀ: il-kuntratt tas-sigurtà għandu jintlaqa 'minn min iċempel
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURTÀ: il-kuntratt tas-sigurtà għandu jintlaqa 'minn min iċempel
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}