use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Allokatur tal-memorja li jista 'jiġi rreġistrat bħala default tal-librerija standard permezz tal-attribut `#[global_allocator]`.
///
/// Uħud mill-metodi jeħtieġu li blokka tal-memorja tkun *attwalment allokata* permezz ta 'allokatur.Dan ifisser li:
///
/// * l-indirizz tal-bidu għal dik il-blokka tal-memorja kien preċedentement mibgħut lura b'sejħa preċedenti għal metodu ta 'allokazzjoni bħal `alloc`, u
///
/// * il-blokka tal-memorja ma ġietx sussegwentement allokata mill-ġdid, fejn il-blokki huma allokati jew billi jiġu mgħoddija lil metodu ta 'allokazzjoni bħal `dealloc` jew billi jiġu mgħoddija lil metodu ta' allokazzjoni mill-ġdid li jirritorna pointer mhux null.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// Ix-`GlobalAlloc` trait huwa `unsafe` trait għal numru ta 'raġunijiet, u l-implimentaturi għandhom jiżguraw li jaderixxu ma' dawn il-kuntratti:
///
/// * Hija mġieba mhux definita jekk l-allokaturi globali jbattu.Din ir-restrizzjoni tista 'titneħħa fiż-future, iżda bħalissa panic minn kwalunkwe minn dawn il-funzjonijiet jista' jwassal għal nuqqas ta 'sigurtà fil-memorja.
///
/// * `Layout` mistoqsijiet u kalkoli b'mod ġenerali għandhom ikunu korretti.Dawk li jċemplu dan trait jitħallew jiddependu fuq il-kuntratti definiti fuq kull metodu, u l-implimentaturi għandhom jiżguraw li dawn il-kuntratti jibqgħu veri.
///
/// * Inti tista 'ma sserraħx fuq allokazzjonijiet li attwalment iseħħu, anke jekk hemm allokazzjonijiet ta' borġ espliċiti fis-sors.
/// L-ottimizzatur jista 'jsib allokazzjonijiet mhux użati li jista' jew jelimina kompletament jew jimxi lejn il-munzell u b'hekk qatt ma jinvoka l-allokatur.
/// L-ottimizzatur jista 'wkoll jassumi li l-allokazzjoni hija infallibbli, allura kodiċi li kien ifalli minħabba fallimenti ta' l-allokatur issa jista 'jaħdem f'daqqa minħabba li l-ottimizzatur ħadem madwar il-ħtieġa għal allokazzjoni.
/// B'mod aktar konkret, l-eżempju tal-kodiċi li ġej mhuwiex sod, irrispettivament minn jekk l-allokatur tad-dwana tiegħek jippermettix li tgħodd kemm ġaraw allokazzjonijiet.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Innota li l-ottimizzazzjonijiet imsemmija hawn fuq mhumiex l-unika ottimizzazzjoni li tista 'tiġi applikata.Ġeneralment tista 'ma sserraħx fuq li jiġru allokazzjonijiet tal-borġ jekk jistgħu jitneħħew mingħajr ma tinbidel l-imġieba tal-programm.
///   Jekk l-allokazzjonijiet jiġrux jew le mhuwiex parti mill-imġieba tal-programm, anke jekk jista 'jinstab permezz ta' allokatur li jsegwi l-allokazzjonijiet billi jistampa jew inkella jkollu effetti sekondarji.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Alloka l-memorja kif deskritt mix-`layout` mogħti.
    ///
    /// Jirritorna pointer għal memorja allokata ġdida, jew null biex jindika falliment fl-allokazzjoni.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura għaliex imġieba mhux definita tista 'tirriżulta jekk min iċempel ma jiżgurax li `layout` għandu daqs mhux żero.
    ///
    /// (Subtraits ta 'estensjoni jistgħu jipprovdu limiti aktar speċifiċi fuq l-imġieba, eż., Jiggarantixxu indirizz sentinella jew pointer null bi tweġiba għal talba ta' allokazzjoni ta 'daqs żero.)
    ///
    /// Il-blokka tal-memorja allokata tista 'jew ma tistax tkun inizjalizzata.
    ///
    /// # Errors
    ///
    /// Ir-ritorn ta 'pointer null jindika li jew il-memorja hija eżawrita jew `layout` ma tissodisfax id-daqs ta' dan l-allokatur jew ir-restrizzjonijiet ta 'allinjament.
    ///
    /// Implimentazzjonijiet huma mħeġġa jirritornaw null fuq l-eżawriment tal-memorja aktar milli jabbortixxu, iżda dan mhuwiex rekwiżit strett.
    /// (Speċifikament: huwa *legali* li timplimenta dan iż-trait fuq librerija ta 'allokazzjoni indiġena sottostanti li tabbortja meta teżawrixxi l-memorja.)
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'allokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Iddokloka l-blokka tal-memorja fil-pointer `ptr` mogħti max-`layout` mogħti.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura għax imġieba mhux definita tista 'tirriżulta jekk min iċempel ma jiżgurax dan kollu li ġej:
    ///
    ///
    /// * `ptr` għandha tindika blokka ta 'memorja allokata bħalissa permezz ta' dan l-allokatur,
    ///
    /// * `layout` għandu jkun l-istess tqassim li ntuża biex tiġi allokata dik il-blokka tal-memorja.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Iġib ruħu bħal `alloc`, iżda jiżgura wkoll li l-kontenut huwa ssettjat għal żero qabel ma jingħata lura.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura għall-istess raġunijiet li hija `alloc`.
    /// Madankollu l-blokka tal-memorja allokata hija garantita li tkun inizjalizzata.
    ///
    /// # Errors
    ///
    /// Ir-ritorn ta 'pointer null jindika li jew il-memorja hija eżawrita jew `layout` ma jissodisfax id-daqs tal-allokatur jew ir-restrizzjonijiet tal-allinjament, l-istess bħal f `alloc`.
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'allokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SIGURTÀ: il-kuntratt ta 'sigurtà għal `alloc` għandu jintlaqa' minn min iċempel.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SIGURTÀ: hekk kif l-allokazzjoni rnexxiet, ir-reġjun minn `ptr`
            // ta 'daqs `size` huwa garantit li jkun validu għal kitbiet.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Iċċekken jew tkabbar blokka tal-memorja għax-`new_size` mogħti.
    /// Il-blokka hija deskritta mill-indikatur `ptr` mogħti u `layout`.
    ///
    /// Jekk dan jirritorna pointer mhux null, allura s-sjieda tal-blokka tal-memorja referenzjata minn `ptr` ġiet trasferita lil dan l-allokatur.
    /// Il-memorja tista 'jew ma tkunx ġiet allokata mill-ġdid, u għandha titqies li ma tistax tintuża (sakemm naturalment ma ġietx trasferita lura lil min iċempel mill-ġdid permezz tal-valur ta' ritorn ta 'dan il-metodu).
    /// Il-blokka tal-memorja l-ġdida hija allokata ma `layout`, iżda max-`size` aġġornata għal `new_size`.
    /// Dan it-tqassim il-ġdid għandu jintuża meta titqassam il-blokka tal-memorja l-ġdida ma `dealloc`.
    /// Il-firxa `0..min(layout.size(), new_size) "tal-blokka tal-memorja l-ġdida hija garantita li jkollha l-istess valuri bħall-blokka oriġinali.
    ///
    /// Jekk dan il-metodu jirritorna null, allura s-sjieda tal-blokka tal-memorja ma ġietx trasferita għal dan l-allokatur, u l-kontenut tal-blokka tal-memorja ma jinbidilx.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura għax imġieba mhux definita tista 'tirriżulta jekk min iċempel ma jiżgurax dan kollu li ġej:
    ///
    /// * `ptr` bħalissa għandhom jiġu allokati permezz ta 'dan l-allokatur,
    ///
    /// * `layout` għandu jkun l-istess tqassim li ntuża biex tiġi allokata dik il-blokka tal-memorja,
    ///
    /// * `new_size` għandu jkun akbar minn żero.
    ///
    /// * `new_size`, meta mqarreb lejn l-eqreb multiplu ta `layout.align()`, m'għandux ifur (jiġifieri, il-valur arrotondat għandu jkun inqas minn `usize::MAX`).
    ///
    /// (Subtraits ta 'estensjoni jistgħu jipprovdu limiti aktar speċifiċi fuq l-imġieba, eż., Jiggarantixxu indirizz sentinella jew pointer null bi tweġiba għal talba ta' allokazzjoni ta 'daqs żero.)
    ///
    /// # Errors
    ///
    /// Jirritorna null jekk it-tqassim il-ġdid ma jissodisfax id-daqs u r-restrizzjonijiet tal-allinjament tal-allokatur, jew jekk l-allokazzjoni mill-ġdid tfalli mod ieħor.
    ///
    /// Implimentazzjonijiet huma mħeġġa jirritornaw null fuq l-eżawriment tal-memorja minflok paniku jew abort, iżda dan mhuwiex rekwiżit strett.
    /// (Speċifikament: huwa *legali* li timplimenta dan iż-trait fuq librerija ta 'allokazzjoni indiġena sottostanti li tabbortja meta teżawrixxi l-memorja.)
    ///
    /// Klijenti li jixtiequ jabbortjaw il-komputazzjoni b'reazzjoni għal żball ta 'riallokazzjoni huma mħeġġa jsejħu l-funzjoni [`handle_alloc_error`], aktar milli jinvokaw direttament `panic!` jew simili.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SIGURTÀ: min iċempel għandu jiżgura li x-`new_size` ma jegħlibx.
        // `layout.align()` ġej minn `Layout` u għalhekk huwa garantit li jkun validu.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SIGURTÀ: min iċempel għandu jiżgura li `new_layout` huwa akbar minn żero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SIGURTÀ: il-blokk allokat qabel ma jistax jikkoinċidi mal-blokk allokat ġdid.
            // Il-kuntratt tas-sigurtà għal `dealloc` għandu jintlaqa 'minn min iċempel.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}