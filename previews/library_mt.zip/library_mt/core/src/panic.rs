//! Appoġġ Panic fil-librerija standard.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// Struttura li tipprovdi informazzjoni dwar panic.
///
/// `PanicInfo` struttura tiġi mgħoddija lil panic hook issettjat mill-funzjoni [`set_hook`].
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// Jirritorna t-tagħbija utli assoċjata maż-panic.
    ///
    /// Dan ġeneralment, iżda mhux dejjem, ikun `&'static str` jew [`String`].
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// Jekk il-makro `panic!` mix-`core` crate (mhux minn `std`) intużat ma 'sekwenza tal-ifformattjar u xi argumenti addizzjonali, jirritorna dak il-messaġġ lest biex jintuża pereżempju ma' [`fmt::write`]
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// Jirritorna informazzjoni dwar il-post minn fejn oriġina panic, jekk disponibbli.
    ///
    /// Dan il-metodu bħalissa dejjem jirritorna [`Some`], iżda dan jista 'jinbidel fil-verżjonijiet ta' future.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: Jekk dan jinbidel biex xi kultant jirritorna Xejn,
        // tittratta dak il-każ f std::panicking::default_hook u std::panicking::begin_panic_fmt.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ma nistgħux nużaw downcast_ref: :<String>() hawn
        // peress String mhix disponibbli fil-libcore!
        // It-tagħbija hija String meta `std::panic!` tissejjaħ b'argumenti multipli, iżda f'dak il-każ il-messaġġ huwa wkoll disponibbli.
        //

        self.location.fmt(formatter)
    }
}

/// Struttura li fiha informazzjoni dwar il-post ta 'panic.
///
/// Din l-istruttura hija maħluqa minn [`PanicInfo::location()`].
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// Paraguni għall-ugwaljanza u l-ordni jsiru fil-fajl, linja, imbagħad prijorità tal-kolonna.
/// Il-fajls jitqabblu bħala kordi, mhux `Path`, li jista 'jkun mhux mistenni.
/// Ara d-dokumentazzjoni ta '[`Location: : file`] għal aktar diskussjoni.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// Jirritorna l-post tas-sors ta 'min iċempel din il-funzjoni.
    /// Jekk dak li jċempel dik il-funzjoni jiġi annotat allura l-post tas-sejħa tiegħu jiġi rritornat, u hekk fuq il-munzell għall-ewwel sejħa fi ħdan korp tal-funzjoni mhux traċċat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// Jirritorna x-[`Location`] li fih tissejjaħ.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// Jirritorna [`Location`] minn ġewwa d-definizzjoni ta 'din il-funzjoni.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // li tħaddem l-istess funzjoni mhux traċċata f'post differenti tagħtina l-istess riżultat
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // it-tħaddim tal-funzjoni tracked f'post differenti jipproduċi valur differenti
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// Jirritorna l-isem tal-fajl sors li minnu oriġina panic.
    ///
    /// # `&str`, mhux `&Path`
    ///
    /// L-isem mibgħut lura jirreferi għal mogħdija tas-sors fuq is-sistema tal-kompilazzjoni, iżda mhuwiex validu li tirrappreżenta dan direttament bħala `&Path`.
    /// Il-kodiċi kkompilat jista 'jaħdem fuq sistema differenti b'implimentazzjoni `Path` differenti mis-sistema li tipprovdi l-kontenut u din il-librerija bħalissa m'għandhiex tip "host path" differenti.
    ///
    /// L-iktar imġieba sorprendenti sseħħ meta l-fajl "the same" jista 'jintlaħaq permezz ta' mogħdijiet multipli fis-sistema tal-modulu (ġeneralment bl-użu tal-attribut `#[path = "..."]` jew simili), li jista 'jikkawża li dak li jidher bħala kodiċi identiku jirritorna valuri differenti minn din il-funzjoni.
    ///
    ///
    /// # Cross-compilation
    ///
    /// Dan il-valur mhuwiex adattat biex jgħaddi lil `Path::new` jew kostrutturi simili meta l-pjattaforma ospitanti u l-pjattaforma fil-mira huma differenti.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// Jirritorna n-numru tal-linja li minnu oriġina panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// Jirritorna l-kolonna li minnha oriġina panic.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// trait intern użat minn libstd biex jgħaddi data minn libstd għal `panic_unwind` u runtimes oħra ta 'panic.
/// Mhux maħsub biex jiġi stabbilizzat dalwaqt, tużax.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// Ħu sjieda sħiħa tal-kontenut.
    /// It-tip ta 'ritorn huwa attwalment `Box<dyn Any + Send>`, iżda ma nistgħux nużaw `Box` fil-libcore.
    ///
    /// Wara li dan il-metodu ġie msejjaħ, fadal biss xi valur finta finta f `self`.
    /// Li ssejjaħ dan il-metodu darbtejn, jew li ċċempel lil `get` wara li ssejjaħ dan il-metodu, huwa żball.
    ///
    /// L-argument huwa misluf minħabba li r-runtime panic (`__rust_start_panic`) jirċievi biss `dyn BoxMeUp` misluf.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// Biss tissellef il-kontenut.
    fn get(&mut self) -> &(dyn Any + Send);
}