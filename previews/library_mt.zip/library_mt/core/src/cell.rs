//! Kontenituri li jistgħu jinbidlu li jistgħu jinqasmu.
//!
//! Is-sigurtà tal-memorja Rust hija bbażata fuq din ir-regola: Minħabba oġġett `T`, huwa possibbli biss li jkollok waħda minn dawn li ġejjin:
//!
//! - Li jkollok diversi referenzi immutabbli (`&T`) għall-oġġett (magħruf ukoll bħala **aliasing**).
//! - Li jkollok referenza waħda li tista 'tinbidel ("&mut T") għall-oġġett (magħruf ukoll bħala **mutabilità**).
//!
//! Dan huwa infurzat mill-kompilatur Rust.Madankollu, hemm sitwazzjonijiet fejn din ir-regola mhix flessibbli biżżejjed.Kultant huwa meħtieġ li jkun hemm referenzi multipli għal oġġett u madankollu tibdlu.
//!
//! Jeżistu kontenituri li jistgħu jinbidlu li jistgħu jinqasmu biex jippermettu l-mutabbiltà b'mod ikkontrollat, anke fil-preżenza ta 'aliasing.Kemm [`Cell<T>`] kif ukoll [`RefCell<T>`] jippermettu li jsir dan b'mod b'kamin wieħed.
//! Madankollu, la `Cell<T>` u lanqas `RefCell<T>` ma huma sikuri għall-ħajt (ma jimplimentawx [`Sync`]).
//! Jekk għandek bżonn tagħmel aliasing u mutazzjoni bejn ħjut multipli huwa possibbli li tuża tipi [`Mutex<T>`], [`RwLock<T>`] jew [`atomic`].
//!
//! Il-valuri tat-tipi `Cell<T>` u `RefCell<T>` jistgħu jiġu mmutati permezz ta 'referenzi kondiviżi (jiġifieri
//! tip `&T` komuni), filwaqt li ħafna mit-tipi Rust jistgħu jiġu mmutati biss permezz ta 'referenzi uniċi ("&mut T").
//! Aħna ngħidu li `Cell<T>` u `RefCell<T>` jipprovdu 'mutabilità interna', b'kuntrast ma 'tipi tipiċi ta' Rust li juru 'mutabilità li ntirtu'.
//!
//! It-tipi ta 'ċelloli jiġu f'żewġ togħmiet: `Cell<T>` u `RefCell<T>`.`Cell<T>` jimplimenta mutabilità interna billi jiċċaqlaq il-valuri ġewwa u barra mix-`Cell<T>`.
//! Biex tuża r-referenzi minflok il-valuri, wieħed irid juża t-tip `RefCell<T>`, billi jakkwista serratura tal-kitba qabel ma jimmuta.`Cell<T>` jipprovdi metodi biex jiġbed u jibdel il-valur intern kurrenti:
//!
//!  - Għal tipi li jimplimentaw [`Copy`], il-metodu [`get`](Cell::get) jirkupra l-valur intern kurrenti.
//!  - Għal tipi li jimplimentaw [`Default`], il-metodu [`take`](Cell::take) jissostitwixxi l-valur intern kurrenti b [`Default::default()`] u jirritorna l-valur sostitwit.
//!  - Għat-tipi kollha, il-metodu [`replace`](Cell::replace) jieħu post il-valur intern kurrenti u jirritorna l-valur mibdul u l-metodu [`into_inner`](Cell::into_inner) jikkonsma `Cell<T>` u jirritorna l-valur intern.
//!  Barra minn hekk, il-metodu [`set`](Cell::set) jissostitwixxi l-valur intern, u jwaqqa 'l-valur mibdul.
//!
//! `RefCell<T>` juża l-ħajja ta 'Rust biex jimplimenta' self dinamiku ', proċess li bih wieħed jista' jitlob aċċess temporanju, esklussiv, li jista 'jinbidel għall-valur intern.
//! Jissellef għal `RefCell<T>"s jiġu rintraċċati"fil-ħin ta 'eżekuzzjoni", b'differenza mit-tipi ta' referenza indiġeni ta 'Rust li huma rintraċċati kompletament statikament, fil-ħin tal-kompilazzjoni.
//! Minħabba li s-self `RefCell<T>` huwa dinamiku huwa possibbli li tipprova tissellef valur li huwa diġà misluf b'mod reċiproku;meta jiġri dan jirriżulta fil-ħajta panic.
//!
//! # Meta tagħżel mutabilità interna
//!
//! L-iktar mutabbiltà komuni li tintiret, fejn wieħed irid ikollu aċċess uniku biex jimmutazzjoni ta 'valur, hija waħda mill-elementi tal-lingwa ewlenin li tippermetti lil Rust jirraġuna bil-qawwa dwar il-pointer aliasing, li jipprevjeni statikament il-bugs tal-crash.
//! Minħabba dan, il-mutabilità li tintiret hija preferuta, u l-mutabilità interna hija xi ħaġa ta 'l-aħħar għażla.
//! Peress li t-tipi ta 'ċelloli jippermettu l-mutazzjoni fejn kieku ma tkunx permessa għalkemm, hemm okkażjonijiet fejn il-mutabilità interna tista' tkun xierqa, jew saħansitra *għandu* jintuża, eż.
//!
//! * L-introduzzjoni ta 'mutabilità 'inside' ta' xi ħaġa immutabbli
//! * Dettalji ta 'implimentazzjoni ta' metodi loġikament-immutabbli.
//! * Implimentazzjonijiet mutanti ta [`Clone`].
//!
//! ## L-introduzzjoni ta 'mutabilità 'inside' ta' xi ħaġa immutabbli
//!
//! Ħafna tipi ta 'pointer intelliġenti kondiviżi, inklużi [`Rc<T>`] u [`Arc<T>`], jipprovdu kontenituri li jistgħu jiġu kklonati u maqsuma bejn partijiet multipli.
//! Minħabba li l-valuri kontenuti jistgħu jkunu multiplikati, jistgħu jiġu mislufa biss b `&`, mhux `&mut`.
//! Mingħajr ċelloli jkun impossibbli li tinbidel id-dejta ġewwa dawn l-indikaturi intelliġenti.
//!
//! Huwa komuni ħafna allura li tpoġġi `RefCell<T>` ġewwa tipi ta 'pointer maqsuma biex tintroduċi mill-ġdid il-mutabilità:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Oħloq blokka ġdida biex tillimita l-ambitu tas-self dinamiku
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Innota li jekk ma konniex inħallu s-self preċedenti tal-cache jaqa 'barra mill-ambitu allura s-self sussegwenti jikkawża thread dinamiku panic.
//!     //
//!     // Dan huwa l-periklu ewlieni li tuża `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Innota li dan l-eżempju juża `Rc<T>` u mhux `Arc<T>`.`RefCell<T>`huma għal xenarji b'kamin wieħed.Ikkunsidra li tuża [`RwLock<T>`] jew [`Mutex<T>`] jekk teħtieġ mutabilità kondiviża f'sitwazzjoni b'ħafna kamin.
//!
//! ## Dettalji ta 'implimentazzjoni ta' metodi loġikament-immutabbli
//!
//! Kultant jista 'jkun mixtieq li ma tesponix f'API li hemm mutazzjoni li qed isseħħ "under the hood".
//! Dan jista 'jkun għaliex loġikament l-operazzjoni ma tistax tinbidel, imma eż., Caching iġiegħel lill-implimentazzjoni twettaq mutazzjoni;jew għax trid tuża mutazzjoni biex timplimenta metodu trait li kien oriġinarjament definit biex jieħu `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Komputazzjoni għalja tmur hawn
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Implimentazzjonijiet mutanti ta `Clone`
//!
//! Dan huwa sempliċement każ speċjali, iżda komuni, tal-preċedenti: jinħeba l-mutabilità għal operazzjonijiet li jidhru li ma jistgħux jinbidlu.
//! Il-metodu [`clone`](Clone::clone) huwa mistenni li ma jbiddilx il-valur tas-sors, u huwa ddikjarat li jieħu `&self`, mhux `&mut self`.
//! Għalhekk, kwalunkwe mutazzjoni li sseħħ fil-metodu `clone` għandha tuża tipi ta 'ċelloli.
//! Pereżempju, [`Rc<T>`] iżomm l-għadd ta 'referenzi tiegħu f `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// Post tal-memorja li jista 'jinbidel.
///
/// # Examples
///
/// F'dan l-eżempju, tista 'tara li `Cell<T>` jippermetti mutazzjoni ġewwa strutt immutabbli.
/// Fi kliem ieħor, jippermetti lil "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // ŻBALL: `my_struct` ma jistax jinbidel
/// // my_struct.regular_field =valur_ġdid;
///
/// // XOGĦLIJIET: għalkemm `my_struct` ma jistax jinbidel, `special_field` huwa `Cell`,
/// // li dejjem jistgħu jiġu mmutati
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Ara x-[module-level documentation](self) għal aktar.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Toħloq `Cell<T>`, bil-valur `Default` għal T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Toħloq `Cell` ġdid li fih il-valur mogħti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Issettja l-valur miżmum.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Tpartit il-valuri ta 'żewġ Ċelloli.
    /// Id-differenza ma `std::mem::swap` hija li din il-funzjoni ma teħtieġx referenza `&mut`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SIGURTÀ: Dan jista 'jkun riskjuż jekk jissejjaħ minn ħjut separati, imma `Cell`
        // huwa `!Sync` allura dan mhux se jiġri.
        // Dan ukoll ma jinvalida l-ebda indikaturi peress li `Cell` jiżgura li xejn ieħor ma jkun qed jindika f'waħda minn dawn iċ-'Ċelloli`.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Jissostitwixxi l-valur kontenut b `val`, u jirritorna l-valur kontenut l-antik.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SIGURTÀ: Dan jista 'jikkawża ġirjiet tad-dejta jekk jissejjaħ minn thread separata,
        // imma `Cell` huwa `!Sync` u allura dan ma jseħħx.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Ikxef il-valur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Jirritorna kopja tal-valur li jinsab.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SIGURTÀ: Dan jista 'jikkawża ġirjiet tad-dejta jekk jissejjaħ minn thread separata,
        // imma `Cell` huwa `!Sync` u allura dan ma jseħħx.
        unsafe { *self.value.get() }
    }

    /// Aġġorna l-valur li jinsab billi tuża funzjoni u tirritorna l-valur il-ġdid.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Jirritorna pointer nej għad-dejta sottostanti f'din iċ-ċellola.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Jirritorna referenza li tista 'tinbidel għad-dejta sottostanti.
    ///
    /// Din is-sejħa tissellef `Cell` b'mod mutabbli (fil-ħin tal-kumpilazzjoni) li jiggarantixxi li aħna għandna l-unika referenza.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Jirritorna `&Cell<T>` minn `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SIGURTÀ: `&mut` jiżgura aċċess uniku.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Jieħu l-valur taċ-ċellola, u jħalli `Default::default()` f'postha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Jirritorna `&[Cell<T>]` minn `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SIGURTÀ: `Cell<T>` għandu l-istess tqassim tal-memorja bħal `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// Post ta 'memorja li jista' jinbidel b'regoli ta 'self ikkontrollati b'mod dinamiku
///
/// Ara x-[module-level documentation](self) għal aktar.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// Żball mibgħut lura minn [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// Żball mibgħut lura minn [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Valuri pożittivi jirrappreżentaw in-numru ta `Ref` attiv.Valuri negattivi jirrappreżentaw in-numru ta `RefMut` attiv.
// Multipli `RefMut`s jistgħu jkunu attivi biss kull darba jekk jirreferu għal komponenti distinti u mhux sovrapposti ta `RefCell` (eż. Firxiet differenti ta' porzjon).
//
// `Ref` u `RefMut` huma t-tnejn b'żewġ kelmiet fid-daqs, u għalhekk x'aktarx qatt ma jkun hemm biżżejjed 'Ref`s jew' RefMut`s biex jeqirdu nofs il-firxa `usize`.
// B'hekk, `BorrowFlag` probabbilment qatt ma jegħleb jew jinfluwenza.
// Madankollu, din mhix garanzija, peress li programm patoloġiku jista 'joħloq ripetutament u mbagħad mem::forget `Ref`s jew`RefMut`s.
// Għalhekk, il-kodiċi kollu għandu jiċċekkja b'mod espliċitu għal overflow u underflow sabiex tiġi evitata n-nuqqas ta 'sigurtà, jew għall-inqas iġib ruħu sewwa f'każ li jseħħ overflow jew underflow (eż., Ara BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Toħloq `RefCell` ġdid li fih `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Jikkonsma l-`RefCell`, u jirritorna l-valur imgeżwer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Peress li din il-funzjoni tieħu `self` (ix-`RefCell`) bil-valur, il-kompilatur jivverifika b'mod statiku li bħalissa mhuwiex issellef.
        //
        self.value.into_inner()
    }

    /// Jissostitwixxi l-valur imgeżwer b'wieħed ġdid, u jirritorna l-valur l-antik, mingħajr ma jiddiżinjalizza l-ebda wieħed.
    ///
    ///
    /// Din il-funzjoni tikkorrispondi għal [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics jekk il-valur huwa attwalment misluf.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Jissostitwixxi l-valur imgeżwer b'wieħed ġdid ikkalkulat minn `f`, u jirritorna l-valur l-antik, mingħajr ma jiddiżinjalizza l-ebda wieħed.
    ///
    ///
    /// # Panics
    ///
    /// Panics jekk il-valur huwa attwalment misluf.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Tpartit il-valur imgeżwer ta `self` mal-valur imgeżwer ta' `other`, mingħajr ma titneħħa l-ebda waħda minnhom.
    ///
    ///
    /// Din il-funzjoni tikkorrispondi għal [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Jissellef b'mod immutabbli l-valur imgeżwer.
    ///
    /// Is-self idum sakemm ix-`Ref` ritornat joħroġ mill-iskop.
    /// Jissellef multipli immutabbli jistgħu jinħarġu fl-istess ħin.
    ///
    /// # Panics
    ///
    /// Panics jekk il-valur huwa attwalment misluf b'mod reċiproku.
    /// Għal varjant mingħajr paniku, uża [`try_borrow`](#method.try_borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Eżempju ta 'panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Jissellef b'mod immutabbli l-valur imgeżwer, u jirritorna żball jekk il-valur huwa attwalment issellef b'mod reċiproku.
    ///
    ///
    /// Is-self idum sakemm ix-`Ref` ritornat joħroġ mill-iskop.
    /// Jissellef multipli immutabbli jistgħu jinħarġu fl-istess ħin.
    ///
    /// Din hija l-varjant ta [`borrow`](#method.borrow) mingħajr paniku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SIGURTÀ: `BorrowRef` jiżgura li hemm biss aċċess immutabbli
            // għall-valur waqt li jkun issellef.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Jissellef b'mod reċiproku l-valur imgeżwer.
    ///
    /// Is-self idum sakemm jirritorna `RefMut` jew ir-'RifMut` kollha derivati mill-ambitu tal-ħruġ tiegħu.
    ///
    /// Il-valur ma jistax jiġi misluf waqt li dan is-self ikun attiv.
    ///
    /// # Panics
    ///
    /// Panics jekk il-valur huwa attwalment misluf.
    /// Għal varjant mingħajr paniku, uża [`try_borrow_mut`](#method.try_borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Eżempju ta 'panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Tissellef b'mod reċiproku l-valur imgeżwer, billi tirritorna żball jekk il-valur huwa attwalment misluf.
    ///
    ///
    /// Is-self idum sakemm jirritorna `RefMut` jew ir-'RifMut` kollha derivati mill-ambitu tal-ħruġ tiegħu.
    /// Il-valur ma jistax jiġi misluf waqt li dan is-self ikun attiv.
    ///
    /// Din hija l-varjant ta [`borrow_mut`](#method.borrow_mut) mingħajr paniku.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SIGURTÀ: `BorrowRef` jiggarantixxi aċċess uniku.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Jirritorna pointer nej għad-dejta sottostanti f'din iċ-ċellola.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Jirritorna referenza li tista 'tinbidel għad-dejta sottostanti.
    ///
    /// Din is-sejħa tissellef `RefCell` b'mod mutabbli (fil-ħin tal-kumpilazzjoni) u għalhekk m'hemmx bżonn ta 'kontrolli dinamiċi.
    ///
    /// Madankollu oqgħod attent: dan il-metodu jistenna li `self` jista 'jinbidel, li ġeneralment mhuwiex il-każ meta tuża `RefCell`.
    ///
    /// Agħti ħarsa lejn il-metodu [`borrow_mut`] minflok jekk `self` ma jistax jinbidel.
    ///
    /// Ukoll, jekk jogħġbok kun af li dan il-metodu huwa biss għal ċirkostanzi speċjali u ġeneralment ma jkunx dak li trid.
    /// F'każ ta 'dubju, uża [`borrow_mut`] minflok.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Ħoll l-effett tal-gwardji li nixxew fuq l-istat tas-self tal-`RefCell`.
    ///
    /// Din is-sejħa hija simili għal [`get_mut`] iżda aktar speċjalizzata.
    /// Jissellef `RefCell` b'mod reċiproku biex jiżgura li ma jeżistux self u mbagħad jerġa 'jdaħħal l-istat li jissorvelja s-self maqsum.
    /// Dan huwa relevanti jekk xi self ta `Ref` jew `RefMut` ġew mikxufa.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Jissellef b'mod immutabbli l-valur imgeżwer, u jirritorna żball jekk il-valur huwa attwalment issellef b'mod reċiproku.
    ///
    /// # Safety
    ///
    /// B'differenza minn `RefCell::borrow`, dan il-metodu mhuwiex sigur għax ma jirritornax `Ref`, u b'hekk iħalli l-bandiera tas-self mhux mittiefsa.
    /// Tissellef b'mod reċiproku l-`RefCell` waqt li r-referenza mogħtija b'dan il-metodu hija ħajja hija mġieba mhux definita.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SIGURTÀ: Aħna niċċekkjaw li ħadd issa ma jikteb b'mod attiv issa, imma hekk hu
            // ir-responsabbiltà ta 'min iċempel biex jiżgura li ħadd ma jikteb sakemm ir-referenza mibgħuta lura ma tibqax tintuża.
            // Ukoll, `self.value.get()` jirreferi għall-valur li għandu `self` u għalhekk huwa garantit li jkun validu għall-ħajja ta `self`.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Jieħu l-valur imgeżwer, u jħalli `Default::default()` f'postha.
    ///
    /// # Panics
    ///
    /// Panics jekk il-valur huwa attwalment misluf.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics jekk il-valur huwa attwalment misluf b'mod reċiproku.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Toħloq `RefCell<T>`, bil-valur `Default` għal T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics jekk il-valur f `RefCell` huwa attwalment issellef.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Żieda ta 'self tista' tirriżulta f'valur li ma jaqrax (<=0) f'dawn il-każijiet:
            // 1. Kien <0, jiġifieri hemm min jissellef bil-miktub, allura ma nistgħux inħallu jissellef moqri minħabba r-regoli ta 'aliasing ta' referenza ta 'Rust
            // 2.
            // Kien isize::MAX (l-ammont massimu ta 'qari jissellef) u nfexxa f isize::MIN (l-ammont massimu ta' kitba tissellef) u allura ma nistgħux inħallu jissellef addizzjonali moqri għax isize ma jistax jirrappreżenta tant li jissellef moqri (dan jista 'jiġri biss jekk inti mem::forget aktar minn ammont kostanti żgħir ta 'Ref, li mhix prattika tajba)
            //
            //
            //
            //
            None
        } else {
            // Żieda ta 'self tista' tirriżulta f'valur ta 'qari (> 0) f'dawn il-każijiet:
            // 1. Kien=0, jiġifieri ma kienx issellef, u qed nieħdu l-ewwel qari jissellef
            // 2. Kien> 0 u <isize::MAX, jiġifieri
            // kien hemm jissellef moqri, u isize huwa kbir biżżejjed biex jirrappreżenta li wieħed jissellef moqri ieħor
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Peress li dan ir-Ref jeżisti, nafu li l-bandiera tissellef hija tissellef qari.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Tipprevjeni li l-bank li jissellef joħroġ f'self bil-miktub.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Kebbeb referenza mislufa għal valur f'kaxxa `RefCell`.
/// Tip ta `tgeżwir għal valur misluf b`mod immutabbli minn `RefCell<T>`.
///
/// Ara x-[module-level documentation](self) għal aktar.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Ikkopja `Ref`.
    ///
    /// Ix-`RefCell` huwa diġà misluf b`mod immutabbli, allura dan ma jistax ifalli.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `Ref::clone(...)`.
    /// Implimentazzjoni `Clone` jew metodu jinterferixxu ma 'l-użu mifrux ta' `r.borrow().clone()` biex ikklona l-kontenut ta `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Jagħmel `Ref` ġdid għal komponent tad-dejta mislufa.
    ///
    /// Ix-`RefCell` huwa diġà misluf b`mod immutabbli, allura dan ma jistax ifalli.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `Ref::map(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Jagħmel `Ref` ġdid għal komponent fakultattiv tad-dejta mislufa.
    /// Il-gwardja oriġinali tingħata lura bħala `Err(..)` jekk l-għeluq jirritorna `None`.
    ///
    /// Ix-`RefCell` huwa diġà misluf b`mod immutabbli, allura dan ma jistax ifalli.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `Ref::filter_map(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Jaqsam `Ref` f'diversi "Ref" għal komponenti differenti tad-dejta mislufa.
    ///
    /// Ix-`RefCell` huwa diġà misluf b`mod immutabbli, allura dan ma jistax ifalli.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `Ref::map_split(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Ikkonverti f'referenza għad-dejta sottostanti.
    ///
    /// Ix-`RefCell` sottostanti qatt ma jista 'jerġa' jiġi misluf b'mod reċiproku u dejjem jidher dejjem issellef b'mod immutabbli.
    ///
    /// Mhix idea tajba li tnixxi aktar minn numru kostanti ta 'referenzi.
    /// Ix-`RefCell` jista 'jerġa' jiġi misluf b'mod immutabbli jekk ikun seħħ biss numru iżgħar ta 'tnixxijiet b'kollox.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `Ref::leak(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Billi ninsew dan ir-Ref nassiguraw li l-bank li jissellef fir-RefCell ma jistax imur lura għal MHUX UŻAT matul il-ħajja `'b`.
        // L-issettjar mill-ġdid tal-istat tat-traċċar tar-referenza jkun jeħtieġ referenza unika għar-RefCell misluf.
        // Ma jistgħux jinħolqu aktar referenzi li jistgħu jinbidlu miċ-ċellula oriġinali.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Jagħmel `RefMut` ġdid għal komponent tad-dejta mislufa, eż., Varjant enum.
    ///
    /// Ix-`RefCell` huwa diġà misluf b'mod reċiproku, allura dan ma jistax ifalli.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `RefMut::map(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): jiffissaw il-verifika tas-self
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Jagħmel `RefMut` ġdid għal komponent fakultattiv tad-dejta mislufa.
    /// Il-gwardja oriġinali tingħata lura bħala `Err(..)` jekk l-għeluq jirritorna `None`.
    ///
    /// Ix-`RefCell` huwa diġà misluf b'mod reċiproku, allura dan ma jistax ifalli.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `RefMut::filter_map(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): jiffissaw il-verifika tas-self
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SIGURTÀ: il-funzjoni żżomm referenza esklussiva għat-tul ta 'żmien
        // tas-sejħa tiegħu permezz ta `orig`, u l-pointer huwa referenzjat biss ġewwa s-sejħa tal-funzjoni li qatt ma jippermetti li r-referenza esklussiva taħrab.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SIGURTÀ: l-istess bħal hawn fuq.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Jaqsam `RefMut` f'diversi `RefMut`s għal komponenti differenti tad-dejta mislufa.
    ///
    /// Ix-`RefCell` sottostanti se jibqa 'misluf b'mod reċiproku sakemm it-tnejn li huma rritornati' RefMut`s joħorġu mill-ambitu.
    ///
    /// Ix-`RefCell` huwa diġà misluf b'mod reċiproku, allura dan ma jistax ifalli.
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `RefMut::map_split(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Ikkonverti f'referenza li tista 'tinbidel għad-dejta sottostanti.
    ///
    /// Ix-`RefCell` sottostanti ma jistax jiġi misluf mill-ġdid u dejjem jidher diġà misluf b'mod reċiproku, u b'hekk ir-referenza mibgħuta lura tkun l-unika għall-intern.
    ///
    ///
    /// Din hija funzjoni assoċjata li teħtieġ li tintuża bħala `RefMut::leak(...)`.
    /// Metodu jinterferixxi ma 'metodi ta' l-istess isem fuq il-kontenut ta `RefCell` użat permezz ta' `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Billi ninsew dan il-BorrowRefMut niżguraw li l-bank li jissellef fir-RefCell ma jistax imur lura għal MHUX UŻAT matul il-ħajja `'b`.
        // L-issettjar mill-ġdid tal-istat tat-traċċar tar-referenza jkun jeħtieġ referenza unika għar-RefCell misluf.
        // Ma jistgħux jinħolqu aktar referenzi miċ-ċellula oriġinali f'dak il-ħajja, u b'hekk is-self kurrenti huwa l-unika referenza għall-ħajja li jifdal.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: B'differenza minn BorrowRefMut::clone, ġdid huwa msejjaħ biex joħloq l-inizjali
        // referenza li tista 'tinbidel, u għalhekk bħalissa m'għandux ikun hemm referenzi eżistenti.
        // Għalhekk, filwaqt li l-klonu jżid ir-refcount li jista 'jinbidel, hawnhekk aħna espliċitament inħallu biss li mmorru minn UNUSED għal UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Ikklona `BorrowRefMut`.
    //
    // Dan huwa validu biss jekk kull `BorrowRefMut` jintuża biex jittraċċa referenza li tista 'tinbidel għal firxa distinta u mhux sovrapposta tal-oġġett oriġinali.
    //
    // Dan mhux fi impl Clone sabiex il-kodiċi ma jsejjaħx dan b'mod impliċitu.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Tipprevjeni li l-bank tas-self jissaffi.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// Tip ta 'tgeżwir għal valur misluf b'mod reċiproku minn `RefCell<T>`.
///
/// Ara x-[module-level documentation](self) għal aktar.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Il-qalba primittiva għall-mutabilità interna f'Rust.
///
/// Jekk għandek referenza `&T`, allura normalment f'Rust il-kompilatur iwettaq ottimizzazzjonijiet ibbażati fuq l-għarfien li `&T` jindika dejta immutabbli.Il-mutazzjoni ta 'dik id-dejta, pereżempju permezz ta' psewdonimu jew billi t-trasmutazzjoni ta `&T` f `&mut T`, hija meqjusa bħala mġieba mhux definita.
/// `UnsafeCell<T>` opt-out tal-garanzija ta 'l-immutabilità għal `&T`: referenza maqsuma `&UnsafeCell<T>` tista' tindika data li qed tiġi mutata.Dan jissejjaħ "interior mutability".
///
/// It-tipi l-oħra kollha li jippermettu l-mutabilità interna, bħal `Cell<T>` u `RefCell<T>`, internament jużaw `UnsafeCell` biex jagħlqu d-dejta tagħhom.
///
/// Innota li l-garanzija tal-immutabbiltà biss għal referenzi kondiviżi hija affettwata minn `UnsafeCell`.Il-garanzija tal-uniċità għal referenzi li jistgħu jinbidlu mhix affettwata.M'hemm l-ebda *mod* legali biex tikseb aliasing `&mut`, lanqas ma `UnsafeCell<T>`.
///
/// L-API `UnsafeCell` innifisha hija teknikament sempliċi ħafna: [`.get()`] jagħtik pointer nej `*mut T` għall-kontenut tiegħu.Huwa sa _you_ bħala d-disinjatur tal-astrazzjoni li juża dak il-pointer nej b'mod korrett.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// Ir-regoli preċiżi ta 'aliasing Rust huma kemmxejn fluss, iżda l-punti ewlenin mhumiex kontroversjali:
///
/// - Jekk toħloq referenza sikura b `'a` tul il-ħajja (jew referenza `&T` jew `&mut T`) li hija aċċessibbli b'kodiċi sikur (per eżempju, għax irritornaha), allura m'għandekx taċċessa d-dejta b'xi mod li tikkontradixxi dik ir-referenza għall-bqija ta `'a`.
/// Pereżempju, dan ifisser li jekk tieħu `*mut T` minn `UnsafeCell<T>` u titfa 'fuq `&T`, allura d-data f `T` għandha tibqa' immutabbli (modulo kwalunkwe data `UnsafeCell` misjuba fi `T`, naturalment) sakemm tiskadi l-ħajja ta 'dik ir-referenza.
/// Bl-istess mod, jekk toħloq referenza `&mut T` li tinħareġ għal kodiċi sigur, allura m'għandekx taċċessa d-dejta fi ħdan `UnsafeCell` sakemm tiskadi dik ir-referenza.
///
/// - F'kull ħin, trid tevita t-tiġrijiet tad-dejta.Jekk ħjut multipli għandhom aċċess għall-istess `UnsafeCell`, allura kwalunkwe kitba għandu jkollha relazzjoni xierqa ta 'jiġri qabel l-aċċessi l-oħra kollha (jew tuża l-atomiċi).
///
/// Biex tassisti fit-tfassil xieraq, ix-xenarji li ġejjin huma ddikjarati espliċitament legali għal kodiċi b'kamin wieħed:
///
/// 1. Referenza `&T` tista 'tiġi rilaxxata għal kodiċi sigur u hemm tista' teżisti flimkien ma 'referenzi oħra `&T`, iżda mhux b `&mut T`
///
/// 2. Referenza `&mut T` tista 'tiġi rilaxxata għal kodiċi sigur sakemm la `&mut T` u lanqas `&T` ma jeżistu flimkien magħha.`&mut T` għandu dejjem ikun uniku.
///
/// Innota li waqt li tibdel il-kontenut ta `&UnsafeCell<T>` (anke waqt li `&UnsafeCell<T>` referenzi oħra jsejħu alias iċ-ċellula) hija ok (sakemm tinforza l-invariants ta' hawn fuq b'xi mod ieħor), xorta waħda mġieba mhix definita li jkollok psewdonimi `&mut UnsafeCell<T>` multipli.
/// Jiġifieri, `UnsafeCell` huwa tgeżwir iddisinjat biex ikollu interazzjoni speċjali ma _shared_ accesses (_i.e._, permezz ta' referenza `&UnsafeCell<_>`);m'hemm l-ebda maġija meta tkun qed tittratta ma _exclusive_ accesses (_e.g._, permezz ta' `&mut UnsafeCell<_>`): la ċ-ċellola u lanqas il-valur imgeżwer ma jistgħu jiġu magħżula għat-tul ta 'dak is-self `&mut`.
///
/// Dan jintwera mill-aċċessur [`.get_mut()`], li huwa _safe_ getter li jagħti `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Hawn hu eżempju li juri kif immutat sew il-kontenut ta `UnsafeCell<_>` minkejja li hemm referenzi multipli li jgħaqqdu ċ-ċellola:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Ikseb referenzi multipli/maqsuma għall-istess `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SIGURTÀ: f'dan l-iskop m'hemm l-ebda referenza oħra għall-kontenut ta '"x",
///     // mela tagħna huwa effettivament uniku.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- tissellef-+
///     *p1_exclusive += 27; // |
/// } // <---------- ma tistax tmur lil hinn minn dan il-punt -------------------+
///
/// unsafe {
///     // SIGURTÀ: f'dan l-iskop ħadd ma jistenna li jkollu aċċess esklussiv għall-kontenut ta '"x",
///     // sabiex inkunu nistgħu jkollna aċċess multipli maqsuma fl-istess ħin.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// L-eżempju li ġej juri l-fatt li aċċess esklussiv għal `UnsafeCell<T>` jimplika aċċess esklussiv għax-`T` tiegħu:
///
/// ```rust
/// #![forbid(unsafe_code)] // b'aċċessi esklussivi,
///                         // `UnsafeCell` huwa tgeżwir trasparenti mingħajr op, allura m'hemmx bżonn għal `unsafe` hawn.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Ikseb referenza unika għal `x` ikkontrollata fil-ħin tal-kumpilazzjoni.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // B'referenza esklussiva, nistgħu nbiddlu l-kontenut b'xejn.
/// *p_unique.get_mut() = 0;
/// // Jew, ekwivalenti:
/// x = UnsafeCell::new(0);
///
/// // Meta aħna stess il-valur, nistgħu noħorġu l-kontenut b'xejn.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Jibni istanza ġdida ta `UnsafeCell` li se tgeżwer il-valur speċifikat.
    ///
    ///
    /// L-aċċess kollu għall-valur intern permezz tal-metodi huwa `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Ikxef il-valur.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Tikseb pointer li jista 'jinbidel għall-valur imgeżwer.
    ///
    /// Dan jista 'jintefa' fuq pointer ta 'kwalunkwe tip.
    /// Żgura li l-aċċess huwa uniku (l-ebda referenzi attivi, li jistgħu jinbidlu jew le) meta tkun qed titfa 'fuq `&mut T`, u kun żgur li m'hemmx mutazzjonijiet jew psewdonimi li jistgħu jinbidlu meta jkunu qed jitfgħu fuq `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Nistgħu sempliċement nitfgħu l-pointer minn `UnsafeCell<T>` għal `T` minħabba #[repr(transparent)].
        // Dan jisfrutta l-istatus speċjali ta 'libstd, m'hemm l-ebda garanzija għall-kodiċi tal-utent li dan jaħdem f'verżjonijiet future tal-kompilatur!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Jirritorna referenza li tista 'tinbidel għad-dejta sottostanti.
    ///
    /// Din is-sejħa tissellef ix-`UnsafeCell` b'mod mutabbli (fil-ħin tal-kumpilazzjoni) li jiggarantixxi li aħna għandna l-unika referenza.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Tikseb pointer li jista 'jinbidel għall-valur imgeżwer.
    /// Id-differenza għal [`get`] hija li din il-funzjoni taċċetta pointer nej, li huwa utli biex tevita l-ħolqien ta 'referenzi temporanji.
    ///
    /// Ir-riżultat jista 'jintefa' fuq pointer ta 'kwalunkwe tip.
    /// Żgura li l-aċċess huwa uniku (l-ebda referenzi attivi, li jistgħu jinbidlu jew le) meta tkun qed titfa 'fuq `&mut T`, u kun żgur li m'hemmx mutazzjonijiet jew psewdonimi li jistgħu jinbidlu meta jkunu qed jitfgħu fuq `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// L-inizjalizzazzjoni gradwali ta `UnsafeCell` teħtieġ `raw_get`, billi s-sejħa għal `get` tkun teħtieġ il-ħolqien ta' referenza għal dejta mhux inizjalizzata:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Nistgħu sempliċement nitfgħu l-pointer minn `UnsafeCell<T>` għal `T` minħabba #[repr(transparent)].
        // Dan jisfrutta l-istatus speċjali ta 'libstd, m'hemm l-ebda garanzija għall-kodiċi tal-utent li dan jaħdem f'verżjonijiet future tal-kompilatur!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Toħloq `UnsafeCell`, bil-valur `Default` għal T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}