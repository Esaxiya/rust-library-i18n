use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Jirritorna `true` jekk il-pointer huwa null.
    ///
    /// Innota li t-tipi mhux imdaqqsa għandhom ħafna indikaturi null possibbli, billi huwa kkunsidrat biss il-pointer tad-dejta mhux ipproċessata, mhux it-tul tagħhom, il-mejda, eċċ.
    /// Għalhekk, żewġ indikaturi li huma nulli xorta jistgħu ma jitqabblux daqs xulxin.
    ///
    /// ## Imġieba waqt l-evalwazzjoni tal-kost
    ///
    /// Meta tintuża din il-funzjoni waqt l-evalwazzjoni tal-kost, tista 'tirritorna `false` għal indikaturi li jirriżultaw nulli fil-ħin tal-eżekuzzjoni.
    /// Speċifikament, meta pointer għal xi memorja jiġi kkumpensat lil hinn mill-limiti tiegħu b'tali mod li l-pointer li jirriżulta jkun null, il-funzjoni xorta tibgħat lura `false`.
    ///
    /// M'hemm l-ebda mod biex CTFE tkun taf il-pożizzjoni assoluta ta 'dik il-memorja, allura ma nistgħux ngħidu jekk il-pointer huwiex null jew le.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Qabbel permezz ta 'mitfugħa ma' pointer irqiq, allura l-indikaturi tax-xaħam qed jikkunsidraw biss il-parti "data" tagħhom għal null.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Titfa 'fuq pointer ta' tip ieħor.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Iddekomponi pointer (possibilment wiesa ') f'komponenti ta' l-indirizz u tal-metadejta.
    ///
    /// Il-pointer jista 'jiġi rikostruwit aktar tard b [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Jirritorna `None` jekk il-pointer huwa null, jew inkella jirritorna referenza kondiviża għall-valur imgeżwer f `Some`.Jekk il-valur jista 'jkun mhux inizjalizzat, minflok għandu jintuża [`as_uninit_ref`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li *jew* il-pointer huwa NULL *jew* dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun allinjat sewwa.
    ///
    /// * Għandu jkun "dereferencable" fis-sens definit f [the module documentation].
    ///
    /// * Il-pointer għandu jindika istanza inizjalizzata ta `T`.
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer tindika m'għandhiex issir mutazzjoni (ħlief ġewwa `UnsafeCell`).
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    /// (Il-parti dwar l-inizjalizzazzjoni għadha mhix deċiża għal kollox, iżda sakemm tkun, l-uniku approċċ sigur huwa li jiġi żgurat li huma tabilħaqq inizjalizzati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Verżjoni mingħajr kontroll
    ///
    /// Jekk inti żgur li l-indikatur qatt ma jista 'jkun null u qed tfittex xi tip ta' `as_ref_unchecked` li jirritorna l-`&T` minflok `Option<&T>`, kun af li tista 'tneħħi l-indikatur direttament.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` huwa validu
        // għal referenza jekk mhix nulla.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Jirritorna `None` jekk il-pointer huwa null, jew inkella jirritorna referenza kondiviża għall-valur imgeżwer f `Some`.
    /// B'kuntrast ma [`as_ref`], dan ma jeħtieġx li l-valur irid jiġi inizjalizzat.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li *jew* il-pointer huwa NULL *jew* dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun allinjat sewwa.
    ///
    /// * Għandu jkun "dereferencable" fis-sens definit f [the module documentation].
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer tindika m'għandhiex issir mutazzjoni (ħlief ġewwa `UnsafeCell`).
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jissodisfa l-
        // rekwiżiti għal referenza.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Ikkalkula l-offset minn pointer.
    ///
    /// `count` huwa f'unitajiet ta 'T;eż. `count` ta '3 jirrappreżenta offset tal-pointer ta' bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin, ir-riżultat huwa Imġieba Mhux Definita:
    ///
    /// * Kemm il-pointer tal-bidu kif ukoll dak li jirriżulta għandhom ikunu jew f'limiti jew byte wieħed wara t-tmiem tal-istess oġġett allokat.
    /// Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
    ///
    /// * L-offset ikkalkulat,**f'bytes**, ma jistax ifur `isize`.
    ///
    /// * L-offset li jinsab fil-limiti ma jistax jistrieħ fuq "wrapping around" l-ispazju tal-indirizz.Jiġifieri, is-somma ta 'preċiżjoni infinita,**f'bytes** għandha tidħol f'użu.
    ///
    /// Il-kompilatur u l-librerija standard ġeneralment jippruvaw jiżguraw li allokazzjonijiet qatt ma jilħqu daqs fejn offset huwa ta 'tħassib.
    /// Pereżempju, `Vec` u `Box` jiżguraw li qatt ma jallokaw aktar minn bytes `isize::MAX`, allura `vec.as_ptr().add(vec.len())` huwa dejjem sigur.
    ///
    /// Ħafna mill-pjattaformi fundamentalment lanqas biss jistgħu jibnu tali allokazzjoni.
    /// Pereżempju, l-ebda pjattaforma magħrufa ta '64-bit ma tista' qatt isservi talba għal 2 <sup>63</sup> byte minħabba limitazzjonijiet ta 'tabella tal-paġna jew qsim tal-ispazju tal-indirizz.
    /// Madankollu, xi pjattaformi 32-bit u 16-bit jistgħu jservu b'suċċess talba għal aktar minn bytes `isize::MAX` b'affarijiet bħall-Estensjoni tal-Indirizz Fiżiku.
    ///
    /// Bħala tali, il-memorja akkwistata direttament minn allokaturi jew fajls immappjati tal-memorja *tista '* tkun kbira wisq biex tiġi mmaniġġjata b'din il-funzjoni.
    ///
    /// Ikkunsidra li tuża [`wrapping_offset`] minflok jekk dawn il-limitazzjonijiet huma diffiċli biex tissodisfahom.
    /// L-uniku vantaġġ ta 'dan il-metodu huwa li jippermetti ottimizzazzjonijiet tal-kompilatur aktar aggressivi.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Ikkalkula l-offset minn pointer billi tuża t-tgeżwir aritmetiku.
    ///
    /// `count` huwa f'unitajiet ta 'T;eż. `count` ta '3 jirrappreżenta offset tal-pointer ta' bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Din l-operazzjoni nnifisha hija dejjem sikura, iżda l-użu tal-pointer li jirriżulta mhuwiex.
    ///
    /// Il-pointer li jirriżulta jibqa 'mwaħħal mal-istess oġġett allokat li `self` jindika.
    /// Jista '*ma* jintuża biex ikollok aċċess għal oġġett allokat differenti.Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
    ///
    /// Fi kliem ieħor, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ma* jagħmilx lil `z` l-istess bħal `y` anke jekk nassumu li `T` għandu daqs `1` u m'hemm l-ebda overflow: `z` għadu mwaħħal ma 'l-oġġett `x` huwa marbut miegħu, u d-differenzjar huwa Imġieba Mhux Definita sakemm `x` u Punt `y` fl-istess oġġett allokat.
    ///
    /// Meta mqabbel ma [`offset`], dan il-metodu bażikament idewwem il-ħtieġa li tibqa' fl-istess oġġett allokat: [`offset`] huwa Imġieba Mhux Definita immedjata meta taqsam il-konfini tal-oġġett;`wrapping_offset` jipproduċi pointer iżda xorta jwassal għal Imġieba Mhux Iddefinita jekk pointer jiġi dereferenzjat meta jkun barra mill-limiti tal-oġġett li huwa mwaħħal miegħu.
    /// [`offset`] jista 'jiġi ottimizzat aħjar u għalhekk huwa preferibbli f'kodiċi sensittiv għall-prestazzjoni.
    ///
    /// Il-kontroll imdewwem jikkunsidra biss il-valur tal-pointer li ġie dereferenzjat, mhux il-valuri intermedji użati waqt il-komputazzjoni tar-riżultat finali.
    /// Pereżempju, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` huwa dejjem l-istess bħal `x`.Fi kliem ieħor, huwa permess li tħalli l-oġġett allokat u mbagħad terġa 'ddaħħal aktar tard.
    ///
    /// Jekk għandek bżonn taqsam il-konfini tal-oġġett, itfa 'l-pointer għal numru sħiħ u għamel l-aritmetika hemmhekk.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // Iterata billi tuża pointer nej f'żidiet ta 'żewġ elementi
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Dan il-linja jistampa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIGURTÀ: l-intrinsiku `arith_offset` m'għandux prerekwiżiti biex jissejjaħ.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Ikkalkula d-distanza bejn żewġ indikaturi.Il-valur ritornat huwa f'unitajiet ta 'T: id-distanza f'bytes hija diviża b `mem::size_of::<T>()`.
    ///
    /// Din il-funzjoni hija l-invers ta [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin, ir-riżultat huwa Imġieba Mhux Definita:
    ///
    /// * Kemm il-pointer tal-bidu kif ukoll dak l-ieħor iridu jkunu jew f'limiti jew byte wieħed wara t-tmiem tal-istess oġġett allokat.
    /// Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
    ///
    /// * Iż-żewġ indikaturi għandhom ikunu *derivati minn* pointer għall-istess oġġett.
    ///   (Ara hawn taħt għal eżempju.)
    ///
    /// * Id-distanza bejn l-indikaturi, f'bytes, għandha tkun multiplu eżatt tad-daqs ta `T`.
    ///
    /// * Id-distanza bejn l-indikaturi,**f'bytes**, ma tistax tfur `isize`.
    ///
    /// * Id-distanza li tkun fil-limiti ma tistax tistrieħ fuq "wrapping around" l-ispazju tal-indirizz.
    ///
    /// It-tipi ta 'Rust qatt ma huma akbar minn allokazzjonijiet ta' `isize::MAX` u Rust qatt ma jdawru l-ispazju tal-indirizz, għalhekk żewġ indikaturi f'xi valur ta 'kwalunkwe tip ta' Rust `T` dejjem jissodisfaw l-aħħar żewġ kundizzjonijiet.
    ///
    /// Il-librerija standard ġeneralment tiżgura wkoll li l-allokazzjonijiet qatt ma jilħqu daqs fejn offset huwa ta 'tħassib.
    /// Pereżempju, `Vec` u `Box` jiżguraw li qatt ma jallokaw aktar minn bytes `isize::MAX`, allura `ptr_into_vec.offset_from(vec.as_ptr())` dejjem jissodisfa l-aħħar żewġ kundizzjonijiet.
    ///
    /// Ħafna mill-pjattaformi fundamentalment lanqas biss jistgħu jibnu allokazzjoni daqshekk kbira.
    /// Pereżempju, l-ebda pjattaforma magħrufa ta '64-bit ma tista' qatt isservi talba għal 2 <sup>63</sup> byte minħabba limitazzjonijiet ta 'tabella tal-paġna jew qsim tal-ispazju tal-indirizz.
    /// Madankollu, xi pjattaformi 32-bit u 16-bit jistgħu jservu b'suċċess talba għal aktar minn bytes `isize::MAX` b'affarijiet bħall-Estensjoni tal-Indirizz Fiżiku.
    /// Bħala tali, il-memorja akkwistata direttament minn allokaturi jew fajls immappjati tal-memorja *tista '* tkun kbira wisq biex tiġi mmaniġġjata b'din il-funzjoni.
    /// (Innota li [`offset`] u [`add`] għandhom ukoll limitazzjoni simili u għalhekk ma jistgħux jintużaw lanqas fuq allokazzjonijiet kbar bħal dawn.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Din il-funzjoni panics jekk `T` hija Tip ta 'Daqs Żero ("ZST").
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// Użu * mhux korrett:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Agħmel ptr2_other "alias" ta ptr2, iżda derivat minn ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Peress li ptr2_other u ptr2 huma derivati minn indikaturi għal oġġetti differenti, il-kalkolu tal-offset tagħhom huwa mġieba mhux definita, avolja jindikaw l-istess indirizz!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Imġieba Mhux Definita
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Jirritorna jekk żewġ indikaturi humiex garantiti li huma ugwali.
    ///
    /// Waqt l-eżekuzzjoni din il-funzjoni ġġib ruħha bħal `self == other`.
    /// Madankollu, f'xi kuntesti (eż., Evalwazzjoni tal-ħin tal-kumpilazzjoni), mhux dejjem huwa possibbli li tiġi ddeterminata l-ugwaljanza ta 'żewġ indikaturi, għalhekk din il-funzjoni tista' terġa 'tirritorna `false` għal indikaturi li aktar tard fil-fatt jirriżultaw li huma ugwali.
    ///
    /// Imma meta tirritorna `true`, l-indikaturi huma garantiti li jkunu ndaqs.
    ///
    /// Din il-funzjoni hija l-mera ta [`guaranteed_ne`], iżda mhux l-invers tagħha.Hemm paraguni tal-pointer li għalihom iż-żewġ funzjonijiet jirritornaw `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Il-valur tar-ritorn jista 'jinbidel skont il-verżjoni tal-kompilatur u kodiċi mhux sikur jista' ma joqgħodx fuq ir-riżultat ta 'din il-funzjoni għas-saħħa.
    /// Huwa ssuġġerit li tintuża din il-funzjoni biss għal ottimizzazzjonijiet tal-prestazzjoni fejn il-valuri ta 'ritorn ta' `false` foloz minn din il-funzjoni ma jaffettwawx ir-riżultat, iżda biss il-prestazzjoni.
    /// Il-konsegwenzi tal-użu ta 'dan il-metodu biex il-kodiċi tal-ħin ta' eżekuzzjoni u tal-kumpilazzjoni jġibu ruħhom b'mod differenti ma ġewx esplorati.
    /// Dan il-metodu m'għandux jintuża biex jintroduċi tali differenzi, u m'għandux ikun stabbilizzat ukoll qabel ma jkollna fehim aħjar ta 'din il-kwistjoni.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Jirritorna jekk żewġ indikaturi humiex garantiti li mhumiex ugwali.
    ///
    /// Waqt l-eżekuzzjoni din il-funzjoni ġġib ruħha bħal `self != other`.
    /// Madankollu, f'xi kuntesti (eż., Evalwazzjoni tal-ħin tal-kumpilazzjoni), mhux dejjem huwa possibbli li tiġi ddeterminata l-inugwaljanza ta 'żewġ indikaturi, għalhekk din il-funzjoni tista' terġa 'tirritorna `false` għal indikaturi li aktar tard fil-fatt jirriżultaw inugwali.
    ///
    /// Imma meta tirritorna `true`, l-indikaturi huma garantiti li mhumiex ugwali.
    ///
    /// Din il-funzjoni hija l-mera ta [`guaranteed_eq`], iżda mhux l-invers tagħha.Hemm paraguni tal-pointer li għalihom iż-żewġ funzjonijiet jirritornaw `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Il-valur tar-ritorn jista 'jinbidel skont il-verżjoni tal-kompilatur u kodiċi mhux sikur jista' ma joqgħodx fuq ir-riżultat ta 'din il-funzjoni għas-saħħa.
    /// Huwa ssuġġerit li tintuża din il-funzjoni biss għal ottimizzazzjonijiet tal-prestazzjoni fejn il-valuri ta 'ritorn ta' `false` foloz minn din il-funzjoni ma jaffettwawx ir-riżultat, iżda biss il-prestazzjoni.
    /// Il-konsegwenzi tal-użu ta 'dan il-metodu biex il-kodiċi tal-ħin ta' eżekuzzjoni u tal-kumpilazzjoni jġibu ruħhom b'mod differenti ma ġewx esplorati.
    /// Dan il-metodu m'għandux jintuża biex jintroduċi tali differenzi, u m'għandux ikun stabbilizzat ukoll qabel ma jkollna fehim aħjar ta 'din il-kwistjoni.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Ikkalkula l-offset minn pointer (konvenjenza għal `.offset(count as isize)`).
    ///
    /// `count` huwa f'unitajiet ta 'T;eż. `count` ta '3 jirrappreżenta offset tal-pointer ta' bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin, ir-riżultat huwa Imġieba Mhux Definita:
    ///
    /// * Kemm il-pointer tal-bidu kif ukoll dak li jirriżulta għandhom ikunu jew f'limiti jew byte wieħed wara t-tmiem tal-istess oġġett allokat.
    /// Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
    ///
    /// * L-offset ikkalkulat,**f'bytes**, ma jistax ifur `isize`.
    ///
    /// * L-offset li jinsab fil-limiti ma jistax jistrieħ fuq "wrapping around" l-ispazju tal-indirizz.Jiġifieri, is-somma ta 'preċiżjoni infinita għandha tidħol f `usize`.
    ///
    /// Il-kompilatur u l-librerija standard ġeneralment jippruvaw jiżguraw li allokazzjonijiet qatt ma jilħqu daqs fejn offset huwa ta 'tħassib.
    /// Pereżempju, `Vec` u `Box` jiżguraw li qatt ma jallokaw aktar minn bytes `isize::MAX`, allura `vec.as_ptr().add(vec.len())` huwa dejjem sigur.
    ///
    /// Ħafna mill-pjattaformi fundamentalment lanqas biss jistgħu jibnu tali allokazzjoni.
    /// Pereżempju, l-ebda pjattaforma magħrufa ta '64-bit ma tista' qatt isservi talba għal 2 <sup>63</sup> byte minħabba limitazzjonijiet ta 'tabella tal-paġna jew qsim tal-ispazju tal-indirizz.
    /// Madankollu, xi pjattaformi 32-bit u 16-bit jistgħu jservu b'suċċess talba għal aktar minn bytes `isize::MAX` b'affarijiet bħall-Estensjoni tal-Indirizz Fiżiku.
    ///
    /// Bħala tali, il-memorja akkwistata direttament minn allokaturi jew fajls immappjati tal-memorja *tista '* tkun kbira wisq biex tiġi mmaniġġjata b'din il-funzjoni.
    ///
    /// Ikkunsidra li tuża [`wrapping_add`] minflok jekk dawn il-limitazzjonijiet huma diffiċli biex tissodisfahom.
    /// L-uniku vantaġġ ta 'dan il-metodu huwa li jippermetti ottimizzazzjonijiet tal-kompilatur aktar aggressivi.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Ikkalkula l-offset minn pointer (konvenjenza għal '. Offset ((jgħodd bħala isize).wrapping_neg())`).
    ///
    /// `count` huwa f'unitajiet ta 'T;eż. `count` ta '3 jirrappreżenta offset tal-pointer ta' bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin, ir-riżultat huwa Imġieba Mhux Definita:
    ///
    /// * Kemm il-pointer tal-bidu kif ukoll dak li jirriżulta għandhom ikunu jew f'limiti jew byte wieħed wara t-tmiem tal-istess oġġett allokat.
    /// Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
    ///
    /// * L-offset ikkalkulat ma jistax jaqbeż `isize::MAX`**bytes**.
    ///
    /// * L-offset li jinsab fil-limiti ma jistax jistrieħ fuq "wrapping around" l-ispazju tal-indirizz.Jiġifieri, is-somma ta 'preċiżjoni infinita trid tidħol f'użu.
    ///
    /// Il-kompilatur u l-librerija standard ġeneralment jippruvaw jiżguraw li allokazzjonijiet qatt ma jilħqu daqs fejn offset huwa ta 'tħassib.
    /// Pereżempju, `Vec` u `Box` jiżguraw li qatt ma jallokaw aktar minn bytes `isize::MAX`, allura `vec.as_ptr().add(vec.len()).sub(vec.len())` huwa dejjem sigur.
    ///
    /// Ħafna mill-pjattaformi fundamentalment lanqas biss jistgħu jibnu tali allokazzjoni.
    /// Pereżempju, l-ebda pjattaforma magħrufa ta '64-bit ma tista' qatt isservi talba għal 2 <sup>63</sup> byte minħabba limitazzjonijiet ta 'tabella tal-paġna jew qsim tal-ispazju tal-indirizz.
    /// Madankollu, xi pjattaformi 32-bit u 16-bit jistgħu jservu b'suċċess talba għal aktar minn bytes `isize::MAX` b'affarijiet bħall-Estensjoni tal-Indirizz Fiżiku.
    ///
    /// Bħala tali, il-memorja akkwistata direttament minn allokaturi jew fajls immappjati tal-memorja *tista '* tkun kbira wisq biex tiġi mmaniġġjata b'din il-funzjoni.
    ///
    /// Ikkunsidra li tuża [`wrapping_sub`] minflok jekk dawn il-limitazzjonijiet huma diffiċli biex tissodisfahom.
    /// L-uniku vantaġġ ta 'dan il-metodu huwa li jippermetti ottimizzazzjonijiet tal-kompilatur aktar aggressivi.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Ikkalkula l-offset minn pointer billi tuża t-tgeżwir aritmetiku.
    /// (konvenjenza għal `.wrapping_offset(count as isize)`)
    ///
    /// `count` huwa f'unitajiet ta 'T;eż. `count` ta '3 jirrappreżenta offset tal-pointer ta' bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Din l-operazzjoni nnifisha hija dejjem sikura, iżda l-użu tal-pointer li jirriżulta mhuwiex.
    ///
    /// Il-pointer li jirriżulta jibqa 'mwaħħal mal-istess oġġett allokat li `self` jindika.
    /// Jista '*ma* jintuża biex ikollok aċċess għal oġġett allokat differenti.Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
    ///
    /// Fi kliem ieħor, `let z = x.wrapping_add((y as usize) - (x as usize))`*ma* jagħmilx lil `z` l-istess bħal `y` anke jekk nassumu li `T` għandu daqs `1` u m'hemmx overflow: `z` għadu mwaħħal ma 'l-oġġett `x` huwa mehmuż miegħu, u d-dereferenzjar huwa Imġieba Undefinita sakemm `x` u Punt `y` fl-istess oġġett allokat.
    ///
    /// Meta mqabbel ma [`add`], dan il-metodu bażikament idewwem ir-rekwiżit li tibqa' fl-istess oġġett allokat: [`add`] huwa Imġieba Mhux Definita immedjata meta taqsam il-konfini tal-oġġett;`wrapping_add` jipproduċi pointer iżda xorta jwassal għal Imġieba Mhux Iddefinita jekk pointer jiġi dereferenzjat meta jkun barra mill-limiti tal-oġġett li huwa mwaħħal miegħu.
    /// [`add`] jista 'jiġi ottimizzat aħjar u għalhekk huwa preferibbli f'kodiċi sensittiv għall-prestazzjoni.
    ///
    /// Il-kontroll imdewwem jikkunsidra biss il-valur tal-pointer li ġie dereferenzjat, mhux il-valuri intermedji użati waqt il-komputazzjoni tar-riżultat finali.
    /// Pereżempju, `x.wrapping_add(o).wrapping_sub(o)` huwa dejjem l-istess bħal `x`.Fi kliem ieħor, huwa permess li tħalli l-oġġett allokat u mbagħad terġa 'ddaħħal aktar tard.
    ///
    /// Jekk għandek bżonn taqsam il-konfini tal-oġġett, itfa 'l-pointer għal numru sħiħ u għamel l-aritmetika hemmhekk.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // Iterata billi tuża pointer nej f'żidiet ta 'żewġ elementi
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Dan il-linja jistampa "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Ikkalkula l-offset minn pointer billi tuża t-tgeżwir aritmetiku.
    /// (konvenjenza għal '.wrapping_offset ((jgħodd bħala isize).wrapping_neg())`)
    ///
    /// `count` huwa f'unitajiet ta 'T;eż. `count` ta '3 jirrappreżenta offset tal-pointer ta' bytes `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Din l-operazzjoni nnifisha hija dejjem sikura, iżda l-użu tal-pointer li jirriżulta mhuwiex.
    ///
    /// Il-pointer li jirriżulta jibqa 'mwaħħal mal-istess oġġett allokat li `self` jindika.
    /// Jista '*ma* jintuża biex ikollok aċċess għal oġġett allokat differenti.Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
    ///
    /// Fi kliem ieħor, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ma* jagħmilx lil `z` l-istess bħal `y` anke jekk nassumu li `T` għandu daqs `1` u m'hemmx overflow: `z` għadu mwaħħal ma 'l-oġġett `x` huwa mehmuż miegħu, u d-dereferenzjar huwa Imġieba Undefinita sakemm `x` u Punt `y` fl-istess oġġett allokat.
    ///
    /// Meta mqabbel ma [`sub`], dan il-metodu bażikament idewwem ir-rekwiżit li tibqa' fl-istess oġġett allokat: [`sub`] huwa Imġieba Mhux Definita immedjata meta taqsam il-konfini tal-oġġett;`wrapping_sub` jipproduċi pointer iżda xorta jwassal għal Imġieba Mhux Iddefinita jekk pointer jiġi dereferenzjat meta jkun barra mill-limiti tal-oġġett li huwa mwaħħal miegħu.
    /// [`sub`] jista 'jiġi ottimizzat aħjar u għalhekk huwa preferibbli f'kodiċi sensittiv għall-prestazzjoni.
    ///
    /// Il-kontroll imdewwem jikkunsidra biss il-valur tal-pointer li ġie dereferenzjat, mhux il-valuri intermedji użati waqt il-komputazzjoni tar-riżultat finali.
    /// Pereżempju, `x.wrapping_add(o).wrapping_sub(o)` huwa dejjem l-istess bħal `x`.Fi kliem ieħor, huwa permess li tħalli l-oġġett allokat u mbagħad terġa 'ddaħħal aktar tard.
    ///
    /// Jekk għandek bżonn taqsam il-konfini tal-oġġett, itfa 'l-pointer għal numru sħiħ u għamel l-aritmetika hemmhekk.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // Iterata billi tuża pointer mhux maħdum f'żidiet ta 'żewġ elementi (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Dan il-linja jistampa "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Issettja l-valur tal-pointer għal `ptr`.
    ///
    /// Fil-każ li `self` huwa pointer (fat) għal tip mhux imdaqqas, din l-operazzjoni taffettwa biss il-parti tal-pointer, filwaqt li għal indikaturi (thin) għal tipi ta 'daqs, dan għandu l-istess effett bħal assenjazzjoni sempliċi.
    ///
    /// Il-pointer li jirriżulta jkollu provenjenza ta `val`, jiġifieri, għal pointer tax-xaħam, din l-operazzjoni hija semantikament l-istess bħall-ħolqien ta' pointer tax-xaħam ġdid bil-valur tal-pointer tad-data ta `val` iżda l-metadata ta' `self`.
    ///
    ///
    /// # Examples
    ///
    /// Din il-funzjoni hija primarjament utli biex tippermetti l-aritmetika tal-indikatur tal-byte għaqli fuq indikaturi potenzjalment xaħmin:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // se jistampa "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SIGURTÀ: Fil-każ ta 'pointer irqiq, din l-operazzjoni hija identika
        // għal assenjazzjoni sempliċi.
        // Fil-każ ta 'pointer tax-xaħam, bl-implimentazzjoni attwali tat-tqassim tal-pointer tax-xaħam, l-ewwel qasam ta' tali pointer huwa dejjem il-pointer tad-dejta, li huwa assenjat bl-istess mod.
        //
        unsafe { *thin = val };
        self
    }

    /// Jaqra l-valur minn `self` mingħajr ma jiċċaqlaq.
    /// Dan iħalli l-memorja f `self` l-istess.
    ///
    /// Ara [`ptr::read`] għal tħassib dwar is-sigurtà u eżempji.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `read`.
        unsafe { read(self) }
    }

    /// Twettaq qari volatili tal-valur minn `self` mingħajr ma tmexxih.Dan iħalli l-memorja f `self` mhux mibdula.
    ///
    /// Operazzjonijiet volatili huma maħsuba biex jaġixxu fuq memorja I/O, u huma garantiti li ma jiġux eliditi jew ordnati mill-ġdid mill-kompilatur f'operazzjonijiet volatili oħra.
    ///
    ///
    /// Ara [`ptr::read_volatile`] għal tħassib dwar is-sigurtà u eżempji.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Jaqra l-valur minn `self` mingħajr ma jiċċaqlaq.
    /// Dan iħalli l-memorja f `self` l-istess.
    ///
    /// B'differenza minn `read`, il-pointer jista 'jkun mhux allinjat.
    ///
    /// Ara [`ptr::read_unaligned`] għal tħassib dwar is-sigurtà u eżempji.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Ikkopja bytes `count * size_of<T>` minn `self` sa `dest`.
    /// Is-sors u d-destinazzjoni jistgħu jikkoinċidu.
    ///
    /// NOTE: dan għandu l-istess * ordni ta 'argument bħal [`ptr::copy`].
    ///
    /// Ara [`ptr::copy`] għal tħassib dwar is-sigurtà u eżempji.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Ikkopja bytes `count * size_of<T>` minn `self` sa `dest`.
    /// Is-sors u d-destinazzjoni jistgħu *ma* jikkoinċidux.
    ///
    /// NOTE: dan għandu l-istess * ordni ta 'argument bħal [`ptr::copy_nonoverlapping`].
    ///
    /// Ara [`ptr::copy_nonoverlapping`] għal tħassib dwar is-sigurtà u eżempji.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Ikkalkula l-offset li jeħtieġ li jiġi applikat fuq il-pointer sabiex tagħmilha allinjata ma `align`.
    ///
    /// Jekk mhux possibbli li l-pointer jiġi allinjat, l-implimentazzjoni tirritorna `usize::MAX`.
    /// Huwa permissibbli għall-implimentazzjoni li *dejjem* tirritorna `usize::MAX`.
    /// Il-prestazzjoni tal-algoritmu tiegħek biss tista 'tiddependi fuq li tikseb offset użabbli hawn, mhux il-korrettezza tiegħu.
    ///
    /// L-offset huwa espress f'numru ta 'elementi `T`, u mhux bytes.Il-valur mibgħut lura jista 'jintuża mal-metodu `wrapping_add`.
    ///
    /// M'hemm l-ebda garanzija li t-tpaċija tal-pointer ma tfurx jew tmur lil hinn mill-allokazzjoni li l-pointer jindika fiha.
    ///
    /// Huwa f'idejn min iċempel li jiżgura li l-offset lura jkun korrett fit-termini kollha minbarra l-allinjament.
    ///
    /// # Panics
    ///
    /// Il-funzjoni panics jekk `align` mhix qawwa ta 'tnejn.
    ///
    /// # Examples
    ///
    /// Aċċess għal `u8` biswit bħal `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // filwaqt li l-pointer jista 'jkun allinjat permezz ta' `offset`, ikun jindika barra l-allokazzjoni
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SIGURTÀ: `align` ġie ċċekkjat biex ikun qawwa ta '2 hawn fuq
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Jirritorna t-tul ta 'porzjon nej.
    ///
    /// Il-valur mogħti lura huwa n-numru ta '**elementi**, mhux in-numru ta' bytes.
    ///
    /// Din il-funzjoni hija sigura, anke meta l-porzjon nej ma jistax jiġi mitfugħ f'referenza ta 'porzjon minħabba li l-pointer huwa null jew mhux allinjat.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIGURTÀ: dan huwa sigur għax `*const [T]` u `FatPtr<T>` għandhom l-istess tqassim.
            // `std` biss jista 'jagħmel din il-garanzija.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Jirritorna pointer nej għall-buffer tal-porzjon.
    ///
    /// Dan huwa ekwivalenti għall-ikkastjar ta `self` għal `*const T`, iżda aktar sigur għat-tip.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Jirritorna pointer mhux maħdum għal element jew subslice, mingħajr ma jagħmel verifika tal-limiti.
    ///
    /// Li ssejjaħ dan il-metodu b'indiċi barra mill-limiti jew meta `self` mhuwiex dereferenzjabbli huwa *[imġieba mhux definita]* anke jekk il-pointer li jirriżulta ma jintużax.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SIGURTÀ: min iċempel jiżgura li `self` huwa dereferenzjabbli u `index` fil-limiti.
        unsafe { index.get_unchecked(self) }
    }

    /// Jirritorna `None` jekk il-pointer huwa null, jew inkella jirritorna porzjon maqsum għall-valur imgeżwer f `Some`.
    /// B'kuntrast ma [`as_ref`], dan ma jeħtieġx li l-valur irid jiġi inizjalizzat.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li *jew* il-pointer huwa NULL *jew* dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun [valid] għal qari għal `ptr.len() * mem::size_of::<T>()` ħafna bytes, u għandu jkun allinjat sewwa.Dan ifisser b'mod partikolari:
    ///
    ///     * Il-firxa sħiħa tal-memorja ta 'din il-porzjon għandha tkun f'oġġett wieħed allokat!
    ///       Slices qatt ma jistgħu jinfirxu fuq oġġetti allokati multipli.
    ///
    ///     * Il-pointer għandu jkun allinjat anke għal flieli ta 'tul żero.
    ///     Raġuni waħda għal dan hija li l-ottimizzazzjonijiet tat-tqassim tal-enum jistgħu jiddependu fuq referenzi (inklużi flieli ta 'kwalunkwe tul) li jkunu allinjati u mhux nulli biex tiddistingwihom minn dejta oħra.
    ///
    ///     Tista 'tikseb pointer li jista' jintuża bħala `data` għal flieli ta 'tul żero billi tuża [`NonNull::dangling()`].
    ///
    /// * Id-daqs totali `ptr.len() * mem::size_of::<T>()` tal-porzjon m'għandux ikun akbar minn `isize::MAX`.
    ///   Ara d-dokumentazzjoni tas-sigurtà ta [`pointer::offset`].
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer tindika m'għandhiex issir mutazzjoni (ħlief ġewwa `UnsafeCell`).
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    ///
    /// Ara wkoll [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Ugwaljanza għall-indikaturi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Paragun għall-indikaturi
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}