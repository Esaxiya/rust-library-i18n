#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Jipprovdi t-tip ta 'metadata tal-pointer ta' kwalunkwe tip ippuntat.
///
/// # Metadata tal-pointer
///
/// Tipi ta 'pointer mhux maħduma u tipi ta' referenza f'Rust jistgħu jitqiesu bħala magħmula minn żewġ partijiet:
/// indikatur tad-dejta li fih l-indirizz tal-memorja tal-valur, u xi metadata.
///
/// Għal tipi ta 'daqs statiku (li jimplimentaw `Sized` traits) kif ukoll għal tipi `extern`, jingħad li l-indikaturi huma "irqaq": il-metadata hija ta' daqs żero u t-tip tagħha hija `()`.
///
///
/// L-indikaturi għal [dynamically-sized types][dst] jingħad li huma "wesgħin" jew "xaħmin", għandhom metadata ta 'daqs mhux żero:
///
/// * Għal strutturi li l-aħħar qasam tagħhom huwa DST, il-metadata hija l-metadata għall-aħħar qasam
/// * Għat-tip `str`, il-metadata hija t-tul f'bytes bħala `usize`
/// * Għal tipi ta 'porzjon bħal `[T]`, il-metadata hija t-tul f'oġġetti bħala `usize`
/// * Għal oġġetti trait bħal `dyn SomeTrait`, il-metadata hija [`DynMetadata<Self>`][DynMetadata] (eż. `DynMetadata<dyn SomeTrait>`)
///
/// Fiż-future, il-lingwa Rust tista 'tikseb tipi ġodda ta' tipi li għandhom metadata differenti tal-pointer.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Ix-`Pointee` trait
///
/// Il-punt ta 'dan trait huwa t-tip assoċjat tiegħu ma' `Metadata`, li huwa `()` jew `usize` jew `DynMetadata<_>` kif deskritt hawn fuq.
/// Huwa implimentat awtomatikament għal kull tip.
/// Wieħed jista 'jassumi li jiġi implimentat f'kuntest ġeneriku, anke mingħajr limitu korrispondenti.
///
/// # Usage
///
/// L-indikaturi mhux ipproċessati jistgħu jiġu dekomposti fl-indirizz tad-dejta u l-komponenti tal-metadejta bil-metodu [`to_raw_parts`] tagħhom.
///
/// Alternattivament, metadata waħedha tista 'tiġi estratta bil-funzjoni [`metadata`].
/// Referenza tista 'tiġi mgħoddija lil [`metadata`] u impliċitament sfurzata.
///
/// Pointer (possibly-wide) jista 'jerġa' jitqiegħed flimkien mill-indirizz u l-metadata tiegħu ma [`from_raw_parts`] jew [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// It-tip għall-metadata f'indikaturi u referenzi għal `Self`.
    #[lang = "metadata_type"]
    // NOTE: Żomm trait bounds f `static_assert_expected_bounds_for_metadata`
    //
    // f `library/core/src/ptr/metadata.rs` f'sinkronizzazzjoni ma 'dawk hawn:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Indikaturi għal tipi li jimplimentaw dan l-alias ta 'trait huma "irqaq".
///
/// Dan jinkludi tipi ta '' Daqs 'statiku u tipi ta' `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: tistabbilizzax dan qabel ma l-aliases ta 'trait huma stabbli fil-lingwa?
pub trait Thin = Pointee<Metadata = ()>;

/// Oħroġ il-komponent tal-metadata ta 'pointer.
///
/// Valuri tat-tip `*mut T`, `&T`, jew `&mut T` jistgħu jiġu mgħoddija direttament lil din il-funzjoni billi jimplikaw impliċitament lil `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SIGURTÀ: L-aċċess għall-valur mill-unjoni `PtrRepr` huwa sigur peress li * const T
    // u PtrComponents<T>għandhom l-istess taqsim tal-memorja.
    // std biss jista 'jagħmel din il-garanzija.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Jifforma pointer nej (possibly-wide) minn indirizz tad-dejta u metadata.
///
/// Din il-funzjoni hija sigura iżda l-pointer li jintbagħat lura mhux neċessarjament sikur għad-dereferenza.
/// Għal flieli, ara d-dokumentazzjoni ta [`slice::from_raw_parts`] għar-rekwiżiti ta' sigurtà.
/// Għal oġġetti trait, il-metadata trid tiġi minn pointer għall-istess tip sottostanti maħruġ.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SIGURTÀ: L-aċċess għall-valur mill-unjoni `PtrRepr` huwa sigur peress li * const T
    // u PtrComponents<T>għandhom l-istess taqsim tal-memorja.
    // std biss jista 'jagħmel din il-garanzija.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Jwettaq l-istess funzjonalità bħal [`from_raw_parts`], ħlief li jiġi rritornat pointer `*mut` mhux ipproċessat, għall-kuntrarju ta 'pointer `* const` mhux ipproċessat.
///
///
/// Ara d-dokumentazzjoni ta [`from_raw_parts`] għal aktar dettalji.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SIGURTÀ: L-aċċess għall-valur mill-unjoni `PtrRepr` huwa sigur peress li * const T
    // u PtrComponents<T>għandhom l-istess taqsim tal-memorja.
    // std biss jista 'jagħmel din il-garanzija.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Impl manwali meħtieġ biex jiġi evitat `T: Copy` marbut.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Impl manwali meħtieġ biex jiġi evitat `T: Clone` marbut.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Il-metadata għal tip ta 'oġġett `Dyn = dyn SomeTrait` trait.
///
/// Huwa pointer għal tabella vtable (tabella ta 'sejħiet virtwali) li tirrappreżenta l-informazzjoni kollha meħtieġa biex timmanipula t-tip ta' konkrit maħżun ġewwa oġġett trait.
/// Il-vtable notevolment fiha:
///
/// * daqs tat-tip
/// * allinjament tat-tip
/// * pointer għall-impl `drop_in_place` tat-tip (jista 'jkun no-op għal plain-old-data)
/// * indikaturi għall-metodi kollha għall-implimentazzjoni tat-tip taż-trait
///
/// Innota li l-ewwel tlieta huma speċjali minħabba li huma meħtieġa biex jallokaw, iwaqqgħu u jqassmu kwalunkwe oġġett trait.
///
/// Huwa possibbli li tissemma din l-istruttura b'parametru tat-tip li mhuwiex oġġett `dyn` trait (per eżempju `DynMetadata<u64>`) iżda mhux li jinkiseb valur sinifikanti ta 'dik l-istruttura.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Il-prefiss komuni tal-vtables kollha.Huwa segwit minn indikaturi tal-funzjoni għall-metodi trait.
///
/// Dettall ta 'implimentazzjoni privata ta' `DynMetadata::size_of` eċċ.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Jirritorna d-daqs tat-tip assoċjat ma 'din il-vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Jirritorna l-allinjament tat-tip assoċjat ma 'din il-vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Jirritorna d-daqs u l-allinjament flimkien bħala `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SIGURTÀ: il-kompilatur ħareġ din il-vtable għal tip konkret ta 'Rust li
        // huwa magħruf li għandu tqassim validu.L-istess raġunament bħal f `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Implimenti manwali meħtieġa biex jiġu evitati limiti `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}