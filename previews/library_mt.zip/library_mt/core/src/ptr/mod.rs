//! Immaniġġja l-memorja manwalment permezz ta 'indikaturi mhux ipproċessati.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Ħafna funzjonijiet f'dan il-modulu jieħdu indikazzjonijiet mhux ipproċessati bħala argumenti u jaqrawhom jew jiktbulhom.Biex dan ikun sigur, dawn l-indikaturi għandhom ikunu *validi*.
//! Jekk pointer huwiex validu jiddependi fuq l-operazzjoni li tintuża għaliha (taqra jew tikteb), u l-firxa tal-memorja li tkun aċċessata għaliha (jiġifieri, kemm bytes huma read/written).
//! Ħafna mill-funzjonijiet jużaw `*mut T` u `* const T` biex jaċċessaw biss valur wieħed, f'liema każ id-dokumentazzjoni tħalli barra d-daqs u impliċitament tassumi li tkun bytes `size_of::<T>()`.
//!
//! Ir-regoli preċiżi għall-validità għadhom mhumiex determinati.Il-garanziji li huma pprovduti f'dan il-punt huma minimi ħafna:
//!
//! * Pointer [null] huwa *qatt* validu, lanqas għal aċċess ta [size zero][zst].
//! * Biex pointer ikun validu, huwa meħtieġ, iżda mhux dejjem biżżejjed, li l-pointer ikun *dereferenzjabbli*: il-medda tal-memorja tad-daqs mogħti li tibda mill-pointer trid tkun kollha fil-limiti ta 'oġġett allokat wieħed.
//!
//! Innota li f'Rust, kull varjabbli (stack-allocated) hija kkunsidrata bħala oġġett separat allokat.
//! * Anke għal operazzjonijiet ta [size zero][zst], il-pointer m'għandux ikun li jindika memorja mqassma, jiġifieri, tqassim jagħmel indikaturi invalidi anke għal operazzjonijiet ta' daqs żero.
//! Madankollu, l-ikkastjar ta 'kwalunkwe numru sħiħ mhux litterali *litterali* għal pointer huwa validu għal aċċessi ta' daqs żero, anke jekk xi memorja jiġri li teżisti f'dak l-indirizz u titqassam.
//! Dan jikkorrispondi għall-kitba tal-allokatur tiegħek stess: l-allokazzjoni ta 'oġġetti ta' daqs żero mhix diffiċli ħafna.
//! Il-mod kanoniku biex jinkiseb pointer li huwa validu għal aċċessi ta 'daqs żero huwa [`NonNull::dangling`].
//! * L-aċċessi kollha mwettqa mill-funzjonijiet f'dan il-modulu huma *mhux atomiċi* fis-sens ta [atomic operations] użat biex jissinkronizza bejn il-ħjut.
//! Dan ifisser li hija mġieba mhux definita li twettaq żewġ aċċessijiet konkorrenti għall-istess post minn ħjut differenti sakemm iż-żewġ aċċess ma jaqrawx biss mill-memorja.
//! Innota li dan espliċitament jinkludi [`read_volatile`] u [`write_volatile`]: Aċċess volatili ma jistgħux jintużaw għas-sinkronizzazzjoni bejn il-ħjut.
//! * Ir-riżultat tal-ikkastjar ta 'referenza għal pointer huwa validu sakemm l-oġġett sottostanti jkun ħaj u l-ebda referenza (biss indikaturi mhux ipproċessati) ma tintuża biex taċċessa l-istess memorja.
//!
//! Dawn l-assiomi, flimkien ma 'użu bir-reqqa ta' [`offset`] għall-aritmetika tal-pointer, huma biżżejjed biex jimplimentaw b'mod korrett ħafna affarijiet utli f'kodiċi mhux sikuri.
//! Garanziji aktar b'saħħithom jiġu pprovduti eventwalment, billi r-regoli [aliasing] qed jiġu determinati.
//! Għal aktar informazzjoni, ara [book] kif ukoll it-taqsima fir-referenza ddedikata għal [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Indikaturi nejjin validi kif definiti hawn fuq mhumiex neċessarjament allinjati sewwa (fejn l-allinjament "proper" huwa definit mit-tip pointee, jiġifieri, `*const T` għandu jkun allinjat ma `mem::align_of::<T>()`).
//! Madankollu, ħafna mill-funzjonijiet jeħtieġu li l-argumenti tagħhom ikunu allinjati kif suppost, u se jiddikjaraw espliċitament dan ir-rekwiżit fid-dokumentazzjoni tagħhom.
//! Eċċezzjonijiet notevoli għal dan huma [`read_unaligned`] u [`write_unaligned`].
//!
//! Meta funzjoni teħtieġ allinjament xieraq, tagħmel dan anke jekk l-aċċess ikollu daqs 0, jiġifieri, anki jekk il-memorja ma tmissx fil-fatt.Ikkunsidra li tuża [`NonNull::dangling`] f'każijiet bħal dawn.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Teżegwixxi d-distruttur (jekk hemm) tal-valur indikat.
///
/// Dan huwa semantikament ekwivalenti għal sejħa [`ptr::read`] u rimi tar-riżultat, iżda għandu l-vantaġġi li ġejjin:
///
/// * Huwa *meħtieġ* li tuża `drop_in_place` biex twaqqa 'tipi mhux daqs bħal oġġetti trait, għax ma jistgħux jinqraw fuq il-munzell u jitwaqqgħu b'mod normali.
///
/// * Huwa aktar faċli għall-ottimizzatur li tagħmel dan fuq [`ptr::read`] meta twaqqa 'memorja allokata manwalment (eż., Fl-implimentazzjoni ta' `Box`/`Rc`/`Vec`), minħabba li l-kompilatur m'għandux għalfejn jipprova li huwa tajjeb li tneħħi l-kopja.
///
///
/// * Tista 'tintuża biex twaqqa' dejta [pinned] meta `T` mhix `repr(packed)` (dejta mwaħħla m'għandhiex titmexxa qabel ma titwaqqa ').
///
/// Valuri mhux allinjati ma jistgħux jitwaqqgħu f'posthom, għandhom jiġu kkupjati f'post allinjat l-ewwel billi tuża [`ptr::read_unaligned`].Għal strutturi ppakkjati, din il-mossa ssir awtomatikament mill-kompilatur.
/// Dan ifisser li l-oqsma tal-istrutturi ppakkjati ma jitwaqqgħux fil-post.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `to_drop` għandu jkun [valid] kemm għall-qari kif ukoll għall-kitba.
///
/// * `to_drop` għandhom ikunu allinjati sewwa.
///
/// * Il-valur `to_drop` jindika li għandu jkun validu biex jinżel, li jista 'jfisser li għandu jżomm invarianti addizzjonali, dan jiddependi mit-tip.
///
/// Barra minn hekk, jekk `T` mhuwiex [`Copy`], l-użu tal-valur ippuntat wara li ċċempel lil `drop_in_place` jista 'jikkawża imġieba mhux definita.Innota li `*to_drop = foo` jgħodd bħala użu għax se jikkawża li l-valur jerġa 'jitwaqqa'.
/// [`write()`] jista 'jintuża biex jissostitwixxi dejta mingħajr ma jikkawża li titwaqqa'.
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer għandu jkun MHUX NULL u allinjat sewwa.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Neħħi manwalment l-aħħar oġġett minn vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Ikseb pointer nej għall-aħħar element f `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Qassar `v` biex tevita li l-aħħar oġġett jinżel.
///     // Aħna nagħmlu dan l-ewwel, biex nipprevjenu kwistjonijiet jekk ix-`drop_in_place` taħt panics.
///     v.set_len(1);
///     // Mingħajr sejħa `drop_in_place`, l-aħħar oġġett qatt ma jitwaqqa ', u l-memorja li timmaniġġja tkun imxerrda.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Kun żgur li l-aħħar oġġett twaqqa '.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Innota li l-kompilatur iwettaq din il-kopja awtomatikament meta jwaqqa 'l-istrutturi ppakkjati, jiġifieri, normalment m'għandekx għalfejn tinkwieta dwar kwistjonijiet bħal dawn sakemm ma ċċempelx lil `drop_in_place` manwalment.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Il-kodiċi hawnhekk ma jimpurtax, dan huwa sostitwit bil-kolla tal-waqgħa reali mill-kompilatur.
    //

    // SIGURTÀ: ara l-kumment hawn fuq
    unsafe { drop_in_place(to_drop) }
}

/// Toħloq pointer mhux maħdum null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Toħloq pointer nej mutabbli null.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Impl manwali meħtieġ biex jiġi evitat `T: Clone` marbut.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Impl manwali meħtieġ biex jiġi evitat `T: Copy` marbut.
impl<T> Copy for FatPtr<T> {}

/// Jifforma porzjon nej minn pointer u tul.
///
/// L-argument `len` huwa n-numru ta '**elementi**, mhux in-numru ta' bytes.
///
/// Din il-funzjoni hija sigura, iżda fil-fatt l-użu tal-valur tar-ritorn mhuwiex sikur.
/// Ara d-dokumentazzjoni ta [`slice::from_raw_parts`] għar-rekwiżiti tas-sigurtà tal-porzjon.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // oħloq pointer slice meta tibda bil-pointer għall-ewwel element
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SIGURTÀ: L-aċċess għall-valur mill-unjoni `Repr` huwa sigur peress li * const [T]
        //
        // u FatPtr għandhom l-istess taqsim tal-memorja.std biss jista 'jagħmel din il-garanzija.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Jaqdi l-istess funzjonalità bħal [`slice_from_raw_parts`], ħlief li porzjon mhux mibdul mhux mibdul jiġi rritornat, għall-kuntrarju ta 'porzjon mhux maħdum immutabbli.
///
///
/// Ara d-dokumentazzjoni ta [`slice_from_raw_parts`] għal aktar dettalji.
///
/// Din il-funzjoni hija sigura, iżda fil-fatt l-użu tal-valur tar-ritorn mhuwiex sikur.
/// Ara d-dokumentazzjoni ta [`slice::from_raw_parts_mut`] għar-rekwiżiti tas-sigurtà tal-porzjon.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // assenja valur f'indiċi fil-porzjon
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SIGURTÀ: L-aċċess għall-valur mill-unjoni `Repr` huwa sigur peress li * mut [T]
        // u FatPtr għandhom l-istess taqsim tal-memorja
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Tpartit il-valuri f'żewġ postijiet li jistgħu jinbidlu ta 'l-istess tip, mingħajr lanqas titneħħa l-inizjalità.
///
/// Iżda għaż-żewġ eċċezzjonijiet li ġejjin, din il-funzjoni hija semantikament ekwivalenti għal [`mem::swap`]:
///
///
/// * Huwa jopera fuq indikaturi mhux ipproċessati minflok fuq referenzi.
/// Meta r-referenzi jkunu disponibbli, [`mem::swap`] għandu jkun preferut.
///
/// * Iż-żewġ valuri indikati jistgħu jikkoinċidu.
/// Jekk il-valuri jikkoinċidu, allura r-reġjun li jikkoinċidi tal-memorja minn `x` jintuża.
/// Dan jintwera fit-tieni eżempju hawn taħt.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * Kemm `x` kif ukoll `y` għandhom ikunu [valid] kemm għall-qari kif ukoll għall-kitba.
///
/// * Kemm `x` kif ukoll `y` għandhom ikunu allinjati sewwa.
///
/// Innota li anke jekk `T` għandu daqs `0`, l-indikaturi għandhom ikunu mhux NULL u allinjati sewwa.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Skambji ta 'żewġ reġjuni li ma jikkoinċidux:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // dan huwa `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // dan huwa `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Skambji ta 'żewġ reġjuni li jikkoinċidu:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // dan huwa `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // dan huwa `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // L-indiċi `1..3` tal-porzjon jikkoinċidu bejn `x` u `y`.
///     // Riżultati raġonevoli jkunu għalihom għax ikunu `[2, 3]`, sabiex l-indiċi `0..3` ikunu `[1, 2, 3]` (li jaqblu ma `y` qabel ix-`swap`);jew biex ikunu `[0, 1]` sabiex l-indiċi `1..4` ikunu `[0, 1, 2]` (li jaqblu ma `x` qabel ix-`swap`).
/////
///     // Din l-implimentazzjoni hija definita biex tagħmel l-aħħar għażla.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Agħti lilna nfusna ftit spazju biex naħdmu magħhom.
    // M`għandniex għalfejn ninkwetaw dwar qtar: `MaybeUninit` ma jagħmel xejn meta jinżel.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Wettaq it-tpartit SIGURTÀ: min iċempel għandu jiggarantixxi li `x` u `y` huma validi għal kitbiet u allinjati sewwa.
    // `tmp` ma tistax tkun sovrapposta la `x` u lanqas `y` għax `tmp` kien biss allokat fuq il-munzell bħala oġġett separat allokat.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` u `y` jistgħu jikkoinċidu
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Tpartit bytes `count * size_of::<T>()` bejn iż-żewġ reġjuni tal-memorja li jibdew minn `x` u `y`.
/// Iż-żewġ reġjuni ma għandhomx * jikkoinċidu.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * Kemm `x` kif ukoll `y` għandhom ikunu [valid] kemm għall-qari kif ukoll għall-kitba ta '' għadd *
///   daqs_ta ': :<T>() 'bytes.
///
/// * Kemm `x` kif ukoll `y` għandhom ikunu allinjati sewwa.
///
/// * Ir-reġjun tal-memorja li jibda minn `x` b'daqs ta 'ʻgħadd *
///   daqs_ta ': :<T>() `bytes m'għandhomx *jikkoinċidu* mar-reġjun tal-memorja li jibda f `y` bl-istess daqs.
///
/// Innota li anke jekk id-daqs ikkupjat b'mod effettiv (`count * size_of: :<T>()`) huwa `0`, l-indikaturi għandhom ikunu mhux NULL u allinjati sewwa.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SIGURTÀ: min iċempel għandu jiggarantixxi li `x` u `y` huma
    // validu għal kitbiet u allinjat sewwa.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Għal tipi iżgħar mill-ottimizzazzjoni tal-blokka hawn taħt, sempliċement ibdel direttament biex tevita li tippessimizza l-kodeġen.
    //
    if mem::size_of::<T>() < 32 {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `x` u `y` huma validi
        // għal kitbiet, allinjati kif suppost, u li ma jikkoinċidux.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // L-approċċ hawnhekk huwa li tuża s-simd biex tpartat x&y b'mod effiċjenti.
    // L-ittestjar juri li l-iskambju ta '32 byte jew 64 byte kull darba huwa l-iktar effiċjenti għall-proċessuri Intel Haswell E.
    // LLVM huwa aktar kapaċi jottimizza jekk nagħtu struct lil #[repr(simd)], anke jekk fil-fatt ma nużawx din struct direttament.
    //
    //
    // FIXME repr(simd) imkisser fuq emscripten u redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Ixgħel permezz ta 'x&y, ikkupjahom `Block` kull darba L-ottimizzatur għandu jħoll il-linja kompletament għal ħafna tipi NB
    // Ma nistgħux nużaw loop għal kif l-`range` impl isejjaħ lil `mem::swap` rikursivament
    //
    let mut i = 0;
    while i + block_size <= len {
        // Oħloq ftit memorja mhux inizjalizzata bħala spazju ta 'scratch Id-dikjarazzjoni ta' `t` hawn tevita li tallinja l-munzell meta dan il-linja ma tintużax
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SIGURTÀ: Bħala `i < len`, u bħala min iċempel għandu jiggarantixxi li `x` u `y` huma validi
        // għal bytes `len`, `x + i` u `y + i` għandhom ikunu indirizzi validi, li jissodisfaw il-kuntratt ta 'sigurtà għal `add`.
        //
        // Ukoll, min iċempel għandu jiggarantixxi li `x` u `y` huma validi għal kitbiet, allinjati kif suppost, u li ma jikkoinċidux, li jissodisfa l-kuntratt ta 'sigurtà għal `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Ibdel blokka ta 'bytes ta' x&y, billi tuża t bħala buffer temporanju Dan għandu jkun ottimizzat f'operazzjonijiet SIMD effiċjenti fejn disponibbli
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Ibdel kwalunkwe byte li jifdal
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SIGURTÀ: ara l-kumment ta 'sigurtà preċedenti.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Tmexxi `src` fix-`dst` ippuntat, u tirritorna l-valur preċedenti ta `dst`.
///
/// L-ebda valur ma jitwaqqa '.
///
/// Din il-funzjoni hija semantikament ekwivalenti għal [`mem::replace`] ħlief li topera fuq indikaturi mhux ipproċessati minflok fuq referenzi.
/// Meta r-referenzi jkunu disponibbli, [`mem::replace`] għandu jkun preferut.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `dst` għandu jkun [valid] kemm għall-qari kif ukoll għall-kitba.
///
/// * `dst` għandhom ikunu allinjati sewwa.
///
/// * `dst` għandu jindika valur inizjalizzat kif suppost tat-tip `T`.
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer għandu jkun MHUX NULL u allinjat sewwa.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ikollu l-istess effett mingħajr ma jeħtieġ il-blokka mhux sigura.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SIGURTÀ: min iċempel għandu jiggarantixxi li `dst` huwa validu biex ikun
    // mitfugħa għal referenza li tista 'tinbidel (valida għal kitbiet, allinjata, inizjalizzata), u ma tistax tikkoinċidi `src` peress li `dst` għandu jindika oġġett distint allokat.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ma jistax jikkoinċidi
    }
    src
}

/// Jaqra l-valur minn `src` mingħajr ma jiċċaqlaq.Dan iħalli l-memorja f `src` mhux mibdula.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `src` għandu jkun [valid] għal qari.
///
/// * `src` għandhom ikunu allinjati sewwa.Uża [`read_unaligned`] jekk dan ma jkunx il-każ.
///
/// * `src` għandu jindika valur inizjalizzat kif suppost tat-tip `T`.
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer għandu jkun MHUX NULL u allinjat sewwa.
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implimenta manwalment [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Oħloq kopja bitwise tal-valur f `a` f `tmp`.
///         let tmp = ptr::read(a);
///
///         // Li toħroġ f'dan il-punt (jew billi tirritorna b'mod espliċitu jew billi ssejjaħ funzjoni li panics) tikkawża li l-valur f `tmp` jitwaqqa 'waqt li l-istess valur ikun għadu referenzjat minn `a`.
///         // Dan jista 'jwassal għal imġieba mhux definita jekk `T` mhuwiex `Copy`.
/////
/////
///
///         // Oħloq kopja bitwise tal-valur f `b` f `a`.
///         // Dan huwa sigur minħabba li referenzi li jistgħu jinbidlu ma jistgħux jiġu magħrufa.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Bħal hawn fuq, il-ħruġ minn hawn jista 'jwassal għal imġieba mhux definita minħabba li l-istess valur huwa referenzjat minn `a` u `b`.
/////
///
///         // Mexxi `tmp` f `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ġie mċaqlaq (`write` jieħu s-sjieda tat-tieni argument tiegħu), għalhekk xejn ma jitwaqqa impliċitament hawn.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Sjieda tal-Valur Mibgħut lura
///
/// `read` joħloq kopja bitwise ta `T`, irrispettivament minn jekk `T` hux [`Copy`].
/// Jekk `T` mhuwiex [`Copy`], l-użu kemm tal-valur ritornat kif ukoll tal-valur f `*src` jista 'jikser is-sigurtà tal-memorja.
/// Innota li l-assenjazzjoni lil `*src` tgħodd bħala użu għax tipprova tnaqqas il-valur f `* src`.
///
/// [`write()`] jista 'jintuża biex jissostitwixxi dejta mingħajr ma jikkawża li titwaqqa'.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` issa jindika l-istess memorja sottostanti bħal `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // L-assenjazzjoni lil `s2` tikkawża li l-valur oriġinali tiegħu jitwaqqa '.
///     // Lil hinn minn dan il-punt, `s` m'għandux jibqa 'jintuża, billi l-memorja sottostanti ġiet meħlusa.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // L-assenjazzjoni lil `s` tikkawża li l-valur qadim jerġa 'jitwaqqa', u jirriżulta f'imġieba mhux definita.
/////
///     // s= String::from("bar");//ŻBALL
///
///     // `ptr::write` tista 'tintuża biex tissostitwixxi valur mingħajr ma twaqqa'.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURTÀ: min iċempel għandu jiggarantixxi li `src` huwa validu għal qari.
    // `src` ma jistax jikkoinċidi `tmp` minħabba li `tmp` kien biss allokat fuq il-munzell bħala oġġett separat allokat.
    //
    //
    // Ukoll, peress li għadna kemm ktibna valur validu f `tmp`, huwa garantit li jkun inizjalizzat sewwa.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Jaqra l-valur minn `src` mingħajr ma jiċċaqlaq.Dan iħalli l-memorja f `src` mhux mibdula.
///
/// B'differenza minn [`read`], `read_unaligned` jaħdem ma 'indikaturi mhux allinjati.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `src` għandu jkun [valid] għal qari.
///
/// * `src` għandu jindika valur inizjalizzat kif suppost tat-tip `T`.
///
/// Bħal [`read`], `read_unaligned` joħloq kopja bitwise ta `T`, irrispettivament minn jekk `T` huwiex [`Copy`].
/// Jekk `T` mhuwiex [`Copy`], bl-użu kemm tal-valur ritornat kif ukoll il-valur f `*src` jista [violate memory safety][read-ownership].
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer m'għandux ikun NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Fuq strutturi `packed`
///
/// Bħalissa huwa impossibbli li toħloq indikaturi mhux ipproċessati għal oqsma mhux allinjati ta 'struttura ppakkjata.
///
/// Li tipprova toħloq pointer mhux maħdum għal qasam `unaligned` struct b'espressjoni bħal `&packed.unaligned as *const FieldType` toħloq referenza intermedja mhux allinjata qabel ma tikkonverti dak għal pointer nej.
///
/// Li din ir-referenza hija temporanja u mitfugħa immedjatament mhix konsegwenzjali peress li l-kompilatur dejjem jistenna li r-referenzi jkunu allinjati sewwa.
/// Bħala riżultat, l-użu ta `&packed.unaligned as *const FieldType` jikkawża imġieba immedjata* mhux definita * fil-programm tiegħek.
///
/// Eżempju ta 'x'għandekx tagħmel u kif dan jirrelata ma' `read_unaligned` huwa:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hawnhekk nippruvaw nieħdu l-indirizz ta 'numru sħiħ ta' 32-bit li mhuwiex allinjat.
///     let unaligned =
///         // Hawnhekk tinħoloq referenza temporanja mhux allinjata li tirriżulta f'imġieba mhux definita irrispettivament minn jekk ir-referenza hijiex użata jew le.
/////
///         &packed.unaligned
///         // Ikkastjar għal pointer nej ma jgħinx;l-iżball diġà ġara.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// L-aċċess għal oqsma mhux allinjati direttament ma 'eż. `packed.unaligned` huwa sigur madankollu.
///
///
///
///
///
///
// FIXME: Aġġorna d-dokumenti bbażati fuq ir-riżultat tal-RFC #2582 u l-ħbieb.
/// # Examples
///
/// Aqra valur ta 'użu minn buffer ta' byte:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIGURTÀ: min iċempel għandu jiggarantixxi li `src` huwa validu għal qari.
    // `src` ma jistax jikkoinċidi `tmp` minħabba li `tmp` kien biss allokat fuq il-munzell bħala oġġett separat allokat.
    //
    //
    // Ukoll, peress li għadna kemm ktibna valur validu f `tmp`, huwa garantit li jkun inizjalizzat sewwa.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Jikteb fuq post tal-memorja bil-valur mogħti mingħajr ma jaqra jew iwaqqa 'l-valur l-antik.
///
/// `write` ma jwaqqax il-kontenut ta `dst`.
/// Dan huwa sigur, iżda jista 'jnixxi allokazzjonijiet jew riżorsi, għalhekk għandha tingħata attenzjoni biex ma jinkitebx oġġett li għandu jitwaqqa'.
///
///
/// Barra minn hekk, ma jwaqqax `src`.Semantikament, `src` jiġi mċaqlaq fil-post indikat minn `dst`.
///
/// Dan huwa xieraq għall-inizjalizzazzjoni ta 'memorja mhux inizjalizzata, jew kitba ta' memorja li kienet preċedentement [`read`] minn.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `dst` għandu jkun [valid] għall-kitbiet.
///
/// * `dst` għandhom ikunu allinjati sewwa.Uża [`write_unaligned`] jekk dan ma jkunx il-każ.
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer għandu jkun MHUX NULL u allinjat sewwa.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Implimenta manwalment [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Oħloq kopja bitwise tal-valur f `a` f `tmp`.
///         let tmp = ptr::read(a);
///
///         // Li toħroġ f'dan il-punt (jew billi tirritorna b'mod espliċitu jew billi ssejjaħ funzjoni li panics) tikkawża li l-valur f `tmp` jitwaqqa 'waqt li l-istess valur ikun għadu referenzjat minn `a`.
///         // Dan jista 'jwassal għal imġieba mhux definita jekk `T` mhuwiex `Copy`.
/////
/////
///
///         // Oħloq kopja bitwise tal-valur f `b` f `a`.
///         // Dan huwa sigur minħabba li referenzi li jistgħu jinbidlu ma jistgħux jiġu magħrufa.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Bħal hawn fuq, il-ħruġ minn hawn jista 'jwassal għal imġieba mhux definita minħabba li l-istess valur huwa referenzjat minn `a` u `b`.
/////
///
///         // Mexxi `tmp` f `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` ġie mċaqlaq (`write` jieħu s-sjieda tat-tieni argument tiegħu), għalhekk xejn ma jitwaqqa impliċitament hawn.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Qed insejħu l-intrinsiċi direttament biex nevitaw sejħiet ta 'funzjoni fil-kodiċi ġġenerat billi `intrinsics::copy_nonoverlapping` hija funzjoni tat-tgeżwir.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SIGURTÀ: min iċempel għandu jiggarantixxi li `dst` huwa validu għal kitbiet.
    // `dst` ma jistax jikkoinċidi ma `src` minħabba li min iċempel għandu aċċess li jista' jinbidel għal `dst` waqt li `src` huwa proprjetà ta 'din il-funzjoni.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Jikteb fuq post tal-memorja bil-valur mogħti mingħajr ma jaqra jew iwaqqa 'l-valur l-antik.
///
/// B'differenza minn [`write()`], il-pointer jista 'jkun mhux allinjat.
///
/// `write_unaligned` ma jwaqqax il-kontenut ta `dst`.Dan huwa sigur, iżda jista 'jnixxi allokazzjonijiet jew riżorsi, għalhekk għandha tingħata attenzjoni biex ma jinkitebx oġġett li għandu jitwaqqa'.
///
/// Barra minn hekk, ma jwaqqax `src`.Semantikament, `src` jiġi mċaqlaq fil-post indikat minn `dst`.
///
/// Dan huwa xieraq għall-inizjalizzazzjoni tal-memorja mhux inizjalizzata, jew il-memorja ta 'kitba mill-ġdid li qabel kienet tinqara b [`read_unaligned`].
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `dst` għandu jkun [valid] għall-kitbiet.
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer m'għandux ikun NULL.
///
/// [valid]: self#safety
///
/// ## Fuq strutturi `packed`
///
/// Bħalissa huwa impossibbli li toħloq indikaturi mhux ipproċessati għal oqsma mhux allinjati ta 'struttura ppakkjata.
///
/// Li tipprova toħloq pointer mhux maħdum għal qasam `unaligned` struct b'espressjoni bħal `&packed.unaligned as *const FieldType` toħloq referenza intermedja mhux allinjata qabel ma tikkonverti dak għal pointer nej.
///
/// Li din ir-referenza hija temporanja u mitfugħa immedjatament mhix konsegwenzjali peress li l-kompilatur dejjem jistenna li r-referenzi jkunu allinjati sewwa.
/// Bħala riżultat, l-użu ta `&packed.unaligned as *const FieldType` jikkawża imġieba immedjata* mhux definita * fil-programm tiegħek.
///
/// Eżempju ta 'x'għandekx tagħmel u kif dan jirrelata ma' `write_unaligned` huwa:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hawnhekk nippruvaw nieħdu l-indirizz ta 'numru sħiħ ta' 32-bit li mhuwiex allinjat.
///     let unaligned =
///         // Hawnhekk tinħoloq referenza temporanja mhux allinjata li tirriżulta f'imġieba mhux definita irrispettivament minn jekk ir-referenza hijiex użata jew le.
/////
///         &mut packed.unaligned
///         // Ikkastjar għal pointer nej ma jgħinx;l-iżball diġà ġara.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// L-aċċess għal oqsma mhux allinjati direttament ma 'eż. `packed.unaligned` huwa sigur madankollu.
///
///
///
///
///
///
///
///
///
// FIXME: Aġġorna d-dokumenti bbażati fuq ir-riżultat tal-RFC #2582 u l-ħbieb.
/// # Examples
///
/// Ikteb valur ta 'użu għal buffer tal-byte:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SIGURTÀ: min iċempel għandu jiggarantixxi li `dst` huwa validu għal kitbiet.
    // `dst` ma jistax jikkoinċidi ma `src` minħabba li min iċempel għandu aċċess li jista' jinbidel għal `dst` waqt li `src` huwa proprjetà ta 'din il-funzjoni.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Qed insejħu l-intrinsiku direttament biex nevitaw sejħiet ta 'funzjoni fil-kodiċi ġġenerat.
        intrinsics::forget(src);
    }
}

/// Twettaq qari volatili tal-valur minn `src` mingħajr ma tmexxih.Dan iħalli l-memorja f `src` mhux mibdula.
///
/// Operazzjonijiet volatili huma maħsuba biex jaġixxu fuq memorja I/O, u huma garantiti li ma jiġux eliditi jew ordnati mill-ġdid mill-kompilatur f'operazzjonijiet volatili oħra.
///
/// # Notes
///
/// Rust bħalissa m'għandux mudell ta 'memorja definit b'mod rigoruż u formalment, għalhekk is-semantika preċiża ta' xi jfisser "volatile" hawn hija suġġetta għal bidla maż-żmien.
/// Cela dit, is-semantika kważi dejjem tispiċċa pjuttost simili għal [C11's definition of volatile][c11].
///
/// Il-kompilatur m'għandux ibiddel l-ordni relattiva jew in-numru ta 'operazzjonijiet ta' memorja volatili.
/// Madankollu, operazzjonijiet ta 'memorja volatili fuq tipi ta' daqs żero (eż., Jekk tip ta 'daqs żero jiġi mgħoddi lil `read_volatile`) huma noops u jistgħu jiġu injorati.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `src` għandu jkun [valid] għal qari.
///
/// * `src` għandhom ikunu allinjati sewwa.
///
/// * `src` għandu jindika valur inizjalizzat kif suppost tat-tip `T`.
///
/// Bħal [`read`], `read_volatile` joħloq kopja bitwise ta `T`, irrispettivament minn jekk `T` huwiex [`Copy`].
/// Jekk `T` mhuwiex [`Copy`], bl-użu kemm tal-valur ritornat kif ukoll il-valur f `*src` jista [violate memory safety][read-ownership].
/// Madankollu, il-ħażna ta 'tipi mhux ["Kopja"] fil-memorja volatili hija kważi ċertament skorretta.
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer għandu jkun MHUX NULL u allinjat sewwa.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Bħal f'Ċ, jekk operazzjoni hijiex volatili m'għandha l-ebda rilevanza fuq kwistjonijiet li jinvolvu aċċess konkorrenti minn ħjut multipli.Aċċessi volatili jġibu ruħhom eżattament bħal aċċessi mhux atomiċi f'dak ir-rigward.
///
/// B'mod partikolari, tellieqa bejn `read_volatile` u kwalunkwe operazzjoni ta 'kitba fl-istess post hija mġieba mhux definita.
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Mhux paniku biex iżomm l-impatt tal-codegen iżgħar.
        abort();
    }
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Twettaq kitba volatili ta 'post tal-memorja bil-valur mogħti mingħajr ma taqra jew twaqqa' l-valur l-antik.
///
/// Operazzjonijiet volatili huma maħsuba biex jaġixxu fuq memorja I/O, u huma garantiti li ma jiġux eliditi jew ordnati mill-ġdid mill-kompilatur f'operazzjonijiet volatili oħra.
///
/// `write_volatile` ma jwaqqax il-kontenut ta `dst`.Dan huwa sigur, iżda jista 'jnixxi allokazzjonijiet jew riżorsi, għalhekk għandha tingħata attenzjoni biex ma jinkitebx oġġett li għandu jitwaqqa'.
///
/// Barra minn hekk, ma jwaqqax `src`.Semantikament, `src` jiġi mċaqlaq fil-post indikat minn `dst`.
///
/// # Notes
///
/// Rust bħalissa m'għandux mudell ta 'memorja definit b'mod rigoruż u formalment, għalhekk is-semantika preċiża ta' xi jfisser "volatile" hawn hija suġġetta għal bidla maż-żmien.
/// Cela dit, is-semantika kważi dejjem tispiċċa pjuttost simili għal [C11's definition of volatile][c11].
///
/// Il-kompilatur m'għandux ibiddel l-ordni relattiva jew in-numru ta 'operazzjonijiet ta' memorja volatili.
/// Madankollu, operazzjonijiet ta 'memorja volatili fuq tipi ta' daqs żero (eż., Jekk tip ta 'daqs żero jiġi mgħoddi lil `write_volatile`) huma noops u jistgħu jiġu injorati.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `dst` għandu jkun [valid] għall-kitbiet.
///
/// * `dst` għandhom ikunu allinjati sewwa.
///
/// Innota li anke jekk `T` għandu daqs `0`, il-pointer għandu jkun MHUX NULL u allinjat sewwa.
///
/// [valid]: self#safety
///
/// Bħal f'Ċ, jekk operazzjoni hijiex volatili m'għandha l-ebda rilevanza fuq kwistjonijiet li jinvolvu aċċess konkorrenti minn ħjut multipli.Aċċessi volatili jġibu ruħhom eżattament bħal aċċessi mhux atomiċi f'dak ir-rigward.
///
/// B`mod partikolari, tellieqa bejn `write_volatile` u kwalunkwe operazzjoni oħra (qari jew kitba) fl-istess post hija mġieba mhux definita.
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Mhux paniku biex iżomm l-impatt tal-codegen iżgħar.
        abort();
    }
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Allinja l-pointer `p`.
///
/// Ikkalkula l-offset (f'termini ta 'elementi ta' pass `stride`) li jrid jiġi applikat għall-pointer `p` sabiex il-pointer `p` jiġi allinjat ma `a`.
///
/// Note: Din l-implimentazzjoni ġiet imfassla bir-reqqa biex ma tkunx panic.Huwa UB għal dan għal panic.
/// L-unika bidla reali li tista 'ssir hawn hija bidla ta' `INV_TABLE_MOD_16` u kostanti assoċjati.
///
/// Jekk qatt niddeċiedu li nagħmluha possibbli li nsejħu l-intrinsiku ma `a` li mhuwiex qawwa ta' tnejn, probabbilment ikun iktar prudenti li nibdlu biss għal implimentazzjoni inġenwa minflok nippruvaw naddattaw dan biex jakkomoda dik il-bidla.
///
///
/// Kwalunkwe mistoqsija mur fuq@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): L-użu dirett ta 'dawn l-intrinsiċi jtejjeb il-codegen b'mod sinifikanti fil-livell ta' għażla <=
    // 1, fejn il-verżjonijiet tal-metodu ta 'dawn l-operazzjonijiet mhumiex inlinjati.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Ikkalkula l-invers modulari multiplikattiv ta `x` modulo `m`.
    ///
    /// Din l-implimentazzjoni hija mfassla apposta għal `align_offset` u għandha l-prekundizzjonijiet li ġejjin:
    ///
    /// * `m` hija qawwa ta 'tnejn;
    /// * `x < m`; (jekk `x ≥ m`, għaddi f `x % m` minflok)
    ///
    /// L-implimentazzjoni ta 'din il-funzjoni m'għandhiex panic.Qatt.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Tabella inversa modulari multiplikattiva modulo 2⁴=16.
        ///
        /// Innota, li din it-tabella ma fihiex valuri fejn l-invers ma jeżistix (jiġifieri, għal `0⁻¹ mod 16`, `2⁻¹ mod 16`, eċċ.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulu li għalih huwa maħsub ix-`INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SIGURTÀ: `m` huwa meħtieġ li jkun qawwa ta 'tnejn, għalhekk mhux żero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Aħna ntennu "up" billi nużaw il-formula li ġejja:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // sa 2²ⁿ ≥ m.Imbagħad nistgħu nnaqqsu għax-`m` mixtieq tagħna billi nieħdu r-riżultat `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Innota, li nużaw operazzjonijiet ta 'tgeżwir hawn intenzjonalment-il-formula oriġinali tuża eż. Tnaqqis `mod n`.
                // Huwa kompletament tajjeb li tagħmilhom `mod usize::MAX` minflok, għax ir-riżultat `mod n` nieħduh fl-aħħar xorta waħda.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SIGURTÀ: `a` huwa qawwa ta 'tnejn, għalhekk mhux żero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` il-każ jista 'jiġi kkalkulat b'mod aktar sempliċi permezz ta' `-p (mod a)`, imma billi tagħmel hekk jinibixxi l-abbiltà ta 'LLVM li tagħżel struzzjonijiet bħal `lea`.Minflok aħna nikkalkulaw
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // li jqassam operazzjonijiet madwar it-tagħbija, iżda jippessimizza `and` biżżejjed biex LLVM ikun jista 'juża l-ottimizzazzjonijiet varji li jaf bihom.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Diġà allinjat.Yay!
        return 0;
    } else if stride == 0 {
        // Jekk il-pointer mhuwiex allinjat, u l-element huwa ta 'daqs żero, allura l-ebda ammont ta' elementi qatt ma jallinja l-pointer.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SIGURTÀ: a hija qawwa ta 'tnejn għalhekk mhux żero.pass==0 każ huwa ttrattat hawn fuq.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SIGURTÀ: gcdpow għandu limitu massimu li l-iktar huwa n-numru ta 'bits f'użu.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SIGURTÀ: gcd huwa dejjem akbar jew ugwali għal 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Dan branch issolvi għall-ekwazzjoni ta 'kongruenza lineari li ġejja:
        //
        // ` p + so = 0 mod a `
        //
        // `p` hawn hu l-valur tal-pointer, `s`, pass ta `T`, `o` offset f'`T`s, u `a`, l-allinjament mitlub.
        //
        // B `g = gcd(a, s)`, u l-kundizzjoni ta 'hawn fuq li tasserixxi li `p` hija wkoll diviżibbli b `g`, nistgħu nindikaw `a' = a/g`, `s' = s/g`, `p' = p/g`, allura dan isir ekwivalenti għal:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // L-ewwel terminu huwa "the relative alignment of `p` to `a`" (diviż bl-`g`), it-tieni terminu huwa "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (għal darb'oħra diviż b `g`).
        //
        // Diviżjoni b `g` hija meħtieġa biex tagħmel l-invers iffurmat sew jekk `a` u `s` mhumiex co-prime.
        //
        // Barra minn hekk, ir-riżultat prodott minn din is-soluzzjoni mhuwiex "minimal", għalhekk huwa meħtieġ li tieħu r-riżultat `o mod lcm(s, a)`.Nistgħu nissostitwixxu `lcm(s, a)` bi `a'` biss.
        //
        //
        //
        //
        //

        // SIGURTÀ: `gcdpow` għandu limitu superjuri mhux akbar min-numru ta '0-bits ta' wara f `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SIGURTÀ: `a2` mhuwiex żero.Ix-Xift ta `a` b `gcdpow` ma jistax jaqleb l-ebda wieħed mis-sett bits
        // f `a` (li minnhom għandha eżattament waħda).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SIGURTÀ: `gcdpow` għandu limitu superjuri mhux akbar min-numru ta '0-bits ta' wara f `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SIGURTÀ: `gcdpow` għandu limitu ta 'fuq mhux akbar min-numru ta' 0-bits wara
        // `a`.
        // Barra minn hekk, it-tnaqqis ma jistax ifur, għax `a2 = a >> gcdpow` dejjem ikun strettament akbar minn `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SIGURTÀ: `a2` huwa qawwa ta 'tnejn, kif ippruvat hawn fuq.`s2` huwa strettament inqas minn `a2`
        // minħabba li `(s % a) >> gcdpow` huwa strettament inqas minn `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Ma tista 'tkun allinjata xejn.
    usize::MAX
}

/// Iqabbel indikaturi nej għall-ugwaljanza.
///
/// Dan huwa l-istess bħall-użu tal-operatur `==`, iżda inqas ġeneriku:
/// l-argumenti għandhom ikunu `*const T` raw pointers, mhux xi ħaġa li timplimenta `PartialEq`.
///
/// Dan jista 'jintuża biex iqabbel ir-referenzi `&T` (li jġiegħlu lil `*const T` impliċitament) bl-indirizz tagħhom aktar milli jqabblu l-valuri li jindikaw (li huwa dak li tagħmel l-implimentazzjoni `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Il-flieli huma mqabbla wkoll bit-tul tagħhom (indikaturi tax-xaħam):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits huma wkoll imqabbla bl-implimentazzjoni tagħhom:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // L-indikaturi għandhom indirizzi indaqs.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // L-oġġetti għandhom indirizzi ugwali, iżda `Trait` għandu implimentazzjonijiet differenti.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Il-konverżjoni tar-referenza għal `*const u8` tqabbel skont l-indirizz.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash pointer nej.
///
/// Dan jista 'jintuża biex jinqasam referenza `&T` (li tisforza għal `*const T` impliċitament) bl-indirizz tagħha aktar milli bil-valur li tipponta għalih (li huwa dak li tagħmel l-implimentazzjoni `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls għal indikaturi tal-funzjoni
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Il-mitfugħa intermedja kif użata hija meħtieġa għall-AVR
                // sabiex l-ispazju tal-indirizz tal-pointer tal-funzjoni tas-sors jiġi ppreservat fil-pointer tal-funzjoni finali.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Il-mitfugħa intermedja kif użata hija meħtieġa għall-AVR
                // sabiex l-ispazju tal-indirizz tal-pointer tal-funzjoni tas-sors jiġi ppreservat fil-pointer tal-funzjoni finali.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // L-ebda funzjoni varjdika b'0 parametri
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Oħloq pointer nej `const` għal post, mingħajr ma toħloq referenza intermedja.
///
/// Il-ħolqien ta 'referenza b `&`/`&mut` huwa permess biss jekk il-pointer huwa allinjat sewwa u jindika data inizjalizzata.
/// Għal każijiet fejn dawk ir-rekwiżiti ma jżommux, minflok għandhom jintużaw indikaturi mhux ipproċessati.
/// Madankollu, `&expr as *const _` joħloq referenza qabel ma titfa 'fuq pointer nej, u dik ir-referenza hija soġġetta għall-istess regoli bħar-referenzi l-oħra kollha.
///
/// Din il-makro tista 'toħloq pointer mhux ipproċessat *mingħajr ma* toħloq referenza l-ewwel.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` toħloq referenza mhux allinjata, u b'hekk tkun Imġieba Mhux Definita!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Oħloq pointer nej `mut` għal post, mingħajr ma toħloq referenza intermedja.
///
/// Il-ħolqien ta 'referenza b `&`/`&mut` huwa permess biss jekk il-pointer huwa allinjat sewwa u jindika data inizjalizzata.
/// Għal każijiet fejn dawk ir-rekwiżiti ma jżommux, minflok għandhom jintużaw indikaturi mhux ipproċessati.
/// Madankollu, `&mut expr as *mut _` joħloq referenza qabel ma titfa 'fuq pointer nej, u dik ir-referenza hija soġġetta għall-istess regoli bħar-referenzi l-oħra kollha.
///
/// Din il-makro tista 'toħloq pointer mhux ipproċessat *mingħajr ma* toħloq referenza l-ewwel.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` toħloq referenza mhux allinjata, u b'hekk tkun Imġieba Mhux Definita!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` forzi li jikkupjaw il-qasam minflok ma joħolqu referenza.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}