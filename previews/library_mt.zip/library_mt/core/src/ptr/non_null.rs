use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` iżda mhux żero u li jvarja.
///
/// Ħafna drabi din hija l-ħaġa korretta li tuża meta tibni strutturi tad-dejta bl-użu ta 'indikaturi mhux ipproċessati, iżda fl-aħħar mill-aħħar hija aktar perikoluża biex tużaha minħabba l-proprjetajiet addizzjonali tagħha.Jekk m'intix ċert jekk għandekx tuża `NonNull<T>`, sempliċement uża `*mut T`!
///
/// B'differenza minn `*mut T`, il-pointer għandu jkun dejjem mhux null, anke jekk il-pointer qatt ma jkun dereferenzjat.Dan sabiex l-enums jistgħu jużaw dan il-valur projbit bħala diskriminanti-`Option<NonNull<T>>` għandu l-istess daqs bħal `* mut T`.
/// Madankollu l-indikatur xorta jista 'jitbandal jekk ma jkunx dereferenzjat.
///
/// B'differenza minn `*mut T`, `NonNull<T>` intgħażel biex ikun iktar varjabbli fuq `T`.Dan jagħmilha possibbli li tuża `NonNull<T>` meta tibni tipi ta 'kovarjanti, iżda tintroduċi r-riskju ta' nuqqas ta 'ħoss jekk użat f'tip li fil-fatt m'għandux ikun kubarant.
/// (L-għażla opposta saret għal `*mut T` anke jekk teknikament in-nuqqas ta 'saħħa jista' jkun ikkawżat biss billi tissejjaħ funzjonijiet mhux siguri.)
///
/// Il-Covarianza hija korretta għall-aktar estrazzjonijiet sikuri, bħal `Box`, `Rc`, `Arc`, `Vec`, u `LinkedList`.Dan huwa l-każ minħabba li jipprovdu API pubblika li ssegwi r-regoli normali li jistgħu jinbidlu XOR maqsuma ta 'Rust.
///
/// Jekk it-tip tiegħek ma jistax ikun sikwit varjabbli, trid tiżgura li jkun fih xi qasam addizzjonali biex tipprovdi invarjanza.Ħafna drabi dan il-field ikun tip [`PhantomData`] bħal `PhantomData<Cell<T>>` jew `PhantomData<&'a mut T>`.
///
/// Innota li `NonNull<T>` għandu eżempju `From` għal `&T`.Madankollu, dan ma jbiddilx il-fatt li l-mutazzjoni permezz ta '(pointer derivat minn a) referenza komuni hija mġieba mhux definita sakemm il-mutazzjoni ma sseħħx f [`UnsafeCell<T>`].L-istess jgħodd għall-ħolqien ta 'referenza li tista' tinbidel minn referenza kondiviża.
///
/// Meta tuża din l-istanza `From` mingħajr `UnsafeCell<T>`, hija r-responsabbiltà tiegħek li tiżgura li `as_mut` qatt ma jissejjaħ, u `as_ptr` qatt ma jintuża għal mutazzjoni.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` pointers mhumiex `Send` minħabba li d-dejta li jirreferu għaliha tista 'tkun magħrufa.
// NB, dan l-impl mhuwiex meħtieġ, iżda għandu jipprovdi messaġġi ta 'żball aħjar.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` pointers mhumiex `Sync` minħabba li d-dejta li jirreferu għaliha tista 'tkun magħrufa.
// NB, dan l-impl mhuwiex meħtieġ, iżda għandu jipprovdi messaġġi ta 'żball aħjar.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Joħloq `NonNull` ġdid li huwa mdendel, iżda allinjat sewwa.
    ///
    /// Dan huwa utli għall-inizjalizzazzjoni ta 'tipi li jallokaw b'mod għażżien, bħal ma jagħmel `Vec::new`.
    ///
    /// Innota li l-valur tal-pointer jista 'potenzjalment jirrappreżenta pointer validu għal `T`, li jfisser li dan m'għandux jintuża bħala valur sentinella "not yet initialized".
    /// Tipi li jallokaw b'mod għażżien għandhom isegwu l-inizjalizzazzjoni b'xi mezzi oħra.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURTÀ: mem::align_of() jirritorna użu mhux żero li mbagħad jiġi mitfugħ
        // lil * mut T.
        // Għalhekk, `ptr` mhuwiex null u l-kundizzjonijiet għas-sejħa lil new_unchecked() huma rispettati.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Jirritorna referenzi kondiviżi għall-valur.B'kuntrast ma [`as_ref`], dan ma jeħtieġx li l-valur irid jiġi inizjalizzat.
    ///
    /// Għall-kontroparti li tista 'tinbidel ara [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun allinjat sewwa.
    ///
    /// * Għandu jkun "dereferencable" fis-sens definit f [the module documentation].
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer tindika m'għandhiex issir mutazzjoni (ħlief ġewwa `UnsafeCell`).
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jissodisfa l-
        // rekwiżiti għal referenza.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Jirritorna referenzi uniċi għall-valur.B'kuntrast ma [`as_mut`], dan ma jeħtieġx li l-valur irid jiġi inizjalizzat.
    ///
    /// Għall-kontroparti maqsuma ara [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun allinjat sewwa.
    ///
    /// * Għandu jkun "dereferencable" fis-sens definit f [the module documentation].
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer jindika għaliha m'għandhiex tkun aċċessata (moqrija jew miktuba) permezz ta' kwalunkwe pointer ieħor.
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jissodisfa l-
        // rekwiżiti għal referenza.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Toħloq `NonNull` ġdid.
    ///
    /// # Safety
    ///
    /// `ptr` m'għandux ikun null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `ptr` mhuwiex null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Joħloq `NonNull` ġdid jekk `ptr` mhuwiex null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURTÀ: Il-pointer huwa diġà ċċekkjat u mhux null
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Jwettaq l-istess funzjonalità bħal [`std::ptr::from_raw_parts`], ħlief li jintbagħat lura pointer `NonNull`, għall-kuntrarju ta 'pointer `*const` mhux ipproċessat.
    ///
    ///
    /// Ara d-dokumentazzjoni ta [`std::ptr::from_raw_parts`] għal aktar dettalji.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SIGURTÀ: Ir-riżultat ta `ptr::from::raw_parts_mut` mhuwiex null minħabba li `data_address` huwa.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Iddekomponi pointer (possibilment wiesa ') f'komponenti ta' l-indirizz u tal-metadejta.
    ///
    /// Il-pointer jista 'jiġi rikostruwit aktar tard b [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Tikseb il-pointer sottostanti `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Jirritorna referenza kondiviża għall-valur.Jekk il-valur jista 'jkun mhux inizjalizzat, minflok għandu jintuża [`as_uninit_ref`].
    ///
    /// Għall-kontroparti li tista 'tinbidel ara [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun allinjat sewwa.
    ///
    /// * Għandu jkun "dereferencable" fis-sens definit f [the module documentation].
    ///
    /// * Il-pointer għandu jindika istanza inizjalizzata ta `T`.
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer tindika m'għandhiex issir mutazzjoni (ħlief ġewwa `UnsafeCell`).
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    /// (Il-parti dwar l-inizjalizzazzjoni għadha mhix deċiża għal kollox, iżda sakemm tkun, l-uniku approċċ sigur huwa li jiġi żgurat li huma tabilħaqq inizjalizzati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jissodisfa l-
        // rekwiżiti għal referenza.
        unsafe { &*self.as_ptr() }
    }

    /// Jirritorna referenza unika għall-valur.Jekk il-valur jista 'jkun mhux inizjalizzat, minflok għandu jintuża [`as_uninit_mut`].
    ///
    /// Għall-kontroparti maqsuma ara [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun allinjat sewwa.
    ///
    /// * Għandu jkun "dereferencable" fis-sens definit f [the module documentation].
    ///
    /// * Il-pointer għandu jindika istanza inizjalizzata ta `T`.
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer jindika għaliha m'għandhiex tkun aċċessata (moqrija jew miktuba) permezz ta' kwalunkwe pointer ieħor.
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    /// (Il-parti dwar l-inizjalizzazzjoni għadha mhix deċiża għal kollox, iżda sakemm tkun, l-uniku approċċ sigur huwa li jiġi żgurat li huma tabilħaqq inizjalizzati.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jissodisfa l-
        // rekwiżiti għal referenza li tista 'tinbidel.
        unsafe { &mut *self.as_ptr() }
    }

    /// Titfa 'fuq pointer ta' tip ieħor.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SIGURTÀ: `self` huwa pointer `NonNull` li huwa neċessarjament mhux null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Joħloq porzjon nej mhux null minn pointer irqiq u tul.
    ///
    /// L-argument `len` huwa n-numru ta '**elementi**, mhux in-numru ta' bytes.
    ///
    /// Din il-funzjoni hija sigura, iżda d-dereferenzjar tal-valur tar-ritorn mhuwiex sikur.
    /// Ara d-dokumentazzjoni ta [`slice::from_raw_parts`] għar-rekwiżiti tas-sigurtà tal-porzjon.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // oħloq pointer slice meta tibda bil-pointer għall-ewwel element
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Innota li dan l-eżempju artifiċjalment juri użu ta 'dan il-metodu, imma `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SIGURTÀ: `data` huwa pointer `NonNull` li huwa neċessarjament mhux null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Jirritorna t-tul ta 'porzjon nej mhux null.
    ///
    /// Il-valur mogħti lura huwa n-numru ta '**elementi**, mhux in-numru ta' bytes.
    ///
    /// Din il-funzjoni hija sigura, anke meta l-porzjon nej mhux null ma jistax jiġi dereferenzjat għal porzjon minħabba li l-pointer m'għandux indirizz validu.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Jirritorna pointer mhux null fil-buffer tal-porzjon.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SIGURTÀ: Nafu li `self` mhuwiex null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Jirritorna pointer nej għall-buffer tal-porzjon.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Jirritorna referenza kondiviża għal porzjon ta 'valuri possibilment mhux inizjalizzati.B'kuntrast ma [`as_ref`], dan ma jeħtieġx li l-valur irid jiġi inizjalizzat.
    ///
    /// Għall-kontroparti li tista 'tinbidel ara [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun [valid] għal qari għal `ptr.len() * mem::size_of::<T>()` ħafna bytes, u għandu jkun allinjat sewwa.Dan ifisser b'mod partikolari:
    ///
    ///     * Il-firxa sħiħa tal-memorja ta 'din il-porzjon għandha tkun f'oġġett wieħed allokat!
    ///       Slices qatt ma jistgħu jinfirxu fuq oġġetti allokati multipli.
    ///
    ///     * Il-pointer għandu jkun allinjat anke għal flieli ta 'tul żero.
    ///     Raġuni waħda għal dan hija li l-ottimizzazzjonijiet tat-tqassim tal-enum jistgħu jiddependu fuq referenzi (inklużi flieli ta 'kwalunkwe tul) li jkunu allinjati u mhux nulli biex tiddistingwihom minn dejta oħra.
    ///
    ///     Tista 'tikseb pointer li jista' jintuża bħala `data` għal flieli ta 'tul żero billi tuża [`NonNull::dangling()`].
    ///
    /// * Id-daqs totali `ptr.len() * mem::size_of::<T>()` tal-porzjon m'għandux ikun akbar minn `isize::MAX`.
    ///   Ara d-dokumentazzjoni tas-sigurtà ta [`pointer::offset`].
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer tindika m'għandhiex issir mutazzjoni (ħlief ġewwa `UnsafeCell`).
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    ///
    /// Ara wkoll [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Jirritorna referenza unika għal porzjon ta 'valuri possibilment mhux inizjalizzati.B'kuntrast ma [`as_mut`], dan ma jeħtieġx li l-valur irid jiġi inizjalizzat.
    ///
    /// Għall-kontroparti maqsuma ara [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Meta ssejjaħ dan il-metodu, għandek tiżgura li dan kollu li ġej huwa veru:
    ///
    /// * Il-pointer għandu jkun [valid] għal jaqra u jikteb għal `ptr.len() * mem::size_of::<T>()` ħafna bytes, u għandu jkun allinjat sewwa.Dan ifisser b'mod partikolari:
    ///
    ///     * Il-firxa sħiħa tal-memorja ta 'din il-porzjon għandha tkun f'oġġett wieħed allokat!
    ///       Slices qatt ma jistgħu jinfirxu fuq oġġetti allokati multipli.
    ///
    ///     * Il-pointer għandu jkun allinjat anke għal flieli ta 'tul żero.
    ///     Raġuni waħda għal dan hija li l-ottimizzazzjonijiet tat-tqassim tal-enum jistgħu jiddependu fuq referenzi (inklużi flieli ta 'kwalunkwe tul) li jkunu allinjati u mhux nulli biex tiddistingwihom minn dejta oħra.
    ///
    ///     Tista 'tikseb pointer li jista' jintuża bħala `data` għal flieli ta 'tul żero billi tuża [`NonNull::dangling()`].
    ///
    /// * Id-daqs totali `ptr.len() * mem::size_of::<T>()` tal-porzjon m'għandux ikun akbar minn `isize::MAX`.
    ///   Ara d-dokumentazzjoni tas-sigurtà ta [`pointer::offset`].
    ///
    /// * Int trid tinforza r-regoli ta 'aliasing ta' Rust, billi l-ħajja ritornata `'a` tintgħażel b'mod arbitrarju u mhux neċessarjament tirrifletti l-ħajja attwali tad-dejta.
    ///   B'mod partikolari, għat-tul ta 'din il-ħajja, il-memorja li l-pointer jindika għaliha m'għandhiex tkun aċċessata (moqrija jew miktuba) permezz ta' kwalunkwe pointer ieħor.
    ///
    /// Dan japplika anke jekk ir-riżultat ta 'dan il-metodu ma jintużax!
    ///
    /// Ara wkoll [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dan huwa sigur peress li `memory` huwa validu għal jaqra u jikteb għal `memory.len()` ħafna bytes.
    /// // Innota li s-sejħa lil `memory.as_mut()` mhix permessa hawnhekk minħabba li l-kontenut jista 'jkun mhux inizjalizzat.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Jirritorna pointer mhux maħdum għal element jew subslice, mingħajr ma jagħmel verifika tal-limiti.
    ///
    /// Li ssejjaħ dan il-metodu b'indiċi barra mill-limiti jew meta `self` mhuwiex dereferenzjabbli huwa *[imġieba mhux definita]* anke jekk il-pointer li jirriżulta ma jintużax.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SIGURTÀ: min iċempel jiżgura li `self` huwa dereferenzjabbli u `index` fil-limiti.
        // Bħala konsegwenza, il-pointer li jirriżulta ma jistax ikun NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SIGURTÀ: Puntatur uniku ma jistax ikun null, allura l-kundizzjonijiet għal
        // new_unchecked() huma rispettati.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURTÀ: Referenza li tista 'tinbidel ma tistax tkun nulla.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SIGURTÀ: Referenza ma tistax tkun nulla, allura l-kundizzjonijiet għal
        // new_unchecked() huma rispettati.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}