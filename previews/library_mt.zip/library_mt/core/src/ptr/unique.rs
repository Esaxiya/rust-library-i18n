use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Tgeżwir madwar `*mut T` mhux raffinat mhux null li jindika li l-pussessur ta `dan it-tgeżwir għandu r-referent.
/// Utli għall-estrazzjonijiet tal-bini bħal `Box<T>`, `Vec<T>`, `String`, u `HashMap<K, V>`.
///
/// B'differenza minn `*mut T`, `Unique<T>` iġib ruħu "as if" kien eżempju ta `T`.
/// Huwa jimplimenta `Send`/`Sync` jekk `T` huwa `Send`/`Sync`.
/// Timplika wkoll it-tip ta 'garanziji qawwija ta' aliasing li istanza ta `T` tista' tistenna:
/// ir-referent tal-pointer m'għandux jiġi modifikat mingħajr triq unika għall-uniku tagħha.
///
/// Jekk m'intix ċert dwar jekk huwiex korrett li tuża `Unique` għall-iskopijiet tiegħek, ikkunsidra li tuża `NonNull`, li għandha semantika aktar dgħajfa.
///
///
/// B'differenza minn `*mut T`, il-pointer għandu jkun dejjem mhux null, anke jekk il-pointer qatt ma jkun dereferenzjat.
/// Dan sabiex l-enums jistgħu jużaw dan il-valur projbit bħala diskriminanti-`Option<Unique<T>>` għandu l-istess daqs bħal `Unique<T>`.
/// Madankollu l-indikatur xorta jista 'jitbandal jekk ma jkunx dereferenzjat.
///
/// B'differenza minn `*mut T`, `Unique<T>` huwa ko-varjanti fuq `T`.
/// Dan għandu dejjem ikun korrett għal kwalunkwe tip li jħares ir-rekwiżiti ta 'aliasing ta' Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: din il-marka m'għandhiex konsegwenzi għall-varjanza, iżda hija meħtieġa
    // biex Dropck jifhem li aħna loġikament għandna `T`.
    //
    // Għad-dettalji, ara:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` l-indikaturi huma `Send` jekk `T` huwa `Send` minħabba li d-dejta li jirreferu għaliha mhix imxekkla.
/// Innota li din l-invariant magħrufa mhix infurzata mis-sistema tat-tip;l-astrazzjoni li tuża x-`Unique` għandha tinforzaha.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` l-indikaturi huma `Sync` jekk `T` huwa `Sync` minħabba li d-dejta li jirreferu għaliha mhix imxekkla.
/// Innota li din l-invariant magħrufa mhix infurzata mis-sistema tat-tip;l-astrazzjoni li tuża x-`Unique` għandha tinforzaha.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Joħloq `Unique` ġdid li huwa mdendel, iżda allinjat sewwa.
    ///
    /// Dan huwa utli għall-inizjalizzazzjoni ta 'tipi li jallokaw b'mod għażżien, bħal ma jagħmel `Vec::new`.
    ///
    /// Innota li l-valur tal-pointer jista 'potenzjalment jirrappreżenta pointer validu għal `T`, li jfisser li dan m'għandux jintuża bħala valur sentinella "not yet initialized".
    /// Tipi li jallokaw b'mod għażżien għandhom isegwu l-inizjalizzazzjoni b'xi mezzi oħra.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SIGURTÀ: mem::align_of() jirritorna pointer validu u mhux null.Il
        // kundizzjonijiet biex tissejjaħ new_unchecked() huma għalhekk rispettati.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Toħloq `Unique` ġdid.
    ///
    /// # Safety
    ///
    /// `ptr` m'għandux ikun null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `ptr` mhuwiex null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Joħloq `Unique` ġdid jekk `ptr` mhuwiex null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIGURTÀ: Il-pointer diġà ġie kkontrollat u mhux null.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Tikseb il-pointer sottostanti `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Id-differenzi fil-kontenut.
    ///
    /// Il-ħajja li tirriżulta hija marbuta waħedha u għalhekk din iġġib ruħha "as if" kienet fil-fatt eżempju ta 'T li qed tissellef.
    /// Jekk hija meħtieġa ħajja itwal ta (unbound), uża `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jissodisfa l-
        // rekwiżiti għal referenza.
        unsafe { &*self.as_ptr() }
    }

    /// Iddeferenzja b'mod reċiproku l-kontenut.
    ///
    /// Il-ħajja li tirriżulta hija marbuta waħedha u għalhekk din iġġib ruħha "as if" kienet fil-fatt eżempju ta 'T li qed tissellef.
    /// Jekk hija meħtieġa ħajja itwal ta (unbound), uża `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jissodisfa l-
        // rekwiżiti għal referenza li tista 'tinbidel.
        unsafe { &mut *self.as_ptr() }
    }

    /// Titfa 'fuq pointer ta' tip ieħor.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SIGURTÀ: Unique::new_unchecked() joħloq unika ġdida u bżonnijiet
        // il-pointer mogħti ma jkunx null.
        // Peress li qed ngħaddu lilu nnifsu bħala pointer, ma jistax ikun null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIGURTÀ: Referenza li tista 'tinbidel ma tistax tkun nulla
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}