#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` jippermetti lill-implimentatur ta 'eżekutur tal-kompitu joħloq [`Waker`] li jipprovdi imġieba ta' wakeup personalizzata.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Din tikkonsisti minn indikatur tad-dejta u [virtual function pointer table (vtable)][vtable] li tippersonalizza l-imġieba tax-`RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Pointer tad-data, li jista 'jintuża biex jaħżen data arbitrarja kif meħtieġ mill-eżekutur.
    /// Dan jista 'jkun eż
    /// pointer imħassar tat-tip għal `Arc` li huwa assoċjat mal-kompitu.
    /// Il-valur ta 'dan il-qasam jgħaddi għall-funzjonijiet kollha li huma parti mill-vtable bħala l-ewwel parametru.
    ///
    data: *const (),
    /// Tabella tal-pointer tal-funzjoni virtwali li tippersonalizza l-imġieba ta 'dan il-waker.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Toħloq `RawWaker` ġdid mill-pointer `data` u `vtable` ipprovduti.
    ///
    /// Il-pointer `data` jista 'jintuża biex jaħżen dejta arbitrarja kif meħtieġ mill-eżekutur.Dan jista 'jkun eż
    /// pointer imħassar tat-tip għal `Arc` li huwa assoċjat mal-kompitu.
    /// Il-valur ta 'dan il-pointer se jgħaddi għall-funzjonijiet kollha li huma parti mix-`vtable` bħala l-ewwel parametru.
    ///
    /// Ix-`vtable` jippersonalizza l-imġieba ta `Waker` li tinħoloq minn `RawWaker`.
    /// Għal kull operazzjoni fuq ix-`Waker`, il-funzjoni assoċjata fix-`vtable` tax-`RawWaker` sottostanti se tissejjaħ.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tabella tal-indikatur tal-funzjoni virtwali (vtable) li tispeċifika l-imġieba ta [`RawWaker`].
///
/// Il-pointer mgħoddi għall-funzjonijiet kollha ġewwa l-vtable huwa l-pointer `data` mill-oġġett li jagħlaq [`RawWaker`].
///
/// Il-funzjonijiet ġewwa din l-istruttura huma maħsuba biss biex jissejħu fuq il-pointer `data` ta 'oġġett [`RawWaker`] mibni sewwa minn ġewwa l-implimentazzjoni [`RawWaker`].
/// Li ssejjaħ waħda mill-funzjonijiet kontenuti billi tuża kwalunkwe pointer `data` ieħor tikkawża imġieba mhux definita.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Din il-funzjoni tissejjaħ meta x-[`RawWaker`] jiġi kklonat, eż. Meta x-[`Waker`] li fih huwa maħżun ix-[`RawWaker`] jiġi kklonat.
    ///
    /// L-implimentazzjoni ta 'din il-funzjoni għandha żżomm ir-riżorsi kollha li huma meħtieġa għal din l-istanza addizzjonali ta' [`RawWaker`] u kompitu assoċjat.
    /// Li ssejjaħ `wake` fuq ix-[`RawWaker`] li jirriżulta għandu jirriżulta f'qajjem ta 'l-istess kompitu li kien ikun imqajjem mix-[`RawWaker`] oriġinali.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Din il-funzjoni tissejjaħ meta `wake` tissejjaħ fuq ix-[`Waker`].
    /// Għandu jqajjem il-kompitu assoċjat ma 'dan ix-[`RawWaker`].
    ///
    /// L-implimentazzjoni ta 'din il-funzjoni għandha tiżgura li tirrilaxxa kwalunkwe riżorsi li huma assoċjati ma' din l-istanza ta [`RawWaker`] u kompitu assoċjat.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Din il-funzjoni tissejjaħ meta `wake_by_ref` tissejjaħ fuq ix-[`Waker`].
    /// Għandu jqajjem il-kompitu assoċjat ma 'dan ix-[`RawWaker`].
    ///
    /// Din il-funzjoni hija simili għal `wake`, iżda m'għandhiex tikkonsma l-indikatur tad-dejta pprovdut.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Din il-funzjoni tissejjaħ meta [`RawWaker`] jitwaqqa '.
    ///
    /// L-implimentazzjoni ta 'din il-funzjoni għandha tiżgura li tirrilaxxa kwalunkwe riżorsi li huma assoċjati ma' din l-istanza ta [`RawWaker`] u kompitu assoċjat.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Joħloq `RawWakerVTable` ġdid mill-funzjonijiet provduti `clone`, `wake`, `wake_by_ref`, u `drop`.
    ///
    /// # `clone`
    ///
    /// Din il-funzjoni tissejjaħ meta x-[`RawWaker`] jiġi kklonat, eż. Meta x-[`Waker`] li fih huwa maħżun ix-[`RawWaker`] jiġi kklonat.
    ///
    /// L-implimentazzjoni ta 'din il-funzjoni għandha żżomm ir-riżorsi kollha li huma meħtieġa għal din l-istanza addizzjonali ta' [`RawWaker`] u kompitu assoċjat.
    /// Li ssejjaħ `wake` fuq ix-[`RawWaker`] li jirriżulta għandu jirriżulta f'qajjem ta 'l-istess kompitu li kien ikun imqajjem mix-[`RawWaker`] oriġinali.
    ///
    /// # `wake`
    ///
    /// Din il-funzjoni tissejjaħ meta `wake` tissejjaħ fuq ix-[`Waker`].
    /// Għandu jqajjem il-kompitu assoċjat ma 'dan ix-[`RawWaker`].
    ///
    /// L-implimentazzjoni ta 'din il-funzjoni għandha tiżgura li tirrilaxxa kwalunkwe riżorsi li huma assoċjati ma' din l-istanza ta [`RawWaker`] u kompitu assoċjat.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Din il-funzjoni tissejjaħ meta `wake_by_ref` tissejjaħ fuq ix-[`Waker`].
    /// Għandu jqajjem il-kompitu assoċjat ma 'dan ix-[`RawWaker`].
    ///
    /// Din il-funzjoni hija simili għal `wake`, iżda m'għandhiex tikkonsma l-indikatur tad-dejta pprovdut.
    ///
    /// # `drop`
    ///
    /// Din il-funzjoni tissejjaħ meta [`RawWaker`] jitwaqqa '.
    ///
    /// L-implimentazzjoni ta 'din il-funzjoni għandha tiżgura li tirrilaxxa kwalunkwe riżorsi li huma assoċjati ma' din l-istanza ta [`RawWaker`] u kompitu assoċjat.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// Ix-`Context` ta 'kompitu mhux sinkroniku.
///
/// Bħalissa, `Context` iservi biss biex jipprovdi aċċess għal `&Waker` li jista 'jintuża biex iqajjem il-kompitu kurrenti.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Żgura li aħna future-prova kontra bidliet fil-varjanza billi ġġiegħel il-ħajja ma tkunx invarjabbli (il-ħajja tal-pożizzjoni tal-argument hija kontravarianta waqt li l-ħajja tal-pożizzjoni tar-ritorn hija ko-varjanti).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Oħloq `Context` ġdid minn `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Jirritorna referenza għax-`Waker` għall-kompitu kurrenti.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` huwa manku biex tqajjem kompitu billi tinnotifika lill-eżekutur tiegħu li huwa lest biex jitħaddem.
///
/// Dan il-manku jiġbor fih istanza [`RawWaker`], li tiddefinixxi l-imġieba ta 'wakeup speċifika għall-eżekutur.
///
///
/// Timplimenta [`Clone`], [`Send`], u [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Qajjem il-kompitu assoċjat ma 'dan ix-`Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Is-sejħa ta 'riattivazzjoni attwali hija ddelegata permezz ta' sejħa ta 'funzjoni virtwali għall-implimentazzjoni li hija definita mill-eżekutur.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Tsejjaħx lil `drop`-il-waker jiġi kkunsmat minn `wake`.
        crate::mem::forget(self);

        // SIGURTÀ: Dan huwa sigur għax `Waker::from_raw` huwa l-uniku mod
        // biex jinizjalizza `wake` u `data` li jeħtieġu lill-utent jirrikonoxxi li l-kuntratt ta `RawWaker` huwa milqugħ.
        //
        unsafe { (wake)(data) };
    }

    /// Qajjem il-kompitu assoċjat ma 'dan ix-`Waker` mingħajr ma tikkonsma x-`Waker`.
    ///
    /// Dan huwa simili għal `wake`, iżda jista 'jkun kemmxejn inqas effiċjenti fil-każ fejn `Waker` ta' proprjetà jkun disponibbli.
    /// Dan il-metodu għandu jkun preferut milli jsejjaħ `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Is-sejħa ta 'riattivazzjoni attwali hija ddelegata permezz ta' sejħa ta 'funzjoni virtwali għall-implimentazzjoni li hija definita mill-eżekutur.
        //

        // SIGURTÀ: ara `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Jirritorna `true` jekk dan `Waker` u `Waker` ieħor qajmu l-istess kompitu.
    ///
    /// Din il-funzjoni taħdem fuq bażi ta 'l-aħjar sforz, u tista' tirritorna falza anke meta l-'Waker` iqajjem l-istess kompitu.
    /// Madankollu, jekk din il-funzjoni tirritorna `true`, huwa garantit li l-'Waker` iqajjem l-istess kompitu.
    ///
    /// Din il-funzjoni tintuża primarjament għal skopijiet ta 'ottimizzazzjoni.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Toħloq `Waker` ġdid minn [`RawWaker`].
    ///
    /// L-imġieba tax-`Waker` mibgħut lura mhix definita jekk il-kuntratt definit fid-dokumentazzjoni ta '["RawWaker"] u ["RawWakerVTable"] ma jiġix milqugħ.
    ///
    /// Għalhekk dan il-metodu mhuwiex sigur.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SIGURTÀ: Dan huwa sigur għax `Waker::from_raw` huwa l-uniku mod
            // biex jinizjalizza `clone` u `data` li jeħtieġu lill-utent jirrikonoxxi li l-kuntratt ta [`RawWaker`] huwa milqugħ.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SIGURTÀ: Dan huwa sigur għax `Waker::from_raw` huwa l-uniku mod
        // biex jinizjalizza `drop` u `data` li jeħtieġu lill-utent jirrikonoxxi li l-kuntratt ta `RawWaker` huwa milqugħ.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}