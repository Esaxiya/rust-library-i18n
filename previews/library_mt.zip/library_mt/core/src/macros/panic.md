Panics il-ħajta attwali.

Dan jippermetti li programm jintemm immedjatament u jipprovdi feedback lil dak li jċempel il-programm.
`panic!` għandhom jintużaw meta programm jilħaq stat li ma jistax jiġi rkuprat.

Din il-makro hija l-mod perfett biex tasserixxi kundizzjonijiet f'kodiċi ta 'eżempju u f'testijiet.
`panic!` huwa marbut mill-qrib mal-metodu `unwrap` kemm ta 'enumerazzjonijiet [`Option`][ounwrap] kif ukoll [`Result`][runwrap].
Iż-żewġ implimentazzjonijiet jitolbu `panic!` meta jkunu ssettjati għal varjanti [`None`] jew [`Err`].

Meta tuża `panic!()` tista 'tispeċifika tagħbija ta' spaga, li hija mibnija bl-użu tas-sintassi [`format!`].
Dik it-tagħbija użata tintuża meta tinjetta panic fil-ħajta Rust li ssejjaħ, u tikkawża l-ħajta għal panic kompletament.

L-imġieba tal-default `std` hook, jiġifieri
il-kodiċi li jaħdem direttament wara li jiġi invokat iż-panic, huwa li tistampa l-payload tal-messaġġ lil `stderr` flimkien mal-informazzjoni file/line/column tas-sejħa `panic!()`.

Tista 'twarrab iż-panic hook billi tuża [`std::panic::set_hook()`].
Ġewwa l-hook jista 'jiġi aċċessat panic bħala `&dyn Any + Send`, li fih jew `&str` jew `String` għal invokazzjonijiet regolari ta' `panic!()`.
Għal panic b'valur ta 'tip ieħor ieħor, [`panic_any`] jista' jintuża.

[`Result`] enum ħafna drabi hija soluzzjoni aħjar biex tirkupra minn żbalji milli tuża l-makro `panic!`.
Din il-makro għandha tintuża biex tevita li tipproċedi billi tuża valuri skorretti, bħal minn sorsi esterni.
Informazzjoni dettaljata dwar it-trattament tal-iżbalji tinstab fix-[book].

Ara wkoll il-makro [`compile_error!`], biex tqajjem żbalji waqt il-kumpilazzjoni.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Implimentazzjoni attwali

Jekk il-ħajta prinċipali panics se ttemm il-ħjut kollha tiegħek u ttemm il-programm tiegħek bil-kodiċi `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





