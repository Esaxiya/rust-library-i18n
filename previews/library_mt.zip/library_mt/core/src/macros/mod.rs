#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Tespandi jew għal `$crate::panic::panic_2015` jew `$crate::panic::panic_2021` skont l-edizzjoni ta 'min iċempel.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Tasserixxi li żewġ espressjonijiet huma ugwali għal xulxin (billi tuża [`PartialEq`]).
///
/// Fuq panic, din il-makro tipprintja l-valuri tal-espressjonijiet bir-rappreżentazzjonijiet ta 'debug tagħhom.
///
///
/// Bħal [`assert!`], din il-makro għandha t-tieni forma, fejn jista 'jiġi pprovdut messaġġ panic personalizzat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ir-reborrows hawn taħt huma intenzjonati.
                    // Mingħajrhom, is-slot tal-munzell għas-self jiġi inizjalizzat anke qabel ma jitqabblu l-valuri, li jwassal għal tnaqqis notevoli.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Ir-reborrows hawn taħt huma intenzjonati.
                    // Mingħajrhom, is-slot tal-munzell għas-self jiġi inizjalizzat anke qabel ma jitqabblu l-valuri, li jwassal għal tnaqqis notevoli.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Tasserixxi li żewġ espressjonijiet mhumiex ugwali għal xulxin (billi tuża [`PartialEq`]).
///
/// Fuq panic, din il-makro tipprintja l-valuri tal-espressjonijiet bir-rappreżentazzjonijiet ta 'debug tagħhom.
///
///
/// Bħal [`assert!`], din il-makro għandha t-tieni forma, fejn jista 'jiġi pprovdut messaġġ panic personalizzat.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ir-reborrows hawn taħt huma intenzjonati.
                    // Mingħajrhom, is-slot tal-munzell għas-self jiġi inizjalizzat anke qabel ma jitqabblu l-valuri, li jwassal għal tnaqqis notevoli.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Ir-reborrows hawn taħt huma intenzjonati.
                    // Mingħajrhom, is-slot tal-munzell għas-self jiġi inizjalizzat anke qabel ma jitqabblu l-valuri, li jwassal għal tnaqqis notevoli.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Tasserixxi li espressjoni booleana hija `true` fil-ħin tal-eżekuzzjoni.
///
/// Dan jinvoka l-makro [`panic!`] jekk l-espressjoni pprovduta ma tkunx tista 'tiġi evalwata għal `true` fil-ħin tal-eżekuzzjoni.
///
/// Bħal [`assert!`], din il-makro għandha wkoll it-tieni verżjoni, fejn jista 'jiġi pprovdut messaġġ panic personalizzat.
///
/// # Uses
///
/// B'differenza minn [`assert!`], id-dikjarazzjonijiet `debug_assert!` huma attivati biss f'kompilazzjonijiet mhux ottimizzati awtomatikament.
/// Bini ottimizzat ma jeżegwixxix dikjarazzjonijiet `debug_assert!` sakemm `-C debug-assertions` ma jgħaddix lill-kompilatur.
/// Dan jagħmel `debug_assert!` utli għal kontrolli li jiswew wisq biex ikunu preżenti f'bini ta 'rilaxx iżda jistgħu jkunu ta' għajnuna waqt l-iżvilupp.
/// Ir-riżultat tal-espansjoni ta `debug_assert!` huwa dejjem iċċekkjat bit-tip.
///
/// Dikjarazzjoni mhux ivverifikata tippermetti li programm fi stat inkonsistenti jibqa 'għaddej, li jista' jkollu konsegwenzi mhux mistennija iżda ma jintroduċix nuqqas ta 'sigurtà sakemm dan jiġri biss f'kodiċi sikur.
///
/// L-ispiża tal-prestazzjoni tal-asserzjonijiet, madankollu, ma tistax titkejjel b'mod ġenerali.
/// Is-sostituzzjoni ta [`assert!`] b `debug_assert!` hija għalhekk imħeġġa biss wara profiling bir-reqqa, u aktar importanti minn hekk, f'kodiċi sikur biss!
///
/// # Examples
///
/// ```
/// // il-messaġġ panic għal dawn l-affermazzjonijiet huwa l-valur strinċifikat tal-espressjoni mogħtija.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // funzjoni sempliċi ħafna
/// debug_assert!(some_expensive_computation());
///
/// // afferma b'messaġġ personalizzat
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Tasserixxi li żewġ espressjonijiet huma ugwali għal xulxin.
///
/// Fuq panic, din il-makro tipprintja l-valuri tal-espressjonijiet bir-rappreżentazzjonijiet ta 'debug tagħhom.
///
/// B'differenza minn [`assert_eq!`], id-dikjarazzjonijiet `debug_assert_eq!` huma attivati biss f'kompilazzjonijiet mhux ottimizzati awtomatikament.
/// Bini ottimizzat ma jeżegwixxix dikjarazzjonijiet `debug_assert_eq!` sakemm `-C debug-assertions` ma jgħaddix lill-kompilatur.
/// Dan jagħmel `debug_assert_eq!` utli għal kontrolli li jiswew wisq biex ikunu preżenti f'bini ta 'rilaxx iżda jistgħu jkunu ta' għajnuna waqt l-iżvilupp.
///
/// Ir-riżultat tal-espansjoni ta `debug_assert_eq!` huwa dejjem iċċekkjat bit-tip.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Tasserixxi li żewġ espressjonijiet mhumiex ugwali għal xulxin.
///
/// Fuq panic, din il-makro tipprintja l-valuri tal-espressjonijiet bir-rappreżentazzjonijiet ta 'debug tagħhom.
///
/// B'differenza minn [`assert_ne!`], id-dikjarazzjonijiet `debug_assert_ne!` huma attivati biss f'kompilazzjonijiet mhux ottimizzati awtomatikament.
/// Bini ottimizzat ma jeżegwixxix dikjarazzjonijiet `debug_assert_ne!` sakemm `-C debug-assertions` ma jgħaddix lill-kompilatur.
/// Dan jagħmel `debug_assert_ne!` utli għal kontrolli li jiswew wisq biex ikunu preżenti f'bini ta 'rilaxx iżda jistgħu jkunu ta' għajnuna waqt l-iżvilupp.
///
/// Ir-riżultat tal-espansjoni ta `debug_assert_ne!` huwa dejjem iċċekkjat bit-tip.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Jirritorna jekk l-espressjoni mogħtija taqbilx ma 'xi mudell mogħti.
///
/// Bħal f'espressjoni `match`, il-mudell jista 'jkun segwit b'għażla minn `if` u espressjoni ta' gwardja li għandha aċċess għal ismijiet marbuta mill-mudell.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Ikxef riżultat jew ixerred l-iżball tiegħu.
///
/// L-operatur `?` ġie miżjud biex jieħu post `try!` u minflok għandu jintuża.
/// Barra minn hekk, `try` hija kelma riservata f'Rust 2018, allura jekk trid tużaha, ikollok bżonn tuża [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` taqbel max-[`Result`] mogħti.Fil-każ tal-varjant `Ok`, l-espressjoni għandha l-valur tal-valur imgeżwer.
///
/// Fil-każ tal-varjant `Err`, jirkupra l-iżball intern.`try!` imbagħad iwettaq konverżjoni bl-użu ta `From`.
/// Dan jipprovdi konverżjoni awtomatika bejn żbalji speċjalizzati u oħrajn aktar ġenerali.
/// L-iżball li jirriżulta mbagħad jintbagħat lura immedjatament.
///
/// Minħabba r-ritorn kmieni, `try!` jista 'jintuża biss f'funzjonijiet li jirritornaw [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Il-metodu preferut ta 'Żbalji li jirritornaw malajr
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Il-metodu preċedenti ta 'Żbalji li jirritornaw malajr
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dan huwa ekwivalenti għal:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Jikteb id-dejta fformattjata ġo buffer.
///
/// Din il-makro taċċetta 'writer', sekwenza ta 'format, u lista ta' argumenti.
/// L-argumenti jiġu fformattjati skond is-sekwenza tal-format speċifikat u r-riżultat jgħaddi lill-kittieb.
/// Il-kittieb jista 'jkun kwalunkwe valur b'metodu `write_fmt`;ġeneralment dan jiġi minn implimentazzjoni jew ta [`fmt::Write`] jew [`io::Write`] trait.
/// Il-makro tirritorna dak kollu li jirritorna l-metodu `write_fmt`;komunement [`fmt::Result`], jew [`io::Result`].
///
/// Ara [`std::fmt`] għal aktar informazzjoni dwar is-sintassi tas-sekwenza tal-format.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modulu jista 'jimporta kemm `std::fmt::Write` kif ukoll `std::io::Write` u jsejjaħ `write!` fuq oġġetti li jimplimentaw it-tnejn, billi l-oġġetti tipikament ma jimplimentawx it-tnejn.
///
/// Madankollu, il-modulu għandu jimporta ż-traits kwalifikat sabiex isimhom ma jmurx kontra:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // juża fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // juża io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Din il-makro tista 'tintuża wkoll f'installazzjonijiet `no_std`.
/// Fi setup `no_std` int responsabbli għad-dettalji tal-implimentazzjoni tal-komponenti.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Ikteb dejta fformattjata ġo buffer, b'linja ġdida mehmuża.
///
/// Fuq il-pjattaformi kollha, il-linja l-ġdida hija l-karattru LINE FEED (`\n`/`U+000A`) waħdu (l-ebda RITORN TA `ĠARR (`\r`/`U+000D`) addizzjonali.
///
/// Għal aktar informazzjoni, ara [`write!`].Għal informazzjoni dwar is-sintassi tas-sekwenza tal-format, ara [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modulu jista 'jimporta kemm `std::fmt::Write` kif ukoll `std::io::Write` u jsejjaħ `write!` fuq oġġetti li jimplimentaw it-tnejn, billi l-oġġetti tipikament ma jimplimentawx it-tnejn.
/// Madankollu, il-modulu għandu jimporta ż-traits kwalifikat sabiex isimhom ma jmurx kontra:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // juża fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // juża io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Tindika kodiċi li ma jistax jintlaħaq.
///
/// Dan huwa utli kull ħin li l-kompilatur ma jistax jiddetermina li xi kodiċi ma jistax jintlaħaq.Pereżempju:
///
/// * Qabbad id-dirgħajn mal-kundizzjonijiet tal-gwardja.
/// * Loops li jispiċċaw b'mod dinamiku.
/// * Iteraturi li jispiċċaw b'mod dinamiku.
///
/// Jekk id-determinazzjoni li l-kodiċi ma jistax jintlaħaq ma tkunx korretta, il-programm jintemm immedjatament b [`panic!`].
///
/// Il-kontroparti mhux sigura ta 'din il-makro hija l-funzjoni [`unreachable_unchecked`], li tikkawża imġieba mhux definita jekk jintlaħaq il-kodiċi.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dan dejjem ikun [`panic!`].
///
/// # Examples
///
/// Match armi:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // tiġbor żball jekk ikkummentat
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // waħda mill-ifqar implimentazzjonijiet ta x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Tindika kodiċi mhux implimentat billi tieħu paniku b'messaġġ ta "not implemented".
///
/// Dan jippermetti lill-kodiċi tiegħek li tivverifika t-tip, li huwa utli jekk qed tipprototipja jew timplimenta trait li teħtieġ metodi multipli li ma tippjanax li tuża kollha.
///
/// Id-differenza bejn `unimplemented!` u [`todo!`] hija li filwaqt li `todo!` iwassal intenzjoni li jimplimenta l-funzjonalità aktar tard u l-messaġġ huwa "not yet implemented", `unimplemented!` ma jagħmel l-ebda pretensjoni bħal din.
/// Il-messaġġ tiegħu huwa "not implemented".
/// Ukoll xi IDEs se jimmarkaw 'todo! `S.
///
/// # Panics
///
/// Dan dejjem ikun [`panic!`] għax `unimplemented!` huwa biss stenografija għal `panic!` b'messaġġ fiss u speċifiku.
///
/// Bħal `panic!`, din il-makro għandha t-tieni forma biex turi valuri tad-dwana.
///
/// # Examples
///
/// Ngħidu li għandna trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Irridu nimplimentaw `Foo` għal 'MyStruct', iżda għal xi raġuni jagħmel sens biss li nimplimentaw il-funzjoni `bar()`.
/// `baz()` u `qux()` għad iridu jiġu definiti fl-implimentazzjoni tagħna ta `Foo`, imma nistgħu nużaw `unimplemented!` fid-definizzjonijiet tagħhom biex inħallu l-kodiċi tagħna jikkompila.
///
/// Aħna xorta rridu li l-programm tagħna jieqaf jaħdem jekk jintlaħqu l-metodi mhux implimentati.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Ma jagħmel l-ebda sens li `baz` a `MyStruct`, allura aħna m'għandna l-ebda loġika hawnhekk.
/////
///         // Dan juri "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Għandna xi loġika hawnhekk, Nistgħu nżidu messaġġ għal mhux implimentat!biex nuru l-ommissjoni tagħna.
///         // Dan juri: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Tindika kodiċi mhux mitmum.
///
/// Dan jista 'jkun utli jekk tkun qed tagħmel prototipi u qed tfittex biss li jkollok il-kodiċi typecheck tiegħek.
///
/// Id-differenza bejn [`unimplemented!`] u `todo!` hija li filwaqt li `todo!` iwassal intenzjoni li jimplimenta l-funzjonalità aktar tard u l-messaġġ huwa "not yet implemented", `unimplemented!` ma jagħmel l-ebda pretensjoni bħal din.
/// Il-messaġġ tiegħu huwa "not implemented".
/// Ukoll xi IDEs se jimmarkaw 'todo! `S.
///
/// # Panics
///
/// Dan dejjem ikun [`panic!`].
///
/// # Examples
///
/// Hawn hu eżempju ta 'xi kodiċi li għadu għaddej.Għandna trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Irridu nimplimentaw `Foo` fuq wieħed mit-tipi tagħna, imma rridu wkoll naħdmu fuq `bar()` biss l-ewwel.Sabiex il-kodiċi tagħna jikkompila, għandna bżonn nimplimentaw `baz()`, sabiex inkunu nistgħu nużaw `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implimentazzjoni tmur hawn
///     }
///
///     fn baz(&self) {
///         // ejja ma ninkwetawx dwar l-implimentazzjoni ta baz() għalissa
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // lanqas biss qed nużaw baz(), allura dan tajjeb.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definizzjonijiet ta 'macros inkorporati.
///
/// Ħafna mill-proprjetajiet makro (stabbiltà, viżibilità, eċċ.) Huma meħuda mill-kodiċi tas-sors hawn, bl-eċċezzjoni ta 'funzjonijiet ta' espansjoni li jittrasformaw inputs makro f'outputs, dawk il-funzjonijiet huma pprovduti mill-kompilatur.
///
///
pub(crate) mod builtin {

    /// Jikkawża li l-kumpilazzjoni tfalli bil-messaġġ ta `żball mogħti meta tiltaqa` magħha.
    ///
    /// Din il-makro għandha tintuża meta crate juża strateġija ta 'kumpilazzjoni kondizzjonali biex jipprovdi messaġġi ta' żball aħjar għal kundizzjonijiet żbaljati.
    ///
    /// Hija l-forma tal-livell tal-kompilatur ta [`panic!`], iżda toħroġ żball waqt il-*kumpilazzjoni* aktar milli f'*runtime*.
    ///
    /// # Examples
    ///
    /// Żewġ eżempji bħal dawn huma macros u ambjenti `#[cfg]`.
    ///
    /// Emetti żball aħjar tal-kompilatur jekk makro tgħaddi valuri invalidi.
    /// Mingħajr l-aħħar branch, il-kompilatur xorta jarmi żball, iżda l-messaġġ tal-iżball ma jsemmix iż-żewġ valuri validi.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Emetti żball tal-kompilatur jekk waħda minn numru ta 'karatteristiċi ma tkunx disponibbli.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Jibni parametri għall-makros l-oħra tal-ifformattjar tas-sekwenza.
    ///
    /// Din il-makro tiffunzjona billi tieħu string tal-ifformattjar litterali li fih `{}` għal kull argument addizzjonali mgħoddi.
    /// `format_args!` jipprepara l-parametri addizzjonali biex jiżgura li l-output jista 'jiġi interpretat bħala sekwenza u canonicalizes l-argumenti f'tip wieħed.
    /// Kwalunkwe valur li jimplimenta [`Display`] trait jista 'jiġi mgħoddi lil `format_args!`, kif tista' kwalunkwe implimentazzjoni [`Debug`] tiġi mgħoddija lil `{:?}` fi ħdan is-sekwenza tal-ifformattjar.
    ///
    ///
    /// Din il-makro tipproduċi valur tat-tip [`fmt::Arguments`].Dan il-valur jista 'jiġi mgħoddi lill-macros fi ħdan [`std::fmt`] għat-twettiq ta' direzzjoni mill-ġdid utli.
    /// Il-macros l-oħra kollha tal-ifformattjar ([`format!`], [`write!`], [`println!`], eċċ) huma rrappreżentati permezz ta 'din.
    /// `format_args!`, kuntrarjament għall-macros derivati tagħha, tevita l-allokazzjonijiet tal-borġ.
    ///
    /// Tista 'tuża l-valur [`fmt::Arguments`] li `format_args!` jirritorna f'kuntesti `Debug` u `Display` kif jidher hawn taħt.
    /// L-eżempju juri wkoll li l-format `Debug` u `Display` għall-istess ħaġa: is-sekwenza tal-format interpolat f `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Għal aktar informazzjoni, ara d-dokumentazzjoni f [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// L-istess bħal `format_args`, iżda fl-aħħar iżid linja ġdida.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Tispezzjona varjabbli tal-ambjent fil-ħin tal-kompilazzjoni.
    ///
    /// Din il-makro se tespandi għall-valur tal-varjabbli tal-ambjent imsemmi fil-ħin tal-kompilazzjoni, u tagħti espressjoni tat-tip `&'static str`.
    ///
    ///
    /// Jekk il-varjabbli ta 'l-ambjent mhix definita, allura jinħareġ żball ta' kumpilazzjoni.
    /// Biex ma tarmix żball ta 'kompilazzjoni, uża l-makro [`option_env!`] minflok.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Tista 'tippersonalizza l-messaġġ ta' żball billi tgħaddi sekwenza bħala t-tieni parametru:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Jekk il-varjabbli ta 'l-ambjent `documentation` mhix definita, ikollok l-iżball li ġej:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// B'għażla tispezzjona varjabbli ta 'l-ambjent fil-ħin tal-kompilazzjoni.
    ///
    /// Jekk il-varjabbli tal-ambjent imsemmi huwa preżenti fil-ħin tal-kompilazzjoni, dan se jespandi f'espressjoni tat-tip `Option<&'static str>` li l-valur tiegħu huwa `Some` tal-valur tal-varjabbli tal-ambjent.
    /// Jekk il-varjabbli tal-ambjent mhix preżenti, allura dan se jespandi għal `None`.
    /// Ara [`Option<T>`][Option] għal aktar informazzjoni dwar dan it-tip.
    ///
    /// Żball fil-ħin tal-kompilazzjoni qatt ma joħroġ meta tuża din il-makro irrispettivament minn jekk il-varjabbli tal-ambjent hix preżenti jew le.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Jikkonkatina l-identifikaturi f'identifikatur wieħed.
    ///
    /// Din il-makro tieħu kwalunkwe numru ta 'identifikaturi separati mill-virgola, u tikkonkatenahom kollha f'wieħed, u tagħti espressjoni li hija identifikatur ġdid.
    /// Innota li l-iġjene tagħmilha tali li din il-makro ma tistax taqbad varjabbli lokali.
    /// Ukoll, bħala regola ġenerali, il-macros huma permessi biss f'pożizzjoni ta 'oġġett, dikjarazzjoni jew espressjoni.
    /// Dan ifisser li waqt li tista 'tuża din il-makro biex tirreferi għal varjabbli eżistenti, funzjonijiet jew moduli eċċ, ma tistax tiddefinixxi waħda ġdida magħha.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (ġdid, divertenti, isem) { }//ma jistax jintuża b'dan il-mod!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Jikkonkatina l-letterali fi porzjon ta 'sekwenza statika.
    ///
    /// Din il-makro tieħu kwalunkwe numru ta 'letterali separati mill-virgola, u tagħti espressjoni tat-tip `&'static str` li tirrappreżenta l-letterali kollha konkatenati mix-xellug għal-lemin.
    ///
    ///
    /// Litterali in-numru sħiħ u f'punt li jvarja huma ssikkati sabiex jiġu konkatenati.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tespandi għan-numru tal-linja li fuqu ġiet invokata.
    ///
    /// B [`column!`] u [`file!`], dawn il-macros jipprovdu informazzjoni ta 'debugging għall-iżviluppaturi dwar il-post fis-sors.
    ///
    /// L-espressjoni estiża għandha t-tip `u32` u hija bbażata fuq 1, allura l-ewwel linja f'kull fajl tevalwa għal 1, it-tieni għal 2, eċċ.
    /// Dan huwa konsistenti ma 'messaġġi ta' żball minn kompilaturi komuni jew edituri popolari.
    /// Il-linja rritornata hija *mhux neċessarjament* il-linja tal-invokazzjoni `line!` innifisha, iżda pjuttost l-ewwel invokazzjoni makro li twassal għall-invokazzjoni tal-makro `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Tespandi għan-numru tal-kolonna li fih ġiet invokata.
    ///
    /// B [`line!`] u [`file!`], dawn il-macros jipprovdu informazzjoni ta 'debugging għall-iżviluppaturi dwar il-post fis-sors.
    ///
    /// L-espressjoni estiża għandha t-tip `u32` u hija bbażata fuq 1, allura l-ewwel kolonna f'kull linja tevalwa għal 1, it-tieni għal 2, eċċ.
    /// Dan huwa konsistenti ma 'messaġġi ta' żball minn kompilaturi komuni jew edituri popolari.
    /// Il-kolonna rritornata hija *mhux neċessarjament* il-linja tal-invokazzjoni `column!` innifisha, iżda pjuttost l-ewwel invokazzjoni makro li twassal għall-invokazzjoni tal-makro `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Tespandi għall-isem tal-fajl li fih ġie invokat.
    ///
    /// B [`line!`] u [`column!`], dawn il-macros jipprovdu informazzjoni ta 'debugging għall-iżviluppaturi dwar il-post fis-sors.
    ///
    /// L-espressjoni estiża għandha t-tip `&'static str`, u l-fajl mibgħut lura mhuwiex l-invokazzjoni tal-makro `file!` innifsu, iżda pjuttost l-ewwel invokazzjoni makro li twassal għall-invokazzjoni tal-makro `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Jenfasizza l-argumenti tiegħu.
    ///
    /// Din il-makro tagħti espressjoni tat-tip `&'static str` li hija l-istringifikazzjoni taż-tokens kollha mgħoddija lill-makro.
    /// Ma titpoġġa l-ebda restrizzjoni fuq is-sintassi tal-invokazzjoni makro nnifisha.
    ///
    /// Innota li r-riżultati estiżi tal-input tokens jistgħu jinbidlu fiż-future.Għandek toqgħod attent jekk tistrieħ fuq il-produzzjoni.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Jinkludi fajl ikkodifikat UTF-8 bħala sekwenza.
    ///
    /// Il-fajl jinsab relattivament għall-fajl kurrenti (b`mod simili għal kif jinstabu l-moduli).
    /// Il-passaġġ ipprovdut huwa interpretat b'mod speċifiku għall-pjattaforma fil-ħin tal-kompilazzjoni.
    /// Allura, pereżempju, invokazzjoni b'passaġġ Windows li jkun fih backslashes `\` ma tiġborx b'mod korrett fuq Unix.
    ///
    ///
    /// Din il-makro tagħti espressjoni tat-tip `&'static str` li huwa l-kontenut tal-fajl.
    ///
    /// # Examples
    ///
    /// Assumi li hemm żewġ fajls fl-istess direttorju bil-kontenut li ġej:
    ///
    /// Fajl 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fajl 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Il-kumpilazzjoni ta 'main.rs' u t-tħaddim tal-binarju li jirriżulta jistampaw "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Jinkludi fajl bħala referenza għal array ta 'byte.
    ///
    /// Il-fajl jinsab relattivament għall-fajl kurrenti (b`mod simili għal kif jinstabu l-moduli).
    /// Il-passaġġ ipprovdut huwa interpretat b'mod speċifiku għall-pjattaforma fil-ħin tal-kompilazzjoni.
    /// Allura, pereżempju, invokazzjoni b'passaġġ Windows li jkun fih backslashes `\` ma tiġborx b'mod korrett fuq Unix.
    ///
    ///
    /// Din il-makro tagħti espressjoni tat-tip `&'static [u8; N]` li huwa l-kontenut tal-fajl.
    ///
    /// # Examples
    ///
    /// Assumi li hemm żewġ fajls fl-istess direttorju bil-kontenut li ġej:
    ///
    /// Fajl 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fajl 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Il-kumpilazzjoni ta 'main.rs' u t-tħaddim tal-binarju li jirriżulta jistampaw "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tespandi għal sekwenza li tirrappreżenta t-triq tal-modulu kurrenti.
    ///
    /// It-triq tal-modulu attwali tista 'titqies bħala l-ġerarkija tal-moduli li jwasslu lura għaż-crate root.
    /// L-ewwel komponent tal-passaġġ mibgħut lura huwa l-isem taż-crate li bħalissa qed jiġi kkompilat.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Jevalwa kombinazzjonijiet booleani ta 'bnadar ta' konfigurazzjoni fil-ħin tal-kumpilazzjoni.
    ///
    /// Minbarra l-attribut `#[cfg]`, din il-makro hija pprovduta biex tippermetti evalwazzjoni tal-espressjoni booleana tal-bnadar tal-konfigurazzjoni.
    /// Dan spiss iwassal għal kodiċi inqas duplikat.
    ///
    /// Is-sintassi mogħtija lil din il-makro hija l-istess sintassi bħall-attribut [`cfg`].
    ///
    /// `cfg!`, kuntrarjament għal `#[cfg]`, ma jneħħi l-ebda kodiċi u jevalwa biss għal veru jew falz.
    /// Pereżempju, il-blokki kollha f'espressjoni if/else għandhom ikunu validi meta jintuża `cfg!` għall-kundizzjoni, irrispettivament minn dak li qed jevalwa `cfg!`.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Analizza fajl bħala espressjoni jew oġġett skont il-kuntest.
    ///
    /// Il-fajl jinsab relattivament għall-fajl kurrenti (b`mod simili għal kif jinstabu l-moduli).Il-passaġġ ipprovdut huwa interpretat b'mod speċifiku għall-pjattaforma fil-ħin tal-kompilazzjoni.
    /// Allura, pereżempju, invokazzjoni b'passaġġ Windows li jkun fih backslashes `\` ma tiġborx b'mod korrett fuq Unix.
    ///
    /// L-użu ta 'din il-makro ħafna drabi hija idea ħażina, għax jekk il-fajl jiġi analizzat bħala espressjoni, se jitqiegħed fil-kodiċi tal-madwar b'mod mhux iġjeniku.
    /// Dan jista 'jirriżulta f'varjabbli jew funzjonijiet differenti minn dak li kien jistenna l-fajl jekk hemm varjabbli jew funzjonijiet li għandhom l-istess isem fil-fajl kurrenti.
    ///
    ///
    /// # Examples
    ///
    /// Assumi li hemm żewġ fajls fl-istess direttorju bil-kontenut li ġej:
    ///
    /// Fajl 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fajl 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Il-kumpilazzjoni ta 'main.rs' u t-tħaddim tal-binarju li jirriżulta jistampaw "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Tasserixxi li espressjoni booleana hija `true` fil-ħin tal-eżekuzzjoni.
    ///
    /// Dan jinvoka l-makro [`panic!`] jekk l-espressjoni pprovduta ma tkunx tista 'tiġi evalwata għal `true` fil-ħin tal-eżekuzzjoni.
    ///
    /// # Uses
    ///
    /// L-asserzjonijiet huma dejjem iċċekkjati kemm fid-debug kif ukoll fir-release builds, u ma jistgħux jiġu diżattivati.
    /// Ara [`debug_assert!`] għal affermazzjonijiet li mhumiex attivati fil-builds tar-rilaxx b'mod awtomatiku.
    ///
    /// Kodiċi mhux sikur jista 'joqgħod fuq `assert!` biex jinforza invariants run-time li, jekk jinkisru jistgħu jwasslu għal nuqqas ta' sigurtà.
    ///
    /// Każijiet oħra ta 'użu ta' `assert!` jinkludu l-ittestjar u l-infurzar ta 'invariants run-time f'kodiċi bla periklu (li l-ksur tagħhom ma jistax jirriżulta f'nuqqas ta' sigurtà).
    ///
    ///
    /// # Messaġġi Custom
    ///
    /// Din il-makro għandha t-tieni forma, fejn messaġġ panic apposta jista 'jiġi pprovdut bi jew mingħajr argumenti għall-ifformattjar.
    /// Ara [`std::fmt`] għas-sintassi għal din il-formola.
    /// Espressjonijiet użati bħala argumenti tal-format jiġu evalwati biss jekk l-affermazzjoni tfalli.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // il-messaġġ panic għal dawn l-affermazzjonijiet huwa l-valur strinċifikat tal-espressjoni mogħtija.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // funzjoni sempliċi ħafna
    ///
    /// assert!(some_computation());
    ///
    /// // afferma b'messaġġ personalizzat
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Assemblaġġ inline.
    ///
    /// Aqra x-[unstable book] għall-użu.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Assemblaġġ inline stil LLVM.
    ///
    /// Aqra x-[unstable book] għall-użu.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Assemblaġġ inline fil-livell tal-modulu.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// L-istampi għaddew lil tokens fil-produzzjoni standard.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Jippermetti jew jiddiżattiva l-funzjonalità tat-traċċar użata għad-debugging ta 'macros oħra.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro tal-attribut użat biex tapplika macros derivati.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attribut makro applikat għal funzjoni biex tibdilha f'test tal-unità.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attribwixxi makro applikata għal funzjoni biex tibdilha f'test ta 'referenza.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Dettall tal-implimentazzjoni tal-macros `#[test]` u `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attribut makro applikat għal statiku biex tirreġistrah bħala allokatur globali.
    ///
    /// Ara wkoll [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Iżomm l-oġġett li għalih huwa applikat jekk il-passaġġ mgħoddi huwa aċċessibbli, u jneħħih mod ieħor.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Tespandi l-attributi `#[cfg]` u `#[cfg_attr]` kollha fil-framment tal-kodiċi li huwa applikat għalih.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Dettall ta 'implimentazzjoni instabbli tal-kompilatur `rustc`, tużax.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Dettall ta 'implimentazzjoni instabbli tal-kompilatur `rustc`, tużax.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}