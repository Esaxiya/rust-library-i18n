#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Fih definizzjonijiet ta 'strutturi għat-tqassim ta' tipi inkorporati tal-kompilatur.
//!
//! Jistgħu jintużaw bħala miri ta 'transmutes f'kodiċi mhux sikuri biex jimmanipulaw ir-rappreżentazzjonijiet mhux ipproċessati direttament.
//!
//!
//! Id-definizzjoni tagħhom għandha dejjem taqbel mal-ABI definita f `rustc_middle::ty::layout`.
//!

/// Ir-rappreżentazzjoni ta 'oġġett trait bħal `&dyn SomeTrait`.
///
/// Din l-istruttura għandha l-istess tqassim bħal tipi bħal `&dyn SomeTrait` u `Box<dyn AnotherTrait>`.
///
/// `TraitObject` huwa garantit li jaqbel mat-taqsimiet, iżda mhuwiex it-tip ta 'oġġetti trait (eż., l-oqsma mhumiex aċċessibbli direttament fuq `&dyn SomeTrait`) u lanqas ma jikkontrolla dak it-tqassim (it-tibdil tad-definizzjoni ma jbiddilx it-tqassim ta' `&dyn SomeTrait`).
///
/// Huwa ddisinjat biss biex jintuża minn kodiċi mhux sikur li jeħtieġ jimmanipula d-dettalji ta 'livell baxx.
///
/// M'hemm l-ebda mod kif tirreferi għall-oġġetti trait kollha b'mod ġeneriku, allura l-uniku mod biex jinħolqu valuri ta 'dan it-tip huwa b'funzjonijiet bħal [`std::mem::transmute`][transmute].
/// Bl-istess mod, l-uniku mod biex toħloq oġġett trait veru minn valur `TraitObject` huwa b `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Is-sintetizzazzjoni ta 'oġġett trait b'tipi mhux imqabbla-wieħed fejn il-vtable ma jikkorrispondix mat-tip tal-valur li għalih jindika l-indikatur tad-dejta-x'aktarx iwassal għal imġieba mhux definita.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // eżempju trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // ħalli l-kompilatur jagħmel oġġett trait
/// let object: &dyn Foo = &value;
///
/// // ħares lejn ir-rappreżentazzjoni prima
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // l-indikatur tad-dejta huwa l-indirizz ta `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // ibni oġġett ġdid, li tipponta lejn `i32` differenti, waqt li toqgħod attent li tuża l-vtable `i32` minn `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // għandu jaħdem bħallikieku bnejna oġġett trait minn `other_value` direttament
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}