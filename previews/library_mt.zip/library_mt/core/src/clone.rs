//! Ix-`Clone` trait għal tipi li ma jistgħux jiġu 'kkupjati b'mod impliċitu'.
//!
//! F'Rust, xi tipi sempliċi huma "implicitly copyable" u meta tassenjahom jew tgħaddihom bħala argumenti, ir-riċevitur jirċievi kopja, u jħalli l-valur oriġinali f'postu.
//! Dawn it-tipi ma jeħtiġux allokazzjoni biex jiġu kkupjati u m'għandhomx finalizzaturi (jiġifieri, ma fihomx kaxex jew jimplimentaw [`Drop`]), allura l-kompilatur iqishom irħas u sikuri biex jiġu kkupjati.
//!
//! Għal tipi oħra kopji għandhom isiru b'mod espliċitu, b'konvenzjoni li timplimenta [`Clone`] trait u ssejjaħ il-metodu [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Eżempju ta 'użu bażiku:
//!
//! ```
//! let s = String::new(); // String type jimplimenta Klonu
//! let copy = s.clone(); // sabiex inkunu nistgħu nikklonawh
//! ```
//!
//! Biex timplimenta faċilment il-Klonu trait, tista 'tuża wkoll `#[derive(Clone)]`.Eżempju:
//!
//! ```
//! #[derive(Clone)] // inżidu l-Klonu trait ma `Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // u issa nistgħu nikklonawh!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// trait komuni għall-abbiltà li jidduplika espliċitament oġġett.
///
/// Differenti minn [`Copy`] f'dak [`Copy`] huwa impliċitu u estremament irħis, filwaqt li `Clone` huwa dejjem espliċitu u jista 'jkun jew le.
/// Sabiex tinforza dawn il-karatteristiċi, Rust ma jippermettilekx timplimenta mill-ġdid [`Copy`], imma tista 'timplimenta mill-ġdid `Clone` u tmexxi kodiċi arbitrarju.
///
/// Peress li `Clone` huwa aktar ġenerali minn [`Copy`], tista 'awtomatikament tagħmel xi ħaġa [`Copy`] tkun `Clone` ukoll.
///
/// ## Derivable
///
/// Dan trait jista 'jintuża ma' `#[derive]` jekk l-oqsma kollha huma `Clone`.L-implimentazzjoni `derivata`d ta [`Clone`] titlob [`clone`] fuq kull qasam.
///
/// [`clone`]: Clone::clone
///
/// Għal struttura ġenerika, `#[derive]` jimplimenta `Clone` kundizzjonalment billi jżid `Clone` marbut fuq parametri ġeneriċi.
///
/// ```
/// // `derive` timplimenta Klonu għall-Qari<T>meta T huwa Klonu.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kif nista 'nimplimenta `Clone`?
///
/// Tipi li huma [`Copy`] għandu jkollhom implimentazzjoni trivjali ta `Clone`.Aktar formalment:
/// jekk `T: Copy`, `x: T`, u `y: &T`, allura `let x = y.clone();` huwa ekwivalenti għal `let x = *y;`.
/// Implimentazzjonijiet manwali għandhom joqogħdu attenti biex iżommu din l-invariant;madankollu, kodiċi mhux sikur m'għandux joqgħod fuqu biex tkun żgurata s-sigurtà tal-memorja.
///
/// Eżempju huwa struttura ġenerika li żżomm pointer tal-funzjoni.F'dan il-każ, l-implimentazzjoni ta `Clone` ma tistax tkun "derivata" d, iżda tista' tiġi implimentata bħala:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Implimentaturi addizzjonali
///
/// Minbarra x-[implementors listed below][impls], it-tipi li ġejjin jimplimentaw ukoll `Clone`:
///
/// * Tipi ta 'oġġett ta' funzjoni (jiġifieri, it-tipi distinti definiti għal kull funzjoni)
/// * Tipi ta 'pointer tal-funzjoni (eż., `fn() -> i32`)
/// * Tipi ta 'matriċi, għad-daqsijiet kollha, jekk it-tip ta' oġġett jimplimenta wkoll `Clone` (eż., `[i32; 123456]`)
/// * Tipi ta 'tupli, jekk kull komponent jimplimenta wkoll `Clone` (eż., `()`, `(i32, bool)`)
/// * Tipi ta 'għeluq, jekk ma jaqbdu l-ebda valur mill-ambjent jew jekk dawn il-valuri kollha maqbuda jimplimentaw `Clone` huma stess.
///   Innota li l-varjabbli maqbuda b'referenza maqsuma dejjem jimplimentaw `Clone` (anke jekk ir-referent ma jagħmilx), filwaqt li l-varjabbli maqbuda b'referenza li tinbidel qatt ma jimplimentaw `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Jirritorna kopja tal-valur.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str timplimenta Klonu
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Twettaq kopja-assenjazzjoni minn `source`.
    ///
    /// `a.clone_from(&b)` hija ekwivalenti għal `a = b.clone()` fil-funzjonalità, iżda tista 'tiġi megħluba biex terġa' tuża r-riżorsi ta `a` biex tevita allokazzjonijiet bla bżonn.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Iġbed makro li jiġġenera impl ta 'trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): dawn l-istrutturi jintużaw biss minn#[derivati] biex jaffermaw li kull komponent ta 'tip jimplimenta Klonu jew Kopja.
//
//
// Dawn l-istrutturi m'għandhom qatt jidhru fil-kodiċi tal-utent.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implimentazzjonijiet ta `Clone` għal tipi primittivi.
///
/// Implimentazzjonijiet li ma jistgħux jiġu deskritti f'Rust huma implimentati f `traits::SelectionContext::copy_clone_conditions()` f `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referenzi kondiviżi jistgħu jiġu kklonati, iżda referenzi li jistgħu jinbidlu *ma jistgħux*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Referenzi kondiviżi jistgħu jiġu kklonati, iżda referenzi li jistgħu jinbidlu *ma jistgħux*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}