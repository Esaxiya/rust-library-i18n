//! Dan il-modulu jimplimenta `Any` trait, li jippermetti ttajpjar dinamiku ta 'kwalunkwe tip `'static` permezz ta' riflessjoni tal-ħin ta 'eżekuzzjoni.
//!
//! `Any` innifsu jista 'jintuża biex jikseb `TypeId`, u għandu aktar karatteristiċi meta jintuża bħala oġġett trait.
//! Bħala `&dyn Any` (oġġett trait misluf), għandu l-metodi `is` u `downcast_ref`, biex jittestja jekk il-valur miżmum huwiex ta 'tip partikolari, u biex tikseb referenza għall-valur intern bħala tip.
//! Bħala `&mut dyn Any`, hemm ukoll il-metodu `downcast_mut`, biex tinkiseb referenza li tista 'tinbidel għall-valur intern.
//! `Box<dyn Any>` iżid il-metodu `downcast`, li jipprova jikkonverti għal `Box<T>`.
//! Ara d-dokumentazzjoni [`Box`] għad-dettalji sħaħ.
//!
//! Innota li `&dyn Any` huwa limitat għall-ittestjar jekk valur huwiex ta 'tip speċifiku ta' konkrit, u ma jistax jintuża biex jiġi ttestjat jekk tip jimplimentax trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smart pointers u `dyn Any`
//!
//! Biċċa waħda ta 'mġieba li għandek iżżomm f'moħħok meta tuża `Any` bħala oġġett trait, speċjalment b'tipi bħal `Box<dyn Any>` jew `Arc<dyn Any>`, hija li sempliċement issejjaħ `.type_id()` fuq il-valur jipproduċi `TypeId` tal-*kontenitur*, mhux l-oġġett sottostanti trait.
//!
//! Dan jista 'jiġi evitat billi tikkonverti l-indikatur intelliġenti f `&dyn Any` minflok, li jirritorna `TypeId` tal-oġġett.
//! Pereżempju:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // X'aktarx li trid dan:
//! let actual_id = (&*boxed).type_id();
//! // ... minn dan:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Ikkunsidra sitwazzjoni fejn irridu niskonnettjaw valur mgħoddi lil funzjoni.
//! Nafu l-valur li qed naħdmu fuqu jimplimenta Debug, imma ma nafux it-tip konkret tiegħu.Irridu nagħtu trattament speċjali lil ċerti tipi: f'dan il-każ l-istampar tat-tul tal-valuri String qabel il-valur tagħhom.
//! Ma nafux it-tip konkret tal-valur tagħna fil-ħin tal-kompilazzjoni, għalhekk għandna bżonn nużaw riflessjoni tal-runtime minflok.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Funzjoni Logger għal kwalunkwe tip li timplimenta Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Ipprova tikkonverti l-valur tagħna għal `String`.
//!     // Jekk tirnexxi, irridu nwasslu t-tul tas-String kif ukoll il-valur tagħha.
//!     // Jekk le, huwa tip differenti: sempliċement ipprintjah mingħajr dekorazzjoni.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Din il-funzjoni trid tilloggja l-parametru tagħha qabel ma tagħmel xogħol magħha.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... agħmel xi xogħol ieħor
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Kwalunkwe trait
///////////////////////////////////////////////////////////////////////////////

/// A trait biex jimita t-tajping dinamiku.
///
/// Ħafna tipi jimplimentaw `Any`.Madankollu, kull tip li fih referenza mhux "statika" ma fihx.
/// Ara x-[module-level documentation][mod] għal aktar dettalji.
///
/// [mod]: crate::any
// Dan trait mhuwiex perikoluż, għalkemm aħna niddependu fuq l-ispeċifiċitajiet tal-funzjoni `type_id` tal-unika impl tiegħu fil-kodiċi mhux sikur (eż. `downcast`).Normalment, dik tkun problema, iżda minħabba li l-unika impl ta `Any` hija implimentazzjoni blanket, l-ebda kodiċi ieħor ma jista' jimplimenta `Any`.
//
// Aħna nistgħu nagħmlu dan trait bla periklu-ma jikkawżax ksur, peress li nikkontrollaw l-implimentazzjonijiet kollha-imma nagħżlu li ma nagħmlux hekk kif dak mhux verament neċessarju u jista 'jħawwad lill-utenti dwar id-distinzjoni ta' traits mhux siguri u metodi mhux siguri (jiġifieri, `type_id` xorta jkun sikur li ċċempel, imma x'aktarx inkunu rridu nindikaw bħala tali fid-dokumentazzjoni).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Tikseb ix-`TypeId` ta `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metodi ta 'estensjoni għal Kwalunkwe oġġett trait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Kun żgur li r-riżultat ta 'eż. It-twaħħil ta' ħajt jista 'jiġi stampat u għalhekk jintuża ma' `unwrap`.
// Jista 'eventwalment ma jibqax meħtieġ jekk id-dispaċċ jaħdem ma' upcasting.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Jirritorna `true` jekk it-tip f'kaxxa huwa l-istess bħal `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Ikseb `TypeId` tat-tip li din il-funzjoni hija istanzjata miegħu.
        let t = TypeId::of::<T>();

        // Ikseb `TypeId` tat-tip fl-oġġett trait (`self`).
        let concrete = self.type_id();

        // Qabbel iż-żewġ "TypeId" dwar l-ugwaljanza.
        t == concrete
    }

    /// Jirritorna xi referenza għall-valur fil-kaxxa jekk huwa tat-tip `T`, jew `None` jekk le.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SIGURTÀ: ikkontrollajna biss jekk inkunux qed nindikaw it-tip korrett, u nistgħu niddependu fuq
            // dak il-kontroll għas-sigurtà tal-memorja għax implimentajna Kwalunkwe għat-tipi kollha;l-ebda impls oħra ma jistgħu jeżistu peress li jkunu f'kunflitt mal-impl. tagħna.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Jirritorna xi referenza li tista 'tinbidel għall-valur fil-kaxxa jekk huwa tat-tip `T`, jew `None` jekk le.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SIGURTÀ: ikkontrollajna biss jekk inkunux qed nindikaw it-tip korrett, u nistgħu niddependu fuq
            // dak il-kontroll għas-sigurtà tal-memorja għax implimentajna Kwalunkwe għat-tipi kollha;l-ebda impls oħra ma jistgħu jeżistu peress li jkunu f'kunflitt mal-impl. tagħna.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Quddiem il-metodu definit fuq it-tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Quddiem il-metodu definit fuq it-tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Quddiem il-metodu definit fuq it-tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Quddiem il-metodu definit fuq it-tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Quddiem il-metodu definit fuq it-tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Quddiem il-metodu definit fuq it-tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID u l-metodi tiegħu
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` jirrappreżenta identifikatur uniku globalment għal tip.
///
/// Kull `TypeId` huwa oġġett opak li ma jippermettix spezzjoni ta 'dak li hemm ġewwa imma jippermetti operazzjonijiet bażiċi bħal klonazzjoni, paragun, stampar u wiri.
///
///
/// `TypeId` bħalissa huwa disponibbli biss għal tipi li jattribwixxu għal `'static`, iżda din il-limitazzjoni tista 'titneħħa fiż-future.
///
/// Filwaqt li `TypeId` jimplimenta `Hash`, `PartialOrd`, u `Ord`, ta 'min jinnota li l-hashes u l-ordnijiet ivarjaw bejn ir-rilaxxi ta' Rust.
/// Oqgħod attent li tistrieħ fuqhom ġewwa l-kodiċi tiegħek!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Jirritorna l-`TypeId` tat-tip li din il-funzjoni ġenerika ġiet istanzjata miegħu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Jirritorna l-isem ta 'tip bħala porzjon ta' sekwenza.
///
/// # Note
///
/// Dan huwa maħsub għal użu dijanjostiku.
/// Il-kontenut eżatt u l-format tas-sekwenza rritornata mhumiex speċifikati, minbarra li huma deskrizzjoni tal-aħjar sforz tat-tip.
/// Pereżempju, fost il-kordi li `type_name::<Option<String>>()` jistgħu jirritornaw hemm `"Option<String>"` u `"std::option::Option<std::string::String>"`.
///
///
/// Is-sekwenza rritornata m'għandhiex titqies bħala identifikatur uniku ta 'tip billi tipi multipli jistgħu jimmappjaw għall-istess isem tat-tip.
/// Bl-istess mod, m'hemm l-ebda garanzija li l-partijiet kollha ta 'tip jidhru fis-sekwenza rritornata: pereżempju, speċifikaturi tal-ħajja bħalissa mhumiex inklużi.
/// Barra minn hekk, l-output jista 'jinbidel bejn verżjonijiet tal-kompilatur.
///
/// L-implimentazzjoni attwali tuża l-istess infrastruttura bħad-dijanjostika tal-kompilatur u d-debuginfo, iżda dan mhux garantit.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Jirritorna l-isem tat-tip tal-valur indikat bħala porzjon ta 'sekwenza.
/// Dan huwa l-istess bħal `type_name::<T>()`, iżda jista 'jintuża fejn it-tip ta' varjabbli mhix disponibbli faċilment.
///
/// # Note
///
/// Dan huwa maħsub għal użu dijanjostiku.Il-kontenut eżatt u l-format tas-sekwenza mhumiex speċifikati, minbarra li huma deskrizzjoni tal-aħjar sforz tat-tip.
/// Pereżempju, `type_name_of_val::<Option<String>>(None)` jista 'jirritorna `"Option<String>"` jew `"std::option::Option<std::string::String>"`, iżda mhux `"foobar"`.
///
/// Barra minn hekk, l-output jista 'jinbidel bejn verżjonijiet tal-kompilatur.
///
/// Din il-funzjoni ma ssolvix oġġetti trait, li jfisser li `type_name_of_val(&7u32 as &dyn Debug)` jista 'jirritorna `"dyn Debug"`, iżda mhux `"u32"`.
///
/// L-isem tat-tip m'għandux jitqies bħala identifikatur uniku ta 'tip;
/// tipi multipli jistgħu jaqsmu l-istess isem tat-tip.
///
/// L-implimentazzjoni attwali tuża l-istess infrastruttura bħad-dijanjostika tal-kompilatur u d-debuginfo, iżda dan mhux garantit.
///
/// # Examples
///
/// Jistampa t-tipi ta 'numru sħiħ u float default.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}