//! Intrinsiċi tal-kompilatur.
//!
//! Id-definizzjonijiet korrispondenti jinsabu f `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! L-implimentazzjoni korrispondenti tal-kost huma f `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Intrinsiċi Const
//!
//! Note: kwalunkwe bidla fil-kostanza tal-intrinsiċi għandha tiġi diskussa mat-tim tal-lingwa.
//! Dan jinkludi bidliet fl-istabbiltà tal-kostanza.
//!
//! Sabiex intrinsika tkun tista 'tintuża fil-ħin tal-kompilazzjoni, hemm bżonn li tikkopja l-implimentazzjoni minn <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> għal `compiler/rustc_mir/src/interpret/intrinsics.rs` u żżid `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ma' l-intrinsiku.
//!
//!
//! Jekk suppost jintuża intrinsiku minn `const fn` b'attribut `rustc_const_stable`, l-attribut tal-intrinsiku għandu jkun `rustc_const_stable` ukoll.
//! Bidla bħal din m'għandhiex issir mingħajr konsultazzjoni ta 'T-lang, għax taħmi karatteristika fil-lingwa li ma tistax tiġi replikata fil-kodiċi tal-utent mingħajr l-appoġġ tal-kompilatur.
//!
//! # Volatiles
//!
//! L-intrinsiċi volatili jipprovdu operazzjonijiet maħsuba biex jaġixxu fuq il-memorja I/O, li huma garantiti li ma jerġgħux jiġu ordnati mill-kompilatur fuq intrinsiċi volatili oħra.Ara d-dokumentazzjoni LLVM fuq [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! L-intrinsiċi atomiċi jipprovdu operazzjonijiet atomiċi komuni fuq kliem magna, b'ordnijiet multipli ta 'memorja possibbli.Huma jobdu l-istess semantika bħal C++ 11.Ara d-dokumentazzjoni LLVM fuq [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Aġġornament mgħaġġel dwar l-ordnijiet tal-memorja:
//!
//! * Akkwista, barriera biex takkwista serratura.Qari u kitbiet sussegwenti jseħħu wara l-barriera.
//! * Rilaxx, barriera għar-rilaxx ta 'serratura.Qari u kitbiet preċedenti jsiru qabel il-barriera.
//! * Operazzjonijiet konsistenti sekwenzjalment, konsistenti sekwenzjalment huma garantiti li jseħħu fl-ordni.Din hija l-modalità standard biex taħdem ma 'tipi atomiċi u hija ekwivalenti għal `volatile` ta' Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Dawn l-importazzjonijiet jintużaw għas-simplifikazzjoni tal-links intra-doc
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SIGURTÀ: ara `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, dawn l-intrinsiċi jieħdu indikaturi mhux ipproċessati minħabba li jbiddlu l-memorja aliased, li mhix valida la għal `&` u lanqas għal `&mut`.
    //

    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::SeqCst`] kemm bħala parametri `success` kif ukoll `failure`.
    ///
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::Acquire`] kemm bħala parametri `success` kif ukoll `failure`.
    ///
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::Release`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::AcqRel`] bħala `success` u [`Ordering::Acquire`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::Relaxed`] kemm bħala parametri `success` kif ukoll `failure`.
    ///
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::SeqCst`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::SeqCst`] bħala `success` u [`Ordering::Acquire`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::Acquire`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange` billi tgħaddi [`Ordering::AcqRel`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::SeqCst`] kemm bħala parametri `success` kif ukoll `failure`.
    ///
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::Acquire`] kemm bħala parametri `success` kif ukoll `failure`.
    ///
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::Release`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::AcqRel`] bħala `success` u [`Ordering::Acquire`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::Relaxed`] kemm bħala parametri `success` kif ukoll `failure`.
    ///
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::SeqCst`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::SeqCst`] bħala `success` u [`Ordering::Acquire`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::Acquire`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Taħżen valur jekk il-valur kurrenti huwa l-istess bħall-valur `old`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `compare_exchange_weak` billi tgħaddi [`Ordering::AcqRel`] bħala `success` u [`Ordering::Relaxed`] bħala l-parametri `failure`.
    /// Pereżempju, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Tgħabba l-valur kurrenti tal-pointer.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `load` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Tgħabba l-valur kurrenti tal-pointer.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `load` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Tgħabba l-valur kurrenti tal-pointer.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `load` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Taħżen il-valur fil-post tal-memorja speċifikat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `store` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Taħżen il-valur fil-post tal-memorja speċifikat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `store` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Taħżen il-valur fil-post tal-memorja speċifikat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `store` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Taħżen il-valur fil-post tal-memorja speċifikat, u tirritorna l-valur l-antik.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `swap` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Taħżen il-valur fil-post tal-memorja speċifikat, u tirritorna l-valur l-antik.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `swap` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Taħżen il-valur fil-post tal-memorja speċifikat, u tirritorna l-valur l-antik.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `swap` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Taħżen il-valur fil-post tal-memorja speċifikat, u tirritorna l-valur l-antik.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `swap` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Taħżen il-valur fil-post tal-memorja speċifikat, u tirritorna l-valur l-antik.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `swap` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Iżżid mal-valur kurrenti, u tirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_add` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iżżid mal-valur kurrenti, u tirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_add` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iżżid mal-valur kurrenti, u tirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_add` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iżżid mal-valur kurrenti, u tirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_add` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Iżżid mal-valur kurrenti, u tirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_add` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Naqqas mill-valur kurrenti, u rritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_sub` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Naqqas mill-valur kurrenti, u rritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_sub` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Naqqas mill-valur kurrenti, u rritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_sub` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Naqqas mill-valur kurrenti, u rritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_sub` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Naqqas mill-valur kurrenti, u rritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_sub` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise u bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_and` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise u bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_and` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise u bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_and` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise u bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_and` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise u bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_and` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitand nand bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tip [`AtomicBool`] permezz tal-metodu `fetch_nand` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tip [`AtomicBool`] permezz tal-metodu `fetch_nand` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tip [`AtomicBool`] permezz tal-metodu `fetch_nand` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tip [`AtomicBool`] permezz tal-metodu `fetch_nand` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitand nand bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tip [`AtomicBool`] permezz tal-metodu `fetch_nand` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit-bit jew bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_or` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-bit jew bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_or` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-bit jew bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_or` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-bit jew bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_or` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-bit jew bil-valur kurrenti, jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_or` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise xor bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_xor` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_xor` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_xor` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_xor` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise xor bil-valur kurrenti, u jirritorna l-valur preċedenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi [`atomic`] permezz tal-metodu `fetch_xor` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Massimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_min` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Massimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::Release`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Massimu bil-valur kurrenti bl-użu ta 'paragun mhux iffirmat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli fuq it-tipi ta' numru sħiħ mhux iffirmat [`atomic`] permezz tal-metodu `fetch_max` billi tgħaddi [`Ordering::Relaxed`] bħala `order`.
    /// Pereżempju, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// L-intrinsiku `prefetch` huwa ħjiel għall-ġeneratur tal-kodiċi biex iddaħħal struzzjoni minn qabel jekk tkun appoġġjata;inkella, huwa no-op.
    /// Prefetches m'għandhom l-ebda effett fuq l-imġieba tal-programm iżda jistgħu jbiddlu l-karatteristiċi tal-prestazzjoni tiegħu.
    ///
    /// L-argument `locality` għandu jkun numru sħiħ kostanti u huwa speċifikatur tal-lokalità temporali li jvarja minn (0), l-ebda lokalità, sa (3), iżommu lokali ħafna fil-cache.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// L-intrinsiku `prefetch` huwa ħjiel għall-ġeneratur tal-kodiċi biex iddaħħal struzzjoni minn qabel jekk tkun appoġġjata;inkella, huwa no-op.
    /// Prefetches m'għandhom l-ebda effett fuq l-imġieba tal-programm iżda jistgħu jbiddlu l-karatteristiċi tal-prestazzjoni tiegħu.
    ///
    /// L-argument `locality` għandu jkun numru sħiħ kostanti u huwa speċifikatur tal-lokalità temporali li jvarja minn (0), l-ebda lokalità, sa (3), iżommu lokali ħafna fil-cache.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// L-intrinsiku `prefetch` huwa ħjiel għall-ġeneratur tal-kodiċi biex iddaħħal struzzjoni minn qabel jekk tkun appoġġjata;inkella, huwa no-op.
    /// Prefetches m'għandhom l-ebda effett fuq l-imġieba tal-programm iżda jistgħu jbiddlu l-karatteristiċi tal-prestazzjoni tiegħu.
    ///
    /// L-argument `locality` għandu jkun numru sħiħ kostanti u huwa speċifikatur tal-lokalità temporali li jvarja minn (0), l-ebda lokalità, sa (3), iżommu lokali ħafna fil-cache.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// L-intrinsiku `prefetch` huwa ħjiel għall-ġeneratur tal-kodiċi biex iddaħħal struzzjoni minn qabel jekk tkun appoġġjata;inkella, huwa no-op.
    /// Prefetches m'għandhom l-ebda effett fuq l-imġieba tal-programm iżda jistgħu jbiddlu l-karatteristiċi tal-prestazzjoni tiegħu.
    ///
    /// L-argument `locality` għandu jkun numru sħiħ kostanti u huwa speċifikatur tal-lokalità temporali li jvarja minn (0), l-ebda lokalità, sa (3), iżommu lokali ħafna fil-cache.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Ċint atomiku.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::fence`] billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Ċint atomiku.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::fence`] billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Ċint atomiku.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::fence`] billi tgħaddi [`Ordering::Release`] bħala `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Ċint atomiku.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::fence`] billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Ostaklu tal-memorja tal-kompilatur biss.
    ///
    /// Aċċess għall-memorja qatt ma jerġgħu jiġu ordnati mill-ġdid f'din l-ostaklu mill-kompilatur, iżda l-ebda struzzjonijiet ma jiġu emessi għaliha.
    /// Dan huwa xieraq għal operazzjonijiet fuq l-istess ħajt li jistgħu jiġu pprevenuti, bħal meta tinteraġixxi ma 'dawk li jimmaniġġjaw is-sinjali.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::compiler_fence`] billi tgħaddi [`Ordering::SeqCst`] bħala `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Ostaklu tal-memorja tal-kompilatur biss.
    ///
    /// Aċċess għall-memorja qatt ma jerġgħu jiġu ordnati mill-ġdid f'din l-ostaklu mill-kompilatur, iżda l-ebda struzzjonijiet ma jiġu emessi għaliha.
    /// Dan huwa xieraq għal operazzjonijiet fuq l-istess ħajt li jistgħu jiġu pprevenuti, bħal meta tinteraġixxi ma 'dawk li jimmaniġġjaw is-sinjali.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::compiler_fence`] billi tgħaddi [`Ordering::Acquire`] bħala `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Ostaklu tal-memorja tal-kompilatur biss.
    ///
    /// Aċċess għall-memorja qatt ma jerġgħu jiġu ordnati mill-ġdid f'din l-ostaklu mill-kompilatur, iżda l-ebda struzzjonijiet ma jiġu emessi għaliha.
    /// Dan huwa xieraq għal operazzjonijiet fuq l-istess ħajt li jistgħu jiġu pprevenuti, bħal meta tinteraġixxi ma 'dawk li jimmaniġġjaw is-sinjali.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::compiler_fence`] billi tgħaddi [`Ordering::Release`] bħala `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Ostaklu tal-memorja tal-kompilatur biss.
    ///
    /// Aċċess għall-memorja qatt ma jerġgħu jiġu ordnati mill-ġdid f'din l-ostaklu mill-kompilatur, iżda l-ebda struzzjonijiet ma jiġu emessi għaliha.
    /// Dan huwa xieraq għal operazzjonijiet fuq l-istess ħajt li jistgħu jiġu pprevenuti, bħal meta tinteraġixxi ma 'dawk li jimmaniġġjaw is-sinjali.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija disponibbli f [`atomic::compiler_fence`] billi tgħaddi [`Ordering::AcqRel`] bħala `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Maġika intrinsika li toħroġ it-tifsira tagħha minn attributi marbuta mal-funzjoni.
    ///
    /// Pereżempju, dataflow juża dan biex jinjetta asserzjonijiet statiċi sabiex `rustc_peek(potentially_uninitialized)` fil-fatt jivverifika darbtejn li dataflow tabilħaqq ikkalkulat li mhix inizjalizzata f'dak il-punt fil-fluss ta 'kontroll.
    ///
    ///
    /// Dan intrinsiku m'għandux jintuża barra l-kompilatur.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Twaqqaf l-eżekuzzjoni tal-proċess.
    ///
    /// Verżjoni aktar faċli għall-utent u stabbli ta 'din l-operazzjoni hija [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Jinforma lill-ottimizzatur li dan il-punt fil-kodiċi ma jistax jintlaħaq, u jippermetti aktar ottimizzazzjonijiet.
    ///
    /// NB, dan huwa differenti ħafna mill-makro `unreachable!()`: B'differenza mill-makro, li panics meta tiġi eżegwita, huwa *imġieba mhux definita* li tilħaq kodiċi mmarkat b'din il-funzjoni.
    ///
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Tinforma lill-ottimizzatur li kundizzjoni hija dejjem vera.
    /// Jekk il-kundizzjoni hija falza, l-imġieba mhix definita.
    ///
    /// L-ebda kodiċi ma huwa ġġenerat għal dan intrinsiku, iżda l-ottimizzatur jipprova jippreservah (u l-kundizzjoni tiegħu) bejn passes, li jistgħu jinterferixxu ma 'l-ottimizzazzjoni tal-kodiċi tal-madwar u jnaqqsu l-prestazzjoni.
    /// M'għandux jintuża jekk l-invariant jista 'jiġi skopert mill-ottimizzatur waħdu, jew jekk ma jippermettix ottimizzazzjonijiet sinifikanti.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Ħjiel lill-kompilatur li l-kundizzjoni branch x'aktarx tkun vera.
    /// Jirritorna l-valur mgħoddi lilu.
    ///
    /// Kwalunkwe użu għajr ma 'dikjarazzjonijiet `if` probabbilment ma jkollux effett.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Ħjiel lill-kompilatur li l-kundizzjoni branch x'aktarx tkun falza.
    /// Jirritorna l-valur mgħoddi lilu.
    ///
    /// Kwalunkwe użu għajr ma 'dikjarazzjonijiet `if` probabbilment ma jkollux effett.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Tesegwixxi nassa tal-punt ta 'waqfien, għal spezzjoni minn debugger.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn breakpoint();

    /// Id-daqs ta 'tip f'bytes.
    ///
    /// B`mod aktar speċifiku, dan huwa l-offset f`bytes bejn oġġetti suċċessivi tal-istess tip, inkluż padding tal-allinjament.
    ///
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// L-allinjament minimu ta 'tip.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// L-allinjament preferut ta 'tip.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Id-daqs tal-valur referenzjat f'bytes.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// L-allinjament meħtieġ tal-valur referenzjat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Tikseb porzjon ta 'sekwenza statika li jkun fih l-isem ta' tip.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Tikseb identifikatur li huwa globalment uniku għat-tip speċifikat.
    /// Din il-funzjoni tirritorna l-istess valur għal tip irrispettivament minn liema crate tkun invokata fih.
    ///
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Gwardja għal funzjonijiet mhux siguri li qatt ma jistgħu jiġu eżegwiti jekk `T` huwa diżabitat:
    /// Dan ikun statikament jew panic, jew ma jagħmel xejn.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Gwardja għal funzjonijiet mhux siguri li qatt ma jistgħu jiġu eżegwiti jekk `T` ma jippermettix inizjalizzazzjoni żero: Dan ikun statikament jew panic, jew ma jagħmel xejn.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn assert_zero_valid<T>();

    /// Gwardja għal funzjonijiet mhux siguri li qatt ma jistgħu jiġu eżegwiti jekk `T` għandu xejriet ta 'bit invalidi: Dan ikun statikament jew panic, jew ma jagħmel xejn.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn assert_uninit_valid<T>();

    /// Tikseb referenza għal `Location` statiku li jindika fejn ġie msejjaħ.
    ///
    /// Ikkunsidra li tuża [`core::panic::Location::caller`](crate::panic::Location::caller) minflok.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Iċċaqlaq valur barra mill-ambitu mingħajr ma taħdem kolla qatra.
    ///
    /// Dan jeżisti biss għal [`mem::forget_unsized`];`forget` normali juża `ManuallyDrop` minflok.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Jinterpreta mill-ġdid il-bits ta 'valur ta' tip wieħed bħala tip ieħor.
    ///
    /// Iż-żewġ tipi għandu jkollhom l-istess daqs.
    /// La l-oriġinal, u lanqas ir-riżultat, ma jistgħu jkunu [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` huwa semantikament ekwivalenti għal mossa bitwise ta 'tip wieħed għal ieħor.Huwa jikkopja l-bits mill-valur tas-sors fil-valur tad-destinazzjoni, imbagħad jinsa l-oriġinal.
    /// Huwa ekwivalenti għal C's `memcpy` taħt il-barnuża, bħal `transmute_copy`.
    ///
    /// Minħabba li `transmute` hija operazzjoni ta 'valur sekondarju, l-allinjament tal-*valuri trasmutati nfushom* mhuwiex ta' tħassib.
    /// Bħal kull funzjoni oħra, il-kompilatur diġà jiżgura li kemm `T` kif ukoll `U` huma allinjati sewwa.
    /// Madankollu, meta ttrasmuta valuri li *jindikaw x'imkien ieħor*(bħal indikaturi, referenzi, kaxxi ...), min iċempel għandu jiżgura allinjament xieraq tal-valuri indikati.
    ///
    /// `transmute` huwa **oerhört** perikoluż.Hemm numru kbir ta 'modi biex tikkawża [undefined behavior][ub] b'din il-funzjoni.`transmute` għandu jkun l-aħħar soluzzjoni assoluta.
    ///
    /// Ix-[nomicon](../../nomicon/transmutes.html) għandu dokumentazzjoni addizzjonali.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Hemm ftit affarijiet li `transmute` huwa verament utli għalihom.
    ///
    /// It-tibdil ta 'pointer f'pointer ta' funzjoni.Dan mhuwiex * portabbli għal magni fejn pointers tal-funzjoni u indikaturi tad-dejta għandhom daqsijiet differenti.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Li testendi ħajja, jew tqassar ħajja invariant.Dan huwa Rust avvanzat, perikoluż ħafna!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Tiddisperax: ħafna użi ta `transmute` jistgħu jinkisbu permezz ta' mezzi oħra.
    /// Hawn taħt hawn applikazzjonijiet komuni ta `transmute` li jistgħu jiġu sostitwiti b'kostruzzjonijiet aktar sikuri.
    ///
    /// Iddawwar bytes(`&[u8]`) mhux ipproċessat għal `u32`, `f64`, eċċ .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // uża `u32::from_ne_bytes` minflok
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // jew uża `u32::from_le_bytes` jew `u32::from_be_bytes` biex tispeċifika l-endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Iddawwar pointer f `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Uża mitfugħa `as` minflok
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Iddawwar `*mut T` f `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Uża reborrow minflok
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Iddawwar `&mut T` f `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Issa, poġġi flimkien `as` u reborrowing, innota li l-ikkatenar ta `as` `as` mhuwiex transittiv
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Iddawwar `&str` f `&[u8]`:
    ///
    /// ```
    /// // dan mhux mod tajjeb biex tagħmel dan.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Tista 'tuża `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Jew, uża biss sekwenza ta 'byte, jekk għandek kontroll fuq is-sekwenza litterali
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Iddawwar `Vec<&T>` f `Vec<Option<&T>>`.
    ///
    /// Biex tibdel it-tip ta 'ġewwa tal-kontenut ta' kontenitur, trid tkun żgur li ma tikser l-ebda invariant tal-kontenitur.
    /// Għal `Vec`, dan ifisser li kemm id-daqs *kif ukoll l-allinjament* tat-tipi interni għandhom jaqblu.
    /// Kontenituri oħra jistgħu jiddependu fuq id-daqs tat-tip, l-allinjament, jew saħansitra x-`TypeId`, f'liema każ it-trasmutazzjoni ma tkun possibbli xejn mingħajr ma tikser l-invarianti tal-kontejners.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // ikklona ż-vector għax aħna nerġgħu nużawhom aktar tard
    /// let v_clone = v_orig.clone();
    ///
    /// // Bl-użu ta 'transmute: dan jiddependi fuq it-tqassim tad-dejta mhux speċifikat ta' `Vec`, li hija idea ħażina u tista 'tikkawża Imġieba Mhux Definita.
    /////
    /// // Madankollu, huwa bla kopja.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dan huwa l-mod issuġġerit u sikur.
    /// // Iżda tikkopja ż-vector kollu, għalkemm, f'firxa ġdida.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dan huwa l-mod xieraq bla kopja, bla periklu ta "transmuting" a `Vec`, mingħajr ma tistrieħ fuq it-tqassim tad-dejta.
    /// // Minflok ma nsejħu litteralment lil `transmute`, aħna nwettqu pointer cast, iżda f'termini ta 'konverżjoni tat-tip intern oriġinali (`&i32`) għal wieħed ġdid (`Option<&i32>`), dan għandu l-istess twissijiet.
    /////
    /// // Minbarra l-informazzjoni pprovduta hawn fuq, ikkonsulta wkoll id-dokumentazzjoni [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Aġġorna dan meta vec_into_raw_parts jiġi stabbilizzat.
    ///     // Kun żgur li ż-vector oriġinali ma jitwaqqax.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implimentazzjoni ta `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Hemm modi multipli biex tagħmel dan, u hemm problemi multipli bil-mod (transmute) li ġej.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // l-ewwel: it-trasmut mhuwiex tip sigur;kull ma jiċċekkja huwa li T u
    ///         // U huma tal-istess daqs.
    ///         // It-tieni, eżatt hawn, għandek żewġ referenzi li jistgħu jinbidlu li jindikaw l-istess memorja.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dan jeħles mill-problemi ta 'sigurtà tat-tip;`&mut *`* biss *jagħtik `&mut T` minn `&mut T` jew `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // madankollu, għad għandek żewġ referenzi li jistgħu jinbidlu li jindikaw lejn l-istess memorja.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Hekk tagħmel il-librerija standard.
    /// // Dan huwa l-aħjar metodu, jekk għandek bżonn tagħmel xi ħaġa bħal din
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dan issa għandu tliet referenzi li jistgħu jinbidlu li jippuntaw lejn l-istess memorja.`slice`, il-valur ret.0, u l-valur ret.1.
    ///         // `slice` qatt ma jintuża wara `let ptr = ...`, u allura wieħed jista 'jittrattah bħala "dead", u għalhekk, għandek biss żewġ flieli li jistgħu jinbidlu.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Filwaqt li dan jagħmel il-kost intrinsiku stabbli, għandna xi kodiċi tad-dwana fil-kost fn
    // kontrolli li jipprevjenu l-użu tiegħu fi ħdan `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Jirritorna `true` jekk it-tip attwali mogħti bħala `T` jeħtieġ kolla li tinżel;jirritorna `false` jekk it-tip attwali pprovdut għal `T` jimplimenta `Copy`.
    ///
    ///
    /// Jekk it-tip attwali la jeħtieġ kolla tal-waqgħa u lanqas jimplimenta `Copy`, allura l-valur ta 'ritorn ta' din il-funzjoni mhuwiex speċifikat.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Ikkalkula l-offset minn pointer.
    ///
    /// Dan huwa implimentat bħala intrinsiku biex tevita li tikkonverti għal u minn numru sħiħ, peress li l-konverżjoni tarmi informazzjoni dwar l-aliasing.
    ///
    /// # Safety
    ///
    /// Kemm il-pointer tal-bidu kif ukoll dak li jirriżulta għandhom ikunu jew f'limiti jew byte wieħed wara t-tmiem ta 'oġġett allokat.
    /// Jekk wieħed mill-indikaturi huwa barra mill-limiti jew isir overflow aritmetiku allura kwalunkwe użu ulterjuri tal-valur ritornat jirriżulta f'imġieba mhux definita.
    ///
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ikkalkula l-offset minn pointer, potenzjalment tgeżwir.
    ///
    /// Dan huwa implimentat bħala intrinsiku biex tevita li tikkonverti għal u minn numru sħiħ, peress li l-konverżjoni tinibixxi ċerti ottimizzazzjonijiet.
    ///
    /// # Safety
    ///
    /// B'differenza mill-intrinsiku `offset`, dan l-intrinsiku ma jirrestrinġix il-pointer li jirriżulta biex jipponta lejn jew byte wieħed wara t-tmiem ta 'oġġett allokat, u jdawwar bl-aritmetika komplementari ta' tnejn.
    /// Il-valur li jirriżulta mhux neċessarjament validu biex jintuża biex fil-fatt ikollok aċċess għall-memorja.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Ekwivalenti għall-intrinsiku `llvm.memcpy.p0i8.0i8.*` xieraq, b'daqs ta `count`*`size_of::<T>()` u allinjament ta'
    ///
    /// `min_align_of::<T>()`
    ///
    /// Il-parametru volatili huwa ssettjat għal `true`, u għalhekk mhux se jiġi ottimizzat sakemm id-daqs ma jkunx daqs żero.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekwivalenti għall-intrinsiku `llvm.memmove.p0i8.0i8.*` xieraq, b'daqs ta `count* size_of::<T>()` u allinjament ta'
    ///
    /// `min_align_of::<T>()`
    ///
    /// Il-parametru volatili huwa ssettjat għal `true`, u għalhekk mhux se jiġi ottimizzat sakemm id-daqs ma jkunx daqs żero.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Ekwivalenti għall-intrinsiku `llvm.memset.p0i8.*` xieraq, b'daqs ta `count* size_of::<T>()` u allinjament ta' `min_align_of::<T>()`.
    ///
    ///
    /// Il-parametru volatili huwa ssettjat għal `true`, u għalhekk mhux se jiġi ottimizzat sakemm id-daqs ma jkunx daqs żero.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Twettaq tagħbija volatili mill-indikatur `src`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Twettaq maħżen volatili għall-pointer `dst`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Twettaq tagħbija volatili mill-pointer `src` Il-pointer mhux meħtieġ li jkun allinjat.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Twettaq maħżen volatili għall-pointer `dst`.
    /// Il-pointer mhux meħtieġ li jkun allinjat.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Jirritorna l-għerq kwadru ta `f32`
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Jirritorna l-għerq kwadru ta `f64`
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Iqajjem `f32` għal qawwa sħiħa.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Iqajjem `f64` għal qawwa sħiħa.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Jirritorna s-sinus ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Jirritorna s-sinus ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Jirritorna l-kosinus ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Jirritorna l-kosinus ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Iqajjem `f32` għal qawwa `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Iqajjem `f64` għal qawwa `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Jirritorna l-esponenzjali ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Jirritorna l-esponenzjali ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Jirritorna 2 imtella 'għall-qawwa ta' `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Jirritorna 2 imtella 'għall-qawwa ta' `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Jirritorna l-logaritmu naturali ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Jirritorna l-logaritmu naturali ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Jirritorna l-logaritmu bażi 10 ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Jirritorna l-logaritmu bażi 10 ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Jirritorna l-logaritmu bażi 2 ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Jirritorna l-logaritmu bażi 2 ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Jirritorna `a * b + c` għal valuri `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Jirritorna `a * b + c` għall-valuri `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Jirritorna l-valur assolut ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Jirritorna l-valur assolut ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Jirritorna l-minimu ta 'żewġ valuri `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Jirritorna l-minimu ta 'żewġ valuri `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Jirritorna l-massimu ta 'żewġ valuri `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Jirritorna l-massimu ta 'żewġ valuri `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Ikkopja s-sinjal minn `y` għal `x` għal valuri `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Ikkopja s-sinjal minn `y` għal `x` għal valuri `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Jirritorna l-akbar numru sħiħ inqas minn jew ugwali għal `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Jirritorna l-akbar numru sħiħ inqas minn jew ugwali għal `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Jirritorna l-iżgħar numru sħiħ akbar minn jew ugwali għal `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Jirritorna l-iżgħar numru sħiħ akbar minn jew ugwali għal `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Jirritorna l-parti sħiħa ta `f32`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Jirritorna l-parti sħiħa ta `f64`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Jirritorna l-eqreb numru sħiħ għal `f32`.
    /// Tista 'tqajjem eċċezzjoni ta' punt varjabbli mhux eżatta jekk l-argument mhuwiex numru sħiħ.
    pub fn rintf32(x: f32) -> f32;
    /// Jirritorna l-eqreb numru sħiħ għal `f64`.
    /// Tista 'tqajjem eċċezzjoni ta' punt varjabbli mhux eżatta jekk l-argument mhuwiex numru sħiħ.
    pub fn rintf64(x: f64) -> f64;

    /// Jirritorna l-eqreb numru sħiħ għal `f32`.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Jirritorna l-eqreb numru sħiħ għal `f64`.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Jirritorna l-eqreb numru sħiħ għal `f32`.Jdur każijiet fin-nofs triq 'il bogħod minn żero.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Jirritorna l-eqreb numru sħiħ għal `f64`.Jdur każijiet fin-nofs triq 'il bogħod minn żero.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Żieda float li tippermetti ottimizzazzjonijiet ibbażati fuq regoli alġebrin.
    /// Jista 'jassumi li l-inputs huma finiti.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Tnaqqis f'wiċċ l-ilma li jippermetti ottimizzazzjonijiet ibbażati fuq regoli alġebrin.
    /// Jista 'jassumi li l-inputs huma finiti.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Multiplikazzjoni float li tippermetti ottimizzazzjonijiet ibbażati fuq regoli alġebrin.
    /// Jista 'jassumi li l-inputs huma finiti.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Diviżjoni float li tippermetti ottimizzazzjonijiet ibbażati fuq regoli alġebrin.
    /// Jista 'jassumi li l-inputs huma finiti.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float bqija li jippermetti ottimizzazzjonijiet ibbażati fuq regoli alġebrin.
    /// Jista 'jassumi li l-inputs huma finiti.
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Ikkonverti ma fptoui/fptosi ta' LLVM, li jista 'jirritorna undef għal valuri barra mill-firxa
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabbilizzat bħala [`f32::to_int_unchecked`] u [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Irritorna n-numru ta 'bits issettjat f'tip sħiħ `T`
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `count_ones`.
    /// Pereżempju,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Irritorna n-numru ta 'bits mhux issettjati ewlenin (zeroes) f'tip sħiħ `T`.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `leading_zeros`.
    /// Pereżempju,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` b'valur `0` jirritorna l-wisa 'tal-bit ta' `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Bħal `ctlz`, iżda extra-perikoluż għax jirritorna `undef` meta jingħata `x` b'valur `0`.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Jirritorna n-numru ta 'bits mhux issettjati ta' wara (zeroes) f'tip sħiħ `T`.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `trailing_zeros`.
    /// Pereżempju,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` b'valur `0` jirritorna l-wisa 'tal-bit ta' `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Bħal `cttz`, iżda extra-perikoluż għax jirritorna `undef` meta jingħata `x` b'valur `0`.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Jaqleb il-bytes fi numru sħiħ `T`.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `swap_bytes`.
    /// Pereżempju,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Jaqleb il-bits fi tip sħiħ `T`.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `reverse_bits`.
    /// Pereżempju,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Twettaq żieda ta 'numru sħiħ iċċekkjat.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `overflowing_add`.
    /// Pereżempju,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Twettaq tnaqqis ta 'numru sħiħ ikkontrollat
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `overflowing_sub`.
    /// Pereżempju,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Twettaq multiplikazzjoni ta 'numru sħiħ verifikat
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `overflowing_mul`.
    /// Pereżempju,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Twettaq diviżjoni eżatta, li tirriżulta f'imġieba mhux definita fejn `x % y != 0` jew `y == 0` jew `x == T::MIN && y == -1`
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Twettaq diviżjoni mhux ivverifikata, li tirriżulta f'imġieba mhux definita fejn `y == 0` jew `x == T::MIN && y == -1`
    ///
    ///
    /// Tgeżwir bla periklu għal dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `checked_div`.
    /// Pereżempju,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Jirritorna l-bqija ta 'diviżjoni mhux kontrollata, li tirriżulta f'imġieba mhux definita meta `y == 0` jew `x == T::MIN && y == -1`
    ///
    ///
    /// Tgeżwir bla periklu għal dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `checked_rem`.
    /// Pereżempju,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Twettaq ċaqliq tax-xellug mhux ikkontrollat, li jirriżulta f'imġieba mhux definita meta `y < 0` jew `y >= N`, fejn N hija l-wisa 'ta' T f'bits.
    ///
    ///
    /// Tgeżwir bla periklu għal dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `checked_shl`.
    /// Pereżempju,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Twettaq bidla tal-lemin mhux ivverifikata, li tirriżulta f'imġieba mhux definita meta `y < 0` jew `y >= N`, fejn N hija l-wisa 'ta' T f'bits.
    ///
    ///
    /// Tgeżwir bla periklu għal dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `checked_shr`.
    /// Pereżempju,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Jirritorna r-riżultat ta 'żieda mhux ivverifikata, li tirriżulta f'imġieba mhux definita meta `x + y > T::MAX` jew `x + y < T::MIN`.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Jirritorna r-riżultat ta 'tnaqqis mhux ivverifikat, li jirriżulta f'imġieba mhux definita meta `x - y > T::MAX` jew `x - y < T::MIN`.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Jirritorna r-riżultat ta 'multiplikazzjoni mhux ivverifikata, li tirriżulta f'imġieba mhux definita meta `x *y > T::MAX` jew `x* y < T::MIN`.
    ///
    ///
    /// Dan l-intrinsiku m'għandux kontroparti stabbli.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Twettaq iddawwar lejn ix-xellug.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `rotate_left`.
    /// Pereżempju,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Twettaq iddawwar lejn il-lemin.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `rotate_right`.
    /// Pereżempju,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Jirritorna (a + b) mod 2 <sup>N</sup>, fejn N hija l-wisa 'ta' T f'bits.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `wrapping_add`.
    /// Pereżempju,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Jirritorna (a, b) mod 2 <sup>N</sup>, fejn N hija l-wisa 'ta' T f'bits.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `wrapping_sub`.
    /// Pereżempju,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Jirritorna (a * b) mod 2 <sup>N</sup>, fejn N hija l-wisa 'ta' T f'bits.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `wrapping_mul`.
    /// Pereżempju,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Ikkalkula `a + b`, saturat f'limiti numeriċi.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `saturating_add`.
    /// Pereżempju,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Ikkalkula `a - b`, saturat f'limiti numeriċi.
    ///
    /// Il-verżjonijiet stabbilizzati ta 'dan l-intrinsiku huma disponibbli fuq il-primittivi integer permezz tal-metodu `saturating_sub`.
    /// Pereżempju,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Jirritorna l-valur tad-diskriminanti għall-varjant f 'v';
    /// jekk `T` m'għandux diskriminazzjoni, jirritorna `0`.
    ///
    /// Il-verżjoni stabbilizzata ta 'dan l-intrinsiku hija [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Jirritorna n-numru ta 'varjanti tat-tip `T` mitfugħ għal `usize`;
    /// jekk `T` m'għandux varjanti, jirritorna `0`.Varjanti diżabitati se jingħaddu.
    ///
    /// Il-verżjoni li trid tiġi stabbilizzata ta 'dan l-intrinsiku hija [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Il-kostruzzjoni "try catch" ta 'Rust li tinvoka l-funzjoni pointer `try_fn` bil-pointer tad-data `data`.
    ///
    /// It-tielet argument huwa funzjoni msejħa jekk iseħħ panic.
    /// Din il-funzjoni tieħu l-indikatur tad-dejta u indikatur għall-oġġett ta 'eċċezzjoni speċifiku għall-mira li nqabad.
    ///
    /// Għal aktar informazzjoni ara s-sors tal-kompilatur kif ukoll l-implimentazzjoni tal-qabda ta 'std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Tarmi maħżen `!nontemporal` skont LLVM (ara d-dokumenti tagħhom).
    /// Probabbilment qatt ma jsir stabbli.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Ara d-dokumentazzjoni ta `<*const T>::offset_from` għad-dettalji.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Ara d-dokumentazzjoni ta `<*const T>::guaranteed_eq` għad-dettalji.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Ara d-dokumentazzjoni ta `<*const T>::guaranteed_ne` għad-dettalji.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Alloka fil-ħin tal-kumpilazzjoni.M'għandux jissejjaħ fil-ħin tal-eżekuzzjoni.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Xi funzjonijiet huma definiti hawn għax aċċidentalment saru disponibbli f'dan il-modulu fuq stabbli.
// Ara <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` jaqa 'wkoll f'din il-kategorija, iżda ma jistax jiġi mgeżwer minħabba l-verifika li `T` u `U` għandhom l-istess daqs.)
//

/// Jiċċekkja jekk `ptr` huwiex allinjat sewwa fir-rigward ta `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Ikkopja bytes `count *size_of::<T>()` minn `src` sa `dst`.Is-sors u d-destinazzjoni m'għandhomx* jikkoinċidu.
///
/// Għal reġjuni tal-memorja li jistgħu jikkoinċidu, uża [`copy`] minflok.
///
/// `copy_nonoverlapping` huwa semantikament ekwivalenti għal C's [`memcpy`], iżda bl-ordni tal-argument mibdula.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `src` għandu jkun [valid] għal qari ta 'bytes `count * size_of::<T>()`.
///
/// * `dst` għandu jkun [valid] għal kitbiet ta 'bytes `count * size_of::<T>()`.
///
/// * Kemm `src` kif ukoll `dst` għandhom ikunu allinjati sewwa.
///
/// * Ir-reġjun tal-memorja li jibda minn `src` b'daqs ta 'ʻgħadd *
///   daqs_ta ': :<T>() `bytes m'għandhomx *jikkoinċidu* mar-reġjun tal-memorja li jibda f `dst` bl-istess daqs.
///
/// Bħal [`read`], `copy_nonoverlapping` joħloq kopja bitwise ta `T`, irrispettivament minn jekk `T` huwiex [`Copy`].
/// Jekk `T` mhuwiex [`Copy`], bl-użu ta '*kemm* il-valuri fir-reġjun li jibdew f `*src` u r-reġjun li jibda f `* dst` jistgħu [violate memory safety][read-ownership].
///
///
/// Innota li anke jekk id-daqs ikkupjat b'mod effettiv (`count * size_of: :<T>()`) huwa `0`, l-indikaturi għandhom ikunu mhux NULL u allinjati sewwa.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Implimenta manwalment [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Iċċaqlaq l-elementi kollha ta `src` f `dst`, u jħalli `src` vojt.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Kun żgur li `dst` għandu biżżejjed kapaċità biex iżomm `src` kollu.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Is-sejħa għall-offset hija dejjem sigura għax `Vec` qatt ma jalloka aktar minn bytes `isize::MAX`.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Ittaqt `src` mingħajr ma twaqqa 'l-kontenut tiegħu.
///         // Dan nagħmlu l-ewwel, biex nevitaw il-problemi f'każ li xi ħaġa aktar 'l isfel minn panics.
///         src.set_len(0);
///
///         // Iż-żewġ reġjuni ma jistgħux jikkoinċidu għax ir-referenzi li jistgħu jinbidlu ma jaħdmux, u żewġ vectors differenti ma jistgħux ikollhom l-istess memorja.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Innotifika lil `dst` li issa għandu l-kontenut ta `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Wettaq dawn il-kontrolli biss waqt il-ħin ta 'tħaddim
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Mhux paniku biex iżomm l-impatt tal-codegen iżgħar.
        abort();
    }*/

    // SIGURTÀ: il-kuntratt ta 'sigurtà għal `copy_nonoverlapping` għandu jkun
    // milqugħ minn min iċempel.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Ikkopja bytes `count * size_of::<T>()` minn `src` sa `dst`.Is-sors u d-destinazzjoni jistgħu jikkoinċidu.
///
/// Jekk is-sors u d-destinazzjoni *qatt* ma jikkoinċidux, [`copy_nonoverlapping`] jista 'jintuża minflok.
///
/// `copy` huwa semantikament ekwivalenti għal C's [`memmove`], iżda bl-ordni tal-argument mibdula.
/// L-ikkupjar iseħħ bħallikieku l-bytes ġew ikkupjati minn `src` għal array temporanja u mbagħad ikkupjati mill-array għal `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `src` għandu jkun [valid] għal qari ta 'bytes `count * size_of::<T>()`.
///
/// * `dst` għandu jkun [valid] għal kitbiet ta 'bytes `count * size_of::<T>()`.
///
/// * Kemm `src` kif ukoll `dst` għandhom ikunu allinjati sewwa.
///
/// Bħal [`read`], `copy` joħloq kopja bitwise ta `T`, irrispettivament minn jekk `T` huwiex [`Copy`].
/// Jekk `T` mhuwiex [`Copy`], l-użu kemm tal-valuri fir-reġjun li jibda f `*src` kif ukoll ir-reġjun li jibda f `* dst` jista [violate memory safety][read-ownership].
///
///
/// Innota li anke jekk id-daqs ikkupjat b'mod effettiv (`count * size_of: :<T>()`) huwa `0`, l-indikaturi għandhom ikunu mhux NULL u allinjati sewwa.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Oħloq b'mod effiċjenti Rust vector minn buffer mhux sikur:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` għandu jkun allinjat b'mod korrett għat-tip tiegħu u mhux żero.
/// /// * `ptr` għandu jkun validu għal qari ta 'elementi kontigwi `elts` tat-tip `T`.
/// /// * Dawk l-elementi m'għandhomx jintużaw wara li ssejjaħ din il-funzjoni sakemm `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SIGURTÀ: Il-prekundizzjoni tagħna tiżgura li s-sors huwa allinjat u validu,
///     // u `Vec::with_capacity` jiżgura li għandna spazju użabbli biex niktbuhom.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SIGURTÀ: Ħloqna b'din il-kapaċità ħafna qabel,
///     // u x-`copy` preċedenti inizjalizza dawn l-elementi.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Wettaq dawn il-kontrolli biss waqt il-ħin ta 'tħaddim
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Mhux paniku biex iżomm l-impatt tal-codegen iżgħar.
        abort();
    }*/

    // SIGURTÀ: il-kuntratt ta 'sigurtà għal `copy` għandu jintlaqa' minn min iċempel.
    unsafe { copy(src, dst, count) }
}

/// Issettja bytes tal-memorja `count * size_of::<T>()` li jibdew minn `dst` sa `val`.
///
/// `write_bytes` huwa simili għal C's [`memset`], iżda jistabbilixxi `count * size_of::<T>()` bytes għal `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `dst` għandu jkun [valid] għal kitbiet ta 'bytes `count * size_of::<T>()`.
///
/// * `dst` għandhom ikunu allinjati sewwa.
///
/// Barra minn hekk, min iċempel għandu jiżgura li l-kitba ta 'bytes `count * size_of::<T>()` għar-reġjun mogħti tal-memorja tirriżulta f'valur validu ta' `T`.
/// L-użu ta 'reġjun ta' memorja ttajpjat bħala `T` li fih valur invalidu ta `T` huwa mġieba mhux definita.
///
/// Innota li anke jekk id-daqs ikkupjat b'mod effettiv (`count * size_of: :<T>()`) huwa `0`, il-pointer m'għandux ikun NULL u allinjat sewwa.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ħolqien ta 'valur invalidu:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Iħalli l-valur miżmum qabel billi tissottoskrivi x-`Box<T>` b'pointer null.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // F'dan il-punt, l-użu jew it-twaqqigħ ta `v` jirriżulta f'imġieba mhux definita.
/// // drop(v); // ERROR
///
/// // Anke jxerred `v` "uses", u għalhekk huwa mġieba mhux definita.
/// // mem::forget(v); // ERROR
///
/// // Fil-fatt, `v` huwa invalidu skont invariants tat-tqassim tat-tip bażiku, allura * kull operazzjoni li tmissha hija mġieba mhux definita.
/////
/// // ħalli v2 =v;//ŻBALL
///
/// unsafe {
///     // Ejjew minflok inpoġġu valur validu
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Issa l-kaxxa hija tajba
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SIGURTÀ: il-kuntratt ta 'sigurtà għal `write_bytes` għandu jintlaqa' minn min iċempel.
    unsafe { write_bytes(dst, val, count) }
}