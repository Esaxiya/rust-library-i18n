#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Utilitajiet relatati ma 'rbit ta' interface (FFI) ta 'funzjoni barranija.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Ekwivalenti għat-tip `void` ta 'C meta jintuża bħala [pointer].
///
/// Essenzjalment, `*const c_void` huwa ekwivalenti għal C's `const void*` u `*mut c_void` huwa ekwivalenti għal C's `void*`.
/// Cela dit, dan mhux * l-istess bħat-tip ta 'ritorn ta' C's `void`, li huwa t-tip `()` ta 'Rust.
///
/// Biex timmudella indikaturi għal tipi opaki f'FFI, sakemm `extern type` jiġi stabbilizzat, huwa rrakkomandat li tuża tgeżwir newtype madwar firxa ta 'bytes vojta.
///
/// Ara x-[Nomicon] għad-dettalji.
///
/// Wieħed jista 'juża `std::os::raw::c_void` jekk iridu jappoġġjaw il-kompilatur antik ta' Rust sa 1.1.0.
/// Wara Rust 1.30.0, ġie esportat mill-ġdid b'din id-definizzjoni.
/// Għal aktar informazzjoni, jekk jogħġbok aqra [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, biex LLVM tirrikonoxxi t-tip ta 'pointer vojt u b'funzjonijiet ta' estensjoni bħal malloc(), jeħtieġ li jkollna rrappreżentata bħala i8 * fil-bitcode LLVM.
// L-enum użat hawnhekk jiżgura dan u jipprevjeni l-użu ħażin tat-tip "raw" billi jkollu biss varjanti privati.
// Għandna bżonn żewġ varjanti, minħabba li l-kompilatur jilmenta dwar l-attribut repr mod ieħor u għandna bżonn mill-inqas varjant wieħed għax inkella l-enum ikun diżabitat u għall-inqas id-dereferenzjar ta 'tali indikaturi jkun UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Implimentazzjoni bażika ta `va_list`.
// L-isem huwa WIP, billi tuża `VaListImpl` għalissa.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant fuq `'f`, allura kull oġġett `VaListImpl<'f>` huwa marbut mar-reġjun tal-funzjoni li huwa definit fih
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Implimentazzjoni ABI ta `va_list`.
/// Ara x-[AArch64 Procedure Call Standard] għal aktar dettalji.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Implimentazzjoni ABI ta `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Implimentazzjoni ABI ta `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Tgeżwir għal `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Ikkonverti `VaListImpl` f `VaList` li huwa kompatibbli binarjament ma 'C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Ikkonverti `VaListImpl` f `VaList` li huwa kompatibbli binarjament ma 'C's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// Il-VaArgSafe trait jeħtieġ li jintuża f'interfaces pubbliċi, madankollu, iż-trait innifsu m'għandux jitħalla jintuża barra dan il-modulu.
// Li tippermetti lill-utenti jimplimentaw iż-trait għal tip ġdid (u b'hekk jippermettu li l-va_arg intrinsiku jintuża fuq tip ġdid) x'aktarx jikkawża imġieba mhux definita.
//
// FIXME(dlrobertson): Sabiex tuża l-VaArgSafe trait f'interface pubblika imma tiżgura wkoll li ma tistax tintuża x'imkien ieħor, iż-trait jeħtieġ li jkun pubbliku fi ħdan modulu privat.
// Ladarba l-RFC 2145 tkun ġiet implimentata ħares lejn it-titjib ta 'dan.
//
//
//
//
mod sealed_trait {
    /// Trait li jippermetti li t-tipi permessi jintużaw ma [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Avvanza għall-arg li jmiss.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Ikkopja x-`va_list` fil-post attwali.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // SIGURTÀ: niktbu fuq ix-`MaybeUninit`, u għalhekk huwa inizjalizzat u `assume_init` huwa legali
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: dan għandu jsejjaħ `va_end`, imma m'hemm l-ebda mod nadif kif
        // tiggarantixxi li `drop` dejjem jiddaħħal fil-linja tas-sejjieħ tiegħu, allura `va_end` jissejjaħ direttament mill-istess funzjoni bħax-`va_copy` korrispondenti.
        // `man va_end` jiddikjara li C jirrikjedi dan, u LLVM bażikament issegwi s-semantika C, allura rridu niżguraw li `va_end` huwa dejjem imsejjaħ mill-istess funzjoni bħal `va_copy`.
        //
        // Għal aktar dettalji, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Dan jaħdem għalissa, billi `va_end` huwa no-op fuq il-miri kurrenti kollha tal-LLVM.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Eqred l-arglist `ap` wara l-inizjalizzazzjoni b `va_start` jew `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Ikkopja l-post attwali tal-arglist `src` għall-arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Tgħabba argument tat-tip `T` mill-`va_list` `ap` u żid l-argument li `ap` jindika.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}