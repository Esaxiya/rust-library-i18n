//! Panic appoġġ għal libcore
//!
//! Il-librerija ewlenija ma tistax tiddefinixxi paniku, iżda *tiddikjara* paniku.
//! Dan ifisser li l-funzjonijiet ġewwa libcore huma permessi għal panic, imma biex tkun utli crate upstream għandu jiddefinixxi paniku biex libcore jintuża.
//! L-interface attwali għall-paniku huwa:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Din id-definizzjoni tippermetti paniku ma 'kwalunkwe messaġġ ġenerali, iżda ma tippermettix li tfalli b'valur `Box<Any>`.
//! (`PanicInfo` fih biss `&(dyn Any + Send)`, li għalih nimlew valur finta f'`PanicInfo: : internal_constructor`.) Ir-raġuni għal dan hija li libcore mhuwiex permess li jalloka.
//!
//!
//! Dan il-modulu fih ftit funzjonijiet oħra ta 'paniku, iżda dawn huma biss l-oġġetti meħtieġa għall-kompilatur.Iż-panics kollha huma mħaddma permezz ta 'din il-funzjoni waħda.
//! Is-simbolu attwali huwa ddikjarat permezz tal-attribut `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// L-implimentazzjoni sottostanti tal-makro `panic!` ta 'libcore meta ma jintuża l-ebda ifformattjar.
#[cold]
// qatt inline sakemm panic_immediate_abort tevita kemm jista 'jkun il-kodiċi nefħa fis-siti tas-sejħa
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // meħtieġa mill-codegen għal panic fuq overflow u terminaturi `Assert` MIR oħra
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Uża Arguments::new_v1 minflok format_args! ("{}", Expr) biex potenzjalment tnaqqas id-daqs overhead.
    // Il-format_args!il-makro tuża l-Display trait ta 'str biex tikteb expr, li jsejjaħ Formatter::pad, li għandu jakkomoda t-truncation u l-ikkuttunar tas-sekwenza (anke jekk hawn ma tintuża l-ebda waħda).
    //
    // L-użu ta Arguments::new_v1 jista' jippermetti lill-kompilatur iħalli barra Formatter::pad mill-binarju tal-ħruġ, u jiffranka sa ftit kilobytes.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // meħtieġa għal panics evalwati mill-kost
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // meħtieġa mill-codegen għal panic fuq aċċess OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// L-implimentazzjoni sottostanti tal-makro `panic!` ta 'libcore meta jintuża l-ifformattjar.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // NOTA Din il-funzjoni qatt ma taqsam il-konfini tal-FFI;hija sejħa Rust-to-Rust li tissolva għall-funzjoni `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SIGURTÀ: `panic_impl` huwa definit f'kodiċi Rust sikur u għalhekk huwa sikur li ċċempel.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Funzjoni interna għal macros `assert_eq!` u `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}