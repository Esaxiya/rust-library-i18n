//! Il-libcore prelude
//!
//! Dan il-modulu huwa maħsub għal utenti ta 'libcore li ma jorbtux ukoll ma' libstd.
//! Dan il-modulu huwa importat awtomatikament meta `#![no_std]` jintuża bl-istess mod bħaż-prelude tal-librerija standard.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Il-verżjoni 2015 tal-qalba prelude.
///
/// Ara x-[module-level documentation](self) għal aktar.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Il-verżjoni 2018 tal-qalba prelude.
///
/// Ara x-[module-level documentation](self) għal aktar.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Il-verżjoni 2021 tal-qalba prelude.
///
/// Ara x-[module-level documentation](self) għal aktar.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Żid aktar affarijiet.
}