//! Tipi atomiċi
//!
//! Tipi atomiċi jipprovdu komunikazzjoni primittiva ta 'memorja maqsuma bejn il-ħjut, u huma l-blokki tal-bini ta' tipi konkorrenti oħra.
//!
//! Dan il-modulu jiddefinixxi verżjonijiet atomiċi ta 'numru magħżul ta' tipi primittivi, inklużi [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`], eċċ.
//! Tipi atomiċi jippreżentaw operazzjonijiet li, meta jintużaw b'mod korrett, jissinkronizzaw aġġornamenti bejn ħjut.
//!
//! Kull metodu jieħu [`Ordering`] li jirrappreżenta l-qawwa tal-barriera tal-memorja għal dik l-operazzjoni.Dawn l-ordnijiet huma l-istess bħal [C++20 atomic orderings][1].Għal aktar informazzjoni ara x-[nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Varjabbli atomiċi huma sikuri biex jaqsmu bejn ħjut (jimplimentaw [`Sync`]) iżda huma stess ma jipprovdux il-mekkaniżmu għall-qsim u jsegwu l-[threading model](../../../std/thread/index.html#the-threading-model) ta 'Rust.
//!
//! L-iktar mod komuni biex taqsam varjabbli atomika huwa li tpoġġiha f [`Arc`][arc] (indikatur kondiviż magħdud b'referenza atomika).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Tipi atomiċi jistgħu jinħażnu f'varjabbli statiċi, inizjalizzati bl-użu ta 'inizjalizzaturi kostanti bħal [`AtomicBool::new`].L-istatiċi atomiċi spiss jintużaw għall-inizjalizzazzjoni globali għażżiena.
//!
//! # Portability
//!
//! It-tipi atomiċi kollha f'dan il-modulu huma garantiti li jkunu [lock-free] jekk ikunu disponibbli.Dan ifisser li ma jakkwistawx internament mutex globali.Tipi u operazzjonijiet atomiċi mhumiex garantiti li ma jistennewx.
//! Dan ifisser li operazzjonijiet bħal `fetch_or` jistgħu jiġu implimentati b'ċirku ta 'tqabbil u swap.
//!
//! Operazzjonijiet atomiċi jistgħu jiġu implimentati fis-saff ta 'struzzjoni b'atomiċi ta' daqs ikbar.Pereżempju xi pjattaformi jużaw struzzjonijiet atomiċi ta '4 bytes biex jimplimentaw `AtomicI8`.
//! Innota li din l-emulazzjoni m'għandux ikollha impatt fuq il-korrettezza tal-kodiċi, hija biss xi ħaġa li għandek tkun taf biha.
//!
//! It-tipi atomiċi f'dan il-modulu jistgħu ma jkunux disponibbli fuq il-pjattaformi kollha.It-tipi atomiċi hawnhekk huma kollha disponibbli b'mod wiesa ', madankollu, u ġeneralment jistgħu jiġu invokati eżistenti.Xi eċċezzjonijiet notevoli huma:
//!
//! * PowerPC u pjattaformi MIPS b'indikaturi ta '32-bit m'għandhomx tipi `AtomicU64` jew `AtomicI64`.
//! * ARM pjattaformi bħal `armv5te` li mhumiex għal Linux jipprovdu biss operazzjonijiet `load` u `store`, u ma jappoġġjawx operazzjonijiet Qabbel u Swap (CAS), bħal `swap`, `fetch_add`, eċċ.
//! Barra minn hekk fuq Linux, dawn l-operazzjonijiet CAS huma implimentati permezz ta [operating system support], li jista' jiġi b'piena ta 'prestazzjoni.
//! * ARM miri b `thumbv6m` jipprovdu biss operazzjonijiet `load` u `store`, u ma jappoġġjawx operazzjonijiet Qabbel u Ibdlu (CAS), bħal `swap`, `fetch_add`, eċċ.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Innota li jistgħu jiżdiedu pjattaformi future li wkoll m'għandhomx appoġġ għal xi operazzjonijiet atomiċi.Kodiċi li jista 'jinġarr massimu jrid ikun attent dwar liema tipi atomiċi jintużaw.
//! `AtomicUsize` u `AtomicIsize` huma ġeneralment l-aktar portabbli, iżda anke allura mhumiex disponibbli kullimkien.
//! Bħala referenza, il-librerija `std` teħtieġ atomika daqs pointer, għalkemm `core` ma teħtieġx.
//!
//! Bħalissa ser ikollok bżonn tuża `#[cfg(target_arch)]` primarjament biex tikkompila kondizzjonalment f'kodiċi ma 'atomiċi.Hemm `#[cfg(target_has_atomic)]` instabbli wkoll li jista 'jkun stabbilizzat fiż-future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! Spinlock sempliċi:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Stenna li l-ħajta l-oħra tirrilaxxa s-serratura
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Żomm għadd globali ta 'ħjut ħajjin:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// Tip boolean li jista 'jinqasam b'mod sigur bejn il-ħjut.
///
/// Dan it-tip għandu l-istess rappreżentazzjoni fil-memorja bħal [`bool`].
///
/// **Nota**: Dan it-tip huwa disponibbli biss fuq pjattaformi li jappoġġjaw tagħbijiet atomiċi u mħażen ta `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Joħloq `AtomicBool` inizjalizzat għal `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send huwa impliċitament implimentat għal AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// Tip ta 'pointer mhux maħdum li jista' jinqasam b'mod sigur bejn il-ħjut.
///
/// Dan it-tip għandu l-istess rappreżentazzjoni fil-memorja bħal `*mut T`.
///
/// **Nota**: Dan it-tip huwa disponibbli biss fuq pjattaformi li jappoġġjaw tagħbijiet atomiċi u ħażniet ta 'indikaturi.
/// Id-daqs tiegħu jiddependi fuq id-daqs tal-pointer fil-mira.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Toħloq `AtomicPtr<T>` null.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Ordnijiet tal-memorja atomika
///
/// Ordnijiet tal-memorja jispeċifikaw il-mod kif l-operazzjonijiet atomiċi jissinkronizzaw il-memorja.
/// Fl-iktar [`Ordering::Relaxed`] dgħajjef tagħha, il-memorja biss li tmiss direttament mill-operazzjoni hija sinkronizzata.
/// Min-naħa l-oħra, par maħżen-load ta 'operazzjonijiet [`Ordering::SeqCst`] jissinkronizzaw memorja oħra filwaqt li wkoll jippreservaw ordni totali ta' operazzjonijiet bħal dawn fil-ħjut kollha.
///
///
/// L-ordnijiet tal-memorja ta 'Rust huma [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// Għal aktar informazzjoni ara [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// L-ebda restrizzjoni ta 'ordni, biss operazzjonijiet atomiċi.
    ///
    /// Jikkorrispondi għal [`memory_order_relaxed`] f'C ++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Meta mqabbda ma 'maħżen, l-operazzjonijiet kollha ta' qabel isiru ordnati qabel kull tagħbija ta 'dan il-valur b'ordni [`Acquire`] (jew aktar b'saħħitha).
    ///
    /// B`mod partikolari, il-kitbiet kollha ta`qabel isiru viżibbli għall-ħjut kollha li jwettqu tagħbija [`Acquire`] (jew aktar qawwija) ta` dan il-valur.
    ///
    /// Innota li l-użu ta 'din l-ordni għal operazzjoni li tgħaqqad tagħbijiet u ħażniet twassal għal operazzjoni ta' tagħbija [`Relaxed`]!
    ///
    /// Dan l-ordni huwa applikabbli biss għal operazzjonijiet li jistgħu jwettqu maħżen.
    ///
    /// Jikkorrispondi għal [`memory_order_release`] f'C ++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Meta kkombinat ma 'tagħbija, jekk il-valur mgħobbi kien miktub minn operazzjoni ta' maħżen b'ordni [`Release`] (jew aktar b'saħħitha), allura l-operazzjonijiet sussegwenti kollha jiġu ordnati wara dak il-maħżen.
    /// B`mod partikolari, it-tagħbijiet sussegwenti kollha jaraw data miktuba qabel il-maħżen.
    ///
    /// Innota li l-użu ta 'dan l-ordni għal operazzjoni li tgħaqqad tagħbijiet u ħażniet iwassal għal operazzjoni ta' maħżen [`Relaxed`]!
    ///
    /// Din l-ordni hija applikabbli biss għal operazzjonijiet li jistgħu jwettqu tagħbija.
    ///
    /// Jikkorrispondi għal [`memory_order_acquire`] f'C ++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Għandu l-effetti ta [`Acquire`] u [`Release`] flimkien:
    /// Għal tagħbijiet juża l-ordni [`Acquire`].Għall-ħwienet juża l-ordni [`Release`].
    ///
    /// Innota li fil-każ ta `compare_and_swap`, huwa possibbli li l-operazzjoni tispiċċa biex ma twettaq l-ebda maħżen u għalhekk hija biss tordna [`Acquire`].
    ///
    /// Madankollu, `AcqRel` qatt ma jwettaq aċċessjonijiet [`Relaxed`].
    ///
    /// Din l-ordni hija applikabbli biss għal operazzjonijiet li jikkombinaw kemm tagħbijiet kif ukoll ħwienet.
    ///
    /// Jikkorrispondi għal [`memory_order_acq_rel`] f'C ++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Bħal ["Akkwista"]/["Rilaxx"]/[`AcqRel '](għal operazzjonijiet ta' tagħbija, maħżen, u tagħbija bil-maħżen, rispettivament) bil-garanzija addizzjonali li l-ħjut kollha jaraw l-operazzjonijiet konsistenti sekwenzjalment kollha fl-istess ordni .
    ///
    ///
    /// Jikkorrispondi għal [`memory_order_seq_cst`] f'C ++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// [`AtomicBool`] inizjalizzat għal `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Toħloq `AtomicBool` ġdid.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Jirritorna referenza li tista 'tinbidel għax-[`bool`] sottostanti.
    ///
    /// Dan huwa sigur għax ir-referenza li tista 'tinbidel tiggarantixxi li l-ebda ħjut oħra ma jkunu qed jaċċessaw id-dejta atomika fl-istess ħin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SIGURTÀ: ir-referenza li tista 'tinbidel tiggarantixxi sjieda unika.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Ikseb aċċess atomiku għal `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SIGURTÀ: ir-referenza li tista 'tinbidel tiggarantixxi sjieda unika, u
        // allinjament kemm ta `bool` kif ukoll ta' `Self` huwa 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Jikkonsma l-atomiku u jirritorna l-valur miżmum.
    ///
    /// Dan huwa sigur minħabba li tgħaddi `self` bil-valur jiggarantixxi li l-ebda ħjut oħra ma jkunu qed jaċċessaw id-dejta atomika fl-istess ħin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Tagħbija valur miż-bool.
    ///
    /// `load` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// Valuri possibbli huma [`SeqCst`], [`Acquire`] u [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jekk `order` huwa [`Release`] jew [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SIGURTÀ: kwalunkwe ġirja tad-dejta hija evitata minn intrinsiċi atomiċi u l-materja prima
        // pointer mgħoddi huwa validu għax irċevejna minn referenza.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Taħżen valur fiż-bool.
    ///
    /// `store` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// Valuri possibbli huma [`SeqCst`], [`Release`] u [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jekk `order` huwa [`Acquire`] jew [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SIGURTÀ: kwalunkwe ġirja tad-dejta hija evitata minn intrinsiċi atomiċi u l-materja prima
        // pointer mgħoddi huwa validu għax irċevejna minn referenza.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Taħżen valur fiż-bool, u tirritorna l-valur preċedenti.
    ///
    /// `swap` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
    /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Taħżen valur fix-[`bool`] jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
    ///
    /// Il-valur tar-ritorn huwa dejjem il-valur preċedenti.Jekk huwa ugwali għal `current`, allura l-valur ġie aġġornat.
    ///
    /// `compare_and_swap` jieħu wkoll argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// Innota li anke meta tuża [`AcqRel`], l-operazzjoni tista 'tfalli u għalhekk twettaq biss tagħbija `Acquire`, imma m'għandhiex semantika `Release`.
    /// L-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`] jekk jiġri, u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Migrazzjoni għal `compare_exchange` u `compare_exchange_weak`
    ///
    /// `compare_and_swap` hija ekwivalenti għal `compare_exchange` bil-mapping li ġej għall-ordnijiet tal-memorja:
    ///
    /// Oriġinali |Suċċess |Nuqqas
    /// -------- | ------- | -------
    /// Irrilassat |Irrilassat |Irrilassat Akkwista |Akkwista |Akkwista Rilaxx |Rilaxx |AcqRel rilassat |AcqRel |Akkwista SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` jitħalla jonqos spuriously anke meta l-paragun jirnexxi, li jippermetti lill-kompilatur jiġġenera kodiċi ta 'assemblaġġ aħjar meta l-paragun u t-tpartit jintużaw f'ċirku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Taħżen valur fix-[`bool`] jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
    ///
    /// Il-valur ta 'ritorn huwa riżultat li jindika jekk il-valur il-ġdid kienx miktub u fih il-valur ta' qabel.
    /// Mas-suċċess dan il-valur huwa garantit li jkun ugwali għal `current`.
    ///
    /// `compare_exchange` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// `success` jiddeskrivi l-ordni meħtieġ għall-operazzjoni ta 'qari-modifika-kitba li sseħħ jekk il-paragun ma' `current` jirnexxi.
    /// `failure` jiddeskrivi l-ordni meħtieġ għall-operazzjoni tat-tagħbija li sseħħ meta l-paragun ifalli.
    /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija b'suċċess [`Relaxed`].
    ///
    /// L-ordni ta 'falliment tista' tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta 'suċċess.
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Taħżen valur fix-[`bool`] jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
    ///
    /// B'differenza minn [`AtomicBool::compare_exchange`], din il-funzjoni titħalla tfalli b'mod spuriż anke meta l-paragun jirnexxi, li jista 'jirriżulta f'kodiċi aktar effiċjenti fuq xi pjattaformi.
    ///
    /// Il-valur ta 'ritorn huwa riżultat li jindika jekk il-valur il-ġdid kienx miktub u fih il-valur ta' qabel.
    ///
    /// `compare_exchange_weak` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// `success` jiddeskrivi l-ordni meħtieġ għall-operazzjoni ta 'qari-modifika-kitba li sseħħ jekk il-paragun ma' `current` jirnexxi.
    /// `failure` jiddeskrivi l-ordni meħtieġ għall-operazzjoni tat-tagħbija li sseħħ meta l-paragun ifalli.
    /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija b'suċċess [`Relaxed`].
    /// L-ordni ta 'falliment tista' tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta 'suċċess.
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// "and" Loġiku b'valur boolean.
    ///
    /// Twettaq operazzjoni loġika "and" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
    ///
    /// Jirritorna l-valur preċedenti.
    ///
    /// `fetch_and` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
    /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// "nand" Loġiku b'valur boolean.
    ///
    /// Twettaq operazzjoni loġika "nand" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
    ///
    /// Jirritorna l-valur preċedenti.
    ///
    /// `fetch_nand` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
    /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Ma nistgħux nużaw atomic_nand hawn għax jista 'jirriżulta f'bool b'valur invalidu.
        // Dan jiġri minħabba li l-operazzjoni atomika ssir b'interger ta '8 bit internament, li tissettja s-7 bits ta' fuq.
        //
        // Allura aħna nużaw biss fetch_xor jew swap minflok.
        if val {
            // ! (x&true)== !x Irridu nqalbu ż-bool.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&falz)==veru Għandna nissettjaw iż-bool għal veru.
            //
            self.swap(true, order)
        }
    }

    /// "or" Loġiku b'valur boolean.
    ///
    /// Twettaq operazzjoni loġika "or" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
    ///
    /// Jirritorna l-valur preċedenti.
    ///
    /// `fetch_or` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
    /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// "xor" Loġiku b'valur boolean.
    ///
    /// Twettaq operazzjoni loġika "xor" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
    ///
    /// Jirritorna l-valur preċedenti.
    ///
    /// `fetch_xor` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
    /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Jirritorna pointer li jista 'jinbidel għax-[`bool`] sottostanti.
    ///
    /// Li tagħmel qari u kitbiet mhux atomiċi fuq in-numru sħiħ li jirriżulta jista 'jkun ġirja tad-dejta.
    /// Dan il-metodu huwa l-aktar utli għall-FFI, fejn il-firma tal-funzjoni tista 'tuża `*mut bool` minflok `&AtomicBool`.
    ///
    /// Ir-ritorn ta 'pointer `*mut` minn referenza komuni għal dan l-atomiku huwa sigur minħabba li t-tipi atomiċi jaħdmu b'mutabilità interna.
    /// Il-modifiki kollha ta 'atomika jibdlu l-valur permezz ta' referenza kondiviża, u jistgħu jagħmlu dan b'mod sigur sakemm jużaw operazzjonijiet atomiċi.
    /// Kwalunkwe użu tal-pointer nej rritornat jeħtieġ blokka `unsafe` u xorta jrid iżomm l-istess restrizzjoni: l-operazzjonijiet fuqu għandhom ikunu atomiċi.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Iġib il-valur, u japplika funzjoni għalih li tirritorna valur ġdid fakultattiv.Jirritorna `Result` ta `Ok(previous_value)` jekk il-funzjoni rritornat `Some(_)`, inkella `Err(previous_value)`.
    ///
    /// Note: Dan jista 'jsejjaħ il-funzjoni bosta drabi jekk il-valur inbidel minn ħjut oħra fil-frattemp, sakemm il-funzjoni tirritorna `Some(_)`, iżda l-funzjoni tkun ġiet applikata darba biss għall-valur maħżun.
    ///
    ///
    /// `fetch_update` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// L-ewwel jiddeskrivi l-ordni meħtieġ għal meta l-operazzjoni finalment tirnexxi filwaqt li t-tieni jiddeskrivi l-ordni meħtieġ għat-tagħbijiet.
    /// Dawn jikkorrispondu għall-ordnijiet ta 'suċċess u falliment ta' [`AtomicBool::compare_exchange`] rispettivament.
    ///
    /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija ta' suċċess finali [`Relaxed`].
    /// L-ordni tat-tagħbija (failed) tista 'tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta' suċċess.
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Toħloq `AtomicPtr` ġdid.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Jirritorna referenza li tista 'tinbidel għall-pointer sottostanti.
    ///
    /// Dan huwa sigur għax ir-referenza li tista 'tinbidel tiggarantixxi li l-ebda ħjut oħra ma jkunu qed jaċċessaw id-dejta atomika fl-istess ħin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Ikseb aċċess atomiku għal pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - ir-referenza li tista 'tinbidel tiggarantixxi sjieda unika.
        //  - l-allinjament ta `*mut T` u `Self` huwa l-istess fuq il-pjattaformi kollha appoġġati minn rust, kif verifikat hawn fuq.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Jikkonsma l-atomiku u jirritorna l-valur miżmum.
    ///
    /// Dan huwa sigur minħabba li tgħaddi `self` bil-valur jiggarantixxi li l-ebda ħjut oħra ma jkunu qed jaċċessaw id-dejta atomika fl-istess ħin.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Tagħbija valur mill-pointer.
    ///
    /// `load` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// Valuri possibbli huma [`SeqCst`], [`Acquire`] u [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jekk `order` huwa [`Release`] jew [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Taħżen valur fil-pointer.
    ///
    /// `store` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// Valuri possibbli huma [`SeqCst`], [`Release`] u [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics jekk `order` huwa [`Acquire`] jew [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Taħżen valur fil-pointer, u tirritorna l-valur preċedenti.
    ///
    /// `swap` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
    /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq indikaturi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Taħżen valur fil-pointer jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
    ///
    /// Il-valur tar-ritorn huwa dejjem il-valur preċedenti.Jekk huwa ugwali għal `current`, allura l-valur ġie aġġornat.
    ///
    /// `compare_and_swap` jieħu wkoll argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// Innota li anke meta tuża [`AcqRel`], l-operazzjoni tista 'tfalli u għalhekk twettaq biss tagħbija `Acquire`, imma m'għandhiex semantika `Release`.
    /// L-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`] jekk jiġri, u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq indikaturi.
    ///
    /// # Migrazzjoni għal `compare_exchange` u `compare_exchange_weak`
    ///
    /// `compare_and_swap` hija ekwivalenti għal `compare_exchange` bil-mapping li ġej għall-ordnijiet tal-memorja:
    ///
    /// Oriġinali |Suċċess |Nuqqas
    /// -------- | ------- | -------
    /// Irrilassat |Irrilassat |Irrilassat Akkwista |Akkwista |Akkwista Rilaxx |Rilaxx |AcqRel rilassat |AcqRel |Akkwista SeqCst |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` jitħalla jonqos spuriously anke meta l-paragun jirnexxi, li jippermetti lill-kompilatur jiġġenera kodiċi ta 'assemblaġġ aħjar meta l-paragun u t-tpartit jintużaw f'ċirku.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Taħżen valur fil-pointer jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
    ///
    /// Il-valur ta 'ritorn huwa riżultat li jindika jekk il-valur il-ġdid kienx miktub u fih il-valur ta' qabel.
    /// Mas-suċċess dan il-valur huwa garantit li jkun ugwali għal `current`.
    ///
    /// `compare_exchange` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// `success` jiddeskrivi l-ordni meħtieġ għall-operazzjoni ta 'qari-modifika-kitba li sseħħ jekk il-paragun ma' `current` jirnexxi.
    /// `failure` jiddeskrivi l-ordni meħtieġ għall-operazzjoni tat-tagħbija li sseħħ meta l-paragun ifalli.
    /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija b'suċċess [`Relaxed`].
    ///
    /// L-ordni ta 'falliment tista' tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta 'suċċess.
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq indikaturi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Taħżen valur fil-pointer jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
    ///
    /// B'differenza minn [`AtomicPtr::compare_exchange`], din il-funzjoni titħalla tfalli b'mod spuriż anke meta l-paragun jirnexxi, li jista 'jirriżulta f'kodiċi aktar effiċjenti fuq xi pjattaformi.
    ///
    /// Il-valur ta 'ritorn huwa riżultat li jindika jekk il-valur il-ġdid kienx miktub u fih il-valur ta' qabel.
    ///
    /// `compare_exchange_weak` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// `success` jiddeskrivi l-ordni meħtieġ għall-operazzjoni ta 'qari-modifika-kitba li sseħħ jekk il-paragun ma' `current` jirnexxi.
    /// `failure` jiddeskrivi l-ordni meħtieġ għall-operazzjoni tat-tagħbija li sseħħ meta l-paragun ifalli.
    /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija b'suċċess [`Relaxed`].
    /// L-ordni ta 'falliment tista' tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta 'suċċess.
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq indikaturi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIGURTÀ: Dan l-intrinsiku mhuwiex sikur minħabba li jopera fuq pointer nej
        // imma nafu żgur li l-indikatur huwa validu (għadna kemm ħadna minn `UnsafeCell` li għandna b'referenza) u l-operazzjoni atomika nnifisha tippermettilna nimmutaw il-kontenuti `UnsafeCell` b'mod sikur.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Iġib il-valur, u japplika funzjoni għalih li tirritorna valur ġdid fakultattiv.Jirritorna `Result` ta `Ok(previous_value)` jekk il-funzjoni rritornat `Some(_)`, inkella `Err(previous_value)`.
    ///
    /// Note: Dan jista 'jsejjaħ il-funzjoni bosta drabi jekk il-valur inbidel minn ħjut oħra fil-frattemp, sakemm il-funzjoni tirritorna `Some(_)`, iżda l-funzjoni tkun ġiet applikata darba biss għall-valur maħżun.
    ///
    ///
    /// `fetch_update` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
    /// L-ewwel jiddeskrivi l-ordni meħtieġ għal meta l-operazzjoni finalment tirnexxi filwaqt li t-tieni jiddeskrivi l-ordni meħtieġ għat-tagħbijiet.
    /// Dawn jikkorrispondu għall-ordnijiet ta 'suċċess u falliment ta' [`AtomicPtr::compare_exchange`] rispettivament.
    ///
    /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija ta' suċċess finali [`Relaxed`].
    /// L-ordni tat-tagħbija (failed) tista 'tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta' suċċess.
    ///
    /// **Note:** Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuq indikaturi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Ikkonverti `bool` f `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Din il-makro tispiċċa biex ma tintużax fuq xi arkitetturi.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// Tip ta 'numru sħiħ li jista' jinqasam b'mod sigur bejn il-ħjut.
        ///
        /// Dan it-tip għandu l-istess rappreżentazzjoni fil-memorja bħat-tip ta 'numru sħiħ sottostanti, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// Għal aktar dwar id-differenzi bejn it-tipi atomiċi u t-tipi mhux atomiċi kif ukoll informazzjoni dwar il-portabbiltà ta 'dan it-tip, jekk jogħġbok ara l-[module-level documentation].
        ///
        ///
        /// **Note:** Dan it-tip huwa disponibbli biss fuq pjattaformi li jappoġġjaw tagħbijiet atomiċi u ħażniet ta '[`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Numru sħiħ atomiku inizjalizzat għal `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Ibgħat huwa impliċitament implimentat.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Toħloq numru sħiħ atomiku ġdid.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Jirritorna referenza li tista 'tinbidel għan-numru sħiħ sottostanti.
            ///
            /// Dan huwa sigur għax ir-referenza li tista 'tinbidel tiggarantixxi li l-ebda ħjut oħra ma jkunu qed jaċċessaw id-dejta atomika fl-istess ħin.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// let mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - ir-referenza li tista 'tinbidel tiggarantixxi sjieda unika.
                //  - l-allinjament ta `$int_type` u `Self` huwa l-istess, kif imwiegħed minn $cfg_align u vverifikat hawn fuq.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Jikkonsma l-atomiku u jirritorna l-valur miżmum.
            ///
            /// Dan huwa sigur minħabba li tgħaddi `self` bil-valur jiggarantixxi li l-ebda ħjut oħra ma jkunu qed jaċċessaw id-dejta atomika fl-istess ħin.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Tgħabbi valur min-numru sħiħ atomiku.
            ///
            /// `load` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
            /// Valuri possibbli huma [`SeqCst`], [`Acquire`] u [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics jekk `order` huwa [`Release`] jew [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Taħżen valur fin-numru sħiħ atomiku.
            ///
            /// `store` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
            ///  Valuri possibbli huma [`SeqCst`], [`Release`] u [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics jekk `order` huwa [`Acquire`] jew [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Taħżen valur fin-numru sħiħ atomiku, u tirritorna l-valur preċedenti.
            ///
            /// `swap` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Taħżen valur fin-numru sħiħ atomiku jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
            ///
            /// Il-valur tar-ritorn huwa dejjem il-valur preċedenti.Jekk huwa ugwali għal `current`, allura l-valur ġie aġġornat.
            ///
            /// `compare_and_swap` jieħu wkoll argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
            /// Innota li anke meta tuża [`AcqRel`], l-operazzjoni tista 'tfalli u għalhekk twettaq biss tagħbija `Acquire`, imma m'għandhiex semantika `Release`.
            ///
            /// L-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`] jekk jiġri, u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrazzjoni għal `compare_exchange` u `compare_exchange_weak`
            ///
            /// `compare_and_swap` hija ekwivalenti għal `compare_exchange` bil-mapping li ġej għall-ordnijiet tal-memorja:
            ///
            /// Oriġinali |Suċċess |Nuqqas
            /// -------- | ------- | -------
            /// Irrilassat |Irrilassat |Irrilassat Akkwista |Akkwista |Akkwista Rilaxx |Rilaxx |AcqRel rilassat |AcqRel |Akkwista SeqCst |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` jitħalla jonqos spuriously anke meta l-paragun jirnexxi, li jippermetti lill-kompilatur jiġġenera kodiċi ta 'assemblaġġ aħjar meta l-paragun u t-tpartit jintużaw f'ċirku.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Taħżen valur fin-numru sħiħ atomiku jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
            ///
            /// Il-valur ta 'ritorn huwa riżultat li jindika jekk il-valur il-ġdid kienx miktub u fih il-valur ta' qabel.
            /// Mas-suċċess dan il-valur huwa garantit li jkun ugwali għal `current`.
            ///
            /// `compare_exchange` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
            /// `success` jiddeskrivi l-ordni meħtieġ għall-operazzjoni ta 'qari-modifika-kitba li sseħħ jekk il-paragun ma' `current` jirnexxi.
            /// `failure` jiddeskrivi l-ordni meħtieġ għall-operazzjoni tat-tagħbija li sseħħ meta l-paragun ifalli.
            /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija b'suċċess [`Relaxed`].
            ///
            /// L-ordni ta 'falliment tista' tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta 'suċċess.
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Taħżen valur fin-numru sħiħ atomiku jekk il-valur kurrenti huwa l-istess bħall-valur `current`.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// din il-funzjoni titħalla tfalli spuriously anke meta l-paragun jirnexxi, li jista 'jirriżulta f'kodiċi aktar effiċjenti fuq xi pjattaformi.
            /// Il-valur ta 'ritorn huwa riżultat li jindika jekk il-valur il-ġdid kienx miktub u fih il-valur ta' qabel.
            ///
            /// `compare_exchange_weak` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
            /// `success` jiddeskrivi l-ordni meħtieġ għall-operazzjoni ta 'qari-modifika-kitba li sseħħ jekk il-paragun ma' `current` jirnexxi.
            /// `failure` jiddeskrivi l-ordni meħtieġ għall-operazzjoni tat-tagħbija li sseħħ meta l-paragun ifalli.
            /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija b'suċċess [`Relaxed`].
            ///
            /// L-ordni ta 'falliment tista' tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta 'suċċess.
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// let mut old= val.load(Ordering::Relaxed);
            /// loop {let new=old * 2;
            ///     taqbel ma val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Iżżid mal-valur kurrenti, u tirritorna l-valur preċedenti.
            ///
            /// Din l-operazzjoni tgeżwer fuq overflow.
            ///
            /// `fetch_add` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Tnaqqas mill-valur kurrenti, u tirritorna l-valur preċedenti.
            ///
            /// Din l-operazzjoni tgeżwer fuq overflow.
            ///
            /// `fetch_sub` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitwise "and" bil-valur kurrenti.
            ///
            /// Twettaq operazzjoni bit0 bit "and" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
            ///
            /// Jirritorna l-valur preċedenti.
            ///
            /// `fetch_and` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitwise "nand" bil-valur kurrenti.
            ///
            /// Twettaq operazzjoni bit0 bit "nand" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
            ///
            /// Jirritorna l-valur preċedenti.
            ///
            /// `fetch_nand` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitwise "or" bil-valur kurrenti.
            ///
            /// Twettaq operazzjoni bit0 bit "or" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
            ///
            /// Jirritorna l-valur preċedenti.
            ///
            /// `fetch_or` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitwise "xor" bil-valur kurrenti.
            ///
            /// Twettaq operazzjoni bit0 bit "xor" fuq il-valur kurrenti u l-argument `val`, u tistabbilixxi l-valur il-ġdid għar-riżultat.
            ///
            /// Jirritorna l-valur preċedenti.
            ///
            /// `fetch_xor` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Iġib il-valur, u japplika funzjoni għalih li tirritorna valur ġdid fakultattiv.Jirritorna `Result` ta `Ok(previous_value)` jekk il-funzjoni rritornat `Some(_)`, inkella `Err(previous_value)`.
            ///
            /// Note: Dan jista 'jsejjaħ il-funzjoni bosta drabi jekk il-valur inbidel minn ħjut oħra fil-frattemp, sakemm il-funzjoni tirritorna `Some(_)`, iżda l-funzjoni tkun ġiet applikata darba biss għall-valur maħżun.
            ///
            ///
            /// `fetch_update` jieħu żewġ argumenti [`Ordering`] biex jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.
            /// L-ewwel jiddeskrivi l-ordni meħtieġ għal meta l-operazzjoni finalment tirnexxi filwaqt li t-tieni jiddeskrivi l-ordni meħtieġ għat-tagħbijiet.Dawn jikkorrispondu għall-ordnijiet ta 'suċċess u falliment ta'
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// L-użu ta [`Acquire`] bħala ordni ta' suċċess jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta [`Release`] jagħmel it-tagħbija ta' suċċess finali [`Relaxed`].
            /// L-ordni tat-tagħbija (failed) tista 'tkun biss [`SeqCst`], [`Acquire`] jew [`Relaxed`] u għandha tkun ekwivalenti għal jew aktar dgħajfa mill-ordni ta' suċċess.
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Ordni: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Ordni: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Massimu bil-valur kurrenti.
            ///
            /// Issib il-massimu tal-valur kurrenti u l-argument `val`, u jistabbilixxi l-valur il-ġdid għar-riżultat.
            ///
            /// Jirritorna l-valur preċedenti.
            ///
            /// `fetch_max` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=42;
            /// let max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// afferma! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimu bil-valur kurrenti.
            ///
            /// Issib il-minimu tal-valur kurrenti u l-argument `val`, u jistabbilixxi l-valur il-ġdid għar-riżultat.
            ///
            /// Jirritorna l-valur preċedenti.
            ///
            /// `fetch_min` jieħu argument [`Ordering`] li jiddeskrivi l-ordni tal-memorja ta 'din l-operazzjoni.Il-modi kollha ta 'ordni huma possibbli.
            /// Innota li l-użu ta [`Acquire`] jagħmel il-maħżen parti minn din l-operazzjoni [`Relaxed`], u l-użu ta' [`Release`] jagħmel il-parti tat-tagħbija [`Relaxed`].
            ///
            ///
            /// **Nota**: Dan il-metodu huwa disponibbli biss fuq pjattaformi li jappoġġjaw operazzjonijiet atomiċi fuqhom
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// let bar=12;
            /// let min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIGURTÀ: it-tiġrijiet tad-dejta huma evitati minn intrinsiċi atomiċi.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Jirritorna pointer mutabbli għan-numru sħiħ sottostanti.
            ///
            /// Li tagħmel qari u kitbiet mhux atomiċi fuq in-numru sħiħ li jirriżulta jista 'jkun ġirja tad-dejta.
            /// Dan il-metodu huwa l-aktar utli għall-FFI, fejn tista 'tuża l-firma tal-funzjoni
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Ir-ritorn ta 'pointer `*mut` minn referenza komuni għal dan l-atomiku huwa sigur minħabba li t-tipi atomiċi jaħdmu b'mutabilità interna.
            /// Il-modifiki kollha ta 'atomika jibdlu l-valur permezz ta' referenza kondiviża, u jistgħu jagħmlu dan b'mod sigur sakemm jużaw operazzjonijiet atomiċi.
            /// Kwalunkwe użu tal-pointer nej rritornat jeħtieġ blokka `unsafe` u xorta jrid iżomm l-istess restrizzjoni: l-operazzjonijiet fuqu għandhom ikunu atomiċi.
            ///
            ///
            /// # Examples
            ///
            /// "" tinjora (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// extern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SIGURTÀ: Sikur sakemm `my_atomic_op` huwa atomiku.
            /// mhux sikur {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Jirritorna l-valur preċedenti (bħal __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Jirritorna l-valur preċedenti (bħal __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// jirritorna l-valur massimu (paragun iffirmat)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// jirritorna l-valur min (paragun iffirmat)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// jirritorna l-valur massimu (paragun mhux iffirmat)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// jirritorna l-valur min (paragun mhux iffirmat)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Ċint atomiku.
///
/// Skont l-ordni speċifikata, ċint ma jħallix lill-kompilatur u lis-CPU milli jordnaw mill-ġdid ċerti tipi ta 'operazzjonijiet tal-memorja madwaru.
/// Dan joħloq sinkronizzazzjoni-ma 'relazzjonijiet bejnha u operazzjonijiet atomiċi jew ċnut f'ħjut oħra.
///
/// Ċint 'A' li għandu (mill-inqas) [`Release`] li jordna semantika, jissinkronizza ma 'ċint 'B' ma' (mill-inqas) semantika [`Acquire`], jekk u biss jekk jeżistu operazzjonijiet X u Y, it-tnejn li joperaw fuq xi oġġett atomiku 'M' b'tali mod li A hija sekwenzjata qabel X, Y huwa sinkronizzat qabel B u Y josservaw il-bidla għal M.
/// Dan jipprovdi dipendenza jiġri qabel bejn A u B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Operazzjonijiet atomiċi bis-semantika [`Release`] jew [`Acquire`] jistgħu wkoll jissinkronizzaw ma 'ċint.
///
/// Ċint li għandu l-ordni [`SeqCst`], minbarra li għandu kemm is-semantika [`Acquire`] kif ukoll [`Release`], jipparteċipa fl-ordni tal-programm globali tal-operazzjonijiet u/jew rixtelli [`SeqCst`] oħra.
///
/// Taċċetta l-ordnijiet [`Acquire`], [`Release`], [`AcqRel`] u [`SeqCst`].
///
/// # Panics
///
/// Panics jekk `order` huwa [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // Primittiv ta 'esklużjoni reċiproka bbażat fuq spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Stenna sakemm il-valur l-antik huwa `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Dan l-ilqugħ jissinkronizza-mal-maħżen f `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SIGURTÀ: l-użu ta 'ċint atomiku huwa sigur.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Ċint tal-memorja tal-kompilatur.
///
/// `compiler_fence` ma jarmi l-ebda kodiċi tal-magna, iżda jirrestrinġi t-tipi ta 'memorja li tordna mill-ġdid li l-kompilatur jitħalla jagħmel.Speċifikament, skont is-semantika [`Ordering`] mogħtija, il-kompilatur jista 'ma jitħalliex milli jiċċaqlaq jaqra jew jikteb minn qabel jew wara t-telefonata għan-naħa l-oħra tas-sejħa għal `compiler_fence`.Innota li **ma** ma jimpedixxix lill-*ħardwer* milli jagħmel ordni mill-ġdid bħal din.
///
/// Din mhix problema f'kuntest ta 'eżekuzzjoni b'kamin wieħed, iżda meta ħjut oħra jistgħu jimmodifikaw il-memorja fl-istess ħin, huma meħtieġa primittivi ta' sinkronizzazzjoni aktar b'saħħithom bħal [`fence`].
///
/// L-ordni mill-ġdid evitat mis-semantika ta 'l-ordni differenti huma:
///
///  - b [`SeqCst`], l-ebda ordni mill-ġdid ta 'qari u kitbiet f'dan il-punt mhu permess.
///  - ma [`Release`], qari u kitbiet preċedenti ma jistgħux jiġu mċaqalqa wara kitbiet sussegwenti.
///  - b [`Acquire`], il-qari u l-kitbiet sussegwenti ma jistgħux jiġu mċaqalqa qabel il-qari preċedenti.
///  - b [`AcqRel`], iż-żewġ regoli ta 'hawn fuq huma infurzati.
///
/// `compiler_fence` ġeneralment huwa utli biss għall-prevenzjoni ta 'ħajta milli tiġri *bih innifsu*.Jiġifieri, jekk ħajt partikolari qed jeżegwixxi biċċa waħda ta 'kodiċi, u mbagħad jiġi interrott, u jibda jeżegwixxi kodiċi x'imkien ieħor (waqt li jkun għadu fl-istess ħajt, u konċettwalment għadu fuq l-istess qalba).Fi programmi tradizzjonali, dan jista 'jseħħ biss meta jiġi rreġistrat handler tas-sinjali.
/// F`kodiċi ta`livell aktar baxx, sitwazzjonijiet bħal dawn jistgħu jinqalgħu wkoll meta jittrattaw interruzzjonijiet, meta jimplimentaw ħjut ħodor bi prelazzjoni, eċċ.
/// Qarrejja kurjużi huma mħeġġa jaqraw id-diskussjoni tal-qalba Linux dwar [memory barriers].
///
/// # Panics
///
/// Panics jekk `order` huwa [`Relaxed`].
///
/// # Examples
///
/// Mingħajr `compiler_fence`, ix-`assert_eq!` fil-kodiċi li ġej huwa *mhux* garantit li jirnexxi, minkejja li kollox jiġri f'ħajt wieħed.
/// Biex tara għaliex, ftakar li l-kompilatur huwa liberu li jibdel il-ħwienet għal `IMPORTANT_VARIABLE` u `IS_READ` peress li t-tnejn huma `Ordering::Relaxed`.Jekk tagħmel hekk, u l-immaniġġjar tas-sinjali jiġi invokat eżatt wara li `IS_READY` jiġi aġġornat, allura l-immaniġġjar tas-sinjal jara `IS_READY=1`, imma `IMPORTANT_VARIABLE=0`.
/// L-użu ta `compiler_fence` jirrimedja din is-sitwazzjoni.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // jipprevjenu li kitbiet preċedenti jiġu mċaqilqa lil hinn minn dan il-punt
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SIGURTÀ: l-użu ta 'ċint atomiku huwa sigur.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Jindika lill-proċessur li qiegħed ġewwa ċirku ta 'spin-busy ("spin lock").
///
/// Din il-funzjoni hija skaduta favur [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}