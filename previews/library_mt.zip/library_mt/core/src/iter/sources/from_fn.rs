use crate::fmt;

/// Joħloq iteratur ġdid fejn kull iterazzjoni ssejjaħ l-għeluq ipprovdut `F: FnMut() -> Option<T>`.
///
/// Dan jippermetti l-ħolqien ta 'iteratur tad-dwana bi kwalunkwe mġieba mingħajr ma tuża s-sintassi aktar verbose tal-ħolqien ta' tip dedikat u l-implimentazzjoni tax-[`Iterator`] trait għaliha.
///
/// Innota li l-iteratur `FromFn` ma jagħmilx suppożizzjonijiet dwar l-imġieba ta 'l-għeluq, u għalhekk b'mod konservattiv ma jimplimentax [`FusedIterator`], jew jegħleb [`Iterator::size_hint()`] mill-`(0, None)` default tiegħu.
///
///
/// L-għeluq jista 'juża captures u l-ambjent tiegħu biex isegwi l-istat bejn iterazzjonijiet.Jiddependi fuq kif jintuża l-iteratur, dan jista 'jirrikjedi li tiġi speċifikata l-kelma prinċipali [`move`] fuq l-għeluq.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ejja nimplimentaw mill-ġdid il-kontro iteratur minn [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Żid l-għadd tagħna.Dan hu għaliex bdejna żero.
///     count += 1;
///
///     // Iċċekkja biex tara jekk lestejtx ngħoddu jew le.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iteratur fejn kull iterazzjoni ssejjaħ l-għeluq ipprovdut `F: FnMut() -> Option<T>`.
///
/// Dan `struct` huwa maħluq mill-funzjoni [`iter::from_fn()`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}