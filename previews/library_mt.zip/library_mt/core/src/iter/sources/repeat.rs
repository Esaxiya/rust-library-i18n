use crate::iter::{FusedIterator, TrustedLen};

/// Joħloq iteratur ġdid li jirrepeti element wieħed bla tmiem.
///
/// Il-funzjoni `repeat()` tirrepeti valur wieħed ripetutament.
///
/// Iteraturi infiniti bħal `repeat()` spiss jintużaw ma 'adapters bħal [`Iterator::take()`], sabiex jagħmluhom finiti.
///
/// Jekk it-tip ta 'element tal-iteratur li għandek bżonn ma jimplimentax `Clone`, jew jekk ma tridx iżżomm l-element ripetut fil-memorja, minflok tista' tuża l-funzjoni [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::iter;
///
/// // in-numru erba '4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // Yup, għadhom erbgħa
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Sejjer finit b [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // dak l-aħħar eżempju kien wisq fours.Ejja jkollna biss erba 'fours.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... u issa lestejna
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iteratur li jirrepeti element bla tmiem.
///
/// Dan `struct` huwa maħluq mill-funzjoni [`repeat()`].Ara d-dokumentazzjoni tagħha għal aktar.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}