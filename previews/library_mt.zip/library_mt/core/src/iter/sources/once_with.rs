use crate::iter::{FusedIterator, TrustedLen};

/// Joħloq iteratur li lazily jiġġenera valur eżattament darba billi jinvoka l-għeluq ipprovdut.
///
/// Dan huwa komunement użat biex jiġi adattat ġeneratur ta 'valur wieħed f [`chain()`] ta' tipi oħra ta 'iterazzjoni.
/// Forsi għandek iteratur li jkopri kważi kollox, imma għandek bżonn każ speċjali żejjed.
/// Forsi għandek funzjoni li taħdem fuq iteraturi, imma għandek bżonn biss tipproċessa valur wieħed.
///
/// B'differenza minn [`once()`], din il-funzjoni se tiġġenera b'mod għażżien il-valur fuq talba.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::iter;
///
/// // wieħed huwa l-iktar numru solitarju
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // wieħed biss, dak kollu li jkollna
/// assert_eq!(None, one.next());
/// ```
///
/// Katina flimkien ma 'iteratur ieħor.
/// Ejja ngħidu li rridu nirrepetu fuq kull fajl tad-direttorju `.foo`, iżda wkoll fajl ta 'konfigurazzjoni,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // għandna bżonn nikkonvertu minn iteratur ta 'DirEntry-s għal iteratur ta' PathBufs, allura nużaw mappa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // issa, l-iteratur tagħna biss għall-fajl tal-konfigurazzjoni tagħna
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // katina ż-żewġ iteraturi flimkien f'iteratur kbir wieħed
/// let files = dirs.chain(config);
///
/// // dan jagħtina l-fajls kollha f .foo kif ukoll f .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iteratur li jagħti element wieħed tat-tip `A` billi japplika l-għeluq ipprovdut `F: FnOnce() -> A`.
///
///
/// Dan `struct` huwa maħluq mill-funzjoni [`once_with()`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}