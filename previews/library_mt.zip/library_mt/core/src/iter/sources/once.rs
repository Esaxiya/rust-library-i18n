use crate::iter::{FusedIterator, TrustedLen};

/// Joħloq iteratur li jagħti element eżattament darba.
///
/// Dan huwa komunement użat biex jiġi adattat valur wieħed f [`chain()`] ta 'tipi oħra ta' iterazzjoni.
/// Forsi għandek iteratur li jkopri kważi kollox, imma għandek bżonn każ speċjali żejjed.
/// Forsi għandek funzjoni li taħdem fuq iteraturi, imma għandek bżonn biss tipproċessa valur wieħed.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::iter;
///
/// // wieħed huwa l-iktar numru solitarju
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // wieħed biss, dak kollu li jkollna
/// assert_eq!(None, one.next());
/// ```
///
/// Katina flimkien ma 'iteratur ieħor.
/// Ejja ngħidu li rridu nirrepetu fuq kull fajl tad-direttorju `.foo`, iżda wkoll fajl ta 'konfigurazzjoni,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // għandna bżonn nikkonvertu minn iteratur ta 'DirEntry-s għal iteratur ta' PathBufs, allura nużaw mappa
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // issa, l-iteratur tagħna biss għall-fajl tal-konfigurazzjoni tagħna
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // katina ż-żewġ iteraturi flimkien f'iteratur kbir wieħed
/// let files = dirs.chain(config);
///
/// // dan jagħtina l-fajls kollha f .foo kif ukoll f .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iteratur li jagħti element eżattament darba.
///
/// Dan `struct` huwa maħluq mill-funzjoni [`once()`].Ara d-dokumentazzjoni tagħha għal aktar.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}