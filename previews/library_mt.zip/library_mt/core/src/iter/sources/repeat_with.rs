use crate::iter::{FusedIterator, TrustedLen};

/// Joħloq iteratur ġdid li jirrepeti elementi tat-tip `A` bla tmiem billi japplika l-għeluq ipprovdut, ir-ripetitur, `F: FnMut() -> A`.
///
/// Il-funzjoni `repeat_with()` issejjaħ ir-ripetitur għal darb'oħra.
///
/// Iteraturi infiniti bħal `repeat_with()` spiss jintużaw ma 'adapters bħal [`Iterator::take()`], sabiex jagħmluhom finiti.
///
/// Jekk it-tip ta 'element tal-iteratur li għandek bżonn jimplimenta [`Clone`], u huwa OK li żżomm l-element tas-sors fil-memorja, minflok għandek tuża l-funzjoni [`repeat()`].
///
///
/// Iteratur prodott minn `repeat_with()` mhuwiex [`DoubleEndedIterator`].
/// Jekk għandek bżonn `repeat_with()` biex tirritorna [`DoubleEndedIterator`], jekk jogħġbok iftaħ kwistjoni ta 'GitHub li tispjega l-każ ta' użu tiegħek.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::iter;
///
/// // ejja nassumu li għandna xi valur ta 'tip li mhuwiex `Clone` jew li ma jridux li jkollhom fil-memorja għadhom biss għax huwa għali:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // valur partikolari għal dejjem:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Uża mutazzjoni u tmur finit:
///
/// ```rust
/// use std::iter;
///
/// // Miż-żero għat-tielet qawwa ta 'tnejn:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... u issa lestejna
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Iteratur li jirrepeti elementi tat-tip `A` bla tmiem billi japplika l-għeluq ipprovdut `F: FnMut() -> A`.
///
///
/// Dan `struct` huwa maħluq mill-funzjoni [`repeat_with()`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}