use crate::{iter::FusedIterator, ops::Try};

/// Iteratur li jirrepeti bla tmiem.
///
/// Dan `struct` huwa maħluq bil-metodu [`cycle`] fuq [`Iterator`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // l-iteratur taċ-ċiklu huwa vojt jew infinit
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // itera għal kollox l-iteratur attwali.
        // dan huwa meħtieġ għax `self.iter` jista 'jkun vojt anke meta `self.orig` ma jkunx
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // imla ċiklu sħiħ, billi żżomm rekord ta 'jekk l-iteratur ċiklat huwiex vojt jew le.
        // għandna nirritornaw kmieni f'każ ta 'iteratur vojt biex nevitaw linja infinita
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // L-ebda override `fold`, għax `fold` ma jagħmilx ħafna sens għal `Cycle`, u ma nistgħu nagħmlu xejn aħjar mill-inadempjenza.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}