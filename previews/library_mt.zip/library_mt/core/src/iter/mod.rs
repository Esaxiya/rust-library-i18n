//! Iterazzjoni esterna kompożibbli.
//!
//! Jekk sibt lilek innifsek b'ġabra ta 'xi tip, u teħtieġ li twettaq operazzjoni fuq l-elementi ta' l-imsemmija ġabra, malajr tidħol f 'iterators'.
//! L-iteraturi jintużaw ħafna fil-kodiċi idjomatiku Rust, allura ta 'min isiru familjari magħhom.
//!
//! Qabel ma nispjega aktar, ejja nitkellmu dwar kif dan il-modulu huwa strutturat:
//!
//! # Organization
//!
//! Dan il-modulu huwa organizzat fil-biċċa l-kbira skont it-tip:
//!
//! * [Traits] huma l-porzjon ewlieni: dawn iż-traits jiddefinixxu x'tip ta 'iteraturi jeżistu u x'tista' tagħmel magħhom.Il-metodi ta 'dawn iż-traits ta' min ipoġġu ftit ħin ta 'studju żejjed.
//! * [Functions] ipprovdi xi modi utli biex toħloq xi iteraturi bażiċi.
//! * [Structs] ħafna drabi huma t-tipi ta 'ritorn tal-metodi varji fuq traits ta' dan il-modulu.Normalment tkun trid tħares lejn il-metodu li joħloq ix-`struct`, aktar milli x-`struct` innifsu.
//! Għal aktar dettalji dwar għaliex, ara '[Implimentazzjoni Iteratur](#implimentazzjoni-iteratur)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Dak hu!Ejja nħaffru fl-iteraturi.
//!
//! # Iterator
//!
//! Il-qalb u r-ruħ ta 'dan il-modulu hija [`Iterator`] trait.Il-qalba ta [`Iterator`] tidher hekk:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iteratur għandu metodu, [`next`], li meta jissejjaħ, jirritorna ['Għażla'] '<Item>".
//! [`next`] jirritorna [`Some(Item)`] sakemm ikun hemm elementi, u ladarba jkunu ġew eżawriti kollha, jirritorna `None` biex jindika li l-iterazzjoni hija lesta.
//! Iteraturi individwali jistgħu jagħżlu li jkomplu l-iterazzjoni, u għalhekk is-sejħa għal [`next`] għal darb'oħra tista 'jew ma tistax eventwalment tibda tirritorna [`Some(Item)`] mill-ġdid f'xi punt (per eżempju, ara [`TryIter`]).
//!
//!
//! Id-definizzjoni sħiħa ta '[`Iterator`] tinkludi numru ta' metodi oħra wkoll, iżda huma metodi awtomatiċi, mibnija fuq [`next`], u għalhekk ikollokhom b'xejn.
//!
//! L-iteraturi huma kompożibbli wkoll, u huwa komuni li tgħaqqadhom flimkien biex jagħmlu forom aktar kumplessi ta 'pproċessar.Ara t-taqsima [Adapters](#adapters) hawn taħt għal aktar dettalji.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # It-tliet forom ta 'iterazzjoni
//!
//! Hemm tliet metodi komuni li jistgħu joħolqu iteraturi minn ġabra:
//!
//! * `iter()`, li jtenni fuq `&T`.
//! * `iter_mut()`, li jtenni fuq `&mut T`.
//! * `into_iter()`, li jtenni fuq `T`.
//!
//! Diversi affarijiet fil-librerija standard jistgħu jimplimentaw waħda jew aktar mit-tlieta, fejn xieraq.
//!
//! # Implimentazzjoni tal-Iteratur
//!
//! Il-ħolqien ta 'iteratur tiegħek jinvolvi żewġ passi: il-ħolqien ta' `struct` biex iżomm l-istat ta 'l-iteratur, u mbagħad timplimenta [`Iterator`] għal dak ix-`struct`.
//! Dan hu għaliex hemm tant `strutt`s f'dan il-modulu: hemm wieħed għal kull iteratur u adapter tal-iteratur.
//!
//! Ejja nagħmlu iteratur bl-isem `Counter` li jgħodd minn `1` sa `5`:
//!
//! ```
//! // L-ewwel, l-istruttura:
//!
//! /// Iteratur li jgħodd minn wieħed għal ħamsa
//! struct Counter {
//!     count: usize,
//! }
//!
//! // irridu li l-għadd tagħna jibda f'waħda, allura ejja nżidu metodu new() biex ngħinu.
//! // Dan mhux strettament meħtieġ, iżda huwa konvenjenti.
//! // Innota li nibdew `count` għal żero, naraw għaliex fl-implimentazzjoni `next()`'s hawn taħt.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Imbagħad, nimplimentaw `Iterator` għax-`Counter` tagħna:
//!
//! impl Iterator for Counter {
//!     // inkunu qed ngħoddu bl-użu
//!     type Item = usize;
//!
//!     // next() huwa l-uniku metodu meħtieġ
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Żid l-għadd tagħna.Dan hu għaliex bdejna żero.
//!         self.count += 1;
//!
//!         // Iċċekkja biex tara jekk lestejtx ngħoddu jew le.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // U issa nistgħu nużawha!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Li ssejjaħ lil [`next`] b'dan il-mod isir ripetittiv.Rust għandu kostruzzjoni li tista 'ssejjaħ [`next`] fuq l-iteratur tiegħek, sakemm tilħaq `None`.Ejja ngħaddu dak li jmiss.
//!
//! Innota wkoll li `Iterator` jipprovdi implimentazzjoni awtomatika ta 'metodi bħal `nth` u `fold` li jsejħu `next` internament.
//! Madankollu, huwa wkoll possibbli li tikteb implimentazzjoni personalizzata ta 'metodi bħal `nth` u `fold` jekk iteratur jista' jikkalkulahom b'mod aktar effiċjenti mingħajr ma jċempel lil `next`.
//!
//! # `for` linji u `IntoIterator`
//!
//! Is-sintassi tal-linja `for` ta 'Rust hija fil-fatt zokkor għall-iteraturi.Hawn eżempju bażiku ta `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Dan se jistampa n-numri minn wieħed sa ħamsa, kull wieħed fuq il-linja tiegħu stess.Imma tinduna xi ħaġa hawn: qatt ma ċempilna xejn fuq vector tagħna biex nipproduċu iteratur.X'jagħti?
//!
//! Hemm trait fil-librerija standard biex tikkonverti xi ħaġa f'iteratur: [`IntoIterator`].
//! Dan trait għandu metodu wieħed, [`into_iter`], li jikkonverti l-ħaġa li timplimenta [`IntoIterator`] f'iteratur.
//! Ejja nagħtu ħarsa lejn dak il-linja `for` għal darb'oħra, u dak li l-kompilatur jikkonvertih fi:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust tneħħi z-zokkor fi:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! L-ewwel, insejħu `into_iter()` fuq il-valur.Imbagħad, aħna nqabblu fuq l-iteratur li jirritorna, billi nsejħu [`next`] aktar u aktar sakemm naraw `None`.
//! F'dak il-punt, aħna `break` barra mill-linja, u aħna lestejna nirrepetu.
//!
//! Hemm daqsxejn sottili aktar hawn: il-librerija standard fiha implimentazzjoni interessanti ta [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Fi kliem ieħor, [l-Iteratur`] kollha jimplimentaw [`IntoIterator`], billi sempliċement jirritornaw lilhom infushom.Dan ifisser żewġ affarijiet:
//!
//! 1. Jekk qed tikteb [`Iterator`], tista 'tużaha ma' linja `for`.
//! 2. Jekk qed toħloq kollezzjoni, l-implimentazzjoni ta [`IntoIterator`] għaliha tippermetti li l-kollezzjoni tiegħek tintuża mal-linja `for`.
//!
//! # Iterazzjoni b'referenza
//!
//! Peress li [`into_iter()`] jieħu `self` bil-valur, l-użu ta 'linja `for` biex iterat fuq ġabra tikkonsma dik il-ġabra.Ħafna drabi, tista 'tkun trid ttenni fuq ġabra mingħajr ma tikkonsmaha.
//! Ħafna kollezzjonijiet joffru metodi li jipprovdu iteraturi fuq referenzi, konvenzjonalment imsejħa `iter()` u `iter_mut()` rispettivament:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` għadu proprjetà ta 'din il-funzjoni.
//! ```
//!
//! Jekk tip ta 'ġbir `C` jipprovdi `iter()`, ġeneralment jimplimenta wkoll `IntoIterator` għal `&C`, b'implimentazzjoni li ssejjaħ biss `iter()`.
//! Bl-istess mod, ġabra `C` li tipprovdi `iter_mut()` ġeneralment timplimenta `IntoIterator` għal `&mut C` billi tiddelega lil `iter_mut()`.Dan jippermetti shorthand konvenjenti:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // l-istess bħal `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // l-istess bħal `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Filwaqt li ħafna kollezzjonijiet joffru `iter()`, mhux kollha joffru `iter_mut()`.
//! Pereżempju, il-mutazzjoni taċ-ċwievet ta [`HashSet<T>`] jew [`HashMap<K, V>`] tista' tpoġġi l-kollezzjoni fi stat inkonsistenti jekk jinbidlu l-hashes taċ-ċavetta, għalhekk dawn il-kollezzjonijiet joffru biss `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funzjonijiet li jieħdu [`Iterator`] u jirritornaw [`Iterator`] ieħor spiss jissejħu 'iterator adapters', għax huma forma ta '' adapter '
//! pattern'.
//!
//! Adapters iteraturi komuni jinkludu [`map`], [`take`], u [`filter`].
//! Għal aktar, ara d-dokumentazzjoni tagħhom.
//!
//! Jekk adapter tal-iteratur panics, l-iteratur ikun fi stat mhux speċifikat (iżda bla periklu għall-memorja).
//! Dan l-istat mhux garantit ukoll li jibqa 'l-istess bejn il-verżjonijiet ta' Rust, allura għandek tevita li tistrieħ fuq il-valuri eżatti rritornati minn iteratur li jkun ippanikjat.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteraturi (u l-iteratur [adapters](#adapters)) huma *għażżienin*. Dan ifisser li l-ħolqien ta 'iteratur sempliċement ma _do_ ħafna. Ma jseħħ xejn verament qabel ma ċċempel lil [`next`].
//! Xi drabi dan huwa sors ta 'konfużjoni meta jinħoloq iteratur biss għall-effetti sekondarji tiegħu.
//! Pereżempju, il-metodu [`map`] jitlob għeluq fuq kull element iterat fuq:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Dan mhux se jistampa xi valuri, peress li ħloqna biss iteratur, aktar milli nużawh.Il-kompilatur iwissina dwar dan it-tip ta 'mġieba:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Il-mod idjomatiku biex tikteb [`map`] għall-effetti sekondarji tiegħu huwa li tuża linja `for` jew ċempel il-metodu [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Mod ieħor komuni biex tevalwa iteratur huwa li tuża l-metodu [`collect`] biex tipproduċi ġabra ġdida.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! L-iteraturi m'għandhomx għalfejn ikunu finiti.Bħala eżempju, firxa miftuħa hija iteratur infinit:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Huwa komuni li tuża l-adapter iteratur [`take`] biex tbiddel iteratur infinit f'wieħed finit:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Dan se jistampa n-numri `0` sa `4`, kull wieħed fuq il-linja tiegħu stess.
//!
//! Żomm f'moħħok li metodi fuq iteraturi infiniti, anke dawk li għalihom jista 'jiġi determinat riżultat matematikament fi żmien finit, jistgħu ma jintemmux.
//! Speċifikament, metodi bħal [`min`], li fil-każ ġenerali jeħtieġu li jaqsmu kull element fl-iteratur, x'aktarx ma jirritornawx b'suċċess għal xi iteraturi infiniti.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh le!Ċirku infinit!
//! // `ones.min()` tikkawża linja infinita, allura ma nilħqux dan il-punt!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;