/// Iteratur li jaf it-tul eżatt tiegħu.
///
/// Ħafna [`Iterator`] ma jafux kemm-il darba se jtennu, imma xi wħud.
/// Jekk iteratur jaf kemm-il darba jista 'jtenni, li jipprovdi aċċess għal dik l-informazzjoni jista' jkun utli.
/// Pereżempju, jekk trid ttenni lura, bidu tajjeb huwa li tkun taf fejn hu t-tmiem.
///
/// Meta timplimenta `ExactSizeIterator`, trid timplimenta wkoll [`Iterator`].
/// Meta tagħmel hekk, l-implimentazzjoni ta [`Iterator::size_hint`]*għandha* tirritorna d-daqs eżatt tal-iteratur.
///
/// Il-metodu [`len`] għandu implimentazzjoni awtomatika, allura normalment m'għandekx timplimentah.
/// Madankollu, inti tista 'tkun kapaċi tipprovdi implimentazzjoni aktar performanti mill-inadempjenza, u għalhekk l-annullament tagħha f'dan il-każ jagħmel sens.
///
///
/// Innota li dan trait huwa trait sigur u bħala tali *ma* u *ma jistax* jiggarantixxi li t-tul ritornat huwa korrett.
/// Dan ifisser li l-kodiċi `unsafe`**m'għandux** jiddependi fuq il-korrettezza ta [`Iterator::size_hint`].
/// L-instabbli u mhux sikur [`TrustedLen`](super::marker::TrustedLen) trait jagħti din il-garanzija addizzjonali.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// // firxa finita taf eżattament kemm-il darba se ttenni
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Fix-[module-level docs], implimentajna [`Iterator`], `Counter`.
/// Ejjew nimplimentaw `ExactSizeIterator` għalih ukoll:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Nistgħu faċilment nikkalkulaw in-numru li jifdal ta 'iterazzjonijiet.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // U issa nistgħu nużawha!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Jirritorna t-tul eżatt tal-iteratur.
    ///
    /// L-implimentazzjoni tiżgura li l-iteratur jirritorna eżattament `len()` aktar darbiet valur [`Some(T)`], qabel ma jirritorna [`None`].
    ///
    /// Dan il-metodu għandu implimentazzjoni awtomatika, allura normalment m'għandekx timplimentah direttament.
    /// Madankollu, jekk tista 'tipprovdi implimentazzjoni aktar effiċjenti, tista' tagħmel hekk.
    /// Ara d-dokumenti [trait-level] għal eżempju.
    ///
    /// Din il-funzjoni għandha l-istess garanziji ta 'sigurtà bħall-funzjoni [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // firxa finita taf eżattament kemm-il darba se ttenni
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Din l-affermazzjoni hija difensiva żżejjed, iżda tiċċekkja l-invariant
        // iggarantit miż-trait.
        // Jekk dan iż-trait kien rust-intern, nistgħu nużaw debug_assert !;assert_eq!se jiċċekkja l-implimentazzjonijiet kollha tal-utent Rust ukoll.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Jirritorna `true` jekk l-iteratur ikun vojt.
    ///
    /// Dan il-metodu għandu implimentazzjoni awtomatika bl-użu ta [`ExactSizeIterator::len()`], allura m'għandekx bżonn timplimentah innifsek.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}