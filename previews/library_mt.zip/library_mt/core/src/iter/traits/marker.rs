/// Iteratur li dejjem ikompli jagħti `None` meta jkun eżawrit.
///
/// Li ssejjaħ li jmiss fuq iteratur imdewweb li rritorna `None` darba huwa garantit li jirritorna [`None`] mill-ġdid.
/// Dan trait għandu jiġi implimentat mill-iteraturi kollha li jġibu ruħhom b'dan il-mod minħabba li jippermetti l-ottimizzazzjoni ta [`Iterator::fuse()`].
///
///
/// Note: Ġeneralment, m'għandekx tuża `FusedIterator` f'limiti ġeneriċi jekk għandek bżonn iteratur imdewweb.
/// Minflok, għandek sempliċement ċempel lil [`Iterator::fuse()`] fuq l-iteratur.
/// Jekk l-iteratur ikun diġà mdewweb, it-tgeżwir addizzjonali [`Fuse`] ikun bla opra mingħajr penali ta 'prestazzjoni.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iteratur li jirrapporta tul preċiż bl-użu ta 'size_hint.
///
/// L-iteratur jirrapporta ħjiel ta 'daqs fejn huwa eżatt (il-limitu t'isfel huwa ugwali għal dak ta' fuq), jew il-limitu ta 'fuq huwa [`None`].
///
/// Il-limitu ta 'fuq għandu jkun [`None`] biss jekk it-tul attwali tal-iteratur huwa akbar minn [`usize::MAX`].
/// F'dak il-każ, il-limitu t'isfel għandu jkun [`usize::MAX`], li jirriżulta f [`Iterator::size_hint()`] ta `(usize::MAX, None)`.
///
/// L-iteratur għandu jipproduċi eżattament in-numru ta 'elementi li rrapporta jew jiddevja qabel ma jasal fit-tmiem.
///
/// # Safety
///
/// Dan trait għandu jiġi implimentat biss meta l-kuntratt jiġi milqugħ.
/// Il-konsumaturi ta 'dan trait għandhom jispezzjonaw il-limitu ta' fuq ta [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iteratur li meta jagħti oġġett ikun ħa mill-inqas element wieħed mix-[`SourceIter`] sottostanti tiegħu.
///
/// Li ssejjaħ kwalunkwe metodu li javvanza l-iteratur, eż
/// [`next()`] jew [`try_fold()`], jiggarantixxi li għal kull pass mill-inqas valur wieħed tas-sors sottostanti tal-iteratur ġie mċaqlaq u r-riżultat tal-katina tal-iteratur jista 'jiddaħħal minflok, jekk wieħed jassumi li l-limitazzjonijiet strutturali tas-sors jippermettu inserzjoni bħal din.
///
/// Fi kliem ieħor dan trait jindika li pipeline iteratur jista 'jinġabar f'postu.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}