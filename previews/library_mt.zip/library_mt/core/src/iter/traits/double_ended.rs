use crate::ops::{ControlFlow, Try};

/// Iteratur kapaċi jagħti elementi miż-żewġt itruf.
///
/// Xi ħaġa li timplimenta `DoubleEndedIterator` għandha kapaċità waħda żejda fuq xi ħaġa li timplimenta [`Iterator`]: il-ħila li tieħu wkoll 'Oġġett` minn wara, kif ukoll minn quddiem.
///
///
/// Huwa importanti li wieħed jinnota li kemm 'il quddiem kif ukoll lura jaħdmu fuq l-istess firxa, u ma jaqsmux: iterazzjoni tispiċċa meta jiltaqgħu fin-nofs.
///
/// Bl-istess mod għall-protokoll [`Iterator`], ladarba `DoubleEndedIterator` jirritorna [`None`] minn [`next_back()`], issejjaħlu mill-ġdid jista 'jew ma jistax jerġa' jirritorna [`Some`].
/// [`next()`] u [`next_back()`] huma interkambjabbli għal dan il-għan.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Tneħħi u tirritorna element mit-tmiem tal-iteratur.
    ///
    /// Jirritorna `None` meta ma jkunx hemm aktar elementi.
    ///
    /// Id-dokumenti [trait-level] fihom aktar dettalji.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// L-elementi mogħtija mill-metodi ta '"DoubleEndedIterator" jistgħu jvarjaw minn dawk mogħtija mill-metodi ta' ["Iterator"]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Javvanza l-iteratur minn wara b'elementi `n`.
    ///
    /// `advance_back_by` hija l-verżjoni inversa ta [`advance_by`].Dan il-metodu se jaqbeż bil-ħerqa elementi `n` li jibda minn wara billi jċempel lil [`next_back`] sa `n` darbiet sakemm jiltaqa 'ma' [`None`].
    ///
    /// `advance_back_by(n)` jirritorna [`Ok(())`] jekk l-iteratur javvanza b'suċċess b'elementi `n`, jew [`Err(k)`] jekk jiltaqa 'ma' [`None`], fejn `k` huwa n-numru ta 'elementi li l-iteratur huwa avvanzat minnu qabel ma jispiċċa l-elementi (ie
    /// it-tul tal-iteratur).
    /// Innota li `k` huwa dejjem inqas minn `n`.
    ///
    /// Is-sejħa lil `advance_back_by(0)` ma tikkonsma l-ebda element u dejjem tirritorna [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` biss inqabeż
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Jirritorna l-element `n`th mit-tmiem tal-iteratur.
    ///
    /// Din hija essenzjalment il-verżjoni maqluba ta [`Iterator::nth()`].
    /// Għalkemm bħal ħafna mill-operazzjonijiet ta `indiċjar, l-għadd jibda minn żero, allura `nth_back(0)` jirritorna l-ewwel valur mit-tmiem, `nth_back(1)` it-tieni, eċċ.
    ///
    ///
    /// Innota li l-elementi kollha bejn it-tarf u l-element ritornat se jiġu kkunsmati, inkluż l-element ritornat.
    /// Dan ifisser ukoll li sejħa `nth_back(0)` bosta drabi fuq l-istess iteratur tirritorna elementi differenti.
    ///
    /// `nth_back()` jirritorna [`None`] jekk `n` huwa akbar jew daqs it-tul tal-iteratur.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Li ssejjaħ `nth_back()` bosta drabi ma tirrifjutax l-iteratur:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Irritorna `None` jekk hemm inqas minn elementi `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Din hija l-verżjoni inversa ta [`Iterator::try_fold()`]: tieħu elementi li jibdew minn wara ta' l-iteratur.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Minħabba li għamel short circuit, l-elementi li jifdal għadhom disponibbli permezz tal-iteratur.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metodu ta 'iteratur li jnaqqas l-elementi ta' l-iteratur għal valur finali wieħed, li jibda minn wara.
    ///
    /// Din hija l-verżjoni inversa ta [`Iterator::fold()`]: tieħu elementi li jibdew minn wara tal-iteratur.
    ///
    /// `rfold()` jieħu żewġ argumenti: valur inizjali, u għeluq b'żewġ argumenti: 'accumulator', u element.
    /// L-għeluq jirritorna l-valur li l-akkumulatur għandu jkollu għall-iterazzjoni li jmiss.
    ///
    /// Il-valur inizjali huwa l-valur li l-akkumulatur ikollu fl-ewwel sejħa.
    ///
    /// Wara li tapplika dan l-għeluq għal kull element tal-iteratur, `rfold()` jirritorna l-akkumulatur.
    ///
    /// Din l-operazzjoni kultant tissejjaħ 'reduce' jew 'inject'.
    ///
    /// It-tiwi huwa utli kull meta jkollok ġabra ta 'xi ħaġa, u trid tipproduċi valur wieħed minnha.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // is-somma tal-elementi kollha ta 'a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Dan l-eżempju jibni sekwenza, li tibda b'valur inizjali u tkompli b'kull element minn wara sa quddiem:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Tiftix għal element ta 'iteratur minn wara li jissodisfa predikat.
    ///
    /// `rfind()` jieħu għeluq li jirritorna `true` jew `false`.
    /// Japplika dan l-għeluq għal kull element tal-iteratur, li jibda fl-aħħar, u jekk xi wieħed minnhom jirritorna `true`, allura `rfind()` jirritorna [`Some(element)`].
    /// Jekk kollha jirritornaw `false`, jirritorna [`None`].
    ///
    /// `rfind()` qed iqassam;fi kliem ieħor, tieqaf mill-ipproċessar hekk kif l-għeluq jirritorna `true`.
    ///
    /// Minħabba li `rfind()` jieħu referenza, u ħafna iteraturi jtennu fuq referenzi, dan iwassal għal sitwazzjoni possibbilment konfuża fejn l-argument huwa referenza doppja.
    ///
    /// Tista 'tara dan l-effett fl-eżempji hawn taħt, b `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Waqfien fl-ewwel `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // xorta nistgħu nużaw `iter`, peress li hemm aktar elementi.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}