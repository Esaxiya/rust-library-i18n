/// Konverżjoni minn [`Iterator`].
///
/// Billi timplimenta `FromIterator` għal tip, tiddefinixxi kif se jinħoloq minn iteratur.
/// Dan huwa komuni għal tipi li jiddeskrivu kollezzjoni ta 'xi tip.
///
/// [`FromIterator::from_iter()`] rarament jissejjaħ b'mod espliċitu, u minflok jintuża permezz tal-metodu [`Iterator::collect()`].
///
/// Ara d-dokumentazzjoni [`Iterator::collect()`]'s għal aktar eżempji.
///
/// Ara ukoll: [`IntoIterator`].
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Uża [`Iterator::collect()`] biex tuża impliċitament `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implimentazzjoni ta `FromIterator` għat-tip tiegħek:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Ġabra ta 'kampjuni, li hija biss tgeżwir fuq Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ejja nagħtuh xi metodi sabiex inkunu nistgħu noħolqu wieħed u nżidu affarijiet miegħu.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // u aħna ser nimplimentaw FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Issa nistgħu nagħmlu iteratur ġdid ...
/// let iter = (0..5).into_iter();
///
/// // ... u agħmel MyCollection minnha
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // iġbor xogħlijiet ukoll!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Joħloq valur minn iteratur.
    ///
    /// Ara x-[module-level documentation] għal aktar.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konverżjoni f [`Iterator`].
///
/// Billi timplimenta `IntoIterator` għal tip, tiddefinixxi kif se tiġi kkonvertita għal iteratur.
/// Dan huwa komuni għal tipi li jiddeskrivu kollezzjoni ta 'xi tip.
///
/// Benefiċċju wieħed li timplimenta `IntoIterator` huwa li t-tip tiegħek ser [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Ara ukoll: [`FromIterator`].
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implimentazzjoni ta `IntoIterator` għat-tip tiegħek:
///
/// ```
/// // Ġabra ta 'kampjuni, li hija biss tgeżwir fuq Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ejja nagħtuh xi metodi sabiex inkunu nistgħu noħolqu wieħed u nżidu affarijiet miegħu.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // u aħna ser nimplimentaw IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Issa nistgħu nagħmlu ġabra ġdida ...
/// let mut c = MyCollection::new();
///
/// // ... żid ftit affarijiet magħha ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... u mbagħad ibdlu f'Iteratur:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Huwa komuni li tuża `IntoIterator` bħala trait bound.Dan jippermetti li t-tip ta 'ġbir ta' input jinbidel, sakemm ikun għadu iteratur.
/// Limiti addizzjonali jistgħu jiġu speċifikati billi tirrestrinġi fuq
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// It-tip tal-elementi li qed jiġu iterati fuq.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// F'liema tip ta 'iteratur qed nibdlu dan?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Joħloq iteratur minn valur.
    ///
    /// Ara x-[module-level documentation] għal aktar.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Estendi kollezzjoni bil-kontenut ta 'iteratur.
///
/// L-iteraturi jipproduċu serje ta 'valuri, u l-kollezzjonijiet jistgħu wkoll jitqiesu bħala serje ta' valuri.
/// Ix-`Extend` trait jimla dan id-distakk, u jippermettilek testendi kollezzjoni billi tinkludi l-kontenut ta 'dak l-iteratur.
/// Meta testendi kollezzjoni b'ċavetta diġà eżistenti, dik l-entrata tiġi aġġornata jew, fil-każ ta 'kollezzjonijiet li jippermettu entrati multipli b'ċwievet ugwali, dik l-entrata tiddaħħal.
///
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// // Tista 'testendi String b'xi karattri:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implimentazzjoni ta `Extend`:
///
/// ```
/// // Ġabra ta 'kampjuni, li hija biss tgeżwir fuq Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ejja nagħtuh xi metodi sabiex inkunu nistgħu noħolqu wieħed u nżidu affarijiet miegħu.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // peress li MyCollection għandha lista ta 'i32s, aħna nimplimentaw Estendi għal i32
/// impl Extend<i32> for MyCollection {
///
///     // Dan huwa kemmxejn aktar sempliċi bil-firma tat-tip konkret: nistgħu nsejħu estensjoni fuq kull ħaġa li tista 'tinbidel f'Iteratur li jagħtina i32s.
///     // Minħabba li għandna bżonn i32s biex nidħlu fil-MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // L-implimentazzjoni hija sempliċi ħafna: aqleb l-iteratur, u add() kull element lilna nfusna.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ejja nestendu l-ġabra tagħna bi tliet numri oħra
/// c.extend(vec![1, 2, 3]);
///
/// // żidna dawn l-elementi fit-tarf
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Jestendi kollezzjoni bil-kontenut ta 'iteratur.
    ///
    /// Peress li dan huwa l-uniku metodu meħtieġ għal dan trait, id-dokumenti [trait-level] fihom aktar dettalji.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // Tista 'testendi String b'xi karattri:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Jestendi ġabra b'eżattament element wieħed.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Jirriżerva kapaċità f'ġabra għan-numru mogħti ta 'elementi addizzjonali.
    ///
    /// L-implimentazzjoni awtomatika ma tagħmel xejn.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}