//! Modulu biex taħdem ma 'dejta mislufa.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait għad-dejta tas-self.
///
/// F`Rust, huwa komuni li jiġu pprovduti rappreżentazzjonijiet differenti ta`tip għal każijiet ta` użu differenti.
/// Pereżempju, il-post tal-ħażna u l-immaniġġjar għal valur jistgħu jintgħażlu speċifikament kif xieraq għal użu partikolari permezz ta 'tipi ta' pointer bħal [`Box<T>`] jew [`Rc<T>`].
/// Lil hinn minn dawn it-tgeżwir ġeneriċi li jistgħu jintużaw ma 'kwalunkwe tip, xi tipi jipprovdu aspetti fakultattivi li jipprovdu funzjonalità potenzjalment għalja.
/// Eżempju għal tali tip huwa [`String`] li jżid il-ħila li testendi sekwenza għax-[`str`] bażiku.
/// Dan jirrikjedi li tinżamm informazzjoni addizzjonali bla bżonn għal sekwenza sempliċi u immutabbli.
///
/// Dawn it-tipi jipprovdu aċċess għad-dejta sottostanti permezz ta 'referenzi għat-tip ta' dik id-dejta.Jingħad li huma 'mislufa bħala' dak it-tip.
/// Pereżempju, [`Box<T>`] jista 'jiġi misluf bħala `T` filwaqt li [`String`] jista' jiġi misluf bħala `str`.
///
/// It-tipi jesprimu li jistgħu jiġu mislufa bħala xi tip `T` billi jimplimentaw `Borrow<T>`, billi jipprovdu referenza għal `T` fil-metodu [`borrow`] taż-trait.Tip huwa liberu li jissellef bħala diversi tipi differenti.
/// Jekk jixtieq jissellef b'mod reċiproku bħala t-tip-li jippermetti li d-dejta sottostanti tiġi modifikata, jista 'wkoll jimplimenta [`BorrowMut<T>`].
///
/// Barra minn hekk, meta jiġu pprovduti implimentazzjonijiet għal traits addizzjonali, jeħtieġ li jiġi kkunsidrat jekk għandhomx iġibu ruħhom identiċi għal dawk tat-tip sottostanti bħala konsegwenza li jaġixxu bħala rappreżentazzjoni ta 'dak it-tip sottostanti.
/// Kodiċi ġeneriku tipikament juża `Borrow<T>` meta jiddependi fuq l-imġieba identika ta 'dawn l-implimentazzjonijiet addizzjonali ta' trait.
/// Dawn traits x'aktarx jidhru bħala trait bounds addizzjonali.
///
/// B'mod partikolari `Eq`, `Ord` u `Hash` għandhom ikunu ekwivalenti għall-valuri mislufa u tal-proprjetà: `x.borrow() == y.borrow()` għandu jagħti l-istess riżultat bħal `x == y`.
///
/// Jekk il-kodiċi ġeneriku sempliċement jeħtieġ jaħdem għat-tipi kollha li jistgħu jipprovdu referenza għal tip relatat `T`, ħafna drabi jkun aħjar li tuża [`AsRef<T>`] peress li aktar tipi jistgħu jimplimentawh b'mod sikur.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Bħala ġabra ta 'dejta, [`HashMap<K, V>`] għandu kemm ċwievet kif ukoll valuri.Jekk id-dejta attwali taċ-ċavetta hija mgeżwra f'tip ta 'ġestjoni ta' xi tip, għandu, madankollu, xorta jkun possibbli li tfittex valur billi tuża referenza għad-dejta taċ-ċavetta.
/// Pereżempju, jekk iċ-ċavetta hija sekwenza, allura x'aktarx tinħażen mal-mappa tal-hash bħala [`String`], filwaqt li għandu jkun possibbli li tfittex bl-użu ta [`&str`][`str`].
/// Għalhekk, `insert` jeħtieġ li jopera fuq `String` filwaqt li `get` jeħtieġ li jkun kapaċi juża `&str`.
///
/// Ftit simplifikata, il-partijiet rilevanti ta `HashMap<K, V>` jidhru hekk:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // oqsma barra
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Il-mappa tal-hash kollha hija ġenerika fuq tip ewlieni `K`.Minħabba li dawn iċ-ċwievet huma maħżuna mal-mappa tal-hash, dan it-tip għandu jkollu d-dejta taċ-ċavetta.
/// Meta ddaħħal par ċavetta-valur, il-mappa tingħata tali `K` u teħtieġ issib il-barmil tal-hash korrett u tivverifika jekk iċ-ċavetta hijiex diġà preżenti abbażi ta 'dak `K`.Għalhekk teħtieġ `K: Hash + Eq`.
///
/// Meta tkun qed tfittex valur fil-mappa, madankollu, li jkollok tipprovdi referenza għal `K` bħala ċ-ċavetta biex tfittex tkun teħtieġ li dejjem toħloq tali valur ta 'proprjetà.
/// Għal string keys, dan ikun ifisser li jinħoloq valur `String` biss għat-tfittxija għal każijiet fejn `str` biss huwa disponibbli.
///
/// Minflok, il-metodu `get` huwa ġeneriku fuq it-tip tad-dejta ewlenija sottostanti, imsejjaħ `Q` fil-firma tal-metodu hawn fuq.Jiddikjara li `K` jissellef bħala `Q` billi jirrikjedi dak ix-`K: Borrow<Q>`.
/// Billi jeħtieġ ukoll `Q: Hash + Eq`, jindika r-rekwiżit li `K` u `Q` għandhom implimentazzjonijiet tax-`Hash` u `Eq` traits li jipproduċu riżultati identiċi.
///
/// L-implimentazzjoni ta `get` tiddependi b'mod partikolari fuq implimentazzjonijiet identiċi ta' `Hash` billi tiddetermina l-barmil tal-hash taċ-ċavetta billi ċċempel lil `Hash::hash` fuq il-valur `Q` anke jekk daħħal iċ-ċavetta bbażata fuq il-valur tal-hash ikkalkulat mill-valur `K`.
///
///
/// Bħala konsegwenza, il-mappa tal-hash tinkiser jekk `K` li jdawwar valur `Q` jipproduċi hash differenti minn `Q`.Pereżempju, immaġina li għandek tip li jdawwar sekwenza imma jqabbel ittri ASCII li jinjoraw il-każ tagħhom:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Minħabba li żewġ valuri ugwali għandhom bżonn jipproduċu l-istess valur hash, l-implimentazzjoni ta `Hash` teħtieġ li tinjora l-każ ASCII ukoll:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// `CaseInsensitiveString` jista 'jimplimenta `Borrow<str>`?Ċertament jista 'jipprovdi referenza għal porzjon ta' sekwenza permezz tas-sekwenza li tinsab fih.
/// Iżda minħabba li l-implimentazzjoni `Hash` tagħha hija differenti, hija ġġib ruħha b'mod differenti minn `str` u għalhekk m'għandhiex, fil-fatt, timplimenta `Borrow<str>`.
/// Jekk trid tħalli lil ħaddieħor aċċess għax-`str` sottostanti, tista 'tagħmel dan permezz ta' `AsRef<str>` li m'għandux ħtiġijiet żejda.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Jissellef b'mod immutabbli minn valur ta 'proprjetà.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait għal dejta li tissellef b'mod reċiproku.
///
/// Bħala anëillari għal [`Borrow<T>`] dan trait jippermetti tip li jissellef bħala tip sottostanti billi jipprovdi referenza li tista 'tinbidel.
/// Ara [`Borrow<T>`] għal aktar informazzjoni dwar self bħala tip ieħor.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Jissellef b'mod reċiproku minn valur ta 'proprjetà.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}