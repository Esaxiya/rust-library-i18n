//! Validazzjoni u dekompożizzjoni ta 'sekwenza deċimali tal-forma:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Fi kliem ieħor, sintassi standard b'punt li jvarja, b'żewġ eċċezzjonijiet: L-ebda sinjal, u l-ebda trattament ta "inf" u "NaN".Dawn huma mmaniġġjati mill-funzjoni tas-sewwieq (super::dec2flt).
//!
//! Għalkemm ir-rikonoxximent ta 'inputs validi huwa relattivament faċli, dan il-modulu għandu wkoll jirrifjuta l-għadd ta' varjazzjonijiet invalidi, qatt panic, u jwettaq bosta verifiki li l-moduli l-oħra jiddependu fuqhom mhux panic (jew overflow) min-naħa tagħhom.
//!
//! Biex tgħaxxaq, dak kollu li jiġri f'pass wieħed fuq l-input.
//! Allura, oqgħod attent meta timmodifika xi ħaġa, u ċċekkja darbtejn mal-moduli l-oħra.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Il-partijiet interessanti ta 'sekwenza deċimali.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// L-esponent deċimali, garantit li jkollu inqas minn 18-il ċifra deċimali.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Iċċekkja jekk is-sekwenza tal-input hijiex numru validu ta 'punt varjabbli u jekk iva, sib il-parti integrali, il-parti frazzjonali, u l-esponent fiha.
/// Ma jimmaniġġax sinjali.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // L-ebda ċifra qabel 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Aħna neħtieġu mill-inqas ċifra waħda qabel jew wara l-punt.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Junk wara l-parti frazzjonali
            }
        }
        _ => Invalid, // Junk sekondarju wara l-ewwel sekwenza taċ-ċifra
    }
}

/// Tnaqqas ċifri deċimali sa l-ewwel karattru mhux ta 'ċifri.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Estrazzjoni tal-esponenti u kontroll tal-iżbalji.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Junk wara l-esponent
    }
    if number.is_empty() {
        return Invalid; // Esponent vojt
    }
    // F'dan il-punt, ċertament għandna sensiela valida ta 'ċifri.Jista 'jkun twil wisq biex tiddaħħal f `i64`, imma jekk huwa daqshekk enormi, l-input huwa ċertament żero jew infinit.
    // Peress li kull żero fiċ-ċifri deċimali jaġġusta biss l-esponent bi +/-1, f'exp=10 ^ 18 l-input ikollu jkun ta '17 exabyte (!) ta' żeri biex ikun saħansitra mill-bogħod viċin li jkun finit.
    //
    // Dan mhuwiex eżattament każ ta 'użu li għandna bżonn nindirizzaw.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}