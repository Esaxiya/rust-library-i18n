//! Bit fiddling fuq floats pożittivi IEEE 754.Numri negattivi mhumiex u m'għandhomx għalfejn jiġu mmaniġġjati.
//! Numri normali b'punt li jvarja għandhom rappreżentazzjoni kanonika bħala (frac, exp) tali li l-valur huwa 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) fejn N huwa n-numru ta 'bits.
//!
//! Subnormali huma kemmxejn differenti u strambi, iżda japplika l-istess prinċipju.
//!
//! Hawnhekk, madankollu, nirrappreżentawhom bħala (sig, k) b'f pożittiv, b'tali mod li l-valur huwa f *
//! 2 <sup>e</sup> .Minbarra li tagħmel ix-"hidden bit" espliċitu, dan ibiddel l-esponent bl-hekk imsejħa mantissa shift.
//!
//! Fi kliem ieħor, normalment il-floats huma miktuba bħala (1) imma hawn huma miktuba bħala (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Aħna nsejħu (1) ir-**rappreżentazzjoni frazzjonali** u (2) ir-**rappreżentazzjoni integrali**.
//!
//! Ħafna funzjonijiet f'dan il-modulu jimmaniġġjaw biss numri normali.Ir-rutini dec2flt b'mod konservattiv jieħdu l-passaġġ bil-mod universalment korrett (Algoritmu M) għal numri żgħar ħafna u kbar ħafna.
//! Dak l-algoritmu jeħtieġ biss next_float() li jimmaniġġa subnormali u żerijiet.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// A helper trait biex tevita li tirdoppja bażikament il-kodiċi tal-konverżjoni kollha għal `f32` u `f64`.
///
/// Ara l-kumment tad-dok tal-modulu ġenitur għalfejn dan huwa meħtieġ.
///
/// **Għandhom** qatt ** jiġu implimentati għal tipi oħra jew jintużaw barra mill-modulu dec2flt.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tip użat minn `to_bits` u `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Twettaq trasmutazzjoni prima għal numru sħiħ.
    fn to_bits(self) -> Self::Bits;

    /// Twettaq trasmutazzjoni prima minn numru sħiħ.
    fn from_bits(v: Self::Bits) -> Self;

    /// Jirritorna l-kategorija li fiha jaqa 'dan in-numru.
    fn classify(self) -> FpCategory;

    /// Jirritorna l-mantissa, l-esponent u s-sinjal bħala numri sħaħ.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Jiddekowdja l-float.
    fn unpack(self) -> Unpacked;

    /// Titfa 'minn numru sħiħ żgħir li jista' jkun rappreżentat eżattament.
    /// Panic jekk in-numru sħiħ ma jistax jiġi rrappreżentat, il-kodiċi l-ieħor f'dan il-modulu jiżgura li qatt ma jħalli dan iseħħ.
    fn from_int(x: u64) -> Self;

    /// Jikseb il-valur 10 <sup>e</sup> minn tabella kkomputata minn qabel.
    /// Panics għal `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Dak li jgħid l-isem.
    /// Huwa iktar faċli għall-kodiċi iebes mill-intrinsiċi tal-juggling u bit-tama li l-kostanti LLVM jingħalaq.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Marka konservattiva fuq iċ-ċifri deċimali tal-inputs li ma jistgħux jipproduċu overflow jew zero jew
    /// subnormali.Probabbilment l-esponent deċimali tal-valur normali massimu, għalhekk l-isem.
    const MAX_NORMAL_DIGITS: usize;

    /// Meta l-aktar ċifra deċimali sinifikanti għandha valur tal-post akbar minn dan, in-numru huwa ċertament arrotondat għall-infinità.
    ///
    const INF_CUTOFF: i64;

    /// Meta l-aktar ċifra deċimali sinifikanti għandha valur tal-post inqas minn dan, in-numru huwa ċertament arrotondat għal żero.
    ///
    const ZERO_CUTOFF: i64;

    /// In-numru ta 'bits fl-esponent.
    const EXP_BITS: u8;

    /// In-numru ta 'bits fis-sinjifikat,*inkluż* il-bit moħbi.
    const SIG_BITS: u8;

    /// In-numru ta 'bits fis-sinjifikat,*eskluż* il-bit moħbi.
    const EXPLICIT_SIG_BITS: u8;

    /// L-esponent legali massimu fir-rappreżentazzjoni frazzjonali.
    const MAX_EXP: i16;

    /// L-esponent legali minimu fir-rappreżentazzjoni frazzjonali, minbarra s-subnormali.
    const MIN_EXP: i16;

    /// `MAX_EXP` għar-rappreżentazzjoni integrali, jiġifieri, bix-shift applikat.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` ikkodifikat (jiġifieri, bi preġudizzju offset)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` għar-rappreżentazzjoni integrali, jiġifieri, bix-shift applikat.
    const MIN_EXP_INT: i16;

    /// Is-sinifikat massimu normalizzat fir-rappreżentazzjoni integrali.
    const MAX_SIG: u64;

    /// Is-sinifikat normalizzat minimu fir-rappreżentazzjoni integrali.
    const MIN_SIG: u64;
}

// L-aktar soluzzjoni għal #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Jirritorna l-mantissa, l-esponent u s-sinjal bħala numri sħaħ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Bejjis tal-esponent + shift tal-mantissa
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe mhuwiex ċert jekk `as` iddurx sewwa fuq il-pjattaformi kollha.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Jirritorna l-mantissa, l-esponent u s-sinjal bħala numri sħaħ.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Bejjis tal-esponent + shift tal-mantissa
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe mhuwiex ċert jekk `as` iddurx sewwa fuq il-pjattaformi kollha.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Ikkonverti `Fp` għall-eqreb tip ta 'float tal-magna.
/// Ma jimmaniġġjax ir-riżultati subnormali.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f huwa 64 bit, allura xe għandu shift ta '63 mantissa
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Iddawwar is-sinifikat ta '64 bit għal T::SIG_BITS bits b'nofs sa l-istess.
/// Ma jimmaniġġjax l-eċċess ta 'esponent.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Aġġusta l-bidla tal-mantissa
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Invers ta `RawFloat::unpack()` għal numri normalizzati.
/// Panics jekk is-sinjifikat jew l-esponent mhumiex validi għal numri normalizzati.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Neħħi l-bit moħbi
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Aġġusta l-esponent għall-preġudizzju tal-esponent u l-bidla tal-mantissa
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Ħalli bit-sinjal f'0 ("+"), in-numri tagħna huma kollha pożittivi
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Ibni subnormali.Mantissa ta '0 hija permessa u tibni żero.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // L-esponent kodifikat huwa 0, il-bit tas-sinjal huwa 0, allura rridu biss ninterpretaw mill-ġdid il-bits.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Approssima bignum b'Fp.Rawnds fi ħdan 0.5 ULP b'nofs sa l-istess.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Aħna naqtgħu l-bits kollha qabel l-indiċi `start`, jiġifieri, effettivament niċċaqilqu lejn il-lemin b'ammont ta `start`, allura dan huwa wkoll l-esponent li għandna bżonn.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) skont il-bits maqtugħin.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Isib l-akbar numru ta 'punt li jvarja strettament iżgħar mill-argument.
/// Ma jimmaniġġax subnormali, żero, jew esponent underflow.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Sib l-iżgħar numru ta 'punt li jvarja strettament akbar mill-argument.
// Din l-operazzjoni hija saturata, jiġifieri, next_float(inf) ==inf.
// B'differenza mill-biċċa l-kbira tal-kodiċi f'dan il-modulu, din il-funzjoni timmaniġġa żero, subnormali u infiniti.
// Madankollu, bħall-kodiċi l-ieħor kollu hawn, ma jittrattax in-NaN u n-numri negattivi.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dan jidher wisq tajjeb biex ikun minnu, imma jaħdem.
        // 0.0 hija kkodifikata bħala l-kelma kollha żero.Subnormali huma 0x000m ... m fejn m hija l-mantissa.
        // B'mod partikolari, l-iżgħar subnormali hija 0x0 ... 01 u l-akbar hija 0x000F ... F.
        // L-iżgħar numru normali huwa 0x0010 ... 0, allura dan il-każ tal-kantuniera jaħdem ukoll.
        // Jekk l-inkrement ifur fuq il-mantissa, il-bit tal-ġarr iżid l-esponent kif irridu, u l-bits tal-mantissa jsiru żero.
        // Minħabba l-konvenzjoni bit moħbija, dan ukoll huwa eżattament dak li rridu!
        // Finalment, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}