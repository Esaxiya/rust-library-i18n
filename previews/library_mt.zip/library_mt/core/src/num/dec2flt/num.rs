//! Funzjonijiet ta 'utilità għal bignums li ma jagħmlux wisq sens biex jinbidlu f'metodi.

// FIXME L-isem ta 'dan il-modulu huwa kemmxejn sfortunat, peress li moduli oħra jimportaw ukoll `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Ittestja jekk it-tqattigħ tal-bits kollha inqas sinifikanti minn `ones_place` jintroduċix żball relattiv inqas, ugwali, jew akbar minn 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Jekk il-bits kollha li jifdal huma żero, huwa= 0.5 ULP, inkella> 0.5 Jekk m'hemmx aktar bits (half_bit==0), is-segwenti jirritorna wkoll Indaqs.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Ikkonverti sekwenza ASCII li jkun fiha biss ċifri deċimali għal `u64`.
///
/// Ma jwettaqx kontrolli għal overflow jew karattri invalidi, allura jekk min iċempel ma joqgħodx attent, ir-riżultat huwa falz u jista 'panic (għalkemm mhux se jkun `unsafe`).
/// Barra minn hekk, kordi vojta huma ttrattati bħala żero.
/// Din il-funzjoni teżisti għax
///
/// 1. l-użu ta `FromStr` fuq `&[u8]` jeħtieġ `from_utf8_unchecked`, li huwa ħażin, u
/// 2. li tgħaqqad flimkien ir-riżultati ta `integral.parse()` u `fractional.parse()` huwa iktar ikkumplikat minn din il-funzjoni sħiħa.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Ikkonverti sensiela ta 'ċifri ASCII f'bignum.
///
/// Bħal `from_str_unchecked`, din il-funzjoni tiddependi fuq il-parser biex tneħħi mhux ċifri.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Ikxef bignum f'numru sħiħ ta '64 bit.Panics jekk in-numru huwa kbir wisq.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Estratti firxa ta 'bits.

/// L-Indiċi 0 huwa l-inqas bit sinifikanti u l-firxa hija nofsha miftuħa bħas-soltu.
/// Panics jekk mitlub joħroġ aktar bits milli jidħlu fit-tip ta 'ritorn.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}