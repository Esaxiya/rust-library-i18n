//! Ikkonverti kordi deċimali f'numri ta 'virgola varjabbli IEEE 754.
//!
//! # Dikjarazzjoni tal-problema
//!
//! Aħna jingħataw sekwenza deċimali bħal `12.34e56`.
//! Din is-sekwenza tikkonsisti f (`12`) integrali, frazzjonali (`34`), u partijiet esponenti (`56`).Il-partijiet kollha mhumiex obbligatorji u interpretati bħala żero meta jkunu nieqsa.
//!
//! Infittxu n-numru tal-punt varjabbli IEEE 754 li huwa l-eqreb għall-valur eżatt tas-sekwenza deċimali.
//! Huwa magħruf li ħafna kordi deċimali m'għandhomx rappreżentazzjonijiet li jispiċċaw fit-tieni bażi, allura aħna ndawru għal unitajiet 0.5 fl-aħħar post (fi kliem ieħor, kif ukoll possibbli).
//! Rabtiet, valuri deċimali eżattament fin-nofs bejn żewġ floats konsekuttivi, jiġu riżolti bl-istrateġija nofs l-istess, magħrufa wkoll bħala l-arrotondament tal-bank.
//!
//! M`għandniex xi ngħidu, dan huwa pjuttost diffiċli, kemm f`termini ta `kumplessità ta` implimentazzjoni kif ukoll f`termini ta`ċikli ta` CPU meħuda.
//!
//! # Implementation
//!
//! L-ewwel, ninjoraw is-sinjali.Jew aħjar, inneħħuh fil-bidu nett tal-proċess ta 'konverżjoni u napplikawh mill-ġdid fl-aħħar nett.
//! Dan huwa korrett fil-każijiet kollha ta 'edge peress li l-floats IEEE huma simetriċi madwar żero, billi jiċħad wieħed sempliċement jaqleb l-ewwel bit.
//!
//! Imbagħad inneħħu l-punt deċimali billi naġġustaw l-esponent: Kunċettwalment, `12.34e56` jinbidel f `1234e54`, li niddeskrivu b'numru sħiħ pożittiv `f = 1234` u numru sħiħ `e = 54`.
//! Ir-rappreżentazzjoni `(f, e)` tintuża minn kważi l-kodiċi kollha li għaddew mill-istadju tal-parsing.
//!
//! Aħna mbagħad nippruvaw katina twila ta 'każijiet speċjali progressivament aktar ġenerali u għaljin bl-użu ta' numri interi ta 'daqs tal-magna u numri żgħar, ta' daqs fiss b'punt li jvarja (l-ewwel `f32`/`f64`, imbagħad tip b'sinifikat 64 bit, `Fp`).
//!
//! Meta dawn kollha jfallu, aħna ngiddmu l-bulit u nirrikorru għal algoritmu sempliċi imma bil-mod ħafna li kien jinvolvi l-informatika `f * 10^e` kompletament u nagħmlu tfittxija iterattiva għall-aħjar approssimazzjoni.
//!
//! Primarjament, dan il-modulu u t-tfal tiegħu jimplimentaw l-algoritmi deskritti fi:
//! "How to Read Floating Point Numbers Accurately" minn William D.
//! Clinger, disponibbli online: <http://citeseerx.ist.psu.edu/viewdoc/summary?doi=10.1.1.45.4152>
//!
//! Barra minn hekk, hemm bosta funzjonijiet helper li jintużaw fil-karta iżda mhux disponibbli f'Rust (jew għall-inqas fil-qalba).
//! Il-verżjoni tagħna hija kkumplikata addizzjonalment bil-ħtieġa li timmaniġġa l-overflow u underflow u x-xewqa li nimmaniġġjaw numri subnormali.
//! Bellerophon u Algorithm R għandhom problemi bil-overflow, subnormali, u underflow.
//! Nibdlu b'mod konservattiv għall-Algoritmu M (bil-modifiki deskritti fit-taqsima 8 tal-karta) sew qabel ma l-inputs jidħlu fir-reġjun kritiku.
//!
//! Aspett ieħor li jeħtieġ attenzjoni huwa r-"RawFloat" trait li permezz tiegħu kważi l-funzjonijiet kollha huma parametrizzati.Wieħed jista 'jaħseb li huwa biżżejjed li parse għal `f64` u titfa' r-riżultat għal `f32`.
//! Sfortunatament din mhijiex id-dinja li ngħixu fiha, u din m'għandha x'taqsam xejn mal-użu ta 'bażi ta' żewġ jew nofs l-indaqs.
//!
//! Ikkunsidra pereżempju żewġ tipi `d2` u `d4` li jirrappreżentaw tip deċimali b'żewġ ċifri deċimali u erba 'ċifri deċimali kull wieħed u ħu "0.01499" bħala input.Ejja nużaw l-arrotondament ta 'nofs.
//! Li mmorru direttament għal żewġ ċifri deċimali jagħti `0.01`, imma jekk l-ewwel inqarrbu għal erba 'ċifri, ikollna `0.0150`, li mbagħad jiġi arrotondat sa `0.02`.
//! L-istess prinċipju japplika għal operazzjonijiet oħra wkoll, jekk trid eżattezza 0.5 ULP trid tagħmel *kollox* bi preċiżjoni sħiħa u tond *eżattament darba, fl-aħħar*, billi tikkunsidra l-bits maqtugħin kollha f'daqqa.
//!
//! FIXME: Għalkemm xi duplikazzjoni tal-kodiċi hija meħtieġa, forsi partijiet mill-kodiċi jistgħu jitħalltu b'tali mod li inqas kodiċi jiġi duplikat.
//! Partijiet kbar tal-algoritmi huma indipendenti mit-tip float biex joħorġu, jew jeħtieġ biss aċċess għal ftit kostanti, li jistgħu jiġu mgħoddija bħala parametri.
//!
//! # Other
//!
//! Il-konverżjoni m'għandha *qatt* panic.
//! Hemm asserzjonijiet u panics espliċiti fil-kodiċi, iżda dawn m'għandhom qatt jiġu attivati u jservu biss bħala kontrolli interni ta 'sanità.Kwalunkwe panics għandu jitqies bħala bug.
//!
//! Hemm testijiet tal-unità iżda huma tassew inadegwati biex jiżguraw il-korrettezza, ikopru biss persentaġġ żgħir ta 'żbalji possibbli.
//! Testijiet ferm aktar estensivi jinsabu fid-direttorju `src/etc/test-float-parse` bħala skritt Python.
//!
//! Nota dwar overflow ta 'numru sħiħ: Bosta partijiet ta' dan il-fajl iwettqu aritmetika bl-esponent deċimali `e`.
//! Primarjament, nibdlu l-punt deċimali madwar: Qabel l-ewwel ċifra deċimali, wara l-aħħar ċifra deċimali, eċċ.Dan jista 'jinfirex jekk isir bi traskuraġni.
//! Aħna niddependu fuq is-submodulu tal-parsing biex inqassmu biss esponenti żgħar biżżejjed, fejn "sufficient" ifisser "such that the exponent +/- the number of decimal digits fits into a 64 bit integer".
//! Esponenti akbar huma aċċettati, imma aħna ma nagħmlux aritmetika magħhom, huma immedjatament mibdula f {positive,negative} {zero,infinity}.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![doc(hidden)]
#![unstable(
    feature = "dec2flt",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

use crate::fmt;
use crate::str::FromStr;

use self::num::digits_to_big;
use self::parse::{parse_decimal, Decimal, ParseResult, Sign};
use self::rawfp::RawFloat;

mod algorithm;
mod num;
mod table;
// Dawn it-tnejn għandhom it-testijiet tagħhom stess.
pub mod parse;
pub mod rawfp;

macro_rules! from_str_float_impl {
    ($t:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl FromStr for $t {
            type Err = ParseFloatError;

            /// Ikkonverti sekwenza fil-bażi 10 għal float.
            /// Jaċċetta esponent deċimali fakultattiv.
            ///
            /// Din il-funzjoni taċċetta kordi bħal
            ///
            /// * '3.14'
            /// * '-3.14'
            /// * '2.5E10', jew ekwivalenti, '2.5e10'
            /// * '2.5E-10'
            /// * '5.'
            /// * '.5', jew, ekwivalenti, '0.5'
            /// * 'inf', '-inf', 'NaN'
            ///
            /// L-ispazju fl-ispazju ta 'quddiem u ta' wara jirrappreżenta żball.
            ///
            /// # Grammar
            ///
            /// Is-sekwenzi kollha li jaderixxu mal-grammatika [EBNF] li ġejja se jirriżultaw fi [`Ok`] lura:
            ///
            ///
            /// ```txt
            /// Float  ::= Sign? ( 'inf' | 'NaN' | Number )
            /// Number ::= ( Digit+ |
            ///              Digit+ '.' Digit* |
            ///              Digit* '.' Digit+ ) Exp?
            /// Exp    ::= [eE] Sign? Digit+
            /// Sign   ::= [+-]
            /// Digit  ::= [0-9]
            /// ```
            ///
            /// [EBNF]: https://www.w3.org/TR/REC-xml/#sec-notation
            ///
            /// # Bugs magħrufa
            ///
            /// F'xi sitwazzjonijiet, xi kordi li għandhom joħolqu float validu minflok jirritornaw żball.
            /// Ara [issue #31407] għad-dettalji.
            ///
            /// [issue #31407]: https://github.com/rust-lang/rust/issues/31407
            ///
            /// # Arguments
            ///
            /// * src, A string
            ///
            /// # Valur tar-ritorn
            ///
            /// `Err(ParseFloatError)` jekk is-sekwenza ma tirrappreżentax numru validu.
            /// Inkella, `Ok(n)` fejn `n` huwa n-numru tal-punt varjabbli rrappreżentat minn `src`.
            ///
            #[inline]
            fn from_str(src: &str) -> Result<Self, ParseFloatError> {
                dec2flt(src)
            }
        }
    };
}
from_str_float_impl!(f32);
from_str_float_impl!(f64);

/// Żball li jista 'jiġi rritornat meta tiġi analizzata float.
///
/// Dan l-iżball jintuża bħala t-tip ta 'żball għall-implimentazzjoni [`FromStr`] għal [`f32`] u [`f64`].
///
///
/// # Example
///
/// ```
/// use std::str::FromStr;
///
/// if let Err(e) = f64::from_str("a.12") {
///     println!("Failed conversion to f64: {}", e);
/// }
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseFloatError {
    kind: FloatErrorKind,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum FloatErrorKind {
    Empty,
    Invalid,
}

impl ParseFloatError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            FloatErrorKind::Empty => "cannot parse float from empty string",
            FloatErrorKind::Invalid => "invalid float literal",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseFloatError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

fn pfe_empty() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Empty }
}

fn pfe_invalid() -> ParseFloatError {
    ParseFloatError { kind: FloatErrorKind::Invalid }
}

/// Aqsam sekwenza deċimali f'sinjal u l-bqija, mingħajr ma tispezzjona jew tivvalida l-bqija.
fn extract_sign(s: &str) -> (Sign, &str) {
    match s.as_bytes()[0] {
        b'+' => (Sign::Positive, &s[1..]),
        b'-' => (Sign::Negative, &s[1..]),
        // Jekk is-sekwenza mhix valida, aħna qatt ma nużaw is-sinjal, allura m'għandniex għalfejn nivvalidaw hawn.
        _ => (Sign::Positive, s),
    }
}

/// Ikkonverti sekwenza deċimali f'numru ta 'punt varjabbli.
fn dec2flt<T: RawFloat>(s: &str) -> Result<T, ParseFloatError> {
    if s.is_empty() {
        return Err(pfe_empty());
    }
    let (sign, s) = extract_sign(s);
    let flt = match parse_decimal(s) {
        ParseResult::Valid(decimal) => convert(decimal)?,
        ParseResult::ShortcutToInf => T::INFINITY,
        ParseResult::ShortcutToZero => T::ZERO,
        ParseResult::Invalid => match s {
            "inf" => T::INFINITY,
            "NaN" => T::NAN,
            _ => {
                return Err(pfe_invalid());
            }
        },
    };

    match sign {
        Sign::Positive => Ok(flt),
        Sign::Negative => Ok(-flt),
    }
}

/// Iż-żiemel tax-xogħol ewlieni għall-konverżjoni deċimali għal float: Orkestra l-ipproċessar kollu minn qabel u nifhem liema algoritmu għandu jagħmel il-konverżjoni attwali.
///
fn convert<T: RawFloat>(mut decimal: Decimal<'_>) -> Result<T, ParseFloatError> {
    simplify(&mut decimal);
    if let Some(x) = trivial_cases(&decimal) {
        return Ok(x);
    }
    // Remove/shift barra l-punt deċimali.
    let e = decimal.exp - decimal.fractional.len() as i64;
    if let Some(x) = algorithm::fast_path(decimal.integral, decimal.fractional, e) {
        return Ok(x);
    }
    // Big32x40 huwa limitat għal 1280 bits, li jissarraf għal madwar 385 ċifri deċimali.
    // Jekk naqbżu dan, inħallu, allura niżbaljaw qabel ma nersqu viċin wisq (fi żmien 10 ^ 10).
    let upper_bound = bound_intermediate_digits(&decimal, e);
    if upper_bound > 375 {
        return Err(pfe_invalid());
    }
    let f = digits_to_big(decimal.integral, decimal.fractional);

    // Issa l-esponent ċertament joqgħod f'16-il bit, li jintuża fl-algoritmi ewlenin.
    let e = e as i16;
    // FIXME Dawn il-limiti huma pjuttost konservattivi.
    // Analiżi aktar bir-reqqa tal-modi ta 'falliment ta' Bellerophon tista 'tippermetti l-użu tagħha f'aktar każijiet għal veloċità enormi.
    let exponent_in_range = table::MIN_E <= e && e <= table::MAX_E;
    let value_in_range = upper_bound <= T::MAX_NORMAL_DIGITS as u64;
    if exponent_in_range && value_in_range {
        Ok(algorithm::bellerophon(&f, e))
    } else {
        Ok(algorithm::algorithm_m(&f, e))
    }
}

// Kif miktub, dan jottimizza ħażin (ara #27130, għalkemm jirreferi għal verżjoni qadima tal-kodiċi).
// `inline(always)` hija soluzzjoni għal dan.
// Hemm biss żewġ siti ta 'sejħiet b'mod ġenerali u ma tagħmilx agħar id-daqs tal-kodiċi.

/// Qaxxar żerijiet fejn possibbli, anke meta dan jirrikjedi li tbiddel l-esponent
#[inline(always)]
fn simplify(decimal: &mut Decimal<'_>) {
    let is_zero = &|&&d: &&u8| -> bool { d == b'0' };
    // It-tirqim ta 'dawn iż-żerijiet ma jbiddel xejn imma jista' jippermetti t-triq mgħaġġla (<15-il ċifra).
    let leading_zeros = decimal.integral.iter().take_while(is_zero).count();
    decimal.integral = &decimal.integral[leading_zeros..];
    let trailing_zeros = decimal.fractional.iter().rev().take_while(is_zero).count();
    let end = decimal.fractional.len() - trailing_zeros;
    decimal.fractional = &decimal.fractional[..end];
    // Simplifika n-numri tal-forma 0.0 ... x u x ... 0.0, billi taġġusta l-esponent kif xieraq.
    // Din tista 'mhux dejjem tkun rebħa (possibbilment timbotta xi numri' l barra mit-triq mgħaġġla), iżda tissimplifika partijiet oħra b'mod sinifikanti (notevolment, approssimazzjoni tal-kobor tal-valur).
    //
    if decimal.integral.is_empty() {
        let leading_zeros = decimal.fractional.iter().take_while(is_zero).count();
        decimal.fractional = &decimal.fractional[leading_zeros..];
        decimal.exp -= leading_zeros as i64;
    } else if decimal.fractional.is_empty() {
        let trailing_zeros = decimal.integral.iter().rev().take_while(is_zero).count();
        let end = decimal.integral.len() - trailing_zeros;
        decimal.integral = &decimal.integral[..end];
        decimal.exp += trailing_zeros as i64;
    }
}

/// Jirritorna limitu ta 'fuq malajr-maħmuġ fuq id-daqs (log10) tal-akbar valur li l-Algoritmu R u l-Algoritmu M jikkalkulaw waqt li jaħdmu fuq id-deċimali mogħtija.
///
fn bound_intermediate_digits(decimal: &Decimal<'_>, e: i64) -> u64 {
    // M'għandniex għalfejn ninkwetaw iżżejjed dwar it-tifwir hawn grazzi għal trivial_cases() u l-parser, li jiffiltraw l-iktar inputs estremi għalina.
    //
    let f_len: u64 = decimal.integral.len() as u64 + decimal.fractional.len() as u64;
    if e >= 0 {
        // Fil-każ e>=0, iż-żewġ algoritmi jikkalkulaw madwar `f * 10^e`.
        // L-Algoritmu R jipproċedi biex jagħmel xi kalkoli kkumplikati ma 'dan imma nistgħu ninjoraw dak għall-limitu ta' fuq għax inaqqas ukoll il-frazzjoni minn qabel, allura għandna ħafna buffer hemmhekk.
        //
        f_len + (e as u64)
    } else {
        // Jekk e <0, l-Algoritmu R jagħmel bejn wieħed u ieħor l-istess ħaġa, iżda l-Algoritmu M ivarja:
        // Huwa jipprova jsib numru pożittiv k tali li `f << k / 10^e` huwa sinjifikat fil-medda.
        // Dan jirriżulta f'madwar `2^53 *f* 10^e` <`10^17 *f* 10^e`.
        // Wieħed mill-input li jqajjem dan huwa 0.33 ... 33 (375 x 3).
        f_len + e.unsigned_abs() + 17
    }
}

/// Tiskopri tifwir ovvju u tlugħ mingħajr ma tħares lejn iċ-ċifri deċimali.
fn trivial_cases<T: RawFloat>(decimal: &Decimal<'_>) -> Option<T> {
    // Kien hemm żerijiet iżda ġew imqaxxra minn simplify()
    if decimal.integral.is_empty() && decimal.fractional.is_empty() {
        return Some(T::ZERO);
    }
    // Din hija approssimazzjoni mhux raffinata ta ceil(log10(the real value)).
    // M`għandniex għalfejn ninkwetaw iżżejjed dwar it-tifwir hawnhekk għax it-tul tal-input huwa żgħir (għallinqas meta mqabbel ma`2 ^ 64) u l-parser diġà jimmaniġġja esponenti li l-valur assolut tagħhom huwa akbar minn 10 ^ 18 (li għadu qasir 10 ^ 19 ta '2 ^ 64).
    //
    //
    let max_place = decimal.exp + decimal.integral.len() as i64;
    if max_place > T::INF_CUTOFF {
        return Some(T::INFINITY);
    } else if max_place < T::ZERO_CUTOFF {
        return Some(T::ZERO);
    }
    None
}