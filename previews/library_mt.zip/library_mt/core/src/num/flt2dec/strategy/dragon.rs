//! Traduzzjoni Kważi diretta (iżda kemmxejn ottimizzata) tat-traduzzjoni Rust tal-Figura 3 ta '"Stampar ta' Numri ta 'Punt Varjabbli malajr u Eżatt" [^ 1].
//!
//!
//! [^1]: Burger, RG u Dybvig, RK 1996. Stampar ta 'numri b'punt li jvarja
//!   malajr u b'mod preċiż.SIGPLAN Mhux.31, 5 (Mejju. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// matriċi kkalkulati minn qabel ta '' Digit`s għal 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// Jista 'jintuża biss meta `x < 16 * scale`;`scaleN` għandu jkun `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// L-iqsar implimentazzjoni tal-modalità għal Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // in-numru `v` għall-format huwa magħruf li huwa:
    // - daqs `mant * 2^exp`;
    // - preċedut minn `(mant - 2 *minus)* 2^exp` fit-tip oriġinali;u
    // - segwit minn `(mant + 2 *plus)* 2^exp` fit-tip oriġinali.
    //
    // ovvjament, `minus` u `plus` ma jistgħux ikunu żero.(għal infinitajiet, nużaw valuri barra mill-firxa.) nassumu wkoll li tal-inqas ċifra waħda hija ġġenerata, jiġifieri, `mant` ma jistax ikun żero wkoll.
    //
    // dan ifisser ukoll li kwalunkwe numru bejn `low = (mant - minus)*2^exp` u `high = (mant + plus)* 2^exp` se jimmappja għal dan in-numru eżatt ta 'virgola, b'limiti inklużi meta l-mantissa oriġinali kienet uniformi (jiġifieri, `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` huwa `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // stima `k_0` minn inputs oriġinali li jissodisfaw `10^(k_0-1) < high <= 10^(k_0+1)`.
    // ix-`k` issikkat li jissodisfa `10^(k-1) < high <= 10^k` huwa kkalkulat aktar tard.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // ikkonverti `{mant, plus, minus} * 2^exp` fil-forma frazzjonali sabiex:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // taqsam `mant` b `10^k`.issa `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // jiffissa meta `mant + plus > scale` (jew `>=`).
    // attwalment m'aħniex qed nimmodifikaw `scale`, peress li nistgħu naqbżu l-multiplikazzjoni inizjali minflok.
    // issa `scale < mant + plus <= scale * 10` u aħna lesti li niġġeneraw ċifri.
    //
    // innota li `d[0]`*jista '* jkun żero, meta `scale - plus < mant < scale`.
    // f'dan il-każ il-kundizzjoni ta 'arrotondament (`up` hawn taħt) tinbeda immedjatament.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // ekwivalenti għal skalar ta `scale` b'10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` għall-ġenerazzjoni taċ-ċifri.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, fejn `d[0..n-1]` huma ċifri ġġenerati s'issa:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (għalhekk `mant / scale < 10`) fejn `d[i..j]` huwa taqsir għal `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // iġġenera ċifra waħda: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // din hija deskrizzjoni simplifikata tal-algoritmu Dragon modifikat.
        // ħafna derivazzjonijiet intermedji u argumenti ta 'kompletezza jitħallew barra għall-konvenjenza.
        //
        // ibda b'invarianti modifikati, kif aġġornajna `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // nassumu li `d[0..n-1]` hija l-iqsar rappreżentazzjoni bejn `low` u `high`, jiġifieri, `d[0..n-1]` jissodisfa t-tnejn li ġejjin imma `d[0..n-2]` le:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijjettività: ċifri tondi sa `v`);u
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (l-aħħar ċifra hija korretta).
        //
        // it-tieni kundizzjoni tissimplifika għal `2 * mant <= scale`.
        // jekk issolvi invarjanti f'termini ta `mant`, `low` u `high` tagħti verżjoni aktar sempliċi tal-ewwel kundizzjoni: `-plus < mant < minus`.
        // minn `-plus < 0 <= mant`, għandna l-iqsar rappreżentazzjoni korretta meta `mant < minus` u `2 * mant <= scale`.
        // (l-ewwel isir `mant <= minus` meta l-mantissa oriġinali tkun uniformi.)
        //
        // meta t-tieni ma żżommx ("2 * mant> skala"), għandna bżonn inżidu l-aħħar ċifra.
        // dan huwa biżżejjed għar-restawr ta 'dik il-kundizzjoni: aħna diġà nafu li l-ġenerazzjoni taċ-ċifri tiggarantixxi `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // f'dan il-każ, l-ewwel kundizzjoni ssir `-plus < mant - scale < minus`.
        // minn `mant < scale` wara l-ġenerazzjoni, għandna `scale < mant + plus`.
        // (għal darb'oħra, dan isir `scale <= mant + plus` meta l-mantissa oriġinali tkun uniformi.)
        //
        // fil-qosor:
        // - waqqaf u dawwar `down` (żomm iċ-ċifri kif inhi) meta `mant < minus` (jew `<=`).
        // - waqqaf u dawwar `up` (żid l-aħħar ċifra) meta `scale < mant + plus` (jew `<=`).
        // - kompli jiġġenera mod ieħor.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // għandna l-iqsar rappreżentazzjoni, ipproċedi għar-rounding

        // jirrestawraw l-invariants.
        // dan jagħmel l-algoritmu dejjem jintemm: `minus` u `plus` dejjem jiżdiedu, imma `mant` huwa maqtugħ modulo `scale` u `scale` huwa ffissat.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // arrotondament 'il fuq jiġri meta i) il-kundizzjoni ta' arrotondament biss ġiet attivata, jew ii) iż-żewġ kundizzjonijiet ġew attivati u tie breaking jippreferi arrotondament 'il fuq.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // jekk l-arrotondament jibdel it-tul, l-esponent għandu jinbidel ukoll.
        // jidher li din il-kundizzjoni hija diffiċli ħafna biex tissodisfaha (possibilment impossibbli), imma aħna qed inkunu sikuri u konsistenti hawnhekk.
        //
        // SIGURTÀ: aħna inizjalizzajna dik il-memorja hawn fuq.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SIGURTÀ: aħna inizjalizzajna dik il-memorja hawn fuq.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// L-implimentazzjoni tal-modalità eżatta u fissa għal Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // stima `k_0` minn inputs oriġinali li jissodisfaw `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // taqsam `mant` b `10^k`.issa `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup meta `mant + plus >= scale`, fejn `plus / scale = 10^-buf.len() / 2`.
    // sabiex inżommu l-bignum ta 'daqs fiss, fil-fatt nużaw `mant + floor(plus) >= scale`.
    // attwalment m'aħniex qed nimmodifikaw `scale`, peress li nistgħu naqbżu l-multiplikazzjoni inizjali minflok.
    // għal darb'oħra bl-iqsar algoritmu, `d[0]` jista 'jkun żero iżda eventwalment jiġi arrotondat' il fuq.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // ekwivalenti għal skalar ta `scale` b'10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // jekk qed naħdmu bil-limitazzjoni tal-aħħar ċifri, għandna nqassru l-buffer qabel l-għoti attwali sabiex nevitaw arrotondament doppju.
    //
    // innota li rridu nkabbru l-buffer mill-ġdid meta jiġri l-arrotondament!
    let mut len = if k < limit {
        // oops, lanqas biss nistgħu nipproduċu * ċifra waħda.
        // dan huwa possibbli meta, ngħidu aħna, għandna xi ħaġa bħal 9.5 u qed tiġi arrotondata għal 10.
        // aħna nirritornaw buffer vojt, bl-eċċezzjoni tal-każ ta 'arrotondament aktar tard li jseħħ meta `k == limit` u għandu jipproduċi eżattament ċifra waħda.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` għall-ġenerazzjoni taċ-ċifri.
        // (dan jista 'jiswa ħafna, allura tikkalkulhomx meta l-buffer ikun vojt.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // iċ-ċifri li ġejjin huma kollha żero, nieqfu hawn *ma* nippruvawx inwettqu l-arrotondament!anzi, imla ċ-ċifri li jifdal.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SIGURTÀ: aħna inizjalizzajna dik il-memorja hawn fuq.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // arrotondament 'il fuq jekk nieqfu fin-nofs taċ-ċifri jekk iċ-ċifri li ġejjin huma eżattament 5000 ..., iċċekkja ċ-ċifra ta' qabel u pprova arrotondaw għal pari (jiġifieri, tevita li ttondja 'l fuq meta ċ-ċifra ta' qabel tkun pari).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SIGURTÀ: `buf[len-1]` huwa inizjalizzat.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // jekk l-arrotondament jibdel it-tul, l-esponent għandu jinbidel ukoll.
        // imma ġejna mitluba numru fiss ta 'ċifri, allura tibdilx il-buffer ...
        // SIGURTÀ: aħna inizjalizzajna dik il-memorja hawn fuq.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... sakemm minflok ma tlabniex il-preċiżjoni fissa minflok.
            // irridu niċċekkjaw ukoll li, jekk il-buffer oriġinali kien vojt, in-numru addizzjonali jista 'jiżdied biss meta `k == limit` (każ edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SIGURTÀ: aħna inizjalizzajna dik il-memorja hawn fuq.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}