//! Adattament ta 'Rust tal-algoritmu Grisu3 deskritt f' "Stampar ta 'Numri ta' Punt Varjabbli Malajr u Eżatt ma 'Integers" [^ 1].
//! Huwa juża madwar 1KB ta 'tabella kkomputata minn qabel, u min-naħa tiegħu, huwa mgħaġġel ħafna għall-biċċa l-kbira tal-inputs.
//!
//! [^1]: Florian Loitsch.2010. Stampar ta 'numri b'punt li jvarja malajr u
//!   b'mod preċiż bin-numri sħaħ.SIGPLAN Mhux.45, 6 (Ġunju 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ara l-kummenti f `format_shortest_opt` għar-raġuni.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Minħabba `x > 0`, jirritorna `(k, 10^k)` b'tali mod li `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// L-iqsar implimentazzjoni tal-modalità għal Grisu.
///
/// Jirritorna `None` meta jirritorna rappreżentazzjoni mhux eżatta mod ieħor.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // għandna bżonn mill-inqas tliet bits ta 'preċiżjoni addizzjonali

    // ibda bil-valuri normalizzati bl-esponent kondiviż
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // sib xi `cached = 10^minusk` tali li `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // billi `plus` huwa normalizzat, dan ifisser `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // minħabba l-għażliet tagħna ta `ALPHA` u `GAMMA`, dan ipoġġi lil `plus * cached` f `[4, 2^32)`.
    //
    // ovvjament huwa mixtieq li nimmassimizzaw `GAMMA - ALPHA`, sabiex ma jkollniex bżonn ħafna setgħat cache ta '10, imma hemm xi konsiderazzjonijiet:
    //
    //
    // 1. irridu nżommu `floor(plus * cached)` fi ħdan `u32` peress li jeħtieġ diviżjoni għalja.
    //    (dan mhux verament evitabbli, il-kumplament huwa meħtieġ għall-istima tal-eżattezza.)
    // 2.
    // il-bqija ta `floor(plus * cached)` ripetutament jiġi mmultiplikat b'10, u m'għandux ifur.
    //
    // l-ewwel jagħti `64 + GAMMA <= 32`, filwaqt li t-tieni jagħti `10 * 2^-ALPHA <= 2^64`;
    // -60 u -32 hija l-firxa massima b'din ir-restrizzjoni, u V8 jużahom ukoll.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.dan jagħti l-iżball massimu ta '1 ulp (ippruvat mit-Teorema 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-firxa attwali ta 'nieqes
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // 'il fuq minn `minus`, `v` u `plus` huma approssimazzjonijiet *kwantizzati*(żball <1 ulp).
    // billi ma nafux l-iżball huwa pożittiv jew negattiv, nużaw żewġ approssimazzjonijiet spazjati b'mod ugwali u għandna l-iżball massimu ta '2 ulps.
    //
    // ix-"unsafe region" huwa intervall liberali li inizjalment niġġeneraw.
    // ix-"safe region" huwa intervall konservattiv li aħna naċċettaw biss.
    // nibdew bir-repr korretta fir-reġjun mhux sikur, u nippruvaw insibu l-eqreb repr għal `v` li hija wkoll fir-reġjun sigur.
    // jekk ma nistgħux, naqtgħu qalbna.
    //
    let plus1 = plus.f + 1;
    // ħalli plus0 = plus.f, 1;//biss għal spjegazzjoni ħalli minus0 = minus.f + 1;//biss għal spjegazzjoni
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // esponent maqsum

    // taqsam `plus1` f'partijiet integrali u frazzjonali.
    // partijiet integrali huma ggarantiti li joqogħdu f u32, billi l-enerġija moħbija tiggarantixxi `plus < 2^32` u `plus.f` normalizzata hija dejjem inqas minn `2^64 - 2^4` minħabba r-rekwiżit ta 'preċiżjoni.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // ikkalkula l-akbar `10^max_kappa` mhux aktar minn `plus1` (għalhekk `plus1 < 10^(max_kappa+1)`).
    // dan huwa limitu ta 'fuq ta' `kappa` hawn taħt.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Teorema 6.2: jekk `k` huwa l-akbar numru sħiħ st
    // `0 <= y mod 10^k <= y - x`,              allura `V = floor(y / 10^k) * 10^k` huwa f `[x, y]` u waħda mill-iqsar rappreżentazzjonijiet (bin-numru minimu ta 'ċifri sinifikanti) f'dik il-medda.
    //
    //
    // sib it-tul taċ-ċifra `kappa` bejn `(minus1, plus1)` skont it-Teorema 6.2.
    // It-teorema 6.2 jista 'jiġi adottat biex jeskludi `x` billi minflok teħtieġ `y mod 10^k < y - x`.
    // (eż., `x` =32000, `y` =32777; `kappa` =2 peress li "y mod 10 ^ 3=777 <y, x=777".) l-algoritmu jiddependi fuq il-fażi ta 'verifika aktar tard biex teskludi `y`.
    //
    let delta1 = plus1 - minus1;
    // let delta1int=(delta1>> e) kif tuża;//biss għal spjegazzjoni
    let delta1frac = delta1 & ((1 << e) - 1);

    // tirrendi partijiet integrali, waqt li tiċċekkja għall-eżattezza f'kull pass.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // ċifri li għad iridu jingħataw
    loop {
        // aħna dejjem għandna mill-inqas ċifra waħda x'nirrendu, bħala `plus1 >= 10^kappa` invariants:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (isegwi li `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // taqsam `remainder` b `10^kappa`.it-tnejn huma skalati minn `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; sibna l-`kappa` it-tajjeb.
            let ten_kappa = (ten_kappa as u64) << e; // skala 10 ^ kappa lura għall-esponent kondiviż
            return round_and_weed(
                // SIGURTÀ: aħna inizjalizzajna dik il-memorja hawn fuq.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // ikisser il-linja meta rridu n-numri integrali kollha.
        // in-numru eżatt ta 'ċifri huwa `max_kappa + 1` bħala `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // jirrestawraw invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // tirrendi partijiet frazzjonali, waqt li tiċċekkja għall-eżattezza f'kull pass.
    // din id-darba niddependu fuq multiplikazzjonijiet ripetuti, billi d-diviżjoni titlef il-preċiżjoni.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // iċ-ċifra li jmiss għandha tkun sinifikanti peress li ttestjajna dik qabel ma nfaqqgħu l-invarianti, fejn `m = max_kappa + 1` (#ta 'ċifri fil-parti integrali):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // mhux ser ifur, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // taqsam `remainder` b `10^kappa`.
        // it-tnejn huma skalati minn `2^e / 10^kappa`, allura dan tal-aħħar huwa impliċitu hawn.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // diviżur impliċitu
            return round_and_weed(
                // SIGURTÀ: aħna inizjalizzajna dik il-memorja hawn fuq.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // jirrestawraw invariants
        kappa -= 1;
        remainder = r;
    }

    // ġġenerajna ċ-ċifri sinifikanti kollha ta `plus1`, imma mhux ċert jekk hix l-aħjar waħda.
    // per eżempju, jekk `minus1` huwa 3.14153 ... u `plus1` huwa 3.14158 ..., hemm 5 l-iqsar rappreżentazzjoni differenti minn 3.14154 sa 3.14158 imma aħna għandna biss l-akbar waħda.
    // irridu nnaqqsu suċċessivament l-aħħar ċifra u niċċekkjaw jekk din hijiex l-aħjar rip.
    // hemm l-iktar 9 kandidati (..1 sa ..9), allura dan huwa pjuttost mgħaġġel.(Fażi "rounding")
    //
    // il-funzjoni tivverifika jekk din ir-repr "optimal" hijiex fil-fatt fil-meded tal-ulp, u wkoll, huwa possibbli li r-repr "second-to-optimal" jista 'effettivament ikun l-aħjar minħabba l-iżball ta' arrotondament.
    // fiż-żewġ każijiet dan jirritorna `None`.
    // (Fażi "weeding")
    //
    // l-argumenti kollha hawn huma skalati bil-valur komuni (iżda impliċitu) `k`, sabiex:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (u wkoll, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (u wkoll, `threshold > plus1v` minn invariants preċedenti)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // ipproduċi żewġ approssimazzjonijiet għal `v` (fil-fatt `plus1 - v`) fi ħdan 1.5 ulps.
        // ir-rappreżentazzjoni li tirriżulta għandha tkun l-eqreb rappreżentazzjoni tat-tnejn.
        //
        // hawn `plus1 - v` jintuża billi l-kalkoli jsiru fir-rigward ta `plus1` sabiex jiġi evitat overflow/underflow (għalhekk l-ismijiet apparentement skambjati).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // naqqas l-aħħar ċifra u waqqaf fl-eqreb rappreżentazzjoni għal `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // naħdmu biċ-ċifri approssimati `w(n)`, li inizjalment hija ugwali għal `plus1 - plus1 % 10^kappa`.wara li tħaddem il-body tal-linja `n` darbiet, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // waqqafna `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (għalhekk `bqija= plus1w(0)`) biex tissimplifika l-kontrolli.
            // innota li `plus1w(n)` dejjem qed jiżdied.
            //
            // għandna tliet kundizzjonijiet x'nitterminaw.kwalunkwe wieħed minnhom jagħmel il-ħolqa ma tkunx tista 'tipproċedi, imma mbagħad għandna mill-inqas rappreżentazzjoni waħda valida magħrufa li hija l-eqreb għal `v + 1 ulp` xorta waħda.
            // se nindikawhom bħala TC1 sa TC3 għall-qosor.
            //
            // TC1: `w(n) <= v + 1 ulp`, jiġifieri, din hija l-aħħar repr li tista 'tkun l-eqreb waħda.
            // dan huwa ekwivalenti għal `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // ikkombinat ma TC2 (li jivverifika jekk `w(n+1)` is valid), dan jimpedixxi l-overflow possibbli fuq il-kalkolu ta' `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, jiġifieri, ir-repr li jmiss żgur ma jdurx għal `v`.
            // dan huwa ekwivalenti għal `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // in-naħa tax-xellug tista 'tfur, imma nafu `threshold > plus1v`, allura jekk TC1 huwa falz, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` u nistgħu nittestjaw b'mod sigur jekk `threshold - plus1w(n) < 10^kappa` minflok.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, jiġifieri, ir-repr li jmiss hija
            // mhux eqreb lejn `v + 1 ulp` mir-repr kurrenti.
            // mogħti `z(n) = plus1v_up - plus1w(n)`, dan isir `abs(z(n)) <= abs(z(n+1))`.għal darb'oħra jekk nassumu li TC1 huwa falz, għandna `z(n) > 0`.għandna żewġ każijiet x'nikkunsidraw:
            //
            // - meta `z(n+1) >= 0`: TC3 isir `z(n) <= z(n+1)`.
            // billi `plus1w(n)` qed jiżdied, `z(n)` għandu jonqos u dan huwa ċar falz.
            // - meta `z(n+1) < 0`:
            //   - TC3a: il-prekundizzjoni hija `plus1v_up < plus1w(n) + 10^kappa`.jekk wieħed jassumi li TC2 huwa falz, `threshold >= plus1w(n) + 10^kappa` għalhekk ma jistax ifur.
            //   - TC3b: TC3 isir `z(n) <= -z(n+1)`, jiġifieri, `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   ix-TC1 innegat jagħti lil `plus1v_up > plus1w(n)`, u għalhekk ma jistax ifur jew ma jaqbiżx meta kkombinat ma 'TC3a.
            //
            // konsegwentement, għandna nieqfu meta `TC1 || TC2 || (TC3a && TC3b)`.dan li ġej huwa ugwali għall-invers tiegħu, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // l-iqsar riproduzzjoni ma tistax tintemm b `0`
                plus1w += ten_kappa;
            }
        }

        // iċċekkja jekk din ir-rappreżentazzjoni hijiex ukoll l-eqreb rappreżentazzjoni għal `v - 1 ulp`.
        //
        // dan huwa sempliċement l-istess għall-kundizzjonijiet ta 'terminazzjoni għal `v + 1 ulp`, bix-`plus1v_up` kollu sostitwit b `plus1v_down` minflok.
        // l-analiżi tat-tifwir għandha l-istess.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // issa għandna l-eqreb rappreżentazzjoni għal `v` bejn `plus1` u `minus1`.
        // dan huwa liberali wisq, għalkemm, allura aħna nirrifjutaw kull `w(n)` mhux bejn `plus0` u `minus0`, jiġifieri, `plus1 - plus1w(n) <= minus0` jew `plus1 - plus1w(n) >= plus0`.
        // nużaw il-fatti li `threshold = plus1 - minus1` u `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// L-iqsar mod ta 'implimentazzjoni għal Grisu b'Dragon fallback.
///
/// Dan għandu jintuża għal ħafna każijiet.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SIGURTÀ: Il-kontrollur tas-self mhuwiex intelliġenti biżżejjed biex iħallina nużaw `buf`
    // fit-tieni branch, allura aħna naħslu l-ħajja hawn.
    // Imma aħna nużaw mill-ġdid `buf` biss jekk `format_shortest_opt` irritorna `None` u allura dan huwa tajjeb.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// L-implimentazzjoni tal-modalità eżatta u fissa għal Grisu.
///
/// Jirritorna `None` meta jirritorna rappreżentazzjoni mhux eżatta mod ieħor.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // għandna bżonn mill-inqas tliet bits ta 'preċiżjoni addizzjonali
    assert!(!buf.is_empty());

    // normalizza u skala `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // taqsam `v` f'partijiet integrali u frazzjonali.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // kemm `v` qadim kif ukoll `v` ġdid (skalat minn `10^-k`) għandu żball ta '<1 ulp (Teorema 5.1).
    // billi ma nafux l-iżball huwa pożittiv jew negattiv, nużaw żewġ approssimazzjonijiet spazjati b'mod ugwali u għandna l-iżball massimu ta '2 ulps (l-istess għall-iqsar każ).
    //
    //
    // l-għan huwa li nsibu s-serje ta 'ċifri eżattament arrotondati li huma komuni kemm għal `v - 1 ulp` kif ukoll għal `v + 1 ulp`, sabiex inkunu kunfidenti kemm jista' jkun.
    // jekk dan mhux possibbli, ma nafux liema waħda hija l-output korrett għal `v`, allura naqtgħu qalbna u naqgħu lura.
    //
    // `err` hawnhekk huwa definit bħala `1 ulp * 2^e` (l-istess għall-ulp f `vfrac`), u aħna nagħmlu skala kull meta `v` isir skalat.
    //
    //
    //
    let mut err = 1;

    // ikkalkula l-akbar `10^max_kappa` mhux aktar minn `v` (għalhekk `v < 10^(max_kappa+1)`).
    // dan huwa limitu ta 'fuq ta' `kappa` hawn taħt.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // jekk qed naħdmu bil-limitazzjoni tal-aħħar ċifri, għandna nqassru l-buffer qabel l-għoti attwali sabiex nevitaw arrotondament doppju.
    //
    // innota li rridu nkabbru l-buffer mill-ġdid meta jiġri l-arrotondament!
    let len = if exp <= limit {
        // oops, lanqas biss nistgħu nipproduċu * ċifra waħda.
        // dan huwa possibbli meta, ngħidu aħna, għandna xi ħaġa bħal 9.5 u qed tiġi arrotondata għal 10.
        //
        // fil-prinċipju nistgħu nsejħu immedjatament `possibly_round` b'buffer vojt, iżda l-iskalar ta `max_ten_kappa << e` b'10 jista' jirriżulta f'flus.
        //
        // għalhekk qed inkunu sloppy hawn u nwessgħu l-firxa ta 'żball b'fattur ta' 10.
        // dan iżid ir-rata negattiva falza, iżda biss ħafna,*ħafna* ftit;
        // jista 'jkun importanti biss b'mod notevoli meta l-mantissa hija akbar minn 60 bits.
        //
        // SIGURTÀ: `len=0`, allura l-obbligu li tkun inizjalizzata din il-memorja huwa trivjali.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // jagħmlu partijiet integrali.
    // l-iżball huwa kompletament frazzjonali, allura m'għandniex bżonn niċċekkjawha f'din il-parti.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // ċifri li għad iridu jingħataw
    loop {
        // dejjem għandna mill-inqas ċifra waħda biex nagħmlu invarjanti:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (isegwi li `remainder = vint % 10^(kappa+1)`)
        //
        //

        // taqsam `remainder` b `10^kappa`.it-tnejn huma skalati minn `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // il-buffer huwa mimli?imexxi l-rounding pass bil-kumplament.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SIGURTÀ: aħna inizjalizzaw `len` ħafna bytes.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // ikisser il-linja meta rridu n-numri integrali kollha.
        // in-numru eżatt ta 'ċifri huwa `max_kappa + 1` bħala `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // jirrestawraw invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // jagħmlu partijiet frazzjonali.
    //
    // fil-prinċipju nistgħu nkomplu sal-aħħar ċifra disponibbli u niċċekkjaw għall-eżattezza.
    // sfortunatament qed naħdmu ma 'numri sħaħ ta' daqs finit, allura għandna bżonn xi kriterju biex nindunaw il-overflow.
    // V8 juża `remainder > err`, li jsir falz meta l-ewwel numri sinifikanti `i` ta `v - 1 ulp` u `v` ivarjaw.
    // madankollu dan jirrifjuta wisq input li xort'oħra huwa validu.
    //
    // billi l-fażi ta 'wara għandha skoperta korretta ta' tifwir, minflok nużaw kriterju aktar strett:
    // inkomplu sakemm `err` jaqbeż `10^kappa / 2`, sabiex il-firxa bejn `v - 1 ulp` u `v + 1 ulp` definittivament ikun fiha żewġ rappreżentazzjonijiet arrotondati jew aktar.
    //
    // dan huwa l-istess għall-ewwel żewġ paraguni minn `possibly_round`, għar-referenza.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarjanti, fejn `m = max_kappa + 1` (#ta 'ċifri fil-parti integrali):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // mhux ser ifur, `2^e * 10 < 2^64`
        err *= 10; // mhux ser ifur, `err * 10 < 2^e * 5 < 2^64`

        // taqsam `remainder` b `10^kappa`.
        // it-tnejn huma skalati minn `2^e / 10^kappa`, allura dan tal-aħħar huwa impliċitu hawn.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // il-buffer huwa mimli?imexxi l-rounding pass bil-kumplament.
        if i == len {
            // SIGURTÀ: aħna inizjalizzaw `len` ħafna bytes.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // jirrestawraw invariants
        remainder = r;
    }

    // aktar kalkolu huwa inutli (`possibly_round` definittivament ifalli), allura naqtgħu qalbna.
    return None;

    // ġenerajna ċ-ċifri kollha mitluba ta `v`, li għandhom ikunu wkoll l-istess għal ċifri korrispondenti ta' `v - 1 ulp`.
    // issa niċċekkjaw jekk hemmx rappreżentazzjoni unika maqsuma kemm minn `v - 1 ulp` kif ukoll minn `v + 1 ulp`;dan jista 'jkun l-istess għal ċifri ġġenerati, jew għall-verżjoni mqarrba' l fuq ta 'dawk iċ-ċifri.
    //
    // jekk il-firxa fiha rappreżentazzjonijiet multipli tal-istess tul, ma nistgħux inkunu ċerti u minflok għandna nirritornaw `None`.
    //
    // l-argumenti kollha hawn huma skalati bil-valur komuni (iżda impliċitu) `k`, sabiex:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SIGURTÀ: l-ewwel `len` bytes ta `buf` għandhom jiġu inizjalizzati.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (għar-referenza, il-linja bit-tikek tindika l-valur eżatt għal rappreżentazzjonijiet possibbli f'numru partikolari ta 'ċifri.)
        //
        //
        // żball huwa kbir wisq li hemm mill-inqas tliet rappreżentazzjonijiet possibbli bejn `v - 1 ulp` u `v + 1 ulp`.
        // ma nistgħux niddeterminaw liema waħda hija korretta.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // fil-fatt, 1/2 ulp huwa biżżejjed biex jintroduċi żewġ rappreżentazzjonijiet possibbli.
        // (ftakar li għandna bżonn rappreżentazzjoni unika kemm għal `v - 1 ulp` kif ukoll għal "v + 1 ulp".) dan mhux ser ifur, għax `ulp < ten_kappa` mill-ewwel verifika.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // jekk `v + 1 ulp` huwa eqreb tar-rappreżentazzjoni mdawra 'l isfel (li diġà jinsab f `buf`), allura nistgħu nerġgħu lura b'mod sikur.
        // innota li `v - 1 ulp`*jista 'jkun* inqas mir-rappreżentazzjoni kurrenti, iżda bħala `1 ulp < 10^kappa / 2`, din il-kundizzjoni hija biżżejjed:
        // id-distanza bejn `v - 1 ulp` u r-rappreżentazzjoni attwali ma tistax taqbeż `10^kappa / 2`.
        //
        // il-kundizzjoni hija daqs `remainder + ulp < 10^kappa / 2`.
        // billi dan jista 'faċilment ifur, l-ewwel iċċekkja jekk `remainder < 10^kappa / 2`.
        // aħna diġà vverifikajna li `ulp < 10^kappa / 2`, allura sakemm `10^kappa` wara kollox ma tfurx, it-tieni verifika hija tajba.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SIGURTÀ: min iċempel tagħna inizjalizza dik il-memorja.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------bqija------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // min-naħa l-oħra, jekk `v - 1 ulp` huwa eqreb lejn ir-rappreżentazzjoni arrotondata, għandna nirrondjaw u nerġgħu lura.
        // għall-istess raġuni m'għandniex bżonn niċċekkjaw `v + 1 ulp`.
        //
        // il-kundizzjoni hija daqs `remainder - ulp >= 10^kappa / 2`.
        // għal darb'oħra aħna l-ewwel niċċekkjaw jekk `remainder > ulp` (innota li dan mhux `remainder >= ulp`, għax `10^kappa` qatt mhu żero).
        //
        // innota wkoll li `remainder - ulp <= 10^kappa`, allura t-tieni verifika ma tfurx.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SIGURTÀ: min iċempel irid ikun inizjalizza dik il-memorja.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // żid ċifra addizzjonali biss meta ġejna mitluba l-preċiżjoni fissa.
                // irridu niċċekkjaw ukoll li, jekk il-buffer oriġinali kien vojt, in-numru addizzjonali jista 'jiżdied biss meta `exp == limit` (każ edge).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SIGURTÀ: aħna u min iċempel tagħna inizjalizzaw dik il-memorja.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // inkella nkunu ddestinati (jiġifieri, xi valuri bejn `v - 1 ulp` u `v + 1 ulp` qed idawru 'l isfel u oħrajn qed idawru' l fuq) u naqtgħu qalbna.
        //
        None
    }
}

/// L-implimentazzjoni eżatta u fissa tal-modalità għal Grisu bi Dragon fallback.
///
/// Dan għandu jintuża għal ħafna każijiet.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SIGURTÀ: Il-kontrollur tas-self mhuwiex intelliġenti biżżejjed biex iħallina nużaw `buf`
    // fit-tieni branch, allura aħna naħslu l-ħajja hawn.
    // Imma aħna nużaw mill-ġdid `buf` biss jekk `format_exact_opt` irritorna `None` u allura dan huwa tajjeb.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}