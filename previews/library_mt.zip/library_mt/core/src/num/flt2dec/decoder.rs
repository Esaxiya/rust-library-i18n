//! Jiddekowdja valur ta 'punt varjabbli f'partijiet individwali u firxiet ta' żbalji.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Valur finit mhux iffirmat dekodifikat, tali li:
///
/// - Il-valur oriġinali huwa daqs `mant * 2^exp`.
///
/// - Kwalunkwe numru minn `(mant - minus)*2^exp` sa `(mant + plus)* 2^exp` se jdawwar għall-valur oriġinali.
/// Il-firxa hija inklussiva biss meta `inclusive` huwa `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Il-mantissa skalata.
    pub mant: u64,
    /// Il-firxa ta 'żball l-aktar baxxa.
    pub minus: u64,
    /// Il-firxa ta 'żball ta' fuq.
    pub plus: u64,
    /// L-esponent kondiviż fil-bażi 2.
    pub exp: i16,
    /// Veru meta l-firxa tal-iżball hija inklussiva.
    ///
    /// Fl-IEEE 754, dan huwa minnu meta l-mantissa oriġinali kienet uniformi.
    pub inclusive: bool,
}

/// Valur mhux iffirmat dekodifikat.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinitajiet, jew pożittivi jew negattivi.
    Infinite,
    /// Żero, jew pożittiv jew negattiv.
    Zero,
    /// Numri finiti b'aktar oqsma dekodifikati.
    Finite(Decoded),
}

/// Tip ta 'punt varjabbli li jista' jkun 'decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Il-valur pożittiv normalizzat minimu.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Jirritorna sinjal (veru meta jkun negattiv) u valur `FullDecoded` minn numru ta 'punt varjabbli mogħti.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // ġirien: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode dejjem jippreserva l-esponent, allura l-mantissa hija skalata għal subnormali.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // ġirien: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // fejn maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // ġirien: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}