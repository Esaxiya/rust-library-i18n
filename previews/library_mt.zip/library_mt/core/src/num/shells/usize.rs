//! Kostanti għat-tip ta 'numru sħiħ mhux iffirmat ta' daqs pointer.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! Kodiċi ġdid għandu juża l-kostanti assoċjati direttament fuq it-tip primittiv.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }