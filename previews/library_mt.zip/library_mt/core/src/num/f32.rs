//! Kostanti speċifiċi għat-tip b'punt li jvarja ta 'preċiżjoni waħda `f32`.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Numri matematikament sinifikanti huma pprovduti fis-sub-modulu `consts`.
//!
//! Għall-kostanti definiti direttament f'dan il-modulu (kif distint minn dawk definiti fis-sub-modulu `consts`), kodiċi ġdid għandu minflok juża l-kostanti assoċjati definiti direttament fuq it-tip `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Ir-radix jew il-bażi tar-rappreżentazzjoni interna ta `f32`.
/// Uża [`f32::RADIX`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // mod maħsub
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Numru ta 'ċifri sinifikanti fil-bażi 2.
/// Uża [`f32::MANTISSA_DIGITS`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // mod maħsub
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Numru approssimattiv ta 'ċifri sinifikanti fil-bażi 10.
/// Uża [`f32::DIGITS`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // mod maħsub
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] valur għal `f32`.
/// Uża [`f32::EPSILON`] minflok.
///
/// Din hija d-differenza bejn `1.0` u n-numru rappreżentattiv ikbar li jmiss.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // mod maħsub
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// L-iżgħar valur `f32` finit.
/// Uża [`f32::MIN`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // mod maħsub
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// L-iżgħar valur pożittiv `f32` normali.
/// Uża [`f32::MIN_POSITIVE`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // mod maħsub
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// L-akbar valur `f32` finit.
/// Uża [`f32::MAX`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // mod maħsub
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Wieħed akbar mill-potenza normali minima possibbli ta '2 esponent.
/// Uża [`f32::MIN_EXP`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // mod maħsub
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Qawwa massima possibbli ta '2 esponent.
/// Uża [`f32::MAX_EXP`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // mod maħsub
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Qawwa normali minima possibbli ta '10 esponent.
/// Uża [`f32::MIN_10_EXP`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // mod maħsub
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Qawwa massima possibbli ta '10 esponent.
/// Uża [`f32::MAX_10_EXP`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // mod maħsub
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Mhux Numru (NaN).
/// Uża [`f32::NAN`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // mod maħsub
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Uża [`f32::INFINITY`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // mod maħsub
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Infinità negattiva (−∞).
/// Uża [`f32::NEG_INFINITY`] minflok.
///
/// # Examples
///
/// ```rust
/// // mod deprezzat
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // mod maħsub
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Kostanti matematiċi bażiċi.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: ibdel b'kostanti matematiċi minn cmath.

    /// (π) kostanti ta 'Arkimede
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Iċ-ċirku sħiħ kostanti (τ)
    ///
    /// Ugwali għal 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// In-numru ta 'Euler (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Ir-radix jew il-bażi tar-rappreżentazzjoni interna ta `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Numru ta 'ċifri sinifikanti fil-bażi 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Numru approssimattiv ta 'ċifri sinifikanti fil-bażi 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] valur għal `f32`.
    ///
    /// Din hija d-differenza bejn `1.0` u n-numru rappreżentattiv ikbar li jmiss.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// L-iżgħar valur `f32` finit.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// L-iżgħar valur pożittiv `f32` normali.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// L-akbar valur `f32` finit.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Wieħed akbar mill-potenza normali minima possibbli ta '2 esponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Qawwa massima possibbli ta '2 esponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Qawwa normali minima possibbli ta '10 esponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Qawwa massima possibbli ta '10 esponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Mhux Numru (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Infinità negattiva (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Jirritorna `true` jekk dan il-valur huwa `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` mhuwiex disponibbli pubblikament fil-libcore minħabba tħassib dwar il-portabbiltà, għalhekk din l-implimentazzjoni hija għal użu privat internament.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Jirritorna `true` jekk dan il-valur huwa infinit pożittiv jew infinit negattiv, u `false` mod ieħor.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Jirritorna `true` jekk dan in-numru la huwa infinit u lanqas `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // M`hemmx għalfejn tittratta NaN separatament: jekk l-awto huwa NaN, it-tqabbil mhux veru, eżattament kif mixtieq.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Jirritorna `true` jekk in-numru huwa [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Valuri bejn `0` u `min` huma Subnormali.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Jirritorna `true` jekk in-numru la huwa żero, infinit, [subnormal], jew `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Valuri bejn `0` u `min` huma Subnormali.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Jirritorna l-kategorija tal-punt varjabbli tan-numru.
    /// Jekk se tiġi ttestjata proprjetà waħda biss, ġeneralment ikun aktar mgħaġġel li tuża l-predikat speċifiku minflok.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Jirritorna `true` jekk `self` għandu sinjal pożittiv, inkluż `+0.0`, `NaN` bit-sinjal pożittiv bit u infinità pożittiva.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Jirritorna `true` jekk `self` għandu sinjal negattiv, inkluż `-0.0`, `NaN` b`sinjal negattiv bit u infinità negattiva.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 jgħid: isSignMinus(x) huwa veru jekk u biss jekk x għandu sinjal negattiv.
        // isSignMinus japplika wkoll għal żerijiet u NaNs.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Jieħu l-(inverse) reċiproku ta 'numru, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Ikkonverti r-radjanti fi gradi.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Uża kostanti għal preċiżjoni aħjar.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Ikkonverti gradi f'radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Jirritorna l-massimu taż-żewġ numri.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Jekk wieħed mill-argumenti huwa NaN, allura l-argument l-ieħor jingħata lura.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Jirritorna l-minimu taż-żewġ numri.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Jekk wieħed mill-argumenti huwa NaN, allura l-argument l-ieħor jingħata lura.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Iddawwar lejn iż-żero u tikkonverti għal kwalunkwe tip ta 'numru sħiħ primittiv, jekk wieħed jassumi li l-valur huwa finit u joqgħod f'dak it-tip.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Il-valur għandu:
    ///
    /// * Ma tkunx `NaN`
    /// * Ma tkunx infinita
    /// * Kun rappreżentabbli fit-tip ta 'ritorn `Int`, wara li tnaqqas il-parti frazzjonali tagħha
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Trasmutazzjoni prima għal `u32`.
    ///
    /// Dan bħalissa huwa identiku għal `transmute::<f32, u32>(self)` fuq il-pjattaformi kollha.
    ///
    /// Ara `from_bits` għal xi diskussjoni dwar il-portabbiltà ta 'din l-operazzjoni (kważi m'hemm l-ebda kwistjoni).
    ///
    /// Innota li din il-funzjoni hija distinta mill-ikkastjar `as`, li jipprova jippreserva l-valur *numeriku*, u mhux il-valur bitwise.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() mhix ikkastjar!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // SIGURTÀ: `u32` huwa tip ta 'dejta sempliċi u qadim u għalhekk nistgħu dejjem nibdluh
        unsafe { mem::transmute(self) }
    }

    /// Trasmutazzjoni prima minn `u32`.
    ///
    /// Dan bħalissa huwa identiku għal `transmute::<u32, f32>(v)` fuq il-pjattaformi kollha.
    /// Jirriżulta li dan huwa oerhört portabbli, għal żewġ raġunijiet:
    ///
    /// * Il-Floats u l-Ints għandhom l-istess endianness fuq il-pjattaformi kollha appoġġjati.
    /// * IEEE-754 jispeċifika b'mod preċiż it-tqassim tal-bit ta 'sufruni.
    ///
    /// Madankollu hemm twissija waħda: qabel il-verżjoni tal-2008 tal-IEEE-754, kif tinterpreta l-bit tas-sinjalar NaN ma kienx fil-fatt speċifikat.
    /// Il-biċċa l-kbira tal-pjattaformi (notevolment x86 u ARM) għażlu l-interpretazzjoni li fl-aħħar kienet standardizzata fl-2008, iżda xi wħud ma ħadmux (notevolment MIPS).
    /// Bħala riżultat, in-NaNs kollha li jagħmlu sinjal fuq MIPS huma NaNs kwieti fuq x86, u viċi-versa.
    ///
    /// Pjuttost milli tipprova tippreserva pjattaforma trasversali ta 'sinjalazzjoni, din l-implimentazzjoni tiffavorixxi l-preservazzjoni tal-bits eżatti.
    /// Dan ifisser li kwalunkwe tagħbija kkodifikata f'NaNs se tiġi ppreservata anke jekk ir-riżultat ta 'dan il-metodu jintbagħat fuq in-netwerk minn magna x86 għal waħda MIPS.
    ///
    ///
    /// Jekk ir-riżultati ta 'dan il-metodu huma manipulati biss mill-istess arkitettura li pproduċiethom, allura m'hemm l-ebda tħassib dwar il-portabbiltà.
    ///
    /// Jekk l-input mhuwiex NaN, allura m'hemm l-ebda tħassib dwar il-portabbiltà.
    ///
    /// Jekk ma jimpurtakx mis-sinjalar (probabbli ħafna), allura m'hemm l-ebda tħassib dwar il-portabbiltà.
    ///
    /// Innota li din il-funzjoni hija distinta mill-ikkastjar `as`, li jipprova jippreserva l-valur *numeriku*, u mhux il-valur bitwise.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // SIGURTÀ: `u32` huwa tip ta 'dejta sempliċi u qadim u għalhekk nistgħu dejjem nibdlu minnu
        // Jirriżulta li l-kwistjonijiet ta 'sikurezza ma' sNaN kienu żżejjed!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Irritorna r-rappreżentazzjoni tal-memorja ta 'dan in-numru tal-punt varjabbli bħala firxa ta' byte f'ordni ta 'byte big-endian (network).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Irritorna r-rappreżentazzjoni tal-memorja ta 'dan in-numru tal-punt varjabbli bħala array ta' byte f'ordni ta 'byte ftit endian.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Irritorna r-rappreżentazzjoni tal-memorja ta 'dan in-numru tal-punt varjabbli bħala array ta' byte f'ordni ta 'byte indiġeni.
    ///
    /// Hekk kif tintuża l-endianness indiġena tal-pjattaforma fil-mira, kodiċi portabbli għandu juża [`to_be_bytes`] jew [`to_le_bytes`], kif xieraq, minflok.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Irritorna r-rappreżentazzjoni tal-memorja ta 'dan in-numru tal-punt varjabbli bħala array ta' byte f'ordni ta 'byte indiġeni.
    ///
    ///
    /// [`to_ne_bytes`] għandu jkun preferut fuq dan kull meta jkun possibbli.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // SIGURTÀ: `f32` huwa tip ta 'dejta sempliċi u qadim u għalhekk nistgħu dejjem nibdluh
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Oħloq valur ta 'punt varjabbli mir-rappreżentazzjoni tiegħu bħala firxa ta' byte f'indian kbir.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Oħloq valur ta 'punt varjabbli mir-rappreżentazzjoni tiegħu bħala firxa ta' byte fi ftit endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Oħloq valur ta 'punt varjabbli mir-rappreżentazzjoni tiegħu bħala firxa ta' byte fl-endian nattiv.
    ///
    /// Hekk kif jintuża l-endianness nattiv tal-pjattaforma fil-mira, kodiċi portabbli x'aktarx irid juża [`from_be_bytes`] jew [`from_le_bytes`], kif xieraq minflok.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Jirritorna ordni bejn valuri personali u valuri oħra.
    /// B'differenza mill-paragun parzjali standard bejn in-numri tal-punt varjabbli, dan il-paragun dejjem jipproduċi ordni skont il-predikat tal-Ordni totali kif definit fl-istandard tal-punt varjabbli IEEE 754 (reviżjoni tal-2008).
    /// Il-valuri huma ordnati fl-ordni li ġejja:
    /// - NaN kwiet negattiv
    /// - Sinjalazzjoni negattiva NaN
    /// - Infinità negattiva
    /// - Numri negattivi
    /// - Numri subnormali negattivi
    /// - Żero negattiv
    /// - Żero pożittiv
    /// - Numri subnormali pożittivi
    /// - Numri pożittivi
    /// - Infinità pożittiva
    /// - Sinjalazzjoni pożittiva NaN
    /// - NaN kwiet pożittiv
    ///
    /// Innota li din il-funzjoni mhux dejjem taqbel mal-implimentazzjonijiet [`PartialOrd`] u [`PartialEq`] ta `f32`.B'mod partikolari, huma jqisu żero negattiv u pożittiv bħala ugwali, filwaqt li `total_cmp` le.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Fil-każ ta 'negattivi, aqleb il-bits kollha minbarra s-sinjal biex tikseb tqassim simili bħall-interi komplementari ta' tnejn
        //
        // Għaliex jaħdem dan?Il-sufruni IEEE 754 jikkonsistu fi tliet oqsma:
        // Sinjal bit, esponent u mantissa.Is-sett ta 'esponenti u l-oqsma mantissa kollha kemm huma għandhom il-proprjetà li l-ordni bitwise tagħhom hija ugwali għall-kobor numeriku fejn il-kobor huwa definit.
        // Il-kobor mhux normalment definit fuq il-valuri NaN, iżda IEEE 754 totalOrder jiddefinixxi l-valuri NaN ukoll biex isegwi l-ordni bitwise.Dan iwassal għal ordni spjegata fil-kumment tad-dok.
        // Madankollu, ir-rappreżentazzjoni tal-kobor hija l-istess għal numri negattivi u pożittivi-il-bit tas-sinjal biss huwa differenti.
        // Biex inqabblu faċilment il-galleġġjanti bħala numri sħaħ iffirmati, għandna nqalbu l-esponent u l-bits mantissa f'każ ta 'numri negattivi.
        // Aħna effettivament nikkonvertu n-numri għall-forma "two's complement".
        //
        // Biex nagħmlu l-flipping, nibnu maskra u XOR kontriha.
        // Aħna nikkalkulaw mingħajr maskra maskra "all-ones except for the sign bit" minn valuri ffirmati negattivament: sinjal li jiċċaqlaq lejn il-lemin jestendi n-numru sħiħ, allura aħna "fill" il-maskra bil-bits tas-sinjal, u mbagħad nikkonvertu għal mhux iffirmat biex timbotta waħda aktar żero bit.
        //
        // Fuq valuri pożittivi, il-maskra hija kollha żerijiet, allura hija no-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Irrestrinġi valur għal ċertu intervall sakemm ma jkunx NaN.
    ///
    /// Jirritorna `max` jekk `self` huwa akbar minn `max`, u `min` jekk `self` huwa inqas minn `min`.
    /// Inkella dan jirritorna `self`.
    ///
    /// Innota li din il-funzjoni tirritorna NaN jekk il-valur inizjali kien NaN ukoll.
    ///
    /// # Panics
    ///
    /// Panics jekk `min > max`, `min` huwa NaN, jew `max` huwa NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}