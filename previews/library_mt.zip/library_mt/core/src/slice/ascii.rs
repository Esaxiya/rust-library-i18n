//! Operazzjonijiet fuq ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Jiċċekkja jekk il-bytes kollha f'din il-porzjon humiex fil-medda ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Jiċċekkja li żewġ flieli huma logħba ASCII li ma tissensibilizzax il-każijiet.
    ///
    /// L-istess bħal `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, iżda mingħajr ma talloka u tikkopja temporanji.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Ikkonverti din il-porzjon għall-ekwivalenti ASCII tagħha f'ittri kbar fil-post.
    ///
    /// Ittri ASCII 'a' sa 'z' huma mmappjati għal 'A' sa 'Z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tirritorna valur superjuri ġdid mingħajr ma timmodifika dak eżistenti, uża [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Ikkonverti din il-porzjon għall-ekwivalenti ASCII tagħha f'ittri żgħar fil-post.
    ///
    /// Ittri ASCII 'A' sa 'Z' huma mmappjati għal 'a' sa 'z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tirritorna valur ġdid b'ittri żgħar mingħajr ma timmodifika dak eżistenti, uża [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Jirritorna `true` jekk xi byte fil-kelma `v` huwa nonascii (>=128).
/// Snarfed minn `../str/mod.rs`, li jagħmel xi ħaġa simili għall-validazzjoni utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Test ASCII ottimizzat li se juża operazzjonijiet ta 'użu minn darba minflok operazzjonijiet ta' byte kull darba (meta jkun possibbli).
///
/// L-algoritmu li nużaw hawnhekk huwa pjuttost sempliċi.Jekk `s` huwa qasir wisq, aħna niċċekkjaw kull byte u nagħmlu bih.Inkella:
///
/// - Aqra l-ewwel kelma b'tagħbija mhux allinjata.
/// - Allinja l-pointer, aqra kliem sussegwenti sat-tmiem b'tagħbijiet allinjati.
/// - Aqra l-aħħar `usize` minn `s` b'tagħbija mhux allinjata.
///
/// Jekk xi waħda minn dawn it-tagħbijiet tipproduċi xi ħaġa li għaliha `contains_nonascii` (above) jirritorna vera, allura nafu li t-tweġiba hija falza.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Jekk aħna ma niksbu xejn mill-implimentazzjoni word-at-a-time, erġgħu lura għal linja skalar.
    //
    // Dan nagħmluh ukoll għal arkitetturi fejn `size_of::<usize>()` mhuwiex allinjament suffiċjenti għal `usize`, għax huwa każ stramb ta 'edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Aħna dejjem naqraw l-ewwel kelma mhux allinjata, li tfisser li `align_offset` hija
    // 0, konna naqraw mill-ġdid l-istess valur għall-qari allinjat.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SIGURTÀ: Aħna nivverifikaw `len < USIZE_SIZE` hawn fuq.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Aħna ċċekkjajna dan hawn fuq, kemmxejn impliċitament.
    // Innota li `offset_to_aligned` huwa jew `align_offset` jew `USIZE_SIZE`, it-tnejn li huma huma kkontrollati b'mod espliċitu hawn fuq.
    //
    debug_assert!(offset_to_aligned <= len);

    // SIGURTÀ: word_ptr huwa l-ptr użat (allinjat sewwa) li nużaw biex naqraw il-ptr
    // biċċa nofs tal-porzjon.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` huwa l-indiċi tal-byte ta `word_ptr`, użat għall-kontrolli tat-tarf tal-linja.
    let mut byte_pos = offset_to_aligned;

    // Iċċekkja l-paranojja dwar l-allinjament, peress li wasalna biex nagħmlu mazz ta 'tagħbijiet mhux allinjati.
    // Fil-prattika dan għandu jkun impossibbli ħlief bug f `align_offset` għalkemm.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Aqra kliem sussegwenti sa l-aħħar kelma allinjata, minbarra l-aħħar kelma allinjata waħedha li trid issir fil-verifika tad-denb aktar tard, biex tiżgura li denb huwa dejjem `usize` wieħed l-iktar għal branch `byte_pos == len` żejda.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanità iċċekkja li l-qari hu fil-limiti
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // U li l-assunzjonijiet tagħna dwar `byte_pos` għandhom.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SIGURTÀ: Nafu li `word_ptr` huwa allinjat sewwa (minħabba
        // "align_offset"), u nafu li għandna biżżejjed bytes bejn `word_ptr` u t-tmiem
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SIGURTÀ: Nafu dak `byte_pos <= len - USIZE_SIZE`, li jfisser dan
        // wara dan ix-`add`, `word_ptr` ikun l-iktar wieħed mill-aħħar.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Iċċekkja s-sanità biex tiżgura li fadal verament `usize` wieħed biss.
    // Dan għandu jkun garantit mill-kundizzjoni tal-linja tagħna.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SIGURTÀ: Dan jiddependi fuq `len >= USIZE_SIZE`, li aħna niċċekkjaw fil-bidu.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}