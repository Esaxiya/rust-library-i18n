// Implimentazzjoni oriġinali meħuda minn rust-memchr.
// Copyright 2015 Andrew Gallant, bluss u Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Uża truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Jirritorna `true` jekk `x` fih kwalunkwe byte żero.
///
/// Minn *Kwistjonijiet Komputazzjonali*, J. Arndt:
///
/// "L-idea hi li tnaqqas wieħed minn kull byte u mbagħad tfittex bytes fejn is-self propagat it-triq kollha sa l-iktar sinifikanti
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Jirritorna l-ewwel indiċi li jaqbel mal-byte `x` f `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Triq mgħaġġla għal flieli żgħar
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Skennja għal valur ta 'byte wieħed billi taqra żewġ kelmiet `usize` kull darba.
    //
    // Aqsam `text` fi tliet partijiet
    // - parti inizjali mhux allinjata, qabel l-ewwel indirizz tal-kelma allinjat fit-test
    // - ġisem, skennja bi 2 kelmiet kull darba
    // - l-aħħar parti li jifdal, <2 daqs tal-kelma

    // fittex sa konfini allinjati
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // fittex il-korp tat-test
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SIGURTÀ: il-predikat tal-waqt jiggarantixxi distanza ta 'mill-inqas 2 * usize_bytes
        // bejn l-offset u t-tarf tal-porzjon.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // pawża jekk hemm byte li jaqbel
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Sib il-byte wara l-punt li ċ-ċirku tal-ġisem waqaf.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Jirritorna l-aħħar indiċi li jaqbel mal-byte `x` f `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Skennja għal valur ta 'byte wieħed billi taqra żewġ kelmiet `usize` kull darba.
    //
    // Aqsam `text` fi tliet partijiet:
    // - denb mhux allinjat, wara l-aħħar kelma allinjata indirizz fit-test,
    // - korp, skannjat bi 2 kelmiet kull darba,
    // - l-ewwel bytes li jifdal, daqs ta '<2 kelma.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Aħna nsejħu dan biss biex niksbu t-tul tal-prefiss u s-suffiss.
        // Fin-nofs dejjem nipproċessaw żewġ biċċiet f'daqqa.
        // SIGURTÀ: it-trasmutazzjoni ta `[u8]` għal `[usize]` hija sigura ħlief għad-differenzi fid-daqs li huma mmaniġġjati minn `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Fittex fil-korp tat-test, kun żgur li ma naqsmux min_aligned_offset.
    // l-offset huwa dejjem allinjat, allura l-ittestjar `>` biss huwa biżżejjed u jevita overflow possibbli.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SIGURTÀ: l-offset jibda minn len, suffix.len(), sakemm ikun akbar minn
        // min_aligned_offset (prefix.len()) id-distanza li jifdal hija mill-inqas 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Kisser jekk hemm byte li jaqbel.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Sib il-byte qabel il-punt li ċ-ċirku tal-ġisem waqaf.
    text[..offset].iter().rposition(|elt| *elt == x)
}