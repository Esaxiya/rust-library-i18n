//! Funzjonijiet b'xejn biex toħloq `&[T]` u `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Jifforma porzjon minn pointer u tul.
///
/// L-argument `len` huwa n-numru ta '**elementi**, mhux in-numru ta' bytes.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `data` għandu jkun [valid] għal qari għal `len * mem::size_of::<T>()` ħafna bytes, u għandu jkun allinjat sewwa.Dan ifisser b'mod partikolari:
///
///     * Il-firxa sħiħa tal-memorja ta 'din il-porzjon għandha tkun f'oġġett wieħed allokat!
///       Slices qatt ma jistgħu jinfirxu fuq oġġetti allokati multipli.Ara [below](#incorrect-usage) għal eżempju ħażin li ma jqisx dan.
///     * `data` m'għandux ikun null u allinjat anke għal flieli ta 'tul żero.
///     Raġuni waħda għal dan hija li l-ottimizzazzjonijiet tat-tqassim tal-enum jistgħu jiddependu fuq referenzi (inklużi flieli ta 'kwalunkwe tul) li jkunu allinjati u mhux nulli biex tiddistingwihom minn dejta oħra.
///     Tista 'tikseb pointer li jista' jintuża bħala `data` għal flieli ta 'tul żero billi tuża [`NonNull::dangling()`].
///
/// * `data` għandu jindika lejn `len` valuri konsekuttivi inizjalizzati kif suppost tat-tip `T`.
///
/// * Il-memorja referenzjata mill-porzjon ritornat m'għandhiex tkun immutata għat-tul tal-ħajja `'a`, ħlief ġewwa `UnsafeCell`.
///
/// * Id-daqs totali `len * mem::size_of::<T>()` tal-porzjon m'għandux ikun akbar minn `isize::MAX`.
///   Ara d-dokumentazzjoni tas-sigurtà ta [`pointer::offset`].
///
/// # Caveat
///
/// Il-ħajja għall-porzjon ritornat hija dedotta mill-użu tagħha.
/// Biex jiġi evitat użu ħażin aċċidentali, huwa ssuġġerit li l-ħajja tintrabat ma 'liema sors ta' ħajja huwa sigur fil-kuntest, bħal billi tipprovdi funzjoni helper li tieħu l-ħajja ta 'valur ospitanti għall-porzjon, jew b'annotazzjoni espliċita.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifest porzjon għal element wieħed
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Użu mhux korrett
///
/// Il-funzjoni `join_slices` li ġejja hija **mhux tajba** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // L-affermazzjoni ta 'hawn fuq tiżgura li `fst` u `snd` huma kontigwi, iżda xorta jistgħu jkunu jinsabu fi ħdan _different allocated objects_, f'liema każ il-ħolqien ta' din il-porzjon huwa mġieba mhux definita.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` u `b` huma oġġetti allokati differenti ...
///     let a = 42;
///     let b = 27;
///     // ... li madankollu jista 'jkun imqiegħed b'mod kontigwu fil-memorja: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Twettaq l-istess funzjonalità bħal [`from_raw_parts`], ħlief li porzjon li jista 'jinbidel jiġi rritornat.
///
/// # Safety
///
/// L-imġieba mhix definita jekk tinkiser xi waħda mill-kundizzjonijiet li ġejjin:
///
/// * `data` għandu jkun [valid] kemm għal qari kif ukoll għal kitba għal `len * mem::size_of::<T>()` ħafna bytes, u għandu jkun allinjat sewwa.Dan ifisser b'mod partikolari:
///
///     * Il-firxa sħiħa tal-memorja ta 'din il-porzjon għandha tkun f'oġġett wieħed allokat!
///       Slices qatt ma jistgħu jinfirxu fuq oġġetti allokati multipli.
///     * `data` m'għandux ikun null u allinjat anke għal flieli ta 'tul żero.
///     Raġuni waħda għal dan hija li l-ottimizzazzjonijiet tat-tqassim tal-enum jistgħu jiddependu fuq referenzi (inklużi flieli ta 'kwalunkwe tul) li jkunu allinjati u mhux nulli biex tiddistingwihom minn dejta oħra.
///
///     Tista 'tikseb pointer li jista' jintuża bħala `data` għal flieli ta 'tul żero billi tuża [`NonNull::dangling()`].
///
/// * `data` għandu jindika lejn `len` valuri konsekuttivi inizjalizzati kif suppost tat-tip `T`.
///
/// * Il-memorja referenzjata mill-porzjon ritornat m'għandhiex tkun aċċessata permezz ta 'xi pointer ieħor (mhux derivat mill-valur ta' ritorn) għat-tul ta 'ħajja `'a`.
///   Kemm l-aċċess għall-qari kif ukoll għall-kitba huma pprojbiti.
///
/// * Id-daqs totali `len * mem::size_of::<T>()` tal-porzjon m'għandux ikun akbar minn `isize::MAX`.
///   Ara d-dokumentazzjoni tas-sigurtà ta [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIGURTÀ: min iċempel għandu jżomm il-kuntratt ta 'sigurtà għal `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Ikkonverti referenza għal T fi porzjon ta 'tul 1 (mingħajr ma tikkopja).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Ikkonverti referenza għal T fi porzjon ta 'tul 1 (mingħajr ma tikkopja).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}