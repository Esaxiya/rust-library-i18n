//! Issortjar tal-porzjon
//!
//! Dan il-modulu fih algoritmu ta 'għażla bbażat fuq il-quicksort ta' Orson Peters li jegħleb il-mudell, ippubblikat fuq: <https://github.com/orlp/pdqsort>
//!
//!
//! Issortjar instabbli huwa kompatibbli ma 'libcore minħabba li ma jallokax memorja, b'differenza mill-implimentazzjoni stabbli tagħna ta' għażla.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Meta niżel, kopji minn `src` għal `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SIGURTÀ: Din hija klassi helper.
        //          Jekk jogħġbok irreferi għall-użu tiegħu għall-korrettezza.
        //          Jiġifieri, wieħed għandu jkun ċert li `src` u `dst` ma jikkoinċidux kif meħtieġ minn `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Iċċaqlaq l-ewwel element lejn il-lemin sakemm jiltaqa 'ma' element ikbar jew ugwali.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURTÀ: L-operazzjonijiet mhux siguri hawn taħt jinvolvu indiċjar mingħajr kontroll marbut (`get_unchecked` u `get_unchecked_mut`)
    // u l-ikkupjar tal-memorja (`ptr::copy_nonoverlapping`).
    //
    // a.Indiċjar:
    //  1. Aħna ċċekkjajna d-daqs tal-firxa għal>=2.
    //  2. L-indiċjar kollu li se nagħmlu huwa dejjem l-iktar bejn {0 <= index < len}.
    //
    // b.Ikkupjar tal-memorja
    //  1. Aħna qed niksbu indikazzjonijiet għal referenzi li huma garantiti li jkunu validi.
    //  2. Ma jistgħux jikkoinċidu għax niksbu indikaturi għad-differenza fl-indiċi tal-porzjon.
    //     Jiġifieri, `i` u `i-1`.
    //  3. Jekk il-porzjon huwa allinjat sewwa, l-elementi huma allinjati sewwa.
    //     Hija r-responsabbiltà ta 'min iċempel li jiżgura li l-porzjon ikun allinjat sewwa.
    //
    // Ara l-kummenti hawn taħt għal aktar dettall.
    unsafe {
        // Jekk l-ewwel żewġ elementi huma barra mill-ordni ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Aqra l-ewwel element f'varjabbli allokat f'munzell.
            // Jekk operazzjoni ta 'paragun li ġejja panics, `hole` tinżel u awtomatikament tikteb l-element lura fil-porzjon.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Mexxi l-element 'i`-th post wieħed lejn ix-xellug, u b'hekk iċċaqlaq it-toqba lejn il-lemin.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` jitwaqqa 'u b'hekk jikkopja `tmp` fit-toqba li jifdal f `v`.
        }
    }
}

/// Iċċaqlaq l-aħħar element lejn ix-xellug sakemm jiltaqa 'ma' element iżgħar jew ugwali.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIGURTÀ: L-operazzjonijiet mhux siguri hawn taħt jinvolvu indiċjar mingħajr kontroll marbut (`get_unchecked` u `get_unchecked_mut`)
    // u l-ikkupjar tal-memorja (`ptr::copy_nonoverlapping`).
    //
    // a.Indiċjar:
    //  1. Aħna ċċekkjajna d-daqs tal-firxa għal>=2.
    //  2. L-indiċjar kollu li se nagħmlu huwa dejjem l-iktar bejn `0 <= index < len-1`.
    //
    // b.Ikkupjar tal-memorja
    //  1. Aħna qed niksbu indikazzjonijiet għal referenzi li huma garantiti li jkunu validi.
    //  2. Ma jistgħux jikkoinċidu għax niksbu indikaturi għad-differenza fl-indiċi tal-porzjon.
    //     Jiġifieri, `i` u `i+1`.
    //  3. Jekk il-porzjon huwa allinjat sewwa, l-elementi huma allinjati sewwa.
    //     Hija r-responsabbiltà ta 'min iċempel li jiżgura li l-porzjon ikun allinjat sewwa.
    //
    // Ara l-kummenti hawn taħt għal aktar dettall.
    unsafe {
        // Jekk l-aħħar żewġ elementi huma barra mill-ordni ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Aqra l-aħħar element f'varjabbli allokat f'munzell.
            // Jekk operazzjoni ta 'paragun li ġejja panics, `hole` tinżel u awtomatikament tikteb l-element lura fil-porzjon.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Mexxi 'i`-th element post wieħed lejn il-lemin, u b'hekk iċċaqlaq it-toqba lejn ix-xellug.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` jitwaqqa 'u b'hekk jikkopja `tmp` fit-toqba li jifdal f `v`.
        }
    }
}

/// Jissortja parzjalment porzjon billi ċċaqlaq diversi elementi barra mill-ordni madwarhom.
///
/// Jirritorna `true` jekk il-porzjon ikun issortjat fl-aħħar.Din il-funzjoni hija l-agħar każ *O*(*n*).
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Numru massimu ta 'pari barra mill-ordni li jmissu magħhom li jinbidlu.
    const MAX_STEPS: usize = 5;
    // Jekk il-porzjon huwa iqsar minn dan, tbiddel l-ebda element.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SIGURTÀ: Aħna diġà għamilna b'mod espliċitu l-iċċekkjar marbut ma `i < len`.
        // L-indiċjar sussegwenti kollu tagħna huwa biss fil-medda `0 <= index < len`
        unsafe {
            // Sib il-par li jmiss ta 'elementi barra mill-ordni li jmissu magħhom.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Aħna lesti?
        if i == len {
            return true;
        }

        // Tbiddilx elementi fuq matriċi qosra, li għandhom spejjeż ta 'prestazzjoni.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Ibdel il-par ta 'elementi misjub.Dan ipoġġihom f'ordni korretta.
        v.swap(i - 1, i);

        // Aqleb l-element iżgħar lejn ix-xellug.
        shift_tail(&mut v[..i], is_less);
        // Aqleb l-element ikbar lejn il-lemin.
        shift_head(&mut v[i..], is_less);
    }

    // Ma rnexxilekx issolvi l-porzjon fin-numru limitat ta 'passi.
    false
}

/// Issortja porzjon billi tuża tip ta 'inserzjoni, li huwa l-agħar każ *O*(*n*^ 2).
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Issortja `v` billi tuża heapsort, li tiggarantixxi *O*(*n*\*log(* n*)) fl-agħar każ.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Dan il-borġ binarju jirrispetta l-invariant `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Tfal ta `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Agħżel it-tifel l-akbar.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Waqqaf jekk l-invariant iżomm f `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Ibdel `node` mat-tifel l-ikbar, imxi pass 'l isfel, u kompli tgħarbel.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Ibni l-borġ f'ħin lineari.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop elementi massimi mill-borġ.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Taqsam `v` f'elementi iżgħar minn `pivot`, segwiti minn elementi akbar minn jew ugwali għal `pivot`.
///
///
/// Jirritorna n-numru ta 'elementi iżgħar minn `pivot`.
///
/// It-tqassim isir blokk bi blokka sabiex titnaqqas kemm jista 'jkun l-ispiża tal-operazzjonijiet ta' fergħat.
/// Din l-idea hija ppreżentata fil-karta [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Numru ta 'elementi fi blokka tipika.
    const BLOCK: usize = 128;

    // L-algoritmu tat-tqassim jirrepeti l-passi li ġejjin sat-tlestija:
    //
    // 1. Traċċa blokka min-naħa tax-xellug biex tidentifika elementi akbar minn jew ugwali għall-pern.
    // 2. Traċċa blokka min-naħa tal-lemin biex tidentifika elementi iżgħar mill-pern.
    // 3. Ibdel l-elementi identifikati bejn in-naħa tax-xellug u tal-lemin.
    //
    // Aħna nżommu l-varjabbli li ġejjin għal blokka ta 'elementi:
    //
    // 1. `block` - Numru ta 'elementi fil-blokka.
    // 2. `start` - Ibda l-pointer fil-firxa `offsets`.
    // 3. `end` - End pointer fil-firxa `offsets`.
    // 4. `offsets, Indiċi ta 'elementi barra mill-ordni fil-blokka.

    // Il-blokka kurrenti fuq in-naħa tax-xellug (minn `l` sa `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Il-blokka kurrenti fuq il-lemin (minn `r.sub(block_r)` to `r`).
    // SIGURTÀ: Id-dokumentazzjoni għal .add() issemmi speċifikament li `vec.as_ptr().add(vec.len())` huwa dejjem sigur '
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Meta jkollna VLAs, ipprova toħloq firxa waħda ta 'tul `min(v.len(), 2 * BLOCK) `pjuttost
    // minn żewġ matriċi ta 'daqs fiss ta' tul `BLOCK`.Il-VLAs jistgħu jkunu aktar effiċjenti fil-cache.

    // Jirritorna n-numru ta 'elementi bejn il-pointers `l` (inclusive) u `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Aħna lesti bil-partizzjoni blokk bi blokka meta `l` u `r` jersqu viċin ħafna.
        // Imbagħad nagħmlu xi xogħol ta 'patch-up sabiex inqassmu l-elementi li jifdal bejniethom.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Numru ta 'elementi li jifdal (għadu mhux imqabbel mal-pern).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Aġġusta d-daqsijiet tal-blokka sabiex il-blokka tax-xellug u tal-lemin ma jikkoinċidux, imma tkun allinjata perfettament biex tkopri l-vojt li jifdal kollu.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Traċċa l-elementi `block_l` min-naħa tax-xellug.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SIGURTÀ: L-operazzjonijiet mhux siguri hawn taħt jinvolvu l-użu tax-`offset`.
                //         Skond il-kondizzjonijiet meħtieġa mill-funzjoni, aħna nissodisfawhom għax:
                //         1. `offsets_l` huwa allokat f'munzelli, u għalhekk meqjus bħala oġġett separat allokat.
                //         2. Il-funzjoni `is_less` tirritorna `bool`.
                //            It-tfigħ ta `bool` qatt ma jisboq `isize`.
                //         3. Aħna garantit li `block_l` se jkun `<= BLOCK`.
                //            Barra minn hekk, `end_l` kien inizjalment issettjat għall-bidu tal-pointer ta `offsets_` li ġie ddikjarat fuq il-munzell.
                //            Għalhekk, nafu li anke fl-agħar każ (l-invokazzjonijiet kollha ta `is_less` jirritornaw foloz) inkunu biss l-iktar b'1 byte ngħaddu t-tmiem.
                //        Operazzjoni oħra ta 'sigurtà hawnhekk hija t-tneħħija ta' referenza għal `elem`.
                //        Madankollu, `elem` kien inizjalment il-pointer tal-bidu għall-porzjon li huwa dejjem validu.
                unsafe {
                    // Paragun mingħajr fergħat.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Traċċa l-elementi `block_r` min-naħa tal-lemin.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SIGURTÀ: L-operazzjonijiet mhux siguri hawn taħt jinvolvu l-użu tax-`offset`.
                //         Skond il-kondizzjonijiet meħtieġa mill-funzjoni, aħna nissodisfawhom għax:
                //         1. `offsets_r` huwa allokat f'munzelli, u għalhekk meqjus bħala oġġett separat allokat.
                //         2. Il-funzjoni `is_less` tirritorna `bool`.
                //            It-tfigħ ta `bool` qatt ma jisboq `isize`.
                //         3. Aħna garantit li `block_r` se jkun `<= BLOCK`.
                //            Barra minn hekk, `end_r` kien inizjalment issettjat għall-bidu tal-pointer ta `offsets_` li ġie ddikjarat fuq il-munzell.
                //            Għalhekk, nafu li anke fl-agħar każ (l-invokazzjonijiet kollha ta `is_less` jirritornaw vera) inkunu l-iktar b'1 byte li ngħaddu t-tmiem.
                //        Operazzjoni oħra ta 'sigurtà hawnhekk hija t-tneħħija ta' referenza għal `elem`.
                //        Madankollu, `elem` kien inizjalment `1 *sizeof(T)` wara t-tmiem u aħna nnaqqsuh minn `1* sizeof(T)` qabel ma nidħlu għalih.
                //        Barra minn hekk, `block_r` ġie affermat li huwa inqas minn `BLOCK` u `elem` għalhekk l-iktar ikun qed jindika l-bidu tal-porzjon.
                unsafe {
                    // Paragun mingħajr fergħat.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Numru ta 'elementi mhux ordnati li għandhom jinbidlu bejn in-naħa tax-xellug u tal-lemin.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Minflok tpartat par wieħed dak il-ħin, huwa iktar effiċjenti li twettaq permutazzjoni ċiklika.
            // Dan mhux strettament ekwivalenti għal tpartit, iżda jipproduċi riżultat simili billi juża inqas operazzjonijiet tal-memorja.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // L-elementi kollha barra mill-ordni fil-blokka tax-xellug ġew imċaqalqa.Mexxi għall-blokka li jmiss.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // L-elementi kollha barra mill-ordni fil-blokka tal-lemin ġew imċaqalqa.Mexxi għall-blokka preċedenti.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Dak kollu li jibqa 'issa huwa l-iktar blokka waħda (jew ix-xellug jew il-lemin) b'elementi barra mill-ordni li għandhom jiġu mċaqalqa.
    // Elementi li jifdal bħal dawn jistgħu sempliċement jiġu mċaqilqa għall-aħħar fil-blokka tagħhom.
    //

    if start_l < end_l {
        // Il-blokka tax-xellug tibqa '.
        // Mexxi l-elementi li jifdal barra mill-ordni tiegħu lejn il-lemin estrem.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Il-blokka t-tajba tibqa '.
        // Mexxi l-elementi li jifdal barra mill-ordni tiegħu lejn ix-xellug.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Xejn ieħor li nagħmlu, aħna lesti.
        width(v.as_mut_ptr(), l)
    }
}

/// Taqsam `v` f'elementi iżgħar minn `v[pivot]`, segwiti minn elementi akbar minn jew ugwali għal `v[pivot]`.
///
///
/// Jirritorna tupla ta ':
///
/// 1. Numru ta 'elementi iżgħar minn `v[pivot]`.
/// 2. Veru jekk `v` kien diġà maqsum.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Poġġi l-pern fil-bidu tal-porzjon.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Aqra l-pern f'varjabbli allokat f'munzelli għall-effiċjenza.
        // Jekk operazzjoni ta 'paragun li ġejja panics, il-pern jinkiteb awtomatikament lura fil-porzjon.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Sib l-ewwel par ta 'elementi barra mill-ordni.
        let mut l = 0;
        let mut r = v.len();

        // SIGURTÀ: In-nuqqas ta 'sigurtà hawn taħt jinvolvi indiċjar ta' firxa.
        // Għall-ewwel waħda: Aħna diġà nagħmlu l-limiti li niċċekkjaw hawn b `l < r`.
        // Għat-tieni waħda: Inizjalment għandna `l == 0` u `r == v.len()` u ċċekkjajna dak `l < r` f'kull operazzjoni ta 'indiċjar.
        //                     Minn hawn nafu li `r` għandu jkun mill-inqas `r == l` li ntwera li huwa validu mill-ewwel wieħed.
        unsafe {
            // Sib l-ewwel element ikbar minn jew ugwali għall-pern.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Sib l-aħħar element iżgħar mill-pern.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` joħroġ mill-ambitu u jikteb il-pern (li huwa varjabbli allokat f'munzell) lura fil-porzjon fejn kien oriġinarjament.
        // Dan il-pass huwa kritiku biex tkun żgurata s-sigurtà!
        //
    };

    // Poġġi l-pern bejn iż-żewġ diviżorji.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Taqsam `v` f'elementi ugwali għal `v[pivot]` segwit minn elementi akbar minn `v[pivot]`.
///
/// Jirritorna n-numru ta 'elementi ugwali għall-pern.
/// Huwa preżunt li `v` ma fihx elementi iżgħar mill-pern.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Poġġi l-pern fil-bidu tal-porzjon.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Aqra l-pern f'varjabbli allokat f'munzelli għall-effiċjenza.
    // Jekk operazzjoni ta 'paragun li ġejja panics, il-pern jinkiteb awtomatikament lura fil-porzjon.
    // SIGURTÀ: Il-pointer hawnhekk huwa validu minħabba li jinkiseb minn referenza għal porzjon.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Issa taqsam il-porzjon.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SIGURTÀ: In-nuqqas ta 'sigurtà hawn taħt jinvolvi indiċjar ta' firxa.
        // Għall-ewwel waħda: Aħna diġà nagħmlu l-limiti li niċċekkjaw hawn b `l < r`.
        // Għat-tieni waħda: Inizjalment għandna `l == 0` u `r == v.len()` u ċċekkjajna dak `l < r` f'kull operazzjoni ta 'indiċjar.
        //                     Minn hawn nafu li `r` għandu jkun mill-inqas `r == l` li ntwera li huwa validu mill-ewwel wieħed.
        unsafe {
            // Sib l-ewwel element akbar mill-pern.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Sib l-aħħar element daqs il-pern.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Aħna lesti?
            if l >= r {
                break;
            }

            // Ibdel il-par misjub ta 'elementi barra mill-ordni.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Sibna elementi `l` daqs il-pern.Żid 1 biex tagħti kont tal-pern innifsu.
    l + 1

    // `_pivot_guard` joħroġ mill-ambitu u jikteb il-pern (li huwa varjabbli allokat f'munzell) lura fil-porzjon fejn kien oriġinarjament.
    // Dan il-pass huwa kritiku biex tkun żgurata s-sigurtà!
}

/// Ixerred xi elementi madwar f'tentattiv biex jiksru xejriet li jistgħu jikkawżaw diviżjonijiet żbilanċjati fil-quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Ġeneratur tan-numri psewdo-każwali mill-karta "Xorshift RNGs" minn George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Ħu numri każwali modulo dan in-numru.
        // In-numru jidħol f `usize` għax `len` mhuwiex akbar minn `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Xi kandidati pivot se jkunu fil-viċin ta 'dan l-indiċi.Ejja nagħżluhom b'mod każwali.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Iġġenera numru każwali modulo `len`.
            // Madankollu, sabiex nevitaw operazzjonijiet li jiswew ħafna flus l-ewwel neħduh modulo qawwa ta 'tnejn, u mbagħad innaqqsu b `len` sakemm tidħol fil-medda `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` huwa garantit li jkun inqas minn `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Jagħżel pern f `v` u jirritorna l-indiċi u `true` jekk il-porzjon x'aktarx ikun diġà magħżul.
///
/// Elementi f `v` jistgħu jiġu ordnati mill-ġdid fil-proċess.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Tul minimu biex tagħżel il-metodu medjan tal-medjani.
    // Slices iqsar jużaw il-metodu sempliċi medjan ta 'tlieta.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Numru massimu ta 'swaps li jistgħu jitwettqu f'din il-funzjoni.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tliet indiċi viċin li se nagħżlu pern.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Jgħodd in-numru totali ta 'swaps li ser nagħmlu waqt li nagħżlu l-indiċi.
    let mut swaps = 0;

    if len >= 8 {
        // Swaps indiċi sabiex `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Swaps indiċi sabiex `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Issib il-medjan ta `v[a - 1], v[a], v[a + 1]` u jaħżen l-indiċi f `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Sib medjani fil-viċinanzi ta `a`, `b`, u `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Sib il-medjan fost `a`, `b`, u `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // In-numru massimu ta 'swaps twettaq.
        // Iċ-ċansijiet huma li l-porzjon ikun dixxendenti jew l-aktar dixxendenti, allura r-rivers probabbilment jgħin biex tissolvaha aktar malajr.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Issortja `v` rikursivament.
///
/// Jekk il-porzjon kellu predeċessur fil-firxa oriġinali, huwa speċifikat bħala `pred`.
///
/// `limit` huwa n-numru ta 'ħitan żbilanċjati permessi qabel ma taqleb għal `heapsort`.
/// Jekk żero, din il-funzjoni tinbidel immedjatament għal heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Flieli sa dan it-tul jiġu magħżula bl-użu ta 'tip ta' inserzjoni.
    const MAX_INSERTION: usize = 20;

    // Veru jekk l-aħħar tqassim kien raġonevolment ibbilanċjat.
    let mut was_balanced = true;
    // Veru jekk l-aħħar tqassim ma ħalliex elementi (il-porzjon kien diġà maqsum).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Flieli qosra ħafna jiġu magħżula bl-użu ta 'tip ta' inserzjoni.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Jekk saru wisq għażliet ta 'pern ħżiena, sempliċement erġa' lura għal heapsort sabiex tiggarantixxi `O(n * log(n))` fl-agħar każ.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Jekk l-aħħar tqassim kien żbilanċjat, ipprova tkisser il-mudelli fil-porzjon billi tħawwad xi elementi madwar.
        // Nisperaw li aħna nagħżlu pern aħjar din id-darba.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Agħżel pern u pprova aqta 'jekk il-porzjon huwiex diġà magħżul.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Jekk l-aħħar tqassim kien ibbilanċjat b'mod deċenti u ma ħallatx elementi, u jekk l-għażla tal-pern tbassar li l-porzjon x'aktarx ikun diġà magħżul ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Ipprova identifika diversi elementi barra mill-ordni u ċċaqlaqhom għal pożizzjonijiet korretti.
            // Jekk il-porzjon jispiċċa magħżul kompletament, aħna lesti.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Jekk il-pern magħżul huwa daqs il-predeċessur, allura huwa l-iżgħar element fil-porzjon.
        // Aqsam il-porzjon f'elementi daqs u elementi akbar mill-pern.
        // Dan il-każ ġeneralment jintlaqat meta l-porzjon ikun fih ħafna elementi duplikati.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Kompli issortja elementi akbar mill-pern.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Aqsam il-porzjon.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Aqsam il-porzjon f `left`, `pivot`, u `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Erġa 'lura fin-naħa l-iqsar biss sabiex tnaqqas in-numru totali ta' sejħiet rikursivi u tikkonsma inqas spazju tal-munzell.
        // Imbagħad kompli bil-ġenb itwal (dan huwa simili għar-rikursjoni tad-denb).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Issortja `v` billi tuża quicksort li jegħleb il-mudell, li huwa *O*(*n*\*log(* n*)) fl-agħar każ.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // L-issortjar m'għandux imġieba sinifikanti fuq tipi ta 'daqs żero.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Limita n-numru ta 'ħitan żbilanċjati għal `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Għal flieli sa dan it-tul huwa probabbilment aktar mgħaġġel li sempliċement issortjahom.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Agħżel pern
        let (pivot, _) = choose_pivot(v, is_less);

        // Jekk il-pern magħżul huwa daqs il-predeċessur, allura huwa l-iżgħar element fil-porzjon.
        // Aqsam il-porzjon f'elementi daqs u elementi akbar mill-pern.
        // Dan il-każ ġeneralment jintlaqat meta l-porzjon ikun fih ħafna elementi duplikati.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Jekk għaddejna l-indiċi tagħna, allura aħna tajbin.
                if mid > index {
                    return;
                }

                // Inkella, kompli issortja elementi akbar mill-pern.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Aqsam il-porzjon f `left`, `pivot`, u `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Jekk indiċi==nofs, allura aħna lesti, peress li partition() garantit li l-elementi kollha wara nofs huma akbar minn jew ugwali għal nofs.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // L-issortjar m'għandux imġieba sinifikanti fuq tipi ta 'daqs żero.Taghmel xejn.
    } else if index == v.len() - 1 {
        // Sib element massimu u poġġih fl-aħħar pożizzjoni tal-firxa.
        // Aħna liberi li nużaw `unwrap()` hawn għax nafu li v m'għandux ikun vojt.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Sib element min u poġġih fl-ewwel pożizzjoni tal-firxa.
        // Aħna liberi li nużaw `unwrap()` hawn għax nafu li v m'għandux ikun vojt.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}