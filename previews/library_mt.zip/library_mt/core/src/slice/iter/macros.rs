//! Makros użati minn iteraturi ta 'porzjon.

// L-inlining is_empty u len jagħmel differenza kbira fil-prestazzjoni
macro_rules! is_empty {
    // Il-mod kif nikkodifikaw it-tul ta 'iteratur ZST, dan jaħdem kemm għal ZST kif ukoll għal mhux ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Biex teħles minn xi kontrolli tal-limiti (ara `position`), aħna nikkalkulaw it-tul b'mod kemmxejn mhux mistenni.
// (Ittestjat minn 'codegen/slice-position-limits-check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // kultant aħna nintużaw fi blokka mhux sigura

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Dan ix-_cannot_ juża `unchecked_sub` għax aħna niddependu fuq it-tgeżwir biex nirrappreżentaw it-tul ta 'iteraturi twal tas-slice ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Nafu li `start <= end`, allura jista 'jagħmel aħjar minn `offset_from`, li għandu bżonn jittratta ffirmat.
            // Billi nistabbilixxu bnadar xierqa hawn nistgħu ngħidu lil LLVM dan, li jgħinha tneħħi l-kontrolli tal-limiti.
            // SIGURTÀ: Bit-tip invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Billi tgħid ukoll lil LLVM li l-indikaturi huma separati minn multiplu eżatt tad-daqs tat-tip, jista 'jottimizza `len() == 0` sa `start == end` minflok `(end - start) < size`.
            //
            // SIGURTÀ: Bit-tip invariant, l-indikaturi huma allinjati b'tali mod li
            //         id-distanza bejniethom trid tkun multiplu tad-daqs tal-pointee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Id-definizzjoni komuni tal-iteraturi `Iter` u `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Jirritorna l-ewwel element u jċaqlaq il-bidu tal-iteratur 'il quddiem b'1.
        // Ittejjeb ħafna l-prestazzjoni meta mqabbla ma 'funzjoni inlinjata.
        // L-iteratur m'għandux ikun vojt.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Jirritorna l-aħħar element u jmexxi t-tarf tal-iteratur lura b'1.
        // Ittejjeb ħafna l-prestazzjoni meta mqabbla ma 'funzjoni inlinjata.
        // L-iteratur m'għandux ikun vojt.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Iċċekken l-iteratur meta T huwa ZST, billi tmexxi t-tarf ta 'l-iteratur lura b `n`.
        // `n` m'għandux jeċċedi `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Funzjoni helper għall-ħolqien ta 'porzjon mill-iteratur.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SIGURTÀ: l-iteratur inħoloq minn porzjon bil-pointer
                // `self.ptr` u t-tul `len!(self)`.
                // Dan jiggarantixxi li l-prerekwiżiti kollha għal `from_raw_parts` huma sodisfatti.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Funzjoni helper biex tmexxi l-bidu ta 'l-iteratur' il quddiem minn elementi `offset`, u tirritorna l-bidu l-qadim.
            //
            // Mhux sikur minħabba li l-offset m'għandux jaqbeż `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SIGURTÀ: min iċempel jiggarantixxi li `offset` ma jaqbiżx `self.len()`,
                    // għalhekk dan il-pointer il-ġdid jinsab ġewwa `self` u għalhekk garantit li mhux null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Funzjoni helper biex iċċaqlaq it-tarf ta 'l-iteratur lura b'elementi `offset`, u tirritorna t-tarf il-ġdid.
            //
            // Mhux sikur minħabba li l-offset m'għandux jaqbeż `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SIGURTÀ: min iċempel jiggarantixxi li `offset` ma jaqbiżx `self.len()`,
                    // li huwa garantit li ma tfur `isize`.
                    // Ukoll, il-pointer li jirriżulta jinsab fil-limiti ta `slice`, li jissodisfa r-rekwiżiti l-oħra għal `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // jistgħu jiġu implimentati bi flieli, iżda dan jevita l-kontrolli tal-limiti

                // SIGURTÀ: Is-sejħiet `assume` huma siguri peress li l-pointer tal-bidu tal-porzjon
                // għandu jkun mhux null, u slices over non-ZSTs għandu jkollhom ukoll pointer tat-tarf mhux null.
                // Is-sejħa għal `next_unchecked!` hija sigura peress li aħna niċċekkjaw jekk l-iteratur huwiex vojt l-ewwel.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dan l-iteratur issa huwa vojt.
                    if mem::size_of::<T>() == 0 {
                        // Irridu nagħmlu dan hekk kif `ptr` jista 'qatt ma jkun 0, iżda `end` jista' jkun (minħabba t-tgeżwir).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SIGURTÀ: tmiem ma jistax ikun 0 jekk T mhuwiex ZST għax ptr mhuwiex 0 u tmiem>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SIGURTÀ: Aħna fil-limiti.`post_inc_start` jagħmel it-tajjeb anke għaż-ZSTs.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Aħna nipprevalu l-implimentazzjoni awtomatika, li tuża `try_fold`, minħabba li din l-implimentazzjoni sempliċi tiġġenera inqas LLVM IR u hija aktar mgħaġġla biex tinġabar.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Aħna nipprevalu l-implimentazzjoni awtomatika, li tuża `try_fold`, minħabba li din l-implimentazzjoni sempliċi tiġġenera inqas LLVM IR u hija aktar mgħaġġla biex tinġabar.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Aħna nipprevalu l-implimentazzjoni awtomatika, li tuża `try_fold`, minħabba li din l-implimentazzjoni sempliċi tiġġenera inqas LLVM IR u hija aktar mgħaġġla biex tinġabar.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Aħna nipprevalu l-implimentazzjoni awtomatika, li tuża `try_fold`, minħabba li din l-implimentazzjoni sempliċi tiġġenera inqas LLVM IR u hija aktar mgħaġġla biex tinġabar.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Aħna nipprevalu l-implimentazzjoni awtomatika, li tuża `try_fold`, minħabba li din l-implimentazzjoni sempliċi tiġġenera inqas LLVM IR u hija aktar mgħaġġla biex tinġabar.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Aħna nipprevalu l-implimentazzjoni awtomatika, li tuża `try_fold`, minħabba li din l-implimentazzjoni sempliċi tiġġenera inqas LLVM IR u hija aktar mgħaġġla biex tinġabar.
            // Ukoll, ix-`assume` jevita kontroll tal-limiti.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SIGURTÀ: aħna garantiti li ninsabu fil-limiti mill-linja invariant:
                        // meta `i >= n`, `self.next()` jirritorna `None` u l-linja tinqasam.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Aħna nipprevalu l-implimentazzjoni awtomatika, li tuża `try_fold`, minħabba li din l-implimentazzjoni sempliċi tiġġenera inqas LLVM IR u hija aktar mgħaġġla biex tinġabar.
            // Ukoll, ix-`assume` jevita kontroll tal-limiti.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SIGURTÀ: `i` għandu jkun inqas minn `n` peress li jibda minn `n`
                        // u qed tonqos biss.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SIGURTÀ: min iċempel għandu jiggarantixxi li `i` jinsab fil-limiti ta '
                // il-porzjon sottostanti, allura `i` ma jistax ifur `isize`, u r-referenzi mibgħuta lura huma garantiti li jirreferu għal element tal-porzjon u għalhekk garantiti li jkunu validi.
                //
                // Innota wkoll li min iċempel jiggarantixxi wkoll li aħna qatt ma nissejħu bl-istess indiċi, u li ma jissejħu l-ebda metodi oħra li se jkollhom aċċess għal din is-sub-porzjon, u għalhekk huwa validu li r-referenza mibgħuta lura tkun tista 'tinbidel fil-każ ta'
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // jistgħu jiġu implimentati bi flieli, iżda dan jevita l-kontrolli tal-limiti

                // SIGURTÀ: Is-sejħiet `assume` huma sikuri peress li l-pointer tal-bidu ta 'porzjon m'għandux ikun null,
                // u slices fuq non-ZSTs għandu jkollhom ukoll pointer tat-tarf mhux null.
                // Is-sejħa għal `next_back_unchecked!` hija sigura peress li aħna niċċekkjaw jekk l-iteratur huwiex vojt l-ewwel.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Dan l-iteratur issa huwa vojt.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SIGURTÀ: Aħna fil-limiti.`pre_dec_end` jagħmel it-tajjeb anke għaż-ZSTs.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}