// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Dawwar il-firxa `[mid-left, mid+right)` b'tali mod li l-element f `mid` isir l-ewwel element.Ekwivalentement, iddawwar il-firxa `left` elementi lejn ix-xellug jew `right` elementi lejn il-lemin.
///
/// # Safety
///
/// Il-firxa speċifikata għandha tkun valida għall-qari u l-kitba.
///
/// # Algorithm
///
/// L-Algoritmu 1 jintuża għal valuri żgħar ta `left + right` jew għal `T` kbar.
/// L-elementi huma mċaqilqa fil-pożizzjonijiet finali tagħhom wieħed kull darba li jibda minn `mid - left` u javvanza minn passi `right` modulo `left + right`, b'tali mod li temporanju wieħed biss huwa meħtieġ.
/// Eventwalment, naslu lura f `mid - left`.
/// Madankollu, jekk `gcd(left + right, right)` mhuwiex 1, il-passi ta 'hawn fuq qabżu l-elementi.
/// Pereżempju:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Fortunatament, in-numru ta 'elementi li jinqabżu bejn l-elementi finalizzati huwa dejjem ugwali, allura nistgħu sempliċement inpattu għall-pożizzjoni tal-bidu tagħna u nagħmlu aktar rawnds (in-numru totali ta' rawnds huwa x-`gcd(left + right, right)` value).
///
/// Ir-riżultat aħħari huwa li l-elementi kollha huma ffinalizzati darba u darba biss.
///
/// L-Algoritmu 2 jintuża jekk `left + right` huwa kbir iżda `min(left, right)` huwa żgħir biżżejjed biex joqgħod fuq buffer tal-munzell.
/// L-elementi `min(left, right)` huma kkupjati fuq il-buffer, `memmove` huwa applikat għall-oħrajn, u dawk fuq il-buffer jiġu mċaqilqa lura fit-toqba fuq in-naħa opposta ta 'fejn oriġinaw.
///
/// Algoritmi li jistgħu jiġu vettorizzati jaqbżu dak ta 'hawn fuq ladarba `left + right` isir kbir biżżejjed.
/// L-Algoritmu 1 jista 'jiġi vettorizzat permezz ta' tqattigħ u twettiq ta 'ħafna rawnds f'daqqa, iżda hemm ftit rawnds wisq bħala medja sakemm `left + right` huwa enormi, u l-agħar każ ta' rawnd wieħed huwa dejjem hemm.
/// Minflok, l-algoritmu 3 juża skambju ripetut ta 'elementi `min(left, right)` sakemm titħalla problema ta' rotazzjoni iżgħar.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// meta `left < right` minflok isseħħ it-tpartit mix-xellug.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. l-algoritmi ta 'hawn taħt jistgħu jfallu jekk dawn il-każijiet ma jiġux ikkontrollati
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritmu 1 Microbenchmarks jindikaw li l-prestazzjoni medja għal ċaqliq każwali hija aħjar fit-triq kollha sa madwar `left + right == 32`, iżda l-prestazzjoni tal-agħar każ tinkiser sa madwar 16.
            // 24 intgħażel bħala triq tan-nofs.
            // Jekk id-daqs ta `T` huwa ikbar minn 4 `usize`s, dan l-algoritmu jaqbeż ukoll algoritmi oħra.
            //
            //
            let x = unsafe { mid.sub(left) };
            // bidu tal-ewwel rawnd
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` tista 'tinstab qabel l-idejn billi tikkalkula `gcd(left + right, right)`, iżda huwa aktar mgħaġġel li tagħmel linja waħda li tikkalkula l-gcd bħala effett sekondarju, imbagħad tagħmel il-bqija tal-blokka
            //
            //
            let mut gcd = right;
            // il-parametri referenzjarji jiżvelaw li huwa aktar mgħaġġel li tpartat il-temporanji fit-triq kollha minflok ma taqra temporanju wieħed darba, tikkopja lura, u mbagħad tikteb dak temporanju fl-aħħar nett.
            // Dan huwa possibbilment minħabba l-fatt li t-tpartit jew is-sostituzzjoni ta 'temporanji juża biss indirizz tal-memorja wieħed fil-linja minflok ma jkollu bżonn jimmaniġġja tnejn.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // minflok inkrementa `i` u mbagħad niċċekkjaw jekk hux barra l-limiti, aħna niċċekkjaw jekk `i` imurx barra l-limiti fuq l-inkrement li jmiss.
                // Dan jipprevjeni kwalunkwe tgeżwir ta 'indikaturi jew `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // tmiem l-ewwel rawnd
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // dan il-kondizzjonali għandu jkun hawn jekk `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // temm il-biċċa b'aktar rawnds
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` mhix tip ta 'daqs żero, allura huwa tajjeb li taqsam bid-daqs tagħha.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritmu 2 Ix-`[T; 0]` hawn huwa biex jiżgura li dan ikun allinjat b'mod xieraq għal T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritmu 3 Hemm mod alternattiv ta 'tpartit li jinvolvi li ssib fejn tkun l-aħħar tpartit ta' dan l-algoritmu, u tpartit billi tuża dik l-aħħar biċċa minflok tpartat biċċiet adjaċenti bħalma qed jagħmel dan l-algoritmu, iżda dan il-mod għadu aktar mgħaġġel.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritmu 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}