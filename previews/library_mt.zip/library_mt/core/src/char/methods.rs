//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// L-ogħla punt ta 'kodiċi validu li jista' jkollu `char`.
    ///
    /// `char` huwa [Unicode Scalar Value], li jfisser li huwa [Code Point], iżda dawk biss f'ċertu firxa.
    /// `MAX` huwa l-ogħla punt ta 'kodiċi validu li huwa [Unicode Scalar Value] validu.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () jintuża f'Unicode biex jirrappreżenta żball ta 'dekodifikazzjoni.
    ///
    /// Jista 'jseħħ, per eżempju, meta tagħti bytes UTF-8 iffurmati ħażin lil [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Il-verżjoni ta [Unicode](http://www.unicode.org/) li fuqha huma bbażati l-partijiet Unicode tal-metodi `char` u `str`.
    ///
    /// Verżjonijiet ġodda ta 'Unicode jiġu rilaxxati regolarment u sussegwentement il-metodi kollha fil-librerija standard skont Unicode jiġu aġġornati.
    /// Għalhekk l-imġieba ta 'xi metodi `char` u `str` u l-valur ta' din il-kostanti jinbidlu maż-żmien.
    /// Din mhix * meqjusa bħala bidla li tkisser.
    ///
    /// L-iskema tan-numerazzjoni tal-verżjoni hija spjegata f [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Joħloq iteratur fuq il-punti tal-kodiċi kkodifikati UTF-16 f `iter`, u jirritorna s-surrogati mhux imqabbla bħala 'Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Jista 'jinkiseb decoder li jitlef billi jiġu sostitwiti r-riżultati ta' `Err` bil-karattru sostitut:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Ikkonverti `u32` għal `char`.
    ///
    /// Innota li l-`char`s kollha huma validi [`u32`] s, u jistgħu jiġu mitfugħa għal waħda bi
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Madankollu, il-maqlub mhuwiex minnu: mhux kollha [`u32`] validi huma validi`char`s.
    /// `from_u32()` tirritorna `None` jekk l-input ma jkunx valur validu għal `char`.
    ///
    /// Għal verżjoni mhux sigura ta 'din il-funzjoni li tinjora dawn il-kontrolli, ara [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Irritorna `None` meta l-input ma jkunx `char` validu:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Ikkonverti `u32` għal `char`, billi tinjora l-validità.
    ///
    /// Innota li l-`char`s kollha huma validi [`u32`] s, u jistgħu jiġu mitfugħa għal waħda bi
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Madankollu, il-maqlub mhuwiex minnu: mhux kollha [`u32`] validi huma validi`char`s.
    /// `from_u32_unchecked()` jinjora dan, u jitfa 'bl-addoċċ għal `char`, possibilment joħloq wieħed invalidu.
    ///
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura, għax tista 'tibni valuri `char` invalidi.
    ///
    /// Għal verżjoni sigura ta 'din il-funzjoni, ara l-funzjoni [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SIGURTÀ: il-kuntratt ta 'sigurtà għandu jintlaqa' minn min iċempel.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Ikkonverti ċifra fir-radix mogħtija għal `char`.
    ///
    /// 'radix' hawn xi kultant jissejjaħ ukoll 'base'.
    /// Radix ta 'tnejn tindika numru binarju, radix ta' għaxra, deċimali, u radix ta 'sittax, eżadeċimali, biex tagħti xi valuri komuni.
    ///
    /// Radices arbitrarji huma appoġġjati.
    ///
    /// `from_digit()` jirritorna `None` jekk l-input ma jkunx ċifra fir-radix mogħtija.
    ///
    /// # Panics
    ///
    /// Panics jekk jingħata radix akbar minn 36.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Id-Deċimali 11 huwa ċifra waħda fil-bażi 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Irritorna `None` meta l-input ma jkunx ċifra:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Tgħaddi radix kbir, u tikkawża panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Jiċċekkja jekk `char` huwiex ċifra fir-radix mogħtija.
    ///
    /// 'radix' hawn xi kultant jissejjaħ ukoll 'base'.
    /// Radix ta 'tnejn tindika numru binarju, radix ta' għaxra, deċimali, u radix ta 'sittax, eżadeċimali, biex tagħti xi valuri komuni.
    ///
    /// Radices arbitrarji huma appoġġjati.
    ///
    /// Meta mqabbel ma [`is_numeric()`], din il-funzjoni tirrikonoxxi biss il-karattri `0-9`, `a-z` u `A-Z`.
    ///
    /// 'Digit' huwa definit bħala l-karattri li ġejjin biss:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Għal fehim aktar komprensiv ta 'digit', ara [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics jekk jingħata radix akbar minn 36.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Tgħaddi radix kbir, u tikkawża panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Ikkonverti `char` għal ċifra fir-radix mogħtija.
    ///
    /// 'radix' hawn xi kultant jissejjaħ ukoll 'base'.
    /// Radix ta 'tnejn tindika numru binarju, radix ta' għaxra, deċimali, u radix ta 'sittax, eżadeċimali, biex tagħti xi valuri komuni.
    ///
    /// Radices arbitrarji huma appoġġjati.
    ///
    /// 'Digit' huwa definit bħala l-karattri li ġejjin biss:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Jirritorna `None` jekk ix-`char` ma jirreferix għal ċifra fir-radix mogħtija.
    ///
    /// # Panics
    ///
    /// Panics jekk jingħata radix akbar minn 36.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Li tgħaddi ċifra tirriżulta fi falliment:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Tgħaddi radix kbir, u tikkawża panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // il-kodiċi huwa maqsum hawn biex ittejjeb il-veloċità tal-eżekuzzjoni għal każijiet fejn ix-`radix` huwa kostanti u 10 jew iżgħar
        //
        let val = if likely(radix <= 10) {
            // Jekk mhux ċifra, jinħoloq numru akbar minn radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Jirritorna iteratur li jagħti l-ħarba Unicode eżadeċimali ta 'karattru bħala' char`s.
    ///
    /// Dan jaħrab mill-karattri bis-sintassi Rust tal-forma `\u{NNNNNN}` fejn `NNNNNN` hija rappreżentazzjoni eżadeċimali.
    ///
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // jew-ing 1 jiżgura li għal c==0 il-kodiċi jikkalkula li ċifra waħda għandha tkun stampata u (li hija l-istess) tevita n-nixxiegħa (31, 32)
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // l-indiċi ta 'l-iktar ċifra hex sinifikanti
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Verżjoni estiża ta `escape_debug` li b'għażla tippermetti li jaħarbu punti ta' kodiċi ta 'Grapheme Estiż.
    /// Dan jippermettilna nifformattjaw karattri bħal marki mingħajr spazju aħjar meta jkunu fil-bidu ta 'sekwenza.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Jirritorna iteratur li jagħti l-kodiċi tal-ħarba litterali ta 'karattru bħala' char`s.
    ///
    /// Dan jaħrab mill-karattri simili għall-implimentazzjonijiet `Debug` ta `str` jew `char`.
    ///
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Jirritorna iteratur li jagħti l-kodiċi tal-ħarba litterali ta 'karattru bħala' char`s.
    ///
    /// L-inadempjenza hija magħżula bi preġudizzju lejn il-produzzjoni ta 'litterali li huma legali f'varjetà ta' lingwi, inklużi C++ 11 u lingwi simili tal-familja C.
    /// Ir-regoli eżatti huma:
    ///
    /// * Tab hija maħruba bħala `\t`.
    /// * Ir-ritorn tat-trasport jinħeles bħala `\r`.
    /// * L-għalf tal-linja jinħeles bħala `\n`.
    /// * Kwotazzjoni waħda tinħeles bħala `\'`.
    /// * Kwotazzjoni doppja taħrab bħala `\"`.
    /// * Backslash jinħeles bħala `\\`.
    /// * Kwalunkwe karattru fil-firxa 'ASCII li tista' tiġi stampata `0x20` .. `0x7e` inklużiv ma jiġix maħrub.
    /// * Il-karattri l-oħra kollha jingħataw ħarbiet eżadeċimali Unicode;ara [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Jirritorna n-numru ta 'bytes li dan `char` ikun jeħtieġ jekk ikkodifikat f UTF-8.
    ///
    /// Dak in-numru ta 'bytes huwa dejjem bejn 1 u 4, inklużi.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// It-tip `&str` jiggarantixxi li l-kontenut tiegħu huwa UTF-8, u għalhekk nistgħu nqabblu t-tul li jieħu kieku kull punt tal-kodiċi kien rappreżentat bħala `char` vs fix-`&str` innifsu:
    ///
    ///
    /// ```
    /// // bħala chars
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // it-tnejn jistgħu jiġu rappreżentati bħala tliet bytes
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // bħala &str, dawn it-tnejn huma kkodifikati f UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // nistgħu naraw li jieħdu total ta 'sitt bytes ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... bħad-&str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Jirritorna n-numru ta 'unitajiet tal-kodiċi 16-bit li dan `char` ikun jeħtieġ jekk ikkodifikat f UTF-16.
    ///
    ///
    /// Ara d-dokumentazzjoni għal [`len_utf8()`] għal aktar spjegazzjoni ta 'dan il-kunċett.
    /// Din il-funzjoni hija mera, iżda għal UTF-16 minflok UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Jikkodifika dan il-karattru bħala UTF-8 fil-buffer tal-byte pprovdut, u mbagħad jirritorna s-sub-porzjon tal-buffer li fih il-karattru kodifikat.
    ///
    ///
    /// # Panics
    ///
    /// Panics jekk il-buffer mhuwiex kbir biżżejjed.
    /// Buffer tat-tul erbgħa huwa kbir biżżejjed biex jikkodifika kwalunkwe `char`.
    ///
    /// # Examples
    ///
    /// Fiż-żewġ eżempji, 'ß' jieħu żewġ bytes biex jikkodifika.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Buffer żgħir wisq:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SIGURTÀ: `char` mhuwiex sostitut, allura dan huwa UTF-8 validu.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Jikkodifika dan il-karattru bħala UTF-16 fil-buffer `u16` provdut, u mbagħad jirritorna s-sub-porzjon tal-buffer li fih il-karattru kodifikat.
    ///
    ///
    /// # Panics
    ///
    /// Panics jekk il-buffer mhuwiex kbir biżżejjed.
    /// Buffer tat-tul 2 huwa kbir biżżejjed biex jikkodifika kwalunkwe `char`.
    ///
    /// # Examples
    ///
    /// Fiż-żewġ eżempji, '𝕊' jieħu żewġ `u16`s biex jikkodifika.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Buffer żgħir wisq:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Jirritorna `true` jekk dan `char` għandu l-proprjetà `Alphabetic`.
    ///
    /// `Alphabetic` huwa deskritt fil-Kapitolu 4 (Karatteristiċi tal-Karattru) tax-[Unicode Standard] u speċifikat fix-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // l-imħabba hija ħafna affarijiet, iżda mhix alfabetika
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Jirritorna `true` jekk dan `char` għandu l-proprjetà `Lowercase`.
    ///
    /// `Lowercase` huwa deskritt fil-Kapitolu 4 (Karatteristiċi tal-Karattru) tax-[Unicode Standard] u speċifikat fix-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Id-diversi skripts Ċiniżi u l-punteġġjatura m'għandhomx każ, u allura:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Jirritorna `true` jekk dan `char` għandu l-proprjetà `Uppercase`.
    ///
    /// `Uppercase` huwa deskritt fil-Kapitolu 4 (Karatteristiċi tal-Karattru) tax-[Unicode Standard] u speċifikat fix-[Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Id-diversi skripts Ċiniżi u l-punteġġjatura m'għandhomx każ, u allura:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Jirritorna `true` jekk dan `char` għandu l-proprjetà `White_Space`.
    ///
    /// `White_Space` huwa speċifikat fix-[Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // spazju li ma jitkissirx
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Jirritorna `true` jekk dan `char` jissodisfa jew [`is_alphabetic()`] jew [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Jirritorna `true` jekk dan `char` għandu l-kategorija ġenerali għall-kodiċi ta 'kontroll.
    ///
    /// Kodiċijiet ta 'kontroll (punti ta' kodiċi bil-kategorija ġenerali ta `Cc`) huma deskritti fil-Kapitolu 4 (Karatteristiċi tal-Karattru) ta' [Unicode Standard] u speċifikati fix-[Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // U + 009C, TERMINATUR TA 'STRING
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Jirritorna `true` jekk dan `char` għandu l-proprjetà `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` huwa deskritt f [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] u speċifikat f [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Jirritorna `true` jekk dan `char` għandu waħda mill-kategoriji ġenerali għan-numri.
    ///
    /// Il-kategoriji ġenerali għan-numri (`Nd` għal ċifri deċimali, `Nl` għal karattri numeriċi li jixbħu l-ittri, u `No` għal karattri numeriċi oħra) huma speċifikati fix-[Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Jirritorna iteratur li jagħti l-immappjar b'ittri żgħar ta 'dan ix-`char` bħala wieħed jew aktar
    /// `char`s.
    ///
    /// Jekk dan ix-`char` m'għandux immappjar b'ittri żgħar, l-iteratur jagħti l-istess `char`.
    ///
    /// Jekk dan ix-`char` għandu immappjar żgħir wieħed għal wieħed mogħti mix-[Unicode Character Database][ucd] [`UnicodeData.txt`], l-iteratur jagħti dak ix-`char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jekk dan `char` jirrikjedi konsiderazzjonijiet speċjali (eż. "Char" multipli) l-iteratur jagħti l-"char" (s) mogħtija minn [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Din l-operazzjoni twettaq immappjar inkondizzjonat mingħajr tfassil.Jiġifieri, il-konverżjoni hija indipendenti mill-kuntest u l-lingwa.
    ///
    /// Fix-[Unicode Standard], il-Kapitolu 4 (Karatteristiċi tal-Karattru) jiddiskuti l-immappjar tal-każijiet b'mod ġenerali u l-Kapitolu 3 (Conformance) jiddiskuti l-algoritmu default għall-konverżjoni tal-każijiet.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Kultant ir-riżultat huwa aktar minn karattru wieħed:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Karattri li m'għandhomx kemm il-majuskoli u kemm il-żgħar jinqalbu fihom infushom.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Jirritorna iteratur li jagħti l-immappjar kapitali ta 'dan ix-`char` bħala wieħed jew aktar
    /// `char`s.
    ///
    /// Jekk dan ix-`char` m'għandux immappjar kapitali, l-iteratur jagħti l-istess `char`.
    ///
    /// Jekk dan ix-`char` għandu mapping kapitali wieħed għal wieħed mogħti mix-[Unicode Character Database][ucd] [`UnicodeData.txt`], l-iteratur jagħti dak ix-`char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Jekk dan `char` jirrikjedi konsiderazzjonijiet speċjali (eż. "Char" multipli) l-iteratur jagħti l-"char" (s) mogħtija minn [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Din l-operazzjoni twettaq immappjar inkondizzjonat mingħajr tfassil.Jiġifieri, il-konverżjoni hija indipendenti mill-kuntest u l-lingwa.
    ///
    /// Fix-[Unicode Standard], il-Kapitolu 4 (Karatteristiċi tal-Karattru) jiddiskuti l-immappjar tal-każijiet b'mod ġenerali u l-Kapitolu 3 (Conformance) jiddiskuti l-algoritmu default għall-konverżjoni tal-każijiet.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Bħala iteratur:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Uża `println!` direttament:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// It-tnejn huma ekwivalenti għal:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Uża `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Kultant ir-riżultat huwa aktar minn karattru wieħed:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Karattri li m'għandhomx kemm il-majuskoli u kemm il-żgħar jinqalbu fihom infushom.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Nota dwar il-lokalità
    ///
    /// Fit-Tork, l-ekwivalenti ta 'i' bil-Latin għandu ħames forom minflok tnejn:
    ///
    /// * 'Dotless': I/ı, kultant miktub ï
    /// * 'Dotted': İ/i
    ///
    /// Innota li l-'i' bit-tikek żgħar huwa l-istess bħal-Latin.Għalhekk:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Il-valur ta `upper_i` hawn jiddependi fuq il-lingwa tat-test: jekk inkunu f `en-US`, għandu jkun `"I"`, imma jekk inkunu f `tr_TR`, għandu jkun `"İ"`.
    /// `to_uppercase()` ma jqisx dan, u allura:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// jżomm bejn il-lingwi.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Jiċċekkja jekk il-valur huwiex fil-medda ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Tagħmel kopja tal-valur fl-ekwivalenti ASCII tagħha f'ittri kbar.
    ///
    /// Ittri ASCII 'a' sa 'z' huma mmappjati għal 'A' sa 'Z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tittella 'l-valur fuq il-majusklu f'post, uża [`make_ascii_uppercase()`].
    ///
    /// Biex tittella 'karattri ASCII b'ittri kbar minbarra karattri mhux ASCII, uża [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Tagħmel kopja tal-valur fl-ekwivalenti ASCII tagħha f'ittri żgħar.
    ///
    /// Ittri ASCII 'A' sa 'Z' huma mmappjati għal 'a' sa 'z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tibbaża l-valur fuq il-post, uża [`make_ascii_lowercase()`].
    ///
    /// Għal karattri żgħar ASCII minbarra karattri mhux ASCII, uża [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Jiċċekkja li żewġ valuri huma logħba ASCII li ma tissensibilizzax il-każijiet.
    ///
    /// Ekwivalenti għal `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Jikkonverti dan it-tip għall-ekwivalenti ASCII tiegħu ta 'l-ittri kbar fil-post.
    ///
    /// Ittri ASCII 'a' sa 'z' huma mmappjati għal 'A' sa 'Z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tirritorna valur superjuri ġdid mingħajr ma timmodifika dak eżistenti, uża [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Ikkonverti dan it-tip għall-ekwivalenti ASCII tagħha ta 'minuskoli fil-post.
    ///
    /// Ittri ASCII 'A' sa 'Z' huma mmappjati għal 'a' sa 'z', iżda ittri mhux ASCII ma jinbidlux.
    ///
    /// Biex tirritorna valur ġdid b'ittri żgħar mingħajr ma timmodifika dak eżistenti, uża [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Jiċċekkja jekk il-valur huwiex karattru alfabetiku ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', jew
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Jiċċekkja jekk il-valur huwiex karattru kapitali ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Jiċċekkja jekk il-valur huwiex karattru żgħir ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Jiċċekkja jekk il-valur huwiex karattru alfanumeriku ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', jew
    /// - U + 0061 'a' ..=U + 007A 'z', jew
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Jiċċekkja jekk il-valur huwiex ċifra deċimali ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Jiċċekkja jekk il-valur huwiex ċifra eżadeċimali ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', jew
    /// - U + 0041 'A' ..=U + 0046 'F', jew
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Jiċċekkja jekk il-valur huwiex karattru ta 'punteġġjatura ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, jew
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, jew
    /// - U + 005B ..=U + 0060 ""[\] ^ _``, jew
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Jiċċekkja jekk il-valur huwiex karattru grafiku ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Jiċċekkja jekk il-valur huwiex karattru ta 'spazju vojt ASCII:
    /// U + 0020 SPAZJU, U + 0009 TABELLA ORIZZONTALI, U + 000A LINJA GĦALF, U + 000C FORMA GĦALF, jew U + 000D RITORN TAL-ĠARR.
    ///
    /// Rust juża [definition of ASCII whitespace][infra-aw] tal-WhatWG Infra Standard.Hemm diversi definizzjonijiet oħra f'użu wiesa '.
    /// Pereżempju, [the POSIX locale][pct] jinkludi U + 000B TABELLA VERTIKALI kif ukoll il-karattri kollha ta 'hawn fuq, iżda - mill-istess speċifikazzjoni-[ir-regola default għal "field splitting" fil-Bourne shell][bfs] tikkunsidra *biss* SPAZJU, TABELLA ORIZZONTALI, u LINJA GĦALF bħala spazju vojt.
    ///
    ///
    /// Jekk qed tikteb programm li jipproċessa format ta 'fajl eżistenti, iċċekkja x'inhi d-definizzjoni ta' dak il-format ta 'spazju vojt qabel ma tuża din il-funzjoni.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Jiċċekkja jekk il-valur huwiex karattru ta 'kontroll ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARATUR TAL-UNITÀ, jew U + 007F Ħassar.
    /// Innota li ħafna mill-karattri ta 'l-ispazju fl-ispazju ASCII huma karattri ta' kontroll, iżda SPAZJU le.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Jikkodifika valur u32 mhux ipproċessat bħala UTF-8 fil-buffer tal-byte pprovdut, u mbagħad jirritorna s-sub-porzjon tal-buffer li fih il-karattru kodifikat.
///
///
/// B'differenza minn `char::encode_utf8`, dan il-metodu jimmaniġġa wkoll punti tal-kodiċi fil-medda surrogata.
/// (Il-ħolqien ta `char` fil-medda surrogata huwa UB.) Ir-riżultat huwa [generalized UTF-8] validu iżda mhux UTF-8 validu.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics jekk il-buffer mhuwiex kbir biżżejjed.
/// Buffer tat-tul erbgħa huwa kbir biżżejjed biex jikkodifika kwalunkwe `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Jikkodifika valur u32 mhux ipproċessat bħala UTF-16 fil-buffer `u16` provdut, u mbagħad jirritorna s-sub-porzjon tal-buffer li fih il-karattru kodifikat.
///
///
/// B'differenza minn `char::encode_utf16`, dan il-metodu jimmaniġġa wkoll punti tal-kodiċi fil-medda surrogata.
/// (Il-ħolqien ta `char` fil-medda surrogata huwa UB.)
///
/// # Panics
///
/// Panics jekk il-buffer mhuwiex kbir biżżejjed.
/// Buffer tat-tul 2 huwa kbir biżżejjed biex jikkodifika kwalunkwe `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SIGURTÀ: kull driegħ jivverifika jekk hemmx biċċiet biżżejjed biex tikteb fihom
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // Il-BMP jaqa '
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Ajruplani supplimentari jinqasmu f'sostituti.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}