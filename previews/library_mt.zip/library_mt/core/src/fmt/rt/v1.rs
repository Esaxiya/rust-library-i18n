//! Dan huwa modulu intern użat mill-ifmt!runtime.Dawn l-istrutturi huma emessi għal matriċi statiċi biex jikkompilaw minn qabel kordi tal-format qabel iż-żmien.
//!
//! Dawn id-definizzjonijiet huma simili għall-ekwivalenti `ct` tagħhom, iżda huma differenti f`dawk li jistgħu jiġu allokati statikament u huma kemmxejn ottimizzati għar-runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Allinjamenti possibbli li jistgħu jintalbu bħala parti minn direttiva dwar l-ifformattjar.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Indikazzjoni li l-kontenut għandu jkun allinjat lejn ix-xellug.
    Left,
    /// Indikazzjoni li l-kontenut għandu jkun allinjat mal-lemin.
    Right,
    /// Indikazzjoni li l-kontenut għandu jkun allinjat maċ-ċentru.
    Center,
    /// Ma ntalab l-ebda allinjament.
    Unknown,
}

/// Użat mill-ispeċifikaturi [width](https://doc.rust-lang.org/std/fmt/#width) u [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Speċifikat b'numru litterali, jaħżen il-valur
    Is(usize),
    /// Speċifikat bl-użu ta 'sintassi `$` u `*`, jaħżen l-indiċi f `args`
    Param(usize),
    /// Mhux speċifikat
    Implied,
}