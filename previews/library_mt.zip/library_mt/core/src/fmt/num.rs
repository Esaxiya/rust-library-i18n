//! Ifformattjar ta 'numru sħiħ u b'punt li jvarja

use crate::fmt;
use crate::mem::MaybeUninit;
use crate::num::flt2dec;
use crate::ops::{Div, Rem, Sub};
use crate::ptr;
use crate::slice;
use crate::str;

#[doc(hidden)]
trait DisplayInt:
    PartialEq + PartialOrd + Div<Output = Self> + Rem<Output = Self> + Sub<Output = Self> + Copy
{
    fn zero() -> Self;
    fn from_u8(u: u8) -> Self;
    fn to_u8(&self) -> u8;
    fn to_u16(&self) -> u16;
    fn to_u32(&self) -> u32;
    fn to_u64(&self) -> u64;
    fn to_u128(&self) -> u128;
}

macro_rules! impl_int {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}
macro_rules! impl_uint {
    ($($t:ident)*) => (
      $(impl DisplayInt for $t {
          fn zero() -> Self { 0 }
          fn from_u8(u: u8) -> Self { u as Self }
          fn to_u8(&self) -> u8 { *self as u8 }
          fn to_u16(&self) -> u16 { *self as u16 }
          fn to_u32(&self) -> u32 { *self as u32 }
          fn to_u64(&self) -> u64 { *self as u64 }
          fn to_u128(&self) -> u128 { *self as u128 }
      })*
    )
}

impl_int! { i8 i16 i32 i64 i128 isize }
impl_uint! { u8 u16 u32 u64 u128 usize }

/// Tip li jirrappreżenta radix speċifiku
#[doc(hidden)]
trait GenericRadix: Sized {
    /// In-numru ta 'ċifri.
    const BASE: u8;

    /// String tal-prefiss speċifiku għar-radix.
    const PREFIX: &'static str;

    /// Ikkonverti numru sħiħ għal ċifra korrispondenti tar-radix.
    fn digit(x: u8) -> u8;

    /// Ifformattja numru sħiħ billi tuża r-radix billi tuża formattur.
    fn fmt_int<T: DisplayInt>(&self, mut x: T, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ir-radix tista 'tkun baxxa daqs 2, allura għandna bżonn buffer ta' mill-inqas 128 karattru għal numru bażi 2.
        //
        let zero = T::zero();
        let is_nonnegative = x >= zero;
        let mut buf = [MaybeUninit::<u8>::uninit(); 128];
        let mut curr = buf.len();
        let base = T::from_u8(Self::BASE);
        if is_nonnegative {
            // Akkumula kull ċifra tan-numru mill-inqas figura sinifikanti għall-iktar figura sinifikanti.
            //
            for byte in buf.iter_mut().rev() {
                let n = x % base; // Ikseb il-valur tal-post attwali.
                x = x / base; // Akkumula n-numru.
                byte.write(Self::digit(n.to_u8())); // Aħżen iċ-ċifra fil-buffer.
                curr -= 1;
                if x == zero {
                    // Ma jibqgħux aktar ċifri biex jakkumulaw.
                    break;
                };
            }
        } else {
            // Agħmel l-istess bħal hawn fuq, imma kont għall-kumpliment ta 'tnejn.
            for byte in buf.iter_mut().rev() {
                let n = zero - (x % base); // Ikseb il-valur tal-post attwali.
                x = x / base; // Akkumula n-numru.
                byte.write(Self::digit(n.to_u8())); // Aħżen iċ-ċifra fil-buffer.
                curr -= 1;
                if x == zero {
                    // Ma jibqgħux aktar ċifri biex jakkumulaw.
                    break;
                };
            }
        }
        let buf = &buf[curr..];
        // SIGURTÀ: L-uniċi karattri f `buf` huma maħluqa minn `Self::digit` li huma preżunti li huma
        // UTF-8 validu
        let buf = unsafe {
            str::from_utf8_unchecked(slice::from_raw_parts(
                MaybeUninit::slice_as_ptr(buf),
                buf.len(),
            ))
        };
        f.pad_integral(is_nonnegative, Self::PREFIX, buf)
    }
}

/// Radix binarju (bażi 2)
#[derive(Clone, PartialEq)]
struct Binary;

/// Radix ottali (bażi 8)
#[derive(Clone, PartialEq)]
struct Octal;

/// Radix eżadeċimali (bażi 16), ifformattjat b'karattri żgħar
#[derive(Clone, PartialEq)]
struct LowerHex;

/// Radix eżadeċimali (bażi 16), ifformattjat b'karattri kbar
#[derive(Clone, PartialEq)]
struct UpperHex;

macro_rules! radix {
    ($T:ident, $base:expr, $prefix:expr, $($x:pat => $conv:expr),+) => {
        impl GenericRadix for $T {
            const BASE: u8 = $base;
            const PREFIX: &'static str = $prefix;
            fn digit(x: u8) -> u8 {
                match x {
                    $($x => $conv,)+
                    x => panic!("number not in the range 0..={}: {}", Self::BASE - 1, x),
                }
            }
        }
    }
}

radix! { Binary,    2, "0b", x @  0 ..=  1 => b'0' + x }
radix! { Octal,     8, "0o", x @  0 ..=  7 => b'0' + x }
radix! { LowerHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'a' + (x - 10) }
radix! { UpperHex, 16, "0x", x @  0 ..=  9 => b'0' + x, x @ 10 ..= 15 => b'A' + (x - 10) }

macro_rules! int_base {
    (fmt::$Trait:ident for $T:ident as $U:ident -> $Radix:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::$Trait for $T {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                $Radix.fmt_int(*self as $U, f)
            }
        }
    };
}

macro_rules! integer {
    ($Int:ident, $Uint:ident) => {
        int_base! { fmt::Binary   for $Int as $Uint  -> Binary }
        int_base! { fmt::Octal    for $Int as $Uint  -> Octal }
        int_base! { fmt::LowerHex for $Int as $Uint  -> LowerHex }
        int_base! { fmt::UpperHex for $Int as $Uint  -> UpperHex }

        int_base! { fmt::Binary   for $Uint as $Uint -> Binary }
        int_base! { fmt::Octal    for $Uint as $Uint -> Octal }
        int_base! { fmt::LowerHex for $Uint as $Uint -> LowerHex }
        int_base! { fmt::UpperHex for $Uint as $Uint -> UpperHex }
    };
}
integer! { isize, usize }
integer! { i8, u8 }
integer! { i16, u16 }
integer! { i32, u32 }
integer! { i64, u64 }
integer! { i128, u128 }
macro_rules! debug {
    ($($T:ident)*) => {$(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Debug for $T {
            #[inline]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if f.debug_lower_hex() {
                    fmt::LowerHex::fmt(self, f)
                } else if f.debug_upper_hex() {
                    fmt::UpperHex::fmt(self, f)
                } else {
                    fmt::Display::fmt(self, f)
                }
            }
        }
    )*};
}
debug! {
  i8 i16 i32 i64 i128 isize
  u8 u16 u32 u64 u128 usize
}

// Deċimali b'żewġ ċifri fittex it-tabella
static DEC_DIGITS_LUT: &[u8; 200] = b"0001020304050607080910111213141516171819\
      2021222324252627282930313233343536373839\
      4041424344454647484950515253545556575859\
      6061626364656667686970717273747576777879\
      8081828384858687888990919293949596979899";

macro_rules! impl_Display {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(mut n: $u, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            // 2 ^ 128 huwa madwar 3 * 10 ^ 38, allura 39 jagħti byte żejjed ta 'spazju
            let mut buf = [MaybeUninit::<u8>::uninit(); 39];
            let mut curr = buf.len() as isize;
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // SIGURTÀ: Peress li `d1` u `d2` huma dejjem inqas minn jew ugwali għal `198`, aħna
            // tista 'tikkopja minn `lut_ptr[d1..d1 + 1]` u `lut_ptr[d2..d2 + 1]`.
            // Biex turi li huwa OK li tikkopja f `buf_ptr`, innota li fil-bidu `curr == buf.len() == 39 > log(n)` minn `n < 2^128 < 10^39`, u f'kull pass dan jinżamm l-istess bħal ma `n` huwa maqsum.
            //
            // Peress li `n` huwa dejjem mhux negattiv, dan ifisser li `curr > 0` allura `buf_ptr[curr..curr + 1]` huwa aċċessibbli mingħajr periklu.
            //
            //
            unsafe {
                // bżonn mill-inqas 16-il bit biex jaħdmu l-4-karattri kull darba.
                assert!(crate::mem::size_of::<$u>() >= 2);

                // iddekowdja bil-ħerqa 4 karattri kull darba
                while n >= 10000 {
                    let rem = (n % 10000) as isize;
                    n /= 10000;

                    let d1 = (rem / 100) << 1;
                    let d2 = (rem % 100) << 1;
                    curr -= 4;

                    // Aħna jitħallew nikkupjaw għal `buf_ptr[curr..curr + 3]` hawnhekk għax inkella `curr < 0`.
                    // Iżda mbagħad `n` kien oriġinarjament mill-inqas `10000^10` li huwa `10^40 > 2^128 > n`.
                    //
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                    ptr::copy_nonoverlapping(lut_ptr.offset(d2), buf_ptr.offset(curr + 2), 2);
                }

                // jekk nilħqu hawn in-numri huma <=9999, allura l-iktar 4 karattri twal
                let mut n = n as isize; // possibilment tnaqqas il-matematika 64bit

                // jiddekowdja 2 karattri oħra, jekk> 2 karattri
                if n >= 100 {
                    let d1 = (n % 100) << 1;
                    n /= 100;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }

                // jiddekowdja l-aħħar 1 jew 2 karattri
                if n < 10 {
                    curr -= 1;
                    *buf_ptr.offset(curr) = (n as u8) + b'0';
                } else {
                    let d1 = n << 1;
                    curr -= 2;
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
            }

            // SIGURTÀ: `curr`> 0 (peress li għamilna `buf` kbir biżżejjed), u l-karattri kollha huma validi
            // UTF-8 peress li `DEC_DIGITS_LUT` huwa
            let buf_slice = unsafe {
                str::from_utf8_unchecked(
                    slice::from_raw_parts(buf_ptr.offset(curr), buf.len() - curr as usize))
            };
            f.pad_integral(is_nonnegative, "", buf_slice)
        }

        $(#[stable(feature = "rust1", since = "1.0.0")]
        impl fmt::Display for $t {
            #[allow(unused_comparisons)]
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                let is_nonnegative = *self >= 0;
                let n = if is_nonnegative {
                    self.$conv_fn()
                } else {
                    // ikkonverti n-num negattiv għal pożittiv billi tgħaqqad 1 mat-2 kumpliment tagħha
                    (!self.$conv_fn()).wrapping_add(1)
                };
                $name(n, is_nonnegative, f)
            }
        })*
    };
}

macro_rules! impl_Exp {
    ($($t:ident),* as $u:ident via $conv_fn:ident named $name:ident) => {
        fn $name(
            mut n: $u,
            is_nonnegative: bool,
            upper: bool,
            f: &mut fmt::Formatter<'_>
        ) -> fmt::Result {
            let (mut n, mut exponent, trailing_zeros, added_precision) = {
                let mut exponent = 0;
                // għadd u neħħi żero deċimali ta 'wara
                while n % 10 == 0 && n >= 10 {
                    n /= 10;
                    exponent += 1;
                }
                let trailing_zeros = exponent;

                let (added_precision, subtracted_precision) = match f.precision() {
                    Some(fmt_prec) => {
                        // numru ta 'ċifri deċimali nieqes 1
                        let mut tmp = n;
                        let mut prec = 0;
                        while tmp >= 10 {
                            tmp /= 10;
                            prec += 1;
                        }
                        (fmt_prec.saturating_sub(prec), prec.saturating_sub(fmt_prec))
                    }
                    None => (0,0)
                };
                for _ in 1..subtracted_precision {
                    n/=10;
                    exponent += 1;
                }
                if subtracted_precision != 0 {
                    let rem = n % 10;
                    n /= 10;
                    exponent += 1;
                    // aqleb l-aħħar ċifra
                    if rem >= 5 {
                        n += 1;
                    }
                }
                (n, exponent, trailing_zeros, added_precision)
            };

            // 39 ċifra (l-agħar każ u128) +.
            // =40 Peress li `curr` dejjem jonqos bin-numru ta 'ċifri kkupjati, dan ifisser li `curr >= 0`.
            //
            let mut buf = [MaybeUninit::<u8>::uninit(); 40];
            let mut curr = buf.len() as isize; // indiċi għal buf
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            let lut_ptr = DEC_DIGITS_LUT.as_ptr();

            // jiddekowdja 2 karattri kull darba
            while n >= 100 {
                let d1 = ((n % 100) as isize) << 1;
                curr -= 2;
                // SIGURTÀ: `d1 <= 198`, allura nistgħu nikkupjaw minn `lut_ptr[d1..d1 + 2]` minn dakinhar
                // `DEC_DIGITS_LUT` għandu tul ta '200.
                unsafe {
                    ptr::copy_nonoverlapping(lut_ptr.offset(d1), buf_ptr.offset(curr), 2);
                }
                n /= 100;
                exponent += 2;
            }
            // n huwa <=99, allura l-iktar 2 karattri twal
            let mut n = n as isize; // possibilment tnaqqas il-matematika 64bit
            // jiddekowdja t-tieni għall-aħħar karattru
            if n >= 10 {
                curr -= 1;
                // SIGURTÀ: Sikur sa minn `40 > curr >= 0` (ara l-kumment)
                unsafe {
                    *buf_ptr.offset(curr) = (n as u8 % 10_u8) + b'0';
                }
                n /= 10;
                exponent += 1;
            }
            // żid punt deċimali jekk> 1 ċifra mantissa tiġi stampata
            if exponent != trailing_zeros || added_precision != 0 {
                curr -= 1;
                // SIGURTÀ: Sikur sa minn `40 > curr >= 0`
                unsafe {
                    *buf_ptr.offset(curr) = b'.';
                }
            }

            // SIGURTÀ: Sikur sa minn `40 > curr >= 0`
            let buf_slice = unsafe {
                // jiddekowdja l-aħħar karattru
                curr -= 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';

                let len = buf.len() - curr as usize;
                slice::from_raw_parts(buf_ptr.offset(curr), len)
            };

            // jaħżen 'e' (jew 'E') u l-esponent sa 2 ċifri
            let mut exp_buf = [MaybeUninit::<u8>::uninit(); 3];
            let exp_ptr = MaybeUninit::slice_as_mut_ptr(&mut exp_buf);
            // SIGURTÀ: Fi kwalunkwe każ, `exp_buf` huwa miktub fil-limiti u `exp_ptr[..len]`
            // jinsab fi `exp_buf` minn `len <= 3`.
            let exp_slice = unsafe {
                *exp_ptr.offset(0) = if upper {b'E'} else {b'e'};
                let len = if exponent < 10 {
                    *exp_ptr.offset(1) = (exponent as u8) + b'0';
                    2
                } else {
                    let off = exponent << 1;
                    ptr::copy_nonoverlapping(lut_ptr.offset(off), exp_ptr.offset(1), 2);
                    3
                };
                slice::from_raw_parts(exp_ptr, len)
            };

            let parts = &[
                flt2dec::Part::Copy(buf_slice),
                flt2dec::Part::Zero(added_precision),
                flt2dec::Part::Copy(exp_slice)
            ];
            let sign = if !is_nonnegative {
                "-"
            } else if f.sign_plus() {
                "+"
            } else {
                ""
            };
            let formatted = flt2dec::Formatted{sign, parts};
            f.pad_formatted_parts(&formatted)
        }

        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::LowerExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // ikkonverti n-num negattiv għal pożittiv billi tgħaqqad 1 mat-2 kumpliment tagħha
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, false, f)
                }
            })*
        $(
            #[stable(feature = "integer_exp_format", since = "1.42.0")]
            impl fmt::UpperExp for $t {
                #[allow(unused_comparisons)]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    let is_nonnegative = *self >= 0;
                    let n = if is_nonnegative {
                        self.$conv_fn()
                    } else {
                        // ikkonverti n-num negattiv għal pożittiv billi tgħaqqad 1 mat-2 kumpliment tagħha
                        (!self.$conv_fn()).wrapping_add(1)
                    };
                    $name(n, is_nonnegative, true, f)
                }
            })*
    };
}

// Inkludi wasm32 hawnhekk peress li ma jirriflettix id-daqs tal-pointer nattiv, u ħafna drabi jimpurtaha bil-qawwa li jkollok daqs tal-kodiċi iżgħar.
//
#[cfg(any(target_pointer_width = "64", target_arch = "wasm32"))]
mod imp {
    use super::*;
    impl_Display!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named fmt_u64
    );
    impl_Exp!(
        i8, u8, i16, u16, i32, u32, i64, u64, usize, isize
            as u64 via to_u64 named exp_u64
    );
}

#[cfg(not(any(target_pointer_width = "64", target_arch = "wasm32")))]
mod imp {
    use super::*;
    impl_Display!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named fmt_u32);
    impl_Display!(i64, u64 as u64 via to_u64 named fmt_u64);
    impl_Exp!(i8, u8, i16, u16, i32, u32, isize, usize as u32 via to_u32 named exp_u32);
    impl_Exp!(i64, u64 as u64 via to_u64 named exp_u64);
}
impl_Exp!(i128, u128 as u128 via to_u128 named exp_u128);

/// Funzjoni helper biex tikteb u64 f `buf` li tmur mill-aħħar għall-ewwel, b `curr`.
fn parse_u64_into<const N: usize>(mut n: u64, buf: &mut [MaybeUninit<u8>; N], curr: &mut isize) {
    let buf_ptr = MaybeUninit::slice_as_mut_ptr(buf);
    let lut_ptr = DEC_DIGITS_LUT.as_ptr();
    assert!(*curr > 19);

    // SAFETY:
    // Jikteb l-iktar 19-il karattru fil-buffer.Garantit li kwalunkwe ptr f'LUT huwa l-iktar
    // 198, hekk qatt ma OOB.
    // Hemm kontroll hawn fuq li fadal mill-inqas 19-il karattru.
    unsafe {
        if n >= 1e16 as u64 {
            let to_parse = n % 1e16 as u64;
            n /= 1e16 as u64;

            // Uħud minn dawn huma nops iżda jidher aktar eleganti b'dan il-mod.
            let d1 = ((to_parse / 1e14 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e12 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e10 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e8 as u64) % 100) << 1;
            let d5 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d6 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d7 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d8 = ((to_parse / 1e0 as u64) % 100) << 1;

            *curr -= 16;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d5 as isize), buf_ptr.offset(*curr + 8), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d6 as isize), buf_ptr.offset(*curr + 10), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d7 as isize), buf_ptr.offset(*curr + 12), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d8 as isize), buf_ptr.offset(*curr + 14), 2);
        }
        if n >= 1e8 as u64 {
            let to_parse = n % 1e8 as u64;
            n /= 1e8 as u64;

            // Uħud minn dawn huma nops iżda jidher aktar eleganti b'dan il-mod.
            let d1 = ((to_parse / 1e6 as u64) % 100) << 1;
            let d2 = ((to_parse / 1e4 as u64) % 100) << 1;
            let d3 = ((to_parse / 1e2 as u64) % 100) << 1;
            let d4 = ((to_parse / 1e0 as u64) % 100) << 1;
            *curr -= 8;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d3 as isize), buf_ptr.offset(*curr + 4), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d4 as isize), buf_ptr.offset(*curr + 6), 2);
        }
        // `n` <1e8 <(1 << 32)
        let mut n = n as u32;
        if n >= 1e4 as u32 {
            let to_parse = n % 1e4 as u32;
            n /= 1e4 as u32;

            let d1 = (to_parse / 100) << 1;
            let d2 = (to_parse % 100) << 1;
            *curr -= 4;

            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr + 0), 2);
            ptr::copy_nonoverlapping(lut_ptr.offset(d2 as isize), buf_ptr.offset(*curr + 2), 2);
        }

        // `n` <1e4 <(1 << 16)
        let mut n = n as u16;
        if n >= 100 {
            let d1 = (n % 100) << 1;
            n /= 100;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }

        // jiddekowdja l-aħħar 1 jew 2 karattri
        if n < 10 {
            *curr -= 1;
            *buf_ptr.offset(*curr) = (n as u8) + b'0';
        } else {
            let d1 = n << 1;
            *curr -= 2;
            ptr::copy_nonoverlapping(lut_ptr.offset(d1 as isize), buf_ptr.offset(*curr), 2);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for u128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt_u128(*self, true, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for i128 {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let is_nonnegative = *self >= 0;
        let n = if is_nonnegative {
            self.to_u128()
        } else {
            // ikkonverti n-num negattiv għal pożittiv billi tgħaqqad 1 mat-2 kumpliment tagħha
            (!self.to_u128()).wrapping_add(1)
        };
        fmt_u128(n, is_nonnegative, f)
    }
}

/// Ottimizzazzjoni speċjalizzata għal u128.
/// Minflok ma tieħu żewġ oġġetti kull darba, tinqasam f'mhux iktar minn 2 u64s, u mbagħad biċċiet b'10e16, 10e8, 10e4, 10e2, u mbagħad 10e1.
/// Għandha wkoll timmaniġġa l-aħħar oġġett wieħed, bħala 10 ^ 40> 2 ^ 128> 10 ^ 39, billi
/// 10 ^ 20> 2 ^ 64> 10 ^ 19.
fn fmt_u128(n: u128, is_nonnegative: bool, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    // 2 ^ 128 huwa madwar 3 * 10 ^ 38, allura 39 jagħti byte żejjed ta 'spazju
    let mut buf = [MaybeUninit::<u8>::uninit(); 39];
    let mut curr = buf.len() as isize;

    let (n, rem) = udiv_1e19(n);
    parse_u64_into(rem, &mut buf, &mut curr);

    if n != 0 {
        // 0 pad sal-punt
        let target = (buf.len() - 19) as isize;
        // SIGURTÀ: Garantit li ktibna mhux aktar minn 19-il byte, u għandu jkun hemm spazju
        // li fadal peress li għandu tul 39
        unsafe {
            ptr::write_bytes(
                MaybeUninit::slice_as_mut_ptr(&mut buf).offset(target),
                b'0',
                (curr - target) as usize,
            );
        }
        curr = target;

        let (n, rem) = udiv_1e19(n);
        parse_u64_into(rem, &mut buf, &mut curr);
        // Dan is-segwenti branch għandu jiġi annotat b'improbabbli?
        if n != 0 {
            let target = (buf.len() - 38) as isize;
            // Il-pointer mhux maħdum `buf_ptr` huwa validu biss sakemm `buf` jintuża d-darba li jmiss, buf `buf` ma jintużax f'dan l-iskop u allura aħna tajbin.
            //
            let buf_ptr = MaybeUninit::slice_as_mut_ptr(&mut buf);
            // SIGURTÀ: F'dan il-punt aħna kiteb l-iktar 38 byte, pad sa dak il-punt,
            // Jista 'jkun fadal biss l-iktar ċifra waħda.
            unsafe {
                ptr::write_bytes(buf_ptr.offset(target), b'0', (curr - target) as usize);
                curr = target - 1;
                *buf_ptr.offset(curr) = (n as u8) + b'0';
            }
        }
    }

    // SIGURTÀ: `curr`> 0 (peress li għamilna `buf` kbir biżżejjed), u l-karattri kollha huma validi
    // UTF-8 peress li `DEC_DIGITS_LUT` huwa
    let buf_slice = unsafe {
        str::from_utf8_unchecked(slice::from_raw_parts(
            MaybeUninit::slice_as_mut_ptr(&mut buf).offset(curr),
            buf.len() - curr as usize,
        ))
    };
    f.pad_integral(is_nonnegative, "", buf_slice)
}

/// Taqsim ta `n` f'n> 1e19 u rem <=1e19
///
/// L-algoritmu tad-diviżjoni tan-numru sħiħ huwa bbażat fuq il-karta li ġejja:
///
///   T. Granlund u P.
///   Montgomery, "Division by Invariant Integers Using Multiplication" fi Proc.
///   tal-Konferenza SIGPLAN94 dwar Id-Disinn u l-Implimentazzjoni tal-Lingwa ta 'Programmar, 1994, pp.
///   61–72
fn udiv_1e19(n: u128) -> (u128, u64) {
    const DIV: u64 = 1e19 as u64;
    const FACTOR: u128 = 156927543384667019095894735580191660403;

    let quot = if n < 1 << 83 {
        ((n >> 19) as u64 / (DIV >> 19)) as u128
    } else {
        u128_mulhi(n, FACTOR) >> 62
    };

    let rem = (n - quot * DIV as u128) as u64;
    (quot, rem)
}

/// Immoltiplika interi ta '128 bit mhux iffirmati, erġa' lura 128 bits ta 'fuq tar-riżultat
#[inline]
fn u128_mulhi(x: u128, y: u128) -> u128 {
    let x_lo = x as u64;
    let x_hi = (x >> 64) as u64;
    let y_lo = y as u64;
    let y_hi = (y >> 64) as u64;

    // jimmaniġġaw possibbiltà ta 'tifwir
    let carry = (x_lo as u128 * y_lo as u128) >> 64;
    let m = x_lo as u128 * y_hi as u128 + carry;
    let high1 = m >> 64;

    let m_lo = m as u64;
    let high2 = (x_hi as u128 * y_lo as u128 + m_lo as u128) >> 64;

    x_hi as u128 * y_hi as u128 + high1 + high2
}