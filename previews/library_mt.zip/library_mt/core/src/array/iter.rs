//! Jiddefinixxi l-iteratur tal-`IntoIter` għall-matriċi.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Iteratur tal-valur sekondarju [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Din hija l-firxa li qed nirrepetu fuqha.
    ///
    /// Elementi b'indiċi `i` fejn `alive.start <= i < alive.end` għadhom ma ngħatawx u huma entrati ta 'array validi.
    /// Elementi b'indiċi `i < alive.start` jew `i >= alive.end` ingħataw diġà u m'għandhomx jiġu aċċessati aktar!Dawk l-elementi mejtin jistgħu saħansitra jkunu fi stat kompletament mhux inizjalizzat!
    ///
    ///
    /// Allura l-invariants huma:
    /// - `data[alive]` huwa ħaj (jiġifieri fih elementi validi)
    /// - `data[..alive.start]` u `data[alive.end..]` huma mejta (jiġifieri l-elementi diġà nqraw u m'għandhomx jintmessu aktar!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// L-elementi f `data` li għadhom ma ġewx mogħtija.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Joħloq iteratur ġdid fuq ix-`array` mogħti.
    ///
    /// *Nota*: dan il-metodu jista 'jkun deprezzat fiż-future, wara [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // It-tip ta `value` huwa `i32` hawn, minflok `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SIGURTÀ: It-transmute hawnhekk huwa attwalment sigur.Id-dokumenti ta `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` huwa garantit li jkollu l-istess daqs u allinjament
        // > bħala `T`.
        //
        // Id-dokumenti juru anke transmute minn firxa ta `MaybeUninit<T>` għal firxa ta' `T`.
        //
        //
        // B'dan, din l-inizjalizzazzjoni tissodisfa l-invariants.

        // FIXME(LukasKalbertodt): attwalment uża `mem::transmute` hawn, ladarba taħdem mal-ġeneriċi kost:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Sa dakinhar, nistgħu nużaw `mem::transmute_copy` biex noħolqu kopja bitwise bħala tip differenti, imbagħad ninsew `array` sabiex ma titwaqqax.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Jirritorna porzjon immutabbli tal-elementi kollha li għadhom ma ġewx mogħtija.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SIGURTÀ: Aħna nafu li l-elementi kollha fi `alive` huma inizjalizzati kif suppost.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Jirritorna porzjon li jista 'jinbidel mill-elementi kollha li għadhom ma ġewx mogħtija.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SIGURTÀ: Aħna nafu li l-elementi kollha fi `alive` huma inizjalizzati kif suppost.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Ikseb l-indiċi li jmiss minn quddiem.
        //
        // Iż-żieda ta `alive.start` b'1 iżżomm l-invariant rigward `alive`.
        // Madankollu, minħabba din il-bidla, għal żmien qasir, iż-żona ħajja m'għadhiex `data[alive]`, iżda `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Aqra l-element mill-firxa.
            // SIGURTÀ: `idx` huwa indiċi fir-reġjun ta 'qabel "alive" ta'
            // firxa.Il-qari ta 'dan l-element ifisser li `data[idx]` huwa meqjus bħala mejjet issa (jiġifieri tmissx).
            // Peress li `idx` kien il-bidu taż-żona ħajja, iż-żona ħajja issa hija `data[alive]` mill-ġdid, u tirrestawra l-invarianti kollha.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Ikseb l-indiċi li jmiss minn wara.
        //
        // It-tnaqqis ta `alive.end` b'1 iżomm l-invariant rigward `alive`.
        // Madankollu, minħabba din il-bidla, għal żmien qasir, iż-żona ħajja m'għadhiex `data[alive]`, iżda `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Aqra l-element mill-firxa.
            // SIGURTÀ: `idx` huwa indiċi fir-reġjun ta 'qabel "alive" ta'
            // firxa.Il-qari ta 'dan l-element ifisser li `data[idx]` huwa meqjus bħala mejjet issa (jiġifieri tmissx).
            // Peress li `idx` kien it-tmiem taż-żona ħajja, iż-żona ħajja issa hija `data[alive]` mill-ġdid, u rrestawra l-invarianti kollha.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SIGURTÀ: Dan huwa sigur: `as_mut_slice` jirritorna eżattament is-sub-porzjon
        // ta `elementi li għadhom ma ġewx imċaqalqa u li għad iridu jitwaqqgħu.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Qatt ma jinfluwenza minħabba l-invariant `ħaj.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// L-iteratur tabilħaqq jirrapporta t-tul korrett.
// In-numru ta 'elementi "alive" (li xorta se jingħata) huwa t-tul tal-firxa `alive`.
// Din il-firxa hija mnaqqsa fit-tul jew f `next` jew `next_back`.
// Huwa dejjem imnaqqas b'1 f'dawk il-metodi, iżda biss jekk `Some(_)` jiġi rritornat.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Innota, ma tantx għandna bżonn inqabblu l-istess firxa ħajja eżatta, u għalhekk nistgħu sempliċement nikklonaw f'offset 0 irrispettivament minn fejn hu `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Ikklona l-elementi ħajjin kollha.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Ikteb klonu fil-firxa l-ġdida, imbagħad aġġorna l-firxa ħajja tagħha.
            // Jekk il-klonazzjoni ta 'panics, inwaqqgħu b'mod korrett l-oġġetti ta' qabel.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Ipprintja biss l-elementi li għadhom ma ġewx: ma nistgħux naċċessaw l-elementi mogħtija aktar.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}