use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Tip ta 'tgeżwir biex tibni istanzi mhux inizjalizzati ta' `T`.
///
/// # Invariant tal-inizjalizzazzjoni
///
/// Il-kompilatur, b'mod ġenerali, jassumi li varjabbli hija inizjalizzata kif suppost skond ir-rekwiżiti tat-tip tal-varjabbli.Pereżempju, varjabbli tat-tip ta 'referenza għandha tkun allinjata u mhux NULL.
/// Din hija invarjanti li għandha *dejjem* tiġi kkonfermata, anke f'kodiċi mhux sikuri.
/// Bħala konsegwenza, l-inizjalizzazzjoni żero ta 'varjabbli tat-tip ta' referenza tikkawża [undefined behavior][ub] istantanja, irrispettivament minn jekk dik ir-referenza qatt tidra biex taċċessa l-memorja:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // imġieba mhux definita!⚠️
/// // Il-kodiċi ekwivalenti b `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // imġieba mhux definita!⚠️
/// ```
///
/// Dan huwa sfruttat mill-kompilatur għal diversi ottimizzazzjonijiet, bħall-eliġiment tal-verifiki fuq il-ħin tal-eżekuzzjoni u l-ottimizzazzjoni tat-tqassim `enum`.
///
/// Bl-istess mod, memorja kompletament mhux inizjalizzata jista 'jkollha kwalunkwe kontenut, filwaqt li `bool` għandu dejjem ikun `true` jew `false`.Għalhekk, il-ħolqien ta `bool` mhux inizjalizzat huwa mġieba mhux definita:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // imġieba mhux definita!⚠️
/// // Il-kodiċi ekwivalenti b `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // imġieba mhux definita!⚠️
/// ```
///
/// Barra minn hekk, memorja mhux inizjalizzata hija speċjali fis-sens li m'għandhiex valur fiss ("fixed" li jfisser "it won't change without being written to").Il-qari tal-istess byte mhux inizjalizzat bosta drabi jista 'jagħti riżultati differenti.
/// Dan jagħmilha imġieba mhux definita li jkollok dejta mhux inizjalizzata f'varjabbli anke jekk dik il-varjabbli għandha tip sħiħ, li altrimenti jista 'jkollu kwalunkwe mudell ta' bit *fiss*:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // imġieba mhux definita!⚠️
/// // Il-kodiċi ekwivalenti b `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // imġieba mhux definita!⚠️
/// ```
/// (Innota li r-regoli madwar numri interi mhux inizjalizzati għadhom mhumiex finalizzati, iżda sakemm ikunu hekk, huwa rrakkomandat li jiġu evitati.)
///
/// Barra minn dan, ftakar li l-biċċa l-kbira tat-tipi għandhom invarjanti addizzjonali lil hinn milli sempliċement jiġu kkunsidrati inizjalizzati fil-livell tat-tip.
/// Pereżempju, [`Vec<T>`] inizjalizzat b '"1" huwa kkunsidrat inizjalizzat (taħt l-implimentazzjoni kurrenti; dan ma jikkostitwixxix garanzija stabbli) minħabba li l-uniku rekwiżit li l-kompilatur jaf dwaru huwa li l-indikatur tad-dejta m'għandux ikun null.
/// Il-ħolqien ta `Vec<T>` bħal dan ma jikkawżax imġieba *immedjata* mhux definita, iżda tikkawża imġieba mhux definita b'ħafna operazzjonijiet siguri (inkluż li twaqqa').
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` iservi biex jippermetti kodiċi mhux sikur biex jittratta dejta mhux inizjalizzata.
/// Huwa sinjal lill-kompilatur li jindika li d-dejta hawn tista '*ma* tkun inizjalizzata *:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Oħloq referenza espliċitament mhux inizjalizzata.
/// // Il-kompilatur jaf li d-dejta ġewwa `MaybeUninit<T>` tista 'tkun invalida, u għalhekk din mhix UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Issettjah għal valur validu.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Oħroġ id-dejta inizjalizzata-din hija permessa biss * wara li inizjalizza sew `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Il-kompilatur imbagħad jaf li ma jagħmel l-ebda suppożizzjoni jew ottimizzazzjoni skorretta fuq dan il-kodiċi.
///
/// Tista 'taħseb f `MaybeUninit<T>` bħala daqsxejn bħal `Option<T>` iżda mingħajr l-ebda traċċar tal-ħin tal-ġirja u mingħajr l-ebda kontroll tas-sigurtà.
///
/// ## out-pointers
///
/// Tista 'tuża `MaybeUninit<T>` biex timplimenta "out-pointers": minflok tirritorna dejta minn funzjoni, għaddiha pointer għal xi memorja (uninitialized) biex ipoġġi r-riżultat.
/// Dan jista 'jkun utli meta jkun importanti għal dak li jċempel biex jikkontrolla kif tiġi allokata l-memorja tar-riżultat, u trid tevita movimenti bla bżonn.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ma jwaqqax il-kontenut qadim, li huwa importanti.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Issa nafu li `v` huwa inizjalizzat!Dan jiżgura wkoll li ż-vector jitwaqqa 'sewwa.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## L-inizjalizzazzjoni ta 'firxa element b'element
///
/// `MaybeUninit<T>` jista 'jintuża biex jinizjalizza firxa kbira element b'element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Oħloq firxa mhux inizjalizzata ta `MaybeUninit`.
///     // Ix-`assume_init` huwa sigur għax it-tip li qed ngħidu li inizjalizzaw hawnhekk huwa mazz ta '' MaybeUninit`s, li ma jeħtiġux inizjalizzazzjoni.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // It-twaqqigħ ta `MaybeUninit` ma jagħmel xejn.
///     // Għalhekk l-użu ta 'assenjazzjoni ta' pointer mhux maħdum minflok `ptr::write` ma jikkawżax li jitwaqqa 'l-valur antik mhux inizjalizzat.
/////
///     // Ukoll jekk hemm panic matul dan iċ-ċirku, għandna tnixxija tal-memorja, iżda m'hemm l-ebda kwistjoni ta 'sigurtà tal-memorja.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Kollox huwa inizjalizzat.
///     // Ittrasmetti l-firxa għat-tip inizjalizzat.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Tista 'taħdem ukoll ma' matriċi parzjalment inizjalizzati, li jistgħu jinstabu f'strutturi tad-dejta ta 'livell baxx.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Oħloq firxa mhux inizjalizzata ta `MaybeUninit`.
/// // Ix-`assume_init` huwa sigur għax it-tip li qed ngħidu li inizjalizzaw hawnhekk huwa mazz ta '' MaybeUninit`s, li ma jeħtiġux inizjalizzazzjoni.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Għodd in-numru ta 'elementi li assenjajna.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Għal kull oġġett fil-firxa, waqqa 'jekk allokajnih.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## L-inizjalizzazzjoni ta 'struttura qasam b'qasam
///
/// Tista 'tuża `MaybeUninit<T>`, u l-makro [`std::ptr::addr_of_mut`], biex tibda l-istrutturi qasam b'qasam:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inizjalizzazzjoni tal-qasam `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inizjalizzazzjoni tal-kamp `list` Jekk hawn panic hawn, allura l-`String` fil-qasam `name` jnixxi.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // L-oqsma kollha huma inizjalizzati, allura nsejħu `assume_init` biex tikseb Foo inizjalizzat.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` huwa garantit li jkollu l-istess daqs, allinjament, u ABI bħal `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Madankollu ftakar li tip *li fih*`MaybeUninit<T>` mhux neċessarjament l-istess tqassim;Rust b'mod ġenerali ma jiggarantixxix li l-oqsma ta `Foo<T>` għandhom l-istess ordni bħal `Foo<U>` anke jekk `T` u `U` għandhom l-istess daqs u allinjament.
///
/// Barra minn hekk minħabba li kwalunkwe valur bit huwa validu għal `MaybeUninit<T>` il-kompilatur ma jistax japplika ottimizzazzjonijiet non-zero/niche-filling, li potenzjalment jirriżultaw f'daqs akbar:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Jekk `T` huwa sikur għall-FFI, allura `MaybeUninit<T>` ukoll.
///
/// Filwaqt li `MaybeUninit` huwa `#[repr(transparent)]` (jindika li jiggarantixxi l-istess daqs, allinjament u ABI bħal `T`), dan ma *jbiddel* l-ebda twissija preċedenti.
/// `Option<T>` u `Option<MaybeUninit<T>>` xorta jista 'jkollhom daqsijiet differenti, u tipi li fihom qasam ta' tip `T` jistgħu jiġu mqassma (u mkejla) b'mod differenti minn kieku dak il-qasam kien `MaybeUninit<T>`.
/// `MaybeUninit` huwa tip ta 'unjoni, u `#[repr(transparent)]` fuq unjonijiet mhuwiex stabbli (ara [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Maż-żmien, il-garanziji eżatti ta `#[repr(transparent)]` fuq unions jistgħu jevolvu, u `MaybeUninit` jista' jibqa `#[repr(transparent)]` jew le.
/// Dak kollu li qal, `MaybeUninit<T>`*dejjem* jiggarantixxi li għandu l-istess daqs, allinjament, u ABI bħal `T`;huwa biss li l-mod kif `MaybeUninit` jimplimenta dik il-garanzija jista 'jevolvi.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Oġġett Lang sabiex inkunu nistgħu ngeżwru tipi oħra fih.Dan huwa utli għall-ġeneraturi.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Mhux insejħu lil `T::clone()`, ma nistgħux inkunu nafu jekk inkunux inizjalizzati biżżejjed għal dak.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Joħloq `MaybeUninit<T>` ġdid inizjalizzat bil-valur mogħti.
    /// Huwa sigur li ċċempel [`assume_init`] fuq il-valur tar-ritorn ta 'din il-funzjoni.
    ///
    /// Innota li t-twaqqigħ ta `MaybeUninit<T>` qatt ma jsejjaħ il-kodiċi tal-waqgħa ta' "T"
    /// Hija r-responsabbiltà tiegħek li tiżgura li `T` jitwaqqa 'jekk jiġi inizjalizzat.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Joħloq `MaybeUninit<T>` ġdid fi stat mhux inizjalizzat.
    ///
    /// Innota li t-twaqqigħ ta `MaybeUninit<T>` qatt ma jsejjaħ il-kodiċi tal-waqgħa ta' "T"
    /// Hija r-responsabbiltà tiegħek li tiżgura li `T` jitwaqqa 'jekk jiġi inizjalizzat.
    ///
    /// Ara x-[type-level documentation][MaybeUninit] għal xi eżempji.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Oħloq firxa ġdida ta 'oġġetti `MaybeUninit<T>`, fi stat mhux inizjalizzat.
    ///
    /// Note: f'verżjoni future Rust dan il-metodu jista 'ma jkunx meħtieġ meta s-sintassi litterali tal-firxa tippermetti [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// L-eżempju hawn taħt jista 'mbagħad juża `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Jirritorna porzjon ta 'dejta (possibilment iżgħar) li fil-fatt inqrat
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SIGURTÀ: `[MaybeUninit<_>; LEN]` mhux inizjalizzat huwa validu.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Joħloq `MaybeUninit<T>` ġdid fi stat mhux inizjalizzat, bil-memorja timtela b'Bytes `0`.Jiddependi fuq `T` jekk dan diġà jagħmilx inizjalizzazzjoni xierqa.
    ///
    /// Pereżempju, `MaybeUninit<usize>::zeroed()` huwa inizjalizzat, iżda `MaybeUninit<&'static i32>::zeroed()` mhux għaliex ir-referenzi m'għandhomx ikunu nulli.
    ///
    /// Innota li t-twaqqigħ ta `MaybeUninit<T>` qatt ma jsejjaħ il-kodiċi tal-waqgħa ta' "T"
    /// Hija r-responsabbiltà tiegħek li tiżgura li `T` jitwaqqa 'jekk jiġi inizjalizzat.
    ///
    /// # Example
    ///
    /// Użu korrett ta 'din il-funzjoni: inizjalizzazzjoni ta' struttura b'żero, fejn l-oqsma kollha tal-istruttura jistgħu jżommu l-mudell tal-bit 0 bħala valur validu.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// * Użu mhux korrett ta 'din il-funzjoni: sejħa lil `x.zeroed().assume_init()` meta `0` mhuwiex mudell ta' bit validu għat-tip:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Ġewwa par, noħolqu `NotZero` li m'għandux diskriminant validu.
    /// // Din hija mġieba mhux definita.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SIGURTÀ: `u.as_mut_ptr()` jindika l-memorja allokata.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Issettja l-valur tax-`MaybeUninit<T>`.
    /// Dan jissostitwixxi kwalunkwe valur preċedenti mingħajr ma twaqqa ', allura jkun attent li ma tużax dan darbtejn sakemm ma tridx taqbeż it-tmexxija tad-distruttur.
    ///
    /// Għall-konvenjenza tiegħek, dan jirritorna wkoll referenza li tista 'tinbidel għall-kontenuti (issa inizjalizzati b'mod sikur) ta' `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SIGURTÀ: Aħna biss inizjalizzajna dan il-valur.
        unsafe { self.assume_init_mut() }
    }

    /// Tikseb pointer għall-valur li jinsab.
    /// Il-qari minn dan il-pointer jew it-tibdil tiegħu f'referenza huwa mġieba mhux definita sakemm ix-`MaybeUninit<T>` ma tkunx inizjalizzata.
    /// Il-kitba fil-memorja li dan il-pointer (non-transitively) jindika hija mġieba mhux definita (ħlief ġewwa `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Użu korrett ta 'dan il-metodu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Oħloq referenza fix-`MaybeUninit<T>`.Dan tajjeb għax inizjalizzawha.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// Użu * mhux korrett ta 'dan il-metodu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Ħloqna referenza għal vector mhux inizjalizzat!Din hija mġieba mhux definita.⚠️
    /// ```
    ///
    /// (Innota li r-regoli dwar ir-referenzi għal dejta mhux inizjalizzata għadhom mhumiex finalizzati, iżda sakemm ikunu hekk, huwa rrakkomandat li jiġu evitati.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` u `ManuallyDrop` huma t-tnejn `repr(transparent)` sabiex inkunu nistgħu nitfgħu l-pointer.
        self as *const _ as *const T
    }

    /// Tikseb pointer li jista 'jinbidel għall-valur li jinsab.
    /// Il-qari minn dan il-pointer jew it-tibdil tiegħu f'referenza huwa mġieba mhux definita sakemm ix-`MaybeUninit<T>` ma tkunx inizjalizzata.
    ///
    /// # Examples
    ///
    /// Użu korrett ta 'dan il-metodu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Oħloq referenza fix-`MaybeUninit<Vec<u32>>`.
    /// // Dan tajjeb għax inizjalizzawha.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// Użu * mhux korrett ta 'dan il-metodu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Ħloqna referenza għal vector mhux inizjalizzat!Din hija mġieba mhux definita.⚠️
    /// ```
    ///
    /// (Innota li r-regoli dwar ir-referenzi għal dejta mhux inizjalizzata għadhom mhumiex finalizzati, iżda sakemm ikunu hekk, huwa rrakkomandat li jiġu evitati.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` u `ManuallyDrop` huma t-tnejn `repr(transparent)` sabiex inkunu nistgħu nitfgħu l-pointer.
        self as *mut _ as *mut T
    }

    /// Oħroġ il-valur mill-kontenitur `MaybeUninit<T>`.Dan huwa mod tajjeb ħafna biex jiġi żgurat li d-dejta tinżel, għax ix-`T` li jirriżulta huwa suġġett għall-immaniġġjar tas-soltu tal-waqgħat.
    ///
    /// # Safety
    ///
    /// Huwa f'idejn min iċempel li jiggarantixxi li x-`MaybeUninit<T>` verament jinsab fi stat inizjalizzat.Li ssejjaħ dan meta l-kontenut għadu mhux inizjalizzat kompletament jikkawża imġieba immedjata mhux definita.
    /// Ix-[type-level documentation][inv] fih aktar informazzjoni dwar din l-invariant tal-inizjalizzazzjoni.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Barra minn dan, ftakar li l-biċċa l-kbira tat-tipi għandhom invarjanti addizzjonali lil hinn milli sempliċement jiġu kkunsidrati inizjalizzati fil-livell tat-tip.
    /// Pereżempju, [`Vec<T>`] inizjalizzat b '"1" huwa kkunsidrat inizjalizzat (taħt l-implimentazzjoni kurrenti; dan ma jikkostitwixxix garanzija stabbli) minħabba li l-uniku rekwiżit li l-kompilatur jaf dwaru huwa li l-indikatur tad-dejta m'għandux ikun null.
    ///
    /// Il-ħolqien ta `Vec<T>` bħal dan ma jikkawżax imġieba *immedjata* mhux definita, iżda tikkawża imġieba mhux definita b'ħafna operazzjonijiet siguri (inkluż li twaqqa').
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Użu korrett ta 'dan il-metodu:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// Użu * mhux korrett ta 'dan il-metodu:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` kienet għadha ma ġietx inizjalizzata, allura din l-aħħar linja kkawżat imġieba mhux definita.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jiġi inizjalizzat.
        // Dan ifisser ukoll li `self` għandu jkun varjant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Aqra l-valur mill-kontenitur `MaybeUninit<T>`.Ix-`T` li jirriżulta huwa suġġett għall-immaniġġar tas-soltu tal-waqgħat.
    ///
    /// Kull meta jkun possibbli, huwa preferibbli li tuża [`assume_init`] minflok, li ma jħallix li d-duplikazzjoni tal-kontenut tax-`MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Huwa f'idejn min iċempel li jiggarantixxi li x-`MaybeUninit<T>` verament jinsab fi stat inizjalizzat.Li ssejjaħ dan meta l-kontenut għadu mhux inizjalizzat għal kollox jikkawża imġieba mhux definita.
    /// Ix-[type-level documentation][inv] fih aktar informazzjoni dwar din l-invariant tal-inizjalizzazzjoni.
    ///
    /// Barra minn hekk, dan iħalli kopja tal-istess dejta lura fix-`MaybeUninit<T>`.
    /// Meta tuża kopji multipli tad-dejta (billi ċċempel `assume_init_read` bosta drabi, jew l-ewwel ċempel lil `assume_init_read` u mbagħad lil [`assume_init`]), hija r-responsabbiltà tiegħek li tiżgura li dik id-dejta tista 'tabilħaqq tiġi duplikata.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Użu korrett ta 'dan il-metodu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` huwa `Copy`, allura nistgħu naqraw bosta drabi.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Id-duplikazzjoni ta 'valur `None` hija tajba, allura nistgħu naqraw bosta drabi.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// Użu * mhux korrett ta 'dan il-metodu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Issa ħloqna żewġ kopji tal-istess vector, li jwassal għal free️ b'xejn doppju meta t-tnejn jitwaqqgħu!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jiġi inizjalizzat.
        // Il-qari minn `self.as_ptr()` huwa sigur peress li `self` għandu jkun inizjalizzat.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Twaqqa 'l-valur miżmum f'postu.
    ///
    /// Jekk għandek is-sjieda tax-`MaybeUninit`, tista 'tuża [`assume_init`] minflok.
    ///
    /// # Safety
    ///
    /// Huwa f'idejn min iċempel li jiggarantixxi li x-`MaybeUninit<T>` verament jinsab fi stat inizjalizzat.Li ssejjaħ dan meta l-kontenut għadu mhux inizjalizzat għal kollox jikkawża imġieba mhux definita.
    ///
    /// Barra minn hekk, l-invarianti addizzjonali kollha tat-tip `T` għandhom ikunu sodisfatti, billi l-implimentazzjoni `Drop` ta `T` (jew il-membri tagħha) tista' tistrieħ fuq dan.
    /// Pereżempju, [`Vec<T>`] inizjalizzat b '"1" huwa kkunsidrat inizjalizzat (taħt l-implimentazzjoni kurrenti; dan ma jikkostitwixxix garanzija stabbli) minħabba li l-uniku rekwiżit li l-kompilatur jaf dwaru huwa li l-indikatur tad-dejta m'għandux ikun null.
    ///
    /// It-twaqqigħ ta `Vec<T>` bħal dan madankollu jikkawża imġieba mhux definita.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jiġi inizjalizzat u
        // jissodisfa l-invariants kollha ta `T`.
        // It-twaħħil tal-valur fil-post huwa sigur jekk dak huwa l-każ.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Tikseb referenza kondiviża għall-valur miżmum.
    ///
    /// Dan jista 'jkun utli meta rridu nidħlu għal `MaybeUninit` li ġie inizjalizzat iżda m'għandux pussess ta' `MaybeUninit` (jipprevjeni l-użu ta `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Li ssejjaħ dan meta l-kontenut għadu mhux inizjalizzat għal kollox jikkawża imġieba mhux definita: huwa f'idejn min iċempel li jiggarantixxi li x-`MaybeUninit<T>` verament jinsab fi stat inizjalizzat.
    ///
    ///
    /// # Examples
    ///
    /// ### Użu korrett ta 'dan il-metodu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inizjalizza `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Issa li `MaybeUninit<_>` tagħna huwa magħruf li ġie inizjalizzat, huwa tajjeb li toħloq referenza komuni għalih:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SIGURTÀ: `x` ġie inizjalizzat.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### Użi *żbaljati* ta 'dan il-metodu:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Ħloqna referenza għal vector mhux inizjalizzat!Din hija mġieba mhux definita.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inizjalizza l-`MaybeUninit` billi tuża `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Referenza għal `Cell<bool>` mhux inizjalizzat: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jiġi inizjalizzat.
        // Dan ifisser ukoll li `self` għandu jkun varjant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Tikseb referenza (unique) li tista 'tinbidel għall-valur kontenut.
    ///
    /// Dan jista 'jkun utli meta rridu nidħlu għal `MaybeUninit` li ġie inizjalizzat iżda m'għandux pussess ta' `MaybeUninit` (jipprevjeni l-użu ta `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Li ssejjaħ dan meta l-kontenut għadu mhux inizjalizzat għal kollox jikkawża imġieba mhux definita: huwa f'idejn min iċempel li jiggarantixxi li x-`MaybeUninit<T>` verament jinsab fi stat inizjalizzat.
    /// Pereżempju, `.assume_init_mut()` ma jistax jintuża biex inizjalizza `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Użu korrett ta 'dan il-metodu:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inizjalizza *il-bytes kollha* tal-buffer tal-input.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inizjalizza `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Issa nafu li `buf` ġie inizjalizzat, allura nistgħu `.assume_init()`.
    /// // Madankollu, l-użu ta `.assume_init()` jista' jwassal għal `memcpy` tal-2048 bytes.
    /// // Biex nasserixxu li l-buffer tagħna ġie inizjalizzat mingħajr ma nikkupjawh, aħna ntejbu x-`&mut MaybeUninit<[u8; 2048]>` għal `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SIGURTÀ: `buf` ġie inizjalizzat.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Issa nistgħu nużaw `buf` bħala porzjon normali:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### Użi *żbaljati* ta 'dan il-metodu:
    ///
    /// Ma tistax tuża `.assume_init_mut()` biex tibda valur:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Ħloqna referenza (mutable) għal `bool` mhux inizjalizzata!
    ///     // Din hija mġieba mhux definita.⚠️
    /// }
    /// ```
    ///
    /// Pereżempju, ma tistax [`Read`] f'buffer mhux inizjalizzat:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) referenza għal memorja mhux inizjalizzata!
    ///                             // Din hija mġieba mhux definita.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Lanqas ma tista 'tuża aċċess dirett fuq il-post biex tagħmel inizjalizzazzjoni gradwali qasam b'qasam:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referenza għal memorja mhux inizjalizzata!
    ///                  // Din hija mġieba mhux definita.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) referenza għal memorja mhux inizjalizzata!
    ///                  // Din hija mġieba mhux definita.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Bħalissa niddependu fuq dan ta 'hawn fuq mhux korrett, jiġifieri, għandna referenzi għal dejta mhux inizjalizzata (eż. F `libcore/fmt/float.rs`).
    // Għandna nieħdu deċiżjoni finali dwar ir-regoli qabel l-istabbilizzazzjoni.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SIGURTÀ: min iċempel għandu jiggarantixxi li `self` jiġi inizjalizzat.
        // Dan ifisser ukoll li `self` għandu jkun varjant `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Oħroġ il-valuri minn firxa ta 'kontenituri `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Huwa f'idejn min iċempel li jiggarantixxi li l-elementi kollha tal-firxa huma fi stat inizjalizzat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SIGURTÀ: Issa sikur hekk kif inizjalizzajna l-elementi kollha
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Min iċempel jiggarantixxi li l-elementi kollha tal-firxa jiġu inizjalizzati
        // * `MaybeUninit<T>` u T huma garantiti li għandhom l-istess tqassim
        // * ForsiUnint ma jonqosx, allura m'hemmx free-double U b'hekk il-konverżjoni hija sigura
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Jekk wieħed jassumi li l-elementi kollha huma inizjalizzati, ġibhom porzjon.
    ///
    /// # Safety
    ///
    /// Huwa f'idejn min iċempel li jiggarantixxi li l-elementi `MaybeUninit<T>` huma verament fi stat inizjalizzat.
    ///
    /// Li ssejjaħ dan meta l-kontenut għadu mhux inizjalizzat għal kollox jikkawża imġieba mhux definita.
    ///
    /// Ara [`assume_init_ref`] għal aktar dettalji u eżempji.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SIGURTÀ: il-porzjon tal-ikkastjar għal `*const [T]` huwa sigur peress li min iċempel jiggarantixxi dan
        // `slice` hija inizjalizzata, u "Forsi Uninit" huwa garantit li jkollu l-istess tqassim bħal `T`.
        // Il-pointer miksub huwa validu peress li jirreferi għal memorja li hija proprjetà ta `slice` li hija referenza u għalhekk garantita li tkun valida għal qari.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Jekk wieħed jassumi li l-elementi kollha huma inizjalizzati, ġibhom porzjon li jista 'jinbidel.
    ///
    /// # Safety
    ///
    /// Huwa f'idejn min iċempel li jiggarantixxi li l-elementi `MaybeUninit<T>` huma verament fi stat inizjalizzat.
    ///
    /// Li ssejjaħ dan meta l-kontenut għadu mhux inizjalizzat għal kollox jikkawża imġieba mhux definita.
    ///
    /// Ara [`assume_init_mut`] għal aktar dettalji u eżempji.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SIGURTÀ: simili għan-noti ta 'sigurtà għal `slice_get_ref`, imma għandna
        // referenza li tista 'tinbidel li hija garantita wkoll li tkun valida għal kitbiet.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Jikseb pointer għall-ewwel element tal-firxa.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Jikseb pointer li jista 'jinbidel għall-ewwel element tal-firxa.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Ikkopja l-elementi minn `src` għal `this`, billi tirritorna referenza li tista 'tinbidel għall-kontenuti issa initalizzati ta' `this`.
    ///
    /// Jekk `T` ma jimplimentax `Copy`, uża [`write_slice_cloned`]
    ///
    /// Dan huwa simili għal [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Din il-funzjoni tkun panic jekk iż-żewġ flieli jkollhom tulijiet differenti.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURTÀ: għadna kemm ikkuppjajna l-elementi kollha tal-len fil-kapaċità żejda
    /// // l-ewwel elementi src.len() tal-vec huma validi issa.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SIGURTÀ: &[T] u&[ForsiUnit<T>] għandhom l-istess tqassim
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SIGURTÀ: Elementi validi għadhom kemm ġew ikkupjati f `this` u għalhekk huwa initalizzat
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Ikklona l-elementi minn `src` sa `this`, billi tirritorna referenza li tista 'tinbidel għall-kontenuti issa initalizzati ta' `this`.
    /// Kwalunkwe element diġà initalizzat mhux se jitwaqqa '.
    ///
    /// Jekk `T` jimplimenta `Copy`, uża [`write_slice`]
    ///
    /// Dan huwa simili għal [`slice::clone_from_slice`] iżda ma jwaqqax elementi eżistenti.
    ///
    /// # Panics
    ///
    /// Din il-funzjoni tkun panic jekk iż-żewġ flieli jkollhom tulijiet differenti, jew jekk l-implimentazzjoni ta `Clone` panics.
    ///
    /// Jekk hemm panic, l-elementi diġà kklonati jitwaqqgħu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIGURTÀ: għadna kif ikklonajna l-elementi kollha tal-len fil-kapaċità żejda
    /// // l-ewwel elementi src.len() tal-vec huma validi issa.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // kuntrarjament għal copy_from_slice dan ma jsejjaħx clone_from_slice fuq is-slice dan minħabba li `MaybeUninit<T: Clone>` ma jimplimentax Klonu.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SIGURTÀ: din il-porzjon nej se jkun fiha biss oġġetti inizjalizzati
                // hu għalhekk, huwa permess li twaqqa '.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Għandna bżonn naqtgħuhom b'mod espliċitu bl-istess tul
        // biex il-kontrolli tal-limiti jiġu eliminati, u l-ottimizzatur jiġġenera memcpy għal każijiet sempliċi (pereżempju T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // hemm bżonn ta 'gwardja b/c panic jista' jiġri waqt klonu
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SIGURTÀ: Elementi validi għadhom kemm ġew miktuba f `this` u għalhekk huwa initalizzat
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}