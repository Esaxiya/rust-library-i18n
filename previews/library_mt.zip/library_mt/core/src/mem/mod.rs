//! Funzjonijiet bażiċi biex tittratta l-memorja.
//!
//! Dan il-modulu fih funzjonijiet għall-mistoqsija dwar id-daqs u l-allinjament tat-tipi, l-inizjalizzazzjoni u l-manipulazzjoni tal-memorja.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Jieħu s-sjieda u "forgets" dwar il-valur **mingħajr ma jmexxi d-distruttur tiegħu**.
///
/// Kwalunkwe riżorsi li l-valur jimmaniġġja, bħal memorja tal-borġ jew file handle, jibqgħu għal dejjem fi stat li ma jistax jintlaħaq.Madankollu, ma tiggarantix li indikazzjonijiet għal din il-memorja jibqgħu validi.
///
/// * Jekk trid tnixxi memorja, ara [`Box::leak`].
/// * Jekk trid tikseb pointer nej għall-memorja, ara [`Box::into_raw`].
/// * Jekk trid tiddisponi minn valur sew, billi tħaddem id-distruttur tiegħu, ara [`mem::drop`].
///
/// # Safety
///
/// `forget` mhix immarkata bħala `unsafe`, minħabba li l-garanziji tas-sigurtà ta 'Rust ma jinkludux garanzija li d-distrutturi dejjem jaħdmu.
/// Pereżempju, programm jista 'joħloq ċiklu ta' referenza billi juża [`Rc`][rc], jew isejjaħ lil [`process::exit`][exit] biex joħroġ mingħajr ma jmexxi destructors.
/// Għalhekk, li tippermetti lil `mem::forget` minn kodiċi sigur ma jbiddilx fundamentalment il-garanziji ta 'sigurtà ta' Rust.
///
/// Cela dit, it-tnixxija ta 'riżorsi bħal memorja jew oġġetti I/O ġeneralment mhix mixtieqa.
/// Il-ħtieġa tqum f'xi każijiet ta 'użu speċjalizzati għal FFI jew kodiċi mhux sikur, iżda anke dakinhar, [`ManuallyDrop`] huwa tipikament preferut.
///
/// Minħabba li tinsa valur huwa permess, kull kodiċi `unsafe` li tikteb għandu jippermetti din il-possibbiltà.Ma tistax tirritorna valur u tistenna li min iċempel neċessarjament imexxi d-distruttur tal-valur.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// L-użu kanoniku sikur ta `mem::forget` huwa li jaħrab mid-distruttur ta' valur implimentat mix-`Drop` trait.Pereżempju, dan se jnixxi `File`, jiġifieri
/// titlob lura l-ispazju meħud mill-varjabbli imma qatt ma tagħlaq ir-riżorsa tas-sistema sottostanti:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dan huwa utli meta s-sjieda tar-riżorsa sottostanti kienet preċedentement trasferita għal kodiċi barra minn Rust, pereżempju billi tittrażmetti d-deskrittur tal-fajl mhux ipproċessat għall-kodiċi C.
///
/// # Relazzjoni ma `ManuallyDrop`
///
/// Filwaqt li `mem::forget` jista 'jintuża wkoll biex jittrasferixxi s-sjieda tal-*memorja*, li tagħmel dan huwa suxxettibbli għall-iżbalji.
/// [`ManuallyDrop`] għandhom jintużaw minflok.Ikkunsidra, per eżempju, dan il-kodiċi:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Ibni `String` billi tuża l-kontenut ta `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // tnixxija `v` minħabba li l-memorja tagħha issa hija ġestita minn `s`
/// mem::forget(v);  // ŻBALL, v huwa invalidu u m'għandux jgħaddi għal funzjoni
/// assert_eq!(s, "Az");
/// // `s` hija impliċitament imwaqqa 'u l-memorja tagħha hija allokata.
/// ```
///
/// Hemm żewġ kwistjonijiet bl-eżempju ta 'hawn fuq:
///
/// * Jekk jiżdiedu aktar kodiċi bejn il-kostruzzjoni ta `String` u l-invokazzjoni ta' `mem::forget()`, panic fi ħdanu jikkawża liberu doppju minħabba li l-istess memorja hija mmaniġġjata kemm minn `v` kif ukoll minn `s`.
/// * Wara li ċċempel lil `v.as_mut_ptr()` u tittrażmetti s-sjieda tad-dejta lil `s`, il-valur `v` huwa invalidu.
/// Anke meta valur jiġi mċaqlaq għal `mem::forget` (li mhux se jispezzjonah), xi tipi għandhom rekwiżiti stretti fuq il-valuri tagħhom li jagħmluhom invalidi meta jitbandlu jew ma jibqgħux proprjetà.
/// L-użu ta 'valuri invalidi b'xi mod, inkluż li tgħaddihom jew tirritornahom minn funzjonijiet, jikkostitwixxi imġieba mhux definita u jista' jikser is-suppożizzjonijiet magħmula mill-kompilatur.
///
/// Il-bidla għal `ManuallyDrop` tevita ż-żewġ kwistjonijiet:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Qabel ma niżżarmaw `v` fil-partijiet nej tiegħu, kun żgur li ma jitwaqqax!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Issa żarma `v`.Dawn l-operazzjonijiet ma jistgħux panic, allura ma jistax ikun hemm tnixxija.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Fl-aħħarnett, ibni `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` hija impliċitament imwaqqa 'u l-memorja tagħha hija allokata.
/// ```
///
/// `ManuallyDrop` jipprevjeni bil-qawwa ħielsa mid-doppju għax ineħħu d-distruttur ta '"v" qabel ma nagħmlu xi ħaġa oħra.
/// `mem::forget()` ma jippermettix dan għax jikkonsma l-argument tiegħu, u jġegħelna nsejħulu biss wara li neħħew dak kollu li għandna bżonn minn `v`.
/// Anki jekk panic ġie introdott bejn il-kostruzzjoni ta `ManuallyDrop` u l-bini tas-sekwenza (li ma jistax jiġri fil-kodiċi kif muri), dan jirriżulta fi tnixxija u mhux b'xejn doppju.
/// Fi kliem ieħor, `ManuallyDrop` jiżbalja fuq in-naħa tal-ħruġ minflok ma jiżbalja fuq in-naħa tal-waqgħa (doppja).
///
/// Ukoll, `ManuallyDrop` jimpedina milli jkollna "touch" `v` wara li tittrasferixxi s-sjieda għal `s`-l-aħħar pass ta 'interazzjoni ma' `v` biex tiddisponi minnha mingħajr ma tħaddem id-distruttur tagħha huwa kompletament evitat.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Bħal [`forget`], iżda jaċċetta wkoll valuri mhux imdaqqsa.
///
/// Din il-funzjoni hija biss shim maħsuba biex titneħħa meta l-karatteristika `unsized_locals` tiġi stabbilizzata.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Jirritorna d-daqs ta 'tip f'bytes.
///
/// B`mod aktar speċifiku, dan huwa l-offset f`bytes bejn elementi suċċessivi f`firxa b`dak it-tip ta `oġġett inkluż il-padding tal-allinjament.
///
/// Għalhekk, għal kwalunkwe tip `T` u tul `n`, `[T; n]` għandu daqs ta `n * size_of::<T>()`.
///
/// B'mod ġenerali, id-daqs ta 'tip mhuwiex stabbli fil-kompilazzjonijiet kollha, iżda tipi speċifiċi bħal primittivi huma.
///
/// It-tabella li ġejja tagħti d-daqs għall-primittivi.
///
/// Tip |size_of: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 karattru |4
///
/// Barra minn hekk, `usize` u `isize` għandhom l-istess daqs.
///
/// It-tipi `*const T`, `&T`, `Box<T>`, `Option<&T>`, u `Option<Box<T>>` kollha għandhom l-istess daqs.
/// Jekk `T` huwa Daqs, dawk it-tipi kollha għandhom l-istess daqs bħal `usize`.
///
/// Il-mutabilità ta 'pointer ma tbiddilx id-daqs tiegħu.Bħala tali, `&T` u `&mut T` għandhom l-istess daqs.
/// Bl-istess mod għal `*const T` u `* mut T`.
///
/// # Daqs ta 'oġġetti `#[repr(C)]`
///
/// Ir-rappreżentazzjoni `C` għal oġġetti għandha tqassim definit.
/// B'dan it-tqassim, id-daqs tal-oġġetti huwa wkoll stabbli sakemm l-oqsma kollha jkollhom daqs stabbli.
///
/// ## Daqs ta 'Strutturi
///
/// Għal `structs`, id-daqs huwa determinat mill-algoritmu li ġej.
///
/// Għal kull qasam fl-istruttura ordnata b'ordni ta 'dikjarazzjoni:
///
/// 1. Żid id-daqs tal-għalqa.
/// 2. Agħmel id-daqs kurrenti sal-eqreb multiplu tal-qasam li jmiss [alignment].
///
/// Fl-aħħarnett, dawwar id-daqs tal-istruttura sal-eqreb multiplu tax-[alignment] tagħha.
/// L-allinjament tal-istruttura ġeneralment huwa l-akbar allinjament tal-oqsma kollha tiegħu;dan jista 'jinbidel bl-użu ta' `repr(align(N))`.
///
/// B'differenza minn `C`, strutturi ta 'daqs żero mhumiex arrotondati sa byte wieħed fid-daqs.
///
/// ## Daqs tal-Enums
///
/// Enums li ma jġorru l-ebda dejta għajr id-diskriminanti għandhom l-istess daqs bħal enums C fuq il-pjattaforma li huma kkompilati għaliha.
///
/// ## Daqs tal-Unions
///
/// Id-daqs ta 'unjoni huwa d-daqs tal-akbar qasam tagħha.
///
/// B'differenza minn `C`, unjonijiet ta 'daqs żero mhumiex arrotondati sa byte wieħed fid-daqs.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Xi primittivi
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Xi matriċi
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Ugwaljanza tad-daqs tal-pointer
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Bl-użu ta `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Id-daqs tal-ewwel qasam huwa 1, allura żid 1 mad-daqs.Id-daqs huwa 1.
/// // L-allinjament tat-tieni qasam huwa 2, allura żid 1 mad-daqs għall-ikkuttunar.Id-daqs huwa 2.
/// // Id-daqs tat-tieni qasam huwa 2, allura żid 2 mad-daqs.Id-daqs huwa 4.
/// // L-allinjament tat-tielet qasam huwa 1, allura żid 0 mad-daqs għall-ikkuttunar.Id-daqs huwa 4.
/// // Id-daqs tat-tielet qasam huwa 1, allura żid 1 mad-daqs.Id-daqs huwa 5.
/// // Fl-aħħarnett, l-allinjament tal-istruttura huwa 2 (minħabba li l-akbar allinjament fost l-oqsma tiegħu huwa 2), allura żid 1 mad-daqs għall-ikkuttunar.
/// // Id-daqs huwa 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Strutturi tat-Tuple jsegwu l-istess regoli.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Innota li l-ordni mill-ġdid tal-oqsma tista 'tnaqqas id-daqs.
/// // Nistgħu nneħħu ż-żewġ bytes tal-ikkuttunar billi npoġġu `third` qabel `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Id-daqs tal-Unjoni huwa d-daqs tal-akbar qasam.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Jirritorna d-daqs tal-valur indikat f'bytes.
///
/// Dan ġeneralment ikun l-istess bħal `size_of::<T>()`.
/// Madankollu, meta `T`*m'għandu* l-ebda daqs statikament magħruf, eż., Porzjon [`[T]`][slice] jew [trait object], allura `size_of_val` jista 'jintuża biex jikseb id-daqs magħruf dinamikament.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURTÀ: `val` huwa referenza, allura huwa pointer nej validu
    unsafe { intrinsics::size_of_val(val) }
}

/// Jirritorna d-daqs tal-valur indikat f'bytes.
///
/// Dan ġeneralment ikun l-istess bħal `size_of::<T>()`.Madankollu, meta `T`*m'għandu* l-ebda daqs statikament magħruf, eż., Porzjon [`[T]`][slice] jew [trait object], allura `size_of_val_raw` jista 'jintuża biex jikseb id-daqs magħruf dinamikament.
///
/// # Safety
///
/// Din il-funzjoni tista 'tissejjaħ mingħajr periklu biss jekk jgħoddu l-kundizzjonijiet li ġejjin:
///
/// - Jekk `T` huwa `Sized`, din il-funzjoni hija dejjem sikura biex tissejjaħ.
/// - Jekk id-denb mhux daqs ta `T` huwa:
///     - a [slice], allura t-tul tad-denb tal-porzjon għandu jkun numru sħiħ inizjalizzat, u d-daqs tal-*valur sħiħ*(tul dinamiku tad-denb + prefiss ta 'daqs statiku) għandu joqgħod f `isize`.
///     - a [trait object], allura l-parti vtable tal-pointer għandha tipponta lejn tabella vtable valida miksuba minn sfurzar li ma jitnaqqasx id-daqs, u d-daqs tal-*valur sħiħ*(tul dinamiku tad-denb + prefiss ta 'daqs statiku) għandu joqgħod f `isize`.
///
///     - (unstable) [extern type], allura din il-funzjoni hija dejjem sikura biex tissejjaħ, iżda tista 'panic jew inkella tirritorna l-valur ħażin, billi t-tqassim tat-tip estern mhuwiex magħruf.
///     Din hija l-istess imġieba bħal [`size_of_val`] fuq referenza għal tip b'denb tat-tip estern.
///     - inkella, b'mod konservattiv mhux permess li tissejjaħ din il-funzjoni.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURTÀ: min iċempel għandu jipprovdi pointer nej validu
    unsafe { intrinsics::size_of_val(val) }
}

/// Jirritorna l-allinjament minimu meħtieġ ta 'tip [ABI].
///
/// Kull referenza għal valur tat-tip `T` għandha tkun multiplu ta 'dan in-numru.
///
/// Dan huwa l-allinjament użat għall-oqsma struct.Jista 'jkun iżgħar mill-allinjament preferut.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Jirritorna l-allinjament minimu mitlub [ABI] tat-tip tal-valur li `val` jindika għalih.
///
/// Kull referenza għal valur tat-tip `T` għandha tkun multiplu ta 'dan in-numru.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURTÀ: val huwa referenza, allura huwa pointer nej validu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Jirritorna l-allinjament minimu meħtieġ ta 'tip [ABI].
///
/// Kull referenza għal valur tat-tip `T` għandha tkun multiplu ta 'dan in-numru.
///
/// Dan huwa l-allinjament użat għall-oqsma struct.Jista 'jkun iżgħar mill-allinjament preferut.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Jirritorna l-allinjament minimu mitlub [ABI] tat-tip tal-valur li `val` jindika għalih.
///
/// Kull referenza għal valur tat-tip `T` għandha tkun multiplu ta 'dan in-numru.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIGURTÀ: val huwa referenza, allura huwa pointer nej validu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Jirritorna l-allinjament minimu mitlub [ABI] tat-tip tal-valur li `val` jindika għalih.
///
/// Kull referenza għal valur tat-tip `T` għandha tkun multiplu ta 'dan in-numru.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Din il-funzjoni tista 'tissejjaħ mingħajr periklu biss jekk jgħoddu l-kundizzjonijiet li ġejjin:
///
/// - Jekk `T` huwa `Sized`, din il-funzjoni hija dejjem sikura biex tissejjaħ.
/// - Jekk id-denb mhux daqs ta `T` huwa:
///     - a [slice], allura t-tul tad-denb tal-porzjon għandu jkun numru sħiħ inizjalizzat, u d-daqs tal-*valur sħiħ*(tul dinamiku tad-denb + prefiss ta 'daqs statiku) għandu joqgħod f `isize`.
///     - a [trait object], allura l-parti vtable tal-pointer għandha tipponta lejn tabella vtable valida miksuba minn sfurzar li ma jitnaqqasx id-daqs, u d-daqs tal-*valur sħiħ*(tul dinamiku tad-denb + prefiss ta 'daqs statiku) għandu joqgħod f `isize`.
///
///     - (unstable) [extern type], allura din il-funzjoni hija dejjem sikura biex tissejjaħ, iżda tista 'panic jew inkella tirritorna l-valur ħażin, billi t-tqassim tat-tip estern mhuwiex magħruf.
///     Din hija l-istess imġieba bħal [`align_of_val`] fuq referenza għal tip b'denb tat-tip estern.
///     - inkella, b'mod konservattiv mhux permess li tissejjaħ din il-funzjoni.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIGURTÀ: min iċempel għandu jipprovdi pointer nej validu
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Jirritorna `true` jekk il-valuri tat-twaqqigħ tat-tip `T` huma importanti.
///
/// Dan huwa purament ħjiel ta 'ottimizzazzjoni, u jista' jiġi implimentat b'mod konservattiv:
/// jista 'jirritorna `true` għal tipi li fil-fatt ma jeħtiġux li jitwaqqgħu.
/// Bħala tali dejjem jirritorna `true` tkun implimentazzjoni valida ta 'din il-funzjoni.Madankollu jekk din il-funzjoni fil-fatt tirritorna `false`, allura tista 'tkun ċert li twaqqa' `T` m'għandux effett sekondarju.
///
/// Implimentazzjonijiet ta 'livell baxx ta' affarijiet bħal kollezzjonijiet, li jeħtieġu li jwaqqgħu d-dejta tagħhom manwalment, għandhom jużaw din il-funzjoni biex jevitaw bla bżonn li jippruvaw iwaqqgħu l-kontenut kollu tagħhom meta jinqerdu.
///
/// Dan jista 'ma jagħmilx differenza fil-builds tar-rilaxx (fejn loop li m'għandux effetti sekondarji huwa faċilment skopert u eliminat), iżda ħafna drabi huwa rebħa kbira għall-builds tad-debug.
///
/// Innota li [`drop_in_place`] diġà jwettaq din il-verifika, allura jekk ix-xogħol tiegħek jista 'jitnaqqas għal xi numru żgħir ta' sejħiet [`drop_in_place`], l-użu ta 'dan mhuwiex meħtieġ.
/// B'mod partikolari innota li tista [`drop_in_place`] porzjon, u li tagħmel verifika need_drop waħda għall-valuri kollha.
///
/// Tipi bħal Vec għalhekk biss `drop_in_place(&mut self[..])` mingħajr ma tuża `needs_drop` b'mod espliċitu.
/// Tipi bħal [`HashMap`], min-naħa l-oħra, għandhom iwaqqgħu l-valuri wieħed wieħed u għandhom jużaw din l-API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hawn hu eżempju ta 'kif kollezzjoni tista' tagħmel użu minn `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // qatra d-dejta
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Jirritorna l-valur tat-tip `T` rappreżentat mill-mudell tal-byte all-zero.
///
/// Dan ifisser li, pereżempju, il-byte tal-ikkuttunar f `(u8, u16)` mhux neċessarjament jiġi zeroed.
///
/// M'hemm l-ebda garanzija li mudell ta 'byte ta' żero jirrappreżenta valur validu ta 'xi tip `T`.
/// Pereżempju, il-mudell tal-byte all-zero mhuwiex valur validu għal tipi ta 'referenza ("&T", `&mut T`) u pointers tal-funzjonijiet.
/// L-użu ta `zeroed` fuq tipi bħal dawn jikkawża [undefined behavior][ub] immedjat minħabba li [the Rust compiler assumes][inv] li dejjem hemm valur validu f'varjabbli li tikkunsidra inizjalizzata.
///
///
/// Dan għandu l-istess effett bħal [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Xi drabi huwa utli għall-FFI, iżda ġeneralment għandu jiġi evitat.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Użu korrett ta 'din il-funzjoni: inizjalizzazzjoni ta' numru sħiħ b'żero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// * Użu mhux korrett ta 'din il-funzjoni: inizjalizzazzjoni ta' referenza b'żero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Imġieba mhux definita!
/// let _y: fn() = unsafe { mem::zeroed() }; // U għal darb'oħra!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SIGURTÀ: min iċempel għandu jiggarantixxi li valur ta 'żero huwa validu għal `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Taqbeż il-kontrolli normali ta `inizjalizzazzjoni tal-memorja ta` Rust billi taparsi jipproduċi valur tat-tip `T`, waqt li ma tagħmel xejn.
///
/// **Din il-funzjoni hija skaduta.** Uża [`MaybeUninit<T>`] minflok.
///
/// Ir-raġuni għad-deprezzament hija li l-funzjoni bażikament ma tistax tintuża b'mod korrett: għandha l-istess effett bħal [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kif jispjega [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] li l-valuri huma inizjalizzati kif suppost.
/// Bħala konsegwenza, sejħa eż
/// `mem::uninitialized::<bool>()` tikkawża imġieba immedjata mhux definita għar-ritorn ta `bool` li mhux definittivament la `true` u lanqas `false`.
/// Memorja agħar, tassew mhux inizjalizzata bħal dik li tiġi rritornata hawnhekk hija speċjali billi l-kompilatur jaf li m'għandux valur fiss.
/// Dan jagħmilha imġieba mhux definita li jkollok dejta mhux inizjalizzata f'varjabbli anke jekk dik il-varjabbli għandha tip sħiħ.
/// (Innota li r-regoli madwar numri interi mhux inizjalizzati għadhom mhumiex finalizzati, iżda sakemm ikunu hekk, huwa rrakkomandat li jiġu evitati.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SIGURTÀ: min iċempel għandu jiggarantixxi li valur unjalizzat huwa validu għal `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Tpartit il-valuri f'żewġ postijiet li jistgħu jinbidlu, mingħajr ma titneħħa l-inizjalizzazzjoni ta 'l-ebda wieħed.
///
/// * Jekk trid tpartat b'valur default jew finta, ara [`take`].
/// * Jekk trid tpartat b'valur mgħoddi, billi tirritorna l-valur l-antik, ara [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SIGURTÀ: l-indikaturi nejjin inħolqu minn referenzi sikuri li jistgħu jinbidlu li jissodisfaw il-parametri kollha
    // restrizzjonijiet fuq `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Jissostitwixxi `dest` bil-valur default ta `T`, u jirritorna l-valur preċedenti ta' `dest`.
///
/// * Jekk trid tissostitwixxi l-valuri ta 'żewġ varjabbli, ara [`swap`].
/// * Jekk trid tissostitwixxi b'valur mgħoddi minflok il-valur awtomatiku, ara [`replace`].
///
/// # Examples
///
/// Eżempju sempliċi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` jippermetti s-sjieda ta 'qasam struct billi tibdilha b'valur "empty".
/// Mingħajr `take` tista 'tiffaċċja kwistjonijiet bħal dawn:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Innota li `T` mhux neċessarjament jimplimenta [`Clone`], allura lanqas biss jista 'jikklona u jirrisettja `self.buf`.
/// Iżda `take` jista 'jintuża biex jiddisassoċja l-valur oriġinali ta' `self.buf` minn `self`, li jippermetti li jiġi rritornat:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Iċċaqlaq `src` fix-`dest` referenzjat, u jirritorna l-valur preċedenti ta `dest`.
///
/// L-ebda valur ma jitwaqqa '.
///
/// * Jekk trid tissostitwixxi l-valuri ta 'żewġ varjabbli, ara [`swap`].
/// * Jekk trid tissostitwixxi b'valur awtomatiku, ara [`take`].
///
/// # Examples
///
/// Eżempju sempliċi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` jippermetti l-konsum ta 'qasam struct billi tibdilha b'valur ieħor.
/// Mingħajr `replace` tista 'tiffaċċja kwistjonijiet bħal dawn:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Innota li `T` mhux neċessarjament jimplimenta [`Clone`], allura ma nistgħux lanqas nikklonaw `self.buf[i]` biex nevitaw il-moviment.
/// Iżda `replace` jista 'jintuża biex jiddisassoċja l-valur oriġinali f'dak l-indiċi minn `self`, u jippermettilu li jingħata lura:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SIGURTÀ: Naqraw minn `dest` imma direttament niktbu `src` fih wara,
    // b'tali mod li l-valur l-antik ma jiġix idduplikat.
    // Xejn ma jitwaqqa 'u xejn hawn ma jista' panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Jiddisponi minn valur.
///
/// Dan jagħmel hekk billi jsejjaħ l-implimentazzjoni tal-argument ta [`Drop`][drop].
///
/// Dan effettivament ma jagħmel xejn għal tipi li jimplimentaw `Copy`, eż
/// integers.
/// Valuri bħal dawn jiġu kkupjati u _then_ imċaqlaq fil-funzjoni, għalhekk il-valur jippersisti wara din is-sejħa tal-funzjoni.
///
///
/// Din il-funzjoni mhix maġija;huwa litteralment definit bħala
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Minħabba li `_x` huwa mċaqlaq fil-funzjoni, jitwaqqa 'awtomatikament qabel ma terġa' lura l-funzjoni.
///
/// [drop]: Drop
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // qatra espliċitament iż-vector
/// ```
///
/// Peress li [`RefCell`] jinforza r-regoli tas-self fil-ħin tal-eżekuzzjoni, `drop` jista 'jirrilaxxa self [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // ċedi s-self li jista 'jinbidel fuq din is-slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Numri sħaħ u tipi oħra li jimplimentaw [`Copy`] mhumiex affettwati minn `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopja ta `x` titmexxa u titwaqqa'
/// drop(y); // kopja ta `y` titmexxa u titwaqqa'
///
/// println!("x: {}, y: {}", x, y.0); // għadu disponibbli
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Jinterpreta lil `src` bħala li għandu t-tip `&U`, u mbagħad jaqra `src` mingħajr ma jċaqlaq il-valur kontenut.
///
/// Din il-funzjoni tassumi li l-indikatur `src` huwa validu għal [`size_of::<U>`][size_of] bytes mingħajr periklu billi jittrasmuta `&T` għal `&U` u mbagħad jaqra l-`&U` (ħlief li dan isir b'mod korrett anke meta `&U` jagħmel rekwiżiti ta 'allinjament aktar stretti minn `&T`).
/// Se toħloq ukoll b'mod mhux sikur kopja tal-valur miżmum minflok ma toħroġ minn `src`.
///
/// Mhuwiex żball fil-ħin tal-kumpilazzjoni jekk `T` u `U` għandhom daqsijiet differenti, iżda huwa mħeġġeġ ħafna li tinvoka din il-funzjoni biss fejn `T` u `U` għandhom l-istess daqs.Din il-funzjoni tqajjem [undefined behavior][ub] jekk `U` huwa akbar minn `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Ikkopja d-dejta minn 'foo_array' u ittrattaha bħala 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Immodifika d-dejta kkupjata
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Il-kontenut ta 'foo_array' ma kellux jinbidel
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Jekk U għandu rekwiżit ta 'allinjament ogħla, src jista' ma jkunx allinjat b'mod xieraq.
    if align_of::<U>() > align_of::<T>() {
        // SIGURTÀ: `src` hija referenza li hija garantita li tkun valida għal qari.
        // Min iċempel għandu jiggarantixxi li t-trasmutazzjoni attwali hija sigura.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SIGURTÀ: `src` hija referenza li hija garantita li tkun valida għal qari.
        // Aħna biss ċċekkjajna li `src as *const U` kien allinjat sewwa.
        // Min iċempel għandu jiggarantixxi li t-trasmutazzjoni attwali hija sigura.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Tip opak li jirrappreżenta d-diskriminant ta 'enum.
///
/// Ara l-funzjoni [`discriminant`] f'dan il-modulu għal aktar informazzjoni.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Dawn l-implimentazzjonijiet trait ma jistgħux jiġu derivati għax ma rridu l-ebda limitu fuq T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Jirritorna valur li jidentifika b'mod uniku l-varjant enum f `v`.
///
/// Jekk `T` mhuwiex enum, is-sejħa għal din il-funzjoni ma tirriżultax f'imġieba mhux definita, iżda l-valur tar-ritorn mhuwiex speċifikat.
///
///
/// # Stability
///
/// Id-diskriminanti ta 'varjant enum jista' jinbidel jekk id-definizzjoni enum tinbidel.
/// Diskriminanti ta 'xi varjant ma jinbidilx bejn kumpilazzjonijiet bl-istess kompilatur.
///
/// # Examples
///
/// Dan jista 'jintuża biex iqabbel enums li jġorru dejta, filwaqt li jinjoraw id-dejta attwali:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Jirritorna n-numru ta 'varjanti fl-enum tip `T`.
///
/// Jekk `T` mhuwiex enum, is-sejħa għal din il-funzjoni ma tirriżultax f'imġieba mhux definita, iżda l-valur tar-ritorn mhuwiex speċifikat.
/// Bl-istess mod, jekk `T` huwa enum b'aktar varjanti minn `usize::MAX` il-valur tar-ritorn mhux speċifikat.
/// Varjanti diżabitati se jingħaddu.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}