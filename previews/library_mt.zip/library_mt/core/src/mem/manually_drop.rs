use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Tgeżwir biex jinibixxi l-kompilatur milli jsejjaħ awtomatikament id-distruttur ta '"T".
/// Dan it-tgeżwir huwa ta '0-ispiża.
///
/// `ManuallyDrop<T>` hija soġġetta għall-istess ottimizzazzjonijiet tat-tqassim bħal `T`.
/// Bħala konsegwenza, m'għandha *l-ebda effett* fuq is-suppożizzjonijiet li l-kompilatur jagħmel dwar il-kontenut tiegħu.
/// Pereżempju, l-inizjalizzazzjoni ta `ManuallyDrop<&mut T>` b [`mem::zeroed`] hija mġieba mhux definita.
/// Jekk għandek bżonn timmaniġġja dejta mhux inizjalizzata, uża [`MaybeUninit<T>`] minflok.
///
/// Innota li l-aċċess għall-valur ġewwa `ManuallyDrop<T>` huwa sigur.
/// Dan ifisser li `ManuallyDrop<T>` li l-kontenut tiegħu twaqqa 'm'għandux ikun espost permezz ta' API pubblika sigura.
/// Korrispondentement, `ManuallyDrop::drop` mhuwiex sikur.
///
/// # `ManuallyDrop` u qatra ordni.
///
/// Rust għandu [drop order] ta 'valuri definit sewwa.
/// Biex tkun żgur li l-għelieqi jew in-nies tal-lokal jitwaqqgħu f'ordni speċifika, ordna mill-ġdid id-dikjarazzjonijiet b'tali mod li l-ordni impliċita ta 'waqgħa hija dik korretta.
///
/// Huwa possibbli li tuża `ManuallyDrop` biex tikkontrolla l-ordni ta 'waqgħa, iżda dan jirrikjedi kodiċi mhux sikur u huwa diffiċli li tagħmel sewwa fil-preżenza li tinħall.
///
///
/// Pereżempju, jekk trid tkun żgur li qasam speċifiku jitwaqqa 'wara l-oħrajn, għamilha l-aħħar qasam ta' struttura:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` jitwaqqa 'wara `children`.
///     // Rust jiggarantixxi li l-oqsma jitwaqqgħu fl-ordni tad-dikjarazzjoni.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Kebbeb valur biex jitwaqqa 'manwalment.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Xorta tista 'topera b'mod sigur fuq il-valur
    /// assert_eq!(*x, "Hello");
    /// // Imma `Drop` mhux se jitmexxa hawn
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Oħroġ il-valur mill-kontenitur `ManuallyDrop`.
    ///
    /// Dan jippermetti li l-valur jerġa 'jitwaqqa'.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dan iwaqqa 'l-`Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Oħroġ il-valur mill-kontenitur `ManuallyDrop<T>`.
    ///
    /// Dan il-metodu huwa primarjament maħsub biex jiċċaqlaq il-valuri fil-waqgħa.
    /// Minflok tuża [`ManuallyDrop::drop`] biex twaqqa 'l-valur manwalment, tista' tuża dan il-metodu biex tieħu l-valur u tużah kif mixtieq.
    ///
    /// Kull meta jkun possibbli, huwa preferibbli li tuża [`into_inner`][`ManuallyDrop::into_inner`] minflok, li ma jħallix li d-duplikazzjoni tal-kontenut tax-`ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Din il-funzjoni tmexxi b'mod semantiku l-valur kontenut mingħajr ma tipprevjeni aktar użu, u tħalli l-istat ta 'dan il-kontenitur mhux mibdul.
    /// Hija r-responsabbiltà tiegħek li tiżgura li dan ix-`ManuallyDrop` ma jerġax jintuża.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SIGURTÀ: qed naqraw minn referenza, li hija garantita
        // tkun valida għal qari.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Twaqqa 'l-valur miżmum manwalment.Dan huwa eżattament ekwivalenti għal sejħa lil [`ptr::drop_in_place`] b'pointer għall-valur kontenut.
    /// Bħala tali, sakemm il-valur kontenut ma jkunx struttura ppakkjata, id-distruttur jissejjaħ fil-post mingħajr ma jċaqlaq il-valur, u b'hekk jista 'jintuża biex titwaqqa' d-dejta [pinned] b'mod sikur.
    ///
    /// Jekk għandek il-pussess tal-valur, tista 'tuża [`ManuallyDrop::into_inner`] minflok.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni tmexxi d-distruttur tal-valur kontenut.
    /// Minbarra l-bidliet magħmula mid-distruttur innifsu, il-memorja titħalla l-istess, u għalhekk safejn huwa kkonċernat il-kompilatur xorta għandu mudell bit li huwa validu għat-tip `T`.
    ///
    ///
    /// Madankollu, dan il-valur "zombie" m'għandux ikun espost għal kodiċi sikur, u din il-funzjoni m'għandhiex tissejjaħ aktar minn darba.
    /// Li tuża valur wara li titwaqqa ', jew twaqqa' valur bosta drabi, jista 'jikkawża Imġieba Mhux Iddefinita (skont dak li jagħmel `drop`).
    /// Normalment dan jiġi evitat mis-sistema tat-tip, iżda l-utenti ta `ManuallyDrop` għandhom iżommu dawk il-garanziji mingħajr assistenza mill-kompilatur.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SIGURTÀ: qed inwaqqgħu l-valur indikat minn referenza li tista 'tinbidel
        // li huwa garantit li jkun validu għal kitbiet.
        // Huwa f'idejn min iċempel biex jiżgura li `slot` ma jerġax jitwaqqa '.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}