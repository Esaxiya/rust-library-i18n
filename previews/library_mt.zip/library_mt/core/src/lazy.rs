//! Valuri għażżien u inizjalizzazzjoni ta 'darba ta' dejta statika.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// Ċellula li tista 'tinkiteb darba biss.
///
/// B'differenza minn `RefCell`, `OnceCell` jipprovdi biss referenzi komuni ta `&T` għall-valur tiegħu.
/// B'differenza minn `Cell`, `OnceCell` ma jeħtieġx li tikkopja jew tissostitwixxi l-valur biex taċċessaha.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // Invariant: miktub lil mhux aktar minn darba.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// Joħloq ċellula vojta ġdida.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// Tikseb ir-referenza għall-valur sottostanti.
    ///
    /// Jirritorna `None` jekk iċ-ċellula tkun vojta.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // SIGURTÀ: Sikur minħabba l-invariant ta '"ġewwa"
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// Tikseb ir-referenza li tista 'tinbidel għall-valur sottostanti.
    ///
    /// Jirritorna `None` jekk iċ-ċellula tkun vojta.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // SIGURTÀ: Sikur għax għandna aċċess uniku
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// Issettja l-kontenut taċ-ċellola għal `value`.
    ///
    /// # Errors
    ///
    /// Dan il-metodu jirritorna `Ok(())` jekk iċ-ċellula kienet vojta u `Err(value)` jekk kienet mimlija.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // SIGURTÀ: Sikur għax ma jistax ikollna self mutabbli li jikkoinċidi
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // SIGURTÀ: Dan huwa l-uniku post fejn waqqafna l-islott, mingħajr tiġrijiet
        // minħabba reentrancy/concurrency huma possibbli, u aħna ċċekkjajna li l-islott bħalissa huwa `None`, allura din il-kitba żżomm l-invariant tal-'intern '.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// Iġib il-kontenut taċ-ċellola, billi jinizjalizzah b `f` jekk iċ-ċellula kienet vojta.
    ///
    /// # Panics
    ///
    /// Jekk `f` panics, iż-panic jiġi propagat lil min iċempel, u ċ-ċellula tibqa 'mhux inizjalizzata.
    ///
    ///
    /// Huwa żball li l-inizjalizzazzjoni mill-ġdid taċ-ċellola minn `f`.Jekk tagħmel hekk jirriżulta f'panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// Iġib il-kontenut taċ-ċellola, billi jinizjalizzah b `f` jekk iċ-ċellula kienet vojta.
    /// Jekk iċ-ċellula kienet vojta u `f` falla, jiġi rritornat żball.
    ///
    /// # Panics
    ///
    /// Jekk `f` panics, iż-panic jiġi propagat lil min iċempel, u ċ-ċellula tibqa 'mhux inizjalizzata.
    ///
    ///
    /// Huwa żball li l-inizjalizzazzjoni mill-ġdid taċ-ċellola minn `f`.Jekk tagħmel hekk jirriżulta f'panic.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // Innota li *xi* forom ta 'inizjalizzazzjoni mill-ġdid jistgħu jwasslu għal UB (ara t-test `reentrant_init`).
        // Nemmen li jekk tneħħi dan ix-`assert`, waqt li żżomm `set/get` ikun tajjeb, imma jidher aħjar għal panic, aktar milli tuża valur qadim fis-skiet.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// Tikkonsma ċ-ċellola, u tirritorna l-valur imgeżwer.
    ///
    /// Jirritorna `None` jekk iċ-ċellula kienet vojta.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // Minħabba li `into_inner` jieħu `self` bil-valur, il-kompilatur jivverifika b'mod statiku li bħalissa mhuwiex issellef.
        // Allura huwa sikur li toħroġ `Option<T>`.
        self.inner.into_inner()
    }

    /// Jieħu l-valur minn dan ix-`OnceCell`, billi jmexxih lura għal stat mhux inizjalizzat.
    ///
    /// M'għandu l-ebda effett u jirritorna `None` jekk ix-`OnceCell` ma jkunx ġie inizjalizzat.
    ///
    /// Is-sigurtà hija garantita billi tirrikjedi referenza li tista 'tinbidel.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// Valur li huwa inizjalizzat mal-ewwel aċċess.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   lesta inizjalizzazzjoni
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// Joħloq valur għażżien ġdid bil-funzjoni ta 'inizjalizzazzjoni mogħtija.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// Tġiegħel l-evalwazzjoni ta 'dan il-valur għażżien u tirritorna referenza għar-riżultat.
    ///
    ///
    /// Dan huwa ekwivalenti għall-impl `Deref`, iżda huwa espliċitu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// Toħloq valur għażżien ġdid billi tuża `Default` bħala l-funzjoni ta 'inizjalizzazzjoni.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}