/// Kodiċi tad-dwana fi ħdan id-distruttur.
///
/// Meta valur ma jibqax meħtieġ, Rust imexxi "destructor" fuq dak il-valur.
/// L-iktar mod komuni li valur m'għadux meħtieġ huwa meta joħroġ mill-ambitu.Id-distrutturi jistgħu jibqgħu jaħdmu f'ċirkostanzi oħra, imma aħna ser niffokaw fuq l-ambitu għall-eżempji hawn.
/// Biex titgħallem dwar xi wħud minn dawk il-każijiet l-oħra, jekk jogħġbok ara t-taqsima [the reference] dwar id-distrutturi.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Dan id-distruttur jikkonsisti f'żewġ komponenti:
/// - Sejħa lil `Drop::drop` għal dak il-valur, jekk dan `Drop` speċjali trait huwa implimentat għat-tip tiegħu.
/// - Ix-"drop glue" iġġenerat awtomatikament li rikursivament isejjaħ lid-distrutturi tal-oqsma kollha ta 'dan il-valur.
///
/// Peress li Rust awtomatikament isejjaħ lid-distrutturi tal-oqsma kollha kontenuti, m'għandekx għalfejn timplimenta `Drop` f'ħafna każijiet.
/// Iżda hemm xi każijiet fejn huwa utli, pereżempju għal tipi li jimmaniġġjaw direttament riżorsa.
/// Dik ir-riżorsa tista 'tkun memorja, tista' tkun deskrittur tal-fajl, tista 'tkun sokit tan-netwerk.
/// Ladarba valur ta 'dak it-tip ma jibqax jintuża, għandu "clean up" ir-riżorsa tiegħu billi jeħles il-memorja jew jagħlaq il-fajl jew is-sokit.
/// Dan huwa xogħol ta 'distruttur, u għalhekk ix-xogħol ta' `Drop::drop`.
///
/// ## Examples
///
/// Biex tara distrutturi fl-azzjoni, ejja nagħtu ħarsa lejn il-programm li ġej:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust l-ewwel sejħa lil `Drop::drop` għal `_x` u mbagħad kemm għal `_x.one` kif ukoll għal `_x.two`, li jfisser li meta titħaddem din se tkun stampata
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Anki jekk inneħħu l-implimentazzjoni ta `Drop` għal `HasTwoDrop`, id-distrutturi tal-oqsma tagħha għadhom imsejħa.
/// Dan jirriżulta fi
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Ma tistax ċempel lil `Drop::drop` int stess
///
/// Minħabba li `Drop::drop` jintuża biex jitnaddaf valur, jista 'jkun perikoluż li tuża dan il-valur wara li l-metodu jkun ġie msejjaħ.
/// Peress li `Drop::drop` ma jkollux pussess tal-input tiegħu, Rust jipprevjeni l-użu ħażin billi ma jippermettilekx li ċċempel lil `Drop::drop` direttament.
///
/// Fi kliem ieħor, jekk ippruvajt sejħa espliċita lil `Drop::drop` fl-eżempju ta 'hawn fuq, ikollok żball tal-kompilatur.
///
/// Jekk tixtieq espliċitament issejjaħ id-distruttur ta 'valur, minflok jista' jintuża [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Drop order
///
/// Liema miż-żewġ `HasDrop` tagħna qtar l-ewwel, għalkemm?Għal strutturi, huwa l-istess ordni li huma ddikjarati: l-ewwel `one`, imbagħad `two`.
/// Jekk tixtieq tipprova dan int stess, tista 'timmodifika `HasDrop` hawn fuq biex ikun fiha xi dejta, bħal numru sħiħ, u mbagħad tużaha fix-`println!` ġewwa `Drop`.
/// Din l-imġieba hija garantita mil-lingwa.
///
/// B'differenza għall-istrutturi, il-varjabbli lokali jitwaqqgħu f'ordni inversa:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dan se jistampa
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Jekk jogħġbok ara [the reference] għar-regoli sħaħ.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` u `Drop` huma esklussivi
///
/// Ma tistax timplimenta kemm [`Copy`] kif ukoll `Drop` fuq l-istess tip.Tipi li huma `Copy` jiġu impliċitament duplikati mill-kompilatur, u dan jagħmilha diffiċli ħafna li wieħed ibassar meta, u kemm-il darba se jiġu eżegwiti distrutturi.
///
/// Bħala tali, dawn it-tipi ma jistax ikollhom distrutturi.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Teżegwixxi d-distruttur għal dan it-tip.
    ///
    /// Dan il-metodu jissejjaħ impliċitament meta l-valur joħroġ mill-ambitu, u ma jistax jissejjaħ b'mod espliċitu (dan huwa l-iżball tal-kompilatur [E0040]).
    /// Madankollu, il-funzjoni [`mem::drop`] fiż-prelude tista 'tintuża biex tissejjaħ l-implimentazzjoni `Drop` tal-argument.
    ///
    /// Meta dan il-metodu ġie msejjaħ, `self` għadu ma ġiex allokat.
    /// Dan jiġri biss wara li jintemm il-metodu.
    /// Kieku dan ma kienx il-każ, `self` ikun referenza mdendlin.
    ///
    /// # Panics
    ///
    /// Minħabba li [`panic!`] se jsejjaħ lil `drop` hekk kif jinħall, kull [`panic!`] f'implimentazzjoni ta `drop` x'aktarx jieqaf.
    ///
    /// Innota li anke jekk dan panics, il-valur huwa meqjus li twaqqa ';
    /// m'għandekx tikkawża li `drop` jerġa 'jissejjaħ.
    /// Dan normalment jiġi mmaniġġjat awtomatikament mill-kompilatur, iżda meta jintuża kodiċi mhux sikur, kultant jista 'jseħħ mingħajr intenzjoni, partikolarment meta jintuża [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}