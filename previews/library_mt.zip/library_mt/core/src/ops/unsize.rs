use crate::marker::Unsize;

/// Trait li jindika li dan huwa pointer jew wrapper għal wieħed, fejn id-daqs jista 'jsir fuq il-pointee.
///
/// Ara [DST coercion RFC][dst-coerce] u [the nomicon entry on coercion][nomicon-coerce] għal aktar dettalji.
///
/// Għal tipi ta 'pointer integrati, indikaturi għal `T` se jġiegħlu għal indikaturi għal `U` jekk `T: Unsize<U>` billi jikkonvertu minn pointer irqiq għal pointer xaħam.
///
/// Għal tipi tad-dwana, il-kostrizzjoni hawn taħdem billi tisforza `Foo<T>` sa `Foo<U>` sakemm tkun teżisti impl ta `CoerceUnsized<Foo<U>> for Foo<T>`.
/// Impl bħal dan jista 'jinkiteb biss jekk `Foo<T>` għandu biss qasam wieħed mhux fantomata li jinvolvi `T`.
/// Jekk it-tip ta 'dak il-qasam huwa `Bar<T>`, għandha teżisti implimentazzjoni ta' `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Il-kostrizzjoni se taħdem billi tisforza l-kamp `Bar<T>` f `Bar<U>` u timla l-bqija tal-oqsma minn `Foo<T>` biex toħloq `Foo<U>`.
/// Dan effettivament iħaffer għal qasam tal-pointer u jġiegħel dak.
///
/// Ġeneralment, għal indikaturi intelliġenti inti timplimenta `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, b `?Sized` fakultattiv marbut ma `T` innifsu.
/// Għal tipi ta 'tgeżwir li jinkorporaw direttament `T` bħal `Cell<T>` u `RefCell<T>`, tista' timplimenta direttament `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>`.
///
/// Dan iħalli l-koerċizzjonijiet ta 'tipi bħal `Cell<Box<T>>` jaħdmu.
///
/// [`Unsize`][unsize] tintuża biex timmarka tipi li jistgħu jiġu sfurzati għal DSTs jekk wara l-indikaturi.Huwa implimentat awtomatikament mill-kompilatur.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * kostanti U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * kostanti U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Dan jintuża għas-sigurtà ta 'l-oġġett, biex jiċċekkja li t-tip ta' riċevitur ta 'metodu jista' jintbagħat.
///
/// Eżempju ta 'implimentazzjoni taż-trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}