/// Użat għal operazzjonijiet ta 'dereferenzjar immutabbli, bħal `*v`.
///
/// Minbarra li jintuża għal operazzjonijiet espliċiti ta 'dereferenzjar ma' l-operatur (unary) `*` f'kuntesti immutabbli, `Deref` jintuża wkoll b'mod impliċitu mill-kompilatur f'ħafna ċirkostanzi.
/// Dan il-mekkaniżmu jissejjaħ ['`Deref` coercion'][more].
/// F'kuntesti li jistgħu jinbidlu, jintuża [`DerefMut`].
///
/// L-implimentazzjoni ta `Deref` għal indikaturi intelliġenti tagħmel l-aċċess għad-dejta warajhom konvenjenti, u huwa għalhekk li jimplimentaw `Deref`.
/// Min-naħa l-oħra, ir-regoli rigward `Deref` u [`DerefMut`] ġew iddisinjati speċifikament biex jakkomodaw smart pointers.
/// Minħabba dan,**"Deref" għandu jiġi implimentat biss għal smart pointers** biex tiġi evitata konfużjoni.
///
/// Għal raġunijiet simili,**dan iż-trait ma għandu qatt ifalli**.Nuqqas waqt id-dereferenzjar jista 'jkun estremament konfuż meta `Deref` jiġi invokat b'mod impliċitu.
///
/// # Aktar dwar il-kostrizzjoni `Deref`
///
/// Jekk `T` jimplimenta `Deref<Target = U>`, u `x` huwa valur tat-tip `T`, allura:
///
/// * F'kuntesti immutabbli, `*x` (fejn `T` la hija referenza u lanqas puntatur mhux ipproċessat) huwa ekwivalenti għal `* Deref::deref(&x)`.
/// * Valuri tat-tip `&T` huma kostretti għal valuri tat-tip `&U`
/// * `T` jimplimenta impliċitament il-metodi (immutable) kollha tat-tip `U`.
///
/// Għal aktar dettalji, żur [the chapter in *The Rust Programming Language*][book] kif ukoll it-taqsimiet ta 'referenza fuq [the dereference operator][ref-deref-op], [method resolution] u [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struttura b'qasam wieħed li hija aċċessibbli billi tiddeferenzja l-istruttura.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// It-tip li jirriżulta wara d-dereferenzjar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Id-differenzi fil-valur.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Użat għal operazzjonijiet ta 'dereferenzjar li jistgħu jinbidlu, bħal f `*v = 1;`.
///
/// Minbarra li jintuża għal operazzjonijiet espliċiti ta 'dereferenzjar ma' l-operatur (unary) `*` f'kuntesti li jistgħu jinbidlu, `DerefMut` jintuża wkoll b'mod impliċitu mill-kompilatur f'ħafna ċirkostanzi.
/// Dan il-mekkaniżmu jissejjaħ ['`Deref` coercion'][more].
/// F'kuntesti immutabbli, jintuża [`Deref`].
///
/// L-implimentazzjoni ta `DerefMut` għal indikaturi intelliġenti tagħmel il-mutazzjoni tad-dejta warajhom konvenjenti, u huwa għalhekk li jimplimentaw `DerefMut`.
/// Min-naħa l-oħra, ir-regoli rigward [`Deref`] u `DerefMut` ġew iddisinjati speċifikament biex jakkomodaw smart pointers.
/// Minħabba dan,**"DerefMut" għandu jiġi implimentat biss għal smart pointers** biex tiġi evitata konfużjoni.
///
/// Għal raġunijiet simili,**dan iż-trait ma għandu qatt ifalli**.Nuqqas waqt id-dereferenzjar jista 'jkun estremament konfuż meta `DerefMut` jiġi invokat b'mod impliċitu.
///
/// # Aktar dwar il-kostrizzjoni `Deref`
///
/// Jekk `T` jimplimenta `DerefMut<Target = U>`, u `x` huwa valur tat-tip `T`, allura:
///
/// * F'kuntesti li jistgħu jinbidlu, `*x` (fejn `T` la hija referenza u lanqas puntatur mhux ipproċessat) huwa ekwivalenti għal `* DerefMut::deref_mut(&mut x)`.
/// * Valuri tat-tip `&mut T` huma kostretti għal valuri tat-tip `&mut U`
/// * `T` jimplimenta impliċitament il-metodi (mutable) kollha tat-tip `U`.
///
/// Għal aktar dettalji, żur [the chapter in *The Rust Programming Language*][book] kif ukoll it-taqsimiet ta 'referenza fuq [the dereference operator][ref-deref-op], [method resolution] u [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struttura b'qasam wieħed li tista 'tiġi modifikata billi tiddeferenzja l-istruttura.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Iddeferenzja b'mod reċiproku l-valur.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Jindika li struttura tista 'tintuża bħala riċevitur tal-metodu, mingħajr il-karatteristika `arbitrary_self_types`.
///
/// Dan huwa implimentat minn tipi ta 'pointer stdlib bħal `Box<T>`, `Rc<T>`, `&T`, u `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}