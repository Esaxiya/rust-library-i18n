/// Użat għal operazzjonijiet ta 'indiċjar (`container[index]`) f'kuntesti immutabbli.
///
/// `container[index]` huwa attwalment zokkor sintattiku għal `*container.index(index)`, iżda biss meta jintuża bħala valur immutabbli.
/// Jekk jintalab valur li jista 'jinbidel, minflok jintuża [`IndexMut`].
/// Dan jippermetti affarijiet sbieħ bħal `let value = v[index]` jekk it-tip ta `value` jimplimenta [`Copy`].
///
/// # Examples
///
/// L-eżempju li ġej jimplimenta `Index` fuq kontenitur `NucleotideCount` li jinqara biss, li jippermetti li l-għadd individwali jiġi rkuprat b'sintassi ta 'indiċi.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// It-tip ritornat wara l-indiċjar.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Twettaq l-operazzjoni ta 'indiċjar (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Użat għal operazzjonijiet ta 'indiċjar (`container[index]`) f'kuntesti li jistgħu jinbidlu.
///
/// `container[index]` huwa attwalment zokkor sintattiku għal `*container.index_mut(index)`, iżda biss meta jintuża bħala valur li jista 'jinbidel.
/// Jekk jintalab valur immutabbli, minflok jintuża [`Index`] trait.
/// Dan jippermetti affarijiet sbieħ bħal `v[index] = value`.
///
/// # Examples
///
/// Implimentazzjoni sempliċi ħafna ta 'struttura `Balance` li għandha żewġ naħat, fejn kull waħda tista' tiġi indiċjata b'mod mutabbli u immutabbli.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // F'dan il-każ, `balance[Side::Right]` huwa zokkor għal `*balance.index(Side::Right)`, peress li aħna qegħdin* biss naqraw * `balance[Side::Right]`, mhux qed niktbuh.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // Madankollu, f'dan il-każ `balance[Side::Left]` huwa zokkor għal `*balance.index_mut(Side::Left)`, peress li qed niktbu `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Twettaq l-operazzjoni ta 'indiċjar mutabbli (`container[index]`).
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}