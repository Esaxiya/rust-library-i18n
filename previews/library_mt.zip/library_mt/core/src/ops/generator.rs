use crate::marker::Unpin;
use crate::pin::Pin;

/// Ir-riżultat ta 'tkomplija tal-ġeneratur.
///
/// Dan l-enum jiġi rritornat mill-metodu `Generator::resume` u jindika l-valuri possibbli ta 'ritorn ta' ġeneratur.
/// Bħalissa dan jikkorrispondi għal punt ta 'sospensjoni (`Yielded`) jew punt ta' terminazzjoni (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Il-ġeneratur sospiż b'valur.
    ///
    /// Dan l-istat jindika li ġeneratur ġie sospiż, u tipikament jikkorrispondi għal dikjarazzjoni `yield`.
    /// Il-valur ipprovdut f'dan il-varjant jikkorrispondi għall-espressjoni mgħoddija lil `yield` u jippermetti lill-ġeneraturi jipprovdu valur kull darba li jipproduċu.
    ///
    ///
    Yielded(Y),

    /// Il-ġeneratur komplut b'valur ta 'ritorn.
    ///
    /// Dan l-istat jindika li ġeneratur temm l-eżekuzzjoni bil-valur ipprovdut.
    /// Ladarba ġeneratur ikun irritorna `Complete` huwa meqjus bħala żball ta 'programmatur li jerġa' jċempel lil `resume`.
    ///
    Complete(R),
}

/// Iż-trait implimentat minn tipi ta 'ġeneraturi integrati.
///
/// Ġeneraturi, magħrufa wkoll bħala koroutini, bħalissa huma karatteristika tal-lingwa sperimentali f'Rust.
/// Miżjud fil-ġeneraturi [RFC 2033] bħalissa huma maħsuba biex primarjament jipprovdu blokka tal-bini għas-sintassi async/await iżda x'aktarx jestendu biex jipprovdu wkoll definizzjoni ergonomika għal iteraturi u primittivi oħra.
///
///
/// Is-sintassi u s-semantika għall-ġeneraturi mhumiex stabbli u se jeħtieġu RFC ulterjuri għall-istabbilizzazzjoni.F'dan iż-żmien, għalkemm, is-sintassi hija simili għall-għeluq:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Iktar dokumentazzjoni tal-ġeneraturi tista 'tinstab fil-ktieb instabbli.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// It-tip ta 'valur li jagħti dan il-ġeneratur.
    ///
    /// Dan it-tip assoċjat jikkorrispondi għall-espressjoni `yield` u l-valuri li jitħallew jiġu rritornati kull darba li ġeneratur joħroġ.
    ///
    /// Pereżempju iteratur-bħala-ġeneratur x'aktarx ikollu dan it-tip bħala `T`, it-tip ikun iterat fuq.
    ///
    type Yield;

    /// It-tip ta 'valur li jirritorna dan il-ġeneratur.
    ///
    /// Dan jikkorrispondi għat-tip mibgħut lura minn ġeneratur jew b'dikjarazzjoni `return` jew impliċitament bħala l-aħħar espressjoni ta 'ġeneratur litterali.
    /// Pereżempju futures juża dan bħala `Result<T, E>` peress li jirrappreżenta future komplut.
    ///
    ///
    type Return;

    /// Jerġa 'jibda l-eżekuzzjoni ta' dan il-ġeneratur.
    ///
    /// Din il-funzjoni terġa 'tibda l-eżekuzzjoni tal-ġeneratur jew tibda l-eżekuzzjoni jekk ma tkunx diġà.
    /// Din is-sejħa terġa 'lura fl-aħħar punt ta' sospensjoni tal-ġeneratur, u terġa 'tibda l-eżekuzzjoni mill-aħħar `yield`.
    /// Il-ġeneratur se jkompli jeżegwixxi sakemm jew iċedi jew jirritorna, f'liema punt din il-funzjoni terġa 'lura.
    ///
    /// # Valur tar-ritorn
    ///
    /// L-enum `GeneratorState` ritornat minn din il-funzjoni jindika f'liema stat jinsab il-ġeneratur meta jirritorna.
    /// Jekk il-varjant `Yielded` jiġi rritornat allura l-ġeneratur ikun laħaq punt ta 'sospensjoni u jkun ingħata valur.
    /// Ġeneraturi f'dan l-istat huma disponibbli biex jerġgħu jibdew aktar tard.
    ///
    /// Jekk `Complete` jiġi rritornat allura l-ġeneratur ikun spiċċa kompletament bil-valur ipprovdut.Huwa invalidu li l-ġeneratur jerġa 'jibda.
    ///
    /// # Panics
    ///
    /// Din il-funzjoni tista 'panic jekk tissejjaħ wara li l-varjant `Complete` ġie rritornat qabel.
    /// Filwaqt li l-litterali tal-ġeneratur fil-lingwa huma garantiti għal panic malli jerġgħu jibdew wara `Complete`, dan mhux garantit għall-implimentazzjoni kollha ta `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}