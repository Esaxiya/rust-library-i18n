/// Il-verżjoni tal-operatur tas-sejħa li tieħu riċevitur immutabbli.
///
/// Istanzi ta `Fn` jistgħu jissejħu ripetutament mingħajr stat ta' mutazzjoni.
///
/// *Dan trait (`Fn`) m'għandux jiġi konfuż ma [function pointers] (`fn`).*
///
/// `Fn` jiġi implimentat awtomatikament minn għeluq li jieħu biss referenzi immutabbli għal varjabbli maqbuda jew ma jaqbad xejn, kif ukoll (safe) [function pointers] (b'xi twissijiet, ara d-dokumentazzjoni tagħhom għal aktar dettalji).
///
/// Barra minn hekk, għal kwalunkwe tip `F` li jimplimenta `Fn`, `&F` jimplimenta `Fn`, ukoll.
///
/// Billi kemm [`FnMut`] kif ukoll [`FnOnce`] huma supertraits ta `Fn`, kwalunkwe każ ta' `Fn` jista 'jintuża bħala parametru fejn huwa mistenni [`FnMut`] jew [`FnOnce`].
///
/// Uża `Fn` bħala marbut meta trid taċċetta parametru ta 'tip bħal funzjoni u teħtieġ issejjaħ ripetutament u mingħajr stat ta' mutazzjoni (eż., Meta ssejjaħlu fl-istess ħin).
/// Jekk m'għandekx bżonn dawn ir-rekwiżiti stretti, uża [`FnMut`] jew [`FnOnce`] bħala limiti.
///
/// Ara x-[chapter on closures in *The Rust Programming Language*][book] għal ftit aktar informazzjoni dwar dan is-suġġett.
///
/// Ta 'min jinnota wkoll is-sintassi speċjali għal `Fn` traits (eż
/// `Fn(usize, bool) -> uża ').Dawk interessati fid-dettalji tekniċi ta 'dan jistgħu jirreferu għal [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Sejjaħ għeluq
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Bl-użu ta 'parametru `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sabiex regex ikun jista 'joqgħod fuq dak `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Twettaq l-operazzjoni tas-sejħa.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Il-verżjoni tal-operatur tas-sejħa li tieħu riċevitur li jista 'jinbidel.
///
/// Istanzi ta `FnMut` jistgħu jissejħu ripetutament u jistgħu jbiddlu l-istat.
///
/// `FnMut` jiġi implimentat awtomatikament minn għeluq li jieħu referenzi li jistgħu jinbidlu għal varjabbli maqbuda, kif ukoll it-tipi kollha li jimplimentaw [`Fn`], eż., (safe) [function pointers] (peress li `FnMut` huwa supertrait ta [`Fn`]).
/// Barra minn hekk, għal kwalunkwe tip `F` li jimplimenta `FnMut`, `&mut F` jimplimenta `FnMut`, ukoll.
///
/// Peress li [`FnOnce`] huwa supertrait ta `FnMut`, kwalunkwe każ ta' `FnMut` jista 'jintuża fejn [`FnOnce`] huwa mistenni, u peress li [`Fn`] huwa subtrait ta' `FnMut`, kwalunkwe każ ta [`Fn`] jista' jintuża fejn `FnMut` huwa mistenni.
///
/// Uża `FnMut` bħala marbut meta trid taċċetta parametru ta 'tip simili għal funzjoni u teħtieġ li ċċempel ripetutament, filwaqt li tħalliha tibdel l-istat.
/// Jekk ma tridx li l-parametru jibdel l-istat, uża [`Fn`] bħala marbut;jekk m'għandekx bżonn ċemplih ripetutament, uża [`FnOnce`].
///
/// Ara x-[chapter on closures in *The Rust Programming Language*][book] għal ftit aktar informazzjoni dwar dan is-suġġett.
///
/// Ta 'min jinnota wkoll is-sintassi speċjali għal `Fn` traits (eż
/// `Fn(usize, bool) -> uża ').Dawk interessati fid-dettalji tekniċi ta 'dan jistgħu jirreferu għal [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Sejjaħ għeluq li jinqabad b'mod reċiproku
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Bl-użu ta 'parametru `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sabiex regex ikun jista 'joqgħod fuq dak `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Twettaq l-operazzjoni tas-sejħa.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Il-verżjoni tal-operatur tas-sejħa li tieħu riċevitur tal-valur sekondarju.
///
/// Istanzi ta `FnOnce` jistgħu jissejħu, iżda jistgħu ma jkunux jistgħu jissejħu bosta drabi.Minħabba dan, jekk l-unika ħaġa magħrufa dwar tip hija li timplimenta `FnOnce`, tista 'tissejjaħ darba biss.
///
/// `FnOnce` jiġi implimentat awtomatikament minn għeluq li jista 'jikkonsma varjabbli maqbuda, kif ukoll it-tipi kollha li jimplimentaw [`FnMut`], eż., (safe) [function pointers] (peress li `FnOnce` huwa supertrait ta' [`FnMut`]).
///
///
/// Billi kemm [`Fn`] kif ukoll [`FnMut`] huma subtraits ta `FnOnce`, kwalunkwe każ ta' [`Fn`] jew [`FnMut`] jista 'jintuża fejn `FnOnce` huwa mistenni.
///
/// Uża `FnOnce` bħala marbut meta trid taċċetta parametru ta 'tip ta' funzjoni u trid biss issejjaħlu darba.
/// Jekk għandek bżonn iċempel il-parametru ripetutament, uża [`FnMut`] bħala marbut;jekk għandek bżonnha wkoll biex ma tibdilx l-istat, uża [`Fn`].
///
/// Ara x-[chapter on closures in *The Rust Programming Language*][book] għal ftit aktar informazzjoni dwar dan is-suġġett.
///
/// Ta 'min jinnota wkoll is-sintassi speċjali għal `Fn` traits (eż
/// `Fn(usize, bool) -> uża ').Dawk interessati fid-dettalji tekniċi ta 'dan jistgħu jirreferu għal [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Bl-użu ta 'parametru `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` tikkonsma l-varjabbli maqbuda tagħha, u għalhekk ma tistax titħaddem aktar minn darba.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Li tipprova terġa 'tinvoka `func()` se tarmi żball `use of moved value` għal `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ma jistgħux jiġu invokati iktar f'dan il-punt
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // sabiex regex ikun jista 'joqgħod fuq dak `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// It-tip mibgħut lura wara li jintuża l-operatur tas-sejħa.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Twettaq l-operazzjoni tas-sejħa.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}