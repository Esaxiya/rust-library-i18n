/// A trait biex tippersonalizza l-imġieba tal-operatur `?`.
///
/// Tip li jimplimenta `Try` huwa wieħed li għandu mod kanoniku biex jarah f'termini ta 'dikotomija success/failure.
/// Dan trait jippermetti kemm l-estrazzjoni ta 'dawk il-valuri ta' suċċess jew falliment minn istanza eżistenti kif ukoll il-ħolqien ta 'istanza ġdida minn valur ta' suċċess jew falliment.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// It-tip ta 'dan il-valur meta jitqies bħala ta' suċċess.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// It-tip ta 'dan il-valur meta meqjus bħala fallut.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Japplika l-operatur "?".Ritorn ta `Ok(t)` ifisser li l-eżekuzzjoni għandha tkompli b'mod normali, u r-riżultat ta' `?` huwa l-valur `t`.
    /// Ritorn ta `Err(e)` ifisser li l-eżekuzzjoni għandha branch għall-iktar ġewwieni li jagħlaq `catch`, jew tirritorna mill-funzjoni.
    ///
    /// Jekk jiġi rritornat riżultat `Err(e)`, il-valur `e` ikun "wrapped" fit-tip ta 'ritorn tal-ambitu magħluq (li għandu jimplimenta huwa stess `Try`).
    ///
    /// Speċifikament, il-valur `X::from_error(From::from(e))` jintbagħat lura, fejn `X` huwa t-tip ta 'ritorn tal-funzjoni li tagħlaq.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Kebbeb valur ta 'żball biex tibni r-riżultat kompost.
    /// Pereżempju, `Result::Err(x)` u `Result::from_error(x)` huma ekwivalenti.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Kebbeb valur OK biex tibni r-riżultat kompost.
    /// Pereżempju, `Result::Ok(x)` u `Result::from_ok(x)` huma ekwivalenti.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}