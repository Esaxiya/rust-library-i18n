//! Funzjonalità għall-ordni u t-tqabbil.
//!
//! Dan il-modulu fih diversi għodod biex tordna u tqabbel il-valuri.Fil-qosor:
//!
//! * [`Eq`] u [`PartialEq`] huma traits li jippermettulek tiddefinixxi ugwaljanza totali u parzjali bejn il-valuri, rispettivament.
//! L-implimentazzjoni tagħhom tgħabbi żżejjed lill-operaturi `==` u `!=`.
//! * [`Ord`] u [`PartialOrd`] huma traits li jippermettulek tiddefinixxi ordnijiet totali u parzjali bejn il-valuri, rispettivament.
//!
//! L-implimentazzjoni tagħhom tgħabbi żżejjed l-operaturi `<`, `<=`, `>`, u `>=`.
//! * [`Ordering`] huwa enum mibgħut lura mill-funzjonijiet ewlenin ta [`Ord`] u [`PartialOrd`], u jiddeskrivi ordni.
//! * [`Reverse`] hija struttura li tippermettilek li tirriversja ordni faċilment.
//! * [`max`] u [`min`] huma funzjonijiet li jibnu minn [`Ord`] u jippermettulek issib il-massimu jew il-minimu ta 'żewġ valuri.
//!
//! Għal aktar dettalji, ara d-dokumentazzjoni rispettiva ta 'kull oġġett fil-lista.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// Trait għal paraguni ta 'ugwaljanza li huma [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation).
///
/// Dan trait jippermetti ugwaljanza parzjali, għal tipi li m'għandhomx relazzjoni ta 'ekwivalenza sħiħa.
/// Pereżempju, f'numri b'punt li jvarja `NaN != NaN`, allura t-tipi b'punt li jvarja jimplimentaw `PartialEq` iżda mhux [`trait@Eq`].
///
/// Formalment, l-ugwaljanza għandha tkun (għal kull `a`, `b`, `c` tat-tip `A`, `B`, `C`):
///
/// - **Simetriku**: jekk `A: PartialEq<B>` u `B: PartialEq<A>`, allura **"a==b" jimplika "b==a"**;u
///
/// - **Transittiv**: jekk `A: PartialEq<B>` u `B: PartialEq<C>` u `A:
///   PartialEq<C>", allura **" a==b "u `b == c` jimplika" a==c "**.
///
/// Innota li l-impls `B: PartialEq<A>` (symmetric) u `A: PartialEq<C>` (transitive) mhumiex sfurzati li jeżistu, iżda dawn ir-rekwiżiti japplikaw kull meta jeżistu.
///
/// ## Derivable
///
/// Dan trait jista 'jintuża ma' `#[derive]`.Meta `joħorġu`d fuq strutturi, żewġ każijiet huma ugwali jekk l-oqsma kollha huma ugwali, u mhux ugwali jekk xi oqsma mhumiex ugwali.Meta `joħorġu`d fuq enums, kull varjant huwa ugwali għalih innifsu u mhux daqs il-varjanti l-oħra.
///
/// ## Kif nista 'nimplimenta `PartialEq`?
///
/// `PartialEq` teħtieġ biss li jiġi implimentat il-metodu [`eq`];[`ne`] huwa definit f'termini tiegħu awtomatikament.Kwalunkwe implimentazzjoni manwali ta [`ne`]*għandha* tirrispetta r-regola li [`eq`] huwa invers strett ta' [`ne`];jiġifieri, `!(a == b)` jekk u biss jekk `a != b`.
///
/// Implimentazzjonijiet ta `PartialEq`, [`PartialOrd`], u [`Ord`]*għandhom* jaqblu ma' xulxin.Huwa faċli li aċċidentalment tagħmilhom ma jaqblux billi tnissel ftit miż-traits u timplimenta manwalment oħrajn.
///
/// Eżempju ta 'implimentazzjoni għal dominju li fih żewġ kotba huma kkunsidrati l-istess ktieb jekk l-ISBN tagħhom jaqbel, anke jekk il-formati huma differenti:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## Kif nista 'nqabbel żewġ tipi differenti?
///
/// It-tip li tista 'tqabbel miegħu huwa kkontrollat mill-parametru tat-tip ta' 'PartialEq'.
/// Pereżempju, ejja nirranġaw il-kodiċi preċedenti tagħna daqsxejn:
///
/// ```
/// // Id-derivat jimplimenta<BookFormat>==<BookFormat>paraguni
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // Implimenta<Book>==<BookFormat>paraguni
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // Implimenta<BookFormat>==<Book>paraguni
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// Billi nbiddlu `impl PartialEq for Book` għal `impl PartialEq<BookFormat> for Book`, nippermettu li 'BookFormat`s jitqabblu ma'`Book`s.
///
/// Paragun bħal dak ta 'hawn fuq, li jinjora xi oqsma tal-istruttura, jista' jkun perikoluż.Jista 'faċilment iwassal għal ksur mhux intenzjonat tar-rekwiżiti għal relazzjoni ta' ekwivalenza parzjali.
/// Pereżempju, jekk inżommu l-implimentazzjoni ta `hawn fuq ta` `PartialEq<Book>` għal `BookFormat` u żidna implimentazzjoni ta `PartialEq<Book>` għal `Book` (jew permezz ta` `#[derive]` jew permezz tal-implimentazzjoni manwali mill-ewwel eżempju) allura r-riżultat jikser it-transitività:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// Dan il-metodu jittestja biex il-valuri `self` u `other` ikunu ugwali, u jintuża minn `==`.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// Dan il-metodu jittestja għal `!=`.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// Iġbed makro li jiġġenera impl ta 'trait `PartialEq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// Trait għal paraguni ta 'ugwaljanza li huma [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation).
///
/// Dan ifisser li minbarra li `a == b` u `a != b` huma inversi stretti, l-ugwaljanza trid tkun (għal `a`, `b` u `c` kollha):
///
/// - reflexive: `a == a`;
/// - simetriku: `a == b` jimplika `b == a`;u
/// - transittiv: `a == b` u `b == c` jimplika `a == c`.
///
/// Din il-proprjetà ma tistax tiġi kkontrollata mill-kompilatur, u għalhekk `Eq` jimplika [`PartialEq`], u m'għandux metodi addizzjonali.
///
/// ## Derivable
///
/// Dan trait jista 'jintuża ma' `#[derive]`.
/// Meta 'joħorġu`d, minħabba li `Eq` m'għandux metodi żejda, qed jinforma lill-kompilatur biss li din hija relazzjoni ta' ekwivalenza aktar milli relazzjoni ta 'ekwivalenza parzjali.
///
/// Innota li l-istrateġija `derive` teħtieġ li l-oqsma kollha huma `Eq`, li mhux dejjem mixtieqa.
///
/// ## Kif nista 'nimplimenta `Eq`?
///
/// Jekk ma tistax tuża l-istrateġija `derive`, speċifika li t-tip tiegħek jimplimenta `Eq`, li m'għandux metodi:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // dan il-metodu jintuża biss minn#[derivazzjoni] biex tafferma li kull komponent ta 'tip jimplimenta#[derivazzjoni] innifsu, l-infrastruttura derivanti attwali tfisser li tagħmel din l-affermazzjoni mingħajr ma tuża metodu fuq dan trait huwa kważi impossibbli.
    //
    //
    // Dan qatt ma għandu jiġi implimentat bl-idejn.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// Iġbed makro li jiġġenera impl ta 'trait `Eq`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: din l-istruttura tintuża biss minn#[derivat] to
// afferma li kull komponent ta 'tip jimplimenta l-Eq.
//
// Din l-istruttura qatt ma għandha tidher fil-kodiċi tal-utent.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// `Ordering` huwa r-riżultat ta 'tqabbil bejn żewġ valuri.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// Ordni fejn valur imqabbel huwa inqas minn ieħor.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// Ordni fejn valur imqabbel huwa ugwali għal ieħor.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// Ordni fejn valur imqabbel huwa akbar minn ieħor.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// Jirritorna `true` jekk l-ordni hija l-varjant `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// Jirritorna `true` jekk l-ordni mhix il-varjant `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// Jirritorna `true` jekk l-ordni hija l-varjant `Less`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// Jirritorna `true` jekk l-ordni hija l-varjant `Greater`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// Jirritorna `true` jekk l-ordni hija jew il-varjant `Less` jew `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// Jirritorna `true` jekk l-ordni hija jew il-varjant `Greater` jew `Equal`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// Jaqleb ix-`Ordering`.
    ///
    /// * `Less` isir `Greater`.
    /// * `Greater` isir `Less`.
    /// * `Equal` isir `Equal`.
    ///
    /// # Examples
    ///
    /// Imġieba bażika:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// Dan il-metodu jista 'jintuża biex ireġġa' tqabbil:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // issortja l-firxa mill-akbar għall-iżgħar.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// Ktajjen żewġ ordnijiet.
    ///
    /// Jirritorna `self` meta ma jkunx `Equal`.Inkella jirritorna `other`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// Ktajjen l-ordni bil-funzjoni mogħtija.
    ///
    /// Jirritorna `self` meta ma jkunx `Equal`.
    /// Inkella jsejjaħ lil `f` u jirritorna r-riżultat.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// Struttura helper għall-ordni bil-maqlub.
///
/// Din l-istruttura hija helper li għandha tintuża ma 'funzjonijiet bħal [`Vec::sort_by_key`] u tista' tintuża biex tordna parti minn ċavetta.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// Trait għal tipi li jiffurmaw [total order](https://en.wikipedia.org/wiki/Total_order).
///
/// Ordni hija ordni totali jekk hi (għal `a`, `b` u `c` kollha):
///
/// - totali u assimetriku: eżattament waħda minn `a < b`, `a == b` jew `a > b` hija vera;u
/// - transittiv, `a < b` u `b < c` jimplika `a < c`.L-istess għandu jgħodd kemm għal `==` kif ukoll għal `>`.
///
/// ## Derivable
///
/// Dan trait jista 'jintuża ma' `#[derive]`.
/// Meta `toħroġ`d fuq strutturi, tipproduċi ordni [lexicographic](https://en.wikipedia.org/wiki/Lexicographic_order) ibbażata fuq l-ordni ta 'dikjarazzjoni minn fuq għal isfel tal-membri ta' l-istruttura.
///
/// Meta 'joħorġu`d fuq enums, varjanti huma ordnati bl-ordni diskriminanti tagħhom minn fuq għal isfel.
///
/// ## Paragun lexicografiku
///
/// Il-paragun leċikografiku huwa operazzjoni bil-proprjetajiet li ġejjin:
///  - Żewġ sekwenzi huma mqabbla element b'element.
///  - L-ewwel element li ma jaqbilx jiddefinixxi liema sekwenza hija lessikografikament inqas jew akbar mill-oħra.
///  - Jekk sekwenza waħda hija prefiss ta 'oħra, is-sekwenza iqsar hija lessikografikament inqas mill-oħra.
///  - Jekk żewġ sekwenzi għandhom elementi ekwivalenti u huma ta 'l-istess tul, allura s-sekwenzi huma lessikografikament ugwali.
///  - Sekwenza vojta hija lessikografikament inqas minn kwalunkwe sekwenza mhux vojta.
///  - Żewġ sekwenzi vojta huma lessikografikament ugwali.
///
/// ## Kif nista 'nimplimenta `Ord`?
///
/// `Ord` teħtieġ li t-tip ikun ukoll [`PartialOrd`] u [`Eq`] (li jeħtieġ [`PartialEq`]).
///
/// Imbagħad trid tiddefinixxi implimentazzjoni għal [`cmp`].Tista 'ssibha utli li tuża [`cmp`] fl-oqsma tat-tip tiegħek.
///
/// Implimentazzjonijiet ta [`PartialEq`], [`PartialOrd`], u `Ord`*għandhom* jaqblu ma' xulxin.
/// Jiġifieri, `a.cmp(b) == Ordering::Equal` jekk u biss jekk `a == b` u `Some(a.cmp(b)) == a.partial_cmp(b)` għal `a` u `b` kollha.
/// Huwa faċli li aċċidentalment tagħmilhom ma jaqblux billi tnissel ftit miż-traits u timplimenta manwalment oħrajn.
///
/// Hawn hu eżempju fejn trid issortja n-nies skont l-għoli biss, billi tinjora `id` u `name`:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// Dan il-metodu jirritorna [`Ordering`] bejn `self` u `other`.
    ///
    /// B'konvenzjoni, `self.cmp(&other)` jirritorna l-ordni li taqbel mal-espressjoni `self <operator> other` jekk vera.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// Iqabbel u jirritorna l-massimu ta 'żewġ valuri.
    ///
    /// Jirritorna t-tieni argument jekk il-paragun jiddeterminahom bħala ugwali.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// Iqabbel u jirritorna l-minimu ta 'żewġ valuri.
    ///
    /// Jirritorna l-ewwel argument jekk il-paragun jiddeterminahom bħala ugwali.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// Irrestrinġi valur għal ċertu intervall.
    ///
    /// Jirritorna `max` jekk `self` huwa akbar minn `max`, u `min` jekk `self` huwa inqas minn `min`.
    /// Inkella dan jirritorna `self`.
    ///
    /// # Panics
    ///
    /// Panics jekk `min > max`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// Iġbed makro li jiġġenera impl ta 'trait `Ord`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// Trait għal valuri li jistgħu jitqabblu għal ordni ta 'għażla.
///
/// Il-paragun għandu jissodisfa, għal kull `a`, `b` u `c`:
///
/// - assimetrija: jekk `a < b` allura `!(a > b)`, kif ukoll `a > b` li jimplika `!(a < b)`;u
/// - transittività: `a < b` u `b < c` jimplika `a < c`.L-istess għandu jgħodd kemm għal `==` kif ukoll għal `>`.
///
/// Innota li dawn ir-rekwiżiti jfissru li l-trait innifsu għandu jkun implimentat b'mod simetriku u transittiv: jekk `T: PartialOrd<U>` u `U: PartialOrd<V>` allura `U: PartialOrd<T>` u `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// Dan trait jista 'jintuża ma' `#[derive]`.Meta `joħroġ`d fuq strutturi, se jipproduċi ordni lessikografika bbażata fuq l-ordni ta 'dikjarazzjoni minn fuq għal isfel tal-membri ta' l-istruttura.
/// Meta 'joħorġu`d fuq enums, varjanti huma ordnati bl-ordni diskriminanti tagħhom minn fuq għal isfel.
///
/// ## Kif nista 'nimplimenta `PartialOrd`?
///
/// `PartialOrd` teħtieġ biss implimentazzjoni tal-metodu [`partial_cmp`], bl-oħrajn iġġenerati minn implimentazzjonijiet awtomatiċi.
///
/// Madankollu jibqa 'possibbli li l-oħrajn jiġu implimentati separatament għal tipi li m'għandhomx ordni totali.
/// Pereżempju, għal numri b'punt li jvarja, `NaN < 0 == false` u `NaN >= 0 == false` (cf.
/// IEEE 754-2008 taqsima 5.11).
///
/// `PartialOrd` jeħtieġ li t-tip tiegħek ikun [`PartialEq`].
///
/// Implimentazzjonijiet ta [`PartialEq`], `PartialOrd`, u [`Ord`]*għandhom* jaqblu ma' xulxin.
/// Huwa faċli li aċċidentalment tagħmilhom ma jaqblux billi tnissel ftit miż-traits u timplimenta manwalment oħrajn.
///
/// Jekk it-tip tiegħek huwa [`Ord`], tista 'timplimenta [`partial_cmp`] billi tuża [`cmp`]:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// Tista 'wkoll issibha utli li tuża [`partial_cmp`] fl-oqsma tat-tip tiegħek.
/// Hawn hu eżempju ta 'tipi `Person` li għandhom field `height` b'punt li jvarja li huwa l-uniku field li għandu jintuża għall-għażla:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// Dan il-metodu jirritorna ordni bejn il-valuri `self` u `other` jekk jeżisti wieħed.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// Meta l-paragun huwa impossibbli:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// Dan il-metodu jittestja inqas minn (għal `self` u `other`) u jintuża mill-operatur `<`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// Dan il-metodu jittestja inqas minn jew ugwali għal (għal `self` u `other`) u jintuża mill-operatur `<=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// Dan il-metodu jittestja akbar minn (għal `self` u `other`) u jintuża mill-operatur `>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// Dan il-metodu jittestja akbar minn jew ugwali għal (għal `self` u `other`) u jintuża mill-operatur `>=`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// Iġbed makro li jiġġenera impl ta 'trait `PartialOrd`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// Iqabbel u jirritorna l-minimu ta 'żewġ valuri.
///
/// Jirritorna l-ewwel argument jekk il-paragun jiddeterminahom bħala ugwali.
///
/// Internament juża psewdonimu għal [`Ord::min`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// Jirritorna l-minimu ta 'żewġ valuri fir-rigward tal-funzjoni ta' tqabbil speċifikata.
///
/// Jirritorna l-ewwel argument jekk il-paragun jiddeterminahom bħala ugwali.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// Jirritorna l-element li jagħti l-valur minimu mill-funzjoni speċifikata.
///
/// Jirritorna l-ewwel argument jekk il-paragun jiddeterminahom bħala ugwali.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// Iqabbel u jirritorna l-massimu ta 'żewġ valuri.
///
/// Jirritorna t-tieni argument jekk il-paragun jiddeterminahom bħala ugwali.
///
/// Internament juża psewdonimu għal [`Ord::max`].
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// Jirritorna l-massimu ta 'żewġ valuri fir-rigward tal-funzjoni ta' tqabbil speċifikata.
///
/// Jirritorna t-tieni argument jekk il-paragun jiddeterminahom bħala ugwali.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// Jirritorna l-element li jagħti l-valur massimu mill-funzjoni speċifikata.
///
/// Jirritorna t-tieni argument jekk il-paragun jiddeterminahom bħala ugwali.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// Implimentazzjoni ta 'PartialEq, Eq, PartialOrd u Ord għal tipi primittivi
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // L-ordni hawnhekk hija importanti biex tiġġenera assemblaġġ aħjar.
                    // Ara <https://github.com/rust-lang/rust/issues/63758> għal aktar informazzjoni.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // L-ikkastjar għal i8's u l-konverżjoni tad-differenza għal Ordni tiġġenera assemblaġġ aħjar.
            //
            // Ara <https://github.com/rust-lang/rust/issues/66780> għal aktar informazzjoni.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // SIGURTÀ: bool hekk kif i8 jirritorna 0 jew 1, allura d-differenza ma tistax tkun xi ħaġa oħra
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &indikaturi

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}