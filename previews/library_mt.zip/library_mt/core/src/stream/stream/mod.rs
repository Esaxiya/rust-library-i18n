use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Interface biex tittratta ma 'iteraturi mhux sinkroniċi.
///
/// Dan huwa l-fluss ewlieni trait.
/// Għal aktar dwar il-kunċett ta 'flussi ġeneralment, jekk jogħġbok ara x-[module-level documentation].
/// B'mod partikolari, tista 'tkun trid tkun taf kif [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// It-tip ta 'oġġetti mogħtija mill-fluss.
    type Item;

    /// Ipprova ħu l-valur li jmiss ta 'dan in-nixxiegħa, tirreġistra l-kompitu kurrenti għal wakeup jekk il-valur għadu mhux disponibbli, u rritorna `None` jekk in-nixxiegħa tkun eżawrita.
    ///
    /// # Valur tar-ritorn
    ///
    /// Hemm diversi valuri ta 'ritorn possibbli, kull wieħed jindika stat ta' fluss distint:
    ///
    /// - `Poll::Pending` ifisser li l-valur li jmiss ta 'dan il-fluss għadu mhux lest.Implimentazzjonijiet se jiżguraw li l-kompitu kurrenti jiġi notifikat meta l-valur li jmiss jista 'jkun lest.
    ///
    /// - `Poll::Ready(Some(val))` ifisser li n-nixxiegħa pproduċiet b'suċċess valur, `val`, u tista 'tipproduċi aktar valuri fuq sejħiet `poll_next` sussegwenti.
    ///
    /// - `Poll::Ready(None)` ifisser li n-nixxiegħa ntemmet, u `poll_next` m'għandux jerġa 'jiġi invokat.
    ///
    /// # Panics
    ///
    /// Ladarba nixxiegħa tkun spiċċat (`Ready(None)` from `poll_next`) irritornat, is-sejħa tal-metodu `poll_next` tagħha mill-ġdid tista 'panic, timblokka għal dejjem, jew tikkawża tipi oħra ta' problemi; ix-`Stream` trait ma jpoġġi l-ebda ħtiġijiet fuq l-effetti ta 'sejħa bħal din.
    ///
    /// Madankollu, billi l-metodu `poll_next` mhuwiex immarkat `unsafe`, japplikaw ir-regoli tas-soltu ta 'Rust: is-sejħiet m'għandhom qatt jikkawżaw imġieba mhux definita (korruzzjoni tal-memorja, użu ħażin tal-funzjonijiet `unsafe`, jew simili), irrispettivament mill-istat tan-nixxiegħa.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Jirritorna l-limiti fuq it-tul li jifdal tal-fluss.
    ///
    /// Speċifikament, `size_hint()` jirritorna tupla fejn l-ewwel element huwa l-limitu ta 'isfel, u t-tieni element huwa l-limitu ta' fuq.
    ///
    /// It-tieni nofs tat-tupla li tiġi rritornata hija [`Għażla`]`<`[`uża`] `>`.
    /// [`None`] hawn ifisser li jew m'hemm l-ebda limitu ta 'fuq magħruf, jew il-limitu ta' fuq huwa akbar minn [`usize`].
    ///
    /// # Noti ta 'implimentazzjoni
    ///
    /// Mhuwiex infurzat li implimentazzjoni ta 'fluss tagħti n-numru ddikjarat ta' elementi.Fluss buggy jista 'jagħti inqas mill-limitu l-aktar baxx jew aktar mill-limitu ta' fuq tal-elementi.
    ///
    /// `size_hint()` huwa maħsub primarjament biex jintuża għal ottimizzazzjonijiet bħar-riservazzjoni ta 'spazju għall-elementi tan-nixxiegħa, iżda m'għandux jiġi fdat biex eż. iħalli barra l-kontrolli tal-limiti f'kodiċi mhux sikuri.
    /// Implimentazzjoni ħażina ta `size_hint()` m'għandhiex twassal għal ksur tas-sigurtà tal-memorja.
    ///
    /// Cela dit, l-implimentazzjoni għandha tipprovdi stima korretta, għax inkella tkun ksur tal-protokoll taż-trait.
    ///
    /// L-implimentazzjoni awtomatika tirritorna `(0,` ['Xejn`]`)` li huwa korrett għal kwalunkwe fluss.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}