//! Iterazzjoni asinkronika kompożibbli.
//!
//! Jekk futures huma valuri mhux sinkroniċi, allura n-nixxigħat huma iteraturi mhux sinkroniċi.
//! Jekk sibt lilek innifsek b'ġabra mhux sinkronika ta 'xi tip, u teħtieġ li twettaq operazzjoni fuq l-elementi ta' l-imsemmija ġabra, malajr tidħol f 'streams'.
//! Il-flussi jintużaw ħafna fil-kodiċi Rust idjomatiku mhux sinkroniku, allura ta 'min isiru familjari magħhom.
//!
//! Qabel ma nispjega aktar, ejja nitkellmu dwar kif dan il-modulu huwa strutturat:
//!
//! # Organization
//!
//! Dan il-modulu huwa organizzat fil-biċċa l-kbira skont it-tip:
//!
//! * [Traits] huma l-porzjon ewlieni: dawn iż-traits jiddefinixxu x'tip ta 'flussi jeżistu u x'tista' tagħmel magħhom.Il-metodi ta 'dawn iż-traits ta' min ipoġġu ftit ħin ta 'studju żejjed.
//! * Il-funzjonijiet jipprovdu xi modi utli biex jinħolqu xi flussi bażiċi.
//! * L-istrutturi spiss huma t-tipi ta 'ritorn tal-metodi varji fuq traits ta' dan il-modulu.Normalment tkun trid tħares lejn il-metodu li joħloq ix-`struct`, aktar milli x-`struct` innifsu.
//! Għal aktar dettalji dwar għaliex, ara '[Fluss ta' Implimentazzjoni](#fluss ta 'implimentazzjoni)'.
//!
//! [Traits]: #traits
//!
//! Dak hu!Ejja nħaffru fil-flussi.
//!
//! # Stream
//!
//! Il-qalb u r-ruħ ta 'dan il-modulu hija [`Stream`] trait.Il-qalba ta [`Stream`] tidher hekk:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! B'differenza minn `Iterator`, `Stream` jagħmel distinzjoni bejn il-metodu [`poll_next`] li jintuża meta timplimenta `Stream`, u metodu (to-be-implemented) `next` li jintuża meta tikkonsma nixxiegħa.
//!
//! Il-konsumaturi ta `Stream` għandhom bżonn jikkunsidraw biss `next`, li meta jissejħu, jirritorna future li jagħti `Option<Stream::Item>`.
//!
//! Iż-future mibgħut lura minn `next` jagħti `Some(Item)` sakemm ikun hemm elementi, u ladarba jkunu ġew eżawriti kollha, jagħti `None` biex jindika li l-iterazzjoni hija lesta.
//! Jekk qed nistennew xi ħaġa mhux sinkronika biex insolvu, iż-future se jistenna sakemm in-nixxiegħa tkun lesta biex terġa 'tirrendi.
//!
//! Flussi individwali jistgħu jagħżlu li jerġgħu jibdew iterazzjoni, u għalhekk is-sejħa għal `next` mill-ġdid tista 'jew ma tistax eventwalment tagħti `Some(Item)` għal darb'oħra f'xi punt.
//!
//! Id-definizzjoni sħiħa ta '[`Stream`] tinkludi numru ta' metodi oħra wkoll, imma huma metodi awtomatiċi, mibnija fuq [`poll_next`], u għalhekk ikollokhom b'xejn.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implimentazzjoni tal-Fluss
//!
//! Il-ħolqien ta 'fluss tiegħek jinvolvi żewġ passi: il-ħolqien ta' `struct` biex iżomm l-istat tan-nixxiegħa, u mbagħad timplimenta [`Stream`] għal dak ix-`struct`.
//!
//! Ejja nagħmlu nixxiegħa msemmija `Counter` li tgħodd minn `1` sa `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // L-ewwel, l-istruttura:
//!
//! /// Fluss li jgħodd minn wieħed għal ħamsa
//! struct Counter {
//!     count: usize,
//! }
//!
//! // irridu li l-għadd tagħna jibda f'waħda, allura ejja nżidu metodu new() biex ngħinu.
//! // Dan mhux strettament meħtieġ, iżda huwa konvenjenti.
//! // Innota li nibdew `count` għal żero, naraw għaliex fl-implimentazzjoni `poll_next()`'s hawn taħt.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Imbagħad, nimplimentaw `Stream` għax-`Counter` tagħna:
//!
//! impl Stream for Counter {
//!     // inkunu qed ngħoddu bl-użu
//!     type Item = usize;
//!
//!     // poll_next() huwa l-uniku metodu meħtieġ
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Żid l-għadd tagħna.Dan hu għaliex bdejna żero.
//!         self.count += 1;
//!
//!         // Iċċekkja biex tara jekk lestejtx ngħoddu jew le.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Il-flussi huma *għażżienin*.Dan ifisser li sempliċement il-ħolqien ta 'nixxiegħa ma _do_ ħafna.Xejn ma jiġri verament qabel ma ċċempel lil `next`.
//! Xi drabi dan huwa sors ta 'konfużjoni meta toħloq nixxiegħa biss għall-effetti sekondarji tagħha.
//! Il-kompilatur iwissina dwar dan it-tip ta 'mġieba:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;