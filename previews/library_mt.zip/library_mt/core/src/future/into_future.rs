use crate::future::Future;

/// Konverżjoni f `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// L-output li future se jipproduċi mat-tlestija.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// F'liema tip ta 'future qed nibdlu dan?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Joħloq future minn valur.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}