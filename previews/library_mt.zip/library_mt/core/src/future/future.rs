#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future jirrappreżenta komputazzjoni mhux sinkronika.
///
/// future huwa valur li jista 'jkun li għadu ma spiċċax l-informatika.
/// Dan it-tip ta "asynchronous value" jagħmilha possibbli għal thread li tkompli tagħmel xogħol utli waqt li tistenna li l-valur isir disponibbli.
///
///
/// # Il-metodu `poll`
///
/// Il-metodu ewlieni ta 'future, `poll`,*jipprova* jsolvi ż-future f'valur finali.
/// Dan il-metodu ma jimblokkax jekk il-valur mhux lest.
/// Minflok, il-kompitu kurrenti huwa skedat li jqum meta jkun possibbli li jsir aktar progress billi terġa 'tivvota.
/// Ix-`context` mgħoddi għall-metodu `poll` jista 'jipprovdi [`Waker`], li huwa manku biex tqajjem il-kompitu kurrenti.
///
/// Meta tuża future, ġeneralment ma ssejjaħx lil `poll` direttament, iżda minflok `.await` il-valur.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// It-tip ta 'valur prodott mat-tlestija.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Ipprova ssolvi ż-future għal valur finali, tirreġistra l-kompitu kurrenti għal wakeup jekk il-valur għadu mhux disponibbli.
    ///
    /// # Valur tar-ritorn
    ///
    /// Din il-funzjoni tirritorna:
    ///
    /// - [`Poll::Pending`] jekk iż-future għadu mhux lest
    /// - [`Poll::Ready(val)`] bir-riżultat `val` ta 'dan future jekk spiċċa b'suċċess.
    ///
    /// Ladarba future ikun spiċċa, il-klijenti m'għandhomx `poll` jerġgħu.
    ///
    /// Meta future għadu mhux lest, `poll` jirritorna `Poll::Pending` u jaħżen klonu tax-[`Waker`] ikkupjat mix-[`Context`] kurrenti.
    /// Dan ix-[`Waker`] imbagħad jinxtegħel ladarba future jista 'jagħmel progress.
    /// Pereżempju, future li qed jistenna li sokit isir leġġibbli jsejjaħ lil `.clone()` fuq ix-[`Waker`] u jaħżnu.
    /// Meta tasal sinjal x'imkien ieħor li jindika li s-sokit jista 'jinqara, jissejjaħ [`Waker::wake`] u l-kompitu tas-sokit future jinqala'.
    /// Ladarba kompitu jqum, għandu jipprova `poll` iż-future mill-ġdid, li jista 'jipproduċi valur finali jew le.
    ///
    /// Innota li fuq sejħiet multipli lil `poll`, ix-[`Waker`] biss mix-[`Context`] mgħoddi għas-sejħa l-aktar reċenti għandu jkun skedat li jirċievi wakeup.
    ///
    /// # Karatteristiċi tal-ħin ta 'eżekuzzjoni
    ///
    /// Futures waħedhom huma *inerti*;iridu jiġu "stmati" b'mod attiv * biex jagħmlu progress, li jfisser li kull darba li l-kompitu kurrenti jinxtegħel, għandu jerġa '' jħaddem 'b'mod attiv sakemm futures li għad għandu interess fih.
    ///
    /// Il-funzjoni `poll` ma tissejjaħx ripetutament f'ċirkuwitu strett-minflok, għandha tissejjaħ biss meta ż-future jindika li hija lesta li tagħmel progress (billi ċċempel lil `wake()`).
    /// Jekk int familjari mas-syscalls `poll(2)` jew `select(2)` fuq Unix ta 'min jinnota li futures tipikament *ma* jsofrux l-istess problemi ta' "all wakeups must poll all events";huma aktar bħal `epoll(4)`.
    ///
    /// Implimentazzjoni ta `poll` għandha tagħmel ħilitha biex tirritorna malajr, u m'għandhiex timblokka.Ir-ritorn malajr jimpedixxi l-imblukkar bla bżonn ta 'ħjut jew loops ta' avvenimenti.
    /// Jekk ikun magħruf minn qabel li sejħa għal `poll` tista 'tispiċċa tieħu ftit, ix-xogħol għandu jinħatt għal ġabra ta' ħajt (jew xi ħaġa simili) biex jiġi żgurat li `poll` jista 'jirritorna malajr.
    ///
    /// # Panics
    ///
    /// Ladarba future ikun temm (irritorna `Ready` minn `poll`), iċempel mill-ġdid il-metodu `poll` tiegħu jista 'panic, jimblokka għal dejjem, jew jikkawża tipi oħra ta' problemi;ix-`Future` trait ma jpoġġi l-ebda rekwiżit fuq l-effetti ta 'sejħa bħal din.
    /// Madankollu, billi l-metodu `poll` mhuwiex immarkat `unsafe`, japplikaw ir-regoli tas-soltu ta 'Rust: is-sejħiet m'għandhom qatt jikkawżaw imġieba mhux definita (korruzzjoni tal-memorja, użu ħażin tal-funzjonijiet `unsafe`, jew simili), irrispettivament mill-istat taż-future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}