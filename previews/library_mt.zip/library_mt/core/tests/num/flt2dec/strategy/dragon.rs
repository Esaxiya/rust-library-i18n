use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri huwa bil-mod wisq
fn exact_sanity_test() {
    // Dan it-test jispiċċa jaħdem dak li nista 'biss nassumi li huwa xi każ ta' kantuniera tal-funzjoni tal-librerija `exp2`, definita fi kwalunkwe C runtime li qed nużaw.
    // Fil-VS 2013 din il-funzjoni apparentement kellha bug peress li dan it-test ifalli meta jkun marbut, iżda mal-VS 2015 il-bug jidher iffissat billi t-test jimxi tajjeb.
    //
    // Il-bug jidher li huwa differenza fil-valur ta 'ritorn ta' `exp2(-1057)`, fejn fil-VS 2013 jirritorna doppja bil-mudell tal-bit 0x2 u fil-VS 2015 jirritorna 0x20000.
    //
    //
    // Għalissa sempliċement tinjora dan it-test kompletament fuq MSVC peress li huwa ttestjat x'imkien ieħor xorta u m'aħniex interessati ħafna fl-ittestjar tal-implimentazzjoni exp2 ta 'kull pjattaforma.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}