# Ix-`rustc-std-workspace-core` crate

Dan crate huwa crate shim u vojt li sempliċement jiddependi fuq `libcore` u jesporta mill-ġdid il-kontenut kollu tiegħu.
Iż-crate huwa l-qofol li l-librerija standard tingħata s-setgħa li tiddependi fuq crates minn crates.io

Crates fuq crates.io li l-librerija standard tiddependi fuq il-ħtieġa li tiddependi fuq ix-`rustc-std-workspace-core` crate minn crates.io, li hija vojta.

Aħna nużaw `[patch]` biex nwarrabha għal dan iż-crate f'dan ir-repożitorju.
Bħala riżultat, crates fuq crates.io jiġbed dipendenza edge sa `libcore`, il-verżjoni definita f'dan ir-repożitorju.
Dak għandu jiġbed it-truf tad-dipendenza kollha biex jiżgura li Cargo jibni crates b'suċċess!

Innota li crates fuq crates.io jeħtieġ li jiddependi fuq dan crate bl-isem `core` biex kollox jaħdem sew.Biex jagħmlu dan jistgħu jużaw:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Permezz tal-użu taċ-ċavetta `package` iż-crate jingħata isem ġdid għal `core`, li jfisser li tidher qisha

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

meta Cargo jinvoka l-kompilatur, li jissodisfa d-direttiva impliċita `extern crate core` injettata mill-kompilatur.




