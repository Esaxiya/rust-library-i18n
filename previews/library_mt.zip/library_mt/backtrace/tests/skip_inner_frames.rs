use backtrace::Backtrace;

// Dan it-test jaħdem biss fuq pjattaformi li għandhom funzjoni `symbol_address` li taħdem għal frames li tirrapporta l-indirizz tal-bidu ta 'simbolu.
// Bħala riżultat huwa attivat biss fuq ftit pjattaformi.
//
const ENABLED: bool = cfg!(all(
    // Windows ma kienx verament ittestjat, u OSX ma jappoġġjax fil-fatt is-sejba ta 'qafas li jagħlaq, għalhekk itfi dan
    //
    target_os = "linux",
    // Fuq ARM is-sejba tal-funzjoni li tagħlaq hija sempliċement tirritorna l-ip innifsu.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}