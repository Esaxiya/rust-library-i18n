use backtrace::Backtrace;

// Isem tal-modulu ta '50 karattru
mod _234567890_234567890_234567890_234567890_234567890 {
    // Isem ta '50 karattru struct
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// Ismijiet ta 'funzjoni twila għandhom jiġu maqtugħa għal karattri (MAX_SYM_NAME, 1).
// Ħaddem dan it-test biss għal msvc, billi gnu jistampa "<no info>" għall-frames kollha.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // 10 repetizzjonijiet ta 'isem struct, għalhekk l-isem tal-funzjoni kwalifikat bis-sħiħ huwa mill-inqas 10 *(50 + 50)* 2=2000 karattru.
    //
    // Huwa fil-fatt itwal peress li jinkludi wkoll `::`, `<>` u l-isem tal-modulu kurrenti
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}