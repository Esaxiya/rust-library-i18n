use core::ffi::c_void;
use core::fmt;

/// Tispezzjona s-sejħa-munzell attwali, billi tgħaddi l-frejms attivi kollha fl-għeluq ipprovdut biex tikkalkula traċċa tal-munzell.
///
/// Din il-funzjoni hija l-qofol tax-xogħol ta 'din il-librerija fil-kalkolu tat-traċċi tal-munzell għal programm.L-għeluq mogħti `cb` jingħata każijiet ta `Frame` li jirrappreżentaw informazzjoni dwar dak il-qafas tas-sejħa fuq il-munzell.
/// L-għeluq jingħata frejms b'mod top-down (l-aktar reċentement imsejħa funzjonijiet l-ewwel).
///
/// Il-valur ta 'ritorn tal-għeluq huwa indikazzjoni ta' jekk it-traċċa ta 'wara għandhiex tkompli.Valur ta 'ritorn ta' `false` itemm it-traċċa ta 'wara u jirritorna immedjatament.
///
/// Ladarba `Frame` jiġi akkwistat x'aktarx li tkun trid iċċempel lil `backtrace::resolve` biex tikkonverti l-`ip` (struzzjoni pointer) jew l-indirizz tas-simbolu għal `Symbol` li permezz tiegħu jistgħu jitgħallmu l-isem u/jew l-isem tal-fajl/in-numru tal-linja.
///
///
/// Innota li din hija funzjoni ta 'livell relattivament baxx u jekk tixtieq, per eżempju, taqbad traċċa ta' wara biex tkun spezzjonata aktar tard, allura t-tip `Backtrace` jista 'jkun aktar xieraq.
///
/// # Karatteristiċi meħtieġa
///
/// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
///
/// # Panics
///
/// Din il-funzjoni tistinka biex qatt ma panic, imma jekk ix-`cb` ipprovda panics allura xi pjattaformi jġiegħlu panic doppju biex jabbortixxi l-proċess.
/// Xi pjattaformi jużaw librerija C li internament tuża callbacks li ma jistgħux jinħallu, u għalhekk paniku minn `cb` jista 'jwassal għal proċess ta' abort.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // kompli bit-traċċa ta 'wara
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// L-istess bħal `trace`, mhux sikur biss għax mhux sinkronizzat.
///
/// Din il-funzjoni m'għandhiex garanti ta 'sinkronizzazzjoni iżda hija disponibbli meta l-karatteristika `std` ta' dan iż-crate ma tkunx ikkumpilata fih.
/// Ara l-funzjoni `trace` għal aktar dokumentazzjoni u eżempji.
///
/// # Panics
///
/// Ara l-informazzjoni dwar `trace` għal twissijiet dwar paniku ta `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait li jirrappreżenta qafas wieħed ta 'traċċa ta' wara, ċeda għall-funzjoni `trace` ta 'dan crate.
///
/// L-għeluq tal-funzjoni ta 'rintraċċar se jingħata frejms, u l-frejm huwa virtwalment mibgħut minħabba li l-implimentazzjoni sottostanti mhux dejjem magħrufa sa runtime.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Jirritorna l-indikatur tal-istruzzjoni kurrenti ta 'dan il-qafas.
    ///
    /// Din normalment hija l-istruzzjoni li jmiss biex tesegwixxi fil-qafas, iżda mhux l-implimentazzjonijiet kollha jelenkaw dan bi preċiżjoni ta '100% (iżda ġeneralment huwa pjuttost viċin).
    ///
    ///
    /// Huwa rrakkomandat li tgħaddi dan il-valur lil `backtrace::resolve` biex tibdlu f'isem simbolu.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Jirritorna l-pointer tal-munzell kurrenti ta 'dan il-qafas.
    ///
    /// Fil-każ li backend ma jistax jirkupra l-pointer tal-munzell għal dan il-qafas, jintbagħat pointer null.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Jirritorna l-indirizz tas-simbolu tal-bidu tal-qafas ta 'din il-funzjoni.
    ///
    /// Dan se jipprova jreġġa 'lura l-istruzzjoni pointer mibgħuta lura minn `ip` għall-bidu tal-funzjoni, u jirritorna dak il-valur.
    ///
    /// F'xi każijiet, madankollu, backends jirritornaw biss `ip` minn din il-funzjoni.
    ///
    /// Il-valur ritornat jista 'xi kultant jintuża jekk `backtrace::resolve` ma rnexxiex fuq ix-`ip` mogħti hawn fuq.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Jirritorna l-indirizz bażi tal-modulu li għalih jappartjeni l-qafas.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dan jeħtieġ li jiġi l-ewwel, biex jiġi żgurat li Miri tieħu prijorità fuq il-pjattaforma ospitanti
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // jintuża biss fid-dbghelp jissimbolizza
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}