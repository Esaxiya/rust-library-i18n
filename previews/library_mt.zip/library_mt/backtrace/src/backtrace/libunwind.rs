//! Appoġġ ta 'traċċi b'lura billi tuża libunwind/gcc_s/etc APIs.
//!
//! Dan il-modulu fih il-ħila li jbattu l-munzell bl-użu ta 'APIs stil libunwind.
//! Innota li hemm mazz sħiħ ta 'implimentazzjonijiet ta' l-API bħal libunwind, u dan sempliċement qed jipprova jkun kompatibbli ma 'ħafna minnhom f'daqqa minflok ma jkun picky.
//!
//!
//! L-API libunwind hija mħaddma minn `_Unwind_Backtrace` u fil-prattika hija affidabbli ħafna biex tiġġenera traċċa ta 'wara.
//! Mhuwiex ċar għal kollox kif tagħmlu (frame pointers? Eh_frame info? It-tnejn?) Imma jidher li jaħdem!
//!
//! Ħafna mill-kumplessità ta 'dan il-modulu qed tieħu ħsieb id-differenzi varji tal-pjattaforma fl-implimentazzjoni tal-libunwind.
//! Inkella din hija Rust pjuttost sempliċi li torbot mal-APIs libunwind.
//!
//! Din hija l-API default li tħoll il-pjattaformi kollha mhux tal-Windows bħalissa.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// B`punter libunwind mhux ipproċessat għandu jkun dejjem aċċess biss b`mod threadsafe, u għalhekk huwa `Sync`.
// Meta nibgħatu lil ħjut oħra permezz ta `Clone` aħna dejjem naqilbu għal verżjoni li ma żżommx pointers interni, allura għandna nkunu `Send` ukoll.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Jidher li fuq OSX "_Unwind_FindEnclosingFunction" jirritorna pointer għal ... xi ħaġa li mhix ċara.
        // Żgur li mhux dejjem hija l-funzjoni li tagħlaq għal kwalunkwe raġuni.
        // Mhuwiex kompletament ċar għalija x'inhu għaddej hawn, allura pessimizza dan għal issa u sempliċement irritorna l-ip.
        //
        // Innota li t-test `skip_inner_frames.rs` huwa maqbuż fuq OSX minħabba din il-klawsola, u jekk dan huwa ffissat dak it-test fit-teorija jista 'jsir fuq OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Interfaċċja tal-librerija li tinfetaħ użata għal traċċi ta 'wara
///
/// Innota li l-kodiċi mejjet huwa permess għax hawn huma biss rbit li l-iOS ma jużaxhom kollha imma żżid aktar konfigurazzjonijiet speċifiċi għall-pjattaforma tniġġes il-kodiċi wisq
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // użat biss minn ARM EABI
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // L-ebda_Unwind_Backtrace indiġenu fuq iOS
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // disponibbli minn GCC 4.2.0, għandu jkun tajjeb għall-iskop tagħna
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Din il-funzjoni hija isem ħażin: aktar milli tikseb l-Indirizz Kanoniku tal-Qafas ta 'dan il-qafas (magħruf ukoll bħala l-SP tal-qafas tas-sejħa) jirritorna l-SP ta' dan il-qafas.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x juża valur CFA preġudikat, għalhekk għandna bżonn nużaw_Unwind_GetGR biex inġibu r-reġistru tal-pointer tal-munzell (%r15) minflok ma niddependu fuq_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Fuq android u driegħ, il-funzjoni `_Unwind_GetIP` u mazz ta 'oħrajn huma macros, allura aħna niddefinixxu funzjonijiet li fihom l-espansjoni tal-macros.
    //
    //
    // TODO: link għall-header file li jiddefinixxi dawn il-macros, jekk tista 'ssibha.
    // (Jien, fitzgen, ma nistax insib il-fajl tal-intestatura li xi wħud minn dawn il-makro espansjonijiet oriġinarjament kienu mislufa minnhom.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 huwa l-pointer tal-munzell fuq id-driegħ.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Din il-funzjoni ma teżistix ukoll fuq Android jew ARM/Linux, allura għamilha no-op.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}