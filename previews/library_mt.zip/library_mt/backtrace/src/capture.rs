use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Rappreżentazzjoni ta 'traċċa ta' wara ta 'proprjetà u self-contained.
///
/// Din l-istruttura tista 'tintuża biex taqbad traċċa ta' wara f'diversi punti fi programm u aktar tard tintuża biex tispezzjona x'kienet it-traċċa ta 'wara f'dak iż-żmien.
///
///
/// `Backtrace` jappoġġja l-istampar pjuttost ta 'traċċi ta' wara permezz tal-implimentazzjoni `Debug` tiegħu.
///
/// # Karatteristiċi meħtieġa
///
/// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Il-gwarniċi hawn huma elenkati minn fuq għal isfel tal-munzell
    frames: Vec<BacktraceFrame>,
    // L-indiċi li nemmnu huwa l-bidu attwali tat-traċċa ta 'wara, billi tħalli barra frejms bħal `Backtrace::new` u `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Verżjoni maqbuda ta 'qafas f'tracktrace.
///
/// Dan it-tip jintbagħat lura bħala lista minn `Backtrace::frames` u jirrappreżenta qafas ta 'munzell wieħed f'traċċ ta' wara maqbud.
///
/// # Karatteristiċi meħtieġa
///
/// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Verżjoni maqbuda ta 'simbolu fi traċċa ta' wara.
///
/// Dan it-tip jintbagħat lura bħala lista minn `BacktraceFrame::symbols` u jirrappreżenta l-metadata għal simbolu fi traċċa ta 'wara.
///
/// # Karatteristiċi meħtieġa
///
/// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Jaqbad traċċa ta 'wara fis-sit tas-sejħa ta' din il-funzjoni, u jirritorna rappreżentazzjoni tal-proprjetà.
    ///
    /// Din il-funzjoni hija utli biex tirrappreżenta traċċa ta 'wara bħala oġġett f'Rust.Dan il-valur mibgħut lura jista 'jintbagħat fuq il-ħjut u jiġi stampat x'imkien ieħor, u l-għan ta' dan il-valur huwa li jkun kompletament awtonomu.
    ///
    /// Innota li fuq xi pjattaformi li jakkwistaw backtrace sħiħ u li jsolvuh jistgħu jkunu għaljin ħafna.
    /// Jekk l-ispiża hija wisq għall-applikazzjoni tiegħek huwa rrakkomandat li tuża `Backtrace::new_unresolved()` minflok li tevita l-pass tar-riżoluzzjoni tas-simbolu (li tipikament jieħu l-itwal) u jippermetti li tiġi differita għal data aktar tard.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // trid tkun żgur li hemm qafas hawn biex tneħħi
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Simili għal `new` ħlief li dan ma jsolvix xi simboli, dan sempliċement jaqbad it-traċċa ta 'wara bħala lista ta' indirizzi.
    ///
    /// Fi żmien aktar tard il-funzjoni `resolve` tista 'tissejjaħ biex issolvi s-simboli ta' din it-traċċa ta 'wara f'ismijiet li jistgħu jinqraw.
    /// Din il-funzjoni teżisti minħabba li l-proċess ta 'riżoluzzjoni kultant jista' jieħu ammont sinifikanti ta 'ħin filwaqt li kwalunkwe traċċa ta' wara waħda tista 'tiġi stampata rarament biss.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // l-ebda ismijiet ta 'simboli
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ismijiet tas-simboli issa preżenti
    /// ```
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    ///
    ///
    #[inline(never)] // trid tkun żgur li hemm qafas hawn biex tneħħi
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Jirritorna l-frejms minn meta nqabad din it-traċċa ta 'wara.
    ///
    /// L-ewwel dħul ta 'din il-porzjon x'aktarx il-funzjoni `Backtrace::new`, u l-aħħar qafas x'aktarx xi ħaġa dwar kif beda dan il-ħajt jew il-funzjoni ewlenija.
    ///
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Jekk din it-traċċa ta 'wara ġiet maħluqa minn `new_unresolved` allura din il-funzjoni ssolvi l-indirizzi kollha fit-traċċa ta' wara għall-ismijiet simboliċi tagħhom.
    ///
    ///
    /// Jekk din it-traċċa ta 'wara ġiet solvuta qabel jew inħolqot permezz ta' `new`, din il-funzjoni ma tagħmel xejn.
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// L-istess bħal `Frame::ip`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// L-istess bħal `Frame::symbol_address`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// L-istess bħal `Frame::module_base_address`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Jirritorna l-lista ta 'simboli li jikkorrispondi magħhom dan il-qafas.
    ///
    /// Normalment hemm simbolu wieħed biss għal kull qafas, imma xi kultant jekk numru ta 'funzjonijiet huma mdaħħlin f'qafas wieħed allura simboli multipli jiġu rritornati.
    /// L-ewwel simbolu elenkat huwa l-"innermost function", filwaqt li l-aħħar simbolu huwa l-iktar imbiegħed (l-aħħar sejjieħ).
    ///
    /// Innota li jekk dan il-qafas ġie minn traċċa ta 'wara mhux solvuta allura dan jirritorna lista vojta.
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// L-istess bħal `Symbol::name`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// L-istess bħal `Symbol::addr`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// L-istess bħal `Symbol::filename`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// L-istess bħal `Symbol::lineno`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// L-istess bħal `Symbol::colno`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Meta tipprintja mogħdijiet nippruvaw inqaxxru s-cwd jekk teżisti, inkella aħna nipprintjaw it-triq kif inhi.
        // Innota li aħna nagħmlu dan biss għall-format qasir, għax jekk huwa mimli aħna preżumibbilment irridu nipprintjaw kollox.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}