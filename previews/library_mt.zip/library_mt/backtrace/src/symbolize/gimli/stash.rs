// użat biss fuq Linux issa, allura ħalli kodiċi mejjet x'imkien ieħor
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Allokatur sempliċi tal-arena għall-buffers tal-byte.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Talloka buffer tad-daqs speċifikat u tirritorna referenza li tista 'tinbidel għaliha.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SIGURTÀ: din hija l-unika funzjoni li qatt tibni mutabbli
        // referenza għal `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SIGURTÀ: aħna qatt ma nneħħu elementi minn `self.buffers`, allura referenza
        // għad-dejta ġewwa kwalunkwe buffer jgħixu sakemm ma jaħdimx `self`.
        &mut buffers[i]
    }
}