//! Strateġija ta 'Simbolizzazzjoni bl-użu tal-kodiċi DWARF-parsing f'libbacktrace.
//!
//! Il-librerija libbacktrace C, tipikament imqassma ma 'gcc, tappoġġja mhux biss li tiġġenera backtrace (li ma nużawx fil-fatt) iżda wkoll tissimbolizza l-backtrace u timmaniġġa informazzjoni dwar debug dwar dwar affarijiet bħal frejms inlinjati u x'inhu.
//!
//!
//! Dan huwa relattivament ikkumplikat minħabba ħafna tħassib hawn, imma l-idea bażika hija:
//!
//! * L-ewwel insejħu `backtrace_syminfo`.Dan jirċievi informazzjoni dwar is-simboli mit-tabella tas-simboli dinamiċi jekk nistgħu.
//! * Sussegwentement insejħu `backtrace_pcinfo`.Dan se janalizza t-tabelli ta 'debuginfo jekk ikunu disponibbli u jippermettulna nirkupraw informazzjoni dwar inline frames, ismijiet ta' fajls, numri ta 'linji, eċċ.
//!
//! Hemm ħafna ingann dwar kif it-tabelli nanu jiddaħħlu fil-libbacktrace, imma nisperaw li mhuwiex it-tmiem tad-dinja u huwa ċar biżżejjed meta taqra hawn taħt.
//!
//! Din hija l-istrateġija ta 'simbolika awtomatika għal pjattaformi mhux MSVC u mhux OSX.Fil-libstd għalkemm din hija l-istrateġija awtomatika għal OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Jekk possibbli tippreferi l-isem `function` li ġej minn debuginfo u jista 'tipikament ikun iktar preċiż għal per eżempju inline frames.
                // Jekk dan mhux preżenti għalkemm erġa 'lura għall-isem tat-tabella tas-simboli speċifikat f `symname`.
                //
                // Innota li xi drabi `function` jista 'jħossu kemmxejn inqas preċiż, pereżempju li jkun elenkat bħala `try<i32,closure>` mhux qabel `std::panicking::try::do_call`.
                //
                // Mhux ċar għaliex, imma b'mod ġenerali l-isem `function` jidher aktar preċiż.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ma tagħmel xejn għalissa
}

/// Tip tal-pointer `data` mgħoddi għal `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Ladarba din is-sejħa lura tiġi invokata minn `backtrace_syminfo` meta nibdew insolvu immorru aktar 'il quddiem biex insejħu `backtrace_pcinfo`.
    // Il-funzjoni `backtrace_pcinfo` tikkonsulta informazzjoni ta 'debug u tipprova tagħmel affarijiet bħall-irkupru ta' informazzjoni file/line kif ukoll frejms inlinjati.
    // Innota għalkemm li `backtrace_pcinfo` jista 'jonqos jew ma jagħmilx ħafna jekk ma jkunx hemm informazzjoni ta' debug, allura jekk jiġri hekk aħna żgur li nsejħu l-callback b'mill-inqas simbolu wieħed mix-`syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tip tal-pointer `data` mgħoddi għal `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// L-API libbacktrace tappoġġja l-ħolqien ta 'stat, iżda ma tappoġġjax il-qerda ta' stat.
// Jien personalment nieħu dan li jfisser li stat huwa maħsub biex jinħoloq u mbagħad ngħix għal dejjem.
//
// Inħobb nirreġistra handler at_exit() li jnaddaf dan l-istat, iżda libbacktrace ma jipprovdix mod kif tagħmel dan.
//
// B'dawn il-limitazzjonijiet, din il-funzjoni għandha stat statikament fil-cache li huwa kkalkulat l-ewwel darba li din tintalab.
//
// Ftakar li r-rintraċċar kollu jiġri serjalment (serratura globali waħda).
//
// Innota n-nuqqas ta 'sinkronizzazzjoni hawn huwa dovut għar-rekwiżit li `resolve` huwa sinkronizzat esternament.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // M'għandekx teżerċita kapaċitajiet threadsafe ta 'libbacktrace peress li aħna dejjem insejħulu b'mod sinkronizzat.
        //
        0,
        error_cb,
        ptr::null_mut(), // l-ebda dejta żejda
    );

    return STATE;

    // Innota li biex libbacktrace jopera għal kollox jeħtieġ li jsib l-informazzjoni tad-debug tad-DWARF għall-eżekutibbli kurrenti.Tipikament tagħmel dan permezz ta 'numru ta' mekkaniżmi inklużi, iżda mhux limitati għal:
    //
    // * /proc/self/exe fuq pjattaformi appoġġjati
    // * L-isem tal-fajl għadda espliċitament meta ħoloq stat
    //
    // Il-librerija libbacktrace hija wad kbira ta 'kodiċi C.Dan ifisser naturalment li għandu vulnerabbiltajiet ta 'sigurtà tal-memorja, speċjalment meta timmaniġġja debuginfo ħażin.
    // Libstd iltaqa 'ma' ħafna minn dawn storikament.
    //
    // Jekk jintuża /proc/self/exe allura nistgħu tipikament ninjorawhom billi nassumu li libbacktrace huwa "mostly correct" u inkella ma jagħmilx affarijiet strambi b'informazzjoni ta 'debug dwarf "attempted to be correct".
    //
    //
    // Jekk ngħaddu f'isem il-fajl, madankollu, allura huwa possibbli fuq xi pjattaformi (bħal BSDs) fejn attur malizzjuż jista 'jikkawża li fajl arbitrarju jitqiegħed f'dak il-post.
    // Dan ifisser li jekk ngħidu lil libbacktrace dwar isem tal-fajl jista 'jkun li juża fajl arbitrarju, li possibbilment jikkawża segfaults.
    // Jekk ma ngħidu lil libbacktrace xejn għalkemm allura ma jagħmel xejn fuq pjattaformi li ma jappoġġjawx mogħdijiet bħal /proc/self/exe!
    //
    // Minħabba dak kollu li nippruvaw kemm jista 'jkun biex *ma* ngħaddux f'isem il-fajl, imma rridu fuq pjattaformi li ma jappoġġjaw xejn /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Innota li idealment aħna nużaw `std::env::current_exe`, imma ma nistgħux neħtieġu `std` hawn.
            //
            // Uża `_NSGetExecutablePath` biex tgħabbi l-passaġġ eżekutibbli kurrenti f'żona statika (li jekk tkun żgħira wisq ċedi biss).
            //
            //
            // Innota li aħna qed nafdaw serjament fil-libbacktrace hawn biex ma jmutux fuq eżekutibbli korrotti, imma żgur li hekk ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows għandu mod ta 'ftuħ ta' fajls fejn wara li jinfetaħ ma jistax jitħassar.
            // Dan huwa ġeneralment dak li rridu hawnhekk għaliex irridu niżguraw li l-eżekutibbli tagħna ma jinbidilx minn taħtna wara li ngħadduh lil libbacktrace, nisperaw li mmitigaw il-ħila li tgħaddi data arbitrarja għal libbacktrace (li jista 'jkun immaniġġjat ħażin).
            //
            //
            // Minħabba li nagħmlu daqsxejn ta 'żfin hawn biex nippruvaw niksbu tip ta' serratura fuq l-immaġni tagħna stess:
            //
            // * Ikseb manku għall-proċess kurrenti, għabbi l-isem tal-fajl tiegħu.
            // * Iftaħ fajl għal dak l-isem tal-fajl bil-bnadar it-tajba.
            // * Erġa 'kkarga l-isem tal-fajl tal-proċess kurrenti, u aċċerta ruħek li huwa l-istess
            //
            // Jekk dak kollu jgħaddi aħna fit-teorija tassew ftaħna l-fajl tal-proċess tagħna u aħna garantiti li ma jinbidilx.FWIW mazz ta 'dan huwa kkupjat mil-libstd storikament, allura din hija l-aħjar interpretazzjoni tiegħi ta' dak li kien qed jiġri.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Dan jgħix fil-memorja statika sabiex inkunu nistgħu nirritornawh ..
                static mut BUF: [i8; N] = [0; N];
                // ... u dan jgħix fuq il-munzell peress li huwa temporanju
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // intenzjonalment inixxi `handle` hawn għax li jkollok dak miftuħ għandu jippreserva s-serratura tagħna fuq dan l-isem tal-fajl.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Aħna rridu nirritornaw porzjon li huwa mitmum b'null, allura jekk kollox kien mimli u huwa daqs it-tul totali, allura dak ikun daqs il-falliment.
                //
                //
                // Inkella meta tirritorna s-suċċess kun żgur li n-nul byte huwa inkluż fis-slice.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // żbalji ta 'traċċi ta' wara huma attwalment miknusa taħt it-tapit
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Ċempel lill-API `backtrace_syminfo` li (mill-qari tal-kodiċi) għandu jsejjaħ `syminfo_cb` eżattament darba (jew ifalli bi żball preżumibbilment).
    // Imbagħad nittrattaw aktar fi ħdan ix-`syminfo_cb`.
    //
    // Innota li nagħmlu dan billi `syminfo` jikkonsulta t-tabella tas-simboli, u jsib ismijiet tas-simboli anke jekk m'hemm l-ebda informazzjoni ta 'debug fil-binarju.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}