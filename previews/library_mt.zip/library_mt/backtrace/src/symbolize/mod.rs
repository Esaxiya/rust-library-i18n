use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Issolvi indirizz għal simbolu, billi tgħaddi s-simbolu għall-għeluq speċifikat.
///
/// Din il-funzjoni tfittex l-indirizz mogħti f'oqsma bħat-tabella tas-simboli lokali, it-tabella tas-simboli dinamiċi, jew l-informazzjoni tad-debug tad-DWARF (skont l-implimentazzjoni attivata) biex issib simboli li tagħti.
///
///
/// L-għeluq jista 'ma jissejjaħx jekk ir-riżoluzzjoni ma tkunx tista' ssir, u jista 'jissejjaħ ukoll aktar minn darba fil-każ ta' funzjonijiet inlinjati.
///
/// Simboli mogħtija jirrappreżentaw l-eżekuzzjoni fix-`addr` speċifikat, u jirritornaw pari file/line għal dak l-indirizz (jekk disponibbli).
///
/// Innota li jekk għandek `Frame` allura huwa rrakkomandat li tuża l-funzjoni `resolve_frame` minflok din.
///
/// # Karatteristiċi meħtieġa
///
/// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
///
/// # Panics
///
/// Din il-funzjoni tistinka biex qatt ma panic, imma jekk ix-`cb` ipprovda panics allura xi pjattaformi jġiegħlu panic doppju biex jabbortixxi l-proċess.
/// Xi pjattaformi jużaw librerija C li internament tuża callbacks li ma jistgħux jinħallu, u għalhekk paniku minn `cb` jista 'jwassal għal proċess ta' abort.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // ħares biss lejn il-qafas ta 'fuq
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Irrisolvi qafas ta 'qbid preċedenti għal simbolu, billi tgħaddi s-simbolu għall-għeluq speċifikat.
///
/// Din il-funzjoni twettaq l-istess funzjoni bħal `resolve` ħlief li tieħu `Frame` bħala argument minflok indirizz.
/// Dan jista 'jippermetti xi implimentazzjonijiet ta' pjattaforma ta 'traċċar b'lura biex jipprovdu informazzjoni tas-simboli aktar preċiża jew informazzjoni dwar frejms inline pereżempju.
///
/// Huwa rrakkomandat li tuża dan jekk tista '.
///
/// # Karatteristiċi meħtieġa
///
/// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
///
/// # Panics
///
/// Din il-funzjoni tistinka biex qatt ma panic, imma jekk ix-`cb` ipprovda panics allura xi pjattaformi jġiegħlu panic doppju biex jabbortixxi l-proċess.
/// Xi pjattaformi jużaw librerija C li internament tuża callbacks li ma jistgħux jinħallu, u għalhekk paniku minn `cb` jista 'jwassal għal proċess ta' abort.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // ħares biss lejn il-qafas ta 'fuq
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Il-valuri IP minn frejms tal-munzelli huma tipikament (always?) l-istruzzjoni *wara* is-sejħa li hija t-traċċa attwali tal-munzell.
// Is-simbolu ta 'dan mixgħul jikkawża li n-numru filename/line ikun wieħed' il quddiem u forsi fil-vojt jekk ikun qrib it-tmiem tal-funzjoni.
//
// Dan jidher li bażikament dejjem ikun il-każ fuq il-pjattaformi kollha, allura aħna dejjem innaqqsu waħda minn ip riżolta biex insolvuha għall-istruzzjoni ta 'sejħa preċedenti minflok ma terġa' lura l-istruzzjoni.
//
//
// Idealment ma nagħmlux dan.
// Idealment nitolbu lil min iċempel l-APIs `resolve` hawn biex manwalment jagħmel ix--1 u jqis li jridu informazzjoni dwar il-post għall-istruzzjoni *preċedenti*, mhux dik attwali.
// Idealment aħna wkoll nikxfu fuq `Frame` jekk inkunu tabilħaqq l-indirizz tal-istruzzjoni li jmiss jew tal-kurrent.
//
// Għalissa għalkemm dan huwa tħassib pjuttost niċċa u għalhekk aħna biss internament innaqqsu wieħed.
// Il-konsumaturi għandhom jibqgħu jaħdmu u jiksbu riżultati pjuttost tajbin, allura għandna nkunu tajbin biżżejjed.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// L-istess bħal `resolve`, mhux sikur biss għax mhux sinkronizzat.
///
/// Din il-funzjoni m'għandhiex garanti ta 'sinkronizzazzjoni iżda hija disponibbli meta l-karatteristika `std` ta' dan iż-crate ma tkunx ikkumpilata fih.
/// Ara l-funzjoni `resolve` għal aktar dokumentazzjoni u eżempji.
///
/// # Panics
///
/// Ara l-informazzjoni dwar `resolve` għal twissijiet dwar paniku ta `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// L-istess bħal `resolve_frame`, mhux sikur biss għax mhux sinkronizzat.
///
/// Din il-funzjoni m'għandhiex garanti ta 'sinkronizzazzjoni iżda hija disponibbli meta l-karatteristika `std` ta' dan iż-crate ma tkunx ikkumpilata fih.
/// Ara l-funzjoni `resolve_frame` għal aktar dokumentazzjoni u eżempji.
///
/// # Panics
///
/// Ara l-informazzjoni dwar `resolve_frame` għal twissijiet dwar paniku ta `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// A trait li tirrappreżenta r-riżoluzzjoni ta 'simbolu f'fajl.
///
/// Dan trait jingħata bħala oġġett trait għall-għeluq mogħti lill-funzjoni `backtrace::resolve`, u huwa virtwalment mibgħut peress li mhux magħruf liema implimentazzjoni hemm warajh.
///
///
/// Simbolu jista 'jagħti informazzjoni kuntestwali dwar funzjoni, pereżempju l-isem, l-isem tal-fajl, in-numru tal-linja, l-indirizz preċiż, eċċ.
/// Mhux l-informazzjoni kollha hija dejjem disponibbli f`simbolu, madankollu, għalhekk il-metodi kollha jirritornaw `Option`.
///
///
pub struct Symbol {
    // TODO: din il-ħajja marbuta teħtieġ li tiġi ppersistuta eventwalment sa `Symbol`,
    // imma dik bħalissa hija bidla li tkisser.
    // Għalissa dan huwa sigur peress li `Symbol` huwa biss imqassam biss b'referenza u ma jistax jiġi kklonat.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Jirritorna l-isem ta 'din il-funzjoni.
    ///
    /// L-istruttura rritornata tista 'tintuża biex tfittex diversi proprjetajiet dwar l-isem tas-simbolu:
    ///
    ///
    /// * L-implimentazzjoni `Display` se tipprintja s-simbolu demangled.
    /// * Il-valur mhux maħdum `str` tas-simbolu jista 'jiġi aċċessat (jekk huwa validu utf-8).
    /// * Il-bytes mhux ipproċessati għall-isem tas-simbolu jistgħu jiġu aċċessati.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Jirritorna l-indirizz tal-bidu ta 'din il-funzjoni.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Jirritorna l-isem tal-fajl nej bħala porzjon.
    /// Dan huwa prinċipalment utli għal ambjenti `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Jirritorna n-numru tal-kolonna għal fejn dan is-simbolu bħalissa qed jeżegwixxi.
    ///
    /// Gimli biss bħalissa jipprovdi valur hawn u anke dakinhar biss jekk `filename` jirritorna `Some`, u allura huwa konsegwentement soġġett għal twissijiet simili.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Jirritorna n-numru tal-linja għal fejn bħalissa qed jesegwixxi dan is-simbolu.
    ///
    /// Dan il-valur ta 'ritorn huwa tipikament `Some` jekk `filename` jirritorna `Some`, u konsegwentement huwa suġġett għal twissijiet simili.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Jirritorna l-isem tal-fajl fejn ġiet definita din il-funzjoni.
    ///
    /// Dan bħalissa huwa disponibbli biss meta jkun qed jintuża libbacktrace jew gimli (eż
    /// unix pjattaformi oħra) u meta binarju huwa kkumpilat ma 'debuginfo.
    /// Jekk l-ebda waħda minn dawn il-kundizzjonijiet ma tkun sodisfatta allura dan x'aktarx jerġa 'jagħti `None`
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Forsi simbolu C++ analizzat, jekk ifalli l-analiżi tas-simbolu mangled bħala Rust.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Kun żgur li żżomm dan ta 'daqs żero, sabiex il-karatteristika `cpp_demangle` ma jkollha l-ebda spiża meta tkun diżattivata.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Tgeżwir madwar isem ta 'simbolu biex tipprovdi aċċessorji ergonomiċi għall-isem imħallat, il-bytes mhux maħduma, is-sekwenza prima, eċċ.
///
// Ħalli kodiċi mejjet għal meta l-karatteristika `cpp_demangle` mhix attivata.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Joħloq isem ta 'simbolu ġdid mill-bytes sottostanti mhux ipproċessati.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Jirritorna l-isem mhux ipproċessat tas-simbolu (mangled) bħala `str` jekk is-simbolu huwa utf-8 validu.
    ///
    /// Uża l-implimentazzjoni `Display` jekk trid il-verżjoni demangled.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Jirritorna l-isem tas-simbolu mhux ipproċessat bħala lista ta 'bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dan jista 'jistampa jekk is-simbolu demangled mhuwiex fil-fatt validu, allura mmaniġġja l-iżball hawnhekk b'mod grazzjuż billi ma txerridx' il barra.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Ipprova titlob lura dik il-memorja fil-cache użata biex tissimbolizza l-indirizzi.
///
/// Dan il-metodu se jipprova jirrilaxxa kwalunkwe struttura ta 'dejta globali li altrimenti ġiet maħżuna globalment jew fil-ħajta li tipikament tirrappreżenta informazzjoni DWARF analizzata jew simili.
///
///
/// # Caveats
///
/// Filwaqt li din il-funzjoni hija dejjem disponibbli fil-fatt ma tagħmel xejn fuq ħafna mill-implimentazzjonijiet.
/// Libreriji bħal dbghelp jew libbacktrace ma jipprovdux faċilitajiet biex iqassmu l-istat u jamministraw il-memorja allokata.
/// Għalissa l-karatteristika `gimli-symbolize` ta 'dan crate hija l-unika karatteristika fejn din il-funzjoni għandha xi effett.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}