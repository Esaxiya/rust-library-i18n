#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Formattur għal traċċi ta 'wara.
///
/// Dan it-tip jista 'jintuża biex jistampa traċċa ta' wara irrispettivament minn minn fejn tiġi t-traċċa ta 'wara nnifisha.
/// Jekk għandek tip `Backtrace` allura l-implimentazzjoni `Debug` tagħha diġà tuża dan il-format tal-istampar.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// L-istili ta 'stampar li nistgħu nipprintjaw
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Stampa traċċa ta 'wara ta' terser li idealment fiha biss informazzjoni rilevanti
    Short,
    /// Stampa traċċa ta 'wara li fiha l-informazzjoni kollha possibbli
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Oħloq `BacktraceFmt` ġdid li se jikteb output fuq ix-`fmt` provdut.
    ///
    /// L-argument `format` jikkontrolla l-istil li fih jiġi stampat it-traċċa ta 'wara, u l-argument `print_path` jintuża biex jistampa l-istanzi `BytesOrWideString` ta' ismijiet ta 'fajls.
    /// Dan it-tip innifsu ma jagħmel l-ebda stampar ta 'ismijiet ta' fajls, iżda din is-sejħa lura hija meħtieġa biex tagħmel dan.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Jistampa preambolu għat-traċċa ta 'wara li se tiġi stampata.
    ///
    /// Dan huwa meħtieġ fuq xi pjattaformi biex it-traċċi ta 'wara jiġu simbolizzati kompletament aktar tard, u inkella dan għandu jkun biss l-ewwel metodu li ċċempel wara li toħloq `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Iżżid qafas mal-ħruġ ta 'traċċa ta' wara.
    ///
    /// Dan l-impenn jirritorna istanza RAII ta `BacktraceFrameFmt` li tista' tintuża biex fil-fatt tipprintja qafas, u mal-qerda se żżid il-counter tal-qafas.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Tlesti l-output tal-backtrace.
    ///
    /// Dan bħalissa huwa no-op iżda huwa miżjud għall-kompatibilità future ma 'formati ta' traċċi ta 'wara.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Bħalissa bla op-inkluż dan hook biex jippermetti żidiet ta 'future.
        Ok(())
    }
}

/// Formattur għal frejm wieħed biss ta 'traċċa ta' wara.
///
/// Dan it-tip huwa maħluq mill-funzjoni `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Stampa `BacktraceFrame` b'dan il-format tal-qafas.
    ///
    /// Dan se jistampa b'mod rikursiv l-istanzi `BacktraceSymbol` kollha fi ħdan ix-`BacktraceFrame`.
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Stampa `BacktraceSymbol` fi `BacktraceFrame`.
    ///
    /// # Karatteristiċi meħtieġa
    ///
    /// Din il-funzjoni teħtieġ li l-karatteristika `std` tax-`backtrace` crate tkun attivata, u l-karatteristika `std` hija attivata awtomatikament.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: dan mhux tajjeb li ma nispiċċaw nistampaw xejn
            // b'ismijiet ta 'fajls mhux utf8.
            // B'xorti tajba kważi kollox huwa utf8 u għalhekk dan m'għandux ikun ħażin wisq.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Stampa `Frame` u `Symbol` traċċati mhux ipproċessati, tipikament minn ġewwa l-callbacks mhux ipproċessati ta 'dan crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Iżżid qafas mhux maħdum mal-ħruġ ta 'traċċa ta' wara.
    ///
    /// Dan il-metodu, b'differenza minn dak ta 'qabel, jieħu l-argumenti mhux ipproċessati f'każ li jkunu qed jiġu minn sorsi differenti.
    /// Innota li dan jista 'jissejjaħ bosta drabi għal qafas wieħed.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Iżżid qafas mhux maħdum mal-ħruġ ta 'traċċa ta' wara, inkluża informazzjoni dwar il-kolonna.
    ///
    /// Dan il-metodu, bħal dak ta 'qabel, jieħu l-argumenti mhux ipproċessati f'każ li jkunu qed jiġu minn sorsi differenti.
    /// Innota li dan jista 'jissejjaħ bosta drabi għal qafas wieħed.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia ma jistax jissimbolizza fi proċess u għalhekk għandu format speċjali li jista 'jintuża biex jissimbolizza aktar tard.
        // Stampa dak minflok tistampa indirizzi fil-format tagħna stess hawn.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // M`hemmx għalfejn tipprintja frejms "null", bażikament ifisser biss li s-sistema ta`traċċa b`lura kienet kemmxejn ħerqana li tiġi rintraċċata lura` l bogħod.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Biex tnaqqas id-daqs tat-TCB fl-enklavi Sgx, ma rridux nimplimentaw il-funzjonalità tar-riżoluzzjoni tas-simboli.
        // Pjuttost, nistgħu nistampaw l-offset tal-indirizz hawnhekk, li jista 'jiġi mmappjat aktar tard biex jikkoreġi l-funzjoni.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Stampa l-indiċi tal-qafas kif ukoll il-pointer tal-istruzzjoni mhux obbligatorju tal-qafas.
        // Jekk inkunu lil hinn mill-ewwel simbolu ta 'dan il-qafas għalkemm aħna biss nipprintjaw spazji xierqa.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Sussegwentement ikteb l-isem tas-simbolu, billi tuża l-ifformattjar alternattiv għal aktar informazzjoni jekk inkunu backtrace sħiħ.
        // Hawnhekk nittrattaw ukoll simboli li m'għandhomx isem,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // U fl-aħħar, ipprintja n-numru filename/line jekk ikunu disponibbli.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line huma stampati fuq linji taħt l-isem tas-simbolu, għalhekk ipprintja ftit spazju xieraq biex issolvi lilna nfusna fuq il-lemin.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Iddelega għas-sejħa lura interna tagħna biex tipprintja l-isem tal-fajl u mbagħad ipprintja n-numru tal-linja.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Żid in-numru tal-kolonna, jekk disponibbli.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Aħna biss jimpurtahom mill-ewwel simbolu ta 'qafas
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}