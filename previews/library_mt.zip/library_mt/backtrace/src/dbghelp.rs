//! Modulu biex jgħin fil-ġestjoni tal-irbit tad-dbghelp fuq Windows
//!
//! It-traċċi ta 'wara fuq Windows (għall-inqas għal MSVC) huma mħaddma fil-biċċa l-kbira permezz ta' `dbghelp.dll` u l-funzjonijiet varji li fih.
//! Dawn il-funzjonijiet bħalissa huma mgħobbija *b'mod dinamiku* aktar milli jgħaqqdu ma `dbghelp.dll` b'mod statiku.
//! Dan bħalissa jsir mil-librerija standard (u fit-teorija huwa meħtieġ hemmhekk), iżda huwa sforz biex jgħin fit-tnaqqis tad-dipendenzi statiċi tad-dll ta 'librerija peress li t-traċċi ta' wara huma tipikament pjuttost fakultattivi.
//!
//! Dak kollu li ntqal, `dbghelp.dll` kważi dejjem jgħabbi b'suċċess fuq Windows.
//!
//! Innota għalkemm li ladarba qed nitgħabbew dan l-appoġġ kollu b'mod dinamiku ma nistgħux attwalment nużaw id-definizzjonijiet mhux ipproċessati f `winapi`, iżda pjuttost għandna bżonn niddefinixxu t-tipi ta 'pointer tal-funzjoni aħna stess u nużaw dak.
//! Ma rridux verament li nkunu fin-negozju li niddupplikaw winapi, allura għandna karatteristika Cargo `verify-winapi` li tafferma li l-irbit kollu jaqbel ma 'dawk fil-winapi u din il-karatteristika hija attivata fuq CI.
//!
//! Fl-aħħarnett, tinnota hawn li d-dll għal `dbghelp.dll` qatt ma jinħatt, u bħalissa dan huwa intenzjonat.
//! Il-ħsieb huwa li nistgħu nagħmlu cache globalment u nużawha bejn sejħiet għall-API, u nevitaw loads/unloads għalja.
//! Jekk din hija problema għad-ditekters tat-tnixxija jew xi ħaġa bħal dik nistgħu naqsmu l-pont meta naslu hemm.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Aħdem madwar `SymGetOptions` u `SymSetOptions` ma tkunx preżenti fil-winapi stess.
// Inkella dan jintuża biss meta nkunu qed nivverifikaw it-tipi kontra winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Għadu mhux definit fil-winapi
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Dan huwa definit fil-winapi, iżda mhux korrett (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Għadu mhux definit fil-winapi
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Din il-makro tintuża biex tiddefinixxi struttura `Dbghelp` li internament fiha l-indikaturi tal-funzjoni kollha li nistgħu nitgħabbew.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Id-DLL mgħobbi għal `dbghelp.dll`
            dll: HMODULE,

            // Kull pointer tal-funzjoni għal kull funzjoni li nistgħu nużaw
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Inizjalment aħna ma għabbiex id-DLL
            dll: 0 as *mut _,
            // Inizjalment il-funzjonijiet kollha huma ssettjati fuq żero biex jgħidu li għandhom bżonn ikunu mgħobbija b'mod dinamiku.
            //
            $($name: 0,)*
        };

        // Tip ta 'konvenjenza għal kull tip ta' funzjoni.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Tentattivi biex tiftaħ `dbghelp.dll`.
            /// Jirritorna s-suċċess jekk jaħdem jew jiżbalja jekk `LoadLibraryW` ifalli.
            ///
            /// Panics jekk il-librerija hija diġà mgħobbija.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funzjoni għal kull metodu li nixtiequ nużaw.
            // Meta jissejjaħ jew jaqra l-pointer tal-funzjoni fil-cache jew jgħabbih u jirritorna l-valur mgħobbi.
            // Tagħbijiet huma affermati biex jirnexxu.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Konvenjenza prokura biex tuża s-serraturi tat-tindif biex tirreferi għall-funzjonijiet tad-dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inizjalizza l-appoġġ kollu meħtieġ biex taċċessa l-funzjonijiet `dbghelp` API minn dan crate.
///
///
/// Innota li din il-funzjoni hija **sigura**, internament għandha s-sinkronizzazzjoni tagħha stess.
/// Innota wkoll li huwa sigur li tissejjaħ din il-funzjoni bosta drabi b'mod rikursiv.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // L-ewwel ħaġa li għandna nagħmlu hija li tissinkronizza din il-funzjoni.Dan jista 'jissejjaħ fl-istess ħin minn ħjut oħra jew rikursivament fi ħjut waħda.
        // Innota li huwa iktar diffiċli minn dak għalkemm għax dak li qed nużaw hawnhekk, `dbghelp`,*ukoll* jeħtieġ li jkun sinkronizzat mas-sejħiet l-oħra kollha għal `dbghelp` f'dan il-proċess.
        //
        // Tipikament m'hemmx verament daqshekk sejħiet lil `dbghelp` fl-istess proċess u probabbilment nistgħu nassumu b'mod sikur li aħna l-uniċi li qed nidħlu għaliha.
        // Hemm, madankollu, utent primarju ieħor li rridu ninkwetaw dwar dak li ironikament aħna nfusna, imma fil-librerija standard.
        // Il-librerija standard Rust tiddependi fuq dan crate għall-appoġġ ta 'backtrace, u dan crate jeżisti wkoll fuq crates.io.
        // Dan ifisser li jekk il-librerija standard qed tipprintja traċċa ta 'wara panic tista' tiġri b'dan iż-crate ġej minn crates.io, u tikkawża segfaults.
        //
        // Biex ngħinu nsolvu din il-problema ta 'sinkronizzazzjoni aħna nimpjegaw trick speċifiku għall-Windows hawn (wara kollox, huwa restrizzjoni speċifika għall-Windows dwar is-sinkronizzazzjoni).
        // Aħna noħolqu *session-local* bl-isem mutex biex nipproteġu din is-sejħa.
        // L-intenzjoni hawnhekk hija li l-librerija standard u dan iż-crate m'għandhomx għalfejn jaqsmu l-APIs tal-livell Rust biex jissinkronizzaw hawn imma minflok jistgħu jaħdmu wara l-kwinti biex jiġi żgurat li qed jissinkronizzaw ma 'xulxin.
        //
        // B'dan il-mod meta din il-funzjoni tissejjaħ permezz tal-librerija standard jew permezz ta crates.io nistgħu nkunu ċerti li l-istess mutex qed jiġi akkwistat.
        //
        // Allura dan kollu jfisser li l-ewwel ħaġa li nagħmlu hawnhekk hija li atomikament noħolqu `HANDLE` li huwa mutex bl-isem fuq Windows.
        // Aħna nissinkronizzaw daqsxejn ma 'ħjut oħra li jaqsmu din il-funzjoni speċifikament u niżguraw li jinħoloq manku wieħed biss għal kull istanza ta' din il-funzjoni.
        // Innota li l-manku qatt ma jingħalaq ladarba jinħażen fil-global.
        //
        // Wara li fil-fatt immorru s-serratura sempliċement nakkwistawh, u l-manku `Init` tagħna li nqassmu jkun responsabbli biex eventwalment inwaqqgħuh.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Issa li aħna lkoll sinkronizzati b'mod sikur, ejja fil-fatt nibdew nipproċessaw kollox.
        // L-ewwelnett irridu niżguraw li `dbghelp.dll` huwa attwalment mgħobbi f'dan il-proċess.
        // Aħna nagħmlu dan b'mod dinamiku biex nevitaw dipendenza statika.
        // Dan storikament sar biex jaħdem madwar kwistjonijiet ta 'konnessjoni strambi u huwa maħsub biex jagħmel il-binarji daqsxejn aktar portabbli peress li din hija fil-biċċa l-kbira biss utilità ta' debugging.
        //
        //
        // Ladarba niftħu `dbghelp.dll` għandna bżonn insejħu xi funzjonijiet ta 'inizjalizzazzjoni fih, u dan huwa ddettaljat aktar hawn taħt.
        // Aħna nagħmlu dan darba biss, għalkemm, allura għandna boolean globali li jindika jekk għadniex jew le.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Kun żgur li l-bandiera `SYMOPT_DEFERRED_LOADS` hija ssettjata, għax skont id-dokumenti tal-MSVC stess dwar dan: "This is the fastest, most efficient way to use the symbol handler.", allura ejja nagħmlu hekk!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Attwalment ibda s-simboli bl-MSVC.Innota li dan jista 'jfalli, imma aħna ninjorawh.
        // M'hemmx tunnellata ta 'arti preċedenti għal dan fih innifsu, iżda LLVM internament jidher li jinjora l-valur ta' ritorn hawn u waħda mill-libreriji ta 'sanitizer f'LVM tipprintja twissija tal-biża' jekk dan ifalli iżda bażikament jinjoraha fit-tul.
        //
        //
        // Każ wieħed dan joħroġ ħafna għal Rust huwa li l-librerija standard u dan iż-crate fuq crates.io it-tnejn iridu jikkompetu għal `SymInitializeW`.
        // Il-librerija standard storikament riedet tinizjalizza imbagħad tindif il-biċċa l-kbira tal-ħin, iżda issa li qed tuża dan iż-crate tfisser li xi ħadd jasal għall-inizjalizzazzjoni l-ewwel u l-ieħor jieħu dik l-inizjalizzazzjoni.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}