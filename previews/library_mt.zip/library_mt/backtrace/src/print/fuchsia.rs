use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr jieħu callback li jirċievi pointer dl_phdr_info għal kull DSO li ġie marbut fil-proċess.
    // dl_iterate_phdr jiżgura wkoll li l-linker dinamiku huwa msakkar mill-bidu sat-tmiem tal-iterazzjoni.
    // Jekk il-callback jirritorna valur mhux żero l-iterazzjoni tintemm kmieni.
    // 'data' se jgħaddi bħala t-tielet argument għas-sejħa lura fuq kull sejħa.
    // 'size' jagħti d-daqs tad-dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Għandna bżonn inqisu l-ID tal-bini u xi dejta bażika tal-header tal-programm li tfisser li għandna bżonn daqsxejn ta 'affarijiet mill-ispeċifikazzjoni tal-ELF ukoll.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Issa rridu nirreplikaw, bit għal bit, l-istruttura tat-tip dl_phdr_info użata mill-linker dinamiku attwali tal-fuchsia.
// Chromium għandu wkoll dan il-limitu ABI kif ukoll crashpad.
// Eventwalment nixtiequ nimxu dawn il-każijiet biex nużaw elf-search imma jkollna bżonn nipprovdu dak fl-SDK u dak għadu ma sarx.
//
// Għalhekk aħna (u huma) aħna mdendlin wara li nużaw dan il-metodu li jeħel akkoppjament strett mal-fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // M'għandniex mod kif nafu li niċċekkjaw jekk e_phoff u e_phnum humiex validi.
    // libc għandu jiżgura dan għalina madankollu għalhekk huwa sikur li tifforma porzjon hawn.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr jirrappreżenta header tal-programm ELF 64-bit fl-endianness tal-arkitettura fil-mira.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr jirrappreżenta header tal-programm ELF validu u l-kontenut tiegħu.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // M'għandniex mod kif niċċekkjaw jekk p_addr jew p_memsz humiex validi.
    // Il-libc ta 'Fuchsia jeżamina n-noti l-ewwel madankollu għalhekk minħabba li jkunu hawn dawn l-intestaturi għandhom ikunu validi.
    //
    // NoteIter ma jeħtieġx li d-dejta sottostanti tkun valida iżda teħtieġ li l-limiti jkunu validi.
    // Aħna nafdaw li l-libc żgura li dan huwa l-każ għalina hawn.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// It-tip ta 'nota għall-IDs tal-bini.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr jirrappreżenta header ta 'nota ELF fl-endianness tal-mira.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Nota tirrappreżenta nota ELF (header + kontenut).
// L-isem jitħalla bħala porzjon u8 minħabba li mhux dejjem huwa terminat null u rust jagħmilha faċli biżżejjed biex tivverifika li l-bytes jaqblu xorta waħda.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter ihallik iterat b'mod sigur fuq segment ta 'nota.
// Tispiċċa hekk kif iseħħ żball jew ma jkunx hemm aktar noti.
// Jekk ttenni fuq dejta invalida tiffunzjona bħallikieku ma nstabu l-ebda noti.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Huwa invariant ta 'funzjoni li l-pointer u d-daqs mogħti jindikaw firxa valida ta' bytes li kollha jistgħu jinqraw.
    // Il-kontenut ta 'dawn il-bytes jista' jkun kwalunkwe ħaġa imma l-firxa trid tkun valida biex dan ikun sigur.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to talline 'x' to 'to'-byte alignment assuming 'to' is a power of 2.
// Dan isegwi mudell standard f'C/C ++ ELF parsing code fejn (x + sa, 1)&-to jintużaw.
// Rust ma jħallikx tiċħad l-użu u allura nuża
// Konverżjoni ta '2's-complement biex terġa' tinħoloq dik.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 jikkonsma num bytes mill-porzjon (jekk preżenti) u barra minn hekk jiżgura li l-porzjon finali huwa allinjat sewwa.
// Jekk jew in-numru ta 'bytes mitluba huwa kbir wisq jew il-porzjon ma jistax jiġi riallinjat wara wara li ma jeżistux biżżejjed bytes li jifdal, Xejn ma jingħata lura u l-porzjon ma jiġix modifikat.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Din il-funzjoni m'għandha l-ebda invariants reali li s-sejjieħ irid isostni għajr forsi li 'bytes' għandu jkun allinjat għall-prestazzjoni (u fuq xi arkitetturi korrettezza).
// Il-valuri fl-oqsma Elf_Nhdr jistgħu jkunu bla sens imma din il-funzjoni ma tiżgura l-ebda ħaġa bħal din.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dan huwa sigur sakemm hemm biżżejjed spazju u għadna kemm ikkonfermajna li fl-istqarrija if hawn fuq allura dan m'għandux ikun perikoluż.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Innota li sice_of: :<Elf_Nhdr>() huwa dejjem allinjat b'4 bytes.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Iċċekkja jekk wasalniex fl-aħħar.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Aħna nbiddlu nhdr iżda nikkunsidraw bir-reqqa l-istruttura li tirriżulta.
        // Aħna ma nafdawx l-namesz jew descsz u ma nieħdu l-ebda deċiżjoni mhux sigura bbażata fuq it-tip.
        //
        // Allura anke jekk noħorġu żibel komplet xorta għandna nkunu sikuri.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Tindika li segment huwa eżegwibbli.
const PERM_X: u32 = 0b00000001;
/// Tindika li segment jista 'jinkiteb.
const PERM_W: u32 = 0b00000010;
/// Tindika li segment jinqara.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Tirrappreżenta segment ELF fil-ħin tal-eżekuzzjoni.
struct Segment {
    /// Jagħti l-indirizz virtwali tal-eżekuzzjoni tal-kontenut ta 'dan is-segment.
    addr: usize,
    /// Jagħti d-daqs tal-memorja tal-kontenut ta 'dan is-segment.
    size: usize,
    /// Jagħti l-indirizz virtwali tal-modulu ta 'dan is-segment bil-fajl ELF.
    mod_rel_addr: usize,
    /// Jagħti l-permessi misjuba fil-fajl ELF.
    /// Dawn il-permessi mhumiex neċessarjament il-permessi preżenti waqt l-eżekuzzjoni madankollu.
    flags: Perm,
}

/// Tikri iterazzjoni waħda fuq Segmenti minn DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Tirrappreżenta ELF DSO (Dynamic Shared Object).
/// Dan it-tip jirreferi għad-dejta maħżuna fid-DSO attwali aktar milli jagħmel il-kopja tiegħu stess.
struct Dso<'a> {
    /// Il-linker dinamiku dejjem jagħtina isem, anke jekk l-isem huwa vojt.
    /// Fil-każ tal-eżekutibbli ewlieni dan l-isem ikun vojt.
    /// Fil-każ ta 'oġġett maqsum ikun l-soname (ara DT_SONAME).
    name: &'a str,
    /// Fuq Fuchsia prattikament il-binarji kollha għandhom IDs tal-bini iżda dan mhux rekwiżit strett.
    /// M'hemm l-ebda mod kif tqabbel l-informazzjoni DSO ma 'fajl ELF reali wara jekk m'hemm l-ebda build_id u għalhekk neħtieġu li kull DSO jkollu waħda hawn.
    ///
    /// DSOs mingħajr build_id huma injorati.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Jirritorna iteratur fuq Segmenti f'dan id-DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Dawn l-iżbalji jikkodifikaw kwistjonijiet li jinqalgħu waqt li tiġi analizzata l-informazzjoni dwar kull DSO.
///
enum Error {
    /// NameError ifisser li seħħ żball waqt li kkonvertiet sekwenza ta 'stil Ċ f'serje rust.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError ifisser li ma sibniex ID tal-bini.
    /// Dan jista 'jkun jew minħabba li d-DSO ma kellux build ID jew minħabba li s-segment li fih l-ID tal-build kien iffurmat ħażin.
    ///
    BuildIDError,
}

/// Jitlob jew 'dso' jew 'error' għal kull DSO marbut fil-proċess mill-linker dinamiku.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter li se jkollu wieħed mill-metodi tal-ikel imsejjaħ għal kull DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr jiżgura li info.name se jindika post validu.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Din il-funzjoni tipprintja l-markup tas-simbolu Fuchsia għall-informazzjoni kollha li tinsab fid-DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}