# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Librerija għall-akkwist ta 'backtraces fil-ħin tal-eżekuzzjoni għal Rust.
Din il-librerija għandha l-għan li ttejjeb l-appoġġ tal-librerija standard billi tipprovdi interface programmatiku biex taħdem magħha, iżda tappoġġja wkoll sempliċement l-istampar tat-traċċa ta 'wara kurrenti bħal panics ta' libstd.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Biex sempliċement taqbad traċċa ta 'wara u tiddifferixxi t-trattament tagħha sa żmien aktar tard, tista' tuża t-tip `Backtrace` tal-ogħla livell.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Jekk, madankollu, tixtieq iktar aċċess mhux ipproċessat għall-funzjonalità attwali tat-traċċar, tista 'tuża l-funzjonijiet `trace` u `resolve` direttament.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Irrisolvi din l-istruzzjoni pointer għal isem ta 'simbolu
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // kompli għaddej għall-qafas li jmiss
    });
}
```

# License

Dan il-proġett huwa liċenzjat taħt kwalunkwe wieħed

 * Liċenzja Apache, Verżjoni 2.0, ([LICENSE-APACHE](LICENSE-APACHE) jew http://www.apache.org/licenses/LICENSE-2.0)
 * Liċenzja MIT ([LICENSE-MIT](LICENSE-MIT) jew http://opensource.org/licenses/MIT)

fuq l-għażla tiegħek.

### Contribution

Sakemm ma tiddikjarax b'mod espliċitu mod ieħor, kwalunkwe kontribuzzjoni sottomessa intenzjonalment għal inklużjoni fil-backtrace-rs minnek, kif definit fil-liċenzja Apache-2.0, għandha tkun liċenzjata doppja bħal hawn fuq, mingħajr ebda termini jew kondizzjonijiet addizzjonali.







