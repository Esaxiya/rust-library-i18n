#![stable(feature = "wake_trait", since = "1.51.0")]
//! Tipi u Traits biex taħdem ma 'kompiti mhux sinkroniċi.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// L-implimentazzjoni li tqajjem kompitu fuq eżekutur.
///
/// Dan trait jista 'jintuża biex jinħoloq [`Waker`].
/// Eżekutur jista 'jiddefinixxi implimentazzjoni ta' dan trait, u juża dak biex jibni Waker biex jgħaddi għall-kompiti li huma eżegwiti fuq dak l-eżekutur.
///
/// Dan trait huwa alternattiva ergonomika u sigura għall-memorja għall-kostruzzjoni ta [`RawWaker`].
/// Huwa jappoġġa d-disinn tal-eżekutur komuni li fih id-dejta użata biex tqajjem kompitu tkun maħżuna f [`Arc`].
/// Xi eżekuturi (speċjalment dawk għal sistemi inkorporati) ma jistgħux jużaw din l-API, u huwa għalhekk li [`RawWaker`] jeżisti bħala alternattiva għal dawk is-sistemi.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Funzjoni bażika `block_on` li tieħu future u tmexxiha sat-tlestija fuq il-ħajta attwali.
///
/// **Note:** Dan l-eżempju jinnegozja l-korrettezza għas-sempliċità.
/// Sabiex jiġu evitati l-imblukkar, l-implimentazzjonijiet ta 'grad ta' produzzjoni jkunu jeħtieġu wkoll li jimmaniġġjaw sejħiet intermedji għal `thread::unpark` kif ukoll invokazzjonijiet imbejta.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker li jqajjem il-ħajta attwali meta jissejjaħ.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Mexxi future sat-tlestija fuq il-ħajta attwali.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pin il-future sabiex tkun tista 'ssir stħarriġ.
///     let mut fut = Box::pin(fut);
///
///     // Oħloq kuntest ġdid biex jgħaddih lil future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Mexxi ż-future sat-tlestija.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Qajjem dan ix-xogħol.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Qajjem din il-biċċa xogħol mingħajr ma tikkonsma lill-waker.
    ///
    /// Jekk eżekutur jappoġġja mod orħos biex iqajjem mingħajr ma jikkonsma l-waker, għandu jwarrab dan il-metodu.
    /// B'default, huwa kloni tax-[`Arc`] u jsejjaħ [`wake`] fuq il-klonu.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SIGURTÀ: Dan huwa sigur għax raw_waker jibni b'mod sikur
        // RawWaker minn Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Din il-funzjoni privata għall-kostruzzjoni ta 'RawWaker tintuża, aktar milli
// billi tiddaħħal dan fl-impl `From<Arc<W>> for RawWaker`, biex tiżgura li s-sigurtà ta `From<Arc<W>> for Waker` ma tiddependix fuq id-dispaċċ korrett ta' trait, minflok iż-żewġ impls isejħu din il-funzjoni direttament u b'mod espliċitu.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Żid l-għadd ta 'referenza tal-ark biex tikklonah.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Qajjem skond il-valur, billi ċċaqlaq l-Ark fil-funzjoni Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Wake b'referenza, wrap the waker in ManuallyDrop biex tevita li twaqqa '
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Iddetermina l-għadd ta 'referenza ta' l-Ark mal-waqgħa
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}