//! Spag ikkodifikat, ikkodifikat UTF-8.
//!
//! Dan il-modulu fih it-tip [`String`], ix-[`ToString`] trait għall-konverżjoni għal kordi, u diversi tipi ta 'żbalji li jistgħu jirriżultaw mix-xogħol ma' [`String`] s.
//!
//!
//! # Examples
//!
//! Hemm modi multipli biex toħloq [`String`] ġdid minn sekwenza litterali:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Tista 'toħloq [`String`] ġdid minn wieħed eżistenti billi tikkonkatenana ma'
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Jekk għandek vector ta 'bytes UTF-8 validi, tista' tagħmel [`String`] minnha.Tista 'tagħmel il-maqlub ukoll.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Nafu li dawn il-bytes huma validi, allura aħna nużaw `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Spag ikkodifikat, ikkodifikat UTF-8.
///
/// It-tip `String` huwa l-iktar tip ta 'sekwenza komuni li għandu pussess fuq il-kontenut tas-sekwenza.Għandu relazzjoni mill-qrib mal-kontroparti tiegħu mislufa, ix-[`str`] primittiv.
///
/// # Examples
///
/// Tista 'toħloq `String` minn [a literal string][`str`] b [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Tista 'żżid [`char`] ma' `String` bil-metodu [`push`], u żżid [`&str`] bil-metodu [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Jekk għandek vector ta 'bytes UTF-8, tista' toħloq `String` minnha bil-metodu [`from_utf8`]:
///
/// ```
/// // xi bytes, f'vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Nafu li dawn il-bytes huma validi, allura aħna nużaw `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// 'String`s huma dejjem validi UTF-8.Dan għandu ftit implikazzjonijiet, li l-ewwel waħda minnhom hija li jekk għandek bżonn sekwenza mhux UTF-8, ikkunsidra [`OsString`].Huwa simili, iżda mingħajr ir-restrizzjoni UTF-8.It-tieni implikazzjoni hija li ma tistax indiċizza f `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// L-indiċjar huwa maħsub li jkun operazzjoni ta 'ħin kostanti, iżda l-kodifikazzjoni UTF-8 ma tippermettilniex nagħmlu dan.Barra minn hekk, mhuwiex ċar x'tip ta 'ħaġa għandu jirritorna l-indiċi: byte, punt tal-kodiċi, jew raggruppament tal-grafema.
/// Il-metodi [`bytes`] u [`chars`] jirritornaw iteraturi fuq l-ewwel tnejn, rispettivament.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// "String`s implement [`Deref`] "<Target=str>', u għalhekk jirtu l-metodi kollha ta' [`str`].Barra minn hekk, dan ifisser li tista 'tgħaddi `String` għal funzjoni li tieħu [`&str`] billi tuża xper u (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Dan joħloq [`&str`] mix-`String` u jgħaddiha. Din il-konverżjoni hija rħisa ħafna, u għalhekk ġeneralment, il-funzjonijiet jaċċettaw [`&str`] s bħala argumenti sakemm ma jkollhomx bżonn `String` għal xi raġuni speċifika.
///
/// F'ċerti każijiet Rust m'għandux biżżejjed informazzjoni biex jagħmel din il-konverżjoni, magħrufa bħala koerzjoni [`Deref`].Fl-eżempju li ġej string spaga [`&'a str`][`&str`] timplimenta trait `TraitExample`, u l-funzjoni `example_func` tieħu kull ħaġa li timplimenta trait.
/// F'dan il-każ Rust ikollu bżonn jagħmel żewġ konverżjonijiet impliċiti, li Rust m'għandux il-mezzi biex jagħmel.
/// Għal dik ir-raġuni, l-eżempju li ġej mhux se jiġbor.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Hemm żewġ għażliet li minflok jaħdmu.L-ewwel wieħed ikun li tbiddel il-linja `example_func(&example_string);` għal `example_func(example_string.as_str());`, billi tuża l-metodu [`as_str()`] biex espliċitament tiġbed il-porzjon tas-sekwenza li jkun fiha s-sekwenza.
/// It-tieni mod ibiddel `example_func(&example_string);` għal `example_func(&*example_string);`.
/// F'dan il-każ qed niddereferenzjaw `String` għal [`str`][`&str`], imbagħad nirreferenzjaw ix-[`str`][`&str`] lura għal [`&str`].
/// It-tieni mod huwa aktar idjomatiku, madankollu t-tnejn jaħdmu biex jagħmlu l-konverżjoni b'mod espliċitu aktar milli jiddependu fuq il-konverżjoni impliċita.
///
/// # Representation
///
/// `String` huwa magħmul minn tliet komponenti: pointer għal xi bytes, tul, u kapaċità.Il-pointer jindika buffer intern li juża `String` biex jaħżen id-data tiegħu.It-tul huwa n-numru ta 'bytes maħżuna bħalissa fil-buffer, u l-kapaċità hija d-daqs tal-buffer f'bytes.
///
/// Bħala tali, it-tul dejjem ikun inqas jew daqs il-kapaċità.
///
/// Dan il-buffer huwa dejjem maħżun fuq il-borġ.
///
/// Tista 'tħares lejn dawn bil-metodi [`as_ptr`], [`len`], u [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Aġġorna dan meta vec_into_raw_parts jiġi stabbilizzat.
/// // Evita li twaqqa 'awtomatikament id-dejta tas-String
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // l-istorja għandha dsatax-il byte
/// assert_eq!(19, len);
///
/// // Nistgħu nibnu mill-ġdid String minn ptr, len, u kapaċità.
/// // Dan kollu mhux sikur għax aħna responsabbli biex niżguraw li l-komponenti jkunu validi:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Jekk `String` għandu biżżejjed kapaċità, iż-żieda ta 'elementi miegħu ma jerġax jiġi allokat.Pereżempju, ikkunsidra dan il-programm:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Dan joħroġ dan li ġej:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Għall-ewwel, m'għandna l-ebda memorja allokata, iżda hekk kif aħna nżidu mas-sekwenza, din iżżid il-kapaċità tagħha b'mod xieraq.Jekk minflok nużaw il-metodu [`with_capacity`] biex nallokaw il-kapaċità t-tajba inizjalment:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Aħna nispiċċaw bi produzzjoni differenti:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Hawnhekk, m'hemmx bżonn li tiġi allokata aktar memorja ġewwa l-linja.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Valur ta 'żball possibbli meta tikkonverti `String` minn byte UTF-8 vector.
///
/// Dan it-tip huwa t-tip ta 'żball għall-metodu [`from_utf8`] fuq [`String`].
/// Huwa ddisinjat b'tali mod biex jiġu evitati bir-reqqa allokazzjonijiet mill-ġdid: il-metodu [`into_bytes`] jagħti lura l-byte vector li ntuża fl-attentat ta 'konverżjoni.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// It-tip [`Utf8Error`] ipprovdut minn [`std::str`] jirrappreżenta żball li jista 'jseħħ meta taqleb porzjon ta' [`u8`] s għal [`&str`].
/// F'dan is-sens, huwa analogu għal `FromUtf8Error`, u tista 'tikseb wieħed minn `FromUtf8Error` permezz tal-metodu [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// // xi bytes invalidi, f'vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Valur ta 'żball possibbli meta tikkonverti `String` minn porzjon ta' byte UTF-16.
///
/// Dan it-tip huwa t-tip ta 'żball għall-metodu [`from_utf16`] fuq [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Joħloq `String` vojt ġdid.
    ///
    /// Minħabba li x-`String` huwa vojt, dan ma jalloka l-ebda buffer inizjali.Filwaqt li dan ifisser li din l-operazzjoni inizjali hija rħisa ħafna, tista 'tikkawża allokazzjoni eċċessiva aktar tard meta żżid id-dejta.
    ///
    /// Jekk għandek idea ta 'kemm dejta se żżomm ix-`String`, ikkunsidra l-metodu [`with_capacity`] biex tevita allokazzjoni mill-ġdid eċċessiva.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Joħloq `String` vojt ġdid b'kapaċità partikolari.
    ///
    /// 'String`s għandhom buffer intern biex iżommu d-data tagħhom.
    /// Il-kapaċità hija t-tul ta 'dak il-buffer, u tista' tiġi mistoqsija bil-metodu [`capacity`].
    /// Dan il-metodu joħloq `String` vojt, iżda wieħed b'bufer inizjali li jista 'jżomm bytes `capacity`.
    /// Dan huwa utli meta tista 'tkun qed iżżid mazz ta' dejta max-`String`, u tnaqqas in-numru ta 'riallokazzjonijiet li trid tagħmel.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Jekk il-kapaċità mogħtija hija `0`, l-ebda allokazzjoni ma sseħħ, u dan il-metodu huwa identiku għall-metodu [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Is-String ma fih l-ebda karattri, anke jekk għandu kapaċità għal aktar
    /// assert_eq!(s.len(), 0);
    ///
    /// // Dawn kollha jsiru mingħajr riallokazzjoni ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... iżda dan jista 'jagħmel is-sekwenza talloka mill-ġdid
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): b cfg(test) il-metodu inerenti `[T]::to_vec`, li huwa meħtieġ għal din id-definizzjoni tal-metodu, mhuwiex disponibbli.
    // Peress li aħna ma jeħtiġux dan il-metodu għal skopijiet ta 'ttestjar, jien ser nieqaf biss NB ara l-modulu slice::hack f slice.rs għal aktar informazzjoni
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Ikkonverti vector ta 'bytes għal `String`.
    ///
    /// String ([`String`]) huwa magħmul minn bytes ([`u8`]), u vector ta 'bytes ([`Vec<u8>`]) huwa magħmul minn bytes, għalhekk din il-funzjoni tikkonverti bejn it-tnejn.
    /// Mhux il-flieli kollha tal-byte huma validi 'String`s, madankollu: `String` jirrikjedi li hija UTF-8 valida.
    /// `from_utf8()` jiċċekkja biex jiżgura li l-bytes huma UTF-8 validi, u mbagħad jagħmel il-konverżjoni.
    ///
    /// Jekk inti żgur li l-porzjon tal-byte huwa UTF-8 validu, u ma tridx iġġarrab l-ispiża ġenerali tal-kontroll tal-validità, hemm verżjoni mhux sigura ta 'din il-funzjoni, [`from_utf8_unchecked`], li għandha l-istess imġieba imma taqbeż il-kontroll.
    ///
    ///
    /// Dan il-metodu jieħu ħsieb li ma jikkopjax iż-vector, għal raġunijiet ta 'effiċjenza.
    ///
    /// Jekk għandek bżonn [`&str`] minflok `String`, ikkunsidra [`str::from_utf8`].
    ///
    /// L-invers ta 'dan il-metodu huwa [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Jirritorna [`Err`] jekk il-porzjon mhuwiex UTF-8 b'deskrizzjoni għaliex il-bytes ipprovduti mhumiex UTF-8.Iż-vector li ċċaqlaq fih huwa wkoll inkluż.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // xi bytes, f'vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Nafu li dawn il-bytes huma validi, allura aħna nużaw `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes mhux korretti:
    ///
    /// ```
    /// // xi bytes invalidi, f'vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Ara d-dokumenti għal [`FromUtf8Error`] għal aktar dettalji dwar x'tista 'tagħmel b'dan l-iżball.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Ikkonverti porzjon ta 'bytes għal sekwenza, inklużi karattri invalidi.
    ///
    /// Il-kordi huma magħmula minn bytes ([`u8`]), u porzjon ta `bytes ([`&[u8]`][byteslice]) huwa magħmul minn bytes, allura din il-funzjoni tikkonverti bejn it-tnejn.Mhux il-flieli kollha tal-byte huma kordi validi, madankollu: kordi huma meħtieġa li jkunu UTF-8 validi.
    /// Matul din il-konverżjoni, `from_utf8_lossy()` jissostitwixxi kwalunkwe sekwenza invalida ta UTF-8 b [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], li tidher hekk:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Jekk inti żgur li l-porzjon tal-byte huwa UTF-8 validu, u ma tridx iġġarrab l-overhead tal-konverżjoni, hemm verżjoni mhux sigura ta 'din il-funzjoni, [`from_utf8_unchecked`], li għandha l-istess imġieba imma taqbeż il-kontrolli.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Din il-funzjoni tirritorna [`Cow<'a, str>`].Jekk il-porzjon tal-byte tagħna huwa UTF-8 invalidu, allura rridu ndaħħlu l-karattri sostituti, li jibdlu d-daqs tas-sekwenza, u għalhekk, jeħtieġu `String`.
    /// Imma jekk diġà huwa UTF-8 validu, m'għandniex bżonn allokazzjoni ġdida.
    /// Dan it-tip ta 'ritorn jippermettilna li nittrattaw iż-żewġ każijiet.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // xi bytes, f'vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Bytes mhux korretti:
    ///
    /// ```
    /// // xi bytes invalidi
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Iddekowdja vector `v` ikkodifikat UTF-16 f `String`, u rritorna [`Err`] jekk `v` fih xi dejta invalida.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Dan ma jsirx permezz ta 'collect: : <Result<_, _>> () għal raġunijiet ta 'prestazzjoni.
        // FIXME: il-funzjoni tista 'tiġi ssimplifikata mill-ġdid meta #48994 ikun magħluq.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Iddekowdja porzjon `v` ikkodifikat UTF-16 f `String`, billi tissostitwixxi dejta invalida b [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// B'differenza minn [`from_utf8_lossy`] li jirritorna [`Cow<'a, str>`], `from_utf16_lossy` jirritorna `String` peress li l-konverżjoni UTF-16 għal UTF-8 teħtieġ allokazzjoni ta 'memorja.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Tiddekomponi `String` fil-komponenti nej tiegħu.
    ///
    /// Irritorna l-indikatur mhux ipproċessat għad-dejta sottostanti, it-tul tas-sekwenza (f'bytes), u l-kapaċità allokata tad-dejta (f'bytes).
    /// Dawn huma l-istess argumenti fl-istess ordni bħall-argumenti għal [`from_raw_parts`].
    ///
    /// Wara li ssejjaħ din il-funzjoni, min iċempel huwa responsabbli għall-memorja li qabel kienet immaniġġjata mix-`String`.
    /// L-uniku mod biex tagħmel dan huwa li tikkonverti l-pointer nej, it-tul u l-kapaċità lura f `String` bil-funzjoni [`from_raw_parts`], li tippermetti lid-distruttur iwettaq it-tindif.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Toħloq `String` ġdid minn tul, kapaċità, u pointer.
    ///
    /// # Safety
    ///
    /// Dan huwa perikoluż ħafna, minħabba n-numru ta 'invariants li mhumiex iċċekkjati:
    ///
    /// * Il-memorja f `buf` teħtieġ li qabel kienet allokata mill-istess allokatur li tuża l-librerija standard, b'allinjament meħtieġ ta 'eżattament 1.
    /// * `length` jeħtieġ li jkun inqas minn jew ugwali għal `capacity`.
    /// * `capacity` jeħtieġ li jkun il-valur korrett.
    /// * L-ewwel bytes `length` f `buf` għandhom ikunu UTF-8 validi.
    ///
    /// Il-ksur ta 'dawn jista' jikkawża problemi bħall-korruzzjoni tal-istrutturi interni tad-dejta tal-allokatur.
    ///
    /// Is-sjieda ta `buf` hija effettivament trasferita għax-`String` li mbagħad tista' tqassam mill-ġdid, talloka mill-ġdid jew tbiddel il-kontenut tal-memorja indikat mill-indikatur kif trid.
    /// Kun żgur li xejn iktar ma juża l-pointer wara li ssejjaħ din il-funzjoni.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Aġġorna dan meta vec_into_raw_parts jiġi stabbilizzat.
    ///     // Evita li twaqqa 'awtomatikament id-dejta tas-String
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Ikkonverti vector ta 'bytes għal `String` mingħajr ma jiċċekkja li s-sekwenza fiha UTF-8 validu.
    ///
    /// Ara l-verżjoni bla periklu, [`from_utf8`], għal aktar dettalji.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura għax ma tiċċekkjax li l-bytes mgħoddija lilha huma UTF-8 validi.
    /// Jekk din il-limitazzjoni tinkiser, tista 'tikkawża problemi ta' sigurtà fil-memorja ma 'utenti ta' future ta `String`, billi l-bqija tal-librerija standard tassumi li "String" huma UTF-8 validi.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // xi bytes, f'vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Ikkonverti `String` f'byte vector.
    ///
    /// Dan jikkonsma x-`String`, allura m'għandniex għalfejn nikkupjaw il-kontenut tiegħu.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Estratti porzjon ta 'sekwenza li fih ix-`String` kollu.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Ikkonverti `String` fi porzjon ta 'sekwenza li tista' tinbidel.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Iwaħħal porzjon ta 'sekwenza partikolari fuq it-tarf ta' dan ix-`String`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Jirritorna l-kapaċità ta 'din l-'Istring`, f'bytes.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Tiżgura li l-kapaċità ta 'din is-'Skinga' hija mill-inqas `additional` bytes akbar mit-tul tagħha.
    ///
    /// Il-kapaċità tista 'tiżdied b'aktar minn `additional` bytes jekk tagħżel, biex tipprevjeni riallokazzjonijiet frekwenti.
    ///
    ///
    /// Jekk ma tridx din l-imġieba "at least", ara l-metodu [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida tfur [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dan jista 'fil-fatt ma jżidx il-kapaċità:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // issa għandu tul ta '2 u kapaċità ta' 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Peress li diġà għandna 8 kapaċità żejda, insejħu dan ...
    /// s.reserve(8);
    ///
    /// // ... fil-fatt ma jiżdiedx.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Tiżgura li l-kapaċità ta 'din' String 'hija `additional` bytes akbar mit-tul tagħha.
    ///
    /// Ikkunsidra li tuża l-metodu [`reserve`] sakemm tkun taf assolutament aħjar mill-allokatur.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida tfur `usize`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Dan jista 'fil-fatt ma jżidx il-kapaċità:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // issa għandu tul ta '2 u kapaċità ta' 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Peress li diġà għandna 8 kapaċità żejda, insejħu dan ...
    /// s.reserve_exact(8);
    ///
    /// // ... fil-fatt ma jiżdiedx.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Jipprova jirriserva kapaċità għal mill-inqas `additional` aktar elementi li għandhom jiddaħħlu fix-`String` mogħti.
    /// Il-kollezzjoni tista 'tirriżerva aktar spazju biex tevita riallokazzjonijiet frekwenti.
    /// Wara li ċċempel lil `reserve`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional`.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà biżżejjed.
    ///
    /// # Errors
    ///
    /// Jekk il-kapaċità tfur, jew l-allokatur jirrapporta falliment, allura jiġi rritornat żball.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Irriserva minn qabel il-memorja, u toħroġ jekk ma nistgħux
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Issa nafu li dan ma jistax OOM fin-nofs tax-xogħol kumpless tagħna
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Tipprova tirriserva l-kapaċità minima għal eżattament `additional` aktar elementi li għandhom jiddaħħlu fix-`String` mogħti.
    ///
    /// Wara li ċċempel lil `reserve_exact`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional`.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà suffiċjenti.
    ///
    /// Innota li l-allokatur jista 'jagħti lill-kollezzjoni aktar spazju milli jitlob.
    /// Għalhekk, il-kapaċità ma tistax tiġi invokata biex tkun preċiżament minima.
    /// Ippreferi `reserve` jekk huma mistennija inserzjonijiet future.
    ///
    /// # Errors
    ///
    /// Jekk il-kapaċità tfur, jew l-allokatur jirrapporta falliment, allura jiġi rritornat żball.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Irriserva minn qabel il-memorja, u toħroġ jekk ma nistgħux
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Issa nafu li dan ma jistax OOM fin-nofs tax-xogħol kumpless tagħna
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Iċċekken il-kapaċità ta 'dan ix-`String` biex jaqbel mat-tul tiegħu.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Iċċekken il-kapaċità ta 'dan ix-`String` b'limitu aktar baxx.
    ///
    /// Il-kapaċità tibqa 'mill-inqas kbira kemm tat-tul kif ukoll tal-valur fornut.
    ///
    ///
    /// Jekk il-kapaċità kurrenti hija inqas mil-limitu l-iktar baxx, dan huwa no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Iwaħħal ix-[`char`] mogħti fit-tmiem ta 'dan ix-`String`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Jirritorna porzjon ta 'byte tal-kontenut ta' din is-'String '.
    ///
    /// L-invers ta 'dan il-metodu huwa [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Qassar dan ix-`String` għat-tul speċifikat.
    ///
    /// Jekk `new_len` huwa akbar mit-tul kurrenti tas-sekwenza, dan m'għandux effett.
    ///
    ///
    /// Innota li dan il-metodu m'għandux effett fuq il-kapaċità allokata tas-sekwenza
    ///
    /// # Panics
    ///
    /// Panics jekk `new_len` ma jimteddx fuq konfini [`char`].
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Tneħħi l-aħħar karattru mill-buffer tas-sekwenza u tirritornaha.
    ///
    /// Jirritorna [`None`] jekk dan `String` huwa vojt.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Neħħi [`char`] minn dan `String` f'pożizzjoni ta 'byte u jirritornaha.
    ///
    /// Din hija operazzjoni *O*(*n*), għax teħtieġ li tikkopja kull element fil-buffer.
    ///
    /// # Panics
    ///
    /// Panics jekk `idx` huwa akbar minn jew ugwali għat-tul ta '' String ', jew jekk ma jinsabx fuq fruntiera [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Neħħi l-logħbiet kollha tal-mudell `pat` fix-`String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Il-logħbiet jiġu skoperti u mneħħija b'mod iterattiv, għalhekk f'każijiet fejn ix-xejriet jikkoinċidu, l-ewwel mudell biss jitneħħa:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // SIGURTÀ: il-bidu u t-tmiem se jkunu fuq il-konfini tal-byte utf8 għal kull
        // id-dokumenti tat-Tiftix
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Iżomm biss il-karattri speċifikati mill-predikat.
    ///
    /// Fi kliem ieħor, neħħi l-karattri kollha `c` b'tali mod li `f(c)` jirritorna `false`.
    /// Dan il-metodu jopera f'postu, u jżur kull karattru eżattament darba fl-ordni oriġinali, u jippreserva l-ordni tal-karattri miżmuma.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// L-ordni eżatta tista 'tkun utli għat-traċċar ta' stat estern, bħal indiċi.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Punt idx għall-karattru li jmiss
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Daħħal karattru f'dan ix-`String` f'pożizzjoni ta 'byte.
    ///
    /// Din hija operazzjoni *O*(*n*) peress li teħtieġ tikkopja kull element fil-buffer.
    ///
    /// # Panics
    ///
    /// Panics jekk `idx` huwa akbar mit-tul ta 'l-'Istrixxa', jew jekk ma jinsabx fuq konfini [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Daħħal porzjon ta 'sekwenza f'dan ix-`String` f'pożizzjoni ta' byte.
    ///
    /// Din hija operazzjoni *O*(*n*) peress li teħtieġ tikkopja kull element fil-buffer.
    ///
    /// # Panics
    ///
    /// Panics jekk `idx` huwa akbar mit-tul ta 'l-'Istrixxa', jew jekk ma jinsabx fuq konfini [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Jirritorna referenza li tista 'tinbidel għall-kontenut ta' dan ix-`String`.
    ///
    /// # Safety
    ///
    /// Din il-funzjoni mhix sigura għax ma tiċċekkjax li l-bytes mgħoddija lilha huma UTF-8 validi.
    /// Jekk din il-limitazzjoni tinkiser, tista 'tikkawża problemi ta' sigurtà fil-memorja ma 'utenti ta' future ta `String`, billi l-bqija tal-librerija standard tassumi li "String" huma UTF-8 validi.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Jirritorna t-tul ta 'dan ix-`String`, f'bytes, mhux [`char`] jew grafemi.
    /// Fi kliem ieħor, jista 'ma jkunx dak li bniedem jikkunsidra t-tul tas-sekwenza.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Jirritorna `true` jekk dan `String` għandu tul ta 'żero, u `false` mod ieħor.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Aqsam is-sekwenza fi tnejn fl-indiċi tal-byte mogħti.
    ///
    /// Jirritorna `String` allokat ġdid.
    /// `self` fih bytes `[0, at)`, u l-`String` ritornat fih bytes `[at, len)`.
    /// `at` għandu jkun fuq il-konfini ta 'punt tal-kodiċi UTF-8.
    ///
    /// Innota li l-kapaċità ta `self` ma tinbidilx.
    ///
    /// # Panics
    ///
    /// Panics jekk `at` mhuwiex fuq limitu tal-punt tal-kodiċi `UTF-8`, jew jekk huwa lil hinn mill-aħħar punt tal-kodiċi tas-sekwenza.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Ittaqqab dan ix-`String`, u tneħħi l-kontenut kollu.
    ///
    /// Filwaqt li dan ifisser li x-`String` se jkollu tul ta 'żero, ma jmissx il-kapaċità tiegħu.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Joħloq iteratur li jbattal li jneħħi l-firxa speċifikata fix-`String` u jagħti x-`chars` imneħħi.
    ///
    ///
    /// Note: Il-firxa tal-elementi titneħħa anke jekk l-iteratur ma jiġix ikkunsmat sa l-aħħar.
    ///
    /// # Panics
    ///
    /// Panics jekk il-punt tat-tluq jew il-punt tat-tmiem ma jkunux fuq konfini [`char`], jew jekk ikunu barra mill-limiti.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Neħħi l-firxa 'l fuq sa β mis-sekwenza
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Firxa sħiħa tħassar is-sekwenza
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Sigurtà tal-memorja
        //
        // Il-verżjoni String ta 'Drain m'għandhiex il-kwistjonijiet ta' sigurtà tal-memorja tal-verżjoni vector.
        // Id-dejta hija biss bytes sempliċi.
        // Minħabba li t-tneħħija tal-firxa sseħħ fi Drop, jekk l-iteratur Drain ikun nixxa, it-tneħħija ma sseħħx.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Oħroġ żewġ self simultanji.
        // Is-sekwenza &mut ma tkunx aċċessata sakemm iterazzjoni tispiċċa, fi Drop.
        let self_ptr = self as *mut _;
        // SIGURTÀ: `slice::range` u `is_char_boundary` jagħmlu l-kontrolli tal-limiti xierqa.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Tneħħi l-firxa speċifikata fis-sekwenza, u tibdilha bis-sekwenza mogħtija.
    /// Is-sekwenza mogħtija m'għandhiex għalfejn tkun l-istess tul bħall-firxa.
    ///
    /// # Panics
    ///
    /// Panics jekk il-punt tat-tluq jew il-punt tat-tmiem ma jkunux fuq konfini [`char`], jew jekk ikunu barra mill-limiti.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Ibdel il-firxa 'l fuq sa β mis-sekwenza
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Sigurtà tal-memorja
        //
        // Replace_range m'għandux il-kwistjonijiet ta 'sigurtà tal-memorja ta' vector Splice.
        // tal-verżjoni vector.Id-dejta hija biss bytes sempliċi.

        // TWISSIJA: L-inklużjoni ta 'din il-varjabbli ma tkunx tajba (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // TWISSIJA: L-inklużjoni ta 'din il-varjabbli ma tkunx tajba (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // L-użu mill-ġdid ta `range` ma jkunx tajjeb (#81138) Aħna nassumu li l-limiti rrappurtati minn `range` jibqgħu l-istess, iżda implimentazzjoni kontradittorja tista' tinbidel bejn is-sejħiet
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Ikkonverti dan ix-`String` f '[`Kaxxa`]`<`[`str`] `>`.
    ///
    /// Dan iwaqqa 'kwalunkwe kapaċità żejda.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Jirritorna porzjon ta '[`u8`] s bytes li kienu ppruvaw jikkonvertu għal `String`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // xi bytes invalidi, f'vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Jirritorna l-bytes li kienu ppruvaw jikkonvertu għal `String`.
    ///
    /// Dan il-metodu huwa mibni bir-reqqa biex tiġi evitata l-allokazzjoni.
    /// Se tikkonsma l-iżball, billi toħroġ il-bytes, sabiex kopja tal-bytes ma teħtieġx li ssir.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // xi bytes invalidi, f'vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Iġbed `Utf8Error` biex tikseb aktar dettalji dwar il-falliment tal-konverżjoni.
    ///
    /// It-tip [`Utf8Error`] ipprovdut minn [`std::str`] jirrappreżenta żball li jista 'jseħħ meta taqleb porzjon ta' [`u8`] s għal [`&str`].
    /// F'dan is-sens, huwa analogu għal `FromUtf8Error`.
    /// Ara d-dokumentazzjoni tagħha għal aktar dettalji dwar kif tużaha.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// // xi bytes invalidi, f'vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // l-ewwel byte mhuwiex validu hawn
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Minħabba li qed nirrepetu fuq 'String`s, nistgħu nevitaw mill-inqas allokazzjoni waħda billi jkollna l-ewwel sekwenza mill-iteratur u nżidu magħha l-kordi sussegwenti kollha.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Minħabba li qed nirrepetu fuq CoWs, nistgħu (potentially) nevitaw mill-inqas allokazzjoni waħda billi jkollna l-ewwel oġġett u nżidu miegħu l-oġġetti sussegwenti kollha.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Impliċità ta 'konvenjenza li tiddelega lill-impl għal `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Joħloq `String` vojt.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Timplimenta l-operatur `+` għall-konkatenazzjoni ta 'żewġ kordi.
///
/// Dan jikkonsma x-`String` fuq in-naħa tax-xellug u jerġa 'juża l-buffer tiegħu (ikabbarha jekk meħtieġ).
/// Dan isir biex tiġi evitata l-allokazzjoni ta `String` ġdid u l-ikkupjar tal-kontenut kollu fuq kull operazzjoni, li twassal għal ħin ta' tħaddim *O*(*n*^ 2) meta tinbena sekwenza ta '*n*-byte b'konkatenazzjoni ripetuta.
///
///
/// Is-sekwenza fuq in-naħa tal-lemin hija biss mislufa;il-kontenut tiegħu huwa kkupjat fix-`String` mibgħut lura.
///
/// # Examples
///
/// Il-konkatenazzjoni ta 'żewġ' String`s tieħu l-ewwel bil-valur u tissellef it-tieni:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` jiġi mċaqlaq u ma jistax jintuża iktar hawn.
/// ```
///
/// Jekk trid tibqa 'tuża l-ewwel `String`, tista' tikklonaha u tehmeż mal-klonu minflok:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` għadu validu hawn.
/// ```
///
/// Il-konkatenazzjoni ta 'flieli `&str` tista' ssir billi l-ewwel tiġi kkonvertita għal `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Timplimenta l-operatur `+=` biex tehmeż ma `String`.
///
/// Dan għandu l-istess imġieba bħall-metodu [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Alias tat-tip għal [`Infallible`].
///
/// Dan l-alias jeżisti għall-kompatibilità b'lura, u jista 'eventwalment jiġi skadut.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// A trait għall-konverżjoni ta 'valur għal `String`.
///
/// Dan trait huwa implimentat awtomatikament għal kwalunkwe tip li jimplimenta l-[`Display`] trait.
/// Bħala tali, `ToString` m'għandux jiġi implimentat direttament:
/// [`Display`] għandhom jiġu implimentati minflok, u ikollok l-implimentazzjoni `ToString` b'xejn.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Ikkonverti l-valur mogħti għal `String`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// F'din l-implimentazzjoni, il-metodu `to_string` panics jekk l-implimentazzjoni `Display` tirritorna żball.
/// Dan jindika implimentazzjoni `Display` inkorretta billi `fmt::Write for String` qatt ma jirritorna żball innifsu.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Linja gwida komuni hija li ma tiddaħħalx il-funzjonijiet ġeneriċi.
    // Madankollu, it-tneħħija ta `#[inline]` minn dan il-metodu tikkawża rigressjonijiet mhux negliġibbli.
    // Ara <https://github.com/rust-lang/rust/pull/74852>, l-aħħar tentattiv biex tipprova tneħħih.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Ikkonverti `&mut str` f `String`.
    ///
    /// Ir-riżultat huwa allokat fuq il-borġ.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test jiġbed fil-libstd, li jikkawża żbalji hawn
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Ikkonverti l-porzjon `str` mogħti f'kaxxa għal `String`.
    /// Huwa notevoli li l-porzjon `str` huwa proprjetà.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Ikkonverti l-`String` mogħti għal porzjon `str` fil-kaxxa li huwa proprjetà.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Ikkonverti porzjon ta 'sekwenza f'varjant misluf.
    /// L-ebda allokazzjoni tal-borġ ma titwettaq, u s-sekwenza mhix ikkupjata.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Ikkonverti String f'varjant Proprjetà.
    /// L-ebda allokazzjoni tal-borġ ma titwettaq, u s-sekwenza mhix ikkupjata.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Ikkonverti referenza String f'varjant misluf.
    /// L-ebda allokazzjoni tal-borġ ma titwettaq, u s-sekwenza mhix ikkupjata.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Ikkonverti l-`String` mogħti għal vector `Vec` li jkollu valuri tat-tip `u8`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Iteratur li jbattal għal `String`.
///
/// Din l-istruttura hija maħluqa bil-metodu [`drain`] fuq [`String`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Se jintuża bħala&'a mut String in the destructor
    string: *mut String,
    /// Bidu tal-parti biex tneħħi
    start: usize,
    /// Tmiem tal-parti li trid titneħħa
    end: usize,
    /// Firxa kurrenti li fadal biex tneħħi
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Uża Vec::drain.
            // "Reaffirm" il-limiti jiċċekkjaw biex jevitaw li jerġa 'jiddaħħal il-kodiċi panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Jirritorna s-sekwenza (sub) li jifdal ta 'dan l-iteratur bħala porzjon.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: kumment AsRef jimplika hawn taħt meta tistabbilizza.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Ikkummenta meta tistabbilizza `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>għal Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> għal Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}