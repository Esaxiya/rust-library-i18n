use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // Il-kitba ta 'test ta' integrazzjoni bejn allokaturi ta 'partijiet terzi u `RawVec` hija ftit delikata minħabba li l-API `RawVec` ma tesponix metodi ta' allokazzjoni fallibbli, allura ma nistgħux niċċekkjaw x'jiġri meta l-allokatur ikun eżawrit (lil hinn mis-sejba ta 'panic).
    //
    //
    // Minflok, dan jiċċekkja biss li l-metodi `RawVec` għallinqas jgħaddu mill-Allocator API meta tirriżerva ħażna.
    //
    //
    //
    //
    //

    // Allokatur stupidu li jikkonsma ammont fiss ta 'fjuwil qabel ma l-attentati ta' allokazzjoni jibdew ifallu.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (tikkawża allokazzjoni mill-ġdid, u b'hekk tuża 50 + 150=200 unità ta 'fjuwil)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // L-ewwel, `reserve` jalloka bħal `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 huwa iktar mid-doppju ta '7, allura `reserve` għandu jaħdem bħal `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 huwa inqas minn nofs 12, għalhekk `reserve` għandu jikber b'mod esponenzjali.
        // Fil-ħin tal-kitba ta 'dan it-test il-fattur ta' tkabbir huwa 2, għalhekk kapaċità ġdida hija 24, madankollu, fattur ta 'tkabbir ta' 1.5 huwa OK ukoll.
        //
        // Għalhekk `>= 18` fl-affermazzjoni.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}