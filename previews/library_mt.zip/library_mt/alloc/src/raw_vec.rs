#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Il-kontenut tal-memorja l-ġdida mhuwiex inizjalizzat.
    Uninitialized,
    /// Il-memorja l-ġdida hija ggarantita li tkun żero.
    Zeroed,
}

/// Utilità ta 'livell baxx għal aktar ergonomikament allokazzjoni, allokazzjoni mill-ġdid u tqassim ta' buffer ta 'memorja fuq il-borġ mingħajr ma jkollok għalfejn tinkwieta dwar il-każijiet kollha involuti.
///
/// Dan it-tip huwa eċċellenti biex tibni l-istrutturi tad-dejta tiegħek stess bħal Vec u VecDeque.
/// Partikolarment:
///
/// * Tipproduċi `Unique::dangling()` fuq tipi ta 'daqs żero.
/// * Tipproduċi `Unique::dangling()` fuq allokazzjonijiet ta 'tul żero.
/// * Jevita li jeħles `Unique::dangling()`.
/// * Jaqbad kull tifwir f'komputazzjonijiet tal-kapaċità (jippromwovihom għal "capacity overflow" panics).
/// * Tħares kontra sistemi ta '32-bit li jallokaw aktar minn isize::MAX bytes.
/// * Gwardji kontra t-tifwir tat-tul tiegħek.
/// * Jitlob lil `handle_alloc_error` għal allokazzjonijiet fallibbli.
/// * Fih `ptr::Unique` u għalhekk jagħti lill-utent il-benefiċċji kollha relatati.
/// * Juża l-eċċess lura mill-allokatur biex juża l-akbar kapaċità disponibbli.
///
/// Dan it-tip ma jispezzjonax xorta waħda l-memorja li jimmaniġġja.Meta titwaqqa '*se* teħles il-memorja tagħha, imma *mhux* tipprova twaqqa' l-kontenut tagħha.
/// Huwa f'idejn l-utent ta `RawVec` li jimmaniġġja l-affarijiet attwali *maħżuna* ġewwa `RawVec`.
///
/// Innota li l-eċċess ta 'tipi ta' daqs żero huwa dejjem infinit, għalhekk `capacity()` dejjem jirritorna `usize::MAX`.
/// Dan ifisser li trid toqgħod attent meta tiddawwar dan it-tip b `Box<[T]>`, peress li `capacity()` ma jrendix it-tul.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dan jeżisti minħabba li `#[unstable]` `const fn`s m'għandux għalfejn jikkonforma ma `min_const_fn` u għalhekk lanqas ma jistgħu jissejħu f'`min_const_fn`s.
    ///
    /// Jekk tibdel `RawVec<T>::new` jew dipendenzi, jekk jogħġbok oqgħod attent li ma tintroduċi xejn li verament jikser `min_const_fn`.
    ///
    /// NOTE: Aħna nistgħu nevitaw din il-hack u niċċekkjaw il-konformità ma 'xi attribut `#[rustc_force_min_const_fn]` li jirrikjedi konformità ma' `min_const_fn` iżda mhux neċessarjament jippermetti li ssejjaħlu f `stable(...) const fn`/kodiċi tal-utent li ma jippermettix `foo` meta `#[rustc_const_unstable(feature = "foo", issue = "01234")]` ikun preżenti.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Toħloq l-akbar `RawVec` possibbli (fuq il-borġ tas-sistema) mingħajr ma talloka.
    /// Jekk `T` għandu daqs pożittiv, allura dan jagħmel `RawVec` b'kapaċità `0`.
    /// Jekk `T` huwa ta 'daqs żero, allura jagħmel `RawVec` b'kapaċità `usize::MAX`.
    /// Utli għall-implimentazzjoni ta 'allokazzjoni mdewma.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Toħloq `RawVec` (fuq il-borġ tas-sistema) bir-rekwiżiti tal-kapaċità u l-allinjament eżattament għal `[T; capacity]`.
    /// Dan huwa ekwivalenti għal sejħa lil `RawVec::new` meta `capacity` huwa `0` jew `T` huwa ta 'daqs żero.
    /// Innota li jekk `T` huwa ta 'daqs żero dan ifisser li inti *ma* jkollokx `RawVec` bil-kapaċità mitluba.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità mitluba taqbeż `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Jieqaf fuq OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Bħal `with_capacity`, iżda jiggarantixxi li l-buffer jiġi ssettjat fuq iż-żero.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Jirrikostitwixxi `RawVec` minn pointer u kapaċità.
    ///
    /// # Safety
    ///
    /// Ix-`ptr` għandu jkun allokat (fuq il-borġ tas-sistema), u max-`capacity` mogħti.
    /// Ix-`capacity` ma jistax jaqbeż `isize::MAX` għal tipi ta 'daqs.(tħassib biss fuq sistemi ta '32-bit).
    /// ZST vectors jista 'jkollu kapaċità sa `usize::MAX`.
    /// Jekk ix-`ptr` u `capacity` jiġu minn `RawVec`, allura dan huwa garantit.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Vecs żgħar huma mutu.Aqbeż għal:
    // - 8 jekk id-daqs tal-element huwa 1, minħabba li kwalunkwe allokatur tal-borġ x'aktarx itawwar talba ta 'inqas minn 8 bytes għal mill-inqas 8 bytes.
    //
    // - 4 jekk l-elementi huma ta 'daqs moderat (<=1 KiB).
    // - 1 inkella, biex tevita li taħli wisq spazju għal Vecs qosra ħafna.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Bħal `new`, iżda parametrizzata fuq l-għażla tal-allokatur għax-`RawVec` ritornat.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` tfisser "unallocated".tipi ta 'daqs żero huma injorati.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Bħal `with_capacity`, iżda parametrizzata fuq l-għażla tal-allokatur għax-`RawVec` ritornat.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Bħal `with_capacity_zeroed`, iżda parametrizzata fuq l-għażla tal-allokatur għax-`RawVec` ritornat.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Ikkonverti `Box<[T]>` f `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Ikkonverti l-buffer kollu f `Box<[MaybeUninit<T>]>` max-`len` speċifikat.
    ///
    /// Innota li dan jirrikostitwixxi b'mod korrett kwalunkwe tibdil `cap` li seta 'sar.(Ara d-deskrizzjoni tat-tip għad-dettalji.)
    ///
    /// # Safety
    ///
    /// * `len` għandhom ikunu akbar minn jew ugwali għall-kapaċità mitluba l-aktar reċentement, u
    /// * `len` għandu jkun inqas minn jew ugwali għal `self.capacity()`.
    ///
    /// Innota, li l-kapaċità mitluba u `self.capacity()` jistgħu jvarjaw, billi allokatur jista 'b'mod ġenerali jqiegħed u jirritorna blokka tal-memorja akbar minn dik mitluba.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Iċċekkja sanità nofs ir-rekwiżit tas-sigurtà (ma nistgħux niċċekkjaw in-nofs l-ieħor).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Hawnhekk nevitaw `unwrap_or_else` minħabba li jintefaħ l-ammont ta 'LLVM IR iġġenerat.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Jirrikostitwixxi `RawVec` minn pointer, kapaċità, u allokatur.
    ///
    /// # Safety
    ///
    /// Ix-`ptr` għandu jkun allokat (permezz tal-allokatur mogħti `alloc`), u max-`capacity` mogħti.
    /// Ix-`capacity` ma jistax jaqbeż `isize::MAX` għal tipi ta 'daqs.
    /// (tħassib biss fuq sistemi ta '32-bit).
    /// ZST vectors jista 'jkollu kapaċità sa `usize::MAX`.
    /// Jekk ix-`ptr` u `capacity` jiġu minn `RawVec` maħluq permezz ta `alloc`, allura dan huwa garantit.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Jikseb pointer mhux maħdum sal-bidu tal-allokazzjoni.
    /// Innota li dan huwa `Unique::dangling()` jekk `capacity == 0` jew `T` huma ta 'daqs żero.
    /// Fl-ewwel każ, trid toqgħod attent.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Tikseb il-kapaċità tal-allokazzjoni.
    ///
    /// Dan dejjem ikun `usize::MAX` jekk `T` huwa ta 'daqs żero.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Jirritorna referenza kondiviża għall-allokatur li jappoġġja dan ix-`RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Għandna biċċa ta 'memorja allokata, sabiex inkunu nistgħu nevitaw il-verifiki tal-runtime biex inġibu t-tqassim attwali tagħna.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Tiżgura li l-buffer fih mill-inqas biżżejjed spazju biex iżomm elementi `len + additional`.
    /// Jekk ma jkollux biżżejjed kapaċità, jalloka mill-ġdid biżżejjed spazju flimkien ma 'spazju laxk komdu biex jikseb imġieba amortizzata *O*(1).
    ///
    /// Se tillimita din l-imġieba jekk bla bżonn tikkawża lilha nnifisha għal panic.
    ///
    /// Jekk `len` jaqbeż `self.capacity()`, dan jista 'jonqos milli effettivament jalloka l-ispazju mitlub.
    /// Dan mhux verament mhux sikur, iżda l-kodiċi mhux sikur *li tikteb* li jiddependi fuq l-imġieba ta 'din il-funzjoni jista' jinkiser.
    ///
    /// Dan huwa ideali għall-implimentazzjoni ta 'operazzjoni ta' bulk-push bħal `extend`.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida taqbeż `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Jieqaf fuq OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // riserva kienet tkun abortita jew panikata kieku l-len qabeż `isize::MAX` allura dan huwa sikur li jsir mingħajr kontroll issa.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// L-istess bħal `reserve`, iżda jirritorna fuq l-iżbalji minflok paniku jew abort.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Tiżgura li l-buffer fih mill-inqas biżżejjed spazju biex iżomm elementi `len + additional`.
    /// Jekk ma tagħmilx diġà, terġa 'talloka l-ammont minimu possibbli ta' memorja meħtieġa.
    /// Ġeneralment dan ikun eżattament l-ammont ta 'memorja neċessarju, iżda fil-prinċipju l-allokatur huwa liberu li jagħti lura iktar milli tlabna.
    ///
    ///
    /// Jekk `len` jaqbeż `self.capacity()`, dan jista 'jonqos milli effettivament jalloka l-ispazju mitlub.
    /// Dan mhux verament mhux sikur, iżda l-kodiċi mhux sikur *li tikteb* li jiddependi fuq l-imġieba ta 'din il-funzjoni jista' jinkiser.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida taqbeż `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Jieqaf fuq OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// L-istess bħal `reserve_exact`, iżda jirritorna fuq l-iżbalji minflok paniku jew abort.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Tnaqqas l-allokazzjoni sa l-ammont speċifikat.
    /// Jekk l-ammont mogħti huwa 0, fil-fatt jittratta kompletament.
    ///
    /// # Panics
    ///
    /// Panics jekk l-ammont mogħti huwa *akbar* mill-kapaċità kurrenti.
    ///
    /// # Aborts
    ///
    /// Jieqaf fuq OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Jirritorna jekk il-buffer jeħtieġ li jikber biex jissodisfa l-kapaċità żejda meħtieġa.
    /// Prinċipalment użat biex jagħmlu sejħiet ta 'riserva inlining possibbli mingħajr XINX inlining.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Dan il-metodu huwa ġeneralment istanzjat ħafna drabi.Allura rridu li jkun żgħir kemm jista 'jkun, biex ittejjeb il-ħinijiet tal-kompilazzjoni.
    // Imma rridu wkoll li kemm jista 'jkun il-kontenut tiegħu jista' jiġi kkalkulat b'mod statiku, biex il-kodiċi ġġenerat jaħdem aktar malajr.
    // Għalhekk, dan il-metodu jinkiteb bir-reqqa sabiex il-kodiċi kollu li jiddependi fuq `T` ikun fih, filwaqt li kemm jista 'jkun mill-kodiċi li ma jiddependix fuq `T` huwa f'funzjonijiet li mhumiex ġeneriċi fuq `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Dan huwa żgurat mill-kuntesti tas-sejħa.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Peress li nirritornaw kapaċità ta `usize::MAX` meta jkun `elem_size`
            // 0, li tasal hawn neċessarjament ifisser li x-`RawVec` huwa mimli żżejjed.
            return Err(CapacityOverflow);
        }

        // Xejn ma nistgħu nagħmlu verament dwar dawn il-kontrolli, sfortunatament.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Dan jiggarantixxi tkabbir esponenzjali.
        // L-irduppjar ma jistax ifur għax `cap <= isize::MAX` u t-tip ta `cap` huwa `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` mhix ġenerika fuq `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Il-limitazzjonijiet fuq dan il-metodu huma l-istess bħal dawk fuq `grow_amortized`, iżda dan il-metodu ġeneralment jiġi istanzjat inqas spiss u għalhekk huwa inqas kritiku.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Peress li nirritornaw kapaċità ta `usize::MAX` meta d-daqs tat-tip huwa
            // 0, li tasal hawn neċessarjament ifisser li x-`RawVec` huwa mimli żżejjed.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` mhix ġenerika fuq `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Din il-funzjoni hija barra `RawVec` biex timminimizza l-ħinijiet tal-kompilazzjoni.Ara l-kumment hawn fuq `RawVec::grow_amortized` għad-dettalji.
// (Il-parametru `A` mhuwiex sinifikanti, minħabba li n-numru ta 'tipi `A` differenti li jidhru fil-prattika huwa ħafna iżgħar min-numru ta' tipi `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Iċċekkja l-iżball hawn biex tnaqqas id-daqs ta `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // L-allokatur jivverifika l-ugwaljanza fl-allinjament
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Tillibera l-memorja tal-`RawVec`*mingħajr ma* tipprova twaqqa 'l-kontenut tagħha.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Funzjoni ċentrali għall-immaniġġjar tal-iżbalji tar-riżerva
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Għandna bżonn niggarantixxu dan li ġej:
// * Aħna qatt ma nallokaw oġġetti ta 'daqs ta' byte `> isize::MAX`.
// * Aħna ma nifilħux `usize::MAX` u fil-fatt talloka ftit wisq.
//
// Fuq 64-bit għandna bżonn biss li niċċekkjaw jekk hemmx overflow billi nippruvaw nallokaw `> isize::MAX` bytes żgur li se tfalli.
// Fuq 32-bit u 16-bit irridu nżidu gwardja żejda għal dan f'każ li nkunu qed nimxu fuq pjattaforma li tista 'tuża l-4GB kollha fl-ispazju tal-utent, eż., PAE jew x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Funzjoni ċentrali waħda responsabbli għar-rappurtar ta 'tifwir tal-kapaċità.
// Dan ser jiżgura li l-ġenerazzjoni tal-kodiċi relatata ma 'dawn iż-panics hija minima peress li hemm lok wieħed biss li panics minflok mazz fil-modulu kollu.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}