//! Kju ta 'prijorità implimentat b'munzell binarju.
//!
//! L-inserzjoni u l-popping tal-akbar element għandhom kumplessità tal-ħin *O*(log(*n*)).
//! L-iċċekkjar tal-akbar element huwa *O*(1).Il-konverżjoni ta 'vector għal munzell binarju tista' ssir fil-post, u għandha kumplessità *O*(*n*).
//! Munzell binarju jista 'wkoll jiġi kkonvertit għal vector issortjat fil-post, li jippermettilu li jintuża għal *O*(*n*\*log(* n*)) fil-post heapsort.
//!
//! # Examples
//!
//! Dan huwa eżempju akbar li jimplimenta [Dijkstra's algorithm][dijkstra] biex isolvi [shortest path problem][sssp] fuq [directed graph][dir_graph].
//!
//! Juri kif tuża [`BinaryHeap`] ma 'tipi tad-dwana.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // Il-kju ta 'prijorità jiddependi fuq `Ord`.
//! // Implimenta b'mod espliċitu ż-trait sabiex il-kju jsir min-heap minflok max-heap.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // Innota li aħna naqilbu l-ordni fuq l-ispejjeż.
//!         // Fil-każ ta 'parità nqabblu pożizzjonijiet, dan il-pass huwa meħtieġ biex l-implimentazzjonijiet ta' `PartialEq` u `Ord` isiru konsistenti.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` jeħtieġ li jiġi implimentat ukoll.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // Kull nodu huwa rappreżentat bħala `usize`, għal implimentazzjoni iqsar.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // L-iqsar algoritmu tat-triq ta 'Dijkstra.
//!
//! // Ibda minn `start` u uża `dist` biex issegwi l-iqsar distanza kurrenti għal kull nodu.Din l-implimentazzjoni mhix effiċjenti fil-memorja għax tista 'tħalli nodi duplikati fil-kju.
//! //
//! // Juża wkoll `usize::MAX` bħala valur sentinella, għal implimentazzjoni aktar sempliċi.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [node]=l-iqsar distanza kurrenti minn `start` sa `node`
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // Aħna qegħdin f `start`, bi spiża żero
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // Eżamina l-fruntiera b'nodi ta 'spejjeż aktar baxxi l-ewwel (min-heap)
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // Inkella stajna komplejna nsibu l-iqsar toroq kollha
//!         if position == goal { return Some(cost); }
//!
//!         // Importanti għax forsi diġà sibna mod aħjar
//!         if cost > dist[position] { continue; }
//!
//!         // Għal kull nodu li nistgħu nilħqu, ara jekk nistgħux insibu mod bi spiża aktar baxxa għaddej minn dan in-nodu
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // Jekk iva, żidha mal-fruntiera u kompli
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // Rilassament, issa sibna mod aħjar
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // Mira mhux milħuqa
//!     None
//! }
//!
//! fn main() {
//!     // Din hija l-grafika diretta li se nużaw.
//!     // In-numri tan-nodi jikkorrispondu għall-istati differenti, u l-piżijiet edge jissimbolizzaw l-ispiża biex wieħed jimxi minn nodu għal ieħor.
//!     //
//!     // Innota li t-truf huma f'direzzjoni waħda.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // Il-graff huwa rrappreżentat bħala lista ta `adjaċenza fejn kull indiċi, li jikkorrispondi għal valur ta` nodu, għandu lista ta `trufijiet li joħorġu.
//!     // Magħżul għall-effiċjenza tiegħu.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // Nodu 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // Nodu 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // Nodu 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // Nodu 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // Nodu 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// Kju ta 'prijorità implimentat b'munzell binarju.
///
/// Dan se jkun max-borġ.
///
/// Huwa żball loġiku li oġġett jiġi modifikat b'tali mod li l-ordni tal-oġġett relattiv għal kwalunkwe oġġett ieħor, kif determinat mix-`Ord` trait, jinbidel waqt li jkun fil-borġ.
///
/// Dan normalment huwa possibbli biss permezz ta `Cell`, `RefCell`, stat globali, I/O, jew kodiċi mhux sikur.
/// L-imġieba li tirriżulta minn żball loġiku bħal dan mhix speċifikata, iżda ma tirriżultax f'imġieba mhux definita.
/// Dan jista 'jinkludi panics, riżultati skorretti, abort, tnixxijiet tal-memorja, u non-terminazzjoni.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // L-inferenza tat-tip tħallina nħallu barra firma espliċita tat-tip (li tkun `BinaryHeap<i32>` f'dan l-eżempju).
/////
/// let mut heap = BinaryHeap::new();
///
/// // Nistgħu nużaw peek biex inħarsu lejn l-oġġett li jmiss fil-borġ.
/// // F'dan il-każ, għad m'hemm l-ebda oġġetti hemmhekk allura ma jkollna Xejn.
/// assert_eq!(heap.peek(), None);
///
/// // Ejja nżidu xi punteġġi ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // Issa peek turi l-iktar oġġett importanti fil-borġ.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // Nistgħu niċċekkjaw it-tul ta 'borġ.
/// assert_eq!(heap.len(), 3);
///
/// // Nistgħu nirrepetu fuq l-oġġetti fil-borġ, għalkemm jiġu rritornati f'ordni każwali.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // Jekk minflok nippopjaw dawn il-punteġġi, għandhom jerġgħu lura fl-ordni.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // Nistgħu niċċaraw il-borġ ta 'kwalunkwe oġġett li jifdal.
/// heap.clear();
///
/// // Il-borġ issa għandu jkun vojt.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// Jew `std::cmp::Reverse` jew implimentazzjoni tad-dwana `Ord` jistgħu jintużaw biex jagħmlu `BinaryHeap` min-borġ.
/// Dan jagħmel lil `heap.pop()` jirritorna l-iżgħar valur minflok l-akbar wieħed.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // Kebbeb il-valuri f `Reverse`
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // Jekk aħna pop dawn il-punteġġi issa, għandhom jiġu lura fl-ordni invers.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # Kumplessità tal-ħin
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// Il-valur għal `push` huwa spiża mistennija;id-dokumentazzjoni tal-metodu tagħti analiżi aktar dettaljata.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// Struttura li tgeżwer referenza li tista 'tinbidel għall-akbar oġġett fuq `BinaryHeap`.
///
///
/// Dan `struct` huwa maħluq bil-metodu [`peek_mut`] fuq [`BinaryHeap`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // SIGURTÀ: PeekMut hija istanzjata biss għal munzelli mhux vojta.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // SAFE: PeekMut huwa istanzjat biss għal munzelli mhux vojta
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // SAFE: PeekMut huwa istanzjat biss għal munzelli mhux vojta
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// Neħħi l-valur peeked mill-borġ u jirritornah.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// Joħloq `BinaryHeap<T>` vojt.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// Joħloq `BinaryHeap` vojt bħala max-borġ.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// Joħloq `BinaryHeap` vojt b'kapaċità speċifika.
    /// Dan jalloka minn qabel biżżejjed memorja għal elementi `capacity`, sabiex ix-`BinaryHeap` ma jkollux għalfejn jiġi riallokat sakemm ikun fih mill-inqas dawk il-valuri.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// Jirritorna referenza li tista 'tinbidel għall-akbar oġġett fil-borġ binarju, jew `None` jekk ikun vojt.
    ///
    /// Note: Jekk il-valur `PeekMut` jitferra, il-borġ jista 'jkun fi stat inkonsistenti.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # Kumplessità tal-ħin
    ///
    /// Jekk l-oġġett jiġi modifikat allura l-agħar każ ta 'kumplessità tal-ħin huwa *O*(log(*n*)), inkella huwa *O*(1).
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// Neħħi l-akbar oġġett mill-borġ binarju u jirritornah, jew `None` jekk ikun vojt.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # Kumplessità tal-ħin
    ///
    /// L-agħar spiża ta `pop` fuq borġ li fih *n* elementi hija *O*(log(*n*)).
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // SIGURTÀ: !self.is_empty() tfisser li self.len()> 0
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// Imbotta oġġett fuq il-borġ binarju.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # Kumplessità tal-ħin
    ///
    /// L-ispiża mistennija ta `push`, medja fuq kull ordni possibbli ta' l-elementi li qed jiġu mbuttati, u fuq numru kbir biżżejjed ta 'imbuttar, hija *O*(1).
    ///
    /// Din hija l-ispiża metrika l-iktar sinifikanti meta timbotta elementi li *mhumiex* diġà fi kwalunkwe mudell magħżul.
    ///
    /// Il-kumplessità tal-ħin tiddegrada jekk l-elementi jiġu mbuttati f'ordni predominantement axxendenti.
    /// Fl-agħar każ, l-elementi jiġu mbuttati f'ordni axxendenti magħżula u l-ispiża amortizzata għal kull imbuttatura hija *O*(log(*n*)) kontra borġ li fih *n* elementi.
    ///
    /// L-agħar spiża ta 'sejħa *waħda* għal `push` hija *O*(*n*).L-agħar każ iseħħ meta l-kapaċità hija eżawrita u teħtieġ daqs mill-ġdid.
    /// L-ispiża tad-daqs mill-ġdid ġiet amortizzata fiċ-ċifri preċedenti.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // SIGURTÀ: Peress li mbuttajna oġġett ġdid dan ifisser li
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// Jikkonsma `BinaryHeap` u jirritorna vector f'ordni (ascending) magħżula.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // SIGURTÀ: `end` imur minn `self.len() - 1` għal 1 (it-tnejn inklużi),
            //  allura huwa dejjem indiċi validu għall-aċċess.
            //  Huwa sigur li taċċessa l-indiċi 0 (jiġifieri `ptr`), minħabba li
            //  1 <=tmiem <self.len(), li jfisser self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // SIGURTÀ: `end` imur minn `self.len() - 1` għal 1 (it-tnejn inklużi) u għalhekk:
            //  0 <1 <=tmiem <= self.len(), 1 <self.len() Li jfisser 0 <tmiem u tmiem <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // L-implimentazzjonijiet ta 'sift_up u sift_down jużaw blokki mhux siguri sabiex iċċaqalqu element barra miż-vector (li jħallu warajhom toqba), ibiddlu tul l-oħrajn u mexxu l-element imneħħi lura fiż-vector fil-post finali tat-toqba.
    //
    // It-tip `Hole` jintuża biex jirrappreżenta dan, u kun żgur li t-toqba timtela lura fit-tarf tal-ambitu tagħha, anke fuq panic.
    // L-użu ta 'toqba tnaqqas il-fattur kostanti meta mqabbel ma' l-użu ta 'swaps, li jinvolvi d-doppju ta' ċaqliq.
    //
    //
    //
    //

    /// # Safety
    ///
    /// Min iċempel għandu jiggarantixxi li `pos < self.len()`.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // Oħroġ il-valur f `pos` u oħloq toqba.
        // SIGURTÀ: Min iċempel jiggarantixxi li pos <self.len()
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // SIGURTÀ: hole.pos()> start>=0, li jfisser hole.pos()> 0
            //  u allura hole.pos(), 1 ma nistax nixxef.
            //  Dan jiggarantixxi li l-ġenitur <hole.pos() allura huwa indiċi validu u wkoll!= hole.pos().
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // SIGURTÀ: L-istess bħal hawn fuq
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// Ħu element f `pos` u mexxih 'l isfel mill-borġ, waqt li t-tfal tiegħu huma akbar.
    ///
    ///
    /// # Safety
    ///
    /// Min iċempel għandu jiggarantixxi li `pos < end <= self.len()`.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // SIGURTÀ: Min iċempel jiggarantixxi li pos <end <= self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariant tal-linja: tifel==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // qabbel mal-akbar miż-żewġt itfal SIGURTÀ: tifel <tmiem, 1 <self.len() u tifel + 1 <tmiem <= self.len(), allura huma indiċi validi.
            //
            //  tifel==2 *hole.pos() + 1!= hole.pos() u tifel + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: 2 *hole.pos() + 1 jew 2* hole.pos() + 2 jistgħu jegħlbu jekk T hija ZST
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // jekk aħna diġà fl-ordni, waqqaf.
            // SIGURTÀ: it-tifel issa huwa jew it-tifel il-qadim jew it-tifel il-qadim + 1
            //  Aħna diġà ppruvajna li t-tnejn huma <self.len() u!= hole.pos()
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // SIGURTÀ: l-istess bħal hawn fuq.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // SIGURTÀ: &&short circuit, li jfisser li fil-
        //  it-tieni kundizzjoni huwa diġà minnu li t-tifel==tmiem, 1 <self.len().
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // SIGURTÀ: it-tifel diġà ġie ppruvat li huwa indiċi validu u
            //  tifel==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// Min iċempel għandu jiggarantixxi li `pos < self.len()`.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // SIGURTÀ: pos <len huwa garantit minn min iċempel u
        //  ovvjament len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// Ħu element f `pos` u mċaqlaq it-triq kollha 'l isfel mill-borġ, imbagħad għarbel sal-pożizzjoni tiegħu.
    ///
    ///
    /// Note: Dan huwa aktar mgħaġġel meta l-element huwa magħruf li huwa kbir/għandu jkun eqreb lejn il-qiegħ.
    ///
    /// # Safety
    ///
    /// Min iċempel għandu jiggarantixxi li `pos < self.len()`.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // SIGURTÀ: Min iċempel jiggarantixxi li pos <self.len().
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // Invariant tal-linja: tifel==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // SIGURTÀ: tifel <tmiem, 1 <self.len() u
            //  tifel + 1 <tmiem <= self.len(), allura huma indiċi validi.
            //  tifel==2 *hole.pos() + 1!= hole.pos() u tifel + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: 2 *hole.pos() + 1 jew 2* hole.pos() + 2 jistgħu jegħlbu jekk T hija ZST
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // SIGURTÀ: L-istess bħal hawn fuq
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // SIGURTÀ: tifel==tmiem, 1 <self.len(), allura huwa indiċi validu
            //  u tifel==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // SIGURTÀ: pos hija l-pożizzjoni fit-toqba u kienet diġà ppruvata
        //  li jkun indiċi validu.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // SIGURTÀ: n jibda minn self.len()/2 u jinżel għal 0.
            //  L-uniku każ meta! (N <self.len()) huwa jekk self.len() ==0, iżda huwa eskluż mill-kundizzjoni tal-linja.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// Iċċaqlaq l-elementi kollha ta `other` f `self`, u jħalli `other` vojt.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` jieħu operazzjonijiet O(len1 + len2) u madwar 2 *(len1 + len2) paraguni fl-agħar każ filwaqt li `extend` jieħu operazzjonijiet O(len2* log(len1)) u madwar 1 *len2* log_2(len1) paraguni fl-agħar każ, jekk wieħed jassumi len1>= len2.
        // Għal munzelli akbar, il-punt ta 'crossover m'għadux isegwi dan ir-raġunament u ġie determinat b'mod empiriku.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// Jirritorna iteratur li jirkupra elementi f'ordni ta 'borġ.
    /// L-elementi rkuprati jitneħħew mill-borġ oriġinali.
    /// L-elementi li jifdal jitneħħew mal-waqgħa fl-ordni tal-borġ.
    ///
    /// Note:
    /// * `.drain_sorted()` huwa *O*(*n*\*log(* n*)); ħafna aktar bil-mod minn `.drain()`.
    ///   Għandek tuża dan tal-aħħar għal ħafna każijiet.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // tneħħi l-elementi kollha f'ordni ta 'borġ
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// Iżomm biss l-elementi speċifikati mill-predikat.
    ///
    /// Fi kliem ieħor, neħħi l-elementi kollha `e` b'tali mod li `f(&e)` jirritorna `false`.
    /// L-elementi jiġu miżjura f'ordni mhux magħżula (u mhux speċifikata).
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // żomm biss numri pari
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// Jirritorna iteratur li jżur il-valuri kollha fiż-vector sottostanti, f'ordni arbitrarja.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Stampa 1, 2, 3, 4 f'ordni arbitrarja
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// Jirritorna iteratur li jirkupra elementi f'ordni ta 'borġ.
    /// Dan il-metodu jikkonsma l-borġ oriġinali.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// Jirritorna l-akbar oġġett fil-borġ binarju, jew `None` jekk ikun vojt.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # Kumplessità tal-ħin
    ///
    /// L-ispiża hija *O*(1) fl-agħar każ.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// Jirritorna n-numru ta 'elementi li l-borġ binarju jista' jżomm mingħajr riallokazzjoni.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// Jirriżerva l-kapaċità minima għal eżattament `additional` aktar elementi biex jiddaħħlu fix-`BinaryHeap` mogħti.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà suffiċjenti.
    ///
    /// Innota li l-allokatur jista 'jagħti lill-kollezzjoni aktar spazju milli jitlob.
    /// Għalhekk il-kapaċità ma tistax tiġi invokata biex tkun preċiżament minima.
    /// Ippreferi [`reserve`] jekk huma mistennija inserzjonijiet future.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida tfur `usize`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// Jirriżerva kapaċità għal mill-inqas `additional` aktar elementi biex jiddaħħlu fix-`BinaryHeap`.
    /// Il-kollezzjoni tista 'tirriżerva aktar spazju biex tevita riallokazzjonijiet frekwenti.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida tfur `usize`.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// Armi kemm jista 'jkun kapaċità addizzjonali.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// Tarmi l-kapaċità b'limitu ta 'isfel.
    ///
    /// Il-kapaċità tibqa 'mill-inqas kbira kemm tat-tul kif ukoll tal-valur fornut.
    ///
    ///
    /// Jekk il-kapaċità kurrenti hija inqas mil-limitu l-iktar baxx, dan huwa no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// Jikkonsma `BinaryHeap` u jirritorna ż-vector sottostanti f'ordni arbitrarja.
    ///
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // Se tipprintja f'xi ordni
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// Jirritorna t-tul tal-borġ binarju.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// Jiċċekkja jekk il-borġ binarju huwiex vojt.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Tħassar il-borġ binarju, u tirritorna iteratur fuq l-elementi mneħħija.
    ///
    /// L-elementi jitneħħew f'ordni arbitrarja.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// Waqqa 'l-oġġetti kollha mill-borġ binarju.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// Toqba tirrappreżenta toqba fi porzjon ie, indiċi mingħajr valur validu (minħabba li ġie mċaqlaq minn jew idduplikat).
///
/// Fil-qatra, `Hole` jirrestawra l-porzjon billi jimla l-pożizzjoni tat-toqba bil-valur li oriġinarjament tneħħa.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// Oħloq `Hole` ġdid fl-indiċi `pos`.
    ///
    /// Mhux sikur minħabba li pos trid tkun fi ħdan il-porzjon tad-dejta.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // SIGUR: il-pos għandu jkun ġewwa l-porzjon
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// Jirritorna referenza għall-element imneħħi.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// Jirritorna referenza għall-element f `index`.
    ///
    /// Mhux sigur minħabba li l-indiċi għandu jkun fil-porzjon tad-dejta u mhux ugwali għal pos.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// Mexxi t-toqba għal post ġdid
    ///
    /// Mhux sigur minħabba li l-indiċi għandu jkun fil-porzjon tad-dejta u mhux ugwali għal pos.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // imla t-toqba mill-ġdid
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// Iteratur fuq l-elementi ta `BinaryHeap`.
///
/// Dan `struct` huwa maħluq minn [`BinaryHeap::iter()`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) Neħħi favur `#[derive(Clone)]`
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// Iteratur proprjetarju fuq l-elementi ta `BinaryHeap`.
///
/// Dan ix-`struct` huwa maħluq minn [`BinaryHeap::into_iter()`] (ipprovdut mix-`IntoIterator` trait).
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// Iteratur li jbattal fuq l-elementi ta `BinaryHeap`.
///
/// Dan `struct` huwa maħluq minn [`BinaryHeap::drain()`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// Iteratur li jbattal fuq l-elementi ta `BinaryHeap`.
///
/// Dan `struct` huwa maħluq minn [`BinaryHeap::drain_sorted()`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// Tneħħi l-elementi tal-borġ fl-ordni tal-borġ.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// Ikkonverti `Vec<T>` f `BinaryHeap<T>`.
    ///
    /// Din il-konverżjoni sseħħ fil-post, u għandha kumplessità ta 'ħin *O*(*n*).
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// Ikkonverti `BinaryHeap<T>` f `Vec<T>`.
    ///
    /// Din il-konverżjoni ma teħtieġ l-ebda moviment jew allokazzjoni tad-dejta, u għandha kumplessità kostanti tal-ħin.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Joħloq iteratur li jikkonsma, jiġifieri, wieħed li jċaqlaq kull valur barra mill-borġ binarju f'ordni arbitrarja.
    /// Il-borġ binarju ma jistax jintuża wara li ssejjaħ dan.
    ///
    /// # Examples
    ///
    /// Użu bażiku:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // Stampa 1, 2, 3, 4 f'ordni arbitrarja
    /// for x in heap.into_iter() {
    ///     // x għandu tip i32, mhux &i32
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}