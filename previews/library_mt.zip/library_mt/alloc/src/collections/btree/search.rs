use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Inklużiv li għandek tfittex, bħal `Bound::Included(T)`.
    Included(T),
    /// Xejn esklussiv li tfittex, bħal `Bound::Excluded(T)`.
    Excluded(T),
    /// Rabta inklussiva inkondizzjonata, l-istess bħal `Bound::Unbounded`.
    AllIncluded,
    /// Rabta esklussiva mingħajr kundizzjonijiet.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Iħares ċavetta partikolari f '(sub) siġra mmexxija min-nodu, b'mod rikursiv.
    /// Jirritorna `Found` bil-manku tal-KV li jaqbel, jekk hemm.
    /// Inkella, jirritorna `GoDown` bil-manku tal-werqa edge fejn tappartjeni ċ-ċavetta.
    ///
    /// Ir-riżultat huwa sinifikanti biss jekk is-siġra tkun ordnata biċ-ċavetta, bħalma hi s-siġra f `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Jinżel għall-eqreb nodu fejn iż-edge li taqbel mal-limitu ta 'isfel tal-firxa huwa differenti miż-edge li jaqbel mal-limitu ta' fuq, jiġifieri, l-eqreb node li għandu mill-inqas ċavetta waħda fil-medda.
    ///
    ///
    /// Jekk jinstab, jirritorna `Ok` ma 'dak in-nodu, il-par ta' indiċi edge fih jiddelimita l-firxa, u l-par korrispondenti ta 'limiti biex titkompla t-tfittxija fin-nodi tfal, f'każ li n-nodu jkun intern.
    ///
    /// Jekk ma tinstabx, tirritorna `Err` bil-werqa edge li taqbel mal-firxa kollha.
    ///
    /// Ir-riżultat huwa sinifikanti biss jekk is-siġra tkun ordnata biċ-ċavetta.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // L-inklużjoni ta 'dawn il-varjabbli għandha tiġi evitata.
        // Aħna nassumu li l-limiti rrappurtati minn `range` jibqgħu l-istess, iżda implimentazzjoni kontradittorja tista 'tinbidel bejn is-sejħiet (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Isib edge fin-nodu li jiddelimita l-limitu t'isfel ta 'firxa.
    /// Jirritorna wkoll il-limitu l-aktar baxx li għandu jintuża biex titkompla t-tfittxija fin-nodu tat-tfal li jaqbel, jekk `self` huwa nodu intern.
    ///
    ///
    /// Ir-riżultat huwa sinifikanti biss jekk is-siġra tkun ordnata biċ-ċavetta.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klonu ta `find_lower_bound_edge` għall-limitu ta' fuq.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Iħares ċavetta partikolari fin-nodu, mingħajr rikursjoni.
    /// Jirritorna `Found` bil-manku tal-KV li jaqbel, jekk hemm.
    /// Inkella, jirritorna `GoDown` bil-manku taż-edge fejn iċ-ċavetta tista 'tinstab (jekk in-nodu huwa intern) jew fejn iċ-ċavetta tista' tiddaħħal.
    ///
    ///
    /// Ir-riżultat huwa sinifikanti biss jekk is-siġra tkun ordnata biċ-ċavetta, bħalma hi s-siġra f `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Jirritorna jew l-indiċi KV fin-nodu li fih teżisti ċ-ċavetta (jew ekwivalenti), jew l-indiċi edge fejn tappartjeni ċ-ċavetta.
    ///
    ///
    /// Ir-riżultat huwa sinifikanti biss jekk is-siġra tkun ordnata biċ-ċavetta, bħalma hi s-siġra f `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Isib indiċi edge fin-nodu li jiddelimita l-limitu ta 'isfel ta' firxa.
    /// Jirritorna wkoll il-limitu l-aktar baxx li għandu jintuża biex titkompla t-tfittxija fin-nodu tat-tfal li jaqbel, jekk `self` huwa nodu intern.
    ///
    ///
    /// Ir-riżultat huwa sinifikanti biss jekk is-siġra tkun ordnata biċ-ċavetta.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klonu ta `find_lower_bound_index` għall-limitu ta' fuq.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}