use core::marker::PhantomData;
use core::ptr::NonNull;

/// Mudelli reborrow ta 'xi referenza unika, meta taf li l-reborrow u d-dixxendenti kollha tagħha (jiġifieri, l-indikaturi u r-referenzi kollha derivati minnha) ma jintużawx aktar f'xi punt, u wara trid terġa' tuża r-referenza unika oriġinali .
///
///
/// Il-kontrollur li jissellef ġeneralment jimmaniġġa dan l-istivar ta 'tissellef għalik, iżda xi flussi ta' kontroll li jwettqu dan l-istivar huma kkumplikati wisq biex il-kompilatur isegwi.
/// `DormantMutRef` jippermettilek tiċċekkja s-self lilek innifsek, filwaqt li xorta tesprimi n-natura f'munzelli tagħha, u tiġbor il-kodiċi tal-pointer nej meħtieġ biex tagħmel dan mingħajr imġieba mhux definita.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Aqbad tissellef uniku, u terġa 'tieħuha mill-ġdid.
    /// Għall-kompilatur, il-ħajja tar-referenza l-ġdida hija l-istess bħall-ħajja tar-referenza oriġinali, imma int promise biex tużaha għal perjodu iqsar.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SIGURTÀ: aħna nżommu s-self matul 'a permezz ta' `_marker`, u nesponu
        // din ir-referenza biss, allura hija unika.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Erġa 'lura għas-self uniku li nqabad inizjalment.
    ///
    /// # Safety
    ///
    /// Ir-rifużjoni trid tkun intemmet, jiġifieri, ir-referenza mogħtija minn `new` u l-indikaturi u r-referenzi kollha derivati minnha, m'għandhomx jintużaw aktar.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SIGURTÀ: il-kundizzjonijiet ta 'sigurtà tagħna stess jimplikaw li din ir-referenza hija għal darb'oħra unika.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;