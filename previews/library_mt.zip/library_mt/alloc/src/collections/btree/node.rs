// Dan huwa tentattiv ta 'implimentazzjoni wara l-ideal
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Peress li Rust fil-fatt m'għandux tipi dipendenti u rikursjoni polimorfa, aħna nagħmlu ħafna affarijiet mhux siguri.
//

// Għan ewlieni ta 'dan il-modulu huwa li tevita l-kumplessità billi tittratta s-siġra bħala kontenitur ġeneriku (jekk ikun iffurmat b'mod stramb) u tevita li tittratta ma' ħafna mill-invarianti tas-Siġar B.
//
// Bħala tali, dan il-modulu ma jimpurtax jekk l-entrati humiex magħżula, liema nodi jistgħu jkunu underfull, jew saħansitra xi jfisser underfull.Madankollu, aħna niddependu fuq ftit invariants:
//
// - Is-siġar għandu jkollhom depth/height uniformi.Dan ifisser li kull passaġġ sa weraq minn nodu partikolari għandu eżattament l-istess tul.
// - Nodu ta 'tul `n` għandu ċwievet `n`, valuri `n`, u truf `n + 1`.
//   Dan jimplika li anke nodu vojt għandu mill-inqas edge wieħed.
//   Għal nodu tal-weraq, "having an edge" ifisser biss li nistgħu nidentifikaw pożizzjoni fin-nodu, billi t-truf tal-weraq huma vojta u m'għandhom bżonn l-ebda rappreżentazzjoni tad-dejta.
// F'nodu intern, edge it-tnejn jidentifika pożizzjoni u fih pointer għal node tfal.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Ir-rappreżentazzjoni sottostanti tan-nodi tal-weraq u parti mir-rappreżentazzjoni tan-nodi interni.
struct LeafNode<K, V> {
    /// Irridu nkunu varjabbli f `K` u `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// L-indiċi ta 'dan in-nodu fil-firxa `edges` tan-nodu ġenitur.
    /// `*node.parent.edges[node.parent_idx]` għandu jkun l-istess ħaġa bħal `node`.
    /// Dan huwa garantit biss li jiġi inizjalizzat meta `parent` mhuwiex null.
    parent_idx: MaybeUninit<u16>,

    /// In-numru ta 'ċwievet u valuri li jaħżen dan in-nodu.
    len: u16,

    /// L-arranġamenti li jaħżnu d-dejta attwali tan-nodu.
    /// L-ewwel elementi `len` biss ta 'kull array huma inizjalizzati u validi.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inizjalizza `LeafNode` ġdid fil-post.
    unsafe fn init(this: *mut Self) {
        // Bħala politika ġenerali, inħallu l-oqsma mhux inizjalizzati jekk jistgħu jkunu, għax dan għandu jkun kemmxejn aktar mgħaġġel u aktar faċli biex jintraċċaw f'Valgrind.
        //
        unsafe {
            // parent_idx, keys, u vals huma kollha MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Toħloq `LeafNode` kaxxa ġdida.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Ir-rappreżentazzjoni sottostanti tan-nodi interni.Bħal fil-każ ta '' LeafNode`s, dawn għandhom ikunu moħbija wara 'BoxedNode`s biex ma jħallux li tinżel ċwievet u valuri mhux inizjalizzati.
/// Kwalunkwe pointer għal `InternalNode` jista 'jiġi direttament mitfugħ fuq pointer għall-porzjon sottostanti `LeafNode` tan-nodu, li jippermetti kodiċi li jaġixxi fuq weraq u nodi interni ġenerikament mingħajr ma jkollu għalfejn jiċċekkja lil liema mit-tnejn qed jindika pointer.
///
/// Din il-proprjetà hija attivata bl-użu ta `repr(C)`.
///
#[repr(C)]
// gdb_providers.py juża dan l-isem tat-tip għall-introspezzjoni.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// L-indikazzjonijiet għat-tfal ta 'dan in-nodu.
    /// `len + 1` minn dawn huma kkunsidrati inizjalizzati u validi, ħlief li qrib it-tmiem, filwaqt li s-siġra tinżamm permezz ta 'tip ta' self `Dying`, uħud minn dawn il-indikaturi huma mdendlin.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Toħloq `InternalNode` kaxxa ġdida.
    ///
    /// # Safety
    /// Invariant ta 'nodi interni huwa li għandhom mill-inqas edge inizjalizzat u validu wieħed.
    /// Din il-funzjoni ma twaqqafx tali edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Għandna bżonn biss li nibdew id-dejta;it-truf huma MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Pointer ġestit, mhux null għal nodu.Dan huwa jew pointer ta 'proprjetà għal `LeafNode<K, V>` jew pointer ta' proprjetà għal `InternalNode<K, V>`.
///
/// Madankollu, `BoxedNode` ma fih l-ebda informazzjoni dwar liema miż-żewġ tipi ta 'nodi fil-fatt fih, u, parzjalment minħabba dan in-nuqqas ta' informazzjoni, mhuwiex tip separat u m'għandux distruttur.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// In-nodu ta 'l-għerq ta' siġra proprjetà.
///
/// Innota li dan m'għandux distruttur, u għandu jitnaddaf manwalment.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Jirritorna siġra ta 'proprjetà ġdida, bin-node ta' l-għerq tagħha stess li inizjalment hija vojta.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` m'għandux ikun żero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Jissellef b'mod reċiproku n-nodu ta 'l-għerq li huwa proprjetà.
    /// B'differenza minn `reborrow_mut`, dan huwa sigur għax il-valur tar-ritorn ma jistax jintuża biex jeqred l-għerq, u ma jistax ikun hemm referenzi oħra għas-siġra.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Jissellef kemmxejn b'mod mutabbli l-għoqda ta 'l-għerq tal-proprjetà.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Tranżizzjonijiet irriversibbli għal referenza li tippermetti l-ġirja u toffri metodi distruttivi u ftit iktar.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Iżżid nodu intern ġdid b'edge wieħed li jindika n-nodu ta 'l-għerq preċedenti, agħmel dak in-nodu ġdid in-nodu ta' l-għerq, u rritornah.
    /// Dan iżid l-għoli b'1 u huwa l-oppost ta `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ħlief li aħna nsejna li aħna interni issa:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Tneħħi n-nodu ta 'l-għerq intern, billi tuża l-ewwel wild tagħha bħala n-nodu ta' l-għerq il-ġdid.
    /// Peress li huwa maħsub li jissejjaħ biss meta n-node ta 'l-għeruq ikollu tifel wieħed biss, ma ssir l-ebda tindif fuq xi waħda mill-imfietaħ, valuri u tfal oħra.
    ///
    /// Dan inaqqas l-għoli b'1 u huwa l-oppost ta `push_internal_level`.
    ///
    /// Jeħtieġ aċċess esklussiv għall-oġġett `Root` iżda mhux għan-node ta 'l-għerq;
    /// mhux se jinvalida manki oħra jew referenzi għan-node ta 'l-għerq.
    ///
    /// Panics jekk m'hemm l-ebda livell intern, jiġifieri, jekk in-nodu ta 'l-għerq huwa werqa.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SIGURTÀ: affermajna li aħna interni.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SIGURTÀ: aħna nissellfu `self` esklussivament u t-tip ta 'self tiegħu huwa esklussiv.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SIGURTÀ: l-ewwel edge huwa dejjem inizjalizzat.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` huwa dejjem varjabbli f `K` u `V`, anke meta l-`BorrowType` huwa `Mut`.
// Dan huwa teknikament ħażin, iżda ma jista 'jirriżulta f'ebda sikurezza minħabba użu intern ta' `NodeRef` minħabba li nibqgħu kompletament ġeneriċi fuq `K` u `V`.
//
// Madankollu, kull meta tip pubbliku jdawwar `NodeRef`, kun żgur li għandu l-varjanza korretta.
//
/// Referenza għal nodu.
///
/// Dan it-tip għandu numru ta 'parametri li jikkontrollaw kif taġixxi:
/// - `BorrowType`: Tip ta 'manikin li jiddeskrivi t-tip ta' self u jġorr ħajtu.
///    - Meta dan huwa `Immut<'a>`, ix-`NodeRef` jaġixxi bejn wieħed u ieħor bħal `&'a Node`.
///    - Meta dan huwa `ValMut<'a>`, ix-`NodeRef` jaġixxi bejn wieħed u ieħor bħal `&'a Node` fir-rigward taċ-ċwievet u l-istruttura tas-siġra, iżda jippermetti wkoll li jikkoeżistu ħafna referenzi li jistgħu jinbidlu għal valuri fis-siġra kollha.
///    - Meta dan huwa `Mut<'a>`, ix-`NodeRef` jaġixxi bejn wieħed u ieħor bħal `&'a mut Node`, għalkemm metodi ta 'inserzjoni jippermettu li jkoeżistu pointer mutabbli għal valur.
///    - Meta dan huwa `Owned`, ix-`NodeRef` jaġixxi bejn wieħed u ieħor bħal `Box<Node>`, iżda m'għandux distruttur, u għandu jitnaddaf manwalment.
///    - Meta dan huwa `Dying`, ix-`NodeRef` xorta jaġixxi bejn wieħed u ieħor bħal `Box<Node>`, iżda għandu metodi biex jeqred is-siġra bit bit, u metodi ordinarji, filwaqt li mhumiex immarkati bħala perikolużi biex jitolbu, jistgħu jinvokaw UB jekk jissejħu ħażin.
///
///   Peress li kwalunkwe `NodeRef` jippermetti navigazzjoni permezz tas-siġra, `BorrowType` japplika b'mod effettiv għas-siġra kollha, mhux biss għan-nodu nnifsu.
/// - `K` u `V`: Dawn huma t-tipi ta 'ċwievet u valuri maħżuna fin-nodi.
/// - `Type`: Dan jista 'jkun `Leaf`, `Internal`, jew `LeafOrInternal`.
/// Meta dan huwa `Leaf`, ix-`NodeRef` jindika nodu tal-werqa, meta dan huwa `Internal` ix-`NodeRef` jindika nodu intern, u meta dan huwa `LeafOrInternal` ix-`NodeRef` jista 'jkun li jindika kwalunkwe tip ta' nodu.
///   `Type` jismu `NodeType` meta jintuża barra `NodeRef`.
///
/// Kemm `BorrowType` kif ukoll `NodeType` jirrestrinġu liema metodi nimplimentaw, biex nisfruttaw is-sigurtà tat-tip statiku.Hemm limitazzjonijiet fil-mod kif nistgħu napplikaw restrizzjonijiet bħal dawn:
/// - Għal kull parametru tat-tip, nistgħu niddefinixxu metodu jew ġenerikament jew għal tip partikolari wieħed.
/// Pereżempju, ma nistgħux niddefinixxu metodu bħal `into_kv` ġenerikament għax-`BorrowType` kollha, jew darba għat-tipi kollha li jġorru ħajjithom kollha, għaliex irridu li jirritorna referenzi `&'a`.
///   Għalhekk, aħna niddefinixxuh biss għat-tip `Immut<'a>` l-inqas qawwi.
/// - Ma nistgħux niksbu sfurzar impliċitu minn ngħidu aħna `Mut<'a>` sa `Immut<'a>`.
///   Għalhekk, irridu nsejħu b'mod espliċitu lil `reborrow` fuq `NodeRef` aktar qawwi sabiex nilħqu metodu bħal `into_kv`.
///
/// Il-metodi kollha fuq `NodeRef` li jirritornaw xi tip ta 'referenza, jew:
/// - Ħu `self` skont il-valur, u rritorna l-ħajja li ġġorr `BorrowType`.
///   Kultant, biex ninvokaw metodu bħal dan, għandna bżonn insejħu `reborrow_mut`.
/// - Ħu `self` b'referenza, u (implicitly) irritorna l-ħajja ta 'dik ir-referenza, minflok il-ħajja li ġġorr `BorrowType`.
/// B'dan il-mod, il-kontrollur tas-self jiggarantixxi li x-`NodeRef` jibqa 'misluf sakemm tintuża r-referenza mibgħuta lura.
///   Il-metodi li jappoġġjaw l-inserzjoni jgħawġu din ir-regola billi jirritornaw pointer mhux maħdum, jiġifieri, referenza mingħajr ebda ħajja.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// In-numru ta 'livelli li n-nodu u l-livell tal-weraq huma separati, kostanti tan-nodu li ma jistax jiġi deskritt kompletament minn `Type`, u li n-nodu nnifsu ma jaħżenx.
    /// Għandna bżonn biss naħżnu l-għoli tan-node ta 'l-għerq, u niksbu l-għoli ta' kull node ieħor minnha.
    /// Għandu jkun żero jekk `Type` huwa `Leaf` u mhux żero jekk `Type` huwa `Internal`.
    ///
    ///
    height: usize,
    /// Il-pointer lejn il-werqa jew in-nodu intern.
    /// Id-definizzjoni ta `InternalNode` tiżgura li l-pointer huwa validu b'kull mod.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Ippakkja referenza tan-nodu li kienet ippakkjata bħala `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Jesponi d-dejta ta 'nodu intern.
    ///
    /// Jirritorna ptr mhux ipproċessat biex jevita li jinvalida referenzi oħra għal dan in-nodu.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SIGURTÀ: it-tip ta 'nodu statiku huwa `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Jissellef aċċess esklussiv għad-dejta ta 'nodu intern.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Isib it-tul tan-nodu.Dan huwa n-numru ta 'ċwievet jew valuri.
    /// In-numru ta 'truf huwa `len() + 1`.
    /// Innota li, minkejja li huwa sigur, li ssejjaħ din il-funzjoni jista 'jkollha l-effett sekondarju li tinvalida referenzi li jistgħu jinbidlu li ħoloq kodiċi mhux sikur.
    ///
    pub fn len(&self) -> usize {
        // B`mod kruċjali, aħna nidħol biss fil-qasam `len` hawn.
        // Jekk BorrowType huwa marker::ValMut, jista 'jkun hemm referenzi mutabbli pendenti għal valuri li m'għandniex ninvalidaw.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Jirritorna n-numru ta 'livelli li n-nodu u l-weraq huma separati.
    /// Għoli żero ifisser li n-nodu huwa werqa nnifisha.
    /// Jekk timmaġina siġar bl-għerq fuq nett, in-numru jgħid f'liema elevazzjoni jidher in-nodu.
    /// Jekk timmaġina siġar bil-weraq fil-wiċċ, in-numru jgħid kemm hi għolja s-siġra testendi 'l fuq min-nodu.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Temporanjament toħroġ referenza oħra, immutabbli għall-istess nodu.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Jesponi l-porzjon tal-weraq ta 'kwalunkwe weraq jew nodu intern.
    ///
    /// Jirritorna ptr mhux ipproċessat biex jevita li jinvalida referenzi oħra għal dan in-nodu.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // In-nodu għandu jkun validu għal mill-inqas il-porzjon LeafNode.
        // Din mhix referenza fit-tip NodeRef għax ma nafux jekk għandhiex tkun unika jew kondiviża.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Isib il-ġenitur tan-nodu kurrenti.
    /// Jirritorna `Ok(handle)` jekk in-nodu kurrenti fil-fatt għandu ġenitur, fejn `handle` jindika ż-edge tal-ġenitur li jindika n-nodu kurrenti.
    ///
    /// Jirritorna `Err(self)` jekk in-nodu kurrenti m'għandux ġenitur, u jagħti lura l-`NodeRef` oriġinali.
    ///
    /// L-isem tal-metodu jassumi li timmaġina siġar bin-node ta 'l-għerq fuq nett.
    ///
    /// `edge.descend().ascend().unwrap()` u `node.ascend().unwrap().descend()` għandhom it-tnejn, wara suċċess, ma jagħmlu xejn.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Għandna bżonn nużaw indikaturi mhux ipproċessati għan-nodi għaliex, jekk BorrowType huwa marker::ValMut, jista 'jkun hemm referenzi mutabbli pendenti għal valuri li m'għandniex ninvalidaw.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Innota li `self` għandu jkun mhux vojt.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Innota li `self` għandu jkun mhux vojt.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Jesponi l-porzjon tal-weraq ta 'kwalunkwe werqa jew nodu intern f'siġra li ma tinbidilx.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SIGURTÀ: ma jistax ikun hemm referenzi mutabbli f'din is-siġra mislufa bħala `Immut`.
        unsafe { &*ptr }
    }

    /// Jissellef veduta fiċ-ċwievet maħżuna fin-nodu.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Simili għal `ascend`, jirċievi referenza għan-nodu ġenitur ta 'nodu, iżda jqassam ukoll in-nodu kurrenti fil-proċess.
    /// Dan mhuwiex sigur minħabba li n-nodu kurrenti xorta se jkun aċċessibbli minkejja li jkun ġie allokat mill-ġdid.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Jasserixxi b'mod sikur lill-kompilatur l-informazzjoni statika li dan in-nodu huwa `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Tasserixxi b'mod sikur lill-kompilatur l-informazzjoni statika li dan in-nodu huwa `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Temporanjament toħroġ referenza oħra li tista 'tinbidel għall-istess nodu.Oqgħod attent, billi dan il-metodu huwa perikoluż ħafna, hekk darbtejn peress li jista 'ma jidhirx perikoluż immedjatament.
    ///
    /// Minħabba li l-indikaturi li jistgħu jinbidlu jistgħu jimirħu kullimkien madwar is-siġra, il-pointer li jintbagħat lura jista 'jintuża faċilment biex il-pointer oriġinali jitbandal, barra mill-limiti, jew invalidu taħt ir-regoli ta' self f'munzelli.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) tikkunsidra li żżid parametru tat-tip ieħor ma `NodeRef` li jirrestrinġi l-użu ta' metodi ta 'navigazzjoni fuq indikaturi mġedda mill-ġdid, u jevita din in-nuqqas ta' sigurtà.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Jissellef aċċess esklussiv għall-porzjon tal-weraq ta 'kwalunkwe weraq jew nodu intern.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SIGURTÀ: għandna aċċess esklussiv għan-nodu kollu.
        unsafe { &mut *ptr }
    }

    /// Joffri aċċess esklussiv għall-porzjon tal-weraq ta 'kwalunkwe weraq jew nodu intern.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SIGURTÀ: għandna aċċess esklussiv għan-nodu kollu.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Jissellef aċċess esklussiv għal element taż-żona tal-ħażna taċ-ċavetta.
    ///
    /// # Safety
    /// `index` huwa fil-limiti ta '0..KAPAĊITÀ
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SIGURTÀ: min iċempel ma jkunx jista 'jċempel metodi oħra waħdu
        // sakemm titwaqqa 'r-referenza tal-porzjon taċ-ċavetta, peress li għandna aċċess uniku għall-ħajja tas-self.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Jissellef aċċess esklussiv għal element jew porzjon taż-żona tal-ħażna tal-valur tan-nodu.
    ///
    /// # Safety
    /// `index` huwa fil-limiti ta '0..KAPAĊITÀ
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SIGURTÀ: min iċempel ma jkunx jista 'jċempel metodi oħra waħdu
        // sakemm titwaqqa 'r-referenza tal-porzjon tal-valur, peress li għandna aċċess uniku għall-ħajja tas-self.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Jissellef aċċess esklussiv għal element jew porzjon taż-żona tal-ħażna tan-nodu għall-kontenuti edge.
    ///
    /// # Safety
    /// `index` huwa fil-limiti ta '0..KAPAĊITÀ + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SIGURTÀ: min iċempel ma jkunx jista 'jċempel metodi oħra waħdu
        // sakemm titwaqqa 'r-referenza tal-porzjon edge, peress li għandna aċċess uniku għal ħajjet is-self.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - In-nodu għandu aktar minn elementi inizjalizzati `idx`.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Aħna noħolqu biss referenza għall-element wieħed li aħna interessati fih, biex nevitaw li nagħmlu aliasing b'referenzi pendenti għal elementi oħra, b'mod partikolari, dawk mibgħuta lura lil min iċempel f'iterazzjonijiet preċedenti.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Irridu nġiegħlu lil pointers ta 'matriċi mhux imdaqqsa minħabba l-kwistjoni Rust #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Jissellef aċċess esklussiv għat-tul tan-nodu.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Issettja r-rabta tan-nodu mal-ġenitur tagħha edge, mingħajr ma tinvalida referenzi oħra għan-nodu.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Tħassar ir-rabta tal-għerq mal-ġenitur tagħha edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Iżżid par ċavetta-valur mat-tarf tan-nodu.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Kull oġġett mibgħut lura minn `range` huwa indiċi edge validu għan-nodu.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Iżżid par ċavetta-valur, u edge biex tmur fuq il-lemin ta 'dak il-par, sat-tarf tan-nodu.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Jiċċekkja jekk nodu huwiex nodu `Internal` jew nodu `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Referenza għal par speċifiku ta 'valur-ċavetta jew edge fi nodu.
/// Il-parametru `Node` għandu jkun `NodeRef`, filwaqt li `Type` jista 'jkun jew `KV` (li jindika manku fuq par ta' valur-ċavetta) jew `Edge` (li jindika manku fuq edge).
///
/// Innota li anke l-għoqiedi `Leaf` jista 'jkollhom manki `Edge`.
/// Minflok ma jirrappreżentaw pointer għal node tat-tfal, dawn jirrappreżentaw l-ispazji fejn il-pointers tat-tfal imorru bejn il-pari tal-valur taċ-ċavetta.
/// Pereżempju, f'nodu b'tul 2, ikun hemm 3 postijiet edge possibbli, wieħed fuq ix-xellug tan-nodu, wieħed bejn iż-żewġ pari, u wieħed fuq il-lemin tan-nodu.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// M'għandniex bżonn il-ġeneralità sħiħa ta `#[derive(Clone)]`, billi l-unika darba li `Node` se jkun "Klonu" jista' jkun meta tkun referenza immutabbli u għalhekk `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Irkupra n-nodu li fih iż-edge jew il-par valur-ċavetta li dan il-manku jindika.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Jirritorna l-pożizzjoni ta 'din il-manku fin-nodu.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Joħloq manku ġdid għal par valur-ċavetta f `node`.
    /// Mhux sigur għax min iċempel għandu jiżgura li `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Tista 'tkun implimentazzjoni pubblika ta' PartialEq, iżda użata biss f'dan il-modulu.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Temporanjament toħroġ manku ieħor immutabbli fuq l-istess post.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Ma nistgħux nużaw Handle::new_kv jew Handle::new_edge għax ma nafux it-tip tagħna
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Tasserixxi b'mod sikur lill-kompilatur l-informazzjoni statika li n-nodu tal-manku huwa `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Temporanjament toħroġ manku ieħor li jista 'jinbidel fuq l-istess post.
    /// Oqgħod attent, billi dan il-metodu huwa perikoluż ħafna, hekk darbtejn peress li jista 'ma jidhirx perikoluż immedjatament.
    ///
    ///
    /// Għad-dettalji, ara `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Ma nistgħux nużaw Handle::new_kv jew Handle::new_edge għax ma nafux it-tip tagħna
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Joħloq manku ġdid għal edge f `node`.
    /// Mhux sigur għax min iċempel għandu jiżgura li `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Minħabba indiċi edge fejn irridu ndaħħlu ġo nodu mimli sa kapaċità, jikkalkula indiċi KV sensibbli ta 'punt maqsum u fejn iwettaq l-inserzjoni.
///
/// L-għan tal-punt maqsum huwa li ċ-ċavetta u l-valur tiegħu jispiċċaw f'nodu ġenitur;
/// iċ-ċwievet, il-valuri u t-truf fuq ix-xellug tal-punt maqsum isiru t-tfal tax-xellug;
/// iċ-ċwievet, il-valuri u t-truf fuq il-lemin tal-punt maqsum isiru t-tfal it-tajbin.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Il-kwistjoni Rust #74834 tipprova tispjega dawn ir-regoli simetriċi.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Daħħal par ċavetta-valur ġdid bejn il-pari ċavetta-valur fuq il-lemin u x-xellug ta 'dan edge.
    /// Dan il-metodu jassumi li hemm biżżejjed spazju fin-nodu biex il-par il-ġdid joqgħod.
    ///
    /// Il-pointer imreġġa 'lura jindika l-valur imdaħħal.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Daħħal par ċavetta-valur ġdid bejn il-pari ċavetta-valur fuq il-lemin u x-xellug ta 'dan edge.
    /// Dan il-metodu jaqsam in-nodu jekk ma jkunx hemm biżżejjed spazju.
    ///
    /// Il-pointer imreġġa 'lura jindika l-valur imdaħħal.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Jiffissa l-pointer ġenitur u l-indiċi fin-node tat-tfal li dan edge jorbot miegħu.
    /// Dan huwa utli meta l-ordni tat-truf inbidlet,
    fn correct_parent_link(self) {
        // Oħloq backpointer mingħajr ma tinvalida referenzi oħra għan-nodu.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Daħħal par ġdid ta 'valur-ċavetta u edge li jmorru lejn il-lemin ta' dak il-par ġdid bejn dan edge u l-par ta 'valur-ċavetta fuq il-lemin ta' dan edge.
    /// Dan il-metodu jassumi li hemm biżżejjed spazju fin-nodu biex il-par il-ġdid joqgħod.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Daħħal par ġdid ta 'valur-ċavetta u edge li jmorru lejn il-lemin ta' dak il-par ġdid bejn dan edge u l-par ta 'valur-ċavetta fuq il-lemin ta' dan edge.
    /// Dan il-metodu jaqsam in-nodu jekk ma jkunx hemm biżżejjed spazju.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Daħħal par ċavetta-valur ġdid bejn il-pari ċavetta-valur fuq il-lemin u x-xellug ta 'dan edge.
    /// Dan il-metodu jaqsam in-nodu jekk ma jkunx hemm biżżejjed spazju, u jipprova jdaħħal il-porzjon maqsum fin-nodu ġenitur b'mod rikursiv, sakemm tintlaħaq l-għerq.
    ///
    ///
    /// Jekk ir-riżultat ritornat huwa `Fit`, in-nodu tal-manku tiegħu jista 'jkun in-nodu ta' dan edge jew antenat.
    /// Jekk ir-riżultat mibgħut lura huwa `Split`, il-qasam `left` ikun in-nodu ta 'l-għerq.
    /// Il-pointer imreġġa 'lura jindika l-valur imdaħħal.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Isib in-nodu indikat minn dan edge.
    ///
    /// L-isem tal-metodu jassumi li timmaġina siġar bin-node ta 'l-għerq fuq nett.
    ///
    /// `edge.descend().ascend().unwrap()` u `node.ascend().unwrap().descend()` għandhom it-tnejn, wara suċċess, ma jagħmlu xejn.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Għandna bżonn nużaw indikaturi mhux ipproċessati għan-nodi għaliex, jekk BorrowType huwa marker::ValMut, jista 'jkun hemm referenzi mutabbli pendenti għal valuri li m'għandniex ninvalidaw.
        // M'hemm l-ebda inkwiet li tidħol fil-qasam tal-għoli minħabba li dak il-valur huwa kkupjat.
        // Oqgħod attent li, ladarba l-pointer tan-node jiġi dereferenzjat, aħna nidħlu għall-firxa tat-truf b'referenza (Rust ħarġa #73987) u ninvalidaw kwalunkwe referenza oħra għal jew ġewwa l-firxa, jekk ikun hemm madwar.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Ma nistgħux insejħu metodi separati taċ-ċavetta u l-valur, minħabba li s-sejħa tat-tieni tinvalida r-referenza mogħtija mill-ewwel.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Ibdel iċ-ċavetta u l-valur li tirreferi għalih il-manku KV.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Jgħin l-implimentazzjoni ta `split` għal `NodeType` partikolari, billi jieħu ħsieb id-dejta tal-weraq.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Jaqsam in-nodu sottostanti fi tliet partijiet:
    ///
    /// - In-nodu huwa maqtugħ biex ikun fih biss il-pari ta 'valur ewlieni fuq ix-xellug ta' dan il-manku.
    /// - Iċ-ċavetta u l-valur indikati minn dan il-manku huma estratti.
    /// - Il-pari kollha tal-valur taċ-ċavetta fuq il-lemin ta 'dan il-manku jitqiegħdu f'nodu allokat ġdid.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Neħħi l-par tal-valur taċ-ċavetta indikat minn dan il-manku u jirritornaha, flimkien maż-edge li fih waqa 'l-par taċ-ċavetta-valur.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Jaqsam in-nodu sottostanti fi tliet partijiet:
    ///
    /// - In-nodu huwa maqtugħ biex ikun fih biss it-truf u l-pari ta 'valur ewlieni fuq ix-xellug ta' dan il-manku.
    /// - Iċ-ċavetta u l-valur indikati minn dan il-manku huma estratti.
    /// - It-truf u l-pari tal-valur taċ-ċavetta kollha fuq il-lemin ta 'dan il-manku jitqiegħdu f'nodu allokat ġdid.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Tirrappreżenta sessjoni għall-evalwazzjoni u t-twettiq ta 'operazzjoni ta' bbilanċjar madwar par intern valur-ċavetta.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Jagħżel kuntest ta 'bilanċ li jinvolvi n-nodu bħala tifel, u b'hekk bejn il-KV immedjatament lejn ix-xellug jew lejn il-lemin fin-nodu ġenitur.
    /// Jirritorna `Err` jekk ma jkunx hemm ġenitur.
    /// Panics jekk il-ġenitur huwa vojt.
    ///
    /// Tippreferi n-naħa tax-xellug, biex tkun l-aħjar jekk in-nodu mogħti jkun b'xi mod inqas tajjeb, li jfisser hawn biss li għandu inqas elementi mill-aħwa tax-xellug tiegħu u mill-aħwa tal-lemin tiegħu, jekk jeżistu.
    /// F'dak il-każ, l-għaqda mal-aħwa tax-xellug hija aktar mgħaġġla, peress li għandna bżonn biss li nimxu l-elementi N tan-nodu, minflok ma nċaqilquhom lejn il-lemin u nimxu aktar minn N elementi quddiem.
    /// Is-serq mill-aħwa tax-xellug huwa wkoll tipikament aktar mgħaġġel, peress li rridu biss nibdlu l-elementi N tan-nodu lejn il-lemin, minflok ma nċaqilqu mill-inqas N mill-elementi tal-aħwa lejn ix-xellug.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Jirritorna jekk l-amalgamazzjoni hijiex possibbli, jiġifieri, jekk hemmx biżżejjed spazju f'node biex tgħaqqad il-KV ċentrali maż-żewġ nodi tfal adjaċenti.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Twettaq għaqda u tħalli għeluq jiddeċiedi x'għandek tirritorna.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SIGURTÀ: l-għoli tan-nodi li qed jingħaqdu huwa wieħed taħt l-għoli
                // tan-nodu ta 'dan edge, għalhekk' il fuq minn żero, allura huma interni.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Għaqqad il-par ċavetta-valur tal-ġenitur u ż-żewġ nodi tfal adjaċenti fin-nodu tfal xellug u jirritorna n-nodu ġenitur imċekken.
    ///
    ///
    /// Panics sakemm aħna `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Għaqqad il-par ċavetta-valur tal-ġenitur u ż-żewġ nodi tfal adjaċenti fin-nodu tfal xellug u jirritorna dak in-nodu tfal.
    ///
    ///
    /// Panics sakemm aħna `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Għaqqad il-par ċavetta-valur tal-ġenitur u ż-żewġ nodi tat-tfal li jmissu magħhom fin-nodu tat-tfal tax-xellug u jirritorna l-manku edge f'dak in-nodu tat-tfal fejn spiċċa t-tifel traċċat edge,
    ///
    ///
    /// Panics sakemm aħna `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Tneħħi par ta 'valur-ċavetta mit-tifel tax-xellug u tpoġġiha fil-ħażna tal-valur taċ-ċavetta tal-ġenitur, waqt li timbotta l-par ta' valur taċ-ċavetta ġenitur qadim fit-tifel it-tajjeb.
    ///
    /// Jirritorna manku lejn iż-edge fit-tifel it-tajjeb li jikkorrispondi għal fejn spiċċa ż-edge oriġinali speċifikat minn `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Neħħi par ċavetta-valur mit-tifel it-tajjeb u jqiegħdu fil-ħażna tal-valur taċ-ċavetta tal-ġenitur, waqt li timbotta l-par qadim tal-valur taċ-ċavetta fuq it-tifel tax-xellug.
    ///
    /// Jirritorna manku lejn iż-edge fit-tifel tax-xellug speċifikat minn `track_left_edge_idx`, li ma ċċaqlaqx.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Dan jisraq simili għal `steal_left` iżda jisraq elementi multipli f'daqqa.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Kun żgur li nistgħu nisirqu bla periklu.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mexxi d-dejta tal-weraq.
            {
                // Agħmel spazju għal elementi misruqa fit-tifel it-tajjeb.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Mexxi elementi mit-tifel tax-xellug għal dak it-tajjeb.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Mexxi l-iktar par misruq mix-xellug lejn il-ġenitur.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mexxi l-par ċavetta-valur tal-ġenitur għat-tifel it-tajjeb.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Agħmel spazju għat-truf misruqa.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Steal truf.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Il-klonu simetriku ta `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Kun żgur li nistgħu nisirqu bla periklu.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Mexxi d-dejta tal-weraq.
            {
                // Mexxi l-par l-iktar misruq fuq il-lemin għand il-ġenitur.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Mexxi l-par ċavetta-valur tal-ġenitur fuq it-tifel tax-xellug.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Mexxi elementi mit-tifel tal-lemin lejn ix-xellug.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Imla l-vojt fejn kienu l-elementi misruqa.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Steal truf.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Imla l-vojt fejn kienu t-truf misruqa.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Tneħħi kwalunkwe informazzjoni statika li tasserixxi li dan in-nodu huwa nodu `Leaf`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Tneħħi kwalunkwe informazzjoni statika li tasserixxi li dan in-nodu huwa nodu `Internal`.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Jiċċekkja jekk in-nodu sottostanti huwiex nodu `Internal` jew nodu `Leaf`.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Mexxi s-suffiss wara `self` minn nodu għal ieħor.`right` għandu jkun vojt.
    /// L-ewwel edge ta `right` jibqa' l-istess.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Riżultat tal-inserzjoni, meta nodu kellu bżonn jespandi lil hinn mill-kapaċità tiegħu.
pub struct SplitResult<'a, K, V, NodeType> {
    // Nodu mibdul fis-siġra eżistenti b'elementi u truf li jappartjenu fuq ix-xellug ta `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Xi ċavetta u valur maqsuma, biex jiddaħħlu x'imkien ieħor.
    pub kv: (K, V),
    // Propjetarju, mhux imwaħħal, nodu ġdid b'elementi u truf li jappartjenu għad-dritt ta `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Jekk ir-referenzi tan-nodi ta 'dan it-tip jissellfu jippermettux li jiċċaqilqu għal nodi oħra fis-siġra.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // It-Traversal mhuwiex meħtieġ, jiġri billi tuża r-riżultat ta `borrow_mut`.
        // Billi tiddiżattiva t-traversal, u toħloq biss referenzi ġodda għall-għeruq, nafu li kull referenza tat-tip `Owned` hija għal nodu ta 'l-għerq.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Daħħal valur fi porzjon ta 'elementi inizjalizzati segwit minn element wieħed mhux inizjalizzat.
///
/// # Safety
/// Il-porzjon għandu aktar minn elementi `idx`.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Tneħħi u tirritorna valur minn porzjon tal-elementi inizjalizzati kollha, u tħalli warajh element mhux inizjalizzat li jkun għaddej.
///
///
/// # Safety
/// Il-porzjon għandu aktar minn elementi `idx`.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Iċċaqlaq l-elementi f'qatgħa `distance` pożizzjonijiet lejn ix-xellug.
///
/// # Safety
/// Il-porzjon għandu mill-inqas elementi `distance`.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Iċċaqlaq l-elementi f'qatgħat ta 'pożizzjonijiet `distance` lejn il-lemin.
///
/// # Safety
/// Il-porzjon għandu mill-inqas elementi `distance`.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Iċċaqlaq il-valuri kollha minn porzjon ta 'elementi inizjalizzati għal porzjon ta' elementi mhux inizjalizzati, u jħalli warajh `src` bħala kollha mhux inizjalizzati.
///
/// Jaħdem bħal `dst.copy_from_slice(src)` iżda ma jeħtieġx li `T` ikun `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;