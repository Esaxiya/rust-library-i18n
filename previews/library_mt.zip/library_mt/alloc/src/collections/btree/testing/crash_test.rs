use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Pjan għall-istanzi finta tat-test tal-ħbit li jissorveljaw avvenimenti partikolari.
/// Xi każijiet jistgħu jiġu kkonfigurati għal panic f'xi punt.
/// L-avvenimenti huma `clone`, `drop` jew xi `query` anonimu.
///
/// Il-manikini tat-test tal-ħbit huma identifikati u ordnati minn id, sabiex ikunu jistgħu jintużaw bħala ċwievet f'BTreeMap.
/// L-implimentazzjoni tuża intenzjonalment ma tiddependix fuq xi ħaġa definita fiż-crate, apparti mix-`Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Toħloq disinn finta tat-test tal-ħbit.Ix-`id` jiddetermina l-ordni u l-ugwaljanza tal-każijiet.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Joħloq eżempju ta 'manikin ta' crash test li jirreġistra liema avvenimenti jesperjenza u b'għażla panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Jirritorna kemm-il darba każijiet tal-manikin ġew ikklonati.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Jirritorna kemm-il darba l-istanzi tal-manikin twaqqgħu.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Jirritorna kemm-il darba l-istanzi tal-manikin kellhom il-membru `query` tagħhom invokat.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Xi mistoqsija anonima, li r-riżultat tagħha huwa diġà mogħti.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}