//! Kju ta 'truf doppji implimentat b' ring buffer li jista 'jitkabbar.
//!
//! Dan il-kju għandu *O*(1) inserzjonijiet u tneħħijiet amortizzati miż-żewġt itruf tal-kontenitur.
//! Għandha wkoll indiċjar *O*(1) bħal vector.
//! L-elementi kontenuti mhumiex meħtieġa li jkunu kopjabbli, u l-kju jkun jista 'jintbagħat jekk it-tip kontenut jista' jintbagħat.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // L-akbar qawwa possibbli ta 'tnejn

/// Kju ta 'truf doppji implimentat b' ring buffer li jista 'jitkabbar.
///
/// L-użu "default" ta 'dan it-tip bħala kju huwa li tuża [`push_back`] biex iżżid mal-kju, u [`pop_front`] biex tneħħi mill-kju.
///
/// [`extend`] u [`append`] imbotta fuq wara b'dan il-mod, u iterazzjoni fuq `VecDeque` tmur minn quddiem għal wara.
///
/// Peress li `VecDeque` huwa buffer taċ-ċirku, l-elementi tiegħu mhumiex neċessarjament kontigwi fil-memorja.
/// Jekk trid taċċessa l-elementi bħala porzjon wieħed, bħal għal għażla effiċjenti, tista 'tuża [`make_contiguous`].
/// Dan idawwar ix-`VecDeque` sabiex l-elementi tiegħu ma jitgeżwrux, u jirritorna porzjon li jista 'jinbidel għas-sekwenza ta' l-elementi issa kontigwi.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // denb u ras huma indikaturi fil-buffer.
    // Denb dejjem jindika l-ewwel element li jista 'jinqara, Kap dejjem jindika fejn għandha tinkiteb id-dejta.
    //
    // Jekk denb==ras il-buffer huwa vojt.It-tul tar-ringbuffer huwa definit bħala d-distanza bejn it-tnejn.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Imexxi d-distruttur għall-oġġetti kollha fil-porzjon meta jinżel (normalment jew waqt it-tħollija).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // uża qatra għal [T]
            ptr::drop_in_place(front);
        }
        // RawVec jimmaniġġa d-deallokazzjoni
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Joħloq `VecDeque<T>` vojt.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marġinalment aktar konvenjenti
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marġinalment aktar konvenjenti
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Għal tipi ta 'daqs żero, aħna dejjem f'kapaċità massima
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Dawwar il-ptr fi porzjon
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Dawwar ptr fi porzjon mut
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Iċċaqlaq element barra mill-buffer
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Jikteb element fil-buffer, billi jċaqlaqha.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Jirritorna `true` jekk il-buffer ikun f'kapaċità sħiħa.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Jirritorna l-indiċi fil-buffer sottostanti għal indiċi ta 'element loġiku partikolari.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Jirritorna l-indiċi fil-buffer sottostanti għal indiċi ta 'element loġiku mogħti + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Jirritorna l-indiċi fil-buffer sottostanti għal indiċi ta 'element loġiku partikolari, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Ikkopja blokka kontigwa ta 'memorja len twila minn src għal dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Ikkopja blokka kontigwa ta 'memorja len twila minn src għal dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Ikkopja blokka tal-memorja potenzjalment imgeżwra twila minn src għal dest.
    /// (abs(dst - src) + len) m'għandux ikun akbar minn cap() (Għandu jkun hemm l-iktar reġjun wieħed kontinwu li jikkoinċidi bejn src u dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src ma jgeżwerx, dst ma jgeżwerx
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst qabel src, src ma jitgeżwer, dst jitgeżwer
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src qabel dst, src ma jgeżwerx, dst wraps
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst qabel src, src jgeżwer, dst ma jgeżwerx
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src qabel dst, src jgeżwer, dst ma jgeżwerx
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst qabel src, src wraps, dst wraps
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src qabel dst, src wraps, dst wraps
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Frobs is-sezzjonijiet tar-ras u tad-denb madwar biex jimmaniġġaw il-fatt li għadna kif allokajna mill-ġdid.
    /// Mhux sikur għax jafda fil-kapaċità_dar.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Mexxi l-iqsar sezzjoni kontigwa tar-ring buffer TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Joħloq `VecDeque` vojt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Joħloq `VecDeque` vojt bi spazju għal mill-inqas elementi `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 billi r-ringbuffer dejjem iħalli spazju wieħed vojt
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Jipprovdi referenza għall-element fl-indiċi mogħti.
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Jipprovdi referenza li tista 'tinbidel għall-element fl-indiċi mogħti.
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Tpartit ta 'elementi fl-indiċi `i` u `j`.
    ///
    /// `i` u `j` jistgħu jkunu ugwali.
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Panics
    ///
    /// Panics jekk kwalunkwe indiċi huwa barra mill-limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Jirritorna n-numru ta 'elementi li `VecDeque` jista' jżomm mingħajr ma jalloka mill-ġdid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Jirriżerva l-kapaċità minima għal eżattament `additional` aktar elementi biex jiddaħħlu fix-`VecDeque` mogħti.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà suffiċjenti.
    ///
    /// Innota li l-allokatur jista 'jagħti lill-kollezzjoni aktar spazju milli jitlob.
    /// Għalhekk il-kapaċità ma tistax tiġi invokata biex tkun preċiżament minima.
    /// Ippreferi [`reserve`] jekk huma mistennija inserzjonijiet future.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida tfur `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Jirriżerva kapaċità għal mill-inqas `additional` aktar elementi biex jiddaħħlu fix-`VecDeque` mogħti.
    /// Il-kollezzjoni tista 'tirriżerva aktar spazju biex tevita riallokazzjonijiet frekwenti.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida tfur `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Tipprova tirriserva l-kapaċità minima għal eżattament `additional` aktar elementi li għandhom jiddaħħlu fix-`VecDeque<T>` mogħti.
    ///
    /// Wara li ċċempel lil `try_reserve_exact`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional`.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà suffiċjenti.
    ///
    /// Innota li l-allokatur jista 'jagħti lill-kollezzjoni aktar spazju milli jitlob.
    /// Għalhekk, il-kapaċità ma tistax tiġi invokata biex tkun preċiżament minima.
    /// Ippreferi `reserve` jekk huma mistennija inserzjonijiet future.
    ///
    /// # Errors
    ///
    /// Jekk il-kapaċità tfur `usize`, jew l-allokatur jirrapporta falliment, allura jiġi rritornat żball.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Irriserva minn qabel il-memorja, u toħroġ jekk ma nistgħux
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Issa nafu li dan ma jistax OOM(Out-Of-Memory) fin-nofs tax-xogħol kumpless tagħna
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ikkumplikata ħafna
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Jipprova jirriserva kapaċità għal mill-inqas `additional` aktar elementi li għandhom jiddaħħlu fix-`VecDeque<T>` mogħti.
    /// Il-kollezzjoni tista 'tirriżerva aktar spazju biex tevita riallokazzjonijiet frekwenti.
    /// Wara li ċċempel lil `try_reserve`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional`.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà biżżejjed.
    ///
    /// # Errors
    ///
    /// Jekk il-kapaċità tfur `usize`, jew l-allokatur jirrapporta falliment, allura jiġi rritornat żball.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Irriserva minn qabel il-memorja, u toħroġ jekk ma nistgħux
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Issa nafu li dan ma jistax OOM fin-nofs tax-xogħol kumpless tagħna
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ikkumplikata ħafna
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Iċekken il-kapaċità tax-`VecDeque` kemm jista 'jkun.
    ///
    /// Se tinżel viċin kemm jista 'jkun tat-tul imma l-allokatur xorta jista' jinforma lix-`VecDeque` li hemm spazju għal ftit elementi oħra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Iċċekken il-kapaċità tax-`VecDeque` b'limitu aktar baxx.
    ///
    /// Il-kapaċità tibqa 'mill-inqas kbira kemm tat-tul kif ukoll tal-valur fornut.
    ///
    ///
    /// Jekk il-kapaċità kurrenti hija inqas mil-limitu l-iktar baxx, dan huwa no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // M`għandniex għalfejn ninkwetaw dwar overflow billi la `self.len()` u lanqas `self.capacity()` ma jistgħu qatt ikunu `usize::MAX`.
        // +1 billi r-ringbuffer dejjem iħalli spazju wieħed vojt.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Hemm tliet każijiet ta 'interess:
            //   L-elementi kollha huma barra mill-limiti mixtieqa L-elementi huma kontigwi, u r-ras hija barra mill-limiti mixtieqa L-elementi mhumiex diskwawi, u d-denb huwa barra mill-limiti mixtieqa
            //
            //
            // Fil-ħinijiet l-oħra kollha, il-pożizzjonijiet tal-elementi mhumiex affettwati.
            //
            // Tindika li l-elementi fir-ras għandhom jiġu mċaqalqa.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Mexxi elementi minn barra l-limiti mixtieqa (pożizzjonijiet wara target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Tqassar ix-`VecDeque`, billi żżomm l-ewwel elementi `len` u twaqqa 'l-bqija.
    ///
    ///
    /// Jekk `len` huwa akbar mit-tul kurrenti tal-'VecDeque ', dan m'għandux effett.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Imexxi d-distruttur għall-oġġetti kollha fil-porzjon meta jinżel (normalment jew waqt it-tħollija).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Sikur għax:
        //
        // * Kull porzjon mgħoddi lil `drop_in_place` huwa validu;it-tieni każ għandu `len <= front.len()` u r-ritorn fuq `len > self.len()` jiżgura `begin <= back.len()` fl-ewwel każ
        //
        // * Ir-ras tal-VecDeque titmexxa qabel ma ċċempel lil `drop_in_place`, allura l-ebda valur ma jitwaqqa 'darbtejn jekk `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Kun żgur li t-tieni nofs titwaqqa 'anke meta distruttur fl-ewwel waħda panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Jirritorna iteratur minn quddiem għal wara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Jirritorna iteratur minn quddiem għal wara li jirritorna referenzi li jistgħu jinbidlu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // SIGURTÀ: L-invariant ta 'sigurtà intern `IterMut` huwa stabbilit minħabba li
        // `ring` noħolqu hija porzjon dereferenzjabbli għal ħajjithom kollha '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Jirritorna par slices li fihom, fl-ordni, il-kontenut tax-`VecDeque`.
    ///
    /// Jekk [`make_contiguous`] kien imsejjaħ qabel, l-elementi kollha tax-`VecDeque` ikunu fl-ewwel porzjon u t-tieni porzjon ikun vojt.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Jirritorna par slices li fihom, fl-ordni, il-kontenut tax-`VecDeque`.
    ///
    /// Jekk [`make_contiguous`] kien imsejjaħ qabel, l-elementi kollha tax-`VecDeque` ikunu fl-ewwel porzjon u t-tieni porzjon ikun vojt.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Jirritorna n-numru ta 'elementi fix-`VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Jirritorna `true` jekk ix-`VecDeque` huwa vojt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Joħloq iteratur li jkopri l-firxa speċifikata fix-`VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics jekk il-punt tat-tluq huwa akbar mill-punt tat-tarf jew jekk il-punt tat-tarf huwa akbar mit-tul taż-vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Firxa sħiħa tkopri l-kontenuti kollha
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Ir-referenza kondiviża li għandna f &self hija miżmuma fil-'_ ta' Iter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Joħloq iteratur li jkopri l-firxa li tista 'tinbidel speċifikata fix-`VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics jekk il-punt tat-tluq huwa akbar mill-punt tat-tarf jew jekk il-punt tat-tarf huwa akbar mit-tul taż-vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Firxa sħiħa tkopri l-kontenuti kollha
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // SIGURTÀ: L-invariant ta 'sigurtà intern `IterMut` huwa stabbilit minħabba li
        // `ring` noħolqu hija porzjon dereferenzjabbli għal ħajjithom kollha '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Joħloq iteratur li jbattal li jneħħi l-firxa speċifikata fix-`VecDeque` u jagħti l-oġġetti mneħħija.
    ///
    /// Nota 1: Il-firxa tal-elementi titneħħa anke jekk l-iteratur ma jiġix ikkunsmat sa l-aħħar.
    ///
    /// Nota 2: Mhux speċifikat kemm elementi jitneħħew mid-deque, jekk il-valur `Drain` ma jitwaqqax, iżda s-self li għandu jiskadi (eż. Minħabba `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics jekk il-punt tat-tluq huwa akbar mill-punt tat-tarf jew jekk il-punt tat-tarf huwa akbar mit-tul taż-vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Firxa sħiħa tħassar il-kontenut kollu
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Sigurtà tal-memorja
        //
        // Meta jinħoloq l-ewwel darba Drain, id-deque tas-sors jitqassar biex jiġi żgurat li l-ebda element mhux inizjalizzat jew imċaqlaq ma jkun aċċessibbli għal kollox jekk id-distruttur taż-Drain qatt ma jasal biex jaħdem.
        //
        //
        // Drain se ptr::read joħroġ il-valuri li għandhom jitneħħew.
        // Meta tispiċċa, id-dejta li jifdal tiġi kkupjata lura biex tkopri t-toqba, u l-valuri head/tail jiġu restawrati b'mod korrett.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // L-elementi tad-deque huma maqsuma fi tliet segmenti:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Aħna naħżnu drain_tail bħala self.head, u drain_head u self.head bħala after_tail u after_head rispettivament fuq iż-Drain.
        // Dan jaqta 'wkoll il-firxa effettiva b'tali mod li jekk iż-Drain ikun nixxa, insejna dwar il-valuri potenzjalment imċaqalqa wara l-bidu taż-drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" dwar il-valuri wara l-bidu ta 'drain sa wara li drain tkun kompluta u jitmexxa d-distruttur Drain.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Kruċjali, aħna noħolqu biss referenzi komuni minn `self` hawn u naqraw minnha.
                // Aħna ma niktbux lil `self` u lanqas nerġgħu nissellfu għal referenza li tista 'tinbidel.
                // Għalhekk il-pointer nej li ħloqna hawn fuq, għal `deque`, jibqa 'validu.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Tħassar ix-`VecDeque`, u tneħħi l-valuri kollha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Jirritorna `true` jekk `VecDeque` fih element ugwali għall-valur mogħti.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Jipprovdi referenza għall-element ta 'quddiem, jew `None` jekk ix-`VecDeque` huwa vojt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Jipprovdi referenza li tista 'tinbidel għall-element ta' quddiem, jew `None` jekk ix-`VecDeque` huwa vojt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Jipprovdi referenza għall-element ta 'wara, jew `None` jekk ix-`VecDeque` huwa vojt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Jipprovdi referenza li tista 'tinbidel għall-element ta' wara, jew `None` jekk ix-`VecDeque` huwa vojt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Tneħħi l-ewwel element u tirritornah, jew `None` jekk ix-`VecDeque` huwa vojt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Neħħi l-aħħar element mix-`VecDeque` u jirritornah, jew `None` jekk ikun vojt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Tipprevjeni element għax-`VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Żid element mad-dahar tax-`VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Għandna nikkunsidraw `head == 0` bħala li tfisser
        // li `self` huwa kontigwu?
        self.tail <= self.head
    }

    /// Ineħħi element minn kullimkien fix-`VecDeque` u jirritornah, u jibdlu bl-ewwel element.
    ///
    ///
    /// Dan ma jippreservax l-ordni, iżda huwa *O*(1).
    ///
    /// Jirritorna `None` jekk `index` huwa barra mill-limiti.
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Neħħi element minn kullimkien fix-`VecDeque` u jirritornah, u jibdlu bl-aħħar element.
    ///
    ///
    /// Dan ma jippreservax l-ordni, iżda huwa *O*(1).
    ///
    /// Jirritorna `None` jekk `index` huwa barra mill-limiti.
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Daħħal element f `index` fi ħdan `VecDeque`, billi tbiddel l-elementi kollha b'indiċi akbar minn jew ugwali għal `index` lejn in-naħa ta 'wara.
    ///
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Panics
    ///
    /// Panics jekk `index` huwa akbar mit-tul ta '"VecDeque"
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Mexxi l-inqas numru ta 'elementi fir-ring buffer u daħħal l-oġġett mogħti
        //
        // L-iktar len/2, 1 elementi se jiġu mċaqalqa. O(min(n, n-i))
        //
        // Hemm tliet każijiet ewlenin:
        //  L-elementi huma kontigwi
        //      - każ speċjali meta d-denb huwa 0 L-elementi huma diskontigwi u l-inserit jinsab fit-taqsima tad-denb L-elementi huma diskontinwi u l-inserit huwa fit-taqsima tar-ras
        //
        //
        // Għal kull wieħed minn dawn hemm żewġ każijiet oħra:
        //  Daħħal huwa eqreb lejn denb Daħħal huwa eqreb lejn ras
        //
        // Ċavetta: H, self.head
        //      T, self.tail o, Element validu I, Element ta 'inserzjoni A, L-element li għandu jkun wara l-punt ta' inserzjoni M, Jindika li element ġie mċaqlaq
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [A oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // kontigwi, daħħal eqreb lejn denb:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // kontigwi, daħħal eqreb lejn denb u denb huwa 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Diġà ċċaqlaq id-denb, allura aħna nikkupjaw biss elementi `index - 1`.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // kontigwi, daħħal eqreb lejn ras:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // mhux kontigwu, daħħal eqreb lejn denb, sezzjoni tad-denb:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // mhux kontigwu, daħħal eqreb lejn ras, sezzjoni tad-denb:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // ikkopja elementi sa ras ġdida
                    self.copy(1, 0, self.head);

                    // ikkopja l-aħħar element f'post vojt fil-qiegħ tal-buffer
                    self.copy(0, self.cap() - 1, 1);

                    // mexxi elementi minn idx biex tispiċċa 'l quddiem mingħajr ma tinkludi ^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // skontigwu, daħħal huwa eqreb tad-denb, tas-sezzjoni tar-ras, u jinsab fl-indiċi żero fil-buffer intern:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // ikkopja elementi sa denb ġdid
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ikkopja l-aħħar element f'post vojt fil-qiegħ tal-buffer
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // mhux kontigwu, daħħal eqreb lejn denb, sezzjoni tar-ras:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // ikkopja elementi sa denb ġdid
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // ikkopja l-aħħar element f'post vojt fil-qiegħ tal-buffer
                    self.copy(self.cap() - 1, 0, 1);

                    // mexxi elementi minn idx-1 biex tispiċċa 'l quddiem mingħajr ma tinkludi ^ element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // mhux kontigwu, daħħal eqreb lejn ras, sezzjoni tar-ras:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // id-denb seta 'nbidel u għalhekk għandna bżonn nerġgħu nikkalkulaw
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Tneħħi u tirritorna l-element f `index` mix-`VecDeque`.
    /// Kwalunkwe tarf ikun l-eqreb tal-punt tat-tneħħija jiġi mċaqlaq biex tagħmel spazju, u l-elementi affettwati kollha jiġu mċaqilqa għal pożizzjonijiet ġodda.
    ///
    /// Jirritorna `None` jekk `index` huwa barra mill-limiti.
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Hemm tliet każijiet ewlenin:
        //  L-elementi huma kontigwi L-elementi huma diskontinwi u t-tneħħija hija fit-taqsima tad-denb L-elementi huma diskontinwi u t-tneħħija hija fit-taqsima tar-ras
        //
        //      - każ speċjali meta l-elementi huma teknikament kontigwi, iżda self.head =0
        //
        // Għal kull wieħed minn dawn hemm żewġ każijiet oħra:
        //  Daħħal huwa eqreb lejn denb Daħħal huwa eqreb lejn ras
        //
        // Ċavetta: H, self.head
        //      T, self.tail o, Element validu x, Element immarkat għat-tneħħija R, Jindika element li qed jitneħħa M, Jindika li element ġie mċaqlaq
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // kontigwi, neħħi eqreb lejn denb:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // kontigwi, neħħi eqreb lejn ras:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // mhux kontigwu, neħħi eqreb lejn denb, sezzjoni tad-denb:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // mhux kontigwu, neħħi eqreb lejn ras, sezzjoni tar-ras:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // mhux kontigwu, neħħi eqreb lejn ras, sezzjoni tad-denb:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // jew kważi diskontinwa, neħħi ħdejn is-sezzjoni tar-ras, tad-denb:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // iġbed elementi fit-taqsima tad-denb
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Jipprevjeni n-nixxigħat.
                    if self.head != 0 {
                        // ikkopja l-ewwel element f'post vojt
                        self.copy(self.cap() - 1, 0, 1);

                        // iċċaqlaq elementi fit-taqsima tar-ras lura
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // mhux kontigwu, neħħi eqreb lejn denb, sezzjoni tar-ras:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // iġbed elementi sa idx
                    self.copy(1, 0, idx);

                    // ikkopja l-aħħar element f'post vojt
                    self.copy(0, self.cap() - 1, 1);

                    // imxi elementi minn denb biex jintemm 'il quddiem, minbarra l-aħħar wieħed
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Jaqsam ix-`VecDeque` fi tnejn fl-indiċi mogħti.
    ///
    /// Jirritorna `VecDeque` allokat ġdid.
    /// `self` fih elementi `[0, at)`, u l-`VecDeque` ritornat fih elementi `[at, len)`.
    ///
    /// Innota li l-kapaċità ta `self` ma tinbidilx.
    ///
    /// Element fl-indiċi 0 huwa l-faċċata tal-kju.
    ///
    /// # Panics
    ///
    /// Panics jekk `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` tinsab fl-ewwel nofs.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // ħu biss it-tieni taqsima kollha.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` tinsab fit-tieni taqsima, jeħtieġ li nikkunsidraw l-elementi li qbiżna fl-ewwel taqsima.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Naddaf fejn hemm it-truf tal-buffers
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Iċċaqlaq l-elementi kollha ta `other` f `self`, u jħalli `other` vojt.
    ///
    /// # Panics
    ///
    /// Panics jekk in-numru ġdid ta 'elementi fl-awto jisfaw `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // impl. naive
        self.extend(other.drain(..));
    }

    /// Iżomm biss l-elementi speċifikati mill-predikat.
    ///
    /// Fi kliem ieħor, neħħi l-elementi kollha `e` b'tali mod li `f(&e)` jirritorna falza.
    /// Dan il-metodu jopera f'postu, u jżur kull element eżattament darba fl-ordni oriġinali, u jippreserva l-ordni tal-elementi miżmuma.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// L-ordni eżatta tista 'tkun utli għat-traċċar ta' stat estern, bħal indiċi.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Dan jista 'panic jew abort
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Iddoppja d-daqs tal-buffer.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Timmodifika l-`VecDeque` fil-post sabiex `len()` tkun ugwali għal `new_len`, jew billi tneħħi l-elementi żejda minn wara jew billi żżid elementi ġġenerati billi ċċempel `generator` fuq wara.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Irranġa mill-ġdid il-ħażna interna ta 'dan id-deque sabiex tkun porzjon wieħed kontigwu, li mbagħad jingħata lura.
    ///
    /// Dan il-metodu ma jallokax u ma jbiddilx l-ordni tal-elementi mdaħħla.Hekk kif tirritorna porzjon li jista 'jinbidel, din tista' tintuża biex issolvi deque.
    ///
    /// Ladarba l-ħażna interna tkun kontigwa, il-metodi [`as_slices`] u [`as_mut_slices`] jirritornaw il-kontenut kollu tax-`VecDeque` f'biċċa waħda.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// Issortjar tal-kontenut ta 'deque.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // issortjar id-deque
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // issortjaha f'ordni inversa
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Ikseb aċċess immutabbli għall-porzjon kontigwu.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // issa nistgħu nkunu ċerti li `slice` fih l-elementi kollha tad-deque, filwaqt li għad għandna aċċess immutabbli għal `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // hemm biżżejjed spazju ħieles biex nikkopjaw id-denb f'daqqa, dan ifisser li l-ewwel nibdlu r-ras lura, u mbagħad nikkopjaw id-denb fil-pożizzjoni t-tajba.
            //
            //
            // minn: DEFGH .... ABC
            // lil: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Bħalissa ma nikkunsidrawx .... ABCDEFGH
            // tkun kontigwa għax `head` ikun `0` f'dan il-każ.
            // Filwaqt li probabbilment irridu nbiddlu dan mhuwiex trivjali peress li ftit postijiet jistennew li `is_contiguous` ifisser li nistgħu sempliċement naqsmu bl-użu ta `buf[tail..head]`.
            //
            //

            // hemm biżżejjed spazju ħieles biex nikkupjaw ir-ras f'daqqa, dan ifisser li l-ewwel nibdlu d-denb 'il quddiem, u mbagħad nikkopjaw ir-ras fil-pożizzjoni t-tajba.
            //
            //
            // minn: FGH .... ABCDE
            // lil: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // b'xejn huwa iżgħar kemm mir-ras kif ukoll mid-denb, dan ifisser li aħna għandna bil-mod "swap" id-denb u r-ras.
            //
            //
            // minn: EFGHI ... ABCD jew HIJK.ABCDEFG
            // lil: ABCDEFGHI ... jew ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Il-problema ġenerali tidher qisha din GHIJKLM ... ABCDEF, qabel kwalunkwe tpartit ABCDEFM ... GHIJKL, wara 1 pass ta 'tpartit ABCDEFGHIJM ... KL, tpartit sakemm ix-xellug edge jilħaq il-maħżen tat-temperatura
                //                  - imbagħad erġa 'ibda l-algoritmu b'maħżen ġdid (smaller) Kultant il-maħżen tat-temp jintlaħaq meta ż-edge it-tajjeb ikun fit-tarf tal-buffer, dan ifisser li laqatna l-ordni t-tajba b'inqas swaps!
                //
                // E.g
                // EF..ABCD ABCDEF .., wara erba 'tpartit biss li lestejna
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Dawwar il-kju tat-tarf doppju `mid` postijiet fuq ix-xellug.
    ///
    /// Equivalently,
    /// - Dawwar l-oġġett `mid` fl-ewwel pożizzjoni.
    /// - Ipoġġi l-ewwel oġġetti `mid` u jimbuttahom sat-tmiem.
    /// - Dawwar il-postijiet `len() - mid` lejn il-lemin.
    ///
    /// # Panics
    ///
    /// Jekk `mid` huwa akbar minn `len()`.
    /// Innota li `mid == len()` jagħmel _not_ panic u huwa rotazzjoni bla op.
    ///
    /// # Complexity
    ///
    /// Jieħu `*O*(min(mid, len() - mid))` ħin u l-ebda spazju żejjed.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Dawwar il-kju tat-tarf doppju `k` postijiet fuq il-lemin.
    ///
    /// Equivalently,
    /// - Dawwar l-ewwel oġġett fil-pożizzjoni `k`.
    /// - Itfa 'l-aħħar oġġetti `k` u jimbuttahom fuq quddiem.
    /// - Dawwar `len() - k` postijiet lejn ix-xellug.
    ///
    /// # Panics
    ///
    /// Jekk `k` huwa akbar minn `len()`.
    /// Innota li `k == len()` jagħmel _not_ panic u huwa rotazzjoni bla op.
    ///
    /// # Complexity
    ///
    /// Jieħu `*O*(min(k, len() - k))` ħin u l-ebda spazju żejjed.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // SIGURTÀ: iż-żewġ metodi li ġejjin jeħtieġu li l-ammont ta 'rotazzjoni
    // ikun inqas minn nofs it-tul tad-deque.
    //
    // `wrap_copy` jirrikjedi li `min(x, cap() - x) + copy_len <= cap()`, iżda minn `min` qatt ma huwa iktar minn nofs il-kapaċità, irrispettivament minn x, allura huwa tajjeb li ċċempel hawn għax qed insejħu b'xi ħaġa inqas minn nofs it-tul, li qatt mhu 'l fuq minn nofs il-kapaċità.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binarju jfittex dan `VecDeque` issortjat għal element partikolari.
    ///
    /// Jekk il-valur jinstab allura [`Result::Ok`] jiġi rritornat, li jkun fih l-indiċi tal-element li jaqbel.
    /// Jekk hemm bosta logħbiet, allura kwalunkwe waħda mill-logħbiet tista 'tingħata lura.
    /// Jekk il-valur ma jinstabx allura [`Result::Err`] jiġi rritornat, li jkun fih l-indiċi fejn jista 'jiddaħħal element li jaqbel waqt li tinżamm ordni magħżula.
    ///
    ///
    /// # Examples
    ///
    /// Ifittex serje ta 'erba' elementi.
    /// L-ewwel wieħed jinstab, b'pożizzjoni determinata b'mod uniku;it-tieni u t-tielet ma jinstabux;ir-raba 'jista' jaqbel ma 'kwalunkwe pożizzjoni f `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Jekk trid iddaħħal oġġett f `VecDeque` issortjat, filwaqt li żżomm l-ordni ta 'l-issortjar:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binarju jfittex dan `VecDeque` magħżul b'funzjoni ta 'komparatur.
    ///
    /// Il-funzjoni tal-komparatur għandha timplimenta ordni konsistenti ma 'l-ordni ta' l-għażla ta 'l-`VecDeque` sottostanti, billi tirritorna kodiċi ta' l-ordni li jindika jekk l-argument tagħha huwiex `Less`, `Equal` jew `Greater` mill-mira mixtieqa.
    ///
    ///
    /// Jekk il-valur jinstab allura [`Result::Ok`] jiġi rritornat, li jkun fih l-indiċi tal-element li jaqbel.Jekk hemm bosta logħbiet, allura kwalunkwe waħda mill-logħbiet tista 'tingħata lura.
    /// Jekk il-valur ma jinstabx allura [`Result::Err`] jiġi rritornat, li jkun fih l-indiċi fejn jista 'jiddaħħal element li jaqbel waqt li tinżamm ordni magħżula.
    ///
    /// # Examples
    ///
    /// Ifittex serje ta 'erba' elementi.L-ewwel wieħed jinstab, b'pożizzjoni determinata b'mod uniku;it-tieni u t-tielet ma jinstabux;ir-raba 'jista' jaqbel ma 'kwalunkwe pożizzjoni f `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binarju jfittex dan `VecDeque` magħżul b'funzjoni ta 'estrazzjoni ewlenija.
    ///
    /// Tassumi li x-`VecDeque` huwa magħżul biċ-ċavetta, per eżempju b [`make_contiguous().sort_by_key()`](#method.make_contiguous) bl-użu ta 'l-istess funzjoni ta' estrazzjoni taċ-ċavetta.
    ///
    ///
    /// Jekk il-valur jinstab allura [`Result::Ok`] jiġi rritornat, li jkun fih l-indiċi tal-element li jaqbel.
    /// Jekk hemm bosta logħbiet, allura kwalunkwe waħda mill-logħbiet tista 'tingħata lura.
    /// Jekk il-valur ma jinstabx allura [`Result::Err`] jiġi rritornat, li jkun fih l-indiċi fejn jista 'jiddaħħal element li jaqbel waqt li tinżamm ordni magħżula.
    ///
    /// # Examples
    ///
    /// Iħares serje ta 'erba' elementi f'qatgħa ta 'pari magħżula bit-tieni elementi tagħhom.
    /// L-ewwel wieħed jinstab, b'pożizzjoni determinata b'mod uniku;it-tieni u t-tielet ma jinstabux;ir-raba 'jista' jaqbel ma 'kwalunkwe pożizzjoni f `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Timmodifika x-`VecDeque` fil-post sabiex `len()` tkun ugwali għal new_len, jew billi tneħħi l-elementi żejda minn wara jew billi twaħħal kloni ta `value` mad-dahar.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Jirritorna l-indiċi fil-buffer sottostanti għal indiċi ta 'element loġiku partikolari.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // id-daqs huwa dejjem qawwa ta '2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Ikkalkula n-numru ta 'elementi li fadal biex jinqraw fil-buffer
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // id-daqs huwa dejjem qawwa ta '2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Dejjem diviżibbli fi tliet taqsimiet, per eżempju: awto: [a b c|d e f] ieħor: [0 1 2 3|4 5] quddiem=3, nofs=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Mhuwiex possibbli li tuża Hash::hash_slice fuq flieli rritornati bil-metodu as_slices billi t-tul tagħhom jista 'jvarja f'deques identiċi mod ieħor.
        //
        //
        // Hasher jiggarantixxi biss ekwivalenza għall-istess sett eżatt ta 'sejħiet għall-metodi tiegħu.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Jikkonsma x-`VecDeque` f'iteratur minn quddiem għal wara li jagħti elementi skont il-valur.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Din il-funzjoni għandha tkun l-ekwivalenti morali ta ':
        //
        //      għal oġġett f iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Dawwar [`Vec<T>`] f [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dan jevita l-allokazzjoni mill-ġdid fejn possibbli, iżda l-kundizzjonijiet għal dan huma stretti, u suġġetti għal bidla, u għalhekk m'għandhomx jiġu invokati sakemm ix-`Vec<T>` ma jkunx ġie minn `From<VecDeque<T>>` u ma jkunx ġie riallokat.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // M'hemm l-ebda allokazzjoni attwali biex ZSTs jinkwetaw dwar il-kapaċità, iżda `VecDeque` ma jistax jimmaniġġja daqs daqs `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Għandna bżonn nagħmlu daqs ieħor jekk il-kapaċità mhix qawwa ta 'tnejn, żgħira wisq jew m'għandhiex mill-inqas spazju wieħed liberu.
            // Aħna nagħmlu dan waqt li jkun għadu fix-`Vec` sabiex l-oġġetti jinżlu fuq panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Dawwar [`VecDeque<T>`] f [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Dan qatt ma jeħtieġ jerġa 'jalloka, iżda jeħtieġ li jagħmel moviment ta' dejta *O*(*n*) jekk il-buffer ċirkolari ma jiġrix fil-bidu tal-allokazzjoni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Dan huwa *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Din teħtieġ arranġament tad-dejta.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}