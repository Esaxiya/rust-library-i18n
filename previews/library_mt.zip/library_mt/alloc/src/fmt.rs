//! Utilitajiet għall-ifformattjar u l-istampar ta '' String`s.
//!
//! Dan il-modulu fih l-appoġġ ta 'runtime għall-estensjoni tas-sintassi [`format!`].
//! Din il-makro hija implimentata fil-kompilatur biex toħroġ sejħiet għal dan il-modulu sabiex tifformattja l-argumenti fil-ħin ta 'eżekuzzjoni f'kordi.
//!
//! # Usage
//!
//! Il-makro [`format!`] huwa maħsub biex ikun familjari għal dawk li ġejjin mill-funzjonijiet `printf`/`fprintf` ta 'C jew il-funzjoni `str.format` ta' Python.
//!
//! Xi eżempji ta 'l-estensjoni [`format!`] huma:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" biż-żerijiet ewlenin
//! ```
//!
//! Minn dawn, tista 'tara li l-ewwel argument huwa sekwenza ta' format.Huwa meħtieġ mill-kompilatur biex dan ikun string litterali;ma tistax tkun varjabbli mgħoddija (sabiex twettaq verifika tal-validità).
//! Il-kompilatur imbagħad analizza s-sekwenza tal-format u jiddetermina jekk il-lista tal-argumenti pprovduti hijiex adattata biex tgħaddi għal din is-sekwenza tal-format.
//!
//! Biex tikkonverti valur wieħed għal sekwenza, uża l-metodu [`to_string`].Dan se juża l-ifformattjar [`Display`] trait.
//!
//! ## Parametri pożizzjonali
//!
//! Kull argument tal-ifformattjar huwa permess li jispeċifika liema argument tal-valur qed jirreferenzja, u jekk jitħalla barra huwa preżunt li jkun "the next argument".
//! Pereżempju, is-sekwenza tal-format `{} {} {}` tieħu tliet parametri, u jkunu fformattjati fl-istess ordni kif jingħataw.
//! Is-sekwenza tal-format `{2} {1} {0}`, madankollu, tifformattja l-argumenti f'ordni inversa.
//!
//! L-affarijiet jistgħu jsiru ftit delikati ladarba tibda tgħaqqad iż-żewġ tipi ta 'speċifikaturi tal-pożizzjoni.L-ispeċifikatur "next argument" jista 'jitqies bħala iteratur fuq l-argument.
//! Kull darba li jidher speċifikatur "next argument", l-iteratur javvanza.Dan iwassal għal imġieba bħal din:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! L-iteratur intern fuq l-argument ma ġiex avvanzat sa meta jidher l-ewwel `{}`, allura jistampa l-ewwel argument.Imbagħad malli laħaq it-tieni `{}`, l-iteratur avvanza għat-tieni argument.
//! Essenzjalment, parametri li jsemmu b'mod espliċitu l-argument tagħhom ma jaffettwawx parametri li ma jsemmux argument f'termini ta 'speċifikaturi tal-pożizzjoni.
//!
//! String tal-format hija meħtieġa biex tuża l-argumenti kollha tagħha, inkella huwa żball fil-ħin tal-kumpilazzjoni.Tista 'tirreferi għall-istess argument aktar minn darba fis-sekwenza tal-format.
//!
//! ## Parametri msemmija
//!
//! Rust innifsu m'għandux ekwivalenti bħal Python ta 'parametri msemmija għal funzjoni, iżda l-makro [`format!`] hija estensjoni tas-sintassi li tippermettilu li jsaħħaħ parametri msemmija.
//! Il-parametri msemmija huma elenkati fl-aħħar tal-lista tal-argumenti u għandhom is-sintassi:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Pereżempju, l-espressjonijiet [`format!`] li ġejjin kollha jużaw argument imsemmi:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Mhuwiex validu li tpoġġi parametri pożizzjonali (dawk mingħajr ismijiet) wara argumenti li għandhom ismijiet.Bħal fil-każ tal-parametri tal-pożizzjoni, mhux validu li jiġu pprovduti parametri msemmija li mhumiex użati mis-sekwenza tal-format.
//!
//! # Parametri tal-Ifformattjar
//!
//! Kull argument li jkun ifformattjat jista 'jiġi ttrasformat b'numru ta' parametri tal-ifformattjar (li jikkorrispondu għal `format_spec` f [the syntax](#syntax)). Dawn il-parametri jaffettwaw ir-rappreżentazzjoni ta 'sekwenza ta' dak li qed jiġi fformattjat.
//!
//! ## Width
//!
//! ```
//! // Dawn kollha jistampaw "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dan huwa parametru għax-"minimum width" li l-format għandu jieħu.
//! Jekk is-sekwenza tal-valur ma timlax dawn il-ħafna karattri, allura l-ikkuttunar speċifikat minn fill/alignment jintuża biex jieħu l-ispazju meħtieġ (ara hawn taħt).
//!
//! Il-valur għall-wisa 'jista' jiġi pprovdut ukoll bħala [`usize`] fil-lista ta 'parametri billi żżid postfix `$`, li jindika li t-tieni argument huwa [`usize`] li jispeċifika l-wisa'.
//!
//! Ir-referenza għal argument bis-sintassi tad-dollaru ma taffettwax il-counter "next argument", allura ġeneralment tkun idea tajba li tirreferi għal argumenti skont il-pożizzjoni, jew tuża argumenti msemmija.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Il-karattru tal-mili u l-allinjament mhux obbligatorju huma pprovduti normalment flimkien mal-parametru [`width`](#width).Għandu jkun definit qabel `width`, eżatt wara `:`.
//! Dan jindika li jekk il-valur li jkun ifformattjat ikun iżgħar minn `width` xi karattri żejda jiġu stampati madwaru.
//! Il-mili jiġi fil-varjanti li ġejjin għal allinjamenti differenti:
//!
//! * `[fill]<` - l-argument huwa allinjat lejn ix-xellug f'kolonni `width`
//! * `[fill]^` - l-argument huwa allinjat fiċ-ċentru f'kolonni `width`
//! * `[fill]>` - l-argument huwa allinjat mal-lemin f'kolonni `width`
//!
//! L-[fill/alignment](#fillalignment) default għal dawk mhux numeriċi huwa spazju u allinjat lejn ix-xellug.In-nuqqas għal formatters numeriċi huwa wkoll karattru spazjali iżda b'allinjament tal-lemin.
//! Jekk il-bandiera `0` (ara hawn taħt) hija speċifikata għan-numeriċi, allura l-karattru tal-mili impliċitu huwa `0`.
//!
//! Innota li l-allinjament jista 'ma jiġix implimentat minn xi tipi.B'mod partikolari, ġeneralment mhuwiex implimentat għax-`Debug` trait.
//! Mod tajjeb biex tiżgura l-ikkuttunar huwa applikat huwa li tifformattja l-input tiegħek, imbagħad ibbadja din is-sekwenza li tirriżulta biex tikseb l-output tiegħek:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hello Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Dawn huma kollha bnadar li jbiddlu l-imġieba tal-formattur.
//!
//! * `+` - Dan huwa maħsub għal tipi numeriċi u jindika li s-sinjal għandu dejjem jiġi stampat.Sinjali pożittivi qatt ma huma stampati awtomatikament, u s-sinjal negattiv huwa stampat biss awtomatikament għax-`Signed` trait.
//! Din il-bandiera tindika li s-sinjal it-tajjeb (`+` jew `-`) għandu dejjem jiġi stampat.
//! * `-` - Bħalissa mhux użat
//! * `#` - Din il-bandiera tindika li għandha tintuża l-forma ta 'stampar "alternate".Il-forom alternattivi huma:
//!     * `#?` - pretty-print l-ifformattjar [`Debug`]
//!     * `#x` - jippreċedi l-argument b `0x`
//!     * `#X` - jippreċedi l-argument b `0x`
//!     * `#b` - jippreċedi l-argument b `0b`
//!     * `#o` - jippreċedi l-argument b `0o`
//! * `0` - Dan jintuża biex jindika għal formati sħaħ li l-ikkuttunar għal `width` għandu jsir kemm b'karattru `0` kif ukoll ikun konxju tas-sinjali.
//! Format bħal `{:08}` jagħti `00000001` għan-numru sħiħ `1`, filwaqt li l-istess format jagħti `-0000001` għan-numru sħiħ `-1`.
//! Innota li l-verżjoni negattiva għandha żero inqas mill-verżjoni pożittiva.
//!         Innota li ż-żerijiet tal-ikkuttunar dejjem jitqiegħdu wara s-sinjal (jekk hemm) u qabel iċ-ċifri.Meta jintuża flimkien mal-bandiera `#`, tapplika regola simili: żerijiet tal-padding jiddaħħlu wara l-prefiss imma qabel iċ-ċifri.
//!         Il-prefiss huwa inkluż fil-wisa 'totali.
//!
//! ## Precision
//!
//! Għal tipi mhux numeriċi, dan jista 'jitqies bħala "maximum width".
//! Jekk is-sekwenza li tirriżulta hija itwal minn din il-wisa ', allura hija maqtugħa sa dawn il-ħafna karattri u dak il-valur maqtugħ joħroġ b `fill`, `alignment` u `width` xierqa jekk dawk il-parametri huma ssettjati.
//!
//! Għal tipi integrali, dan huwa injorat.
//!
//! Għal tipi b'punt li jvarja, dan jindika kemm-il ċifra wara l-punt deċimali għandha tkun stampata.
//!
//! Hemm tliet modi possibbli biex tispeċifika x-`precision` mixtieq:
//!
//! 1. Numru sħiħ `.N`:
//!
//!    in-numru sħiħ `N` innifsu huwa l-preċiżjoni.
//!
//! 2. Numru sħiħ jew isem segwit bis-sinjal tad-dollaru `.N$`:
//!
//!    uża format *argument*`N` (li għandu jkun `usize`) bħala l-preċiżjoni.
//!
//! 3. Asterisk `.*`:
//!
//!    `.*` ifisser li dan ix-`{...}` huwa assoċjat ma '*żewġ* inputs tal-format minflok wieħed: l-ewwel input iżomm il-preċiżjoni `usize`, u t-tieni għandu l-valur li jistampa.
//!    Innota li f'dan il-każ, jekk wieħed juża s-sekwenza tal-format `{<arg>:<spec>.*}`, allura l-parti `<arg>` tirreferi għall-valur* biex tipprintja, u l-`precision` għandu jidħol fl-input qabel `<arg>`.
//!
//! Pereżempju, is-sejħiet li ġejjin kollha jistampaw l-istess ħaġa `Hello x is 0.01000`:
//!
//! ```
//! // Hello {arg 0 ("x")} huwa {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hello {arg 1 ("x")} huwa {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hello {arg 0 ("x")} huwa {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} huwa {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} huwa {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hello {next arg ("x")} huwa {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Filwaqt li dawn:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! ipprintja tliet affarijiet differenti b'mod sinifikanti:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! F'xi lingwi ta 'programmazzjoni, l-imġieba tal-funzjonijiet tal-ifformattjar tas-sekwenza tiddependi fuq l-issettjar locale tas-sistema operattiva.
//! Il-funzjonijiet tal-format ipprovduti mil-librerija standard ta 'Rust m'għandhom l-ebda kunċett ta' locale u se jipproduċu l-istess riżultati fuq is-sistemi kollha irrispettivament mill-konfigurazzjoni tal-utent.
//!
//! Pereżempju, il-kodiċi li ġej dejjem jistampa `1.5` anke jekk il-lokalità tas-sistema tuża separatur deċimali għajr punt.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Il-karattri litterali `{` u `}` jistgħu jiġu nklużi f`serje billi jiġu preċeduti bl-istess karattru.Pereżempju, il-karattru `{` jinħeba b `{{` u l-karattru `}` jinħeba b `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Fil-qosor, hawn tista 'ssib il-grammatika sħiħa tal-kordi tal-format.
//! Is-sintassi għall-lingwa tal-ifformattjar użata hija meħuda minn lingwi oħra, għalhekk m'għandhiex tkun aljena wisq.L-argumenti huma fformattjati b'sintassi simili għal Python, li jfisser li l-argumenti huma mdawra b `{}` minflok b `%` bħal C.
//! Il-grammatika attwali għas-sintassi tal-ifformattjar hija:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Fil-grammatika ta 'hawn fuq, `text` ma jistax ikun fih karattri `'{'` jew `'}'`.
//!
//! # Ifformattjar ta 'traits
//!
//! Meta titlob li argument jiġi fformattjat ma 'tip partikolari, fil-fatt qed titlob li argument jiġi attribwit lil trait partikolari.
//! Dan jippermetti li jiġu fformattjati tipi attwali multipli permezz ta `{:x}` (bħal [`i8`] kif ukoll [`isize`]).L-immappjar attwali tat-tipi għal traits huwa:
//!
//! * *xejn* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] b'numri interi eżadeċimali b'ittri żgħar
//! * `X?` ⇒ [`Debug`] b 'numri interi eżadeċimali f'ittri kbar
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Dan ifisser huwa li kull tip ta 'argument li jimplimenta [`fmt::Binary`][`Binary`] trait jista' mbagħad jiġi fformattjat b `{:b}`.Implimentazzjonijiet huma pprovduti għal dawn iż-traits għal numru ta 'tipi primittivi mil-librerija standard ukoll.
//!
//! Jekk l-ebda format m'hu speċifikat (bħal f `{}` jew `{:6}`), allura l-format trait użat huwa [`Display`] trait.
//!
//! Meta timplimenta format trait għat-tip tiegħek stess, ikollok timplimenta metodu tal-firma:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // it-tip tad-dwana tagħna
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! It-tip tiegħek jgħaddi bħala referenza sekondarja `self`, u allura l-funzjoni għandha toħroġ output fil-fluss `f.buf`.Huwa f'idejn kull format ta 'implimentazzjoni ta' trait li jaderixxi b'mod korrett mal-parametri tal-ifformattjar mitluba.
//! Il-valuri ta 'dawn il-parametri jiġu elenkati fl-oqsma tal-istruttura [`Formatter`].Sabiex tgħin f'dan, l-istruttura [`Formatter`] tipprovdi wkoll xi metodi ta 'għajnuna.
//!
//! Barra minn hekk, il-valur tar-ritorn ta 'din il-funzjoni huwa [`fmt::Result`] li huwa psewdonimu tat-tip ta' [`Riżultat`]`<(),`[`std: : fmt::Error`] `>`.
//! Implimentazzjonijiet tal-ifformattjar għandhom jiżguraw li dawn ixerrdu żbalji mix-[`Formatter`] (eż., Meta ċċempel lil [`write!`]).
//! Madankollu, huma m'għandhom qatt jirritornaw l-iżbalji b'mod spuriously.
//! Jiġifieri, implimentazzjoni tal-ifformattjar għandha u tista 'tirritorna żball biss jekk il-pass-in [`Formatter`] jirritorna żball.
//! Dan għaliex, kuntrarjament għal dak li tista 'tissuġġerixxi l-firma tal-funzjoni, l-ifformattjar tas-sekwenza huwa operazzjoni infallibbli.
//! Din il-funzjoni tirritorna riżultat biss minħabba li l-kitba għan-nixxiegħa sottostanti tista 'tfalli u għandha tipprovdi mod kif jinfirex il-fatt li seħħ żball back-up tal-munzell.
//!
//! Eżempju ta 'implimentazzjoni tal-ifformattjar traits ikun qisu:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Il-valur `f` jimplimenta l-`Write` trait, li huwa dak li tikteb!makro qed tistenna.
//!         // Innota li dan l-ifformattjar jinjora d-diversi bnadar ipprovduti għall-format tal-kordi.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // traits differenti jippermettu forom differenti ta 'produzzjoni ta' tip.
//! // It-tifsira ta 'dan il-format hija li tipprintja l-kobor ta' vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Irrispetta l-bnadar tal-ifformattjar billi tuża l-metodu helper `pad_integral` fuq l-oġġett Formatter.
//!         // Ara d-dokumentazzjoni tal-metodu għad-dettalji, u l-funzjoni `pad` tista 'tintuża biex timla l-kordi.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Dawn iż-żewġ ifformattjar ta 'traits għandhom skopijiet distinti:
//!
//! - [`fmt::Display`][`Display`] l-implimentazzjonijiet jaffermaw li t-tip jista 'jkun irrappreżentat fedelment bħala sekwenza UTF-8 f'kull ħin.Huwa **mhux** mistenni li t-tipi kollha jimplimentaw ix-[`Display`] trait.
//! - [`fmt::Debug`][`Debug`] l-implimentazzjonijiet għandhom jiġu implimentati għal **it-tipi** pubbliċi kollha.
//!   Ir-riżultat tipikament jirrappreżenta l-istat intern kemm jista 'jkun lealment.
//!   L-iskop ta [`Debug`] trait huwa li jiffaċilita l-iddibaggjar tal-kodiċi Rust.Fil-biċċa l-kbira tal-każijiet, l-użu ta `#[derive(Debug)]` huwa biżżejjed u rrakkomandat.
//!
//! Xi eżempji tal-produzzjoni miż-żewġ traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Makros relatati
//!
//! Hemm numru ta 'macros relatati fil-familja [`format!`].Dawk li bħalissa huma implimentati huma:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dan u [`writeln!`] huma żewġ macros li jintużaw biex joħorġu s-sekwenza tal-format għal fluss speċifikat.Dan jintuża biex jipprevjeni allokazzjonijiet intermedji ta 'kordi tal-format u minflok jikteb direttament l-output.
//! Taħt il-barnuża, din il-funzjoni fil-fatt qed tinvoka l-funzjoni [`write_fmt`] definita fuq ix-[`std::io::Write`] trait.
//! Eżempju ta 'użu huwa:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dan u [`println!`] jarmu l-output tagħhom lil stdout.Bl-istess mod għall-makro [`write!`], l-għan ta 'dawn il-macros huwa li jiġu evitati allokazzjonijiet intermedji meta tkun stampata l-produzzjoni.Eżempju ta 'użu huwa:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Il-macros [`eprint!`] u [`eprintln!`] huma identiċi għal [`print!`] u [`println!`], rispettivament, ħlief li jarmu l-output tagħhom lil stderr.
//!
//! ### `format_args!`
//!
//! Din hija makro kurjuża użata biex tgħaddi mingħajr periklu oġġett opak li jiddeskrivi s-sekwenza tal-format.Dan l-oġġett ma jeħtieġ l-ebda allokazzjoni ta 'borġ biex jinħoloq, u jirreferi biss informazzjoni fuq il-munzell.
//! Taħt il-barnuża, il-macros relatati kollha huma implimentati f'termini ta 'dan.
//! First off, xi eżempju ta 'użu huwa:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Ir-riżultat tal-makro [`format_args!`] huwa valur tat-tip [`fmt::Arguments`].
//! Din l-istruttura tista 'mbagħad tgħaddi għall-funzjonijiet [`write`] u [`format`] ġewwa dan il-modulu sabiex tiġi pproċessata s-sekwenza tal-format.
//! L-għan ta 'din il-makro huwa li tevita saħansitra aktar allokazzjonijiet intermedji meta tittratta kordi tal-ifformattjar.
//!
//! Pereżempju, librerija tal-illoggjar tista 'tuża s-sintassi standard tal-ifformattjar, iżda tista' tgħaddi internament madwar din l-istruttura sakemm ikun ġie determinat fejn għandha tmur l-output.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Il-funzjoni `format` tieħu struttura [`Arguments`] u tirritorna s-sekwenza fformattjata li tirriżulta.
///
///
/// L-istanza [`Arguments`] tista 'tinħoloq bil-makro [`format_args!`].
///
/// # Examples
///
/// Użu bażiku:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Jekk jogħġbok innota li l-użu ta [`format!`] jista' jkun preferibbli.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}