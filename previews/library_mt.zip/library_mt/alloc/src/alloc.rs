//! APIs tal-allokazzjoni tal-memorja

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Dawn huma s-simboli maġiċi biex tissejjaħ l-allokatur globali.rustc jiġġenerahom biex iċemplu lil `__rg_alloc` eċċ.
    // jekk hemm attribut `#[global_allocator]` (il-kodiċi li jespandi dak l-attribut makro jiġġenera dawk il-funzjonijiet), jew biex issejjaħ l-implimentazzjonijiet default fil-libstd (`__rdl_alloc` eċċ.
    //
    // f `library/std/src/alloc.rs`) mod ieħor.
    // Iż-rustc fork ta 'LLVM ukoll f'każijiet speċjali dawn l-ismijiet tal-funzjoni biex ikunu jistgħu jottimizzawhom bħal `malloc`, `realloc`, u `free`, rispettivament.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// L-allokatur tal-memorja globali.
///
/// Dan it-tip jimplimenta l-[`Allocator`] trait billi jibgħat sejħiet lill-allokatur irreġistrat bl-attribut `#[global_allocator]` jekk hemm wieħed, jew in-nuqqas tal-`std` crate.
///
///
/// Note: filwaqt li dan it-tip mhuwiex stabbli, il-funzjonalità li tipprovdi tista 'tiġi aċċessata permezz tax-[free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Alloka l-memorja bl-allokatur globali.
///
/// Din il-funzjoni tibgħat sejħiet għall-metodu [`GlobalAlloc::alloc`] tal-allokatur irreġistrat bl-attribut `#[global_allocator]` jekk hemm wieħed, jew il-kontumaċja tal-`std` crate.
///
///
/// Din il-funzjoni hija mistennija li titneħħa favur il-metodu `alloc` tat-tip [`Global`] meta dan u [`Allocator`] trait isiru stabbli.
///
/// # Safety
///
/// Ara [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Iddokloka l-memorja mal-allokatur globali.
///
/// Din il-funzjoni tibgħat sejħiet għall-metodu [`GlobalAlloc::dealloc`] tal-allokatur irreġistrat bl-attribut `#[global_allocator]` jekk hemm wieħed, jew il-kontumaċja tal-`std` crate.
///
///
/// Din il-funzjoni hija mistennija li titneħħa favur il-metodu `dealloc` tat-tip [`Global`] meta dan u [`Allocator`] trait isiru stabbli.
///
/// # Safety
///
/// Ara [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Alloka mill-ġdid il-memorja bl-allokatur globali.
///
/// Din il-funzjoni tibgħat sejħiet għall-metodu [`GlobalAlloc::realloc`] tal-allokatur irreġistrat bl-attribut `#[global_allocator]` jekk hemm wieħed, jew il-kontumaċja tal-`std` crate.
///
///
/// Din il-funzjoni hija mistennija li titneħħa favur il-metodu `realloc` tat-tip [`Global`] meta dan u [`Allocator`] trait isiru stabbli.
///
/// # Safety
///
/// Ara [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Alloka memorja inizjalizzata żero bl-allokatur globali.
///
/// Din il-funzjoni tibgħat sejħiet għall-metodu [`GlobalAlloc::alloc_zeroed`] tal-allokatur irreġistrat bl-attribut `#[global_allocator]` jekk hemm wieħed, jew il-kontumaċja tal-`std` crate.
///
///
/// Din il-funzjoni hija mistennija li titneħħa favur il-metodu `alloc_zeroed` tat-tip [`Global`] meta dan u [`Allocator`] trait isiru stabbli.
///
/// # Safety
///
/// Ara [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SIGURTÀ: `layout` mhuwiex żero fid-daqs,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SIGURTÀ: L-istess bħal `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SIGURTÀ: `new_size` mhuwiex żero billi `old_size` huwa akbar minn jew ugwali għal `new_size`
            // kif meħtieġ mill-kundizzjonijiet tas-sigurtà.Kundizzjonijiet oħra għandhom jintlaqgħu minn min iċempel
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` probabbilment jiċċekkja għal `new_size >= old_layout.size()` jew xi ħaġa simili.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SIGURTÀ: għax `new_layout.size()` għandu jkun akbar minn jew ugwali għal `old_size`,
            // kemm l-allokazzjoni tal-memorja l-qadima kif ukoll dik ġdida huma validi għal qari u kitbiet għal bytes `old_size`.
            // Ukoll, minħabba li l-allokazzjoni l-qadima kienet għadha ma ġietx allokata mill-ġdid, ma tistax tirkeb fuq `new_ptr`.
            // Għalhekk, is-sejħa għal `copy_nonoverlapping` hija sigura.
            // Il-kuntratt tas-sigurtà għal `dealloc` għandu jintlaqa 'minn min iċempel.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SIGURTÀ: `layout` mhuwiex żero fid-daqs,
            // kundizzjonijiet oħra għandhom jintlaqgħu minn min iċempel
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURTÀ: il-kundizzjonijiet kollha għandhom jintlaqgħu minn min iċempel
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIGURTÀ: il-kundizzjonijiet kollha għandhom jintlaqgħu minn min iċempel
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SIGURTÀ: il-kundizzjonijiet għandhom jiġu milqugħa minn min iċempel
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SIGURTÀ: `new_size` mhuwiex żero.Kundizzjonijiet oħra għandhom jintlaqgħu minn min iċempel
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` probabbilment jiċċekkja għal `new_size <= old_layout.size()` jew xi ħaġa simili.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SIGURTÀ: għax `new_size` għandu jkun iżgħar minn jew ugwali għal `old_layout.size()`,
            // kemm l-allokazzjoni tal-memorja l-qadima kif ukoll dik ġdida huma validi għal qari u kitbiet għal bytes `new_size`.
            // Ukoll, minħabba li l-allokazzjoni l-qadima kienet għadha ma ġietx allokata mill-ġdid, ma tistax tirkeb fuq `new_ptr`.
            // Għalhekk, is-sejħa għal `copy_nonoverlapping` hija sigura.
            // Il-kuntratt tas-sigurtà għal `dealloc` għandu jintlaqa 'minn min iċempel.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// L-allokatur għal indikaturi uniċi.
// Din il-funzjoni m'għandhiex tinħall.Jekk tagħmel hekk, il-kodiġen MIR ifalli.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Din il-firma trid tkun l-istess bħal `Box`, inkella jiġri ICE.
// Meta parametru addizzjonali għal `Box` jiġi miżjud (bħal `A: Allocator`), dan irid jiżdied hawn ukoll.
// Pereżempju jekk `Box` jinbidel għal `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, din il-funzjoni trid tinbidel ukoll għal `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Immaniġġjar ta 'żball ta' allokazzjoni

extern "Rust" {
    // Dan huwa s-simbolu maġiku biex tissejjaħ il-hand handler tal-iżball allokazzjoni globali
    // rustc jiġġenerah biex iċempel lil `__rg_oom` jekk ikun hemm `#[alloc_error_handler]`, jew inkella biex iċempel l-implimentazzjonijiet default taħt (`__rdl_oom`).
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Abort fuq żball jew falliment ta 'allokazzjoni tal-memorja.
///
/// Dawk li jċemplu l-APIs tal-allokazzjoni tal-memorja li jixtiequ jwaqqfu l-komputazzjoni b'reazzjoni għal żball fl-allokazzjoni huma mħeġġa jsejħu din il-funzjoni, aktar milli jinvokaw direttament `panic!` jew simili.
///
///
/// L-imġieba default ta 'din il-funzjoni hija li tipprintja messaġġ għal żball standard u tabbortixxi l-proċess.
/// Jista 'jiġi sostitwit b [`set_alloc_error_hook`] u [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Għat-test tal-allokazzjoni `std::alloc::handle_alloc_error` jista 'jintuża direttament.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // imsejjaħ permezz ta `__rust_alloc_error_handler` iġġenerat

    // jekk m'hemmx `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // jekk hemm `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Speċjalizza kloni f'memorja mhux allokata minn qabel u mhux inizjalizzata.
/// Użat minn `Box::clone` u `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Wara li allokajt *l-ewwel* jista 'jippermetti lill-ottimizzatur joħloq il-valur klonat fil-post, jaqbeż il-lokal u jiċċaqlaq.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Dejjem nistgħu nikkupjaw fil-post, mingħajr qatt ma ninvolvu valur lokali.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}