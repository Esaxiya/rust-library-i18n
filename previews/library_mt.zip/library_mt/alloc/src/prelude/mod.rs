//! L-allok Prelude
//!
//! L-iskop ta 'dan il-modulu huwa li jtaffi l-importazzjonijiet ta' oġġetti użati b'mod komuni tax-`alloc` crate billi żżid importazzjoni ta 'glob mal-parti ta' fuq tal-moduli:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;