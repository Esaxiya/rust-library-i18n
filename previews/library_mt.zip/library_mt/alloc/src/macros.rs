/// Joħloq [`Vec`] li jkun fih l-argumenti.
///
/// `vec!` jippermetti li Vec`s jiġu definiti bl-istess sintassi bħall-espressjonijiet tal-firxa.
/// Hemm żewġ forom ta 'din il-makro:
///
/// - Oħloq [`Vec`] li fih lista mogħtija ta 'elementi:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Oħloq [`Vec`] minn element u daqs partikolari:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Innota li b'differenza mill-espressjonijiet tal-firxa din is-sintassi tappoġġja l-elementi kollha li jimplimentaw [`Clone`] u n-numru ta 'elementi m'għandux għalfejn ikun kostanti.
///
/// Dan se juża `clone` biex jidduplika espressjoni, allura wieħed għandu joqgħod attent billi juża din b'tipi li għandhom implimentazzjoni `Clone` mhux standard.
/// Pereżempju, `vec![Rc::new(1);5] "se toħloq vector ta 'ħames referenzi għall-istess valur ta' numru sħiħ f'kaxxa, mhux ħames referenzi li jindikaw għal numru sħiħ f'kaxxi indipendenti.
///
///
/// Innota wkoll li `vec![expr; 0]` huwa permess, u jipproduċi vector vojt.
/// Dan xorta se jevalwa `expr`, madankollu, u jwaqqa 'immedjatament il-valur li jirriżulta, għalhekk kun attent għall-effetti sekondarji.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): b cfg(test) il-metodu inerenti `[T]::into_vec`, li huwa meħtieġ għal din id-definizzjoni makro, mhuwiex disponibbli.
// Minflok uża l-funzjoni `slice::into_vec` li hija disponibbli biss b cfg(test) NB ara l-modulu slice::hack f slice.rs għal aktar informazzjoni
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Joħloq `String` billi juża interpolazzjoni ta 'espressjonijiet ta' runtime.
///
/// L-ewwel argument li jirċievi `format!` huwa format string.Dan għandu jkun string litterali.Il-qawwa tas-sekwenza tal-ifformattjar tinsab f '"{}` s li jinsabu.
///
/// Parametri addizzjonali mgħoddija lil `format!` jissostitwixxu l-"{}` s fis-sekwenza tal-ifformattjar fl-ordni mogħtija sakemm ma jintużawx parametri msemmija jew pożizzjonali;ara [`std::fmt`] għal aktar informazzjoni.
///
///
/// Użu komuni għal `format!` huwa l-konkatenazzjoni u l-interpolazzjoni ta 'kordi.
/// L-istess konvenzjoni tintuża mal-macros [`print!`] u [`write!`], skont id-destinazzjoni maħsuba tas-sekwenza.
///
/// Biex tikkonverti valur wieħed għal sekwenza, uża l-metodu [`to_string`].Dan se juża l-ifformattjar [`Display`] trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics jekk implimentazzjoni tal-ifformattjar ta 'trait tirritorna żball.
/// Dan jindika implimentazzjoni ħażina peress li `fmt::Write for String` qatt ma jirritorna żball innifsu.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Forza nodu AST għal espressjoni biex ittejjeb id-dijanjostika fil-pożizzjoni tal-mudell.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}