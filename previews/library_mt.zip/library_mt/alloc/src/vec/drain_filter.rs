use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Iteratur li juża għeluq biex jiddetermina jekk element għandux jitneħħa.
///
/// Din l-istruttura hija maħluqa minn [`Vec::drain_filter`].
/// Ara d-dokumentazzjoni tagħha għal aktar.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// L-indiċi tal-oġġett li se jiġi spezzjonat mis-sejħa li jmiss għal `next`.
    pub(super) idx: usize,
    /// In-numru ta 'oġġetti li ġew skulati (removed) s'issa.
    pub(super) del: usize,
    /// It-tul oriġinali ta `vec` qabel l-iskular.
    pub(super) old_len: usize,
    /// Il-predikat tat-test tal-filtru.
    pub(super) pred: F,
    /// Bandiera li tindika panic seħħet fil-predikat tat-test tal-filtru.
    /// Dan jintuża bħala ħjiel fl-implimentazzjoni tal-waqgħa biex jipprevjeni l-konsum tal-bqija tax-`DrainFilter`.
    /// Kwalunkwe oġġett mhux ipproċessat jinbidel lura fix-`vec`, iżda l-ebda oġġett ieħor ma jitwaqqa 'jew jiġi ttestjat mill-predikat tal-filtru.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Jirritorna referenza għall-allokatur sottostanti.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Aġġorna l-indiċi *wara* li tissejjaħ il-predikat.
                // Jekk l-indiċi jiġi aġġornat minn qabel u l-predikat panics, l-element f'dan l-indiċi jitneħħa.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // Dan huwa stat pjuttost imħawwad, u m'hemmx verament ħaġa ovvja t-tajba li tagħmel.
                        // Ma rridux nibqgħu nippruvaw neżegwixxu `pred`, allura aħna sempliċement naqilbu lura l-elementi kollha mhux ipproċessati u ngħidu lill-vec li għadhom jeżistu.
                        //
                        // Il-bidla lura hija meħtieġa biex tevita qatra doppja ta 'l-aħħar oġġett imsaffi b'suċċess qabel panic fil-predikat.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Ipprova jikkunsma kwalunkwe element li jifdal jekk il-predikat tal-filtru għadu ma qabadx paniku.
        // Aħna ser nimxu lura kwalunkwe element li jkun fadal kemm jekk diġà ħadna paniku jew jekk il-konsum hawnhekk panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}