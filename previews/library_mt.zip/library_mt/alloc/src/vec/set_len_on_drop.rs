// Issettja t-tul tal-vec meta l-valur `SetLenOnDrop` joħroġ mill-ambitu.
//
// L-idea hi: Il-qasam tat-tul f'SetLenOnDrop huwa varjabbli lokali li l-ottimizzatur se jara ma juri l-ebda ħanut permezz tal-indikatur tad-dejta tal-Vec.
// Din hija soluzzjoni għall-alias issue issue #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}