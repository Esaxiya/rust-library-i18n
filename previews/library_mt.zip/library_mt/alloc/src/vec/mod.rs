//! Tip ta 'array li jista' jitkabbar kontigwu b'kontenut allokat mill-borġ, miktub `Vec<T>`.
//!
//! Vectors għandhom indiċjar `O(1)`, push amortizzat `O(1)` (sat-tmiem) u `O(1)` pop (mit-tmiem).
//!
//!
//! Vectors jiżguraw li qatt ma jallokaw aktar minn `isize::MAX` bytes.
//!
//! # Examples
//!
//! Tista 'b'mod espliċitu toħloq [`Vec`] b [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... jew billi tuża l-makro [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // għaxar żero
//! ```
//!
//! Tista 'valuri [`push`] fit-tarf ta' vector (li jikber iż-vector kif meħtieġ):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Il-valuri popping jaħdem bl-istess mod:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors jappoġġjaw ukoll l-indiċjar (permezz tax-[`Index`] u [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Tip ta `array li jista` jitkabbar kontigwi, miktub bħala `Vec<T>` u pronunzjat 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Il-makro [`vec!`] huwa pprovdut biex l-inizjalizzazzjoni ssir iktar konvenjenti:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Jista 'wkoll inizjalizza kull element ta' `Vec<T>` b'valur mogħti.
/// Dan jista 'jkun aktar effiċjenti milli jwettaq allokazzjoni u inizjalizzazzjoni fi stadji separati, speċjalment meta jiġi inizjalizzat vector ta' żerijiet:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Dan li ġej huwa ekwivalenti, iżda potenzjalment aktar bil-mod:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Għal aktar informazzjoni, ara [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Uża `Vec<T>` bħala munzell effiċjenti:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Stampi 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// It-tip `Vec` jippermetti aċċess għall-valuri skont l-indiċi, minħabba li jimplimenta l-[`Index`] trait.Eżempju jkun aktar espliċitu:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // se juri '2'
/// ```
///
/// Madankollu oqgħod attent: jekk tipprova taċċessa indiċi li mhuwiex fix-`Vec`, is-softwer tiegħek se panic!Ma tistax tagħmel dan:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Uża [`get`] u [`get_mut`] jekk trid tivverifika jekk l-indiċi huwiex fix-`Vec`.
///
/// # Slicing
///
/// `Vec` jista 'jinbidel.Min-naħa l-oħra, il-flieli huma oġġetti li jinqraw biss.
/// Biex tikseb [slice][prim@slice], uża [`&`].Eżempju:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... u dak kollu!
/// // tista 'wkoll tagħmel hekk:
/// let u: &[usize] = &v;
/// // jew bħal dan:
/// let u: &[_] = &v;
/// ```
///
/// F'Rust, huwa iktar komuni li tgħaddi slices bħala argumenti aktar milli vectors meta trid biss tipprovdi aċċess għall-qari.L-istess jgħodd għal [`String`] u [`&str`].
///
/// # Kapaċità u riallokazzjoni
///
/// Il-kapaċità ta 'vector hija l-ammont ta' spazju allokat għal kwalunkwe element future li se jiżdied ma 'vector.Dan m'għandux jiġi konfuż mat-*tul* ta 'vector, li jispeċifika n-numru ta' elementi attwali fi ħdan vector.
/// Jekk it-tul ta 'vector jaqbeż il-kapaċità tiegħu, il-kapaċità tiegħu awtomatikament tiżdied, iżda l-elementi tiegħu jkollhom jiġu riallokati.
///
/// Pereżempju, vector b'kapaċità 10 u tul 0 ikun vector vojt bi spazju għal 10 elementi oħra.Li timbotta 10 elementi jew inqas fuq iż-vector ma tbiddilx il-kapaċità tagħha jew tikkawża riallokazzjoni.
/// Madankollu, jekk it-tul taż-vector jiżdied għal 11, ikollu jalloka mill-ġdid, li jista 'jkun bil-mod.Għal din ir-raġuni, huwa rrakkomandat li tuża [`Vec::with_capacity`] kull meta jkun possibbli biex tispeċifika kemm hu kbir iż-vector li mistenni jikseb.
///
/// # Guarantees
///
/// Minħabba n-natura fundamentali oerhört tiegħu, `Vec` jagħmel ħafna garanziji dwar id-disinn tiegħu.Dan jiżgura li huwa baxx kemm jista 'jkun fil-każ ġenerali, u jista' jiġi mmanipulat b'mod korrett b'modi primittivi permezz ta 'kodiċi mhux sikur.Innota li dawn il-garanziji jirreferu għal `Vec<T>` mhux kwalifikat.
/// Jekk jiżdiedu parametri tat-tip addizzjonali (eż., Biex jappoġġjaw allokaturi tad-dwana), l-iskadenza tad-difetti tagħhom tista 'tbiddel l-imġieba.
///
/// L-iktar fundamentalment, `Vec` huwa u dejjem se jkun triplet (pointer, kapaċità, tul).Mhux iktar, xejn inqas.L-ordni ta 'dawn l-oqsma mhix speċifikata għal kollox, u għandek tuża l-metodi xierqa biex timmodifikahom.
/// Il-pointer qatt mhu se jkun null, allura dan it-tip huwa null-pointer-optimized.
///
/// Madankollu, il-pointer jista 'fil-fatt ma jindikax il-memorja allokata.
/// B'mod partikolari, jekk tibni `Vec` b'kapaċità 0 permezz ta [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], jew billi ċċempel [`shrink_to_fit`] fuq Vec vojt, ma jallokax memorja.Bl-istess mod, jekk taħżen tipi ta 'daqs żero ġewwa `Vec`, ma jallokax spazju għalihom.
/// *Innota li f'dan il-każ ix-`Vec` jista 'ma jirrapportax [`capacity`] ta' 0*.
/// `Vec` se talloka jekk u biss jekk [`mem: : size_of::<T>"]"() * capacity()> 0".
/// Ġeneralment, id-dettalji tal-allokazzjoni ta '"Vec" huma sottili ħafna-jekk għandek il-ħsieb li talloka memorja billi tuża `Vec` u tużaha għal xi ħaġa oħra (jew biex tgħaddi għal kodiċi mhux sikur, jew biex tibni l-ġabra tiegħek appoġġjata mill-memorja), kun żgur biex tqassam din il-memorja billi tuża `from_raw_parts` biex tirkupra l-`Vec` u mbagħad twaqqa '.
///
/// Jekk `Vec`*għandu* allokat memorja, allura l-memorja li tipponta għaliha hija fuq il-borġ (kif definit mill-allokatur Rust huwa kkonfigurat biex jintuża awtomatikament), u l-pointer tiegħu jindika lejn [`len`] inizjalizzat, elementi kontigwi fl-ordni (dak li tkun ara jekk sfurzajtiex f'qatgħa), segwit minn [`kapaċità`]`,`[`len`] elementi loġikament mhux inizjalizzati, kontigwi.
///
///
/// vector li fih l-elementi `'a'` u `'b'` b'kapaċità 4 jista 'jiġi viżwalizzat kif ġej.Il-parti ta 'fuq hija l-istruttura `Vec`, fiha pointer għar-ras tal-allokazzjoni fil-borġ, it-tul u l-kapaċità.
/// Il-parti t'isfel hija l-allokazzjoni fuq il-borġ, blokka tal-memorja kontigwa.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** tirrappreżenta memorja li mhix inizjalizzata, ara [`MaybeUninit`].
/// - Note: l-ABI mhix stabbli u `Vec` ma jagħmel l-ebda garanzija dwar it-tqassim tal-memorja tiegħu (inkluż l-ordni tal-oqsma).
///
/// `Vec` qatt ma jwettaq "small optimization" fejn l-elementi huma attwalment maħżuna fuq il-munzell għal żewġ raġunijiet:
///
/// * Ikun iktar diffiċli għal kodiċi mhux sikur biex jimmanipula b'mod korrett `Vec`.Il-kontenut ta `Vec` ma jkollux indirizz stabbli kieku ġie mċaqlaq biss, u jkun iktar diffiċli li jiġi ddeterminat jekk `Vec` kienx effettivament alloka memorja.
///
/// * Ikun jippenalizza l-każ ġenerali, u jġarrab branch addizzjonali fuq kull aċċess.
///
/// `Vec` qatt ma jiċkien awtomatikament innifsu, anke jekk kompletament vojt.Dan jiżgura li ma jseħħu l-ebda allokazzjonijiet jew deallokazzjonijiet bla bżonn.It-tbattil ta `Vec` u mbagħad timlaha lura għall-istess [`len`] m'għandux iġarrab sejħiet lill-allokatur.Jekk tixtieq teħles memorja mhux użata, uża [`shrink_to_fit`] jew [`shrink_to`].
///
/// [`push`] u [`insert`] qatt ma jallokaw (mill-ġdid) jekk il-kapaċità rrappurtata tkun biżżejjed.[`push`] u [`insert`]*se*(jerġgħu) jallokaw jekk [`len`]`==`[`kapaċità`].Jiġifieri, il-kapaċità rrappurtata hija kompletament preċiża, u tista 'tiġi invokata.Jista 'jintuża wkoll biex jeħles manwalment il-memorja allokata minn `Vec` jekk mixtieq.
/// Metodi ta 'inserzjoni bil-massa *jistgħu* jallokaw mill-ġdid, anke meta mhux meħtieġ.
///
/// `Vec` ma tiggarantix xi strateġija ta 'tkabbir partikolari meta tkun allokata mill-ġdid meta tkun sħiħa, u lanqas meta tissejjaħ [`reserve`].L-istrateġija attwali hija bażika u jista 'jkun mixtieq li jintuża fattur ta' tkabbir mhux kostanti.Tkun xi tkun l-istrateġija użata naturalment tiggarantixxi *O*(1) [`push`] amortizzat.
///
/// `vec![x; n]`, `vec![a, b, c, d]`, u [`Vec::with_capacity(n)`][`Vec::with_capacity`], kollha jipproduċu `Vec` b'eżattament il-kapaċità mitluba.
/// Jekk [`len`]`==`[`kapaċità`], (kif inhu l-każ għall-makro [`vec!`]), allura `Vec<T>` jista 'jiġi kkonvertit għal u minn [`Box<[T]>`][owned slice] mingħajr ma jalloka mill-ġdid jew iċċaqlaq l-elementi.
///
/// `Vec` mhux se jissostitwixxi speċifikament kwalunkwe dejta li titneħħa minnha, iżda lanqas ma tippreservaha speċifikament.Il-memorja mhux inizjalizzata tagħha hija spazju għall-bidu li tista 'tuża kif trid.Ġeneralment tagħmel dak kollu li hu l-aktar effiċjenti jew inkella faċli biex jiġi implimentat.Tiddependix fuq dejta mneħħija biex titħassar għal skopijiet ta 'sigurtà.
/// Anki jekk twaqqa `Vec`, il-buffer tiegħu jista' sempliċement jerġa 'jintuża minn `Vec` ieħor.
/// Anki jekk l-ewwel tpoġġi żero memorja ta '"Vec", dak jista' ma jiġrix fil-fatt għax l-ottimizzatur ma jqisx dan bħala effett sekondarju li jrid jiġi ppreservat.
/// Hemm każ wieħed li aħna ma nkissrux, madankollu: l-użu tal-kodiċi `unsafe` biex tikteb lill-kapaċità żejda, u mbagħad iżżid it-tul biex taqbel, huwa dejjem validu.
///
/// Bħalissa, `Vec` ma jiggarantixxix l-ordni li fiha jitwaqqgħu l-elementi.
/// L-ordni nbidlet fil-passat u tista 'terġa' tinbidel.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Metodi inerenti
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Jibni `Vec<T>` ġdid u vojt.
    ///
    /// Iż-vector mhux se jalloka sakemm l-elementi jiġu mbuttati fuqu.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Jibni `Vec<T>` ġdid vojt bil-kapaċità speċifikata.
    ///
    /// Iż-vector ikun jista 'jżomm eżattament elementi `capacity` mingħajr ma jalloka mill-ġdid.
    /// Jekk `capacity` huwa 0, iż-vector ma jallokax.
    ///
    /// Huwa importanti li wieħed jinnota li għalkemm iż-vector mibgħut lura għandu l-*kapaċità* speċifikata, iż-vector ikollu tul *żero*.
    ///
    /// Għal spjegazzjoni tad-differenza bejn it-tul u l-kapaċità, ara *[Kapaċità u riallokazzjoni]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // Iż-vector ma fih l-ebda oġġett, anke jekk għandu kapaċità għal aktar
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Dawn kollha jsiru mingħajr riallokazzjoni ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... imma dan jista 'jagħmel li vector jalloka mill-ġdid
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Joħloq `Vec<T>` direttament mill-komponenti nejjin ta 'vector ieħor.
    ///
    /// # Safety
    ///
    /// Dan huwa perikoluż ħafna, minħabba n-numru ta 'invariants li mhumiex iċċekkjati:
    ///
    /// * `ptr` jeħtieġ li ġie allokat qabel permezz ta '[`String`]/`Vec<T>"(għallinqas, huwa probabbli ħafna li ma jkunx korrett jekk ma kienx).
    /// * `T` jeħtieġ li jkollu l-istess daqs u allinjament bħal dak li ġie allokat miegħu `ptr`.
    ///   (`T` li jkollu allinjament inqas strett mhuwiex biżżejjed, l-allinjament verament jeħtieġ li jkun ugwali biex jissodisfa r-rekwiżit [`dealloc`] li l-memorja trid tiġi allokata u allokata mill-ġdid bl-istess tqassim.)
    ///
    /// * `length` jeħtieġ li jkun inqas minn jew ugwali għal `capacity`.
    /// * `capacity` jeħtieġ li jkun il-kapaċità li magħha ġie allokat il-pointer.
    ///
    /// Il-ksur ta 'dawn jista' jikkawża problemi bħall-korruzzjoni tal-istrutturi interni tad-dejta tal-allokatur.Pereżempju mhuwiex ** sikur li tibni `Vec<u8>` minn pointer għal array C `char` b'tul `size_t`.
    /// Mhuwiex sigur ukoll li tibni wieħed minn `Vec<u16>` u t-tul tiegħu, minħabba li l-allokatur jimpurtah mill-allinjament, u dawn iż-żewġ tipi għandhom allinjamenti differenti.
    /// Il-buffer ġie allokat bl-allinjament 2 (għal `u16`), iżda wara li jibdlu f `Vec<u8>` se jiġi allokat mill-ġdid bl-allinjament 1.
    ///
    /// Is-sjieda ta `ptr` hija effettivament trasferita għax-`Vec<T>` li mbagħad tista' titqassam, tirrialloka jew tbiddel il-kontenut tal-memorja indikat mill-indikatur kif trid.
    /// Kun żgur li xejn iktar ma juża l-pointer wara li ssejjaħ din il-funzjoni.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Aġġorna dan meta vec_into_raw_parts jiġi stabbilizzat.
    ///     // Evita li tħaddem 'v`'s destructor u allura aħna ninsabu f'kontroll sħiħ tal-allokazzjoni.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Iġbed id-diversi biċċiet importanti ta 'informazzjoni dwar `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Ikteb il-memorja b'4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Poġġi kollox lura flimkien f'Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Jibni `Vec<T, A>` ġdid u vojt.
    ///
    /// Iż-vector mhux se jalloka sakemm l-elementi jiġu mbuttati fuqu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Jibni `Vec<T, A>` ġdid vojt bil-kapaċità speċifikata bl-allokatur ipprovdut.
    ///
    /// Iż-vector ikun jista 'jżomm eżattament elementi `capacity` mingħajr ma jalloka mill-ġdid.
    /// Jekk `capacity` huwa 0, iż-vector ma jallokax.
    ///
    /// Huwa importanti li wieħed jinnota li għalkemm iż-vector mibgħut lura għandu l-*kapaċità* speċifikata, iż-vector ikollu tul *żero*.
    ///
    /// Għal spjegazzjoni tad-differenza bejn it-tul u l-kapaċità, ara *[Kapaċità u riallokazzjoni]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // Iż-vector ma fih l-ebda oġġett, anke jekk għandu kapaċità għal aktar
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Dawn kollha jsiru mingħajr riallokazzjoni ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... imma dan jista 'jagħmel li vector jalloka mill-ġdid
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Joħloq `Vec<T, A>` direttament mill-komponenti nejjin ta 'vector ieħor.
    ///
    /// # Safety
    ///
    /// Dan huwa perikoluż ħafna, minħabba n-numru ta 'invariants li mhumiex iċċekkjati:
    ///
    /// * `ptr` jeħtieġ li ġie allokat qabel permezz ta '[`String`]/`Vec<T>"(għallinqas, huwa probabbli ħafna li ma jkunx korrett jekk ma kienx).
    /// * `T` jeħtieġ li jkollu l-istess daqs u allinjament bħal dak li ġie allokat miegħu `ptr`.
    ///   (`T` li jkollu allinjament inqas strett mhuwiex biżżejjed, l-allinjament verament jeħtieġ li jkun ugwali biex jissodisfa r-rekwiżit [`dealloc`] li l-memorja trid tiġi allokata u allokata mill-ġdid bl-istess tqassim.)
    ///
    /// * `length` jeħtieġ li jkun inqas minn jew ugwali għal `capacity`.
    /// * `capacity` jeħtieġ li jkun il-kapaċità li magħha ġie allokat il-pointer.
    ///
    /// Il-ksur ta 'dawn jista' jikkawża problemi bħall-korruzzjoni tal-istrutturi interni tad-dejta tal-allokatur.Pereżempju mhuwiex ** sikur li tibni `Vec<u8>` minn pointer għal array C `char` b'tul `size_t`.
    /// Mhuwiex sigur ukoll li tibni wieħed minn `Vec<u16>` u t-tul tiegħu, minħabba li l-allokatur jimpurtah mill-allinjament, u dawn iż-żewġ tipi għandhom allinjamenti differenti.
    /// Il-buffer ġie allokat bl-allinjament 2 (għal `u16`), iżda wara li jibdlu f `Vec<u8>` se jiġi allokat mill-ġdid bl-allinjament 1.
    ///
    /// Is-sjieda ta `ptr` hija effettivament trasferita għax-`Vec<T>` li mbagħad tista' titqassam, tirrialloka jew tbiddel il-kontenut tal-memorja indikat mill-indikatur kif trid.
    /// Kun żgur li xejn iktar ma juża l-pointer wara li ssejjaħ din il-funzjoni.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Aġġorna dan meta vec_into_raw_parts jiġi stabbilizzat.
    ///     // Evita li tħaddem 'v`'s destructor u allura aħna ninsabu f'kontroll sħiħ tal-allokazzjoni.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Iġbed id-diversi biċċiet importanti ta 'informazzjoni dwar `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Ikteb il-memorja b'4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Poġġi kollox lura flimkien f'Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Tiddekomponi `Vec<T>` fil-komponenti nej tiegħu.
    ///
    /// Irritorna l-indikatur mhux ipproċessat għad-dejta sottostanti, it-tul taż-vector (f'elementi), u l-kapaċità allokata tad-dejta (f'elementi).
    /// Dawn huma l-istess argumenti fl-istess ordni bħall-argumenti għal [`from_raw_parts`].
    ///
    /// Wara li ssejjaħ din il-funzjoni, min iċempel huwa responsabbli għall-memorja li qabel kienet immaniġġjata mix-`Vec`.
    /// L-uniku mod biex tagħmel dan huwa li tikkonverti l-pointer nej, it-tul u l-kapaċità lura f `Vec` bil-funzjoni [`from_raw_parts`], li tippermetti lid-distruttur iwettaq it-tindif.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Issa nistgħu nagħmlu bidliet fil-komponenti, bħat-trasmutazzjoni tal-pointer nej għal tip kompatibbli.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Tiddekomponi `Vec<T>` fil-komponenti nej tiegħu.
    ///
    /// Irritorna l-indikatur nej għad-dejta sottostanti, it-tul taż-vector (f'elementi), il-kapaċità allokata tad-dejta (f'elementi), u l-allokatur.
    /// Dawn huma l-istess argumenti fl-istess ordni bħall-argumenti għal [`from_raw_parts_in`].
    ///
    /// Wara li ssejjaħ din il-funzjoni, min iċempel huwa responsabbli għall-memorja li qabel kienet immaniġġjata mix-`Vec`.
    /// L-uniku mod biex tagħmel dan huwa li tikkonverti l-pointer nej, it-tul u l-kapaċità lura f `Vec` bil-funzjoni [`from_raw_parts_in`], li tippermetti lid-distruttur iwettaq it-tindif.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Issa nistgħu nagħmlu bidliet fil-komponenti, bħat-trasmutazzjoni tal-pointer nej għal tip kompatibbli.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Jirritorna n-numru ta 'elementi li ż-vector jista' jżomm mingħajr ma jalloka mill-ġdid.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Jirriżerva kapaċità għal mill-inqas `additional` aktar elementi biex jiddaħħlu fix-`Vec<T>` mogħti.
    /// Il-kollezzjoni tista 'tirriżerva aktar spazju biex tevita riallokazzjonijiet frekwenti.
    /// Wara li ċċempel lil `reserve`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional`.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà biżżejjed.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida taqbeż `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Jirriżerva l-kapaċità minima għal eżattament `additional` aktar elementi biex jiddaħħlu fix-`Vec<T>` mogħti.
    ///
    /// Wara li ċċempel lil `reserve_exact`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional`.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà suffiċjenti.
    ///
    /// Innota li l-allokatur jista 'jagħti lill-kollezzjoni aktar spazju milli jitlob.
    /// Għalhekk, il-kapaċità ma tistax tiġi invokata biex tkun preċiżament minima.
    /// Ippreferi `reserve` jekk huma mistennija inserzjonijiet future.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida tfur `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Jipprova jirriserva kapaċità għal mill-inqas `additional` aktar elementi li għandhom jiddaħħlu fix-`Vec<T>` mogħti.
    /// Il-kollezzjoni tista 'tirriżerva aktar spazju biex tevita riallokazzjonijiet frekwenti.
    /// Wara li ċċempel lil `try_reserve`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional`.
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà biżżejjed.
    ///
    /// # Errors
    ///
    /// Jekk il-kapaċità tfur, jew l-allokatur jirrapporta falliment, allura jiġi rritornat żball.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Irriserva minn qabel il-memorja, u toħroġ jekk ma nistgħux
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Issa nafu li dan ma jistax OOM fin-nofs tax-xogħol kumpless tagħna
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ikkumplikata ħafna
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Jipprova jirriserva l-kapaċità minima għal elementi eżattament `additional` li għandhom jiddaħħlu fix-`Vec<T>` mogħti.
    /// Wara li ċċempel lil `try_reserve_exact`, il-kapaċità tkun akbar minn jew ugwali għal `self.len() + additional` jekk tirritorna `Ok(())`.
    ///
    /// Ma jagħmel xejn jekk il-kapaċità hija diġà suffiċjenti.
    ///
    /// Innota li l-allokatur jista 'jagħti lill-kollezzjoni aktar spazju milli jitlob.
    /// Għalhekk, il-kapaċità ma tistax tiġi invokata biex tkun preċiżament minima.
    /// Ippreferi `reserve` jekk huma mistennija inserzjonijiet future.
    ///
    /// # Errors
    ///
    /// Jekk il-kapaċità tfur, jew l-allokatur jirrapporta falliment, allura jiġi rritornat żball.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Irriserva minn qabel il-memorja, u toħroġ jekk ma nistgħux
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Issa nafu li dan ma jistax OOM fin-nofs tax-xogħol kumpless tagħna
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // ikkumplikata ħafna
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Iċekken il-kapaċità taż-vector kemm jista 'jkun.
    ///
    /// Se tinżel viċin kemm jista 'jkun tat-tul iżda l-allokatur xorta jista' jinforma liż-vector li hemm spazju għal ftit elementi oħra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Il-kapaċità qatt mhija inqas mit-tul, u m'hemm xejn x'jagħmlu meta jkunu ndaqs, allura nistgħu nevitaw il-każ panic f `RawVec::shrink_to_fit` billi nsejħulu biss b'kapaċità akbar.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Iċċekken il-kapaċità taż-vector b'limitu aktar baxx.
    ///
    /// Il-kapaċità tibqa 'mill-inqas kbira kemm tat-tul kif ukoll tal-valur fornut.
    ///
    ///
    /// Jekk il-kapaċità kurrenti hija inqas mil-limitu l-iktar baxx, dan huwa no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Ikkonverti ż-vector f [`Box<[T]>`][owned slice].
    ///
    /// Innota li dan se jwaqqa 'kwalunkwe kapaċità żejda.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Kwalunkwe kapaċità żejda titneħħa:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Tqassar iż-vector, billi żżomm l-ewwel elementi `len` u twaqqa 'l-bqija.
    ///
    /// Jekk `len` huwa akbar mit-tul kurrenti taż-vector, dan m'għandux effett.
    ///
    /// Il-metodu [`drain`] jista 'jimita `truncate`, iżda jikkawża li l-elementi żejda jiġu rritornati minflok jitwaqqgħu.
    ///
    ///
    /// Innota li dan il-metodu m'għandu l-ebda effett fuq il-kapaċità allokata taż-vector.
    ///
    /// # Examples
    ///
    /// It-tqattigħ ta 'ħames element vector għal żewġ elementi:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ma sseħħ l-ebda qtugħ meta `len` huwa akbar mit-tul kurrenti taż-vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// It-tqattigħ meta `len == 0` huwa ekwivalenti għal sejħa għall-metodu [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Dan huwa sigur għax:
        //
        // * il-porzjon mgħoddi lil `drop_in_place` huwa validu;il-każ `len > self.len` jevita l-ħolqien ta 'porzjon invalidu, u
        // * ix-`len` taż-vector huwa mċekken qabel ma ċċempel lil `drop_in_place`, b'tali mod li l-ebda valur ma jitwaqqa 'darbtejn f'każ li `drop_in_place` kienu għal panic darba (jekk panics darbtejn, il-programm jieqaf).
        //
        //
        //
        unsafe {
            // Note: Huwa intenzjonat li dan huwa `>` u mhux `>=`.
            //       Li tibdilha għal `>=` għandu implikazzjonijiet ta 'prestazzjoni negattivi f'xi każijiet.
            //       Ara #78884 għal aktar.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Estratti porzjon li fih iż-vector kollu.
    ///
    /// Ekwivalenti għal `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Estratti porzjon li jista 'jinbidel taż-vector kollu.
    ///
    /// Ekwivalenti għal `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Jirritorna pointer nej għall-buffer taż-vector.
    ///
    /// Min iċempel għandu jiżgura li ż-vector jegħleb il-pointer li tirritorna din il-funzjoni, jew inkella jispiċċa jindika ż-żibel.
    /// Il-modifika ta 'vector tista' tikkawża li l-buffer tiegħu jiġi riallokat, u dan jagħmel ukoll kwalunkwe indikaturi invalidi.
    ///
    /// Min iċempel għandu wkoll jiżgura li l-memorja li l-pointer (non-transitively) jindika għaliha qatt ma tinkiteb (ħlief ġewwa `UnsafeCell`) billi tuża dan il-pointer jew kwalunkwe pointer derivat minnu.
    /// Jekk għandek bżonn tibdel il-kontenut tal-porzjon, uża [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Aħna nużaw il-metodu porzjon tal-istess isem biex nevitaw li ngħaddu minn `deref`, li joħloq referenza intermedja.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Jirritorna pointer mutabbli mhux sikur fil-buffer taż-vector.
    ///
    /// Min iċempel għandu jiżgura li ż-vector jegħleb il-pointer li tirritorna din il-funzjoni, jew inkella jispiċċa jindika ż-żibel.
    ///
    /// Il-modifika ta 'vector tista' tikkawża li l-buffer tiegħu jiġi riallokat, u dan jagħmel ukoll kwalunkwe indikaturi invalidi.
    ///
    /// # Examples
    ///
    /// ```
    /// // Alloka vector kbir biżżejjed għal 4 elementi.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Inizjalizza l-elementi permezz ta 'kitba tal-pointer mhux maħduma, imbagħad issettja t-tul.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Aħna nużaw il-metodu porzjon tal-istess isem biex nevitaw li ngħaddu minn `deref_mut`, li joħloq referenza intermedja.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Jirritorna referenza għall-allokatur sottostanti.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Forza t-tul taż-vector għal `new_len`.
    ///
    /// Din hija operazzjoni ta 'livell baxx li ma żżomm l-ebda waħda mill-invarianti normali tat-tip.
    /// Normalment it-tibdil tat-tul ta 'vector isir bl-użu ta' waħda mill-operazzjonijiet sikuri minflok, bħal [`truncate`], [`resize`], [`extend`], jew [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` għandu jkun inqas minn jew ugwali għal [`capacity()`].
    /// - L-elementi f `old_len..new_len` għandhom jiġu inizjalizzati.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Dan il-metodu jista 'jkun utli għal sitwazzjonijiet li fihom iż-vector qed iservi bħala buffer għal kodiċi ieħor, partikolarment fuq FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dan huwa biss skeletru minimu għall-eżempju tad-dok;
    /// # // tużax dan bħala punt tat-tluq għal librerija vera.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Skond id-dokumenti tal-metodu FFI, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SIGURTÀ: Meta `deflateGetDictionary` jirritorna `Z_OK`, iżomm li:
    ///     // 1. `dict_length` elementi ġew inizjalizzati.
    ///     // 2.
    ///     // `dict_length` <=il-kapaċità (32_768) li tagħmel lil `set_len` sikur li ċċempel.
    ///     unsafe {
    ///         // Agħmel is-sejħa FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... u aġġorna t-tul għal dak li ġie inizjalizzat.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Filwaqt li l-eżempju li ġej huwa tajjeb, hemm tnixxija tal-memorja peress li ż-vectors ta 'ġewwa ma ġewx meħlusa qabel is-sejħa `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` huwa vojt u għalhekk l-ebda element ma għandu bżonn jiġi inizjalizzat.
    /// // 2. `0 <= capacity` dejjem iżomm x'inhu `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalment, hawnhekk, wieħed juża [`clear`] minflok biex iwaqqa 'l-kontenut b'mod korrett u b'hekk ma jnixxix il-memorja.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Tneħħi element miż-vector u tirritornah.
    ///
    /// L-element imneħħi huwa sostitwit bl-aħħar element taż-vector.
    ///
    /// Dan ma jippreservax l-ordnijiet, iżda huwa O(1).
    ///
    /// # Panics
    ///
    /// Panics jekk `index` huwa barra mill-limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Nissostitwixxu self [index] bl-aħħar element.
            // Innota li jekk il-kontroll tal-limiti ta 'hawn fuq jirnexxi għandu jkun hemm l-aħħar element (li jista' jkun innifsu [indiċi] innifsu).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Daħħal element fil-pożizzjoni `index` fi ħdan iż-vector, billi ċċaqlaq l-elementi kollha warajh lejn il-lemin.
    ///
    ///
    /// # Panics
    ///
    /// Panics jekk `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // spazju għall-element il-ġdid
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // infallibbli Il-post biex tpoġġi l-valur il-ġdid
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Aqleb kollox biex tagħmel l-ispazju.
                // (Id-duplikazzjoni tal-element "index" f'żewġ postijiet konsekuttivi.)
                ptr::copy(p, p.offset(1), len - index);
                // Ikteb fih, kitba mill-ġdid fuq l-ewwel kopja tal-element "index".
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Tneħħi u tirritorna l-element fil-pożizzjoni `index` fi ħdan iż-vector, billi tbiddel l-elementi kollha warajh lejn ix-xellug.
    ///
    ///
    /// # Panics
    ///
    /// Panics jekk `index` huwa barra mill-limiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // il-post li qed nieħdu minnu.
                let ptr = self.as_mut_ptr().add(index);
                // ikkopjaha, mingħajr kopja tal-valur fuq il-munzell u fiż-vector fl-istess ħin mingħajr periklu.
                //
                ret = ptr::read(ptr);

                // Ċaqlaq kollox 'l isfel biex timla dak il-post.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Iżomm biss l-elementi speċifikati mill-predikat.
    ///
    /// Fi kliem ieħor, neħħi l-elementi kollha `e` b'tali mod li `f(&e)` jirritorna `false`.
    /// Dan il-metodu jopera f'postu, u jżur kull element eżattament darba fl-ordni oriġinali, u jippreserva l-ordni tal-elementi miżmuma.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Minħabba li l-elementi jiġu miżjura eżattament darba fl-ordni oriġinali, jista 'jintuża stat estern biex jiġi deċiż liema elementi għandhom jinżammu.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Evita qatra doppja jekk il-gwardja tal-waqgħa ma tiġix eżegwita, peress li nistgħu nagħmlu xi toqob matul il-proċess.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-len ipproċessat-> |^-ħdejn il-verifika
        //                  | <-imħassar cnt-> |
        //      | <-original_len-> |Miżmuma: Elementi li l-predikat jirritorna veru.
        //
        // Toqba: Slott tal-element imċaqlaq jew imwaqqa '.
        // Mhux ikkontrollat: Elementi validi mhux ikkontrollati.
        //
        // Dan il-gwardja tal-waqgħa jiġi invokat meta l-predikat jew `drop` tal-element ikollu paniku.
        // Jibdel elementi mhux kontrollati biex ikopri toqob u `set_len` għat-tul korrett.
        // F'każijiet meta l-predikat u `drop` qatt ma jibżgħu, dan jiġi ottimizzat.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SIGURTÀ: It-tkaxkir ta 'oġġetti mhux ikkontrollati għandhom ikunu validi peress li aħna qatt ma jmissuhom.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SIGURTÀ: Wara li timla toqob, l-oġġetti kollha huma fil-memorja kontigwa.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SIGURTÀ: L-element mhux ivverifikat għandu jkun validu.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Avvanza kmieni biex tevita qatra doppja jekk `drop_in_place` ikollu paniku.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SIGURTÀ: Qatt ma nmissu dan l-element wara li niżel.
                unsafe { ptr::drop_in_place(cur) };
                // Aħna diġà avvanzajna l-counter.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SIGURTÀ: `deleted_cnt`> 0, allura l-islott tat-toqba m'għandux jikkoinċidi ma 'l-element kurrenti.
                // Aħna nużaw kopja għal ċaqliq, u qatt ma nmissu dan l-element mill-ġdid.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // L-oġġett kollu huwa pproċessat.Dan jista 'jiġi ottimizzat għal `set_len` minn LLVM.
        drop(g);
    }

    /// Tneħħi l-elementi konsekuttivi kollha ħlief l-ewwel wieħed fiż-vector li jissolvew għall-istess ċavetta.
    ///
    ///
    /// Jekk iż-vector huwa magħżul, dan ineħħi d-duplikati kollha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Tneħħi l-elementi konsekuttivi kollha minbarra l-ewwel wieħed fiż-vector li tissodisfa relazzjoni ta 'ugwaljanza mogħtija.
    ///
    /// Il-funzjoni `same_bucket` tgħaddi referenzi għal żewġ elementi miż-vector u trid tiddetermina jekk l-elementi jitqabblux indaqs.
    /// L-elementi huma mgħoddija f'ordni opposta mill-ordni tagħhom fil-porzjon, allura jekk `same_bucket(a, b)` jirritorna `true`, `a` jitneħħa.
    ///
    ///
    /// Jekk iż-vector huwa magħżul, dan ineħħi d-duplikati kollha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Iżżid element fuq wara ta 'kollezzjoni.
    ///
    /// # Panics
    ///
    /// Panics jekk il-kapaċità l-ġdida taqbeż `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Dan se panic jew jabbortja jekk nallokaw> isize::MAX bytes jew jekk l-inkrement tat-tul ikun ifur għal tipi ta 'daqs żero.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Neħħi l-aħħar element minn vector u jirritornah, jew [`None`] jekk ikun vojt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Iċċaqlaq l-elementi kollha ta `other` f `Self`, u jħalli `other` vojt.
    ///
    /// # Panics
    ///
    /// Panics jekk in-numru ta 'elementi fiż-vector ifur `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Iżżid elementi għal `Self` minn buffer ieħor.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Joħloq iteratur li jbattal li jneħħi l-firxa speċifikata fiż-vector u jagħti l-oġġetti mneħħija.
    ///
    /// Meta l-iteratur **jitwaqqa**, l-elementi kollha fil-firxa jitneħħew miż-vector, anke jekk l-iteratur ma kienx ikkunsmat għal kollox.
    /// Jekk l-iteratur **ma jiġix** imwaqqa '(b [`mem::forget`] per eżempju), mhux speċifikat kemm elementi jitneħħew.
    ///
    /// # Panics
    ///
    /// Panics jekk il-punt tat-tluq huwa akbar mill-punt tat-tarf jew jekk il-punt tat-tarf huwa akbar mit-tul taż-vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Firxa sħiħa tħassar iż-vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Sigurtà tal-memorja
        //
        // Meta l-Drain jinħoloq għall-ewwel darba, iqassar it-tul tas-sors vector biex jiżgura li l-ebda element mhux inizjalizzat jew imċaqlaq ma jkun aċċessibbli għal kollox jekk id-distruttur taż-Drain qatt ma jasal biex jaħdem.
        //
        //
        // Drain se ptr::read joħroġ il-valuri li għandhom jitneħħew.
        // Meta jkun lest, id-denb li jifdal tal-vec jiġi kkupjat lura biex ikopri t-toqba, u t-tul vector jerġa 'jiġi restawrat għat-tul il-ġdid.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // issettja t-tul ta self.vec biex jibda, biex tkun sigur f'każ li Drain ikun nixxa
            self.set_len(start);
            // Uża s-self fl-IterMut biex tindika l-imġieba tas-self tal-iteratur Drain kollu (bħal &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Tħassar iż-vector, u tneħħi l-valuri kollha.
    ///
    /// Innota li dan il-metodu m'għandu l-ebda effett fuq il-kapaċità allokata taż-vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Jirritorna n-numru ta 'elementi fiż-vector, imsejjaħ ukoll bħala 'length' tiegħu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Jirritorna `true` jekk iż-vector ma jkunx fih elementi.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Jaqsam il-kollezzjoni fi tnejn fl-indiċi mogħti.
    ///
    /// Jirritorna vector allokat ġdid li fih l-elementi fil-firxa `[at, len)`.
    /// Wara t-telefonata, iż-vector oriġinali jitħalla jkun fih l-elementi `[0, at)` bil-kapaċità preċedenti tiegħu mhux mibdula.
    ///
    ///
    /// # Panics
    ///
    /// Panics jekk `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // iż-vector il-ġdid jista 'jieħu f'idejh il-buffer oriġinali u jevita l-kopja
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // `set_len` mhux sikur u kkopja oġġetti għal `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Irridimensjona l-`Vec` fil-post sabiex `len` ikun ugwali għal `new_len`.
    ///
    /// Jekk `new_len` huwa akbar minn `len`, ix-`Vec` huwa estiż bid-differenza, b'kull slot addizzjonali mimli bir-riżultat li ssejjaħ l-għeluq `f`.
    ///
    /// Il-valuri tar-ritorn minn `f` jispiċċaw fix-`Vec` fl-ordni li ġew iġġenerati.
    ///
    /// Jekk `new_len` huwa inqas minn `len`, ix-`Vec` huwa sempliċement maqtugħ.
    ///
    /// Dan il-metodu juża għeluq biex joħloq valuri ġodda fuq kull imbuttatura.Jekk tippreferi [`Clone`] valur partikolari, uża [`Vec::resize`].
    /// Jekk trid tuża [`Default`] trait biex tiġġenera valuri, tista 'tgħaddi [`Default::default`] bħala t-tieni argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Jikkonsma u jnixxi x-`Vec`, jirritorna referenza li tista 'tinbidel għall-kontenut, `&'a mut [T]`.
    /// Innota li t-tip `T` għandu jgħix aktar mill-ħajja magħżula `'a`.
    /// Jekk it-tip għandu biss referenzi statiċi, jew xejn, allura dan jista 'jintgħażel biex ikun `'static`.
    ///
    /// Din il-funzjoni hija simili għall-funzjoni [`leak`][Box::leak] fuq [`Box`] ħlief li m'hemm l-ebda mod biex tirkupra l-memorja mxerrda.
    ///
    ///
    /// Din il-funzjoni hija prinċipalment utli għal dejta li tgħix għall-bqija tal-ħajja tal-programm.
    /// It-twaqqigħ tar-referenza mibgħuta lura jikkawża tnixxija tal-memorja.
    ///
    /// # Examples
    ///
    /// Użu sempliċi:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Jirritorna l-kapaċità żejda li jifdal taż-vector bħala porzjon ta `MaybeUninit<T>`.
    ///
    /// Il-porzjon ritornat jista 'jintuża biex jimla l-vector b'dejta (eż
    /// billi taqra minn fajl) qabel ma timmarka d-dejta bħala inizjalizzata bl-użu tal-metodu [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Alloka vector kbir biżżejjed għal 10 elementi.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Imla l-ewwel 3 elementi.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Immarka l-ewwel 3 elementi taż-vector bħala inizjalizzati.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Dan il-metodu mhuwiex implimentat f'termini ta `split_at_spare_mut`, biex jipprevjeni l-invalidazzjoni ta' indikaturi għall-buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Jirritorna l-kontenut ta 'vector bħala porzjon ta' `T`, flimkien mal-kapaċità żejda li jifdal taż-vector bħala porzjon ta `MaybeUninit<T>`.
    ///
    /// Il-porzjon ta 'kapaċità żejda ritornata jista' jintuża biex jimla vector b'dejta (eż. Billi taqra minn fajl) qabel ma timmarka d-dejta bħala inizjalizzata bl-użu tal-metodu [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Innota li din hija API ta 'livell baxx, li għandha tintuża b'attenzjoni għal skopijiet ta' ottimizzazzjoni.
    /// Jekk għandek bżonn tehmeż data ma `Vec` tista' tuża [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] jew [`resize_with`], skond il-bżonnijiet eżatti tiegħek.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Irriserva spazju addizzjonali kbir biżżejjed għal 10 elementi.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Imla l-4 elementi li jmiss.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Immarka l-4 elementi taż-vector bħala inizjalizzati.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len huwa injorat u għalhekk qatt ma nbidel
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sikurezza: tibdil mibgħut lura .2 (użu &mut) huwa meqjus l-istess bħal sejħa `.set_len(_)`.
    ///
    /// Dan il-metodu jintuża biex ikollu aċċess uniku għall-partijiet vec kollha f'daqqa f `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` huwa garantit li jkun validu għal elementi `len`
        // - `spare_ptr` qed tipponta element wieħed lil hinn mill-buffer, allura ma jikkoinċidix ma `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Irridimensjona l-`Vec` fil-post sabiex `len` ikun ugwali għal `new_len`.
    ///
    /// Jekk `new_len` huwa akbar minn `len`, ix-`Vec` huwa estiż bid-differenza, b'kull slot addizzjonali mimli b `value`.
    ///
    /// Jekk `new_len` huwa inqas minn `len`, ix-`Vec` huwa sempliċement maqtugħ.
    ///
    /// Dan il-metodu jeħtieġ `T` biex jimplimenta [`Clone`], sabiex ikun jista 'jikklona l-valur mgħoddi.
    /// Jekk teħtieġ aktar flessibilità (jew trid tistrieħ fuq [`Default`] minflok [`Clone`]), uża [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Jikklona u jżid l-elementi kollha f'biċċa porzjon max-`Vec`.
    ///
    /// Iterata fuq il-porzjon `other`, ikklona kull element, u mbagħad jehmeż ma 'dan ix-`Vec`.
    /// Ix-`other` vector huwa mgħoddi fl-ordni.
    ///
    /// Innota li din il-funzjoni hija l-istess bħal [`extend`] ħlief li hija speċjalizzata biex taħdem bi slices minflok.
    ///
    /// Jekk u meta Rust jikseb l-ispeċjalizzazzjoni din il-funzjoni x'aktarx tkun skaduta (iżda xorta waħda disponibbli).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Ikkopja elementi mill-firxa `src` sat-tarf taż-vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` tiggarantixxi li l-firxa mogħtija hija valida għall-indiċjar ta 'lilek innifsek
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Dan il-kodiċi jiġġeneralizza `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Estendi l-valuri vector b `n`, billi tuża l-ġeneratur mogħti.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Uża SetLenOnDrop biex taħdem madwar bug fejn il-kompilatur jista 'ma jirrealizzax il-maħżen permezz ta' `ptr` permezz ta self.set_len() ma jismux.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Ikteb l-elementi kollha minbarra l-aħħar wieħed
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Żid it-tul f'kull pass f'każ next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Nistgħu niktbu l-aħħar element direttament mingħajr ma nikklonjaw bla bżonn
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len issettjat mill-gwardja tal-iskop
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Tneħħi l-elementi ripetuti konsekuttivi fiż-vector skont l-implimentazzjoni [`PartialEq`] trait.
    ///
    ///
    /// Jekk iż-vector huwa magħżul, dan ineħħi d-duplikati kollha.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Metodi u funzjonijiet interni
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` jeħtieġ li jkun indiċi validu
    /// - `self.capacity() - self.len()` għandu jkun `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len tiżdied biss wara l-inizjalizzazzjoni tal-elementi
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - min iċempel jiggarantixxi li src huwa indiċi validu
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element kien inizjalizzat biss b `MaybeUninit::write`, allura huwa tajjeb li żżid il-len
            // - len tiżdied wara kull element biex tevita tnixxijiet (ara l-ħarġa #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - min iċempel jiggarantixxi li `src` huwa indiċi validu
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Iż-żewġ indikaturi huma maħluqa minn referenzi slice uniċi (`&mut [_]`) u għalhekk huma validi u ma jikkoinċidux.
            //
            // - L-elementi huma: Ikkopja u allura tajjeb li tikkopjahom, mingħajr ma tagħmel xejn bil-valuri oriġinali
            // - `count` hija ugwali għal-len ta `source`, allura s-sors huwa validu għal `count` jaqra
            // - `.reserve(count)` jiggarantixxi li `spare.len() >= count` hekk żejda hija valida għal `count` jikteb
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - L-elementi kienu biss inizjalizzati minn `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Implimentazzjonijiet komuni ta 'trait għal Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): b cfg(test) il-metodu inerenti `[T]::to_vec`, li huwa meħtieġ għal din id-definizzjoni tal-metodu, mhuwiex disponibbli.
    // Minflok uża l-funzjoni `slice::to_vec` li hija disponibbli biss b cfg(test) NB ara l-modulu slice::hack f slice.rs għal aktar informazzjoni
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // qatra kull ħaġa li ma tkunx miktuba fuqha
        self.truncate(other.len());

        // self.len <= other.len minħabba t-tronk hawn fuq, allura l-flieli hawn huma dejjem fil-limiti.
        //
        let (init, tail) = other.split_at(self.len());

        // erġa 'uża l-valuri kontenuti' allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Joħloq iteratur li jikkonsma, jiġifieri, wieħed li jċaqlaq kull valur barra miż-vector (mill-bidu sat-tmiem).
    /// Iż-vector ma jistax jintuża wara li ċċempel dan.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s għandha tip String, mhux &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // metodu tal-werqa li għalih jiddelegaw diversi implimentazzjonijiet SpecFrom/SpecExtend meta ma jkollhomx aktar ottimizzazzjonijiet x'japplikaw
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Dan huwa l-każ għal iteratur ġenerali.
        //
        // Din il-funzjoni għandha tkun l-ekwivalenti morali ta ':
        //
        //      għal oġġett fl-iteratur {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB ma jistax ifur peress li kien ikollna nallokaw l-ispazju tal-indirizzi
                self.set_len(len + 1);
            }
        }
    }

    /// Joħloq iteratur tal-ġonot li jissostitwixxi l-firxa speċifikata fiż-vector bl-iteratur `replace_with` mogħti u jagħti l-oġġetti mneħħija.
    ///
    /// `replace_with` m'għandux għalfejn ikun l-istess tul bħal `range`.
    ///
    /// `range` jitneħħa anke jekk l-iteratur ma jiġix ikkunsmat sa l-aħħar.
    ///
    /// Mhuwiex speċifikat kemm elementi jitneħħew miż-vector jekk il-valur `Splice` jitnixxef.
    ///
    /// L-iteratur tal-input `replace_with` jiġi kkunsmat biss meta jitwaqqa 'l-valur `Splice`.
    ///
    /// Dan huwa ottimali jekk:
    ///
    /// * Id-denb (elementi fiż-vector wara `range`) huwa vojt,
    /// * jew `replace_with` jagħti inqas elementi jew ugwali mit-tul tal-'firxa '
    /// * jew il-limitu t'isfel tax-`size_hint()` tagħha huwa eżatt.
    ///
    /// Inkella, jiġi allokat vector temporanju u d-denb jiġi mċaqlaq darbtejn.
    ///
    /// # Panics
    ///
    /// Panics jekk il-punt tat-tluq huwa akbar mill-punt tat-tarf jew jekk il-punt tat-tarf huwa akbar mit-tul taż-vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Joħloq iteratur li juża għeluq biex jiddetermina jekk element għandux jitneħħa.
    ///
    /// Jekk l-għeluq jirritorna veru, allura l-element jitneħħa u jingħata.
    /// Jekk l-għeluq jirritorna falz, l-element jibqa 'fiż-vector u ma jingħatax mill-iteratur.
    ///
    /// L-użu ta 'dan il-metodu huwa ekwivalenti għall-kodiċi li ġej:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // il-kodiċi tiegħek hawn
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Imma `drain_filter` huwa aktar faċli biex tużah.
    /// `drain_filter` huwa wkoll aktar effiċjenti, minħabba li jista 'jċaqlaq lura l-elementi tal-firxa bl-ingrossa.
    ///
    /// Innota li `drain_filter` iħallik ukoll tibdel kull element fl-għeluq tal-filtru, irrispettivament minn jekk tagħżilx li żżommha jew tneħħiha.
    ///
    ///
    /// # Examples
    ///
    /// Qsim ta 'firxa f'valuri u odds, uża mill-ġdid l-allokazzjoni oriġinali:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Gwardja kontra li jkollna nixxew (amplifikazzjoni tat-tnixxija)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Estendi l-implimentazzjoni li tikkopja elementi minn referenzi qabel ma timbottahom fuq il-Vec.
///
/// Din l-implimentazzjoni hija speċjalizzata għall-iteraturi tas-slice, fejn tuża [`copy_from_slice`] biex tehmeż is-slice kollu f'daqqa.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Jimplimenta paragun ta 'vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Timplimenta l-ordni ta 'vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // uża qatra għal [T] uża porzjon nej biex tirreferi għall-elementi taż-vector bħala l-aktar tip dgħajjef neċessarju;
            //
            // jista 'jevita mistoqsijiet ta' validità f'ċerti każijiet
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec jimmaniġġa d-deallokazzjoni
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Joħloq `Vec<T>` vojt.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test jiġbed fil-libstd, li jikkawża żbalji hawn
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test jiġbed fil-libstd, li jikkawża żbalji hawn
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Tikseb il-kontenut kollu tax-`Vec<T>` bħala array, jekk id-daqs tiegħu jaqbel eżattament ma 'dak tal-array mitlub.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Jekk it-tul ma jaqbilx, id-dħul jiġi lura f `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Jekk int tajjeb bi ftit li jkollok prefiss tax-`Vec<T>`, l-ewwel tista 'ċċempel lil [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SIGURTÀ: `.set_len(0)` huwa dejjem sod.
        unsafe { vec.set_len(0) };

        // SIGURTÀ: Il-pointer ta '"Vec" huwa dejjem allinjat sewwa, u
        // l-allinjament li jeħtieġ l-arranġament huwa l-istess bħall-oġġetti.
        // Aħna ċċekkjajna qabel li għandna oġġetti suffiċjenti.
        // L-oġġetti ma jinżlux darbtejn għax ix-`set_len` jgħid lill-`Vec` biex ma jwaħħalhomx ukoll.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}