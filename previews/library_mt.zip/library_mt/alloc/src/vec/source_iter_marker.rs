use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Markatur ta 'speċjalizzazzjoni għall-ġbir ta' pipeline ta 'iteratur f'Vec waqt li terġa' tuża l-allokazzjoni tas-sors, jiġifieri
/// eżekuzzjoni tal-pipeline f`postha.
///
/// Il-ġenitur SourceIter trait huwa meħtieġ għall-funzjoni ta 'speċjalizzazzjoni biex taċċessa l-allokazzjoni li għandha terġa' tintuża.
/// Iżda mhux biżżejjed li l-ispeċjalizzazzjoni tkun valida.
/// Ara limiti addizzjonali fuq l-impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Il-std-intern SourceIter/InPlaceIterable traits huma implimentati biss minn ktajjen ta 'Adapter <Adapter<Adapter<IntoIter>>> (kollha proprjetà ta core/std).
// Limiti addizzjonali fuq l-implimentazzjoni tal-adapter (lil hinn minn `impl<I: Trait> Trait for Adapter<I>`) jiddependu biss fuq traits oħra diġà mmarkati bħala speċjalizzazzjoni traits (Kopja, TrustedRandomAccess, FusedIterator).
//
// I.e. il-markatur ma jiddependix fuq il-ħajja ta 'tipi fornuti mill-utent.Modulo it-toqba tal-Kopja, li diġà jiddependu minnha diversi speċjalizzazzjonijiet oħra.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Rekwiżiti addizzjonali li ma jistgħux jiġu espressi permezz ta 'trait bounds.Aħna niddependu fuq const eval minflok:
        // a) l-ebda ZSTs għax ma jkun hemm l-ebda allokazzjoni għall-użu mill-ġdid u l-aritmetika tal-pointer tkun panic b) id-daqs jaqbel kif meħtieġ mill-kuntratt Alloc c) l-allinjamenti jaqblu kif meħtieġ mill-kuntratt Alloc
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // riżerva għal implimentazzjonijiet aktar ġeneriċi
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // uża try-fold minn dakinhar
        // - tivverjalizza aħjar għal xi adapters iteraturi
        // - b'differenza mill-biċċa l-kbira tal-metodi ta 'iterazzjoni interni, tieħu biss awto &mut
        // - iħallina ndaħħlu l-pointer tal-kitba mill-ġewwieni tiegħu u nġibu lura fl-aħħar
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iterazzjoni rnexxiet, titlaqx ras
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // iċċekkja jekk il-kuntratt SourceIter kienx milqugħ twiddiba: kieku ma kinux aħna lanqas biss nistgħu nagħmluh f'dan il-punt
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // iċċekkja l-kuntratt InPlaceIterable.Dan huwa possibbli biss jekk l-iteratur ikun avvanza l-pointer tas-sors.
        // Jekk juża aċċess mhux ikkontrollat permezz ta `TrustedRandomAccess allura l-pointer tas-sors jibqa` fil-pożizzjoni inizjali tiegħu u ma nistgħux nużawh bħala referenza
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // waqqa 'kwalunkwe valur li jifdal fid-denb tas-sors imma tevita li tinżel l-allokazzjoni nnifisha ladarba IntoIter joħroġ mill-ambitu jekk il-waqgħa panics allura aħna nixxew ukoll xi elementi miġbura f'dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // il-kuntratt InPlaceIterable ma jistax jiġi vverifikat preċiż hawn peress li try_fold għandu referenza esklussiva għall-pointer tas-sors kull ma nistgħu nagħmlu huwa li niċċekkjaw jekk għadux fil-medda
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}