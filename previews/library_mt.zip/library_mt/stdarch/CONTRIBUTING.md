# Kontribuzzjoni għal stdarch

Ix-`stdarch` crate huwa iktar minn lest li jaċċetta kontribuzzjonijiet!L-ewwel probabbilment tkun trid tiċċekkja r-repożitorju u kun żgur li t-testijiet jgħaddu għalik:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Fejn `<your-target-arch>` huwa t-triplu fil-mira kif użat minn `rustup`, eż. `x86_x64-unknown-linux-gnu` (mingħajr l-ebda `nightly-` preċedenti jew simili).
Ftakar ukoll li dan ir-repożitorju jeħtieġ il-kanal ta 'filgħaxija ta' Rust!
It-testijiet ta 'hawn fuq fil-fatt jirrikjedu li rust ta' bil-lejl ikun il-default fis-sistema tiegħek, biex tissettja dak l-użu ta `rustup default nightly` (u `rustup default stable` biex terġa' lura).

Jekk xi wieħed mill-passi ta 'hawn fuq ma jaħdimx, [please let us know][new]!

Sussegwentement tista [find an issue][issues] biex tgħin, għażilna ftit bit-tikketti [`help wanted`][help] u [`impl-period`][impl] li jistgħu partikolarment jużaw xi għajnuna. 
Inti tista 'tkun l-iktar interessat f [#40][vendor], li timplimenta l-intrinsiċi kollha tal-bejjiegħ fuq x86.Dik il-ħarġa għandha indikazzjonijiet tajbin dwar fejn tibda!

Jekk għandek mistoqsijiet ġenerali tħossok liberu li [join us on gitter][gitter] u staqsi madwar!Ħossok liberu li tagħmel ping jew lil@BurntSushi jew lil@alexcrichton bi mistoqsijiet.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kif tikteb eżempji għal intrinsiċi stdarch

Hemm ftit fatturi li għandhom ikunu attivati biex l-intrinsiku partikolari jaħdem sewwa u l-eżempju għandu jitmexxa biss minn `cargo test --doc` meta l-karatteristika tkun appoġġjata mis-CPU.

Bħala riżultat, l-`fn main` default li huwa ġġenerat minn `rustdoc` ma jaħdimx (f'ħafna każijiet).
Ikkunsidra li tuża dan li ġej bħala gwida biex tiżgura li l-eżempju tiegħek jaħdem kif mistenni.

```rust
/// # // Għandna bżonn cfg_target_feature biex niżguraw li l-eżempju huwa biss
/// # // immexxi minn `cargo test --doc` meta s-CPU jappoġġja l-karatteristika
/// # #![feature(cfg_target_feature)]
/// # // Għandna bżonn target_feature biex l-intrinsiku jaħdem
/// # #![feature(target_feature)]
/// #
/// # // rustdoc awtomatikament juża `extern crate stdarch`, imma neħtieġu
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Il-funzjoni ewlenija vera
/// # fn main() {
/// #     // Ħaddem dan biss jekk `<target feature>` huwa appoġġjat
/// #     jekk cfg_feature_enabled! ("<target feature>"){
/// #         // Oħloq funzjoni `worker` li titħaddem biss jekk il-karatteristika fil-mira
/// #         // huwa appoġġjat u kun żgur li `target_feature` huwa attivat għall-ħaddiem tiegħek
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         fn worker() mhux sikur {
/// // Ikteb l-eżempju tiegħek hawn.Karatteristiċi intrinsiċi speċifiċi se jaħdmu hawn!Mur selvaġġ!
///
/// #         }
///
/// #         { worker(); } mhux sikur
/// #     }
/// # }
```

Jekk uħud mis-sintassi ta 'hawn fuq ma jidhrux familjari, is-sezzjoni [Documentation as tests] tax-[Rust Book] tiddeskrivi s-sintassi `rustdoc` pjuttost tajjeb.
Bħal dejjem, tħossok liberu li [join us on gitter][gitter] u staqsina jekk tolqotx xi xkiel, u grazzi talli għenet biex ittejjeb id-dokumentazzjoni ta `stdarch`!

# Struzzjonijiet Alternattivi għall-Ittestjar

Ġeneralment huwa rrakkomandat li tuża `ci/run.sh` biex tmexxi t-testijiet.
Madankollu dan jista 'ma jaħdimx għalik, eż. Jekk inti fuq Windows.

F'dak il-każ tista 'taqa' lura għat-tħaddim ta `cargo +nightly test` u `cargo +nightly test --release -p core_arch` għall-ittestjar tal-ġenerazzjoni tal-kodiċi.
Innota li dawn jeħtieġu li l-għodda tal-lejl tkun installata u biex `rustc` tkun taf dwar il-mira tripla tiegħek u s-CPU tagħha.
B'mod partikolari għandek bżonn tissettja l-varjabbli ta 'l-ambjent `TARGET` kif tagħmel għal `ci/run.sh`.
Barra minn hekk għandek bżonn tissettja `RUSTCFLAGS` (teħtieġ ix-`C`) biex tindika l-karatteristiċi fil-mira, eż `RUSTCFLAGS="-C -target-features=+avx2"`.
Tista 'wkoll tissettja `-C -target-cpu=native` jekk qed tiżviluppa "just" kontra s-CPU attwali tiegħek.

Kun imwissi li meta tuża dawn l-istruzzjonijiet alternattivi, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], eż
testijiet tal-ġenerazzjoni tal-istruzzjoni jistgħu jfallu minħabba li d-disassembler semmiehom b'mod differenti, eż
jista 'jiġġenera `vaesenc` minflok istruzzjonijiet `aesenc` minkejja li jġibu l-istess.
Dawn l-istruzzjonijiet ukoll jeżegwixxu inqas testijiet milli normalment isiru, allura ma tkunx sorpriż li meta eventwalment tirreġistra xi żbalji jistgħu jidhru għal testijiet mhux koperti hawnhekk.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






