//! Implimentazzjoni tal-makro `#[assert_instr]`
//!
//! Din il-makro tintuża meta tiġi ttestjata `stdarch` crate u tintuża biex tiġġenera każijiet tat-test biex tafferma li l-funzjonijiet tassew fihom l-istruzzjonijiet li qed nistennew li fihom.
//!
//! Il-makro proċedurali hawnhekk hija relattivament sempliċi, sempliċement tehmeż funzjoni `#[test]` mal-fluss oriġinali token li jafferma li l-funzjoni nnifisha fiha l-istruzzjoni rilevanti.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // Itfi assert_instr għal miri x86 ikkumpilati bl-avx attivat, li jikkawża LLVM biex jiġġenera intrinsiċi differenti għal dawk li qed nittestjaw għalihom.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // Jekk it-testijiet tal-istruzzjoni huma diżattivati evita li tarmi dan il-shim, irritorna l-oġġett oriġinali mingħajr l-attribut tagħna.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // Dawn l-ismijiet għandhom ikunu uniċi biżżejjed għalina biex insibuha fiż-żarmar aktar tard:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // Uża ABI fuq Windows li tgħaddi valuri SIMD fir-reġistri, bħal dak li jiġri fuq Unix (naħseb?) Awtomatikament.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // Il-kompilatur f'modalità ottimizzata awtomatikament imexxi pass imsejjaħ "mergefunc" fejn ser jgħaqqad funzjonijiet li jidhru identiċi.
            // Jirriżulta li xi intrinsiċi jipproduċu kodiċi identiku u huma mitwija flimkien, li jfisser li wieħed biss jaqbeż għal ieħor.
            // Dan ifixkel l-ispezzjoni tagħna taż-żarmar ta 'din il-funzjoni u aħna m'aħniex fan kbir ta' dan.
            //
            // Biex tfixkel dan il-pass u tevita li l-funzjonijiet jingħaqdu aħna niġġeneraw xi kodiċi li nisperaw li huwa strett ħafna f'termini ta 'codegen iżda li altrimenti huwa uniku biex ma jħallix li l-kodiċi jintlewa.
            //
            //
            // Dan huwa evitat fuq Wasm32 bħalissa peress li dawn il-funzjonijiet mhumiex inlinjati li jkissru t-testijiet tagħna billi kull intrinsiku jidher qisu jitlob funzjonijiet.
            // Jirriżulta li l-funzjonijiet mhumiex simili biżżejjed biex jingħaqdu fuq wasm32 xorta waħda.
            // Dan il-bug huwa ssorveljat f rust-lang/rust#74320.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}