`core::arch` - Intrinsiċi tal-arkitettura tal-librerija ewlenija ta 'Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Il-modulu `core::arch` jimplimenta intrinsiċi dipendenti fuq l-arkitettura (eż. SIMD).

# Usage 

`core::arch` huwa disponibbli bħala parti minn `libcore` u huwa esportat mill-ġdid minn `libstd`.Nippreferi tużah permezz ta `core::arch` jew `std::arch` milli permezz ta' dan crate.
Karatteristiċi instabbli ħafna drabi huma disponibbli f'Rust ta 'bil-lejl permezz tax-`feature(stdsimd)`.

L-użu ta `core::arch` permezz ta' dan crate jirrikjedi Rust ta 'bil-lejl, u jista' (u jkisser) spiss.L-uniċi każijiet li fihom għandek tikkunsidra li tużah permezz ta 'dan crate huma:

* jekk għandek bżonn terġa 'tikkompila `core::arch` lilek innifsek, eż., b'fatturi ta' mira partikolari attivati li mhumiex attivati għal `libcore`/`libstd`.
Note: jekk għandek bżonn terġa 'tiġborha għal mira mhux standard, jekk jogħġbok ippreferi tuża `xargo` u terġa' tikkompila `libcore`/`libstd` kif xieraq minflok tuża dan crate.
  
* billi tuża xi karatteristiċi li jistgħu ma jkunux disponibbli anke wara karatteristiċi instabbli ta 'Rust.Aħna nippruvaw inżommu dawn għall-minimu.
Jekk għandek bżonn tuża xi wħud minn dawn il-karatteristiċi, jekk jogħġbok tiftaħ kwistjoni sabiex inkunu nistgħu nikxfuhom fiż-Rust ta 'bil-lejl u tista' tużahom minn hemm.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` huwa distribwit primarjament taħt it-termini kemm tal-liċenzja MIT kif ukoll tal-Liċenzja Apache (Verżjoni 2.0), b'porzjonijiet koperti minn diversi liċenzji bħal BSD.

Ara LICENSE-APACHE, u LICENSE-MIT għad-dettalji.

# Contribution

Sakemm ma tiddikjarax b'mod espliċitu mod ieħor, kwalunkwe kontribuzzjoni sottomessa intenzjonalment għal inklużjoni f `core_arch` minnek, kif definit fil-liċenzja Apache-2.0, għandha tkun liċenzjata doppja bħal hawn fuq, mingħajr ebda termini jew kundizzjonijiet addizzjonali.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












