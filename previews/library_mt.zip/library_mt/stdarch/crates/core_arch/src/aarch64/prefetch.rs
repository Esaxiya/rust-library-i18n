#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// Ara [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_READ: i32 = 0;

/// Ara [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_WRITE: i32 = 1;

/// Ara [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// Ara [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// Ara [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// Ara [`prefetch`](fn._prefetch.html).
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// Ġib il-linja tal-cache li fiha l-indirizz `p` billi tuża l-`rw` u `locality` mogħtija.
///
/// Ix-`rw` għandu jkun wieħed minn:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): il-prefetch qed jipprepara għal qari.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): il-prefetch qed jipprepara għal kitba.
///
/// Ix-`locality` għandu jkun wieħed minn:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): Streaming jew prefetch mhux temporali, għal dejta li tintuża darba biss.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): Ġib fil-cache tal-livell 3.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): Ġib fil-cache tal-livell 2.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): Ġib fil-cache tal-livell 1.
///
/// L-istruzzjonijiet tal-memorja tal-prefetch jindikaw lis-sistema tal-memorja li l-aċċess għall-memorja minn indirizz speċifikat x'aktarx iseħħu fiż-future qrib.
/// Is-sistema tal-memorja tista 'tirrispondi billi tieħu azzjonijiet li huma mistennija li jħaffu l-aċċess tal-memorja meta jseħħu, bħall-preloading tal-indirizz speċifikat f'waħda jew aktar cache.
///
/// Minħabba li dawn is-sinjali huma biss ħjiel, huwa validu għal CPU partikolari biex jittratta xi struzzjonijiet jew xi struzzjonijiet minn qabel kollha bħala NOP.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // Aħna nużaw l-istrinsiku `llvm.prefetch` b `cache type` =1 (cache tad-dejta).
    // `rw` u `strategy` huma bbażati fuq il-parametri tal-funzjoni.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}