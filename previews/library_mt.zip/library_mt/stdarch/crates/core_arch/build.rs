use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Użati biex tgħid l-annotazzjonijiet `#[assert_instr]` tagħna li s-simd intrinsiċi kollha huma disponibbli biex jittestjaw il-kodegen tagħhom, peress li xi wħud huma magħluqin wara `-Ctarget-feature=+unimplemented-simd128` żejjed li m'għandux ekwivalenti f `#[target_feature]` issa.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}