//! `Cell` varjant għall-ħajja eżistenzjali (scoped).

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// Tip ta 'applikazzjoni lambda, b'ħajja sħiħa.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// Tip lambda li jieħu ħajtu kollha, jiġifieri, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) aħdem madwar il-limitazzjonijiet tal-projezzjoni b'newtype FIXME(#52812) ibdel b `&'a mut <T as ApplyL<'b>>::Out`
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// Issettja l-valur f `self` għal `replacement` waqt li tkun qed taħdem `f`, li jikseb il-valur l-antik, b'mod mutabbli.
    /// Il-valur l-antik jiġi rrestawrat wara l-ħruġ ta `f`, anke minn panic, inklużi modifiki magħmula lilu minn `f`.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// Tgeżwir li jiżgura li ċ-ċellula dejjem timtela (bl-istat oriġinali, mhux obbligatorju mibdul b `f`), anke jekk `f` kien ippanikjat.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// Issettja l-valur f `self` għal `value` waqt li tkun qed taħdem `f`.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}