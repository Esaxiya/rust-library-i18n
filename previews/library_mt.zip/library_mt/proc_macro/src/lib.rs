//! Librerija ta 'appoġġ għall-awturi tal-makro meta jiddefinixxu macros ġodda.
//!
//! Din il-librerija, ipprovduta mid-distribuzzjoni standard, tipprovdi t-tipi kkunsmati fl-interfaces ta 'definizzjonijiet ta' makro definiti b'mod proċedurali bħal makros bħal funzjoni `#[proc_macro]`, attributi makro `#[proc_macro_attribute]` u attributi derivati apposta "#[proc_macro_derive]".
//!
//!
//! Ara [the book] għal aktar.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Jiddetermina jekk proc_macro sarx aċċessibbli għall-programm li qed jitħaddem bħalissa.
///
/// Il-proc_macro crate huwa maħsub biss għall-użu fl-implimentazzjoni tal-macros proċedurali.Il-funzjonijiet kollha f'dan crate panic jekk invokati minn barra ta 'makro proċedurali, bħal minn kitba tal-bini jew test ta' unità jew binarju ordinarju ta 'Rust.
///
/// B'kunsiderazzjoni għal-libreriji Rust li huma mfassla biex jappoġġjaw każijiet ta 'użu kemm makro kif ukoll mhux makro, `proc_macro::is_available()` jipprovdi mod mingħajr paniku biex jidentifika jekk l-infrastruttura meħtieġa biex tuża l-API ta' proc_macro hijiex disponibbli bħalissa.
/// Jirritorna veru jekk invokat minn ġewwa ta 'makro proċedurali, falz jekk invokat minn kwalunkwe binarju ieħor.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// It-tip ewlieni pprovdut minn dan crate, li jirrappreżenta nixxiegħa astratta ta 'tokens, jew, aktar speċifikament, sekwenza ta' siġar token.
/// It-tip jipprovdi interfaces għal iterazzjoni fuq dawk is-siġar token u, għall-kuntrarju, jiġbor numru ta 'siġar token fi fluss wieħed.
///
///
/// Dan huwa kemm l-input kif ukoll l-output tad-definizzjonijiet `#[proc_macro]`, `#[proc_macro_attribute]` u `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Żball lura minn `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Jirritorna `TokenStream` vojt li ma fihx siġar token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Jiċċekkja jekk dan `TokenStream` huwiex vojt.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Tentattivi biex tkisser is-sekwenza f'tokens u analizza dawk iż-tokens fi fluss ta 'token.
/// Jista 'jfalli għal numru ta' raġunijiet, per eżempju, jekk is-sekwenza fiha delimitaturi żbilanċjati jew karattri li ma jeżistux fil-lingwa.
///
/// Iż-tokens kollha fil-fluss analizzat jiksbu span `Span::call_site()`.
///
/// NOTE: xi żbalji jistgħu jikkawżaw panics minflok jirritornaw `LexError`.Aħna nirriżervaw id-dritt li nbiddlu dawn l-iżbalji għal 'LexError`s aktar tard.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, il-pont jipprovdi biss `to_string`, jimplimenta `fmt::Display` ibbażat fuqu (il-maqlub tar-relazzjoni tas-soltu bejn it-tnejn).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Stampa l-fluss token bħala sekwenza li suppost tista 'tiġi konvertita mingħajr telf lura fl-istess fluss token (modulo tifrex), ħlief possibilment għal' TokenTree: : Group`s b'delimiters `Delimiter::None` u litterali numeriċi negattivi.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Stampa token f'forma konvenjenti għad-debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Joħloq fluss token li fih siġra waħda token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Iġbor numru ta 'siġar token fi fluss wieħed.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operazzjoni "flattening" fuq flussi token, tiġbor siġar token minn flussi multipli token fi fluss wieħed.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Uża implimentazzjoni ottimizzata if/when possibbli.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Dettalji ta 'implimentazzjoni pubblika għat-tip `TokenStream`, bħal iteraturi.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iteratur fuq it-TokenTree`s ta '"TokenStream".
    /// L-iterazzjoni hija "shallow", eż., L-iteratur ma jerġax iseħħ fi gruppi delimitati, u jirritorna gruppi sħaħ bħala siġar token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` jaċċetta tokens arbitrarju u jespandi f `TokenStream` li jiddeskrivi l-input.
/// Pereżempju, `quote!(a + b)` jipproduċi espressjoni, li, meta evalwata, tibni l-`TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// It-tneħħija tal-kwotazzjonijiet issir b `$`, u taħdem billi tieħu l-ident wieħed li jmiss bħala t-terminu mhux ikkwotat.
/// Biex tikkwota lil `$` innifsu, uża `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Reġjun ta 'kodiċi tas-sors, flimkien ma' informazzjoni ta 'espansjoni makro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Toħloq `Diagnostic` ġdid max-`message` mogħti fil-medda `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Medda li tissolva fis-sit tad-definizzjoni makro.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Il-firxa tal-invokazzjoni tal-makro proċedurali attwali.
    /// Identifikaturi maħluqa b'din il-firxa jiġu solvuti bħallikieku nkitbu direttament fil-post tal-makro sejħa (iġjene tas-sit tas-sejħa) u kodiċi ieħor fis-sit tal-makro sejħa jkunu jistgħu jirreferu għalihom ukoll.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Medda li tirrappreżenta l-iġjene `macro_rules`, u xi kultant tissolva fis-sit ta 'definizzjoni makro (varjabbli lokali, tikketti, `$crate`) u xi kultant fis-sit ta' sejħa makro (kull ħaġa oħra).
    ///
    /// Il-post tal-firxa jittieħed mis-sit tas-sejħa.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Il-fajl tas-sors oriġinali li fih jindika dan il-firxa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Ix-`Span` għaż-tokens fl-espansjoni makro preċedenti li minnha ġie ġġenerat `self`, jekk hemm.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Il-firxa għall-kodiċi tas-sors tal-oriġini li minnu ġie ġġenerat `self`.
    /// Jekk dan `Span` ma ġġenerax minn espansjonijiet makro oħra allura l-valur tar-ritorn huwa l-istess bħal `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Iġib ix-line/column tal-bidu fil-fajl sors għal dan il-medda.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Iġib it-tmiem line/column fil-fajl sors għal dan il-firxa.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Toħloq firxa ġdida li tinkludi `self` u `other`.
    ///
    /// Jirritorna `None` jekk `self` u `other` huma minn fajls differenti.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Toħloq firxa ġdida bl-istess informazzjoni line/column bħal `self` iżda li ssolvi simboli bħallikieku kienet f `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Joħloq firxa ġdida bl-istess imġieba ta 'riżoluzzjoni ta' l-isem bħal `self` iżda bl-informazzjoni line/column ta `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Tqabbel mal-firxiet biex tara jekk humiex ugwali.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Jirritorna t-test tas-sors wara medda.
    /// Dan jippreserva l-kodiċi tas-sors oriġinali, inklużi spazji u kummenti.
    /// Irritorna riżultat biss jekk il-firxa tikkorrispondi għal kodiċi tas-sors reali.
    ///
    /// Note: Ir-riżultat osservabbli ta 'makro għandu jiddependi biss fuq iż-tokens u mhux fuq dan it-test sors.
    ///
    /// Ir-riżultat ta 'din il-funzjoni huwa l-aħjar sforz biex jintuża biss għad-dijanjostika.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Stampa span f'forma konvenjenti għad-debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Par linja-kolonna li jirrappreżenta l-bidu jew it-tmiem ta `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Il-linja indiċjata 1 fil-fajl sors li fuqu l-firxa tibda jew tispiċċa (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Il-kolonna 0-indiċjata (f'karattri UTF-8) fil-fajl sors li fuqu l-firxa tibda jew tispiċċa (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Il-fajl sors ta `Span` partikolari.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Tikseb it-triq għal dan il-fajl tas-sors.
    ///
    /// ### Note
    /// Jekk il-firxa tal-kodiċi assoċjata ma 'dan ix-`SourceFile` kienet iġġenerata minn makro estern, din il-makro, din tista' ma tkunx triq attwali fuq is-sistema tal-fajls.
    /// Uża [`is_real`] biex tivverifika.
    ///
    /// Innota wkoll li anke jekk `is_real` jirritorna `true`, jekk `--remap-path-prefix` ġie mgħoddi fuq il-linja tal-kmand, it-triq kif mogħtija tista 'ma tkunx attwalment valida.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Jirritorna `true` jekk dan il-fajl tas-sors huwa fajl tas-sors reali, u mhux iġġenerat mill-espansjoni ta 'makro estern.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Din hija hack sakemm jiġu implimentati spans ta 'intercrate u jista' jkollna fajls sors reali għal spans iġġenerati f'makros esterni.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token wieħed jew sekwenza delimitata ta 'siġar token (eż., `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Nixxiegħa token imdawra minn delimitaturi tal-parentesi.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikatur.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Karattru ta 'punteġġjatura waħda ("+", `,`, `$`, eċċ.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Karattru litterali (`'a'`), sekwenza (`"hello"`), numru (`2.3`), eċċ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Irritorna l-firxa ta 'din is-siġra, billi tiddelega lill-metodu `span` taż-token li jinsab jew nixxiegħa delimitata.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Jikkonfigura l-firxa għal *dan token* biss.
    ///
    /// Innota li jekk dan token huwa `Group` allura dan il-metodu mhux se jikkonfigura l-firxa ta 'kull wieħed miż-tokens intern, dan sempliċement jiddelega lill-metodu `set_span` ta' kull varjant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Stampa siġra token f'forma konvenjenti għad-debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Kull wieħed minn dawn għandu l-isem fit-tip struct fid-debug derivat, allura ma tiddejjaqx b'saff żejjed ta 'indirezzjoni
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, il-pont jipprovdi biss `to_string`, jimplimenta `fmt::Display` ibbażat fuqu (il-maqlub tar-relazzjoni tas-soltu bejn it-tnejn).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Jistampa s-siġra token bħala sekwenza li suppost tista 'tiġi konvertita mingħajr telf lura fl-istess siġra token (modulo tifrex), ħlief possibilment għal' TokenTree: : Group`s b'delimiters `Delimiter::None` u litterali numeriċi negattivi.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Fluss token delimitat.
///
/// `Group` internament fih `TokenStream` li huwa mdawwar b'`Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Jiddeskrivi kif sekwenza ta 'siġar token hija delimitata.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Delimitatur impliċitu, li jista ', per eżempju, jidher madwar tokens ġej minn "macro variable" `$var`.
    /// Huwa importanti li l-prijoritajiet tal-operatur jiġu ppreservati f'każijiet bħal `$var * 3` fejn `$var` huwa `1 + 2`.
    /// Id-delimitaturi impliċiti jistgħu ma jgħixux roundtrip ta 'nixxiegħa token permezz ta' sekwenza.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Joħloq `Group` ġdid bid-delimitatur mogħti u n-nixxiegħa token.
    ///
    /// Dan il-kostruttur jistabbilixxi l-firxa għal dan il-grupp għal `Span::call_site()`.
    /// Biex tibdel il-firxa tista 'tuża l-metodu `set_span` hawn taħt.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Jirritorna d-delimitatur ta 'dan ix-`Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Jirritorna l-`TokenStream` ta 'tokens li huma delimitati f'dan ix-`Group`.
    ///
    /// Innota li n-nixxiegħa token ritornata ma tinkludix id-delimitatur ritornat hawn fuq.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Jirritorna l-firxa għad-delimiters ta 'dan il-fluss token, li jkopri x-`Group` kollu.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Jirritorna l-firxa li tipponta lejn id-delimitatur tal-ftuħ ta 'dan il-grupp.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Jirritorna l-firxa li tipponta lejn id-delimitatur tal-għeluq ta 'dan il-grupp.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Jikkonfigura l-firxa għad-delimiters ta 'dan il-'Grupp', iżda mhux iż-tokens interni tiegħu.
    ///
    /// Dan il-metodu **mhux** se jistabbilixxi l-firxa taż-tokens interni kollha mifruxa minn dan il-grupp, iżda pjuttost jistabbilixxi l-firxa tad-delimitatur tokens fil-livell tax-`Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, il-pont jipprovdi biss `to_string`, jimplimenta `fmt::Display` ibbażat fuqu (il-maqlub tar-relazzjoni tas-soltu bejn it-tnejn).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Jistampa l-grupp bħala sekwenza li għandha tkun konvertibbli mingħajr telf lura fl-istess grupp (tifrex modulo), ħlief possibilment għal 'TokenTree: : Group`s b'delimiters `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` huwa karattru ta 'punteġġjatura waħda bħal `+`, `-` jew `#`.
///
/// Operaturi b'ħafna karattri bħal `+=` huma rappreżentati bħala żewġ każijiet ta `Punct` b'forom differenti ta' `Spacing` ritornati.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Jekk `Punct` huwiex segwit immedjatament minn `Punct` ieħor jew segwit minn token ieħor jew spazju vojt.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// eż. `+` huwa `Alone` f `+ =`, `+ident` jew `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// eż. `+` huwa `Joint` f `+=` jew `'#`.
    /// Barra minn hekk, kwotazzjoni waħda `'` tista 'tingħaqad ma' identifikaturi biex tifforma ħajjithom `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Toħloq `Punct` ġdid mill-karattru u l-ispazjar mogħtija.
    /// L-argument `ch` għandu jkun karattru ta 'punteġġjatura validu permess mil-lingwa, inkella l-funzjoni tkun panic.
    ///
    /// Ix-`Punct` ritornat ikollu l-firxa default ta `Span::call_site()` li tista' tiġi kkonfigurata aktar bil-metodu `set_span` hawn taħt.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Jirritorna l-valur ta 'dan il-karattru ta' punteġġjatura bħala `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Jirritorna l-ispazjar ta 'dan il-karattru ta' punteġġjatura, u jindika jekk hux immedjatament segwit minn `Punct` ieħor fin-nixxiegħa token, sabiex ikunu jistgħu jiġu kkombinati f'operatur b'ħafna karattri (`Joint`), jew ikun segwit minn xi token ieħor jew spazju vojt (`Alone`) sabiex l-operatur ċertament intemm.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Jirritorna l-firxa għal dan il-karattru ta 'punteġġjatura.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Ikkonfigura l-firxa għal dan il-karattru ta 'punteġġjatura.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, il-pont jipprovdi biss `to_string`, jimplimenta `fmt::Display` ibbażat fuqu (il-maqlub tar-relazzjoni tas-soltu bejn it-tnejn).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa l-karattru tal-punteġġjatura bħala sekwenza li għandha tkun konvertibbli mingħajr telf lura fl-istess karattru.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identifikatur (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Joħloq `Ident` ġdid max-`string` mogħti kif ukoll max-`span` speċifikat.
    /// L-argument `string` għandu jkun identifikatur validu permess mil-lingwa (inklużi kliem ewlieni, eż. `self` jew `fn`).Inkella, il-funzjoni tkun panic.
    ///
    /// Innota li `span`, bħalissa f'rustc, jikkonfigura l-informazzjoni dwar l-iġjene għal dan l-identifikatur.
    ///
    /// Minn dan iż-żmien `Span::call_site()` espliċitament jagħżel l-iġjene "call-site" li jfisser li l-identifikaturi maħluqa b'din il-firxa jiġu solvuti bħallikieku kienu miktuba direttament fil-post tal-makro sejħa, u kodiċi ieħor fis-sit tal-makro sejħa jkun jista 'jirreferi għal minnhom ukoll.
    ///
    ///
    /// Aktar tard mifruxa bħal `Span::def_site()` jippermettu li jagħżlu l-iġjene "definition-site" li jfisser li l-identifikaturi maħluqa b'din il-firxa jiġu solvuti fil-post tad-definizzjoni makro u kodiċi ieħor fis-sit tal-makro sejħa ma jkunux jistgħu jirreferu għalihom.
    ///
    /// Minħabba l-importanza attwali tal-iġjene dan il-kostruttur, b'differenza minn tokens oħra, jeħtieġ `Span` biex jiġi speċifikat fil-kostruzzjoni.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// L-istess bħal `Ident::new`, iżda joħloq identifikatur mhux ipproċessat (`r#ident`).
    /// L-argument `string` ikun identifikatur validu permess mil-lingwa (inklużi kliem ewlieni, eż. `fn`).
    /// Kliem ewlieni li jistgħu jintużaw f'segmenti ta 'passaġġ (eż
    /// `self`, "super") mhumiex appoġġjati, u jikkawżaw panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Jirritorna l-firxa ta 'dan ix-`Ident`, li tinkludi s-sekwenza sħiħa rritornata minn [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Jikkonfigura l-firxa ta 'dan ix-`Ident`, possibilment ibiddel il-kuntest ta' iġjene tiegħu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, il-pont jipprovdi biss `to_string`, jimplimenta `fmt::Display` ibbażat fuqu (il-maqlub tar-relazzjoni tas-soltu bejn it-tnejn).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Stampa l-identifikatur bħala sekwenza li għandha tkun konvertibbli mingħajr telf lura fl-istess identifikatur.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// String letterali (`"hello"`), sekwenza tal-byte (`b"hello"`), karattru (`'a'`), karattru tal-byte (`b'a'`), numru sħiħ jew punt li jvarja bis-suffiss jew mingħajru ('1', `1u8`, `2.3`, `2.3f32`).
///
/// Litturali Booleani bħal `true` u `false` ma jappartjenux hawn, huma `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Joħloq numru sħiħ ġdid suffissiv litterali bil-valur speċifikat.
        ///
        /// Din il-funzjoni toħloq numru sħiħ bħal `1u32` fejn il-valur ta 'numru sħiħ speċifikat huwa l-ewwel parti taż-token u l-integrali hija suffissata wkoll fl-aħħar.
        /// Il-litterali maħluqa minn numri negattivi jistgħu ma jgħixux fuq vjaġġi bir-ritorn permezz ta `TokenStream` jew kordi u jistgħu jinqasmu f'żewġ tokens (`-` u litterali pożittivi).
        ///
        ///
        /// Il-litterali maħluqa permezz ta 'dan il-metodu għandhom il-firxa `Span::call_site()` awtomatikament, li tista' tiġi kkonfigurata bil-metodu `set_span` hawn taħt.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Toħloq numru sħiħ litterali ġdid mhux imwaħħal bil-valur speċifikat.
        ///
        /// Din il-funzjoni se toħloq numru sħiħ bħal `1` fejn il-valur sħiħ speċifikat huwa l-ewwel parti taż-token.
        /// L-ebda suffiss mhu speċifikat fuq dan token, li jfisser li invokazzjonijiet bħal `Literal::i8_unsuffixed(1)` huma ekwivalenti għal `Literal::u32_unsuffixed(1)`.
        /// Il-litterali maħluqa minn numri negattivi jistgħu ma jgħixux fir-rountrips permezz ta `TokenStream` jew kordi u jistgħu jinqasmu f'żewġ tokens (`-` u litterali pożittivi).
        ///
        ///
        /// Il-litterali maħluqa permezz ta 'dan il-metodu għandhom il-firxa `Span::call_site()` awtomatikament, li tista' tiġi kkonfigurata bil-metodu `set_span` hawn taħt.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Joħloq letteral ġdid ta 'punt varjabbli mhux imwaħħal.
    ///
    /// Dan il-kostruttur huwa simili għal dawk bħal `Literal::i8_unsuffixed` fejn il-valur tal-float joħroġ direttament fiż-token iżda ma jintuża l-ebda suffiss, allura jista 'jiġi dedott li jkun `f64` aktar tard fil-kompilatur.
    ///
    /// Il-litterali maħluqa minn numri negattivi jistgħu ma jgħixux fir-rountrips permezz ta `TokenStream` jew kordi u jistgħu jinqasmu f'żewġ tokens (`-` u litterali pożittivi).
    ///
    /// # Panics
    ///
    /// Din il-funzjoni teħtieġ li l-float speċifikat ikun finit, pereżempju jekk huwa infinit jew NaN din il-funzjoni tkun panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Joħloq letteral ġdid b'punt li jvarja suffiss.
    ///
    /// Dan il-kostruttur joħloq litterali bħal `1.0f32` fejn il-valur speċifikat huwa l-parti preċedenti taż-token u `f32` huwa s-suffiss taż-token.
    /// Dan iż-token dejjem jiġi dedott li huwa `f32` fil-kompilatur.
    /// Il-litterali maħluqa minn numri negattivi jistgħu ma jgħixux fir-rountrips permezz ta `TokenStream` jew kordi u jistgħu jinqasmu f'żewġ tokens (`-` u litterali pożittivi).
    ///
    ///
    /// # Panics
    ///
    /// Din il-funzjoni teħtieġ li l-float speċifikat ikun finit, pereżempju jekk huwa infinit jew NaN din il-funzjoni tkun panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Joħloq letteral ġdid ta 'punt varjabbli mhux imwaħħal.
    ///
    /// Dan il-kostruttur huwa simili għal dawk bħal `Literal::i8_unsuffixed` fejn il-valur tal-float joħroġ direttament fiż-token iżda ma jintuża l-ebda suffiss, allura jista 'jiġi dedott li jkun `f64` aktar tard fil-kompilatur.
    ///
    /// Il-litterali maħluqa minn numri negattivi jistgħu ma jgħixux fir-rountrips permezz ta `TokenStream` jew kordi u jistgħu jinqasmu f'żewġ tokens (`-` u litterali pożittivi).
    ///
    /// # Panics
    ///
    /// Din il-funzjoni teħtieġ li l-float speċifikat ikun finit, pereżempju jekk huwa infinit jew NaN din il-funzjoni tkun panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Joħloq letteral ġdid b'punt li jvarja suffiss.
    ///
    /// Dan il-kostruttur joħloq litterali bħal `1.0f64` fejn il-valur speċifikat huwa l-parti preċedenti taż-token u `f64` huwa s-suffiss taż-token.
    /// Dan iż-token dejjem jiġi dedott li huwa `f64` fil-kompilatur.
    /// Il-litterali maħluqa minn numri negattivi jistgħu ma jgħixux fir-rountrips permezz ta `TokenStream` jew kordi u jistgħu jinqasmu f'żewġ tokens (`-` u litterali pożittivi).
    ///
    ///
    /// # Panics
    ///
    /// Din il-funzjoni teħtieġ li l-float speċifikat ikun finit, pereżempju jekk huwa infinit jew NaN din il-funzjoni tkun panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String letterali.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karattru litterali.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Sekwenza letterali tal-byte.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Jirritorna l-firxa li tinkludi din il-letterali.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Jikkonfigura l-firxa assoċjata għal din il-letterali.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Jirritorna `Span` li huwa subsett ta `self.span()` li fih biss il-bytes tas-sors fil-firxa `range`.
    /// Jirritorna `None` jekk il-firxa mirquma tkun barra l-limiti ta `self`.
    ///
    // FIXME(SergioBenitez): iċċekkja li l-firxa tal-byte tibda u tispiċċa f'limitu UTF-8 tas-sors.
    // inkella, huwa probabbli li panic iseħħ x'imkien ieħor meta jiġi stampat it-test tas-sors.
    // FIXME(SergioBenitez): m'hemm l-ebda mod biex l-utent ikun jaf għal xiex jimmarka `self.span()` fil-fatt, allura dan il-metodu bħalissa jista 'jissejjaħ biss bl-addoċċ.
    // Pereżempju, `to_string()` għall-karattru 'c' jirritorna "'\u{63}'";m'hemm l-ebda mod biex l-utent ikun jaf jekk it-test tas-sors kienx 'c' jew jekk kienx '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) xi ħaġa simili għal `Option::cloned`, imma għal `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, il-pont jipprovdi biss `to_string`, jimplimenta `fmt::Display` ibbażat fuqu (il-maqlub tar-relazzjoni tas-soltu bejn it-tnejn).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Jistampa l-litterali bħala sekwenza li għandha tkun konvertibbli mingħajr telf lura fl-istess litterali (ħlief għal arrotondament possibbli għal litterali b'punt li jvarja).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Aċċess traċċat għall-varjabbli tal-ambjent.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Irkupra varjabbli tal-ambjent u żidha biex tibni informazzjoni dwar id-dipendenza.
    /// Sistema ta 'Bini li tesegwixxi l-kompilatur tkun taf li l-varjabbli ġiet aċċessata waqt il-kumpilazzjoni, u tkun tista' terġa 'tibda l-bini meta jinbidel il-valur ta' dik il-varjabbli.
    ///
    /// Minbarra t-traċċar tad-dipendenza din il-funzjoni għandha tkun ekwivalenti għal `env::var` mil-librerija standard, ħlief li l-argument għandu jkun UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}