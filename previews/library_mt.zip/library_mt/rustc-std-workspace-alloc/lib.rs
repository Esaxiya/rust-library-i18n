#![feature(no_core)]
#![no_core]

// Ara rustc-std-workspace-core għalfejn dan iż-crate huwa meħtieġ.

// Semmi mill-ġdid iż-crate biex tevita li tkun f'kunflitt mal-modulu alloc fil-liballoc.
extern crate alloc as foo;

pub use foo::*;