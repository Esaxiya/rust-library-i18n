// rsbegin.o u rsend.o huma l-hekk imsejħa "compiler runtime startup objects".
// Fihom kodiċi meħtieġ biex l-runtime tal-kompilatur jiġi inizjalizzat b'mod korrett.
//
// Meta immaġni eżegwibbli jew dylib hija marbuta, il-kodiċi tal-utent u l-libreriji kollha huma "sandwiched" bejn dawn iż-żewġ fajls tal-oġġett, allura kodiċi jew dejta minn rsbegin.o isiru l-ewwel fit-taqsimiet rispettivi tal-immaġni, filwaqt li kodiċi u dejta minn rsend.o isiru l-aħħar.
// Dan l-effett jista 'jintuża biex jitqiegħdu simboli fil-bidu jew fl-aħħar ta' taqsima, kif ukoll biex tiddaħħal kwalunkwe header jew footer meħtieġa.
//
// Innota li l-punt tad-dħul tal-modulu attwali jinsab fl-oġġett tal-istartjar C runtime (ġeneralment imsejjaħ `crtX.o`), li mbagħad jinvoka callbacks ta 'inizjalizzazzjoni ta' komponenti oħra runtime (irreġistrati permezz ta 'sezzjoni speċjali oħra tal-immaġni).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Marki tal-bidu tal-qafas tal-munzell jbattu t-taqsima tal-informazzjoni
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Scratch space għaż-żamma tal-kotba interna tal-unwinder.
    // Dan huwa definit bħala `struct object` f '$ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Ħoll rutini ta 'informazzjoni registration/deregistration.
    // Ara d-dokumenti ta 'libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // irreġistra jbattu informazzjoni dwar l-istartjar tal-modulu
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // unreġistra mal-għeluq
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Reġistrazzjoni ta 'rutina init/uninit speċifika għall-MinGW
    pub mod mingw_init {
        // L-oġġetti tal-istartjar ta 'MinGW (crt0.o/dllcrt0.o) se jinvokaw kostrutturi globali fit-taqsimiet .ctors u .dtors mal-istartjar u l-ħruġ.
        // Fil-każ ta 'DLLs, dan isir meta d-DLL titgħabba u tinħatt.
        //
        // Il-linker ser jagħżel is-sezzjonijiet, li jiżgura li s-sejħiet lura tagħna jinsabu fl-aħħar tal-lista.
        // Peress li l-kostrutturi jitħaddmu f'ordni inversa, dan jiżgura li l-callbacks tagħna huma l-ewwel u l-aħħar eżegwiti.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: Callbacks ta 'inizjalizzazzjoni Ċ
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dutturi. *: Callbacks tat-terminazzjoni Ċ
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}