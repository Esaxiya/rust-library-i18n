//! Windows SEH
//!
//! Fuq Windows (bħalissa fuq MSVC biss), il-mekkaniżmu ta 'maniġġar ta' eċċezzjonijiet awtomatiku huwa Strutturat Eċċezzjoni Immaniġġjar (SEH).
//! Dan huwa pjuttost differenti mill-immaniġġjar ta 'eċċezzjonijiet ibbażat fuq Dwarf (eż., Dak li jużaw pjattaformi unix oħra) f'termini ta' kompilaturi interni, għalhekk LLVM huwa meħtieġ li jkollu ammont kbir ta 'appoġġ żejjed għal SEH.
//!
//! Fi ftit kliem, dak li jiġri hawnhekk huwa:
//!
//! 1. Il-funzjoni `panic` issejjaħ il-funzjoni standard Windows `_CxxThrowException` biex tarmi eċċezzjoni bħal C++ , li tikkawża l-proċess tat-tħollija.
//! 2.
//! Il-pads tal-inżul kollha ġġenerati mill-kompilatur jużaw il-funzjoni tal-personalità `__CxxFrameHandler3`, funzjoni fis-CRT, u l-kodiċi tat-tidwir f Windows se juża din il-funzjoni tal-personalità biex teżegwixxi l-kodiċi tat-tindif kollu fuq il-munzell.
//!
//! 3. Is-sejħiet kollha ġġenerati mill-kompilatur għal `invoke` għandhom kuxxinett tal-inżul issettjat bħala struzzjoni `cleanuppad` LLVM, li tindika l-bidu tar-rutina tat-tindif.
//! Il-personalità (fil-pass 2, definita fis-CRT) hija responsabbli għat-tmexxija tar-rutini tat-tindif.
//! 4. Eventwalment il-kodiċi "catch" fl-intrinsiku `try` (iġġenerat mill-kompilatur) jiġi eżegwit u jindika li l-kontroll għandu jiġi lura għal Rust.
//! Dan isir permezz ta `catchswitch` flimkien ma' struzzjoni `catchpad` f'termini ta 'LLVM IR, fl-aħħar jirritorna l-kontroll normali lill-programm b'istruzzjoni `catchret`.
//!
//! Xi differenzi speċifiċi mill-immaniġġjar tal-eċċezzjonijiet ibbażat fuq gcc huma:
//!
//! * Rust m'għandux funzjoni ta 'personalità personalizzata, minflok huwa *dejjem*`__CxxFrameHandler3`.Barra minn hekk, ma jsir l-ebda filtrazzjoni żejda, allura aħna nispiċċaw naqbdu xi eċċezzjonijiet C++ li jiġru qishom it-tip li qed nitfgħu.
//! Innota li l-fatt li titfa 'eċċezzjoni f'Rust huwa xorta waħda mġieba mhux definita, allura dan għandu jkun tajjeb.
//! * Għandna xi dejta x'nittrażmettu tul il-konfini tat-tħollija, speċifikament `Box<dyn Any + Send>`.Bħal f'eċċezzjonijiet Dwarf dawn iż-żewġ indikaturi huma maħżuna bħala payload fl-eċċezzjoni nnifisha.
//! Fuq MSVC, madankollu, m'hemmx bżonn ta 'allokazzjoni żejda tal-borġ minħabba li l-munzell tas-sejħiet huwa ppreservat waqt li l-funzjonijiet tal-filtru qed jiġu eżegwiti.
//! Dan ifisser li l-indikaturi huma mgħoddija direttament lil `_CxxThrowException` li mbagħad jiġu rkuprati fil-funzjoni tal-filtru biex jinkitbu fil-qafas tal-munzell tal-intrinsiku `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Din teħtieġ li tkun Għażla għax naqbdu l-eċċezzjoni b'referenza u d-distruttur tagħha jiġi eżegwit mill-runtime ta 'C ++.
    // Meta noħorġu l-Kaxxa mill-eċċezzjoni, irridu nħallu l-eċċezzjoni fi stat validu biex id-distruttur tagħha jimxi mingħajr ma twaqqa 'l-Kaxxa darbtejn.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// L-ewwelnett, mazz sħiħ ta 'definizzjonijiet tat-tip.Hawn xi odditajiet speċifiċi għall-pjattaforma hawn, u ħafna li huma biss ikkupjati sfaċċatament minn LLVM.L-iskop ta 'dan kollu huwa li timplimenta l-funzjoni `panic` hawn taħt permezz ta' sejħa lil `_CxxThrowException`.
//
// Din il-funzjoni tieħu żewġ argumenti.L-ewwel wieħed huwa indikatur għad-dejta li qed ngħaddu fiha, li f'dan il-każ huwa l-oġġett trait tagħna.Pjuttost faċli biex issib!Is-segwenti, madankollu, huwa iktar ikkumplikat.
// Dan huwa indikatur għal struttura `_ThrowInfo`, u ġeneralment huwa maħsub biss biex jiddeskrivi l-eċċezzjoni li qed tintefa '.
//
// Bħalissa d-definizzjoni ta 'dan it-tip [1] hija ftit xagħar, u l-oddità ewlenija (u d-differenza mill-artiklu onlajn) hija li fuq 32-bit l-indikaturi huma indikaturi iżda fuq 64-il-indikaturi huma espressi bħala offsets ta' 32-bit Simbolu `__ImageBase`.
//
// Il-makro `ptr_t` u `ptr!` fil-moduli hawn taħt jintużaw biex jesprimu dan.
//
// Il-labirint tad-definizzjonijiet tat-tip isegwi wkoll mill-qrib dak li LLVM joħroġ għal din it-tip ta 'operazzjoni.Pereżempju, jekk tikkompila dan il-kodiċi C++ fuq MSVC u tarmi l-LLVM IR:
//
//      #include <stdint.h>
//
//      strutt rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      null foo() { rust_panic a = {0, 1};
//          tarmi a;}
//
// Dak hu essenzjalment dak li qed nippruvaw nimitaw.Ħafna mill-valuri kostanti hawn taħt kienu biss ikkupjati minn LLVM,
//
// Fi kwalunkwe każ, dawn l-istrutturi huma kollha mibnija b'mod simili, u huwa kemmxejn verbose għalina.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Innota li intenzjonalment ninjoraw ir-regoli tal-immaniġġjar tal-ismijiet hawn: ma rridux li C++ ikun jista 'jaqbad lil Rust panics billi sempliċement tiddikjara `struct rust_panic`.
//
//
// Meta timmodifika, kun żgur li s-sekwenza tal-isem tat-tip taqbel eżattament ma 'dik użata f `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Il-byte `\x01` ewlieni hawnhekk huwa attwalment sinjal maġiku lil LLVM biex *ma* japplikax xi mangljar ieħor bħal prefissjar b'karattru `_`.
    //
    //
    // Dan is-simbolu huwa l-vtable użat minn `std::type_info` ta 'C ++.
    // Oġġetti tat-tip `std::type_info`, deskritturi tat-tip, għandhom pointer għal din it-tabella.
    // Id-deskritturi tat-tip huma referenzjati mill-istrutturi C++ EH definiti hawn fuq u li nibnu hawn taħt.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Dan id-deskrittur tat-tip jintuża biss meta titfa eċċezzjoni.
// Il-parti tal-qabda hija mmaniġġjata mill-try intrinsic, li tiġġenera t-TypeDescriptor tagħha stess.
//
// Dan huwa tajjeb peress li r-runtime tal-MSVC juża paragun ta 'spag fuq l-isem tat-tip biex jaqbel ma' Deskritturi tat-Tip minflok l-ugwaljanza tal-pointer.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Distruttur użat jekk il-kodiċi C++ jiddeċiedi li jaqbad l-eċċezzjoni u jwaħħalha mingħajr ma jinfirex.
// Il-parti tal-qabda tal-try intrinsika tissettja l-ewwel kelma tal-oġġett tal-eċċezzjoni għal 0 sabiex tinqabeż mid-distruttur.
//
// Innota li x86 Windows juża l-konvenzjoni tas-sejħa "thiscall" għall-funzjonijiet tal-membru C++ minflok il-konvenzjoni tas-sejħa "C" default.
//
// Il-funzjoni exception_copy hija daqsxejn speċjali hawnhekk: hija invokata mill-MSVC runtime taħt blokka try/catch u ż-panic li niġġeneraw hawn se jintuża bħala riżultat tal-kopja ta 'eċċezzjoni.
//
// Dan jintuża mir-runtime ta 'C ++ biex jappoġġja l-qbid ta' eċċezzjonijiet b std::exception_ptr, li ma nistgħux nappoġġjaw minħabba Box<dyn Any>mhix kklonabbli.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException jeżegwixxi kompletament fuq dan il-qafas tal-munzell, allura m'hemmx bżonn li inkella tittrasferixxi `data` għall-borġ.
    // Aħna biss ngħaddu munzell pointer għal din il-funzjoni.
    //
    // Il-ManuallyDrop huwa meħtieġ hawnhekk peress li ma rridux li Eċċezzjoni titwaqqa 'meta tinħall.
    // Minflok jitwaqqa 'minn exception_cleanup li huwa invokat mir-runtime ta' C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dan ... jista 'jidher sorprendenti, u ġustifikabbilment.Fuq MSVC ta '32-bit l-indikaturi bejn dawn l-istrutturi huma biss dak, indikaturi.
    // Fuq 64-bit MSVC, madankollu, l-indikaturi bejn l-istrutturi huma pjuttost espressi bħala offsets ta '32-bit minn `__ImageBase`.
    //
    // Konsegwentement, fuq MSVC ta '32-bit nistgħu niddikjaraw dawn l-indikaturi kollha fl-'statiku' hawn fuq.
    // Fuq MSVC ta '64 bit, ikollna nesprimu tnaqqis ta' indikaturi fl-istatika, li Rust bħalissa ma jippermettix, allura ma nistgħux nagħmlu dak.
    //
    // L-aħjar ħaġa li jmiss, allura hija li timla dawn l-istrutturi waqt il-ħin ta 'eżekuzzjoni (il-paniku huwa diġà x-"slow path" xorta waħda).
    // Allura hawn aħna ninterpretaw mill-ġdid dawn l-oqsma kollha tal-pointer bħala numri sħaħ ta '32-bit u mbagħad naħżnu l-valur rilevanti fih (atomikament, kif jista' jkun qed iseħħ panics konkorrenti).
    //
    // Teknikament ir-runtime probabbilment jagħmel qari mhux anatomiku ta 'dawn l-oqsma, imma fit-teorija huma qatt ma jaqraw il-valur *ħażin* u għalhekk m'għandux ikun ħażin wisq ...
    //
    // Fi kwalunkwe każ, bażikament għandna bżonn nagħmlu xi ħaġa bħal din sakemm inkunu nistgħu nesprimu aktar operazzjonijiet fl-istatika (u forsi qatt ma nkunu nistgħu).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // Tagħbija NULL hawnhekk tfisser li wasalna hawn mill-qabda (...) ta '__rust_try.
    // Dan jiġri meta tinqabad eċċezzjoni barranija mhux Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dan huwa meħtieġ mill-kompilatur biex jeżisti (eż., Huwa oġġett lang), iżda qatt ma jissejjaħ mill-kompilatur għax __C_specific_handler jew_except_handler3 hija l-funzjoni tal-personalità li dejjem tintuża.
//
// Għalhekk dan huwa biss stub abort.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}