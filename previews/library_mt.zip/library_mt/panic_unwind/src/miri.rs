//! Ħoll panics għal Miri.
use alloc::boxed::Box;
use core::any::Any;

// It-tip ta 'tagħbija li l-magna Miri tinfirex permezz ta' tħollija għalina.
// Għandu jkun daqs il-pointer.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Funzjoni esterna pprovduta minn Miri biex tibda tħoll.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // It-tagħbija li ngħaddu lil `miri_start_panic` se tkun eżattament l-argument li nġibu f `cleanup` hawn taħt.
    // Allura aħna sempliċement kaxxa darba, biex tikseb xi ħaġa daqs pointer.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Irkupra x-`Box` sottostanti.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}