# د `rustc-std-workspace-core` crate

دا crate یو شمع او خالي crate دی کوم چې په ساده ډول په `libcore` پورې اړه لري او د هغې ټول مینځپانګې له سره ثبت کوي.
crate د crates.io څخه crates تکیه کولو لپاره د معیاري کتابتون ځواک کولو ځواک دی

Crates په crates.io کې چې معیاري کتابتون د X002 څخه د `rustc-std-workspace-core` crate پورې تړلو ته اړتیا پورې اړه لري ، کوم چې خالي دی.

موږ په دې ذخیره کې د دې crate ته د تاوولو لپاره `[patch]` کاروو.
د پایلې په توګه ، crates.io باندې crates به X0Xge ته edge انحصار راوباسي ، نسخه چې پدې زیرمه کې تعریف شوې.
دا باید د انحصاري ټولې څنډې رسم کړي ترڅو ډاډ ترلاسه شي چې Cargo د crates بریالیتوب سره جوړوي!

په یاد ولرئ چې په crates.io کې crates اړتیا لري ترڅو د هرڅه سم کار لپاره د `core` نوم سره پدې crate تکیه وکړي.د دې کولو لپاره چې دوی وکاروي:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

د `package` کیلي کارولو له لارې crate `core` ته بدل شوی ، پدې معنی چې دا به ورته ښکاري

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

کله چې Cargo تالیف کونکي غوښتنه کوي ، د کمپلر لخوا انجیک شوي ضمیمه `extern crate core` لارښود راضي کوي.




