#![feature(no_core)]
#![no_core]

// rustc-std-workpace-core وګورئ د دې لپاره چې ولې دې crate اړین دی.

// crate نوم بدل کړئ ترڅو په لیبالاک کې د تخصیص ماډل سره تضاد څخه مخنیوی وشي.
extern crate alloc as foo;

pub use foo::*;