# backtrace-rs

[Documentation](https://docs.rs/backtrace)

د Rust لپاره په وخت کې د بیکټراس ترلاسه کولو کتابتون.
دا کتابتون هدف لري ترڅو د کار کولو لپاره د برنامې انٹرفیس چمتو کولو سره د معیاري کتابتون ملاتړ لوړ کړي ، مګر دا د لیبسټډ panics په څیر په اسانۍ سره د اوسني بیک ټریس چاپولو ملاتړ کوي.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

په ساده ډول د بیکټریک او ډیفر معاملې کولو لپاره ترڅو وروسته تر هغه پورې دا معامله وکړئ ، تاسو کولی شئ د لوړې کچې `Backtrace` ډول وکاروئ.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

که چیرې ، تاسو د اصلي تعقیب فعالیت ته ډیر خام لاسرسی غواړئ ، نو تاسو کولی شئ په مستقیم ډول د `trace` او `resolve` افعال وکاروئ.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // د دې لارښود نښه د سمبول نوم ته حل کړئ
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // راتلونکي چوکاټ ته دوام ورکړئ
    });
}
```

# License

دا پروژه د کوم یو لاندې جواز لري

 * د Apache جواز ، نسخه 2.0 ، ([LICENSE-APACHE](LICENSE-APACHE) یا http://www.apache.org/licenses/LICENSE-2.0)
 * د MIT لایسنس ([LICENSE-MIT](LICENSE-MIT) یا http://opensource.org/licenses/MIT)

ستاسو په اختیار کې.

### Contribution

غیر لدې چې تاسو په ښکاره ډول بیان کړئ ، هرهغه مرسته چې په قصدي ډول ستاسو لخوا بیکریکټ-آر ایس کې د شمولیت لپاره سپارل شوې وي ، لکه څنګه چې د Apache-2.0 لایسنس کې تعریف شوي ، پرته د اضافي شرایطو او شرایطو څخه ، دوه ځله جواز جواز لري.







