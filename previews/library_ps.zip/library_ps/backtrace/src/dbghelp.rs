//! په Windows د dbghelp باندینیو اداره کولو کې د مرستې لپاره یو ماډل
//!
//! په Windows کې بیکراسیس (لږترلږه د MSVC لپاره) په پراخه کچه د `dbghelp.dll` او بیلابیل افعالونو له لارې ځواک لري چې پکې شامل دي.
//! دا افعال اوس مهال د `dbghelp.dll` سره په احصایه د لینک کولو پرځای *په متحرک ډول* ډک شوي دي.
//! دا اوس مهال د معیاري کتابتون لخوا ترسره کیږي (او په تیورۍ کې ورته اړتیا لیدل کیږي) ، مګر دا یوه هڅه ده چې د کتابتون مستحکم dll انحصار کمولو کې مرسته وکړئ ځکه چې backtraces عموما خورا اختیاري دي.
//!
//! دا ویل کیږي چې ، `dbghelp.dll` نږدې تل په بریالیتوب سره په Windows لوړیږي.
//!
//! که څه هم یادونه وکړئ چې له دې چې موږ دا ټول ملاتړ په متحرک ډول واردوو موږ واقعیا نشو کولی په `winapi` کې خام تعریفونه وکاروو ، بلکه موږ اړتیا لرو پخپله د فعالیت نښې ډولونه تعریف کړو او دا وکاروو.
//! موږ واقعیا نه غواړو د ویناپی د نقل کولو سوداګرۍ کې واوسو ، نو موږ د Cargo ب featureه لرئ `verify-winapi` چې دا ادعا کوي چې ټول تړلي د ویناپی سره ورته دي او دا ب Cه په CI کې فعال شوي.
//!
//! په نهایت کې ، تاسو به دلته یادونه وکړئ چې د `dbghelp.dll` لپاره dll هیڅکله نه ډک شوی ، او دا اوس مهال ارادي دی.
//! فکر دا دی چې موږ کولی شو دا په نړیواله کچه زیرمه کړو او دا API ته د تلیفونونو تر منځ وکاروو ، د ګران loads/unloads څخه مخنیوی وکړو.
//! که دا د لیک کشف کونکو لپاره ستونزه وي یا ورته ورته یو څه چې موږ کولی شو پل تیر کړو کله چې موږ هلته ورسیږو.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// د `SymGetOptions` او `SymSetOptions` شاوخوا کار وکړئ پخپله په ویناپی کې شتون نلري.
// که نه نو دا یوازې هغه وخت کارول کیږي کله چې موږ د وینپي په مقابل کې دوه ځله چیک کوو.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // تراوسه په ویناپی کې نه دی ټاکل شوی
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // دا په ویناپی کې تعریف شوی ، مګر دا غلط دی (FIXME winapi-RSS#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // تراوسه په ویناپی کې نه دی ټاکل شوی
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// دا میکرو د `Dbghelp` جوړښت تعریف کولو لپاره کارول کیږي کوم چې په داخلي توګه ټول د فعالیت نښې لري چې موږ یې شاید لوړه کړو.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// د `dbghelp.dll` لپاره بار شوی DLL
            dll: HMODULE,

            // د هرې غونډې لپاره د هر فعالیت نښې چې موږ یې وکاروو
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // په پیل کې موږ DLL نه دی پورته کړی
            dll: 0 as *mut _,
            // ابتدایی ټول افعال صفر ته تنظیم شوي ترڅو دا ووایی چې دوی په متحرک ډول بارولو ته اړتیا لري.
            //
            $($name: 0,)*
        };

        // د هر فعالیت ډول لپاره اسانتیا ټایډیډیف.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// د `dbghelp.dll` خلاصولو هڅې.
            /// بریا ته راستنوي که چیرې دا کار وکړي یا غلطي وي که `LoadLibraryW` ناکام شي.
            ///
            /// Panics که کتابتون لا دمخه شوی وي.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // د هرې میتود لپاره فنکشن چې موږ یې کارول غواړو.
            // کله چې ویل کیږي دا به د کیچ شوي فنکشن نښه ولوستل شي یا به یې پورته کړي او پورته شوی ارزښت بیرته راشي.
            // د بریالیتوب لپاره بارونه تاکید شوي.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // د dbghelp وظایفو ته مراجع کولو لپاره د پاکولو قفلونو کارولو لپاره د اسانتیا پراکسي.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// د دې crate څخه د `dbghelp` API افعالاتو ته لاسرسي لپاره ټول ملاتړ اړین پیل کړئ.
///
///
/// په یاد ولرئ چې دا فنکشن **خوندي** دی ، دا په داخلي توګه خپل ترکیب لري.
/// دا هم په یاد ولرئ چې دا خوندي دی چې دا فعالیت څو ځله تکرار سره تلیفون کړئ.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // لومړی شی چې موږ یې کولو ته اړتیا لرو د دې فنلیک هماهنګ کول دي.دا په ورته ډول د نورو موضوعاتو څخه یا په یو تار کې تکرار بلل کیدی شي.
        // په یاد ولرئ چې دا د دې په پرتله خورا پیچلي دي که څه هم چې موږ دلته کار کوو ، `dbghelp` ،*هم* اړتیا لري چې پدې پروسه کې `dbghelp` ته د نورو ټولو تلیفون کونکو سره همغږه شي.
        //
        // په عموم کې واقعیا داسې نه دي چې په ورته پروسه کې `dbghelp` ته ډیری زنګونه وي او موږ شاید په خوندي ډول فرض کړو چې موږ ورته یوازینۍ لاسرسی لرو.
        // په هرصورت ، یو لومړنی بل کارونکی شتون لري چې موږ یې په اړه اندیښنه لرو کوم چې پخپله پخپله ساده دی ، مګر په معیاري کتابتون کې.
        // د Rust معیاري کتابتون د بیکټریک ملاتړ لپاره پدې crate پورې اړه لري ، او دا crate په crates.io کې هم شتون لري.
        // دا پدې مانا ده چې که معیاري کتابتون د panic بیکټریس چاپ کوي نو ممکن د دې crate سره سیالي وکړي چې د crates.io څخه راځي ، د سیګفاټونو لامل کیږي.
        //
        // د دې همغږۍ ستونزې حلولو کې د مرستې لپاره موږ دلته د وینډوز ځانګړي چال ګمارو (دا له هرڅه وروسته ، د همغږۍ په اړه د وینډوز ځانګړی محدودیت دی).
        // موږ د دې کال ساتنې لپاره د میټیکس په نوم *سیشن ځایی* جوړوو.
        // دلته اراده دا ده چې معیاري کتابتون او دا crate اړتیا نلري چې دلته د ترکیب لپاره د Rust کچې APIs شریک کړي مګر د پردې ترشا کار کولی شي ډاډ ترلاسه کړي چې دوی د یو بل سره همغږي شوي دي.
        //
        // په دې توګه کله چې دا فنکشن د معیاري کتابتون یا crates.io له لارې ویل کیږي موږ ډاډه کیدی شو چې ورته مسټیک ترلاسه شوی دی.
        //
        // نو د دې ټولو ویل دا دي چې لومړی شی چې موږ دلته کوو هغه دا دی چې موږ په اټومي ډول یو `HANDLE` رامینځته کړو کوم چې په Windows کې نومیږي.
        // موږ د نورو موضوعاتو سره یو څه یو څه ترکیب کوو په ځانګړي ډول دا فنکشنل شریکوي او ډاډ ترلاسه کوو چې د دې فعالیت مثال په توګه یوازې یو هینډل جوړ شوی.
        // په یاد ولرئ چې لاستی هیڅکله نه تړل کیږي کله چې دا په نړۍ کې زیرمه شي.
        //
        // وروسته له هغه چې موږ واقعیا لاک ته لاړ شو موږ یې ساده ډول ترلاسه کوو ، او زموږ د `Init` هینڈل چې موږ یې وسپارو د دې د پای ته رسولو مسؤلیت به وي.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // سمه ده ، وروره!اوس چې موږ ټول په خوندي ډول همغږي شوي یو ، راځئ چې واقعیا د هرڅه پروسس پیل کړو.
        // لومړی موږ اړتیا لرو ډاډ ترلاسه کړو چې `dbghelp.dll` واقعیا پدې پروسه کې بار شوی.
        // موږ دا د متحرک انحصار څخه مخنیوي لپاره په متحرک ډول کوو.
        // دا په تاریخي ډول د عجیب اړیکې مسلو په اړه کار کولو لپاره ترسره شوی او موخه یې دا ده چې بائنریونه یو څه ډیر د پام وړ وړ شي ځکه چې دا په لویه کچه یوازې د ډیبګ کولو کار دی.
        //
        //
        // یوځل چې موږ د `dbghelp.dll` خلاص کړی نو موږ اړتیا لرو پدې کې یو څه ابتدايي افعال وغواړو ، او دا لاندې نور تفصیل ورکړل شوی.
        // موږ دا یوازې یو ځل ترسره کوو ، که څه هم ، نو موږ یو نړیوال بولین ترلاسه کړی چې په ګوته کوي چې ایا موږ تراوسه بشپړ کړی یا نه.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // ډاډ ترلاسه کړئ چې د `SYMOPT_DEFERRED_LOADS` بيرغ تنظیم شوی ، ځکه چې د دې په اړه د MSVC د خپلو اسنادو مطابق: "This is the fastest, most efficient way to use the symbol handler." ، نو راځئ چې دا وکړو!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // په حقیقت کې د MSVC سره سمبولونه پیل کړئ.په یاد ولرئ چې دا ناکام کیدی شي ، مګر موږ یې له پامه غورځوو.
        // د دې برخې لپاره یو ټن دمخه هنر شتون نلري ، مګر LLVM په داخلي توګه داسې ښکاري چې دلته د بیرته ستنیدو ارزښت له پامه غورځوي او په LLVM کې د سنیټاییزر کتابتونونو څخه یو ویرونکی خبرداری چاپ کوي که چیرې دا ناکام شي مګر اساسا په اوږد مهال کې یې له پامه غورځوي.
        //
        //
        // یوه قضیه چې دا د Rust لپاره خورا راپورته کیږي هغه دا چې معیاري کتابتون او دا crate په crates.io کې دواړه غواړي د `SymInitializeW` لپاره سیالي وکړي.
        // معیاري کتابتون په تاریخي توګه غوښتل چې ډیری وخت پاک کړي بیا ډیری وخت پاک کړي ، مګر اوس چې دا دا د crate کاروي د دې معنی لري چې یو څوک به لومړی ابتکار ته ورسیږي او بل به دا ابتکار غوره کړي.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}