use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr یو کال بیک اخلي چې د هر DSO لپاره به dl_phdr_info پوائنټر ترلاسه کړي چې په پروسه کې تړاو لري.
    // dl_iterate_phdr هم ډاډ ترلاسه کوي چې متحرک لینکر د پیل څخه د تکرار پای پورې لاک شوی دی.
    // که چیرې کالبیک غیر صفر ارزښت بیرته راشي نو تکرار به دمخه پای ته ورسیږي.
    // 'data' په هر کال کې به زنګ ته د دریم دلیل په توګه انتقال شي.
    // 'size' د dl_phdr_info کچه ورکوي.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// موږ اړتیا لرو د جوړونې ID او ځینې لومړني برنامه سرلیک معلومات ډاټا کړئ چې پدې معنی دي چې موږ د ELF ځانګړي څخه یو څه شیانو ته هم اړتیا لرو.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// اوس موږ باید د بیټ لپاره دقیقا ، د dl_phdr_info ډول جوړښت د فوچیا اوسني متحرک لینکر لخوا کارول شوي.
// کرومیم د دې ABI حد او همدارنګه کریشپډ لري.
// په نهایت کې موږ غواړو دا قضیې د ایلف-لټون کارولو لپاره حرکت وکړي مګر موږ اړتیا لرو چې دا په SDK کې چمتو کړو او دا لاهم ندي ترسره شوي.
//
// پدې توګه موږ (او دوی) د دې میتود کارولو ته پاتي یو چې د فوچیا لیبک سره کلک جوړه جوړه کوي.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // موږ د چک کولو پوهه کولو کومه لاره نلرو که چیرې e_phoff او e_phnum معتبر وي.
    // libc باید دا زموږ لپاره ډاډمن کړي نو ځکه نو دا خوندي دی چې دلته سلیس جوړ کړئ.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr د 64-bit ELF برنامې سرلیک د هدف جوړونې په پای کې وړاندې کوي.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// پی ایچ ډي آر د ELF برنامه معتبر سرلیک او د هغې مینځپانګې وړاندې کوي.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // موږ د چک کولو هیڅ لاره نلرو که p_addr یا p_memsz معتبر وي.
    // د فوچیا لبیک لومړی نوټونه پارس کوي په هرصورت د دې لپاره چې دلته شتون باید دا سرلیکونه باید د اعتبار وړ وي.
    //
    // نوټ انټرنیټ اړین ارقام ته اړتیا نلري باوري وي مګر دا د اعتبار لپاره حدونو ته اړتیا لري.
    // موږ باور لرو چې لبیک ډاډ ترلاسه کړی چې دا دلته زموږ لپاره قضیه ده.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// د IDs جوړولو لپاره د یادونې ډول.
const NT_GNU_BUILD_ID: u32 = 3;

// ایلف_ اینډډر د هدف په پای کې د ELF نوټ سرلیک وړاندې کوي.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// یادونه د ELF یادداشت وړاندې کوي (سرلیک + مینځپانګه).
// نوم د u8 سلیس په توګه پاتې دی ځکه چې دا تل نه ختمیدل کیږي او rust دا دومره اسانه کوي چې دا چیک کړي چې بایټونه دواړه سره میچ لري.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// نوټ انټر تاسو ته اجازه درکوي په خوندي ډول د یادونې برخې ته واړوئ.
// دا ژر تر ژره ختمیږي کله چې یوه ستونزه رامینځته کیږي یا نور نوټونه شتون نلري.
// که تاسو په ناباوره معلوماتو تکرار کړئ دا به داسې کار وکړي لکه څنګه چې هیڅ نوټونه ونه موندل شول.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // دا د فعالیت یو ناڅاپي دی چې ورکړل شوی نښې او اندازه یې د بایټونو معتبر سلسله په نښه کوي چې ټول یې لوستل کیدی شي.
    // د دې بایټس مینځپانګه هرڅه کیدی شي مګر حد یې باید د دې لپاره د اعتبار وړ وي ترڅو خوندي وي.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' د 'to'-بایټ دښت سمون په دې معنی چې 'to' د 2 ځواک دی.
// دا په C/C ++ ELF پارسی کولو کوډ کې معیاري ب patternه تعقیبوي چیرې چې (x + to، 1) او -to کارول کیږي.
// Rust تاسو ته اجازه نه ورکوي چې موږ غلا کړئ نو زه یې کاروم
// 2 د بشپړولو لپاره د هغه بشپړولو لپاره بشپړونکي بدلون.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 د سلایټ څخه شمیر بایټونه مصرف کوي (که شتون ولري) او سربیره پردې تضمین کوي چې وروستۍ ټوټه په مناسبه توګه تنظیم شوې وي.
// که چیرې د غوښتنې شوي بایټونو شمیر خورا ډیر وي یا نو وروسته د کافي پاتې بایټس نه شتون له امله پاiceه نشي پیژندل کیدی ، هیڅ یې بیرته نه راځي او سلیس تمدید شوی ندی.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// دا فنکشن هیڅ اصلي دعوت کونکي نلري زنګ وهونکی باید نور هم پورته کړي شاید دا چې 'bytes' باید د فعالیت لپاره سمون ولري (او په ځینې معماراتو سموالي باندې).
// په ایلف_ اینډډر برخو کې ارزښتونه شاید احمقانه وي مګر دا فعالیت هیڅ داسې شی نه تضمینوي.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // دا تر هغه وخته خوندي دی چې مناسب ځای شتون ولري او موږ یوازې تایید کړه چې که په پورتنۍ بیانیه کې نو دا باید خوندي نه وي.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // په یاد ولرئ چې sice_of: :<Elf_Nhdr>() تل د 4 بایټ سره سم دی.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // وګورئ که موږ پای ته رسیدلي یاست.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // موږ یو nhdr لیږدوو مګر موږ په احتیاط سره پایلې ته پام کوو.
        // موږ په نومز یا ډیسیکز باور نه لرو او د ډول پراساس موږ هیڅ غیر محفوظې پریکړې نه کوو.
        //
        // نو حتی که موږ بشپړ کثافات بهر کړو موږ باید لاهم خوندي واوسو.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// په ګوته کوي چې برخه د اجرا وړ ده.
const PERM_X: u32 = 0b00000001;
/// په ګوته کوي چې برخه د لیکلو وړ ده.
const PERM_W: u32 = 0b00000010;
/// په ګوته کوي چې برخه د لوستلو وړ ده.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// په منډه وخت کې د ELF برخې وړاندې کوي.
struct Segment {
    /// د دې برخې مینځپانګې د رنیم وخت مجازی پته ورکوي.
    addr: usize,
    /// د دې برخې مینځپانګو د حافظې اندازه ورکوي.
    size: usize,
    /// د دې برخې ماډل مجازی پته د ELF فایل سره ورکوي.
    mod_rel_addr: usize,
    /// د ELF فایل کې موندل شوي اجازه درکوي.
    /// دا اجازه لیکونه لازمي نه دي په ورته وخت کې د ځنډ پر مهال موجودې اجازې دي.
    flags: Perm,
}

/// اجازه راکړئ د DSO څخه برخې باندې یو تکرار شي.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// د ELF DSO (متحرک شریکه شی) وړاندې کوي.
/// دا ډول د خپل کاپي جوړولو پرځای په ریښتیني DSO کې زیرمه شوي معلومات حواله کوي.
struct Dso<'a> {
    /// متحرک لینکر تل موږ ته یو نوم راکوي ، حتی که نوم خالي وي.
    /// د اصلي اجرا کونکي په حالت کې به دا نوم خالي وي.
    /// د شریک شوي څیز په قضیه کې به دا سونیم وي (وګورئ DT_SOName).
    name: &'a str,
    /// په فوچیا کې په حقیقت کې ټول بائنریز IDs جوړوي مګر دا یو سخت اړتیا نلري.
    /// د DSO معلومات د اصلي ELF فایل سره وروسته میچ کولو لپاره هیڅ لاره شتون نلري وروسته له دې که build_id شتون نلري نو موږ اړتیا لرو چې هر DSO دلته ولري.
    ///
    /// DSO د build_id پرته سترګې پټوي.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// په دې DSO کې برخو کې تکراري ب .ه ورکوي.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// دا غلطۍ هغه مسلې کوډ کوي چې رامینځته کیږي کله چې د هر DSO په اړه د معلوماتو تجزیه کول.
///
enum Error {
    /// د نوم اییر معنی دا ده چې د C سټایل سلسله rust تار ته اړولو پرمهال یوه ستونزه رامینځته شوه.
    ///
    NameError(core::str::Utf8Error),
    /// د بلډ ایډرایر پدې معنی چې موږ د جوړونې ID ونه موند.
    /// دا یا دا کیدی شي ځکه چې DSO هیڅ د جوړولو ID نلري یا ځکه چې برخه د ID په کې برخه لري خرابه وه.
    ///
    BuildIDError,
}

/// د هر DSO لپاره 'dso' یا 'error' تلیفون کړئ د متحرک لینکر لخوا پروسې سره وصل شوي.
///
///
/// # Arguments
///
/// * `visitor` - یو DsoPrinter چې د خواړو یو له میتودونه ولري د foreach DSO په نوم.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr ډاډ ورکوي چې info.name به معتبر موقعیت ته ګوته ونیسي.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// دا فنکشن په DSO کې شامل ټول معلوماتو لپاره د فوچیا سمبولیک مارک اپ چاپ کوي.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}