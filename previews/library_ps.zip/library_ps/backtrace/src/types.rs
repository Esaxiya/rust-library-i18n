//! د پلیټفارم پورې تړلې ډولونه.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// د سلسلې یو پلیټ فارم خپلواک استازیتوب.
/// کله چې د `std` فعال سره کار کول دا د `std` ډولونو ته د تبادلې چمتو کولو لپاره د اسانتیا میتودونو کې وړاندیز کیږي.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// یو سلیس ، په عمومي ډول د Unix پلیټ فارمونو کې چمتو شوی.
    Bytes(&'a [u8]),
    /// پراخه تارونه عموما د Windows څخه.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// لوسی `Cow<str>` ته واړوئ ، اختصاص شي که `Bytes` د UTF-8 اعتبار نلري یا که `BytesOrWideString` `Wide` وي.
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// د `BytesOrWideString` استازیتوب د `Path` چمتو کوي.
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}