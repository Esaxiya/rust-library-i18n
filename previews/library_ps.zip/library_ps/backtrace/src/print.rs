#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// د بیکټراس لپاره یو فارمیټر.
///
/// دا ډول د بیکټریس چاپ کولو لپاره کارول کیدی شي پرته لدې چې له هغه ځای څخه چې backtrace پخپله راځي.
/// که تاسو د `Backtrace` ډول لرئ نو بیا د دې `Debug` پلي کول دمخه دا چاپ کولو ب usesه کاروي.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// د چاپ کولو سټایلونه چې موږ یې چاپ کولی شو
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// د ټیرسر بیکټریس چاپوي کوم چې په مثالي ډول یوازې اړوند معلومات لري
    Short,
    /// د بیکټریس چاپ کوي چې ټول احتمالي معلومات لري
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// یو نوی `BacktraceFmt` رامینځته کړئ کوم چې چمتو شوي `fmt` ته آؤټ لیکي.
    ///
    /// د `format` دلیل به هغه سټایل کنټرول کړي په کوم کې چې بیکټریس چاپ شوی ، او د `print_path` دلیل به د فایل نومونو `BytesOrWideString` مثالونو چاپولو لپاره وکارول شي.
    /// دا ډول پخپله د فایل نومونو هیڅ چاپ نه کوي ، مګر دا کالباک د دې کولو لپاره اړین دی.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// د چاپ کیدو په اړه د بیک ټریس لپاره وړاندیز وړاندې کوي.
    ///
    /// دا په ځینو پلیټونو کې د بیکټریس لپاره اړین دی چې وروسته وروسته په بشپړ ډول سمبول شي ، او نه نو دا باید لومړی میتود وي چې تاسو د `BacktraceFmt` رامینځته کولو وروسته تلیفون کوئ.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// د بیک ټرېس محصول کې یو چوکاټ اضافه کوي.
    ///
    /// دا ژمنتیا د `BacktraceFrameFmt` یو RAII مثال بیرته راولي کوم چې واقعیا د یو چوکاټ چاپ کولو لپاره کارول کیدی شي ، او په ویجاړیدو به دا د چوکاټ کاونټر لوړ کړي.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// د بیک ټریس محصول بشپړوي.
    ///
    /// دا اوسمهال هیڅ انتخاب ندی مګر د بیک ټریک شکلونو سره د future مطابقت لپاره اضافه شوی.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // اوس مهال هیڅ انتخاب نشته-پدې کې د hook په شمول د future اضافو لپاره اجازه.
        Ok(())
    }
}

/// د بیکټریک یوازې یو چوکاټ لپاره فارمیټر.
///
/// دا ډول د `BacktraceFmt::frame` فنکشن لخوا رامینځته شوی.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// د دې چوکاټ فارمیټ سره `BacktraceFrame` چاپوي.
    ///
    /// دا به په `BacktraceFrame` کې د `BacktraceSymbol` بیلګې په پرله پسې ډول چاپ کړي.
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// په `BacktraceFrame` کې دننه `BacktraceSymbol` چاپوي.
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: دا عالي نده چې موږ د هیڅ شی په چاپولو پای نه کوو
            // د غیر utf8 فایل نومونو سره.
            // مننه چې تقریبا هرڅه utf8 دي نو دا باید ډیر بد هم نه وي.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// د `Frame` او `Symbol` خام ټریپونه چاپ کوي ، په ځانګړي ډول د دې crate خام کال بیک بیک کې.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// د بیک ټریس محصول کې خام چوکاټ اضافه کوي.
    ///
    /// دا میتود ، د تیرو برعکس ، خام دلیلونه په پام کې نیسي که چیرې دوی د مختلف ځایونو سرچینې وي.
    /// په یاد ولرئ چې دا ممکن د یو چوکاټ لپاره ډیری وختونه وبلل شي.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// د بیکټراس محصول کې خام چوکاټ اضافه کوي ، پشمول د کالم معلوماتو.
    ///
    /// دا طریقه ، لکه د تیر په څیر ، که چیرې دوی د مختلف ځایونو سرچینې وي نو خام دلیلونه اخلي.
    /// په یاد ولرئ چې دا ممکن د یو چوکاټ لپاره ډیری وختونه وبلل شي.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // فوسیا د پروسې دننه د سمبول توان نلري نو دا یو ځانګړی ب hasه لري کوم چې وروسته د سمبول لپاره کارول کیدی شي.
        // دلته زموږ په خپل ب inه د ادرسونو چاپ کولو پرځای چاپ کړئ.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // د "null" چوکاټونو چاپ کولو ته اړتیا نلري ، دا اساسا یوازې دا معنی لري چې د سیسټم بیک ټریس یو څه ډیر لیواله و ترڅو بیرته د سپر څخه تعقیب کړي.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // په Sgx انکلیو کې د TCB اندازه کمولو لپاره ، موږ نه غواړو د سمبولیک حل فعالیت پلي کړئ.
        // بلکه ، موږ کولی شو دلته د ادرس آفسیټ چاپ کړو ، کوم چې وروسته د درست کار کولو لپاره نقشه کیدلی شي.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // د چوکاټ شاخص او همدارنګه د چوکاټ اختیاري لارښود چاپ کړئ.
        // که موږ د دې چوکاټ لومړی سمبول څخه هاخوا یو که څه هم موږ یوازې مناسب سپینه ځای چاپ کړو.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // بیا د سمبول نوم ولیکئ ، د نورو معلوماتو لپاره د بدیل فارمیټ په کارولو سره که چیرې موږ بشپړ بیکټریس ولرو.
        // دلته موږ سمبولونه هم لرو چې نوم یې نه لري ،
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // او په پای کې ، د filename/line شمیره چاپ کړئ که دوی شتون ولري.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line د سمبول نوم لاندې لینونو کې چاپ شوي ، نو د ځان سم تنظیمولو لپاره ځینې مناسب سپین ځای چاپ کړئ.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // زموږ د داخلي کال بیک ته وټاکئ ترڅو د فایل نوم چاپ کړئ او بیا د کرښې شمیره چاپ کړئ.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // د کالم شمیره اضافه کړئ ، که شتون ولري.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // موږ یوازې د چوکاټ لومړی سمبول په اړه پاملرنه کوو
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}