use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// د مالکیت لرونکي او په ځان بسیا بیکټریک استازیتوب.
///
/// دا جوړښت کولی شي په برنامه کې په مختلفو نقطو کې د بیکټریک اخیستلو لپاره وکارول شي او وروسته د دې معاینه کولو لپاره وکارول شي چې په هغه وخت کې بیکټرایس څه و.
///
///
/// `Backtrace` د دې د `Debug` پلي کولو له لارې د بیکټریسونو په زړه پورې چاپ کولو ملاتړ کوي.
///
/// # اړین ب .ې
///
/// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // دلته چوکاټونه د ټیک له پورتنۍ څخه لاندې څخه لیست شوي دي
    frames: Vec<BacktraceFrame>,
    // هغه شاخص چې موږ یې باور لرو د بیک ټریس اصل پیل دی ، د `Backtrace::new` او `backtrace::trace` په څیر چوکاټونه.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// په بیکټراس کې د چوکاټ نیول شوی نسخه.
///
/// دا ډول د `Backtrace::frames` څخه د لیست په توګه بیرته راستنیدل کیږي او په نیول شوي بیکټراس کې د یو سټیک چوکاټ استازیتوب کوي.
///
/// # اړین ب .ې
///
/// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// په بیکټریک کې د سمبول نیول شوی نسخه.
///
/// دا ډول د `BacktraceFrame::symbols` څخه د لیست په توګه بیرته راستنیدل شوی او په بیکټریک کې د سمبول لپاره میټاډاټا استازیتوب کوي.
///
/// # اړین ب .ې
///
/// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// د دې فعالیت په زنګ وهلو کې بیکراټس نیول ، د ملکیت نمایندګۍ بیرته راګرځول.
    ///
    /// دا فنکشن په Rust کې د یوې مقالې په توګه د بیکټریک استازیتوب لپاره ګټور دی.دا بیرته راوړل شوی ارزښت د تارونو په اوږدو کې لیږل کیدی شي او په بل ځای کې هم چاپ کیدلی شي ، او د دې ارزښت هدف په بشپړ ډول ځان شاملول دي.
    ///
    /// په یاد ولرئ چې په ځینې پلیټ فارمونو کې د بشپړ بیکټریک ترلاسه کول او حل کول خورا ګران وي.
    /// که ستاسو د غوښتنلیک لپاره لګښت خورا ډیر وي نو د دې پرځای وړاندیز کیږي چې `Backtrace::new_unresolved()` وکاروئ کوم چې د سمبولیک حل مرحلې څخه مخنیوی کوي (کوم چې عموما ترټولو اوږده وخت نیسي) او دا وروسته نیټې ته ځنډوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // غواړئ ډاډ ترلاسه کړئ چې دلته د لرې کولو لپاره یو چوکاټ شتون لري
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// د `new` سره ورته پرته لدې چې دا هیڅ سمبولونه نه حل کوي ، دا په ساده ډول د پتې لیست په توګه backtrace راښکاره کوي.
    ///
    /// په وروسته وخت کې د `resolve` فعالیت کولی شي د دې بیک ټریس سمبولونه د لوستلو وړ نومونو کې حل کولو لپاره وبلل شي.
    /// دا دنده شتون لري ځکه چې د حل پروسه ځینې وختونه د پام وړ اندازه وخت نیسي پداسې حال کې چې هر یو بیکراټس شاید یوازې په ندرت سره چاپ شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // د سمبول نومونه نشته
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // د سمبول نومونه اوس شتون لري
    /// ```
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    ///
    #[inline(never)] // غواړئ ډاډ ترلاسه کړئ چې دلته د لرې کولو لپاره یو چوکاټ شتون لري
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// د دې چوکاټ نیول کیدو څخه چوکاټونه راستنوي.
    ///
    /// د دې سلیس لومړۍ ننوتنه احتمال د `Backtrace::new` فعالیت دی ، او وروستی چوکاټ احتمال یو څه په اړه دي چې دا تار یا اصلي فعالیت څنګه پیل شو.
    ///
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// که دا بیکټریس د `new_unresolved` څخه رامینځته شوی وي نو بیا دا فنکشن به په بټریک کې ټولې پتې د دوی سمبولیک نومونو ته حل کړي.
    ///
    ///
    /// که دا بیکټریس مخکې حل شوی وي یا د `new` له لارې رامینځته شوی و ، نو دا فن هیڅ نه کوي.
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// د `Frame::ip` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// د `Frame::symbol_address` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// د `Frame::module_base_address` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// د سمبولونو لیست بیرته راوړي چې دا چوکاټ ورته وي.
    ///
    /// عموما په هر چوکاټ کې یوازې یو سمبول شتون لري ، مګر کله ناکله یو شمیر افعال په یو چوکاټ کې دننه شي نو ګ multiple سمبولونه به بیرته راشي.
    /// لومړی لیست شوی علامت د "innermost function" دی ، پداسې حال کې چې وروستی سمبول یې ترټولو بهر (وروستی زنګ وهونکی) دی.
    ///
    /// په یاد ولرئ که چیرې دا چوکاټ د نه حل شوي بیکټریس څخه راغلی وي نو دا به خالي لیست بیرته راولي.
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// د `Symbol::name` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// د `Symbol::addr` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// د `Symbol::filename` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// د `Symbol::lineno` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// د `Symbol::colno` په څیر ورته
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // کله چې د لارې چاپ کول موږ هڅه کوو cwd راخلاص کړو که دا شتون ولري ، نو موږ یوازې لاره لکه څنګه چې چاپ کړه.
        // په یاد ولرئ چې موږ دا یوازې د لنډ فارمیټ لپاره کوو ، ځکه چې که دا بشپړ وي موږ غواړو چې هرڅه چاپ کړو.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}