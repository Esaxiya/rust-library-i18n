//! په crates.io کې د `gimli` crate کارولو سمبول لپاره ملاتړ
//!
//! دا د Rust لپاره د سمبول سمبول پلي کول دي.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'جامد ژوند د ځان-ریفرنډل سټریکونو لپاره د ملاتړ نشتوالي شاوخوا هیک کولو لپاره دروغ دی.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // د جامد ژوند وختونو ته بدل کړئ ځکه چې سمبولونه باید یوازې `map` او `stash` پور کړي او موږ یې لاندې خوندي کوو.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // په Windows کې د اصلي کتابتونونو بارولو لپاره ، دلته د مختلف ستراتیژیو لپاره په rust-lang/rust#71060 باندې یو څه بحث وګورئ.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // د MinGW کتابتونونه اوس مهال ASLR (rust-lang/rust#16514) ملاتړ نه کوي ، مګر DLLs لاهم د پته ځای کې شاوخوا ځای په ځای کیدی شي.
            // داسې ښکاري چې په ډیبګ معلوماتو کې ادرس ټول هغه ډول دي که چیرې دا کتابتون په خپل "image base" کې ډک شوی وي ، کوم چې د دې د COFF فایل سرۍ کې ساحه ده.
            // له دې چې دا هغه څه دي چې ډیبګینفو د لیست کولو لپاره داسې بریښي چې موږ د سمبول جدول او سټور پتې پارس کوو لکه څنګه چې کتابتون په "image base" کې هم ډک شوی و.
            //
            // په هرصورت ، کتابتون ممکن په "image base" کې پورته نشي.
            // (په احتمال سره ممکن یو څه نور دلته ولول شي؟) دا هغه ځای دی چې د `bias` ساحه پکې لوبیږي ، او موږ اړتیا لرو چې دلته د `bias` ارزښت وپیژنو.له بده مرغه که څه هم دا روښانه نده چې څنګه له دې څخه ډک شوي موډل څخه ترلاسه شي.
            // هغه څه چې موږ یې لرو ، په هرصورت ، د بار بار اصلي پته (`modBaseAddr`) دی.
            //
            // د اوس لپاره د کاپي آټ لږ څه په توګه موږ فایل ایم ایمپ کوو ، د فایل سرلیک معلومات لوستل ، بیا mmap ډراپ کړئ.دا ضایع دی ځکه چې موږ به شاید وروسته وروسته ایم ایم پی خلاص کړو ، مګر دا باید د اوس لپاره کافي کار وکړي.
            //
            // یوځل چې موږ د `image_base` (مطلوب بار بار موقعیت) او `base_addr` (د رښتیني بوډ موقعیت) لرو نو موږ کولی شو `bias` ډک کړو (د اصلي او مطلوب ترمینځ توپیر) او بیا د هرې برخې بیان شوې پته `image_base` ده ځکه چې فایل ورته څه وايي.
            //
            //
            // د اوس لپاره داسې ښکاري چې د ELF/MachO برعکس موږ کولی شو د هر کتابتون یوې برخې سره ترسره کړو ، د `modBaseSize` د بشپړ اندازې په توګه کارولو سره.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS د مچ-او فایل ب formatه کاروي او د اصلي کتابتونونو لیست ډکولو لپاره د DYLD-ځانګړي APIs کاروي چې د غوښتنلیک برخې دي.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // د دې کتابتون نوم واخلئ کوم چې د دې د لارو سره ورته دی چیرې چې د دې بارول هم پکې وي.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // د دې کتابتون د عکس سرۍ پورته کړئ او د `object` ته استازي ورکړئ ترڅو د ټولو بارونو امرونه تجزیه کړئ نو موږ کولی شو دلته ښکیل ټولې برخې وپیژنو.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // برخو باندې تفتیش وکړئ او د برخو لپاره مو پیژندل شوي سیمې راجسټر کړئ چې موږ یې ګورو.
            // سربیره پردې د پروسس کولو لپاره د ټیکټ برخې برخې برخې معلومات ثبت کړئ ، لاندې نظرونه وګورئ.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // د دې کتابتون لپاره "slide" وټاکئ کوم چې د تعصب په توګه پای ته رسیږي چې موږ یې معلومولو لپاره وکاروو چیرې چې په حافظه کې توکي بار شوي.
            // که څه هم دا یو څه عجیب حساب دی که څه هم او په ځنګل کې د یو څو شیانو هڅه کولو پایله او څه لیدل دي.
            //
            // عمومي نظر دا دی چې د `bias` پلس د برخې `stated_virtual_memory_address` چیرته ځي چیرته چې د اصلي پته ځای کې سیګام ژوند کوي.
            // بله شی چې موږ یې په تکیه کوو هغه دا دی چې د ریښتیني پته مائنس `bias` شاخص دی چې د سمبول جدول او ډیبګینفو کې وګورئ.
            //
            // دا په ګوته کوي ، که څه هم ، د سیسټم څخه ډکې کتابتونونو لپاره دا محاسبې غلط دي.د اصلي اعدامونو لپاره ، په هرصورت ، دا سم ښکاري.
            // د LLDB سرچینې څخه ځینې منطق ایستل دا د لومړي `__TEXT` برخې لپاره یو څه ځانګړي قضیه لري د فایل آفسیټ 0 څخه د نیزروز اندازه سره لوډ شوی.
            // د هر دلیل لپاره چې کله دا شتون ولري نو داسې ښکاري چې د سمبول میز د کتابتون لپاره یوازې د vmaddr سلایډ سره تړاو لري.
            // که دا *شتون ونلري* نو د سمبول جدول د vmaddr سلایډ سره د برخې برخې برخې سره سم دی.
            //
            // د دې وضعیت اداره کولو لپاره که چیرې موږ د فایل صفی آفسیټ کې د متن برخې ونه مومو نو بیا موږ د لومړي متن برخې لخوا ویل شوي پته په تعصب کې زیاتوالی راولی او په هماغه اندازه موږ ټولې پته راکمه کوو.
            //
            // په دې توګه د سمبول میز تل د کتابتون د تعصب مقدار سره سم ښکاري.
            // داسې ښکاري چې د سمبول میز له لارې د سمبول لپاره سمې پایلې شتون لري.
            //
            // په ریښتیا زه په بشپړ ډول ډاډه نه یم چې ایا دا سم دی یا که کوم بل څه شتون ولري چې باید د دې ترسره کولو څرنګوالی په ګوته کړي.
            // د اوس لپاره که څه هم داسې ښکاري چې کافي اندازه (?) کار کوي او موږ باید تل د دې توان ولرو چې د وخت په تیریدلو دا اړین وي که اړین وي.
            //
            // د نورو معلوماتو لپاره #318 وګورئ
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // نور Unix (د مثال په توګه
        // لینکس) پلیټ فارمونه د ELF د توکي فایل فارمیټ په توګه کاروي او په عموم ډول د اصلي کتابتونونو بارولو لپاره د `dl_iterate_phdr` په نوم یو API پلي کوي.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` باید باوري اشاره وي.
        // `vec` باید `std::Vec` ته یو درست ټکي وي.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 په اصلي ډول د ډیبګ معلوماتو ملاتړ نه کوي ، مګر د جوړولو سیسټم به د ډیبګ معلومات په `romfs:/debug_info.elf` لاره کې ځای په ځای کړي.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // هرڅه باید ELF وکاروي ، مګر نه پوهیږي چې اصلي کتابتونونه څنګه لوډ شي.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// ټول پیژندل شوي شریک شوي کتابتونونه چې بار شوي دي.
    libraries: Vec<Library>,

    /// نخشه کیشې چرته چې مونږ د پارس شوې بونډې معلومات ساتو.
    ///
    /// دا لیست د دې د ټول عمر لپاره ټاکلې ظرفیت لري کوم چې هیڅکله نه ډیریږي.
    /// د هر جوړه د `usize` عنصر پورته `libraries` کې شاخص دی چیرې چې `usize::max_value()` د اوسني اجرااتو وړ نمایندګي کوي.
    ///
    /// `Mapping` د پارس شوي بورن معلوماتو سره مطابقت لري.
    ///
    /// په یاد ولرئ چې دا اساسا د LRU کیچ دی او موږ به دلته شاوخوا شیان واړوو ځکه چې موږ ادرس سمبول کوو.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// د دې کتابتون برخې په حافظه کې ډکې شوې ، او چیرې چې دوی بار شوي.
    segments: Vec<LibrarySegment>,
    /// د دې کتابتون "bias" ، په ځانګړي ډول چیرې چې دا په حافظه کې ډک شوی دی.
    /// دا ارزښت د هرې برخې په بیان شوي پتې کې اضافه کیږي ترڅو د ریښتیني مجازی حافظې پته ترلاسه کړئ چې برخه یې ډکه شوې ده.
    /// سربیره پردې دا تعصب د ریښتیني مجازی حافظې پتې څخه په ډیبګینفو او سمبول میز کې شاخص ته غورځول کیږي.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// د څیز برخې کې د دې برخې بیان شوی پته.
    /// دا واقعیا نه ده چیرې چیرې برخې برخې ډکې دي ، بلکه دا پته جمع د کتابتون `bias` لرونکی چیرې دی چیرې چې دا ومومئ.
    ///
    stated_virtual_memory_address: usize,
    /// په حافظه کې د ths برخې کچه.
    len: usize,
}

// غیر محفوظ ځکه چې دا باید بهرنی همغږه شي
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // غیر محفوظ ځکه چې دا باید بهرنی همغږه شي
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // د ډیبګ معلوماتو نقشه کولو لپاره خورا کوچنی ، خورا ساده LRU کیچ.
        //
        // د ضربې کچه باید خورا لوړه وي ، ځکه چې عادي کڅوړه د ډیری شریک شوي کتابتونونو ترمینځ نه تیریږي.
        //
        // د `addr2line::Context` جوړښتونه رامینځته کول خورا ګران دي.
        // د دې لګښت تمه کیږي چې د وروسته `locate` پوښتنو لخوا امور شي ، کوم چې د جوړ شوي جوړښتونو ګټه پورته کوي کله چې د `addr2line: : ساختمانونه جوړول ګټور وي ترڅو ښه سرعت ترلاسه کړي.
        //
        // که چیرې موږ دا زیرمه نه درلوده ، نو دا امتیاز به هیڅکله پیښ نه شي ، او د شاخونو سمبول به ssssllllooooowwww وي.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // لومړی ، ازموینه وکړئ که چیرې دا `lib` کومه برخه لري چې د `addr` لري (د ځای په ځای کولو اداره کول).که دا چک تیریږي نو بیا موږ لاندې دوام کولی شو او په حقیقت کې پته وژباړو.
                //
                // په یاد ولرئ چې موږ دلته د `wrapping_add` کاروو ترڅو د جریان چیکونو مخه ونیسو.دا په ځنګل کې لیدل شوی چې د SVMA + تعصب کمپیوټري ډیریږي.
                // دا یو څه عجیب ښکاري چې پیښ شي مګر دومره لوی مقدار شتون نلري چې موږ یې په اړه یې ترسره کولی شو نور یې شاید شاید یوازې دې برخې ته پام وکړئ ځکه چې دوی احتمال لري خلا ته اشاره وکړي.
                //
                // دا په اصل کې په rust-lang/backtrace-rs#329 کې راپورته شو.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // اوس چې موږ پوهیږو `lib` په `addr` لري ، موږ کولی شو د تعصب سره وصولی شو ترڅو بیان شوي ویروټیل حافظې پته ومومئ.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // ناڅاپي: وروسته له دې چې دا شرایط د ژر بیرته راستنیدو پرته بشپړ شي
        // د غلطۍ څخه ، د دې لارې لپاره د کیچ ننوت په شاخص 0 کې دی.

        if let Some(idx) = idx {
            // کله چې نقشه کول دمخه په زیرمه کې وي ، مخ ته یې واچوئ.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // کله چې نقشه په زیرمه کې نده ، نو نقشه جوړه کړئ ، د کیچ مخ ته یې دننه کړئ ، او د اړتیا په صورت کې د زاړه زاړه داخله ایسته کړئ.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // د `'static` ژوندون مه لیکئ ، ډاډ ترلاسه کړئ چې دا پخپله پخپله سکوپ شوی
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // د `sym` ژوند موده `'static` ته وغزوئ ځکه چې موږ دلته بدبختانه اړین یو ، مګر دا دقیقا کله هم د حوالې په توګه بهر ځي نو پدې اړه هیڅ حواله باید په هر حالت کې د دې چوکاټ څخه بهر پاتې نشي.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // په نهایت کې ، د دې دوتنې لپاره زیرمه شوې نقشه ترلاسه کړئ یا د دې نقشې لپاره نوې نقشه جوړه کړئ ، او د DWARF معلومات ارزونه وکړئ ترڅو د دې پتې لپاره file/line/name ومومئ.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// موږ د دې سمبول لپاره د چوکاټ معلومات موندلو توان درلود ، او د `addr2line` چوکاټ په داخلي توګه د ټولو د زړه نازک توضیحات لري.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// د ډیبګ معلومات ونه موندل شو ، مګر موږ دا د اجرا کولو وړ د ایلف سمبول جدول کې وموند.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}