//! د `dbghelp.dll` په Windows کې د سمبولیک تګلارې کارول ، یوازې د MSVC لپاره کارول شوی
//!
//! دا سمبولیکه ستراتیژي ، لکه د بیکټریس په څیر ، له `dbghelp.dll` څخه په متحرک ډول بار شوي معلومات کاروي.
//! (د دې لپاره چې دا په متحرک ډول ډک شوی وي د معلوماتو لپاره `src/dbghelp.rs` وګورئ).
//!
//! دا API د چمتو شوي چوکاټ یا هغه معلوماتو پراساس چې موږ په لاس کې لرو د حلولو ستراتیژي غوره کوي.
//! که چیرې د `StackWalkEx` څخه یو چوکاټ موږ ته راکړل شي نو بیا موږ د ورته افهاماتو کارول د انلاین افعالاتو په اړه د سم معلوماتو چمتو کولو لپاره.
//! که نه نو موږ ټول د پته یا د `StackWalk64` څخه زاړه سټیک چوکاټ لرو موږ د سمبول لپاره زاړه APIs کاروو.
//!
//! پدې ماډل کې د ملاتړ ښه معاملې شتون لري ، مګر د دې ښه برخه د Windows ډولونو او Rust ډولونو ترمینځ شا او خوا بدلیږي.
//!
//! د مثال په توګه سمبولونه موږ ته د پراخو تارونو په توګه راځي چې موږ بیا د utf-8 تارونو ته واړوو که موږ یې کولی شو.
//!
//!
//!
//!

#![allow(bad_style)]

use super::super::{backtrace::StackFrame, dbghelp, windows::*};
use super::{BytesOrWideString, ResolveWhat, SymbolName};
use core::char;
use core::ffi::c_void;
use core::marker;
use core::mem;
use core::slice;

// په std کې د اوسټرینګ ذخیره کړئ نو موږ کولی شو د سمبول نوم او فایل نوم چمتو کړو.
pub struct Symbol<'a> {
    name: *const [u8],
    addr: *mut c_void,
    line: Option<u32>,
    filename: Option<*const [u16]>,
    #[cfg(feature = "std")]
    _filename_cache: Option<::std::ffi::OsString>,
    #[cfg(not(feature = "std"))]
    _filename_cache: (),
    _marker: marker::PhantomData<&'a i32>,
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        Some(SymbolName::new(unsafe { &*self.name }))
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        Some(self.addr as *mut _)
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename
            .map(|slice| unsafe { BytesOrWideString::Wide(&*slice) })
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }

    pub fn lineno(&self) -> Option<u32> {
        self.line
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        self._filename_cache.as_ref().map(Path::new)
    }
}

#[repr(C, align(8))]
struct Aligned8<T>(T);

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    // ډاډ ترلاسه کړئ چې د دې پروسې سمبولونه پیل شوي
    let dbghelp = match dbghelp::init() {
        Ok(dbghelp) => dbghelp,
        Err(()) => return, // اوو ښه ده...
    };

    match what {
        ResolveWhat::Address(_) => resolve_without_inline(&dbghelp, what.address_or_ip(), cb),
        ResolveWhat::Frame(frame) => match &frame.inner.stack_frame {
            StackFrame::New(frame) => resolve_with_inline(&dbghelp, frame, cb),
            StackFrame::Old(_) => resolve_without_inline(&dbghelp, frame.ip(), cb),
        },
    }
}

unsafe fn resolve_with_inline(
    dbghelp: &dbghelp::Init,
    frame: &STACKFRAME_EX,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    do_resolve(
        |info| {
            dbghelp.SymFromInlineContextW()(
                GetCurrentProcess(),
                super::adjust_ip(frame.AddrPC.Offset as *mut _) as u64,
                frame.InlineFrameContext,
                &mut 0,
                info,
            )
        },
        |line| {
            dbghelp.SymGetLineFromInlineContextW()(
                GetCurrentProcess(),
                super::adjust_ip(frame.AddrPC.Offset as *mut _) as u64,
                frame.InlineFrameContext,
                0,
                &mut 0,
                line,
            )
        },
        cb,
    )
}

unsafe fn resolve_without_inline(
    dbghelp: &dbghelp::Init,
    addr: *mut c_void,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    do_resolve(
        |info| dbghelp.SymFromAddrW()(GetCurrentProcess(), addr as DWORD64, &mut 0, info),
        |line| dbghelp.SymGetLineFromAddrW64()(GetCurrentProcess(), addr as DWORD64, &mut 0, line),
        cb,
    )
}

unsafe fn do_resolve(
    sym_from_addr: impl FnOnce(*mut SYMBOL_INFOW) -> BOOL,
    get_line_from_addr: impl FnOnce(&mut IMAGEHLP_LINEW64) -> BOOL,
    cb: &mut dyn FnMut(&super::Symbol),
) {
    const SIZE: usize = 2 * MAX_SYM_NAME + mem::size_of::<SYMBOL_INFOW>();
    let mut data = Aligned8([0u8; SIZE]);
    let data = &mut data.0;
    let info = &mut *(data.as_mut_ptr() as *mut SYMBOL_INFOW);
    info.MaxNameLen = MAX_SYM_NAME as ULONG;
    // د جوړښت اندازه په سي.
    // ارزښت د `size_of::<SYMBOL_INFOW>() - MAX_SYM_NAME + 1` سره توپیر لري (==81) د جوړښت د ورته والي له امله.
    //
    info.SizeOfStruct = 88;

    if sym_from_addr(info) != TRUE {
        return;
    }

    // که د سمبول نوم د میکسم نومین څخه لوی وي ، SymFromAddrW به د (ماکسنامیلین ، 1) تورو بفر ورکړي او نوملین به ریښتیني ارزښت ته وټاکي.
    //
    //
    let name_len = ::core::cmp::min(info.NameLen as usize, info.MaxNameLen as usize - 1);
    let name_ptr = info.Name.as_ptr() as *const u16;
    let name = slice::from_raw_parts(name_ptr, name_len);

    // د utf-16 سمبول utf-8 ته بیا کوډ کړئ نو موږ کولی شو د نورو نورو پلیټونو په څیر `SymbolName::new` وکاروو
    //
    let mut name_len = 0;
    let mut name_buffer = [0; 256];
    {
        let mut remaining = &mut name_buffer[..];
        for c in char::decode_utf16(name.iter().cloned()) {
            let c = c.unwrap_or(char::REPLACEMENT_CHARACTER);
            let len = c.len_utf8();
            if len < remaining.len() {
                c.encode_utf8(remaining);
                let tmp = remaining;
                remaining = &mut tmp[len..];
                name_len += len;
            } else {
                break;
            }
        }
    }
    let name = &name_buffer[..name_len] as *const [u8];

    let mut line = mem::zeroed::<IMAGEHLP_LINEW64>();
    line.SizeOfStruct = mem::size_of::<IMAGEHLP_LINEW64>() as DWORD;

    let mut filename = None;
    let mut lineno = None;
    if get_line_from_addr(&mut line) == TRUE {
        lineno = Some(line.LineNumber as u32);

        let base = line.FileName;
        let mut len = 0;
        while *base.offset(len) != 0 {
            len += 1;
        }

        let len = len as usize;

        filename = Some(slice::from_raw_parts(base, len) as *const [u16]);
    }

    cb(&super::Symbol {
        inner: Symbol {
            name,
            addr: info.Address as *mut _,
            line: lineno,
            filename,
            _filename_cache: cache(filename),
            _marker: marker::PhantomData,
        },
    })
}

#[cfg(feature = "std")]
unsafe fn cache(filename: Option<*const [u16]>) -> Option<::std::ffi::OsString> {
    use std::os::windows::ffi::OsStringExt;
    filename.map(|f| ::std::ffi::OsString::from_wide(&*f))
}

#[cfg(not(feature = "std"))]
unsafe fn cache(_filename: Option<*const [u16]>) {}

pub unsafe fn clear_symbol_cache() {}