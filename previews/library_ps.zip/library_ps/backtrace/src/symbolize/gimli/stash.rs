// یوازې همدا اوس په Linux کې کارول شوی ، نو د بل ځای مړه کوډ ته اجازه ورکړئ
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// د بایټ بفرونو لپاره یو ساده ډګر تخصیص کونکی.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// د ټاکل شوي اندازې بفر تخصیص کوي او دې ته د تغیر وړ حواله ورکوي.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // امنیت: دا یوازینۍ دنده ده چې هرکله یو بدلون رامینځته کوي
        // `self.buffers` ته مراجعه.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // خوندي: موږ هیڅکله له `self.buffers` څخه عنصرونه نه لرې کوو ، نو ځکه یې حواله
        // هر بفر کې دننه ډاټا ته به تر هغه وخته ژوند وکړي چې `self` یې کوي.
        &mut buffers[i]
    }
}