use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// سیمالټ ته پته حل کړئ ، ټاکل شوي بند ته د سمبول لیږدول.
///
/// دا فنکشن به ورکړل شوي پته په ساحو کې وګوري لکه د ځایی سمبول میز ، متحرک سمبول میز ، یا DWARF ډیبګ معلومات (د فعال پلي کیدو پورې اړه لري) ترڅو د حاصل ورکولو لپاره سمبول ومومي.
///
///
/// بند ممکن ونه بلل شي که چیرې پریکړه ترسره نه شي ، او دا به د په زړه پورې دندو په صورت کې له یو ځل څخه هم وبلل شي.
///
/// ترلاسه شوي سمبولونه په ټاکل شوي `addr` کې د اعدام نمایندګي کوي ، د دې پتې لپاره file/line جوړې بیرته راوړي (که شتون ولري).
///
/// په یاد ولرئ چې که تاسو `Frame` لرئ نو بیا سپارښتنه کیږي چې د دې پرځای د `resolve_frame` فعالیت وکاروئ.
///
/// # اړین ب .ې
///
/// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
///
/// # Panics
///
/// دا فعالیت هیڅکله panic ته هڅه نه کوي ، مګر که `cb` panics چمتو کړي نو بیا ځینې پلیټ فارمونه به دوه ځله panic د پروسې مخنیوي ته اړ کړي.
/// ځینې پلیټ فارمونه د سي کتابتون کاروي کوم چې په داخلي توګه کال بیکونه کاروي کوم چې له دې لارې ضایع کیدلی نشي ، نو د `cb` څخه ویستل ممکن د پروسې اختطاف لامل شي.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // یوازې پورته چوکاټ وګورئ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// سیمال ته د تیر نیول شوي چوکاټ حل کړئ ، نښه ته ټاکل شوي بند ته انتقال کول.
///
/// دا فنټین د `resolve` په څیر ورته فعالیت ترسره کوي پرته لدې چې دا د پتې پرځای د دلیل په توګه `Frame` اخلي.
/// دا کولی شي د بیکټریک کولو ځینې پلیټ فارم پلي کولو ته اجازه ورکړي چې د مثال په توګه د انلاین چوکاټونو په اړه دقیق سمبول معلومات یا معلومات چمتو کړي.
///
/// سپارښتنه کیږي چې دا وکاروي که تاسو یې کولی شئ.
///
/// # اړین ب .ې
///
/// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
///
/// # Panics
///
/// دا فعالیت هیڅکله panic ته هڅه نه کوي ، مګر که `cb` panics چمتو کړي نو بیا ځینې پلیټ فارمونه به دوه ځله panic د پروسې مخنیوي ته اړ کړي.
/// ځینې پلیټ فارمونه د سي کتابتون کاروي کوم چې په داخلي توګه کال بیکونه کاروي کوم چې له دې لارې ضایع کیدلی نشي ، نو د `cb` څخه ویستل ممکن د پروسې اختطاف لامل شي.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // یوازې پورته چوکاټ وګورئ
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// د سټا چوکاټونو څخه IP ارزښتونه په عموم ډول د (always?) لارښوونې دي *وروسته* د زنګ څخه چې دا د اصلي اسٹیک ټریس دی.
// پدې باندې سمبول د دې لامل کیږي چې د filename/line شمیره یو دمخه وي او شاید باطل کې که چیرې دا د فنکشن پای ته نږدې وي.
//
// دا په اساسا ډول تل په ټولو پلیټ فارمونو کې قضیه ښکاري ، نو موږ تل د حل شوي IP څخه یو له هغه ځایه لرې کوو چې دا د لارښوونې بیرته راستنیدو پرځای پخوانۍ اړیکې لارښوونې ته حل کړئ.
//
//
// په مثبته توګه موږ دا نه کوو.
// په مثبته توګه موږ به دلته د `resolve` APIs تلیفونونو ته اړتیا ولرو ترڅو په لاسي ډول د -1 ترسره کړئ او حساب ورکړئ چې دوی د *تیر* لارښوونې لپاره د ځای معلومات غواړي ، نه اوسني.
// په مثالي توګه موږ په `Frame` باندې هم توضیح کوو که چیرې موږ واقعیا د راتلونکي لارښود یا اوسني پته ولرو.
//
// د اوس لپاره که څه هم دا یو په زړه پورې اندیښنه ده نو موږ یوازې په داخلي توګه تل یو کم کوو.
// مصرف کونکي باید کار ته دوام ورکړي او خورا ښې پایلې ترلاسه کړي ، نو موږ باید کافي واوسو.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// د `resolve` په څیر ، یوازې غیر محفوظ دی ځکه چې دا غیر منظم دی.
///
/// دا فنکشن د همغږۍ تضمین نلري مګر شتون لري کله چې د دې crate `std` ب featureه نده جوړه شوې.
/// د نورو سندونو او مثالونو لپاره د `resolve` فعالیت وګورئ.
///
/// # Panics
///
/// په `cb` ویشتلو کې د انتحار لپاره د `resolve` په اړه معلومات وګورئ.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// د `resolve_frame` په څیر ، یوازې غیر محفوظ دی ځکه چې دا غیر منظم دی.
///
/// دا فنکشن د همغږۍ تضمین نلري مګر شتون لري کله چې د دې crate `std` ب featureه نده جوړه شوې.
/// د نورو سندونو او مثالونو لپاره د `resolve_frame` فعالیت وګورئ.
///
/// # Panics
///
/// په `cb` ویشتلو کې د انتحار لپاره د `resolve_frame` په اړه معلومات وګورئ.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// یو trait په دوتنه کې د سمبول د حل نمایندګي کوي.
///
/// دا trait د `backtrace::resolve` فعالیت ته ورکړل شوي بند ته د trait څیز په توګه ترلاسه شوی ، او دا په حقیقت کې لیږدول شوی ځکه چې دا نامعلوم دی کوم پلي کول یې تر شا دي.
///
///
/// سیمالټ کولی شي د فعالیت په اړه متناسب معلومات ورکړي ، د بیلګې په توګه نوم ، د فایل نوم ، د کرښې شمیره ، دقیق پته ، او داسې نور.
/// ټول معلومات تل په سمبول کې شتون نلري ، په هرصورت ، نو ټولې میتودونه `Option` بیرته راولي.
///
///
pub struct Symbol {
    // TODO: د دې ټول عمر محدودیت باید په پای کې `Symbol` ته دوام ورکړي ،
    // مګر دا اوس یو ماتونکی بدلون دی.
    // د اوس لپاره دا خوندي دی ځکه چې `Symbol` یوازې کله هم د حوالې لخوا سپارل شوی او کلون نشي کیدلی.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// د دې فنکشن نوم راګرځوي.
    ///
    /// بیرته راګرځیدلی جوړښت د سمبول نوم په اړه مختلف ملکیتونو پوښتنو لپاره کارول کیدی شي:
    ///
    ///
    /// * د `Display` پلي کول به demangled سمبول چاپ کړي.
    /// * د سیمال خام `str` ارزښت لاسرسی کیدی شي (که دا معتبر utf-8 وي).
    /// * د سیمال نوم لپاره خام بایټس لاسرسی کیدی شي.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// د دې فنکشن پیل پته راستنوي.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// خام فایل نوم د سلیس په توګه راستنوي.
    /// دا اساسا د `no_std` چاپیریال لپاره ګټور دی.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// د کالم شمېره بیرته راګرځوي چیرې چې دا سمبول اوس مهال اجرا کیږي.
    ///
    /// یوازې جملی اوس مهال دلته ارزښت چمتو کوي او حتی بیا یوازې که `filename` `Some` بیرته راستنوي ، او نو دا بیا په پایله کې ورته ورته انتشاراتو سره مخ کیږي.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// د دې لپاره چې دا سمبول اوس مهال اجرا کیږي د کرښې شمیره راولي.
    ///
    /// د راستنیدنې ارزښت معمولا `Some` دی که `filename` `Some` بیرته راولي ، او په پایله کې ورته ورته انتشاراتو سره مخ کیږي.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// د فایل نوم راستنوي چیرې چې دا فنکشن ټاکل شوی و.
    ///
    /// دا اوس مهال یوازې شتون لري کله چې لیبریکټریس یا جملي کارول کیږي (د مثال په توګه
    /// unix پلیټ فارم نور) او کله چې یو بائنری د ډیبګینفو سره ترکیب شوی وي.
    /// که نه د دې شرایطو څخه هیڅ نه پوره کیږي نو بیا به احتمال یې `None` بیرته راشي.
    ///
    /// # اړین ب .ې
    ///
    /// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // ممکن د پارس شوي C++ سمبول ، که د Rust په توګه د منګلي شوي سمبول پارس کول ناکام شوي.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ډاډ ترلاسه کړئ چې دا صفر اندازه وساتئ ، نو د `cpp_demangle` ب featureه هیڅ لګښت نلري کله چې معلول شي.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// د سمبول نوم شاوخوا ریمار کول ترڅو ډیمینج شوي نوم ته ارګونومیک لاسرسی چمتو کړي ، خام بایټس ، خام تار او نور.
///
// د مړه کوډ ته اجازه ورکړئ کله چې د `cpp_demangle` ب featureه فعاله نه وي.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// د خامو زیرمو بایټونو څخه د نوي سمبول نوم رامینځته کوي.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// د (mangled) خامو نوم د `str` په توګه بیرته راولي که چیرې سمبول د utf-8 معتبر وي.
    ///
    /// د `Display` تطبیق وکاروئ که تاسو ډیمینډ شوی نسخه غواړئ.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// د بایټونو لیست په توګه د خامو سمبول نوم راستنوي
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // دا ممکن د چاپ لپاره که چیرې بې منل شوي سمبول په حقیقت کې معتبر نه وي ، نو دلته غلطي په ګرانۍ سره اداره کړئ د دې نه بهر تکثیر کولو سره.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// د بیرته ترلاسه کولو هڅه چې ساتل شوی حافظه د پتې سمبول لپاره کاروي.
///
/// دا میتود به هڅه وکړي د نړۍ هرډول ډیټا جوړښتونه خوشې کړي چې په بل ډول د نړۍ په کچه یا په تار کې ساتل شوي وي چې په عمومي ډول د پارس ډورف معلومات یا ورته ورته نمایش کوي.
///
///
/// # Caveats
///
/// پداسې حال کې چې دا دنده تل شتون لري دا واقعیا د ډیری تطبیقاتو په اړه هیڅ نه کوي.
/// لائبریري لکه dbghelp یا libbacktrace د دولت ضایع کیدو او تخصیص شوي حافظې اداره کولو لپاره اسانتیاوې نه چمتو کوي.
/// د اوس لپاره د دې crate `gimli-symbolize` ب featureه یوازینی ب featureه ده چیرې چې دا فعالیت کوم تاثیر لري.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}