//! په libbacktrace کې د DWARF-parsing کوډ کارولو سمبولیک تګلاره.
//!
//! د لیب بیکټرایس سی کتابتون ، په عمومي ډول د gcc سره توزیع شوی ، نه یوازې د بیکټریک رامینځته کولو ملاتړ کوي (کوم چې موږ واقعیا نه کاروو) بلکه د بیکټریک سمبول او د څرخیدونکي چوکاټونو او واټ نوټ په اړه د شیانو ډیبګ معلوماتو اداره کول هم شامل دي.
//!
//!
//! دا دلته د ډیری مختلف اندیښنو له امله نسبتا پیچلی دی ، مګر اساسی نظر دا دی:
//!
//! * لومړی موږ `backtrace_syminfo` ووایو.دا د متحرک سمبول میز څخه د سمبول معلومات ترلاسه کوي که چیرې موږ وکولی شو.
//! * بل موږ `backtrace_pcinfo` زنګ ووهلو.دا به د ډبینګفو جدولونه تجزیه کړي که چیرې شتون ولري او موږ ته اجازه راکړئ چې د انلاین چوکاټونو ، فایل نومونو ، کرښې شمیرو ، او نورو په اړه معلومات ترلاسه کړو.
//!
//! په لیبب ټریټیس کې د بورن میزونو ترلاسه کولو په اړه ډیری چال چلن شتون لري ، مګر امید لري چې دا د نړۍ پای نه وي او کافي روښانه وي کله چې لاندې لوستل کیږي.
//!
//! دا د غیر MSVC او غیر OSX پلیټونو لپاره د سمبول سمبول ستراتیژي ده.په لیبسټډ کې که څه هم دا د OSX لپاره اصلي تګلاره ده.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // که امکان ولري د `function` نوم غوره کړئ کوم چې د ډبګینفو څخه راځي او عموما د مثال په توګه د انلاین چوکاټونو لپاره ډیر دقیق کیدی شي.
                // که دا شتون نلري پداسې حال کې چې بیرته د `symname` کې ټاکل شوي سمبول میز میز ته وګرځئ.
                //
                // په یاد ولرئ چې ځینې وختونه `function` کولی شي یو څه لږ دقیق احساس احساس کړي ، د بیلګې په توګه د `std::panicking::try::do_call` `try<i32,closure>` اسسټینډ لست شوي.
                //
                // دا واقعیا روښانه نده چې ولې ، مګر په ټوله کې د `function` نوم ډیر دقیق ښکاري.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // د اوس لپاره هیڅ مه کوه
}

/// د `data` نښې ډول په `syminfo_cb` کې تېر شو
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // یوځل چې دا کال بیک د `backtrace_syminfo` څخه وغوښتل شي کله چې موږ حل پیل کړو موږ نور د `backtrace_pcinfo` تلیفون کولو ته لاړ شو.
    // د `backtrace_pcinfo` فنکشن به د ډیبګ معلوماتو سره مشوره وکړي او د داسې کارونو ترسره کولو هڅه وکړي لکه د file/line معلوماتو ب recoverه کول لکه دننه لیکل شوي چوکاټونه.
    // که څه هم یادونه وکړئ چې `backtrace_pcinfo` کولی شي ناکام شي یا ډیر څه ونه کړي که چیرې د ډیبګ معلومات شتون نلري ، نو که دا پیښ شي نو موږ به د `syminfo_cb` څخه لږترلږه یو سمبول سره زنګ ووهلو.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// د `data` نښې ډول په `pcinfo_cb` کې تېر شو
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// libbacktrace API د دولت رامینځته کولو ملاتړ کوي ، مګر دا د دولت ویجاړولو ملاتړ نه کوي.
// زه شخصا دا د دې معنی اخلي چې یو دولت د رامینځته کیدو معنی لري او بیا د تل لپاره ژوند کوي.
//
// زه غواړم د at_exit() هینڈلر ثبت کړم کوم چې دا حالت پاکوي ، مګر لیبریکټریس د دې کولو لپاره هیڅ لاره نه وړاندې کوي.
//
// د دې خنډونو سره ، دا فعالیت په ثابت ډول ساتل شوی حالت لري چې د لومړي ځل لپاره غوښتنه کیږي غوښتنه کیږي.
//
// په یاد ولرئ چې د بیکټریک کول ټول په سریال ډول پیښیږي (یو نړیوال تالا).
//
// په یاد ولرئ چې دلته د همغږۍ نشتوالی د دې اړتیا له امله دی چې `resolve` په بهر کې همغږي کیږي.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // د لیبب ټریټیس تندرصاف وړتیاوې مه کاروئ ځکه چې موږ تل دا په ترکیب ب fashionه غږوو.
        //
        0,
        error_cb,
        ptr::null_mut(), // اضافي معلومات نشته
    );

    return STATE;

    // په یاد ولرئ چې د لیبریکټریس لپاره په هرڅه کار کول دا د اوسني اجرا کونکي لپاره د DWARF ډیبګ معلوماتو موندلو ته اړتیا لري.دا عموما دا د یو شمیر میکانیزمونو له لارې کوي په شمول ، مګر محدود ندي:
    //
    // * /proc/self/exe په ملاتړ شوي پلیټ فارمونو کې
    // * د دوتنې نوم په څرګند ډول تېر شو کله چې دولت جوړول
    //
    // د لیبب ټریټس کتابتون د C کوډ لوی واډ دی.دا طبیعي معنی لري چې دا د حافظې خوندیتوب زیانونه لري ، په ځانګړي توګه کله چې د خرابې شوې ډیبینفونو اداره کول.
    // لیبرسټ ډی د دې تاریخي پلوه خورا ډیر کړی.
    //
    // که /proc/self/exe کارول شوی وي نو بیا موږ عموما دا له پامه غورځولی شو ځکه چې فرض کوو لیوبریکټریس د "mostly correct" دی او که نه نو د "attempted to be correct" بورن ډیبګ معلوماتو سره عجیب شیان نه ترسره کوي.
    //
    //
    // که موږ په فایل نوم کې تېر کړو ، په هرصورت ، نو بیا دا په ځینې پلیټ فارمونو (لکه BSDs) کې امکان لري چیرې چې بدکار لوبغاړی کولی شي په هغه ځای کې د خپلسري فایل ځای پرځای کولو لامل شي.
    // د دې معنی دا ده چې که موږ د فایل نوم په اړه لیبریکټریس ووایو دا ممکن یو ارقام فایل وکاروي ، ممکن د سیګفالټ لامل شي.
    // که چیرې موږ لیببریک ټریس ته څه ونه ووایو نو بیا به دا په پلیټ فارمونو کې هیڅ ونه کړي چې د /proc/self/exe په څیر لارې ملاتړ نه کوي!
    //
    // هغه څه ورکړل شوي چې موږ یې د امکان تر حده هڅه کوو چې د فایل نوم کې * تېر نشو ، مګر موږ باید په پلیټ فارمونو کې چې په بشپړ ډول د /proc/self/exe ملاتړ نه کوو.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // په یاد ولرئ چې په مثالي توګه موږ د `std::env::current_exe` کاروو ، مګر موږ دلته د `std` اړتیا نه لرو.
            //
            // په مستحکم سیمه کې د اوسني اجرایوي لاره پورته کولو لپاره `_NSGetExecutablePath` وکاروئ (کوم چې که دا خورا کوچنی وي یوازې پریږدئ).
            //
            //
            // په یاد ولرئ چې موږ دلته د لیبریکټریس په جدي ډول باور لرو ترڅو د فاسدو اعدامونو مخه ونه نیول شي ، مګر دا خامخا ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows د فایلونو د خلاصولو طریقه لري چیرې چې وروسته د خلاصیدو وروسته دا حذف کیدی نشي.
            // دا په عموم کې هغه څه دي چې موږ یې دلته غواړو ځکه چې موږ غواړو ډاډ ترلاسه کړو چې زموږ اجرایوي زموږ تر کنترول لاندې نه راځي کله چې موږ دا لیببریکټریس ته وسپارلو ، هیله ده په لیببریکټریس کې د خپل سري معلوماتو راټولولو وړتیا کمه کړئ (کوم چې ممکن غلط لیکل شوی وي).
            //
            //
            // ورکړل شوي چې موږ دلته یو څه نڅا کوو ترڅو زموږ په خپل عکس د یو ډول لاک ترلاسه کولو هڅه وکړي:
            //
            // * اوسني پروسې ته لاسرسی ومومئ ، د هغې دوتنې نوم یې پورته کړئ.
            // * د سم بيرغونو سره دې فايل نوم ته فايل خلاص کړئ.
            // * د اوسني پروسې فایل نوم بیا پورته کړئ ، ډاډ ترلاسه کړئ چې ورته ورته دی
            //
            // که دا ټول تیریږي موږ په تیوري کې واقعیا زموږ د پروسې فایل خلاص کړی او موږ تضمین لرو چې دا به بدل نشي.FWIW د دې یوه برخه د تاریخي پلوه له لیبسټډ څخه کاپي شوې ، نو دا د هغه څه زما غوره تفسیر دی چې پیښ شوي و.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // دا په جامد حافظه کې ژوند کوي نو موږ کولی شو دا بیرته راستون کړو ..
                static mut BUF: [i8; N] = [0; N];
                // ... او دا په کټ کې ژوند کوي ځکه چې لنډمهاله ده
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // په قصدي توګه دلته `handle` لیک کړئ ځکه چې د دې خلاصیدل باید زموږ د بندولو لپاره د دې فایل نوم خوندي کړي.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // موږ غواړو یوه ټوټه بیرته راولو چې ناسالمه شوې وي ، نو که هرڅه ډک شوي وي او دا د ټول اوږدوالي سره مساوي وي نو ورته ناکامي ته مساوي وي.
                //
                //
                // که نه نو د بریا راستنولو وروسته ډاډ ترلاسه کړئ چې نول بایټ په سلایس کې شامل دی.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // د بیک ټریس غلطي اوس مهال د غالۍ لاندې راوتلي دي
    let state = init_state();
    if state.is_null() {
        return;
    }

    // د `backtrace_syminfo` API ته زنګ ووهئ کوم چې (د کوډ لوستلو څخه) باید XK1X ته یو ځل زنګ ووهئ (یا په غلط ډول د خطا سره ناکام شئ).
    // موږ بیا د `syminfo_cb` دننه ډیر اداره کوو.
    //
    // په یاد ولرئ چې موږ دا کار کوو ځکه چې `syminfo` به د سمبول میز سره مشوره وکړي ، د سمبول نومونه به ومومي حتی که په بائنري کې د ڈیبګ معلومات شتون نلري.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}