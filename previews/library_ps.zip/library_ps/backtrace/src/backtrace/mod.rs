use core::ffi::c_void;
use core::fmt;

/// اوسنی کال سټیک معاینه کوي ، ټول فعال چوکاټونه تړل شوي ته د سټریک ټریس محاسبه کولو لپاره تیروي.
///
/// دا فنکشن د یوې برنامې لپاره د زېرمه نښو په محاسبه کولو کې د دې کتابتون ورک هارس دی.ورکړل شوی بندیز `cb` د `Frame` مثالونه ترلاسه شوي کوم چې په سټیک کې د زنګ وهلو چوکاټ په اړه معلومات وړاندې کوي.
/// بندیز د پورته ښکته فیشن کې چوکاټونه ترلاسه کوي (په دې وروستیو کې لومړی دندې په نامه یادیږي).
///
/// د بند بیرته ستنیدونکي ارزښت د دې نښه ده چې ایا بیکټرېس باید دوام ولري.د `false` بیرته ستنیدونکي ارزښت به بیرته ټریس ختم کړي او سمدلاسه بیرته راشي.
///
/// یوځل چې د `Frame` اخیستل شوی نو تاسو به احتمال وغواړئ `backtrace::resolve` ته زنګ ووهئ چې د `ip` (لارښود پوائنټر) یا سمبولیک پته `Symbol` ته واړوئ چې له لارې یې نوم او/یا د فایل نوم/لاین شمیره زده شي.
///
///
/// په یاد ولرئ چې دا په نسبتا ټیټه کچه فعالیت دی او که تاسو غواړئ ، د مثال په توګه ، وروسته د معاینې لپاره بیکټریس ونیسئ ، نو د `Backtrace` ډول ممکن ممکن مناسب وي.
///
/// # اړین ب .ې
///
/// دا فنکشن د `backtrace` crate فعالولو لپاره د `std` ب featureه غواړي ، او د `std` بXه د ډیفالټ لخوا فعال شوې.
///
/// # Panics
///
/// دا فعالیت هیڅکله panic ته هڅه نه کوي ، مګر که `cb` panics چمتو کړي نو بیا ځینې پلیټ فارمونه به دوه ځله panic د پروسې مخنیوي ته اړ کړي.
/// ځینې پلیټ فارمونه د سي کتابتون کاروي کوم چې په داخلي توګه کال بیکونه کاروي کوم چې له دې لارې ضایع کیدلی نشي ، نو د `cb` څخه ویستل ممکن د پروسې اختطاف لامل شي.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // شاته تګ ته دوام ورکړئ
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// د `trace` په څیر ، یوازې غیر محفوظ دی ځکه چې دا غیر منظم دی.
///
/// دا فنکشن د همغږۍ تضمین نلري مګر شتون لري کله چې د دې crate `std` ب featureه نده جوړه شوې.
/// د نورو سندونو او مثالونو لپاره د `trace` فعالیت وګورئ.
///
/// # Panics
///
/// په `cb` ویشتلو کې د انتحار لپاره د `trace` په اړه معلومات وګورئ.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// یو trait د بیکټریک یو چوکاټ استازیتوب کوي ، د دې crate `trace` فعالیت ته ترلاسه شوی.
///
/// د تعقیب فنکشن بند کول به حاصل شوي چوکاټونه وي ، او چوکاټ په حقیقت کې لیږل شوی وي ځکه چې لاندې پلي کول تل د رونټیم پورې نه پیژندل کیږي.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// د دې چوکاټ اوسني لارښود راستنوي.
    ///
    /// دا په نورمال ډول په چوکاټ کې د اجرا کولو لپاره راتلونکی لارښوونې دي ، مګر ټول پلي کونکي دا د 100 acc دقت سره لیست نه کوي (مګر دا عموما خورا نږدې ده).
    ///
    ///
    /// سپارښتنه کیږي چې دا ارزښت `backtrace::resolve` ته انتقال شي ترڅو دا سمبول نوم ته واړوئ.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// د دې چوکاټ اوسني زاړه پوړونکی راستنوي.
    ///
    /// په هغه حالت کې چې بیک اینڈ نشي کولی د دې چوکاټ لپاره سټیک پوینټر بیرته راولي ، نوال پوائنټر بیرته راځي.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// د دې فنکشن چوکاټ د پیل سمبول پته راستنوي.
    ///
    /// دا به د `ip` لخوا بیرته راستنیدونکي لارښود ته د فعالیت پیل کولو لپاره بیرته راستنولو هڅه وکړي ، چې دا ارزښت بیرته راشي.
    ///
    /// په ځینو قضیو کې ، په هرصورت ، بیکینډز به یوازې د دې فعالیت څخه `ip` بیرته راشي.
    ///
    /// بیرته راوړل شوی ارزښت ځینې وختونه کارول کیدی شي که `backtrace::resolve` په پورته ورکړل شوي `ip` کې ناکام شو.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// د هغه موډل اساس پته راګرځوي چې له هغې سره چوکاټ تړاو لري.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // دا لومړی ته اړتیا لري ، ترڅو ډاډ ترلاسه کړي چې میري د کوربه پلیټ فارم په پرتله لومړیتوب اخلي
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // یوازې په dbghelp سمبول کې کارول شوی
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}