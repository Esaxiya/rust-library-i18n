use backtrace::Backtrace;

// د 50 کرکټر انډول نوم
mod _234567890_234567890_234567890_234567890_234567890 {
    // د 50 کرکټر جوړښت نوم
    #[allow(non_camel_case_types)]
    pub struct _234567890_234567890_234567890_234567890_234567890<T>(T);
    impl<T> _234567890_234567890_234567890_234567890_234567890<T> {
        #[allow(dead_code)]
        pub fn new() -> crate::Backtrace {
            crate::Backtrace::new()
        }
    }
}

// د اوږدو فعالیتونو نومونه باید (MAX_SYM_NAME ، 1) کرکټرونو ته لنډ شي.
// یوازې دا ازموینه د MSvc لپاره پرمخ وړئ ، ځکه چې gnu د ټولو چوکاټونو لپاره "<no info>" چاپوي.
#[test]
#[cfg(all(windows, target_env = "msvc"))]
fn test_long_fn_name() {
    use _234567890_234567890_234567890_234567890_234567890::_234567890_234567890_234567890_234567890_234567890 as S;

    // د جوړ شوي نوم 10 تکرار ، نو په بشپړ ډول وړ د فنکشن نوم لږترلږه 10 *(50 + 50)* 2=2000 حروف اوږد دی.
    //
    // دا واقعیا اوږد دی ځکه چې پدې کې د `::` ، `<>` او د اوسني ماډل نوم هم شامل دی
    //
    let bt = S::<S<S<S<S<S<S<S<S<S<i32>>>>>>>>>>::new();
    println!("{:?}", bt);

    let mut found_long_name_frame = false;

    for frame in bt.frames() {
        let symbols = frame.symbols();
        if symbols.is_empty() {
            continue;
        }

        if let Some(function_name) = symbols[0].name() {
            let function_name = function_name.as_str().unwrap();
            if function_name.contains("::_234567890_234567890_234567890_234567890_234567890") {
                found_long_name_frame = true;
                assert!(function_name.len() > 200);
            }
        }
    }

    assert!(found_long_name_frame);
}