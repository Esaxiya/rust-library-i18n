`core::arch` - د Rust اصلي کتابتون معمارۍ ځانګړي داخلي
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

د `core::arch` انډول د جوړښت پورې تړلي داخلي توکي پلي کوي (د بیلګې په توګه سیمډ).

# Usage 

`core::arch` د `libcore` برخې په توګه شتون لري او دا د `libstd` لخوا بیا صادر شوی.د دې crate له لارې د `core::arch` یا `std::arch` له لارې کارول غوره کړئ.
بې ثباته ب featuresې اکثرا د شپې Rust کې د `feature(stdsimd)` له لارې شتون لري.

د دې crate له لارې د `core::arch` کارول د شپې Rust ته اړتیا لري ، او دا کولی شي اکثرا مات شي (او کوي).یوازینۍ قضیې چې تاسو یې باید د دې crate له لارې د دې کارولو ته پام وکړئ:

* که تاسو اړتیا لرئ پخپله د `core::arch` بیا تنظیم کړئ ، د بیلګې په توګه ، د ځانګړي اهدافو ب enabledو سره فعال شوي چې د `libcore`/`libstd` لپاره ندي فعال شوي.
Note: که تاسو اړتیا لرئ دا د غیر معیاري هدف لپاره بیا تنظیم کړئ ، نو مهرباني وکړئ د دې crate کارولو پرځای `xargo` او د `libcore`/`libstd` مناسب ترتیب کولو لپاره غوره کړئ.
  
* د ځینې ب featuresو کارول چې ممکن حتی د بې ثبات Rust ب featuresو شاته هم شتون ونلري.موږ هڅه کوو چې دا لږترلږه وساتو.
که تاسو د دې ب featuresو څخه ځینې کارولو ته اړتیا لرئ ، مهرباني وکړئ یوه مسله پرانیزئ ترڅو موږ یې د شپې Rust کې ښکاره کړو او تاسو کولی شئ له دوی څخه یې وکاروئ.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` اساسا د MIT جواز او Apache جواز (نسخه 2.0) دواړه شرایطو سره توزیع شوی ، د BSD-لکه جوازونو لخوا پوښل شوي برخو سره.

د لا نورو معلوماتو لپاره لایسنس-APachE ، او د لایسنس-MIT وګورئ.

# Contribution

غیر لدې چې تاسو په ښکاره ډول بیان کړئ ، هره مرسته چې په قصدي ډول ستاسو لخوا `core_arch` کې د شمولیت لپاره سپارل شوې وي ، لکه څنګه چې د Apache-2.0 لایسنس کې تعریف شوي ، پرته د اضافي شرایطو او شرایطو څخه ، دوه ځله جواز لري.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












