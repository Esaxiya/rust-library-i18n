use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // زموږ د `#[assert_instr]` تشریحاتو ته ویلو لپاره کارول شوي چې ټول سیمال انټرنیټونه د دوی کوډګین ازموینې لپاره شتون لري ، ځکه چې ځینې یې د اضافي `-Ctarget-feature=+unimplemented-simd128` شاته دي چې همدا اوس په `#[target_feature]` کې مساوي ندي.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}