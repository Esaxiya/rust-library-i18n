# سټارډارک سره مرسته کول

د `stdarch` crate د شراکتونو منلو ته لیوالتیا څخه ډیر دی!لومړی شاید تاسو غواړئ ذخیره وګورئ او ډاډ ترلاسه کړئ چې ازموینې ستاسو لپاره تیریږي:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

چیرې چې `<your-target-arch>` هدف درې چنده وي لکه څنګه چې د `rustup` لخوا کارول کیږي ، د مثال په توګه `x86_x64-unknown-linux-gnu` (پرته له کوم مخکیني `nightly-` یا ورته).
دا هم په یاد ولرئ چې دا ذخیره د شپې شپې چینل Rust ته اړتیا لري!
پورتنۍ ازموینې په حقیقت کې د شپې rust ته اړتیا لري چې ستاسو په سیسټم کې ډیفالټ وي ، د دې لپاره چې تنظیم کړئ `rustup default nightly` (او بیرته راستنیدو لپاره `rustup default stable`).

که پورتني کوم ګامونه کار نه کوي ، [please let us know][new]!

بل پورته تاسو کولی شئ د مرستې لپاره [find an issue][issues] وکړئ ، موږ د [`help wanted`][help] او [`impl-period`][impl] ټاګونو سره یو څه غوره کړي دي چې ممکن په ځانګړي توګه یو څه مرسته وکاروي. 
تاسو ممکن په [#40][vendor] کې خورا علاقه ولرئ ، په x86 کې د ټولو پلورونکي داخلي پلي کول.دا مسله د کوم ځای پیل کولو په اړه یو څه ښه نښې لري!

که تاسو عمومي پوښتنې ترلاسه کړئ نو د [join us on gitter][gitter] لپاره وړیا احساس وکړئ او شاوخوا یې وپوښتئ!د پوښتنو سره یا د@برنټسوشي یاalexcrichton پاینګ لپاره آزاد احساس وکړئ.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# د سټارډ انتشاراتو لپاره مثالونه ولیکئ

دلته یو څو ب featuresې شتون لري چې د ورکړل شوي داخلي کار لپاره باید فعال شي او ښه مثال یې باید یوازې د `cargo test --doc` لخوا پرمخ وړل شي کله چې فیچر د CPU لخوا ملاتړ کیږي.

د پایلې په توګه ، ډیفالټ `fn main` چې د `rustdoc` لخوا رامینځته کیږي کار نه کوي (په ډیری قضیو کې).
د لارښود په توګه د لاندې کارولو په اړه غور وکړئ ترڅو ډاډ ترلاسه کړئ چې ستاسو مثال د تمه په توګه کار کوي.

```rust
/// # // موږ cfg_target_feature ته اړتیا لرو ترڅو ډاډ ترلاسه کړئ چې مثال یوازې دی
/// # // د `cargo test --doc` لخوا پرمخ وړل کیږي کله چې CPU د ب supportsه ملاتړ کوي
/// # #![feature(cfg_target_feature)]
/// # // موږ د کار کولو لپاره د داخلي لپاره هدف_فید ته اړتیا لرو
/// # #![feature(target_feature)]
/// #
/// # // رستاک د ډیفالټ په واسطه `extern crate stdarch` کاروي ، مګر موږ دې ته اړتیا لرو
/// # // `#[macro_use]`
/// # # [میکرو_یوز] د crate سټارډارک بهر؛
/// #
/// # // اصلي اصلي دنده
/// # fn main() {
/// #     // یوازې دا چل کړئ که `<target feature>` ملاتړ شوی وي
/// #     که cfg_feature_enabled! ("<target feature>"){
/// #         // د `worker` فعالیت رامینځته کړئ چې یوازې به چلیږي که د هدف ب .ه
/// #         // ملاتړ شوی او ډاډ ترلاسه کوي چې `target_feature` ستاسو د کارګر لپاره فعال شوی
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         غیر محفوظ fn worker() {
/// // خپل مثال دلته ولیکئ.د ځانګړتیا ځانګړي انترنیکس به دلته کار وکړي!ځنګلي شه!
///
/// #         }
///
/// #         غیر محفوظ { worker(); }
/// #     }
/// # }
```

که ځینې پورته نحوي نزاکت معلوم نه شي ، د [Rust Book] د [Documentation as tests] برخه د `rustdoc` ترکیب خورا ښه تشریح کوي.
د تل په څیر ، د [join us on gitter][gitter] لپاره وړیا احساس وکړئ او له موږ څخه وپوښتئ که تاسو کوم عکس واخیست ، او د `stdarch` اسناد ښه کولو کې د مرستې لپاره مننه!

# د ازموینې بدیل لارښوونې

دا عموما سپارښتنه کیږي چې تاسو د آزموینو د پرمخ وړلو لپاره `ci/run.sh` وکاروئ.
په هرصورت دا ممکن ستاسو لپاره کار ونکړي ، د مثال په توګه که تاسو په Windows کې یاست.

پدې حالت کې تاسو کولی شئ د کوډ تولید ازموینې لپاره د `cargo +nightly test` او `cargo +nightly test --release -p core_arch` چلولو ته بیرته ستن شئ.
په یاد ولرئ چې دا د شپې اوزار کیچ نصب کولو ته اړتیا لري او د `rustc` لپاره ترڅو ستاسو د هدف درې ګونې او د دې CPU په اړه پوه شي.
په ځانګړي توګه تاسو اړتیا لرئ د `TARGET` چاپیریال متغیر تنظیم کړئ لکه څنګه چې تاسو د `ci/run.sh` لپاره.
سربیره پردې تاسو اړتیا لرئ د `RUSTCFLAGS` تنظیم کړئ (د `C` ته اړتیا لرئ) د نښه شوي ب featuresو په ګوته کولو لپاره ، د مثال په توګه `RUSTCFLAGS="-C -target-features=+avx2"`.
تاسو کولی شئ `-C -target-cpu=native` هم تنظیم کړئ که تاسو د اوسني CPU پروړاندې "just" وده کوئ.

خبرداری ورکړئ کله چې تاسو دا بدیل لارښوونې کاروئ ، [things may go less smoothly than they would with `ci/run.sh`][ci-run-good] ، د مثال په توګه
د لارښود نسل ازموینې ممکن ناکام شي ځکه چې ډیسامبلر دوی ته مختلف نوم ورکړی ، د بیلګې په توګه
دا ممکن د `aesenc` لارښوونو پرځای `vaesenc` تولید کړي سره له دې چې ورته چلند کوي.
همدارنګه دا لارښوونې د معمول ترسره کیدو په پرتله لږې ازموینې ترسره کوي ، نو مه حیران کیږئ کله چې تاسو په پای کې یوځل غلطیتونه ښیې چې د ازموینو لپاره دلته ښودل شوي ندي.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






