# د `rustc-std-workspace-std` crate

د `rustc-std-workspace-core` crate لپاره اسناد وګورئ.