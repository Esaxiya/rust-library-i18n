// rsbegin.o او rsend.o د "compiler runtime startup objects" په نوم نومول شوي.
// دوی د کویلر چلولو وخت په سمه توګه پیل کولو لپاره اړین کوډ لري.
//
// کله چې د اجرا کولو وړ یا ډیلیب عکس وصل شي ، نو د ټول کاروونکي کوډ او کتابتونونه د دې دوه اعتراض فایلونو ترمینځ "sandwiched" دي ، نو د rsbegin.o څخه کوډ یا ډاټا د عکس اړوندو برخو کې لومړی رامینځته کیږي ، پداسې حال کې چې د rsend.o څخه کوډ او معلومات وروستي شي.
// دا تاثیر د پیل په پیل یا د یوې برخې په پای کې د سمبولونو ځای په ځای کولو لپاره کارول کیدی شي ، او همدارنګه د اړتیا وړ سرلیک یا فوټر ایښودلو لپاره.
//
// په یاد ولرئ چې د اصلي انډول ننوتلو نقطه د C رن ټیټ سټارټم آبجیکټ کې موقعیت لري (معمولا د `crtX.o` په نامه هم یادیږي) ، کوم چې بیا د نورو رنټیم اجزاو ابتدايي کال بیکونه غوښتنه کوي (د بل ځانګړي عکس برخې له لارې راجستر شوي).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // د سټا چوکاټ unwind معلوماتو برخې پیل نښه کوي
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // د انویندر داخلي کتاب ساتلو لپاره د سکریچ ځای.
    // دا په 00 GCC/unwind-dw2-fde.h کې د `struct object` په توګه تعریف شوی.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // د معلوماتو registration/deregistration روټینان خلاص کړئ.
    // د libpanic_unwind لاسوندونه وګورئ.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // په ماډل پیل کې نامعلومه معلومات ثبت کړئ
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // په بند کې ثبت نه کول
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // د MinGW ځانګړی init/uninit معمول ثبت
    pub mod mingw_init {
        // د MinGW د پیل شوي توکي (crt0.o/dllcrt0.o) به په .ctors او .dtors برخو کې د پیل او وتلو په وخت کې نړیوال جوړونکي وغواړي.
        // د DLLs په قضیه کې ، دا هغه وخت ترسره کیږي کله چې DLL لوډ او پورته شوی وي.
        //
        // لینیکر به برخې قطع کړي ، کوم چې دا تضمین کوي چې زموږ زنګونه د لیست په پای کې موقعیت لري.
        // له هغه ځایه چې جوړونکي په متوافق ترتیب کې پرمخ وړل کیږي ، دا ډاډ ترلاسه کوي چې زموږ زنګونه لومړی او وروستي اجرا شوي دي.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: د C پیل پیل
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: د ختمیدو کالبکسونه
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}