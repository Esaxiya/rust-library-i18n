//! `Cell` د (scoped) موجود ژوندی وختونو لپاره ډول

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// د ژوندی سره ، د لامبډا غوښتنلیک ولیکئ.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// لمبډا د ژوند په اوږدو کې ټایپ کړئ ، لکه ، `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) د newtype FIXME(#52812) سره د `&'a mut <T as ApplyL<'b>>::Out` سره د پروجیکشن محدودیتونو شاوخوا کار وکړئ
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// په `self` کې `replacement` ته ارزښت وټاکئ پداسې حال کې چې `f` چلیږي ، کوم چې زاړه ارزښت په متناسب ډول ترلاسه کوي.
    /// زاړه ارزښت به د `f` وتلو وروسته بحال شي ، حتی د panic لخوا ، په شمول د دې `f` لخوا رامینځته شوي تعدیلات.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// ریپر چې دا باوري کوي چې حجره تل ډکېږي (د اصلي حالت سره ، په اختیاري توګه د `f` لخوا بدل شوی) ، حتی که `f` ویره کړې وه.
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// په `self` کې `value` ته ارزښت وټاکئ پداسې حال کې چې `f` چلیږي.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}