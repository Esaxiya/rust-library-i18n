//! د میکرو لیکوالانو لپاره د ملاتړ کتابتون کله چې نوي میکرو تعریف کوي.
//!
//! دا کتابتون ، د معیاري توزیع لخوا چمتو شوی ، د کړنلارې په توګه ټاکل شوي میکرو تعریفونو په انټررفیس کې مصرف شوي ډولونه چمتو کوي لکه د فعالیت په څیر میکروس `#[proc_macro]` ، د میکرو ځانګړتیاوې `#[proc_macro_attribute]` او د کسب لاسته راوړل شوي خاصیتونه#[[proc_macro_derive] `].
//!
//!
//! د نورو لپاره [the book] وګورئ.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// معلوموي چې ایا پروکاکټر اوسني روان برنامې ته د لاسرسي وړ ګرځول شوی.
///
/// proc_macro crate یوازې د پروسیژرونکي مایکرو پلي کولو دننه کارولو لپاره دی.پدې crate panic کې ټولې دندې که د پروسیژرونکي میکرو څخه بهر غوښتل شوي وي ، لکه د جوړ سکریپټ یا واحد ټیسټ یا عادي Rust بائنری څخه.
///
/// د Rust کتابتونونو لپاره په پام کې نیولو سره چې دواړه د میکرو او غیر میکرو کارولو قضیې مالتړ لپاره ډیزاین شوي ، `proc_macro::is_available()` د نه ویریدلو لاره چمتو کوي ترڅو معلومه کړي چې ایا د پروچاماکرو د API کارولو لپاره اړین زیربنا موجوده شتون لري.
/// ریښتیني راستنیدل که د پروسیژرونکي مایکرو دننه بلل شوي وي ، غلط که چیرې له کوم بلنری څخه غوښتل شوی وي.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// اصلي ډول د دې crate لخوا چمتو شوی ، د tokens د خلاصې جریان استازیتوب کوي ، یا په ځانګړي توګه د token ونو لړۍ.
/// ډول د دې token ونو باندې تکرار کولو لپاره انٹرفیس چمتو کوي او په مقابل کې ، د token ونې یو جریان کې راټولوي.
///
///
/// دا د `#[proc_macro]` ، `#[proc_macro_attribute]` او `#[proc_macro_derive]` تعریفونو ننوتنه او محصول دي.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// تېروتنه له `TokenStream::from_str` څخه راستون شوې.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// خالي `TokenStream` راګرځي چې token ونه ونه لري.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// چک کوي که دا `TokenStream` خالي وي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// tokens ته مزی ماتولو او tokens د token جریان کې پارس کولو هڅې.
/// ممکن د یو څو دلیلونو لپاره ناکام شي ، د مثال په توګه ، که چیرې توازن متوازن ډیلیمټرې یا حروف ولري په ژبه کې شتون نلري.
///
/// په پارس شوي جریان کې ټول tokens د `Span::call_site()` سپینو ترلاسه کوي.
///
/// NOTE: ځینې غلطۍ ممکن د `LexError` بیرته ورکولو پرځای panics لامل شي.موږ حق لرو چې دا تېروتنې وروسته په `LexError` کې بدلې کړو.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB ، پل یوازې `to_string` چمتو کوي ، د دې پراساس `fmt::Display` تطبیقوي (د دواړو ترمینځ د معمول اړیکو برعکس).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// د token جریان د یو تار په توګه چاپ کوي چې داسې انګیرل کیږي چې په خساره ډول بیرته ورته token جریان کې بدل شي (موډولو سپان) ، پرته لدې چې د ممکنه T ټوکن ټری: : ګروپ د `Delimiter::None` ډلیمیټرونو او منفي شمیرو سره.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// token د ډیبګ کولو لپاره مناسب فورمه کې چاپوي.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// یو token جریان رامینځته کوي چې یو واحد token ونه لري.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// په یو واحد جریان کې ډیری token ونې راټولوي.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// د token جریان کې د "flattening" عملیات ، د token ونې د ډیری token جریان څخه په یو واحد جریان کې راټولوي.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) د امکان تر بریده تطبیق شوي if/when وکاروئ.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// د `TokenStream` ډول لپاره د عامه پلي کولو توضیحات ، لکه تکرارونکي.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// د `توکین سټریم`` ټوکنTree`s څخه تیریدوونکی.
    /// تکرار د "shallow" دی ، د بیلګې په توګه ، تکرار په محدود ډلو کې تکرار نه کوي ، او ټولې ډلې د token ونو په توګه بیرته راستانه کیږي.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` خپلواکي tokens مني او په `TokenStream` کې پراخه کیږي چې ان پټ تشریح کوي.
/// د مثال په توګه ، `quote!(a + b)` به یو بیان تولید کړي ، چې ، کله چې ارزول کیږي ، د `TokenStream` `[Ident("a") ، Punct('+', Alone) ، Ident("b")]`.
///
///
/// انکیوټینګ د `$` سره ترسره کیږي ، او د ناخوالې مودې په توګه د راتلونکي راتلونکي پیژندلو په کارولو سره کار کوي.
/// د `$` پخپله نقل کولو لپاره ، `$$` وکاروئ.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// د سرچینې کوډ سیمه ، د میکرو توسیع معلوماتو سره.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// په سپن `self` کې ورکړل شوي `message` سره نوی `Diagnostic` رامینځته کوي.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// یو سپان چې د میکرو تعریف سایټ کې حل کوي.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// د اوسني پروسیژرونکي میکرو د غوښتنې موده.
    /// د دې دورې سره رامینځته شوي پیژندونکي به حل شي لکه څنګه چې دوی په مستقیم ډول د مایکرو تلیفون ځای کې لیکل شوي (د کال سایټ حفظ الصحه) او د کوډ کال سایټ کې نور کوډ به دوی ته د راجع کولو وړ وي.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// یو سپان چې د `macro_rules` حفظ الصحه استازیتوب کوي ، او ځینې وختونه د میکرو تعریف سایټ کې حل کوي (سیمه ایز تغیرات ، لیبلونه ، `$crate`) او ځینې وختونه د میکرو کال سایټ کې (هرڅه).
    ///
    /// د سپان موقعیت د کال سایټ څخه اخیستل شوی.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// د اصلي سرچینې فایل چې پدې کې ورته اشاره کوي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// په تیرو میکرو توسیع کې د tokens لپاره `Span` له کوم ځای څخه چې `self` له کوم څخه پیدا شوی ، که کوم یو.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// د اصلي سرچینې کوډ لپاره موده چې `self` له کومه څخه جوړه شوې وه.
    /// که دا `Span` د نورو میکرو توضیحاتو څخه رامینځته شوی نه وي نو د بیرته ستنیدو ارزښت د `*self` ورته دی.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// د دې مودې لپاره د سرچینې فایل کې د line/column پیل کول ترلاسه کوي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// د دې مودې لپاره د سرچینې فایل کې د پای line/column ترلاسه کول.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// د `self` او `other` په احاطه کولو کې نوی سپان رامینځته کوي.
    ///
    /// که `self` او `other` له مختلف فایلونو څخه وي نو `None` بیرته راولي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// د ورته line/column معلوماتو سره د `self` په څیر یو نوی سپین رامینځته کوي مګر دا سمبولونه حلوي لکه څنګه چې دا په `other` کې و.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// د `self` په څیر ورته ورته ریزولوشن سلوک سره یو نوی سپین رامینځته کوي مګر د `other` line/column معلوماتو سره.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// د سپینو سره پرتله کول ترڅو وګورئ چې دوی مساوي دي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// د سرچینې متن د یوې مودې شاته راوړي.
    /// دا د اصلي سرچینې کوډ خوندي کوي ، په شمول ځایونو او نظرونو سره.
    /// دا یوازې یوه پایلې بیرته راګرځوي که چیرې سپن د اصلي سرچینې کوډ سره مطابقت ولري.
    ///
    /// Note: د میکرو مشاهده پایلې باید یوازې په tokens تکیه وکړي او نه د سرچینې متن باندې.
    ///
    /// د دې فعالیت پایله یوه غوره هڅه ده چې یوازې د تشخیص لپاره وکارول شي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// د ډبګنګ کولو لپاره مناسب فورمه کې سپن چاپ کړئ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// د لاین کالم جوړه د `Span` پیل یا پای نمایندګي کوي.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// د سرچینې دوسیه کې 1-ترتیب شوې کرښه چې په هغې کې سپن (inclusive) ختمیږي یا پای ته رسیږي.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// د سرچینې دوسیه کې د 0 شاخص شوي کالم (په UTF-8 تورو کې) چې په هغه وخت کې سپان (inclusive) پیل کیږي یا پای ته رسیږي.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// د ورکړل شوي `Span` د سرچینې فایل.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// دې سرچینې فایل ته لاره پیدا کوي.
    ///
    /// ### Note
    /// که چیرې د دې `SourceFile` سره تړلی کوډ موده د بهرني میکرو لخوا رامینځته شوې ، دا ماکرو ، دا ممکن د فایل سیسټم کې واقعی لاره نه وي.
    /// د چیک کولو لپاره [`is_real`] وکاروئ.
    ///
    /// دا هم په یاد ولرئ چې حتی که `is_real` `true` بیرته راولي ، که `--remap-path-prefix` د قوماندې په لیکه کې تیره شوې وه ، نو لکه څنګه چې ورکړل شوی لاره ممکن په حقیقت کې معتبر نه وي.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// `true` راستنوي که چیرې د دې سرچینې فایل ریښتینې سرچینه فایل وي ، او د بهرني میکرو د توسعې له امله رامینځته شوی نه وي.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // دا یو هیک دی ترڅو پورې چې د انټرکانټ سپان پلي نه شي او موږ کولی شو په بهرني مایکرو کې تولید شوي اسپانونو لپاره ریښتینې سرچینې فایلونه ولرو.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// یو token یا د token ونو یو محدود ترتیب (د مثال په توګه ، `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// د token جریان د بریکٹ ډیلیمټرو لخوا محاصره شوی.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// یو پیژندونکی
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// یو واحد وقفه ایښودونکی کرکټر (`+` ، `,` ، `$` ، او داسې نور).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// یو لفظي کرکټر (`'a'`) ، تار (`"hello"`) ، شمیره (`2.3`) ، او داسې نور.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// د دې ونې دوره بیرته راوړي ، د موجود token یا Xdxted جریان د `span` میتود ته استوي.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// د دې *یوازې دې token* لپاره سپان تنظیموي.
    ///
    /// په یاد ولرئ که چیرې دا token `Group` وي نو دا طریقه به د هر داخلي tokens ساحه تنظیم نکړي ، دا به په اسانۍ سره د هر متغیر `set_span` میتود ته واستوي.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// د token ونې د ډبګین لپاره مناسب فارم کې چاپوي.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // د دې هر یو د ترلاسه شوي ډیبګ کې د سټریک ډول کې نوم لري ، نو د اضافي لارښوونې سره ځور مه کوئ
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB ، پل یوازې `to_string` چمتو کوي ، د دې پراساس `fmt::Display` تطبیقوي (د دواړو ترمینځ د معمول اړیکو برعکس).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// د token ونې د تار په توګه چاپ کوي چې داسې انګیرل کیږي چې په خساره ډول بیرته ورته token ونې (ماډولو سپانس) ته بدلیږي ، پرته لدې چې د ممکنه `ټوکن ټری: : ګروپ د `Delimiter::None` ډلیمیټرونو او منفي شمیرو سره.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// یو محدود شوی token جریان.
///
/// یو `Group` په داخلي توګه یو `TokenStream` لري چې د `ډیلیمیټرز لخوا محاصره شوی دی.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// تشریح کوي چې څنګه د token ونو ترتیب ترتیب شوی.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// یو ضمیمه ډلییمټر ، چې ممکن د مثال په توګه د tokens شاوخوا راڅرګند شي چې د "macro variable" `$var` څخه راځي.
    /// د `$var * 3` په څیر قضیو کې چیرې چې د `$var` `1 + 2` وي د آپریټر لومړیتوبونه ساتل مهم دي.
    /// ضمیمه ډیلیمټران ممکن د تار له لارې د token جریان پړاو کې ژوندي پاتې نشي.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// د ورکړل شوي ډیلیمټر او token جریان سره نوی `Group` جوړوي.
    ///
    /// دا جوړونکی به د دې ډلې لپاره `Span::call_site()` ته موده تنظیم کړي.
    /// د سپان بدلولو لپاره تاسو کولی شئ لاندې د `set_span` میتود وکاروئ.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// د دې `Group` ډلیمیټر راستنوي
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// د tokens `TokenStream` راستنوي چې پدې `Group` کې ډیل شوي.
    ///
    /// په یاد ولرئ چې بیرته راستانه شوي token جریان کې پورته شوی حدود نه شاملوي.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// د دې token جریان د ډیمیټرانو لپاره سپن بیرته راولي ، د ټول `Group` پراخه کول.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// د دې ګروپ پرانیستونکي ډیلیمټر ته په اشارې کولو سپان بیرته راوړي.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// د دې ګروپ تړل شوي ډیلیمټر ته په اشارې کولو موده سپانوي.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// د دې `ګروپ del ډلیمیټرانو لپاره سپان تنظیموي ، مګر د دې داخلي tokens نه.
    ///
    /// دا میتود به **نه** د دې ډلې لخوا پراخ شوي ټول داخلي tokens پراخه اندازه تنظیم کړي ، مګر دا به یوازې د `Group` په کچه د ډیلیمټر tokens پراخه کړي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB ، پل یوازې `to_string` چمتو کوي ، د دې پراساس `fmt::Display` تطبیقوي (د دواړو ترمینځ د معمول اړیکو برعکس).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ګروپ د تار په توګه چاپ کوي چې باید په خساره ډول بیرته ورته ډلې ته بدل شي (موډولو سپان) ، پرته لدې چې د ممکن `ټوکن ټری: : ګروپ د `Delimiter::None` ډلیمیټرونو سره.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` د XT1X ، `-` یا `#` په څیر واحد مقناطیسي ځانګړتیا ده.
///
/// د `+=` په څیر ملټي کریکټ آپریټرونه د `Punct` دوه مثالونو په توګه نمایش شوي د `Spacing` مختلف شکلونو سره بیرته راستانه شوي.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// که چیرې یو `Punct` سمدلاسه د بل `Punct` تعقیب شي یا د بل token یا سپین ځای تعقیب شي.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// د مثال په توګه ، `+` په `+ =` ، `+ident` یا `+()` کې `Alone` دی.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// د مثال په توګه ، `+` په `+=` یا `'#` کې `Joint` دی.
    /// سربیره پردې ، واحد نرخ `'` کولی شي د پیژندونکو سره یوځای شي ترڅو د ژوند وختونه `'ident` تشکیل کړي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// ورکړل شوي کرکټر او تشو څخه نوی `Punct` جوړوي.
    /// د `ch` دلیل باید د اعتبار وړ ټکي ټکي وي چې د ژبې لخوا اجازه ورکړل شوې وي ، که نه نو فنکشن به panic وي.
    ///
    /// بیرته راوړل شوی `Punct` به د `Span::call_site()` ډیفالټ دوره ولري کوم چې لاندې د `set_span` میتود سره تنظیم کیدی شي.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// د دې ټکي ټکي خاصیت د `char` په حیث راټولیږي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// د دې ټکي ایښودو ځانګړتیاوې بیرته راګرځوي ، دا په ګوته کوي چې ایا دا په سملاسي ډول د token جریان کې د بل `Punct` تعقیب کیږي ، نو دوی ممکن په کثیر کرکټر آپریټر (`Joint`) کې یوځای شي ، یا دا د یو څو نورو token یا سپین ځای (`Alone`) تعقیب شي نو عملیاتي خامخا لري ختم شو
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// د دې ټکي ټکي خاصیت لپاره سپان راوګرځوي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// د دې ټکي ټکي کرکټر لپاره سپین کړئ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB ، پل یوازې `to_string` چمتو کوي ، د دې پراساس `fmt::Display` تطبیقوي (د دواړو ترمینځ د معمول اړیکو برعکس).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// د زنګ وهلو ځانګړنه د تار په توګه چاپوي چې باید له لاسه وتلې ب .ه بیرته ورته کرکټر ته واړول شي.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// یو پیژندونکی (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// د ورکړل شوي `string` سره د ټاکل شوي `span` سره نوی `Ident` رامینځته کوي.
    /// د `string` دلیل باید د اعتبار وړ پیژندونکی وي چې د ژبې لخوا اجازه ورکړل شوې وي (پشمول د کلیدي ټکي په شمول ، د `self` یا `fn`).که نه نو ، فنکشن به panic.
    ///
    /// په یاد ولرئ چې `span` ، دا مهال په rustc کې ، د دې پیژندونکي لپاره د حفظ الصحې معلومات تنظیموي.
    ///
    /// د دې وخت پورې ، `Span::call_site()` په څرګنده توګه د "call-site" حفظ الصحه غوره کوي پدې معنی چې پدې پیژندل شوي سره پیژندونکي به حل شي لکه څنګه چې دوی د میکرو کال موقعیت کې مستقیم لیکل شوي ، او د میکرو کال سایټ کې نور کوډ به د دې وړتیا ولري دوی هم.
    ///
    ///
    /// وروسته د `Span::def_site()` په څیر سپنونه به اجازه ورکړي "definition-site" حفظ الصحه غوره کړي پدې معنی چې پدې سپین سره رامینځته شوي پیژندونکي به د میکرو تعریف په موقعیت کې حل شي او د میکرو کال سایټ کې نور کوډ به دوی ته د راجع کولو توان ونلري.
    ///
    /// د حفظ الصحې د اوسني اهمیت له امله دا جوړونکی ، د نورو tokens برعکس ، د `Span` ته اړتیا لري چې په ساختمان کې مشخص شي.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// د `Ident::new` په څیر ، مګر د خام پیژندونکي (`r#ident`) رامینځته کوي.
    /// د `string` دلیل یو معتبر پیژندونکی وي چې د ژبې لخوا اجازه ورکړل شوې وي (پشمول د کلیدي ټکو په شمول `fn`).
    /// کلیدي ټکي چې د لارې برخو کې د کارولو وړ دي (د مثال په توګه
    /// `self`, `سوپر`) ملاتړ ندی شوی او د panic لامل ګرځی.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// د دې `Ident` دوره بیرته راګرځوي ، د [`to_string`](Self::to_string) لخوا راستانه شوی ټوله تار پواسطه.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// د دې `Ident` پراخه اندازه تنظیموي ، ممکن د دې حفظ الصحې شرایط بدل کړي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB ، پل یوازې `to_string` چمتو کوي ، د دې پراساس `fmt::Display` تطبیقوي (د دواړو ترمینځ د معمول اړیکو برعکس).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// پیژندونکی د تار په توګه چاپوي چې باید له لاسه وتلی بیرته ورته پیژندونکي ته واړول شي.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// یو لفظي تار (`"hello"`) ، د بایټ تار (`b"hello"`) ، کرکټر (`'a'`) ، د بایټ کرکټر (`b'a'`) ، د بشپړ او یا تیرونکي نکتې شمیره د مخه سره (د `1` ، `1u8` ، `2.3` ، `2.3f32`) سره یا پرته.
///
/// د بوتان سوادونه لکه د `true` او `false` دلته تړاو نه لري ، دوی `پیژندونکي دي.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// د ټاکل شوي ارزښت سره نوی ضمیمه انډول رامینځته کوي.
        ///
        /// دا فنکشن به د `1u32` په څیر یو بشپړ انکشاف رامینځته کړي چیرې چې ټاکل شوي د بشپړ ارزښت ارزښت د token لومړۍ برخه ده او انضمام هم په پای کې ضمیمه کیږي.
        /// د منفي شمیرو څخه رامینځته شوي لیکوال ممکن د `TokenStream` یا تارونو له لارې دورې سفرونو کې ژوندي پاتې نشي او ممکن دوه tokens (`-` او مثبت لفظي) کې مات شي.
        ///
        ///
        /// د دې میتود له لارې رامینځته شوي لیکوال د ډیفالټ په واسطه د `Span::call_site()` موده لري ، کوم چې لاندې د `set_span` میتود سره تنظیم کیدی شي.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// د ټاکل شوي ارزښت سره نوی بې بنسټه عدد لغړی رامینځته کوي.
        ///
        /// دا فنکشن به د `1` په څیر یو بشپړ انکشاف رامینځته کړي چیرې چې ټاکل شوي د بشپړ ارزښت ارزښت د token لومړۍ برخه ده.
        /// پدې token کې هیڅ لاحقه نده مشخص شوې ، پدې معنی چې غوښتنې لکه `Literal::i8_unsuffixed(1)` د `Literal::u32_unsuffixed(1)` سره مساوي دي.
        /// له منفي شمیرو څخه رامینځته شوي لیکوال ممکن د `TokenStream` یا تارونو له لارې rountrips نه ژوندي پاتې شي او ممکن دوه tokens (`-` او مثبت لفظي) کې مات شي.
        ///
        ///
        /// د دې میتود له لارې رامینځته شوي لیکوال د ډیفالټ په واسطه د `Span::call_site()` موده لري ، کوم چې لاندې د `set_span` میتود سره تنظیم کیدی شي.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// یو نوی بې شمیره فلوټینګ پواینټ رامینځته کوي.
    ///
    /// دا جوړونکی د `Literal::i8_unsuffixed` په څیر ورته دی چیرې چې د فلوټ ارزښت مستقیم په token کې خارج کیږي مګر هیڅ ضمیمه نه کارول کیږي ، نو دا ممکن وروسته په مرتب کې `f64` وي.
    ///
    /// له منفي شمیرو څخه رامینځته شوي لیکوال ممکن د `TokenStream` یا تارونو له لارې rountrips نه ژوندي پاتې شي او ممکن دوه tokens (`-` او مثبت لفظي) کې مات شي.
    ///
    /// # Panics
    ///
    /// دا فنکشن ته اړتیا لري چې ټاکل شوی فلوټ محدود وي ، د مثال په توګه که دا انفینټ یا NAN وي نو دا فنکشن به panic وي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// یو نوی ضمیمه فلوټینګ پواینټ رامینځته کوي.
    ///
    /// دا جوړونکی به د `1.0f32` په څیر لفظی رامینځته کړي چیرې چې ټاکل شوي ارزښت د token مخکینۍ برخه ده او `1.0f32` د token پخوانۍ برخه ده.
    /// دا token به تل په کمپیلر کې د `f32` کیدو لپاره تحلیل شي.
    /// له منفي شمیرو څخه رامینځته شوي لیکوال ممکن د `TokenStream` یا تارونو له لارې rountrips نه ژوندي پاتې شي او ممکن دوه tokens (`-` او مثبت لفظي) کې مات شي.
    ///
    ///
    /// # Panics
    ///
    /// دا فنکشن ته اړتیا لري چې ټاکل شوی فلوټ محدود وي ، د مثال په توګه که دا انفینټ یا NAN وي نو دا فنکشن به panic وي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// یو نوی بې شمیره فلوټینګ پواینټ رامینځته کوي.
    ///
    /// دا جوړونکی د `Literal::i8_unsuffixed` په څیر ورته دی چیرې چې د فلوټ ارزښت مستقیم په token کې خارج کیږي مګر هیڅ ضمیمه نه کارول کیږي ، نو دا ممکن وروسته په مرتب کې `f64` وي.
    ///
    /// له منفي شمیرو څخه رامینځته شوي لیکوال ممکن د `TokenStream` یا تارونو له لارې rountrips نه ژوندي پاتې شي او ممکن دوه tokens (`-` او مثبت لفظي) کې مات شي.
    ///
    /// # Panics
    ///
    /// دا فنکشن ته اړتیا لري چې ټاکل شوی فلوټ محدود وي ، د مثال په توګه که دا انفینټ یا NAN وي نو دا فنکشن به panic وي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// یو نوی ضمیمه فلوټینګ پواینټ رامینځته کوي.
    ///
    /// دا جوړونکی به د `1.0f64` په څیر لفظی رامینځته کړي چیرې چې ټاکل شوي ارزښت د token مخکینۍ برخه ده او `1.0f64` د token پخوانۍ برخه ده.
    /// دا token به تل په کمپیلر کې د `f64` کیدو لپاره تحلیل شي.
    /// له منفي شمیرو څخه رامینځته شوي لیکوال ممکن د `TokenStream` یا تارونو له لارې rountrips نه ژوندي پاتې شي او ممکن دوه tokens (`-` او مثبت لفظي) کې مات شي.
    ///
    ///
    /// # Panics
    ///
    /// دا فنکشن ته اړتیا لري چې ټاکل شوی فلوټ محدود وي ، د مثال په توګه که دا انفینټ یا NAN وي نو دا فنکشن به panic وي.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// ژبنۍ نښې.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// کرکټر لفظي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// د بایټ تار سواد
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// د دې لفظي پوښښ لرونکي مودې ته راستنوي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// د دې لفظي لپاره اړوند سپان تنظیموي.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// د `Span` راګرځوي چې د `self.span()` فرعي سیټ دی چې یوازې د `range` لړ کې سرچینې بایټ لري.
    /// `None` راګرځوي که چیرې دا ټرینیم شوی موده د `self` حدود څخه بهر وي.
    ///
    // FIXME(SergioBenitez): وګورئ چې د بایټ سلسله د سرچینې په UTF-8 حد کې پیل او پای ته رسي.
    // که نه ، نو امکان لري چې panic به بل چیرې پیښ شي کله چې د سرچینې متن چاپ شي.
    // FIXME(SergioBenitez): د کاروونکي لپاره هیڅ لاره شتون نلري چې پوه شي `self.span()` په حقیقت کې کوم ته نقشه ورکوي ، نو دا میتود اوس مهال یوازې په ړوند ډول بلل کیدی شي.
    // د مثال په توګه ، 'c' د کرکټر لپاره `to_string()` "'\u{63}'" راګرځوي؛د کاروونکي لپاره هیڅ لاره نشته چې پوه شي چې آیا د سرچینې متن 'c' و یا ایا دا '\u{63}' و.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) یو څه `Option::cloned` ته ورته ، مګر د `Bound<&T>` لپاره.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB ، پل یوازې `to_string` چمتو کوي ، د دې پراساس `fmt::Display` تطبیقوي (د دواړو ترمینځ د معمول اړیکو برعکس).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// لفظي لیکنه د تار په توګه چاپوي چې باید له لاسه وتلې ب theه ورته عین لفظ ته واړوئ (پرته لدې چې د تیرې نقطې سووالی لپاره د احتمالي راتلو لپاره).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// د چاپیریال متغیرونو ته د لاسرسي لاسرسی.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// د چاپیریال بدلون بدل کړئ او د انحصاري معلوماتو رامینځته کولو لپاره یې اضافه کړئ.
    /// د سیسټم رامینځته کونکي سیسټم چې د کمپیلر اجرا کوي به پوه شي چې متغیر د تالیف په جریان کې لاسرسی شوی و ، او د دې وړتیا به ولري چې بیا جوړونه بیا پیل کړي کله چې د دې تغیر ارزښت بدل شي.
    ///
    /// د انحصار تعقیب سربیره دا فنکشن باید د معیاري کتابتون څخه د `env::var` سره مساوي وي ، پرته لدې چې دلیل یې باید UTF-8 وي.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}