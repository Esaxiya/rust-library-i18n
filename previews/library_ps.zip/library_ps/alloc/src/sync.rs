#![stable(feature = "rust1", since = "1.0.0")]

//! د سلسلې خوندي حوالې-د رایو شمېرنې نښې.
//!
//! د نورو جزیاتو لپاره د [`Arc<T>`][Arc] اسناد وګورئ.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// د حوالې مقدار باندې نرم حد چې ممکن `Arc` ته رامینځته شي.
///
/// د دې حد څخه پورته لاړ به ستاسو برنامه لغوه کړي (که څه هم اړینه نه وي) د _exactly_ `MAX_REFCOUNT + 1` حواله کې.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// د ThreadSanitizer د حافظې fence ملاتړ نه کوي.
// په آرک/ضعیف پلي کولو کې د غلط مثبت راپورونو مخنیوي لپاره پرځای ترکیب لپاره اټومي بوټونه وکاروئ.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// د سلسلې خوندي حواله-د شمېرنې نښه.'Arc' د 'اتوماتیک حوالې شمار شوی' لپاره ولاړ دی.
///
/// د `Arc<T>` ډول د `T` ډول ارزښت مشترکه ملکیت چمتو کوي ، په ڈھیر کې تخصیص شوی.په `Arc` کې د [`clone`][clone] غوښتنه کول یو نوی `Arc` مثال رامینځته کوي ، کوم چې د سرچینې `Arc` په توګه په ورته برخه کې ورته تخصیص په ګوته کوي ، پداسې حال کې چې د حوالې شمیره ډیروي.
/// کله چې ورکړل شوې تخصیص ته د `Arc` وروستی نښه ویجاړ شي ، نو پدې تخصیص کې زیرمه شوي ارزښت (اکثرا د "inner value" په توګه ورته راجع کیږي) هم له مینځه وړل کیږي.
///
/// په Rust کې شریک شوي حوالې د ډیفالټ له مخې بدلون نه منع کوي ، او `Arc` هیڅ استثنا نلري: تاسو نشئ کولی په عموم ډول د `Arc` دننه کوم شی ته اړونده مبایل ترلاسه کړئ.که تاسو د `Arc` له لارې بدلون ته اړتیا لرئ ، نو [`Mutex`][mutex] ، [`RwLock`][rwlock] ، یا د [`Atomic`][atomic] ډولونو څخه یوه وکاروئ.
///
/// ## د مزي خوندیتوب
///
/// د [`Rc<T>`] په خلاف ، `Arc<T>` د دې مراجعې شمیرنې لپاره اټومي عملیات کاروي.دا پدې مانا ده چې دا د تار خوندي دی.زیان یې دا دی چې اټومي عملیات د عادي حافظې لاسرسي څخه ډیر قیمتي دي.که تاسو د سلسلو ترمینځ د حوالې-شمیرل شوي تخصیصونه شریک نه کوئ ، د ټیټ پوټکي لپاره د [`Rc<T>`] په کارولو غور وکړئ.
/// [`Rc<T>`] یو خوندي ډیفالټ دی ، ځکه چې تالیف کونکی به د موضوعاتو ترمینځ د [`Rc<T>`] لیږلو لپاره کومه هڅه ونیسي.
/// په هرصورت ، یو کتابتون ممکن د `Arc<T>` غوره کړي ترڅو د کتابتون مصرف کونکو ته ډیر نرمښت ورکړي.
///
/// `Arc<T>` [`Send`] او [`Sync`] به تر هغه وخته پلي کوي چې `T` [`Send`] او [`Sync`] تطبیق کړي.
/// ولې تاسو نشئ کولی د غیر تار-خوندي ډول `T` ډول په `Arc<T>` کې وساتئ ترڅو دا تار خوندي وساتي؟دا ممکن په لومړي سر کې یو څه متناقض وي: له هرڅه وروسته ، د `Arc<T>` سلسلې خوندیتوب نقطه نده؟کلیدي یې دا دي: `Arc<T>` دا د ورته معلوماتو ډیرو مالکیت لرلو لپاره توره خوندي کوي ، مګر دا په دې ډاټا کې د موضوع خوندیتوب نه اضافه کوي.
///
/// `آرک <` [`ریف سییل په پام کې ونیسئ<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] ندی ، او که `Arc<T>` تل [`Send`] و ، `آرک <` [`ریفسیکل<T>`]`>`به هم وی.
/// مګر بیا موږ ستونزه لرو:
/// [`RefCell<T>`] دا تار خوندي ندی؛دا د غیر اټومي عملیاتو په کارولو سره د پور اخیستنې حساب ساتي.
///
/// په پای کې ، دا پدې مانا ده چې تاسو ممکن د `Arc<T>` ډول سره د [`std::sync`] ډول سره مل کولو ته اړتیا ولرئ ، معمولا [`Mutex<T>`][mutex].
///
/// ## د `Weak` سره دورې ماتول
///
/// د [`downgrade`][downgrade] میتود د غیر مالکیت [`Weak`] پوائنټر رامینځته کولو لپاره کارول کیدی شي.د [`Weak`] پوائنټر کیدی شي [`اپ گریډین][اپ گریډ] d ته `Arc` ته ، مګر دا به [`None`] بیرته راشي که چیرې په تخصیص کې زیرمه شوي ارزښت دمخه راټیټ شوی وي.
/// په بل عبارت ، د `Weak` نښې د تخصیص دننه ارزښت ژوندی نه ساتي؛په هرصورت ، دوی * تخصیص (د ارزښت لپاره ملاتړ پلورنځي) ژوندي ساتي.
///
/// د `Arc` نښې ترمینځ یو دوره به هیڅکله له مینځه وی نه وړل شي.
/// د دې دلیل لپاره ، [`Weak`] د دوراناتو ماتولو لپاره کارول کیږي.د مثال په توګه ، یوه ونه کولی شي د مور او پلار نوډونو څخه `Arc` 1X قوي نښه ولري ، او د [`Weak`] نښې له ماشومانو څخه بیرته خپلو پلرونو ته.
///
/// # کلونونه حوالې
///
/// د موجود ریفرنس-شمیرل شوي اشارې څخه د نوي ریفرنس رامینځته کول د `Clone` trait په کارولو سره ترسره کیږي چې د [`Arc<T>`][Arc] او [`Weak<T>`][Weak] لپاره پلي شوي.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // لاندې دوه ترکیبونه مساوي دي.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a ، b ، او foo ټول آرکسونه دي چې ورته حافظې موقعیت ته په ګوته کوي
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` په اتوماتيک ډول `T` ته مراجعه وکړئ (د [`Deref`][deref] trait له لارې) ، نو تاسو کولی شئ د `Arc<T>` ډول په ارزښت د `T` میتودونه زنګ ووهئ.د `T` میتودونو سره د نوم نښتې مخنیوي لپاره ، د `Arc<T>` میتودونه پخپله اړوند وظایف دي ، چې د [fully qualified syntax] په کارولو سره بلل کیږي:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `آرک<T>د traits پلي کول لکه `Clone` ممکن د بشپړ کیفیت لرونکي ترکیب په کارولو سره هم وبلل شي.
/// ځینې خلک د بشپړ کیفیت لرونکي نحو کارولو ته ترجیح ورکوي ، پداسې حال کې چې نور د میتود کال ترکیب کارولو ته ترجیع ورکوي.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // د میتود کال تاکید
/// let arc2 = arc.clone();
/// // په بشپړ ډول وړ نحو
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] د `T` ته آټو-ډایریکریشن نه کوي ، ځکه چې داخلي ارزښت یې لا دمخه غورځول شوی و.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// د تارونو ترمینځ ځینې بې ثباته معلومات شریکول:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// په یاد ولرئ چې موږ ** دلته دا ازموینې نه کوو.
// د windows جوړونکي خورا ناراضه کیږي که چیرې یو تار عمده مزي وتړي او بیا په ورته وخت کې بهر شي (یو څه خنډونه) نو موږ یوازې د دې ازموینو په نه پلي کولو سره په بشپړ ډول دا مخنیوی کوو.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// د بدلون وړ [`AtomicUsize`] شریکول:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// په عمومي ډول د حوالې شمېرنې د نورو مثالونو لپاره [`rc` documentation][rc_examples] وګورئ.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` د [`Arc`] نسخه ده چې اداره شوي تخصیص ته غیر مالکیت حواله لري.
/// تخصیص د `Weak` پوائنټر کې د [`upgrade`] تلیفون کولو سره لاسرسی کیږي ، کوم چې [[اختیار`] returns <`[`آرک] returns بیرته راولي<T>>`.
///
/// لکه څنګه چې د `Weak` حواله د ملکیت په لور نه حسابیږي ، نو دا به په تخصیص کې زیرمه شوي ارزښت له مینځه وړو مخه ونه نیسي ، او پخپله `Weak` د هغه ارزښت په اړه تضمین نه کوي چې لاهم شتون لري.
///
/// پدې توګه دا ممکن [`None`] بیرته راشي کله چې [`اپ گریډ] d.
/// په هرصورت یادونه وکړئ چې د `Weak` حواله *کوي* پخپله د تخصیص مخه نیسي (د ملاتړ کولو پلورنځي) د ضعیف کیدو څخه.
///
/// د `Weak` پوائنټر د [`Arc`] لخوا اداره شوي تخصیص ته د لنډمهاله حوالې ساتلو لپاره ګټور دی پرته لدې چې خپل داخلي ارزښت له مینځه وړو مخه ونیسي.
/// دا د [`Arc`] نښې ترمینځ د سرکلیک حوالې مخه نیولو لپاره هم کارول کیږي ، ځکه چې د متقابل مالکیت حوالې به هیڅکله هم اجازه ورنکړي [`Arc`] له مینځه یوسي.
/// د مثال په توګه ، ونې کولی شي قوي [`Arc`] پوائنټرونه له والدینو نوډونو څخه ماشومانو ته ، او `Weak` نښې له ماشومانو څخه بیرته خپلو پلرونو ته.
///
/// د `Weak` پوائنټر ترلاسه کولو ځانګړې لاره د [`Arc::downgrade`] تلیفون کول دي.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // دا `NonNull` دی ترڅو په انیمونو کې د دې ډول اندازې مطلوب کولو ته اجازه ورکړي ، مګر دا لازمي معتبر نښې نلري.
    //
    // `Weak::new` دا `usize::MAX` ته ټاکي نو دا د دې لپاره چې په ڈھیر کې ځای ځانګړي کولو ته اړتیا ونلري.
    // دا یو ارزښت ندی چې ریښتیني نښه کونکی به یې هیڅکله ولري ځکه چې RcBox لږترلږه 2 سمون لري.
    // دا یوازې امکان لري کله چې `T: Sized`؛ناتوانه شوی `T` هیڅکله هم ځړوی.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// دا د احتمالي ساحې تنظیم کولو پروړاندې د repr(C) څخه future-پروف دی ، کوم چې به د لیږد وړ داخلي ډولونو خوندي [into|from]_raw() سره مداخله وکړي.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // د usize::MAX ارزښت د لنډ وخت لپاره د "locking" لپاره د لیږونکي په توګه کار کوي د ضعیف نقطو د لوړولو یا قوي اشخاصو د ښکته کولو وړتیا؛دا په `make_mut` او `get_mut` کې د ریسونو مخنیوي لپاره کارول کیږي.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// نوی `Arc<T>` جوړوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // د ضعیف پوائنټر شمیره د 1 په توګه پیل کړئ کوم چې هغه ضعیف پوینټر دی چې د ټولو قوي نښو (kinda) لخوا نیول شوی ، د نورو معلوماتو لپاره std/rc.rs وګورئ.
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// ځان ته د ضعیف حوالې په کارولو سره نوی `Arc<T>` جوړوي.
    /// د دې فعالیت بیرته راګرځیدو دمخه د ضعیف حوالې لوړولو هڅه به د `None` ارزښت پایله ولري.
    /// په هرصورت ، ضعیف حواله ممکن په آزاده توګه کلون شي او په وروسته وخت کې د کارولو لپاره زیرمه شي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // دننه د واحد ضعیف حوالې سره په "uninitialized" ایالت کې دننه جوړ کړئ.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // دا مهمه ده چې موږ د ضعیف اشاري مالکیت پریږدو ، یا نه نو حافظه ممکن د `data_fn` بیرته ستنیدو سره خلاص شي.
        // که موږ واقعیا د ملکیت تیریدو ته اړتیا درلودو ، نو موږ کولی شو د ځان لپاره یو اضافي ضعیف پوینټر رامینځته کړو ، مګر دا به د ضعیف حوالې شمیرو ته اضافي تازه معلومات رامینځته کړي چې ممکن بل ډول اړین نه وي.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // اوس موږ کولی شو داخلي ارزښت په سمه توګه پیل کړو او زموږ ضعیف حواله قوي ریفرنس ته واړوو.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // د معلوماتو ساحې ته پورته لیکل باید د هرې موضوعاتو لپاره د لیدو وړ وي چې د غیر صفر قوي حساب مشاهده کوي.
            // له همدې امله موږ لږترلږه "Release" ترتیب کولو ته اړتیا لرو ترڅو په `Weak::upgrade` کې د `compare_exchange_weak` سره ترکیب وکړئ.
            //
            // "Acquire" ترتیب ورکول اړین ندي.
            // کله چې د `data_fn` ممکنه چلند په پام کې ونیسو نو موږ یوازې دې ته اړتیا لرو چې هغه څه چې دا کولی شي د نه لوړولو وړ `Weak` حوالې سره ترسره کړي:
            //
            // - دا کولی شي د `Weak`*کلون* کړي ، د ضعیف حوالې شمیره لوړه کړي.
            // - دا کولی شي دا کلونونه وباسي ، د ضعیف حوالې شمیره کموي (مګر هیڅکله صفر ته نه وي).
            //
            // دا اړخیز تاثیرات موږ ته په هیڅ ډول تاثیر نه کوي ، او نور خوندي اړخونه یوازې د خوندي کوډ سره امکان نلري.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // قوي حوالې باید په ګډه د ګډ ضعیف حوالې مالکیت ولري ، نو زموږ د زاړه ضعیف حوالې لپاره تخریب کونکي نه چلوئ.
        //
        mem::forget(weak);
        strong
    }

    /// د بې بنسټه مینځپانګو سره نوی `Arc` جوړوي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// د ایکسینیمکس مینځپانګو سره نوی `Arc` جوړوي ، حافظه د `0` بایټونو سره ډکیږي.
    ///
    ///
    /// د دې میتود د درست او غلط استعمال مثالونو لپاره [`MaybeUninit::zeroed`][zeroed] وګورئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// نوی `Pin<Arc<T>>` جوړوي.
    /// که `T` `Unpin` نه تطبیقوي ، نو `data` به په حافظه کې ونښلول شي او د حرکت ورکولو توان به ونه لري.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// نوی `Arc<T>` جوړوي ، یوه تېروتنه راستنوي که تخصیص ناکام شي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // د ضعیف پوائنټر شمیره د 1 په توګه پیل کړئ کوم چې هغه ضعیف پوینټر دی چې د ټولو قوي نښو (kinda) لخوا نیول شوی ، د نورو معلوماتو لپاره std/rc.rs وګورئ.
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// د بې بنسټه مینځپانګو سره نوی `Arc` جوړوي ، یوه تېروتنه راستنوي که تخصیص ناکام شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// د ایکس ایکس ایکس ایکس بېټایټ شوي مینځپانګو سره نوی `Arc` رامینځته کوي ، د حافظې سره د `0` بایټونو ډک شوی ، غلطي بیرته راستنوي که تخصیص ناکام شي.
    ///
    ///
    /// د دې میتود د درست او غلط استعمال مثالونو لپاره [`MaybeUninit::zeroed`][zeroed] وګورئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// داخلي ارزښت بیرته راګرځوي ، که چیرې `Arc` په سمه توګه یو قوي حواله ولري.
    ///
    /// بلکه ، یو [`Err`] د ورته `Arc` سره راستون شوی چې دننه شوی و.
    ///
    ///
    /// دا به بریالي شي حتی که چیرې دلته ضعیف ضعیف حوالې شتون ولري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // د ضمیمه قوي-ضعیف حوالې پاکولو لپاره ضعیف اشاره وکړئ
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// د نه اټکل شوي مینځپانګو سره د اټمي پلوه نوي محاسبې ټوټه جوړوي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// د غیر اټکل شوي مینځپانګې سره نوي اتوماتيک حواله-شمیرل شوی سلیس رامینځته کوي ، د حافظې سره د `0` بایټونو ډک شوی.
    ///
    ///
    /// د دې میتود د درست او غلط استعمال مثالونو لپاره [`MaybeUninit::zeroed`][zeroed] وګورئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>` ته واړوئ.
    ///
    /// # Safety
    ///
    /// لکه څنګه چې د [`MaybeUninit::assume_init`] سره ، دا تلیفون کونکي پورې اړه لري ترڅو تضمین وکړي چې داخلي ارزښت واقعیا په ابتدایی حالت کې دی.
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د سمدستي نامعلومه چلند لامل کیږي.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>` ته واړوئ.
    ///
    /// # Safety
    ///
    /// لکه څنګه چې د [`MaybeUninit::assume_init`] سره ، دا تلیفون کونکي پورې اړه لري ترڅو تضمین وکړي چې داخلي ارزښت واقعیا په ابتدایی حالت کې دی.
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د سمدستي نامعلومه چلند لامل کیږي.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// د `Arc` مصرف کوي ، نغښتل شوی نښې بیرته راوړي.
    ///
    /// د حافظې لیکې څخه مخنیوي لپاره باید د [`Arc::from_raw`] په کارولو سره اشاره باید `Arc` ته بدل شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ډیټا ته خام نښې چمتو کوي.
    ///
    /// شمېرې په هیڅ ډول نه متاثره کیږي او د `Arc` مصرف نه کیږي.
    /// نښې تر هغه پورې د اعتبار وړ دي ترڅو چې په `Arc` کې قوي حسابونه شتون ولري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // خوندي: دا د Deref::deref یا RcBoxPtr::inner څخه نشي تیریدلی ځکه چې
        // دا د raw/mut پروانین ساتلو لپاره اړین دی لکه د مثال په توګه
        // `get_mut` د نښې له لارې لیکل کیدی شي وروسته له هغه چې Rc د `from_raw` له لارې ترلاسه کیږي.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// د خامو پوائنټر څخه `Arc<T>` جوړوي.
    ///
    /// خام نښې باید مخکې د [`Arc<U>::into_raw`][into_raw] ته د زنګ له لارې بیرته راستانه شوي وي چیرې چې `U` باید د `T` په څیر ورته اندازه او ساحه ولري.
    /// دا کوچني ریښتیا دي که `U` `T` وي.
    /// په یاد ولرئ چې که `U` `T` نه وي مګر ورته اندازه او ورته والی ولري ، دا اساسا د مختلف ډولونو حوالې لیږدولو په څیر دی.
    /// د نورو معلوماتو لپاره [`mem::transmute`][transmute] وګورئ چې پدې قضیه کې څه محدودیتونه پلي کیږي.
    ///
    /// د `from_raw` کارونکي باید ډاډ ترلاسه کړي چې د `T` مشخص ارزښت یوازې یو ځل راټیټ شوی.
    ///
    /// دا دنده غیر محفوظ ده ځکه چې ناسم کارول ممکن د حافظې بې باورۍ لامل شي ، حتی که بیرته راستانه شوي `Arc<T>` هیڅکله هم لاسرسی ونلري.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // د لیک د مخنیوي لپاره بیرته `Arc` ته واړوئ.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)` ته نور زنګونه به له حافظې خوندي نه وي.
    /// }
    ///
    /// // حافظه آزاده شوه کله چې `x` د پورتنۍ حوزې څخه بهر شو ، نو `x_ptr` اوس تنګ شوی!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // د اصلي آرک انیر موندلو لپاره له آفسیټ څخه بیرته وګرځئ.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// دې تخصیص لپاره نوی [`Weak`] پوائنټر رامینځته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // دا آرام دی ځکه چې موږ لاندې په CAS کې ارزښت ګورو.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // چیک کړئ که ضعیف معاون اوس مهال "locked" دی؛که داسې وي ، سپین یې کړئ.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: دا کوډ اوس مهال د ډیر جریان امکان له پامه غورځوي
            // په usize::MAX کې؛په عموم کې دواړه Rc او آرک باید د ډیر جریان سره معاملې لپاره تنظیم شي.
            //

            // د Clone() سره برعکس ، موږ دې ته اړتیا لرو چې د `is_unique` راوتلو لیکلو سره همغږي کولو لپاره د اکسیور لوستل ولرو ، نو د دې لیکلو دمخه پیښې د دې لوستلو دمخه پیښیږي.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ډاډ ترلاسه کړئ چې موږ ځوړند کمزوری نه جوړوو
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// دې اختصاصې ته د [`Weak`] نښو شمیره ترلاسه کوي.
    ///
    /// # Safety
    ///
    /// دا میتود پخپله خوندي دی ، مګر د دې په سمه توګه کارول اضافي پاملرنې ته اړتیا لري.
    /// بله موضوع کولی شي هر وخت ضعیف شمیره بدل کړي ، پشمول د دې میتود زنګ وهلو او پایله باندې عمل کولو تر مینځ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // دا تاکید ضد دی ځکه چې موږ د موضوعاتو تر مینځ `Arc` یا `Weak` نه دی شریک کړی.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // که چیرې ضعیف شمیره اوس مهال لاک شوې وي ، نو د شمیره ارزښت د لاک اخیستلو دمخه 0 و.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// دې تخصیص ته د قوي (`Arc`) نښو شمیره ترلاسه کوي.
    ///
    /// # Safety
    ///
    /// دا میتود پخپله خوندي دی ، مګر د دې په سمه توګه کارول اضافي پاملرنې ته اړتیا لري.
    /// بله موضوع کولی شي هر وخت قوي حساب بدل کړي ، په شمول د احتمالي توګه د دې میتود زنګ وهلو او پایله کې عمل کولو ترمنځ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // دا تاکید ضد دی ځکه چې موږ د موضوعاتو تر مینځ `Arc` نه دی شریک کړی.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// په `Arc<T>` پورې تړلي د حوالې قوي شمیره د یو لخوا چمتو شوي پوائنټر سره ډیروی.
    ///
    /// # Safety
    ///
    /// نښې باید د `Arc::into_raw` له لارې ترلاسه شوي وي ، او اړوند `Arc` بیلګه باید باوري وي (د بیلګې په توګه
    /// قوي شمیر باید لږترلږه 1 وي) د دې میتود موده لپاره.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // دا تاکید ضد دی ځکه چې موږ د موضوعاتو تر مینځ `Arc` نه دی شریک کړی.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // آرک وساتئ ، مګر په لاسي ډراپ کې ریپین کولو سره د حساب محاسبه مه کوئ
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // اوس د حساب محاسبه زیاته کړئ ، مګر نوې محاسبه هم مه پریږدئ
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// په `Arc<T>` کې د قوي حوالې شمیره د یو لخوا چمتو شوي نښې سره تړاو لري.
    ///
    /// # Safety
    ///
    /// نښې باید د `Arc::into_raw` له لارې ترلاسه شوي وي ، او اړوند `Arc` بیلګه باید باوري وي (د بیلګې په توګه
    /// قوي شمیره باید لږترلږه 1 وي) کله چې د دې میتود غوښتنه کوئ.
    /// دا میتود د وروستي `Arc` او ملاتړ کولو ذخیره کولو لپاره کارول کیدی شي ، مګر **باید** د وروستي `Arc` خوشې کیدو وروسته ونه بلل شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // دا ادعاوې ضد دي ځکه چې موږ د موضوعاتو تر مینځ `Arc` نه دی شریک کړی.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // دا بې باوري سمه ده ځکه چې پداسې حال کې چې دا آرک ژوندي دی موږ تضمین لرو چې داخلي نښې درست دي.
        // سربیره پردې ، موږ پوهیږو چې د `ArcInner` جوړښت پخپله د `Sync` دی ځکه چې داخلي معلومات هم `Sync` دي ، نو موږ ښه یو چې دې مینځپانګو ته بې عیب اشاره پور ورکړو.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // د `drop` غیر داخلي برخه.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // پدې وخت کې ډاټا ویجاړ کړئ ، که څه هم موږ ممکن پخپله د بکس تخصیص آزاد نه کړو (ممکن لاهم شاوخوا شاوخوا ضعیف ټکي وي).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // ضعیف ریف ډراپ کړئ په ګډه د ټولو قوي حوالې لخوا ساتل شوی
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` راستنوي که چیرې دوه `آرکز ورته ورته تخصیص ته اشاره وکړي (د [`ptr::eq`] په ورته رګ کې).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// د احتمالي-ناثبت داخلي ارزښت لپاره کافي ځای لپاره `ArcInner<T>` مختص کوي چیرې چې ارزښت ترتیب چمتو کړی.
    ///
    /// د `mem_to_arcinner` فنکشن د ډاټا پوائنټر سره بلل شوی او باید د `ArcInner<T>` لپاره بیرته (احتمالي غوړ)-پوینټر بیرته راشي.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // د ورکړل شوي ارزښت ترتیب په کارولو سره ترتیب محاسبه کړئ.
        // مخکې ، ترتیب د `&*(ptr as* const ArcInner<T>)` په بیان کې محاسبه شوی و ، مګر دا د غلط غلط حواله رامینځته کړی (د #54908 وګورئ).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// د احتمالي-غیر منقول داخلي ارزښت لپاره د کافي ځای لپاره `ArcInner<T>` مختص کوي چیرې چې ارزښت ترتیب چمتو کړی ، نو خطا بیرته راستنوي که تخصیص ناکام شي.
    ///
    ///
    /// د `mem_to_arcinner` فنکشن د ډاټا پوائنټر سره بلل شوی او باید د `ArcInner<T>` لپاره بیرته (احتمالي غوړ)-پوینټر بیرته راشي.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // د ورکړل شوي ارزښت ترتیب په کارولو سره ترتیب محاسبه کړئ.
        // مخکې ، ترتیب د `&*(ptr as* const ArcInner<T>)` په بیان کې محاسبه شوی و ، مګر دا د غلط غلط حواله رامینځته کړی (د #54908 وګورئ).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // د آرک اننر پیل کړئ
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// د غیر منل شوي داخلي ارزښت لپاره کافي ځای سره `ArcInner<T>` مختص کوي.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // د ورکړل شوي ارزښت په کارولو سره د `ArcInner<T>` لپاره تخصیص کړئ.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // د بایټونو په څیر ارزښت کاپي کړئ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // پرته له دې چې مینځپانګې راوباسي تخصیص وړیا کړئ
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// د ورکړل شوي اوږدوالي سره `ArcInner<[T]>` مختص کوي.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// عناصر له ټوټې څخه نوي مختص شوي آرک <\[T\]> ته کاپي کړئ
    ///
    /// غیر محفوظ ځکه چې زنګ وهونکی باید ملکیت واخلي یا `T: Copy` تړلی وي.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// د تکرار کونکي څخه `Arc<[T]>` جوړوي چې د ټاکلې اندازې څخه پیژندل شوی.
    ///
    /// چلند باید ټاکل شوی نه وي باید اندازه یې غلط وي.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic ساتونکی په داسې حال کې چې د T عناصر کلون کول.
        // د panic په پیښه کې ، هغه عناصر چې په نوي آرک انیر کې لیکل شوي وي به له مینځه ویسي ، بیا یې حافظه آزاده شي.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // لومړي عنصر ته نغدي
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ټول روښانه دي.ساتونکی هیر کړئ نو دا نوی آرک انیر نه آزادوي.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// د `From<&[T]>` لپاره کارول شوی تخصص trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// د `Arc` پوائنټر یو کلون جوړوي.
    ///
    /// دا ورته تخصیص ته بل نښې رامینځته کوي ، د قوي حوالې شمیره لوړه کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // د راحتي فرمایش کارول دلته سم دي ، ځکه چې د اصلي مآخذ په اړه پوهه د نورو تیروتونو څخه په غلط ډول د شیانو له مینځه ویستلو څخه مخنیوی کوي.
        //
        // لکه څنګه چې په [Boost documentation][1] کې تشریح شوی ، د مآخذ کاونټر ډیروالی تل د حافظې_ډیرلیکس سره ترسره کیدی شي: یوه شي ته نوي مآخذ یوازې له موجود مآخذ څخه رامینځته کیدلی شي ، او د یوې مآخذ څخه بلې ته د موجود حوالې لیږدول لا دمخه اړین ترکیب چمتو کوي.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // په هرصورت موږ اړتیا لرو که چیرې یو څوک: : میم:::هیرونکی هیرونکی وي نو د لوی حساب ورکولو څخه محافظت وکړو.
        // که موږ دا ونه کړو نو شمیرنه کولی شي جریان ولري او کارونکي به یې وروسته وړیا وکاروي.
        // موږ په دې ګومان سره د `isize::MAX` مطمئن یو چې د ~2 ملیارډ سلسلې شتون نلري چې په یوځل کې د حوالې شمیره ډیروي.
        //
        // دا branch به هیڅکله په ریښتیني برنامه کې ونه نیول شي.
        //
        // موږ له پامه غورځول شو ځکه چې دا ډول برنامه په لویه کچه له پامه غورځول کیږي ، او موږ یې ملاتړ ته پام نه کوو.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// ورکړل شوي `Arc` ته د تغیر وړ حواله ورکوي.
    ///
    /// که ورته ورته تخصیص ته نور `Arc` یا [`Weak`] نښې شتون ولري ، نو `make_mut` به نوی اختصاص رامینځته کړي او د داخلي ارزښت به [`clone`][clone] غوښتنه وکړي ترڅو د ځانګړي ملکیت ډاډ ترلاسه کړي.
    /// دې ته د کلون-آن لیکل هم ویل کیږي.
    ///
    /// په یاد ولرئ چې دا د [`Rc::make_mut`] له چلند سره توپیر لري کوم چې نور `Weak` نښې جلا کوي.
    ///
    /// [`get_mut`][get_mut] هم وګورئ ، کوم چې د کلینګ کولو پرځای به ناکام شي.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // هیڅ شی کلون نکوی
    /// let mut other_data = Arc::clone(&data); // داخلي ډاټا کلون نکوي
    /// *Arc::make_mut(&mut data) += 1;         // کلون داخلي معلومات
    /// *Arc::make_mut(&mut data) += 1;         // هیڅ شی کلون نکوی
    /// *Arc::make_mut(&mut other_data) *= 2;   // هیڅ شی کلون نکوی
    ///
    /// // اوس `data` او `other_data` مختلف تخصیصونو ته ګوته نیسي.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // په یاد ولرئ چې موږ دواړه قوي حواله او ضعیف حواله ساتو.
        // په دې توګه ، زموږ د قوي حوالې خوشې کول به یوازې پخپله د حافظې ضعیف کیدو لامل نه شي.
        //
        // د لاسته راوړنې څخه کار واخلئ ترڅو ډاډ ترلاسه کړئ چې موږ `weak` ته کوم لیکونه ګورو چې د خوشې کیدو دمخه پیښ کیږي `strong` ته.
        // لدې چې موږ ضعیف حساب لرو ، نو هیڅ امکان شتون نلري چې پخپله د آرک انیر له مینځه ویسي.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // بل غښتلی نښې شتون لري ، نو موږ باید کلون وکړو.
            // دمخه مختص شوي حافظه د کلون شوي ارزښت په مستقیم ډول د لیکلو اجازه.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // په پورتنۍ برخه کې آرامۍ درملنه ځکه چې دا اساسا یو مطلوب دی: موږ تل د ضعف نښې ایښودو سره سیالي کوو.
            // ترټولو خرابه قضیه ، موږ په غیر ضروري توګه یو نوی آرک تخصیص کړ.
            //

            // موږ وروستی قوي ریف لرې کړ ، مګر نور اضافي ضعیف ریفونه شتون لري.
            // موږ به مینځپانګې نوي آرک ته واړوو ، او نور ضعیف ریفیس به باطله کړو.
            //

            // په یاد ولرئ چې د `weak` لوستلو لپاره امکان نلري ترڅو usize::MAX ترلاسه کړي (د بیلګې په توګه ، لاک شوی) ، ځکه چې ضعیف شمیره یوازې د قوي حوالې سره د تار له لارې لاک کیدی شي.
            //
            //

            // زموږ خپل اختصاص ضعیف اشاري مادې کړئ ، ترڅو دا د اړتیا سره سم د آرک انیر پاک کړي.
            //
            let _weak = Weak { ptr: this.ptr };

            // کولی شي یوازې ډاټا غلا کړي ، هغه څه چې پاتې دي هغه کمزوري دي
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // موږ د هر ډول یوازینۍ مآخذ لرو.د قوي ریف شمېرنې ملاتړ کول.
            //
            this.inner().strong.store(1, Release);
        }

        // لکه څنګه چې د `get_mut()` سره ، بې باوري سمه ده ځکه چې زموږ حواله د پیل کولو لپاره یا هم ځانګړې وه ، یا د مینځپانګې کلونولو وروسته یو شو.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ورکړل شوي `Arc` ته د تغیر وړ حواله بیرته راګرځوي ، که ورته ورته تخصیص ته نور `Arc` یا [`Weak`] نښې شتون نلري.
    ///
    ///
    /// [`None`] راستنوي ، ځکه چې دا د شریک شوي ارزښت بدلولو لپاره خوندي ندي.
    ///
    /// [`make_mut`][make_mut] هم وګورئ ، کوم چې به داخلي ارزښت [`clone`][clone] وي کله چې نور نښې شتون ولري.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // دا بې اعتباره خبره سمه ده ځکه چې موږ تضمین لرو چې راوړل شوی پوائنټر یوازې *یوازې* نښې دي چې هیڅکله به T ته راستانه شي.
            // زموږ د حوالې شمیره پدې مرحله کې 1 تضمین کیږي ، او موږ پخپله د آرک اړتیا درلوده چې `mut` وي ، نو موږ داخلي معلوماتو ته یوازینۍ ممکنه حواله بیرته راستون کوو.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ورکړل شوي `Arc` ته د بدلون پرته حواله ، پرته له کوم چیک څخه راستنوي.
    ///
    /// [`get_mut`] هم وګورئ ، کوم چې خوندي دی او مناسب چیکونه کوي.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ورته ورته تخصیص ته کوم بل `Arc` یا [`Weak`] نښې باید د راستول شوي پور دورې لپاره درناوی ونلري.
    ///
    /// دا کوچني قضیه ده که چیرې داسې نښې شتون نلري ، د مثال په توګه سمدلاسه د `Arc::new` وروسته.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // موږ محتاط یو چې *د*"count" برخې پوښښ لپاره مآخذ رامینځته نکړو ، ځکه چې دا به د مآخذ شمیرو ته په ورته وخت سره لاسرسی ولري.
        // د `Weak` لخوا).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// معلومه کړئ چې ایا دا اصلي معلوماتو ته ځانګړي حواله ده (د ضعیف ریفونو په شمول).
    ///
    ///
    /// په یاد ولرئ چې دا د ضعیف ریفیر شمیره لاک کول غواړي.
    fn is_unique(&mut self) -> bool {
        // د ضعیف نقطه شمیره قلف کړئ که موږ داسې بریښي چې یوازینی ضعیف اشاره لرونکی لرو.
        //
        // د ترلاسه کولو لیبل دلته د `strong` (په ځانګړي ډول `Weak::upgrade` کې) ته د هر لیکلو سره د `weak` شمیره کمولو دمخه اړیکې تضمینوي (د `Weak::drop` له لارې ، چې خوشې یې کاروي).
        // که چیرې لوړ شوي ضعیف ریف هیڅکله ونه ایستل شي ، نو دلته کاس به ناکام شي نو موږ د همغږۍ کولو ته پام نه کوو.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // دا باید په `drop` کې د `strong` کاونټر کمولو سره همغږي کولو لپاره `Acquire` ته اړتیا وي-یوازینی لاسرسی هغه وخت پیښیږي کله چې یو مګر وروستی حواله پریښودل شي.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // د خوشې کیدو لیکنه دلته په `downgrade` کې د لوستلو سره همغږي کیږي ، په اغیزمنه توګه د `strong` پورته لوستل د لیکلو وروسته پیښ کیدو څخه مخنیوی کوي.
            //
            //
            self.inner().weak.store(1, Release); // لاک خوشې کړه
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// د `Arc` کمیدل.
    ///
    /// دا به د قوي حوالې شمیره راکمه کړي.
    /// که چیرې د قوي حوالې شمیره صفر ته ورسیږي نو یوازې نور ماخذونه (که کوم دي) [`Weak`] دي ، نو موږ داخلي ارزښت `drop` کوو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // هیڅ شی نه چاپ کوي
    /// drop(foo2);   // د "dropped!" چاپ
    /// ```
    #[inline]
    fn drop(&mut self) {
        // ځکه چې `fetch_sub` دمخه اټومي دی ، موږ اړتیا نلرو د نورو موضوعاتو سره همغږه شي ترڅو چې موږ دا شی حذف نه کړو.
        // دا ورته منطق د `weak` شمېرنې لاندې `fetch_sub` کې پلي کیږي.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // دا کنډک ته اړتیا لري ترڅو د ډاټا کارولو او ډیټا حذف کولو مخه ونیسي.
        // ځکه چې دا د `Release` نښه شوی ، د حوالې شمیره کمیدل د دې `Acquire` باڑ سره همغږي کیږي.
        // دا پدې مانا ده چې د معلوماتو کارول د حوالې شمیره کمولو دمخه پیښیږي ، کوم چې د دې کښت دمخه پیښیږي ، کوم چې د معلوماتو حذف کیدو دمخه پیښیږي.
        //
        // لکه څنګه چې په [Boost documentation][1] کې تشریح شوی ،
        //
        // > دا مهم دي چې په یوه کې اعتراض ته هر ممکنه لاسرسي پلي کړئ
        // > تار د (موجود حوالې له لارې) د *حذف کیدو دمخه* پیښ شي
        // > څیز په یو بل تار کې.دا د "release" لخوا ترلاسه شوی
        // > د حوالې غورځولو وروسته چلول (اعتراض ته کوم لاسرسی
        // > د دې مآخذ له لارې باید څرګنده توګه دمخه پیښ شي) ، او
        // > "acquire" د څیز له ړنګولو دمخه عملیات.
        //
        // په ځانګړي توګه ، پداسې حال کې چې د آرک مینځپانګه معمولا غیر عاجل دي ، دا امکان لري چې داخلي لیکنې د میټکس په څیر یو څه ته ولیکي<T>.
        // لکه څنګه چې یو Mutex نه دی ترلاسه شوی کله چې دا حذف شوی ، نو موږ نشو کولی د دې ترکیب کولو منطق باندې تکیه وکړو ترڅو په موضوع کې لیکنې وکړو A د تار په B کې روان ویستونکي ته د لیدو وړ وي.
        //
        //
        // دا هم په یاد ولرئ چې دلته د اکیوایر کڅوړه شاید د اکیور بار سره ځای په ځای شي ، کوم چې کولی شي په خورا اختلل شرایطو کې فعالیت ښه کړي.[2] وګورئ.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// د کانکریټ ډول ته د `Arc<dyn Any + Send + Sync>` ښکته کولو هڅه.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// نوی `Weak<T>` جوړوي ، پرته له کوم حافظې تخصیص.
    /// د بیرته ستنیدو ارزښت باندې [`upgrade`] زنګ وهل تل [`None`] ورکوي.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// د مرستندویه ډول د معلوماتو ډیټا ساحې په اړه هیڅ ادعا کولو پرته د حوالې شمیرې ته د لاسرسي اجازه ورکولو لپاره.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// د دې `Weak<T>` لخوا اشارې شوي ایکس X1X ایکس ته خام پوائنټر بیرته راګرځي.
    ///
    /// اشاره یوازې د اعتبار وړ ده که چیرې ځینې قوي حوالې شتون ولري.
    /// اشاره کیدی شي ځړول ، بې خطره او یا حتی [`null`] وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // دواړه ورته اعتراض ته اشاره کوي
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // پیاوړی دلته ژوندي ساتي ، نو موږ لاهم وکولی شو اعتراض ته لاسرسی ومومئ.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // مګر نور نه.
    /// // موږ کولی شو weak.as_ptr() ترسره کړو ، مګر پوائنټر ته لاسرسی به د نامعلومه چلند لامل شي.
    /// // assert_eq! ("سلام" ، غیر خوندي {&*weak.as_ptr() })؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // که چیرې اشاره جګه وي ، نو موږ لیږل شوي مستقیم بیرته راستون کوو.
            // دا د تادیاتو معتبر پته نشي کیدی ، ځکه چې تادیه لږترلږه د آرک انیر (usize) په څیر تنظیم شوې وي.
            ptr as *const T
        } else {
            // خوندي: که is_dangling غلط راګرځي ، نو بیا اشاره د درک وړ ده.
            // د تادیاتو بیه کیدی شي پدې مرحله کې راکښته شي ، او موږ باید مخ پروړاندې وساتو نو له دې امله د خام نقطې لاسوهنه کاروئ.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// د `Weak<T>` مصرف کوي او دا په خام پوائنټر بدلوي.
    ///
    /// دا ضعیف اشاره په خام نقطه بدلوي ، پداسې حال کې چې لاهم د یوې ضعیف حوالې مالکیت ساتل کیږي (ضعیف شمیره د دې عملیاتو لخوا نه بدله کیږي).
    /// دا د [`from_raw`] سره بیرته `Weak<T>` ته بدلیدلی شي.
    ///
    /// د [`as_ptr`] په څیر د اشارې هدف ته رسیدو ورته محدودیتونه پلي کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// د [`into_raw`] لخوا رامینځته شوی خام نښې بیرته `Weak<T>` ته بدلوي.
    ///
    /// دا کولی شي په خوندي ډول د قوي حوالې ترلاسه کولو لپاره وکارول شي (وروسته د [`upgrade`] تلیفون کولو سره) یا د `Weak<T>` په غورځولو سره ضعیف شمیره ضایع کول.
    ///
    /// دا د یوې ضعیف حوالې ملکیت اخلي (د [`new`] لخوا رامینځته شوي نښو څخه استثنا سره ، ځکه چې دا هیڅ شی نلري the میتود لاهم په دوی کار کوي).
    ///
    /// # Safety
    ///
    /// نښې باید د [`into_raw`] څخه رامینځته شوي وي او لاهم باید د هغې احتمالي ضعیف حواله ولري.
    ///
    /// دا د دې زنګ وهلو په وخت کې د قوي شمیر 0 لپاره اجازه لري.
    /// په هرصورت ، دا د یوې ضعیف حوالې ملکیت اخلي چې دا مهال د خامو اشارې په توګه نمایش شوي (ضعیف شمیره د دې عملیاتو لخوا نه بدله شوې) او له همدې امله دا باید [`into_raw`] ته د تیر کال سره جوړه شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // وروستی ضعیف شمیره کمه کړئ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // د مقالې لپاره Weak::as_ptr وګورئ چې د ان پیوینټر پوینټر څنګه ترلاسه کیږي.

        let ptr = if is_dangling(ptr as *mut T) {
            // دا ځورونکی ضعیف دی.
            ptr as *mut ArcInner<T>
        } else {
            // که نه نو ، موږ تضمین یو چې اشاره د نونډنګل کمزوري څخه راغله.
            // خوندي: د Data_offset د زنګ وهلو لپاره خوندي دی ، ځکه چې ptr ریښتیني (احتمالي غورځول شوی) T ته اشاره کوي.
            let offset = unsafe { data_offset(ptr) };
            // په دې توګه ، موږ د بشپړ RcBox ترلاسه کولو لپاره آفسیټ بیرته راولو.
            // خوندي: نښې له ضعیف څخه پیدا شوې ، نو له همدې امله دغه آفسیټ خوندي دی.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // خوندي: موږ اوس د اصلي ضعف نښې موندلي ، نو کولی شو ضعیف رامینځته کړي.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// د `Weak` نښې ته [`Arc`] ته لوړولو هڅې ، د داخلي ارزښت غورځېدو ځنډول که بریالي وي.
    ///
    ///
    /// [`None`] راستنوي که چیرې داخلي ارزښت له هغه وخته راښکته شي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ټول قوي نښې له منځه وړي.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // موږ د فیچ_ډیډ پرځای قوي شمیرې ته وده ورکولو لپاره د CAS لوپ کاروو ځکه چې دا فنکشن باید هیڅکله د حوالې شمیره له صفر څخه یوې ته ونه رسوي.
        //
        //
        let inner = self.inner()?;

        // آرام شوی بار ځکه چې د 0 هره لیکنه چې موږ یې لیدلی شو ساحه د تل لپاره صفر حالت کې پریږدو (نو د 0 "stale" X لوستل ښه دي) ، او نور کوم ارزښت د لاندې CAS له لارې تایید شوی.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // په `Arc::clone` کې نظرونه وګورئ چې ولې موږ دا کوو (د `mem::forget` لپاره).
            if n > MAX_REFCOUNT {
                abort();
            }

            // آرام د ناکامۍ قضیې لپاره ښه دی ځکه چې موږ د نوي دولت په اړه هیڅ تمه نلرو.
            // د `Arc::new_cyclic` سره همغږي کولو لپاره د بریا قضیې لپاره لاسته راوړل اړین دي ، کله چې داخلي ارزښت د `Weak` حوالې دمخه رامینځته کیدو وروسته پیل کیدی شي.
            // پدې حالت کې ، موږ تمه لرو چې بشپړ پیل شوي ارزښت وڅارو.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // ځنډول شوی
                Err(old) => n = old,
            }
        }
    }

    /// دې اختصاص ته په ګوته شوي د قوي (`Arc`) نښو شمیره ترلاسه کوي.
    ///
    /// که `self` د [`Weak::new`] په کارولو سره رامینځته شوی وي ، دا به 0 بیرته راشي.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// دې اختصاص ته په ګوته شوي د `Weak` نښو شمیر نږدې نږدې ترلاسه کوي.
    ///
    /// که `self` د [`Weak::new`] په کارولو سره رامینځته شوی ، یا که نور قوي نښې شتون نلري ، دا به 0 بیرته راشي.
    ///
    /// # Accuracy
    ///
    /// د پلي کولو توضیحاتو له امله ، بیرته ورکړل شوي ارزښت د 1 لخوا په دواړو لوریو کې بند کیدی شي کله چې نور موضوعات ورته ation آرکز یا `ضعیفونه ورته تخصیص ته په ګوته کوي.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // لکه څنګه چې موږ ولیدل چې د ضعیف حساب لوستلو وروسته لږترلږه یو قوي نښه کونکی شتون درلود ، موږ پوهیږو چې ضمني ضعیف حواله (شتون لري کله چې کوم قوي حواله ژوندی وي) لاهم شاوخوا وه کله چې موږ ضعیف شمیره مشاهده کړې ، او له دې امله یې په خوندي ډول منفي کولی شو.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// `None` بیرته راګرځی کله چې پوائنټر ځړول شوی وي او هیڅ `ArcInner` تخصیص نه وي ، (د مثال په توګه ، کله چې دا `Weak` د `Weak::new` لخوا رامینځته شوی و).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // موږ محتاط یو چې *د*"data" ساحې پوښاک لپاره ریفرنس رامینځته نکړو ، ځکه چې ساحه په ورته وخت کې بدلیدلی شي (د مثال په توګه ، که وروستی `Arc` راټیټ شي ، د معلوماتو ساحه به په ځای کې پریښودل شي).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` راګرځوي که چیرې دوه `ضعیف عین تخصیص ته اشاره وکړي ([`ptr::eq`] ته ورته) ، یا که دواړه هیڅ تخصیص ته اشاره نکړي (ځکه چې دا د `Weak::new()`) سره رامینځته شوي.
    ///
    ///
    /// # Notes
    ///
    /// له دې چې دا نښو سره پرتله کوي پدې معنی چې `Weak::new()` به یو بل سره مساوي کړي ، که څه هم دوی هیڅ تخصیص ته اشاره نه کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// د `Weak::new` پرتله کول.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// د `Weak` پوائنټر کلون جوړوي چې ورته ورته تخصیص ته په ګوته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // په Arc::clone() کې نظرونه وګورئ چې ولې دا آرام دی.
        // دا کولی شي fetch_add وکاروي (د قفل په پام کې نیولو سره) ځکه چې ضعیف شمیره یوازې لاک شوې وي چیرې چې *شتون نلري بل کوم* ضعیف نښې دي.
        //
        // (نو موږ نشو کولی پدې کوډ کې دا کوډ پرمخ وړو).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // په Arc::clone() کې نظرونه وګورئ چې ولې موږ دا کوو (د mem::forget لپاره).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// د حافظې مختص کولو پرته ، نوی `Weak<T>` جوړوي.
    /// د بیرته ستنیدو ارزښت باندې [`upgrade`] زنګ وهل تل [`None`] ورکوي.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// د `Weak` نښې غورځوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // هیڅ شی نه چاپ کوي
    /// drop(foo);        // د "dropped!" چاپ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // که موږ پوهه شو چې موږ وروستی ضعیف پواینټ وو ، نو د دې وخت دی چې په بشپړ ډول د ډیټا ګوښه کړو.د حافظې ترتیباتو په اړه په Arc::drop() کې بحث وګورئ
        //
        // دلته د بند شوي حالت لپاره چک کول اړین ندي ، ځکه چې ضعیف شمیره یوازې هغه وخت لاک کیدلی شي که چیرې دقیقا یو ضعیف ریف شتون ولري ، پدې معنی چې ډراپ یوازې وروسته پاتې کیدلی ضعیف ریف باندې کیدی شي ، کوم چې یوازې د لاک خوشې کیدو وروسته پیښ کیدی شي.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// موږ دا تخصص دلته کوو ، او نه په `&T` باندې د عمومي اصلاح په توګه ، ځکه چې دا به نور په ریفس کې د ټولو مساواتو چیکونو کې لګښت اضافه کړي.
/// موږ فرض کوو چې `آرکز د لوی ارزښتونو ذخیره کولو لپاره کارول کیږي ، کوم چې کلون کول ورو دي ، مګر د مساواتو لپاره چک کول هم دروند دي ، د دې المل کیږي چې دا لګښت په اسانۍ سره تادیه کړي.
///
/// دا هم احتمال لري چې د دوه `Arc` کلونونه ولرئ ، چې ورته ارزښت ته په ګوته کوي ، د دوه than&T`s څخه.
///
/// موږ دا یوازې هغه وخت کولی شو کله چې `T: Eq` د `PartialEq` په توګه ممکن په قصدي توګه غیر معقول وي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// د دوه `آرکز لپاره مساوات.
    ///
    /// دوه `آرکونه مساوي دي که چیرې د دوی داخلي ارزښتونه مساوي وي ، حتی که دوی په مختلف تخصیص کې زیرمه شوي وي.
    ///
    /// که چیرې `T` هم د `Eq` تطبیق کړي (د مساواتو انعطاف منونکي اغیزه کوي) ، دوه `آرکز چې ورته ورته تخصیص ته اشاره کوي تل مساوي وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// د دوه `آرکز لپاره مساوات.
    ///
    /// دوه `آرکونه مساوي ندي که چیرې د دوی داخلي ارزښتونه مساوي نه وي.
    ///
    /// که چیرې `T` هم د `Eq` تطبیق کړي (د مساواتو انعطاف منونکي اغیزه کوي) ، دوه `آرکز چې ورته ارزښت ته اشاره کوي هیڅکله غیر مساوي ندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// د دوه `آرکز لپاره جزوي پرتله کول.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `partial_cmp()` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// د دوه `آرکز لپاره پرتله کولو څخه کم.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `<` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// د دوه `آرکز لپاره پرتله کولو څخه 'مساوي یا مساوي'.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `<=` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// د دوه `آرکز لپاره لوی پرتله.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `>` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// د دوه `آرکز لپاره پرتله کولو څخه لوی یا مساوي.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `>=` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// د دوه `آرکز لپاره پرتله کول.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `cmp()` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// د `T` لپاره د `Default` ارزښت سره نوی `Arc<T>` رامینځته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// د یوې حوالې محاسب شوي سلایټ تنظیم کړئ او د توکو په کلون کولو سره ډک کړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// د یوې مراجعې حساب شوي `str` تخصیص کړئ او په دې کې `v` کاپي کړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// د یوې مراجعې حساب شوي `str` تخصیص کړئ او په دې کې `v` کاپي کړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// یو بکس شوی څیز ته نوي ، د حوالې څخه شمیرل شوي تخصیص ته حرکت ورکړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// د یوې حوالې-شمیرل شوي سلایټونو تنظیم او د هغې مینځلو ته ورته شی.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // ویک ته اجازه ورکړئ چې خپل حافظه خالي کړي ، مګر مینځپانګې یې له مینځه نه وړي
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// په `Iterator` کې هر عنصر اخلي او دا په `Arc<[T]>` کې راټولوي.
    ///
    /// # د فعالیت ځانګړتیاوې
    ///
    /// ## عمومي قضیه
    ///
    /// په عمومي حالت کې ، په `Arc<[T]>` کې راټولول لومړی په `Vec<T>` کې راټولولو لخوا ترسره کیږي.همدا ده ، کله چې لاندې لیکنې:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// دا داسې چلند کوي لکه څنګه چې موږ لیکلي:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // د تخصیصونو لومړۍ سیټ دلته پیښیږي.
    ///     .into(); // د `Arc<[T]>` لپاره دویم تخصیص دلته واقع کیږي.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// دا به د `Vec<T>` رامینځته کولو لپاره ورته اړتیا ډیری وختونه تخصیص کړي او بیا به دا د `Vec<T>` په `Arc<[T]>` کې بدلولو لپاره یوځل مختص کړي.
    ///
    ///
    /// ## د پیژندل شوی اوږدوالي میترونه
    ///
    /// کله چې ستاسو `Iterator` `TrustedLen` پلي کوي او د دقیق اندازې څخه وي ، نو د `Arc<[T]>` لپاره به یو واحد تخصیص ورکړل شي.د مثال په توګه:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // یوازې یو تخصیص دلته واقع کیږي.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// د `Arc<[T]>` کې راټولولو لپاره تخصص trait کارول شوی.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // دا د `TrustedLen` تکرار لپاره قضیه ده.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // خوندي: موږ اړتیا لرو ډاډ ترلاسه کړو چې تکرار کونکی دقیق اوږدوالی لري او موږ یې لرو.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // نورمال پلي کیدو ته بیرته ستنیدل.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// د نښې تر شا د تادیې لپاره په `ArcInner` کې آفسیټ ترلاسه کړئ.
///
/// # Safety
///
/// اشاره کونکی باید په نښه کړي (او د اعتبار وړ میټاټا ولري) د T پخوانی معتبر مثال دی ، مګر T اجازه لري چې پریښودل شي.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // د آرکی اننر پای ته بې ثباتي ارزښت سم کړئ.
    // ځکه چې RcBox repr(C) دی ، دا به په یاد کې تل وروستی ډګر وي.
    // خوندي: ځکه چې یوازې نا تایید شوي ډولونه یې ممکن ټوټې دي ، trait څیزونه ،
    // او خارجي ډولونه ، د داخلي خوندیتوب اړتیا اوس مهال د align_of_val_raw اړتیاو پوره کولو لپاره کافي ده؛دا د ژبې پلي کولو تفصیل دی چې ممکن د std څخه بهر تکیه ونلري.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}