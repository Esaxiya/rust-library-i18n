//! د حافظې تخصیص API

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // دا د جادو سمبولونه دي چې د نړۍ مختصونکي یې بولي.rustc دوی تولیدوي ترڅو د `__rg_alloc` وغیرہ غږ وکړي.
    // که چیرې د `#[global_allocator]` خاصیت شتون ولري (د کوډ پراخول چې انتصابي میکرو دا افعال رامینځته کوي) ، یا په لیبسټډ کې د ډیفالټ پلي کولو غږ کول (`__rdl_alloc` وغيره.
    //
    // په بل ډول.
    // د LLVM rustc fork هم د ځانګړو قضیو نومونه د دې فعالیت نومونه د دې وړ دي ترڅو دوی په ترتیب سره د `malloc` ، `realloc` ، او `free` اصلاح کړي.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// د نړیوال حافظې تخصیص کونکی.
///
/// دا ډول د X0 `#[global_allocator]` منسوب سره راجستر شوي تخصیص کونکي ته د تلیفونونو لیږلو سره د [`Allocator`] trait پلي کوي که چیرې یو شتون ولري ، یا د `std` crate اصلي.
///
///
/// Note: پداسې حال کې چې دا ډول بې ثباته دی ، هغه فعالیت چې دا یې چمتو کوي د [free functions in `alloc`](self#functions) له لارې لاسرسی کیدی شي.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// د نړیوال تخصیص کونکي سره حافظه مختص کړئ.
///
/// دا فنکشن د X0 `#[global_allocator]` صفت سره ثبت شوي تخصیص کونکي [`GlobalAlloc::alloc`] میتود ته لیږل کوي که چیرې یو شتون ولري ، یا د `std` crate اصلي.
///
///
/// دا فنکشن تمه کیږي چې د [`Global`] ډول ډول `alloc` میتود کې تخفیف شي کله چې دا او د [`Allocator`] trait مستحکم شي.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] وګورئ.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// د نړیوال تخصیص کونکي سره حافظه ضایع کړئ.
///
/// دا فنکشن د X0 `#[global_allocator]` صفت سره ثبت شوي تخصیص کونکي [`GlobalAlloc::dealloc`] میتود ته لیږل کوي که چیرې یو شتون ولري ، یا د `std` crate اصلي.
///
///
/// دا فنکشن تمه کیږي چې د [`Global`] ډول ډول `dealloc` میتود کې تخفیف شي کله چې دا او د [`Allocator`] trait مستحکم شي.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] وګورئ.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// د نړیوال تخصیص کونکي سره یادداشت له سره وټاکئ.
///
/// دا فنکشن د X0 `#[global_allocator]` صفت سره ثبت شوي تخصیص کونکي [`GlobalAlloc::realloc`] میتود ته لیږل کوي که چیرې یو شتون ولري ، یا د `std` crate اصلي.
///
///
/// دا فنکشن تمه کیږي چې د [`Global`] ډول ډول `realloc` میتود کې تخفیف شي کله چې دا او د [`Allocator`] trait مستحکم شي.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] وګورئ.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// د نړیوال تخصیص کونکي سره د صفر پیل شوي حافظه مختص کړئ.
///
/// دا فنکشن د X0 `#[global_allocator]` صفت سره ثبت شوي تخصیص کونکي [`GlobalAlloc::alloc_zeroed`] میتود ته لیږل کوي که چیرې یو شتون ولري ، یا د `std` crate اصلي.
///
///
/// دا فنکشن تمه کیږي چې د [`Global`] ډول ډول `alloc_zeroed` میتود کې تخفیف شي کله چې دا او د [`Allocator`] trait مستحکم شي.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] وګورئ.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // خوندي: `layout` په صفر کې غیر صفر دی ،
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // خوندي: د `Allocator::grow` په څیر ورته
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // خوندي: `new_size` غیر صفر دی ځکه چې `old_size` د `new_size` څخه لوی یا مساوي دی
            // لکه څنګه چې د خوندیتوب شرایطو لخوا اړین دی.نور شرایط باید د تلیفون کونکي لخوا وساتل شي
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` شاید د `new_size >= old_layout.size()` یا ورته ورته شی لپاره ګوري.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // خوندي: ځکه چې `new_layout.size()` باید د `old_size` څخه لوی وي یا مساوي وي ،
            // د زاړه او نوي حافظې تخصیص دواړه د `old_size` بیتونو لپاره د لوستلو او لیکلو لپاره معتبر دي.
            // همچنان ، ځکه چې زاړه تخصیص لاهم ضایع شوی نه و ، نو دا نشي کولی `new_ptr` پراخه کړي.
            // پدې توګه ، `copy_nonoverlapping` ته زنګ خوندي دی.
            // د `dealloc` لپاره د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // خوندي: `layout` په صفر کې غیر صفر دی ،
            // نور شرایط باید د زنګ وهونکي لخوا ملاتړ وشي
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // خوندي: ټول شرایط باید د زنګ وهونکي لخوا ملاتړ وشي
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // خوندي: ټول شرایط باید د زنګ وهونکي لخوا ملاتړ وشي
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // خوندي: شرایط باید د زنګ وهونکي لخوا ملاتړ وشي
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // خوندي: `new_size` غیر صفر دی.نور شرایط باید د تلیفون کونکي لخوا وساتل شي
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` شاید د `new_size <= old_layout.size()` یا ورته ورته شی لپاره ګوري.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // خوندي: ځکه چې `new_size` باید د `old_layout.size()` سره کوچنی وي یا مساوي وي ،
            // د زاړه او نوي حافظې تخصیص دواړه د `new_size` بیتونو لپاره د لوستلو او لیکلو لپاره معتبر دي.
            // همچنان ، ځکه چې زاړه تخصیص لاهم ضایع شوی نه و ، نو دا نشي کولی `new_ptr` پراخه کړي.
            // پدې توګه ، `copy_nonoverlapping` ته زنګ خوندي دی.
            // د `dealloc` لپاره د خوندیتوب قرارداد باید د زنګ وهونکي لخوا ملاتړ وشي.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// د ځانګړي نښو لپاره تخصیص.
// دا فنکشن باید نه مني.که دا وکړي ، د MIR کوډګین به ناکام شي.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// دا لاسلیک باید د `Box` په شان وي ، که نه نو ICE به پیښ شي.
// کله چې `Box` ته اضافي پیرامیټر اضافه شي (د `A: Allocator` په څیر) ، دا باید دلته هم اضافه شي.
// د مثال په توګه که `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ته بدل شي ، نو دا فنکشن باید `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ته هم بدل شي.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # د تخصيص غلطي سمبالوونکی

extern "Rust" {
    // دا د جادو سمبول دی چې د نړیوال تخصیص غلطي اداره کونکي ته زنګ ووهي.
    // rustc دا تولیدوي ترڅو د `__rg_oom` تلیفون وکړي که چیرې یو `#[alloc_error_handler]` شتون ولري ، یا بل ډول د (`__rdl_oom`) لاندې ډیفالټ پلي کونکي غږولو لپاره.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// د حافظې تخصیص تېروتنه یا ناکامي بندول.
///
/// د حافظې تخصیص API تلیفون کونکي چې د تخصیص غلطي په ځواب کې د کمپیوټري ضایع کیدو غوښتونکي وي د دې فعالیت په اړه زنګ وهلو ته هڅول کیږي ، د دې پرځای چې په مستقیم ډول `panic!` یا ورته غوښتنه وکړي.
///
///
/// د دې فنلیک اصلي چلند معیاري تېروتنې ته د پیغام چاپ کول او پروسه ضایع کول دي.
/// دا د [`set_alloc_error_hook`] او [`take_alloc_error_hook`] سره ځای په ځای کیدی شي.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// د تخصیص ازمونې لپاره `std::alloc::handle_alloc_error` مستقیم کارول کیدی شي.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // د تولید شوي `__rust_alloc_error_handler` له لارې نومول شوی

    // که `#[alloc_error_handler]` شتون نلري
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // که چیرې `#[alloc_error_handler]` وي
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// مخکینی ټاکل شوي ، بې بنسټه یادونې ته کلونونه تخصص کړئ.
/// د `Box::clone` او `Rc`/`Arc::make_mut` لخوا کارول شوی.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // د *لومړي* تخصیص ورکول ممکن مطلوب ته اجازه ورکړي چې ځای په ځای کلون شوی ارزښت رامینځته کړي ، ځایی پریښودل او حرکت.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // موږ کولی شو تل په ځای کې کاپي ، پرته له دې چې هیڅکله د ځایي ارزښت ښکیلتیا.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}