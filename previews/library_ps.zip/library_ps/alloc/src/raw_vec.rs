#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// د نوې حافظې مینځپانګې بې بنسټه دي.
    Uninitialized,
    /// نوی حافظه د صفر کیدو تضمین لري.
    Zeroed,
}

/// د ډیر ارګونومیک پلوه تخصیص ، بیا تنظیم کول ، او په حافظه کې د حافظې بفر ضایع کولو لپاره د ټیټ کچې کارونې پرته له دې چې پکې ښکیل ټولې کونج قضیې اندیښنه ولري.
///
/// دا ډول ستاسو د ډیټا جوړښتونو لکه Vec او VecDeque جوړولو لپاره عالي دی.
/// په تېره بیا:
///
/// * د صفر اندازې ډولونو باندې `Unique::dangling()` تولید کوي.
/// * د صفر-اوږدوالي تخصیصونو کې `Unique::dangling()` تولید کوي.
/// * د `Unique::dangling()` آزادولو څخه ډډه وکړئ.
/// * د ظرفیت کمپیوټونو کې ټول جریان نیول (دوی ته "capacity overflow" panics ته وده ورکوي).
/// * د 32 بټ سیسټمونو پروړاندې ساتونکي له isize::MAX بایټونو څخه ډیر تخصیص ورکوي.
/// * ستاسو د اوږدوالي د ډیرولو پروړاندې ساتونکي.
/// * د پام وړ تخصیصونو لپاره `handle_alloc_error` تلیفون وکړئ.
/// * یو `ptr::Unique` لري او پدې توګه کارونکي د ټولو اړوند ګټو سره پای ته رسوي.
/// * ترټولو لوی موجود ظرفیت کارولو لپاره له تخصیص کونکي څخه بیرته راستنیدونکي اضافي کارول.
///
/// دا ډول په هرصورت د حافظې معاینه نه کوي چې دا اداره کوي.کله چې غورځول شوی وي *دا به خپل حافظه خالي کړي ، مګر دا* به هڅه ونه کړي چې خپل مینځپانګه پریږدي.
/// دا د `RawVec` کارونکي پورې اړه لري ترڅو د `RawVec` دننه *خوندي شوي* اصلي شیان اداره کړي.
///
/// په یاد ولرئ چې د صفر اندازې ډولونو څخه زیات تل تل کافي وي ، نو ځکه `capacity()` تل `usize::MAX` بیرته راولي.
/// د دې معنی دا ده چې تاسو اړتیا لرئ محتاط اوسئ کله چې دا ډول د `Box<[T]>` سره وپیژنئ ، ځکه چې `capacity()` اوږدوالی به ترلاسه نکړي.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): دا شتون لري ځکه چې `#[unstable]` `const fn`s د `min_const_fn` مطابق ندي او پدې توګه دوی په`min_const_fn`s کې هم نشي زنګولی.
    ///
    /// که تاسو `RawVec<T>::new` یا انحصار بدل کړئ ، نو مهرباني وکړئ پاملرنه وکړئ داسې کوم شی معرفي نه کړئ چې واقعیا د `min_const_fn` سرغړونه وکړي.
    ///
    /// NOTE: موږ کولی شو له دې هیک څخه مخنیوی وکړو او د ځینې `#[rustc_force_min_const_fn]` انتصاب سره همغږۍ چیک کړو کوم چې د `min_const_fn` سره همغږي ته اړتیا لري مګر په `stable(...) const fn`/د کارونکي کوډ کې زنګ وهلو ته اجازه مه ورکوئ کله چې `#[rustc_const_unstable(feature = "foo", issue = "01234")]` شتون ولري.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// پرته له تخصیص څخه ترټولو لوی ممکنه `RawVec` (د سیسټم په جریان کې) رامینځته کوي.
    /// که `T` مثبت اندازه ولري ، نو دا د `0` ظرفیت سره `RawVec` جوړوي.
    /// که `T` د صفر اندازې وي ، نو دا د `usize::MAX` ظرفیت سره `RawVec` جوړوي.
    /// د ځنډ تخصیص پلي کولو لپاره ګټور.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// د `[T; capacity]` لپاره د وړتیا او سمون اړتیاو سره د `RawVec` (د سیسټم په ګیر کې) رامینځته کوي.
    /// دا د `RawVec::new` تلیفون کولو سره برابر دی کله چې `capacity` د `0` وي یا `T` د صفر اندازې وي.
    /// په یاد ولرئ که چیرې `T` صفر شی دی نو پدې معنی چې تاسو به * د غوښتل شوي ظرفیت سره `RawVec` ترلاسه نکړئ.
    ///
    /// # Panics
    ///
    /// Panics که د غوښتل شوي ظرفیت له `isize::MAX` بایټ څخه ډیر شي.
    ///
    /// # Aborts
    ///
    /// په OOM کې بندیزونه.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// د `with_capacity` په څیر ، مګر تضمین د بفر صفر دی.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// د پوائنټر او ظرفیت څخه `RawVec` بیا تنظیم کوي.
    ///
    /// # Safety
    ///
    /// د `ptr` باید تخصیص شي (د سیسټم په برخه کې) ، او ورکړل شوي `capacity` سره.
    /// د `capacity` د اندازو ډولونو لپاره د `isize::MAX` څخه ډیر نشي.(یوازې په 32 بټ سیسټمونو اندیښنه).
    /// ZST vectors ممکن د `usize::MAX` پورې ظرفیت ولري.
    /// که `ptr` او `capacity` د `RawVec` څخه راشي ، نو دا تضمین دی.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // کوچني ویسونه بې واره دي.دې ته ورشئ:
    // - 8 که د عنصر اندازه 1 وي ، ځکه چې د هیپ تخصیص کونکي ممکن د 8 بایټ څخه لږترلږه 8 بایټ غوښتنه وغواړي.
    //
    // - 4 که چیرې عناصر متوسطې اندازې وي (<=1 KiB).
    // - 1 نه ، د خورا لنډ Vecs لپاره د ډیر ځای ضایع کیدو مخنیوي لپاره.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// د `new` په څیر ، مګر د بیرته راستن شوي `RawVec` لپاره د تخصیص کونکي انتخاب باندې پیرامیټرایز شوی.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` معنی د "unallocated".د صفر ډوله ډولونه له پامه غورځول کیږي.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// د `with_capacity` په څیر ، مګر د بیرته راستن شوي `RawVec` لپاره د تخصیص کونکي انتخاب باندې پیرامیټرایز شوی.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// د `with_capacity_zeroed` په څیر ، مګر د بیرته راستن شوي `RawVec` لپاره د تخصیص کونکي انتخاب باندې پیرامیټرایز شوی.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// `Box<[T]>` په `RawVec<T>` بدلوي.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// بشپړ بفر د ټاکل شوي `len` سره `Box<[MaybeUninit<T>]>` ته واړوئ.
    ///
    /// په یاد ولرئ چې دا به د `cap` بدلونونه په سمه توګه تنظیم کړي چې ممکن ترسره شوي وي.(د توضیحاتو لپاره د ډول توضیحات وګورئ.)
    ///
    /// # Safety
    ///
    /// * `len` باید د وروستي غوښتنه شوي ظرفیت څخه لوی یا مساوي وي ، او
    /// * `len` باید د `self.capacity()` څخه کم یا مساوي وي.
    ///
    /// په یاد ولرئ ، چې غوښتل شوی ظرفیت او `self.capacity()` ممکن توپیر ولري ، ځکه چې تخصیص کونکي کولی شي د تمویل څخه لوی حافظه بلاک ټول کړي او بیرته راولي.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // د خوندیتوب اړتیا نیمه برخه چیک کړئ (موږ نشو کولی نوره نیمه برخه وګورو).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // موږ دلته د `unwrap_or_else` مخنیوی کوو ځکه چې دا د تولید شوي LLVM IR مقدار ډیریږي.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// د پوائنټر ، ظرفیت ، او تخصیص کونکي څخه `RawVec` بیا تنظیم کوي.
    ///
    /// # Safety
    ///
    /// د `ptr` باید تخصیص شي (د ورکړل شوي تخصیص `alloc` له لارې) ، او ورکړل شوي `capacity` سره.
    /// د `capacity` د اندازو ډولونو لپاره د `isize::MAX` څخه ډیر نشي.
    /// (یوازې په 32 بټ سیسټمونو اندیښنه).
    /// ZST vectors ممکن د `usize::MAX` پورې ظرفیت ولري.
    /// که `ptr` او `capacity` د `alloc` له لارې رامینځته شوي `RawVec` څخه راشي ، نو دا تضمین دی.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// د تخصیص پیل لپاره خامو اشاره ترلاسه کوي.
    /// په یاد ولرئ چې دا `Unique::dangling()` دی که `capacity == 0` یا `T` د صفر اندازې وي.
    /// په پخوانۍ قضیه کې ، تاسو باید محتاط اوسئ.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// د تخصیص وړتیا ترلاسه کوي.
    ///
    /// دا به تل `usize::MAX` وي که `T` د صفر اندازې وي.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// د دې `RawVec` ملاتړ کونکي تخصیص ته یوه ګډه حواله ورکوي.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // موږ د حافظې یو ټاکل شوی برخه لرو ، نو موږ کولی شو د خپل اوسني ترتیب ترلاسه کولو لپاره د رنټیم چیکونو څخه تیر کړو.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// ډاډ ترلاسه کوي چې بفر لږترلږه د `len + additional` عنصرونو ساتلو لپاره ځای لري.
    /// که چیرې دا دمخه کافي ظرفیت نلري ، نو د مناسب والي *O*(1) چلند ترلاسه کولو لپاره به کافي ځای او آرامۍ سلیک ځای له سره تنظیم کړي.
    ///
    /// دا چلند به محدود کړي که چیرې دا په غیر ضروري ډول خپل ځان panic ته ورسوي.
    ///
    /// که `len` له `self.capacity()` څخه زیات شي ، نو دا ممکن په حقیقت کې غوښتل شوي ځای په تخصیص کې پاتې راشي.
    /// دا واقعیا غیر محفوظ ندي ، مګر غیر محفوظ کوډ *تاسو* لیکي چې د دې فعالیت چلند پورې اړه لري ممکن مات شي.
    ///
    /// دا د `extend` په څیر د بلک-فشار عملیاتو پلي کولو لپاره مثالی دی.
    ///
    /// # Panics
    ///
    /// Panics که نوی ظرفیت د `isize::MAX` بایټونو څخه ډیر شي.
    ///
    /// # Aborts
    ///
    /// په OOM کې بندیزونه.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ذخیره به لغوه یا ویره شوې وه که چیرې لین له `isize::MAX` څخه ډیر شو نو دا خوندي دی چې دا اوس غیر چیک کړئ.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// ورته د `reserve` په څیر ، مګر د ویرې یا اختطاف پرځای غلطیو باندې بیرته راګرځي.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// ډاډ ترلاسه کوي چې بفر لږترلږه د `len + additional` عنصرونو ساتلو لپاره ځای لري.
    /// که دا دمخه نه وي ، نو د حافظې لږترلږه ممکنه اندازه به له سره تنظیم کړئ.
    /// عموما دا به دقیقا د اړتیا اندازه وي چې اړتیا ورته وي ، مګر په اصولو کې تخصیص وړ دی چې موږ له هغه څه څخه ډیر څه بیرته ورکړي.
    ///
    ///
    /// که `len` له `self.capacity()` څخه زیات شي ، نو دا ممکن په حقیقت کې غوښتل شوي ځای په تخصیص کې پاتې راشي.
    /// دا واقعیا غیر محفوظ ندي ، مګر غیر محفوظ کوډ *تاسو* لیکي چې د دې فعالیت چلند پورې اړه لري ممکن مات شي.
    ///
    /// # Panics
    ///
    /// Panics که نوی ظرفیت د `isize::MAX` بایټونو څخه ډیر شي.
    ///
    /// # Aborts
    ///
    /// په OOM کې بندیزونه.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// ورته د `reserve_exact` په څیر ، مګر د ویرې یا اختطاف پرځای غلطیو باندې بیرته راګرځي.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// ځانګړې شوې اندازه ته تخصيص کموي.
    /// که ورکړل شوې اندازه 0 وي ، په حقیقت کې په بشپړه توګه له منځه ځي.
    ///
    /// # Panics
    ///
    /// Panics که ورکړل شوی مقدار د اوسني ظرفیت څخه *لوی* وي.
    ///
    /// # Aborts
    ///
    /// په OOM کې بندیزونه.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// بیرته راګرځي که چیرې بفر اړتیا ولري د اړتیا وړ اضافي ظرفیت پوره کولو لپاره وده وکړي.
    /// په عمده توګه د `grow` انلاین کولو پرته د انلاینینګ ریزرو تلیفونونو ترسره کولو لپاره کارول کیږي.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // دا میتود معمولا ډیری وختونه انسټینټ کیږي.نو موږ غواړو دا د امکان تر اندازې کوچني وي ، ترڅو د تالیف وخت اصلاح کړئ.
    // مګر موږ دا هم غواړو چې د هغې ډیری مینځپانګې د امکان تر حده احصایه شوي کمپیوټري وي ، ترڅو تولید شوی کوډ ګړندی چالان شي.
    // نو ځکه ، دا میتود په احتیاط سره لیکل شوی ترڅو ټول کوډ چې په `T` پورې اړه لري پدې کې وي ، پداسې حال کې چې د کوډ څومره چې په `T` پورې اړه نلري ممکن په افعال کې وي چې د `T` څخه غیر عام دي.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // دا تلیفون کولو شرایطو لخوا تضمین شوی.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // له هغه وخته چې موږ د `usize::MAX` ظرفیت بیرته راوړو کله چې `elem_size` وي
            // 0 ، دلته د لاسرسي په لازمي ډول معنی لري چې `RawVec` ډیر بشپړ دی.
            return Err(CapacityOverflow);
        }

        // هیڅ نه موږ واقعیا د دې چیکونو په اړه کولی شو ، په خواشینۍ سره.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // دا د ګړندي وده تضمین کوي.
        // دوه ځله ډیر نشي کیدی ځکه چې `cap <= isize::MAX` او د `cap` ډول د `usize` دی.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` د `T` څخه غیر عام دی.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // په دې میتود کې محدودیتونه د `grow_amortized` په څیر ورته دي ، مګر دا میتود معمولا لږ ځله انسټینټ کیږي نو دا لږ مهم دی.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // له هغه وخته چې موږ د `usize::MAX` ظرفیت بیرته راوړو کله چې د ډول اندازه وي
            // 0 ، دلته د لاسرسي په لازمي ډول معنی لري چې `RawVec` ډیر بشپړ دی.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` د `T` څخه غیر عام دی.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// دا فنکشن د `RawVec` بهر دی چې د تالیف وختونه کم کړي.د توضیحاتو لپاره `RawVec::grow_amortized` پورته نظر وګورئ.
// (د `A` پیرامیټر د پام وړ ندی ، ځکه چې د `A` مختلف ډولونو شمیر چې په عمل کې لیدل کیږي د `T` ډولونو څخه ډیر کوچنی دی.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // د `RawVec::grow_*` اندازه کمولو لپاره دلته تېروتنه وګورئ.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // تخصیص د برابر والي مساوات لپاره ګوري
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// د `RawVec`*ملکیت شوي حافظې ازادوي پرته د دې د مینځپانګې پریښودو هڅه*.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// د زیرمو تېروتنې اداره کولو لپاره مرکزي فعالیت.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// موږ لاندې تضمین ته اړتیا لرو:
// * موږ هیڅکله د `> isize::MAX` بایټ اندازې څیزونه نه تخصیص کوو.
// * موږ د `usize::MAX` جریان نه کوو او په حقیقت کې ډیر لږ تخصیص کوو.
//
// په 64 بټ کې موږ یوازې د ډیر جریان چیک کولو ته اړتیا لرو ځکه چې د `> isize::MAX` بایټونو تخصیص کولو هڅه کول به خامخا ناکام شي.
// په 32-bit او 16-bit کې موږ د دې لپاره اضافي ساتونکي اضافه کولو ته اړتیا لرو که چیرې موږ په داسې پلیټ فارم کې پرمخ وړو چې وکولی شي ټول 4GB په کارن-ځای کې وکاروي ، د بیلګې په توګه ، PAE یا x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// یو مرکزي فعالیت د راپورته کولو ظرفیت جریان لپاره مسؤل دی.
// دا به ډاډ ترلاسه کړي چې د دې panics پورې اړوند کوډ تولید لږترلږه دی ځکه چې دلته یوازې یو موقعیت دی چې د ماډل په اوږدو کې د کنډک پرځای panics دی.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}