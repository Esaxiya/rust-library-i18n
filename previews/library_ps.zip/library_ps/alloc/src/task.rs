#![stable(feature = "wake_trait", since = "1.51.0")]
//! ډولونه او Traits د غیر عضوي کارونو سره کار کولو لپاره.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// په یو اعدام کونکي باندې د دندې ضبط کول.
///
/// دا trait د [`Waker`] جوړولو لپاره کارول کیدی شي.
/// یو اعدام کونکی کولی شي د دې trait پلي کول تعریف کړي ، او دا کار وکاروي ترڅو هغه وظیفه پرمخ بوځي چې پدې اجرا کونکي باندې اعدام شوي وي.
///
/// دا trait د [`RawWaker`] جوړولو لپاره د حافظې خوندي او ایرګونومیک بدیل دی.
/// دا د عام اجرا کونکي ډیزاین ملاتړ کوي په کوم کې چې د کار راویښولو لپاره کارول شوي ډاټا په [`Arc`] کې زیرمه شوي.
/// ځینې اعدام کونکي (په ځانګړي توګه دا چې د ځای په ځای شوي سیسټمونو لپاره) نشي کولی دا API وکاروي ، له همدې امله [`RawWaker`] د دې سیسټمونو لپاره د بدیل په توګه شتون لري.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// د `block_on` لومړنی فعالیت چې future اخلي او دا په اوسني تار بشپړیدو لپاره پرمخ وړي.
///
/// **Note:** دا مثال د سادگي لپاره د صداقت تجارت کوي.
/// د ډډ لاکونو مخه نیولو لپاره ، د تولید-درجې تطبیقات به د `thread::unpark` ته د منځګړیتوب تلیفونونو او همدارنګه ځړول شوي غوښتنو ته هم اړتیا ولري.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// یو وزر چې اوسنی تار راپورته کوي کله چې ویل کیږي.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// په اوسني تار بشپړیدو لپاره future چل کړئ.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future پن کړئ ترڅو دا پول شي.
///     let mut fut = Box::pin(fut);
///
///     // یو نوی شراکت رامینځته کړئ ترڅو future ته وسپارل شي.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // د بشپړیدو لپاره future چلوئ.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// دا دنده وخورئ.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// د ویکر مصرف پرته دا دنده وباسئ.
    ///
    /// که چیرې یو اعدامونکی د واکر مصرف پرته د ویښتو ارزانه لاره ملاتړ وکړي ، نو دا باید دا میتود پراخه کړي.
    /// د ډیفالټ په واسطه ، دا د [`Arc`] کلون کوي او په کلون کې [`wake`] غږوي.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // خوندي: دا خوندي دی ځکه چې خام_ واکر په خوندي ډول جوړوي
        // د آرک څخه یو راولونکی<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: د را واوکر جوړولو لپاره دا شخصي فعالیت د دې پرځای کارول کیږي
// دا د `From<Arc<W>> for RawWaker` امپلو ته دننه کول ، تر څو ډاډ ترلاسه شي چې د `From<Arc<W>> for Waker` خوندیتوب په سمه trait لیږد پورې اړه نلري ، پرځای دواړه غوښتنې یې دا فعالیت مستقیم او ښکاره بولي.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // د کلون کولو لپاره د آرک حوالې شمیرې ته وده ورکړئ.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // د ارزښت په واسطه وخورئ ، د Wake::wake فعالیت ته آرک حرکت
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // د حوالې سره وخورئ ، ویکر په لاسي ډول ډراپ کړئ چې د غورځیدو مخه ونیسئ
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // په ډراپ کې د آرک حوالې شمیره کمه کړئ
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}