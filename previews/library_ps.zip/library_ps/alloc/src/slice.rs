//! متقابل سلسلې ته د متحرک ډول لرونکی لید ، `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! سلیزونه د حافظې بلاک کې لید دی چې د ښودونکي او اوږدوالي په توګه ښودل شوی.
//!
//! ```
//! // د Vec ټوټې کول
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ټوټې ته د یو ارام فشار
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! ټوټې یا خو بدلیدونکي یا شریک دي.
//! د شریک شوي سلایس ډول `&[T]` دی ، پداسې حال کې چې د بدلون وړ سلیس ډول `&mut [T]` دی ، چیرې چې `T` د عنصر ډول څرګندوي.
//! د مثال په توګه ، تاسو کولی شئ د حافظې بلاک ته بدلون ورکړئ چې بدلون وړ سلیس ورته په ګوته کوي:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! دلته ځینې شیان دي چې پدې ماډل کې شامل دي:
//!
//! ## Structs
//!
//! دلته ډیری سلسلې شتون لري چې د سلیسونو لپاره ګټور دي ، لکه [`Iter`] ، کوم چې د سلیز څخه تکرار نمایندګي کوي.
//!
//! ## د Trait تطبیقونه
//!
//! د ټوټو لپاره د عام traits ډیری پلي کول شتون لري.ځینې مثالونه پکې شامل دي:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] ، د ټوټو لپاره چې د عنصر ډول یې [`Eq`] یا [`Ord`] دی.
//! * [`Hash`] - د ټوټې لپاره چې د عنصر ډول یې [`Hash`] دی.
//!
//! ## Iteration
//!
//! ټوټې د `IntoIterator` پلي کوي.تکرار کونکي سلیس عناصرو ته مراجعه کوي.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! د بدلون وړ سلیس دې عناصرو ته بدلون مومي:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! دا تکرار کونکی د سلیس عناصرو ته بدلیدونکي حوالې لاسته راوړي ، نو پداسې حال کې چې د سلیس عنصر ډول `i32` دی ، د تکرار عنصر ډول `&mut i32` دی.
//!
//!
//! * [`.iter`] او [`.iter_mut`] څرګند شوي میتودونه دي چې د ډیفالټ تکرار بیرته راشي.
//! * نور میتودونه چې تکرار بیرته راولي [`.split`] ، [`.splitn`] ، [`.chunks`] ، [`.windows`] او نور ډیر څه دي.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// پدې ماډل کې ډیری using یوازې د ازموینې ترتیب کې کارول کیږي.
// دا پاک دی چې یوازې د غیر قانوني شوي وارداتو خبرداری بند کړئ د دوی د حلولو څخه.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// د سلایش غزولو لومړني میتودونه
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) د NB ازمونې پرمهال د `vec!` میکرو پلي کولو لپاره اړین دی ، د نورو معلوماتو لپاره پدې فایل کې د `hack` ماډل وګورئ.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) د NB ټیسټ کولو پرمهال د `Vec::clone` پلي کولو لپاره اړین دی ، د نورو معلوماتو لپاره پدې فایل کې د `hack` انډول وګورئ.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): د cfg(test) سره `impl [T]` شتون نلري ، دا درې دندې واقعیا هغه میتودونه دي چې په `impl [T]` کې دي مګر په cfg(test) X کې ندي ، موږ اړتیا لرو د `test_permutations` ازموینې لپاره دا افعال تحویلي کړئ
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // موږ باید پدې کې انلاین صفات اضافه نکړو ځکه چې دا په `vec!` میکرو کې ډیری کارول کیږي او د perf regression لامل کیږي.
    // د مباحثې او غوره پایلو لپاره #71204 وګورئ.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // توکي لاندې لوپ کې په نښه شوي و
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) د LLVM لپاره اړینه ده چې د حدود چیکونه لرې کړي او د زپ څخه غوره کوډجن ولري.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // لږترلږه د دې اوږدوالي لپاره پورته ویشل شوي او پیل شوي و.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // د `s` ظرفیت سره پورته تخصیص شوی ، او په ptr::copy_to_non_overlapping کې یې په `s.len()` کې پیل کړئ.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// ټوټه ب Sه کوي.
    ///
    /// دا ترتیب مستحکم دی (د بیلګې په توګه ، مساوي عنصر نه تنظیموي) او *O*(*n*\*log(* n*)) بدترین قضیه).
    ///
    /// کله چې د تطبیق وړ وي ، بې ثباتي ډلبندۍ غوره ګ becauseل کیږي ځکه چې دا عموما د مستحکم ترتیب کولو څخه ګړندی وي او دا مرسته شوي حافظه نه مختص کوي.
    /// [`sort_unstable`](slice::sort_unstable) وګورئ.
    ///
    /// # اوسنی تطبیق
    ///
    /// اوسنی الګوریتم د تطبیق وړ ، تکراري یوځای کیدونکی ډول دی چې د [timsort](https://en.wikipedia.org/wiki/Timsort) لخوا هڅول شوی.
    /// دا په داسې قضیو کې خورا ګړندۍ لپاره ډیزاین شوی چیرې چې سلیز نږدې ترتیب شوی وي ، یا دوه یا ډیر ترتیب شوي ترتیبونه لري چې یو له بل وروسته قناعت کوي.
    ///
    ///
    /// همچنان ، دا د `self` نیمایي اندازې لنډمهاله ذخیره مختص کوي ، مګر د لنډو ټوټو لپاره د دې پرځای د غیر تخصیص شوي داخلولو ډول کارول کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// سلائس د پرتله کونکي فعالیت سره تنظیم کوي.
    ///
    /// دا ترتیب مستحکم دی (د بیلګې په توګه ، مساوي عنصر نه تنظیموي) او *O*(*n*\*log(* n*)) بدترین قضیه).
    ///
    /// د پرتله کونکي فعالیت باید په سیس کې د عناصرو لپاره مجموعي ترتیب تعریف کړي.که امر ټول نه وي ، د عناصرو ترتیب غیر مشخص شوی دی.
    /// یو آرډر مجموعي حکم دی که دا وي (د ټولو `a` ، `b` او `c` لپاره):
    ///
    /// * ټولیز او انټیسومیټریک: د `a < b` ، `a == b` یا `a > b` څخه بالکل یو دی ، او
    /// * انتقالي ، `a < b` او `b < c` د `a < c` معنی ورکوي.ورته باید دواړه د `==` او `>` لپاره وساتي.
    ///
    /// د مثال په توګه ، پداسې حال کې چې [`f64`] [`Ord`] نه عملي کوي ځکه چې `NaN != NaN` ، موږ کولی شو `partial_cmp` زموږ د ترتیباتو فعالیت په توګه وکاروو کله چې موږ پوه شو چې سلیس پکې `NaN` نه لري.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// کله چې د تطبیق وړ وي ، بې ثباتي ډلبندۍ غوره ګ becauseل کیږي ځکه چې دا عموما د مستحکم ترتیب کولو څخه ګړندی وي او دا مرسته شوي حافظه نه مختص کوي.
    /// [`sort_unstable_by`](slice::sort_unstable_by) وګورئ.
    ///
    /// # اوسنی تطبیق
    ///
    /// اوسنی الګوریتم د تطبیق وړ ، تکراري یوځای کیدونکی ډول دی چې د [timsort](https://en.wikipedia.org/wiki/Timsort) لخوا هڅول شوی.
    /// دا په داسې قضیو کې خورا ګړندۍ لپاره ډیزاین شوی چیرې چې سلیز نږدې ترتیب شوی وي ، یا دوه یا ډیر ترتیب شوي ترتیبونه لري چې یو له بل وروسته قناعت کوي.
    ///
    /// همچنان ، دا د `self` نیمایي اندازې لنډمهاله ذخیره مختص کوي ، مګر د لنډو ټوټو لپاره د دې پرځای د غیر تخصیص شوي داخلولو ډول کارول کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // بيرون ترتيب
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// سلیس د کلیدي استخراج کولو فعالیت سره تنظیم کوي.
    ///
    /// دا ترتیب مستحکم دی (د مثال په توګه مساوي عنصر نه تنظیموي) او *O*(*m*\* * n *\* log(*n*)) بدترین قضیه ده چیرې چې کلیدي فعالیت *O*(*m*) دی.
    ///
    /// د قیمتي کلیدي دندو لپاره (د مثال په توګه
    /// هغه افعال چې د ملکیت ساده لاسرسی یا لومړني عملیات ندي) ، [`sort_by_cached_key`](slice::sort_by_cached_key) احتمال خورا ګړندی وي ، ځکه چې دا د عنصر کلیدونه نه ترکیب کوي.
    ///
    ///
    /// کله چې د تطبیق وړ وي ، بې ثباتي ډلبندۍ غوره ګ becauseل کیږي ځکه چې دا عموما د مستحکم ترتیب کولو څخه ګړندی وي او دا مرسته شوي حافظه نه مختص کوي.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) وګورئ.
    ///
    /// # اوسنی تطبیق
    ///
    /// اوسنی الګوریتم د تطبیق وړ ، تکراري یوځای کیدونکی ډول دی چې د [timsort](https://en.wikipedia.org/wiki/Timsort) لخوا هڅول شوی.
    /// دا په داسې قضیو کې خورا ګړندۍ لپاره ډیزاین شوی چیرې چې سلیز نږدې ترتیب شوی وي ، یا دوه یا ډیر ترتیب شوي ترتیبونه لري چې یو له بل وروسته قناعت کوي.
    ///
    /// همچنان ، دا د `self` نیمایي اندازې لنډمهاله ذخیره مختص کوي ، مګر د لنډو ټوټو لپاره د دې پرځای د غیر تخصیص شوي داخلولو ډول کارول کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// سلیس د کلیدي استخراج کولو فعالیت سره تنظیم کوي.
    ///
    /// د ترتیب په جریان کې ، کلیدي فعالیت یوازې په هر عنصر کې یو ځل ویل کیږي.
    ///
    /// دا ترتیب مستحکم دی (د مثال په توګه مساوي عنصر نه تنظیموي) او *O*(*m*\* * n *+* n *\* log(*n*)) بدترین قضیه ده چیرې چې کلیدي فعالیت *O*(*m*) دی .
    ///
    /// د ساده کلیدي دندو لپاره (د بیلګې په توګه هغه دندې چې د ملکیت لاسرسی یا لومړني عملیات دي) ، [`sort_by_key`](slice::sort_by_key) خورا ګړندی دی.
    ///
    /// # اوسنی تطبیق
    ///
    /// اوسنی الګوریتم د اورسن پیټرز لخوا د [pattern-defeating quicksort][pdqsort] پراساس دی ، کوم چې د تصادفي قوسکوټ ګړندی اوسط قضیه د heapsort ګړندي بدترین قضیې سره ترکیب کوي ، پداسې حال کې چې د ځانګړو نمونو سره په سلیسونو کې خطي وخت ترلاسه کوي.
    /// دا د تخفیف قضیو مخنیوي لپاره یو څه تنظیمي کاروي ، مګر د ټاکل شوي seed سره تل د تعصبي چلند چمتو کولو لپاره.
    ///
    /// په بدترین حالت کې ، الګوریتم په `Vec<(K, usize)>` کې د سلیس اوږدوالي لنډمهاله ذخیره مختص کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // د کوچني ممکنه ډول لخوا زموږ vector شاخص کولو لپاره د مرستې میکرو ، د تخصیص کمولو لپاره.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // د `indices` عناصر بې ساري دي ، لکه څنګه چې دوی شاخص شوي ، نو هر ډول به د اصلي سلایس په پام کې نیولو سره مستحکم وي.
                // موږ دلته `sort_unstable` کاروو ځکه چې دا د حافظې لږ تخصیص ته اړتیا لري.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` په نوي `Vec` کې کاپي کړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // دلته ، `s` او `x` په خپلواکه توګه بدلون موندلی شي.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// د مختص کونکي سره نوي `Vec` ته `self` کاپي کړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // دلته ، `s` او `x` په خپلواکه توګه بدلون موندلی شي.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB ، د نورو معلوماتو لپاره پدې فایل کې د `hack` انډول وګورئ.
        hack::to_vec(self, alloc)
    }

    /// `self` د کلونونو یا تخصیص پرته vector ته بدلوي.
    ///
    /// د vector پایله به د `Vec له لارې بیرته بکس ته واړول شي<T>د `into_boxed_slice` طریقه.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` نور نشي کارول کېدلی ځکه چې دا په `x` بدل شوی دی.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB ، د نورو معلوماتو لپاره پدې فایل کې د `hack` انډول وګورئ.
        hack::into_vec(self)
    }

    /// د `n` وختونو تکرار سره vector رامینځته کوي.
    ///
    /// # Panics
    ///
    /// دا فنکشن به panic که چیرې ظرفیت به ترې تیر شي.
    ///
    /// # Examples
    ///
    /// بنسټیز کارول:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// A panic د ډیرې جریان باندې:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // که `n` د صفر څخه لوی وي ، نو دا د `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` په توګه تقسیم کیدی شي.
        // `2^expn` دا هغه شمیره ده چې د `n` کی1 ترټولو '1' بټ لخوا ښودل کیږي ، او `rem` د `n` پاتې برخه ده.
        //
        //

        // د `set_len()` لاسرسي لپاره د `Vec` کارول.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` تکرار د `buf` `توضیحي وختونو دوه چنده کولو سره ترسره کیږي.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // که `m > 0` وي ، ترټولو '1' پورې پاتې ټوټې شتون لري.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` د `self.len() * n` ظرفیت لري.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n ، 2` Expn`) تکرار د `buf` پخپله لومړي `rem` تکرارونه کاپي کولو لخوا ترسره کیږي.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // دا د `2^expn > rem` راهیسې غیر اتفاقی دی.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` د `buf.capacity()` سره مساوي (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// د `T` ټوټه په یو واحد قیمت `Self::Output` کې فلیټ کړئ.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// د `T` ټوټه په یو واحد قیمت `Self::Output` کې فلیټ کړئ ، د هر یو تر مینځ ورکړل شوی جدا کونکی ځای په ځای کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// د `T` ټوټه په یو واحد قیمت `Self::Output` کې فلیټ کړئ ، د هر یو تر مینځ ورکړل شوی جدا کونکی ځای په ځای کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// یو vector راستنوي چې د دې ټوټې کاپي لري چیرې چې هر بایټ د ASCII پورتنۍ قضیې سره مساوي کیږي.
    ///
    ///
    /// د ASCII اکرونه 'a' ته 'z' ته 'A' ته 'Z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// په ځای کې د ارزښت لوی کیدو لپاره ، [`make_ascii_uppercase`] وکاروئ.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// یو vector راستنوي چې د دې ټوټې کاپي لري چیرې چې هر بایټ د ASCII ټیټ قضیې مساوي سره نقشه شوی.
    ///
    ///
    /// د ASCII اکرونه 'A' ته 'Z' ته 'a' ته 'z' ته نقشه شوي ، مګر د ASCII غیر لیکونه بدلیږي.
    ///
    /// په ځای کې د ارزښت کمولو لپاره ، [`make_ascii_lowercase`] وکاروئ.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// د ځانګړو ډولونو ډیټا څخه د سلیزو لپاره traits غزول
////////////////////////////////////////////////////////////////////////////////

/// مرسته کونکي trait د [`[T]: : کونټات] لپاره (سلیس::کونټات).
///
/// Note: د `Item` ډول پیرامیټر پدې trait کې ندي کارول شوی ، مګر دا اجازه ورکوي چې نور عام شي.
/// پرته له دې ، موږ دا غلطي ترلاسه کوو:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// دا ځکه چې دلته ممکن د `V` ډولونه د ډیری `Borrow<[_]>` اغیزو سره شتون ولري ، لکه د `T` ډیری ډولونه به پلي شي:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// نتیجه قسم د مشغولیت وروسته
    type Output;

    /// د [`[T]: : کونټات] پلي کول (ټوټې::کونټات)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// مرسته کونکي trait د [sl [T]: : join`] لپاره (سلیس::شامل کړئ)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// نتیجه قسم د مشغولیت وروسته
    type Output;

    /// د [`[T]: : join`] پلي کول (ټوټه::شامل کول)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// د ټوټو لپاره معیاري trait پلي کول
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // په نښه کې هرڅه پریږدئ چې نا به وګرځول شي
        target.truncate(self.len());

        // target.len <= self.len د پورتنۍ برخې د ټوټېدو له امله ، نو دلته ټوټې تل په دننه کې دي.
        //
        let (init, tail) = self.split_at(target.len());

        // موجود ارزښتونه allocations/resources بیا وکاروئ.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// `v[0]` د مخکین ترتیب شوي ترتیب `v[1..]` کې دننه کوي ترڅو ټوله `v[..]` ترتیب شي.
///
/// دا د اضافی ډول ترتیب اړونده سبروټین دی.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // دلته د اضافې پلي کولو لپاره درې لارې شتون لري:
            //
            // 1. نږدې عنصرونه بدل کړئ تر هغه چې لومړی یې خپل وروستي منزل ته ورسي.
            //    په هرصورت ، پدې توګه موږ د اړتیا څخه ډیر شاوخوا ډیټا کاپي کوو.
            //    که عناصر لوی جوړښتونه وي (د کاپي کولو لپاره ګران) ، دا طریقه به ورو وي.
            //
            // 2. تر هغه وخته پورې وقفه وکړئ چې د لومړي عنصر لپاره سم ځای ونه موندل شي.
            // بیا هغه عناصر دې بریالي کړئ چې دا یې بریالي کوي ترڅو د هغې لپاره خونه جوړه کړي او په نهایت کې دې پاتې سوري کې ځای په ځای کړي.
            // دا یو ښه میتود دی.
            //
            // 3. لومړی عنصر په لنډمهاله تغیر کې کاپي کړئ.تر هغه وخته پورې چې د دې لپاره سم ځای ونه موندل شي.
            // لکه څنګه چې موږ پرمخ ځو ، هر لیږد شوی عنصر د هغې څخه دمخه سلاټ کې کاپي کړئ.
            // په نهایت کې ، د لنډمهاله تغیر څخه ډاټا په پاتې سوري کې کاپي کړئ.
            // دا میتود خورا ښه دی.
            // بنچمارکونو د دویمې میتود په پرتله یو څه ښه فعالیت ښودلی.
            //
            // ټول میتودونه بینچمارک شوي ، او دریم غوره پایلې ښیې.نو موږ هغه یو غوره کړ.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // د ننوتلو پروسې منځمهاله حالت تل د `hole` لخوا تعقیب شوی ، کوم چې دوه اهداف وړاندې کوي:
            // 1. په `is_less` کې له panics څخه د `v` بشپړتیا ساتي.
            // 2. په آخر کې په `v` کې پاتې سوري ډک کړئ.
            //
            // Panic خوندیتوب:
            //
            // که چیرې د پروسې په جریان کې `is_less` panics ، `hole` به راټیټ شي او `v` کې سوري به د `tmp` سره ډک کړي ، نو پدې توګه ډاډ ترلاسه کوي چې `v` لاهم هر هغه شی ساتي چې په پیل کې ورته یوځل ساتل شوی و.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` راکښته کیږي او پدې توګه `tmp` په `v` کې پاتې سوري کې کاپي کوي.
        }
    }

    // کله چې غورځول شوی ، نو له `src` څخه `dest` ته نقلونه.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// د غیر کمیدونکي منډو رامینځته کول `v[..mid]` او `v[mid..]` د لنډمهاله ذخیره په توګه `buf` په کارولو سره ، او پایله په `v[..]` کې ذخیره کوي.
///
/// # Safety
///
/// دوه ټوټې باید غیر خالي وي او `mid` باید په حدود کې وي.
/// د بفر `buf` باید د لنډ سلیس کاپي کولو لپاره خورا اوږد وي.
/// همچنان ، `T` باید د صفر اندازې ډول نه وي.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // د انضمام پروسې لومړی په `buf` کې لنډ ځلې کاپي کوي.
    // بیا دا نوي کاپي شوي رن او د اوږدې مودې فارورډونه (یا شاته) په ګوته کوي ، د دوی راتلونکي غیر منل شوي عنصرونه پرتله کوي او یو له لږ (یا ډیر) کاپي په `v` کې کوي.
    //
    // هرڅومره ژر چې لنډه منډه په بشپړ ډول مصرف شي ، پروسه ترسره کیږي.که چیرې اوږدې مودې لومړی مصرف شي ، نو موږ باید هغه څه کاپي کړو چې د لنډ رن څخه پاتې وي په `v` کې پاتې سوري ته.
    //
    // د عمل منځمهاله حالت تل د `hole` لخوا تعقیب شوی ، کوم چې دوه اهداف وړاندې کوي:
    // 1. په `is_less` کې له panics څخه د `v` بشپړتیا ساتي.
    // 2. په `v` کې پاتې سوري ډک کړئ که اوږدې مودې لومړی مصرف شي.
    //
    // Panic خوندیتوب:
    //
    // که چیرې د پروسې په جریان کې `is_less` panics ، `hole` به راټیټ شي او `v` کې سوري به په `buf` کې غیر متناسب حد سره ډک کړي ، نو پدې توګه ډاډ ترلاسه کوي چې `v` لاهم هر اعتراض ساتي چې دا په پیل کې یو ځل ترسره شوی.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // کی run ځنډ لنډ دی.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // په پیل کې ، دا نښې د خپلو تیرونو پیل ته په ګوته کوي.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // لږ اړخ مصرف کړئ.
            // که مساوي وي ، د ثبات ساتلو لپاره کی run لاس ته ترجیع ورکړئ.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // سمه منډه لنډه ده.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // په پیل کې ، دا نښې د دوی د تیرونو تیرونو په ګوته کوي.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // لوی اړخ مصرف کړئ.
            // که مساوي وي ، د ثبات ساتلو لپاره سم منډه غوره کړئ.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // په نهایت کې ، `hole` راولویږی.
    // که لنډ رن په بشپړه توګه ونه لګول شو ، نو د هغې پاتې شوني به اوس په `v` کې سوري ته کاپي شي.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // کله چې غورځول شوی ، نو د `start..end` حد په `dest..` کې کاپي کړئ.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` دا د صفر اندازې ډول ندی ، نو دا سمه ده چې د هغې اندازې سره ویشئ.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// دا انضمام ترتیب د ټیمسورټ څخه ځینې (مګر ټول نه) نظرونه پور کوي ، کوم چې په تفصیل سره [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) کې بیان شوی.
///
///
/// الګوریتم په کلکه توګه ښکته او نه ښکته راتلونکي برخې پیژني ، کوم چې طبیعي منډې بلل کیږي.د منډو پاتې کیدو لپاره لاهم پاتې دي.
/// هر نوی موندل شوی منډې په کڅوړه کې کښته کیږي ، او بیا د نږدې منډو یو څه جوړې تر دې پورې ګډېږي چې دا دوه بریدګر راضي نه وي:
///
/// 1. په `1..runs.len()` کې د هر `i` لپاره: `runs[i - 1].len > runs[i].len`
/// 2. په `2..runs.len()` کې د هر `i` لپاره: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// اشغالګر ډاډ ورکوي چې د چلولو مجموعي وخت *O*(*n*\*log(* n*)) بدترین قضیه ده).
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // تر دې اندازې پورې ټوټې د اضافو ډول سره په ترتیب ډول ترتیب شوي.
    const MAX_INSERTION: usize = 20;
    // ډیرې لنډې منډې د اضافې ډول سره په کار وړل کیږي ترڅو لږترلږه د دې ډیری عناصرو سپړنه وکړي.
    const MIN_RUN: usize = 10;

    // ترتیب ورکول د صفر اندازې ډولونو باندې هیڅ معنی لرونکی چلند نه لري.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // لنډې لړۍ د ځای په ځای کولو سره د داخلي تنظیم کولو له لارې تنظیميږي ترڅو د تخصیصونو مخه ونیول شي.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // د سکریچ حافظې په توګه کارولو لپاره بفر ټاکل.موږ اوږدوالی 0 ساتو نو موږ کولی شو پدې کې د `v` مینځپانګې کاپي کاپي وساتو پرته له دې چې د کاپيانو پرمخ روانې ډیسټرې له خطر سره مخ کړي که `is_less` panics.
    //
    // کله چې د دوه ترتیب شوي منډو یوځای کول ، دا بفر د لنډې منډې کاپي لري ، کوم چې به یې په اوږدو کې به یې په `len / 2` X کې اوږدوالی وي.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // په `v` کې د طبیعي منډو پیژندلو لپاره ، موږ دا شاته حرکت کوو.
    // دا ممکن د عجیب پریکړې په څیر ښکاري ، مګر دا حقیقت په پام کې ونیسئ چې ډیر ځله یوځای کیدل په مقابل لوري (forwards) کې ځي.
    // د بنچمارکونو په وینا ، د مخ په حرکت کول د شاته حرکت سره یو څه ګړندي دي.
    // د پایلې ترلاسه کولو لپاره ، د شا تعقیبولو سره د منډو پیژندل فعالیت ښه کوي.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // راتلونکی طبیعي ځغل ومومئ ، او بیرته یې وګرځئ که دا په کلکه توګه ښکته شي.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // منډې ته ځینې نور عناصر دننه کړئ که دا خورا لنډ وي.
        // د اضافه کولو ترتیب په لنډو ترتیبونو کې د یوځای کولو ترتیب څخه ګړندی دی ، نو دا کار د پام وړ وده کوي.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // دا منډه په دلۍ کې فشار کړئ.
        runs.push(Run { start, len: end - start });
        end = start;

        // د بریدګرو راضي کولو لپاره د نږدې منډو ځینې جوړې ضمیمه کړئ.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // په نهایت کې ، حتما یو رن باید باید په زینه کې پاتې شي.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // د منډو سټیک معاینه کوي او د منډو کیدو لپاره د منډو راتلونکي جوړه پیژني.
    // په ځانګړي ډول ، که `Some(r)` بیرته راستانه شي ، پدې معنی چې `runs[r]` او `runs[r + 1]` باید یوځای شي.
    // که چیرې الګوریتم باید د دې پرځای د نوي رن جوړولو ته دوام ورکړي ، نو `None` بيرته راستون شوی.
    //
    // ټیمسورټ د هغې د غټو پلي کولو لپاره بدنام دی ، لکه څنګه چې دلته تشریح شوي:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // د کیسې خلاصون دا دی: موږ باید بریدګر په ټیک څلور غوره منډو پلي کړو.
    // په یوازې درې غوره باندې د دوی پلي کول کافي ندي چې ډاډ ترلاسه کړي چې بریدګر به لاهم په سټیک کې *ټولو* منډو لپاره وساتي.
    //
    // دا فنکشن د غوره څلورو منډو لپاره دعوت کونکي په سمه توګه ګوري.
    // سربیره پردې ، که چیرې لوړه منډه په 0 شاخص کې پیل شي ، دا به تل د انضمام عملیاتو غوښتنه وکړي ترڅو پورې چې پوړ په بشپړ ډول نسکور شي ، نو د ترتیب بشپړولو لپاره.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}