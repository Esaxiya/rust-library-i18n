//! تخصیص Prelude
//!
//! د دې ماډل هدف د `alloc` crate د معمول سره کارول شوي توکو وارداتو کمول دي د ماډلونو سر ته د نړیوال وارداتو اضافه کولو سره:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;