//! د مزي شموله واحد پیوستون.'Rc' د حوالې لپاره ولاړ دی
//! Counted'.
//!
//! د [`Rc<T>`][`Rc`] ډول د `T` ډول ارزښت مشترکه ملکیت چمتو کوي ، په ڈھیر کې تخصیص شوی.
//! په [`clone`][clone] کې د [`clone`][clone] بلنه په ورته برخه کې ورته تخصیص ته نوی شاخص رامینځته کوي.
//! کله چې ورکړل شوې تخصیص ته د [`Rc`] وروستی نښه ویجاړ شي ، نو پدې تخصیص کې زیرمه شوي ارزښت (اکثرا د "inner value" په توګه ورته راجع کیږي) هم له مینځه وړل کیږي.
//!
//! په Rust کې شریک شوي حوالې د ډیفالټ په واسطه بدلون نه منع کوي ، او [`Rc`] استثنا نلري: تاسو نشئ کولی په عموم ډول د [`Rc`] دننه یو شی ته د تغیر وړ حواله ترلاسه کړئ.
//! که تاسو بدلون ته اړتیا لرئ ، نو د [`Rc`] دننه [`Cell`] یا [`RefCell`] وکړئ؛[an example of mutability inside an `Rc`][mutability] وګوره.
//!
//! [`Rc`] د غیر اټومي حوالې شمېرنې کاروي.
//! د دې معنی دا ده چې سر ټیټ ټیټ دی ، مګر [`Rc`] نشي کولی د تارونو ترمینځ لیږل شي ، او په پایله کې [`Rc`] [`Send`][send] نه پلي کوي.
//! د پایلې په توګه ، د Rust تالیف کونکی به *د تالیف وخت* وګوري چې تاسو د [threads Rc`] s د مزو ترمینځ نه لیږئ.
//! که تاسو څو اړخیزو ، اټومي حواله شمیرنې ته اړتیا لرئ ، نو [`sync::Arc`][arc] وکاروئ.
//!
//! د [`downgrade`][downgrade] میتود د غیر مالکیت [`Weak`] پوائنټر رامینځته کولو لپاره کارول کیدی شي.
//! د [`Weak`] پوائنټر کیدی شي [`اپ گریډین][اپ گریډ] d ته [`Rc`] ته ، مګر دا به [`None`] بیرته راشي که چیرې په تخصیص کې زیرمه شوي ارزښت دمخه راکښته شوی وي.
//! په بل عبارت ، د `Weak` نښې د تخصیص دننه ارزښت ژوندی نه ساتي؛په هرصورت ، دوی * تخصیص (د داخلي ارزښت لپاره ملاتړ پلورنځي) ژوندي ساتي.
//!
//! د [`Rc`] نښې ترمینځ یو دوره به هیڅکله له مینځه وی نه وړل شي.
//! د دې دلیل لپاره ، [`Weak`] د دوراناتو ماتولو لپاره کارول کیږي.
//! د مثال په توګه ، ونې کولی شي قوي [`Rc`] پوائنټرونه له والدینو نوډونو څخه ماشومانو ته ، او [`Weak`] نښې له ماشومانو څخه بیرته خپلو پلرونو ته.
//!
//! `Rc<T>` په اتوماتيک ډول د `T` ته مراجعه وکړئ (د [`Deref`] trait له لارې) ، نو تاسو کولی شئ د [`Rc<T>`][`Rc`] ډول په ارزښت `T` میتودونه زنګ ووهئ.
//! د `T` میتودونو سره د نوم نښتې مخنیوي لپاره ، د [`Rc<T>`][`Rc`] میتودونه پخپله پورې اړوند وظیفې دي ، چې د [fully qualified syntax] په کارولو سره بلل کیږي:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>د traits پلي کول لکه `Clone` ممکن د بشپړ کیفیت لرونکي ترکیب په کارولو سره هم وبلل شي.
//! ځینې خلک د بشپړ کیفیت لرونکي نحو کارولو ته ترجیح ورکوي ، پداسې حال کې چې نور د میتود کال ترکیب کارولو ته ترجیع ورکوي.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // د میتود کال تاکید
//! let rc2 = rc.clone();
//! // په بشپړ ډول وړ نحو
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] د `T` ته آټو-ډایریکریشن نه کوي ، ځکه چې داخلي ارزښت یې لا دمخه غورځول شوی و.
//!
//! # کلونونه حوالې
//!
//! د ورته تخصیص لپاره د نوي حوالې رامینځته کول لکه د موجوده حوالې شمیرل شوي پوینټر په توګه د `Clone` trait په کارولو سره د [`Rc<T>`][`Rc`] او [`Weak<T>`][`Weak`] لپاره پلي کیږي.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // لاندې دوه ترکیبونه مساوي دي.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a او b دواړه د foo په توګه ورته حافظې موقعیت ته اشاره کوي.
//! ```
//!
//! د `Rc::clone(&from)` ترکیب ترټولو ایډیوماتیک دی ځکه چې دا د کوډ مفهوم په څرګند ډول وړاندې کوي.
//! په پورتنۍ مثال کې ، دا نحو کول اسانه کوي چې وګورئ چې دا کوډ د foo ټول مینځپانګې کاپي کولو پرځای نوی حواله رامینځته کوي.
//!
//! # Examples
//!
//! یوه سناریو ته پام وکړئ چیرې چې د `ګیډیټس سیټ د ورکړل شوي `Owner` ملکیت دی.
//! موږ غواړو چې زموږ د `ګیډیټز نقطه د دوی `Owner` ته وي.موږ دا د ځانګړي ملکیت سره نشو ترسره کولی ، ځکه چې له یوې څخه ډیرې وسیلې ممکن په ورته `Owner` پورې اړه ولري.
//! [`Rc`] موږ ته اجازه راکوي چې د ګ`و ګیجیتزونو ترمینځ `Owner` شریک کړو ، او `Owner` تر هغه وخته چې په هغه کې د کوم `Gadget` ټکو تخصیص پاتې وي.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... نورې برخې
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... نورې برخې
//! }
//!
//! fn main() {
//!     // د حوالې څخه شمیرل شوی `Owner` جوړ کړئ.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // د `gadget_owner` پورې اړوند `ګیجټ Create جوړ کړئ.
//!     // د `Rc<Owner>` کلون کول موږ ته ورته `Owner` تخصیص ته نوی اشاره راکوي ، چې په پروسه کې د حوالې شمیره لوړه کوي.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // زموږ د ځایی بدلیدونکی `gadget_owner` ضایع کول.
//!     drop(gadget_owner);
//!
//!     // د `gadget_owner` له غورځیدو سره سره ، موږ لاهم توان لرو چې د `ګیجټس د `Owner` نوم چاپ کړو.
//!     // دا ځکه چې موږ یوازې یو واحد `Rc<Owner>` راټیټ کړی ، نه `Owner` چې دې ته اشاره کوي.
//!     // تر هغه وخته چې ورته `Owner` تخصیص کې نور `Rc<Owner>` په ګوته کیږي ، دا به ژوندي پاتې شي.
//!     // د ساحې پروجیکشن `gadget1.owner.name` کار کوي ځکه چې `Rc<Owner>` په اتوماتيک ډول `Owner` ته مراجعه کوي.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // د فعالیت په پای کې ، `gadget1` او `gadget2` ویجاړ شوي ، او د دوی سره زموږ `Owner` ته وروستی شمیرل شوي حوالې.
//!     // د ګیجټ مین اوس هم له مینځه ځي.
//!     //
//! }
//! ```
//!
//! که چیرې زموږ اړتیاوې بدلې شي ، او موږ باید د `Owner` څخه `Gadget` ته د وتلو وړتیا ته هم اړتیا ولرو ، موږ به په ستونزو کې بریالي شو.
//! د `Owner` څخه `Gadget` ته د [`Rc`] نښې یوه دوره معرفي کوي.
//! دا پدې مانا ده چې د دوی حوالې شمیرې هیڅکله 0 ته نشي رسیدلی ، او تخصیص به هیڅکله ویجاړ نشي:
//! د حافظې لیکد دې شاوخوا ترلاسه کولو لپاره ، موږ کولی شو د [`Weak`] نښې وکاروو.
//!
//! Rust په حقیقت کې دا په لومړي ځای کې د دې لوپ تولید یو څه ستونزمن کوي.د دې لپاره چې د دوه ارزښتونو سره پای ته ورسیږو چې یو بل ته اشاره کوي ، له دوی څخه یو باید بدلون ته اړتیا ولري.
//! دا ستونزمن کار دی ځکه چې [`Rc`] یوازې د ارزښت ریفورم کولو ته د شریک حوالې په ورکولو سره د حافظې خوندیتوب پلي کوي ، او دا مستقیم بدلون ته اجازه نه ورکوي.
//! موږ اړتیا لرو چې د X1X ایکس کې بدلون غوښتلو د ارزښت هغه برخه وپلټو ، کوم چې د *داخلي بدلون* چمتو کوي: د شریک ریفرنس له لارې بدلون ته د رسیدو لپاره میتود.
//! [`RefCell`] د وخت په وخت کې د Rust پور اخیستنې قواعد پلي کوي.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... نورې برخې
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... نورې برخې
//! }
//!
//! fn main() {
//!     // د حوالې څخه شمیرل شوی `Owner` جوړ کړئ.
//!     // په یاد ولرئ چې موږ د `RefCell` دننه `مالک` vector د `ګیډیټز دننه کړی نو ترڅو چې دا د شریک حوالې له لارې بدل کړو.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // د `gadget_owner` پورې اړوند `ګیجټس رامینځته کړئ ، لکه څنګه چې دمخه.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // د دوی `Owner` ته `ګیجټز اضافه کړئ.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` متحرک پور دلته پای ته رسي.
//!     }
//!
//!     // زموږ د `ګیډیټز over باندې سپړنه ، د هغوی جزئیات چاپول.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` دا `Weak<Gadget>` دی.
//!         // له هغه وخته چې د `Weak` نښې تخصیص نشي تضمین کولی لاهم شتون لري ، نو موږ باید `upgrade` تلیفون وکړو ، کوم چې `Option<Rc<Gadget>>` بیرته راوړي.
//!         //
//!         //
//!         // پدې حالت کې موږ پوهیږو چې تخصیص لاهم شتون لري ، نو موږ په ساده ډول د `Option` `Option`.
//!         // په یو ډیر پیچلي برنامه کې ، تاسو ممکن د `None` پایلو لپاره د پام وړ غلطي اداره کولو ته اړتیا ولرئ.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // د فعالیت په پای کې ، `gadget_owner` ، `gadget1` ، او `gadget2` ویجاړ شوي.
//!     // ګیجونو ته اوس د قوي (`Rc`) نښې نشته ، نو له همدې امله ویجاړ شوي.
//!     // دا په گیجټ مین کې د حوالې شمیره صفر کوي ، نو هغه هم له مینځه ځي.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// دا د احتمالي ساحې تنظیم کولو پروړاندې د repr(C) څخه future-پروف دی ، کوم چې به د لیږد وړ داخلي ډولونو خوندي [into|from]_raw() سره مداخله وکړي.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// د واحد طبقې حوالې-شمېرنې پوړ.'Rc' د حوالې لپاره ولاړ دی
/// Counted'.
///
/// د نورو جزیاتو لپاره [module-level documentation](./index.html) وګورئ.
///
/// د `Rc` اصلي میتودونه ټول اړوند وظیفې دي ، پدې معنی چې تاسو باید دوی ته د مثال په توګه زنګ ووهئ ، د `value.get_mut()` پرځای [`Rc::get_mut(&mut value)`][get_mut].
/// دا د داخلي ډول `T` میتودونو سره مخالفتونو څخه مخنیوی کوي.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // دا بې باوري سمه ده ځکه چې پداسې حال کې چې دا Rc ژوندي دی موږ تضمین لرو چې داخلي نښې درست دي.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// نوی `Rc<T>` جوړوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // دلته یو غښتلی ضعیف نښه شتون لري چې د ټولو قوي اشارو ملکیت لري ، کوم چې دا ډاډ ورکوي چې ضعیف ویجاړونکی هیڅکله تخصیص نه آزادوي پداسې حال کې چې قوي ویجاړونکی روان دی ، حتی که ضعیف اشاره په قوي کې زیرمه شوي وي.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// ځان ته د ضعیف حوالې په کارولو سره نوی `Rc<T>` جوړوي.
    /// د دې فعالیت بیرته راګرځیدو دمخه د ضعیف حوالې لوړولو هڅه به د `None` ارزښت پایله ولري.
    ///
    /// په هرصورت ، ضعیف حواله ممکن په آزاده توګه کلون شي او په وروسته وخت کې د کارولو لپاره زیرمه شي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... نور برخې
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // دننه د واحد ضعیف حوالې سره په "uninitialized" ایالت کې دننه جوړ کړئ.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // دا مهمه ده چې موږ د ضعیف اشاري مالکیت پریږدو ، یا نه نو حافظه ممکن د `data_fn` بیرته ستنیدو سره خلاص شي.
        // که موږ واقعیا د ملکیت تیریدو ته اړتیا درلودو ، نو موږ کولی شو د ځان لپاره یو اضافي ضعیف پوینټر رامینځته کړو ، مګر دا به د ضعیف حوالې شمیرو ته اضافي تازه معلومات رامینځته کړي چې ممکن بل ډول اړین نه وي.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // قوي حوالې باید په ګډه د ګډ ضعیف حوالې مالکیت ولري ، نو زموږ د زاړه ضعیف حوالې لپاره تخریب کونکي نه چلوئ.
        //
        mem::forget(weak);
        strong
    }

    /// د بې بنسټه مینځپانګو سره نوی `Rc` جوړوي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// د ایکسینیمکس مینځپانګو سره نوی `Rc` جوړوي ، حافظه د `0` بایټونو سره ډکیږي.
    ///
    ///
    /// د دې میتود د درست او غلط استعمال مثالونو لپاره [`MaybeUninit::zeroed`][zeroed] وګورئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// نوی `Rc<T>` جوړوي ، یوه تېروتنه راستنوي که تخصیص ناکام شي
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // دلته یو غښتلی ضعیف نښه شتون لري چې د ټولو قوي اشارو ملکیت لري ، کوم چې دا ډاډ ورکوي چې ضعیف ویجاړونکی هیڅکله تخصیص نه آزادوي پداسې حال کې چې قوي ویجاړونکی روان دی ، حتی که ضعیف اشاره په قوي کې زیرمه شوي وي.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// د بې بنسټه مینځپانګو سره نوی `Rc` جوړوي ، یوه تېروتنه راستنوي که تخصیص ناکام شي
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// د ایکس ایکس ایکس ایکس بایټونو سره ډک شوي حافظې سره بې بنسټه مینځپانګو سره نوی `Rc` رامینځته کوي ، غلطي یې بیرته راوړي که تخصیص ناکام شي
    ///
    ///
    /// د دې میتود د درست او غلط استعمال مثالونو لپاره [`MaybeUninit::zeroed`][zeroed] وګورئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// نوی `Pin<Rc<T>>` جوړوي.
    /// که `T` `Unpin` نه تطبیقوي ، نو `value` به په حافظه کې ونښلول شي او د حرکت ورکولو توان به ونه لري.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// داخلي ارزښت بیرته راګرځوي ، که چیرې `Rc` په سمه توګه یو قوي حواله ولري.
    ///
    /// بلکه ، یو [`Err`] د ورته `Rc` سره راستون شوی چې دننه شوی و.
    ///
    ///
    /// دا به بریالي شي حتی که چیرې دلته ضعیف ضعیف حوالې شتون ولري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // موجود توکي کاپي کړئ

                // ضعفونو ته اشاره وکړئ چې دوی د قوي شمیر کمولو سره وده نشي کولی ، او بیا ضمیمه "strong weak" نښې لرې کړئ پداسې حال کې چې یوازې د جعلي ضعیف کسب کولو لخوا د منطق منطق اداره کول هم.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// د بې بنسټه مینځپانګو سره د نوي حوالې حساب شوي سلیس جوړوي.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// د بې بنسټه مینځپانګو سره د نوي حوالې حساب شوي سلیز رامینځته کوي ، د حافظې سره د `0` بایټونو ډک شوی.
    ///
    ///
    /// د دې میتود د درست او غلط استعمال مثالونو لپاره [`MaybeUninit::zeroed`][zeroed] وګورئ.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>` ته واړوئ.
    ///
    /// # Safety
    ///
    /// لکه څنګه چې د [`MaybeUninit::assume_init`] سره ، دا تلیفون کونکي پورې اړه لري ترڅو تضمین وکړي چې داخلي ارزښت واقعیا په ابتدایی حالت کې دی.
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د سمدستي نامعلومه چلند لامل کیږي.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>` ته واړوئ.
    ///
    /// # Safety
    ///
    /// لکه څنګه چې د [`MaybeUninit::assume_init`] سره ، دا تلیفون کونکي پورې اړه لري ترڅو تضمین وکړي چې داخلي ارزښت واقعیا په ابتدایی حالت کې دی.
    ///
    /// دې ته زنګ وهل کله چې مینځپانګه لاهم په بشپړ ډول نه ده پیل شوې د سمدستي نامعلومه چلند لامل کیږي.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // ځنډول شوي پیل:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// د `Rc` مصرف کوي ، نغښتل شوی نښې بیرته راوړي.
    ///
    /// د حافظې لیکې څخه مخنیوي لپاره باید د [`Rc::from_raw`][from_raw] په کارولو سره اشاره باید `Rc` ته بدل شي.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ډیټا ته خام نښې چمتو کوي.
    ///
    /// شمېرې په هیڅ ډول نه متاثره کیږي او د `Rc` مصرف نه کیږي.
    /// اشارہ د اعتبار وړ دی ترڅو پورې چې په `Rc` کې قوي حسابونه شتون ولري.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // خوندي: دا د Deref::deref یا Rc::inner څخه نشي تیریدلی ځکه چې
        // دا د raw/mut پروانین ساتلو لپاره اړین دی لکه د مثال په توګه
        // `get_mut` د نښې له لارې لیکل کیدی شي وروسته له هغه چې Rc د `from_raw` له لارې ترلاسه کیږي.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// د خامو پوائنټر څخه `Rc<T>` جوړوي.
    ///
    /// خام نښې باید مخکې د [`Rc<U>::into_raw`][into_raw] ته د زنګ له لارې بیرته راستانه شوي وي چیرې چې `U` باید د `T` په څیر ورته اندازه او ساحه ولري.
    /// دا کوچني ریښتیا دي که `U` `T` وي.
    /// په یاد ولرئ چې که `U` `T` نه وي مګر ورته اندازه او ورته والی ولري ، دا اساسا د مختلف ډولونو حوالې لیږدولو په څیر دی.
    /// د نورو معلوماتو لپاره [`mem::transmute`][transmute] وګورئ چې پدې قضیه کې څه محدودیتونه پلي کیږي.
    ///
    /// د `from_raw` کارونکي باید ډاډ ترلاسه کړي چې د `T` مشخص ارزښت یوازې یو ځل راټیټ شوی.
    ///
    /// دا دنده غیر محفوظ ده ځکه چې ناسم کارول ممکن د حافظې بې باورۍ لامل شي ، حتی که بیرته راستانه شوي `Rc<T>` هیڅکله هم لاسرسی ونلري.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // د لیک د مخنیوي لپاره بیرته `Rc` ته واړوئ.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)` ته نور زنګونه به له حافظې خوندي نه وي.
    /// }
    ///
    /// // حافظه آزاده شوه کله چې `x` د پورتنۍ حوزې څخه بهر شو ، نو `x_ptr` اوس تنګ شوی!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // د اصلي RcBox موندلو لپاره له آفسیټ څخه بیرته وګرځئ.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// دې تخصیص لپاره نوی [`Weak`] پوائنټر رامینځته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ډاډ ترلاسه کړئ چې موږ ځوړند کمزوری نه جوړوو
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// دې اختصاصې ته د [`Weak`] نښو شمیره ترلاسه کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// دې تخصیص ته د قوي (`Rc`) نښو شمیره ترلاسه کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// `true` راګرځوي که چیرې پدې اختصاصې کې نور `Rc` یا [`Weak`] نښې شتون نلري.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// ورکړل شوي `Rc` ته د تغیر وړ حواله بیرته راګرځوي ، که ورته ورته تخصیص ته نور `Rc` یا [`Weak`] نښې شتون نلري.
    ///
    ///
    /// [`None`] راستنوي ، ځکه چې دا د شریک شوي ارزښت بدلولو لپاره خوندي ندي.
    ///
    /// [`make_mut`][make_mut] هم وګورئ ، کوم چې به داخلي ارزښت [`clone`][clone] وي کله چې نور نښې شتون ولري.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// ورکړل شوي `Rc` ته د بدلون پرته حواله ، پرته له کوم چیک څخه راستنوي.
    ///
    /// [`get_mut`] هم وګورئ ، کوم چې خوندي دی او مناسب چیکونه کوي.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ورته ورته تخصیص ته کوم بل `Rc` یا [`Weak`] نښې باید د راستول شوي پور دورې لپاره درناوی ونلري.
    ///
    /// دا کوچني قضیه ده که چیرې داسې نښې شتون نلري ، د مثال په توګه سمدلاسه د `Rc::new` وروسته.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // موږ محتاط یو چې *د*"count" برخې پوښښ حواله رامینځته نکړو ، ځکه چې دا به د مراجعې شمیرو ته د لاسرسي سره مخالفت ولري (د مثال په توګه.
        // د `Weak` لخوا).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// `true` راستنوي که چیرې دوه `Rc` ورته ورته تخصیص ته اشاره وکړي (د [`ptr::eq`] په ورته رګ کې).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// ورکړل شوي `Rc` ته د تغیر وړ حواله ورکوي.
    ///
    /// که ورته ورته تخصیص ته نور `Rc` نښې شتون ولري ، نو `make_mut` به د داخلي ارزښت [`clone`] نوي تخصیص ته ځانګړي کړي ترڅو د ځانګړي ملکیت ډاډ ترلاسه کړي.
    /// دې ته د کلون-آن لیکل هم ویل کیږي.
    ///
    /// که چیرې دې اختصاصې لپاره نور `Rc` نښې شتون ونلري ، نو بیا دې تخصیص ته [`Weak`] نښې به جلا شي.
    ///
    /// [`get_mut`] هم وګورئ ، کوم چې د کلینګ کولو پرځای به ناکام شي.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // هیڅ شی کلون نکوی
    /// let mut other_data = Rc::clone(&data);    // داخلي ډاټا کلون نکوي
    /// *Rc::make_mut(&mut data) += 1;        // کلون داخلي معلومات
    /// *Rc::make_mut(&mut data) += 1;        // هیڅ شی کلون نکوی
    /// *Rc::make_mut(&mut other_data) *= 2;  // هیڅ شی کلون نکوی
    ///
    /// // اوس `data` او `other_data` مختلف تخصیصونو ته ګوته نیسي.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] نښې به بې ځایه شي:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // د ډیټا کلون ته لاړ شئ ، نور Rcs شتون لري.
            // دمخه مختص شوي حافظه د کلون شوي ارزښت په مستقیم ډول د لیکلو اجازه.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // کولی شي یوازې ډاټا غلا کړي ، هغه څه چې پاتې دي هغه کمزوري دي
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // ضمیمه قوي-ضعیف ریف لرې کړئ (اړتیا نلري د جعلي ضعیفې دستګاه جوړولو لپاره-موږ پوهیږو چې نور ضعیف زموږ لپاره پاکولی شي)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // دا بې اعتباره خبره سمه ده ځکه چې موږ تضمین لرو چې راوړل شوی پوائنټر یوازې *یوازې* نښې دي چې هیڅکله به T ته راستانه شي.
        // زموږ د حوالې شمیره پدې مرحله کې 1 تضمین کیږي ، او موږ اړتیا درلوده چې پخپله `Rc<T>` `mut` وي ، نو موږ د تخصیص یوازینۍ ممکنه حواله بیرته راستون کوو.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// د کانکریټ ډول ته د `Rc<dyn Any>` ښکته کولو هڅه.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// د احتمالي-ناثبت داخلي ارزښت لپاره کافي ځای لپاره `RcBox<T>` مختص کوي چیرې چې ارزښت ترتیب چمتو کړی.
    ///
    /// د `mem_to_rcbox` فنکشن د ډاټا پوائنټر سره بلل شوی او باید د `RcBox<T>` لپاره بیرته (احتمالي غوړ)-پوینټر بیرته راشي.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // د ورکړل شوي ارزښت ترتیب په کارولو سره ترتیب محاسبه کړئ.
        // مخکې ، ترتیب د `&*(ptr as* const RcBox<T>)` په بیان کې محاسبه شوی و ، مګر دا د غلط غلط حواله رامینځته کړی (د #54908 وګورئ).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// د احتمالي-غیر منقول داخلي ارزښت لپاره د کافي ځای لپاره `RcBox<T>` مختص کوي چیرې چې ارزښت ترتیب چمتو کړی ، نو خطا بیرته راستنوي که تخصیص ناکام شي.
    ///
    ///
    /// د `mem_to_rcbox` فنکشن د ډاټا پوائنټر سره بلل شوی او باید د `RcBox<T>` لپاره بیرته (احتمالي غوړ)-پوینټر بیرته راشي.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // د ورکړل شوي ارزښت ترتیب په کارولو سره ترتیب محاسبه کړئ.
        // مخکې ، ترتیب د `&*(ptr as* const RcBox<T>)` په بیان کې محاسبه شوی و ، مګر دا د غلط غلط حواله رامینځته کړی (د #54908 وګورئ).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // د ترتیب لپاره تخصیص.
        let ptr = allocate(layout)?;

        // RcBox پیل کړئ
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// د غیر منل شوي داخلي ارزښت لپاره کافي ځای سره `RcBox<T>` مختص کوي
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // د ورکړل شوي ارزښت په کارولو سره د `RcBox<T>` لپاره تخصیص کړئ.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // د بایټونو په څیر ارزښت کاپي کړئ
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // پرته له دې چې مینځپانګې راوباسي تخصیص وړیا کړئ
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// د ورکړل شوي اوږدوالي سره `RcBox<[T]>` مختص کوي.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// عناصر له ټوټې څخه نوي ټاکل شوي Rc <\[T\]> ته کاپي کړئ
    ///
    /// غیر محفوظ ځکه چې زنګ وهونکی باید ملکیت واخلي یا `T: Copy` تړلی وي
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// د تکرار کونکي څخه `Rc<[T]>` جوړوي چې د ټاکلې اندازې څخه پیژندل شوی.
    ///
    /// چلند باید ټاکل شوی نه وي باید اندازه یې غلط وي.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic ساتونکی په داسې حال کې چې د T عناصر کلون کول.
        // د panic په پیښه کې ، هغه عناصر چې په نوي RcBox کې لیکل شوي وي به له مینځه ویسي ، بیا یې حافظه آزاده شي.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // لومړي عنصر ته نغدي
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // ټول روښانه دي.ساتونکی هیر کړئ نو دا نوی RcBox نه آزادوي.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// د `From<&[T]>` لپاره کارول شوی تخصص trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// د `Rc` کمیدل.
    ///
    /// دا به د قوي حوالې شمیره راکمه کړي.
    /// که چیرې د قوي حوالې شمیره صفر ته ورسیږي نو یوازې نور ماخذونه (که کوم دي) [`Weak`] دي ، نو موږ داخلي ارزښت `drop` کوو.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // هیڅ شی نه چاپ کوي
    /// drop(foo2);   // د "dropped!" چاپ
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // موجود څیز له منځه یوسئ
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ضمیمه "strong weak" پوائنټر اوس لرې کړئ چې موږ مینځپانګې له منځه یوړې.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// د `Rc` پوائنټر یو کلون جوړوي.
    ///
    /// دا ورته تخصیص ته بل نښې رامینځته کوي ، د قوي حوالې شمیره لوړه کوي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// د `T` لپاره د `Default` ارزښت سره نوی `Rc<T>` رامینځته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// هیک د `Eq` تخصص اجازه ورکولو لپاره که څه هم `Eq` یو میتود لري.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// موږ دا تخصص دلته کوو ، او نه په `&T` باندې د عمومي اصلاح په توګه ، ځکه چې دا به نور په ریفس کې د ټولو مساواتو چیکونو کې لګښت اضافه کړي.
/// موږ فرض کوو چې `Rc`s د لوی ارزښتونو ذخیره کولو لپاره کارول کیږي ، چې کلون کول ورو دي ، مګر د مساواتو لپاره چک کولو لپاره هم دروند دی ، چې له امله یې دا لګښت په اسانۍ سره تادیه کیږي.
///
/// دا هم احتمال لري چې د دوه `Rc` کلونونه ولرئ ، چې ورته ارزښت ته په ګوته کوي ، د دوه than&T`s څخه.
///
/// موږ دا یوازې هغه وخت کولی شو کله چې `T: Eq` د `PartialEq` په توګه ممکن په قصدي توګه غیر معقول وي.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// د دوه `Rc`s لپاره مساوات.
    ///
    /// دوه `Rc`s مساوي دي که چیرې د دوی داخلي ارزښتونه مساوي وي ، حتی که دوی په مختلف تخصیص کې زیرمه شوي وي.
    ///
    /// که چیرې `T` هم د `Eq` تطبیق کړي (د مساواتو انعطاف منونکي اثر) ، دوه `Rc` چې ورته تخصیص ته اشاره کوي تل مساوي وي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// د دوه `Rc`s لپاره مساوات.
    ///
    /// دوه `Rc`s غیر مساوي دي که چیرې د دوی داخلي ارزښتونه مساوي نه وي.
    ///
    /// که چیرې `T` هم د `Eq` تطبیق کړي (د مساواتو انعطاف منونکي اغیزه کوي) ، دوه `Rc` چې ورته تخصیص ته اشاره کوي هیڅکله غیر مساوي ندي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// د دوه `Rc`s لپاره جزوي پرتله کول.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `partial_cmp()` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// د دوه `Rc`s لپاره پرتله کولو څخه لږ.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `<` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// د دوه `Rc`s لپاره پرتله کول 'مساوي یا سره مساوي'.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `<=` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// د دوه `Rc`s لپاره لوی پرتله.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `>` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// د دوه `Rc`s لپاره پرتله کولو څخه لوی یا مساوي.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `>=` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// د دوه `Rc`s لپاره پرتله کول.
    ///
    /// دواړه د دوی داخلي ارزښتونو باندې د `cmp()` تلیفون کولو سره پرتله کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// د یوې حوالې محاسب شوي سلایټ تنظیم کړئ او د توکو په کلون کولو سره ډک کړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// د یوې مراجع څخه شمیرل شوي سوريیس ټوټه تخصیص کړئ او په دې کې `v` کاپي کړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// د یوې مراجع څخه شمیرل شوي سوريیس ټوټه تخصیص کړئ او په دې کې `v` کاپي کړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// یو بکس شوی څیز ته نوي ، حوالې شمیرل ، اختصاص ته حرکت ورکړئ.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// د یوې حوالې-شمیرل شوي سلایټونو تنظیم او د هغې مینځلو ته ورته شی.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // ویک ته اجازه ورکړئ چې خپل حافظه خالي کړي ، مګر مینځپانګې یې له مینځه نه وړي
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// په `Iterator` کې هر عنصر اخلي او دا په `Rc<[T]>` کې راټولوي.
    ///
    /// # د فعالیت ځانګړتیاوې
    ///
    /// ## عمومي قضیه
    ///
    /// په عمومي حالت کې ، په `Rc<[T]>` کې راټولول لومړی په `Vec<T>` کې راټولولو لخوا ترسره کیږي.همدا ده ، کله چې لاندې لیکنې:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// دا داسې چلند کوي لکه څنګه چې موږ لیکلي:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // د تخصیصونو لومړۍ سیټ دلته پیښیږي.
    ///     .into(); // د `Rc<[T]>` لپاره دویم تخصیص دلته واقع کیږي.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// دا به د `Vec<T>` رامینځته کولو لپاره ورته اړتیا ډیری وختونه تخصیص کړي او بیا به دا د `Vec<T>` په `Rc<[T]>` کې بدلولو لپاره یوځل مختص کړي.
    ///
    ///
    /// ## د پیژندل شوی اوږدوالي میترونه
    ///
    /// کله چې ستاسو `Iterator` `TrustedLen` پلي کوي او د دقیق اندازې څخه وي ، نو د `Rc<[T]>` لپاره به یو واحد تخصیص ورکړل شي.د مثال په توګه:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // یوازې یو تخصیص دلته واقع کیږي.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// د `Rc<[T]>` کې راټولولو لپاره تخصص trait کارول شوی.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // دا د `TrustedLen` تکرار لپاره قضیه ده.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // خوندي: موږ اړتیا لرو ډاډ ترلاسه کړو چې تکرار کونکی دقیق اوږدوالی لري او موږ یې لرو.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // نورمال پلي کیدو ته بیرته ستنیدل.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` د [`Rc`] نسخه ده چې اداره شوي تخصیص ته غیر مالکیت حواله لري.تخصیص په `Weak` پوائنټر کې د [`upgrade`] په زنګ وهلو سره لاسرسی کیږي ، کوم چې [`اختیار`] returns <`[`Rc`] returns بیرته راولي<T>>`.
///
/// لکه څنګه چې د `Weak` حواله د ملکیت په لور نه حسابیږي ، نو دا به په تخصیص کې زیرمه شوي ارزښت له مینځه وړو مخه ونه نیسي ، او پخپله `Weak` د هغه ارزښت په اړه تضمین نه کوي چې لاهم شتون لري.
/// پدې توګه دا ممکن [`None`] بیرته راشي کله چې [`اپ گریډ] d.
/// په هرصورت یادونه وکړئ چې د `Weak` حواله *کوي* پخپله د تخصیص مخه نیسي (د ملاتړ کولو پلورنځي) د ضعیف کیدو څخه.
///
/// د `Weak` پوائنټر د [`Rc`] لخوا اداره شوي تخصیص ته د لنډمهاله حوالې ساتلو لپاره ګټور دی پرته لدې چې خپل داخلي ارزښت له مینځه وړو مخه ونیسي.
/// دا د [`Rc`] نښې ترمینځ د سرکلیک حوالې مخه نیولو لپاره هم کارول کیږي ، ځکه چې د متقابل مالکیت حوالې به هیڅکله هم اجازه ورنکړي [`Rc`] له مینځه یوسي.
/// د مثال په توګه ، ونې کولی شي قوي [`Rc`] پوائنټرونه له والدینو نوډونو څخه ماشومانو ته ، او `Weak` نښې له ماشومانو څخه بیرته خپلو پلرونو ته.
///
/// د `Weak` پوائنټر ترلاسه کولو ځانګړې لاره د [`Rc::downgrade`] تلیفون کول دي.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // دا `NonNull` دی ترڅو په انیمونو کې د دې ډول اندازې مطلوب کولو ته اجازه ورکړي ، مګر دا لازمي معتبر نښې نلري.
    //
    // `Weak::new` دا `usize::MAX` ته ټاکي نو دا د دې لپاره چې په ڈھیر کې ځای ځانګړي کولو ته اړتیا ونلري.
    // دا یو ارزښت ندی چې ریښتیني نښه کونکی به یې هیڅکله ولري ځکه چې RcBox لږترلږه 2 سمون لري.
    // دا یوازې امکان لري کله چې `T: Sized`؛ناتوانه شوی `T` هیڅکله هم ځړوی.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// نوی `Weak<T>` جوړوي ، پرته له کوم حافظې تخصیص.
    /// د بیرته ستنیدو ارزښت باندې [`upgrade`] زنګ وهل تل [`None`] ورکوي.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// د مرستندویه ډول د معلوماتو ډیټا ساحې په اړه هیڅ ادعا کولو پرته د حوالې شمیرې ته د لاسرسي اجازه ورکولو لپاره.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// د دې `Weak<T>` لخوا اشارې شوي ایکس X1X ایکس ته خام پوائنټر بیرته راګرځي.
    ///
    /// اشاره یوازې د اعتبار وړ ده که چیرې ځینې قوي حوالې شتون ولري.
    /// اشاره کیدی شي ځړول ، بې خطره او یا حتی [`null`] وي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // دواړه ورته اعتراض ته اشاره کوي
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // پیاوړی دلته ژوندي ساتي ، نو موږ لاهم وکولی شو اعتراض ته لاسرسی ومومئ.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // مګر نور نه.
    /// // موږ کولی شو weak.as_ptr() ترسره کړو ، مګر پوائنټر ته لاسرسی به د نامعلومه چلند لامل شي.
    /// // assert_eq! ("سلام" ، غیر خوندي {&*weak.as_ptr() })؛
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // که چیرې اشاره جګه وي ، نو موږ لیږل شوي مستقیم بیرته راستون کوو.
            // دا د تادیاتو معتبر پته نشي کیدی ، ځکه چې تادیه لږترلږه د RcBox (usize) په څیر تنظیم شوې وي.
            ptr as *const T
        } else {
            // خوندي: که is_dangling غلط راګرځي ، نو بیا اشاره د درک وړ ده.
            // د تادیاتو بیه کیدی شي پدې مرحله کې راکښته شي ، او موږ باید مخ پروړاندې وساتو نو له دې امله د خام نقطې لاسوهنه کاروئ.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// د `Weak<T>` مصرف کوي او دا په خام پوائنټر بدلوي.
    ///
    /// دا ضعیف اشاره په خام نقطه بدلوي ، پداسې حال کې چې لاهم د یوې ضعیف حوالې مالکیت ساتل کیږي (ضعیف شمیره د دې عملیاتو لخوا نه بدله کیږي).
    /// دا د [`from_raw`] سره بیرته `Weak<T>` ته بدلیدلی شي.
    ///
    /// د [`as_ptr`] په څیر د اشارې هدف ته رسیدو ورته محدودیتونه پلي کیږي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// د [`into_raw`] لخوا رامینځته شوی خام نښې بیرته `Weak<T>` ته بدلوي.
    ///
    /// دا کولی شي په خوندي ډول د قوي حوالې ترلاسه کولو لپاره وکارول شي (وروسته د [`upgrade`] تلیفون کولو سره) یا د `Weak<T>` په غورځولو سره ضعیف شمیره ضایع کول.
    ///
    /// دا د یوې ضعیف حوالې ملکیت اخلي (د [`new`] لخوا رامینځته شوي نښو څخه استثنا سره ، ځکه چې دا هیڅ شی نلري the میتود لاهم په دوی کار کوي).
    ///
    /// # Safety
    ///
    /// نښې باید د [`into_raw`] څخه رامینځته شوي وي او لاهم باید د هغې احتمالي ضعیف حواله ولري.
    ///
    /// دا د دې زنګ وهلو په وخت کې د قوي شمیر 0 لپاره اجازه لري.
    /// په هرصورت ، دا د یوې ضعیف حوالې ملکیت اخلي چې دا مهال د خامو اشارې په توګه نمایش شوي (ضعیف شمیره د دې عملیاتو لخوا نه بدله شوې) او له همدې امله دا باید [`into_raw`] ته د تیر کال سره جوړه شي.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // وروستی ضعیف شمیره کمه کړئ.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // د مقالې لپاره Weak::as_ptr وګورئ چې د ان پیوینټر پوینټر څنګه ترلاسه کیږي.

        let ptr = if is_dangling(ptr as *mut T) {
            // دا ځورونکی ضعیف دی.
            ptr as *mut RcBox<T>
        } else {
            // که نه نو ، موږ تضمین یو چې اشاره د نونډنګل کمزوري څخه راغله.
            // خوندي: د Data_offset د زنګ وهلو لپاره خوندي دی ، ځکه چې ptr ریښتیني (احتمالي غورځول شوی) T ته اشاره کوي.
            let offset = unsafe { data_offset(ptr) };
            // په دې توګه ، موږ د بشپړ RcBox ترلاسه کولو لپاره آفسیټ بیرته راولو.
            // خوندي: نښې له ضعیف څخه پیدا شوې ، نو له همدې امله دغه آفسیټ خوندي دی.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // خوندي: موږ اوس د اصلي ضعف نښې موندلي ، نو کولی شو ضعیف رامینځته کړي.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// د `Weak` نښې ته [`Rc`] ته لوړولو هڅې ، د داخلي ارزښت غورځېدو ځنډول که بریالي وي.
    ///
    ///
    /// [`None`] راستنوي که چیرې داخلي ارزښت له هغه وخته راښکته شي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // ټول قوي نښې له منځه وړي.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// دې اختصاص ته په ګوته شوي د قوي (`Rc`) نښو شمیره ترلاسه کوي.
    ///
    /// که `self` د [`Weak::new`] په کارولو سره رامینځته شوی وي ، دا به 0 بیرته راشي.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// دې اختصاص ته په ګوته شوي د `Weak` نښو شمیره ترلاسه کوي.
    ///
    /// که هیڅ قوي نښې پاتې نشي ، دا به صفر ته راستون شي.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // ضمني ضعیف ptr کم کړئ
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// `None` بیرته راګرځی کله چې پوائنټر ځړول شوی وي او هیڅ `RcBox` تخصیص نه وي ، (د مثال په توګه ، کله چې دا `Weak` د `Weak::new` لخوا رامینځته شوی و).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // موږ محتاط یو چې *د*"data" ساحې پوښاک لپاره ریفرنس رامینځته نکړو ، ځکه چې ساحه په ورته وخت کې بدلیدلی شي (د مثال په توګه ، که وروستی `Rc` راټیټ شي ، د معلوماتو ساحه به په ځای کې پریښودل شي).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// `true` راګرځوي که چیرې دوه `ضعیف عین تخصیص ته اشاره وکړي ([`ptr::eq`] ته ورته) ، یا که دواړه هیڅ تخصیص ته اشاره نکړي (ځکه چې دا د `Weak::new()`) سره رامینځته شوي.
    ///
    ///
    /// # Notes
    ///
    /// له دې چې دا نښو سره پرتله کوي پدې معنی چې `Weak::new()` به یو بل سره مساوي کړي ، که څه هم دوی هیڅ تخصیص ته اشاره نه کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// د `Weak::new` پرتله کول.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// د `Weak` نښې غورځوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // هیڅ شی نه چاپ کوي
    /// drop(foo);        // د "dropped!" چاپ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ضعیف شمیرنه په 1 پیل کیږي ، او یوازې صفر ته لاړ شي که چیرې ټول قوي نښې له لاسه وتلې وي.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// د `Weak` پوائنټر کلون جوړوي چې ورته ورته تخصیص ته په ګوته کوي.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// نوی `Weak<T>` جوړوي ، د پیل کولو پرته د `T` لپاره حافظه مختص کوي.
    /// د بیرته ستنیدو ارزښت باندې [`upgrade`] زنګ وهل تل [`None`] ورکوي.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: موږ دلته د mem::forget سره په خوندي ډول معامله کولو لپاره چیک ایډ کړی.په تېره بیا
// که تاسو د mem::forget Rcs (یا ضعیف) یاست ، د ریفر شمیرنه کولی شي جریان ولري ، او بیا تاسو کولی شئ تخصیص آزاد کړئ پداسې حال کې چې پاتې Rcs (یا ضعیف) شتون لري.
//
// موږ تیروتنه کوو ځکه چې دا دومره تخریب شوي سناریو ده چې موږ د هغه څه په اړه پروا نلرو چې هیڅ پیښیږي-هیڅ ریښتینی برنامه باید تجربه نکړي.
//
// دا باید بې ارزښته سر ولري ځکه چې تاسو واقعیا اړتیا نلرئ چې دا د Rust کې خورا ډیر کلون ته اړتیا ولرئ د ملکیت او خوځښت سیمینټیک څخه مننه.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // موږ غواړو د ارزښت د راکمولو پرځای په فلو ډوبیدو.
        // د حوالې شمیره به هیڅکله صفر نه وي کله چې ورته ویل کیږي؛
        // په هرصورت ، موږ دلته غیرقانوني اضافه کول په بل ډول له لاسه ورکړل شوي مطلوب ته د LLVM اشارې لپاره.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // موږ غواړو د ارزښت د راکمولو پرځای په فلو ډوبیدو.
        // د حوالې شمیره به هیڅکله صفر نه وي کله چې ورته ویل کیږي؛
        // په هرصورت ، موږ دلته غیرقانوني اضافه کول په بل ډول له لاسه ورکړل شوي مطلوب ته د LLVM اشارې لپاره.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// د نښې تر شا د تادیې لپاره په `RcBox` کې آفسیټ ترلاسه کړئ.
///
/// # Safety
///
/// اشاره کونکی باید په نښه کړي (او د اعتبار وړ میټاټا ولري) د T پخوانی معتبر مثال دی ، مګر T اجازه لري چې پریښودل شي.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // د RcBox پای ته نا تایید شوي ارزښت برابر کړئ.
    // ځکه چې RcBox repr(C) دی ، دا به په یاد کې تل وروستی ډګر وي.
    // خوندي: ځکه چې یوازې نا تایید شوي ډولونه یې ممکن ټوټې دي ، trait څیزونه ،
    // او خارجي ډولونه ، د داخلي خوندیتوب اړتیا اوس مهال د align_of_val_raw اړتیاو پوره کولو لپاره کافي ده؛دا د ژبې پلي کولو تفصیل دی چې ممکن د std څخه بهر تکیه ونلري.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}