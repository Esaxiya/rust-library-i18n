use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// یو تکرار کونکی چې د بند لپاره کاروي ترڅو معلومه کړي چې ایا عنصر باید لرې شي.
///
/// دا جوړښت د [`Vec::drain_filter`] لخوا رامینځته شوی.
/// د نورو لپاره د دې اسناد وګورئ.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// د توکي شاخص چې د `next` ته د راتلونکي کال لخوا به معاینه شي.
    pub(super) idx: usize,
    /// د هغه توکو شمیر چې تر دې دمه (removed) وچ شوي دي.
    pub(super) del: usize,
    /// د وچولو دمخه د `vec` اصلي اوږدوالی.
    pub(super) old_len: usize,
    /// د فلټر ازموینه وړاندوینه.
    pub(super) pred: F,
    /// یو بیرغ چې panic ته اشاره کوي د فلټر ټیسټ وړاندوینې کې پیښ شوی.
    /// دا د `DrainFilter` پاتې برخې مصرف مخنیوي لپاره د ډراپ پلي کولو کې د اشارې په توګه کارول کیږي.
    /// هر ډول غیر پروسس شوي توکي به په `vec` کې بیک شيفټ شي ، مګر نور توکي به د فلټر وړاندوینې لخوا نه ویستل شوي یا ازمول شوي.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// لاندې اختصاص کونکي ته حواله ورکوي.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // د *وړاندوینې ویل کیدو وروسته* شاخص تازه کړئ.
                // که چیرې شاخص تازه دمخه تازه شوی وي او panics وړاندوینه وکړي ، نو پدې لړلیک کې به عنصر لیک شي.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // دا یو ډیر ګډوډ حالت دی ، او واقعیا یو څرګند کار نه دی شوی.
                        // موږ نه غواړو د `pred` د عملي کولو هڅه جاري وساتو ، نو موږ یوازې ټول غیر پروسس شوي عنصرونه شاته کوو او ویټر ته وایو چې دوی لاهم شتون لري.
                        //
                        // بیککیفټ اړین دی په وړاندوینه کې د panic دمخه د وروستي بریالي وچیدونکي توکي دوه چنده مخه ونیسي.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // د پاتې عناصرو مصرف کولو هڅه که چیرې د فلټر وړاندوینه لا نه ویره شوی.
        // موږ به هر هغه پاتې عنصر ملاتړ وکړو چې آیا موږ لا دمخه ویره کړې یا که مصرف دلته panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}