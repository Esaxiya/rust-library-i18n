use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// د Vec::from_iter لپاره کارول شوی تخصص trait
///
/// ## د پلاوي ګراف:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // یوه معمولي قضیه د vector فعالیت ته لیږدول دي چې سمدلاسه یو vector کې بیا راټولوي.
        // موږ دا شارټ سرکټ کولی شو که چیرې انټو انټر پرمختللی نه وي.
        // کله چې دا پرمختللی شوی وي موږ کولی شو حافظه له سره وکاروو او ارقام ته ډاټا ته واړوو.
        // مګر موږ یوازې دا کار کوو کله چې پایله شوي Vec به د عمومي فلټر ایټریټر پلي کولو له لارې رامینځته کولو څخه ډیر نه کارول شوې وړتیا ونلري.
        //
        // دا محدودیت په کلکه اړین ندی ځکه چې د Vec تخصیص چلند په قصدي توګه غیرمستقیم دی.
        // مګر دا محافظه کاره انتخاب دی.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // باید spec_extend() ته واستوي ځکه چې extend() پخپله د خالي Vecs لپاره spec_from ته استوي
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// دا د `iterator.as_slice().to_vec()` کاروي ځکه چې spec_extend باید د وروستي ظرفیت + اوږدوالي په اړه دلیل لپاره نور ګامونه واخلي او پدې توګه نور کار وکړي.
// `to_vec()` مستقیم سم مقدار ټاکي او په سمه توګه یې ډکوي.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): د cfg(test) سره اصلي `[T]::to_vec` میتود ، کوم چې د دې میتود تعریف لپاره اړین دی ، شتون نلري.
    // پرځای یې د `slice::to_vec` فنکشن وکاروئ کوم چې یوازې د cfg(test) NB سره شتون لري د نورو معلوماتو لپاره په slice.rs کې د slice::hack ماډل وګورئ
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}