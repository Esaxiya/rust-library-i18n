// د واسک اوږدوالی تنظیم کړئ کله چې د `SetLenOnDrop` ارزښت له حوزې بهر وځي.
//
// نظر دا دی: په سیټ لین او ډراپ کې د اوږدوالي ساحه یو محلي تغیر دی چې مطلوب کونکی به یې وګوري د Vec د ډیټا پوائنټر له لارې د هیڅ پلورنځي سره عرف نلري.
// دا د عرف تحلیلي مسلې #32155 لپاره یو کار دی
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}